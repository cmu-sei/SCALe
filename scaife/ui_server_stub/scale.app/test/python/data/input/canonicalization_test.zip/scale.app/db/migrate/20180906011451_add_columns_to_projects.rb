# <legal></legal>

class AddColumnsToProjects < ActiveRecord::Migration[5.1]
  def change
  	add_column :projects, :last_used_confidence_scheme, :integer
  	add_column :projects, :last_used_priority_scheme, :integer
  end
end
