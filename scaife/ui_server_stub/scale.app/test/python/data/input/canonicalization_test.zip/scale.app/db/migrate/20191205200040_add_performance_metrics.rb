# <legal></legal>

class AddPerformanceMetrics < ActiveRecord::Migration[5.2]
  def change
    create_table :performance_metrics do |t|
        t.string :scaife_mode
        t.string :function_name
        t.string :metric_description
    	t.datetime :transaction_timestamp
        t.string :user_id
        t.string :user_organization_id
        t.integer :project_id
        t.float :elapsed_time
        t.float :cpu_time
    end
  end
end
