# <legal></legal>

class AddTestSuiteFieldsProject < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :source_url, :string
    add_column :projects, :test_suite_version, :string
    add_column :projects, :manifest_file, :string
    add_column :projects, :manifest_url, :string
    add_column :projects, :function_info_file, :string
    add_column :projects, :file_info_file, :string
  end
end
