# <legal></legal>

class CreateTaxonomies < ActiveRecord::Migration[5.2]
  def change
    create_table :taxonomies do |t|
      t.string :name
      t.string :version_string
      t.float :version_number
      t.text :type
      t.text :author_source
      t.text :user_id
      t.text :user_org_id
      t.text :format
      t.string :scaife_tax_id
    end
  end
end
