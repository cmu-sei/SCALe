# -*- coding: utf-8 -*-

# <legal></legal>

class AddScaleIdToDisplays < ActiveRecord::Migration[4.2]
  def change
    add_column :displays, :meta_alert_id, :integer, :default => 0
	#add_column :displays, :cwe_likelihood, :integer, :time, :datetime
  end
end
