# <legal></legal>

class AddDataSubscriptionIdToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :data_subscription_id, :string
  end
end
