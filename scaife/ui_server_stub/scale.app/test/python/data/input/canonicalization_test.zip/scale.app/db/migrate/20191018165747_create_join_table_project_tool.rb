# <legal></legal>

class CreateJoinTableProjectTool < ActiveRecord::Migration[5.2]
  def change
    create_join_table :projects, :tools, table_name: :project_tools do |t|
      t.index [:project_id, :tool_id], :unique => true
      t.index [:tool_id, :project_id], :unique => true
    end
  end
end
