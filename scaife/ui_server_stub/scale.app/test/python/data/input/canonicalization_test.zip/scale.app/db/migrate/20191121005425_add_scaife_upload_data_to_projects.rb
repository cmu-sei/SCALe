# <legal></legal>

class AddScaifeUploadDataToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :project_data_source, :string
    add_column :projects, :scaife_uploaded_on, :datetime
    add_column :projects, :upload_changes_to_scaife, :boolean
  end
end
