# <legal></legal>

class CreateUserUploads < ActiveRecord::Migration[5.1]
  def change
    create_table :user_uploads do |t|
    	t.integer :meta_alert_id
    	t.text :user_columns
    	t.timestamps
    end
  end
end
