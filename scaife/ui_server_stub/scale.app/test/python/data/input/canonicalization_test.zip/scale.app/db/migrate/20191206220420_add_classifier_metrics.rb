# <legal></legal>

class AddClassifierMetrics < ActiveRecord::Migration[5.2]
  def change
    create_table :classifier_metrics do |t|
        t.integer :project_id
        t.string :scaife_classifier_instance_id
    	t.datetime :transaction_timestamp
        t.integer :num_labeled_meta_alerts_used_for_classifier_evaluation
        t.float :accuracy
        t.float :precision
        t.float :recall
        t.float :f1
    end
  end
end
