# -*- coding: utf-8 -*-

# <legal></legal>

class CreateProjects < ActiveRecord::Migration[4.2]
  def change
    create_table :projects do |t|
      t.string :name
      t.text :description
      t.string :classifier #added August 24 2018

      t.timestamps
    end
  end
end
