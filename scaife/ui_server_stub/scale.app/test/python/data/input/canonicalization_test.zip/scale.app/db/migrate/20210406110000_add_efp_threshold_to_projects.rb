class AddEfpThresholdToProjects < ActiveRecord::Migration[5.2]
  def change
      add_column :projects, :efp_confidence_threshold, :decimal
  end
end
