# <legal></legal>

class CreateJoinTableConditionCheckerLinks < ActiveRecord::Migration[5.2]
  def change
    create_join_table :conditions, :checkers, table_name: :condition_checker_links do |t|
      t.index [:condition_id, :checker_id]
      t.index [:checker_id, :condition_id]
    end
  end
end
