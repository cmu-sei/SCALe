class AddMetaAlertCountsFieldsToProjects < ActiveRecord::Migration[5.2]
  def change
      add_column :projects, :meta_alert_counts_type, :string
      add_column :projects, :confidence_threshold, :decimal
  end
end
