# <legal></legal>

class ChangeAlertPriorityToMetaAlertPriority < ActiveRecord::Migration[5.2]
  def change
    rename_column :displays, :alert_priority, :meta_alert_priority
  end
end