class CreateMetaAlertCounts < ActiveRecord::Migration[4.2]
  def change
    create_table :meta_alert_counts do |t|
      t.integer     :project_id
      t.string      :scaife_classifier_instance_id
      t.integer     :manual_verdict_count
      t.integer     :auto_verdict_count
    end
  end
end
