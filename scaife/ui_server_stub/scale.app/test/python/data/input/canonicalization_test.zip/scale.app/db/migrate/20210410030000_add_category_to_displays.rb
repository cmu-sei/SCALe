class AddCategoryToDisplays < ActiveRecord::Migration[5.2]
  def change
      add_column :displays, :category, :string
  end
end
