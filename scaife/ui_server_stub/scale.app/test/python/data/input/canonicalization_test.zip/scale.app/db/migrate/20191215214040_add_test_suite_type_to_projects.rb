# <legal></legal>

class AddTestSuiteTypeToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :test_suite_type, :string
  end
end
