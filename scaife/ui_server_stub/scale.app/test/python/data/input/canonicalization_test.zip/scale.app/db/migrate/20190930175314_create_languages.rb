# <legal></legal>

class CreateLanguages < ActiveRecord::Migration[5.2]
  def change
    create_table :languages do |t|
      t.string :name
      t.string :platform
      t.string :version
      t.string :scaife_language_id
      t.index [:name, :version], :unique => true
    end
  end
end
