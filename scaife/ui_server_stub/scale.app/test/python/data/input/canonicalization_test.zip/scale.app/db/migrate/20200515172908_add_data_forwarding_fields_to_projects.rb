# <legal></legal>

class AddDataForwardingFieldsToProjects < ActiveRecord::Migration[5.2]
  def change
        rename_column :projects, :upload_changes_to_scaife, :publish_data_updates
        change_column :projects, :publish_data_updates, :boolean, :default => false
        add_column :projects, :subscribe_to_data_updates, :boolean, :default => false
  end
end
