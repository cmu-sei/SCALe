# <legal></legal>

class AddColumnsToDisplays < ActiveRecord::Migration[5.2]
  def change
    add_column :displays, :taxonomy_id, :integer
    add_column :displays, :taxonomy, :string
    add_column :displays, :taxonomy_version, :string
    add_column :displays, :tool_id, :integer
    add_column :displays, :tool_version, :string
    rename_column :displays, :rule, :condition
  end
end
