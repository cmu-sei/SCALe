# <legal></legal>

class AddIdToColumnNames < ActiveRecord::Migration[5.2]
  def change
 	rename_column :determinations, :meta_alert, :meta_alert_id
  end
end
