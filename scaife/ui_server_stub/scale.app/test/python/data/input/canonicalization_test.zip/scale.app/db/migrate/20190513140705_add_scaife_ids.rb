# <legal></legal>

class AddScaifeIds < ActiveRecord::Migration[5.2]
  def change
  	add_column :displays, :scaife_alert_id, :string
  	add_column :displays, :scaife_meta_alert_id, :string
  	add_column :priority_schemes, :scaife_p_scheme_id, :string
  	add_column :classifier_schemes, :scaife_classifier_id, :string
  	add_column :classifier_schemes, :scaife_classifier_instance_id, :string
  	add_column :projects, :scaife_project_id, :string
        add_column :projects, :scaife_package_id, :string
  end
end
