# <legal></legal>

class AddTaxonomyToPrioritySchemes < ActiveRecord::Migration[5.1]
  def change
    add_column :priority_schemes, :cert_severity, :integer
    add_column :priority_schemes, :cert_likelihood, :integer
    add_column :priority_schemes, :cert_remediation, :integer
    add_column :priority_schemes, :cert_priority, :integer
    add_column :priority_schemes, :cert_level, :integer
    add_column :priority_schemes, :cwe_likelihood, :integer
  end
end
