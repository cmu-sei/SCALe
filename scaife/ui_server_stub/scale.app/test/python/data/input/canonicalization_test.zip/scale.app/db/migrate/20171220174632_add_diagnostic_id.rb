# -*- coding: utf-8 -*-

# <legal></legal>

class AddDiagnosticId < ActiveRecord::Migration[4.2]
  def change
    add_column :displays, :diagnostic_id, :integer, :default => 0
  end
end
