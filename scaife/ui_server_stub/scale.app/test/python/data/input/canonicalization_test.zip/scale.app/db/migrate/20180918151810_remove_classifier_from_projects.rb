# <legal></legal>

class RemoveClassifierFromProjects < ActiveRecord::Migration[5.1]
  def change
    remove_column :projects, :classifier, :string
  end
end
