class AddScaifeCiToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :git_url, :string
    add_column :projects, :git_user, :string
    add_column :projects, :git_access_token, :string
    add_column :projects, :ci_enabled, :boolean
    add_column :projects, :ci_locked, :boolean
    add_column :projects, :git_hash, :string
  end
end
