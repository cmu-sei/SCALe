# <legal></legal>

class CreatePrioritySchemes < ActiveRecord::Migration[5.1]
  def change
    create_table :priority_schemes do |t|
      t.string :name
      t.integer :project_id
      t.text :formula
      t.text :weighted_columns
      t.decimal :confidence

      t.timestamps
    end
  end
end
