# <legal></legal>

class CreateJoinTableProjectTaxonomy < ActiveRecord::Migration[5.2]
  def change
    create_join_table :projects, :taxonomies, table_name: :project_taxonomies do |t|
       t.index [:project_id, :taxonomy_id], :unique => true
       t.index [:taxonomy_id, :project_id], :unique => true
    end
  end
end
