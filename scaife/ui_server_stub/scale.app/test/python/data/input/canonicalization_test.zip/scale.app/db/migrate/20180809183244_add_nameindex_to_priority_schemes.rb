# <legal></legal>

class AddNameindexToPrioritySchemes < ActiveRecord::Migration[5.1]
  def change
  	add_index :priority_schemes, :name, unique: true
  end
end
