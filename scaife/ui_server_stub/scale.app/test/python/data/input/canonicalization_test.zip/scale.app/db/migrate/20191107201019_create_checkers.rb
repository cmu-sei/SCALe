# <legal></legal>

class CreateCheckers < ActiveRecord::Migration[5.2]
  def change
    create_table :checkers do |t|
      t.string :name
      t.integer :tool_id
      t.boolean :regex
      t.string :scaife_checker_id
    end
  end
end
