# This file should contain all the record creation needed to seed the
# database with its default values.
#
# The data can then be loaded with the rake db:seed (or created
# alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

# <legal></legal>

# make sure any non-standard app dirs exist
[ Rails.configuration.x.db_dir,
  Rails.configuration.x.external_db_dir,
  Rails.configuration.x.db_backup_dir,
  Rails.configuration.x.archive_dir,
  Rails.configuration.x.archive_backup_dir,
  Rails.configuration.x.archive_nobackup_dir].each do |d|
    FileUtils.makedirs(d)
end

# probably might want to port this to ruby, but we're using the
# python for expediency
init_db_script = Rails.root.join("scripts/init_shared_tables.py").to_s
internal_db = Rails.configuration.x.db_path
cmd = "#{init_db_script} #{internal_db}"
puts "initializing static/shared data: #{cmd}"
output = `#{cmd}`
if $? != 0
  puts "problem executing:"
  puts cmd
end
if output =~ /\S+/
  puts output
end
