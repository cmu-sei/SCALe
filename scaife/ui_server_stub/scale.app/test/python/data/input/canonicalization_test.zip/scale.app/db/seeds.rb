# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

# <legal></legal>

# probably might want to port this to ruby, but we're using the
# python for expediency
init_db_script = Rails.root.join("scripts/init_shared_tables.py").to_s
development_db = Rails.configuration.x.db_path
cmd = "#{init_db_script} #{development_db}"
puts "initializing static/shared data: #{cmd}"
output = `#{cmd}`
if $? != 0
  puts "problem executing:"
  puts cmd
end
if output =~ /\S+/
  puts output
end
