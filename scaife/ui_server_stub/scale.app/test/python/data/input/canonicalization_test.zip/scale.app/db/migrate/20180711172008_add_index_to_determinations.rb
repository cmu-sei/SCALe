# <legal></legal>

class AddIndexToDeterminations < ActiveRecord::Migration[5.1]
  def change
    add_index(:determinations, [:meta_alert, :project_id], name: 'idx_metaid_projectid')
  end
end
