# <legal></legal>

class AddCodeLanguageToDisplays < ActiveRecord::Migration[5.2]
  def change
    add_column :displays, :code_language, :string
  end
end
