# <legal></legal>

class AddNameIndexToClassifierSchemes < ActiveRecord::Migration[5.1]
  def change
  	add_index :classifier_schemes, :classifier_instance_name, unique: true
  end
end
