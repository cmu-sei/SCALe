# <legal></legal>

class CreateDeterminations < ActiveRecord::Migration[4.2]
  def change
    create_table :determinations do |t|
      t.integer :project_id
      t.integer :meta_alert
      t.datetime :time
      t.integer :verdict
      t.boolean :flag
      t.string :notes
      t.boolean :ignored
      t.boolean :dead
      t.boolean :inapplicable_environment
      t.string :dangerous_construct

      t.timestamps
    end

  end
end
