# <legal></legal>

class AddCurrentClassifierSchemeToProjects < ActiveRecord::Migration[5.1]
  def change
    add_column :projects, :current_classifier_scheme, :string
  end
end
