# <legal></legal>

class CreateTools < ActiveRecord::Migration[5.2]
  def change
    create_table :tools do |t|
      t.string :name
      t.string :platform
      t.string :version
      t.string :label
      t.string :scaife_tool_id
      t.index [:name, :platform, :version], :unique => true
    end
  end
end
