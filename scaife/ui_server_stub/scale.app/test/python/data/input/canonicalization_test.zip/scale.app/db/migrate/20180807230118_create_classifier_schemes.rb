# <legal></legal>

class CreateClassifierSchemes < ActiveRecord::Migration[5.1]
  def change
    create_table :classifier_schemes do |t|
    	t.string :classifier_instance_name
    	t.string :classifier_type
    	t.text :source_domain
    	t.datetime :created_at
    	t.datetime :updated_at
    	t.text :adaptive_heuristic_name
    	t.text :adaptive_heuristic_parameters
    	t.text :ahpo_name
    	t.text :ahpo_parameters
    	t.timestamps
    end
  end
end
