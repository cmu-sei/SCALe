# <legal></legal>

class ChangeColumnNames < ActiveRecord::Migration[5.2]
  def change
  	rename_column :displays, :diagnostic_id, :alert_id
		rename_column :messages, :diagnostic_id, :alert_id
  end
end
