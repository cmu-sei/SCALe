<legal></legal>

This directory is for the Rails tests to create external.sqlite3 files.
