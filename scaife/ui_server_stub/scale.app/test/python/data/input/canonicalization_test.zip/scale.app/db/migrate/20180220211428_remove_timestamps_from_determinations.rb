# <legal></legal>

class RemoveTimestampsFromDeterminations < ActiveRecord::Migration[4.2]
  def up
    remove_column :determinations, :created_at
    remove_column :determinations, :updated_at
  end

  def down
    add_column :determinations, :updated_at, :string
    add_column :determinations, :created_at, :string
  end
end
