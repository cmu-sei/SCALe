# <legal></legal>

class AddTestSuiteFieldsToProjects < ActiveRecord::Migration[5.2]
  def change
    add_column :projects, :test_suite_name, :string
    add_column :projects, :author_source, :string
    add_column :projects, :source_file, :string
    add_column :projects, :license_file, :string
    add_column :projects, :test_suite_sard_id, :integer
    add_column :projects, :scaife_test_suite_id, :string
  end
end
