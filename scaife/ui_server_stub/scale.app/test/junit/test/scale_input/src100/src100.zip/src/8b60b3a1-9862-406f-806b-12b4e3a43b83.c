/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4111714492
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x49FE387FL;
static int8_t g_64 = 0x7DL;
static int32_t g_68[3][6][8] = {{{0x8F5063F3L,(-1L),0L,0L,0x0F4AEDF2L,0xCDD5376EL,(-1L),0x0F4AEDF2L},{(-1L),(-1L),2L,(-1L),0L,0x8F5063F3L,0L,0x8F5063F3L},{0L,0L,1L,0L,0L,5L,(-10L),0x34E4A53EL},{0x8F5063F3L,0L,(-2L),0xDCF28D0DL,0L,0L,0xCDD5376EL,0L},{(-10L),(-1L),(-2L),0xB06862EAL,0xDCF28D0DL,2L,(-10L),0xCE61FA7BL},{0L,0L,1L,0x34E4A53EL,0x34E4A53EL,1L,2L,0xDCF28D0DL}},{{0x910C3349L,0x8F5063F3L,5L,1L,0L,0xFA36FE54L,(-1L),0x8F5063F3L},{(-2L),1L,0x16B405B7L,0xDCF28D0DL,1L,0xFA36FE54L,0xDCF28D0DL,(-9L)},{0xCE61FA7BL,0x8F5063F3L,0x34E4A53EL,2L,(-2L),(-10L),(-2L),2L},{(-9L),2L,(-9L),0x2213AABDL,(-1L),5L,(-1L),(-1L)},{0xCDD5376EL,(-1L),1L,0xCDD5376EL,0x2213AABDL,0x16B405B7L,(-1L),(-9L)},{0xCDD5376EL,0xDCF28D0DL,(-10L),0L,(-1L),0x34E4A53EL,0L,0L}},{{(-9L),(-2L),1L,1L,(-2L),(-9L),1L,0L},{0xCE61FA7BL,(-1L),0x2213AABDL,0x8F5063F3L,1L,1L,0xCE61FA7BL,0x910C3349L},{(-2L),(-1L),(-10L),0x8F5063F3L,0L,(-10L),0xCDD5376EL,0L},{0x910C3349L,0L,(-1L),1L,0xCE61FA7BL,1L,(-1L),0L},{0xDCF28D0DL,1L,0x910C3349L,0L,1L,0x2213AABDL,0L,(-9L)},{0x8F5063F3L,0xCE61FA7BL,0x34E4A53EL,0xCDD5376EL,0xDCF28D0DL,(-10L),0L,(-1L)}}};
static int32_t * volatile g_67 = &g_68[0][0][4];/* VOLATILE GLOBAL g_67 */
static int32_t g_78 = 1L;
static int64_t g_87 = 0x4513F91E7325C604LL;
static uint64_t g_88 = 4UL;
static int32_t g_90 = 1L;
static uint8_t g_114 = 0x8CL;
static uint8_t g_130 = 0xB0L;
static uint8_t *g_129 = &g_130;
static uint8_t **g_128 = &g_129;
static uint8_t g_147[5][5][4] = {{{1UL,0x2AL,255UL,255UL},{1UL,255UL,1UL,0x73L},{0x2AL,255UL,0x73L,0x73L},{255UL,255UL,0UL,255UL},{255UL,0x2AL,0UL,0x2AL}},{{255UL,1UL,0x73L,0UL},{0x2AL,1UL,1UL,0x2AL},{1UL,0x2AL,255UL,255UL},{1UL,255UL,1UL,0x73L},{0x2AL,255UL,0x73L,0x73L}},{{255UL,255UL,0UL,255UL},{255UL,0x2AL,0UL,0x2AL},{255UL,1UL,0x73L,0UL},{0x2AL,1UL,1UL,0x2AL},{1UL,0x2AL,255UL,255UL}},{{1UL,255UL,1UL,0x73L},{0x2AL,255UL,0x73L,0x73L},{255UL,255UL,0UL,255UL},{255UL,0x2AL,0UL,0x2AL},{255UL,1UL,0x73L,0UL}},{{0x2AL,1UL,1UL,0x2AL},{1UL,0x2AL,255UL,255UL},{1UL,255UL,1UL,0x73L},{0x2AL,0x73L,0UL,0UL},{0xC0L,0xC0L,255UL,0x73L}}};
static uint16_t g_149 = 0x8A42L;
static uint8_t g_150[9][1][1] = {{{2UL}},{{0xAFL}},{{2UL}},{{0xAFL}},{{2UL}},{{0xAFL}},{{2UL}},{{0xAFL}},{{2UL}}};
static int32_t *g_160 = &g_3;
static int32_t **g_159 = &g_160;
static int64_t g_165 = 1L;
static uint32_t g_200 = 0xD6E3933DL;
static volatile uint64_t g_222 = 0x9A09FAE641700D33LL;/* VOLATILE GLOBAL g_222 */
static volatile uint64_t *g_221 = &g_222;
static int32_t g_246[7][9] = {{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L},{0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L,0xC4D34D63L}};
static int16_t g_259 = 1L;
static int16_t g_261[7][7][5] = {{{0x37E7L,0x6BAFL,0x97B3L,(-1L),(-10L)},{1L,1L,0xE3D1L,0x3FD7L,(-1L)},{0x37E7L,0x7665L,0x9310L,(-5L),0xDF5FL},{0x97B3L,0xE3D1L,1L,(-10L),0x7665L},{0x6BAFL,0xDE9FL,0x1344L,0x9C3CL,0x893DL},{0x79FFL,(-5L),0x7D96L,0x893DL,(-5L)},{(-5L),(-5L),1L,0x8CE0L,0xF44FL}},{{0x8CE0L,0xDE9FL,0x893DL,(-9L),(-9L)},{(-10L),0xE3D1L,(-10L),(-5L),2L},{0x4F27L,0x7665L,1L,0x3EEFL,0x7D96L},{0x1344L,1L,0xF44FL,0x8492L,0x97B3L},{(-5L),0x6BAFL,1L,0x7D96L,0x1344L},{0x9C3CL,0x97F2L,(-10L),0x4F27L,1L},{0x9758L,0xDE88L,0x893DL,0x7D17L,(-5L)}},{{0xDE9FL,0x97B3L,1L,0L,1L},{0x6AF5L,0L,0x7D96L,0L,(-1L)},{0xA778L,1L,0x1344L,0x7D17L,(-5L)},{0x97F2L,0x4F27L,1L,0x4F27L,0x97F2L},{0x893DL,0x3EEFL,0x9310L,0x7D96L,0xC1EAL},{1L,(-9L),0xE3D1L,0x8492L,0x4F27L},{0xE3D1L,0x37E7L,0x97B3L,0x3EEFL,0xC1EAL}},{{0xDF5FL,0x8492L,(-5L),(-5L),0x97F2L},{0xC1EAL,0xDE88L,(-9L),1L,0xF44FL},{(-1L),0L,0xF44FL,0x6AF5L,0x3FD7L},{0x8492L,0L,(-5L),(-5L),1L},{0x8492L,(-10L),0x893DL,1L,(-5L)},{(-1L),1L,0x7665L,0x97F2L,0x7665L},{0xA778L,0xA778L,0xDF5FL,0xF44FL,(-5L)}},{{(-8L),0x1344L,(-1L),0xDF5FL,0x7D96L},{0x97B3L,(-1L),(-10L),0x3FD7L,1L},{1L,0x1344L,0x3EEFL,0xDE88L,0x79FFL},{(-5L),0xA778L,0xDE88L,(-9L),1L},{(-4L),1L,0x8492L,0x893DL,0x4F27L},{0x6BAFL,(-10L),0xA54FL,(-8L),2L},{0x9C3CL,0L,0xA54FL,0x1344L,(-5L)}},{{1L,0L,0x8492L,0x9C3CL,0L},{0L,0xDE88L,0xDE88L,0L,(-8L)},{1L,0x9758L,0x3EEFL,1L,0x8492L},{(-5L),(-9L),(-10L),0xC1EAL,0x97F2L},{(-5L),1L,(-1L),1L,0x7D17L},{0x8CE0L,0x7D17L,0xDF5FL,0L,0x893DL},{0x97F2L,0x8CE0L,0x7665L,0x9C3CL,0x9758L}},{{0x6AF5L,1L,0x893DL,0x1344L,0x37E7L},{2L,0x3EEFL,(-5L),(-8L),0x37E7L},{0xDE88L,0x7D96L,0xF44FL,0x893DL,0x9758L},{0xDE9FL,0x893DL,(-9L),(-9L),0x893DL},{0x7D96L,(-4L),2L,0xDE88L,0x7D17L},{(-9L),0xDE9FL,0x7D96L,0x3FD7L,0x97F2L},{1L,0xC1EAL,0x97B3L,0xDF5FL,0x8492L}}};
static uint32_t g_289[3] = {18446744073709551612UL,18446744073709551612UL,18446744073709551612UL};
static volatile uint64_t g_341 = 0x14C672D6932EEAFFLL;/* VOLATILE GLOBAL g_341 */
static int64_t g_350[7] = {0x222CCB60AA2DB91DLL,1L,0x222CCB60AA2DB91DLL,0x222CCB60AA2DB91DLL,1L,0x222CCB60AA2DB91DLL,0x222CCB60AA2DB91DLL};
static int32_t *g_443 = &g_90;
static int32_t **g_442[10] = {(void*)0,(void*)0,&g_443,(void*)0,(void*)0,&g_443,(void*)0,(void*)0,&g_443,(void*)0};


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint16_t  func_8(uint64_t  p_9, int32_t  p_10, int32_t  p_11);
static uint16_t  func_19(uint32_t  p_20, const uint64_t  p_21, uint16_t  p_22);
static int32_t  func_30(int8_t  p_31, uint64_t  p_32, uint64_t  p_33, int64_t  p_34, uint32_t  p_35);
static uint16_t  func_53(int8_t  p_54, uint64_t  p_55);
static uint16_t  func_56(int8_t  p_57, uint32_t  p_58, int16_t  p_59, uint16_t  p_60, int32_t  p_61);
static uint64_t  func_70(const int8_t * p_71, int16_t  p_72, int8_t * p_73);
static int8_t * func_75(int8_t * p_76);
static uint32_t  func_82(const int32_t  p_83, int32_t * p_84, uint32_t  p_85);
static int32_t * func_93(int8_t  p_94, int32_t * p_95, int8_t * p_96);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_259
 * writes: g_3
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_25 = 18446744073709551611UL;
    int32_t l_266 = (-2L);
    for (g_3 = 0; (g_3 != 14); g_3++)
    { /* block id: 3 */
        uint32_t l_38 = 4294967295UL;
        int8_t *l_63[7] = {(void*)0,&g_64,&g_64,(void*)0,&g_64,&g_64,(void*)0};
        int16_t *l_258 = &g_259;
        int16_t *l_260 = &g_261[2][2][1];
        int32_t l_262[10][4][1] = {{{0xBB022EA6L},{0x0B8C973AL},{0L},{0x5D77D440L}},{{(-6L)},{0x5D77D440L},{0L},{0x0B8C973AL}},{{0xBB022EA6L},{0xE62EBD1BL},{0xB48D6DF3L},{0x55BD5735L}},{{(-1L)},{(-1L)},{0x55BD5735L},{0xB48D6DF3L}},{{0xE62EBD1BL},{0xBB022EA6L},{0x0B8C973AL},{0L}},{{0x5D77D440L},{(-6L)},{0x5D77D440L},{0L}},{{0x0B8C973AL},{0xBB022EA6L},{0xE62EBD1BL},{0xB48D6DF3L}},{{0x55BD5735L},{(-1L)},{0x6402A00CL},{(-1L)}},{{0x5D77D440L},{(-3L)},{0x55BD5735L},{0xE62EBD1BL}},{{5L},{(-6L)},{0xBB022EA6L},{(-6L)}}};
        int64_t *l_265[2];
        int8_t l_267 = 0L;
        int32_t l_391[2];
        int32_t *l_392 = &g_78;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_265[i] = &g_165;
        for (i = 0; i < 2; i++)
            l_391[i] = 1L;
    }
    return g_259;
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_165 g_350 g_149 g_200 g_246 g_2 g_128 g_129 g_68 g_261
 * writes: g_64 g_149
 */
static uint16_t  func_8(uint64_t  p_9, int32_t  p_10, int32_t  p_11)
{ /* block id: 159 */
    int32_t l_361[8] = {0x938638C1L,0x938638C1L,0x938638C1L,0x938638C1L,0x938638C1L,0x938638C1L,0x938638C1L,0x938638C1L};
    int32_t *l_362 = &l_361[2];
    int32_t *l_363 = &g_246[3][1];
    int32_t *l_364 = &g_68[0][0][4];
    int32_t *l_365 = &g_68[0][0][4];
    int32_t *l_366[1];
    int8_t l_367 = (-1L);
    int32_t l_368 = 0x57E27B00L;
    uint32_t l_369 = 1UL;
    int8_t *l_380 = &l_367;
    uint16_t *l_385 = &g_149;
    int32_t l_388 = 4L;
    int i;
    for (i = 0; i < 1; i++)
        l_366[i] = &g_78;
    for (g_64 = 0; (g_64 != 22); g_64 = safe_add_func_int32_t_s_s(g_64, 2))
    { /* block id: 162 */
        l_361[1] = (g_165 && (safe_lshift_func_int16_t_s_u(l_361[1], 13)));
    }
    --l_369;
    (*l_362) = ((safe_rshift_func_int8_t_s_s((((safe_div_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_s((g_64 = ((*l_380) = (*l_362))), 7)), (safe_div_func_uint32_t_u_u((safe_add_func_uint32_t_u_u(p_11, ((g_350[3] , ((*l_385)++)) < ((l_388 < (p_11 , ((void*)0 != &g_222))) <= (g_200 < ((((p_9 <= (-1L)) ^ (*l_363)) & 0x99L) >= g_2)))))), 0x84E16D6EL)))), (*l_362))) , l_380) != (*g_128)), 5)) , (*l_364));
    return g_261[3][5][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_159 g_160 g_128 g_129 g_246 g_3 g_341 g_261 g_149 g_64
 * writes: g_160 g_130 g_114 g_149 g_88 g_150 g_341 g_246
 */
static uint16_t  func_19(uint32_t  p_20, const uint64_t  p_21, uint16_t  p_22)
{ /* block id: 101 */
    uint32_t *l_281 = &g_200;
    int32_t l_282 = (-1L);
    int8_t *l_291 = &g_64;
    uint32_t l_294 = 0x45D1DAE8L;
    const uint8_t *l_296 = &g_147[3][2][2];
    const uint8_t **l_295 = &l_296;
    int32_t l_303 = 0xFFDCB38DL;
    int32_t *l_304 = &g_246[5][1];
    int32_t l_331 = 4L;
    int32_t l_332 = 9L;
    int32_t l_334 = 0x04191B9CL;
    int32_t l_335 = 0x574A7358L;
    int32_t l_337 = 7L;
    int32_t l_339 = 0L;
    int32_t l_340[6] = {(-1L),1L,(-1L),(-1L),1L,(-1L)};
    uint8_t l_351[8][3][8] = {{{0x7EL,1UL,254UL,255UL,251UL,0x0AL,0x6EL,9UL},{250UL,0xE6L,252UL,249UL,255UL,0UL,0x76L,253UL},{9UL,0xEFL,0x4AL,0xE6L,6UL,255UL,0x04L,0UL}},{{0xDBL,0x04L,0x56L,1UL,6UL,0UL,255UL,0UL},{1UL,0x74L,6UL,0UL,0xD5L,0xF6L,0UL,255UL},{0x04L,255UL,255UL,0UL,249UL,0UL,0x4AL,6UL}},{{0x56L,249UL,0x04L,251UL,0x29L,0UL,0xA6L,0x4AL},{9UL,253UL,0UL,254UL,0xF6L,1UL,0x6EL,1UL},{251UL,1UL,0x43L,1UL,251UL,1UL,255UL,0x0EL}},{{1UL,0xEFL,0x01L,0x7EL,0x02L,250UL,0x29L,1UL},{255UL,4UL,0x01L,0x76L,6UL,249UL,255UL,0xA6L},{0x02L,255UL,0x43L,0x0EL,0UL,251UL,0x6EL,255UL}},{{255UL,0xE6L,0UL,252UL,0UL,0UL,0xA6L,0x74L},{0x01L,0UL,0x04L,255UL,6UL,0xE6L,0x4AL,0xEFL},{0x7EL,1UL,255UL,1UL,253UL,1UL,0UL,9UL}},{{0UL,9UL,6UL,249UL,255UL,0UL,255UL,250UL},{1UL,255UL,0x56L,1UL,0x8BL,0UL,0x04L,1UL},{0x56L,1UL,0x4AL,0x76L,0x87L,0x87L,0x76L,0x4AL}},{{0x74L,0x74L,252UL,255UL,0UL,0x0EL,0x6EL,0xAFL},{0x8BL,0x4AL,254UL,0UL,249UL,1UL,0UL,0xAFL},{0x4AL,0UL,255UL,255UL,0x02L,9UL,0xEFL,1UL}},{{0UL,0UL,0x43L,0x87L,255UL,0x01L,0xAFL,0xEFL},{1UL,0xA6L,4UL,0x4AL,0UL,0x6EL,0x43L,254UL},{0xDBL,0UL,253UL,0UL,0UL,254UL,0UL,0x71L}}};
    int i, j, k;
    if (p_22)
    { /* block id: 102 */
        int32_t * const l_287 = &g_246[3][1];
        uint8_t *l_288[3][1][9] = {{{&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[1][2][3],(void*)0,&g_147[1][2][3]}},{{&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[1][2][3],(void*)0,&g_147[1][2][3]}},{{&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[3][2][3],(void*)0,&g_147[3][2][3],&g_147[1][2][3],(void*)0,&g_147[1][2][3]}}};
        uint16_t *l_290 = &g_149;
        int32_t *l_292 = &g_68[0][0][2];
        int16_t *l_302[1];
        int32_t **l_305 = (void*)0;
        int32_t *l_306 = &g_90;
        uint8_t l_307 = 0x24L;
        int32_t l_311 = 0xAF8A9D95L;
        int32_t l_333 = 0x070DA7D1L;
        int32_t l_336[5];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_302[i] = (void*)0;
        for (i = 0; i < 5; i++)
            l_336[i] = 3L;
        (*g_159) = (l_292 = (*g_159));
        if ((l_307 = (0x92B72CE6AA63A2EDLL > ((+((**g_128) = ((l_306 = &g_90) != (void*)0))) & (*l_287)))))
        { /* block id: 113 */
            uint32_t l_320 = 0xEE41A932L;
            for (g_114 = 0; g_114 < 9; g_114 += 1)
            {
                for (g_149 = 0; g_149 < 1; g_149 += 1)
                {
                    for (g_88 = 0; g_88 < 1; g_88 += 1)
                    {
                        g_150[g_114][g_149][g_88] = 1UL;
                    }
                }
            }
            for (l_294 = 0; (l_294 <= 2); l_294 += 1)
            { /* block id: 117 */
                int32_t *l_308 = &l_282;
                int32_t l_309 = 0L;
                int32_t *l_310 = &g_78;
                int32_t *l_312 = (void*)0;
                int32_t *l_313 = &g_246[3][1];
                int32_t *l_314 = &g_246[0][6];
                int32_t *l_315 = &l_311;
                int32_t l_316 = (-1L);
                int32_t *l_317 = &g_68[0][0][4];
                int32_t *l_318 = &l_303;
                int32_t *l_319[10][7] = {{&g_68[0][2][0],&g_246[2][5],&g_246[6][1],&g_246[2][5],&g_68[0][2][0],&g_68[0][2][0],&g_246[2][5]},{&g_246[4][2],&g_68[0][0][4],&g_246[4][2],&l_282,&l_282,&g_246[4][2],&g_68[0][0][4]},{&g_246[2][5],&g_78,&g_246[6][1],&g_246[6][1],&g_78,&g_246[2][5],&g_78},{&g_246[4][2],&l_282,&l_282,&g_246[4][2],&g_68[0][0][4],&g_246[4][2],&l_282},{&g_68[0][2][0],&g_68[0][2][0],&g_246[2][5],&g_246[6][1],&g_246[2][5],&g_68[0][2][0],&g_68[0][2][0]},{(void*)0,&l_282,&g_78,&l_282,(void*)0,(void*)0,&l_282},{(void*)0,&g_78,(void*)0,&g_246[2][5],&g_246[2][5],(void*)0,&g_78},{&l_282,&g_68[0][0][4],&g_78,&g_78,&g_68[0][0][4],&l_282,&g_68[0][0][4]},{(void*)0,&g_246[2][5],&g_246[2][5],(void*)0,&g_78,(void*)0,&g_246[2][5]},{(void*)0,(void*)0,&l_282,&g_78,&l_282,(void*)0,(void*)0}};
                int i, j;
                (*g_159) = &l_303;
                --l_320;
                for (p_20 = 0; (p_20 <= 2); p_20 += 1)
                { /* block id: 122 */
                    int8_t *l_323 = &g_64;
                    int8_t *l_324 = &g_64;
                    int32_t *l_325 = &g_68[0][0][4];
                }
                return g_3;
            }
            (*g_159) = (*g_159);
        }
        else
        { /* block id: 135 */
            int32_t *l_326 = &g_68[1][5][6];
            int32_t *l_327 = &g_78;
            int32_t l_328[10] = {0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L,0xD2B11E06L};
            int32_t *l_329 = &l_328[4];
            int32_t *l_330[3];
            int32_t l_338 = 0xA060F067L;
            int i;
            for (i = 0; i < 3; i++)
                l_330[i] = (void*)0;
            g_341++;
        }
        for (l_339 = 0; (l_339 >= 0); l_339 -= 1)
        { /* block id: 140 */
            int32_t *l_344 = &l_282;
            int32_t *l_345 = &g_246[6][8];
            uint32_t l_346 = 0UL;
            l_346++;
            return g_261[2][6][4];
        }
    }
    else
    { /* block id: 144 */
        int32_t *l_349[8] = {&l_337,&l_337,&l_337,&l_337,&l_337,&l_337,&l_337,&l_337};
        int i;
        for (l_339 = 0; (l_339 >= 0); l_339 -= 1)
        { /* block id: 147 */
            return (*l_304);
        }
        l_351[3][1][1]++;
        for (g_149 = 0; (g_149 == 20); ++g_149)
        { /* block id: 153 */
            uint32_t l_356 = 0x7AB4BD69L;
            (*l_304) = (l_356 ^= 0xF59170CBL);
        }
    }
    return g_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_67 g_68
 * writes: g_68
 */
static int32_t  func_30(int8_t  p_31, uint64_t  p_32, uint64_t  p_33, int64_t  p_34, uint32_t  p_35)
{ /* block id: 96 */
    int16_t l_263 = 0x5E22L;
    int32_t *l_264 = &g_68[0][2][1];
    (*g_67) = p_32;
    (*l_264) &= l_263;
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_67 g_68 g_78 g_147 g_128 g_129 g_130 g_2 g_150 g_88 g_221 g_87 g_64 g_114 g_159 g_160 g_222 g_246
 * writes: g_68 g_78 g_64 g_130 g_149 g_200 g_88 g_114 g_147 g_150 g_160
 */
static uint16_t  func_53(int8_t  p_54, uint64_t  p_55)
{ /* block id: 7 */
    uint32_t l_240 = 5UL;
    int32_t *l_241[4];
    int32_t * const l_245 = &g_246[3][1];
    int32_t * const *l_244 = &l_245;
    uint64_t *l_255 = (void*)0;
    uint64_t *l_256[6] = {&g_88,&g_88,&g_88,&g_88,&g_88,&g_88};
    int64_t l_257 = 0x604263C3DD7BFDBELL;
    int i;
    for (i = 0; i < 4; i++)
        l_241[i] = &g_68[1][4][1];
    for (p_55 = 0; (p_55 > 58); p_55 = safe_add_func_uint32_t_u_u(p_55, 8))
    { /* block id: 10 */
        uint8_t l_69 = 0x3AL;
        const int8_t *l_74 = (void*)0;
        (*g_67) |= p_55;
        l_240 |= (l_69 && func_70(l_74, p_55, func_75(&g_64)));
        (*g_159) = l_241[2];
    }
    g_78 ^= (safe_add_func_int16_t_s_s(p_54, (((l_244 = &l_241[2]) == ((((p_54 < (0xF209L || (((l_257 |= (safe_rshift_func_int8_t_s_u((((*g_221) == (safe_sub_func_int16_t_s_s((0xC5EAA5A20392186ALL == ((((safe_add_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u((((*g_159) = l_241[2]) != (void*)0), ((*l_245) , 0x12L))) ^ p_54), 6L)) | (*l_245)) >= (*l_245)) & 5UL)), 0x5ECCL))) >= 0xF1068F0A819F9FF2LL), 3))) <= 0x3399677F995BE46CLL) , (*l_245)))) , (*g_221)) , p_55) , (void*)0)) == g_68[2][3][0])));
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_56(int8_t  p_57, uint32_t  p_58, int16_t  p_59, uint16_t  p_60, int32_t  p_61)
{ /* block id: 4 */
    int32_t l_62 = 0xA64E785CL;
    return l_62;
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_147 g_128 g_129 g_130 g_2 g_78 g_150 g_88 g_221 g_87 g_67 g_68 g_114 g_159 g_160
 * writes: g_64 g_68 g_130 g_78 g_149 g_200 g_88 g_114 g_147 g_150 g_160
 */
static uint64_t  func_70(const int8_t * p_71, int16_t  p_72, int8_t * p_73)
{ /* block id: 49 */
    int16_t l_169 = 0L;
    uint16_t *l_184 = &g_149;
    int32_t l_203[5] = {0x2C683EECL,0x2C683EECL,0x2C683EECL,0x2C683EECL,0x2C683EECL};
    int i;
    for (g_64 = 0; (g_64 <= (-9)); --g_64)
    { /* block id: 52 */
        int32_t *l_170 = &g_68[0][0][0];
        int32_t *l_171 = &g_78;
        int32_t *l_172 = &g_68[2][4][1];
        int32_t *l_173 = &g_68[0][0][4];
        int32_t *l_174 = &g_68[0][0][4];
        int32_t *l_175 = &g_78;
        int32_t *l_176 = &g_68[0][1][2];
        int32_t *l_177[4];
        uint16_t l_178 = 65534UL;
        uint16_t *l_181 = &l_178;
        uint32_t *l_199 = &g_200;
        int32_t l_201 = 0xAC5C6483L;
        int32_t l_205 = 1L;
        uint32_t l_208 = 0UL;
        int8_t *l_224 = &g_64;
        int8_t l_236 = 1L;
        int i;
        for (i = 0; i < 4; i++)
            l_177[i] = &g_78;
        --l_178;
        if ((((*l_181) = p_72) && (((*l_173) = (safe_mul_func_int16_t_s_s(1L, 0x7CA1L))) ^ (((l_184 == ((safe_sub_func_uint32_t_u_u((((**g_128) ^= (g_147[3][2][3] , 0x4CL)) > ((safe_add_func_uint32_t_u_u(((*l_199) = (((*l_171) |= (safe_div_func_uint64_t_u_u((safe_rshift_func_int16_t_s_u(g_2, 8)), (safe_rshift_func_int16_t_s_s(0x9C97L, 11))))) < (safe_mul_func_uint16_t_u_u(((*l_184) = (((&g_149 == l_184) & p_72) == 0L)), g_150[6][0][0])))), 0x71376D48L)) , (*l_171))), l_169)) , (void*)0)) == l_201) | 0xFD5E730205D3DB02LL))))
        { /* block id: 60 */
            int32_t l_202 = (-2L);
            int32_t l_204 = (-4L);
            int32_t l_206 = 6L;
            int32_t l_207[9][10][2] = {{{(-3L),1L},{0L,0xF0DCE50DL},{1L,1L},{0xF0DCE50DL,1L},{0L,(-1L)},{0L,1L},{0xF0DCE50DL,1L},{1L,0xF0DCE50DL},{0L,1L},{(-3L),1L}},{{1L,(-1L)},{1L,1L},{(-3L),1L},{0L,0xF0DCE50DL},{1L,1L},{0xF0DCE50DL,1L},{0L,(-1L)},{0L,1L},{0xF0DCE50DL,1L},{1L,0xF0DCE50DL}},{{(-3L),(-1L)},{(-1L),0xF0DCE50DL},{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL},{(-1L),(-1L)},{(-3L),0L},{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL},{(-3L),1L},{(-3L),0xF0DCE50DL}},{{0L,(-1L)},{0xF0DCE50DL,0L},{(-3L),(-1L)},{(-1L),0xF0DCE50DL},{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL},{(-1L),(-1L)},{(-3L),0L},{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL}},{{(-3L),1L},{(-3L),0xF0DCE50DL},{0L,(-1L)},{0xF0DCE50DL,0L},{(-3L),(-1L)},{(-1L),0xF0DCE50DL},{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL},{(-1L),(-1L)},{(-3L),0L}},{{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL},{(-3L),1L},{(-3L),0xF0DCE50DL},{0L,(-1L)},{0xF0DCE50DL,0L},{(-3L),(-1L)},{(-1L),0xF0DCE50DL},{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL}},{{(-1L),(-1L)},{(-3L),0L},{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL},{(-3L),1L},{(-3L),0xF0DCE50DL},{0L,(-1L)},{0xF0DCE50DL,0L},{(-3L),(-1L)},{(-1L),0xF0DCE50DL}},{{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL},{(-1L),(-1L)},{(-3L),0L},{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL},{(-3L),1L},{(-3L),0xF0DCE50DL},{0L,(-1L)},{0xF0DCE50DL,0L}},{{(-3L),(-1L)},{(-1L),0xF0DCE50DL},{0xF0DCE50DL,1L},{0xF0DCE50DL,0xF0DCE50DL},{(-1L),(-1L)},{(-3L),0L},{0xF0DCE50DL,(-1L)},{0L,0xF0DCE50DL},{(-3L),1L},{(-3L),0xF0DCE50DL}}};
            int i, j, k;
            if (l_169)
                break;
            ++l_208;
        }
        else
        { /* block id: 63 */
            uint64_t l_218[8] = {18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL};
            int32_t l_234 = 0x732B9EF2L;
            int8_t *l_237 = &l_236;
            uint8_t *l_239 = &g_150[3][0][0];
            int i;
            for (l_208 = (-2); (l_208 <= 17); l_208 = safe_add_func_int8_t_s_s(l_208, 9))
            { /* block id: 66 */
                uint64_t *l_215[8] = {&g_88,&g_88,&g_88,&g_88,&g_88,&g_88,&g_88,&g_88};
                int32_t l_223 = 0x17D50ABDL;
                int64_t *l_233[7][10] = {{&g_87,&g_165,&g_165,(void*)0,(void*)0,&g_165,&g_165,&g_87,&g_165,&g_87},{(void*)0,(void*)0,&g_87,(void*)0,&g_87,(void*)0,(void*)0,&g_165,&g_165,(void*)0},{&g_165,&g_87,&g_87,&g_87,&g_87,&g_165,(void*)0,&g_87,(void*)0,&g_165},{&g_165,&g_87,&g_165,&g_87,(void*)0,(void*)0,&g_165,&g_165,(void*)0,(void*)0},{(void*)0,&g_165,&g_165,(void*)0,&g_87,&g_87,(void*)0,&g_87,&g_87,(void*)0},{&g_87,(void*)0,&g_87,&g_87,(void*)0,&g_165,&g_165,(void*)0,&g_87,&g_87},{&g_165,&g_165,(void*)0,(void*)0,&g_87,(void*)0,&g_87,(void*)0,(void*)0,&g_165}};
                int i, j;
                (*l_174) = (65535UL < (safe_div_func_uint16_t_u_u(8UL, (((g_88++) != (l_218[6] == (safe_lshift_func_int8_t_s_u((g_221 == l_215[3]), 3)))) ^ l_223))));
                (*g_159) = func_93(l_218[6], &l_205, l_224);
                (*l_170) = (18446744073709551615UL < (safe_mod_func_int8_t_s_s(g_2, ((((l_218[2] & ((*l_181) = ((void*)0 != &g_149))) > (g_130 , 7UL)) == (l_203[0] = (p_72 < (safe_div_func_int64_t_s_s(((*g_160) == p_72), p_72))))) , l_234))));
                l_234 &= (*g_160);
            }
            (*g_159) = ((((*l_237) = (~l_236)) == ((*l_239) = (~((**g_128) = (**g_128))))) , (void*)0);
            (*g_159) = func_93(g_2, &l_234, &g_64);
        }
        (*l_175) |= p_72;
        if (l_203[2])
            break;
    }
    return l_169;
}


/* ------------------------------------------ */
/* 
 * reads : g_67 g_68 g_78
 * writes: g_78
 */
static int8_t * func_75(int8_t * p_76)
{ /* block id: 12 */
    int32_t *l_77[9][5] = {{&g_78,&g_3,&g_68[1][0][2],&g_68[1][2][4],(void*)0},{&g_3,&g_68[1][2][7],&g_68[0][0][4],&g_68[1][2][7],&g_3},{&g_68[1][0][2],&g_68[1][2][7],&g_3,&g_68[0][0][6],&g_78},{&g_78,&g_3,(void*)0,&g_3,&g_68[2][3][5]},{&g_68[1][2][7],&g_78,&g_68[1][3][3],&g_68[1][2][7],&g_78},{&g_68[0][0][4],&g_3,&g_68[0][5][4],&g_68[0][5][4],&g_3},{&g_78,&g_68[1][0][2],&g_68[0][5][4],(void*)0,(void*)0},{&g_78,&g_78,&g_68[1][3][3],&g_68[1][2][4],(void*)0},{&g_68[0][0][6],&g_68[1][2][7],(void*)0,&g_68[0][0][4],&g_3}};
    uint8_t l_79 = 0x3BL;
    int64_t *l_86 = &g_87;
    int32_t *l_89 = &g_90;
    int i, j;
    g_78 &= (*g_67);
    --l_79;
    return &g_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_78 g_64 g_87 g_128 g_129 g_130 g_2 g_67 g_3 g_68 g_114 g_147 g_150
 * writes: g_78 g_114 g_68 g_147 g_149 g_150 g_67
 */
static uint32_t  func_82(const int32_t  p_83, int32_t * p_84, uint32_t  p_85)
{ /* block id: 17 */
    int64_t l_91 = (-9L);
    int32_t *l_92 = &g_78;
    int8_t *l_112 = &g_64;
    uint8_t *l_113 = &g_114;
    int32_t **l_151 = &l_92;
    int32_t *l_158 = &g_78;
    int32_t **l_157 = &l_158;
    int32_t ***l_156[1][2][9] = {{{&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157},{&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157,&l_157}}};
    uint16_t *l_161 = &g_149;
    uint64_t l_162 = 0xEC7B67EAC4BFEEEDLL;
    int8_t *l_163 = (void*)0;
    uint16_t l_164 = 0x46BDL;
    int i, j, k;
    (*l_92) ^= l_91;
    (*l_92) = (-1L);
    g_67 = func_93(((safe_lshift_func_int8_t_s_u((-1L), ((*l_113) = ((safe_rshift_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u((0xD8L | (p_83 < (((void*)0 != &l_91) < (safe_add_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((*l_92), ((+(((((((safe_mul_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u(0x4591L, (((g_78 != (((*l_92) && g_64) != (-2L))) >= (*l_92)) | p_83))) < p_83), g_64)) || 2UL) , l_112) == l_112) < 0xAF2EL) < g_78) | g_87)) || 0x5FL))), (*l_92)))))), p_85)) >= 0x4BL), 7)) == 0x9BL)))) & g_87), &g_3, l_112);
    p_84 = (*l_157);
    return l_164;
}


/* ------------------------------------------ */
/* 
 * reads : g_87 g_128 g_129 g_130 g_64 g_2 g_78 g_67 g_3 g_68 g_114 g_147 g_150
 * writes: g_114 g_78 g_68 g_147 g_149 g_150
 */
static int32_t * func_93(int8_t  p_94, int32_t * p_95, int8_t * p_96)
{ /* block id: 21 */
    uint8_t *l_115 = &g_114;
    uint8_t *l_117 = (void*)0;
    uint8_t **l_116 = &l_117;
    int64_t *l_124 = &g_87;
    int64_t **l_125 = &l_124;
    uint8_t **l_131 = &g_129;
    int32_t l_132 = (-1L);
    int32_t *l_133[9][3] = {{&g_3,&g_3,&g_68[0][0][4]},{(void*)0,&g_68[0][0][4],&g_68[0][0][4]},{&g_68[0][0][4],&g_68[1][1][4],&g_78},{(void*)0,&g_68[1][1][4],(void*)0},{&g_3,&g_68[0][0][4],&g_78},{&g_3,&g_3,&g_68[0][0][4]},{(void*)0,&g_68[0][0][4],&g_68[0][0][4]},{&g_68[0][0][4],&g_68[1][1][4],&g_78},{(void*)0,&g_68[1][1][4],(void*)0}};
    int i, j;
    g_78 &= ((p_94 , ((l_115 != ((*l_116) = &g_114)) & (((((safe_add_func_int64_t_s_s((safe_div_func_int16_t_s_s(g_87, (((((p_94 <= (((*l_115) = 0xB3L) == (((safe_sub_func_int32_t_s_s((((*l_125) = l_124) == &g_87), (((safe_mul_func_int8_t_s_s(((l_131 = g_128) != &g_129), l_132)) > (**g_128)) , l_132))) > l_132) , 0xB1L))) | 65532UL) < 1UL) , l_132) , 0x3B3BL))), p_94)) || (*p_96)) > g_2) >= 4294967292UL) | 0x289B7103L))) <= g_87);
    for (p_94 = (-12); (p_94 > (-19)); p_94 = safe_sub_func_int64_t_s_s(p_94, 1))
    { /* block id: 29 */
        int32_t **l_136 = &l_133[8][0];
        uint8_t *l_141 = &g_130;
        uint8_t *l_146 = &g_147[3][2][3];
        uint16_t *l_148 = &g_149;
        (*l_136) = p_95;
        g_78 |= (p_94 , ((*g_67) = (-1L)));
        (*g_67) &= (*p_95);
        g_150[3][0][0] &= (safe_add_func_uint16_t_u_u(((*l_148) = (((safe_mul_func_int8_t_s_s(((*g_67) != (-3L)), (**g_128))) & 0UL) > ((((*l_115) |= (**g_128)) == (l_141 == (*g_128))) | (safe_sub_func_int8_t_s_s((((*l_146) ^= (safe_sub_func_int32_t_s_s(0x3A335C48L, ((0x4BC14809L != g_78) , 0x00A2DC19L)))) >= (-7L)), (*g_129)))))), 0L));
    }
    return p_95;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_68[i][j][k], "g_68[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_147[i][j][k], "g_147[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_149, "g_149", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_150[i][j][k], "g_150[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_165, "g_165", print_hash_value);
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_222, "g_222", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_246[i][j], "g_246[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_259, "g_259", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_261[i][j][k], "g_261[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_289[i], "g_289[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_341, "g_341", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_350[i], "g_350[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 98
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 32
breakdown:
   depth: 1, occurrence: 76
   depth: 2, occurrence: 13
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1
   depth: 17, occurrence: 1
   depth: 24, occurrence: 1
   depth: 27, occurrence: 2
   depth: 29, occurrence: 1
   depth: 32, occurrence: 1

XXX total number of pointers: 110

XXX times a variable address is taken: 162
XXX times a pointer is dereferenced on RHS: 57
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 8
XXX times a pointer is dereferenced on LHS: 64
breakdown:
   depth: 1, occurrence: 61
   depth: 2, occurrence: 3
XXX times a pointer is compared with null: 8
XXX times a pointer is compared with address of another variable: 2
XXX times a pointer is compared with another pointer: 2
XXX times a pointer is qualified to be dereferenced: 1836

XXX max dereference level: 2
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 490
   level: 2, occurrence: 106
XXX number of pointers point to pointers: 15
XXX number of pointers point to scalars: 95
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 18.2
XXX average alias set size: 1.36

XXX times a non-volatile is read: 348
XXX times a non-volatile is write: 182
XXX times a volatile is read: 17
XXX    times read thru a pointer: 3
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 215
XXX percentage of non-volatile access: 95.7

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 67
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 18
   depth: 2, occurrence: 13
   depth: 3, occurrence: 8

XXX percentage a fresh-made variable is used: 13.6
XXX percentage an existing variable is used: 86.4
********************* end of statistics **********************/

