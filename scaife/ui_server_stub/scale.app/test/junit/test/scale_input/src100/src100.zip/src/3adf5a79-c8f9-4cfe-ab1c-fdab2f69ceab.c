/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2154344679
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   const uint64_t  f0;
   const int8_t  f1;
   uint16_t  f2;
   volatile int8_t  f3;
   const signed f4 : 1;
   volatile uint8_t  f5;
   volatile uint32_t  f6;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S1 {
   const volatile int8_t  f0;
};
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
struct S2 {
   const signed f0 : 8;
   unsigned f1 : 18;
   volatile uint8_t  f2;
   unsigned f3 : 11;
};
#pragma pack(pop)

struct S3 {
   const unsigned f0 : 27;
   volatile uint16_t  f1;
   uint64_t  f2;
};

union U4 {
   int32_t  f0;
   volatile signed f1 : 17;
};

union U5 {
   volatile int16_t  f0;
   int8_t * const  f1;
   volatile uint32_t  f2;
   volatile int32_t  f3;
   volatile uint16_t  f4;
};

union U6 {
   struct S1  f0;
   uint32_t  f1;
};

union U7 {
   volatile uint16_t  f0;
   int8_t * const  f1;
   volatile signed f2 : 17;
   int8_t  f3;
   volatile struct S1  f4;
};

union U8 {
   int8_t * f0;
   struct S1  f1;
   const volatile unsigned f2 : 24;
};

/* --- GLOBAL VARIABLES --- */
static const int32_t g_27[2] = {(-9L),(-9L)};
static int16_t g_63 = (-1L);
static uint32_t g_68 = 0x90F9CF50L;
static int8_t g_82 = 0L;
static int32_t g_91 = 9L;
static int32_t * volatile g_90 = &g_91;/* VOLATILE GLOBAL g_90 */
static int32_t *g_97 = &g_91;
static int32_t ** const  volatile g_96 = &g_97;/* VOLATILE GLOBAL g_96 */
static volatile union U8 g_99[9][2] = {{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}},{{0},{0}}};
static volatile union U8 *g_98 = &g_99[2][1];
static volatile union U7 g_107 = {0x8F0BL};/* VOLATILE GLOBAL g_107 */
static union U6 g_108 = {{5L}};/* VOLATILE GLOBAL g_108 */
static uint32_t g_110 = 18446744073709551609UL;
static int32_t ** volatile g_133[6] = {&g_97,&g_97,&g_97,&g_97,&g_97,&g_97};
static int32_t ** volatile g_135 = &g_97;/* VOLATILE GLOBAL g_135 */
static uint64_t g_143[1] = {1UL};
static volatile union U4 g_152[9][8][2] = {{{{-7L},{0xBCB40BA7L}},{{0xBCB40BA7L},{-7L}},{{0xBCB40BA7L},{0xBCB40BA7L}},{{-7L},{0xBCB40BA7L}},{{0xBCB40BA7L},{-7L}},{{0xBCB40BA7L},{0xBCB40BA7L}},{{-7L},{0xBCB40BA7L}},{{0xBCB40BA7L},{-7L}}},{{{0xBCB40BA7L},{0xBCB40BA7L}},{{-7L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}}},{{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}}},{{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}}},{{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}}},{{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}}},{{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}}},{{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}}},{{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}},{{0L},{-7L}},{{-7L},{0L}},{{-7L},{-7L}}}};
static volatile union U8 g_173[3][9] = {{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0},{0}}};
static uint8_t g_182 = 0xA2L;
static int32_t g_192 = 0xDC146C1EL;
static int32_t * const g_191 = &g_192;
static int32_t * const *g_190 = &g_191;
static int64_t g_230 = 0x7E6F4C367A671B5ELL;
static uint8_t *g_249 = &g_182;
static uint8_t * volatile * volatile g_248[4] = {&g_249,&g_249,&g_249,&g_249};
static int32_t ** volatile g_253 = (void*)0;/* VOLATILE GLOBAL g_253 */
static union U8 g_256 = {0};/* VOLATILE GLOBAL g_256 */
static volatile struct S1 g_257 = {0x14L};/* VOLATILE GLOBAL g_257 */
static struct S1 g_258 = {0x33L};/* VOLATILE GLOBAL g_258 */
static volatile int8_t *g_260 = &g_107.f3;
static volatile int8_t **g_259 = &g_260;
static union U4 g_261 = {-1L};/* VOLATILE GLOBAL g_261 */
static union U4 g_264 = {0xC724F6DBL};/* VOLATILE GLOBAL g_264 */
static uint64_t **g_271 = (void*)0;
static uint64_t *** volatile g_270 = &g_271;/* VOLATILE GLOBAL g_270 */
static union U5 ** volatile g_290 = (void*)0;/* VOLATILE GLOBAL g_290 */
static uint16_t g_300 = 0xD8E1L;
static union U4 g_370 = {0xFE9FE08AL};/* VOLATILE GLOBAL g_370 */
static volatile struct S2 g_389 = {-0,289,0x08L,14};/* VOLATILE GLOBAL g_389 */
static int32_t ** volatile g_392 = &g_97;/* VOLATILE GLOBAL g_392 */
static uint8_t g_419 = 0xE6L;
static int64_t g_443 = (-1L);
static uint16_t *g_453 = (void*)0;
static int32_t ** volatile g_462 = &g_97;/* VOLATILE GLOBAL g_462 */
static volatile union U5 g_479 = {0xDE48L};/* VOLATILE GLOBAL g_479 */
static struct S3 g_483 = {6111,8UL,18446744073709551615UL};/* VOLATILE GLOBAL g_483 */
static struct S3 *g_482 = &g_483;
static struct S3 g_495 = {2268,65535UL,18446744073709551615UL};/* VOLATILE GLOBAL g_495 */
static union U6 g_512 = {{1L}};/* VOLATILE GLOBAL g_512 */
static struct S3 g_519[7][9][4] = {{{{6980,1UL,0xDC08434A7E381A96LL},{9490,1UL,0x7271939D2F84F1ECLL},{1253,65530UL,0x8AD5CB1D2A691310LL},{6607,0x78B5L,0x8D311142099F832DLL}},{{8101,1UL,0UL},{6729,1UL,5UL},{6111,65535UL,1UL},{358,2UL,18446744073709551613UL}},{{7374,65535UL,0xD87977EC3D881791LL},{10000,65531UL,0xDFCB74FB2A9267C8LL},{719,0xC2A7L,0x0C32C5D20319E91CLL},{6207,0xF306L,0x53363FF28CFC0586LL}},{{6729,1UL,5UL},{6607,0x78B5L,0x8D311142099F832DLL},{1695,0x6456L,0xFEAEDE3505A2D5E3LL},{5354,0x3F00L,0xE444E60323B760FELL}},{{5513,2UL,18446744073709551609UL},{11270,0x0EDBL,18446744073709551615UL},{6729,1UL,5UL},{1723,65535UL,0UL}},{{8947,0UL,0xC464A7D2C4370C23LL},{347,0x335BL,0x6A01FFECC01C9519LL},{3316,0x3209L,0x76993A80BFA9227CLL},{3316,0x3209L,0x76993A80BFA9227CLL}},{{3660,0UL,0x68DDBFA053D2864DLL},{3660,0UL,0x68DDBFA053D2864DLL},{11150,65532UL,0xFF9B10BBF2B9FAB4LL},{11281,0x8605L,9UL}},{{6980,1UL,0xDC08434A7E381A96LL},{6207,0xF306L,0x53363FF28CFC0586LL},{358,2UL,18446744073709551613UL},{10520,3UL,0UL}},{{4165,0UL,0xE53045BD1E8B36E4LL},{6591,0xA7C7L,0xEA27300EACFC8219LL},{3658,0xA204L,18446744073709551606UL},{8101,1UL,0UL}}},{{{10000,65531UL,0xDFCB74FB2A9267C8LL},{11281,0x8605L,9UL},{3994,0xAC6FL,18446744073709551615UL},{4617,0xADFBL,0x4E223383F2871015LL}},{{11281,0x8605L,9UL},{5513,2UL,18446744073709551609UL},{3545,0x0A57L,18446744073709551615UL},{3658,0xA204L,18446744073709551606UL}},{{4528,0xACA5L,0x33924AC93078B3C1LL},{7353,0xCEC2L,18446744073709551611UL},{5354,0x3F00L,0xE444E60323B760FELL},{11150,65532UL,0xFF9B10BBF2B9FAB4LL}},{{719,0xC2A7L,0x0C32C5D20319E91CLL},{1723,65535UL,0UL},{10866,0xF3F8L,0xE85D3DA190B05777LL},{7498,1UL,0xE3E9985CE8822A2DLL}},{{3545,0x0A57L,18446744073709551615UL},{6535,1UL,5UL},{3660,0UL,0x68DDBFA053D2864DLL},{6697,0UL,0x79A3C18AA77CB711LL}},{{3713,1UL,0xB65B79D96ECEE043LL},{6591,0xA7C7L,0xEA27300EACFC8219LL},{1695,0x6456L,0xFEAEDE3505A2D5E3LL},{5513,2UL,18446744073709551609UL}},{{4867,0x21DFL,1UL},{347,0x335BL,0x6A01FFECC01C9519LL},{1361,8UL,0xF69008CA34DF0093LL},{8101,1UL,0UL}},{{5513,2UL,18446744073709551609UL},{6980,1UL,0xDC08434A7E381A96LL},{11281,0x8605L,9UL},{6591,0xA7C7L,0xEA27300EACFC8219LL}},{{347,0x335BL,0x6A01FFECC01C9519LL},{10000,65531UL,0xDFCB74FB2A9267C8LL},{3545,0x0A57L,18446744073709551615UL},{6111,65535UL,1UL}}},{{{6716,0xC1F7L,0xCF3CC333776CF44ELL},{3545,0x0A57L,18446744073709551615UL},{6716,0xC1F7L,0xCF3CC333776CF44ELL},{1805,0x34ADL,0x71290EFDB011652ALL}},{{6591,0xA7C7L,0xEA27300EACFC8219LL},{1723,65535UL,0UL},{7498,1UL,0xE3E9985CE8822A2DLL},{1253,65530UL,0x8AD5CB1D2A691310LL}},{{6611,65526UL,0UL},{5561,0xE7F2L,18446744073709551606UL},{4165,0UL,0xE53045BD1E8B36E4LL},{1723,65535UL,0UL}},{{3713,1UL,0xB65B79D96ECEE043LL},{719,0xC2A7L,0x0C32C5D20319E91CLL},{4165,0UL,0xE53045BD1E8B36E4LL},{6729,1UL,5UL}},{{6611,65526UL,0UL},{6716,0xC1F7L,0xCF3CC333776CF44ELL},{7498,1UL,0xE3E9985CE8822A2DLL},{8101,1UL,0UL}},{{6591,0xA7C7L,0xEA27300EACFC8219LL},{3994,0xAC6FL,18446744073709551615UL},{6716,0xC1F7L,0xCF3CC333776CF44ELL},{3946,0xB443L,0x3D89F24AA2C10E5DLL}},{{6716,0xC1F7L,0xCF3CC333776CF44ELL},{3946,0xB443L,0x3D89F24AA2C10E5DLL},{3545,0x0A57L,18446744073709551615UL},{3713,1UL,0xB65B79D96ECEE043LL}},{{347,0x335BL,0x6A01FFECC01C9519LL},{6611,65526UL,0UL},{11281,0x8605L,9UL},{1361,8UL,0xF69008CA34DF0093LL}},{{5513,2UL,18446744073709551609UL},{1723,65535UL,0UL},{1361,8UL,0xF69008CA34DF0093LL},{358,2UL,18446744073709551613UL}}},{{{4867,0x21DFL,1UL},{11249,65535UL,18446744073709551615UL},{1695,0x6456L,0xFEAEDE3505A2D5E3LL},{5841,0x4E7FL,5UL}},{{3713,1UL,0xB65B79D96ECEE043LL},{6729,1UL,5UL},{3660,0UL,0x68DDBFA053D2864DLL},{10000,65531UL,0xDFCB74FB2A9267C8LL}},{{3545,0x0A57L,18446744073709551615UL},{4528,0xACA5L,0x33924AC93078B3C1LL},{10866,0xF3F8L,0xE85D3DA190B05777LL},{8101,1UL,0UL}},{{719,0xC2A7L,0x0C32C5D20319E91CLL},{5354,0x3F00L,0xE444E60323B760FELL},{5354,0x3F00L,0xE444E60323B760FELL},{719,0xC2A7L,0x0C32C5D20319E91CLL}},{{4528,0xACA5L,0x33924AC93078B3C1LL},{4617,0xADFBL,0x4E223383F2871015LL},{3545,0x0A57L,18446744073709551615UL},{3316,0x3209L,0x76993A80BFA9227CLL}},{{11281,0x8605L,9UL},{4867,0x21DFL,1UL},{3994,0xAC6FL,18446744073709551615UL},{10866,0xF3F8L,0xE85D3DA190B05777LL}},{{10000,65531UL,0xDFCB74FB2A9267C8LL},{1723,65535UL,0UL},{1253,65530UL,0x8AD5CB1D2A691310LL},{10866,0xF3F8L,0xE85D3DA190B05777LL}},{{11249,65535UL,18446744073709551615UL},{4867,0x21DFL,1UL},{8101,1UL,0UL},{3316,0x3209L,0x76993A80BFA9227CLL}},{{3713,1UL,0xB65B79D96ECEE043LL},{4617,0xADFBL,0x4E223383F2871015LL},{7514,0x063EL,1UL},{719,0xC2A7L,0x0C32C5D20319E91CLL}}},{{{7353,0xCEC2L,18446744073709551611UL},{5354,0x3F00L,0xE444E60323B760FELL},{11150,65532UL,0xFF9B10BBF2B9FAB4LL},{8101,1UL,0UL}},{{6729,1UL,5UL},{4528,0xACA5L,0x33924AC93078B3C1LL},{6980,1UL,0xDC08434A7E381A96LL},{10000,65531UL,0xDFCB74FB2A9267C8LL}},{{5354,0x3F00L,0xE444E60323B760FELL},{6729,1UL,5UL},{3545,0x0A57L,18446744073709551615UL},{5841,0x4E7FL,5UL}},{{6980,1UL,0xDC08434A7E381A96LL},{11249,65535UL,18446744073709551615UL},{4528,0xACA5L,0x33924AC93078B3C1LL},{358,2UL,18446744073709551613UL}},{{3946,0xB443L,0x3D89F24AA2C10E5DLL},{1723,65535UL,0UL},{1805,0x34ADL,0x71290EFDB011652ALL},{1361,8UL,0xF69008CA34DF0093LL}},{{5561,0xE7F2L,18446744073709551606UL},{6611,65526UL,0UL},{8606,0x09AAL,0x988F4E89A1344311LL},{3713,1UL,0xB65B79D96ECEE043LL}},{{3713,1UL,0xB65B79D96ECEE043LL},{3946,0xB443L,0x3D89F24AA2C10E5DLL},{11270,0x0EDBL,18446744073709551615UL},{3946,0xB443L,0x3D89F24AA2C10E5DLL}},{{6535,1UL,5UL},{3994,0xAC6FL,18446744073709551615UL},{358,2UL,18446744073709551613UL},{8101,1UL,0UL}},{{4617,0xADFBL,0x4E223383F2871015LL},{6716,0xC1F7L,0xCF3CC333776CF44ELL},{347,0x335BL,0x6A01FFECC01C9519LL},{6729,1UL,5UL}}},{{{3994,0xAC6FL,18446744073709551615UL},{719,0xC2A7L,0x0C32C5D20319E91CLL},{3545,0x0A57L,18446744073709551615UL},{1723,65535UL,0UL}},{{3994,0xAC6FL,18446744073709551615UL},{5561,0xE7F2L,18446744073709551606UL},{347,0x335BL,0x6A01FFECC01C9519LL},{1253,65530UL,0x8AD5CB1D2A691310LL}},{{4617,0xADFBL,0x4E223383F2871015LL},{1723,65535UL,0UL},{358,2UL,18446744073709551613UL},{1805,0x34ADL,0x71290EFDB011652ALL}},{{6535,1UL,5UL},{3545,0x0A57L,18446744073709551615UL},{11270,0x0EDBL,18446744073709551615UL},{6111,65535UL,1UL}},{{3713,1UL,0xB65B79D96ECEE043LL},{10000,65531UL,0xDFCB74FB2A9267C8LL},{8606,0x09AAL,0x988F4E89A1344311LL},{6591,0xA7C7L,0xEA27300EACFC8219LL}},{{5561,0xE7F2L,18446744073709551606UL},{6980,1UL,0xDC08434A7E381A96LL},{1805,0x34ADL,0x71290EFDB011652ALL},{8101,1UL,0UL}},{{3946,0xB443L,0x3D89F24AA2C10E5DLL},{347,0x335BL,0x6A01FFECC01C9519LL},{4528,0xACA5L,0x33924AC93078B3C1LL},{5513,2UL,18446744073709551609UL}},{{6980,1UL,0xDC08434A7E381A96LL},{6591,0xA7C7L,0xEA27300EACFC8219LL},{3545,0x0A57L,18446744073709551615UL},{6697,0UL,0x79A3C18AA77CB711LL}},{{5354,0x3F00L,0xE444E60323B760FELL},{6535,1UL,5UL},{6980,1UL,0xDC08434A7E381A96LL},{7498,1UL,0xE3E9985CE8822A2DLL}}},{{{6729,1UL,5UL},{1723,65535UL,0UL},{11150,65532UL,0xFF9B10BBF2B9FAB4LL},{11150,65532UL,0xFF9B10BBF2B9FAB4LL}},{{7353,0xCEC2L,18446744073709551611UL},{7353,0xCEC2L,18446744073709551611UL},{7514,0x063EL,1UL},{3658,0xA204L,18446744073709551606UL}},{{3713,1UL,0xB65B79D96ECEE043LL},{5354,0x3F00L,0xE444E60323B760FELL},{5561,0xE7F2L,18446744073709551606UL},{6716,0xC1F7L,0xCF3CC333776CF44ELL}},{{8947,0UL,0xC464A7D2C4370C23LL},{3658,0xA204L,18446744073709551606UL},{8606,0x09AAL,0x988F4E89A1344311LL},{5561,0xE7F2L,18446744073709551606UL}},{{347,0x335BL,0x6A01FFECC01C9519LL},{3658,0xA204L,18446744073709551606UL},{5841,0x4E7FL,5UL},{6716,0xC1F7L,0xCF3CC333776CF44ELL}},{{3658,0xA204L,18446744073709551606UL},{5354,0x3F00L,0xE444E60323B760FELL},{6607,0x78B5L,0x8D311142099F832DLL},{1253,65530UL,0x8AD5CB1D2A691310LL}},{{6111,65535UL,1UL},{7374,65535UL,0xD87977EC3D881791LL},{6697,0UL,0x79A3C18AA77CB711LL},{7514,0x063EL,1UL}},{{4528,0xACA5L,0x33924AC93078B3C1LL},{7498,1UL,0xE3E9985CE8822A2DLL},{1695,0x6456L,0xFEAEDE3505A2D5E3LL},{11270,0x0EDBL,18446744073709551615UL}},{{6607,0x78B5L,0x8D311142099F832DLL},{1843,65527UL,0x0A4D8FB16E7476C2LL},{7353,0xCEC2L,18446744073709551611UL},{1361,8UL,0xF69008CA34DF0093LL}}}};
static int32_t ** volatile g_523 = &g_97;/* VOLATILE GLOBAL g_523 */
static const int64_t g_532 = 5L;
static union U5 g_539 = {2L};/* VOLATILE GLOBAL g_539 */
static volatile uint32_t g_546 = 8UL;/* VOLATILE GLOBAL g_546 */
static volatile union U4 g_597 = {0xFF50843EL};/* VOLATILE GLOBAL g_597 */
static const int32_t g_605 = 8L;
static union U5 g_625 = {-1L};/* VOLATILE GLOBAL g_625 */
static int16_t *g_634 = &g_63;
static volatile union U8 g_636 = {0};/* VOLATILE GLOBAL g_636 */
static volatile union U7 g_637[9] = {{65530UL},{65530UL},{65530UL},{65530UL},{65530UL},{65530UL},{65530UL},{65530UL},{65530UL}};
static union U5 g_640 = {-5L};/* VOLATILE GLOBAL g_640 */
static union U8 g_658[1][1][9] = {{{{0},{0},{0},{0},{0},{0},{0},{0},{0}}}};
static union U8 g_661[1][7] = {{{0},{0},{0},{0},{0},{0},{0}}};
static union U8 *g_660 = &g_661[0][4];
static union U8 **g_659 = &g_660;
static struct S2 g_679 = {8,119,248UL,39};/* VOLATILE GLOBAL g_679 */
static int16_t g_690 = (-7L);
static int8_t *g_693[9][6][4] = {{{&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,(void*)0},{&g_82,&g_82,&g_82,&g_82}},{{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,(void*)0,&g_82},{&g_82,&g_82,&g_82,(void*)0},{(void*)0,&g_82,&g_82,(void*)0},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82}},{{(void*)0,&g_82,(void*)0,&g_82},{&g_82,&g_82,&g_82,(void*)0},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82}},{{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,(void*)0,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,(void*)0},{(void*)0,&g_82,&g_82,&g_82}},{{&g_82,&g_82,(void*)0,&g_82},{&g_82,&g_82,&g_82,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82}},{{&g_82,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,(void*)0},{&g_82,&g_82,&g_82,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,(void*)0,&g_82},{&g_82,(void*)0,&g_82,&g_82}},{{&g_82,&g_82,&g_82,&g_82},{(void*)0,(void*)0,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82},{(void*)0,&g_82,(void*)0,&g_82},{&g_82,&g_82,&g_82,&g_82}},{{&g_82,(void*)0,&g_82,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,(void*)0},{&g_82,&g_82,(void*)0,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82}},{{&g_82,(void*)0,&g_82,&g_82},{(void*)0,&g_82,&g_82,&g_82},{&g_82,&g_82,&g_82,&g_82},{&g_82,(void*)0,&g_82,&g_82},{(void*)0,&g_82,(void*)0,&g_82},{(void*)0,&g_82,&g_82,&g_82}}};
static int8_t **g_692 = &g_693[7][0][3];
static int8_t g_700 = 0xA7L;
static int8_t *g_699[2] = {&g_700,&g_700};
static int8_t ** const g_698[7][6][1] = {{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}},{{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]},{&g_699[0]},{&g_699[1]}}};
static union U8 g_709[5] = {{0},{0},{0},{0},{0}};
static volatile uint16_t g_728 = 65529UL;/* VOLATILE GLOBAL g_728 */
static struct S3 g_732 = {10130,0xB21FL,6UL};/* VOLATILE GLOBAL g_732 */
static int32_t ** volatile g_735 = (void*)0;/* VOLATILE GLOBAL g_735 */
static uint32_t *g_741 = &g_68;
static uint32_t * const *g_740 = &g_741;
static uint32_t * const *g_744[5] = {&g_741,&g_741,&g_741,&g_741,&g_741};
static uint32_t * const ** volatile g_743 = &g_744[1];/* VOLATILE GLOBAL g_743 */
static struct S3 g_754[6] = {{2263,0x23DEL,0x26A5FF566BC0F194LL},{2263,0x23DEL,0x26A5FF566BC0F194LL},{2263,0x23DEL,0x26A5FF566BC0F194LL},{2263,0x23DEL,0x26A5FF566BC0F194LL},{2263,0x23DEL,0x26A5FF566BC0F194LL},{2263,0x23DEL,0x26A5FF566BC0F194LL}};
static volatile struct S0 g_764 = {0UL,0xC4L,65532UL,0x4DL,0,1UL,0xD6B0767DL};/* VOLATILE GLOBAL g_764 */
static volatile union U6 g_777 = {{0xE9L}};/* VOLATILE GLOBAL g_777 */
static union U7 g_786 = {2UL};/* VOLATILE GLOBAL g_786 */
static struct S3 g_788 = {5384,65529UL,9UL};/* VOLATILE GLOBAL g_788 */
static const volatile union U7 g_804 = {0x933DL};/* VOLATILE GLOBAL g_804 */
static volatile struct S1 g_807[3][5] = {{{0x5DL},{0x0DL},{0x5DL},{0x0DL},{0x5DL}},{{-1L},{-1L},{-1L},{-1L},{-1L}},{{0x5DL},{0x0DL},{0x5DL},{0x0DL},{0x5DL}}};
static uint32_t *g_813 = &g_110;
static union U4 g_814 = {-1L};/* VOLATILE GLOBAL g_814 */
static volatile union U5 g_821 = {0L};/* VOLATILE GLOBAL g_821 */
static union U4 g_823 = {4L};/* VOLATILE GLOBAL g_823 */
static const int32_t *g_833 = &g_605;
static const int32_t **g_832 = &g_833;
static volatile union U7 * volatile g_853 = &g_637[7];/* VOLATILE GLOBAL g_853 */
static volatile union U7 * volatile *g_852 = &g_853;
static volatile union U7 * volatile **g_851[5][4][3] = {{{&g_852,&g_852,&g_852},{&g_852,&g_852,&g_852},{(void*)0,&g_852,&g_852},{&g_852,&g_852,(void*)0}},{{&g_852,(void*)0,&g_852},{&g_852,(void*)0,&g_852},{&g_852,&g_852,&g_852},{(void*)0,&g_852,&g_852}},{{(void*)0,&g_852,&g_852},{&g_852,&g_852,(void*)0},{&g_852,&g_852,(void*)0},{&g_852,(void*)0,&g_852}},{{&g_852,&g_852,&g_852},{(void*)0,&g_852,(void*)0},{&g_852,(void*)0,(void*)0},{(void*)0,&g_852,(void*)0}},{{(void*)0,&g_852,(void*)0},{&g_852,&g_852,(void*)0},{&g_852,(void*)0,&g_852},{&g_852,&g_852,(void*)0}}};
static volatile struct S1 g_891[8][8][4] = {{{{3L},{0x94L},{0L},{-9L}},{{0L},{-9L},{0x0EL},{7L}},{{0x02L},{0L},{0x2EL},{4L}},{{0xBFL},{0x61L},{7L},{0x41L}},{{0x31L},{-1L},{0x0BL},{0xF1L}},{{-1L},{0x2AL},{0L},{0x00L}},{{-8L},{0x3EL},{0L},{-1L}},{{0L},{-1L},{-5L},{1L}}},{{{4L},{3L},{-1L},{0x0CL}},{{3L},{0x3EL},{0x9AL},{-10L}},{{0x2AL},{-1L},{1L},{0xF1L}},{{0x41L},{0x02L},{-8L},{1L}},{{0x00L},{0x61L},{0xEBL},{0x71L}},{{0x30L},{0x23L},{0L},{7L}},{{0xCDL},{-1L},{0x52L},{0x8EL}},{{-1L},{0x94L},{0L},{4L}}},{{{1L},{1L},{1L},{-4L}},{{0x2AL},{2L},{-1L},{0L}},{{-1L},{0L},{0x48L},{-10L}},{{1L},{0L},{1L},{0xF2L}},{{0x02L},{-1L},{0x52L},{0x2AL}},{{0x71L},{0xF6L},{-1L},{1L}},{{0x30L},{0L},{0x9AL},{0x15L}},{{-10L},{0x2AL},{-8L},{0x7DL}}},{{{1L},{0xBEL},{0xBEL},{1L}},{{0x2AL},{1L},{0L},{-1L}},{{-10L},{0L},{-1L},{-9L}},{{0xCDL},{1L},{0x58L},{-9L}},{{0L},{0L},{1L},{-1L}},{{0xBFL},{1L},{0L},{1L}},{{0x62L},{0xBEL},{0xF1L},{0x7DL}},{{0x31L},{0x2AL},{0x48L},{0x15L}}},{{{0L},{0L},{0x2EL},{1L}},{{-1L},{0xF6L},{-5L},{0x2AL}},{{0L},{-1L},{-10L},{0xF2L}},{{-10L},{0L},{0x2EL},{-10L}},{{-10L},{0L},{0L},{0L}},{{0xF5L},{2L},{1L},{-4L}},{{0x00L},{1L},{0x2EL},{4L}},{{-1L},{0x94L},{-1L},{0x8EL}}},{{{0L},{-1L},{0x58L},{7L}},{{2L},{0x23L},{0x2EL},{0x71L}},{{-8L},{0x61L},{0x81L},{0L}},{{0x9EL},{0xF5L},{-8L},{0x2CL}},{{1L},{7L},{-1L},{0xF2L}},{{-1L},{-8L},{0x9EL},{-6L}},{{0xD6L},{0x15L},{9L},{0x81L}},{{0x0BL},{0x2AL},{0x7DL},{0x94L}}},{{{0x2AL},{-8L},{2L},{0xE2L}},{{0x5DL},{1L},{0xD6L},{0x2CL}},{{1L},{0L},{0x41L},{0x31L}},{{0x61L},{1L},{0x52L},{0x3EL}},{{1L},{0x9AL},{-1L},{0x16L}},{{0x3EL},{0x27L},{0xBFL},{0x27L}},{{-4L},{0x2EL},{0x9EL},{0xF1L}},{{0L},{-6L},{0x16L},{0x8EL}}},{{{0x48L},{0xF5L},{0x02L},{0xBEL}},{{0x48L},{0L},{0x16L},{0xE2L}},{{0L},{0xBEL},{0x9EL},{9L}},{{-4L},{-1L},{0xBFL},{0x48L}},{{0x3EL},{0x2CL},{-1L},{0x94L}},{{1L},{0L},{0x52L},{0x4CL}},{{0x61L},{7L},{0x41L},{1L}},{{1L},{0xA4L},{0xD6L},{1L}}}};
static struct S0 g_975 = {18446744073709551615UL,0L,0xC368L,-1L,0,0UL,7UL};/* VOLATILE GLOBAL g_975 */
static volatile union U5 g_1010 = {0x0137L};/* VOLATILE GLOBAL g_1010 */
static struct S0 g_1033 = {0x3B0D8905B5C08BB7LL,0x23L,0x15F6L,-9L,0,0x5FL,0xEA17CE19L};/* VOLATILE GLOBAL g_1033 */
static union U4 g_1034 = {0x19DC4232L};/* VOLATILE GLOBAL g_1034 */
static volatile int16_t g_1056 = (-8L);/* VOLATILE GLOBAL g_1056 */
static volatile union U4 g_1061 = {-10L};/* VOLATILE GLOBAL g_1061 */
static volatile int64_t * volatile g_1069 = (void*)0;/* VOLATILE GLOBAL g_1069 */
static volatile int64_t * const  volatile * volatile g_1068 = &g_1069;/* VOLATILE GLOBAL g_1068 */
static volatile union U8 g_1112 = {0};/* VOLATILE GLOBAL g_1112 */
static union U6 *g_1128 = (void*)0;
static int64_t g_1161 = 4L;
static uint64_t g_1164 = 18446744073709551611UL;
static struct S2 g_1186 = {12,286,0UL,36};/* VOLATILE GLOBAL g_1186 */
static const union U4 g_1194 = {5L};/* VOLATILE GLOBAL g_1194 */
static const int8_t *g_1216 = (void*)0;
static const int8_t **g_1215[4] = {&g_1216,&g_1216,&g_1216,&g_1216};
static const int8_t *** volatile g_1217 = &g_1215[0];/* VOLATILE GLOBAL g_1217 */
static union U6 g_1224 = {{6L}};/* VOLATILE GLOBAL g_1224 */
static struct S1 g_1227 = {1L};/* VOLATILE GLOBAL g_1227 */
static int16_t ** volatile g_1229 = &g_634;/* VOLATILE GLOBAL g_1229 */
static int16_t ** volatile *g_1228 = &g_1229;
static union U8 g_1231 = {0};/* VOLATILE GLOBAL g_1231 */
static struct S3 g_1269 = {5260,0UL,0xFB15667CCA8F28A8LL};/* VOLATILE GLOBAL g_1269 */
static const volatile struct S0 g_1275 = {0x507EB27009DCBA3ELL,5L,0x0712L,0x98L,0,248UL,0xAF995FE6L};/* VOLATILE GLOBAL g_1275 */
static struct S3 g_1289 = {6451,0xFE16L,0x74CDB3DF593BBB82LL};/* VOLATILE GLOBAL g_1289 */
static const struct S2 g_1319 = {-3,69,0x50L,44};/* VOLATILE GLOBAL g_1319 */
static struct S0 g_1332[5] = {{1UL,-1L,0xCF9BL,3L,-0,0xD2L,0x892146E1L},{1UL,-1L,0xCF9BL,3L,-0,0xD2L,0x892146E1L},{1UL,-1L,0xCF9BL,3L,-0,0xD2L,0x892146E1L},{1UL,-1L,0xCF9BL,3L,-0,0xD2L,0x892146E1L},{1UL,-1L,0xCF9BL,3L,-0,0xD2L,0x892146E1L}};
static struct S1 g_1337 = {1L};/* VOLATILE GLOBAL g_1337 */
static volatile union U5 g_1396[2][10] = {{{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L}},{{1L},{-1L},{1L},{-1L},{1L},{-1L},{1L},{-1L},{1L},{-1L}}};
static union U4 g_1413 = {0xCD00BF79L};/* VOLATILE GLOBAL g_1413 */
static struct S3 g_1428 = {5984,0UL,0xDBCA8600D2BF0541LL};/* VOLATILE GLOBAL g_1428 */
static volatile struct S2 g_1430 = {15,403,0xBCL,44};/* VOLATILE GLOBAL g_1430 */
static volatile union U7 g_1443 = {8UL};/* VOLATILE GLOBAL g_1443 */
static volatile struct S3 g_1453 = {1294,0UL,0UL};/* VOLATILE GLOBAL g_1453 */
static volatile union U7 g_1466 = {0x95ECL};/* VOLATILE GLOBAL g_1466 */
static volatile struct S3 g_1503 = {4754,5UL,0xDB2A07ACD03C26FELL};/* VOLATILE GLOBAL g_1503 */
static union U8 g_1514[7][9][4] = {{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}},{{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}},{{0},{0},{0},{0}}}};
static union U8 *g_1513[9] = {(void*)0,&g_1231,(void*)0,&g_1231,(void*)0,&g_1231,(void*)0,&g_1231,(void*)0};
static int32_t ** volatile g_1537 = &g_97;/* VOLATILE GLOBAL g_1537 */
static int16_t **g_1539 = &g_634;
static int16_t ** const *g_1538 = &g_1539;
static const volatile union U6 g_1541 = {{0x6CL}};/* VOLATILE GLOBAL g_1541 */
static volatile union U5 g_1556 = {-1L};/* VOLATILE GLOBAL g_1556 */
static union U6 g_1567 = {{1L}};/* VOLATILE GLOBAL g_1567 */
static volatile union U4 g_1574[2] = {{0xC8657C5AL},{0xC8657C5AL}};
static volatile union U5 g_1579 = {0xD734L};/* VOLATILE GLOBAL g_1579 */
static int64_t g_1588[2][8][2] = {{{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)}},{{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)},{0xDE44A2AB3F881101LL,0xDE44A2AB3F881101LL},{0xDE44A2AB3F881101LL,(-1L)}}};
static uint16_t g_1590 = 6UL;
static union U7 *g_1596[1] = {(void*)0};
static union U7 *g_1599 = (void*)0;
static int64_t g_1603 = 0L;
static int32_t * volatile g_1604 = (void*)0;/* VOLATILE GLOBAL g_1604 */
static int32_t ** const  volatile g_1638 = &g_97;/* VOLATILE GLOBAL g_1638 */
static volatile struct S2 g_1640 = {3,162,0xA9L,35};/* VOLATILE GLOBAL g_1640 */
static volatile struct S2 *g_1639 = &g_1640;
static const volatile int16_t *g_1658 = &g_1010.f0;
static const volatile int16_t ** volatile g_1657 = &g_1658;/* VOLATILE GLOBAL g_1657 */
static const volatile int16_t ** volatile *g_1656 = &g_1657;
static const volatile int16_t ** volatile **g_1655 = &g_1656;
static int16_t ***g_1666 = (void*)0;
static const int8_t ***g_1670 = (void*)0;
static union U5 g_1686 = {0L};/* VOLATILE GLOBAL g_1686 */
static struct S0 g_1709 = {0x2C85DFAB6B8CAE44LL,0xF7L,65530UL,0xEAL,0,255UL,4294967295UL};/* VOLATILE GLOBAL g_1709 */
static volatile uint32_t g_1718[2] = {0x2391D9D3L,0x2391D9D3L};
static union U5 g_1721 = {3L};/* VOLATILE GLOBAL g_1721 */
static union U5 g_1765 = {0x238CL};/* VOLATILE GLOBAL g_1765 */
static struct S0 ** volatile g_1766 = (void*)0;/* VOLATILE GLOBAL g_1766 */
static union U5 g_1769 = {-1L};/* VOLATILE GLOBAL g_1769 */


/* --- FORWARD DECLARATIONS --- */
static union U5  func_1(void);
static uint64_t  func_4(uint16_t  p_5);
static const int8_t ** func_7(int32_t  p_8, int64_t  p_9, uint64_t  p_10, uint64_t  p_11, const int64_t  p_12);
static uint32_t  func_16(int8_t * p_17, uint8_t  p_18, uint8_t  p_19, int8_t ** const  p_20, int8_t ** p_21);
static int8_t * func_22(const uint16_t  p_23, uint64_t  p_24, uint8_t  p_25, const uint32_t  p_26);
static int8_t ** func_30(uint32_t  p_31, uint8_t  p_32, int8_t ** p_33, uint8_t  p_34, uint32_t  p_35);
static uint8_t  func_48(int16_t  p_49, int8_t * p_50, const uint8_t  p_51);
static int8_t * func_52(int16_t  p_53, int32_t  p_54, int8_t ** p_55, const int32_t  p_56, int8_t ** p_57);
static int16_t  func_58(int32_t  p_59, int16_t  p_60, uint32_t  p_61);
static int32_t * const  func_75(int8_t  p_76);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_1769
 * writes:
 */
static union U5  func_1(void)
{ /* block id: 0 */
    int8_t l_6 = 0x0CL;
    int64_t *l_1586 = &g_1161;
    int64_t *l_1587 = &g_1588[0][3][0];
    uint16_t *l_1589 = &g_1590;
    int64_t l_1595 = 0xD017760D2E5E8BA9LL;
    union U7 **l_1597 = (void*)0;
    union U7 **l_1598 = &g_1596[0];
    uint64_t *l_1600[3];
    const int32_t l_1601[3][1] = {{0xDE55B734L},{0xDE55B734L},{0xDE55B734L}};
    int64_t *l_1602 = &g_1603;
    int32_t *l_1605 = &g_261.f0;
    int32_t **l_1606 = (void*)0;
    int32_t **l_1607 = &l_1605;
    int32_t l_1734 = 0xD30BABE9L;
    int32_t l_1738 = 1L;
    int64_t l_1741 = 0x66851A6CD7F37DD7LL;
    int32_t l_1742 = 0x8C94524CL;
    int32_t l_1743 = (-7L);
    int64_t l_1749[2];
    uint32_t l_1762 = 0xD81345E1L;
    int i, j;
    for (i = 0; i < 3; i++)
        l_1600[i] = &g_732.f2;
    for (i = 0; i < 2; i++)
        l_1749[i] = 0x2DA7D2BD19520972LL;
    return g_1769;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_248 g_107.f0 g_82 g_63 g_90 g_257 g_258 g_259 g_261 g_97 g_91 g_264 g_191 g_192 g_190 g_270 g_96 g_300 g_68 g_143 g_98 g_99 g_546 g_249 g_182 g_519.f0 g_389.f3 g_597 g_260 g_532 g_230 g_625 g_370.f0 g_636 g_637 g_640 g_483.f0 g_108.f0.f0 g_659 g_634 g_679 g_692 g_693 g_419 g_698 g_709 g_152.f0 g_512.f1 g_728 g_740 g_743 g_754 g_764 g_108.f1 g_152 g_777 g_135 g_107 g_804 g_389 g_807 g_814 g_821 g_823 g_744 g_788.f0 g_851 g_370 g_853 g_462 g_443 g_891 g_814.f0 g_823.f0 g_290 g_741 g_660 g_661 g_519.f2 g_539.f4 g_788.f2 g_975 g_482 g_832 g_833 g_605 g_1010 g_261.f1 g_523 g_1033 g_1034 g_392 g_1061 g_804.f3 g_1068 g_1112 g_1164 g_1194 g_1215 g_1217 g_261.f0 g_1224 g_1227 g_1228 g_1231 g_1229 g_690 g_1269 g_1275 g_1289 g_495.f0 g_1413 g_1574 g_1332.f2 g_1579
 * writes: g_63 g_248 g_91 g_97 g_108.f1 g_192 g_271 g_300 g_230 g_182 g_82 g_370.f0 g_634 g_143 g_659 g_690 g_692 g_693 g_512.f1 g_68 g_728 g_482 g_740 g_744 g_700 g_419 g_813 g_110 g_832 g_443 g_823.f0 g_495.f2 g_660 g_975.f2 g_788.f2 g_814.f0 g_1128 g_1164 g_1033.f2 g_1034.f0 g_1215 g_261.f0 g_1332.f2
 */
static uint64_t  func_4(uint16_t  p_5)
{ /* block id: 1 */
    int16_t l_13 = 7L;
    int8_t **l_697 = &g_693[7][5][1];
    const int32_t l_1230 = 1L;
    int32_t l_1261 = 0x28A5FB31L;
    int32_t l_1263 = 0x7A6D6CEFL;
    union U8 **l_1271[4];
    union U8 **l_1272 = &g_660;
    int16_t *l_1296[6][2];
    int32_t l_1307 = 0xBB3D2F27L;
    int32_t l_1311 = 8L;
    int32_t l_1312 = 0xA75066ACL;
    int32_t l_1315 = 0L;
    int64_t *l_1338 = (void*)0;
    uint8_t l_1354 = 0xC6L;
    int32_t *l_1357 = (void*)0;
    int64_t **l_1477 = &l_1338;
    int64_t ***l_1476 = &l_1477;
    uint64_t l_1509 = 0x6C2808D937580F49LL;
    uint16_t *l_1575 = &g_1332[2].f2;
    uint16_t *l_1578 = &g_1033.f2;
    int i, j;
    for (i = 0; i < 4; i++)
        l_1271[i] = &g_660;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
            l_1296[i][j] = &g_690;
    }
    (*g_1217) = func_7(l_13, l_13, (safe_mul_func_uint8_t_u_u(6UL, (((*g_741) = (func_16(((*l_697) = func_22(g_27[1], p_5, l_13, (safe_add_func_uint8_t_u_u(g_27[0], l_13)))), l_13, g_419, g_698[2][2][0], l_697) | (-1L))) > l_13))), l_13, l_13);
    if (((*g_634) > ((p_5 < 0L) , (safe_mod_func_uint64_t_u_u((g_261.f0 , (((safe_mod_func_uint16_t_u_u(((((((p_5 <= (((safe_rshift_func_uint8_t_u_s((g_1224 , ((safe_div_func_uint64_t_u_u(l_13, ((g_1227 , ((l_13 && (*g_634)) || p_5)) & 0xE2A02F7C7FC6FBB9LL))) & p_5)), 7)) & 0x54L) && l_13)) == 9UL) && l_13) , g_1228) == (void*)0) != (*g_249)), 0xBA10L)) && l_1230) , l_1230)), p_5)))))
    { /* block id: 564 */
        int32_t l_1250 = 0L;
        int16_t *l_1251 = &g_690;
        const int32_t l_1252 = 0L;
        int16_t *l_1253 = &l_13;
        int32_t l_1254 = 0L;
        int8_t *l_1255 = &g_82;
        uint64_t *l_1260 = (void*)0;
        uint64_t *l_1262[3][1];
        union U8 **l_1270 = &g_660;
        union U8 ***l_1273 = &l_1272;
        union U8 **l_1274 = &g_660;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_1262[i][j] = &g_519[6][1][2].f2;
        }
        (*g_659) = (g_1231 , (((*l_1255) |= (l_1254 |= (~(p_5 == (!((*l_1253) &= (((((*l_1251) ^= ((safe_mul_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((*g_249), p_5)), ((safe_sub_func_uint64_t_u_u(l_1230, (safe_lshift_func_uint16_t_u_s((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(((!(1UL > ((safe_rshift_func_uint8_t_u_u(p_5, 7)) & (safe_unary_minus_func_int8_t_s(0xF4L))))) <= (*g_741)), (***g_1228))), p_5)), l_1250)))) ^ g_788.f0))) != p_5)) >= 1UL) < (*g_741)) || l_1252))))))) , (void*)0));
        for (g_419 = (-10); (g_419 == 60); ++g_419)
        { /* block id: 572 */
            return p_5;
        }
        l_1263 = (safe_mod_func_int8_t_s_s((((--g_143[0]) >= ((safe_unary_minus_func_int16_t_s((safe_div_func_int16_t_s_s(((((*g_249) = 5UL) ^ 0L) || ((g_1269 , ((254UL == (l_1261 > ((*g_97) ^= ((**g_190) = ((l_1271[0] = l_1270) == (l_1274 = ((*l_1273) = (g_659 = l_1272)))))))) , g_1275)) , (**g_740))), l_1252)))) , 1UL)) >= 0x50L), l_13));
    }
    else
    { /* block id: 584 */
        int64_t l_1278[10] = {0x43DE88F44435BDF8LL,0x5006D12122B2200ELL,0x43DE88F44435BDF8LL,0x43DE88F44435BDF8LL,0x5006D12122B2200ELL,0x43DE88F44435BDF8LL,0x43DE88F44435BDF8LL,0x5006D12122B2200ELL,0x43DE88F44435BDF8LL,0x43DE88F44435BDF8LL};
        const union U8 **l_1291 = (void*)0;
        const union U8 ** const *l_1290 = &l_1291;
        int32_t l_1297 = 0L;
        int32_t l_1306 = 0L;
        int32_t l_1313 = 1L;
        union U5 *l_1370[9][10][2] = {{{&g_625,&g_539},{&g_539,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_640,&g_539},{&g_539,(void*)0},{&g_539,&g_539},{(void*)0,(void*)0}},{{&g_539,&g_539},{&g_539,(void*)0},{&g_539,&g_625},{&g_640,&g_539},{&g_625,&g_539},{&g_625,&g_539},{&g_640,&g_625},{&g_539,(void*)0},{&g_539,&g_539},{&g_539,(void*)0}},{{(void*)0,&g_539},{&g_539,(void*)0},{&g_539,&g_539},{&g_640,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_539,&g_539},{&g_625,&g_539}},{{(void*)0,&g_539},{&g_539,(void*)0},{&g_539,(void*)0},{&g_539,&g_539},{(void*)0,&g_539},{&g_625,&g_539},{&g_539,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_539,&g_625}},{{&g_539,&g_539},{&g_640,&g_539},{&g_539,(void*)0},{&g_539,&g_539},{(void*)0,(void*)0},{&g_539,&g_539},{&g_539,(void*)0},{&g_539,&g_625},{&g_640,&g_539},{&g_625,&g_539}},{{&g_625,&g_539},{&g_640,&g_625},{&g_539,(void*)0},{&g_539,&g_539},{&g_539,(void*)0},{(void*)0,&g_539},{&g_539,(void*)0},{&g_539,&g_539},{&g_640,&g_539},{&g_539,&g_625}},{{&g_539,&g_539},{&g_539,&g_625},{&g_539,&g_539},{&g_539,&g_539},{&g_625,&g_539},{(void*)0,&g_539},{&g_539,(void*)0},{&g_539,(void*)0},{&g_539,&g_539},{(void*)0,&g_539}},{{&g_625,&g_539},{&g_539,&g_539},{&g_539,&g_625},{&g_625,&g_539},{&g_640,&g_539},{&g_539,&g_539},{&g_640,&g_539},{&g_539,&g_640},{&g_640,&g_539},{&g_625,&g_625}},{{&g_539,&g_539},{&g_539,&g_539},{&g_539,&g_640},{&g_640,&g_539},{&g_539,&g_640},{&g_539,&g_539},{&g_640,&g_640},{&g_539,&g_539},{&g_539,&g_539},{&g_539,&g_625}}};
        union U5 **l_1369 = &l_1370[0][7][0];
        union U8 **l_1388 = (void*)0;
        int32_t **l_1423 = (void*)0;
        uint64_t l_1424[8][1] = {{8UL},{0UL},{8UL},{0UL},{8UL},{0UL},{8UL},{0UL}};
        const struct S3 *l_1427 = &g_1428;
        const struct S3 **l_1426 = &l_1427;
        int16_t **l_1449 = &l_1296[5][0];
        int16_t ***l_1448 = &l_1449;
        uint32_t l_1463 = 0x0A7A41C0L;
        uint16_t l_1490 = 65526UL;
        int32_t l_1527[1];
        int64_t **l_1568 = &l_1338;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1527[i] = (-1L);
        for (p_5 = (-4); (p_5 > 48); p_5 = safe_add_func_uint64_t_u_u(p_5, 6))
        { /* block id: 587 */
            int64_t l_1298 = (-1L);
            int32_t l_1302 = 0x0A7D1B18L;
            int16_t *l_1320 = &g_63;
            uint64_t *l_1353 = &g_495.f2;
            volatile struct S2 *l_1429 = &g_1430;
            int16_t ****l_1450 = &l_1448;
            uint16_t *l_1451 = &g_1033.f2;
            int32_t l_1489[3][8] = {{0x17A92983L,0x17A92983L,1L,0L,1L,0x17A92983L,0x17A92983L,1L},{0x42681375L,1L,1L,0x42681375L,(-1L),0x42681375L,1L,1L},{1L,(-1L),0L,0L,(-1L),1L,(-1L),0L}};
            union U8 *l_1512 = (void*)0;
            int16_t ** const **l_1540 = &g_1538;
            int i, j;
            if ((8L && l_1278[9]))
            { /* block id: 588 */
                uint32_t l_1292 = 0x24314ECEL;
                int32_t l_1308 = 0xA6E74745L;
                int32_t l_1314 = 0x58DF9B52L;
                uint16_t l_1316 = 0UL;
                uint16_t **l_1335 = &g_453;
                for (g_63 = (-27); (g_63 == 24); g_63 = safe_add_func_uint64_t_u_u(g_63, 1))
                { /* block id: 591 */
                    uint64_t l_1303 = 0UL;
                    int32_t l_1309 = (-1L);
                    int32_t l_1310[9];
                    uint64_t l_1355 = 0x6E88ED00C811EBADLL;
                    union U5 *l_1367 = &g_625;
                    union U5 **l_1366 = &l_1367;
                    int i;
                    for (i = 0; i < 9; i++)
                        l_1310[i] = 1L;
                    if ((safe_rshift_func_int16_t_s_s((l_1297 = ((safe_add_func_int16_t_s_s((safe_div_func_uint32_t_u_u(p_5, ((*g_191) = (safe_sub_func_uint64_t_u_u((g_1289 , (((*g_853) , l_1290) != (void*)0)), 0xFE4BEBE2BA255A5ALL))))), l_1292)) <= (((*g_249) = (safe_add_func_int32_t_s_s((((+(&g_63 == (l_1296[3][0] = &g_690))) && g_495.f0) , p_5), 4294967293UL))) , 4294967295UL))), (*g_634))))
                    { /* block id: 596 */
                        if (l_1298)
                            break;
                    }
                    else
                    { /* block id: 598 */
                        int32_t *l_1299 = &g_261.f0;
                        int32_t *l_1300 = &g_261.f0;
                        int32_t *l_1301[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_1301[i] = &g_261.f0;
                        (*g_462) = &l_1297;
                        l_1303++;
                        (*g_96) = l_1300;
                        l_1316++;
                    }
                }
            }
            else
            { /* block id: 635 */
                int32_t **l_1422 = (void*)0;
                (*g_191) |= 0xD6A2C1E4L;
                for (g_261.f0 = 0; (g_261.f0 >= 0); g_261.f0 -= 1)
                { /* block id: 639 */
                    const int64_t l_1425 = 0xCE97AF6B0C113C26LL;
                    for (g_68 = 0; (g_68 <= 1); g_68 += 1)
                    { /* block id: 642 */
                        uint64_t l_1419[9][4][4] = {{{0xA861ABB850067337LL,0UL,0x1F09FFAA137CEB2DLL,0UL},{1UL,18446744073709551612UL,0x1C1F915A0B4B9783LL,1UL},{0xB362C1537769A455LL,0x1F09FFAA137CEB2DLL,18446744073709551615UL,0x565F307B37AA0864LL},{0x999010067712C6F3LL,4UL,0UL,0UL}},{{0UL,18446744073709551610UL,0x4320F055A3F3A975LL,18446744073709551612UL},{0UL,0UL,0UL,0x565F307B37AA0864LL},{0x1CABC812FA3BE260LL,9UL,0UL,18446744073709551615UL},{0xCAE8C475CC2EEE50LL,18446744073709551612UL,1UL,0xB362C1537769A455LL}},{{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0x4B2D61C1E504C8D9LL},{0x1F09FFAA137CEB2DLL,0xD00231B21C1D0BDBLL,0x999010067712C6F3LL,18446744073709551615UL},{0UL,0x048354072C969B8ELL,9UL,0UL},{9UL,0UL,18446744073709551615UL,1UL}},{{8UL,1UL,0x8A8C7A9EEE161498LL,0x8A8C7A9EEE161498LL},{0xCAE8C475CC2EEE50LL,0xCAE8C475CC2EEE50LL,18446744073709551615UL,18446744073709551615UL},{1UL,18446744073709551615UL,0UL,9UL},{0x1D522F5EFE425D04LL,0x4B2D61C1E504C8D9LL,18446744073709551615UL,0UL}},{{0UL,0x4B2D61C1E504C8D9LL,18446744073709551614UL,9UL},{0x4B2D61C1E504C8D9LL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0UL,0xCAE8C475CC2EEE50LL,0UL,0x8A8C7A9EEE161498LL},{1UL,1UL,1UL,1UL}},{{0x565F307B37AA0864LL,0UL,0UL,0UL},{0UL,0x048354072C969B8ELL,0x03D3E58E35757975LL,18446744073709551615UL},{18446744073709551612UL,0xD00231B21C1D0BDBLL,0xC651020319C8F8A7LL,0x4B2D61C1E504C8D9LL},{0x565F307B37AA0864LL,18446744073709551615UL,0x1F09FFAA137CEB2DLL,0xB362C1537769A455LL}},{{18446744073709551615UL,18446744073709551612UL,0UL,18446744073709551615UL},{0xB362C1537769A455LL,9UL,5UL,0x565F307B37AA0864LL},{0x4B2D61C1E504C8D9LL,0UL,0UL,18446744073709551612UL},{18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,0UL}},{{0UL,4UL,0UL,0x565F307B37AA0864LL},{1UL,0x1F09FFAA137CEB2DLL,0UL,1UL},{0x8A8C7A9EEE161498LL,18446744073709551612UL,0x8A8C7A9EEE161498LL,0UL},{0x8A8C7A9EEE161498LL,0UL,0x048354072C969B8ELL,0xA861ABB850067337LL}},{{0UL,0x6B34985C45100B26LL,18446744073709551615UL,0UL},{18446744073709551615UL,0UL,18446744073709551615UL,8UL},{0UL,18446744073709551615UL,0x048354072C969B8ELL,0UL},{0x8A8C7A9EEE161498LL,0xE74E3C4BC05E1494LL,0x200E644271EA8AA3LL,0x0717F0C29BA2A8E7LL}}};
                        int i, j, k;
                        (**g_190) ^= ((((((g_1413 , (!0xABEEF0FCL)) && ((safe_sub_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(p_5, l_1419[3][1][2])), (g_1275.f5 ^ ((l_1422 != l_1423) == ((((0x49E0A13DA9366A4DLL || (((p_5 || p_5) || p_5) ^ l_1419[3][1][2])) <= g_975.f4) || l_1424[0][0]) , l_1298))))) & l_1419[6][3][3])) <= l_1425) > 8UL) , &g_482) != l_1426);
                        l_1429 = (p_5 , &g_389);
                    }
                }
            }
        }
        return l_1297;
    }
    (*g_97) = (((((g_1574[0] , ((*l_1575)--)) <= ((*l_1578) = 0x9A02L)) , g_1579) , (**g_740)) >= (p_5 , ((void*)0 == &l_1357)));
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_97 g_1215
 * writes: g_91
 */
static const int8_t ** func_7(int32_t  p_8, int64_t  p_9, uint64_t  p_10, uint64_t  p_11, const int64_t  p_12)
{ /* block id: 559 */
    int32_t *l_1206 = (void*)0;
    int32_t *l_1207 = (void*)0;
    int32_t *l_1208 = &g_91;
    int32_t *l_1209 = &g_261.f0;
    int32_t *l_1210[2][1];
    int64_t l_1211 = (-5L);
    uint16_t l_1212 = 0x79C6L;
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_1210[i][j] = &g_1034.f0;
    }
    --l_1212;
    (*g_97) = ((void*)0 == &p_8);
    return g_1215[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_190 g_191 g_192 g_709 g_249 g_182 g_152.f0 g_68 g_97 g_91 g_690 g_728 g_63 g_90 g_740 g_743 g_754 g_634 g_764 g_419 g_108.f1 g_152 g_777 g_82 g_135 g_107 g_804 g_389 g_807 g_814 g_821 g_823 g_744 g_788.f0 g_851 g_370 g_853 g_637 g_823.f0 g_462 g_443 g_891 g_814.f0 g_96 g_290 g_741 g_660 g_661 g_519.f2 g_539.f4 g_679.f3 g_788.f2 g_659 g_975 g_482 g_832 g_833 g_605 g_1010 g_300 g_679 g_261.f1 g_523 g_1033 g_1034 g_519.f0 g_392 g_1061 g_804.f3 g_640 g_1068 g_1112 g_230 g_1164 g_1034.f0 g_1194 g_512.f1
 * writes: g_192 g_512.f1 g_182 g_68 g_91 g_690 g_728 g_482 g_63 g_97 g_740 g_744 g_700 g_108.f1 g_419 g_813 g_110 g_832 g_230 g_443 g_823.f0 g_495.f2 g_660 g_300 g_975.f2 g_788.f2 g_814.f0 g_82 g_1128 g_1164 g_1033.f2 g_1034.f0
 */
static uint32_t  func_16(int8_t * p_17, uint8_t  p_18, uint8_t  p_19, int8_t ** const  p_20, int8_t ** p_21)
{ /* block id: 295 */
    int32_t l_713 = (-1L);
    int64_t l_717 = 0x2285682284DB795CLL;
    int32_t l_726[4];
    struct S3 *l_731 = &g_732;
    struct S3 **l_733[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t l_734 = 1UL;
    union U7 *l_785 = &g_786;
    union U7 **l_791 = (void*)0;
    uint32_t l_902[10][10] = {{1UL,0UL,1UL,0x09CEA0ABL,0x3B83DE21L,0x80EBD29FL,1UL,1UL,0x80EBD29FL,0x3B83DE21L},{0x3B83DE21L,1UL,1UL,0x3B83DE21L,1UL,1UL,0x3ACE6DA1L,0x80EBD29FL,0UL,0x09CEA0ABL},{0x3B83DE21L,0UL,0x3ACE6DA1L,1UL,0x80EBD29FL,0x80EBD29FL,1UL,0x3ACE6DA1L,0UL,0x3B83DE21L},{1UL,0x09CEA0ABL,1UL,0x3B83DE21L,0UL,0x3ACE6DA1L,1UL,0x80EBD29FL,0x80EBD29FL,1UL},{0x80EBD29FL,0UL,0x09CEA0ABL,0x09CEA0ABL,0UL,0x80EBD29FL,0x3ACE6DA1L,1UL,1UL,0x3B83DE21L},{0UL,1UL,0x09CEA0ABL,0x3B83DE21L,0x80EBD29FL,1UL,1UL,0x80EBD29FL,0x3B83DE21L,0x09CEA0ABL},{0UL,0UL,1UL,1UL,1UL,0x80EBD29FL,0x09CEA0ABL,0x3ACE6DA1L,0x3B83DE21L,0x3B83DE21L},{0x80EBD29FL,0x09CEA0ABL,0x3ACE6DA1L,0x3B83DE21L,0x3B83DE21L,0x3ACE6DA1L,0x09CEA0ABL,0x80EBD29FL,1UL,1UL},{1UL,0UL,1UL,0x09CEA0ABL,0x3B83DE21L,0x80EBD29FL,1UL,1UL,0x80EBD29FL,0x3B83DE21L},{0x3B83DE21L,1UL,1UL,0x3B83DE21L,1UL,1UL,0x3ACE6DA1L,0x80EBD29FL,0UL,0x09CEA0ABL}};
    int64_t l_929 = 0L;
    int32_t l_965 = 0x50E57FDFL;
    union U8 *l_968 = &g_661[0][2];
    uint8_t ***l_992 = (void*)0;
    int32_t l_1027 = 0x02DAA1EAL;
    union U5 *l_1062 = &g_640;
    int8_t l_1078[2][7][10] = {{{0L,1L,(-1L),9L,1L,0xB5L,(-4L),(-6L),0xC0L,(-1L)},{0x5BL,0x57L,0x9EL,0xE7L,(-3L),1L,0xB5L,0xBEL,0x51L,0xE7L},{(-1L),0xBEL,1L,(-1L),0L,0x46L,0x2BL,(-4L),0xF9L,(-1L)},{0L,0xE7L,0xF0L,0x3DL,(-6L),(-6L),0x3DL,0xF0L,0xE7L,0L},{1L,0x2AL,0x5BL,0x14L,0x3DL,0xE7L,0x51L,0xBEL,0xB5L,1L},{0L,(-1L),0xF9L,0x2AL,0x3DL,1L,0L,(-1L),0x0BL,0L},{0x3DL,0x51L,(-1L),(-4L),(-6L),(-1L),0x57L,0xF9L,(-1L),(-1L)}},{{0x19L,0x6FL,0x65L,0x19L,1L,0xE2L,0L,0x14L,0L,0x46L},{0x5BL,(-1L),(-4L),0xB3L,0x6FL,9L,0x6FL,0xB3L,(-4L),(-1L)},{(-1L),0x0BL,5L,(-6L),0xEBL,0x03L,0xC0L,0L,(-1L),1L},{0x0BL,0xB5L,0x03L,0x44L,(-1L),0x03L,0x46L,0x4CL,0x19L,0xE2L},{(-1L),0xE7L,0x2AL,0x4CL,0x9EL,9L,0x14L,0xC0L,0x57L,(-1L)},{0x5BL,0xF9L,0L,0x9EL,1L,0xE2L,(-6L),0x0BL,0x46L,1L},{0x19L,0x51L,0x03L,0xE2L,0xF0L,(-1L),(-1L),0xF0L,0xE2L,0x03L}}};
    int32_t *l_1129 = &g_192;
    const int32_t ** const *l_1141 = &g_832;
    uint64_t ***l_1175[10] = {&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_726[i] = (-1L);
lbl_722:
    (**g_190) |= 0xAE3D0A5FL;
    for (g_512.f1 = 0; (g_512.f1 < 23); g_512.f1++)
    { /* block id: 299 */
        int8_t l_712 = 0x6AL;
        uint32_t *l_718 = (void*)0;
        uint32_t *l_719 = &g_68;
        int32_t l_727[3][8][4] = {{{0x4F0C006CL,(-8L),(-7L),0xF6C7C67BL},{3L,0xD2F87F33L,(-6L),0x7B25E418L},{0x54DE9549L,0xF7357D95L,0x54DE9549L,0xEB4B5232L},{1L,0x54DE9549L,0L,(-10L)},{0x7B25E418L,0x4F0C006CL,0xBD68A164L,0x54DE9549L},{0x4C13A5C3L,8L,0xBD68A164L,5L},{0x7B25E418L,5L,0L,(-9L)},{1L,1L,0x54DE9549L,0x157F5AFCL}},{{0x54DE9549L,0x157F5AFCL,(-6L),(-7L)},{3L,5L,(-7L),(-3L)},{0x4F0C006CL,(-6L),1L,0L},{1L,1L,1L,1L},{(-9L),0xBD68A164L,6L,0xF7357D95L},{0xF6C7C67BL,0x4C13A5C3L,0x7B25E418L,8L},{0x90BF114CL,1L,0x51C2796FL,8L},{5L,0x4C13A5C3L,0x68DDA277L,0xF7357D95L}},{{(-8L),0xBD68A164L,5L,1L},{1L,1L,1L,0L},{0x504B4ED4L,(-6L),0x4C13A5C3L,(-3L)},{1L,5L,5L,(-7L)},{0xBD68A164L,0x157F5AFCL,0x504B4ED4L,0x157F5AFCL},{0L,1L,3L,(-9L)},{8L,5L,(-3L),5L},{5L,8L,(-9L),0x54DE9549L}}};
        int i, j, k;
        (*g_97) &= (((*l_719) |= (safe_add_func_uint16_t_u_u((0xA6L && p_18), (safe_sub_func_uint8_t_u_u(0xA1L, ((*g_249) = (safe_sub_func_int32_t_s_s((g_709[1] , ((safe_add_func_uint8_t_u_u((l_712 > l_713), (*g_249))) != ((safe_mod_func_int16_t_s_s((((l_712 || ((~(&g_271 == (void*)0)) || l_713)) == g_152[5][4][0].f0) != l_713), 0xF43BL)) , p_18))), l_717)))))))) <= p_18);
        for (g_690 = 3; (g_690 > 14); g_690 = safe_add_func_uint8_t_u_u(g_690, 6))
        { /* block id: 305 */
            int16_t l_723 = 0xDA50L;
            int32_t *l_724 = &l_713;
            int32_t *l_725[7][2][9] = {{{&g_91,&g_91,(void*)0,&g_370.f0,(void*)0,&g_91,&g_91,&g_91,&g_91},{&g_192,&g_192,&l_713,&g_192,(void*)0,&l_713,&l_713,(void*)0,&g_192}},{{&g_370.f0,&g_264.f0,&g_370.f0,&l_713,(void*)0,(void*)0,&l_713,&g_370.f0,&g_264.f0},{&g_370.f0,&g_192,&l_713,&g_192,&g_192,&l_713,&g_192,&g_370.f0,&g_192}},{{&g_91,&g_370.f0,&l_713,&l_713,&g_370.f0,&g_91,(void*)0,&g_91,&g_370.f0},{&g_192,&g_192,&g_192,&g_192,&g_370.f0,(void*)0,&g_370.f0,&g_192,&g_192}},{{&g_264.f0,&g_264.f0,(void*)0,&g_370.f0,&g_91,&g_370.f0,(void*)0,&g_264.f0,&g_264.f0},{&g_192,&g_192,&g_370.f0,(void*)0,&g_370.f0,&g_192,&g_192,&g_192,&g_192}},{{&g_370.f0,&g_91,(void*)0,&g_91,&g_370.f0,&l_713,&l_713,&g_370.f0,&g_91},{&g_192,&g_370.f0,&g_192,&l_713,&g_192,&g_192,&l_713,&g_192,&g_370.f0}},{{&g_264.f0,&g_370.f0,&l_713,(void*)0,(void*)0,&l_713,&g_370.f0,&g_264.f0,&g_370.f0},{&g_192,(void*)0,&l_713,&l_713,(void*)0,&g_192,&g_192,&g_192,(void*)0}},{{&g_91,&g_370.f0,&g_370.f0,&g_91,&g_264.f0,&g_370.f0,&g_264.f0,&g_91,&g_370.f0},{&g_370.f0,&g_370.f0,&g_192,(void*)0,&g_192,(void*)0,&g_192,&g_370.f0,&g_370.f0}}};
            int i, j, k;
            if (g_512.f1)
                goto lbl_722;
            if (l_712)
                break;
            g_728--;
        }
    }
    g_482 = (l_731 = &g_519[6][1][2]);
    if (l_717)
    { /* block id: 313 */
        int32_t **l_736 = (void*)0;
        int32_t **l_737 = &g_97;
        (*l_737) = func_75(l_734);
    }
    else
    { /* block id: 315 */
        uint8_t **l_757 = &g_249;
        int32_t l_759 = 1L;
        union U5 **l_767 = (void*)0;
        int32_t ** const l_778 = (void*)0;
        struct S3 *l_787 = &g_788;
        union U7 **l_789 = &l_785;
        int32_t l_799[5] = {0L,0L,0L,0L,0L};
        int8_t l_800 = 0xD4L;
        uint32_t *l_812 = &l_734;
        uint32_t **l_822[2][7][4] = {{{&g_741,&g_741,(void*)0,&g_741},{&g_741,&g_741,(void*)0,&g_741},{&g_741,&g_741,(void*)0,(void*)0},{&g_741,&g_741,&g_741,&g_741},{&g_741,&g_741,&g_741,&g_741},{&g_741,&g_741,&g_741,(void*)0},{&g_741,&g_741,(void*)0,(void*)0}},{{&g_741,&g_741,(void*)0,&g_741},{&g_741,&g_741,(void*)0,&g_741},{&g_741,&g_741,(void*)0,(void*)0},{&g_741,&g_741,&g_741,&g_741},{&g_741,&g_741,&g_741,&g_741},{&g_741,&g_741,&g_741,(void*)0},{&g_741,&g_741,(void*)0,(void*)0}}};
        const int32_t *l_830 = &l_726[1];
        const int32_t **l_829 = &l_830;
        int16_t **l_870 = &g_634;
        uint32_t l_926 = 0xE1BA0CAFL;
        uint32_t l_964 = 4294967295UL;
        uint16_t l_966 = 0UL;
        uint8_t l_973 = 6UL;
        uint32_t l_1081 = 1UL;
        uint8_t l_1096 = 0x77L;
        int16_t l_1159[1][2];
        int32_t l_1162 = 1L;
        int8_t l_1163[4] = {3L,3L,3L,3L};
        int64_t l_1183 = 0xE50FD11BEA448AFCLL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_1159[i][j] = (-1L);
        }
        for (l_717 = 8; (l_717 != (-4)); --l_717)
        { /* block id: 318 */
            uint32_t * const **l_742 = &g_740;
            int32_t l_745 = 0x74F36BD2L;
            uint8_t **l_755 = &g_249;
            uint8_t **l_756 = &g_249;
            int8_t *l_758 = &g_700;
            int32_t l_796 = (-1L);
            int32_t l_797 = 0x9153EAE6L;
            int32_t l_798[9] = {0x573BF78EL,0x573BF78EL,(-10L),0x573BF78EL,0x573BF78EL,(-10L),0x573BF78EL,0x573BF78EL,(-10L)};
            uint16_t l_801 = 0xB0D2L;
            const int32_t **l_834 = &l_830;
            union U7 ***l_854 = (void*)0;
            int16_t l_912[10][1] = {{(-1L)},{(-1L)},{0xB089L},{0x43CBL},{0x43CBL},{0xB089L},{0x43CBL},{0x43CBL},{0xB089L},{0x43CBL}};
            struct S3 * const *l_924 = &l_731;
            int i, j;
            (*g_743) = ((*l_742) = g_740);
            l_726[2] = ((l_745 > ((safe_sub_func_uint32_t_u_u(p_18, (safe_lshift_func_uint8_t_u_s((safe_div_func_int32_t_s_s(((*g_90) = (safe_rshift_func_int16_t_s_u((((g_754[1] , l_755) != l_756) ^ (((void*)0 != l_757) & ((*l_758) = l_745))), (l_759 <= 4UL)))), (**g_190))), l_726[0])))) & p_18)) || l_734);
            l_726[0] &= (safe_lshift_func_int16_t_s_s((*g_634), 0));
            for (g_108.f1 = 0; (g_108.f1 <= 1); g_108.f1 += 1)
            { /* block id: 327 */
                int64_t l_772 = (-1L);
                int32_t *l_792 = &g_192;
                int32_t *l_793 = &l_726[0];
                int32_t *l_794 = &l_726[2];
                int32_t *l_795[9][9] = {{&g_261.f0,&l_713,&l_726[2],&l_726[3],&l_745,&l_759,&g_192,&g_192,&g_264.f0},{&l_745,&g_370.f0,(void*)0,&g_192,(void*)0,&l_759,&l_726[2],(void*)0,&l_726[2]},{&g_370.f0,&l_713,(void*)0,(void*)0,&l_713,&g_370.f0,&l_745,(void*)0,(void*)0},{&l_759,(void*)0,&g_192,(void*)0,&g_370.f0,&l_745,&g_264.f0,&g_192,(void*)0},{&l_759,&l_745,&l_726[3],&l_726[2],&l_713,&g_261.f0,&l_745,&g_261.f0,&l_713},{&l_726[3],&g_192,&g_192,&l_726[3],&g_261.f0,&g_261.f0,&l_726[2],&g_370.f0,&g_264.f0},{&g_91,&l_726[2],(void*)0,&l_713,(void*)0,&l_745,&g_192,(void*)0,&g_192},{&g_370.f0,(void*)0,&g_192,(void*)0,&g_261.f0,&g_370.f0,&g_261.f0,(void*)0,&g_192},{(void*)0,(void*)0,&g_370.f0,(void*)0,&l_713,&l_759,&g_264.f0,&l_726[2],(void*)0}};
                int64_t *l_842 = &g_443;
                int8_t l_892 = 0L;
                int i, j;
                for (g_419 = 0; (g_419 <= 3); g_419 += 1)
                { /* block id: 330 */
                    int32_t l_784[7] = {0L,0L,0L,0L,0L,0L,0L};
                    union U7 ***l_790[4][5][4] = {{{(void*)0,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,(void*)0,&l_789},{&l_789,&l_789,&l_789,&l_789}},{{&l_789,&l_789,&l_789,&l_789},{(void*)0,&l_789,(void*)0,&l_789},{&l_789,(void*)0,&l_789,&l_789},{&l_789,(void*)0,(void*)0,&l_789},{(void*)0,&l_789,&l_789,(void*)0}},{{&l_789,(void*)0,&l_789,&l_789},{&l_789,(void*)0,(void*)0,&l_789},{&l_789,(void*)0,&l_789,(void*)0},{&l_789,&l_789,&l_789,&l_789},{&l_789,(void*)0,&l_789,&l_789}},{{(void*)0,(void*)0,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,&l_789,&l_789},{&l_789,&l_789,(void*)0,&l_789},{&l_789,&l_789,&l_789,&l_789}}};
                    int i, j, k;
                    l_713 &= (safe_div_func_int32_t_s_s(((-1L) < (((g_764 , g_764) , (safe_mod_func_int16_t_s_s(((void*)0 == l_767), (g_152[(g_419 + 3)][(g_108.f1 + 3)][g_108.f1] , (*g_634))))) && (safe_mul_func_int8_t_s_s(9L, l_759)))), 4294967288UL));
                    if ((safe_mod_func_int16_t_s_s(l_772, (l_759 && ((l_726[1] = (safe_mul_func_uint8_t_u_u((*g_249), l_772))) & p_18)))))
                    { /* block id: 333 */
                        int32_t l_783 = 0xC4E092E0L;
                        int i;
                        (**g_190) ^= (safe_mul_func_int16_t_s_s(((((l_759 && l_745) , (p_19 , (g_152[(g_419 + 3)][(g_108.f1 + 3)][g_108.f1].f0 , g_777))) , (l_778 == ((safe_sub_func_int64_t_s_s((safe_rshift_func_uint16_t_u_s(l_783, 4)), g_82)) , (void*)0))) | l_784[0]), p_18));
                        (**g_190) = l_783;
                        l_785 = (void*)0;
                        l_787 = &g_495;
                    }
                    else
                    { /* block id: 338 */
                        if ((**g_135))
                            break;
                    }
                    l_791 = l_789;
                }
                --l_801;
                if (((g_107 , (g_804 , (((**l_757) = ((p_19 & (safe_rshift_func_int8_t_s_s((g_389 , ((g_807[2][2] , ((*g_634) = ((safe_lshift_func_int8_t_s_u((((**g_190) &= (safe_sub_func_int32_t_s_s(((g_813 = l_812) == (g_814 , &g_110)), (((&l_791 != (void*)0) & 4294967289UL) , 3L)))) == p_18), 2)) && p_18))) < p_19)), 1))) > p_18)) | p_18))) , 0x42F7BAFAL))
                { /* block id: 348 */
                    for (g_110 = 0; (g_110 <= 1); g_110 += 1)
                    { /* block id: 351 */
                        return p_19;
                    }
                }
                else
                { /* block id: 354 */
                    uint32_t l_824 = 4294967295UL;
                    int8_t ** const *l_826 = &g_698[2][2][0];
                    int8_t ** const **l_825 = &l_826;
                    int8_t ** const *l_828 = &g_698[2][2][0];
                    int8_t ** const **l_827 = &l_828;
                    const int32_t ***l_831[3];
                    int64_t *l_835 = &g_443;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_831[i] = &l_829;
                    for (g_192 = 1; (g_192 >= 0); g_192 -= 1)
                    { /* block id: 357 */
                        int32_t **l_815 = (void*)0;
                        int32_t **l_816 = &l_792;
                        int32_t **l_817 = (void*)0;
                        int32_t **l_818 = &l_793;
                        (*l_818) = ((*l_816) = &l_713);
                    }
                    (*l_793) &= (safe_div_func_int64_t_s_s(((((g_821 , (l_822[1][2][2] != (g_823 , (p_19 , (*g_743))))) & l_824) < ((*l_835) = (g_230 = (l_824 , (((((l_734 < ((((*g_634) = ((l_834 = (g_832 = ((((*l_827) = ((*l_825) = &p_20)) == (void*)0) , l_829))) != (void*)0)) , p_18) , (*g_634))) >= p_19) == l_798[3]) <= p_18) == p_18))))) , p_19), g_192));
                }
                (*g_191) |= (safe_div_func_int64_t_s_s((safe_add_func_int64_t_s_s(g_788.f0, ((*l_842) = (safe_rshift_func_int16_t_s_u(0xE652L, 8))))), (18446744073709551614UL && ((**l_829) | (safe_lshift_func_int8_t_s_u(((safe_mod_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(((((g_851[3][1][0] == ((g_370 , (*g_853)) , l_854)) <= (((((safe_lshift_func_int8_t_s_s(l_734, 4)) == 0x2762EA5EL) | 0xE044743403AFC6C5LL) > (*g_634)) != p_18)) != 6L) & g_754[1].f2), (*l_793))), p_18)) || l_734), 1))))));
                for (g_823.f0 = 1; (g_823.f0 >= 0); g_823.f0 -= 1)
                { /* block id: 374 */
                    int16_t **l_872 = &g_634;
                    int16_t ***l_871 = &l_872;
                    int32_t l_893 = (-1L);
                    int32_t l_896 = 0x153B3D2DL;
                    int32_t l_897 = 9L;
                    int32_t l_898[10][4] = {{(-1L),(-1L),1L,(-4L)},{6L,(-1L),(-4L),(-4L)},{(-1L),(-1L),1L,(-4L)},{6L,(-1L),(-4L),(-4L)},{(-1L),(-1L),1L,(-4L)},{6L,(-1L),(-4L),(-4L)},{(-1L),(-1L),1L,(-4L)},{6L,(-1L),(-4L),(-4L)},{(-1L),(-1L),1L,(-4L)},{6L,(-1L),(-4L),(-4L)}};
                    uint8_t l_899 = 0xCBL;
                    int i, j;
                    l_713 = ((*g_97) = (1UL < 5L));
                    if ((**g_462))
                        break;
                    if (((-9L) == ((**l_834) || ((*g_249) = (safe_lshift_func_int8_t_s_u(((safe_lshift_func_int8_t_s_s(0L, (safe_div_func_uint16_t_u_u(0x6054L, ((**l_870) = (safe_sub_func_int64_t_s_s(g_389.f3, (safe_mod_func_int64_t_s_s(((*l_842) &= (((safe_unary_minus_func_uint8_t_u((((((((l_870 == ((p_19 <= p_19) , ((*l_871) = (void*)0))) || (-3L)) == g_91) , 65532UL) && 0UL) & p_18) ^ (*l_793)))) | p_19) & (*g_249))), p_18))))))))) >= (*g_249)), 1))))))
                    { /* block id: 382 */
                        uint32_t ***l_877[3][10] = {{&l_822[1][2][2],&l_822[1][2][2],&l_822[1][0][3],&l_822[1][2][2],&l_822[1][2][2],&l_822[1][2][2],&l_822[1][0][3],&l_822[1][2][2],&l_822[1][2][2],&l_822[1][0][3]},{(void*)0,&l_822[1][2][2],(void*)0,(void*)0,&l_822[1][2][2],(void*)0,&l_822[1][0][3],(void*)0,&l_822[1][2][2],(void*)0},{&l_822[1][1][2],&l_822[1][2][2],&l_822[1][1][2],(void*)0,&l_822[1][0][3],&l_822[1][0][3],(void*)0,&l_822[1][1][2],&l_822[1][2][2],&l_822[1][1][2]}};
                        uint32_t ****l_876 = &l_877[0][3];
                        int32_t l_894 = 0x21976617L;
                        int32_t l_895[4];
                        int i, j;
                        for (i = 0; i < 4; i++)
                            l_895[i] = 1L;
                        (*g_97) |= (safe_lshift_func_int8_t_s_s((+(((((((((**l_755) = ((g_389 , l_726[0]) || (((*l_876) = (void*)0) == &g_744[4]))) && (safe_sub_func_uint32_t_u_u((((safe_lshift_func_int16_t_s_u((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_s(p_19, 7)), (((((!((0x9D76L ^ 1UL) == ((safe_mul_func_uint8_t_u_u(((**l_755) |= (safe_mul_func_int16_t_s_s((((p_19 < (g_891[7][3][2] , l_892)) , l_713) & 1L), p_19))), 0xC2L)) >= p_19))) >= g_814.f0) == (**l_834)) && (*l_792)) > p_18))), 0)) == 4294967293UL) , 0xE5EB1B17L), (-1L)))) ^ l_893) && 0L) != (*g_634)) ^ 0x8869L) < 1L) || 255UL)), l_894));
                        l_899--;
                        l_902[0][3]++;
                        (**g_190) = ((*g_97) = (**g_96));
                    }
                    else
                    { /* block id: 391 */
                        uint64_t *l_907[6][2] = {{&g_732.f2,&g_143[0]},{&g_143[0],&g_732.f2},{&g_143[0],&g_143[0]},{&g_732.f2,&g_143[0]},{&g_143[0],&g_732.f2},{&g_143[0],&g_143[0]}};
                        uint32_t l_925[6] = {0xFED702F2L,1UL,0xFED702F2L,0xFED702F2L,1UL,0xFED702F2L};
                        int i, j;
                        l_798[0] ^= ((*g_191) = (((safe_add_func_int64_t_s_s((*l_792), g_823.f0)) ^ (g_495.f2 = l_896)) < ((0xE001L > 1UL) != (safe_sub_func_int32_t_s_s((6L >= ((p_18 >= ((safe_lshift_func_uint16_t_u_s(0UL, 9)) & (((p_18 || 0x3783FCB3A6E4B119LL) || p_18) , 0xD76EL))) < (**l_834))), l_912[8][0])))));
                        (*l_792) |= ((safe_rshift_func_uint16_t_u_u((safe_div_func_int64_t_s_s((safe_mul_func_int8_t_s_s(0xADL, (((safe_mod_func_uint8_t_u_u(((*g_249) |= p_19), (safe_rshift_func_uint8_t_u_u(((((*g_741) = (!((p_19 , g_290) == l_767))) , (&p_20 != (((void*)0 != l_924) , ((*g_660) , &p_21)))) > 0x48L), 1)))) >= (*l_794)) && (*l_830)))), g_519[6][1][2].f2)), 3)) <= l_925[0]);
                        l_926++;
                    }
                    (*g_135) = (*g_135);
                }
            }
        }
        if (l_929)
        { /* block id: 404 */
            const uint8_t l_963 = 1UL;
            int32_t l_967[1][4] = {{(-3L),(-3L),(-3L),(-3L)}};
            int16_t l_1057 = 0x640CL;
            int i, j;
            for (l_800 = 0; (l_800 == 22); l_800 = safe_add_func_int32_t_s_s(l_800, 1))
            { /* block id: 407 */
                uint32_t l_932 = 4294967286UL;
                uint8_t *l_940[3][6][1] = {{{(void*)0},{&g_182},{(void*)0},{&g_419},{(void*)0},{&g_182}},{{(void*)0},{&g_419},{(void*)0},{&g_182},{(void*)0},{&g_419}},{{(void*)0},{&g_182},{(void*)0},{&g_419},{(void*)0},{&g_182}}};
                int32_t l_941 = 6L;
                int16_t l_946 = 0x152AL;
                union U5 *l_974[1];
                uint16_t *l_976 = &g_300;
                int32_t l_990[7] = {0L,0L,0L,0L,0L,0L,0L};
                uint8_t ** const *l_993[6];
                const union U7 *l_1011 = &g_786;
                uint32_t l_1012 = 0x90DF6A88L;
                uint8_t ***l_1045 = &l_757;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_974[i] = &g_625;
                for (i = 0; i < 6; i++)
                    l_993[i] = (void*)0;
                if (l_932)
                    break;
                (*g_659) = (((safe_mul_func_uint8_t_u_u((((++(*g_249)) <= (safe_div_func_int64_t_s_s(p_19, p_19))) , (l_967[0][1] &= (!((((*g_249) <= (l_941 ^= p_18)) ^ ((safe_add_func_uint32_t_u_u((((g_539.f4 != p_18) <= (l_726[1] = ((((safe_mul_func_int16_t_s_s(l_946, (((p_18 || (safe_rshift_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_u(((safe_add_func_uint64_t_u_u((((((((l_964 = (safe_add_func_uint32_t_u_u(((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_u((p_19 |= (((safe_lshift_func_uint8_t_u_u((g_419 &= (safe_rshift_func_int16_t_s_u(0xCB2AL, l_946))), (*g_249))) | l_932) < l_713)), 1)), 6)) <= l_734), l_963))) <= l_932) > 6L) , 0xC6L) <= (-1L)) || p_18) == g_679.f3), l_946)) != l_932), p_18)) == l_965) , 0x08L), l_902[0][3]))) ^ g_788.f2) >= 1UL))) != 1UL) | (**g_190)) && p_19))) | l_966), l_929)) , 0xA3A5L)) , (**l_829))))), 0xDAL)) | (-7L)) , l_968);
                if (((safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(l_973, (((((((l_974[0] = l_974[0]) != (void*)0) == (g_975 , (g_975.f2 = ((*l_976) = p_18)))) > (((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u(((((safe_sub_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s((~0x41L), (l_967[0][1] && 0xFCL))) < (l_726[0] ^= (*g_741))), (*g_249))) , g_482) != (void*)0) && (**g_832)), l_941)) >= p_18), l_946)), p_18)), p_19)) , l_902[0][3]) | l_734)) >= l_967[0][3]) , p_18) , (-1L)))), l_990[5])) > (*g_634)))
                { /* block id: 421 */
                    int16_t l_991 = 0x3087L;
                    return l_991;
                }
                else
                { /* block id: 423 */
                    uint8_t l_1025 = 0xDDL;
                    const int32_t l_1026 = 0x1A98D812L;
                    int32_t *l_1030 = &l_759;
                    int16_t * const *l_1040 = (void*)0;
                    uint8_t ***l_1044 = (void*)0;
                    int32_t l_1055[5];
                    uint32_t l_1058 = 0x88292282L;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1055[i] = 0x9A0270A6L;
                    (**g_462) = (((l_992 == l_993[5]) | ((((((((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((safe_div_func_int8_t_s_s(l_967[0][3], (*g_249))) == ((safe_mul_func_uint8_t_u_u(255UL, (safe_add_func_int8_t_s_s((*l_830), (((*l_976) ^= (safe_sub_func_int8_t_s_s(((g_1010 , l_1011) == (void*)0), 0UL))) != p_19))))) <= l_990[5])) == l_932), p_18)), l_1012)), 7)), l_967[0][1])) && p_18) | p_19) & 0x474BL) < p_19) && p_18) && (-9L)) ^ p_18)) || p_19);
                    if ((safe_add_func_uint16_t_u_u(((p_19 = l_717) == (g_679 , ((((l_726[0] = (((safe_sub_func_uint64_t_u_u((g_261.f1 != (l_902[7][4] <= (l_1027 ^= (safe_add_func_uint16_t_u_u((((*g_97) = 1L) || ((**g_740) |= (1UL <= (safe_rshift_func_uint16_t_u_s(((-1L) < (p_18 & (((((safe_lshift_func_uint8_t_u_s(((safe_mul_func_uint8_t_u_u((l_1025 = ((**l_757) = (*g_249))), p_18)) , 252UL), 2)) , l_713) < (*g_634)) <= p_18) , p_18))), p_18))))), l_1026))))), 0x6A4C864DA4FEA684LL)) ^ p_18) <= 9UL)) & 0xF2L) ^ 0x17072A4EC6BE8CCELL) != p_18))), l_932)))
                    { /* block id: 433 */
                        int32_t *l_1029 = &l_967[0][1];
                        int32_t **l_1028[6][3][8] = {{{&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029},{(void*)0,(void*)0,&l_1029,(void*)0,(void*)0,(void*)0,&l_1029,&l_1029},{(void*)0,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,&l_1029,&l_1029}},{{&l_1029,&l_1029,&l_1029,(void*)0,&l_1029,(void*)0,&l_1029,&l_1029},{&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,&l_1029,(void*)0,&l_1029},{(void*)0,(void*)0,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,&l_1029}},{{&l_1029,&l_1029,&l_1029,(void*)0,(void*)0,&l_1029,&l_1029,(void*)0},{&l_1029,(void*)0,&l_1029,&l_1029,&l_1029,&l_1029,(void*)0,&l_1029},{&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029}},{{&l_1029,&l_1029,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,(void*)0},{&l_1029,(void*)0,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,(void*)0},{&l_1029,&l_1029,(void*)0,&l_1029,(void*)0,&l_1029,&l_1029,(void*)0}},{{&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029},{&l_1029,&l_1029,&l_1029,(void*)0,&l_1029,(void*)0,&l_1029,&l_1029},{(void*)0,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029}},{{&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,&l_1029,(void*)0,(void*)0},{&l_1029,(void*)0,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,&l_1029},{&l_1029,&l_1029,&l_1029,&l_1029,(void*)0,&l_1029,&l_1029,&l_1029}}};
                        int i, j, k;
                        if (p_18)
                            break;
                        (*l_829) = (l_1030 = ((*g_523) = (*g_135)));
                    }
                    else
                    { /* block id: 438 */
                        uint64_t *l_1041 = &g_788.f2;
                        int32_t l_1046 = 0x12CDB18CL;
                        int8_t l_1047 = 7L;
                        int32_t *l_1048 = &l_799[3];
                        int32_t *l_1049 = &l_759;
                        int32_t *l_1050 = &l_713;
                        int32_t *l_1051 = &g_264.f0;
                        int32_t *l_1052 = &l_941;
                        int32_t *l_1053 = &l_759;
                        int32_t *l_1054[7] = {(void*)0,&g_261.f0,&g_261.f0,(void*)0,&g_261.f0,&g_261.f0,(void*)0};
                        int i;
                        l_713 = (safe_rshift_func_uint16_t_u_s((p_19 >= (*g_634)), ((((((*g_191) ^= ((g_1033 , g_1034) , ((*l_1030) = (((!((*l_1041) = (1UL | ((void*)0 != l_1040)))) != ((safe_rshift_func_uint16_t_u_s((p_19 | ((((p_18 >= (*g_97)) || p_18) , p_18) ^ p_18)), 13)) != 6L)) ^ (-1L))))) , l_1044) != l_1045) && l_1046) == g_519[6][1][2].f0)));
                        if ((**l_829))
                            break;
                        l_1058++;
                        if ((**g_392))
                            continue;
                    }
                }
            }
            (**g_190) |= (-1L);
        }
        else
        { /* block id: 450 */
            union U5 **l_1063 = &l_1062;
            int64_t *l_1083 = &l_929;
            int64_t **l_1082 = &l_1083;
            int64_t ***l_1084 = (void*)0;
            int64_t ***l_1085 = (void*)0;
            int64_t ***l_1086 = &l_1082;
            int8_t l_1094[1][8][5] = {{{0x65L,0x65L,0x49L,0x49L,0x65L},{(-7L),(-10L),(-7L),(-10L),(-7L)},{0x65L,0x49L,0x49L,0x65L,0x65L},{0xD1L,(-10L),0xD1L,(-10L),0xD1L},{0x65L,0x65L,0x49L,0x49L,0x65L},{(-7L),(-10L),(-7L),(-10L),(-7L)},{0x65L,0x49L,0x49L,0x65L,0x65L},{0xD1L,(-10L),0xD1L,(-10L),0xD1L}}};
            int32_t l_1095 = 0xA30288E3L;
            int32_t l_1099[1];
            int16_t l_1100 = 0L;
            uint32_t l_1101 = 2UL;
            union U6 *l_1127 = &g_108;
            uint16_t l_1150 = 2UL;
            struct S2 *l_1185 = &g_1186;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1099[i] = (-1L);
            (*l_1063) = (g_1061 , l_1062);
            if (((g_804.f3 || (safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(((((*l_1062) , g_1068) == ((*l_1086) = (((safe_lshift_func_uint16_t_u_s(65534UL, (safe_div_func_uint8_t_u_u((*g_249), ((g_814.f0 | (((safe_rshift_func_uint16_t_u_u(l_1078[1][0][0], 2)) | (safe_add_func_uint8_t_u_u(p_19, (0xFB9C3B851A0FD121LL | l_1081)))) < p_18)) || p_19))))) | l_1027) , l_1082))) > (*g_249)), 15)), 0x7FB60F5EF18BB6DALL))) && (**g_462)))
            { /* block id: 453 */
                for (g_975.f2 = 6; (g_975.f2 != 39); g_975.f2 = safe_add_func_uint16_t_u_u(g_975.f2, 4))
                { /* block id: 456 */
                    for (g_68 = 0; (g_68 >= 51); g_68 = safe_add_func_int8_t_s_s(g_68, 1))
                    { /* block id: 459 */
                        if (p_19)
                            break;
                    }
                }
                return (**g_740);
            }
            else
            { /* block id: 464 */
                int32_t *l_1091 = &g_814.f0;
                int32_t *l_1092 = &g_261.f0;
                int32_t *l_1093[5][6] = {{&g_261.f0,(void*)0,&l_799[1],(void*)0,&l_799[1],(void*)0},{&l_799[1],&g_261.f0,&l_799[1],&l_713,&l_713,&l_799[1]},{&l_799[1],&l_799[1],&l_713,(void*)0,&g_370.f0,(void*)0},{&g_261.f0,&l_799[1],&g_261.f0,&l_799[1],&l_713,&l_713},{(void*)0,&g_261.f0,&g_261.f0,(void*)0,&l_799[1],(void*)0}};
                int i, j;
                l_1096++;
                l_1101--;
            }
            (*g_97) = (l_902[6][7] , p_19);
            for (g_443 = 0; (g_443 <= 0); g_443 += 1)
            { /* block id: 471 */
                union U5 **l_1104 = &l_1062;
                const int32_t l_1124 = (-1L);
                uint64_t ***l_1125[1][8] = {{&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271}};
                int32_t l_1155 = 0x8C6C4CBCL;
                int32_t l_1156 = 9L;
                int32_t l_1157 = (-1L);
                int32_t l_1158[2][3];
                uint16_t l_1180 = 0UL;
                const int8_t *l_1189 = (void*)0;
                const int8_t **l_1188 = &l_1189;
                const int8_t ***l_1187 = &l_1188;
                int8_t ***l_1190 = (void*)0;
                uint16_t l_1191 = 4UL;
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_1158[i][j] = 1L;
                }
                for (g_814.f0 = 0; (g_814.f0 >= 0); g_814.f0 -= 1)
                { /* block id: 474 */
                    int8_t *l_1126 = &g_82;
                    int i;
                    l_726[(g_814.f0 + 3)] = (l_1063 != l_1104);
                    if (l_1099[0])
                        break;
                    (*g_97) ^= ((!(((*g_249) = (safe_rshift_func_uint16_t_u_u(p_19, 8))) || ((safe_sub_func_uint8_t_u_u((safe_div_func_int16_t_s_s(((((*l_1126) = (g_1112 , ((((((void*)0 != l_1104) == ((((safe_mod_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_s((((safe_mul_func_int16_t_s_s((l_726[2] < 1L), p_19)) | (((safe_rshift_func_uint16_t_u_u(((safe_unary_minus_func_uint32_t_u(p_18)) || (safe_add_func_int32_t_s_s((p_19 , p_18), (*g_191)))), l_713)) && 0x662CL) , (*g_634))) & l_1124), 1)) & (*l_830)), 7UL)) , (void*)0) != l_1125[0][5]) & (*g_249))) < 0x41C490A8L) || (**g_740)) && l_1101))) <= 255UL) > p_19), p_18)), 1L)) < (*g_634)))) , p_18);
                    for (g_230 = 0; (g_230 <= 0); g_230 += 1)
                    { /* block id: 482 */
                        int i, j, k;
                        g_1128 = l_1127;
                        return l_1094[g_443][(g_230 + 2)][g_230];
                    }
                    for (g_108.f1 = 0; (g_108.f1 <= 1); g_108.f1 += 1)
                    { /* block id: 488 */
                        int i, j, k;
                        l_1129 = func_75(l_1094[g_443][(g_814.f0 + 6)][(g_443 + 4)]);
                        return p_18;
                    }
                }
                for (g_788.f2 = 0; (g_788.f2 <= 1); g_788.f2 += 1)
                { /* block id: 495 */
                    uint16_t l_1130[3][4][1] = {{{0xC0BFL},{0UL},{0x90B8L},{0UL}},{{0x90B8L},{0UL},{0xC0BFL},{0UL}},{{0x90B8L},{0UL},{0x90B8L},{0UL}}};
                    int32_t *l_1153 = (void*)0;
                    int32_t *l_1154[1];
                    int32_t l_1160 = 0x0BC87FE6L;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_1154[i] = &g_192;
                    for (l_717 = 1; (l_717 >= 0); l_717 -= 1)
                    { /* block id: 498 */
                        uint32_t l_1148 = 5UL;
                        int32_t l_1149 = 0x9B3C89CDL;
                        (*g_97) = (l_1130[0][0][0] , ((((safe_add_func_uint16_t_u_u(((((*g_191) ^= (((safe_rshift_func_int16_t_s_s((safe_sub_func_int32_t_s_s((safe_add_func_uint64_t_u_u(p_18, ((safe_unary_minus_func_uint64_t_u(l_1095)) == (1L <= (+(*g_249)))))), (l_1141 != (void*)0))), (safe_mul_func_uint16_t_u_u(p_19, (((safe_add_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u(((l_1148 = (*g_634)) , p_19), 252UL)) < p_18), l_1149)) > p_18) >= 0x36BEBEC0L))))) || l_1124) <= l_1130[0][0][0])) | l_1094[0][0][3]) == 0UL), (*g_634))) && l_1130[0][0][0]) > 3L) ^ 0xBEB7L));
                    }
                    (**g_190) = (l_1150 == (safe_lshift_func_int16_t_s_u(0x0079L, 6)));
                    g_1164++;
                    for (g_823.f0 = 1; (g_823.f0 >= 0); g_823.f0 -= 1)
                    { /* block id: 507 */
                        return (**g_740);
                    }
                }
                if ((!((*l_1129) >= (safe_lshift_func_uint8_t_u_u(p_19, 0)))))
                { /* block id: 511 */
                    uint64_t ****l_1174[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1174[i] = &l_1125[0][5];
                    for (l_717 = 0; (l_717 <= 1); l_717 += 1)
                    { /* block id: 514 */
                        int i, j;
                        (*g_191) = 0L;
                        return l_1158[(g_443 + 1)][(l_717 + 1)];
                    }
                    (**g_190) |= (p_18 || ((safe_lshift_func_int16_t_s_s(p_18, 9)) && (safe_lshift_func_uint16_t_u_s((((l_1175[4] = l_1125[0][5]) != (void*)0) && (l_1099[0] && 0xCCC82F8CL)), 12))));
                    for (g_1033.f2 = 0; (g_1033.f2 <= 1); g_1033.f2 += 1)
                    { /* block id: 522 */
                        (*g_97) = 0x6174F32DL;
                    }
                }
                else
                { /* block id: 525 */
                    int64_t l_1179 = 0x6D7BE16E239453D6LL;
                    for (l_1096 = 0; (l_1096 <= 1); l_1096 += 1)
                    { /* block id: 528 */
                        int32_t *l_1176 = (void*)0;
                        int32_t *l_1177 = &g_91;
                        int32_t *l_1178[3][2][9] = {{{&l_1157,&g_370.f0,&l_1158[0][0],&g_91,&l_1156,&l_1156,&g_91,&l_1158[0][0],&g_370.f0},{&l_726[0],&l_1158[0][0],&l_1157,&l_1158[0][1],&l_1158[0][1],&l_799[1],&l_799[1],&l_1158[0][1],&l_1158[0][1]}},{{&l_726[0],(void*)0,&l_726[0],&l_799[1],&g_91,&l_1157,&l_1099[0],&l_1099[0],&l_1157},{&l_1157,&l_1158[0][0],&l_726[0],&l_1158[0][0],&l_1157,&l_1158[0][1],&l_1158[0][1],&l_799[1],&l_799[1]}},{{&l_1158[0][0],&g_370.f0,&l_1157,&l_1158[0][0],&l_1099[0],&l_1158[0][1],(void*)0,&l_1156,&l_1157},{&l_726[0],&l_1157,(void*)0,&g_370.f0,&l_1156,&g_370.f0,(void*)0,&l_1157,&l_726[0]}}};
                        int i, j, k;
                        --l_1180;
                        return l_1183;
                    }
                    (**g_190) &= l_1179;
                    for (g_68 = 0; (g_68 <= 1); g_68 += 1)
                    { /* block id: 535 */
                        struct S2 *l_1184 = &g_679;
                        l_1185 = l_1184;
                    }
                }
                for (l_973 = 0; (l_973 <= 1); l_973 += 1)
                { /* block id: 541 */
                    uint16_t l_1203 = 6UL;
                    l_1191 &= (l_1187 == l_1190);
                    (*g_191) = (safe_mod_func_uint32_t_u_u((((**l_870) = p_18) && 0x2B99L), l_1155));
                    for (g_1034.f0 = 0; (g_1034.f0 <= 1); g_1034.f0 += 1)
                    { /* block id: 547 */
                        int32_t l_1200 = (-1L);
                        int32_t *l_1201 = &l_799[1];
                        int32_t *l_1202[5][6] = {{&l_1158[0][0],&l_965,&l_965,&l_1158[0][0],&l_1158[0][0],&l_1158[0][0]},{&l_1158[0][0],&l_1158[0][0],&l_1158[0][0],&l_965,&l_965,&l_1158[0][0]},{&l_1095,&l_1095,&l_965,(void*)0,&l_965,&l_1095},{&l_965,&l_1158[0][0],(void*)0,(void*)0,&l_1158[0][0],&l_965},{&l_1095,&l_965,(void*)0,&l_965,&l_1095,&l_1095}};
                        int i, j;
                        (**g_190) &= 2L;
                        (*g_191) |= ((p_19 & (g_1194 , (safe_lshift_func_uint16_t_u_s(0UL, 1)))) , (safe_div_func_int32_t_s_s((0x71E61ADDB366F2AELL != 0x2F89F7E6D4620E5BLL), (safe_unary_minus_func_int16_t_s(p_18)))));
                        if ((*g_833))
                            continue;
                        ++l_1203;
                    }
                }
            }
        }
    }
    return (**g_740);
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_248 g_107.f0 g_82 g_63 g_90 g_257 g_258 g_259 g_261 g_97 g_91 g_264 g_191 g_192 g_108.f1 g_190 g_270 g_96 g_300 g_68 g_143 g_230 g_98 g_99 g_546 g_249 g_182 g_519.f0 g_389.f3 g_597 g_260 g_532 g_625 g_370.f0 g_636 g_637 g_640 g_483.f0 g_108.f0.f0 g_659 g_634 g_679 g_692 g_693
 * writes: g_63 g_248 g_91 g_97 g_108.f1 g_192 g_271 g_300 g_230 g_182 g_82 g_370.f0 g_634 g_143 g_659 g_690 g_692
 */
static int8_t * func_22(const uint16_t  p_23, uint64_t  p_24, uint8_t  p_25, const uint32_t  p_26)
{ /* block id: 2 */
    uint16_t l_44 = 1UL;
    uint64_t *l_45[7];
    int32_t l_62[6][1][1] = {{{1L}},{{0xE9EE1947L}},{{1L}},{{0xE9EE1947L}},{{1L}},{{0xE9EE1947L}}};
    int8_t *l_252 = &g_82;
    int8_t **l_251 = &l_252;
    int32_t l_670 = 0x569430FDL;
    int8_t ***l_694 = &g_692;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_45[i] = (void*)0;
    (*l_694) = func_30((safe_div_func_uint32_t_u_u((safe_add_func_int8_t_s_s(p_26, ((p_25 ^ g_27[0]) < (safe_add_func_uint16_t_u_u((l_62[0][0][0] = (((safe_lshift_func_uint16_t_u_s((((l_44 <= (p_24 |= p_25)) > (safe_sub_func_int16_t_s_s(9L, l_44))) != func_48(p_25, func_52(func_58((g_27[0] | g_27[0]), g_27[1], l_62[0][0][0]), p_26, l_251, g_27[1], &l_252), l_62[1][0][0])), p_23)) <= l_62[4][0][0]) | 0x02384E95L)), (-7L)))))), l_44)), l_44, &l_252, l_670, p_25);
    for (l_44 = (-28); (l_44 == 36); l_44 = safe_add_func_uint16_t_u_u(l_44, 8))
    { /* block id: 290 */
        return (*g_692);
    }
    return (*g_692);
}


/* ------------------------------------------ */
/* 
 * reads : g_679 g_634 g_63 g_190 g_191 g_192 g_97 g_91 g_249 g_182 g_370.f0 g_692
 * writes: g_63 g_91 g_690 g_370.f0
 */
static int8_t ** func_30(uint32_t  p_31, uint8_t  p_32, int8_t ** p_33, uint8_t  p_34, uint32_t  p_35)
{ /* block id: 280 */
    int32_t l_675 = 0x6643AAE8L;
    union U8 ***l_686 = (void*)0;
    int32_t l_687 = 0L;
    int16_t *l_688 = (void*)0;
    int16_t *l_689 = &g_690;
    int32_t *l_691[1];
    int i;
    for (i = 0; i < 1; i++)
        l_691[i] = &g_264.f0;
    g_370.f0 &= ((safe_lshift_func_int16_t_s_s(p_32, l_675)) <= (!(((((*l_689) = (safe_sub_func_int8_t_s_s((g_679 , (safe_mod_func_int16_t_s_s(((*g_634) = (*g_634)), p_34))), ((safe_sub_func_uint8_t_u_u(((safe_add_func_int32_t_s_s((**g_190), (((*g_97) ^= 0xFF38EA3CL) | l_675))) >= (l_687 = (((l_686 != (void*)0) != 0L) != p_34))), 0xB4L)) ^ (*g_249))))) | 0xA7BBL) | p_35) | l_675)));
    return g_692;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_96 g_97 g_91 g_190 g_191 g_192 g_300 g_68 g_143 g_257.f0 g_230 g_98 g_99 g_546 g_249 g_182 g_519.f0 g_389.f3 g_597 g_259 g_260 g_532 g_625 g_63 g_370.f0 g_107.f0 g_257 g_636 g_637 g_261 g_640 g_483.f0 g_108.f0.f0 g_659 g_634 g_27
 * writes: g_300 g_63 g_230 g_192 g_182 g_91 g_82 g_370.f0 g_634 g_143 g_659
 */
static uint8_t  func_48(int16_t  p_49, int8_t * p_50, const uint8_t  p_51)
{ /* block id: 110 */
    int32_t l_276 = 0L;
    int8_t *l_282 = &g_82;
    int8_t **l_281[5][2] = {{&l_282,(void*)0},{(void*)0,&l_282},{(void*)0,(void*)0},{&l_282,(void*)0},{(void*)0,&l_282}};
    int16_t l_294 = 0L;
    int16_t *l_314[8][3] = {{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294},{&l_294,&l_294,&l_294}};
    int16_t l_330 = 0x84D7L;
    int32_t l_331 = (-10L);
    int32_t l_332 = 1L;
    int32_t l_333[7][2] = {{0x63935E4DL,0L},{0xCA76A6F4L,0x81819350L},{0xCA76A6F4L,0L},{0x63935E4DL,0x63935E4DL},{0L,0xCA76A6F4L},{0x81819350L,0xCA76A6F4L},{0L,0x63935E4DL}};
    uint32_t l_336 = 0x0CC205E8L;
    int64_t l_388 = (-6L);
    const uint64_t *l_407 = &g_143[0];
    uint32_t *l_459[5];
    int8_t l_567 = 0x9EL;
    int16_t l_643 = (-3L);
    uint8_t ***l_649 = (void*)0;
    union U8 *l_657 = &g_658[0][0][1];
    union U8 **l_656 = &l_657;
    union U8 ***l_662 = &g_659;
    uint32_t *l_666[1][8];
    int i, j;
    for (i = 0; i < 5; i++)
        l_459[i] = (void*)0;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
            l_666[i][j] = &g_110;
    }
    if ((safe_div_func_uint32_t_u_u((safe_div_func_int16_t_s_s(0L, l_276)), (safe_div_func_int32_t_s_s((((*p_50) & (safe_add_func_int32_t_s_s((l_281[0][1] == &l_282), (**g_96)))) <= (**g_190)), (safe_add_func_uint8_t_u_u((~(!((safe_sub_func_uint32_t_u_u((&l_282 != &p_50), (*g_191))) < 1UL))), l_276)))))))
    { /* block id: 111 */
        union U5 *l_289 = (void*)0;
        union U5 **l_291 = &l_289;
        (*l_291) = l_289;
    }
    else
    { /* block id: 113 */
        uint16_t *l_299 = &g_300;
        uint32_t l_311 = 8UL;
        int16_t *l_312 = &g_63;
        uint64_t l_313 = 0UL;
        uint32_t l_315[8][5][6] = {{{0x67FB14B8L,2UL,1UL,0x6C51E9E2L,0xEE67E9CEL,0x9D79BECEL},{0x4ABB6083L,4294967287UL,0x30DF1235L,0x67FB14B8L,4294967294UL,0x246B0190L},{4294967295UL,4294967295UL,0UL,0xADA6E78CL,0x6B18B82BL,0x37EBB39FL},{0xBA0CF04CL,5UL,4294967294UL,0x32B6C0A9L,9UL,1UL},{0x3C8D7FFEL,0x9D79BECEL,0xF6ADCC65L,0x19CB918FL,0UL,4294967295UL}},{{0xE282847CL,4294967292UL,0xB6EA32EEL,1UL,4294967287UL,4294967287UL},{0xEE67E9CEL,9UL,9UL,0xEE67E9CEL,0xA699ECD2L,5UL},{0UL,1UL,1UL,0xF6ADCC65L,0x246B0190L,2UL},{0UL,0xA354450CL,4294967289UL,0UL,0x246B0190L,0x4ABB6083L},{4294967295UL,1UL,9UL,0x41B177A2L,0xA699ECD2L,4294967294UL}},{{0x32B6C0A9L,9UL,4294967295UL,0xA354450CL,4294967287UL,0x3C8D7FFEL},{4294967289UL,4294967292UL,0xC4C1271EL,4294967294UL,0UL,0x32B6C0A9L},{1UL,0x9D79BECEL,0xA3A0DC72L,8UL,9UL,0xA699ECD2L},{0x9D79BECEL,5UL,4294967288UL,0xE282847CL,0x6B18B82BL,3UL},{0xADA6E78CL,4294967295UL,4294967292UL,0UL,4294967294UL,0x30DF1235L}},{{0xD0AF1690L,1UL,5UL,1UL,0x37EBB39FL,0UL},{0x30DF1235L,0x41B177A2L,0x4ABB3CF0L,0x41B177A2L,0x30DF1235L,4294967295UL},{2UL,8UL,0x9CE3384BL,4294967295UL,0xA699ECD2L,4294967287UL},{1UL,0x6B18B82BL,0x9D79BECEL,8UL,9UL,4294967287UL},{1UL,0x6C51E9E2L,0x9CE3384BL,3UL,4294967294UL,4294967295UL}},{{9UL,0xF6ADCC65L,0x4ABB3CF0L,0xA3A0DC72L,3UL,0UL},{4294967287UL,0x4ABB3CF0L,5UL,2UL,0UL,0xA354450CL},{3UL,0xADA6E78CL,4294967287UL,4294967295UL,0x246B0190L,0x19CB918FL},{0xE282847CL,0UL,0x31727D57L,0x504D460EL,0x6B18B82BL,0xA3A0DC72L},{0UL,4294967295UL,0x543B7BEBL,0xC4C1271EL,0x4ABB6083L,0x34DD9D57L}},{{4294967289UL,0xA3A0DC72L,9UL,4294967294UL,0x9CE3384BL,0x4ABB6083L},{0xBA0CF04CL,8UL,0xD0AF1690L,0xD0AF1690L,8UL,0xBA0CF04CL},{0xF6ADCC65L,0xB6EA32EEL,4294967295UL,0x9D79BECEL,0x34DD9D57L,0x9CE3384BL},{8UL,4294967288UL,0UL,0UL,4294967292UL,0x41B177A2L},{8UL,1UL,0UL,0x9D79BECEL,4294967295UL,4294967292UL}},{{0xF6ADCC65L,0x34DD9D57L,0xEE67E9CEL,0xD0AF1690L,4294967295UL,1UL},{0xBA0CF04CL,4294967295UL,9UL,4294967294UL,0xD0AF1690L,1UL},{4294967289UL,0xA354450CL,0xB6EA32EEL,0xC4C1271EL,0x0C4D3313L,0UL},{0UL,4294967287UL,8UL,0x504D460EL,0xF6ADCC65L,0xA699ECD2L},{0xE282847CL,0x67FB14B8L,4294967295UL,4294967295UL,0xADA6E78CL,0x9D79BECEL}},{{3UL,0xC4C1271EL,0xA354450CL,2UL,0x504D460EL,3UL},{4294967287UL,5UL,3UL,0xA3A0DC72L,3UL,5UL},{9UL,4294967289UL,0x37EBB39FL,3UL,4294967287UL,9UL},{1UL,0xD0AF1690L,3UL,8UL,0xC4C1271EL,1UL},{1UL,0xD0AF1690L,0x34DD9D57L,4294967295UL,4294967287UL,0xE282847CL}}};
        int32_t l_318 = 0x2A6E63B8L;
        int32_t l_327 = 1L;
        int32_t l_334[4][1][4] = {{{0x7617977AL,0x7617977AL,(-2L),(-2L)}},{{0x7617977AL,0x7617977AL,(-2L),(-2L)}},{{0x7617977AL,0x7617977AL,(-2L),(-2L)}},{{0x7617977AL,0x7617977AL,(-2L),(-2L)}}};
        int64_t l_335[8][4] = {{0xF79BC65250F36B81LL,0x6087708FEE426FECLL,0x6087708FEE426FECLL,0xF79BC65250F36B81LL},{0xF65186CB05A65902LL,0x6087708FEE426FECLL,0xEC74DB1BB4CEAF6BLL,0x6087708FEE426FECLL},{0x6087708FEE426FECLL,0x5068C64CD6CF3194LL,0xEC74DB1BB4CEAF6BLL,0xEC74DB1BB4CEAF6BLL},{0xF65186CB05A65902LL,0xF65186CB05A65902LL,0x6087708FEE426FECLL,0xEC74DB1BB4CEAF6BLL},{0xF79BC65250F36B81LL,0x5068C64CD6CF3194LL,0xF79BC65250F36B81LL,0x6087708FEE426FECLL},{0xF79BC65250F36B81LL,0x6087708FEE426FECLL,0x6087708FEE426FECLL,0xF79BC65250F36B81LL},{0xF65186CB05A65902LL,0x6087708FEE426FECLL,0x5068C64CD6CF3194LL,0xF79BC65250F36B81LL},{0xF79BC65250F36B81LL,0xF65186CB05A65902LL,0x5068C64CD6CF3194LL,0x5068C64CD6CF3194LL}};
        uint32_t l_415[5][5] = {{4294967286UL,1UL,4294967286UL,4294967286UL,1UL},{1UL,4294967295UL,4294967295UL,1UL,4294967295UL},{1UL,1UL,0x3DE580A4L,1UL,1UL},{4294967295UL,1UL,4294967295UL,4294967295UL,1UL},{1UL,4294967286UL,4294967286UL,1UL,4294967286UL}};
        uint32_t l_481 = 0x3779F667L;
        const uint64_t **l_507 = &l_407;
        const uint64_t ***l_506 = &l_507;
        int16_t l_558 = 0L;
        int i, j, k;
        if ((safe_mul_func_int16_t_s_s(1L, (((-1L) && l_294) || (safe_div_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u((((((*l_299)--) != (-1L)) ^ g_68) | ((((0x5AL || (safe_div_func_uint32_t_u_u(((((safe_div_func_int16_t_s_s(((*l_312) = ((0L >= ((safe_mod_func_uint8_t_u_u((p_51 != ((safe_add_func_uint32_t_u_u(((void*)0 != p_50), g_143[0])) == g_91)), l_311)) == 0xCEL)) == p_51)), 0x9706L)) >= l_313) , &g_63) != l_314[5][2]), l_311))) || p_51) || l_315[4][4][1]) == g_143[0])), g_257.f0)), 0x049D0830L))))))
        { /* block id: 116 */
            int32_t *l_316 = &g_264.f0;
            int32_t *l_317 = &l_276;
            int32_t *l_319 = &l_318;
            int32_t *l_320 = &g_192;
            int32_t *l_321 = &g_192;
            int32_t *l_322 = (void*)0;
            int32_t *l_323 = &g_91;
            int32_t *l_324 = (void*)0;
            int32_t *l_325 = &g_192;
            int32_t *l_326 = &g_192;
            int32_t l_328 = (-1L);
            int32_t *l_329[2];
            uint8_t ** const l_341 = (void*)0;
            uint8_t ** const *l_340 = &l_341;
            int8_t l_480[8] = {0xAFL,0xA6L,0xAFL,0xA6L,0xAFL,0xA6L,0xAFL,0xA6L};
            uint32_t *l_513 = &l_415[2][1];
            int i;
            for (i = 0; i < 2; i++)
                l_329[i] = &g_91;
            l_336++;
            for (l_311 = 0; (l_311 <= 0); l_311 += 1)
            { /* block id: 120 */
                uint64_t *l_339 = &l_313;
                int32_t l_357 = 0x070E812FL;
                uint16_t *l_369[3][7][8] = {{{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300}},{{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300}},{{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300},{&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300,&g_300}}};
                uint32_t l_393[9] = {0UL,0x4B885DE9L,0UL,0x4B885DE9L,0UL,0x4B885DE9L,0UL,0x4B885DE9L,0UL};
                int8_t *l_475 = &g_82;
                int32_t l_520 = 1L;
                int i, j, k;
            }
            for (g_230 = 0; (g_230 >= (-23)); g_230--)
            { /* block id: 216 */
                uint32_t *l_548[7] = {&l_336,&l_336,&l_336,&l_336,&l_336,&l_336,&l_336};
                int32_t l_555 = (-6L);
                int i;
                (*l_325) &= ((safe_mod_func_uint64_t_u_u(((((*g_98) , g_546) , p_51) < p_49), (~((((&l_336 == l_548[6]) , (safe_mod_func_uint16_t_u_u((((*g_249) , 1L) < (safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((p_51 == (-1L)), l_327)), l_555))), 1UL))) , l_555) < 0x0EL)))) || p_49);
                (*l_326) = 0x6AE2B4E3L;
            }
            (*l_319) = l_294;
        }
        else
        { /* block id: 221 */
            uint8_t *l_559[6][8][3] = {{{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419}},{{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419}},{{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0}},{{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419}},{{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419}},{{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0},{&g_419,&g_419,&g_419},{&g_419,&g_419,&g_419},{&g_419,&g_419,(void*)0}}};
            uint32_t l_560 = 18446744073709551613UL;
            int32_t l_572 = (-6L);
            uint64_t l_582 = 0xC8DA137436E587A1LL;
            uint8_t l_583 = 252UL;
            int32_t l_584[10] = {0xE2CDA35AL,8L,0xE2CDA35AL,8L,0xE2CDA35AL,8L,0xE2CDA35AL,8L,0xE2CDA35AL,8L};
            int i, j, k;
            if ((l_584[7] = (l_572 = (safe_mul_func_uint16_t_u_u((l_558 ^ (((l_560 &= ((*g_249) |= l_331)) > (safe_mul_func_uint16_t_u_u((((safe_mod_func_uint8_t_u_u(p_51, (l_567 = p_49))) < l_481) | ((safe_lshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_s((0xCF306CB9L >= ((*g_191) = 0x45587DE4L)), 4)), 3)) < l_572)), (((*l_299) = (safe_div_func_uint8_t_u_u((safe_add_func_int16_t_s_s((+(((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(g_519[6][1][2].f0, p_49)), l_582)) >= l_583) , (*p_50))), 65530UL)), l_572))) < 0x08B0L)))) && p_49)), g_389.f3)))))
            { /* block id: 229 */
                int16_t l_591 = 0xB30EL;
                const int32_t *l_606 = &l_572;
                for (l_311 = 0; (l_311 == 8); l_311++)
                { /* block id: 232 */
                    uint64_t l_602 = 0xF9695ADBCC2153A1LL;
                    if ((safe_lshift_func_int8_t_s_u((safe_mul_func_uint8_t_u_u(l_591, ((((safe_div_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_s((((!(((l_582 != (g_597 , ((safe_div_func_int16_t_s_s(((*g_259) != (*g_259)), (safe_mul_func_int16_t_s_s(((0x2BA7AB1A77ABCE0DLL ^ p_51) , p_51), p_51)))) || l_602))) < g_532) , l_334[1][0][2])) <= p_51) , 0xDCL), (*p_50))) < (*p_50)), p_51)) < g_230) & 255UL) <= (*g_249)))), 0)))
                    { /* block id: 233 */
                        const int32_t *l_604 = &g_605;
                        const int32_t **l_603 = &l_604;
                        if (p_49)
                            break;
                        l_606 = ((*l_603) = &l_334[1][0][2]);
                    }
                    else
                    { /* block id: 237 */
                        return p_51;
                    }
                    (*g_97) = (*l_606);
                }
                for (l_318 = 0; (l_318 > (-16)); --l_318)
                { /* block id: 244 */
                    for (g_82 = 0; (g_82 < 6); ++g_82)
                    { /* block id: 247 */
                        return (*g_249);
                    }
                }
            }
            else
            { /* block id: 251 */
                uint64_t *l_617 = &g_519[6][1][2].f2;
                uint64_t **l_616 = &l_617;
                int32_t l_626 = (-1L);
                (**g_190) = (safe_rshift_func_uint16_t_u_u(((+(0xC1L || (safe_div_func_int16_t_s_s((l_616 != (void*)0), p_51)))) > (((&l_584[6] != (void*)0) > ((((p_49 , ((safe_div_func_int16_t_s_s((safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((!((g_63 ^= (g_625 , (-1L))) && l_560)), g_370.f0)), (*p_50))), 65535UL)) > p_49)) || g_107.f0) , g_257) , g_107.f0)) == p_51)), l_626));
                return l_626;
            }
        }
    }
    for (g_370.f0 = 0; (g_370.f0 <= 9); g_370.f0 = safe_add_func_uint8_t_u_u(g_370.f0, 2))
    { /* block id: 260 */
        uint16_t l_638 = 1UL;
        uint8_t ** const *l_648 = (void*)0;
        uint32_t l_651[7] = {18446744073709551608UL,0xF6247D9AL,0xF6247D9AL,18446744073709551608UL,0x73A7BC2CL,0x73A7BC2CL,0xF6247D9AL};
        int i;
        for (g_300 = (-13); (g_300 > 19); g_300 = safe_add_func_uint64_t_u_u(g_300, 2))
        { /* block id: 263 */
            int16_t **l_631 = &l_314[5][2];
            int16_t *l_633 = &g_63;
            int16_t **l_632[6][5][6] = {{{&l_633,(void*)0,&l_633,&l_633,&l_633,&l_633},{&l_633,&l_633,(void*)0,&l_633,&l_633,&l_633},{&l_633,&l_633,&l_633,(void*)0,&l_633,&l_633},{(void*)0,&l_633,&l_633,(void*)0,&l_633,&l_633},{&l_633,(void*)0,&l_633,&l_633,&l_633,&l_633}},{{&l_633,&l_633,&l_633,&l_633,&l_633,(void*)0},{(void*)0,(void*)0,(void*)0,&l_633,&l_633,(void*)0},{(void*)0,&l_633,&l_633,&l_633,&l_633,&l_633},{(void*)0,&l_633,(void*)0,(void*)0,&l_633,&l_633},{(void*)0,&l_633,&l_633,&l_633,&l_633,&l_633}},{{&l_633,(void*)0,&l_633,&l_633,(void*)0,(void*)0},{(void*)0,&l_633,&l_633,(void*)0,(void*)0,&l_633},{(void*)0,&l_633,&l_633,&l_633,&l_633,&l_633},{(void*)0,(void*)0,(void*)0,&l_633,&l_633,&l_633},{(void*)0,&l_633,(void*)0,&l_633,&l_633,(void*)0}},{{&l_633,(void*)0,(void*)0,&l_633,(void*)0,&l_633},{&l_633,&l_633,(void*)0,(void*)0,&l_633,&l_633},{(void*)0,&l_633,&l_633,(void*)0,&l_633,&l_633},{&l_633,&l_633,&l_633,&l_633,&l_633,(void*)0},{&l_633,&l_633,&l_633,&l_633,(void*)0,&l_633}},{{&l_633,&l_633,&l_633,(void*)0,&l_633,&l_633},{(void*)0,&l_633,(void*)0,&l_633,&l_633,&l_633},{(void*)0,&l_633,&l_633,&l_633,&l_633,(void*)0},{&l_633,&l_633,(void*)0,&l_633,(void*)0,(void*)0},{(void*)0,(void*)0,&l_633,&l_633,&l_633,&l_633}},{{(void*)0,&l_633,&l_633,&l_633,&l_633,&l_633},{&l_633,(void*)0,&l_633,&l_633,&l_633,&l_633},{(void*)0,&l_633,&l_633,&l_633,(void*)0,&l_633},{(void*)0,&l_633,(void*)0,(void*)0,(void*)0,&l_633},{&l_633,(void*)0,&l_633,&l_633,&l_633,&l_633}}};
            int32_t l_635 = 0x3FB514DCL;
            uint64_t *l_644 = &g_143[0];
            int64_t *l_650[4][5] = {{&g_443,&g_443,&g_443,&g_443,&g_443},{&g_443,&g_443,&g_443,&g_443,&g_443},{&g_443,&g_443,&g_443,&g_443,&g_443},{&g_443,&g_443,&g_443,&g_443,&g_443}};
            int i, j, k;
            (*g_97) = (((((g_634 = ((*l_631) = &g_63)) != (void*)0) <= l_635) || 9L) , (g_636 , (*g_191)));
            l_651[6] = ((g_637[7] , (g_261 , (l_638 != (~((g_640 , l_638) <= (g_230 = ((safe_sub_func_uint64_t_u_u(l_643, ((*l_644)++))) , ((+l_294) >= (((l_648 == (g_483.f0 , l_649)) >= p_49) || l_388))))))))) >= 0L);
            return l_651[6];
        }
    }
    (**g_190) = (safe_sub_func_uint32_t_u_u(g_108.f0.f0, (l_276 = (((*p_50) &= (safe_sub_func_int32_t_s_s(p_49, (l_656 == ((*l_662) = g_659))))) == (((l_331 = (safe_unary_minus_func_uint8_t_u((safe_rshift_func_int16_t_s_s((*g_634), (g_27[1] >= l_388)))))) , (p_49 , (+(safe_sub_func_int8_t_s_s(l_388, 0x9FL))))) ^ l_333[3][1])))));
    return p_49;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_63 g_90 g_257 g_258 g_259 g_261 g_97 g_91 g_264 g_191 g_192 g_108.f1 g_190 g_270
 * writes: g_63 g_91 g_97 g_108.f1 g_192 g_271
 */
static int8_t * func_52(int16_t  p_53, int32_t  p_54, int8_t ** p_55, const int32_t  p_56, int8_t ** p_57)
{ /* block id: 91 */
    int32_t **l_254 = &g_97;
    const union U8 *l_255 = &g_256;
    int8_t *l_263 = &g_82;
    int8_t **l_262[6];
    uint64_t *l_269[6] = {&g_143[0],&g_143[0],&g_143[0],&g_143[0],&g_143[0],&g_143[0]};
    uint64_t **l_268 = &l_269[1];
    int i;
    for (i = 0; i < 6; i++)
        l_262[i] = &l_263;
    (*l_254) = func_75((**p_57));
    l_255 = l_255;
    if (((g_257 , g_258) , ((**l_254) &= (g_259 != (g_261 , l_262[0])))))
    { /* block id: 95 */
        uint32_t l_265 = 4294967289UL;
        (*l_254) = func_75((**p_57));
        l_265 |= ((g_264 , ((**l_254) = (*g_191))) | ((void*)0 != &g_97));
    }
    else
    { /* block id: 99 */
        for (g_108.f1 = 11; (g_108.f1 > 59); g_108.f1 = safe_add_func_int8_t_s_s(g_108.f1, 3))
        { /* block id: 102 */
            if (p_53)
                break;
        }
        (*g_97) = p_53;
        (**g_190) |= 0x591298C8L;
        (*g_270) = l_268;
    }
    return &g_82;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_248 g_107.f0
 * writes: g_63 g_248
 */
static int16_t  func_58(int32_t  p_59, int16_t  p_60, uint32_t  p_61)
{ /* block id: 4 */
    uint64_t l_66 = 0x2DF500C330E0E3CELL;
    int32_t l_69 = 0L;
    int32_t l_70[2];
    int32_t l_208 = (-1L);
    int8_t **l_234[1][4];
    int32_t l_236 = (-1L);
    uint8_t * volatile * volatile *l_250 = &g_248[2];
    int i, j;
    for (i = 0; i < 2; i++)
        l_70[i] = 0x2A6657A9L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
            l_234[i][j] = (void*)0;
    }
    g_63 = (g_27[1] == 8UL);
    for (p_61 = 0; (p_61 != 48); p_61 = safe_add_func_int8_t_s_s(p_61, 5))
    { /* block id: 8 */
        uint32_t *l_67[1][10] = {{&g_68,(void*)0,&g_68,&g_68,&g_68,&g_68,(void*)0,&g_68,&g_68,&g_68}};
        int32_t l_71 = 0L;
        int32_t l_72 = 9L;
        int32_t l_141[7][2] = {{4L,(-1L)},{(-1L),4L},{(-1L),(-1L)},{4L,(-1L)},{(-1L),4L},{(-1L),(-1L)},{4L,(-1L)}};
        int8_t l_142 = 0xDAL;
        int16_t l_202 = 4L;
        uint32_t l_231 = 0x8CF20DE4L;
        int8_t *l_233 = &g_82;
        int8_t * const *l_232 = &l_233;
        int32_t *l_235 = &l_69;
        int8_t l_244 = (-6L);
        uint64_t l_245 = 18446744073709551613UL;
        int i, j;
    }
    (*l_250) = g_248[1];
    return g_107.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_90
 * writes: g_63 g_91
 */
static int32_t * const  func_75(int8_t  p_76)
{ /* block id: 11 */
    int8_t *l_84[3];
    int32_t * const l_92 = &g_91;
    int i;
    for (i = 0; i < 3; i++)
        l_84[i] = &g_82;
    for (p_76 = 0; (p_76 > 20); p_76++)
    { /* block id: 14 */
        int8_t *l_81[1];
        int i;
        for (i = 0; i < 1; i++)
            l_81[i] = &g_82;
        for (g_63 = 10; (g_63 != 2); --g_63)
        { /* block id: 17 */
            int8_t **l_83 = &l_81[0];
            int8_t **l_85 = &l_84[2];
            int32_t l_89[7][6] = {{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L},{0xF5132FC9L,1L,1L,0xF5132FC9L,1L,1L}};
            int i, j;
            (*g_90) = (((((*l_83) = l_81[0]) != ((*l_85) = l_84[2])) & (safe_rshift_func_int8_t_s_s((~l_89[4][2]), 7))) && g_63);
        }
        return l_92;
    }
    return &g_91;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_107.f0, "g_107.f0", print_hash_value);
    transparent_crc(g_107.f3, "g_107.f3", print_hash_value);
    transparent_crc(g_107.f4.f0, "g_107.f4.f0", print_hash_value);
    transparent_crc(g_108.f0.f0, "g_108.f0.f0", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_143[i], "g_143[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_152[i][j][k].f0, "g_152[i][j][k].f0", print_hash_value);
                transparent_crc(g_152[i][j][k].f1, "g_152[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_192, "g_192", print_hash_value);
    transparent_crc(g_230, "g_230", print_hash_value);
    transparent_crc(g_257.f0, "g_257.f0", print_hash_value);
    transparent_crc(g_258.f0, "g_258.f0", print_hash_value);
    transparent_crc(g_261.f0, "g_261.f0", print_hash_value);
    transparent_crc(g_261.f1, "g_261.f1", print_hash_value);
    transparent_crc(g_264.f0, "g_264.f0", print_hash_value);
    transparent_crc(g_264.f1, "g_264.f1", print_hash_value);
    transparent_crc(g_300, "g_300", print_hash_value);
    transparent_crc(g_370.f0, "g_370.f0", print_hash_value);
    transparent_crc(g_370.f1, "g_370.f1", print_hash_value);
    transparent_crc(g_389.f0, "g_389.f0", print_hash_value);
    transparent_crc(g_389.f1, "g_389.f1", print_hash_value);
    transparent_crc(g_389.f2, "g_389.f2", print_hash_value);
    transparent_crc(g_389.f3, "g_389.f3", print_hash_value);
    transparent_crc(g_419, "g_419", print_hash_value);
    transparent_crc(g_443, "g_443", print_hash_value);
    transparent_crc(g_479.f0, "g_479.f0", print_hash_value);
    transparent_crc(g_479.f4, "g_479.f4", print_hash_value);
    transparent_crc(g_483.f0, "g_483.f0", print_hash_value);
    transparent_crc(g_483.f1, "g_483.f1", print_hash_value);
    transparent_crc(g_483.f2, "g_483.f2", print_hash_value);
    transparent_crc(g_495.f0, "g_495.f0", print_hash_value);
    transparent_crc(g_495.f1, "g_495.f1", print_hash_value);
    transparent_crc(g_495.f2, "g_495.f2", print_hash_value);
    transparent_crc(g_512.f0.f0, "g_512.f0.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_519[i][j][k].f0, "g_519[i][j][k].f0", print_hash_value);
                transparent_crc(g_519[i][j][k].f1, "g_519[i][j][k].f1", print_hash_value);
                transparent_crc(g_519[i][j][k].f2, "g_519[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_532, "g_532", print_hash_value);
    transparent_crc(g_539.f0, "g_539.f0", print_hash_value);
    transparent_crc(g_539.f4, "g_539.f4", print_hash_value);
    transparent_crc(g_546, "g_546", print_hash_value);
    transparent_crc(g_597.f0, "g_597.f0", print_hash_value);
    transparent_crc(g_597.f1, "g_597.f1", print_hash_value);
    transparent_crc(g_605, "g_605", print_hash_value);
    transparent_crc(g_625.f0, "g_625.f0", print_hash_value);
    transparent_crc(g_625.f4, "g_625.f4", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_637[i].f0, "g_637[i].f0", print_hash_value);
        transparent_crc(g_637[i].f3, "g_637[i].f3", print_hash_value);
        transparent_crc(g_637[i].f4.f0, "g_637[i].f4.f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_640.f0, "g_640.f0", print_hash_value);
    transparent_crc(g_640.f4, "g_640.f4", print_hash_value);
    transparent_crc(g_679.f0, "g_679.f0", print_hash_value);
    transparent_crc(g_679.f1, "g_679.f1", print_hash_value);
    transparent_crc(g_679.f2, "g_679.f2", print_hash_value);
    transparent_crc(g_679.f3, "g_679.f3", print_hash_value);
    transparent_crc(g_690, "g_690", print_hash_value);
    transparent_crc(g_700, "g_700", print_hash_value);
    transparent_crc(g_728, "g_728", print_hash_value);
    transparent_crc(g_732.f0, "g_732.f0", print_hash_value);
    transparent_crc(g_732.f1, "g_732.f1", print_hash_value);
    transparent_crc(g_732.f2, "g_732.f2", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_754[i].f0, "g_754[i].f0", print_hash_value);
        transparent_crc(g_754[i].f1, "g_754[i].f1", print_hash_value);
        transparent_crc(g_754[i].f2, "g_754[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_764.f0, "g_764.f0", print_hash_value);
    transparent_crc(g_764.f1, "g_764.f1", print_hash_value);
    transparent_crc(g_764.f2, "g_764.f2", print_hash_value);
    transparent_crc(g_764.f3, "g_764.f3", print_hash_value);
    transparent_crc(g_764.f4, "g_764.f4", print_hash_value);
    transparent_crc(g_764.f5, "g_764.f5", print_hash_value);
    transparent_crc(g_764.f6, "g_764.f6", print_hash_value);
    transparent_crc(g_777.f0.f0, "g_777.f0.f0", print_hash_value);
    transparent_crc(g_786.f0, "g_786.f0", print_hash_value);
    transparent_crc(g_786.f3, "g_786.f3", print_hash_value);
    transparent_crc(g_786.f4.f0, "g_786.f4.f0", print_hash_value);
    transparent_crc(g_788.f0, "g_788.f0", print_hash_value);
    transparent_crc(g_788.f1, "g_788.f1", print_hash_value);
    transparent_crc(g_788.f2, "g_788.f2", print_hash_value);
    transparent_crc(g_804.f0, "g_804.f0", print_hash_value);
    transparent_crc(g_804.f3, "g_804.f3", print_hash_value);
    transparent_crc(g_804.f4.f0, "g_804.f4.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_807[i][j].f0, "g_807[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_814.f0, "g_814.f0", print_hash_value);
    transparent_crc(g_814.f1, "g_814.f1", print_hash_value);
    transparent_crc(g_821.f0, "g_821.f0", print_hash_value);
    transparent_crc(g_821.f4, "g_821.f4", print_hash_value);
    transparent_crc(g_823.f0, "g_823.f0", print_hash_value);
    transparent_crc(g_823.f1, "g_823.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_891[i][j][k].f0, "g_891[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_975.f0, "g_975.f0", print_hash_value);
    transparent_crc(g_975.f1, "g_975.f1", print_hash_value);
    transparent_crc(g_975.f2, "g_975.f2", print_hash_value);
    transparent_crc(g_975.f3, "g_975.f3", print_hash_value);
    transparent_crc(g_975.f4, "g_975.f4", print_hash_value);
    transparent_crc(g_975.f5, "g_975.f5", print_hash_value);
    transparent_crc(g_975.f6, "g_975.f6", print_hash_value);
    transparent_crc(g_1010.f0, "g_1010.f0", print_hash_value);
    transparent_crc(g_1010.f4, "g_1010.f4", print_hash_value);
    transparent_crc(g_1033.f0, "g_1033.f0", print_hash_value);
    transparent_crc(g_1033.f1, "g_1033.f1", print_hash_value);
    transparent_crc(g_1033.f2, "g_1033.f2", print_hash_value);
    transparent_crc(g_1033.f3, "g_1033.f3", print_hash_value);
    transparent_crc(g_1033.f4, "g_1033.f4", print_hash_value);
    transparent_crc(g_1033.f5, "g_1033.f5", print_hash_value);
    transparent_crc(g_1033.f6, "g_1033.f6", print_hash_value);
    transparent_crc(g_1034.f0, "g_1034.f0", print_hash_value);
    transparent_crc(g_1034.f1, "g_1034.f1", print_hash_value);
    transparent_crc(g_1056, "g_1056", print_hash_value);
    transparent_crc(g_1061.f0, "g_1061.f0", print_hash_value);
    transparent_crc(g_1061.f1, "g_1061.f1", print_hash_value);
    transparent_crc(g_1161, "g_1161", print_hash_value);
    transparent_crc(g_1164, "g_1164", print_hash_value);
    transparent_crc(g_1186.f0, "g_1186.f0", print_hash_value);
    transparent_crc(g_1186.f1, "g_1186.f1", print_hash_value);
    transparent_crc(g_1186.f2, "g_1186.f2", print_hash_value);
    transparent_crc(g_1186.f3, "g_1186.f3", print_hash_value);
    transparent_crc(g_1194.f0, "g_1194.f0", print_hash_value);
    transparent_crc(g_1194.f1, "g_1194.f1", print_hash_value);
    transparent_crc(g_1224.f0.f0, "g_1224.f0.f0", print_hash_value);
    transparent_crc(g_1227.f0, "g_1227.f0", print_hash_value);
    transparent_crc(g_1269.f0, "g_1269.f0", print_hash_value);
    transparent_crc(g_1269.f1, "g_1269.f1", print_hash_value);
    transparent_crc(g_1269.f2, "g_1269.f2", print_hash_value);
    transparent_crc(g_1275.f0, "g_1275.f0", print_hash_value);
    transparent_crc(g_1275.f1, "g_1275.f1", print_hash_value);
    transparent_crc(g_1275.f2, "g_1275.f2", print_hash_value);
    transparent_crc(g_1275.f3, "g_1275.f3", print_hash_value);
    transparent_crc(g_1275.f4, "g_1275.f4", print_hash_value);
    transparent_crc(g_1275.f5, "g_1275.f5", print_hash_value);
    transparent_crc(g_1275.f6, "g_1275.f6", print_hash_value);
    transparent_crc(g_1289.f0, "g_1289.f0", print_hash_value);
    transparent_crc(g_1289.f1, "g_1289.f1", print_hash_value);
    transparent_crc(g_1289.f2, "g_1289.f2", print_hash_value);
    transparent_crc(g_1319.f0, "g_1319.f0", print_hash_value);
    transparent_crc(g_1319.f1, "g_1319.f1", print_hash_value);
    transparent_crc(g_1319.f2, "g_1319.f2", print_hash_value);
    transparent_crc(g_1319.f3, "g_1319.f3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1332[i].f0, "g_1332[i].f0", print_hash_value);
        transparent_crc(g_1332[i].f1, "g_1332[i].f1", print_hash_value);
        transparent_crc(g_1332[i].f2, "g_1332[i].f2", print_hash_value);
        transparent_crc(g_1332[i].f3, "g_1332[i].f3", print_hash_value);
        transparent_crc(g_1332[i].f4, "g_1332[i].f4", print_hash_value);
        transparent_crc(g_1332[i].f5, "g_1332[i].f5", print_hash_value);
        transparent_crc(g_1332[i].f6, "g_1332[i].f6", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1337.f0, "g_1337.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1396[i][j].f0, "g_1396[i][j].f0", print_hash_value);
            transparent_crc(g_1396[i][j].f4, "g_1396[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1413.f0, "g_1413.f0", print_hash_value);
    transparent_crc(g_1413.f1, "g_1413.f1", print_hash_value);
    transparent_crc(g_1428.f0, "g_1428.f0", print_hash_value);
    transparent_crc(g_1428.f1, "g_1428.f1", print_hash_value);
    transparent_crc(g_1428.f2, "g_1428.f2", print_hash_value);
    transparent_crc(g_1430.f0, "g_1430.f0", print_hash_value);
    transparent_crc(g_1430.f1, "g_1430.f1", print_hash_value);
    transparent_crc(g_1430.f2, "g_1430.f2", print_hash_value);
    transparent_crc(g_1430.f3, "g_1430.f3", print_hash_value);
    transparent_crc(g_1443.f0, "g_1443.f0", print_hash_value);
    transparent_crc(g_1443.f3, "g_1443.f3", print_hash_value);
    transparent_crc(g_1443.f4.f0, "g_1443.f4.f0", print_hash_value);
    transparent_crc(g_1453.f0, "g_1453.f0", print_hash_value);
    transparent_crc(g_1453.f1, "g_1453.f1", print_hash_value);
    transparent_crc(g_1453.f2, "g_1453.f2", print_hash_value);
    transparent_crc(g_1466.f0, "g_1466.f0", print_hash_value);
    transparent_crc(g_1466.f3, "g_1466.f3", print_hash_value);
    transparent_crc(g_1466.f4.f0, "g_1466.f4.f0", print_hash_value);
    transparent_crc(g_1503.f0, "g_1503.f0", print_hash_value);
    transparent_crc(g_1503.f1, "g_1503.f1", print_hash_value);
    transparent_crc(g_1503.f2, "g_1503.f2", print_hash_value);
    transparent_crc(g_1541.f0.f0, "g_1541.f0.f0", print_hash_value);
    transparent_crc(g_1556.f0, "g_1556.f0", print_hash_value);
    transparent_crc(g_1556.f4, "g_1556.f4", print_hash_value);
    transparent_crc(g_1567.f0.f0, "g_1567.f0.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1574[i].f0, "g_1574[i].f0", print_hash_value);
        transparent_crc(g_1574[i].f1, "g_1574[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1579.f0, "g_1579.f0", print_hash_value);
    transparent_crc(g_1579.f4, "g_1579.f4", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1588[i][j][k], "g_1588[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1590, "g_1590", print_hash_value);
    transparent_crc(g_1603, "g_1603", print_hash_value);
    transparent_crc(g_1640.f0, "g_1640.f0", print_hash_value);
    transparent_crc(g_1640.f1, "g_1640.f1", print_hash_value);
    transparent_crc(g_1640.f2, "g_1640.f2", print_hash_value);
    transparent_crc(g_1640.f3, "g_1640.f3", print_hash_value);
    transparent_crc(g_1686.f0, "g_1686.f0", print_hash_value);
    transparent_crc(g_1686.f4, "g_1686.f4", print_hash_value);
    transparent_crc(g_1709.f0, "g_1709.f0", print_hash_value);
    transparent_crc(g_1709.f1, "g_1709.f1", print_hash_value);
    transparent_crc(g_1709.f2, "g_1709.f2", print_hash_value);
    transparent_crc(g_1709.f3, "g_1709.f3", print_hash_value);
    transparent_crc(g_1709.f4, "g_1709.f4", print_hash_value);
    transparent_crc(g_1709.f5, "g_1709.f5", print_hash_value);
    transparent_crc(g_1709.f6, "g_1709.f6", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1718[i], "g_1718[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1721.f0, "g_1721.f0", print_hash_value);
    transparent_crc(g_1721.f4, "g_1721.f4", print_hash_value);
    transparent_crc(g_1765.f0, "g_1765.f0", print_hash_value);
    transparent_crc(g_1765.f4, "g_1765.f4", print_hash_value);
    transparent_crc(g_1769.f0, "g_1769.f0", print_hash_value);
    transparent_crc(g_1769.f4, "g_1769.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 435
   depth: 1, occurrence: 22
XXX total union variables: 41

XXX non-zero bitfields defined in structs: 8
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 4
XXX volatile bitfields defined in structs: 3
XXX structs with bitfields in the program: 72
breakdown:
   indirect level: 0, occurrence: 38
   indirect level: 1, occurrence: 16
   indirect level: 2, occurrence: 14
   indirect level: 3, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 25
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 53
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 18

XXX max expression depth: 49
breakdown:
   depth: 1, occurrence: 173
   depth: 2, occurrence: 59
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 12, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 3
   depth: 21, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 2
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 49, occurrence: 1

XXX total number of pointers: 451

XXX times a variable address is taken: 854
XXX times a pointer is dereferenced on RHS: 182
breakdown:
   depth: 1, occurrence: 132
   depth: 2, occurrence: 45
   depth: 3, occurrence: 5
XXX times a pointer is dereferenced on LHS: 251
breakdown:
   depth: 1, occurrence: 213
   depth: 2, occurrence: 36
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 30
XXX times a pointer is compared with address of another variable: 8
XXX times a pointer is compared with another pointer: 6
XXX times a pointer is qualified to be dereferenced: 6799

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1166
   level: 2, occurrence: 361
   level: 3, occurrence: 39
   level: 4, occurrence: 1
XXX number of pointers point to pointers: 206
XXX number of pointers point to scalars: 216
XXX number of pointers point to structs: 9
XXX percent of pointers has null in alias set: 29.9
XXX average alias set size: 1.34

XXX times a non-volatile is read: 1354
XXX times a non-volatile is write: 718
XXX times a volatile is read: 92
XXX    times read thru a pointer: 12
XXX times a volatile is write: 29
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 5.03e+03
XXX percentage of non-volatile access: 94.5

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 189
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 22
   depth: 2, occurrence: 25
   depth: 3, occurrence: 25
   depth: 4, occurrence: 37
   depth: 5, occurrence: 48

XXX percentage a fresh-made variable is used: 16.9
XXX percentage an existing variable is used: 83.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

