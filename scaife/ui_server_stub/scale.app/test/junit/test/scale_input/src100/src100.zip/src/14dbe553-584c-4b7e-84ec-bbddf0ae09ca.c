/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3659772504
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint32_t  f0;
   int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static int64_t g_37 = 0xBB4F5AC3D6C1DFE9LL;
static volatile union U0 g_40[1] = {{0UL}};
static int64_t g_100 = (-5L);
static int32_t g_101 = 0x40DD146FL;
static int16_t g_105 = (-1L);
static uint32_t g_109[10] = {0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL,0x0516A45AL};
static uint32_t g_113[7][4] = {{0xACDC9FF6L,0x420D6CD4L,1UL,9UL},{1UL,9UL,0xB9DA0115L,9UL},{4294967295UL,0x420D6CD4L,4294967286UL,1UL},{0x58EF108CL,4294967295UL,9UL,0x694BF019L},{4294967286UL,4294967295UL,0xEC2A3D91L,0xEC2A3D91L},{4294967286UL,4294967286UL,9UL,0xDBC33063L},{0x58EF108CL,0xEC2A3D91L,4294967286UL,4294967295UL}};
static int16_t g_115 = 0xAE81L;
static int8_t g_125 = 4L;
static volatile uint32_t g_133[1][9] = {{0xB86B6EF1L,6UL,0xB86B6EF1L,6UL,0xB86B6EF1L,6UL,0xB86B6EF1L,6UL,0xB86B6EF1L}};
static int32_t * volatile g_137 = &g_101;/* VOLATILE GLOBAL g_137 */
static uint8_t g_149 = 0UL;
static uint64_t g_162 = 0x83D76CE6111D5598LL;
static int32_t * volatile g_163 = &g_101;/* VOLATILE GLOBAL g_163 */
static union U0 g_166[5] = {{0x16B1FF0AL},{0x16B1FF0AL},{0x16B1FF0AL},{0x16B1FF0AL},{0x16B1FF0AL}};
static volatile union U0 *g_167 = &g_40[0];
static volatile uint8_t g_177 = 1UL;/* VOLATILE GLOBAL g_177 */
static volatile int32_t g_189 = 0xDF43112EL;/* VOLATILE GLOBAL g_189 */
static int8_t g_190 = 8L;
static volatile int8_t g_191 = 0x5FL;/* VOLATILE GLOBAL g_191 */
static volatile int32_t g_193 = 0xB9DDAD4CL;/* VOLATILE GLOBAL g_193 */
static volatile int8_t g_195[7][6] = {{(-5L),0xD7L,0xD7L,(-5L),9L,0xA0L},{0x2DL,0xD7L,9L,0x2DL,9L,0xD7L},{(-2L),0xD7L,0xA0L,(-2L),9L,9L},{(-5L),0xD7L,0xD7L,(-5L),9L,0xA0L},{0x2DL,0xD7L,9L,0x2DL,9L,0xD7L},{(-2L),0xD7L,0xA0L,(-2L),9L,9L},{(-5L),0xD7L,0xD7L,(-5L),9L,0xA0L}};
static uint8_t g_196 = 255UL;
static uint8_t g_199 = 0x1EL;
static volatile uint8_t g_251 = 0xFFL;/* VOLATILE GLOBAL g_251 */
static union U0 *g_259[1][2][4] = {{{&g_166[3],&g_166[0],&g_166[0],&g_166[3]},{&g_166[0],&g_166[3],&g_166[0],&g_166[0]}}};
static union U0 **g_258 = &g_259[0][1][0];
static int16_t *g_264 = &g_105;
static int32_t g_274 = 0x35A53A13L;
static volatile int8_t g_295 = 0x0DL;/* VOLATILE GLOBAL g_295 */
static uint8_t g_298[3][8][10] = {{{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL},{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL},{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL},{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL}},{{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL},{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,3UL,0UL,253UL,0UL,3UL,255UL},{0x9EL,252UL,0x9EL,255UL,0UL,0UL,2UL,0UL,0UL,255UL},{0x49L,252UL,0x49L,255UL,0x49L,246UL,0x92L,246UL,0x49L,0UL},{0UL,9UL,0UL,0UL,0x9EL,246UL,0x07L,246UL,0x9EL,0UL},{0x38L,9UL,0x38L,0UL,0x49L,246UL,0x92L,246UL,0x49L,0UL}},{{0UL,9UL,0UL,0UL,0x9EL,246UL,0x07L,246UL,0x9EL,0UL},{0x38L,9UL,0x38L,0UL,0x49L,246UL,0x92L,246UL,0x49L,0UL},{0UL,9UL,0UL,0UL,0x9EL,246UL,0x07L,246UL,0x9EL,0UL},{0x38L,9UL,0x38L,0UL,0x49L,246UL,0x92L,246UL,0x49L,0UL},{0UL,9UL,0UL,0UL,0x9EL,246UL,0x07L,246UL,0x9EL,0UL},{0x38L,9UL,0x38L,0UL,0x49L,246UL,0x92L,246UL,0x49L,0UL},{0UL,9UL,0UL,0UL,0x9EL,246UL,0x07L,246UL,0x9EL,0UL},{0x38L,9UL,0x38L,0UL,0x49L,246UL,0x92L,246UL,0x49L,0UL}}};
static uint16_t g_315[3][2] = {{0x384EL,0x384EL},{0x384EL,0x384EL},{0x384EL,0x384EL}};
static uint16_t *g_314 = &g_315[2][0];
static int32_t g_316 = 0x1BD17697L;
static int16_t g_318 = (-3L);
static uint8_t g_349[10] = {1UL,5UL,1UL,5UL,1UL,5UL,1UL,5UL,1UL,5UL};
static union U0 g_359[4] = {{0UL},{0UL},{0UL},{0UL}};
static uint64_t g_367 = 18446744073709551609UL;
static int32_t * volatile g_376 = &g_316;/* VOLATILE GLOBAL g_376 */
static const uint8_t g_387[4][8][2] = {{{0xC5L,0x0EL},{255UL,0xC5L},{0xAEL,0UL},{0xAEL,0xC5L},{255UL,0x0EL},{0xC5L,0xF3L},{0x0BL,0x38L},{0x0EL,0x14L}},{{0x14L,0x14L},{0x0EL,0x38L},{0x0BL,0xF3L},{0xC5L,0x0EL},{255UL,0xC5L},{0xAEL,0UL},{0xAEL,0xC5L},{255UL,0x0EL}},{{0xC5L,0xF3L},{0x0BL,0x38L},{0x0EL,0x14L},{0x14L,0x14L},{0x0EL,0x38L},{0x0BL,0xF3L},{0xC5L,0x0EL},{255UL,0xC5L}},{{0xAEL,0UL},{0xAEL,0xC5L},{255UL,0x0EL},{0xC5L,0xF3L},{0x0BL,0x38L},{0x0EL,0x14L},{0x14L,0x14L},{0x0EL,0x38L}}};
static int64_t g_394 = 0x9ED0CE8B5572DAFALL;
static volatile int32_t * volatile *g_461 = (void*)0;
static volatile int32_t * volatile ** const  volatile g_460 = &g_461;/* VOLATILE GLOBAL g_460 */
static int32_t *g_464 = &g_101;
static int32_t **g_463 = &g_464;
static int32_t ***g_462[3] = {&g_463,&g_463,&g_463};
static volatile union U0 g_528 = {0x8F74F565L};/* VOLATILE GLOBAL g_528 */
static volatile union U0 g_551 = {0xCF8096CDL};/* VOLATILE GLOBAL g_551 */
static uint16_t g_592 = 0UL;
static uint32_t g_648[2][2][10] = {{{4294967286UL,4294967289UL,4294967295UL,0xD831EC18L,0xD831EC18L,4294967295UL,4294967289UL,4294967286UL,4294967289UL,4294967295UL},{5UL,0xCFC5964FL,0xD831EC18L,0xCFC5964FL,5UL,4294967295UL,4294967295UL,5UL,0xCFC5964FL,0xD831EC18L}},{{4294967286UL,4294967286UL,0xD831EC18L,5UL,0UL,5UL,0xD831EC18L,4294967286UL,4294967286UL,0xD831EC18L},{0xCFC5964FL,5UL,4294967295UL,4294967295UL,5UL,0xCFC5964FL,0xD831EC18L,0xCFC5964FL,5UL,4294967295UL}}};
static const int32_t g_718 = 0x24192F10L;
static union U0 g_747 = {4294967295UL};/* VOLATILE GLOBAL g_747 */
static volatile int16_t g_755 = 0x217CL;/* VOLATILE GLOBAL g_755 */
static int16_t * const *g_767 = &g_264;
static int16_t * const **g_766 = &g_767;
static volatile uint64_t * const  volatile *g_797 = (void*)0;
static const uint8_t *g_811 = (void*)0;
static const uint8_t **g_810 = &g_811;
static const uint8_t *** volatile g_809 = &g_810;/* VOLATILE GLOBAL g_809 */
static union U0 g_826 = {1UL};/* VOLATILE GLOBAL g_826 */
static union U0 ** volatile g_882[2][9][10] = {{{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0]}},{{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{(void*)0,&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],(void*)0,&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][3],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][0][0]},{&g_259[0][0][1],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][3],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][0][0]},{&g_259[0][1][3],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][3],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][1][0]},{&g_259[0][0][1],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][0][0],&g_259[0][1][1],&g_259[0][0][0],&g_259[0][1][0],&g_259[0][1][0],&g_259[0][0][0]}}};
static int8_t *g_910 = &g_166[3].f1;
static const volatile union U0 g_964 = {0x42DDF9E0L};/* VOLATILE GLOBAL g_964 */
static uint16_t g_998[8][9][3] = {{{65531UL,1UL,0UL},{0UL,6UL,0UL},{65529UL,0x1521L,0xCA10L},{1UL,65534UL,65535UL},{0x924BL,0x0FF2L,0x0FF2L},{65530UL,65535UL,65526UL},{0x1B11L,0x4856L,0x924BL},{0xFE89L,1UL,0x45B0L},{65535UL,0xFB61L,0x1521L}},{{0x0A09L,1UL,0UL},{65531UL,0x4856L,0xC235L},{0x3491L,65535UL,0UL},{0xFB61L,0x0FF2L,0xC217L},{0xB912L,65534UL,65530UL},{0UL,0x1521L,0xA48FL},{65530UL,6UL,0xC1CEL},{0x31CCL,1UL,0x924BL},{1UL,0x826EL,0xC1CEL}},{{0xB822L,0xFB61L,0xA48FL},{0xFA36L,9UL,65530UL},{65531UL,0xE2F2L,0xC217L},{0UL,65527UL,0UL},{0UL,0UL,0xC235L},{0x8E38L,65534UL,0UL},{0x1680L,65531UL,0x1521L},{65530UL,1UL,0x45B0L},{0x1680L,8UL,0x924BL}},{{0x8E38L,65531UL,65526UL},{0UL,0xFB61L,0x0FF2L},{0UL,0x904CL,65535UL},{65531UL,0xE335L,0xCA10L},{0xFA36L,0xF71DL,0UL},{0xB822L,0xA48FL,0UL},{1UL,65534UL,0UL},{0x31CCL,0xA48FL,0UL},{65530UL,0xF71DL,65528UL}},{{0UL,0xE335L,0x924BL},{0xB912L,0x904CL,65530UL},{0xFB61L,0xFB61L,65531UL},{0x3491L,65531UL,0x707DL},{65531UL,8UL,65535UL},{0x0A09L,1UL,0UL},{65535UL,65531UL,65535UL},{0xFE89L,65534UL,0x707DL},{0x1B11L,0UL,65531UL}},{{65530UL,65527UL,65530UL},{0x924BL,0xE2F2L,0x924BL},{1UL,9UL,65528UL},{65529UL,0xFB61L,0UL},{0UL,0x826EL,0UL},{65531UL,1UL,0UL},{0UL,6UL,0UL},{65529UL,0x1521L,0xCA10L},{0UL,0x826EL,0UL}},{{0UL,0x924BL,0x924BL},{0x0A09L,0x9DFCL,0UL},{65535UL,65529UL,0UL},{0UL,0x8D55L,1UL},{0xA48FL,65531UL,0x1B11L},{65526UL,0x8D55L,0x3491L},{0x31CCL,65529UL,1UL},{65528UL,0x9DFCL,0x45B0L},{65531UL,0x924BL,0xE2F2L}},{{65530UL,0x826EL,0x0A09L},{0xC235L,0x1B11L,0x1680L},{0x0A09L,0x705FL,0x2A93L},{0xCA10L,65535UL,0UL},{0x707DL,0x4C19L,0x2A93L},{0x1521L,65531UL,0x1680L},{0xC1CEL,0UL,0x0A09L},{0x31CCL,0xFB61L,0xE2F2L},{0x45B0L,65534UL,0x45B0L}}};
static union U0 g_1088 = {0xF1E69BC9L};/* VOLATILE GLOBAL g_1088 */
static volatile uint8_t g_1168 = 0x82L;/* VOLATILE GLOBAL g_1168 */
static volatile uint64_t g_1199 = 0x3706120B278E20F4LL;/* VOLATILE GLOBAL g_1199 */
static const int8_t * const g_1218 = &g_747.f1;
static const int8_t * const *g_1217 = &g_1218;
static const int8_t * const ** const  volatile g_1216 = &g_1217;/* VOLATILE GLOBAL g_1216 */
static int16_t g_1270 = 0x51D5L;
static int8_t **g_1282 = &g_910;
static int8_t ***g_1281[6] = {&g_1282,&g_1282,&g_1282,&g_1282,&g_1282,&g_1282};
static volatile union U0 * volatile * volatile ** volatile g_1316 = (void*)0;/* VOLATILE GLOBAL g_1316 */
static uint64_t * const  volatile **g_1318[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static uint64_t * const  volatile ** volatile *g_1317 = &g_1318[1];
static const volatile union U0 g_1339 = {0x1881973DL};/* VOLATILE GLOBAL g_1339 */
static volatile union U0 g_1355 = {1UL};/* VOLATILE GLOBAL g_1355 */
static int16_t g_1375 = 1L;
static volatile union U0 g_1389[7][2][5] = {{{{0x5DAB74DFL},{0x6BFF9DF6L},{4294967295UL},{7UL},{4UL}},{{0UL},{0xF44B6C4CL},{4294967293UL},{9UL},{4294967293UL}}},{{{4UL},{0x6BFF9DF6L},{0UL},{0x6BFF9DF6L},{4UL}},{{4294967293UL},{9UL},{4294967293UL},{0xF44B6C4CL},{0UL}}},{{{4UL},{7UL},{4294967295UL},{0x6BFF9DF6L},{0x5DAB74DFL}},{{0UL},{9UL},{0xAAEA7952L},{9UL},{0UL}}},{{{0x5DAB74DFL},{0x6BFF9DF6L},{4294967295UL},{7UL},{4UL}},{{0UL},{0xF44B6C4CL},{4294967293UL},{9UL},{4294967293UL}}},{{{4UL},{0x6BFF9DF6L},{0UL},{0x6BFF9DF6L},{4UL}},{{4294967293UL},{9UL},{4294967293UL},{0xF44B6C4CL},{0UL}}},{{{4UL},{7UL},{4294967295UL},{0x6BFF9DF6L},{0x5DAB74DFL}},{{0UL},{9UL},{0xAAEA7952L},{9UL},{0UL}}},{{{0x5DAB74DFL},{0x6BFF9DF6L},{4294967295UL},{7UL},{4UL}},{{0UL},{0xF44B6C4CL},{4294967293UL},{9UL},{4294967293UL}}}};
static uint8_t *g_1411 = &g_199;
static uint8_t **g_1410 = &g_1411;
static uint8_t ** const *g_1409 = &g_1410;
static int16_t **g_1461 = &g_264;
static int16_t ***g_1460 = &g_1461;
static int16_t ***g_1463 = &g_1461;
static volatile union U0 g_1464 = {0UL};/* VOLATILE GLOBAL g_1464 */
static volatile union U0 g_1520 = {0UL};/* VOLATILE GLOBAL g_1520 */
static const int16_t g_1525 = 0L;
static int8_t g_1532 = 0x8EL;
static int32_t * volatile g_1534 = &g_101;/* VOLATILE GLOBAL g_1534 */
static uint64_t ***g_1635 = (void*)0;
static uint64_t *g_1645 = &g_162;
static uint64_t **g_1644 = &g_1645;
static uint64_t ***g_1643 = &g_1644;
static uint64_t ****g_1642 = &g_1643;
static uint32_t g_1810 = 0UL;
static volatile int32_t g_1845 = 0xA3886F63L;/* VOLATILE GLOBAL g_1845 */
static const uint64_t g_1893 = 18446744073709551608UL;
static union U0 * volatile *g_1925 = &g_259[0][0][0];
static union U0 * volatile ** volatile g_1924 = &g_1925;/* VOLATILE GLOBAL g_1924 */
static union U0 * volatile ** volatile *g_1923 = &g_1924;
static union U0 * volatile ** volatile * volatile *g_1922[8] = {&g_1923,&g_1923,&g_1923,&g_1923,&g_1923,&g_1923,&g_1923,&g_1923};
static union U0 g_2032 = {0xF315CE69L};/* VOLATILE GLOBAL g_2032 */
static union U0 g_2044 = {4294967291UL};/* VOLATILE GLOBAL g_2044 */
static volatile union U0 g_2045[10] = {{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL}};
static int16_t g_2046 = (-1L);
static int32_t g_2048 = 0L;
static int32_t * volatile g_2047[9][3][3] = {{{(void*)0,&g_101,&g_101},{&g_101,&g_2048,&g_2048},{&g_101,(void*)0,&g_101}},{{&g_101,&g_2048,(void*)0},{&g_2048,&g_2048,&g_101},{&g_2048,&g_2048,&g_2048}},{{&g_101,(void*)0,&g_101},{&g_101,&g_2048,(void*)0},{&g_101,&g_101,&g_101}},{{(void*)0,&g_101,&g_101},{(void*)0,(void*)0,(void*)0},{&g_101,&g_2048,&g_101}},{{&g_101,&g_2048,&g_2048},{(void*)0,&g_2048,(void*)0},{&g_101,&g_101,&g_101}},{{(void*)0,&g_2048,(void*)0},{&g_101,&g_101,&g_101},{&g_2048,&g_2048,&g_2048}},{{&g_2048,(void*)0,&g_2048},{&g_101,(void*)0,&g_2048},{&g_2048,&g_2048,(void*)0}},{{(void*)0,&g_101,&g_101},{&g_2048,&g_2048,&g_2048},{&g_2048,&g_101,(void*)0}},{{&g_101,&g_2048,&g_2048},{(void*)0,&g_2048,&g_101},{&g_2048,&g_101,(void*)0}}};
static uint64_t g_2146 = 0x68EC0AE9714A0256LL;
static int32_t ** volatile g_2152 = (void*)0;/* VOLATILE GLOBAL g_2152 */
static int32_t ** volatile g_2153 = (void*)0;/* VOLATILE GLOBAL g_2153 */
static int32_t ** volatile g_2154 = (void*)0;/* VOLATILE GLOBAL g_2154 */
static int32_t *g_2156[2] = {&g_101,&g_101};
static int32_t ** volatile g_2155 = &g_2156[0];/* VOLATILE GLOBAL g_2155 */
static int32_t * volatile g_2159[2] = {&g_2048,&g_2048};
static volatile int32_t g_2183 = 0x78150149L;/* VOLATILE GLOBAL g_2183 */
static int32_t * volatile g_2184[6][1][7] = {{{&g_2048,&g_316,(void*)0,&g_101,&g_101,&g_2048,&g_101}},{{(void*)0,&g_2048,&g_2048,(void*)0,(void*)0,&g_101,&g_2048}},{{&g_2048,&g_101,(void*)0,(void*)0,&g_2048,&g_2048,(void*)0}},{{&g_101,&g_2048,&g_101,&g_101,(void*)0,&g_316,&g_2048}},{{&g_2048,(void*)0,&g_101,(void*)0,&g_101,(void*)0,&g_101}},{{(void*)0,(void*)0,(void*)0,&g_2048,&g_2048,&g_316,&g_2048}}};
static union U0 g_2198 = {0UL};/* VOLATILE GLOBAL g_2198 */
static union U0 g_2199 = {1UL};/* VOLATILE GLOBAL g_2199 */
static const union U0 g_2205 = {0xD3A61860L};/* VOLATILE GLOBAL g_2205 */
static const union U0 *g_2204 = &g_2205;
static const union U0 **g_2203 = &g_2204;
static int16_t g_2238 = 0L;
static int32_t ** volatile g_2244 = &g_2156[0];/* VOLATILE GLOBAL g_2244 */
static volatile uint64_t g_2260 = 0UL;/* VOLATILE GLOBAL g_2260 */
static union U0 g_2263[1][4] = {{{4294967287UL},{4294967287UL},{4294967287UL},{4294967287UL}}};
static union U0 g_2268 = {0x40422233L};/* VOLATILE GLOBAL g_2268 */
static union U0 g_2311 = {4294967290UL};/* VOLATILE GLOBAL g_2311 */
static union U0 g_2312 = {4294967291UL};/* VOLATILE GLOBAL g_2312 */
static int64_t g_2326[10][4][6] = {{{0xD56C0C754D642FCALL,0xA78E7382C6C0A4DBLL,0xC2733499AA9D4D81LL,0x96ADE0BD541151AALL,0x83B221092AB5C4E9LL,(-1L)},{0xFB049284DA9F0EFELL,2L,1L,(-1L),0x9639D0DBD0D2E66ALL,0x6EDBC130D5CC4E38LL},{0x9639D0DBD0D2E66ALL,0xC443C5AED8269C45LL,0xD94E078AECB3775BLL,0xC443C5AED8269C45LL,0x9639D0DBD0D2E66ALL,0x05F36B146F0B4F4BLL},{0x0E9A27FEAB5239C9LL,2L,0x66A49BE085A8B14ALL,(-1L),0x83B221092AB5C4E9LL,(-1L)}},{{1L,0xA78E7382C6C0A4DBLL,1L,2L,0xC2733499AA9D4D81LL,(-1L)},{7L,(-1L),0x66A49BE085A8B14ALL,0L,1L,0x05F36B146F0B4F4BLL},{0xC2733499AA9D4D81LL,0x6EDBC130D5CC4E38LL,0xD94E078AECB3775BLL,(-1L),0xD94E078AECB3775BLL,0x6EDBC130D5CC4E38LL},{0xC2733499AA9D4D81LL,0x05F36B146F0B4F4BLL,1L,0L,0x66A49BE085A8B14ALL,(-1L)}},{{7L,(-1L),0xC2733499AA9D4D81LL,2L,1L,0xA78E7382C6C0A4DBLL},{1L,(-1L),0x83B221092AB5C4E9LL,(-1L),0x66A49BE085A8B14ALL,2L},{0x0E9A27FEAB5239C9LL,0x05F36B146F0B4F4BLL,0x9639D0DBD0D2E66ALL,0xC443C5AED8269C45LL,0xD94E078AECB3775BLL,0xC443C5AED8269C45LL},{0x9639D0DBD0D2E66ALL,0x6EDBC130D5CC4E38LL,0x9639D0DBD0D2E66ALL,(-1L),1L,2L}},{{0xFB049284DA9F0EFELL,(-1L),0x83B221092AB5C4E9LL,0x96ADE0BD541151AALL,0xC2733499AA9D4D81LL,0xA78E7382C6C0A4DBLL},{0xD56C0C754D642FCALL,0xA78E7382C6C0A4DBLL,0xC2733499AA9D4D81LL,0x96ADE0BD541151AALL,0x83B221092AB5C4E9LL,(-1L)},{0xFB049284DA9F0EFELL,2L,1L,(-1L),0x9639D0DBD0D2E66ALL,0x6EDBC130D5CC4E38LL},{0x9639D0DBD0D2E66ALL,0xC443C5AED8269C45LL,0xD94E078AECB3775BLL,0xC443C5AED8269C45LL,0x9639D0DBD0D2E66ALL,0L}},{{7L,0xA78E7382C6C0A4DBLL,0xD94E078AECB3775BLL,(-1L),0x0E9A27FEAB5239C9LL,0xC443C5AED8269C45LL},{0x83B221092AB5C4E9LL,0x96ADE0BD541151AALL,0xC2733499AA9D4D81LL,0xA78E7382C6C0A4DBLL,0xD56C0C754D642FCALL,0xC443C5AED8269C45LL},{(-5L),0x05F36B146F0B4F4BLL,0xD94E078AECB3775BLL,2L,0x83B221092AB5C4E9LL,0L},{0xD56C0C754D642FCALL,(-1L),0xFB049284DA9F0EFELL,0xC443C5AED8269C45LL,0xFB049284DA9F0EFELL,(-1L)}},{{0xD56C0C754D642FCALL,0L,0x83B221092AB5C4E9LL,2L,0xD94E078AECB3775BLL,0x05F36B146F0B4F4BLL},{(-5L),0xC443C5AED8269C45LL,0xD56C0C754D642FCALL,0xA78E7382C6C0A4DBLL,0xC2733499AA9D4D81LL,0x96ADE0BD541151AALL},{0x83B221092AB5C4E9LL,0xC443C5AED8269C45LL,0x0E9A27FEAB5239C9LL,(-1L),0xD94E078AECB3775BLL,0xA78E7382C6C0A4DBLL},{7L,0L,1L,0x6EDBC130D5CC4E38LL,0xFB049284DA9F0EFELL,0x6EDBC130D5CC4E38LL}},{{1L,(-1L),1L,0x05F36B146F0B4F4BLL,0x83B221092AB5C4E9LL,0xA78E7382C6C0A4DBLL},{0x9639D0DBD0D2E66ALL,0x05F36B146F0B4F4BLL,0x0E9A27FEAB5239C9LL,(-1L),0xD56C0C754D642FCALL,0x96ADE0BD541151AALL},{1L,0x96ADE0BD541151AALL,0xD56C0C754D642FCALL,(-1L),0x0E9A27FEAB5239C9LL,0x05F36B146F0B4F4BLL},{0x9639D0DBD0D2E66ALL,0xA78E7382C6C0A4DBLL,0x83B221092AB5C4E9LL,0x05F36B146F0B4F4BLL,1L,(-1L)}},{{1L,0x6EDBC130D5CC4E38LL,0xFB049284DA9F0EFELL,0x6EDBC130D5CC4E38LL,1L,0L},{7L,0xA78E7382C6C0A4DBLL,0xD94E078AECB3775BLL,(-1L),0x0E9A27FEAB5239C9LL,0xC443C5AED8269C45LL},{0x83B221092AB5C4E9LL,0x96ADE0BD541151AALL,0xC2733499AA9D4D81LL,0xA78E7382C6C0A4DBLL,0xD56C0C754D642FCALL,0xC443C5AED8269C45LL},{(-5L),0x05F36B146F0B4F4BLL,0xD94E078AECB3775BLL,2L,0x83B221092AB5C4E9LL,0L}},{{0xD56C0C754D642FCALL,(-1L),0xFB049284DA9F0EFELL,0xC443C5AED8269C45LL,0xFB049284DA9F0EFELL,(-1L)},{0xD56C0C754D642FCALL,0L,0x83B221092AB5C4E9LL,2L,0xD94E078AECB3775BLL,0x05F36B146F0B4F4BLL},{(-5L),0xC443C5AED8269C45LL,0xD56C0C754D642FCALL,0xA78E7382C6C0A4DBLL,0xC2733499AA9D4D81LL,0x96ADE0BD541151AALL},{0x83B221092AB5C4E9LL,0xC443C5AED8269C45LL,0x0E9A27FEAB5239C9LL,(-1L),0xD94E078AECB3775BLL,0xA78E7382C6C0A4DBLL}},{{7L,0L,1L,0x6EDBC130D5CC4E38LL,0xFB049284DA9F0EFELL,0x6EDBC130D5CC4E38LL},{1L,(-1L),1L,0x05F36B146F0B4F4BLL,0x83B221092AB5C4E9LL,0xA78E7382C6C0A4DBLL},{0x9639D0DBD0D2E66ALL,0x05F36B146F0B4F4BLL,0x0E9A27FEAB5239C9LL,(-1L),0xD56C0C754D642FCALL,0x96ADE0BD541151AALL},{1L,0x96ADE0BD541151AALL,0xD56C0C754D642FCALL,(-1L),0x0E9A27FEAB5239C9LL,0x05F36B146F0B4F4BLL}}};
static union U0 g_2328 = {0UL};/* VOLATILE GLOBAL g_2328 */
static volatile uint8_t g_2350 = 5UL;/* VOLATILE GLOBAL g_2350 */
static volatile int64_t g_2405 = 0x291FE801B891AE40LL;/* VOLATILE GLOBAL g_2405 */
static volatile int64_t * volatile g_2404[8][6][5] = {{{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,(void*)0,&g_2405},{(void*)0,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405}},{{(void*)0,(void*)0,(void*)0,&g_2405,(void*)0},{&g_2405,(void*)0,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,(void*)0,&g_2405,&g_2405},{&g_2405,&g_2405,(void*)0,(void*)0,&g_2405}},{{(void*)0,(void*)0,(void*)0,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,(void*)0,&g_2405,&g_2405}},{{&g_2405,&g_2405,&g_2405,&g_2405,(void*)0},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,(void*)0,&g_2405},{&g_2405,(void*)0,&g_2405,&g_2405,&g_2405},{(void*)0,&g_2405,(void*)0,(void*)0,&g_2405},{&g_2405,(void*)0,(void*)0,&g_2405,&g_2405}},{{(void*)0,(void*)0,&g_2405,&g_2405,&g_2405},{&g_2405,(void*)0,&g_2405,(void*)0,&g_2405},{&g_2405,&g_2405,(void*)0,&g_2405,&g_2405},{(void*)0,&g_2405,(void*)0,(void*)0,&g_2405},{&g_2405,(void*)0,&g_2405,&g_2405,&g_2405},{(void*)0,(void*)0,(void*)0,&g_2405,&g_2405}},{{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,(void*)0,&g_2405,(void*)0},{&g_2405,(void*)0,(void*)0,&g_2405,&g_2405},{(void*)0,&g_2405,&g_2405,&g_2405,(void*)0},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,(void*)0,&g_2405,&g_2405}},{{&g_2405,&g_2405,(void*)0,(void*)0,&g_2405},{&g_2405,(void*)0,&g_2405,&g_2405,(void*)0},{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,&g_2405,(void*)0},{&g_2405,(void*)0,&g_2405,&g_2405,(void*)0},{&g_2405,(void*)0,(void*)0,&g_2405,&g_2405}},{{&g_2405,&g_2405,&g_2405,&g_2405,&g_2405},{&g_2405,&g_2405,&g_2405,(void*)0,&g_2405},{&g_2405,(void*)0,&g_2405,&g_2405,&g_2405},{&g_2405,(void*)0,&g_2405,(void*)0,&g_2405},{&g_2405,(void*)0,(void*)0,&g_2405,&g_2405},{(void*)0,&g_2405,&g_2405,(void*)0,(void*)0}}};
static volatile int64_t * volatile * volatile g_2403[7][6][6] = {{{&g_2404[0][0][1],&g_2404[7][2][3],(void*)0,&g_2404[2][4][3],&g_2404[0][0][1],(void*)0},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],(void*)0},{&g_2404[0][0][1],(void*)0,&g_2404[6][3][3],&g_2404[0][0][1],&g_2404[4][4][3],&g_2404[0][0][1]},{&g_2404[0][0][1],(void*)0,&g_2404[0][0][0],(void*)0,(void*)0,&g_2404[0][0][1]},{(void*)0,&g_2404[0][0][1],&g_2404[6][3][3],&g_2404[0][0][1],&g_2404[5][1][0],(void*)0},{(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],(void*)0}},{{&g_2404[0][0][1],(void*)0,(void*)0,&g_2404[6][3][3],&g_2404[0][0][1],&g_2404[0][0][1]},{&g_2404[0][0][1],(void*)0,(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1]},{&g_2404[0][0][1],(void*)0,&g_2404[5][3][0],&g_2404[0][0][1],(void*)0,&g_2404[0][0][1]},{(void*)0,&g_2404[0][0][1],&g_2404[6][3][3],&g_2404[5][3][2],(void*)0,(void*)0},{(void*)0,(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1]},{(void*)0,(void*)0,&g_2404[5][3][2],&g_2404[5][1][0],&g_2404[0][0][1],(void*)0}},{{&g_2404[0][0][0],(void*)0,&g_2404[5][1][0],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1]},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[6][3][3],&g_2404[5][1][0],&g_2404[5][3][0]},{(void*)0,&g_2404[0][0][1],(void*)0,&g_2404[2][4][3],(void*)0,&g_2404[0][0][1]},{(void*)0,(void*)0,&g_2404[0][0][1],&g_2404[2][4][3],&g_2404[4][4][3],&g_2404[6][3][3]},{(void*)0,(void*)0,&g_2404[5][3][2],&g_2404[6][3][3],&g_2404[0][0][1],(void*)0},{&g_2404[0][0][1],&g_2404[0][0][1],(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1]}},{{&g_2404[0][0][0],&g_2404[7][2][3],&g_2404[0][0][1],&g_2404[5][1][0],&g_2404[5][1][0],&g_2404[0][0][1]},{(void*)0,(void*)0,&g_2404[5][1][0],&g_2404[0][0][1],&g_2404[7][2][4],&g_2404[0][0][1]},{(void*)0,&g_2404[0][0][1],(void*)0,&g_2404[5][3][2],&g_2404[4][5][0],&g_2404[5][1][0]},{(void*)0,(void*)0,(void*)0,&g_2404[0][0][1],(void*)0,&g_2404[0][0][1]},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[5][1][0],&g_2404[0][0][1],&g_2404[4][4][3],&g_2404[0][0][1]},{&g_2404[0][0][1],&g_2404[4][4][3],&g_2404[0][0][1],&g_2404[6][3][3],(void*)0,&g_2404[0][0][1]}},{{&g_2404[0][0][1],(void*)0,(void*)0,&g_2404[0][0][1],(void*)0,(void*)0},{(void*)0,&g_2404[7][2][3],&g_2404[5][3][2],&g_2404[0][0][1],&g_2404[4][5][0],&g_2404[6][3][3]},{(void*)0,(void*)0,&g_2404[0][0][1],(void*)0,(void*)0,&g_2404[0][0][1]},{&g_2404[0][0][1],(void*)0,(void*)0,&g_2404[0][0][1],&g_2404[4][5][0],&g_2404[5][3][0]},{&g_2404[0][0][1],&g_2404[7][2][3],&g_2404[0][0][1],&g_2404[0][0][1],(void*)0,&g_2404[0][0][1]},{&g_2404[0][0][1],(void*)0,&g_2404[5][1][0],&g_2404[2][4][3],(void*)0,(void*)0}},{{&g_2404[0][0][1],&g_2404[4][4][3],&g_2404[5][3][2],&g_2404[5][3][2],&g_2404[4][4][3],&g_2404[0][0][1]},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[7][2][4],(void*)0},{&g_2404[5][3][1],&g_2404[0][0][1],&g_2404[5][3][0],&g_2404[0][0][1],(void*)0,&g_2404[0][0][1]},{&g_2404[5][3][1],(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[5][3][2]},{(void*)0,&g_2404[7][2][4],&g_2404[0][0][1],&g_2404[4][5][0],&g_2404[0][0][0],(void*)0},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[4][4][3],&g_2404[7][2][3],(void*)0,&g_2404[0][0][1]}},{{&g_2404[6][3][3],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[6][3][3],&g_2404[5][1][0]},{(void*)0,&g_2404[0][0][1],&g_2404[5][3][0],&g_2404[0][0][1],(void*)0,(void*)0},{&g_2404[0][0][1],&g_2404[0][0][1],&g_2404[5][3][1],&g_2404[0][0][1],(void*)0,(void*)0},{&g_2404[7][2][4],(void*)0,&g_2404[5][3][0],&g_2404[0][0][1],&g_2404[0][0][0],&g_2404[5][1][0]},{(void*)0,(void*)0,&g_2404[0][0][1],&g_2404[0][0][1],(void*)0,&g_2404[0][0][1]},{(void*)0,(void*)0,&g_2404[4][4][3],&g_2404[5][3][0],(void*)0,(void*)0}}};
static const volatile int16_t g_2457 = 0x4A84L;/* VOLATILE GLOBAL g_2457 */
static int32_t ** volatile g_2458 = &g_2156[1];/* VOLATILE GLOBAL g_2458 */
static union U0 g_2459[4] = {{0UL},{0UL},{0UL},{0UL}};
static union U0 g_2499 = {0UL};/* VOLATILE GLOBAL g_2499 */
static const union U0 g_2555 = {0x13ECDB3CL};/* VOLATILE GLOBAL g_2555 */
static union U0 g_2595 = {4294967295UL};/* VOLATILE GLOBAL g_2595 */
static int16_t g_2644 = 0x54DEL;
static uint32_t g_2650 = 1UL;
static int64_t g_2672 = 7L;
static int32_t ** volatile g_2705 = &g_2156[0];/* VOLATILE GLOBAL g_2705 */
static union U0 g_2745 = {2UL};/* VOLATILE GLOBAL g_2745 */
static int32_t * volatile g_2804 = &g_2048;/* VOLATILE GLOBAL g_2804 */
static int16_t *g_2819 = &g_2238;
static volatile int16_t ** volatile * volatile * volatile g_2859 = (void*)0;/* VOLATILE GLOBAL g_2859 */
static volatile int16_t ** volatile * volatile * volatile * volatile g_2858 = &g_2859;/* VOLATILE GLOBAL g_2858 */
static volatile int64_t **g_2864 = (void*)0;
static int16_t g_2870 = 6L;
static uint64_t g_2901 = 0xE3896D444F27946BLL;
static int64_t g_2915 = 0x7E7B14034F093FAELL;
static volatile union U0 g_2927 = {0x899C4286L};/* VOLATILE GLOBAL g_2927 */
static volatile union U0 g_2979[9] = {{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L},{0xD564BFA9L}};
static volatile union U0 g_3001 = {0x38360E40L};/* VOLATILE GLOBAL g_3001 */
static union U0 g_3005 = {1UL};/* VOLATILE GLOBAL g_3005 */
static int32_t g_3035[4] = {(-1L),(-1L),(-1L),(-1L)};
static int8_t ****g_3057 = (void*)0;
static int16_t g_3082 = 0x1028L;
static volatile union U0 g_3152 = {0xFB069899L};/* VOLATILE GLOBAL g_3152 */
static volatile union U0 g_3173 = {0xFD10147BL};/* VOLATILE GLOBAL g_3173 */
static volatile int8_t g_3184 = 0xCAL;/* VOLATILE GLOBAL g_3184 */
static volatile union U0 g_3209 = {4294967286UL};/* VOLATILE GLOBAL g_3209 */
static uint32_t *g_3215 = &g_109[7];
static uint32_t **g_3214 = &g_3215;
static volatile uint64_t g_3279 = 0UL;/* VOLATILE GLOBAL g_3279 */
static uint32_t g_3287 = 18446744073709551615UL;
static volatile union U0 g_3290 = {0x546A93E7L};/* VOLATILE GLOBAL g_3290 */
static union U0 ***g_3295 = &g_258;
static int8_t *** volatile g_3409 = (void*)0;/* VOLATILE GLOBAL g_3409 */
static int8_t *** volatile g_3410 = &g_1282;/* VOLATILE GLOBAL g_3410 */
static int64_t *g_3434[1][7][5] = {{{&g_394,&g_2915,&g_2915,&g_394,&g_37},{(void*)0,&g_394,(void*)0,&g_2326[8][0][0],&g_2326[8][0][0]},{&g_2672,&g_394,&g_2672,&g_37,&g_394},{&g_2326[8][0][0],&g_2915,&g_37,&g_2326[8][0][0],&g_37},{&g_2326[8][0][0],&g_2326[8][0][0],(void*)0,&g_394,(void*)0},{&g_2672,(void*)0,&g_37,&g_37,(void*)0},{(void*)0,&g_2915,&g_2672,(void*)0,&g_37}}};
static int64_t **g_3433[6] = {&g_3434[0][1][0],&g_3434[0][1][0],&g_3434[0][3][3],&g_3434[0][1][0],&g_3434[0][1][0],&g_3434[0][3][3]};
static int64_t ***g_3432 = &g_3433[4];
static union U0 g_3438[1][3] = {{{0xF1417AB8L},{0xF1417AB8L},{0xF1417AB8L}}};
static union U0 g_3520 = {4294967286UL};/* VOLATILE GLOBAL g_3520 */
static uint32_t g_3546 = 4294967289UL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint16_t  func_2(const uint32_t  p_3, uint32_t  p_4);
static union U0  func_14(uint64_t  p_15, uint64_t  p_16);
static const uint32_t  func_25(int16_t  p_26, int32_t  p_27, uint32_t  p_28);
static uint16_t  func_31(uint16_t  p_32, int8_t  p_33, const int64_t  p_34, const int32_t  p_35, int32_t  p_36);
static uint64_t  func_44(uint32_t  p_45);
static uint8_t  func_56(uint32_t  p_57, uint16_t  p_58, int32_t  p_59, uint64_t  p_60);
static uint32_t  func_61(const uint32_t  p_62, int32_t  p_63);
static uint16_t  func_68(int32_t  p_69, int8_t  p_70, uint64_t  p_71);
static uint32_t  func_72(int32_t  p_73, const int8_t  p_74, int8_t  p_75, uint32_t  p_76);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_37 g_40 g_314 g_315 g_349 g_464 g_101 g_149 g_367 g_105 g_1923 g_1924 g_1925 g_316 g_196 g_2032 g_551.f1 g_2044 g_2045 g_109 g_1463 g_1461 g_264 g_166 g_910 g_166.f1 g_1644 g_1645 g_162 g_767 g_2046 g_376 g_394 g_1460 g_463 g_2146 g_1409 g_1410 g_1411 g_199 g_2032.f1 g_1534 g_2155 g_648 g_2183 g_826.f1 g_115 g_2044.f1 g_113 g_163 g_1088.f1 g_2048 g_1643 g_1282 g_826 g_766 g_298 g_2238 g_2244 g_274 g_195 g_2260 g_2263 g_2268 g_2205.f1 g_2311 g_2312 g_1339.f0 g_2328 g_2350 g_1218 g_747.f1 g_2326 g_2403 g_137 g_2328.f1 g_1464.f1 g_259 g_2457 g_2458 g_2459 g_167 g_100 g_2499 g_1217 g_318 g_2047 g_2204 g_2205 g_191 g_2595 g_2268.f0 g_592 g_2644 g_2263.f0 g_2705 g_2198.f1 g_2268.f1 g_1270 g_3546
 * writes: g_315 g_367 g_105 g_101 g_316 g_196 g_2046 g_149 g_162 g_274 g_464 g_259 g_1642 g_394 g_592 g_2156 g_648 g_1088.f1 g_2048 g_2203 g_115 g_298 g_199 g_2260 g_318 g_37 g_2326 g_2350 g_2328.f1 g_1645 g_755 g_1464.f1 g_998 g_2044.f0 g_2044.f1 g_109 g_1810 g_2312.f1 g_2198.f1 g_2184 g_166.f1 g_2644 g_2650 g_2268.f1 g_1270 g_2328.f0 g_2183 g_1925
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    const uint64_t l_5 = 0UL;
    const int32_t l_1612 = 0L;
    int8_t *l_2188 = &g_1088.f1;
    uint8_t l_2742 = 0xD2L;
    int32_t l_3547[2];
    int i;
    for (i = 0; i < 2; i++)
        l_3547[i] = 1L;
    l_3547[0] = ((((func_2(l_5, (safe_lshift_func_int16_t_s_s((safe_rshift_func_int16_t_s_s((safe_div_func_int8_t_s_s((safe_div_func_int16_t_s_s((func_14((safe_sub_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(((*l_2188) |= (safe_sub_func_int32_t_s_s((((safe_div_func_uint32_t_u_u(func_25((0xDD78L & (safe_rshift_func_uint16_t_u_s(func_31(((*g_314) = (g_37 > (((safe_add_func_int16_t_s_s(l_5, ((0xF4DFL > (g_40[0] , (!(safe_add_func_uint64_t_u_u(l_5, (func_44(l_5) < l_5)))))) == (*g_314)))) == g_349[5]) < l_5))), l_5, l_1612, (*g_464), g_149), 3))), l_5, g_2044.f1), g_113[0][0])) , g_826.f1) , (*g_163)), l_1612))), 0xADL)), l_1612)), l_1612) , 0x6143L), l_5)), 0xC9L)), l_1612)), l_2742))) , (*g_2204)) , 0xA7674D6FF08F5AF7LL) , l_2742) , g_3546);
    for (g_367 = 0; (g_367 != 12); ++g_367)
    { /* block id: 1667 */
        uint16_t l_3550 = 0UL;
        if (l_3550)
            break;
    }
    return l_3547[0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_2(const uint32_t  p_3, uint32_t  p_4)
{ /* block id: 1303 */
    const uint64_t l_2746 = 0x0656C47F5EBC7075LL;
    int32_t l_2749[6] = {3L,3L,1L,3L,3L,1L};
    uint32_t l_2756[4];
    int16_t *l_2818 = &g_2644;
    uint8_t l_2852 = 252UL;
    int32_t ***l_2888 = &g_463;
    const int8_t *l_3012 = &g_2198.f1;
    const int8_t **l_3011 = &l_3012;
    const int8_t ***l_3010 = &l_3011;
    const int8_t ****l_3009 = &l_3010;
    uint64_t ***l_3069[10] = {&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644};
    int16_t l_3171 = 0x8750L;
    uint8_t l_3204 = 0xA2L;
    const int16_t ****l_3270 = (void*)0;
    uint8_t **l_3299 = (void*)0;
    int32_t l_3337 = 0xB5B4DA56L;
    uint8_t l_3377 = 0UL;
    uint8_t l_3412 = 0x6AL;
    int64_t *l_3431[9] = {&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0],&g_2326[8][2][0]};
    int64_t **l_3430 = &l_3431[1];
    int64_t *** const l_3429[3][9][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_3430,&l_3430,&l_3430,&l_3430,&l_3430},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
    uint8_t ***l_3456 = &l_3299;
    uint8_t ****l_3455 = &l_3456;
    union U0 ****l_3479[5] = {&g_3295,&g_3295,&g_3295,&g_3295,&g_3295};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_2756[i] = 0x04638593L;
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_2048 g_1643 g_1644 g_1645 g_162 g_1282 g_910 g_166.f1 g_826 g_264 g_105 g_1411 g_199 g_766 g_767 g_367 g_115 g_298 g_1410 g_2238 g_648 g_314 g_315 g_2244 g_463 g_274 g_195 g_2260 g_2263 g_2268 g_1461 g_2205.f1 g_376 g_316 g_2311 g_2312 g_1339.f0 g_37 g_1923 g_2328 g_2350 g_1218 g_747.f1 g_1463 g_1924 g_1925 g_2326 g_2403 g_1460 g_1534 g_101 g_137 g_2328.f1 g_1464.f1 g_259 g_1409 g_2457 g_2458 g_2459 g_167 g_40 g_100 g_2499 g_2044.f1 g_1217 g_318 g_149 g_2047 g_2204 g_2205 g_191 g_394 g_2595 g_2268.f0 g_2046 g_592 g_2644 g_2263.f0 g_2705 g_2198.f1 g_2268.f1 g_1270 g_1088.f1
 * writes: g_2048 g_2203 g_115 g_298 g_199 g_315 g_2156 g_464 g_274 g_2260 g_318 g_37 g_2326 g_2350 g_2328.f1 g_259 g_1645 g_394 g_105 g_101 g_316 g_755 g_1464.f1 g_998 g_2044.f0 g_648 g_1088.f1 g_2044.f1 g_149 g_109 g_1810 g_2312.f1 g_2198.f1 g_2184 g_196 g_166.f1 g_162 g_2644 g_2650 g_2268.f1 g_1270 g_2328.f0 g_2183 g_1925
 */
static union U0  func_14(uint64_t  p_15, uint64_t  p_16)
{ /* block id: 1002 */
    int16_t l_2192[6] = {1L,1L,0x5D46L,1L,1L,0x5D46L};
    const union U0 *l_2201 = &g_826;
    const union U0 **l_2200[5][5][2] = {{{&l_2201,&l_2201},{&l_2201,&l_2201},{&l_2201,(void*)0},{&l_2201,&l_2201},{&l_2201,&l_2201}},{{&l_2201,&l_2201},{(void*)0,&l_2201},{&l_2201,&l_2201},{&l_2201,&l_2201},{&l_2201,(void*)0}},{{&l_2201,&l_2201},{&l_2201,&l_2201},{&l_2201,&l_2201},{(void*)0,&l_2201},{&l_2201,&l_2201}},{{&l_2201,&l_2201},{&l_2201,(void*)0},{&l_2201,&l_2201},{&l_2201,&l_2201},{&l_2201,&l_2201}},{{(void*)0,&l_2201},{&l_2201,&l_2201},{&l_2201,&l_2201},{&l_2201,(void*)0},{&l_2201,&l_2201}}};
    int32_t l_2242[10][8][3] = {{{0xB6D6E77EL,(-1L),0x620CEAD8L},{2L,0L,0x25B7CC70L},{0xFD635786L,0x9FC46A62L,0xF0C45E9BL},{(-1L),0x4C897B4FL,(-3L)},{(-5L),(-1L),0L},{(-5L),1L,0xFD635786L},{(-1L),0xADDF3CDBL,0x9F66274CL},{0xFD635786L,0x4F14847BL,(-1L)}},{{2L,0xCCC80AA7L,(-5L)},{0xB6D6E77EL,0x4C897B4FL,0x9F66274CL},{0xF0C45E9BL,0x8F030F79L,2L},{0xB6D6E77EL,5L,(-7L)},{(-7L),0xF0C45E9BL,(-1L)},{1L,0xF45203A9L,9L},{0xE2F6F5F9L,0x41A9C47EL,0L},{0xA12B70BDL,0xB6D6E77EL,0x48DEE870L}},{{0xA12B70BDL,2L,9L},{0xE2F6F5F9L,0x1F8CFEE4L,0xE2F6F5F9L},{1L,0xFD635786L,(-5L)},{(-7L),0x25B7CC70L,0x8ED9F2EDL},{0L,0x41A9C47EL,0xE2F6F5F9L},{(-4L),0x2AD97937L,(-2L)},{0L,(-10L),0x8A167226L},{(-7L),0xFB71B891L,0L}},{{1L,0x2AD97937L,0xFE639175L},{0xE2F6F5F9L,0x79F888D3L,0xBFDE95A6L},{0xA12B70BDL,(-3L),(-7L)},{0xA12B70BDL,0xFD635786L,(-2L)},{0xE2F6F5F9L,0xA3EEC5F1L,1L},{1L,0x90676B53L,0xA12B70BDL},{(-7L),0xB6D6E77EL,(-5L)},{0L,0x79F888D3L,1L}},{{(-4L),0L,1L},{0L,0xF0C45E9BL,0x48DEE870L},{(-7L),(-10L),0xBFDE95A6L},{1L,0L,(-4L)},{0xE2F6F5F9L,0xE3AF3587L,(-1L)},{0xA12B70BDL,0x25B7CC70L,0x8A167226L},{0xA12B70BDL,0x90676B53L,1L},{0xE2F6F5F9L,0x78CC6E09L,0xEC932497L}},{{1L,2L,0x8ED9F2EDL},{(-7L),(-3L),0xA12B70BDL},{0L,0xE3AF3587L,0xEC932497L},{(-4L),0xF45203A9L,9L},{0L,0xFB71B891L,(-7L)},{(-7L),0xF0C45E9BL,(-1L)},{1L,0xF45203A9L,9L},{0xE2F6F5F9L,0x41A9C47EL,0L}},{{0xA12B70BDL,0xB6D6E77EL,0x48DEE870L},{0xA12B70BDL,2L,9L},{0xE2F6F5F9L,0x1F8CFEE4L,0xE2F6F5F9L},{1L,0xFD635786L,(-5L)},{(-7L),0x25B7CC70L,0x8ED9F2EDL},{0L,0x41A9C47EL,0xE2F6F5F9L},{(-4L),0x2AD97937L,(-2L)},{0L,(-10L),0x8A167226L}},{{(-7L),0xFB71B891L,0L},{1L,0x2AD97937L,0xFE639175L},{0xE2F6F5F9L,0x79F888D3L,0xBFDE95A6L},{0xA12B70BDL,(-3L),(-7L)},{0xA12B70BDL,0xFD635786L,(-2L)},{0xE2F6F5F9L,0xA3EEC5F1L,1L},{1L,0x90676B53L,0xA12B70BDL},{(-7L),0xB6D6E77EL,(-5L)}},{{0L,0x79F888D3L,1L},{(-4L),0L,1L},{0L,0xF0C45E9BL,0x48DEE870L},{(-7L),(-10L),0xBFDE95A6L},{1L,0L,(-4L)},{0xE2F6F5F9L,0xE3AF3587L,(-1L)},{0xA12B70BDL,0x25B7CC70L,0x8A167226L},{0xA12B70BDL,0x90676B53L,1L}},{{0xE2F6F5F9L,0x78CC6E09L,0xEC932497L},{1L,2L,0x8ED9F2EDL},{(-7L),(-3L),0xA12B70BDL},{0x11430839L,5L,(-1L)},{1L,(-2L),0x9C238541L},{0x11430839L,0xFE639175L,4L},{4L,(-4L),0x01990186L},{(-9L),(-2L),0x58EBF8ECL}}};
    int32_t *l_2255[6][4] = {{&l_2242[2][0][0],&g_101,&l_2242[2][0][0],&g_2048},{&g_2048,&g_101,&g_101,&l_2242[5][4][1]},{&g_101,&g_101,&g_101,&g_101},{&l_2242[2][0][0],&l_2242[5][4][1],&g_101,&g_2048},{&g_101,&g_2048,&g_101,&g_2048},{&g_2048,&g_101,&l_2242[2][0][0],&g_2048}};
    uint64_t l_2265 = 0xB1492F79E331C18BLL;
    int32_t l_2344 = 0x626CBF19L;
    union U0 *l_2359 = &g_2311;
    int64_t *l_2407 = &g_394;
    int64_t **l_2406 = &l_2407;
    uint8_t l_2426[1][8] = {{0xDEL,0x76L,0xDEL,0x76L,0xDEL,0x76L,0xDEL,0x76L}};
    int8_t l_2487 = 0x27L;
    uint64_t l_2498 = 0xD94EA0B25DE4F999LL;
    int32_t l_2510 = (-1L);
    union U0 ***l_2526 = (void*)0;
    union U0 ****l_2525 = &l_2526;
    uint8_t l_2534 = 3UL;
    int32_t l_2544 = (-3L);
    uint64_t * const *l_2583 = &g_1645;
    int8_t l_2638 = 0x2DL;
    uint64_t l_2707 = 18446744073709551614UL;
    uint8_t ***l_2711[7][8][4] = {{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}},{{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410},{&g_1410,&g_1410,&g_1410,&g_1410}}};
    uint8_t ****l_2710 = &l_2711[3][1][2];
    int32_t ****l_2714 = &g_462[0];
    int i, j, k;
    for (g_2048 = 0; (g_2048 >= 0); g_2048 -= 1)
    { /* block id: 1005 */
        union U0 * const l_2197[4] = {&g_2199,&g_2199,&g_2199,&g_2199};
        union U0 * const *l_2196[4][1];
        union U0 * const **l_2195 = &l_2196[0][0];
        const union U0 ***l_2202[2];
        uint64_t l_2207[9][6] = {{0x46388D17825FA2FCLL,18446744073709551614UL,7UL,0x7BB50BB1179EF6EALL,1UL,18446744073709551615UL},{1UL,0x5D781F8E388CD3BCLL,0xFA76005BF03BE979LL,0x5D781F8E388CD3BCLL,1UL,6UL},{18446744073709551615UL,18446744073709551614UL,0x9B20146E06334729LL,18446744073709551615UL,0x5D781F8E388CD3BCLL,7UL},{7UL,1UL,18446744073709551614UL,18446744073709551614UL,1UL,7UL},{18446744073709551615UL,0x7BB50BB1179EF6EALL,0x9B20146E06334729LL,1UL,7UL,6UL},{1UL,18446744073709551615UL,0xFA76005BF03BE979LL,7UL,0xFA76005BF03BE979LL,18446744073709551615UL},{1UL,6UL,7UL,1UL,0x9B20146E06334729LL,0x7BB50BB1179EF6EALL},{18446744073709551615UL,7UL,1UL,18446744073709551614UL,18446744073709551614UL,1UL},{7UL,7UL,0x5D781F8E388CD3BCLL,18446744073709551615UL,0x9B20146E06334729LL,18446744073709551614UL}};
        int32_t * const l_2243[4][4][3] = {{{&g_2048,(void*)0,&g_316},{(void*)0,&g_316,&g_316},{&g_2048,&l_2242[3][2][0],&g_316},{&l_2242[6][2][0],&g_101,&g_101}},{{(void*)0,&g_316,&g_101},{&l_2242[5][4][1],(void*)0,&g_316},{&g_2048,&l_2242[5][4][1],&g_316},{&g_316,&g_316,&g_316}},{{&g_2048,&l_2242[5][4][1],&g_316},{(void*)0,(void*)0,&l_2242[6][2][0]},{&g_316,&g_316,&l_2242[5][4][1]},{&g_316,&g_101,&g_2048}},{{(void*)0,&l_2242[3][2][0],&g_316},{&g_2048,&g_316,(void*)0},{&g_316,(void*)0,&g_316},{&g_2048,&l_2242[5][4][1],&g_2048}}};
        uint8_t l_2252 = 0x90L;
        int16_t l_2349[6][8] = {{4L,0xCF57L,0x9B93L,1L,(-7L),(-10L),0x43E9L,(-1L)},{0xCF57L,0xCF57L,0x41AAL,2L,0x43E9L,1L,0xCF57L,0x43E9L},{0xAA05L,0x43E9L,6L,0xAA05L,(-7L),0xAA05L,6L,0x43E9L},{0x43E9L,0x5CE4L,(-1L),2L,0x5CE4L,6L,(-7L),(-1L)},{0x9B93L,(-7L),(-1L),0x43E9L,0x43E9L,(-1L),(-7L),0x9B93L},{(-10L),0x43E9L,(-1L),6L,0xCF57L,(-10L),6L,2L}};
        int32_t l_2477 = 0x4E35D1DCL;
        int8_t **l_2513[2];
        int16_t ****l_2569 = &g_1463;
        uint16_t l_2571 = 0x53AAL;
        uint64_t **l_2584[2][9] = {{&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645},{&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645}};
        uint8_t l_2586[10] = {0xF1L,254UL,254UL,0xF1L,0xCDL,0xF1L,254UL,254UL,0xF1L,0xCDL};
        uint8_t l_2677 = 0x91L;
        const uint16_t l_2698[7] = {1UL,0x4C97L,1UL,1UL,0x4C97L,1UL,1UL};
        uint64_t l_2702 = 9UL;
        int i, j, k;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 1; j++)
                l_2196[i][j] = &l_2197[3];
        }
        for (i = 0; i < 2; i++)
            l_2202[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_2513[i] = (void*)0;
        if ((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint64_t_u(l_2192[5])), ((***g_1643) | (safe_rshift_func_uint16_t_u_s(((((*l_2195) = &g_259[0][1][0]) == (g_2203 = l_2200[4][3][0])) || p_15), (l_2192[5] , (&l_2201 != (void*)0))))))))
        { /* block id: 1008 */
            int16_t l_2206 = 5L;
            int32_t l_2248 = 0xA0804737L;
            int32_t l_2249 = 0L;
            int32_t l_2251 = (-7L);
            int32_t l_2259 = (-9L);
            uint64_t ***l_2315 = (void*)0;
            int16_t l_2323 = 0x5D5BL;
            int32_t l_2330 = 0L;
            int32_t l_2335 = 7L;
            int32_t l_2336 = (-5L);
            int32_t l_2337 = (-1L);
            int32_t l_2339 = 0x8B767EB7L;
            int32_t l_2342 = 0x2EC53A72L;
            int32_t l_2343[10] = {3L,3L,3L,3L,3L,3L,3L,3L,3L,3L};
            union U0 *l_2360 = (void*)0;
            const union U0 *****l_2416 = (void*)0;
            int16_t l_2417[2][9] = {{(-7L),(-7L),0L,0x186DL,0L,(-7L),(-7L),0L,0x186DL},{0xD27BL,(-1L),0xD27BL,0L,0L,0xD27BL,(-1L),0xD27BL,0L}};
            uint32_t l_2450[6][1];
            int i, j;
            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 1; j++)
                    l_2450[i][j] = 0xD75EB5E2L;
            }
            if (l_2206)
            { /* block id: 1009 */
                uint16_t l_2232 = 65535UL;
                int32_t l_2258[10] = {(-10L),6L,6L,(-10L),(-8L),(-10L),6L,6L,(-10L),(-8L)};
                uint8_t l_2301 = 0xF1L;
                int i;
                if (l_2207[2][2])
                { /* block id: 1010 */
                    int16_t *l_2233 = &g_115;
                    uint8_t *l_2234 = (void*)0;
                    uint8_t *l_2235 = (void*)0;
                    uint8_t *l_2236 = (void*)0;
                    uint8_t *l_2237 = &g_298[2][4][5];
                    int32_t l_2245 = 0xDDBE6D32L;
                    int32_t l_2246 = 1L;
                    int32_t l_2247[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2247[i] = 1L;
                    if ((((((**g_1410) = ((*l_2237) ^= (((0xFBB4CDDCCF3742C0LL > ((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s((**g_1282), 4)), (safe_mul_func_int16_t_s_s(((*l_2233) |= (+(((safe_sub_func_uint8_t_u_u(p_15, 253UL)) != ((safe_rshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s(((*l_2201) , l_2206), ((safe_rshift_func_int8_t_s_u(((p_15 > (safe_mul_func_int16_t_s_s((((((0x0203L || (+(safe_rshift_func_int8_t_s_s((((safe_mul_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u(3UL, 3)) ^ (*g_264)), l_2232)) ^ 0x9F83FA7B1138347ELL) >= l_2232), 3)))) , (*g_1411)) , l_2232) , p_16) , p_15), (***g_766)))) != g_367), p_15)) & p_15))), 9)) >= 0xEFE7B18EL)) && p_16))), (**g_767))))) & 0x61B5B55CL)) , l_2232) & 0x65D24B41L))) & 0x19L) & g_2238) & g_648[0][1][4]))
                    { /* block id: 1014 */
                        l_2242[5][4][1] ^= (!(++(*g_314)));
                        (*g_2244) = l_2243[3][3][0];
                    }
                    else
                    { /* block id: 1018 */
                        int32_t l_2250 = 5L;
                        l_2252--;
                        l_2255[1][1] = &l_2248;
                        (*g_463) = &l_2249;
                    }
                    for (g_274 = 0; (g_274 <= 0); g_274 += 1)
                    { /* block id: 1025 */
                        int32_t l_2256 = 0x80814B8FL;
                        int32_t l_2257[4];
                        int i, j;
                        for (i = 0; i < 4; i++)
                            l_2257[i] = 8L;
                        if (g_195[(g_274 + 4)][(g_2048 + 3)])
                            break;
                        --g_2260;
                    }
                    if (p_15)
                        continue;
                    if (p_16)
                        continue;
                }
                else
                { /* block id: 1031 */
                    int32_t *l_2264[8][1] = {{&g_274},{&g_274},{&g_274},{&g_274},{&g_274},{&g_274},{&g_274},{&g_274}};
                    int i, j;
                    for (g_318 = 0; (g_318 >= 0); g_318 -= 1)
                    { /* block id: 1034 */
                        return g_2263[0][0];
                    }
                    l_2259 = p_15;
                    l_2255[4][3] = ((l_2258[4] &= p_15) , &l_2258[7]);
                }
                if (p_16)
                { /* block id: 1041 */
                    ++l_2265;
                    for (p_15 = 1; (p_15 <= 9); p_15 += 1)
                    { /* block id: 1045 */
                        return g_2268;
                    }
                }
                else
                { /* block id: 1048 */
                    int32_t l_2275 = (-2L);
                    int32_t l_2296 = 0x1BC387D2L;
                    int32_t l_2298 = (-1L);
                    uint64_t l_2310 = 0x23920C041A955DC2LL;
                    for (l_2249 = 5; (l_2249 >= 0); l_2249 -= 1)
                    { /* block id: 1051 */
                        int64_t *l_2297 = &g_37;
                        int32_t l_2309[7][3][10] = {{{0x88E17929L,4L,1L,0xD1C99333L,0x1E1686B4L,(-1L),1L,0x95325233L,(-6L),(-1L)},{6L,4L,(-10L),0L,0xE094BE11L,1L,1L,0x6A30DCA2L,0x45001CB2L,0x511FF117L},{0xECF5D119L,0x1E1686B4L,0xBC684671L,0x8F62F7CBL,(-8L),0xD65BC54DL,0L,4L,(-1L),1L}},{{0x511FF117L,(-10L),0xDADCA18AL,0x80DFBF98L,(-5L),0xCB0A0F08L,0xA7468774L,(-8L),(-10L),0x88E17929L},{0x21474B09L,0xD1C99333L,(-4L),(-1L),(-10L),(-6L),(-5L),0L,0xCB0A0F08L,0x8F62F7CBL},{0xC11C388CL,0x7A405C94L,(-1L),7L,9L,0x95325233L,0x20479D71L,6L,0xBC684671L,(-5L)}},{{(-7L),(-1L),0x28DE7200L,(-3L),9L,9L,(-3L),(-6L),0L,1L},{7L,(-1L),0x21474B09L,0xC784BEE3L,6L,0x88E17929L,1L,7L,(-5L),1L},{1L,0x8F62F7CBL,0L,(-1L),6L,1L,0x1E1686B4L,0x7A405C94L,0x48ED956EL,1L}},{{6L,1L,0x9E0FE807L,0xE094BE11L,1L,0x0663F4A4L,0xD65BC54DL,(-1L),1L,0L},{0x95325233L,0x9E0FE807L,(-3L),9L,0L,4L,0xECF5D119L,0x511FF117L,0x5A24C56DL,0xA7468774L},{(-1L),9L,6L,2L,0xD65BC54DL,0x7A405C94L,(-3L),0x80DFBF98L,0xA7468774L,(-5L)}},{{(-1L),(-1L),0x88E17929L,0x7A405C94L,0L,0x2CCEC343L,1L,0x785D6A8DL,0xC11C388CL,0x20479D71L},{0xE094BE11L,0x511FF117L,(-5L),(-3L),0L,0xCB0A0F08L,7L,0xCB0A0F08L,0L,(-3L)},{4L,1L,4L,0L,(-8L),(-7L),0xE094BE11L,0x88E17929L,(-10L),0x2CCEC343L}},{{0L,0xDADCA18AL,1L,0xC11C388CL,0x80DFBF98L,9L,0x205D170DL,0x88E17929L,(-6L),0xEAD864EFL},{0L,1L,4L,1L,(-10L),(-1L),0x20479D71L,0xCB0A0F08L,1L,(-10L)},{0xC784BEE3L,(-8L),(-5L),(-6L),1L,0xC11C388CL,(-1L),0x785D6A8DL,0x511FF117L,(-6L)}},{{1L,0x1E1686B4L,0x88E17929L,7L,0x8F62F7CBL,0xE094BE11L,4L,0x80DFBF98L,0x20479D71L,0x511FF117L},{2L,0xECF5D119L,6L,4L,0x45001CB2L,0x95325233L,6L,0x511FF117L,0L,9L},{(-6L),0x48ED956EL,(-3L),1L,0x205D170DL,(-8L),(-5L),(-1L),(-1L),(-5L)}}};
                        int i, j, k;
                        l_2298 ^= (g_195[l_2249][l_2249] >= (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((((*l_2297) = (((l_2259 = (safe_add_func_int64_t_s_s((l_2275 &= 0L), p_15))) , p_16) != (safe_mod_func_int32_t_s_s(((((safe_div_func_int8_t_s_s(((p_15 , (--(*g_314))) | (safe_mod_func_uint8_t_u_u(p_15, ((((safe_mod_func_int64_t_s_s((-3L), (((l_2258[8] & ((safe_div_func_uint8_t_u_u(((**g_1410) &= (safe_rshift_func_uint8_t_u_s(((safe_rshift_func_uint8_t_u_u((((safe_lshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(0xD36FL, 11)), (**g_1461))) <= p_15) || 0x6F64A7FDL), 3)) | l_2258[3]), 3))), (*g_910))) != l_2296)) >= 0UL) & p_16))) == (-1L)) , l_2248) ^ 0xB2L)))), p_16)) != p_15) == p_16) != g_115), p_15)))) || p_15) || g_298[1][2][4]), g_2205.f1)), l_2296)));
                        (*g_463) = ((l_2258[3] >= ((safe_div_func_uint8_t_u_u(((((1L & p_15) < (l_2301 = (*g_376))) < ((((~(safe_lshift_func_int16_t_s_u(((void*)0 != &g_1642), ((-1L) || (safe_mul_func_uint16_t_u_u(p_15, (safe_add_func_uint32_t_u_u((&l_2265 != &l_2265), p_15)))))))) >= l_2309[5][0][8]) <= (**g_1282)) , l_2258[3])) , l_2310), p_16)) & p_15)) , (void*)0);
                        if (l_2248)
                            continue;
                    }
                    return g_2311;
                }
                return g_2312;
            }
            else
            { /* block id: 1065 */
                uint64_t * const *l_2314 = &g_1645;
                uint64_t * const **l_2313 = &l_2314;
                int64_t *l_2318 = &g_37;
                int32_t l_2324 = 0x535A45A5L;
                union U0 **l_2325 = &g_259[0][1][0];
                int32_t l_2331 = 0x8639D33BL;
                int32_t l_2332 = 0L;
                int32_t l_2333 = 0x30A92F45L;
                int32_t l_2334 = 0xB740927EL;
                int32_t l_2338 = 1L;
                int32_t l_2340 = 0x7EE0B965L;
                int32_t l_2341 = 0L;
                int32_t l_2345 = 0x25E045F4L;
                int32_t l_2346 = 0L;
                int32_t l_2347 = (-5L);
                int32_t l_2348[8];
                int8_t ***l_2370 = (void*)0;
                int i;
                for (i = 0; i < 8; i++)
                    l_2348[i] = (-1L);
                if ((g_1339.f0 > ((g_2326[3][3][2] = ((((p_16 < (l_2313 != l_2315)) > (l_2249 = (((safe_lshift_func_uint8_t_u_s((((*l_2318) |= (0xE34BL || (**g_767))) & (safe_mod_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s(((0x412EL >= (((0x7BL == ((l_2323 , g_1923) != (void*)0)) & l_2324) || (-3L))) , 255UL), p_15)), 0x2D5CL))), 1)) < p_16) , 0x683C729BL))) , &l_2201) == l_2325)) != 0UL)))
                { /* block id: 1069 */
                    uint8_t l_2327 = 0x18L;
                    int32_t l_2329[8] = {5L,5L,5L,5L,5L,5L,5L,5L};
                    int i;
                    l_2327 ^= p_16;
                    for (g_274 = 0; (g_274 <= 0); g_274 += 1)
                    { /* block id: 1073 */
                        return g_2328;
                    }
                    ++g_2350;
                    for (g_2328.f1 = 0; (g_2328.f1 <= 0); g_2328.f1 += 1)
                    { /* block id: 1079 */
                        uint8_t l_2353 = 0x92L;
                        union U0 *l_2356 = &g_166[3];
                        union U0 *l_2358 = &g_359[2];
                        union U0 **l_2357 = &l_2358;
                        int64_t l_2361 = 0L;
                        --l_2353;
                        l_2360 = (l_2359 = ((*l_2357) = ((*l_2325) = (l_2356 = (void*)0))));
                        if (l_2361)
                            break;
                    }
                }
                else
                { /* block id: 1088 */
                    uint8_t *l_2364[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int8_t ***l_2367 = &g_1282;
                    int32_t l_2380 = 0L;
                    union U0 *l_2381 = &g_2263[0][3];
                    uint64_t l_2410 = 0x1BBE68C75951E8CFLL;
                    int i;
                    if ((safe_mul_func_int16_t_s_s((((l_2364[1] == (*g_1410)) | (safe_rshift_func_int8_t_s_s((*g_1218), 0))) | ((void*)0 != l_2367)), (safe_mul_func_int16_t_s_s(3L, ((void*)0 != l_2370))))))
                    { /* block id: 1089 */
                        int16_t ****l_2371 = &g_1460;
                        int32_t l_2389 = 6L;
                        l_2248 &= (((l_2371 == (void*)0) < (safe_add_func_uint8_t_u_u((251UL < (safe_lshift_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((*g_314), 65535UL)) <= 0x0B3598A36E0A9AFCLL), ((safe_rshift_func_int8_t_s_s((7UL | (***g_1463)), l_2380)) != l_2380)))), l_2343[6]))) & l_2380);
                        (***g_1923) = l_2381;
                        l_2380 = (+((((safe_mul_func_uint8_t_u_u(((((safe_mul_func_int16_t_s_s((~0UL), 0x5FD7L)) , (*g_314)) , (((**g_1643) = (**g_1643)) == &p_15)) , (~1L)), (((void*)0 == &l_2202[1]) , 0x0DL))) < g_2326[7][0][2]) & l_2389) && 0x28D810C863F72B55LL));
                        if (p_15)
                            continue;
                    }
                    else
                    { /* block id: 1095 */
                        uint8_t l_2400 = 254UL;
                        int64_t ***l_2408 = &l_2406;
                        int32_t l_2409 = (-1L);
                        int32_t l_2411 = (-3L);
                        l_2338 = (l_2411 |= (safe_add_func_int32_t_s_s((safe_mod_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((l_2409 = (l_2337 & ((safe_mod_func_int32_t_s_s(l_2348[0], (safe_div_func_int32_t_s_s(((p_15 != l_2400) || ((safe_mod_func_int64_t_s_s(((p_15 , g_2403[0][0][3]) == ((*l_2408) = l_2406)), (((*l_2407) = ((*g_314) || p_16)) , p_16))) > (**g_1644))), p_16)))) , l_2380))), 0x8EL)) == l_2410), 0xB238L)), l_2400)));
                        l_2342 &= (p_15 > (((safe_div_func_uint32_t_u_u((safe_div_func_uint8_t_u_u(((***g_1643) ^ ((*l_2318) = (l_2416 == &g_1923))), l_2417[0][2])), (0xC05315711508E36ALL && (((*g_1411) &= (((***g_1460) |= (safe_rshift_func_int8_t_s_s((*g_1218), 7))) == ((0xFCL || ((((safe_add_func_int64_t_s_s(l_2334, l_2335)) <= (*g_314)) >= p_15) , p_15)) ^ p_15))) ^ p_15)))) >= 0x35B8AC44L) < (*g_314)));
                        (*g_376) = ((*g_1534) = (((*g_1534) || (l_2259 = (safe_sub_func_int16_t_s_s(p_15, (-10L))))) == (safe_sub_func_uint16_t_u_u((*g_314), 0UL))));
                        (*g_463) = &l_2409;
                    }
                }
                if (l_2426[0][4])
                    break;
                for (l_2323 = 0; l_2323 < 8; l_2323 += 1)
                {
                    for (g_755 = 0; g_755 < 9; g_755 += 1)
                    {
                        for (g_1464.f1 = 0; g_1464.f1 < 3; g_1464.f1 += 1)
                        {
                            g_998[l_2323][g_755][g_1464.f1] = 1UL;
                        }
                    }
                }
            }
            (*g_137) = p_15;
            for (l_2249 = 0; l_2249 < 3; l_2249 += 1)
            {
                for (g_2044.f0 = 0; g_2044.f0 < 2; g_2044.f0 += 1)
                {
                    g_315[l_2249][g_2044.f0] = 0xFC0DL;
                }
            }
            for (g_105 = 0; (g_105 >= 0); g_105 -= 1)
            { /* block id: 1118 */
                int32_t **l_2433 = &l_2255[2][1];
                int32_t l_2436 = 1L;
                uint32_t *l_2437 = &g_648[0][1][4];
                l_2436 = (l_2344 = (0x21F37BA2L | (safe_mod_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((*l_2437) = (((*g_314) = (safe_rshift_func_uint16_t_u_s((((((*l_2433) = (g_2328.f1 , &l_2344)) != &l_2344) ^ p_16) ^ (*g_314)), 6))) ^ (p_15 && (((-5L) & (safe_div_func_uint8_t_u_u(l_2436, l_2426[0][6]))) , 0x05FD010BL)))), g_1464.f1)), (-1L)))));
                l_2330 = ((((safe_unary_minus_func_int16_t_s((((safe_div_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s((safe_div_func_int16_t_s_s((safe_div_func_int16_t_s_s((l_2342 | (((*g_1925) != (void*)0) ^ (~((safe_lshift_func_uint8_t_u_s((***g_1409), 3)) , (l_2450[4][0] || (g_298[0][1][5] ^ (safe_div_func_uint64_t_u_u((safe_div_func_int64_t_s_s(0xD760F49AA7848E98LL, (safe_mod_func_int16_t_s_s((g_2457 && p_16), (*g_314))))), 0x81A318F5F96EFB33LL)))))))), l_2436)), p_16)), (***g_766))) | (**g_767)), 7UL)) < p_16) | 4UL))) && p_15) , (*g_1534)) == 1L);
                for (g_1088.f1 = 0; (g_1088.f1 >= 0); g_1088.f1 -= 1)
                { /* block id: 1127 */
                    for (l_2251 = 3; (l_2251 >= 0); l_2251 -= 1)
                    { /* block id: 1130 */
                        (*g_2458) = l_2243[1][3][2];
                    }
                }
            }
        }
        else
        { /* block id: 1135 */
            return g_2459[0];
        }
        if (p_15)
        { /* block id: 1138 */
            int32_t l_2460 = 0x6461D7AFL;
            uint32_t l_2463 = 0x81F55E6FL;
            union U0 *l_2523 = &g_2032;
            int32_t l_2540 = 9L;
            int32_t *l_2553 = &l_2510;
            int64_t *l_2561 = &g_394;
            int16_t ****l_2570 = &g_1460;
            for (g_2044.f1 = 0; (g_2044.f1 >= 0); g_2044.f1 -= 1)
            { /* block id: 1141 */
                uint16_t l_2468 = 65535UL;
                for (g_149 = 0; (g_149 <= 0); g_149 += 1)
                { /* block id: 1144 */
                    uint32_t *l_2471 = &g_109[8];
                    uint32_t *l_2472 = (void*)0;
                    uint32_t *l_2473 = &g_1810;
                    uint16_t *l_2474[6][3] = {{(void*)0,&g_998[6][6][1],(void*)0},{&g_998[6][4][2],&g_998[6][4][2],&g_592},{&l_2468,&g_998[6][6][1],&l_2468},{&g_998[6][4][2],&g_592,&g_592},{(void*)0,&g_998[6][6][1],(void*)0},{&g_998[6][4][2],&g_998[6][4][2],&g_592}};
                    int32_t l_2478 = 1L;
                    int i, j, k;
                    if (l_2460)
                        break;
                    if ((l_2478 |= (safe_rshift_func_int16_t_s_u((p_16 >= l_2463), (safe_div_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(((*g_314) = l_2468), (safe_sub_func_uint32_t_u_u(((*l_2473) = ((*l_2471) = p_16)), ((g_998[2][2][0] = l_2463) & (!((*g_167) , 0UL))))))) > ((!(0UL != g_100)) , p_16)), l_2477))))))
                    { /* block id: 1151 */
                        if (p_16)
                            break;
                    }
                    else
                    { /* block id: 1153 */
                        uint16_t l_2479[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_2479[i] = 1UL;
                        l_2479[0]++;
                    }
                    l_2498 = ((safe_mul_func_int8_t_s_s(0xEBL, ((1UL < ((safe_add_func_uint32_t_u_u((g_162 == (safe_unary_minus_func_int64_t_s(l_2487))), 7UL)) | (p_15 & (safe_sub_func_uint32_t_u_u(p_16, (safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s(((((safe_lshift_func_uint16_t_u_s(((safe_add_func_uint64_t_u_u(1UL, (0xF6CD0AD2903A7779LL >= p_16))) && 0x9EL), 14)) || p_16) < l_2478) > l_2478), p_16)), p_15))))))) == 0x54DDED7CL))) ^ l_2478);
                    return g_2499;
                }
                for (l_2252 = 0; (l_2252 <= 0); l_2252 += 1)
                { /* block id: 1161 */
                    int16_t l_2518 = 0L;
                    int32_t l_2527 = 1L;
                    int8_t l_2545[3][3] = {{(-6L),(-6L),(-6L)},{0x81L,0x81L,0x81L},{(-6L),(-6L),(-6L)}};
                    int i, j, k;
                    if ((((*g_314) > (safe_rshift_func_int16_t_s_s(((((((((l_2468 == (safe_sub_func_int16_t_s_s((safe_sub_func_int32_t_s_s((safe_div_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s(((((l_2510 | (safe_lshift_func_uint8_t_u_s(((void*)0 == l_2513[0]), (safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(l_2518, (&l_2426[0][3] != (((safe_mul_func_uint16_t_u_u(0UL, ((***g_1463) = ((safe_lshift_func_int8_t_s_s((((g_259[l_2252][(l_2252 + 1)][(g_2044.f1 + 3)] = l_2523) != (void*)0) , p_15), (*g_1218))) ^ (*g_137))))) && p_16) , &l_2252)))), l_2518))))) , p_16) && p_15) ^ (*g_1218)), p_15)), p_16)), 0xB70CD806L)), 1UL))) , 0xC7L) != 0x8BL) != 0x17L) && 0xD8E9L) , (**g_1282)) == (**g_1217)) < p_15), 11))) <= l_2468))
                    { /* block id: 1164 */
                        int32_t **l_2524 = &g_2156[0];
                        (*l_2524) = ((*g_463) = &l_2344);
                        l_2527 = (l_2525 == (void*)0);
                    }
                    else
                    { /* block id: 1168 */
                        const uint16_t l_2541[5] = {0x8223L,0x8223L,0x8223L,0x8223L,0x8223L};
                        int32_t l_2546[8][7] = {{0xE86D87D1L,0xD4965B36L,9L,0xD4965B36L,9L,9L,0xD4965B36L},{9L,0xD4965B36L,9L,9L,0xD4965B36L,9L,9L},{0xD4965B36L,0xD4965B36L,0xE86D87D1L,0xD4965B36L,0xD4965B36L,0xE86D87D1L,0xD4965B36L},{0xD4965B36L,9L,9L,0xD4965B36L,9L,9L,0xD4965B36L},{9L,0xD4965B36L,9L,9L,0xD4965B36L,9L,9L},{0xD4965B36L,0xD4965B36L,0xE86D87D1L,0xD4965B36L,0xD4965B36L,0xE86D87D1L,0xD4965B36L},{0xD4965B36L,9L,9L,0xD4965B36L,9L,9L,0xD4965B36L},{9L,0xD4965B36L,9L,9L,0xD4965B36L,9L,9L}};
                        int i, j;
                        l_2546[7][6] = (safe_rshift_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u(((0x72FEL < 9UL) < ((safe_div_func_int32_t_s_s((l_2534 , (safe_div_func_int8_t_s_s(((+(*g_910)) && (safe_add_func_uint16_t_u_u(l_2540, p_15))), l_2541[0]))), (0x2A46L ^ (safe_rshift_func_int8_t_s_s(((0x4273159EL ^ l_2544) >= l_2468), 2))))) <= l_2518)), (***g_1409))) & l_2545[2][1]), 1));
                    }
                }
            }
            for (g_2312.f1 = 0; (g_2312.f1 >= 2); g_2312.f1 = safe_add_func_uint32_t_u_u(g_2312.f1, 6))
            { /* block id: 1175 */
                const union U0 *l_2554 = &g_2555;
                const union U0 *l_2556 = (void*)0;
                int16_t ****l_2558 = &g_1463;
                int16_t *****l_2557 = &l_2558;
                for (g_2198.f1 = 0; (g_2198.f1 == (-14)); g_2198.f1 = safe_sub_func_int64_t_s_s(g_2198.f1, 5))
                { /* block id: 1178 */
                    for (g_1810 = 0; (g_1810 <= 55); ++g_1810)
                    { /* block id: 1181 */
                        l_2553 = l_2553;
                        l_2556 = (l_2554 = (void*)0);
                    }
                }
                if ((((void*)0 != l_2557) != ((((*l_2553) = (3UL && ((*g_314) = (l_2561 != (*l_2406))))) != (*g_376)) < (safe_add_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u((safe_add_func_uint16_t_u_u(((((safe_lshift_func_int8_t_s_u(((p_15 && ((***g_766) == ((p_16 < g_318) == 0xD8L))) | 65528UL), p_15)) , l_2569) != l_2570) , p_15), l_2571)))), (*g_1411))))))
                { /* block id: 1189 */
                    for (g_149 = 0; (g_149 <= 3); g_149 += 1)
                    { /* block id: 1192 */
                        int i, j, k;
                        (*l_2553) &= 0x72708CE1L;
                        g_2184[1][0][4] = g_2047[(g_149 + 4)][(g_2048 + 1)][g_2048];
                        if (p_15)
                            break;
                        if ((*g_137))
                            continue;
                    }
                }
                else
                { /* block id: 1198 */
                    if ((*g_137))
                        break;
                    for (g_196 = 0; (g_196 < 58); g_196 = safe_add_func_int64_t_s_s(g_196, 5))
                    { /* block id: 1202 */
                        uint16_t l_2574 = 1UL;
                        l_2574++;
                        (*g_463) = ((*g_2204) , &l_2510);
                        (*g_463) = &l_2510;
                    }
                }
            }
        }
        else
        { /* block id: 1209 */
            int16_t ***l_2577 = (void*)0;
            int32_t l_2585[8][2] = {{0L,1L},{1L,0L},{(-6L),0L},{(-6L),0L},{1L,1L},{0L,(-6L)},{0L,(-6L)},{0L,1L}};
            int32_t l_2594 = (-6L);
            int32_t * const *l_2643 = &g_2156[0];
            int32_t * const **l_2642 = &l_2643;
            int32_t l_2669 = 0x121A2F13L;
            int i, j;
            if ((0x4B94B8187053189ALL >= ((*l_2569) == l_2577)))
            { /* block id: 1210 */
                uint32_t l_2590 = 0UL;
                int32_t ***l_2618 = &g_463;
                int32_t l_2657[7] = {0x45C47D49L,0x45C47D49L,0x45C47D49L,0x45C47D49L,0x45C47D49L,0x45C47D49L,0x45C47D49L};
                int8_t l_2670[6];
                int16_t l_2701 = 0x6EBFL;
                int i;
                for (i = 0; i < 6; i++)
                    l_2670[i] = 0xB5L;
                if ((((*l_2407) = (-10L)) , (safe_mod_func_uint64_t_u_u((0x1EA8823E39D77F34LL <= ((safe_div_func_uint32_t_u_u(g_2326[6][2][2], g_191)) , p_16)), (((((+((((((**g_1282) = 0L) && p_15) , (l_2583 == l_2584[0][6])) < g_2048) != l_2585[2][1])) , (-5L)) && 0x3B21C55434467F90LL) != p_15) ^ l_2586[0])))))
                { /* block id: 1213 */
                    uint64_t l_2587 = 0x12764C5957BC91C9LL;
                    int64_t l_2593 = (-3L);
                    int32_t l_2596[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_2596[i] = 0L;
                    if (l_2587)
                        break;
                    if ((safe_rshift_func_uint16_t_u_s((((*g_1645) = (p_15 || ((**l_2406) ^= 0xA61CA3C421C7C864LL))) < ((-1L) >= (l_2594 ^= ((l_2590 || p_15) & ((((*g_1218) > l_2585[2][1]) == (safe_sub_func_int64_t_s_s(0x7EEED84E7355BADELL, (((p_15 != 0UL) || l_2593) || 1UL)))) || 0x23D5C5A4L))))), 15)))
                    { /* block id: 1218 */
                        return g_2595;
                    }
                    else
                    { /* block id: 1220 */
                        int32_t l_2597 = 0x54D865EDL;
                        int32_t l_2598 = (-2L);
                        uint32_t l_2599 = 0x9660A099L;
                        l_2599++;
                    }
                }
                else
                { /* block id: 1223 */
                    int8_t *** const l_2604 = (void*)0;
                    int32_t * const *l_2617 = (void*)0;
                    int32_t * const **l_2616 = &l_2617;
                    int32_t * const ***l_2615 = &l_2616;
                    uint32_t l_2619 = 0xFFEEFB52L;
                    int32_t *l_2655[7] = {&l_2477,&l_2477,&l_2477,&l_2477,&l_2477,&l_2477,&l_2477};
                    int32_t l_2671 = 0x9DF32086L;
                    int64_t l_2675 = 0L;
                    int32_t l_2676[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2676[i] = 0L;
                    if ((((((safe_add_func_int32_t_s_s((((((l_2604 != &g_1217) | (((safe_sub_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u((((g_2268.f0 >= (((*g_314) && (safe_rshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((l_2590 > 0xB6496F1FL), ((safe_lshift_func_uint8_t_u_s((p_15 & ((((*l_2615) = ((**g_1217) , (void*)0)) != l_2618) < l_2619)), p_15)) ^ p_15))), 9))) , p_16)) != 0x914BL) | (**g_1644)), p_15)) , 0xD2E0L), p_15)) != (**g_1217)) >= l_2585[2][0])) , p_16) & p_16) , p_16), (-9L))) , (-1L)) > g_2046) & l_2594) != p_16))
                    { /* block id: 1225 */
                        int16_t l_2639 = 0x617DL;
                        (*g_137) = p_15;
                        l_2585[2][1] = 0x4E58ADDCL;
                        (*g_1534) &= ((((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s(((safe_lshift_func_uint8_t_u_s((((p_16 , ((*g_1411) = (safe_mod_func_uint64_t_u_u(((safe_div_func_int16_t_s_s((p_16 || (-10L)), (~p_16))) == ((+((g_394 = p_16) <= ((safe_sub_func_int8_t_s_s(0xCEL, ((safe_mul_func_int8_t_s_s((((safe_sub_func_uint16_t_u_u((*g_314), p_16)) == l_2638) | 0xC9L), (-1L))) >= p_16))) > (*g_1645)))) , l_2639)), p_15)))) , l_2590) && g_592), p_15)) <= 0UL), 3)), 0x8993L)) == p_15) >= l_2585[2][0]) >= (*g_264));
                    }
                    else
                    { /* block id: 1231 */
                        (*g_463) = &l_2585[0][1];
                    }
                    for (l_2638 = 0; (l_2638 != (-23)); --l_2638)
                    { /* block id: 1236 */
                        int64_t **l_2649 = &l_2407;
                        int32_t l_2656 = 1L;
                        union U0 **l_2662 = &g_259[0][1][0];
                        int64_t ***l_2667 = &l_2649;
                        int64_t * const *l_2668 = &l_2407;
                        int32_t l_2673 = 0x6CC454E7L;
                        int32_t l_2674[9] = {0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL,0x210E639BL};
                        int i;
                        g_2644 &= ((0x9EC3L <= 1UL) >= ((*g_314) , ((void*)0 == l_2642)));
                        l_2657[1] = (((safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((p_16 ^ (***g_1643)), ((void*)0 == l_2649))), (p_16 >= ((g_2650 = 0x1355AD44L) , (safe_lshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((&g_2183 != ((*g_1534) , l_2655[3])), l_2656)), 14)))))) <= g_105) < 252UL);
                        l_2670[0] ^= (((4294967295UL < ((safe_sub_func_int64_t_s_s(((((safe_sub_func_int8_t_s_s(p_16, (((void*)0 != l_2662) || (safe_lshift_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(((p_16 < (((((((*l_2667) = (void*)0) == l_2668) || (*g_910)) != l_2656) | p_15) , l_2669)) , p_15), p_16)) && p_15), 7))))) , 4294967295UL) || p_16) , p_15), p_16)) == 0x9CL)) , (*g_314)) <= 0x67A1L);
                        --l_2677;
                    }
                    for (g_1810 = 9; (g_1810 <= 13); g_1810++)
                    { /* block id: 1246 */
                        uint16_t **l_2688 = &g_314;
                        uint16_t ***l_2689 = &l_2688;
                        uint64_t l_2697 = 18446744073709551615UL;
                        int32_t l_2699 = 0xE163F24AL;
                        uint32_t *l_2700 = &g_648[0][1][4];
                        l_2702 = (safe_rshift_func_int16_t_s_s((((g_648[0][1][4] = g_162) && ((safe_sub_func_int16_t_s_s((((safe_mod_func_uint16_t_u_u((((*l_2689) = l_2688) != &g_314), (+(***g_1409)))) == 249UL) | (***g_1409)), ((((0x473CL || (safe_div_func_uint64_t_u_u((safe_div_func_uint64_t_u_u(((0x9796L & (((*l_2700) &= (((**g_1282) = ((l_2699 = ((((safe_add_func_uint32_t_u_u(l_2697, g_2263[0][0].f0)) , (*g_314)) < l_2698[3]) < 0UL)) < 0x0EL)) >= 0UL)) <= 0x909834BDL)) <= p_15), 2UL)), l_2697))) == l_2701) || 5L) , 0UL))) != 0x943964B1L)) | (-1L)), (***g_766)));
                        l_2657[1] = p_16;
                    }
                }
            }
            else
            { /* block id: 1256 */
                for (g_1088.f1 = 0; (g_1088.f1 < 6); g_1088.f1 = safe_add_func_uint32_t_u_u(g_1088.f1, 5))
                { /* block id: 1259 */
                    int64_t l_2706 = 0x7257DC69299EC717LL;
                    (*g_2705) = l_2243[0][0][1];
                    l_2706 = p_15;
                }
            }
            l_2707 = p_15;
        }
    }
    for (g_2198.f1 = 22; (g_2198.f1 > (-7)); g_2198.f1--)
    { /* block id: 1269 */
        (*g_463) = &l_2242[5][4][1];
    }
    if ((&g_809 == l_2710))
    { /* block id: 1272 */
        const int32_t *l_2726 = &l_2242[5][4][1];
        const int32_t **l_2725 = &l_2726;
        const int32_t ***l_2724[8][3] = {{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725},{&l_2725,&l_2725,&l_2725}};
        const int32_t ****l_2723[8] = {&l_2724[0][2],&l_2724[0][2],&l_2724[1][2],&l_2724[0][2],&l_2724[0][2],&l_2724[1][2],&l_2724[0][2],&l_2724[0][2]};
        int32_t l_2727[2];
        int i, j;
        for (i = 0; i < 2; i++)
            l_2727[i] = 1L;
        l_2727[1] ^= (safe_mul_func_uint8_t_u_u((((***g_1643) = (&g_462[1] != l_2714)) , p_16), (safe_mod_func_int8_t_s_s((safe_add_func_int16_t_s_s((p_16 , (safe_div_func_uint16_t_u_u(((safe_add_func_uint64_t_u_u(((-1L) & (&g_462[1] == l_2723[5])), ((**l_2406) = p_15))) < p_15), p_15))), p_16)), p_16))));
    }
    else
    { /* block id: 1276 */
        union U0 **l_2741 = &g_259[0][1][1];
        for (l_2544 = 0; (l_2544 != 29); l_2544 = safe_add_func_uint16_t_u_u(l_2544, 1))
        { /* block id: 1279 */
            uint16_t l_2730 = 65533UL;
            l_2730 = p_15;
        }
        for (g_2268.f1 = (-3); (g_2268.f1 <= 0); g_2268.f1 = safe_add_func_int8_t_s_s(g_2268.f1, 6))
        { /* block id: 1284 */
            uint64_t **** const l_2739 = &g_1635;
            int32_t l_2740[9] = {0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L,0x5A9E1435L};
            int i;
            for (g_1270 = (-10); (g_1270 > 15); ++g_1270)
            { /* block id: 1287 */
                for (g_274 = 2; (g_274 > 28); g_274 = safe_add_func_int64_t_s_s(g_274, 9))
                { /* block id: 1290 */
                    for (g_1088.f1 = (-3); (g_1088.f1 >= 28); g_1088.f1++)
                    { /* block id: 1293 */
                        l_2740[8] = ((void*)0 != l_2739);
                    }
                }
                for (g_2328.f0 = 0; g_2328.f0 < 3; g_2328.f0 += 1)
                {
                    for (g_2183 = 0; g_2183 < 2; g_2183 += 1)
                    {
                        g_315[g_2328.f0][g_2183] = 65529UL;
                    }
                }
            }
        }
        (*g_1924) = l_2741;
    }
    return (*l_2201);
}


/* ------------------------------------------ */
/* 
 * reads : g_315
 * writes:
 */
static const uint32_t  func_25(int16_t  p_26, int32_t  p_27, uint32_t  p_28)
{ /* block id: 999 */
    return g_315[1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_1923 g_1924 g_1925 g_316 g_2032 g_551.f1 g_2044 g_2045 g_109 g_315 g_1463 g_1461 g_264 g_105 g_166 g_910 g_166.f1 g_1644 g_1645 g_162 g_767 g_2046 g_314 g_376 g_394 g_1460 g_463 g_2146 g_1409 g_1410 g_1411 g_199 g_2032.f1 g_1534 g_101 g_2155 g_648 g_2183 g_826.f1 g_115 g_367 g_196 g_149
 * writes: g_367 g_105 g_101 g_316 g_196 g_2046 g_149 g_162 g_315 g_274 g_464 g_259 g_1642 g_394 g_592 g_2156 g_648
 */
static uint16_t  func_31(uint16_t  p_32, int8_t  p_33, const int64_t  p_34, const int32_t  p_35, int32_t  p_36)
{ /* block id: 796 */
    union U0 * const *l_1628 = (void*)0;
    int32_t l_1633 = (-1L);
    uint64_t l_1655[7][3][2] = {{{18446744073709551612UL,0x6F3DFC860C3573A5LL},{0x7354A32797CD1E11LL,0x6F3DFC860C3573A5LL},{18446744073709551612UL,0xBDBBE47E42565D75LL}},{{0xBDBBE47E42565D75LL,18446744073709551612UL},{0x6F3DFC860C3573A5LL,0x7354A32797CD1E11LL},{0x6F3DFC860C3573A5LL,18446744073709551612UL}},{{0xBDBBE47E42565D75LL,0xBDBBE47E42565D75LL},{18446744073709551612UL,0x6F3DFC860C3573A5LL},{0x7354A32797CD1E11LL,0x6F3DFC860C3573A5LL}},{{18446744073709551612UL,0xBDBBE47E42565D75LL},{0xBDBBE47E42565D75LL,18446744073709551612UL},{0x6F3DFC860C3573A5LL,0x7354A32797CD1E11LL}},{{0x6F3DFC860C3573A5LL,18446744073709551612UL},{0xBDBBE47E42565D75LL,0xBDBBE47E42565D75LL},{18446744073709551612UL,0x6F3DFC860C3573A5LL}},{{0x7354A32797CD1E11LL,0x6F3DFC860C3573A5LL},{18446744073709551612UL,0xBDBBE47E42565D75LL},{0xBDBBE47E42565D75LL,18446744073709551612UL}},{{0x6F3DFC860C3573A5LL,0x7354A32797CD1E11LL},{0x6F3DFC860C3573A5LL,18446744073709551612UL},{0xBDBBE47E42565D75LL,0xBDBBE47E42565D75LL}}};
    int32_t l_1705 = 0x35F9B05EL;
    int32_t l_1768[2];
    int32_t l_1773 = 0x0759D04EL;
    int32_t l_1781 = 0x6D8B8B5AL;
    int16_t l_1791 = 1L;
    int64_t l_1809 = 0L;
    uint8_t *l_1824 = &g_199;
    int64_t l_1910 = (-10L);
    int16_t l_1916 = (-1L);
    uint32_t l_1917 = 1UL;
    int8_t **l_1954 = &g_910;
    int32_t l_2089 = 0xEC3C559DL;
    uint64_t l_2127[9];
    uint16_t l_2187[6];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1768[i] = 0xD3ABA1AAL;
    for (i = 0; i < 9; i++)
        l_2127[i] = 18446744073709551615UL;
    for (i = 0; i < 6; i++)
        l_2187[i] = 65529UL;
lbl_2131:
    for (g_367 = 26; (g_367 < 32); g_367++)
    { /* block id: 799 */
        uint32_t l_1615[3][7];
        union U0 **l_1629 = (void*)0;
        int16_t *l_1632 = &g_1375;
        uint64_t *l_1638 = &g_367;
        uint64_t **l_1637[8];
        uint64_t ***l_1636 = &l_1637[2];
        uint64_t ****l_1639 = (void*)0;
        int8_t l_1691 = 1L;
        int32_t l_1704 = 0xAE7337F5L;
        int32_t l_1707 = 0xFE1F548BL;
        uint32_t l_1711 = 0x60AA15ACL;
        int32_t l_1760 = 1L;
        int32_t l_1761 = 0x72D6E07DL;
        int32_t l_1762 = 0xE56AFAD4L;
        int16_t l_1766 = 0x669BL;
        int32_t l_1767 = 0x117E876DL;
        int32_t l_1775 = 0x4412DCA2L;
        int32_t l_1777[10][3][4] = {{{0x82F9C556L,0x4FCA71BDL,0x82F9C556L,(-5L)},{(-9L),(-8L),0x261EE45AL,0xE4D7E7A8L},{0x9EB5DD0AL,(-5L),(-5L),(-8L)}},{{0x00942914L,0x4FCA71BDL,(-5L),0xA22E374BL},{0x00942914L,(-5L),(-9L),0x030A1842L},{(-5L),0x7C39BB34L,(-1L),0x03EF1D43L}},{{(-1L),0x03EF1D43L,0L,0L},{0x00942914L,0x03EF1D43L,(-1L),0x03EF1D43L},{0x82F9C556L,0x7C39BB34L,(-6L),0x030A1842L}},{{0x261EE45AL,(-5L),0L,0xA22E374BL},{(-5L),0L,0x2D042AFDL,0x03EF1D43L},{(-5L),6L,0L,1L}},{{0x261EE45AL,0x03EF1D43L,(-6L),6L},{0x82F9C556L,0L,(-1L),0x030A1842L},{0x00942914L,(-5L),0L,0x030A1842L}},{{(-1L),0L,(-1L),6L},{(-5L),0x03EF1D43L,(-9L),1L},{0x00942914L,6L,(-6L),0x03EF1D43L}},{{0L,0L,(-6L),0xA22E374BL},{0x00942914L,(-5L),(-9L),0x030A1842L},{(-5L),0x7C39BB34L,(-1L),0x03EF1D43L}},{{(-1L),0x03EF1D43L,0L,0L},{0x00942914L,0x03EF1D43L,(-1L),0x03EF1D43L},{0x82F9C556L,0x7C39BB34L,(-6L),0x030A1842L}},{{0x261EE45AL,(-5L),0L,0xA22E374BL},{(-5L),0L,0x2D042AFDL,0x03EF1D43L},{(-5L),6L,0L,1L}},{{0x261EE45AL,0x03EF1D43L,(-6L),6L},{0x82F9C556L,0L,(-1L),0x030A1842L},{0x00942914L,(-5L),0L,0x030A1842L}}};
        int64_t l_1794 = 1L;
        uint32_t l_1797[2][4][2] = {{{0UL,5UL},{5UL,0UL},{5UL,5UL},{0UL,5UL}},{{5UL,0UL},{5UL,5UL},{0UL,5UL},{5UL,0UL}}};
        int64_t l_1804 = (-1L);
        int16_t l_1907[7][2][6] = {{{0x0048L,0x0048L,1L,5L,1L,0x0048L},{1L,0xA638L,5L,5L,0xA638L,1L}},{{0x0048L,1L,5L,1L,0x0048L,0x0048L},{(-1L),1L,1L,(-1L),0xA638L,(-1L)}},{{(-1L),0xA638L,(-1L),1L,1L,(-1L)},{0x0048L,0x0048L,1L,5L,1L,0x0048L}},{{1L,0xA638L,5L,5L,0xA638L,1L},{0x0048L,1L,5L,1L,0x0048L,0x0048L}},{{(-1L),1L,1L,(-1L),0xA638L,(-1L)},{(-1L),0xA638L,(-1L),1L,1L,(-1L)}},{{0x0048L,0x0048L,1L,5L,1L,0x0048L},{1L,0xA638L,5L,5L,0x0048L,(-1L)}},{{1L,(-1L),0xA638L,(-1L),1L,1L},{5L,(-1L),(-1L),5L,0x0048L,5L}}};
        int32_t l_1915 = 0xA1262E03L;
        const uint32_t *l_1948[4][2] = {{&g_1810,&l_1615[0][6]},{&g_1810,&l_1615[0][6]},{&g_1810,&l_1615[0][6]},{&g_1810,&l_1615[0][6]}};
        const uint32_t **l_1947[4][2][8] = {{{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]},{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]}},{{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]},{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]}},{{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]},{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]}},{{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]},{&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0],&l_1948[0][0]}}};
        int64_t l_1963[4][8] = {{7L,7L,(-7L),7L,0xCDEF169A8A85D58CLL,(-7L),0xCDEF169A8A85D58CLL,7L},{0L,7L,0L,0x07AA35FE1791A8D8LL,7L,0xF4D0C4E7B4A16296LL,0xF4D0C4E7B4A16296LL,7L},{7L,0xF4D0C4E7B4A16296LL,0xF4D0C4E7B4A16296LL,7L,0x07AA35FE1791A8D8LL,0L,7L,0L},{7L,0xCDEF169A8A85D58CLL,(-7L),0xCDEF169A8A85D58CLL,7L,(-7L),7L,7L}};
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 7; j++)
                l_1615[i][j] = 0x0A6E5AC7L;
        }
        for (i = 0; i < 8; i++)
            l_1637[i] = &l_1638;
        if (p_33)
            break;
    }
    for (g_105 = (-2); (g_105 != (-5)); g_105--)
    { /* block id: 927 */
        int8_t l_2009[2];
        union U0 **l_2010 = &g_259[0][1][0];
        uint16_t l_2066 = 0xB8C2L;
        int32_t l_2067 = (-5L);
        int32_t l_2069 = 0x18A94DB0L;
        int32_t l_2070 = 0xC1781082L;
        int32_t l_2071 = (-7L);
        uint8_t l_2072 = 0xB3L;
        int8_t ***l_2114[4][3][6] = {{{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282}},{{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282}},{{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282}},{{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282},{&l_1954,&g_1282,&l_1954,&g_1282,&l_1954,&g_1282}}};
        int64_t *l_2121 = &g_394;
        uint64_t l_2126[5][7][6] = {{{0x4A441CEC6A892BC6LL,6UL,0xB0B746262BDF5F5ELL,18446744073709551615UL,18446744073709551607UL,0xACA55101E8931DF8LL},{0UL,6UL,0xC043902E74B2E6A5LL,0UL,2UL,0xC043902E74B2E6A5LL},{0x583AEC64DF12B2E3LL,0x511CA284C74CFEC7LL,18446744073709551615UL,1UL,0xB8F252AE46342984LL,0UL},{0x89ABCA399C278DF7LL,2UL,18446744073709551615UL,0x4A441CEC6A892BC6LL,0xD6347091F4FFF2C7LL,18446744073709551615UL},{18446744073709551615UL,6UL,18446744073709551615UL,0UL,0x511CA284C74CFEC7LL,0UL},{18446744073709551615UL,0xF173217B88F3EA51LL,18446744073709551615UL,5UL,18446744073709551615UL,0xC043902E74B2E6A5LL},{5UL,18446744073709551615UL,0xC043902E74B2E6A5LL,1UL,1UL,0xACA55101E8931DF8LL}},{{1UL,18446744073709551606UL,0xB0B746262BDF5F5ELL,1UL,18446744073709551615UL,5UL},{5UL,8UL,18446744073709551615UL,5UL,6UL,0UL},{18446744073709551615UL,0x15F7268DD52AA810LL,0xACA55101E8931DF8LL,0UL,0x3A9B5866F89863B9LL,18446744073709551615UL},{18446744073709551615UL,0xD6347091F4FFF2C7LL,0x583AEC64DF12B2E3LL,0x4A441CEC6A892BC6LL,0x3A9B5866F89863B9LL,1UL},{0x89ABCA399C278DF7LL,0x15F7268DD52AA810LL,5UL,1UL,6UL,0x4A441CEC6A892BC6LL},{0x583AEC64DF12B2E3LL,8UL,0UL,0UL,18446744073709551615UL,18446744073709551615UL},{0UL,18446744073709551606UL,0x89ABCA399C278DF7LL,18446744073709551615UL,1UL,18446744073709551615UL}},{{0x4A441CEC6A892BC6LL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0x4A441CEC6A892BC6LL},{0x3D42A5CDBCD17DADLL,0xF173217B88F3EA51LL,5UL,0xB0B746262BDF5F5ELL,0x511CA284C74CFEC7LL,1UL},{0UL,6UL,0x583AEC64DF12B2E3LL,0xACA55101E8931DF8LL,0xD6347091F4FFF2C7LL,18446744073709551615UL},{0UL,2UL,0xACA55101E8931DF8LL,0xB0B746262BDF5F5ELL,0xB8F252AE46342984LL,0UL},{0x3D42A5CDBCD17DADLL,0x511CA284C74CFEC7LL,18446744073709551615UL,0UL,2UL,5UL},{0x4A441CEC6A892BC6LL,6UL,0xB0B746262BDF5F5ELL,18446744073709551615UL,18446744073709551607UL,0xACA55101E8931DF8LL},{0UL,6UL,0xC043902E74B2E6A5LL,0UL,2UL,0xC043902E74B2E6A5LL}},{{0x583AEC64DF12B2E3LL,0x511CA284C74CFEC7LL,18446744073709551615UL,1UL,0xB8F252AE46342984LL,0UL},{0x89ABCA399C278DF7LL,2UL,18446744073709551615UL,0x4A441CEC6A892BC6LL,0xD6347091F4FFF2C7LL,18446744073709551615UL},{18446744073709551615UL,6UL,18446744073709551615UL,0UL,0x511CA284C74CFEC7LL,0UL},{18446744073709551615UL,0xF173217B88F3EA51LL,18446744073709551615UL,5UL,18446744073709551615UL,0xC043902E74B2E6A5LL},{5UL,18446744073709551615UL,0xC043902E74B2E6A5LL,1UL,1UL,0xACA55101E8931DF8LL},{1UL,18446744073709551606UL,0xB0B746262BDF5F5ELL,1UL,18446744073709551615UL,5UL},{5UL,8UL,18446744073709551615UL,5UL,6UL,0UL}},{{18446744073709551615UL,0x15F7268DD52AA810LL,0xACA55101E8931DF8LL,0UL,0x3A9B5866F89863B9LL,18446744073709551615UL},{18446744073709551615UL,0xD6347091F4FFF2C7LL,0x583AEC64DF12B2E3LL,0x4A441CEC6A892BC6LL,0x3A9B5866F89863B9LL,1UL},{0x89ABCA399C278DF7LL,0x15F7268DD52AA810LL,5UL,1UL,6UL,0x4A441CEC6A892BC6LL},{0x583AEC64DF12B2E3LL,8UL,0UL,0UL,18446744073709551615UL,0x2A4FA68328895F2CLL},{7UL,0x4A441CEC6A892BC6LL,18446744073709551612UL,18446744073709551615UL,0UL,0x2A4FA68328895F2CLL},{0xF0A9E56BE2B6EC24LL,1UL,7UL,7UL,1UL,0xF0A9E56BE2B6EC24LL},{18446744073709551607UL,0xC043902E74B2E6A5LL,5UL,0xB5B7D31BBB724502LL,18446744073709551615UL,0xE773C46404619631LL}}};
        uint64_t ****l_2141 = &g_1643;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2009[i] = 0x83L;
        for (g_101 = (-14); (g_101 != (-6)); g_101++)
        { /* block id: 930 */
            uint32_t l_2043 = 6UL;
            int32_t l_2068[6][4][10] = {{{(-5L),0x46C48EE7L,0x9B6E7201L,0xF004F98BL,(-1L),0xBD031B9BL,4L,0x31F5BCA6L,0x61DB05FDL,0xA176607AL},{0x31F5BCA6L,0xB0F14F78L,(-1L),0L,0xD23DB1EDL,0x239D7A41L,0xD619E1AEL,8L,0x8F3C32DBL,0x46C48EE7L},{0xC5C2A942L,(-5L),0x3053FD3EL,(-4L),0x46CFDF61L,(-1L),5L,(-8L),0x0B3E50E4L,0x89472B6EL},{1L,1L,(-1L),(-1L),(-1L),0x07DB4F70L,0x8BCFF435L,7L,0x31F5BCA6L,1L}},{{(-6L),(-8L),0xB6F1812FL,0x239D7A41L,(-10L),0x7D462100L,0x07DB4F70L,0x23255E6AL,(-1L),0x59EF0140L},{0x9C50126BL,0xDE888556L,0xBD031B9BL,0xAB1282F6L,0xD50BA346L,1L,0x59EF0140L,0x46CFDF61L,0x46C48EE7L,0x7AE79A14L},{0xB0F14F78L,0L,5L,(-1L),(-1L),(-6L),0xB6F1812FL,1L,0L,0x07DB4F70L},{1L,1L,1L,1L,0xB6F1812FL,0x59EF0140L,5L,0x9B6E7201L,1L,0x9B6E7201L}},{{0x31F5BCA6L,0xC42E8CDAL,0x46C48EE7L,0x664780F7L,0x46C48EE7L,0xC42E8CDAL,0x31F5BCA6L,1L,2L,1L},{0x7EFDE526L,0x3053FD3EL,0xEA8828FFL,1L,7L,0L,0xD23DB1EDL,(-8L),0x89472B6EL,1L},{(-1L),0x3053FD3EL,5L,0x07B807E1L,0xD9D0EC61L,(-1L),0x31F5BCA6L,1L,0xD619E1AEL,0x957DA453L},{0x5CB43ACDL,0xC42E8CDAL,(-1L),0x8F3C32DBL,(-10L),5L,5L,0x94AD1657L,8L,0xBD031B9BL}},{{7L,1L,0x0BEFE3B3L,0L,0L,0xAB1282F6L,0xB6F1812FL,(-1L),5L,0xD9D0EC61L},{0x36F3B6E7L,0L,0xF004F98BL,5L,(-2L),0x05E92511L,0x59EF0140L,0x36F3B6E7L,0L,(-1L)},{1L,0xDE888556L,0x31F5BCA6L,0L,1L,1L,0x07DB4F70L,(-5L),1L,0xA176607AL},{0xEA8828FFL,(-8L),(-7L),1L,0x2F45ED8FL,0x7EFDE526L,0x8BCFF435L,0x62F3C97EL,0x239D7A41L,(-1L)}},{{2L,1L,(-8L),0x7EFDE526L,(-1L),0L,5L,8L,(-5L),(-8L)},{0x46C48EE7L,(-5L),0x59EF0140L,1L,0x9C50126BL,0xD9D0EC61L,(-2L),1L,0x4E252122L,(-1L)},{0L,0x0B3E50E4L,0x46CFDF61L,8L,(-1L),1L,1L,1L,0x62F3C97EL,(-7L)},{0x3B85B296L,0x7838C3C0L,(-1L),1L,(-4L),0xF004F98BL,0xDE888556L,(-8L),(-8L),0xDE888556L}},{{0x0B3E50E4L,5L,0xBD031B9BL,0xBD031B9BL,5L,0x0B3E50E4L,7L,(-8L),0L,0xD9D0EC61L},{0L,(-8L),0x94AD1657L,1L,(-1L),0x8DCD7267L,1L,0L,0x189FA0B0L,1L},{0L,1L,0xD50BA346L,(-10L),(-4L),0x0B3E50E4L,1L,0x5CB43ACDL,0x31F5BCA6L,(-4L)},{0x0B3E50E4L,1L,0x5CB43ACDL,0x31F5BCA6L,(-4L),0xF004F98BL,0x7838C3C0L,0xEA8828FFL,1L,1L}}};
            int32_t l_2130 = 0xC728B2D0L;
            int8_t l_2175 = (-2L);
            int8_t ***l_2179 = (void*)0;
            uint64_t l_2182 = 18446744073709551615UL;
            int i, j, k;
            if ((safe_sub_func_int8_t_s_s(((l_2009[1] ^ (l_2010 != (**g_1923))) , 0x04L), 0xB0L)))
            { /* block id: 931 */
                const uint32_t l_2013[10] = {0x8D88DD35L,0x8D88DD35L,18446744073709551607UL,0x128B40EFL,18446744073709551607UL,0x8D88DD35L,0x8D88DD35L,18446744073709551607UL,0x128B40EFL,18446744073709551607UL};
                int32_t l_2016 = 0xE020FF0CL;
                int32_t *l_2019 = &g_316;
                int32_t ****l_2041 = &g_462[1];
                int i;
                l_2016 = (safe_lshift_func_int16_t_s_s(l_2013[4], (safe_lshift_func_int8_t_s_u(p_33, 7))));
                (*l_2019) &= (safe_rshift_func_uint16_t_u_s(0xA6D1L, 13));
                for (g_196 = (-16); (g_196 == 50); g_196++)
                { /* block id: 936 */
                    int64_t *l_2042 = (void*)0;
                    int32_t *l_2049[8][7][4] = {{{&l_2016,&l_1768[0],&g_101,&l_1768[0]},{(void*)0,&l_1705,&l_1633,&l_1768[0]},{&l_1768[1],&g_2048,&l_1633,&g_101},{(void*)0,&l_1705,&g_101,&l_1768[0]},{&l_2016,&l_1768[0],&l_1633,&l_1633},{&l_1633,&l_1633,(void*)0,&l_1633},{&l_1633,&l_1768[0],&l_1633,&l_1768[0]}},{{&l_1768[0],&l_1705,&g_2048,&g_101},{&l_1633,&g_2048,&l_1633,&l_1768[0]},{&l_1633,&l_1705,&g_2048,&l_1768[0]},{&l_1768[0],&l_1768[0],&l_1633,&l_1705},{&l_1633,(void*)0,(void*)0,&l_1705},{&l_1633,(void*)0,&l_1633,&l_1705},{&l_2016,&l_1768[0],&g_101,&l_1768[0]}},{{(void*)0,&l_1705,&l_1633,&l_1768[0]},{&l_1768[1],&g_2048,&l_1633,&g_101},{(void*)0,&l_1705,&g_101,&l_1768[0]},{&l_2016,&l_1768[0],&l_1633,&l_1633},{&l_1633,&l_1633,(void*)0,&l_1633},{&l_1633,&l_1768[0],&l_1633,&l_1768[0]},{&l_1768[0],&l_1705,&g_2048,&g_101}},{{&l_1633,&g_2048,&l_1633,&l_1768[0]},{&l_1633,&l_1705,&g_2048,&l_1768[0]},{&l_1768[0],&l_1768[0],&l_1633,&l_1705},{&l_1633,(void*)0,(void*)0,&l_1705},{&l_1633,(void*)0,&l_1633,&l_1705},{&l_2016,&l_1768[0],&g_101,&l_1768[0]},{(void*)0,&l_1705,&l_1633,&l_1768[0]}},{{&l_1633,&g_101,&l_1768[1],&l_1705},{&l_1768[0],&l_1768[0],(void*)0,&l_1768[0]},{(void*)0,&l_1768[1],&l_1633,(void*)0},{&l_1633,(void*)0,&l_1768[0],(void*)0},{&l_1768[1],&l_1768[1],&g_2048,&l_1768[0]},{&l_1633,&l_1768[0],&l_2016,&l_1705},{&g_2048,&g_101,&l_1633,&g_2048}},{{&g_2048,&l_1633,&l_2016,&l_1705},{&l_1633,&g_2048,&g_2048,&l_1768[0]},{&l_1768[1],&l_1768[0],&l_1768[0],&l_1633},{&l_1633,&l_1768[0],&l_1633,&l_1768[0]},{(void*)0,&g_2048,(void*)0,&l_1705},{&l_1768[0],&l_1633,&l_1768[1],&g_2048},{&l_1633,&g_101,&l_1768[1],&l_1705}},{{&l_1768[0],&l_1768[0],(void*)0,&l_1768[0]},{(void*)0,&l_1768[1],&l_1633,(void*)0},{&l_1633,(void*)0,&l_1768[0],(void*)0},{&l_1768[1],&l_1768[1],&g_2048,&l_1768[0]},{&l_1633,&l_1768[0],&l_2016,&l_1705},{&g_2048,&g_101,&l_1633,&g_2048},{&g_2048,&l_1633,&l_2016,&l_1705}},{{&l_1633,&g_2048,&g_2048,&l_1768[0]},{&l_1768[1],&l_1768[0],&l_1768[0],&l_1633},{&l_1633,&l_1768[0],&l_1633,&l_1768[0]},{(void*)0,&g_2048,(void*)0,&l_1705},{&l_1768[0],&l_1633,&l_1768[1],&g_2048},{&l_1633,&g_101,&l_1768[1],&l_1705},{&l_1768[0],&l_1768[0],(void*)0,&l_1768[0]}}};
                    uint64_t l_2056 = 0x9A245E4C8E07F28FLL;
                    int i, j, k;
                    l_2016 = (safe_mod_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_mod_func_int64_t_s_s((g_2046 = (safe_add_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u((((p_32 , ((g_2032 , ((safe_div_func_uint8_t_u_u(l_2009[1], ((*l_2019) = 0x8CL))) < (safe_rshift_func_int8_t_s_u((safe_mod_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u(p_32, ((l_2043 = ((((void*)0 != l_2041) != (g_551.f1 > (p_34 , 0x2E221F76E4468E2ELL))) , 3L)) != (-1L)))) | (-1L)) != 0xE1F95589L), l_2009[1])), 2)))) , g_2044)) , g_2045[5]) , p_32), p_32)), g_109[6]))), g_315[1][0])), (***g_1463))), p_33));
                    for (l_1633 = 2; (l_1633 >= 0); l_1633 -= 1)
                    { /* block id: 943 */
                        const uint16_t l_2065 = 65533UL;
                        int i;
                        l_2067 = (safe_mul_func_int16_t_s_s((safe_add_func_int16_t_s_s((7L & (0x351DL == (((((safe_add_func_int32_t_s_s((l_2056 != 0x2620538ADCE0E1C7LL), (g_166[(l_1633 + 1)] , (safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((safe_sub_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_u(p_36, l_2065)) < (l_2066 = 0x36716273L)) & p_36), p_34)), 2)), l_1768[0]))))) < p_33) == (*g_910)) != 0xE2BBD4AFL) >= (-9L)))), 0x3C46L)), 0xC38CL));
                    }
                    --l_2072;
                    if (p_34)
                        continue;
                }
            }
            else
            { /* block id: 950 */
                int32_t l_2081 = 0L;
                int64_t *l_2085 = &l_1809;
                int64_t **l_2084[8][1][10] = {{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}},{{&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085,&l_2085}}};
                uint32_t l_2122 = 0xF281B606L;
                uint64_t l_2149 = 0UL;
                const int16_t * const l_2157 = &g_2046;
                int i, j, k;
                for (g_149 = 0; (g_149 == 12); ++g_149)
                { /* block id: 953 */
                    int64_t *l_2083 = &l_1809;
                    int64_t **l_2082 = &l_2083;
                    int32_t l_2086 = 0xCADA8A71L;
                    int32_t l_2124 = (-3L);
                    union U0 *l_2132 = (void*)0;
                    int32_t *l_2151 = (void*)0;
                    int32_t l_2167 = 1L;
                    int32_t *l_2185 = (void*)0;
                    int32_t *l_2186[6][2] = {{&l_1768[1],&l_1768[1]},{&l_1768[1],&l_1768[1]},{&l_1768[1],&l_1768[1]},{&l_1768[1],&l_1768[1]},{&l_1768[1],&l_1768[1]},{&l_1768[1],&l_1768[1]}};
                    int i, j;
                    if (((safe_add_func_uint64_t_u_u(((**g_1644)--), ((l_2081 , ((((l_2082 != l_2084[3][0][4]) | l_2086) == (safe_lshift_func_uint16_t_u_u(((void*)0 == &g_1463), (((**g_767) < l_1781) <= (l_2072 , p_33))))) ^ l_2081)) , 18446744073709551615UL))) , l_2089))
                    { /* block id: 955 */
                        int16_t *l_2101 = &g_2046;
                        uint16_t *l_2113[6][3][4] = {{{&l_2066,&g_592,&g_998[3][6][2],&g_998[0][6][2]},{&l_2066,&g_592,&g_998[0][8][0],&g_998[3][6][2]},{&g_998[2][2][2],&g_998[0][6][2],&g_998[0][6][2],&l_2066}},{{&g_998[2][2][2],&g_998[0][8][0],&g_998[0][8][0],&g_998[2][2][2]},{&l_2066,&l_2066,&g_998[3][6][2],&g_998[0][8][0]},{&l_2066,&g_998[0][6][2],&l_2066,&g_998[0][6][2]}},{{&g_592,&l_2066,&g_998[0][8][0],&g_998[0][6][2]},{&g_998[0][6][2],&g_998[0][6][2],&g_998[0][6][2],&g_998[0][8][0]},{&g_998[2][2][2],&l_2066,(void*)0,&g_998[2][2][2]}},{{&g_592,&g_998[0][8][0],&g_998[3][6][2],&l_2066},{&g_998[0][8][0],&g_998[0][6][2],&g_998[3][6][2],&g_998[3][6][2]},{&g_592,&g_592,(void*)0,&g_998[0][6][2]}},{{&g_998[2][2][2],&g_592,&g_998[0][6][2],&l_2066},{&g_998[0][6][2],&l_2066,&g_998[0][8][0],&g_998[0][6][2]},{&g_592,&l_2066,&l_2066,&l_2066}},{{&l_2066,&g_592,&g_998[3][6][2],&g_998[0][6][2]},{&l_2066,&g_592,&g_998[0][8][0],&g_998[3][6][2]},{&g_998[2][2][2],&g_998[0][6][2],&g_998[0][6][2],&l_2066}}};
                        int8_t ****l_2115 = (void*)0;
                        int8_t ****l_2116 = &l_2114[0][2][2];
                        int32_t l_2123 = 1L;
                        int32_t *l_2125 = &g_274;
                        int32_t *l_2128 = &l_2123;
                        int32_t *l_2129[10];
                        int i, j, k;
                        for (i = 0; i < 10; i++)
                            l_2129[i] = &l_1633;
                        l_2130 = (p_34 , ((*l_2128) = ((p_35 != (safe_div_func_uint32_t_u_u((((safe_lshift_func_int8_t_s_s((((safe_div_func_uint64_t_u_u(0x4B7574A00AF39D26LL, (safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_s((!(((*l_2125) = (((*l_2101) |= 0x4029L) == (safe_sub_func_int32_t_s_s(((safe_rshift_func_int8_t_s_u(l_2086, 0)) != (~((safe_sub_func_int64_t_s_s((l_2068[1][1][5] &= (safe_mul_func_uint16_t_u_u((l_2069 = ((*g_314)++)), (l_2081 |= (((*l_2116) = l_2114[0][2][2]) == &l_1954))))), (((((l_2124 &= (7L || (safe_sub_func_uint8_t_u_u((((safe_lshift_func_uint16_t_u_u(((l_2121 == &p_34) && (*g_376)), 8)) && l_2122) & l_2123), l_2089)))) < l_2122) >= 0xAF2FL) >= 0x14L) & 0xFF65L))) , 0xA566L))), g_394)))) , l_2123)), (***g_1460))), 0x02L)))) , p_35) ^ (*g_910)), l_2126[0][3][2])) != p_33) , l_2127[6]), p_34))) , l_1781)));
                        if (p_33)
                            break;
                        (*g_463) = (void*)0;
                    }
                    else
                    { /* block id: 968 */
                        uint64_t ****l_2142 = &g_1643;
                        uint64_t *****l_2143 = &g_1642;
                        uint16_t *l_2150[9];
                        int i;
                        for (i = 0; i < 9; i++)
                            l_2150[i] = &l_2066;
                        if (l_2081)
                            goto lbl_2131;
                        (*g_1925) = l_2132;
                        l_2124 |= (l_2069 = (0xB58718E5L | (((safe_mod_func_uint16_t_u_u((g_592 = (safe_sub_func_int64_t_s_s((safe_div_func_int8_t_s_s(((l_1773 >= ((*g_314) = (safe_lshift_func_int16_t_s_s((((l_2142 = l_2141) == ((*l_2143) = (void*)0)) < (safe_sub_func_int16_t_s_s(g_2146, (safe_mod_func_int32_t_s_s((l_2068[1][1][5] || ((((*l_2121) = (((p_32 <= 0x6C74L) < l_2149) == (***g_1409))) < l_2081) , p_34)), g_2032.f1))))), 5)))) == 0xD7L), l_2086)), l_2043))), 65535UL)) && l_1705) > p_36)));
                    }
                    if ((l_1705 = (l_2069 |= (*g_1534))))
                    { /* block id: 981 */
                        (*g_2155) = ((*g_463) = &l_1633);
                    }
                    else
                    { /* block id: 984 */
                        int16_t *l_2158[6][3] = {{&g_318,&g_1270,&g_1270},{&g_1270,&l_1791,&g_1375},{&g_318,&l_1791,&g_318},{&l_1791,&g_1270,&g_1375},{&l_1791,&l_1791,&g_1270},{&g_318,&g_1270,&g_1270}};
                        int32_t *l_2160 = &l_1768[0];
                        uint32_t *l_2176 = &g_648[1][1][2];
                        int i, j;
                        (*l_2160) = (l_2157 == l_2158[1][2]);
                        if (l_1773)
                            goto lbl_2131;
                        (*l_2160) |= (safe_div_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u((((((safe_mod_func_int32_t_s_s((l_2167 >= (((0L > ((safe_mul_func_uint8_t_u_u((*g_1411), 0x45L)) == (((safe_add_func_uint32_t_u_u(((!((safe_lshift_func_uint8_t_u_s(l_2175, ((--(*l_2176)) , p_32))) == (((l_2179 == ((safe_rshift_func_uint8_t_u_s(((void*)0 != (*g_1410)), 7)) , &g_1282)) , l_2182) , (*g_910)))) , p_32), l_2130)) | g_2183) <= 1UL))) & p_32) ^ l_2122)), p_34)) & (*g_314)) != (***g_1409)) & 0xBAE54FD5L) >= 1UL), g_826.f1)) || 0x7F7AL), g_115));
                    }
                    if (p_32)
                        goto lbl_2131;
                    l_1705 = (l_2009[0] > (p_32 , p_32));
                }
            }
            return (*g_314);
        }
    }
    if (g_199)
        goto lbl_2131;
    return l_2187[5];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_44(uint32_t  p_45)
{ /* block id: 1 */
    const uint32_t l_64 = 0xB7A2E255L;
    int32_t l_1530 = 1L;
    int32_t l_1538[7] = {(-1L),0x374B6A67L,0x374B6A67L,(-1L),0x374B6A67L,0x374B6A67L,(-1L)};
    int32_t l_1554 = 0x2DF3FAD3L;
    uint64_t l_1555 = 18446744073709551613UL;
    int16_t ****l_1559[2];
    int32_t l_1568 = 0x3BB36AD0L;
    uint32_t l_1580 = 1UL;
    int8_t **l_1587 = &g_910;
    int i;
    for (i = 0; i < 2; i++)
        l_1559[i] = (void*)0;
    for (p_45 = (-10); (p_45 != 11); p_45++)
    { /* block id: 4 */
        uint32_t l_65[10] = {0x21F997ECL,1UL,1UL,0x21F997ECL,0xFBDEDBECL,0x21F997ECL,1UL,1UL,0x21F997ECL,0xFBDEDBECL};
        int8_t *l_1531 = &g_1532;
        int32_t l_1533 = 0x76914EBDL;
        int32_t l_1539 = 1L;
        int32_t l_1540 = 0L;
        int32_t l_1541 = 2L;
        int32_t l_1542 = 3L;
        uint64_t l_1543 = 0x82C96D8380FD969BLL;
        union U0 ****l_1551 = (void*)0;
        union U0 ***l_1553 = &g_258;
        union U0 ****l_1552 = &l_1553;
        uint32_t l_1564 = 0x20AB6CD9L;
        int32_t **l_1573[7][7] = {{&g_464,&g_464,&g_464,&g_464,&g_464,&g_464,&g_464},{&g_464,&g_464,&g_464,(void*)0,&g_464,&g_464,&g_464},{&g_464,&g_464,(void*)0,&g_464,&g_464,&g_464,&g_464},{&g_464,&g_464,&g_464,&g_464,&g_464,&g_464,&g_464},{&g_464,&g_464,&g_464,&g_464,&g_464,&g_464,&g_464},{&g_464,&g_464,(void*)0,&g_464,&g_464,(void*)0,&g_464},{&g_464,&g_464,&g_464,&g_464,&g_464,(void*)0,&g_464}};
        int16_t l_1594 = 0xAD09L;
        uint64_t *l_1598[7][5] = {{&l_1543,&g_162,&l_1543,&l_1543,&l_1543},{&g_162,&g_162,(void*)0,&l_1555,&l_1555},{&g_367,&l_1543,(void*)0,&l_1543,&g_367},{&l_1555,&l_1555,(void*)0,&g_162,&g_162},{&l_1543,&l_1543,&l_1543,&g_162,&l_1543},{&l_1555,&g_162,&l_1555,&l_1555,&g_162},{&g_367,&g_162,(void*)0,&g_162,&g_367}};
        uint64_t ** const l_1597 = &l_1598[3][3];
        uint32_t l_1599 = 0x46D87A78L;
        int i, j;
    }
    return l_1530;
}


/* ------------------------------------------ */
/* 
 * reads : g_463 g_464 g_910 g_193 g_199 g_367 g_315 g_314 g_349 g_163 g_101 g_387 g_648 g_964 g_767 g_264 g_105 g_998 g_318 g_149 g_718 g_113 g_295 g_826.f1 g_1216 g_274 g_298 g_1316 g_1317 g_137 g_1339 g_1218 g_747.f1 g_1355 g_195 g_1375 g_125 g_177 g_1389 g_394 g_1409 g_766 g_1464 g_528.f0 g_1464.f1 g_1410 g_1411 g_162 g_1520 g_1461
 * writes: g_464 g_274 g_314 g_166.f1 g_190 g_592 g_826.f1 g_315 g_367 g_101 g_998 g_316 g_318 g_149 g_199 g_359.f1 g_1217 g_115 g_1088.f1 g_1281 g_162 g_105 g_394 g_100 g_1409 g_747.f1 g_1460 g_1463 g_258 g_113
 */
static uint8_t  func_56(uint32_t  p_57, uint16_t  p_58, int32_t  p_59, uint64_t  p_60)
{ /* block id: 465 */
    int32_t *l_932 = (void*)0;
    int32_t l_953 = 1L;
    int16_t *l_973 = &g_318;
    int32_t l_982 = (-1L);
    int32_t l_993 = 0xA27688CAL;
    int32_t l_994 = 0x93F2D0B4L;
    int32_t l_995 = 0xA38D5A9EL;
    int32_t l_996[10][6][2] = {{{0x9DD4AF02L,0x3DA5BC73L},{1L,0x2385C664L},{0x3B0AE5BBL,0x396452B2L},{0L,0x3B0AE5BBL},{6L,0xFC04F6D7L},{6L,0x3B0AE5BBL}},{{0L,0x396452B2L},{0x3B0AE5BBL,0x2385C664L},{1L,0x3DA5BC73L},{0x9DD4AF02L,0L},{0L,0x084B975AL},{0x2B3E7D3CL,(-1L)}},{{(-1L),6L},{0xB3539AFFL,0L},{0x3DA5BC73L,0L},{0x084B975AL,(-1L)},{0L,(-1L)},{0x084B975AL,0L}},{{0x3DA5BC73L,0L},{0xB3539AFFL,6L},{(-1L),(-1L)},{0x2B3E7D3CL,0x084B975AL},{0L,0L},{0x9DD4AF02L,0x3DA5BC73L}},{{1L,0x2385C664L},{0x3B0AE5BBL,0x396452B2L},{0L,0x3B0AE5BBL},{6L,0xFC04F6D7L},{6L,0x3B0AE5BBL},{0L,0x396452B2L}},{{0x3B0AE5BBL,0x2385C664L},{1L,0x3DA5BC73L},{0x9DD4AF02L,0L},{0L,0x084B975AL},{0x2B3E7D3CL,(-1L)},{(-1L),6L}},{{0xB3539AFFL,0L},{0x3DA5BC73L,0L},{0x084B975AL,(-1L)},{0L,(-1L)},{0x084B975AL,0L},{0x3DA5BC73L,0L}},{{0xB3539AFFL,6L},{(-1L),(-1L)},{0x2B3E7D3CL,0x084B975AL},{0L,0L},{0x9DD4AF02L,0x3DA5BC73L},{1L,0x2385C664L}},{{0x3B0AE5BBL,0x396452B2L},{0L,0x3B0AE5BBL},{6L,0xFC04F6D7L},{6L,0x3B0AE5BBL},{0L,0x396452B2L},{0x3B0AE5BBL,0x2385C664L}},{{1L,0x3DA5BC73L},{0x9DD4AF02L,0L},{0L,0x084B975AL},{0x2B3E7D3CL,(-1L)},{(-1L),6L},{0xB3539AFFL,0L}}};
    uint16_t l_1027 = 65529UL;
    uint8_t l_1028 = 251UL;
    uint64_t l_1101 = 0x889B138B5B0535ADLL;
    const int8_t * const l_1117[7] = {&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1};
    const int8_t * const *l_1116[10] = {(void*)0,&l_1117[4],(void*)0,&l_1117[4],(void*)0,&l_1117[4],(void*)0,&l_1117[4],(void*)0,&l_1117[4]};
    uint8_t l_1148 = 0x50L;
    uint64_t l_1213[9];
    union U0 **l_1493 = &g_259[0][0][1];
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_1213[i] = 0x2204CFFA8B5F48A3LL;
lbl_1029:
    (*g_463) = l_932;
lbl_1030:
    (*g_463) = (*g_463);
    for (g_274 = 3; (g_274 >= 0); g_274 -= 1)
    { /* block id: 470 */
        const uint32_t l_933 = 0x0E791D7CL;
        int32_t **l_942 = &l_932;
        uint16_t **l_944 = &g_314;
        uint16_t *l_947 = &g_592;
        uint16_t *l_952 = &g_315[2][0];
        int8_t *l_970 = &g_359[2].f1;
        int32_t l_990 = (-1L);
        int32_t l_991 = 1L;
        int32_t l_992 = 0x3A0DD5B5L;
        int32_t l_997 = 0x015E0AAFL;
        uint8_t l_1003 = 1UL;
        uint64_t *l_1025 = (void*)0;
        uint64_t **l_1024 = &l_1025;
        uint64_t ***l_1023 = &l_1024;
        union U0 * const l_1181 = &g_166[2];
        l_953 = (0xC3L != (l_933 & (safe_rshift_func_int8_t_s_u((g_826.f1 = (safe_rshift_func_uint16_t_u_u(((*l_947) = (!(((~(safe_lshift_func_int8_t_s_s((((void*)0 == l_942) | 0xD7L), 0))) != (!(((*l_944) = &p_58) != &p_58))) || ((*g_910) = (~(safe_unary_minus_func_int8_t_s(5L))))))), 11))), (safe_add_func_int32_t_s_s(((safe_mod_func_uint64_t_u_u((((*l_952) &= (((g_193 != g_199) , g_367) , 5UL)) , 0x7433C5678A3E8E34LL), 0xD3923814609EC53BLL)) ^ (-1L)), l_953))))));
        if ((safe_add_func_int64_t_s_s((((l_953 && (((*g_314) , 1L) ^ (safe_mod_func_int16_t_s_s((safe_unary_minus_func_int16_t_s((g_349[8] , ((p_60 || 0x67L) >= ((((!((((safe_add_func_uint16_t_u_u((*g_314), p_58)) == (*g_163)) && g_387[1][5][1]) , p_57)) == p_57) , p_59) >= p_57))))), p_58)))) > p_59) | g_648[0][1][4]), 1UL)))
        { /* block id: 477 */
            int8_t *l_969 = &g_166[3].f1;
            uint64_t *l_971 = (void*)0;
            uint64_t *l_972[4];
            int32_t l_974 = 0L;
            int32_t *l_975 = (void*)0;
            int32_t *l_976 = (void*)0;
            int32_t *l_977 = &g_101;
            int i;
            for (i = 0; i < 4; i++)
                l_972[i] = (void*)0;
            if (p_59)
                break;
            (*l_977) ^= ((g_964 , (g_367 = (((safe_lshift_func_int16_t_s_u((((safe_rshift_func_int8_t_s_u(p_57, 6)) < 0xAD87L) , (**g_767)), 7)) >= ((l_969 = &g_190) == (l_970 = l_970))) <= l_953))) < (((p_59 >= (l_973 == (void*)0)) && 0xA4B99FD9L) | l_974));
        }
        else
        { /* block id: 483 */
            int32_t l_978 = 7L;
            int32_t *l_979 = (void*)0;
            int32_t *l_980 = &l_953;
            int32_t *l_981 = &l_953;
            int32_t *l_983 = &g_101;
            int32_t *l_984 = &g_101;
            int32_t *l_985 = &l_978;
            int32_t *l_986 = &g_316;
            int32_t *l_987 = &l_982;
            int32_t *l_988 = &l_982;
            int32_t *l_989[5] = {&l_982,&l_982,&l_982,&l_982,&l_982};
            uint8_t *l_1019 = &g_149;
            uint8_t *l_1022 = &l_1003;
            uint64_t ****l_1026[4];
            int i;
            for (i = 0; i < 4; i++)
                l_1026[i] = (void*)0;
            g_998[0][6][2]++;
            if (((*l_988) = (safe_lshift_func_int8_t_s_s(((void*)0 == l_973), 3))))
            { /* block id: 486 */
                ++l_1003;
            }
            else
            { /* block id: 488 */
                uint64_t l_1006[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_1006[i] = 18446744073709551610UL;
                --l_1006[0];
            }
            (*l_986) = (*l_988);
            (*l_988) = ((safe_lshift_func_uint8_t_u_s(((safe_mod_func_uint8_t_u_u(p_57, ((safe_div_func_int8_t_s_s((-1L), (safe_sub_func_int16_t_s_s(((*l_973) &= (**g_767)), (safe_mul_func_uint8_t_u_u(((*l_1022) = (--(*l_1019))), ((p_60 , ((l_1023 = (((void*)0 == l_1023) , (void*)0)) == &g_797)) ^ (((l_933 , l_1027) | 7L) >= l_1028)))))))) | (*g_314)))) >= g_718), 5)) != 0x8B56L);
        }
        if (g_367)
            goto lbl_1029;
        if (p_60)
            goto lbl_1030;
        for (l_992 = 0; (l_992 <= 1); l_992 += 1)
        { /* block id: 502 */
            uint32_t l_1046 = 9UL;
            uint16_t l_1081 = 0x0D32L;
            int32_t l_1126[7][4][7] = {{{0L,0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL},{0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL},{0L,1L,0x638D871DL,0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L},{0x9266D98BL,0x4024FD9CL,0xFE331976L,0x4024FD9CL,0x9266D98BL,0x4024FD9CL,0xFE331976L}},{{0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L,0L,0L,1L},{0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL},{0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL,0x638D871DL},{0x9266D98BL,(-2L),0xFE331976L,(-2L),0x9266D98BL,(-2L),0xFE331976L}},{{0L,0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL},{0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL},{0L,1L,0x638D871DL,0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L},{0x9266D98BL,0x4024FD9CL,0xFE331976L,0x4024FD9CL,0x9266D98BL,0x4024FD9CL,0xFE331976L}},{{0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L,0L,0L,1L},{0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL},{0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL,0x638D871DL},{0x9266D98BL,(-2L),0xFE331976L,(-2L),0x9266D98BL,(-2L),0xFE331976L}},{{0L,0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL},{0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL},{0L,1L,0x638D871DL,0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L},{0x9266D98BL,0x4024FD9CL,0xFE331976L,0x4024FD9CL,0x9266D98BL,0x4024FD9CL,0xFE331976L}},{{0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L,0L,0L,1L},{0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL},{0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL,0x638D871DL},{0x9266D98BL,(-2L),0xFE331976L,(-2L),0x9266D98BL,(-2L),0xFE331976L}},{{0L,0xEA81DCDBL,1L,1L,0xEA81DCDBL,0L,0x638D871DL},{0x79A1894CL,0x4024FD9CL,0x79A1894CL,(-2L),0x79A1894CL,0x4024FD9CL,0x79A1894CL},{0L,1L,0x638D871DL,0xEA81DCDBL,0xEA81DCDBL,0x638D871DL,1L},{0x9266D98BL,0x4024FD9CL,0xFE331976L,0x4024FD9CL,0x9266D98BL,0x4024FD9CL,0xFE331976L}}};
            union U0 * const *l_1147 = &g_259[0][1][0];
            union U0 * const **l_1146[1];
            int64_t l_1150 = 0x9FE3FA8AB09286F5LL;
            uint32_t l_1151[2];
            uint64_t ***l_1183 = &l_1024;
            uint32_t l_1208 = 0x9CC70F92L;
            int32_t *l_1211 = &l_990;
            int32_t *l_1212[5];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1146[i] = &l_1147;
            for (i = 0; i < 2; i++)
                l_1151[i] = 0x9C82DD19L;
            for (i = 0; i < 5; i++)
                l_1212[i] = &l_1126[4][3][6];
            for (g_199 = 0; (g_199 <= 1); g_199 += 1)
            { /* block id: 505 */
                uint64_t l_1051 = 0x01AF1FFA57124870LL;
                int32_t l_1080 = 0xB9478B1BL;
                for (p_58 = 0; (p_58 <= 3); p_58 += 1)
                { /* block id: 508 */
                    int64_t l_1075[7] = {0x772218B30191D4F6LL,0x583B01B5C7FECD33LL,0x772218B30191D4F6LL,0x772218B30191D4F6LL,0x583B01B5C7FECD33LL,0x772218B30191D4F6LL,0x772218B30191D4F6LL};
                    int i;
                    for (l_997 = 0; (l_997 <= 1); l_997 += 1)
                    { /* block id: 511 */
                        int32_t *l_1031 = &l_953;
                        int32_t l_1038 = 0xBB778D8DL;
                        uint8_t *l_1039 = &l_1028;
                        uint64_t l_1074[4][1];
                        int8_t *l_1076 = &g_826.f1;
                        int32_t *l_1077 = &l_996[4][1][0];
                        int i, j;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_1074[i][j] = 18446744073709551611UL;
                        }
                        (*l_1031) = g_113[(p_58 + 2)][l_992];
                        (*l_1077) ^= (((*l_1076) |= ((*l_970) = ((((g_315[l_992][l_997]++) & (((p_60 < (safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s((g_295 && l_1038), 4)), (++(*l_1039))))) | ((((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u(l_1046, 0)), l_1046)) && (safe_add_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u(((((l_1051 , ((safe_sub_func_uint32_t_u_u((safe_div_func_int64_t_s_s(p_59, (safe_mod_func_int16_t_s_s((safe_rshift_func_int16_t_s_s((p_60 & ((safe_mul_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((safe_div_func_int16_t_s_s(1L, 4UL)) || 0x04DA9AC2L), (-10L))), l_1051)), 0x4ED1L)) && 0x93C2L), (*l_1031))), (*g_314))), l_1074[1][0])) , l_1075[6])), l_1046)), (**g_767))))), p_57)) || 0xF14AL)) & 1UL) > 0xF5L) , l_1075[6]), l_1075[6])) ^ 0xC00C8D6DL), 0x71B94DAEL))) & (*g_314)) || (**g_767))) && l_1051)) == 0xE44B0A3FL) & p_59))) & 1UL);
                        if (l_1051)
                            continue;
                    }
                }
                for (l_995 = 0; (l_995 <= 3); l_995 += 1)
                { /* block id: 523 */
                    l_1080 = (safe_rshift_func_uint16_t_u_s(((*g_314) , (l_1046 , 65534UL)), (&g_195[3][3] != (void*)0)));
                    if (l_1046)
                        goto lbl_1029;
                }
            }
        }
    }
    for (l_982 = 0; (l_982 <= 2); l_982 += 1)
    { /* block id: 573 */
        int16_t l_1234[9][10][2] = {{{0x4184L,1L},{0L,1L},{0x4184L,0x3FF4L},{0xE067L,0xC815L},{0xE891L,0L},{0xA868L,0x22F9L},{0xE067L,0xE7D7L},{(-6L),1L},{0xD9FAL,1L},{0x4184L,0xE7D7L}},{{0x02B4L,0xC815L},{0xA868L,0x1A14L},{(-6L),0xDB16L},{(-1L),7L},{0L,0x9D00L},{4L,0x22F9L},{0x3A5FL,7L},{0x8419L,0xA4E9L},{(-6L),0x2566L},{1L,0xDB16L}},{{0x8419L,0x3033L},{0L,0x22F9L},{0xF844L,0x22F9L},{0L,0x3033L},{0x8419L,0xDB16L},{1L,0x2566L},{(-6L),0xA4E9L},{0x8419L,7L},{0x3A5FL,0x22F9L},{4L,0x9D00L}},{{0L,7L},{(-1L),0xDB16L},{(-6L),0x1A14L},{(-6L),0xDB16L},{(-1L),7L},{0L,0x9D00L},{4L,0x22F9L},{0x3A5FL,7L},{0x8419L,0xA4E9L},{(-6L),0x2566L}},{{1L,0xDB16L},{0x8419L,0x3033L},{0L,0x22F9L},{0xF844L,0x22F9L},{0L,0x3033L},{0x8419L,0xDB16L},{1L,0x2566L},{(-6L),0xA4E9L},{0x8419L,7L},{0x3A5FL,0x22F9L}},{{4L,0x9D00L},{0L,7L},{(-1L),0xDB16L},{(-6L),0x1A14L},{(-6L),0xDB16L},{(-1L),7L},{0L,0x9D00L},{4L,0x22F9L},{0x3A5FL,7L},{0x8419L,0xA4E9L}},{{(-6L),0x2566L},{1L,0xDB16L},{0x8419L,0x3033L},{0L,0x22F9L},{0xF844L,0x22F9L},{0L,0x3033L},{0x8419L,0xDB16L},{1L,0x2566L},{(-6L),0xA4E9L},{0x8419L,7L}},{{0x3A5FL,0x22F9L},{4L,0x9D00L},{0L,7L},{(-1L),0xDB16L},{(-6L),0x1A14L},{(-6L),0xDB16L},{(-1L),7L},{0L,0x9D00L},{4L,0x22F9L},{0x3A5FL,7L}},{{0x8419L,0xA4E9L},{(-6L),0x2566L},{1L,0xDB16L},{0x8419L,0x3033L},{0L,0x22F9L},{0xF844L,0x22F9L},{0L,0x3033L},{0x8419L,0xDB16L},{1L,0x2566L},{(-6L),0xA4E9L}}};
        int32_t l_1236[7][5] = {{0L,0L,(-1L),1L,0xAFD65CD2L},{0xAB21D30FL,0x5669D303L,0x5669D303L,0xAB21D30FL,0L},{0xAB21D30FL,1L,0xE9B6666FL,0xE9B6666FL,1L},{0L,0x5669D303L,0xE9B6666FL,(-1L),(-1L)},{0x5669D303L,0L,0x5669D303L,0xE9B6666FL,(-1L)},{1L,0xAB21D30FL,(-1L),0xAB21D30FL,1L},{0x5669D303L,0xAB21D30FL,0L,0xE9B6666FL,0xAFD65CD2L}};
        uint32_t l_1263 = 4294967291UL;
        int8_t l_1319 = (-9L);
        int32_t l_1364 = (-5L);
        uint16_t * const l_1426 = &g_592;
        int16_t ***l_1459 = (void*)0;
        uint32_t l_1483 = 0xEEF938D0L;
        int i, j, k;
        (*g_1216) = &l_1117[2];
        for (p_57 = 1; (p_57 <= 5); p_57 += 1)
        { /* block id: 577 */
            uint32_t l_1224 = 0UL;
            int32_t l_1250 = 0xD7BF62CFL;
            int32_t l_1252 = (-10L);
            int32_t l_1253 = (-7L);
            int32_t l_1254 = 0x2A9776DFL;
            int32_t l_1255 = 2L;
            int32_t l_1256 = 0x7CAAE651L;
            int32_t l_1257 = 9L;
            int32_t l_1258 = 8L;
            int32_t l_1259[10] = {0x8344A0D3L,0L,0x8344A0D3L,0x8344A0D3L,0L,0x8344A0D3L,0x8344A0D3L,0L,0x8344A0D3L,0x8344A0D3L};
            union U0 *l_1291 = &g_166[0];
            int i;
            for (g_274 = 5; (g_274 >= 0); g_274 -= 1)
            { /* block id: 580 */
                int16_t l_1233[1][6];
                int32_t l_1235 = (-1L);
                int32_t l_1237 = 0xDFBD7546L;
                int32_t l_1239 = 0xC837D0B2L;
                int32_t l_1240 = 1L;
                int32_t l_1241 = (-1L);
                int32_t l_1242 = 1L;
                int32_t l_1244 = 1L;
                int32_t l_1245 = (-4L);
                int32_t l_1260 = 0x49AA7AB3L;
                int32_t l_1261 = 0x65589A85L;
                int32_t l_1262 = 0x4C5DF28DL;
                int16_t l_1268 = 1L;
                int32_t l_1269[7][1];
                int8_t ***l_1283 = &g_1282;
                union U0 *l_1290 = &g_166[1];
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 6; j++)
                        l_1233[i][j] = 1L;
                }
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_1269[i][j] = (-3L);
                }
                for (g_115 = 5; (g_115 >= 0); g_115 -= 1)
                { /* block id: 583 */
                    int8_t l_1238 = (-3L);
                    int32_t l_1243[1][10] = {{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L}};
                    int16_t l_1251 = 4L;
                    int i, j;
                    for (g_1088.f1 = 2; (g_1088.f1 >= 0); g_1088.f1 -= 1)
                    { /* block id: 586 */
                        int32_t *l_1219 = &l_993;
                        int32_t *l_1220 = (void*)0;
                        int32_t *l_1221 = (void*)0;
                        int32_t *l_1222 = &g_101;
                        int32_t *l_1223 = (void*)0;
                        int32_t *l_1227 = &l_996[1][1][0];
                        int32_t *l_1228 = &l_995;
                        int32_t *l_1229 = &l_995;
                        int32_t *l_1230 = &g_101;
                        int32_t *l_1231 = &l_993;
                        int32_t *l_1232[6] = {(void*)0,&l_996[4][1][0],&l_996[4][1][0],(void*)0,&l_996[4][1][0],&l_996[4][1][0]};
                        uint16_t l_1246 = 0xF8B3L;
                        int i;
                        l_1224--;
                        ++l_1246;
                    }
                    for (l_1241 = 2; (l_1241 >= 0); l_1241 -= 1)
                    { /* block id: 592 */
                        int32_t *l_1249[3];
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_1249[i] = &l_1245;
                        ++l_1263;
                    }
                }
                if (g_298[l_982][p_57][g_274])
                    break;
                for (l_1148 = 0; (l_1148 <= 5); l_1148 += 1)
                { /* block id: 599 */
                    int32_t *l_1266 = &l_1245;
                    int32_t *l_1267[3];
                    uint16_t l_1271 = 0xD24DL;
                    int8_t **l_1280[1][3];
                    int8_t ***l_1279 = &l_1280[0][1];
                    int8_t ****l_1278[4][5];
                    uint64_t *l_1297 = &g_367;
                    uint64_t *l_1298 = &g_162;
                    union U0 ***l_1315 = &g_258;
                    union U0 ****l_1314 = &l_1315;
                    union U0 *****l_1313 = &l_1314;
                    uint16_t l_1320 = 0xA643L;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_1267[i] = &l_1242;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_1280[i][j] = &g_910;
                    }
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 5; j++)
                            l_1278[i][j] = &l_1279;
                    }
                    ++l_1271;
                    (*l_1266) |= (safe_mul_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u((g_998[(g_274 + 1)][g_274][l_982] = ((l_1283 = (g_1281[4] = (void*)0)) == ((safe_sub_func_uint16_t_u_u(g_298[l_982][(g_274 + 1)][(p_57 + 4)], (safe_sub_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_s((l_1290 == l_1291), g_298[l_982][(l_1148 + 1)][(l_982 + 4)])) <= (~(((safe_mul_func_int8_t_s_s(((safe_div_func_uint64_t_u_u(((*l_1298) = ((*l_1297) = (0x5AL & 0x71L))), p_59)) == (p_59 <= 0x2FL)), 0xE8L)) && 1UL) == p_60))), l_1261)))) , (void*)0))), p_60)) , p_59), l_1258));
                    l_1320 &= (0xD4436464E6294DBBLL ^ ((((*l_1266) ^= ((((0x26L || (safe_mod_func_int64_t_s_s(p_59, (safe_mod_func_uint64_t_u_u((safe_div_func_int32_t_s_s(l_1252, (safe_add_func_uint64_t_u_u(((0x87L >= ((safe_div_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(((((**g_767) ^= l_1259[0]) , ((((p_57 | 0x3E343C9FFDB68950LL) & (safe_lshift_func_uint16_t_u_s((((*l_1313) = (void*)0) != g_1316), 8))) , 0UL) , g_1317)) == &g_1318[0]), 0xC1C7L)), l_1236[6][3])) == l_1319)) | l_1256), (-2L))))), p_59))))) && l_1256) < (*g_314)) && l_1236[6][3])) , l_1263) > p_59));
                }
            }
            if ((*g_137))
                continue;
            for (l_1254 = 0; (l_1254 <= 5); l_1254 += 1)
            { /* block id: 616 */
                int64_t *l_1340 = &g_394;
                int64_t *l_1341 = &g_100;
                int32_t l_1346 = (-1L);
                uint64_t l_1376 = 0x737AC1DB59231C02LL;
                int32_t l_1381 = 0x943A9647L;
                const int16_t *l_1403 = &g_115;
                const int16_t **l_1402 = &l_1403;
                const int16_t ***l_1401 = &l_1402;
                const int16_t ****l_1400 = &l_1401;
                int i, j, k;
                if ((safe_rshift_func_int8_t_s_u((((((safe_sub_func_int8_t_s_s((safe_sub_func_uint64_t_u_u(((((l_1252 = (safe_mod_func_int64_t_s_s(((*l_1341) = (safe_add_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(((0xA63CL < g_298[l_982][p_57][l_1254]) > (&p_58 != &g_998[2][0][0])), l_1257)), (((safe_add_func_int16_t_s_s((g_1339 , (((l_1236[0][2] = g_298[l_982][p_57][l_1254]) != p_59) < ((*l_1340) = (0x8C547F76L || g_298[l_982][p_57][l_1254])))), 1L)) > p_57) == p_59))), 1UL))), l_1263))) < 0x3BL) > p_59) == g_298[l_982][p_57][l_1254]), g_298[l_982][p_57][l_1254])), (*g_1218))) , 1UL) | g_105) , 0x3868702AL) > p_57), l_1213[2])))
                { /* block id: 621 */
                    uint64_t * const l_1361 = &g_367;
                    uint64_t * const *l_1360 = &l_1361;
                    uint64_t * const **l_1359 = &l_1360;
                    uint64_t * const ***l_1358 = &l_1359;
                    int32_t l_1362 = 2L;
                    for (g_199 = 0; (g_199 <= 5); g_199 += 1)
                    { /* block id: 624 */
                        int32_t *l_1363 = &l_1253;
                        l_1346 |= (safe_mod_func_int32_t_s_s(((void*)0 != &g_766), (safe_add_func_int32_t_s_s(p_58, p_60))));
                        l_1364 |= (!((*l_1363) |= ((safe_lshift_func_int16_t_s_s((safe_add_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(((*g_314) = ((((void*)0 != &g_1318[1]) ^ (0xED000A9202832290LL == ((!((g_1355 , 0xC8E0L) != ((*l_973) |= ((p_57 || ((l_1236[1][3] ^ (((safe_lshift_func_int8_t_s_s(((l_1358 != &l_1359) || p_60), 4)) != 0L) && p_58)) >= 1L)) , (*g_264))))) , 0x0868C8836C7BAE4FLL))) != l_1346)), p_57)) ^ l_1362), 0x9B1DL)), 2)) >= p_60)));
                        (*g_463) = &l_1364;
                    }
                    if (p_58)
                        break;
                }
                else
                { /* block id: 633 */
                    int32_t l_1365 = 0x5D0739A2L;
                    int32_t *l_1366[7][5][7] = {{{&l_1255,&l_1252,&l_1236[6][3],&l_1258,&l_996[1][1][1],&l_1346,&l_1259[1]},{&l_996[4][1][0],&l_1255,&l_1236[6][3],&l_1254,&l_1236[6][3],&l_1236[6][3],&l_1236[5][3]},{&l_993,(void*)0,(void*)0,&l_996[4][1][0],(void*)0,&l_1258,&l_1346},{&l_1253,(void*)0,&l_996[4][1][0],&l_993,&g_316,&l_1346,(void*)0},{&l_1258,&l_1254,&l_993,(void*)0,&l_993,&l_1254,&l_1258}},{{&l_1236[6][3],&l_953,&l_1346,&l_1259[0],(void*)0,(void*)0,&l_993},{&l_1346,&l_993,&l_1346,(void*)0,&l_1236[1][3],(void*)0,(void*)0},{&l_1364,&l_1253,&l_1346,&l_1346,&l_1252,&l_1259[0],&l_993},{&l_1255,&g_316,&l_993,(void*)0,&l_953,&l_996[6][2][1],&g_101},{&l_996[1][1][1],&l_995,&l_996[4][1][0],&g_101,&l_996[6][0][0],&l_1258,&g_316}},{{(void*)0,&l_1258,(void*)0,&l_1346,(void*)0,&l_1236[4][0],&l_1236[6][3]},{(void*)0,&l_1346,&l_1236[6][3],&l_1252,(void*)0,(void*)0,&l_1250},{&l_1259[1],&l_1236[1][3],&l_1236[6][3],&l_1236[5][3],&l_1259[2],&l_1259[3],&l_1259[0]},{&l_1257,&l_1236[1][3],&l_1250,(void*)0,(void*)0,(void*)0,&l_1236[6][3]},{&l_1254,&l_1346,&l_995,&l_1364,&l_1258,&l_1252,&l_1236[4][0]}},{{&l_995,&l_1258,&l_1258,&l_1255,&l_1236[5][3],(void*)0,(void*)0},{&l_953,&l_995,&l_1236[5][3],(void*)0,&l_1259[8],&l_1364,&l_1364},{&l_1236[4][0],&g_316,&l_993,&g_316,&l_1236[4][0],&l_1236[6][3],&l_1250},{&l_1236[5][3],&l_1253,&g_316,&l_953,&l_1259[0],&l_996[4][1][0],&l_1254},{(void*)0,&l_993,(void*)0,&l_1258,&l_1236[6][3],(void*)0,&l_1259[3]}},{{&l_1236[5][3],&l_953,(void*)0,(void*)0,&l_1256,&l_996[6][0][0],&l_996[6][2][1]},{&l_1236[4][0],&l_1254,&g_316,&l_996[6][0][0],(void*)0,(void*)0,&l_993},{&l_953,(void*)0,&l_1256,&l_993,(void*)0,(void*)0,&l_1253},{&l_995,(void*)0,(void*)0,&l_1346,&l_1258,&g_316,(void*)0},{&l_1236[6][3],&l_982,&g_316,&l_1346,&l_1258,&l_1258,&g_316}},{{&l_1236[6][3],(void*)0,&l_996[5][2][1],&l_996[6][0][0],(void*)0,(void*)0,&g_316},{&l_1250,&l_1257,&g_101,&l_996[6][2][1],&g_316,&l_1258,(void*)0},{&l_995,(void*)0,(void*)0,&l_996[4][1][0],&l_996[6][0][0],(void*)0,&l_1256},{&l_1258,&l_1255,(void*)0,&g_101,&l_1252,&l_993,&l_996[5][2][1]},{&l_1236[5][3],&g_316,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_993,&l_1258,&l_993,&l_1259[0],&l_982,&l_996[4][1][0],&l_996[6][2][1]},{&g_316,&l_1236[6][3],&l_1258,&l_1236[6][3],(void*)0,(void*)0,&l_1236[6][3]},{(void*)0,&l_1259[2],&l_996[4][1][0],&l_1236[5][3],&l_1259[1],&l_996[4][1][0],&l_996[4][1][0]},{(void*)0,&l_993,(void*)0,&l_1254,&l_1250,(void*)0,&g_316},{&g_316,&l_1259[1],(void*)0,&l_1259[8],&l_1346,&l_993,(void*)0}}};
                    int i, j, k;
                    l_1236[6][3] ^= (l_1365 == p_57);
                    (*g_463) = &l_1346;
                    for (l_1263 = 0; (l_1263 <= 5); l_1263 += 1)
                    { /* block id: 638 */
                        int32_t *l_1371[3][4][4] = {{{&g_316,&l_993,&g_101,&l_1259[6]},{(void*)0,&l_982,(void*)0,&l_1259[6]},{&g_101,&l_993,&g_316,&l_1250},{&g_101,(void*)0,&l_993,&l_993}},{{&l_993,&l_993,&l_993,(void*)0},{&g_101,&l_1252,&g_316,(void*)0},{&g_101,&g_316,(void*)0,&g_316},{(void*)0,&g_316,&g_101,(void*)0}},{{&g_316,&l_1252,&g_101,(void*)0},{&l_993,&l_993,&l_993,&l_993},{&l_993,(void*)0,&g_101,&l_1250},{&g_316,&l_993,&g_101,&l_1259[6]}}};
                        int i, j, k;
                        l_993 = (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u(((*g_314) = (((&l_1236[3][1] != ((*g_463) = l_1371[0][3][2])) > (g_113[(l_1263 + 1)][(l_982 + 1)] <= (l_1253 &= (p_57 == (((!(safe_lshift_func_uint8_t_u_u(((void*)0 == &g_1318[1]), 6))) != 0x20E5L) == p_59))))) && (g_195[1][0] >= p_60))), (*g_264))) >= g_1375), g_125));
                        if (l_1250)
                            continue;
                        if (p_60)
                            break;
                    }
                }
                if (p_60)
                { /* block id: 647 */
                    l_1376 ^= p_57;
                }
                else
                { /* block id: 649 */
                    int32_t *l_1377 = &l_1250;
                    int32_t *l_1378 = &l_1257;
                    int32_t *l_1379 = &l_1257;
                    int32_t *l_1380[3][2][8] = {{{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346},{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346}},{{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346},{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346}},{{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346},{&g_101,&l_1346,(void*)0,&l_1346,&g_101,&l_1346,(void*)0,&l_1346}}};
                    uint8_t l_1382 = 0x80L;
                    int8_t * const l_1396[5][9] = {{(void*)0,&g_747.f1,(void*)0,&l_1319,&g_1088.f1,&g_826.f1,(void*)0,&g_826.f1,&g_1088.f1},{&g_125,&g_125,&g_125,&g_125,&g_359[2].f1,(void*)0,&g_125,&g_125,(void*)0},{&g_1088.f1,&g_826.f1,(void*)0,&g_826.f1,&g_1088.f1,&l_1319,(void*)0,&g_747.f1,(void*)0},{&g_125,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1,&g_125,&g_359[2].f1,&g_359[2].f1,&g_359[2].f1},{&g_1088.f1,&l_1319,(void*)0,&g_747.f1,(void*)0,&l_1319,&g_1088.f1,&g_826.f1,(void*)0}};
                    uint64_t *l_1421 = &g_367;
                    int i, j, k;
                    --l_1382;
                    for (g_592 = 0; (g_592 <= 5); g_592 += 1)
                    { /* block id: 653 */
                        const int16_t *****l_1404 = &l_1400;
                        uint8_t ** const **l_1412 = (void*)0;
                        uint8_t ** const **l_1413 = (void*)0;
                        uint8_t ** const **l_1414 = &g_1409;
                        uint64_t *l_1415 = &g_367;
                        int32_t l_1416 = (-4L);
                        (*l_1377) ^= (0x18L || (l_1255 &= ((((((((*g_314) ^= (g_113[0][0] >= 0x83293387AD685765LL)) , ((safe_rshift_func_uint16_t_u_u((g_177 , (0L & (safe_mod_func_uint16_t_u_u((*g_314), ((g_1389[1][1][2] , p_59) , (safe_mul_func_uint16_t_u_u(((safe_add_func_int64_t_s_s((safe_div_func_uint8_t_u_u(((void*)0 == l_1396[4][2]), p_57)), g_298[0][5][1])) , g_298[l_982][p_57][l_1254]), 0x29A5L))))))), 6)) != p_58)) || l_1253) >= (-5L)) , l_1254) > g_387[0][0][1]) | l_1256)));
                        (*l_1377) = (18446744073709551615UL > (safe_mul_func_int8_t_s_s(((+(((((*l_1404) = l_1400) != (void*)0) , (((g_100 = (((*l_1401) == (***l_1404)) | ((*l_1415) = (&g_810 == ((*l_1414) = ((p_57 , (((*l_1378) & ((*l_1340) ^= (safe_div_func_uint32_t_u_u(((*g_264) | (-1L)), 0x646A1079L)))) , p_57)) , g_1409)))))) >= p_59) >= l_1416)) >= (*g_314))) > p_60), (*l_1378))));
                    }
                    if ((safe_mod_func_int8_t_s_s((p_57 , (l_1236[2][3] = (safe_mod_func_uint16_t_u_u((((*l_1421) = (p_60 ^= l_1250)) != (safe_rshift_func_int8_t_s_s(l_1259[0], 7))), ((*g_314) &= g_298[l_982][p_57][l_1254]))))), (safe_lshift_func_int8_t_s_s((l_1426 != (void*)0), 0)))))
                    { /* block id: 668 */
                        int32_t *l_1427 = &l_1236[5][3];
                        (*g_463) = l_1427;
                    }
                    else
                    { /* block id: 670 */
                        union U0 *l_1428 = &g_166[3];
                        l_1428 = l_1291;
                    }
                    for (g_747.f1 = 4; (g_747.f1 >= 0); g_747.f1 -= 1)
                    { /* block id: 675 */
                        int32_t *l_1429[6][9] = {{&l_1253,(void*)0,&l_1381,&l_1259[3],&l_1259[0],&l_1236[6][3],&l_1250,&l_953,&l_996[4][1][0]},{&l_1250,(void*)0,&l_1364,&l_953,&l_953,&l_1364,(void*)0,&l_1250,&l_1258},{(void*)0,(void*)0,&l_1236[6][3],(void*)0,&g_316,&l_996[4][1][0],&l_1381,&l_1258,&l_996[7][2][1]},{(void*)0,(void*)0,(void*)0,&l_1364,&l_1258,&l_1259[3],&l_953,&l_1259[3],&l_1258},{&l_1253,&l_1250,&l_1250,&l_1253,&l_1364,&l_1259[0],&l_953,(void*)0,&l_996[4][1][0]},{&l_1364,(void*)0,(void*)0,(void*)0,&l_1250,&l_1236[6][3],&l_1381,&l_1236[6][3],&l_1258}};
                        int i, j;
                        (*g_463) = l_1429[0][1];
                    }
                }
            }
        }
        for (g_100 = 0; (g_100 <= 5); g_100 += 1)
        { /* block id: 683 */
            return p_59;
        }
        if (p_57)
            break;
        for (p_58 = 0; (p_58 <= 5); p_58 += 1)
        { /* block id: 689 */
            uint16_t l_1446 = 0x76B2L;
            int16_t ***l_1465[8];
            int32_t l_1529[7][4][9] = {{{(-3L),0x073196C2L,0L,1L,0L,1L,0L,0x073196C2L,(-3L)},{(-1L),0x2030CC61L,8L,(-1L),(-3L),1L,0xAEA59EB9L,0x903404F0L,0xF00EE0D1L},{0L,0x0867B4C2L,(-3L),5L,0xC6981A09L,8L,0x9C42953FL,0x9C42953FL,8L},{(-1L),(-3L),0xAEA59EB9L,(-3L),(-1L),8L,(-1L),0x1596AC86L,0xAF324BBBL}},{{(-3L),0x5DD66AC2L,0x5C9A467FL,0x4F78E405L,0x9D505AEFL,0x857BD582L,0xA061C297L,5L,0L},{0x2030CC61L,1L,0L,1L,8L,8L,1L,0L,1L},{0x9C42953FL,0x857BD582L,0L,0L,0L,8L,0x073196C2L,0x5DD66AC2L,1L},{8L,0xCF3079E2L,8L,0xAEA59EB9L,(-1L),1L,0L,0xF00EE0D1L,0L}},{{1L,0x857BD582L,9L,9L,0x857BD582L,1L,0x5C9A467FL,0L,0xC6981A09L},{(-1L),1L,0x11636AEDL,0x903404F0L,0x1596AC86L,0L,0xF00EE0D1L,(-3L),0xCF3079E2L},{5L,0x5DD66AC2L,0L,0x27E4124CL,0x5C9A467FL,0x9D505AEFL,0x5C9A467FL,0x27E4124CL,0L},{(-3L),(-3L),(-9L),0xF00EE0D1L,0xAF324BBBL,0L,0x1596AC86L,0x903404F0L,0x11636AEDL}},{{0L,0x857BD582L,5L,8L,0xA061C297L,0x5C9A467FL,0x0867B4C2L,1L,1L},{0x11636AEDL,0xAEA59EB9L,0xCF3079E2L,0x562A8B19L,0xCF3079E2L,0xAEA59EB9L,0x11636AEDL,0L,1L},{0x5DD66AC2L,0x0867B4C2L,0x073196C2L,0x4F78E405L,0L,(-3L),0x5C9A467FL,0L,9L},{(-1L),0xF00EE0D1L,0x53D71113L,(-1L),0L,8L,8L,0L,(-1L)}},{{0L,0L,0L,0L,0x857BD582L,0L,0xA061C297L,1L,1L},{0L,(-1L),(-9L),0L,0x2030CC61L,0x53D71113L,(-1L),0x903404F0L,0xAF324BBBL},{0L,8L,0x4F78E405L,0L,0L,0x4F78E405L,8L,0L,0L},{(-3L),(-1L),8L,(-1L),0x1596AC86L,0xAF324BBBL,(-9L),0x8B4AF5F5L,0L}},{{8L,0x27E4124CL,1L,0x4F78E405L,0L,0x073196C2L,5L,0x073196C2L,0L},{0x562A8B19L,(-1L),(-1L),0x562A8B19L,0xAEA59EB9L,0x2030CC61L,0x903404F0L,(-3L),0xAF324BBBL},{0x4F78E405L,1L,0x27E4124CL,8L,0L,0x0867B4C2L,0x857BD582L,(-3L),1L},{(-1L),8L,(-1L),(-3L),0xAEA59EB9L,(-3L),(-1L),8L,(-1L)}},{{0L,0x4F78E405L,8L,0L,0L,0x5DD66AC2L,0L,0xC6981A09L,9L},{0L,(-9L),(-1L),0L,0x1596AC86L,1L,0x562A8B19L,0x562A8B19L,1L},{0L,0L,0L,0L,0L,0x857BD582L,0L,0xA061C297L,1L},{(-1L),0x53D71113L,0xF00EE0D1L,(-1L),0x2030CC61L,0xCF3079E2L,0xAF324BBBL,0L,0x11636AEDL}}};
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_1465[i] = &g_1461;
            for (g_190 = 5; (g_190 >= 0); g_190 -= 1)
            { /* block id: 692 */
                int64_t *l_1434[10][6] = {{&g_100,&g_100,&g_37,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_394,&g_37},{&g_100,&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_37,&g_394,(void*)0,&g_100},{&g_394,(void*)0,&g_100,&g_100,&g_100,&g_37},{&g_100,&g_394,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_37,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_100,&g_100,&g_37,&g_100},{(void*)0,&g_394,&g_100,&g_100,&g_100,&g_100},{&g_100,(void*)0,&g_100,&g_394,&g_394,&g_100}};
                int32_t l_1445 = 0xFF2CF0D8L;
                int32_t *l_1447 = &l_1364;
                int32_t *l_1448 = &l_993;
                int16_t ****l_1462 = &l_1459;
                union U0 ** const *l_1485 = &g_258;
                union U0 ** const **l_1484 = &l_1485;
                union U0 **l_1522 = &g_259[0][1][0];
                int i, j;
                (*l_1448) ^= ((*l_1447) = ((p_58 & 1L) < ((*g_163) != (~(((p_57 ^ ((!p_57) != (g_100 = (p_59 == (0xA587L == p_58))))) , ((g_394 = ((safe_div_func_int64_t_s_s(((safe_mul_func_int16_t_s_s((((l_1446 = (safe_sub_func_int32_t_s_s((((safe_mod_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(l_1234[8][6][1], p_59)) && (***g_766)), p_58)) | p_58) , l_1445), 0x9464D6C8L))) >= 0xD270L) ^ (**g_767)), 0UL)) & (-5L)), p_60)) > 0x8FL)) <= l_1234[1][3][1])) , l_1445)))));
                if ((safe_add_func_uint16_t_u_u(1UL, (safe_lshift_func_uint16_t_u_s(0x6990L, (safe_rshift_func_int16_t_s_u((p_59 || (((safe_rshift_func_int16_t_s_u(l_1446, 11)) >= ((g_1463 = ((*l_1462) = (g_1460 = l_1459))) != (g_1464 , l_1465[6]))) ^ ((safe_div_func_uint64_t_u_u(0xD3980EF8BACF3375LL, 0xF6E34E39E3A9E2E4LL)) , 0x8F95EC3DL))), 5)))))))
                { /* block id: 701 */
                    int8_t l_1470 = (-1L);
                    if (l_1364)
                        break;
                    (*l_1448) = ((safe_mod_func_uint32_t_u_u(l_1446, l_1470)) || g_648[0][1][4]);
                    if ((*g_137))
                        break;
                }
                else
                { /* block id: 705 */
                    union U0 ***l_1489[9] = {&g_258,&g_258,&g_258,&g_258,&g_258,&g_258,&g_258,&g_258,&g_258};
                    int32_t l_1492[1][2][5] = {{{0x938A5051L,0xD54CA919L,0x938A5051L,0x99831A33L,0x99831A33L},{0x938A5051L,0xD54CA919L,0x938A5051L,0x99831A33L,0x99831A33L}}};
                    const int16_t *l_1524 = &g_1525;
                    const int16_t **l_1523 = &l_1524;
                    uint32_t *l_1526 = (void*)0;
                    uint32_t *l_1527 = (void*)0;
                    uint32_t *l_1528 = &g_113[0][0];
                    int i, j, k;
                    (*l_1447) = ((0L < ((~(safe_rshift_func_int8_t_s_u((g_528.f0 <= ((l_1446 != (*l_1448)) < ((*g_1218) == ((((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(((*l_973) ^= (l_1236[2][4] != ((((l_1364 && (p_60 == (safe_rshift_func_int16_t_s_u((safe_unary_minus_func_int8_t_s((((((((safe_mod_func_uint32_t_u_u((l_1446 & (*l_1447)), 4294967290UL)) & 0L) || (*l_1448)) >= 0x4AL) && 1L) , p_58) && p_58))), 8)))) <= l_1483) == l_1319) ^ (*l_1448)))), l_1446)), 0L)) , (*g_1218)) < 1UL) || (**g_767))))), 6))) , p_58)) <= (*g_314));
                    if (((l_1484 != g_1316) , ((0x4E6CL == 0x72E2L) > (~(safe_rshift_func_int16_t_s_u(((void*)0 == l_1489[7]), 1))))))
                    { /* block id: 708 */
                        int8_t l_1491 = 0x1AL;
                        if (l_1446)
                            break;
                        (*l_1448) = (((safe_unary_minus_func_uint16_t_u((l_1491 ^ p_58))) ^ (p_57 != l_1446)) > l_1492[0][0][3]);
                        if ((*l_1448))
                            break;
                    }
                    else
                    { /* block id: 712 */
                        uint64_t *l_1510 = &g_162;
                        int32_t l_1513 = 0xD3ADDB43L;
                        (*l_1448) = ((g_998[0][6][2] != (((-3L) <= (l_1493 != ((!(g_1464.f1 ^ ((safe_add_func_uint8_t_u_u((((*l_1426) = (safe_sub_func_uint64_t_u_u(((*g_314) | (safe_mod_func_uint8_t_u_u(((**g_1410) &= p_57), ((((l_1483 <= ((safe_sub_func_int32_t_s_s((safe_sub_func_int32_t_s_s((safe_div_func_uint8_t_u_u(((((l_1492[0][1][3] = (safe_mod_func_int32_t_s_s(((~0x4EF9L) | (--(*l_1510))), (p_57 | l_1492[0][1][1])))) && 7L) & 0xAE92L) , p_57), 0x7AL)), p_58)), l_1236[6][3])) != l_1513)) != (*l_1447)) , 3L) & (-1L))))), p_59))) & (*g_314)), p_57)) ^ 0x13E044E4L))) , (void*)0))) != 0x5D7C52ED92963D33LL)) | 0x21L);
                        (*g_463) = &l_1236[6][1];
                    }
                    (*l_1448) &= ((safe_add_func_int64_t_s_s((safe_sub_func_int16_t_s_s(6L, ((**g_1461) = (safe_rshift_func_int8_t_s_s((l_1529[2][1][8] |= ((g_1520 , ((*l_1528) = (((void*)0 != &g_766) || (safe_unary_minus_func_uint16_t_u((p_60 && (((((g_258 = l_1522) == (void*)0) ^ (l_973 == ((*l_1523) = l_973))) > p_57) || (*g_137)))))))) || (*l_1447))), 1))))), g_826.f1)) , p_59);
                }
            }
        }
    }
    return p_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_100 g_37 g_314 g_315 g_193 g_648 g_463 g_464 g_747 g_115 g_298 g_755 g_264 g_105 g_125 g_766 g_349 g_528.f0 g_387 g_113 g_460 g_461 g_149 g_797 g_747.f1 g_551.f0 g_809 g_826 g_767 g_109 g_199 g_163 g_101 g_40.f0 g_196 g_810 g_811 g_376 g_259 g_394 g_137 g_910 g_190
 * writes: g_100 g_394 g_464 g_125 g_190 g_115 g_314 g_105 g_766 g_648 g_166.f1 g_196 g_747.f1 g_315 g_113 g_349 g_810 g_162 g_298 g_101 g_316 g_259 g_592 g_149 g_910
 */
static uint32_t  func_61(const uint32_t  p_62, int32_t  p_63)
{ /* block id: 164 */
    const uint8_t *l_384 = &g_199;
    int32_t l_392 = 1L;
    int16_t **l_401 = &g_264;
    int16_t ***l_400 = &l_401;
    uint32_t l_429 = 0xC1104DD7L;
    const int64_t l_443[8] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
    int8_t l_447 = 0x6AL;
    int32_t l_481 = (-1L);
    int32_t l_482 = 0x71A94A4FL;
    int32_t l_483 = 0x801EF4C1L;
    int32_t l_484 = 6L;
    int32_t l_485[4][9][5] = {{{0L,(-8L),4L,(-1L),0x4E51D2ECL},{0xAF7C6731L,0xCBC974CAL,0x0071A631L,0x02DE4639L,0xE47C92CCL},{0xD80E3966L,0x998834DCL,0xA96BA776L,0x998834DCL,0xD80E3966L},{0xF49E84E6L,0x0B300B62L,1L,(-1L),0xF8527D49L},{0x20119565L,0xA96BA776L,1L,6L,0x0071A631L},{(-3L),(-5L),9L,0x0B300B62L,0xF8527D49L},{(-1L),6L,0xCBC974CAL,(-6L),0xD80E3966L},{0xF8527D49L,0L,4L,1L,0xE47C92CCL},{0L,5L,0L,0xC4EBD6CAL,0x4E51D2ECL}},{{0xEEDF33D6L,5L,0x3CFE64C0L,(-4L),0xCA098B23L},{1L,6L,0xD80E3966L,3L,1L},{(-4L),(-10L),(-7L),0x7287F9ECL,0x2B8BD812L},{0x998834DCL,(-1L),0x188C3755L,0xCA098B23L,0L},{0x4E51D2ECL,(-1L),(-8L),0xA96BA776L,0x56A15EEDL},{0xE96E200CL,(-10L),0x2B8BD812L,0x6E7F1324L,0x11216D08L},{5L,6L,0x02DE4639L,0xE96E200CL,0x7287F9ECL},{4L,5L,1L,(-6L),0xE96E200CL},{(-1L),5L,7L,0x2B8BD812L,4L}},{{1L,0L,0L,1L,0L},{0L,6L,(-3L),0x9AED675AL,1L},{0x02DE4639L,(-5L),0xAF7C6731L,5L,(-10L)},{0xFF83EBA1L,0xA96BA776L,2L,0x9AED675AL,9L},{1L,0x0B300B62L,0xEEDF33D6L,1L,0xF47291F4L},{0xF9409E84L,0x998834DCL,(-3L),0x2B8BD812L,(-1L)},{0L,0xCBC974CAL,0xCA098B23L,(-6L),7L},{0xCA098B23L,(-8L),0x56A15EEDL,0xE96E200CL,1L},{(-10L),0x9AED675AL,0x20119565L,0x6E7F1324L,0xA96BA776L}},{{(-8L),0xFF83EBA1L,0x9AED675AL,0xA96BA776L,1L},{(-1L),0xC7F3EB5AL,0L,0xCA098B23L,6L},{(-1L),9L,(-1L),5L,0xCBC974CAL},{(-1L),7L,(-5L),6L,0x7287F9ECL},{(-1L),0x9AED675AL,0x188C3755L,0xF8527D49L,0x4E51D2ECL},{6L,0x0071A631L,0L,0L,4L},{0xF49E84E6L,5L,1L,0x2B8BD812L,0x2B8BD812L},{0x9AED675AL,(-4L),0x9AED675AL,0x6E7F1324L,5L},{0L,0L,0L,0xC4EBD6CAL,4L}}};
    int16_t l_486 = (-7L);
    int16_t l_541 = 0x7D33L;
    uint64_t *l_600 = &g_162;
    int64_t *l_732[9][6][4] = {{{&g_37,&g_37,&g_37,&g_394},{&g_394,&g_394,&g_37,&g_394},{(void*)0,&g_37,&g_37,&g_394},{(void*)0,&g_37,&g_394,&g_37},{&g_394,&g_37,&g_37,(void*)0},{(void*)0,&g_37,(void*)0,&g_100}},{{&g_100,&g_394,&g_37,&g_37},{&g_37,&g_37,&g_100,&g_394},{(void*)0,(void*)0,&g_100,&g_394},{&g_37,&g_394,&g_37,&g_37},{&g_100,&g_394,(void*)0,&g_394},{(void*)0,&g_394,&g_37,&g_394}},{{&g_394,&g_37,&g_394,&g_394},{(void*)0,&g_37,&g_37,&g_37},{(void*)0,&g_394,&g_37,&g_100},{&g_394,&g_394,&g_37,&g_37},{&g_37,&g_37,&g_394,&g_394},{(void*)0,&g_37,&g_394,&g_394}},{{(void*)0,&g_394,&g_37,&g_394},{&g_100,&g_394,(void*)0,&g_37},{(void*)0,&g_394,&g_100,&g_394},{(void*)0,(void*)0,&g_394,&g_394},{(void*)0,&g_37,&g_100,&g_37},{(void*)0,&g_394,(void*)0,&g_100}},{{&g_100,&g_37,&g_37,(void*)0},{(void*)0,&g_37,&g_394,&g_37},{(void*)0,&g_37,&g_394,&g_394},{&g_37,&g_37,&g_37,&g_394},{&g_394,&g_394,&g_37,&g_394},{(void*)0,&g_37,&g_37,&g_394}},{{(void*)0,&g_37,&g_394,&g_37},{&g_394,&g_37,&g_37,(void*)0},{(void*)0,&g_37,(void*)0,&g_100},{&g_100,&g_394,&g_37,&g_37},{&g_37,&g_37,&g_100,&g_394},{(void*)0,(void*)0,&g_100,&g_394}},{{&g_37,&g_394,&g_37,&g_37},{&g_100,&g_394,(void*)0,&g_394},{(void*)0,&g_394,&g_37,&g_394},{&g_394,(void*)0,(void*)0,&g_37},{(void*)0,&g_100,&g_100,&g_100},{(void*)0,&g_37,&g_100,&g_37}},{{&g_100,&g_37,(void*)0,&g_100},{&g_394,&g_100,&g_394,&g_37},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_394,&g_37,(void*)0,&g_37},{&g_37,&g_100,(void*)0,&g_100},{(void*)0,&g_394,&g_394,(void*)0}},{{(void*)0,&g_394,(void*)0,&g_394},{(void*)0,&g_100,&g_394,(void*)0},{(void*)0,&g_394,(void*)0,&g_37},{&g_37,&g_394,(void*)0,&g_394},{&g_394,&g_100,(void*)0,&g_394},{(void*)0,&g_100,&g_394,(void*)0}}};
    union U0 **l_737 = &g_259[0][1][0];
    uint16_t **l_740 = &g_314;
    int32_t **l_838[1];
    int32_t ****l_843[4];
    int8_t **l_904 = (void*)0;
    int8_t *l_906 = &g_826.f1;
    int8_t **l_905 = &l_906;
    int8_t **l_907 = (void*)0;
    int8_t *l_909[9] = {&l_447,(void*)0,&l_447,(void*)0,&l_447,(void*)0,&l_447,(void*)0,&l_447};
    int8_t **l_908[4] = {&l_909[5],&l_909[5],&l_909[5],&l_909[5]};
    uint8_t *l_911 = &g_298[0][6][9];
    uint64_t l_912[5] = {0xB154FB93975BB2E5LL,0xB154FB93975BB2E5LL,0xB154FB93975BB2E5LL,0xB154FB93975BB2E5LL,0xB154FB93975BB2E5LL};
    uint8_t *l_913 = &g_149;
    const uint8_t l_916 = 0x52L;
    uint64_t ***l_917[1];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_838[i] = &g_464;
    for (i = 0; i < 4; i++)
        l_843[i] = &g_462[0];
    for (i = 0; i < 1; i++)
        l_917[i] = (void*)0;
lbl_884:
    for (g_100 = (-10); (g_100 == (-15)); g_100--)
    { /* block id: 167 */
        int16_t * const *l_382 = &g_264;
        int16_t * const **l_381[6] = {&l_382,&l_382,(void*)0,&l_382,&l_382,(void*)0};
        uint8_t *l_383 = (void*)0;
        const uint8_t *l_386 = &g_387[1][5][1];
        int32_t l_388 = 1L;
        int32_t l_409[7] = {0L,0L,0L,0L,0L,0L,0L};
        int8_t l_477 = 0xF9L;
        const uint16_t *l_531 = (void*)0;
        const uint64_t * const l_599 = &g_367;
        int32_t ****l_720 = &g_462[1];
        int i;
    }
    if (((-1L) ^ ((safe_div_func_int16_t_s_s((((safe_rshift_func_uint8_t_u_s((&g_314 != ((safe_add_func_int64_t_s_s((65532UL | ((((((g_394 = 0x040975CC43BC124ALL) >= p_63) < ((l_541 > ((safe_mod_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((((l_737 == l_737) < ((((safe_sub_func_int32_t_s_s((3UL <= l_482), l_443[7])) && g_37) ^ l_482) == p_63)) | g_37) , 0xC2C9L), l_484)) != l_443[7]), 0x03F7L)) == (*g_314))) || g_193)) , 1UL) || p_62) , 0L)), 0xB310AEBB1A48D202LL)) , l_740)), 5)) != g_648[0][0][7]) <= 1UL), (*g_314))) == 0xE0L)))
    { /* block id: 320 */
        int32_t l_741 = 0x0050980EL;
        int32_t l_781 = 0xA48A82FDL;
        int32_t **l_785[10] = {&g_464,&g_464,&g_464,(void*)0,(void*)0,&g_464,&g_464,&g_464,(void*)0,(void*)0};
        int8_t l_818 = 0x9DL;
        int i;
lbl_870:
        (*g_463) = &p_63;
        for (g_125 = 3; (g_125 >= 0); g_125 -= 1)
        { /* block id: 324 */
            int8_t l_782[4] = {6L,6L,6L,6L};
            int32_t l_814 = 0x4F8CC3B5L;
            int32_t l_815[1][5];
            uint64_t l_846 = 0x15CCFF853CA9C265LL;
            int8_t l_863[3];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 5; j++)
                    l_815[i][j] = 0xB6374395L;
            }
            for (i = 0; i < 3; i++)
                l_863[i] = 0xFDL;
            for (g_190 = 0; (g_190 <= 3); g_190 += 1)
            { /* block id: 327 */
                uint8_t * const l_752 = &g_298[1][2][8];
                uint8_t * const *l_751 = &l_752;
                int32_t ***l_776[5][5][7] = {{{&g_463,&g_463,(void*)0,(void*)0,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,(void*)0,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,(void*)0,(void*)0,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463}},{{(void*)0,&g_463,&g_463,&g_463,(void*)0,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{(void*)0,(void*)0,&g_463,&g_463,&g_463,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,(void*)0,&g_463,&g_463,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,(void*)0,&g_463,&g_463,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,(void*)0,(void*)0,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,(void*)0,(void*)0,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463,(void*)0,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,&g_463,&g_463},{(void*)0,&g_463,&g_463,&g_463,(void*)0,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463,&g_463,(void*)0,&g_463},{&g_463,&g_463,&g_463,(void*)0,(void*)0,&g_463,&g_463}}};
                int32_t l_780 = (-10L);
                int i, j, k;
                for (g_100 = 3; (g_100 >= 0); g_100 -= 1)
                { /* block id: 330 */
                    if (l_741)
                        break;
                }
                if ((**g_463))
                    continue;
                for (l_482 = 0; (l_482 <= 3); l_482 += 1)
                { /* block id: 336 */
                    uint16_t *l_746 = &g_315[2][0];
                    int32_t l_773 = 0x6A669CD3L;
                    const int32_t **l_779 = (void*)0;
                    const int32_t ***l_778 = &l_779;
                    for (g_115 = 0; (g_115 <= 2); g_115 += 1)
                    { /* block id: 339 */
                        uint8_t **l_748 = (void*)0;
                        int32_t *l_756 = &l_484;
                        int16_t * const ***l_768 = &g_766;
                        int32_t ****l_777 = &l_776[4][1][6];
                        uint32_t *l_783 = &g_648[0][1][3];
                        int8_t *l_784 = &g_166[3].f1;
                        int i, j, k;
                        (*l_756) |= ((safe_rshift_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((((*l_740) = (*l_740)) != l_746), 7)) > (65534UL < ((*g_264) ^= ((g_747 , ((g_298[g_115][(l_482 + 4)][(l_482 + 1)] | (l_748 == ((safe_rshift_func_uint16_t_u_s(p_62, 12)) , l_751))) == (safe_mul_func_uint16_t_u_u(g_755, p_62)))) != 0xF91EL)))) & (**g_463)), 3)) < p_63);
                        (*l_756) = ((!((((((*l_784) = (((*l_783) |= (safe_mod_func_int32_t_s_s(((safe_rshift_func_int16_t_s_u((safe_sub_func_int32_t_s_s((g_125 | ((safe_mul_func_int8_t_s_s((&l_401 == ((*l_768) = g_766)), 1UL)) , ((safe_mod_func_int64_t_s_s(((((safe_mul_func_int8_t_s_s((p_62 == ((((p_63 > (l_773 >= (((p_63 , (l_780 = (l_741 &= (safe_rshift_func_int16_t_s_u((((*l_777) = l_776[4][1][6]) == l_778), 9))))) , p_62) < p_62))) && (-8L)) ^ 0x4DL) , g_349[8])), g_528.f0)) || (*g_464)) & p_62) >= g_387[1][5][1]), p_63)) > 0L))), g_113[0][0])), l_781)) && p_62), l_782[1]))) == (**g_463))) , p_63) != g_37) , (*g_460)) != l_785[7])) ^ g_149);
                        if (p_63)
                            break;
                        (*g_464) = 0L;
                    }
                    if (p_63)
                        continue;
                }
                l_485[3][1][4] = p_63;
            }
            for (l_447 = 3; (l_447 >= 0); l_447 -= 1)
            { /* block id: 359 */
                uint32_t l_787 = 1UL;
                int32_t l_812[2][3];
                int32_t **l_835 = &g_464;
                int32_t ***l_839[4][6][9] = {{{&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2]},{&l_835,&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835},{&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0]},{&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835,&g_463},{&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2]},{&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835,&l_785[7],&l_785[7],&g_463}},{{&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0]},{&l_835,&l_785[7],&l_785[7],&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835},{&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2]},{&l_835,&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835},{&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0]},{&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835,&g_463}},{{&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2]},{&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835,&l_785[7],&l_785[7],&g_463},{&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0]},{&l_835,&l_785[7],&l_785[7],&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835},{&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2]},{&l_835,&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835}},{{&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0],&l_785[2],(void*)0,&l_785[2],&l_838[0]},{&g_463,&l_785[7],&l_785[7],&g_463,&l_835,&l_785[7],&l_785[7],&l_835,&g_463},{&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2],&l_785[2],&l_785[2],&l_785[3],&l_785[2]},{&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835,&l_785[7],&l_785[7],&g_463},{&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0],&l_785[3],(void*)0,&l_785[3],&l_838[0]},{&l_835,&l_785[7],&l_785[7],&g_463,&g_463,&l_785[7],&l_785[7],&l_835,&l_835}}};
                uint8_t *l_840 = &g_298[1][2][4];
                int i, j, k;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_812[i][j] = 1L;
                }
                for (g_196 = 0; (g_196 <= 3); g_196 += 1)
                { /* block id: 362 */
                    int32_t l_786 = 0x0220C45CL;
                    --l_787;
                }
                for (g_747.f1 = 3; (g_747.f1 >= 0); g_747.f1 -= 1)
                { /* block id: 367 */
                    uint32_t l_804 = 4294967295UL;
                    int32_t l_813[8][10][2] = {{{0x31C406ECL,1L},{(-5L),0L},{(-1L),0x400A8A2FL},{0x31C406ECL,0x969BA511L},{0x400A8A2FL,0x2BB563EDL},{0L,0L},{0x0FCC3DE8L,0x56FF2DB3L},{0x7DFD20D7L,0x7DFD20D7L},{0x969BA511L,0L},{0L,7L}},{{0x400A8A2FL,0x0FCC3DE8L},{0L,0x400A8A2FL},{(-5L),5L},{(-5L),0x400A8A2FL},{0L,0x0FCC3DE8L},{0x400A8A2FL,7L},{0L,0L},{0x969BA511L,0x7DFD20D7L},{0x7DFD20D7L,0x56FF2DB3L},{0x0FCC3DE8L,0L}},{{0L,0x2BB563EDL},{0x400A8A2FL,0x969BA511L},{0x31C406ECL,0x400A8A2FL},{(-1L),0L},{(-5L),1L},{0x31C406ECL,0x0FCC3DE8L},{1L,0x2BB563EDL},{0L,0x11E349ABL},{0x0FCC3DE8L,0x7DFD20D7L},{0x56FF2DB3L,0x7DFD20D7L}},{{0x0FCC3DE8L,0x11E349ABL},{0L,0x2BB563EDL},{1L,0x0FCC3DE8L},{0x31C406ECL,1L},{(-5L),0L},{(-1L),0x400A8A2FL},{0x31C406ECL,0x969BA511L},{0x400A8A2FL,0x2BB563EDL},{0L,0x969BA511L},{0x56FF2DB3L,1L}},{{0x1B94502CL,0x1B94502CL},{0xAF90B1CCL,0x969BA511L},{(-1L),(-6L)},{5L,0x56FF2DB3L},{0L,5L},{0x11E349ABL,0L},{0x11E349ABL,5L},{0L,0x56FF2DB3L},{5L,(-6L)},{(-1L),0x969BA511L}},{{0xAF90B1CCL,0x1B94502CL},{0x1B94502CL,1L},{0x56FF2DB3L,0x969BA511L},{0x59BF357EL,0L},{5L,0xAF90B1CCL},{0L,5L},{0x8B2BFA02L,(-4L)},{0x11E349ABL,0x928DA939L},{0L,0x56FF2DB3L},{0x928DA939L,0L}},{{(-1L),0x8945C035L},{0x56FF2DB3L,0x1B94502CL},{1L,0x1B94502CL},{0x56FF2DB3L,0x8945C035L},{(-1L),0L},{0x928DA939L,0x56FF2DB3L},{0L,0x928DA939L},{0x11E349ABL,(-4L)},{0x8B2BFA02L,5L},{0L,0xAF90B1CCL}},{{5L,0L},{0x59BF357EL,0x969BA511L},{0x56FF2DB3L,1L},{0x1B94502CL,0x1B94502CL},{0xAF90B1CCL,0x969BA511L},{(-1L),(-6L)},{5L,0x56FF2DB3L},{0L,5L},{0x11E349ABL,0L},{0x11E349ABL,5L}}};
                    uint32_t l_821 = 1UL;
                    int i, j, k;
                    for (l_483 = 0; (l_483 <= 3); l_483 += 1)
                    { /* block id: 370 */
                        uint64_t **l_799 = &l_600;
                        uint64_t ***l_798 = &l_799;
                        int32_t l_802 = 0x3077C160L;
                        uint8_t *l_803 = &g_349[8];
                        int32_t l_816 = (-1L);
                        int32_t l_817 = 0x4A5BF343L;
                        int32_t l_819 = 0x0115415BL;
                        int32_t l_820[4] = {1L,1L,1L,1L};
                        int i, j;
                        (*g_809) = (((safe_unary_minus_func_uint32_t_u(g_298[2][1][0])) ^ ((((safe_sub_func_int16_t_s_s((1L <= (((((**l_740)++) > (safe_add_func_int32_t_s_s((((g_797 != ((*l_798) = &l_600)) ^ (safe_sub_func_uint32_t_u_u(((g_113[(g_747.f1 + 2)][l_483] = l_802) >= (((*l_803) = p_63) > l_804)), 0xFA7DAC2AL))) <= ((safe_lshift_func_int16_t_s_u(((safe_sub_func_uint64_t_u_u(l_802, 0UL)) || g_551.f0), 12)) , 65535UL)), 1L))) , 0x8621C11CAF3F50CCLL) , p_62)), p_63)) , p_62) && p_63) == l_804)) , &l_384);
                        l_812[0][1] |= p_63;
                        l_821++;
                        (*g_464) = (safe_rshift_func_uint8_t_u_s((l_812[0][0] == (l_740 != (void*)0)), 0));
                    }
                }
                l_781 |= ((((g_826 , (safe_div_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_s(((safe_sub_func_uint64_t_u_u((safe_div_func_uint8_t_u_u((((*l_600) = p_62) > (((***g_766) , l_835) == ((++(*g_314)) , (l_785[3] = l_838[0])))), (--(*l_840)))), (&g_462[0] != l_843[2]))) != (safe_add_func_uint16_t_u_u(l_846, ((l_782[3] , 1UL) >= p_63)))), 15)) | g_115), g_109[6]))) ^ g_747.f1) , l_814) < 4294967291UL);
            }
            l_815[0][2] = l_782[1];
            for (l_741 = 0; (l_741 <= 3); l_741 += 1)
            { /* block id: 390 */
                uint16_t l_866 = 65535UL;
                uint8_t *l_867 = (void*)0;
                uint8_t *l_868[10][5] = {{&g_349[6],&g_149,&g_349[6],&g_149,&g_349[6]},{&g_149,&g_149,&g_149,&g_149,&g_149},{&g_349[6],&g_149,&g_349[6],&g_149,&g_349[6]},{&g_149,&g_149,&g_149,&g_149,&g_149},{&g_349[6],&g_149,&g_349[6],&g_149,&g_349[6]},{&g_149,&g_149,&g_149,&g_149,&g_149},{&g_349[6],&g_149,&g_349[6],&g_149,&g_349[6]},{&g_149,&g_149,&g_149,&g_149,&g_149},{&g_349[6],&g_149,&g_349[6],&g_149,&g_349[6]},{&g_149,&g_149,&g_149,&g_149,&g_149}};
                int32_t l_869 = (-8L);
                int i, j;
                l_869 &= (safe_div_func_int16_t_s_s((((((l_815[0][2] = (safe_mul_func_int8_t_s_s(g_199, ((p_62 || (safe_lshift_func_int16_t_s_u((((*g_163) , (l_815[0][1] >= ((safe_lshift_func_int8_t_s_s((safe_sub_func_int8_t_s_s(((safe_lshift_func_int16_t_s_s((l_815[0][2] | ((l_863[0] || (p_62 >= ((l_814 = (((safe_div_func_int8_t_s_s((((-1L) | (l_866 & l_815[0][2])) && p_63), l_866)) == l_866) & (**g_463))) , 0x0B07CCE692EDDB70LL))) , 0x72L)), l_863[1])) != g_40[0].f0), p_63)), l_863[0])) < 0xCA0E5EA3L))) || g_755), p_63))) <= 0xA55D359645E6A9AELL)))) < p_63) , p_62) , 0x692A9187F349928BLL) , (**g_767)), p_63));
                if (l_741)
                    goto lbl_870;
            }
        }
    }
    else
    { /* block id: 397 */
        uint64_t l_871 = 0x7A1C0D4EA13F1C81LL;
        uint64_t * const ** const l_880 = (void*)0;
        const int32_t *l_892 = &l_482;
        int32_t l_895[2][9] = {{0x52BE329FL,0xACB6FCA5L,0x52BE329FL,0xACB6FCA5L,0x52BE329FL,0xACB6FCA5L,0x52BE329FL,0xACB6FCA5L,0x52BE329FL},{0xF50697A9L,0L,0L,0xF50697A9L,0xF50697A9L,0L,0L,0xF50697A9L,0xF50697A9L}};
        uint16_t l_896[2];
        int i, j;
        for (i = 0; i < 2; i++)
            l_896[i] = 1UL;
        ++l_871;
        if (p_63)
        { /* block id: 399 */
            for (g_196 = 0; (g_196 < 4); g_196 = safe_add_func_int32_t_s_s(g_196, 1))
            { /* block id: 402 */
                uint64_t l_876 = 0UL;
                (**g_463) = (*g_464);
                l_876--;
                return l_871;
            }
        }
        else
        { /* block id: 407 */
            uint32_t l_879[4][2][10] = {{{0xA0F718ACL,0xD9E4708AL,0xAF392DAFL,0xF55BE8ECL,0x6EFFE4B4L,9UL,0x50C1724AL,4294967286UL,9UL,0UL},{4294967295UL,0xF380603CL,0x0BAA20DBL,4294967295UL,1UL,4294967295UL,0x6B7113DAL,4294967289UL,0UL,4294967289UL}},{{0xF380603CL,0xDD9CF99AL,4294967292UL,4294967289UL,4294967292UL,0xDD9CF99AL,0xF380603CL,0x83EAE4D5L,0UL,0xD9E4708AL},{0x83EAE4D5L,0x7A672888L,0x52FECC8BL,0x3374B5E3L,0xF380603CL,0xA0F718ACL,0UL,0xDD9CF99AL,0UL,0x46F5DA29L}},{{9UL,4294967295UL,0x6937A1D3L,0x6483DDC4L,0x52FECC8BL,0x6EFFE4B4L,0x3374B5E3L,0UL,1UL,0x6483DDC4L},{0x6483DDC4L,0xBE1FB85AL,0x7920823AL,4294967295UL,4294967295UL,0x0BAA20DBL,0xF55BE8ECL,1UL,1UL,0xF55BE8ECL}},{{4294967295UL,0x3374B5E3L,0x0BAA20DBL,0x0BAA20DBL,0x3374B5E3L,4294967295UL,4294967295UL,0x83EAE4D5L,0UL,0UL},{0x50C1724AL,0UL,7UL,0xDD9CF99AL,0x83EAE4D5L,1UL,0x6483DDC4L,0UL,4294967286UL,0x52FECC8BL}}};
            int i, j, k;
            if (((l_879[0][1][2] || p_62) && (((p_63 , (**g_809)) == (*g_810)) | ((void*)0 == l_880))))
            { /* block id: 408 */
                union U0 * const l_881 = &g_747;
                union U0 **l_883 = &g_259[0][1][3];
                (*g_376) = (**g_463);
                (*l_883) = l_881;
            }
            else
            { /* block id: 411 */
                (*g_464) = (-3L);
                if (g_101)
                    goto lbl_884;
            }
            for (l_392 = 22; (l_392 < (-7)); l_392 = safe_sub_func_int16_t_s_s(l_392, 1))
            { /* block id: 417 */
                for (g_101 = (-1); (g_101 > (-20)); g_101 = safe_sub_func_int32_t_s_s(g_101, 9))
                { /* block id: 420 */
                    (*g_463) = &p_63;
                    if (p_62)
                        break;
                    for (g_592 = 0; (g_592 != 36); ++g_592)
                    { /* block id: 425 */
                        const int32_t *l_891 = &l_485[1][7][0];
                        l_892 = l_891;
                        (**g_463) = (safe_div_func_uint8_t_u_u((&g_810 != (void*)0), 0xC4L));
                        (*g_463) = &p_63;
                    }
                }
            }
        }
        if ((g_797 != &l_600))
        { /* block id: 433 */
            ++l_896[1];
            return p_63;
        }
        else
        { /* block id: 436 */
            for (g_149 = 0; (g_149 <= 1); g_149 += 1)
            { /* block id: 439 */
                return p_62;
            }
        }
    }
    if ((p_63 = (safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((*l_911) |= (~(((*l_905) = &l_447) != (g_910 = &g_190)))), ((*l_737) != (*l_737)))), ((g_100 = (((g_394 &= g_100) & (l_912[1] > ((*l_913)--))) & l_916)) >= (((*g_137) ^= p_63) , (((l_917[0] == (void*)0) && 1L) == p_63)))))))
    { /* block id: 452 */
        (**g_463) = 0x84D40C56L;
    }
    else
    { /* block id: 454 */
        int32_t l_924 = 1L;
        uint32_t *l_925 = &g_113[2][0];
        union U0 **l_928 = &g_259[0][1][0];
        uint16_t *l_931 = &g_592;
        (*g_464) = (safe_rshift_func_int16_t_s_s(((**g_767) = (((g_100 = (g_394 |= (((**g_766) == (void*)0) && ((*l_931) = (safe_sub_func_int32_t_s_s((safe_sub_func_int16_t_s_s((((l_924 && (0xD6241557L != ((*l_925) = 0x7BED96EDL))) | ((safe_div_func_uint16_t_u_u(((**l_740) = (l_928 == ((safe_div_func_int64_t_s_s((p_63 , ((((((void*)0 != &g_460) ^ 0xBFL) , p_62) == 0xBFDE528BL) , 0x0D6A6343401189FFLL)), p_63)) , &g_167))), p_62)) , p_63)) > (*g_910)), (*g_264))), l_924)))))) || 0x166FBBE0A0EEB9E4LL) & p_62)), 7));
        (*g_463) = &p_63;
    }
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_190 g_349 g_376 g_316
 * writes: g_190 g_316
 */
static uint16_t  func_68(int32_t  p_69, int8_t  p_70, uint64_t  p_71)
{ /* block id: 156 */
    uint16_t **l_374 = &g_314;
    uint8_t l_375 = 0x9CL;
    int32_t l_377 = 0xDDB469A3L;
    for (g_190 = 0; (g_190 <= 9); g_190 += 1)
    { /* block id: 159 */
        int i;
        (*g_376) ^= (safe_div_func_uint8_t_u_u((0xEB9A91AE63A26EFFLL <= (safe_rshift_func_uint16_t_u_u(((l_374 == l_374) > g_349[g_190]), l_375))), 255UL));
        return l_377;
    }
    return p_71;
}


/* ------------------------------------------ */
/* 
 * reads : g_40.f1 g_37 g_40.f0 g_101 g_105 g_100 g_40 g_125 g_133 g_137 g_113 g_109 g_163 g_177 g_196 g_199 g_189 g_166.f1 g_149 g_190 g_162 g_193 g_367
 * writes: g_100 g_101 g_105 g_109 g_115 g_125 g_133 g_149 g_113 g_162 g_167 g_177 g_196 g_199 g_137 g_367 g_190
 */
static uint32_t  func_72(int32_t  p_73, const int8_t  p_74, int8_t  p_75, uint32_t  p_76)
{ /* block id: 5 */
    int8_t l_96 = 1L;
    int16_t *l_152 = &g_115;
    int32_t l_180[3][6][5] = {{{0L,0L,0L,0L,0L},{0x1135C14CL,0xC5394159L,0xDB91B04CL,0x8BFC28CDL,0x8BFC28CDL},{1L,0L,1L,0L,0L},{0x8BFC28CDL,0xE314DBE9L,(-1L),0x8BFC28CDL,(-1L)},{1L,1L,1L,0L,0xFB40517BL},{0x658C38B9L,0x1135C14CL,(-1L),(-1L),0x1135C14CL}},{{0xFB40517BL,0L,1L,0xFB40517BL,0L},{0xC5394159L,0x1135C14CL,0xDB91B04CL,0x1135C14CL,0xC5394159L},{1L,1L,0L,0L,1L},{0xC5394159L,0xE314DBE9L,0xE314DBE9L,0xC5394159L,(-1L)},{0xFB40517BL,0L,1L,1L,1L},{0x658C38B9L,0xC5394159L,0x658C38B9L,(-1L),0xC5394159L}},{{1L,0L,0L,1L,0L},{0x8BFC28CDL,0x8BFC28CDL,0xDB91B04CL,0xC5394159L,0x1135C14CL},{1L,0xFB40517BL,0L,0L,0xFB40517BL},{0x1135C14CL,0xE314DBE9L,0x658C38B9L,0x1135C14CL,(-1L)},{0L,0xFB40517BL,1L,0xFB40517BL,0L},{0x658C38B9L,0x8BFC28CDL,0xE314DBE9L,(-1L),0x8BFC28CDL}}};
    int16_t *l_265 = &g_115;
    int32_t l_287 = (-5L);
    uint64_t *l_312 = &g_162;
    int i, j, k;
    for (p_75 = 0; (p_75 >= 0); p_75 -= 1)
    { /* block id: 8 */
        uint16_t l_95 = 65532UL;
        uint32_t *l_112 = &g_113[0][0];
        int32_t l_174 = 0x41F08C6BL;
        int32_t l_194 = 0xF5F8C257L;
        union U0 *l_241 = (void*)0;
        int32_t *l_255[5];
        int16_t **l_267 = &l_152;
        int16_t ***l_266 = &l_267;
        const int32_t *l_355 = (void*)0;
        const int32_t **l_354[4] = {&l_355,&l_355,&l_355,&l_355};
        int32_t **l_357 = (void*)0;
        int i;
        for (i = 0; i < 5; i++)
            l_255[i] = &l_180[0][0][0];
        for (p_76 = 0; (p_76 <= 0); p_76 += 1)
        { /* block id: 11 */
            int16_t l_94 = 0x81CAL;
            int64_t *l_99 = &g_100;
            int16_t *l_104 = &g_105;
            uint32_t *l_108 = &g_109[6];
            int16_t *l_114 = &g_115;
            int32_t l_126 = 0xAB2FCBA4L;
            int32_t l_181 = (-9L);
            int32_t l_192[2];
            int i;
            for (i = 0; i < 2; i++)
                l_192[i] = (-4L);
            g_101 |= (safe_mul_func_int8_t_s_s(1L, ((((safe_div_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(((1L ^ (l_94 , (l_95 <= (g_40[0].f1 != (p_75 | (l_96 ^ (((((*l_99) = (safe_sub_func_int8_t_s_s(g_37, l_95))) | l_94) , 0x97L) < l_95))))))) <= 0L), l_95)) , l_96), 1UL)) || g_40[0].f0) & g_37) || 4294967289UL)));
            if (((((l_94 , (void*)0) != &g_100) < l_94) < ((safe_lshift_func_int16_t_s_s(((*l_104) |= p_75), 3)) > (safe_lshift_func_int16_t_s_s(p_76, ((*l_114) = ((((((((*l_108) = g_40[0].f1) & (g_100 >= ((((((((4L >= p_76) && p_76) , 1L) , (void*)0) != l_112) <= (-5L)) > 18446744073709551610UL) == g_100))) == 0x120EL) < l_95) , 1L) , g_40[p_75]) , g_101)))))))
            { /* block id: 17 */
                const int16_t l_124 = 0xE280L;
                if ((safe_mul_func_int8_t_s_s(((safe_div_func_int64_t_s_s(0x4F06586993EB3337LL, p_76)) < ((((safe_rshift_func_int16_t_s_u(((((safe_mul_func_uint16_t_u_u(p_76, ((p_73 ^ (g_101 == l_124)) ^ (g_125 &= ((&g_100 != (void*)0) ^ g_37))))) , &g_109[7]) != (void*)0) | 0L), 0)) , l_124) == 0x825DL) | 2L)), l_96)))
                { /* block id: 19 */
                    int32_t *l_127 = &l_126;
                    int32_t *l_128 = &g_101;
                    int32_t *l_129 = &l_126;
                    int32_t l_130 = 0x6C5754D5L;
                    int32_t *l_131 = &l_126;
                    int32_t *l_132[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_132[i] = &l_126;
                    g_133[0][8]++;
                    if (p_74)
                        continue;
                }
                else
                { /* block id: 22 */
                    int64_t *l_136 = &g_100;
                    (*g_137) = ((void*)0 == l_136);
                }
            }
            else
            { /* block id: 25 */
                uint32_t *l_146 = (void*)0;
                int32_t l_147 = (-1L);
                uint8_t *l_148 = &g_149;
                int32_t l_175 = 0xCE111123L;
                int64_t l_205 = 0xD219E0C19E0181DALL;
                int16_t ***l_210 = (void*)0;
                int16_t **l_212 = &l_152;
                int16_t ***l_211 = &l_212;
                p_73 &= ((l_96 != ((*l_148) = (l_126 = (safe_mod_func_uint32_t_u_u(((((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(l_96, g_40[0].f0)), ((((safe_mod_func_int64_t_s_s(((g_125 > ((l_146 == (void*)0) & l_147)) != (g_113[1][3] || g_101)), l_96)) < 0xC2L) , p_76) != g_101))) && (*g_137)) , (void*)0) != (void*)0), 0x7D2F2FD2L))))) <= l_95);
                for (g_149 = 0; (g_149 <= 0); g_149 += 1)
                { /* block id: 31 */
                    int32_t l_153 = 0x65BEC774L;
                    uint16_t *l_160 = &l_95;
                    uint64_t *l_161 = &g_162;
                    int32_t l_176 = (-10L);
                    int32_t *l_186 = (void*)0;
                    int32_t *l_187 = &l_181;
                    int32_t *l_188[2][6][5] = {{{&l_147,(void*)0,&l_176,&l_176,(void*)0},{(void*)0,&l_175,&l_175,(void*)0,&l_126},{(void*)0,&l_176,&l_180[0][0][0],(void*)0,&l_175},{&l_176,(void*)0,&l_175,(void*)0,&l_175},{&g_101,&g_101,(void*)0,(void*)0,&l_126},{&l_180[1][3][3],(void*)0,&g_101,(void*)0,(void*)0}},{{(void*)0,&l_176,(void*)0,&l_176,(void*)0},{(void*)0,(void*)0,(void*)0,&g_101,&l_176},{&g_101,&g_101,(void*)0,&l_147,&l_147},{(void*)0,(void*)0,&l_147,&l_147,(void*)0},{(void*)0,&l_176,&g_101,&l_176,&l_126},{(void*)0,&l_176,&l_175,&l_180[0][0][0],&g_101}}};
                    int i, j, k;
                    if (l_96)
                        break;
                    if (((safe_sub_func_uint64_t_u_u((((((l_152 != (void*)0) ^ ((0x552C197979DB4E21LL <= (-6L)) | l_153)) >= (((*l_112)--) | (*g_137))) >= g_109[6]) ^ (safe_add_func_uint16_t_u_u(g_101, (((*l_161) = ((safe_lshift_func_uint16_t_u_s((((((*l_160) &= 0x30A7L) != g_101) , l_96) || p_73), 3)) ^ p_74)) != l_96)))), g_105)) || g_113[0][0]))
                    { /* block id: 36 */
                        union U0 *l_165 = &g_166[3];
                        union U0 **l_164[6] = {&l_165,&l_165,&l_165,&l_165,&l_165,&l_165};
                        int i;
                        (*g_163) = (*g_137);
                        if ((*g_137))
                            break;
                        g_167 = (void*)0;
                        if ((*g_137))
                            break;
                    }
                    else
                    { /* block id: 41 */
                        int32_t *l_168 = &l_126;
                        int32_t *l_169 = &l_126;
                        int32_t *l_170 = &l_126;
                        int32_t *l_171 = &l_147;
                        int32_t *l_172 = &l_126;
                        int32_t *l_173[6][4] = {{(void*)0,&g_101,(void*)0,(void*)0},{&l_147,&l_147,(void*)0,(void*)0},{&g_101,&g_101,&g_101,(void*)0},{&g_101,(void*)0,(void*)0,&g_101},{&l_147,(void*)0,(void*)0,(void*)0},{(void*)0,&g_101,(void*)0,(void*)0}};
                        int32_t l_182 = 1L;
                        uint8_t l_183[10][1] = {{2UL},{0x03L},{2UL},{0x03L},{2UL},{0x03L},{2UL},{0x03L},{2UL},{0x03L}};
                        int i, j;
                        ++g_177;
                        --l_183[6][0];
                    }
                    --g_196;
                    --g_199;
                }
                for (l_126 = 0; (l_126 <= 0); l_126 += 1)
                { /* block id: 50 */
                    int32_t *l_202 = &l_175;
                    int32_t *l_203 = (void*)0;
                    int32_t *l_204[2];
                    int64_t l_206 = 0L;
                    uint16_t l_207 = 0UL;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_204[i] = &l_181;
                    l_207--;
                    (*l_202) = (l_114 == &l_207);
                }
                (*l_211) = (void*)0;
            }
            for (p_73 = 4; (p_73 >= 0); p_73 -= 1)
            { /* block id: 58 */
                uint16_t *l_222 = &l_95;
                int32_t *l_227 = (void*)0;
                int32_t *l_228 = &l_192[1];
                l_194 = ((*l_228) = (p_73 < (safe_mod_func_uint16_t_u_u((!(safe_add_func_int32_t_s_s((-8L), (g_189 | ((safe_add_func_uint8_t_u_u((((l_194 == ((*l_222) = (safe_lshift_func_int8_t_s_u(l_94, 3)))) && (safe_add_func_int32_t_s_s((safe_sub_func_uint32_t_u_u(((*l_108) = ((((g_166[3].f1 && g_166[3].f1) >= ((*l_222) = (((g_196 = 0xC7L) & ((g_113[0][0] , &g_100) != l_99)) , 65528UL))) ^ g_149) > p_73)), g_101)), p_75))) != p_76), 0x9BL)) , 0L))))), 7UL))));
                for (l_181 = 0; (l_181 <= 0); l_181 += 1)
                { /* block id: 67 */
                    for (l_194 = 0; (l_194 <= 0); l_194 += 1)
                    { /* block id: 70 */
                        (*l_228) = (p_74 && (1UL != (!1L)));
                        (*l_228) = (-2L);
                        return p_74;
                    }
                }
                g_137 = &g_101;
                (*l_228) = ((*g_163) = (*g_163));
            }
            for (g_115 = 0; g_115 < 1; g_115 += 1)
            {
                for (l_126 = 0; l_126 < 9; l_126 += 1)
                {
                    g_133[g_115][l_126] = 0xCD69E2DAL;
                }
            }
        }
        for (g_101 = 0; (g_101 <= 0); g_101 += 1)
        { /* block id: 84 */
            uint16_t *l_230 = &l_95;
            uint64_t *l_237 = &g_162;
            union U0 *l_240 = &g_166[4];
            union U0 **l_242 = (void*)0;
            union U0 *l_243 = &g_166[3];
            uint32_t *l_248 = (void*)0;
            int32_t *l_249 = &l_194;
            union U0 **l_260 = (void*)0;
            int32_t l_293 = 0x53CF452AL;
            int32_t l_297[4] = {0x33D1B2EEL,0x33D1B2EEL,0x33D1B2EEL,0x33D1B2EEL};
            const int64_t l_333 = 0x3BF655A909A3CD57LL;
            int i;
            (*l_249) = (((*l_230) = l_194) || ((safe_div_func_int16_t_s_s(l_194, (safe_mod_func_uint64_t_u_u(g_190, (safe_rshift_func_int8_t_s_u(((--(*l_237)) < ((((l_240 != (l_243 = l_241)) == (++(*l_230))) & g_133[0][8]) , (safe_unary_minus_func_int64_t_s(g_193)))), (safe_unary_minus_func_uint8_t_u(((l_248 == (void*)0) == g_190))))))))) > p_76));
        }
        for (g_367 = 0; (g_367 <= 0); g_367 += 1)
        { /* block id: 147 */
            int8_t l_369 = 0x6AL;
            for (g_190 = 0; (g_190 >= 0); g_190 -= 1)
            { /* block id: 150 */
                return l_369;
            }
        }
    }
    return l_96;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_40[i].f0, "g_40[i].f0", print_hash_value);
        transparent_crc(g_40[i].f1, "g_40[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_109[i], "g_109[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_113[i][j], "g_113[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_133[i][j], "g_133[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_166[i].f1, "g_166[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_189, "g_189", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_193, "g_193", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_195[i][j], "g_195[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_196, "g_196", print_hash_value);
    transparent_crc(g_199, "g_199", print_hash_value);
    transparent_crc(g_251, "g_251", print_hash_value);
    transparent_crc(g_274, "g_274", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_298[i][j][k], "g_298[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_315[i][j], "g_315[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_316, "g_316", print_hash_value);
    transparent_crc(g_318, "g_318", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_349[i], "g_349[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_359[i].f0, "g_359[i].f0", print_hash_value);
        transparent_crc(g_359[i].f1, "g_359[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_367, "g_367", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_387[i][j][k], "g_387[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_394, "g_394", print_hash_value);
    transparent_crc(g_528.f0, "g_528.f0", print_hash_value);
    transparent_crc(g_528.f1, "g_528.f1", print_hash_value);
    transparent_crc(g_551.f0, "g_551.f0", print_hash_value);
    transparent_crc(g_551.f1, "g_551.f1", print_hash_value);
    transparent_crc(g_592, "g_592", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_648[i][j][k], "g_648[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_718, "g_718", print_hash_value);
    transparent_crc(g_747.f0, "g_747.f0", print_hash_value);
    transparent_crc(g_747.f1, "g_747.f1", print_hash_value);
    transparent_crc(g_755, "g_755", print_hash_value);
    transparent_crc(g_826.f0, "g_826.f0", print_hash_value);
    transparent_crc(g_826.f1, "g_826.f1", print_hash_value);
    transparent_crc(g_964.f0, "g_964.f0", print_hash_value);
    transparent_crc(g_964.f1, "g_964.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_998[i][j][k], "g_998[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1088.f1, "g_1088.f1", print_hash_value);
    transparent_crc(g_1168, "g_1168", print_hash_value);
    transparent_crc(g_1199, "g_1199", print_hash_value);
    transparent_crc(g_1270, "g_1270", print_hash_value);
    transparent_crc(g_1339.f0, "g_1339.f0", print_hash_value);
    transparent_crc(g_1339.f1, "g_1339.f1", print_hash_value);
    transparent_crc(g_1355.f0, "g_1355.f0", print_hash_value);
    transparent_crc(g_1355.f1, "g_1355.f1", print_hash_value);
    transparent_crc(g_1375, "g_1375", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1389[i][j][k].f0, "g_1389[i][j][k].f0", print_hash_value);
                transparent_crc(g_1389[i][j][k].f1, "g_1389[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1464.f0, "g_1464.f0", print_hash_value);
    transparent_crc(g_1464.f1, "g_1464.f1", print_hash_value);
    transparent_crc(g_1520.f0, "g_1520.f0", print_hash_value);
    transparent_crc(g_1520.f1, "g_1520.f1", print_hash_value);
    transparent_crc(g_1525, "g_1525", print_hash_value);
    transparent_crc(g_1532, "g_1532", print_hash_value);
    transparent_crc(g_1810, "g_1810", print_hash_value);
    transparent_crc(g_1845, "g_1845", print_hash_value);
    transparent_crc(g_1893, "g_1893", print_hash_value);
    transparent_crc(g_2032.f0, "g_2032.f0", print_hash_value);
    transparent_crc(g_2032.f1, "g_2032.f1", print_hash_value);
    transparent_crc(g_2044.f1, "g_2044.f1", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2045[i].f0, "g_2045[i].f0", print_hash_value);
        transparent_crc(g_2045[i].f1, "g_2045[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2046, "g_2046", print_hash_value);
    transparent_crc(g_2048, "g_2048", print_hash_value);
    transparent_crc(g_2146, "g_2146", print_hash_value);
    transparent_crc(g_2183, "g_2183", print_hash_value);
    transparent_crc(g_2198.f1, "g_2198.f1", print_hash_value);
    transparent_crc(g_2199.f0, "g_2199.f0", print_hash_value);
    transparent_crc(g_2199.f1, "g_2199.f1", print_hash_value);
    transparent_crc(g_2205.f0, "g_2205.f0", print_hash_value);
    transparent_crc(g_2205.f1, "g_2205.f1", print_hash_value);
    transparent_crc(g_2238, "g_2238", print_hash_value);
    transparent_crc(g_2260, "g_2260", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_2263[i][j].f0, "g_2263[i][j].f0", print_hash_value);
            transparent_crc(g_2263[i][j].f1, "g_2263[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2268.f1, "g_2268.f1", print_hash_value);
    transparent_crc(g_2311.f0, "g_2311.f0", print_hash_value);
    transparent_crc(g_2311.f1, "g_2311.f1", print_hash_value);
    transparent_crc(g_2312.f1, "g_2312.f1", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_2326[i][j][k], "g_2326[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2328.f1, "g_2328.f1", print_hash_value);
    transparent_crc(g_2350, "g_2350", print_hash_value);
    transparent_crc(g_2405, "g_2405", print_hash_value);
    transparent_crc(g_2457, "g_2457", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2459[i].f0, "g_2459[i].f0", print_hash_value);
        transparent_crc(g_2459[i].f1, "g_2459[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2499.f0, "g_2499.f0", print_hash_value);
    transparent_crc(g_2499.f1, "g_2499.f1", print_hash_value);
    transparent_crc(g_2555.f0, "g_2555.f0", print_hash_value);
    transparent_crc(g_2555.f1, "g_2555.f1", print_hash_value);
    transparent_crc(g_2595.f0, "g_2595.f0", print_hash_value);
    transparent_crc(g_2595.f1, "g_2595.f1", print_hash_value);
    transparent_crc(g_2644, "g_2644", print_hash_value);
    transparent_crc(g_2650, "g_2650", print_hash_value);
    transparent_crc(g_2672, "g_2672", print_hash_value);
    transparent_crc(g_2745.f0, "g_2745.f0", print_hash_value);
    transparent_crc(g_2745.f1, "g_2745.f1", print_hash_value);
    transparent_crc(g_2870, "g_2870", print_hash_value);
    transparent_crc(g_2901, "g_2901", print_hash_value);
    transparent_crc(g_2915, "g_2915", print_hash_value);
    transparent_crc(g_2927.f0, "g_2927.f0", print_hash_value);
    transparent_crc(g_2927.f1, "g_2927.f1", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2979[i].f0, "g_2979[i].f0", print_hash_value);
        transparent_crc(g_2979[i].f1, "g_2979[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3001.f0, "g_3001.f0", print_hash_value);
    transparent_crc(g_3001.f1, "g_3001.f1", print_hash_value);
    transparent_crc(g_3005.f0, "g_3005.f0", print_hash_value);
    transparent_crc(g_3005.f1, "g_3005.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3035[i], "g_3035[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3082, "g_3082", print_hash_value);
    transparent_crc(g_3152.f0, "g_3152.f0", print_hash_value);
    transparent_crc(g_3152.f1, "g_3152.f1", print_hash_value);
    transparent_crc(g_3173.f0, "g_3173.f0", print_hash_value);
    transparent_crc(g_3173.f1, "g_3173.f1", print_hash_value);
    transparent_crc(g_3184, "g_3184", print_hash_value);
    transparent_crc(g_3209.f0, "g_3209.f0", print_hash_value);
    transparent_crc(g_3209.f1, "g_3209.f1", print_hash_value);
    transparent_crc(g_3279, "g_3279", print_hash_value);
    transparent_crc(g_3287, "g_3287", print_hash_value);
    transparent_crc(g_3290.f0, "g_3290.f0", print_hash_value);
    transparent_crc(g_3290.f1, "g_3290.f1", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_3438[i][j].f0, "g_3438[i][j].f0", print_hash_value);
            transparent_crc(g_3438[i][j].f1, "g_3438[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3520.f0, "g_3520.f0", print_hash_value);
    transparent_crc(g_3520.f1, "g_3520.f1", print_hash_value);
    transparent_crc(g_3546, "g_3546", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 948
XXX total union variables: 35

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 43
breakdown:
   depth: 1, occurrence: 325
   depth: 2, occurrence: 98
   depth: 3, occurrence: 8
   depth: 4, occurrence: 3
   depth: 5, occurrence: 5
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 5
   depth: 18, occurrence: 4
   depth: 19, occurrence: 3
   depth: 20, occurrence: 4
   depth: 21, occurrence: 5
   depth: 22, occurrence: 1
   depth: 23, occurrence: 6
   depth: 25, occurrence: 2
   depth: 26, occurrence: 5
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 3
   depth: 30, occurrence: 2
   depth: 31, occurrence: 2
   depth: 32, occurrence: 2
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 2
   depth: 42, occurrence: 2
   depth: 43, occurrence: 1

XXX total number of pointers: 795

XXX times a variable address is taken: 1810
XXX times a pointer is dereferenced on RHS: 392
breakdown:
   depth: 1, occurrence: 267
   depth: 2, occurrence: 68
   depth: 3, occurrence: 56
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 447
breakdown:
   depth: 1, occurrence: 362
   depth: 2, occurrence: 60
   depth: 3, occurrence: 23
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 71
XXX times a pointer is compared with address of another variable: 26
XXX times a pointer is compared with another pointer: 22
XXX times a pointer is qualified to be dereferenced: 12834

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1975
   level: 2, occurrence: 594
   level: 3, occurrence: 385
   level: 4, occurrence: 50
   level: 5, occurrence: 4
XXX number of pointers point to pointers: 326
XXX number of pointers point to scalars: 441
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.1
XXX average alias set size: 1.45

XXX times a non-volatile is read: 2807
XXX times a non-volatile is write: 1422
XXX times a volatile is read: 140
XXX    times read thru a pointer: 4
XXX times a volatile is write: 42
XXX    times written thru a pointer: 5
XXX times a volatile is available for access: 1.06e+04
XXX percentage of non-volatile access: 95.9

XXX forward jumps: 1
XXX backward jumps: 13

XXX stmts: 351
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 33
   depth: 2, occurrence: 41
   depth: 3, occurrence: 60
   depth: 4, occurrence: 84
   depth: 5, occurrence: 105

XXX percentage a fresh-made variable is used: 17.6
XXX percentage an existing variable is used: 82.4
********************* end of statistics **********************/

