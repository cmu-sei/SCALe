/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4035508031
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static const volatile int8_t g_20 = 0xC0L;/* VOLATILE GLOBAL g_20 */
static int32_t g_31 = 0L;
static int32_t *g_30 = &g_31;
static int16_t g_39 = 0xB903L;
static struct S0 g_52 = {18446744073709551611UL};
static int16_t g_77[2][10][1] = {{{0xAE52L},{0xEF11L},{0xA070L},{0xA070L},{0xEF11L},{0xAE52L},{0x2740L},{0xAE52L},{0xEF11L},{0xA070L}},{{0xA070L},{0xEF11L},{0xAE52L},{0x2740L},{0xAE52L},{0xEF11L},{0xA070L},{0xA070L},{0xEF11L},{0xAE52L}}};
static uint16_t g_90[5][9] = {{65533UL,0x3BBCL,65535UL,65535UL,0x3BBCL,65533UL,0x3BBCL,65535UL,65535UL},{1UL,1UL,65533UL,65535UL,65533UL,1UL,1UL,65533UL,65535UL},{6UL,0x3BBCL,6UL,65533UL,65533UL,6UL,0x3BBCL,6UL,6UL},{65535UL,6UL,6UL,65535UL,1UL,65535UL,6UL,6UL,65535UL},{65533UL,6UL,0x3BBCL,6UL,65533UL,65533UL,6UL,0x3BBCL,6UL}};
static int64_t g_93 = 0x4FAB08463F95669DLL;
static int64_t g_95 = 0xEB85967819277EF9LL;
static int32_t g_98[3][9][9] = {{{9L,9L,0xF56F3C4EL,3L,0xEFA9ADBFL,0x797F7BC9L,0x797F7BC9L,0xEFA9ADBFL,3L},{5L,0L,5L,1L,(-1L),1L,0x067E36F2L,7L,(-1L)},{0xEFA9ADBFL,(-9L),9L,0L,(-5L),0x65C6936EL,0x8DD85FC2L,3L,1L},{0L,(-3L),(-4L),1L,(-2L),4L,0x37768238L,0x453ACC8DL,0L},{0x6474A040L,(-1L),0x02138E64L,3L,1L,0x4517DE86L,(-1L),0xD70CC316L,0x52A621C2L},{0x18651235L,0L,(-1L),0x5A511998L,0x3CB19522L,7L,0L,0L,7L},{0x4517DE86L,0L,(-3L),0L,0x4517DE86L,9L,(-7L),(-5L),(-9L)},{8L,0x566F38F6L,0xD4F1ACCAL,7L,5L,(-10L),(-8L),(-1L),0L},{0xECBAE8C6L,(-3L),(-1L),0x8DD85FC2L,9L,9L,1L,8L,(-7L)}},{{0L,0x453ACC8DL,0x3CB19522L,8L,1L,7L,0xFE8B44A6L,8L,0xEAA6BC85L},{1L,(-1L),0xEFA9ADBFL,0L,(-1L),0x4517DE86L,(-3L),0x3138B78EL,0x3138B78EL},{0L,4L,(-1L),5L,(-1L),4L,0L,0L,0xD4F1ACCAL},{0L,0xD60A67ACL,0L,0xFABE471AL,0xEBF9D6D6L,0x65C6936EL,0xECBAE8C6L,0x52A621C2L,0x6474A040L},{0x067E36F2L,0x04770596L,0x6CD8D342L,0xFE8B44A6L,0xB685EF4CL,1L,0xB756FC10L,0L,0xA554F1F2L},{(-1L),0x8DD85FC2L,(-9L),0x99FDCBA9L,(-7L),0x797F7BC9L,0L,0x3138B78EL,1L},{0x2FCB8F78L,0x2AF6298AL,4L,0x3CB19522L,(-4L),0L,1L,8L,0L},{(-1L),8L,9L,0xE572A963L,0xD60A67ACL,0xE572A963L,9L,8L,(-1L)},{0x3CB19522L,0xB685EF4CL,0x5A511998L,4L,0xC13D3DF2L,0xFE8B44A6L,0x2FCB8F78L,(-1L),0x566F38F6L}},{{(-3L),0L,0x52A621C2L,(-1L),9L,0xEFA9ADBFL,0x02138E64L,(-5L),0x8ABD3BCAL},{0x3CB19522L,0xB756FC10L,0x453ACC8DL,0x04770596L,0L,0L,0x8A746704L,0xC13D3DF2L,0L},{(-3L),0xEBF9D6D6L,4L,9L,1L,0x52A621C2L,(-7L),(-1L),0xE572A963L},{0x453ACC8DL,4L,0L,0x3CB19522L,0L,7L,0L,0x3CB19522L,0L},{(-7L),(-7L),0L,(-1L),0xEFA9ADBFL,(-9L),9L,0L,(-5L)},{1L,0xC13D3DF2L,(-1L),0L,4L,0L,0L,(-10L),0x04770596L},{0L,0x3138B78EL,0L,(-1L),1L,(-7L),0x52A621C2L,1L,(-1L)},{7L,1L,0L,0x18651235L,(-10L),0xEAA6BC85L,0x3CB19522L,0x37768238L,0xD4F1ACCAL},{9L,(-1L),4L,0xE572A963L,0L,0x3138B78EL,0L,0x3138B78EL,0L}}};
static int32_t g_100 = 0L;
static uint32_t g_126 = 1UL;
static struct S0 g_131 = {0x44F0331C24E8149FLL};
static uint32_t g_146 = 0x7AFFF8E3L;
static int16_t g_231 = (-2L);
static int16_t g_242 = 0L;
static volatile uint8_t *g_274 = (void*)0;
static uint64_t g_357[2][1] = {{18446744073709551606UL},{18446744073709551606UL}};
static uint32_t g_358 = 0x2B0756A2L;
static struct S0 *g_362 = &g_52;
static struct S0 * volatile *g_361 = &g_362;
static int32_t g_392 = (-1L);
static const volatile int32_t g_441 = 0L;/* VOLATILE GLOBAL g_441 */
static const volatile int32_t *g_440 = &g_441;
static const volatile int32_t * volatile *g_439 = &g_440;
static const volatile int32_t * volatile **g_438 = &g_439;
static int32_t *g_448 = (void*)0;
static const uint8_t *g_490 = (void*)0;
static const uint8_t **g_489 = &g_490;
static uint8_t g_527 = 0xEDL;
static uint8_t *g_526 = &g_527;
static int32_t g_558 = 0x709FF2F6L;
static struct S0 **g_686 = &g_362;
static struct S0 ***g_685[8][5][5] = {{{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{(void*)0,&g_686,&g_686,&g_686,&g_686},{&g_686,(void*)0,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686}},{{&g_686,(void*)0,(void*)0,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,(void*)0,&g_686},{&g_686,&g_686,(void*)0,&g_686,&g_686},{(void*)0,&g_686,(void*)0,&g_686,&g_686}},{{&g_686,&g_686,(void*)0,&g_686,&g_686},{&g_686,(void*)0,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,(void*)0,&g_686,&g_686}},{{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{(void*)0,&g_686,(void*)0,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686}},{{&g_686,&g_686,&g_686,&g_686,&g_686},{(void*)0,&g_686,(void*)0,&g_686,&g_686},{&g_686,(void*)0,&g_686,(void*)0,&g_686},{&g_686,&g_686,&g_686,(void*)0,&g_686},{&g_686,&g_686,&g_686,&g_686,&g_686}},{{&g_686,&g_686,(void*)0,&g_686,&g_686},{(void*)0,&g_686,&g_686,&g_686,&g_686},{&g_686,&g_686,&g_686,(void*)0,(void*)0},{&g_686,(void*)0,&g_686,(void*)0,&g_686},{&g_686,&g_686,(void*)0,(void*)0,&g_686}},{{&g_686,&g_686,&g_686,&g_686,&g_686},{&g_686,(void*)0,(void*)0,&g_686,&g_686},{&g_686,&g_686,&g_686,(void*)0,(void*)0},{&g_686,&g_686,&g_686,&g_686,&g_686},{(void*)0,&g_686,&g_686,&g_686,&g_686}},{{&g_686,&g_686,(void*)0,&g_686,&g_686},{&g_686,&g_686,&g_686,&g_686,(void*)0},{&g_686,(void*)0,&g_686,&g_686,&g_686},{(void*)0,&g_686,&g_686,&g_686,(void*)0},{&g_686,(void*)0,(void*)0,(void*)0,&g_686}}};
static int32_t *g_754 = &g_558;
static uint32_t g_888 = 0x583A0F50L;
static int64_t *g_894[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int64_t **g_893[4] = {&g_894[0],&g_894[0],&g_894[0],&g_894[0]};
static uint32_t g_898 = 4294967295UL;
static uint8_t g_908 = 0xC1L;
static const uint32_t g_971[1] = {0x82398447L};
static uint64_t g_1003[9] = {0xBD87979485699AE6LL,0xBD87979485699AE6LL,0xF652F60BC143ACB0LL,0xBD87979485699AE6LL,0xBD87979485699AE6LL,0xF652F60BC143ACB0LL,0xBD87979485699AE6LL,0xBD87979485699AE6LL,0xF652F60BC143ACB0LL};
static uint32_t g_1057 = 0x84791607L;
static uint16_t g_1060 = 65535UL;
static const int32_t g_1080 = 7L;
static const int32_t *g_1079 = &g_1080;
static const int32_t **g_1078 = &g_1079;
static int32_t g_1128[5] = {1L,1L,1L,1L,1L};
static uint32_t g_1151[2][4][4] = {{{3UL,0x5D91C2B8L,0xE7E7859FL,3UL},{1UL,0x5D91C2B8L,3UL,0x5D91C2B8L},{0x5D91C2B8L,0x56EC0529L,0x97CFBEC1L,0x7B09C101L},{0xFB9FD1BCL,1UL,0xE7E7859FL,0x97CFBEC1L}},{{0xB475702CL,0x4BDF81A1L,0x82882906L,0x5D91C2B8L},{0xB475702CL,0xE7E7859FL,0xE7E7859FL,0xB475702CL},{0xFB9FD1BCL,0x5D91C2B8L,0x97CFBEC1L,0xE7E7859FL},{0x5D91C2B8L,0x4BDF81A1L,3UL,0x7B09C101L}}};
static uint32_t g_1173 = 4294967292UL;
static uint16_t g_1189 = 0x3B1DL;
static uint16_t *g_1194 = &g_1189;
static uint16_t * volatile *g_1193 = &g_1194;
static uint8_t ***g_1216 = (void*)0;
static int32_t **g_1236 = &g_448;
static int8_t g_1276 = (-1L);
static int32_t * volatile g_1379 = &g_100;/* VOLATILE GLOBAL g_1379 */
static int32_t * const  volatile g_1442 = &g_98[0][7][6];/* VOLATILE GLOBAL g_1442 */
static int32_t ** volatile g_1443 = &g_30;/* VOLATILE GLOBAL g_1443 */
static int32_t g_1458 = (-1L);
static int16_t g_1501 = (-6L);
static volatile uint32_t g_1555 = 0UL;/* VOLATILE GLOBAL g_1555 */
static volatile uint64_t g_1569 = 0UL;/* VOLATILE GLOBAL g_1569 */
static volatile uint64_t *g_1568 = &g_1569;
static volatile uint64_t **g_1567 = &g_1568;
static int32_t *g_1576 = &g_100;
static struct S0 g_1658 = {0x5059347BE57B9261LL};
static int32_t *g_1660 = (void*)0;
static struct S0 * const  volatile g_1701 = &g_131;/* VOLATILE GLOBAL g_1701 */
static uint8_t ****g_1742 = &g_1216;
static uint8_t ****g_1743 = &g_1216;
static uint8_t ****g_1744 = &g_1216;
static int32_t *g_1746 = &g_98[1][1][3];
static volatile int32_t g_1766 = 6L;/* VOLATILE GLOBAL g_1766 */
static volatile int32_t *g_1765 = &g_1766;
static volatile int32_t * volatile *g_1764 = &g_1765;
static volatile int32_t * volatile ** volatile g_1763[7][1] = {{&g_1764},{&g_1764},{&g_1764},{&g_1764},{&g_1764},{&g_1764},{&g_1764}};
static volatile int32_t * volatile ** volatile * volatile g_1762[8][6] = {{&g_1763[4][0],(void*)0,&g_1763[1][0],&g_1763[4][0],&g_1763[4][0],&g_1763[4][0]},{(void*)0,(void*)0,(void*)0,&g_1763[4][0],&g_1763[4][0],&g_1763[1][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_1763[4][0]},{&g_1763[4][0],&g_1763[4][0],&g_1763[1][0],(void*)0,&g_1763[4][0],&g_1763[4][0]},{(void*)0,&g_1763[4][0],&g_1763[4][0],&g_1763[4][0],&g_1763[4][0],(void*)0},{(void*)0,&g_1763[4][0],&g_1763[4][0],&g_1763[4][0],(void*)0,(void*)0},{&g_1763[4][0],(void*)0,&g_1763[4][0],&g_1763[1][0],&g_1763[4][0],&g_1763[4][0]},{&g_1763[4][0],&g_1763[0][0],&g_1763[4][0],&g_1763[4][0],(void*)0,&g_1763[4][0]}};
static const volatile int32_t * volatile g_1873 = (void*)0;/* VOLATILE GLOBAL g_1873 */
static volatile uint8_t g_1992 = 255UL;/* VOLATILE GLOBAL g_1992 */
static uint8_t g_2030 = 0x53L;
static volatile int16_t g_2043 = 1L;/* VOLATILE GLOBAL g_2043 */
static volatile int16_t * volatile g_2042[9] = {&g_2043,&g_2043,&g_2043,&g_2043,&g_2043,&g_2043,&g_2043,&g_2043,&g_2043};
static volatile int16_t * volatile *g_2041[4] = {&g_2042[8],&g_2042[8],&g_2042[8],&g_2042[8]};
static int64_t ****g_2109 = (void*)0;
static int64_t ****g_2111 = (void*)0;
static int64_t ***g_2117 = &g_893[3];
static int64_t ****g_2116 = &g_2117;
static int64_t *****g_2142 = (void*)0;
static uint8_t * volatile * volatile g_2257 = &g_526;/* VOLATILE GLOBAL g_2257 */
static uint8_t * volatile * volatile *g_2256 = &g_2257;
static uint8_t * volatile * volatile * volatile * volatile g_2255 = &g_2256;/* VOLATILE GLOBAL g_2255 */
static int8_t g_2343[3][8][8] = {{{(-1L),0x7FL,0xE4L,(-1L),0x35L,(-1L),0x35L,(-1L)},{0xF7L,0x35L,0xF7L,0x5DL,(-1L),(-1L),0x5DL,0x7FL},{0x35L,0xD1L,(-1L),0xE6L,0L,1L,(-1L),0xD1L},{0x35L,0x7FL,0x6DL,(-1L),(-1L),0x6DL,0x7FL,0x35L},{0xF7L,(-1L),0xD1L,1L,0x35L,7L,0xF7L,0x7FL},{(-1L),1L,0x5DL,0xE9L,1L,7L,(-1L),7L},{0xE6L,(-1L),0x4AL,(-1L),0xE6L,0x6DL,0xE9L,0xE6L},{7L,0x7FL,0xF7L,7L,0x35L,1L,0xD1L,(-1L)}},{{0x7FL,0xD1L,0xF7L,0xE9L,(-1L),(-1L),0xE9L,0xF7L},{0x35L,0x35L,0x4AL,0xE6L,0x9CL,(-1L),(-1L),0x35L},{0xD1L,0x7FL,0x5DL,(-1L),(-1L),0x5DL,0xF7L,0x35L},{0x7FL,7L,0xD1L,0xE6L,0xD1L,7L,0x7FL,0xF7L},{(-1L),0xE6L,0x6DL,0xE9L,0xE6L,1L,(-1L),(-1L)},{1L,(-1L),(-1L),7L,0xE6L,0x5DL,0x5DL,0xE6L},{(-1L),0xF7L,0xF7L,(-1L),0xD1L,1L,0x35L,7L},{0x7FL,0x35L,0xE4L,0xE9L,(-1L),0x4AL,0xE9L,0x7FL}},{{0xD1L,0x35L,(-1L),1L,0x9CL,1L,(-1L),0x35L},{0x35L,0xF7L,0x5DL,(-1L),(-1L),0x5DL,0x7FL,0xD1L},{0x7FL,(-1L),0xA4L,0xE6L,0x35L,1L,0x7FL,0x7FL},{7L,0xE6L,0x5DL,0x5DL,0xE6L,7L,(-1L),(-1L)},{0xE6L,7L,(-1L),(-1L),1L,0x5DL,0xE9L,1L},{(-1L),0x7FL,0xE4L,(-1L),0L,0xE9L,0L,0xF7L},{(-1L),0L,(-1L),0x4AL,0xD1L,0xA4L,0x4AL,1L},{0L,0x9EL,0xA4L,0x5DL,1L,0x6DL,0xD1L,0x9EL}}};
static uint64_t *g_2353 = &g_1003[0];
static uint64_t **g_2352 = &g_2353;
static const int32_t *g_2364 = (void*)0;
static const int32_t **g_2363 = &g_2364;
static const int32_t ***g_2362 = &g_2363;
static struct S0 *** volatile g_2443 = &g_686;/* VOLATILE GLOBAL g_2443 */
static int16_t *g_2460[3][10][1] = {{{&g_77[1][7][0]},{&g_231},{(void*)0},{(void*)0},{(void*)0},{&g_231},{&g_77[1][7][0]},{&g_231},{&g_77[1][7][0]},{(void*)0}},{{&g_77[1][7][0]},{(void*)0},{&g_77[1][7][0]},{&g_231},{&g_77[1][7][0]},{&g_231},{(void*)0},{(void*)0},{(void*)0},{&g_231}},{{&g_77[1][7][0]},{&g_231},{&g_77[1][7][0]},{(void*)0},{&g_77[1][7][0]},{(void*)0},{&g_77[1][7][0]},{&g_231},{&g_77[1][7][0]},{&g_231}}};
static int16_t **g_2459 = &g_2460[1][4][0];
static volatile int32_t g_2603[3][10] = {{1L,9L,1L,9L,1L,9L,1L,9L,1L,9L},{1L,9L,1L,9L,1L,9L,1L,9L,1L,9L},{1L,9L,1L,9L,1L,9L,1L,9L,1L,9L}};
static int32_t **g_2664[2][3][7] = {{{&g_754,&g_754,(void*)0,&g_754,&g_754,(void*)0,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754}},{{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{(void*)0,&g_754,&g_754,&g_754,&g_754,(void*)0,&g_754}}};
static const uint8_t ***g_2676 = &g_489;
static uint32_t g_2737 = 1UL;
static int16_t g_2776[4] = {(-1L),(-1L),(-1L),(-1L)};
static int64_t g_2786 = 0xB99492F142BE87F0LL;
static volatile uint8_t g_2791 = 0x0DL;/* VOLATILE GLOBAL g_2791 */
static struct S0 * volatile g_2857 = &g_1658;/* VOLATILE GLOBAL g_2857 */
static volatile int8_t g_2863 = 2L;/* VOLATILE GLOBAL g_2863 */
static const uint64_t g_2975 = 0xD261DBEBE2A373D9LL;
static const uint64_t *g_2974 = &g_2975;
static volatile int32_t g_3053 = 1L;/* VOLATILE GLOBAL g_3053 */
static int64_t g_3114 = 0x1C29AB91E7BB50FDLL;
static volatile int32_t g_3118 = 0x1A2DEC1FL;/* VOLATILE GLOBAL g_3118 */
static volatile int16_t g_3155[9] = {0x822AL,0x2A2FL,0x2A2FL,0x822AL,0x2A2FL,0x2A2FL,0x822AL,0x2A2FL,0x2A2FL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t * func_2(int32_t * p_3);
static int32_t * func_4(struct S0  p_5);
static struct S0  func_6(int32_t * p_7, uint16_t  p_8, int32_t * p_9, int32_t * const  p_10);
static int32_t * func_11(uint32_t  p_12, uint32_t  p_13, int32_t  p_14);
static uint8_t  func_25(struct S0  p_26, int32_t * p_27, int32_t * p_28);
static int32_t * func_32(int32_t * p_33, int16_t  p_34, const int32_t  p_35, int32_t * p_36, int8_t  p_37);
static struct S0  func_40(uint32_t  p_41, uint64_t  p_42, int8_t  p_43);
static const int16_t  func_54(int32_t  p_55, int32_t * p_56, int16_t * p_57);
static int32_t * func_58(int32_t * p_59, uint16_t  p_60, int32_t * p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_20 g_30 g_31 g_52 g_77 g_90 g_93 g_95 g_98 g_100 g_448 g_438 g_439 g_358 g_357 g_362 g_361 g_126 g_39 g_392 g_146 g_526 g_242 g_685 g_527 g_558 g_686 g_908 g_898 g_971 g_888 g_231 g_131.f0 g_1003 g_1080 g_1128 g_1189 g_1193 g_1194 g_1057 g_1079 g_1173 g_440 g_441 g_1379 g_1236 g_1151 g_1442 g_1443 g_1060 g_1555 g_1567 g_1576 g_1276 g_894 g_1701 g_1568 g_1569 g_1658.f0 g_1746 g_1762 g_131 g_1766 g_1501 g_2030 g_2041 g_2109 g_2111 g_2255 g_2256 g_2257 g_2343 g_754
 * writes: g_39 g_77 g_90 g_93 g_98 g_100 g_126 g_131 g_448 g_357 g_358 g_146 g_52 g_95 g_527 g_31 g_242 g_362 g_30 g_685 g_231 g_754 g_686 g_439 g_1003 g_1078 g_1189 g_898 g_392 g_893 g_1173 g_888 g_1057 g_1276 g_1501 g_1555 g_1060 g_1658.f0 g_1742 g_1743 g_1744 g_440 g_1151 g_1992 g_2030 g_2109 g_2111 g_2116 g_908
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_15 = 8L;
    struct S0 l_29 = {0x073046773196E86FLL};
    int16_t *l_38 = &g_39;
    int32_t *l_566[10][5] = {{&g_31,&g_31,(void*)0,&g_31,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,(void*)0},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,&g_31},{&g_31,&g_31,(void*)0,&g_31,(void*)0}};
    uint8_t l_567[4][6][8] = {{{1UL,9UL,251UL,0UL,0UL,251UL,0UL,9UL},{0xBAL,0x59L,0UL,9UL,1UL,0x2AL,4UL,0x35L},{0UL,0xAAL,0x43L,4UL,9UL,0x2AL,0UL,1UL},{0x2AL,0x59L,0x75L,5UL,0x75L,0x59L,0x2AL,0x14L},{1UL,0UL,0xBDL,1UL,0UL,9UL,0x43L,1UL},{0x84L,0x43L,1UL,0x35L,0UL,0xBAL,5UL,5UL}},{{1UL,0x75L,1UL,1UL,0x75L,1UL,249UL,0x84L},{0x2AL,0xBDL,0x84L,0x59L,9UL,0x3CL,9UL,251UL},{0UL,1UL,249UL,0x59L,1UL,0x84L,0xAAL,0x84L},{0xBAL,1UL,4UL,1UL,0xBAL,0x43L,9UL,5UL},{9UL,0x84L,0x3CL,0x35L,5UL,0xBDL,1UL,1UL},{4UL,249UL,0x3CL,1UL,0x14L,9UL,9UL,0x14L}},{{5UL,4UL,4UL,5UL,0x59L,251UL,0xAAL,1UL},{1UL,0x3CL,249UL,4UL,251UL,0x75L,9UL,0x35L},{0x35L,0x3CL,0x84L,9UL,249UL,251UL,249UL,9UL},{1UL,4UL,1UL,0xBAL,0x43L,9UL,5UL,249UL},{0x59L,249UL,1UL,0UL,4UL,0xBDL,0x43L,0x3CL},{0x59L,0x84L,0xBDL,0x2AL,0x43L,0x43L,0x2AL,0xBDL}},{{1UL,1UL,0x75L,1UL,249UL,0x84L,0UL,0xAAL},{0x35L,1UL,0x43L,0x84L,251UL,0x3CL,4UL,0xAAL},{1UL,0xBDL,0UL,1UL,0x59L,1UL,0UL,0xBDL},{5UL,0x75L,0x59L,0x2AL,0x14L,0xBAL,0xBDL,0x3CL},{4UL,0x43L,0xAAL,0UL,5UL,9UL,0xBDL,249UL},{9UL,0UL,0x59L,0xBAL,0xBAL,0x59L,0UL,9UL}}};
    int32_t l_1325 = (-1L);
    uint8_t l_1326 = 9UL;
    uint32_t l_1747 = 0x06DB0EFFL;
    uint16_t l_2086 = 0UL;
    int32_t l_2089 = 1L;
    uint64_t *l_2098 = &g_1003[1];
    uint32_t l_2105[2];
    int64_t ****l_2118 = &g_2117;
    uint32_t l_2130 = 0xDE867004L;
    int16_t l_2151 = 0xB304L;
    int64_t l_2202 = 2L;
    uint64_t l_2208 = 3UL;
    int32_t **l_2217[1][4] = {{&g_754,&g_754,&g_754,&g_754}};
    int32_t ***l_2216 = &l_2217[0][3];
    uint32_t l_2239[7][6] = {{0x519BBCB2L,0x5D3A580EL,0x573897A5L,0x573897A5L,0x5D3A580EL,0x519BBCB2L},{4294967287UL,0x519BBCB2L,0x573897A5L,0x519BBCB2L,4294967287UL,4294967287UL},{7UL,0x519BBCB2L,0x519BBCB2L,7UL,0x5D3A580EL,7UL},{7UL,0x5D3A580EL,7UL,0x519BBCB2L,0x519BBCB2L,7UL},{4294967287UL,4294967287UL,0x519BBCB2L,0x573897A5L,0x519BBCB2L,4294967287UL},{0x519BBCB2L,0x5D3A580EL,0x573897A5L,0x573897A5L,0x5D3A580EL,0x519BBCB2L},{4294967287UL,0x519BBCB2L,0x573897A5L,0x519BBCB2L,4294967287UL,4294967287UL}};
    int32_t l_2266 = 0x03E54722L;
    int64_t l_2300 = 0x8B01E69F638CF908LL;
    uint16_t l_2312 = 8UL;
    const uint8_t l_2323 = 251UL;
    uint64_t **l_2355 = &g_2353;
    const int32_t *l_2360 = &g_100;
    const int32_t **l_2359 = &l_2360;
    const int32_t ***l_2358 = &l_2359;
    uint32_t l_2401[7] = {0x8BC8206EL,0x8BC8206EL,0x8BC8206EL,0x8BC8206EL,0x8BC8206EL,0x8BC8206EL,0x8BC8206EL};
    int16_t l_2440 = 0x0A79L;
    uint32_t l_2574 = 0x49F56F0EL;
    uint8_t **l_2651 = (void*)0;
    const int32_t l_2696 = 0xBA0ABD9DL;
    int32_t l_2718 = 0x74492BB6L;
    uint16_t *l_2746[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t ** const *l_2828[2][9] = {{&g_2664[0][1][0],&g_2664[0][0][5],&g_2664[0][1][0],&g_2664[0][0][5],&g_2664[0][1][0],&g_2664[0][0][5],&g_2664[0][1][0],&g_2664[0][0][5],&g_2664[0][1][0]},{&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3],&g_2664[0][1][3]}};
    uint8_t l_2845 = 1UL;
    int8_t l_2853 = 0xA2L;
    uint32_t *l_2885 = &l_2239[3][3];
    uint32_t **l_2884 = &l_2885;
    int32_t *l_2889 = &g_1128[4];
    int8_t l_2895 = 4L;
    uint8_t *l_2911 = &l_567[1][0][7];
    uint8_t l_2918 = 0UL;
    uint8_t l_2922 = 0x6DL;
    const uint32_t l_2925 = 0x0B75F531L;
    int32_t l_2926 = 0x20AD0F91L;
    const int32_t *l_2927 = &g_98[1][5][8];
    int8_t l_2928 = 5L;
    int8_t l_2937 = 6L;
    uint16_t **l_3004 = &l_2746[3];
    uint16_t ***l_3003 = &l_3004;
    uint64_t l_3066 = 0x427BED192EADF3DDLL;
    int32_t *l_3088 = &g_98[1][7][8];
    int32_t l_3113 = 0L;
    struct S0 l_3122 = {0xF18F9CBA8D9CE33ALL};
    int32_t *l_3163 = (void*)0;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2105[i] = 18446744073709551615UL;
    (*g_1236) = func_2(func_4(func_6(func_11(l_15, l_15, (safe_mod_func_uint32_t_u_u(((((safe_rshift_func_int8_t_s_s((l_15 != (g_20 >= (safe_lshift_func_int16_t_s_s((((((safe_rshift_func_uint8_t_u_u(((func_25(l_29, g_30, func_32(&g_31, ((*l_38) = g_31), (func_40((safe_rshift_func_int8_t_s_u((safe_add_func_int16_t_s_s((g_31 || g_31), 7L)), g_31)), l_29.f0, g_31) , l_15), l_566[5][0], l_567[3][1][4])) , l_1325) && g_1057), g_392)) , g_100) , &g_98[1][2][0]) != g_1079) != g_1057), 2)))), g_971[0])) ^ l_1326) > g_1173) , 0x82D5F01FL), 4294967292UL))), l_1747, l_566[5][0], l_566[5][0])));
    if ((g_898 <= (safe_add_func_int64_t_s_s((((safe_mul_func_int8_t_s_s(l_2086, (safe_rshift_func_int16_t_s_s(l_2089, 10)))) > 0x2A4490B55AB06E69LL) < ((safe_rshift_func_int16_t_s_u((((*l_2098) = (safe_mul_func_uint16_t_u_u(0UL, (safe_add_func_int32_t_s_s(((*g_1746) ^= (-7L)), (safe_lshift_func_uint8_t_u_u((*g_526), 2))))))) | ((((safe_add_func_int8_t_s_s(g_358, ((safe_rshift_func_int8_t_s_s(((g_2030--) , 6L), g_126)) & (*g_1568)))) <= g_357[1][0]) <= g_77[1][6][0]) || (***g_438))), 11)) , l_2105[1])), 0x0CF8BB34D5594169LL))))
    { /* block id: 1029 */
        uint32_t l_2106 = 4294967287UL;
        int64_t *****l_2110[4][4] = {{(void*)0,&g_2109,(void*)0,&g_2109},{&g_2109,&g_2109,&g_2109,&g_2109},{&g_2109,&g_2109,(void*)0,&g_2109},{&g_2109,(void*)0,&g_2109,(void*)0}};
        uint32_t *l_2115 = &g_358;
        int32_t l_2119 = 0x5CC7FAE9L;
        const int32_t l_2143 = 0x69AED23BL;
        int32_t l_2153 = 1L;
        int32_t l_2158 = 3L;
        int32_t l_2159 = 3L;
        int32_t l_2168 = 4L;
        int32_t l_2170 = 0xBC7E195EL;
        int32_t l_2171 = (-9L);
        uint16_t l_2203 = 0x877BL;
        int8_t l_2207 = 0xE2L;
        int32_t **l_2212 = &g_754;
        struct S0 l_2275 = {0x02E405657F1D9F50LL};
        uint8_t **l_2302[7][4][3];
        int8_t l_2304 = 1L;
        int32_t l_2309 = 0xCC2C11AEL;
        int i, j, k;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 4; j++)
            {
                for (k = 0; k < 3; k++)
                    l_2302[i][j][k] = &g_526;
            }
        }
        l_2119 = ((g_2116 = (((*l_38) |= (l_2106 & ((l_2106 | (*g_1568)) | (safe_add_func_uint16_t_u_u((((((g_2109 = g_2109) == (g_2111 = g_2111)) & (((l_2106 ^ (((void*)0 == (*g_1236)) , ((safe_mul_func_int8_t_s_s((((((*l_2115) |= (((((~l_2106) & 0x1F765260L) ^ 65534UL) & g_2030) != l_2106)) && g_1501) ^ 0x8BL) > (*g_448)), 8UL)) & g_898))) , g_1057) , l_2106)) && 0x667FC9CCL) , (*g_1194)), 9UL))))) , (void*)0)) == l_2118);
        for (l_2119 = 20; (l_2119 <= 2); l_2119--)
        { /* block id: 1038 */
            int32_t l_2123[1];
            uint64_t ** const l_2129 = &l_2098;
            uint16_t l_2175 = 0UL;
            int64_t l_2204[3];
            int32_t **l_2213 = &g_754;
            struct S0 l_2221 = {0x77FC215280082912LL};
            uint8_t *l_2229[8][10] = {{&l_567[3][1][4],&g_908,&g_908,&l_567[3][1][4],&l_567[0][5][2],&g_2030,&l_1326,&l_567[1][5][5],&l_1326,&g_2030},{&g_527,&l_1326,&l_567[0][5][2],&l_1326,&g_527,&g_908,&g_908,&l_1326,&l_1326,&g_908},{&l_567[1][5][5],&g_908,&l_567[3][1][4],&l_567[3][1][4],&g_908,&l_567[1][5][5],&g_2030,&g_908,&g_527,&g_908},{&l_1326,&l_567[3][1][4],&g_527,&l_1326,&g_527,&l_567[3][1][4],&l_1326,&g_2030,&g_2030,&g_2030},{&l_1326,&g_2030,&l_567[1][5][5],&l_567[0][5][2],&l_567[0][5][2],&l_567[1][5][5],&g_2030,&l_1326,&g_908,&g_2030},{&l_567[1][5][5],&g_2030,&l_1326,&g_908,&g_2030,&g_908,&l_1326,&g_2030,&l_567[1][5][5],&l_567[0][5][2]},{&g_527,&l_567[3][1][4],&l_1326,&g_2030,&g_2030,&g_2030,&g_2030,&l_1326,&l_567[3][1][4],&g_527},{&l_567[3][1][4],&g_908,&l_567[1][5][5],&g_2030,&g_908,&g_527,&g_908,&g_2030,&l_567[1][5][5],&g_908}};
            int32_t **l_2264 = (void*)0;
            int i, j;
            for (i = 0; i < 1; i++)
                l_2123[i] = 0L;
            for (i = 0; i < 3; i++)
                l_2204[i] = 0x0E94A997FCA46356LL;
            for (l_29.f0 = 1; (l_29.f0 <= 5); l_29.f0 += 1)
            { /* block id: 1041 */
                uint32_t l_2122 = 18446744073709551607UL;
                int32_t ***l_2124 = &g_1236;
                struct S0 l_2145 = {0x9934B0B4EF66B17BLL};
                uint8_t l_2147 = 0x41L;
                int32_t l_2152 = 0x97736EAEL;
                int32_t l_2155 = 0xD673C042L;
                int32_t l_2156 = (-1L);
                int32_t l_2162 = 0xDFED4114L;
                int64_t l_2164 = 0L;
                int32_t l_2165 = 0x30D4DDF0L;
                int32_t l_2166 = 0L;
                int32_t l_2167 = (-2L);
                int32_t l_2169 = 0xB6C63C42L;
                (*g_1236) = (l_2122 , (void*)0);
                if ((l_2119 | l_2123[0]))
                { /* block id: 1043 */
                    uint64_t **l_2128 = &l_2098;
                    int32_t l_2139 = 0x89F0F63BL;
                    int32_t l_2157 = 0x6251CA2AL;
                    int32_t l_2161 = (-1L);
                    int32_t l_2163[4] = {0x556116ABL,0x556116ABL,0x556116ABL,0x556116ABL};
                    int i;
                    (*g_1746) &= (((void*)0 == l_2124) > (safe_lshift_func_uint8_t_u_u((+l_2122), 2)));
                    if ((*g_1576))
                        break;
                    for (g_527 = 0; (g_527 <= 3); g_527 += 1)
                    { /* block id: 1048 */
                        int32_t l_2144 = 1L;
                        int8_t l_2146 = 0L;
                        int32_t l_2154 = 0x1BCF2EC2L;
                        int32_t l_2160[3];
                        uint32_t l_2172 = 0x35970AEDL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2160[i] = 0xA12536DEL;
                        (*g_1236) = func_4(l_2145);
                        (*g_1576) = (*g_1576);
                        (*g_448) = (((**l_2128) ^= l_2146) != ((l_2147 &= g_1128[4]) , ((**g_1193) || (+(safe_add_func_uint8_t_u_u(l_2139, l_2123[0]))))));
                        --l_2172;
                    }
                    if (l_2156)
                        break;
                }
                else
                { /* block id: 1060 */
                    if (l_2175)
                        break;
                }
            }
            (*g_1576) &= (safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((**g_1567), 0xF2A49CFF131093E8LL)), (safe_mod_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u(0xC631L, (safe_mul_func_int8_t_s_s((l_29 , g_1501), (*g_526))))), g_558))));
            for (g_908 = 0; (g_908 <= 2); g_908 += 1)
            { /* block id: 1070 */
                int8_t l_2205 = 0xA5L;
                int32_t l_2206[7][4] = {{(-9L),0x3C2ACCF6L,6L,0x858CEDA5L},{6L,0x858CEDA5L,0x35B14A6EL,0x858CEDA5L},{7L,0x3C2ACCF6L,(-2L),6L},{0L,(-6L),0x858CEDA5L,0xED63EAABL},{(-2L),7L,7L,7L},{0x858CEDA5L,0x858CEDA5L,(-9L),(-6L)},{6L,7L,0x858CEDA5L,0x3C2ACCF6L}};
                uint8_t *l_2231 = &l_1326;
                int64_t ****l_2259 = &g_2117;
                uint16_t **l_2261 = &g_1194;
                uint16_t ***l_2260 = &l_2261;
                const int16_t l_2263 = (-1L);
                int32_t l_2299 = 0x63943025L;
                uint16_t l_2301 = 2UL;
                uint32_t l_2306 = 4294967289UL;
                int i, j;
                ++l_2208;
                for (g_1189 = 0; (g_1189 <= 1); g_1189 += 1)
                { /* block id: 1074 */
                    uint32_t l_2211[8][10] = {{1UL,4294967293UL,3UL,0x908100F8L,3UL,4294967293UL,1UL,0x1B48E135L,0xE7EA93C7L,4294967288UL},{0x1B48E135L,0x2514E944L,0x9C46E934L,0x4766B9EEL,1UL,1UL,0x4766B9EEL,0x9C46E934L,0x2514E944L,0x1B48E135L},{0x1843AEAEL,0x2514E944L,0xE7EA93C7L,0x7D67C41FL,0x908100F8L,4294967288UL,1UL,4294967288UL,0x908100F8L,0x7D67C41FL},{0x7D67C41FL,4294967293UL,0x7D67C41FL,0x2514E944L,0x908100F8L,0xB1F519B7L,0x1B48E135L,3UL,3UL,0x1B48E135L},{0x908100F8L,1UL,0xB1F519B7L,0xB1F519B7L,1UL,0x908100F8L,0x1843AEAEL,3UL,0x4766B9EEL,4294967288UL},{4294967293UL,4294967288UL,0x7D67C41FL,0x9C46E934L,3UL,0x9C46E934L,0x7D67C41FL,4294967288UL,4294967293UL,0x908100F8L},{4294967293UL,0xB1F519B7L,0xE7EA93C7L,0x1843AEAEL,0x9C46E934L,0x908100F8L,0x908100F8L,0x9C46E934L,0x1843AEAEL,0xE7EA93C7L},{0x908100F8L,0x908100F8L,0x9C46E934L,0x1843AEAEL,0xE7EA93C7L,0xB1F519B7L,4294967293UL,0x1B48E135L,4294967293UL,0xB1F519B7L}};
                    int32_t ***l_2219 = &l_2212;
                    int32_t ****l_2218 = &l_2219;
                    uint16_t *l_2220 = (void*)0;
                    uint8_t *l_2228[3][3] = {{&g_2030,&g_908,&g_2030},{(void*)0,(void*)0,(void*)0},{&g_2030,&g_908,&g_2030}};
                    int32_t l_2238 = 0L;
                    uint8_t ****l_2258 = &g_1216;
                    uint16_t *l_2262[7][8][3] = {{{&g_90[4][6],&l_2175,(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086},{&g_90[3][5],&g_90[4][6],(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086},{(void*)0,&g_90[4][6],&l_2203},{&g_1060,&g_90[3][5],(void*)0},{(void*)0,&l_2175,&g_90[3][5]},{&g_90[3][5],&g_1060,(void*)0}},{{&g_90[3][5],&g_90[3][5],&l_2203},{&g_90[3][5],&g_1060,&l_2086},{&g_90[4][6],&l_2175,(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086},{&g_90[3][5],&g_90[4][6],(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086},{(void*)0,&g_90[4][6],&l_2203},{&g_1060,&g_90[3][5],(void*)0}},{{(void*)0,&l_2175,&g_90[3][5]},{&g_90[3][5],&g_1060,(void*)0},{&g_90[3][5],&g_90[3][5],&l_2203},{&g_90[3][5],&g_1060,&l_2086},{&g_90[4][6],&l_2175,(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086},{&g_90[3][5],&g_90[4][6],(void*)0},{&g_90[3][5],&g_90[3][5],&l_2086}},{{(void*)0,&g_90[4][6],&l_2203},{&g_1060,&g_90[3][5],(void*)0},{(void*)0,&l_2175,&g_90[3][5]},{&g_90[3][5],&g_1060,(void*)0},{&g_90[3][5],&g_90[3][5],&l_2203},{&g_90[3][5],&g_1060,&l_2086},{&g_90[4][6],&l_2175,&l_2175},{(void*)0,&l_2203,&l_2175}},{{&g_90[3][5],&g_90[3][5],&l_2175},{&g_90[3][5],&g_90[3][5],&g_90[3][5]},{&g_90[3][5],&g_90[3][5],(void*)0},{&g_1189,&l_2203,&g_90[3][5]},{&g_90[3][5],(void*)0,&l_2175},{&g_90[3][5],&g_1189,&g_90[3][5]},{&g_90[3][5],&g_90[3][5],(void*)0},{(void*)0,&g_1189,&g_90[3][5]}},{{&g_90[3][5],(void*)0,&l_2175},{(void*)0,&l_2203,&l_2175},{&g_90[3][5],&g_90[3][5],&l_2175},{&g_90[3][5],&g_90[3][5],&g_90[3][5]},{&g_90[3][5],&g_90[3][5],(void*)0},{&g_1189,&l_2203,&g_90[3][5]},{&g_90[3][5],(void*)0,&l_2175},{&g_90[3][5],&g_1189,&g_90[3][5]}},{{&g_90[3][5],&g_90[3][5],(void*)0},{(void*)0,&g_1189,&g_90[3][5]},{&g_90[3][5],(void*)0,&l_2175},{(void*)0,&l_2203,&l_2175},{&g_90[3][5],&g_90[3][5],&l_2175},{&g_90[3][5],&g_90[3][5],&g_90[3][5]},{&g_90[3][5],&g_90[3][5],(void*)0},{&g_1189,&l_2203,&g_90[3][5]}}};
                    int i, j, k;
                    if ((l_2211[2][1] <= ((((((*g_526) == (l_2206[6][1] ^ ((((((((l_2212 != l_2213) | (*g_526)) >= (safe_sub_func_uint16_t_u_u((**g_1193), (g_90[3][5] = (((l_2216 == ((*l_2218) = &l_2212)) <= 1UL) != 0x34F4L))))) == l_2204[2]) < l_2207) || 0x6AD88BDDL) , l_2211[0][6]) , (*g_1194)))) > l_2211[4][2]) < l_2204[2]) , (void*)0) == (*l_2216))))
                    { /* block id: 1077 */
                        l_2221 = (*g_1701);
                    }
                    else
                    { /* block id: 1079 */
                        return l_2205;
                    }
                    for (g_1276 = 1; (g_1276 >= 0); g_1276 -= 1)
                    { /* block id: 1084 */
                        struct S0 l_2222[1] = {{5UL}};
                        int32_t *l_2223 = &l_2119;
                        uint8_t **l_2230 = &l_2228[2][0];
                        int64_t *** const *l_2240 = &g_2117;
                        int i;
                        (*g_1701) = l_2222[0];
                        (**g_438) = (*g_439);
                    }
                    if ((safe_lshift_func_int8_t_s_s((((g_1151[g_1189][g_1189][g_908]--) , l_2203) == (safe_lshift_func_int16_t_s_u((((((((safe_lshift_func_int8_t_s_s(((((&g_2111 != l_2110[2][2]) > (((((+(safe_add_func_int64_t_s_s((!(g_90[3][5] = (((g_2255 == (l_2206[2][2] , ((g_98[(g_1189 + 1)][(g_1189 + 1)][(g_908 + 2)] = l_2205) , l_2258))) && (((((0xF1L >= ((l_2118 != l_2259) | (-1L))) , (void*)0) == l_2260) >= 0xD1F8L) , (*g_1194))) < 0x518CL))), l_2159))) || 4L) & l_2204[0]) | (**g_1193)) > g_31)) , 0L) && l_2263), 0)) || l_2153) | (*g_1194)) != (**g_1193)) , l_2159) == l_2175) & 0UL), l_2175))), g_39)))
                    { /* block id: 1094 */
                        return (*g_1079);
                    }
                    else
                    { /* block id: 1096 */
                        struct S0 l_2298 = {0x8348DC139FA897B0LL};
                        int32_t l_2303 = 0x22876F92L;
                        int32_t l_2305[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2305[i] = 0L;
                        l_2238 = (((0L || ((*l_2115) |= ((*g_1701) , (0x83D353EAL <= l_2263)))) , &l_566[5][0]) != l_2264);
                        (*g_1746) &= (!((g_1003[(g_908 + 3)] = l_2266) || (safe_div_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((((*g_1701) , (void*)0) != l_2302[3][3][1]) < 0x5318L), 0xDC25L)), 0x54L))));
                        l_2306--;
                        (*g_1746) = l_2309;
                    }
                }
            }
        }
        for (l_2208 = 0; l_2208 < 2; l_2208 += 1)
        {
            for (l_2159 = 0; l_2159 < 10; l_2159 += 1)
            {
                for (g_146 = 0; g_146 < 1; g_146 += 1)
                {
                    g_77[l_2208][l_2159][g_146] = 0L;
                }
            }
        }
    }
    else
    { /* block id: 1113 */
        uint64_t l_2313 = 18446744073709551615UL;
        struct S0 l_2318[10][3][5] = {{{{5UL},{0x35246675F6B8C41CLL},{0UL},{1UL},{18446744073709551607UL}},{{18446744073709551612UL},{0UL},{1UL},{18446744073709551609UL},{1UL}},{{1UL},{0xA6224B2532C7C98FLL},{1UL},{0x3B0A82069F27435CLL},{0x51BDFFC9A4B7BF04LL}}},{{{0x51BDFFC9A4B7BF04LL},{5UL},{0UL},{0UL},{0UL}},{{18446744073709551610UL},{0x51BDFFC9A4B7BF04LL},{9UL},{18446744073709551615UL},{0x33A933DB2431B786LL}},{{0xB3812A1256B1F67ALL},{18446744073709551607UL},{0UL},{0x5890436ECE72C066LL},{0UL}}},{{{1UL},{0x4C98D323A33DE2ECLL},{0x6C4FA1957178973CLL},{0UL},{0xAFBABFCD6ECBC03DLL}},{{18446744073709551615UL},{0UL},{0x0560C5AEF02EE0E0LL},{18446744073709551613UL},{0xBD662E9029FDCDEELL}},{{18446744073709551615UL},{0x076C08D80014CE8CLL},{8UL},{18446744073709551615UL},{18446744073709551613UL}}},{{{1UL},{18446744073709551610UL},{0x4C98D323A33DE2ECLL},{0xAFBABFCD6ECBC03DLL},{0x50104BB7613CF344LL}},{{0xB3812A1256B1F67ALL},{9UL},{0x13634BA4E0764ED3LL},{9UL},{0xA6224B2532C7C98FLL}},{{18446744073709551610UL},{0x5559AC1A0D15A374LL},{18446744073709551613UL},{0x4C98D323A33DE2ECLL},{9UL}}},{{{0x51BDFFC9A4B7BF04LL},{1UL},{1UL},{0x51BDFFC9A4B7BF04LL},{0x5890436ECE72C066LL}},{{1UL},{1UL},{18446744073709551612UL},{1UL},{0UL}},{{18446744073709551612UL},{0x04E01BCEACF3CD9FLL},{0xBD662E9029FDCDEELL},{1UL},{0x5559AC1A0D15A374LL}}},{{{5UL},{0UL},{2UL},{1UL},{0x93EB98A8C29DD93ELL}},{{0x6DF07101F3979143LL},{18446744073709551613UL},{0xDE44C6F29780F7B2LL},{0x51BDFFC9A4B7BF04LL},{5UL}},{{1UL},{0x3B0A82069F27435CLL},{0x51BDFFC9A4B7BF04LL},{0x4C98D323A33DE2ECLL},{0x342A22D07DAD963DLL}}},{{{0x165C56F8913ACF49LL},{0x93EB98A8C29DD93ELL},{0x746B81B9BB46EE75LL},{9UL},{18446744073709551610UL}},{{0x5377460548AB624DLL},{0x7CFA1AE78603037CLL},{0x6DDA7767F09A42ADLL},{0xAFBABFCD6ECBC03DLL},{0x0560C5AEF02EE0E0LL}},{{0x5F5B507F084D59CCLL},{18446744073709551615UL},{0x50104BB7613CF344LL},{18446744073709551615UL},{18446744073709551615UL}}},{{{0UL},{0xBD662E9029FDCDEELL},{1UL},{18446744073709551613UL},{9UL}},{{0xC1196AC0404CD1A3LL},{0xBD662E9029FDCDEELL},{1UL},{0x51BDFFC9A4B7BF04LL},{1UL}},{{0x076C08D80014CE8CLL},{6UL},{0xDE44C6F29780F7B2LL},{0x5559AC1A0D15A374LL},{1UL}}},{{{1UL},{0UL},{0x35246675F6B8C41CLL},{5UL},{0x93EB98A8C29DD93ELL}},{{0x342A22D07DAD963DLL},{0x6DDA7767F09A42ADLL},{18446744073709551610UL},{0xB3812A1256B1F67ALL},{18446744073709551606UL}},{{0xBD662E9029FDCDEELL},{18446744073709551610UL},{0UL},{18446744073709551610UL},{0xBD662E9029FDCDEELL}}},{{{0xC971A0A197F9CA66LL},{0x165C56F8913ACF49LL},{18446744073709551615UL},{0x04E01BCEACF3CD9FLL},{0UL}},{{0x7F358C7D61086BC3LL},{0x6C4FA1957178973CLL},{18446744073709551610UL},{0x93EB98A8C29DD93ELL},{18446744073709551613UL}},{{18446744073709551615UL},{18446744073709551613UL},{0UL},{0x165C56F8913ACF49LL},{0UL}}}};
        int32_t ****l_2324 = (void*)0;
        int i, j, k;
        (*g_1746) = (safe_mod_func_uint64_t_u_u(l_2312, l_2313));
        for (g_131.f0 = 6; (g_131.f0 < 26); ++g_131.f0)
        { /* block id: 1117 */
            const int32_t l_2335 = 0x12D35162L;
            int32_t l_2339 = 0xD422A021L;
            int32_t l_2342[4][2][7] = {{{0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}},{{0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}},{{0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}},{{0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L,0x245BD932L,0xD08C7653L},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}}};
            int i, j, k;
            for (g_242 = 5; (g_242 == (-24)); g_242 = safe_sub_func_uint64_t_u_u(g_242, 3))
            { /* block id: 1120 */
                if (l_2313)
                    break;
            }
            (*g_1443) = func_4((l_2318[4][0][0] = (*g_1701)));
            for (l_2300 = 0; (l_2300 > 1); l_2300 = safe_add_func_uint16_t_u_u(l_2300, 7))
            { /* block id: 1127 */
                int32_t l_2332 = 3L;
                (*g_30) = ((safe_sub_func_int64_t_s_s(((((*g_1746) = 0x42ED0FAEL) & (((l_2323 , l_2324) != ((safe_sub_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((+(safe_div_func_int8_t_s_s((l_2332 && (((safe_rshift_func_uint8_t_u_u((****g_2255), 0)) == (l_2335 != (~(safe_mul_func_uint16_t_u_u((((((((l_2339 = l_2332) | 0xA691C5F551FEE5F7LL) | (l_2342[2][0][6] &= (safe_div_func_int64_t_s_s(((1L ^ l_2332) | l_2335), g_358)))) , g_1501) & 8UL) | 0x1137CED98FD706E5LL) != l_2335), 1UL))))) <= (*g_1576))), 1L))), 0L)), g_93)) , (void*)0)) <= (*g_448))) && 9L), l_2335)) >= 0x2C610D86L);
            }
        }
        return g_2343[0][0][0];
    }
    for (l_2202 = (-29); (l_2202 != 6); ++l_2202)
    { /* block id: 1138 */
        uint32_t l_2365 = 0x565B0724L;
        int32_t l_2388 = 0x043293D7L;
        int8_t l_2408 = (-10L);
        uint32_t l_2421 = 1UL;
        struct S0 *l_2429 = (void*)0;
        struct S0 l_2438 = {18446744073709551610UL};
        uint8_t l_2466 = 0xD1L;
        uint8_t l_2478 = 253UL;
        uint32_t l_2545 = 0xAD48446EL;
        int16_t * const l_2589[5] = {&l_2440,&l_2440,&l_2440,&l_2440,&l_2440};
        int32_t l_2591 = (-1L);
        uint8_t l_2600 = 250UL;
        int32_t l_2627 = 0xBD7CB1E1L;
        uint32_t *l_2637 = &l_2105[1];
        const uint8_t ***l_2675[5];
        int32_t l_2780 = 0x0F6D2361L;
        int32_t l_2781 = 0x86BEF04FL;
        int32_t l_2782 = 0L;
        int32_t l_2787[5][9] = {{7L,0x90CC646EL,7L,7L,0x90CC646EL,7L,7L,0x90CC646EL,7L},{(-1L),2L,(-1L),(-1L),2L,(-1L),(-1L),2L,(-1L)},{7L,0x90CC646EL,7L,7L,0x90CC646EL,7L,7L,0x90CC646EL,7L},{(-1L),2L,(-1L),(-1L),2L,(-1L),(-1L),2L,(-1L)},{7L,0x90CC646EL,7L,7L,0x90CC646EL,7L,7L,0x90CC646EL,7L}};
        int32_t *l_2819[1][9][9] = {{{&l_2787[1][3],&l_2780,&l_2782,&l_2787[4][3],&g_100,&g_98[1][5][8],&g_31,&l_2787[4][3],&l_2787[0][4]},{&g_31,&l_2787[0][4],&l_2787[2][1],&l_2781,&l_2782,&l_2782,&l_2781,&l_2787[2][1],&l_2787[0][4]},{&l_2782,&l_2787[1][3],&l_2781,&l_2781,&l_2266,&g_98[0][7][7],&l_2787[4][3],&l_2787[4][3],&l_2782},{&g_100,&g_100,(void*)0,&l_2782,&l_2787[4][3],&l_2787[4][3],&g_98[0][7][7],&l_2266,&l_2781},{&l_2266,&l_2787[1][3],&g_31,&l_2787[0][4],&l_2787[2][1],&l_2781,&l_2782,&l_2782,&l_2781},{&l_2787[4][3],&l_2787[0][4],&l_2266,&l_2780,&l_2780,&g_31,&g_100,&l_2787[4][3],&l_2266},{&g_100,&l_2266,&g_100,&l_2782,&l_2780,&l_2787[4][4],&l_2266,&g_98[1][5][8],&l_2787[4][3]},{&l_2787[4][3],&l_2782,(void*)0,&g_100,&g_100,&g_31,&l_2787[0][4],&g_31,&l_2787[2][1]},{&l_2787[4][3],&g_31,&l_2787[4][3],&l_2782,&l_2787[1][3],&l_2782,&l_2787[4][3],&g_31,&l_2787[4][3]}}};
        int32_t ***l_2830 = &l_2217[0][0];
        uint32_t *l_2883 = (void*)0;
        uint32_t **l_2882 = &l_2883;
        int16_t l_2908 = 0xAFE5L;
        int64_t l_2923 = 0xB5C7CFC87ACE511ALL;
        uint64_t l_2924 = 0x3EA027ADD40B8112LL;
        uint32_t l_2962[6][3] = {{0UL,0UL,0x26A77741L},{0x66F9C154L,0x66A40B76L,0x66F9C154L},{0UL,0x26A77741L,0x26A77741L},{2UL,0x66A40B76L,2UL},{0UL,0UL,0x26A77741L},{0x66F9C154L,0x66A40B76L,0x66F9C154L}};
        int64_t **l_3160 = &g_894[0];
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_2675[i] = &g_489;
    }
    (*l_2359) = l_3163;
    return (*g_754);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_2(int32_t * p_3)
{ /* block id: 1023 */
    int32_t *l_2081 = &g_100;
    return l_2081;
}


/* ------------------------------------------ */
/* 
 * reads : g_1766 g_440 g_441 g_1276 g_1576 g_100
 * writes: g_1276 g_100
 */
static int32_t * func_4(struct S0  p_5)
{ /* block id: 1019 */
    int64_t l_2062 = 0xA60E9941A73A803FLL;
    int8_t *l_2079[7][2] = {{&g_1276,&g_1276},{&g_1276,&g_1276},{(void*)0,&g_1276},{&g_1276,&g_1276},{&g_1276,&g_1276},{&g_1276,(void*)0},{&g_1276,&g_1276}};
    int32_t *l_2080[2];
    int i, j;
    for (i = 0; i < 2; i++)
        l_2080[i] = &g_31;
    (*g_1576) |= (l_2062 >= (safe_mod_func_int8_t_s_s((-1L), (safe_lshift_func_int8_t_s_s((-4L), ((safe_rshift_func_int16_t_s_u(p_5.f0, ((g_1276 |= (((safe_sub_func_uint8_t_u_u(0x87L, (safe_lshift_func_uint16_t_u_u(0x96B3L, (safe_mod_func_int16_t_s_s((safe_add_func_uint8_t_u_u(p_5.f0, (safe_mod_func_uint64_t_u_u((g_1766 , ((p_5.f0 > l_2062) || p_5.f0)), l_2062)))), l_2062)))))) || (*g_440)) > l_2062)) & 0xE1L))) , (-1L)))))));
    return l_2080[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_1576 g_527 g_146 g_1151 g_1276 g_1762 g_1658.f0 g_242 g_1236 g_31 g_77 g_52.f0 g_90 g_93 g_95 g_98 g_100 g_52 g_439 g_440 g_1189 g_1443 g_1701 g_131 g_30 g_1003 g_1194 g_1128 g_231 g_888 g_558 g_526 g_1766 g_438 g_441 g_1080 g_357 g_908 g_1568 g_1569 g_358 g_1746 g_1567 g_1057 g_2030 g_2041 g_898 g_39 g_1501
 * writes: g_100 g_527 g_1276 g_146 g_448 g_90 g_93 g_98 g_126 g_77 g_131 g_440 g_30 g_1151 g_39 g_1501 g_231 g_1658.f0 g_898 g_52.f0 g_888 g_1992 g_95 g_1189
 */
static struct S0  func_6(int32_t * p_7, uint16_t  p_8, int32_t * p_9, int32_t * const  p_10)
{ /* block id: 863 */
    uint32_t l_1748 = 1UL;
    int8_t l_1773[7][4][2] = {{{0xF1L,0L},{0xF1L,0xC9L},{0L,0xF1L},{0xC9L,0L}},{{(-1L),(-1L)},{0L,(-1L)},{(-1L),0L},{0xC9L,0xF1L}},{{0L,0xC9L},{0xF1L,0L},{0xF1L,0xC9L},{0L,0xF1L}},{{0xC9L,0L},{(-1L),(-1L)},{0L,(-1L)},{(-1L),0L}},{{0xC9L,0xF1L},{0L,0xC9L},{0xF1L,0L},{0xF1L,0xC9L}},{{0L,0xF1L},{0xC9L,0L},{(-1L),(-1L)},{0L,(-1L)}},{{(-1L),0L},{0xC9L,0xF1L},{0L,0xC9L},{0xF1L,0L}}};
    int32_t *l_1787 = (void*)0;
    int32_t **l_1790 = (void*)0;
    int32_t l_1808 = 0L;
    uint8_t **l_1820 = &g_526;
    int32_t l_1904 = 6L;
    int32_t l_1936[7];
    int8_t l_1956 = 0xC1L;
    struct S0 l_1989 = {1UL};
    uint32_t l_2028 = 1UL;
    uint8_t l_2029 = 246UL;
    int32_t *l_2060 = &l_1808;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_1936[i] = 0x7CB42373L;
    if (((*g_1576) = (l_1748 , l_1748)))
    { /* block id: 865 */
        int32_t l_1767[9] = {(-8L),(-8L),9L,(-8L),(-8L),9L,(-8L),(-8L),9L};
        uint8_t *****l_1780 = &g_1743;
        int32_t l_1782 = 0x34DA5201L;
        int32_t **l_1788 = (void*)0;
        int8_t *l_1829 = (void*)0;
        int32_t *l_1830 = &l_1808;
        struct S0 l_1916[3][8][10] = {{{{0xA9C3E81F2CE6DDF6LL},{0xEE04A87C0F4413A9LL},{4UL},{0x625DA60875B38865LL},{0xE11C740071A5D5B9LL},{0x57CBC82DEECF3DC6LL},{18446744073709551608UL},{3UL},{0xCE8C926454FF5C86LL},{0x94506B1CBBD640D0LL}},{{0xD491F5E763741FE1LL},{0x7FBF37D38A176080LL},{4UL},{0x33104A1DC1CAF61DLL},{0xCE8C926454FF5C86LL},{18446744073709551615UL},{0UL},{3UL},{0x29A504FC25B4BEAELL},{0x625DA60875B38865LL}},{{0xFE51BCED74E1162FLL},{18446744073709551615UL},{4UL},{18446744073709551609UL},{0x169D18289DECC3B0LL},{3UL},{0x7D6E0B27FBBEC577LL},{3UL},{0x169D18289DECC3B0LL},{18446744073709551609UL}},{{4UL},{0UL},{4UL},{0x94506B1CBBD640D0LL},{18446744073709551607UL},{0x4D6A42FD38F41461LL},{18446744073709551615UL},{3UL},{0xE11C740071A5D5B9LL},{0x34584F6A5DC244EFLL}},{{18446744073709551609UL},{0x47011B4DDCC9F7A5LL},{4UL},{0x34584F6A5DC244EFLL},{0x29A504FC25B4BEAELL},{0x3D264BD05385237ALL},{3UL},{3UL},{18446744073709551607UL},{0x33104A1DC1CAF61DLL}},{{0xA9C3E81F2CE6DDF6LL},{0xEE04A87C0F4413A9LL},{4UL},{0x625DA60875B38865LL},{0xE11C740071A5D5B9LL},{0x57CBC82DEECF3DC6LL},{18446744073709551608UL},{3UL},{0xCE8C926454FF5C86LL},{0x94506B1CBBD640D0LL}},{{0xD491F5E763741FE1LL},{1UL},{18446744073709551611UL},{3UL},{0xFE51BCED74E1162FLL},{0xB7AD0DFD222C2CBALL},{0x6412F0511BDDF529LL},{1UL},{18446744073709551609UL},{0x57CBC82DEECF3DC6LL}},{{0xB1B628AA0958D04BLL},{0xFEEE8E81D7E09B15LL},{18446744073709551611UL},{0x3D264BD05385237ALL},{0xD491F5E763741FE1LL},{1UL},{6UL},{1UL},{0xD491F5E763741FE1LL},{0x3D264BD05385237ALL}}},{{{18446744073709551611UL},{0x834A0872DB9BF5F3LL},{18446744073709551611UL},{18446744073709551615UL},{0xA9C3E81F2CE6DDF6LL},{18446744073709551611UL},{0x05EB69E0F0F616FALL},{1UL},{4UL},{0x4D6A42FD38F41461LL}},{{1UL},{0xC386B717AABE654CLL},{18446744073709551611UL},{0x4D6A42FD38F41461LL},{18446744073709551609UL},{6UL},{0x6C301B5369FED8F9LL},{1UL},{0xA9C3E81F2CE6DDF6LL},{3UL}},{{18446744073709551615UL},{0x79CE2A7E80E5CC95LL},{18446744073709551611UL},{0x57CBC82DEECF3DC6LL},{4UL},{1UL},{0xFA15D804E8E1522CLL},{1UL},{0xFE51BCED74E1162FLL},{18446744073709551615UL}},{{0x09A08CBBFBADEBE7LL},{1UL},{18446744073709551611UL},{3UL},{0xFE51BCED74E1162FLL},{0xB7AD0DFD222C2CBALL},{0x6412F0511BDDF529LL},{1UL},{18446744073709551609UL},{0x57CBC82DEECF3DC6LL}},{{0xB1B628AA0958D04BLL},{0xFEEE8E81D7E09B15LL},{18446744073709551611UL},{0x3D264BD05385237ALL},{0xD491F5E763741FE1LL},{1UL},{6UL},{1UL},{0xD491F5E763741FE1LL},{0x3D264BD05385237ALL}},{{18446744073709551611UL},{0x834A0872DB9BF5F3LL},{18446744073709551611UL},{18446744073709551615UL},{0xA9C3E81F2CE6DDF6LL},{18446744073709551611UL},{0x05EB69E0F0F616FALL},{1UL},{4UL},{0x4D6A42FD38F41461LL}},{{1UL},{0xC386B717AABE654CLL},{18446744073709551611UL},{0x4D6A42FD38F41461LL},{18446744073709551609UL},{6UL},{0x6C301B5369FED8F9LL},{1UL},{0xA9C3E81F2CE6DDF6LL},{3UL}},{{18446744073709551615UL},{0x79CE2A7E80E5CC95LL},{18446744073709551611UL},{0x57CBC82DEECF3DC6LL},{4UL},{1UL},{0xFA15D804E8E1522CLL},{1UL},{0xFE51BCED74E1162FLL},{18446744073709551615UL}}},{{{0x09A08CBBFBADEBE7LL},{1UL},{18446744073709551611UL},{3UL},{0xFE51BCED74E1162FLL},{0xB7AD0DFD222C2CBALL},{0x6412F0511BDDF529LL},{1UL},{18446744073709551609UL},{0x57CBC82DEECF3DC6LL}},{{0xB1B628AA0958D04BLL},{0xFEEE8E81D7E09B15LL},{18446744073709551611UL},{0x3D264BD05385237ALL},{0xD491F5E763741FE1LL},{1UL},{6UL},{1UL},{0xD491F5E763741FE1LL},{0x3D264BD05385237ALL}},{{18446744073709551611UL},{0x834A0872DB9BF5F3LL},{18446744073709551611UL},{18446744073709551615UL},{0xA9C3E81F2CE6DDF6LL},{18446744073709551611UL},{0x05EB69E0F0F616FALL},{1UL},{4UL},{0x4D6A42FD38F41461LL}},{{1UL},{0xC386B717AABE654CLL},{18446744073709551611UL},{0x4D6A42FD38F41461LL},{18446744073709551609UL},{6UL},{0x6C301B5369FED8F9LL},{1UL},{0xA9C3E81F2CE6DDF6LL},{3UL}},{{18446744073709551615UL},{0x79CE2A7E80E5CC95LL},{18446744073709551611UL},{0x57CBC82DEECF3DC6LL},{4UL},{1UL},{0xFA15D804E8E1522CLL},{1UL},{0xFE51BCED74E1162FLL},{18446744073709551615UL}},{{0x09A08CBBFBADEBE7LL},{1UL},{18446744073709551611UL},{3UL},{0xFE51BCED74E1162FLL},{0xB7AD0DFD222C2CBALL},{0x6412F0511BDDF529LL},{1UL},{18446744073709551609UL},{0x57CBC82DEECF3DC6LL}},{{0xB1B628AA0958D04BLL},{0xFEEE8E81D7E09B15LL},{18446744073709551611UL},{0x3D264BD05385237ALL},{0xD491F5E763741FE1LL},{1UL},{6UL},{1UL},{0xD491F5E763741FE1LL},{0x3D264BD05385237ALL}},{{18446744073709551611UL},{0x834A0872DB9BF5F3LL},{18446744073709551611UL},{18446744073709551615UL},{0xA9C3E81F2CE6DDF6LL},{18446744073709551611UL},{0x05EB69E0F0F616FALL},{1UL},{4UL},{0x4D6A42FD38F41461LL}}}};
        int i, j, k;
lbl_1986:
        for (g_527 = 0; (g_527 <= 1); g_527 += 1)
        { /* block id: 868 */
            int32_t *l_1784 = &l_1767[3];
            struct S0 l_1786 = {18446744073709551607UL};
            int32_t l_1806 = (-1L);
            int32_t l_1807[1];
            uint8_t **l_1818 = &g_526;
            int64_t * const *l_1855 = &g_894[2];
            int64_t * const **l_1854 = &l_1855;
            uint32_t l_1937 = 0UL;
            uint16_t l_1950 = 7UL;
            uint16_t l_1957 = 0UL;
            uint32_t l_1983 = 4294967287UL;
            int i;
            for (i = 0; i < 1; i++)
                l_1807[i] = 0x6F36BFF6L;
            for (g_1276 = 1; (g_1276 >= 0); g_1276 -= 1)
            { /* block id: 871 */
                uint8_t l_1759 = 1UL;
                const int32_t ***l_1761 = &g_1078;
                const int32_t ****l_1760 = &l_1761;
                int32_t l_1768[9][6] = {{0x68C7A8B3L,0L,(-5L),0L,0x68C7A8B3L,0x7BFB30EBL},{0x68C7A8B3L,0L,(-5L),0L,0x68C7A8B3L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L},{0L,(-1L),0x68C7A8B3L,(-1L),0L,0L}};
                uint8_t *** const *l_1779 = &g_1216;
                uint8_t *** const **l_1778 = &l_1779;
                struct S0 l_1785 = {0x35F5BE0E9293EB41LL};
                int32_t l_1803 = 0xE2A1F005L;
                uint32_t l_1809 = 0xD285830FL;
                uint8_t **l_1819 = &g_526;
                int32_t l_1825 = 0x98D403C0L;
                int i, j;
                for (g_146 = 0; (g_146 <= 1); g_146 += 1)
                { /* block id: 874 */
                    int32_t *l_1783 = &g_98[1][4][2];
                    struct S0 l_1800 = {0x70A834DD37800A0BLL};
                    int32_t l_1805[9][9][3] = {{{(-1L),(-1L),0L},{(-1L),0x668D25B7L,0xE8F61F46L},{(-1L),0x668D25B7L,0L},{0x66B4718DL,(-1L),0x66B4718DL},{6L,0xB88774CEL,0x668D25B7L},{0x1742EA4FL,0xF647B4CDL,0x05643B4EL},{0x43AE9F60L,0x7EB25BC2L,(-1L)},{0x668D25B7L,0x3B158488L,(-3L)},{0x43AE9F60L,(-1L),(-1L)}},{{0x1742EA4FL,(-1L),0xF647B4CDL},{6L,0x1B1463DAL,0L},{0x66B4718DL,1L,0xB88774CEL},{(-1L),0x05643B4EL,0xB88774CEL},{(-1L),0L,0L},{(-1L),0x43AE9F60L,0xF647B4CDL},{(-1L),1L,(-1L)},{0x1B785789L,0x772EE6AAL,(-3L)},{0x7127844CL,0xE8F61F46L,(-1L)}},{{1L,0x772EE6AAL,0x05643B4EL},{0x7EB25BC2L,1L,0x668D25B7L},{0L,0x43AE9F60L,0x66B4718DL},{0x1B1463DAL,0L,0L},{0L,0x05643B4EL,0xE8F61F46L},{0L,1L,0L},{0x1B1463DAL,0x1B1463DAL,0x7127844CL},{0L,(-1L),(-1L)},{0x7EB25BC2L,(-1L),0x3B158488L}},{{1L,0x3B158488L,9L},{0x7127844CL,0x7EB25BC2L,0x3B158488L},{0x1B785789L,0xF647B4CDL,(-1L)},{(-1L),0xB88774CEL,0x7127844CL},{(-1L),(-1L),0L},{(-1L),0x668D25B7L,0xE8F61F46L},{(-1L),0x668D25B7L,0L},{0x66B4718DL,(-1L),0x66B4718DL},{6L,0xB88774CEL,0x668D25B7L}},{{0x1742EA4FL,0xF647B4CDL,0x05643B4EL},{0x43AE9F60L,0x7EB25BC2L,(-1L)},{0x668D25B7L,0x3B158488L,(-3L)},{0x43AE9F60L,(-1L),(-1L)},{0x1742EA4FL,(-1L),0xF647B4CDL},{6L,0x1B1463DAL,0L},{0x66B4718DL,1L,0xB88774CEL},{(-1L),0x05643B4EL,0xB88774CEL},{(-1L),0L,0L}},{{(-1L),0x43AE9F60L,0xF647B4CDL},{(-1L),1L,(-1L)},{0x1B785789L,0x772EE6AAL,(-3L)},{0x7127844CL,0xE8F61F46L,(-1L)},{1L,1L,0x7EB25BC2L},{0xE8F61F46L,0x3B158488L,0L},{0x05643B4EL,0x1742EA4FL,0x1B785789L},{0L,(-1L),0xB88774CEL},{(-1L),0x7EB25BC2L,(-3L)}},{{(-1L),0x668D25B7L,0x05643B4EL},{0L,0L,0x1B1463DAL},{0x05643B4EL,1L,(-1L)},{0xE8F61F46L,0L,(-1L)},{0x668D25B7L,(-1L),0x43AE9F60L},{0x1B1463DAL,0xE8F61F46L,(-1L)},{0x138E66EEL,0xA72EBB7BL,(-1L)},{(-1L),6L,0x1B1463DAL},{0x9E47D21CL,(-1L),0x05643B4EL}},{{0L,0L,(-3L)},{1L,0L,0xB88774CEL},{0x1B785789L,(-1L),0x1B785789L},{0xF647B4CDL,6L,0L},{0x7127844CL,0xA72EBB7BL,0x7EB25BC2L},{0x1742EA4FL,0xE8F61F46L,0L},{0L,(-1L),9L},{0x1742EA4FL,0L,0x9E47D21CL},{0x7127844CL,1L,0xA72EBB7BL}},{{0xF647B4CDL,0L,(-1L)},{0x1B785789L,0x668D25B7L,6L},{1L,0x7EB25BC2L,6L},{0L,(-1L),(-1L)},{0x9E47D21CL,0x1742EA4FL,0xA72EBB7BL},{(-1L),0x3B158488L,0x9E47D21CL},{0x138E66EEL,1L,9L},{0x1B1463DAL,(-3L),0L},{0x668D25B7L,1L,0x7EB25BC2L}}};
                    int8_t *l_1828 = &l_1773[2][3][1];
                    int i, j, k;
                    if (((l_1768[5][3] = ((safe_lshift_func_uint16_t_u_s((safe_mod_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((3UL ^ g_1151[g_527][g_146][(g_527 + 1)]), (((safe_add_func_uint32_t_u_u(0xB3880CBEL, g_1151[g_1276][(g_1276 + 1)][(g_527 + 1)])) > ((&g_685[(g_1276 + 5)][(g_1276 + 1)][(g_1276 + 2)] == &g_685[(g_1276 + 5)][(g_1276 + 1)][(g_1276 + 2)]) , (((((0UL >= l_1759) <= (l_1760 != g_1762[7][4])) && 0x74DB66FDEC17D63DLL) && g_1658.f0) & 0xDCD60AA13303A1D9LL))) , l_1767[3]))), l_1759)), g_242)) , p_8)) ^ p_8))
                    { /* block id: 876 */
                        int16_t l_1781 = 0x0855L;
                        p_9 = func_58(((*g_1236) = l_1783), p_8, l_1784);
                    }
                    else
                    { /* block id: 881 */
                        int32_t ***l_1789[9][3] = {{(void*)0,&l_1788,(void*)0},{&g_1236,&g_1236,&g_1236},{(void*)0,&g_1236,&l_1788},{&l_1788,&g_1236,(void*)0},{&g_1236,&g_1236,&g_1236},{(void*)0,&l_1788,(void*)0},{&l_1788,&g_1236,&l_1788},{&l_1788,&l_1788,&g_1236},{(void*)0,(void*)0,(void*)0}};
                        int i, j;
                        l_1786 = l_1785;
                        (*g_439) = (*g_439);
                        l_1790 = l_1788;
                    }
                    if ((g_1189 >= 0x5CL))
                    { /* block id: 887 */
                        struct S0 l_1791[3] = {{0x05E483111C54AF29LL},{0x05E483111C54AF29LL},{0x05E483111C54AF29LL}};
                        int i;
                        (*g_1443) = ((*g_1236) = (void*)0);
                        l_1786 = (*g_1701);
                        (*g_1236) = (l_1786 , (*g_1443));
                        return l_1791[2];
                    }
                    else
                    { /* block id: 893 */
                        int32_t *l_1804[6][5] = {{&g_31,&g_31,(void*)0,&g_31,&g_31},{&l_1768[7][5],&g_98[2][6][0],&l_1768[7][5],&l_1768[7][5],&g_98[2][6][0]},{&g_31,&g_98[1][5][8],&g_98[1][5][8],&g_31,&g_98[1][5][8]},{&g_98[2][6][0],&g_98[2][6][0],(void*)0,&g_98[2][6][0],&g_98[2][6][0]},{&g_98[1][5][8],&g_31,&g_98[1][5][8],&g_98[1][5][8],&g_31},{&g_98[2][6][0],&l_1768[7][5],&l_1768[7][5],&g_98[2][6][0],&l_1768[7][5]}};
                        int i, j, k;
                        l_1803 |= ((*l_1784) = ((((((safe_add_func_int32_t_s_s((p_8 , ((*l_1783) = ((safe_add_func_int8_t_s_s(((safe_mod_func_uint32_t_u_u((g_1151[g_146][(g_1276 + 1)][(g_527 + 1)] &= (p_8 > ((p_8 >= g_1003[0]) <= (*g_1194)))), ((((*g_1576) = (safe_mul_func_uint16_t_u_u(((((p_8 != (*l_1784)) , (l_1800 = l_1785)) , (safe_add_func_uint64_t_u_u(((*l_1783) , 0x4AE2788972C6B671LL), p_8))) < 1L), 8L))) != p_8) && (*l_1784)))) && l_1759), 0x4CL)) != l_1768[3][5]))), 0x10641B40L)) , 7UL) && p_8) , p_8) | g_1128[4]) || 0x96L));
                        l_1809++;
                        if (g_131.f0)
                            goto lbl_1986;
                        (*g_439) = (*g_439);
                    }
                    (*l_1784) ^= (safe_lshift_func_uint16_t_u_u(((((safe_lshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((*l_1828) ^= ((((((g_231 , (((l_1819 = l_1818) != l_1820) != ((safe_sub_func_uint16_t_u_u(p_8, g_888)) > g_558))) < (safe_rshift_func_int8_t_s_u((*l_1783), (l_1825 >= (safe_sub_func_int32_t_s_s(0x3528B1F0L, 0xCC7014A9L)))))) < p_8) || (*g_526)) , g_1128[1]) , p_8)) <= 0x66L), 0x2353L)), 15)) , l_1829) == l_1828) , 1UL), 2));
                }
                l_1830 = ((*g_1236) = p_9);
                return l_1786;
            }
            for (g_39 = 0; (g_39 <= 0); g_39 += 1)
            { /* block id: 913 */
                uint64_t l_1843 = 0xDF85396B1E775473LL;
                int16_t *l_1844 = &g_77[1][7][0];
                int16_t *l_1845[9][9][3] = {{{&g_242,(void*)0,&g_231},{&g_231,&g_1501,&g_1501},{&g_1501,&g_39,&g_242},{&g_39,&g_39,&g_242},{&g_242,&g_242,&g_39},{&g_1501,&g_231,(void*)0},{&g_1501,&g_231,(void*)0},{&g_231,&g_1501,(void*)0},{&g_39,&g_242,&g_39}},{{&g_1501,(void*)0,&g_242},{&g_39,&g_1501,&g_242},{&g_39,&g_1501,&g_1501},{&g_39,&g_242,&g_39},{(void*)0,(void*)0,&g_231},{&g_242,&g_242,(void*)0},{&g_1501,&g_39,&g_231},{&g_1501,(void*)0,&g_231},{&g_39,&g_1501,&g_1501}},{{&g_39,&g_39,(void*)0},{&g_1501,&g_242,&g_242},{(void*)0,(void*)0,&g_231},{(void*)0,&g_231,(void*)0},{&g_242,&g_1501,&g_39},{(void*)0,&g_242,&g_39},{&g_231,&g_1501,(void*)0},{&g_1501,&g_231,&g_242},{&g_231,(void*)0,&g_1501}},{{(void*)0,&g_242,&g_39},{&g_242,&g_1501,&g_242},{(void*)0,&g_242,&g_1501},{(void*)0,&g_1501,&g_1501},{&g_1501,&g_242,&g_231},{&g_39,(void*)0,(void*)0},{&g_39,&g_242,&g_39},{&g_1501,&g_242,(void*)0},{&g_1501,&g_242,&g_1501}},{{&g_242,&g_39,(void*)0},{(void*)0,&g_242,&g_231},{&g_39,&g_242,(void*)0},{&g_231,&g_1501,&g_1501},{(void*)0,&g_1501,&g_242},{&g_1501,&g_39,&g_242},{&g_39,&g_1501,&g_231},{(void*)0,(void*)0,&g_231},{(void*)0,&g_1501,(void*)0}},{{&g_242,&g_39,&g_39},{&g_231,&g_1501,&g_1501},{&g_1501,&g_1501,&g_242},{(void*)0,&g_242,&g_1501},{&g_242,&g_242,&g_1501},{(void*)0,&g_39,&g_1501},{(void*)0,&g_242,&g_242},{&g_39,&g_242,&g_1501},{&g_1501,&g_242,&g_242}},{{&g_1501,(void*)0,(void*)0},{&g_242,&g_242,&g_39},{&g_1501,&g_1501,&g_242},{(void*)0,&g_242,&g_1501},{&g_1501,&g_1501,(void*)0},{&g_242,&g_242,&g_242},{&g_1501,(void*)0,&g_242},{&g_231,&g_231,(void*)0},{&g_39,&g_1501,&g_242}},{{&g_1501,&g_242,&g_242},{&g_242,&g_1501,(void*)0},{&g_231,&g_231,&g_1501},{(void*)0,(void*)0,&g_242},{(void*)0,&g_242,&g_39},{(void*)0,&g_39,(void*)0},{(void*)0,&g_1501,&g_242},{(void*)0,(void*)0,&g_1501},{&g_242,&g_39,&g_242}},{{&g_242,&g_242,&g_1501},{(void*)0,(void*)0,&g_1501},{&g_242,&g_242,&g_1501},{&g_39,&g_242,&g_231},{&g_1501,&g_1501,&g_1501},{&g_1501,&g_231,&g_231},{(void*)0,(void*)0,&g_1501},{&g_39,(void*)0,(void*)0},{&g_231,&g_39,&g_39}}};
                struct S0 l_1846 = {1UL};
                int i, j, k;
                (*g_1576) ^= ((safe_add_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u((+((safe_mul_func_uint8_t_u_u((~((safe_lshift_func_int8_t_s_u(g_1766, 3)) == ((-4L) >= g_146))), ((*l_1784) = 0x45L))) , (safe_mul_func_uint8_t_u_u((((0x67B5EE4E6E44449BLL != 0xEC555400D8540711LL) , p_8) >= (((*l_1844) = l_1843) ^ (g_1501 = (((***g_438) , p_8) , g_1080)))), 0x43L)))), g_1080)) || l_1843) <= g_98[1][6][2]), 0xB73FL)) && 0x5C14L);
                for (g_231 = 0; (g_231 >= 0); g_231 -= 1)
                { /* block id: 920 */
                    return l_1846;
                }
            }
            for (g_1658.f0 = 0; (g_1658.f0 <= 0); g_1658.f0 += 1)
            { /* block id: 926 */
                uint64_t l_1849 = 7UL;
                uint8_t **l_1859 = &g_526;
                struct S0 * const *l_1868[1][5] = {{&g_362,&g_362,&g_362,&g_362,&g_362}};
                struct S0 * const **l_1867 = &l_1868[0][2];
                struct S0 * const ***l_1866 = &l_1867;
                int32_t l_1878 = 0xF3EB4DCFL;
                int32_t l_1951 = 0x14863375L;
                int32_t l_1952 = (-5L);
                int32_t l_1954 = 0x9B25FF0CL;
                int32_t l_1955[10] = {0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L,0x4B91A229L};
                int32_t *l_1978 = &l_1767[3];
                int32_t *l_1979 = &l_1955[1];
                int32_t *l_1980 = &l_1936[5];
                int32_t *l_1981 = &l_1936[3];
                int32_t *l_1982[9] = {(void*)0,(void*)0,&l_1954,(void*)0,(void*)0,&l_1954,(void*)0,(void*)0,&l_1954};
                int i, j;
                for (g_898 = 0; (g_898 <= 0); g_898 += 1)
                { /* block id: 929 */
                    int64_t * const ***l_1856 = &l_1854;
                    int32_t l_1860[1][5][3] = {{{(-8L),8L,8L},{0x2A09F964L,8L,0xF7A1DEF7L},{0xAB7CD38AL,(-8L),1L},{0x2A09F964L,0x2A09F964L,1L},{(-8L),0xAB7CD38AL,0xF7A1DEF7L}}};
                    uint64_t *l_1869 = (void*)0;
                    uint64_t *l_1870 = &l_1786.f0;
                    int i, j, k;
                }
                for (g_1501 = 0; (g_1501 <= 0); g_1501 += 1)
                { /* block id: 953 */
                    uint64_t l_1913[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
                    int i;
                    for (l_1808 = 0; (l_1808 >= 0); l_1808 -= 1)
                    { /* block id: 956 */
                        int32_t l_1898[9][7][4] = {{{3L,(-3L),(-10L),1L},{0x9F2382C9L,(-7L),0x39435F5EL,0x304F6D8EL},{0x48C71C8CL,0L,0L,0x26C7498BL},{0x26C7498BL,(-6L),0L,0L},{1L,0x0A2F2999L,0x304F6D8EL,0xC36BF298L},{0x9D38877BL,(-1L),0xA0EC4B0AL,1L},{(-1L),(-6L),1L,(-7L)}},{{0xBA2A40C2L,0x48C71C8CL,0xBA2A40C2L,0x304F6D8EL},{0L,0x149059FCL,0xAE6F21F1L,0xAC7BE672L},{0x48C71C8CL,(-3L),0x790AA1D0L,0x149059FCL},{0x92175C1AL,0x9D38877BL,0x790AA1D0L,0x527BABB1L},{0x48C71C8CL,0x0A2F2999L,0xAE6F21F1L,0x13497F73L},{0L,(-10L),0xBA2A40C2L,0L},{0xBA2A40C2L,0L,1L,(-1L)}},{{(-1L),1L,0xA0EC4B0AL,1L},{0x9D38877BL,0x5C079328L,0x304F6D8EL,0xAC7BE672L},{1L,0x48C71C8CL,0L,(-1L)},{0x26C7498BL,1L,0L,0x9D38877BL},{0x48C71C8CL,(-10L),0x39435F5EL,(-9L)},{0x9F2382C9L,(-1L),(-10L),0x527BABB1L},{3L,0L,0x48E61B3AL,0x26C7498BL}},{{0x0A2F2999L,(-3L),0xBA2A40C2L,0L},{0x9F2382C9L,0x26C7498BL,0x304F6D8EL,0x304F6D8EL},{1L,1L,0L,0x149059FCL},{(-7L),(-6L),0xC36BF298L,0x9D38877BL},{1L,3L,(-8L),0xC36BF298L},{0L,3L,0xA0EC4B0AL,0x9D38877BL},{3L,(-6L),(-3L),0x149059FCL}},{{0xBA2A40C2L,1L,(-10L),0x304F6D8EL},{1L,0x26C7498BL,0xAE6F21F1L,0L},{0L,(-3L),0L,0x26C7498BL},{0x92175C1AL,0L,0xC36BF298L,0x527BABB1L},{6L,0x92175C1AL,0L,(-3L)},{0xBA2A40C2L,1L,1L,0xBA2A40C2L},{0x260902E9L,(-10L),(-8L),0x61C1364EL}},{{(-1L),1L,(-7L),0L},{(-10L),0xAE6F21F1L,0L,0x790AA1D0L},{(-8L),6L,0x48E61B3AL,0x61C1364EL},{0x39435F5EL,3L,1L,3L},{0L,1L,1L,1L},{0xBF96DB18L,(-1L),1L,(-10L)},{0x92175C1AL,0xBA2A40C2L,(-1L),0x39435F5EL}},{{0x92175C1AL,0xE22444F7L,1L,0L},{0xBF96DB18L,0x39435F5EL,1L,0x3ED58B33L},{0L,1L,1L,(-8L)},{0x39435F5EL,0xA0EC4B0AL,0x48E61B3AL,(-10L)},{(-8L),0x92175C1AL,0L,(-3L)},{(-10L),(-1L),(-7L),3L},{(-1L),0xA0EC4B0AL,(-8L),0x304F6D8EL}},{{0x260902E9L,0L,1L,0x3ED58B33L},{0xBA2A40C2L,(-8L),0L,0x790AA1D0L},{6L,0xE22444F7L,(-3L),(-8L)},{1L,(-10L),0x593B36E6L,(-10L)},{0L,0x5C079328L,0L,1L},{(-10L),1L,1L,(-10L)},{0x260902E9L,0xBA2A40C2L,0xE22444F7L,0x61C1364EL}},{{0x5C079328L,0L,(-7L),0xC36BF298L},{3L,0xAE6F21F1L,1L,0xC36BF298L},{(-8L),0L,(-3L),0x61C1364EL},{(-8L),0xBA2A40C2L,1L,(-10L)},{6L,1L,0x3ED58B33L,1L},{0xBF96DB18L,0x5C079328L,0x260902E9L,(-10L)},{(-1L),(-10L),(-1L),(-8L)}}};
                        int32_t *l_1899 = &l_1806;
                        int32_t *l_1900 = &l_1898[8][6][3];
                        int32_t *l_1901 = &g_98[1][5][8];
                        int32_t *l_1902 = &l_1807[0];
                        int32_t *l_1903 = &l_1807[0];
                        int32_t *l_1905 = &l_1807[0];
                        int32_t *l_1906 = &l_1898[1][5][2];
                        int32_t *l_1907 = (void*)0;
                        int32_t *l_1908 = &l_1807[l_1808];
                        int32_t *l_1909 = &l_1767[2];
                        int32_t *l_1910 = (void*)0;
                        int32_t *l_1911 = &l_1878;
                        int32_t *l_1912[9][9] = {{&l_1806,&l_1898[5][4][1],&l_1878,&l_1904,&l_1807[0],&l_1807[0],&l_1904,&l_1878,&l_1898[5][4][1]},{&l_1898[5][4][1],&g_98[0][5][7],&l_1782,&l_1904,(void*)0,&l_1904,&g_98[0][5][7],&l_1808,&l_1878},{&l_1878,&l_1782,&l_1904,&l_1782,&g_98[1][5][8],&l_1878,&l_1807[0],&g_98[2][2][5],(void*)0},{&g_98[1][5][8],&g_98[0][5][7],&l_1898[4][4][2],&g_98[2][2][5],&l_1898[5][4][1],&l_1807[l_1808],&l_1898[4][2][2],&g_98[1][5][8],&g_98[1][5][8]},{&g_31,&l_1898[5][4][1],&l_1782,&l_1807[l_1808],&l_1898[4][2][2],&l_1807[l_1808],&l_1782,&l_1898[5][4][1],&g_31},{&l_1806,&g_98[2][2][5],&l_1808,&g_98[1][5][8],(void*)0,&l_1878,&g_98[1][5][8],&l_1878,&g_98[2][2][5]},{&g_98[1][5][8],(void*)0,&l_1904,&l_1807[0],(void*)0,&l_1904,&g_98[0][2][6],(void*)0,&l_1807[0]},{&l_1806,(void*)0,&g_98[1][5][8],&l_1782,&g_31,&l_1898[5][4][1],&l_1782,&l_1807[l_1808],&l_1898[4][2][2]},{&g_98[1][5][8],&l_1782,&l_1904,&g_31,&g_31,&l_1904,&l_1782,&g_98[1][5][8],&l_1807[l_1808]}};
                        int i, j, k;
                        (*g_439) = (*g_439);
                        l_1913[3]++;
                        return l_1916[0][6][4];
                    }
                    return l_1786;
                }
                for (g_100 = 0; (g_100 <= 0); g_100 += 1)
                { /* block id: 965 */
                    uint16_t l_1917 = 65535UL;
                    int32_t l_1934 = 0xADFB9823L;
                    int32_t l_1935[2][2][7] = {{{0x95A75F07L,0xF8145633L,5L,5L,0xF8145633L,0x95A75F07L,0x6CB5866DL},{0x95A75F07L,0xF8145633L,5L,5L,0xF8145633L,0x95A75F07L,0x6CB5866DL}},{{0x95A75F07L,0xF8145633L,5L,5L,0xF8145633L,0x95A75F07L,0x6CB5866DL},{0x95A75F07L,0xF8145633L,5L,5L,0xF8145633L,0x95A75F07L,0x6CB5866DL}}};
                    uint32_t l_1949 = 0xA0DBF033L;
                    int64_t l_1953 = 1L;
                    int32_t ** const l_1965 = &g_754;
                    int32_t ** const *l_1964 = &l_1965;
                    int32_t ** const **l_1963 = &l_1964;
                    int i, j, k;
                    if (((l_1917 >= (*l_1830)) < (((safe_rshift_func_int8_t_s_u((safe_add_func_uint8_t_u_u((p_8 >= l_1849), 1L)), 0)) | ((safe_rshift_func_uint8_t_u_s(0UL, 2)) ^ 0x22L)) == (p_8 <= ((*l_1784) ^= ((((safe_lshift_func_uint16_t_u_u((((g_77[(g_100 + 1)][(g_1658.f0 + 6)][g_100] = g_357[1][0]) == 8UL) == (*g_440)), 15)) >= g_908) ^ 0xF1139472L) != 0x91L))))))
                    { /* block id: 968 */
                        int32_t *l_1926 = &l_1808;
                        int32_t *l_1927 = (void*)0;
                        int32_t *l_1928 = &l_1807[0];
                        int32_t *l_1929 = &l_1767[3];
                        int32_t *l_1930 = &l_1767[1];
                        int32_t *l_1931 = &g_98[0][7][1];
                        int32_t *l_1932 = &l_1782;
                        int32_t *l_1933[5];
                        struct S0 l_1940 = {1UL};
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1933[i] = &l_1808;
                        l_1937++;
                        (*l_1932) ^= ((((((l_1940 , ((l_1878 = ((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((((l_1935[1][0][2] = 9UL) >= 0UL) , (*g_526)), (((((*g_1568) && (*l_1830)) > (safe_lshift_func_uint16_t_u_u((*g_1194), ((safe_mod_func_uint32_t_u_u((l_1949 != g_358), l_1849)) , 65532UL)))) , (*l_1830)) >= (*g_1746)))), p_8)) != l_1950)) , (void*)0)) != (void*)0) , 4294967293UL) > 0xB5F02F84L) , (*l_1784)) && (*l_1784));
                        l_1957--;
                    }
                    else
                    { /* block id: 974 */
                        int8_t l_1960[2][10] = {{0x8DL,(-5L),0x8DL,0x8DL,(-5L),0x8DL,0x8DL,(-5L),0x8DL,0x8DL},{(-5L),(-5L),0xC0L,(-5L),(-5L),0xC0L,(-5L),(-5L),0xC0L,(-5L)}};
                        int i, j;
                        if (l_1960[0][5])
                            break;
                        (*l_1830) = ((safe_lshift_func_int8_t_s_u((((p_8 , (void*)0) != &l_1855) || (l_1960[0][5] != ((void*)0 == l_1963))), 6)) > (((((((safe_div_func_uint8_t_u_u((8UL < (((*g_1568) | ((safe_rshift_func_uint8_t_u_s(((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(((((safe_mul_func_uint16_t_u_u(p_8, p_8)) != (*l_1784)) , l_1917) != (*l_1830)), 1L)), g_31)) ^ 65535UL), p_8)) > g_357[0][0])) , (*l_1784))), 255UL)) != p_8) >= p_8) || p_8) | p_8) >= 0x201DL) && p_8));
                    }
                }
                --l_1983;
            }
        }
        p_7 = p_10;
    }
    else
    { /* block id: 984 */
lbl_2061:
        for (g_52.f0 = 0; (g_52.f0 >= 48); g_52.f0 = safe_add_func_uint8_t_u_u(g_52.f0, 8))
        { /* block id: 987 */
            struct S0 *l_1990 = &l_1989;
            int32_t l_1991 = 0x9CFE4809L;
            uint64_t *l_1995 = &g_131.f0;
            (*l_1990) = l_1989;
            for (g_888 = 0; (g_888 <= 0); g_888 += 1)
            { /* block id: 991 */
                (*g_1576) &= l_1991;
                if ((*g_1576))
                    break;
                g_1992 = 0x241AC736L;
            }
            (*g_1576) ^= (safe_rshift_func_uint16_t_u_u(((**g_1567) == ((*l_1995) = g_1057)), (safe_rshift_func_int16_t_s_s(l_1991, 13))));
        }
        l_1989 = l_1989;
    }
    for (l_1904 = (-29); (l_1904 <= (-20)); l_1904 = safe_add_func_uint32_t_u_u(l_1904, 4))
    { /* block id: 1003 */
        uint32_t l_2010 = 1UL;
        uint8_t *****l_2026 = (void*)0;
        int64_t *l_2027 = &g_95;
        int8_t *l_2031 = &l_1956;
        uint32_t *l_2032[8] = {&g_1173,&g_1173,&g_1173,&g_1173,&g_1173,&g_1173,&g_1173,&g_1173};
        int32_t l_2033 = 6L;
        int16_t *l_2040 = &g_1501;
        int16_t **l_2039 = &l_2040;
        int32_t ***l_2057[1][5] = {{&l_1790,&l_1790,&l_1790,&l_1790,&l_1790}};
        int32_t ****l_2056[7][8] = {{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]},{&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3],&l_2057[0][2],&l_2057[0][3],&l_2057[0][3],&l_2057[0][3]}};
        uint32_t l_2058 = 0x07E271C9L;
        uint8_t *l_2059 = &l_2029;
        int i, j;
        (*g_1443) = p_7;
        (*g_1576) |= ((safe_mul_func_int8_t_s_s(4L, ((safe_rshift_func_int16_t_s_s((g_358 <= ((safe_mod_func_uint32_t_u_u((safe_div_func_int64_t_s_s((-5L), (safe_rshift_func_int16_t_s_s(((l_2010 != (((*g_1194) >= (safe_add_func_uint32_t_u_u(g_242, ((l_2033 = (safe_mul_func_int8_t_s_s(((*l_2031) |= (((!((0xF0L != (*g_526)) != (((*l_2027) = (safe_div_func_uint32_t_u_u((safe_mod_func_int16_t_s_s(((safe_mul_func_int8_t_s_s((&g_1744 == l_2026), g_98[1][5][8])) ^ (*g_526)), l_2010)), 8UL))) != l_2028))) >= l_2029) > g_2030)), l_2010))) >= 0L)))) , p_8)) | 0xCC9CBF43D9172837LL), 5)))), g_98[0][6][0])) || (**g_1567))), p_8)) < l_2010))) ^ p_8);
        (*g_1236) = ((safe_mul_func_uint8_t_u_u((((**l_1820) = (((safe_rshift_func_uint8_t_u_s((!(l_2039 == g_2041[1])), 5)) , &g_1216) == &g_1216)) & (safe_div_func_uint64_t_u_u(((((*l_2059) = (safe_mul_func_int8_t_s_s(((l_2033 , ((((*l_2027) = ((safe_div_func_uint16_t_u_u(((l_2033 = 1UL) | ((--(*g_1194)) > (1UL && ((g_898 &= ((void*)0 != l_2056[0][3])) > p_8)))), 0xF375L)) > (***g_438))) == 18446744073709551612UL) || p_8)) , l_2058), 255UL))) | g_888) < p_8), p_8))), g_131.f0)) , l_2060);
        if (l_1808)
            goto lbl_2061;
    }
    return (*g_1701);
}


/* ------------------------------------------ */
/* 
 * reads : g_357 g_1193 g_1194 g_1189 g_231 g_440 g_441 g_1128 g_392 g_898 g_90 g_526 g_126 g_77 g_1379 g_1236 g_31 g_438 g_439 g_1151 g_448 g_908 g_20 g_1173 g_100 g_1442 g_1443 g_888 g_1057 g_527 g_98 g_39 g_1060 g_52.f0 g_93 g_95 g_52 g_1555 g_1080 g_1567 g_1576 g_146 g_1276 g_1003 g_971 g_894 g_1701 g_1568 g_1569 g_358 g_1658.f0 g_1746
 * writes: g_357 g_231 g_1189 g_898 g_392 g_527 g_100 g_448 g_893 g_98 g_358 g_1173 g_30 g_888 g_1057 g_39 g_1276 g_1501 g_1003 g_31 g_90 g_93 g_126 g_77 g_131 g_1555 g_146 g_1060 g_1658.f0 g_95 g_1742 g_1743 g_1744
 */
static int32_t * func_11(uint32_t  p_12, uint32_t  p_13, int32_t  p_14)
{ /* block id: 638 */
    uint64_t *l_1333 = (void*)0;
    uint16_t *l_1341 = &g_1060;
    int32_t l_1342 = 4L;
    const struct S0 l_1345 = {0x598A453CA6C015FCLL};
    int16_t *l_1350[5][9][2] = {{{&g_77[0][6][0],(void*)0},{&g_77[1][7][0],&g_231},{&g_77[1][7][0],(void*)0},{&g_77[0][6][0],&g_77[0][6][0]},{(void*)0,&g_77[1][7][0]},{&g_231,&g_77[1][7][0]},{(void*)0,&g_77[0][6][0]},{&g_77[0][6][0],(void*)0},{&g_77[1][7][0],&g_231}},{{&g_77[1][7][0],(void*)0},{&g_77[0][6][0],&g_77[0][6][0]},{(void*)0,&g_77[1][7][0]},{&g_231,&g_77[1][7][0]},{(void*)0,&g_77[0][6][0]},{&g_77[0][6][0],(void*)0},{&g_77[1][7][0],&g_231},{&g_77[1][7][0],(void*)0},{&g_77[0][6][0],&g_77[0][6][0]}},{{(void*)0,&g_77[1][7][0]},{&g_231,&g_77[1][7][0]},{(void*)0,&g_77[0][6][0]},{&g_77[0][6][0],(void*)0},{&g_77[1][7][0],&g_231},{&g_77[1][7][0],(void*)0},{&g_77[0][6][0],&g_77[0][6][0]},{(void*)0,&g_77[1][7][0]},{&g_231,&g_77[1][7][0]}},{{(void*)0,&g_77[0][6][0]},{&g_77[0][6][0],(void*)0},{&g_77[1][7][0],&g_231},{(void*)0,&g_231},{&g_231,&g_231},{&g_231,(void*)0},{&g_231,(void*)0},{&g_231,&g_231},{&g_231,&g_231}},{{(void*)0,&g_231},{(void*)0,&g_231},{&g_231,&g_231},{&g_231,(void*)0},{&g_231,(void*)0},{&g_231,&g_231},{&g_231,&g_231},{(void*)0,&g_231},{(void*)0,&g_231}}};
    int16_t l_1351 = (-9L);
    int32_t l_1352 = 0L;
    uint8_t l_1353 = 0UL;
    uint8_t *** const *l_1356 = &g_1216;
    int32_t l_1452 = 0x49879BADL;
    int32_t l_1454 = 0x51E9778BL;
    int32_t l_1455 = 0x85CF9BD3L;
    int32_t l_1457[4][8] = {{(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L},{(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L},{(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L},{(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L}};
    const int8_t l_1476 = (-9L);
    uint64_t l_1485 = 18446744073709551615UL;
    int16_t *l_1499[6] = {&g_231,&g_231,&g_231,&g_231,&g_231,&g_231};
    struct S0 l_1530[10] = {{0x55544CDBDE0C99A0LL},{1UL},{0x55544CDBDE0C99A0LL},{1UL},{0x55544CDBDE0C99A0LL},{1UL},{0x55544CDBDE0C99A0LL},{1UL},{0x55544CDBDE0C99A0LL},{1UL}};
    int32_t l_1531 = 0x46632936L;
    uint8_t l_1544[2];
    uint32_t l_1572 = 0xC48A4933L;
    int64_t **l_1667 = &g_894[1];
    int32_t *l_1681[9];
    int32_t *l_1683 = &l_1452;
    int64_t *l_1690 = &g_95;
    struct S0 l_1714 = {0x7BB9BEAF0908A11ALL};
    int8_t l_1716 = (-1L);
    uint8_t ****l_1739 = &g_1216;
    uint8_t ****l_1740 = &g_1216;
    int32_t *l_1745 = &l_1352;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1544[i] = 0x02L;
    for (i = 0; i < 9; i++)
        l_1681[i] = &l_1531;
lbl_1715:
    if ((((p_13 < (safe_mul_func_int16_t_s_s((l_1352 = ((safe_add_func_uint8_t_u_u((((safe_div_func_uint64_t_u_u((g_357[1][0]++), (((l_1342 = (safe_unary_minus_func_uint32_t_u((((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((((*g_1193) != l_1341) , p_13), 4)), (l_1342 | (safe_sub_func_uint16_t_u_u(((**g_1193) != ((l_1345 , (((p_12 , (safe_sub_func_int16_t_s_s((g_231 ^= (0x04DFL | 0x524FL)), 1UL))) < 0UL) & l_1351)) & l_1345.f0)), (**g_1193)))))) , 0x076F44CAD5AB6F27LL) , 0UL)))) | (**g_1193)) && l_1351))) & 0x1DL) >= p_12), 0xD0L)) < 0L)), 1UL))) < 65535UL) & l_1353))
    { /* block id: 643 */
        uint8_t l_1357 = 0xCCL;
        struct S0 l_1384 = {0x17A3243101DBF2ECLL};
        int32_t l_1413 = 0x23BB7A55L;
        int32_t *l_1417 = (void*)0;
        int32_t l_1418 = 0x644A9A22L;
        int16_t l_1438[3][9][8] = {{{0L,(-1L),0L,8L,0xF762L,0xB214L,0xA676L,0x3E01L},{0x3BBCL,0L,(-9L),0L,0xF762L,0x76B1L,0x4FAFL,0xB214L},{0L,1L,0x8321L,0x3E01L,(-9L),0x3E01L,0x8321L,1L},{(-9L),1L,0xA676L,5L,0L,0x76B1L,0x77D4L,8L},{0xA676L,0L,1L,(-1L),(-9L),0xB214L,0x77D4L,8L},{0x4FAFL,(-1L),0xA676L,0x76B1L,0x8321L,(-3L),0x8321L,0x76B1L},{0x8321L,(-3L),0x8321L,0x76B1L,0xA676L,(-1L),0x4FAFL,8L},{0x77D4L,0xB214L,(-9L),(-1L),1L,0L,0xA676L,8L},{0x77D4L,0x76B1L,0L,5L,0xA676L,1L,(-9L),1L}},{{0x8321L,0x3E01L,(-9L),0x3E01L,0x8321L,1L,0L,0xB214L},{0x4FAFL,0x76B1L,0xF762L,0L,(-9L),0L,0x3BBCL,0x3E01L},{0xA676L,0xB214L,0xF762L,8L,0L,(-1L),0L,1L},{(-9L),(-3L),(-9L),0xB214L,(-9L),(-3L),(-9L),1L},{0L,(-1L),0L,8L,0xF762L,0xB214L,0xA676L,0x3E01L},{0xA676L,0L,0x3BBCL,0xB214L,0L,1L,0x8321L,0x3E01L},{0x77D4L,4L,1L,(-3L),0x4FAFL,(-3L),1L,4L},{0x3BBCL,4L,0xF762L,(-1L),(-9L),1L,0xA603L,0x76B1L},{0xF762L,0L,(-9L),0L,0x3BBCL,0x3E01L,0xA603L,1L}},{{0x8321L,0L,0xF762L,1L,1L,8L,1L,1L},{1L,8L,1L,1L,0xF762L,0L,0x8321L,1L},{0xA603L,0x3E01L,0x3BBCL,0L,(-9L),0L,0xF762L,0x76B1L},{0xA603L,1L,(-9L),(-1L),0xF762L,4L,0x3BBCL,4L},{1L,(-3L),0x4FAFL,(-3L),1L,4L,0x77D4L,0x3E01L},{0x8321L,1L,0L,0xB214L,0x3BBCL,0L,0xA676L,(-3L)},{0xF762L,0x3E01L,0L,0x76B1L,(-9L),0L,0x77D4L,5L},{0x3BBCL,8L,0x4FAFL,0x3E01L,0x4FAFL,8L,0x3BBCL,5L},{0x77D4L,0L,(-9L),0x76B1L,0L,0x3E01L,0xF762L,(-3L)}}};
        uint32_t l_1489 = 4294967295UL;
        int i, j, k;
        for (l_1351 = 0; (l_1351 <= 7); l_1351 += 1)
        { /* block id: 646 */
            uint32_t l_1358[6][2][8] = {{{0x8D3AFF71L,0UL,0x062222DDL,4294967289UL,0xFC661A72L,0xCFF7F532L,6UL,4294967295UL},{0UL,9UL,0x43AF20D3L,1UL,0UL,4294967288UL,4294967287UL,0x0C561145L}},{{0x0C561145L,0x5AFCAF45L,0xE5BFAB2AL,0UL,9UL,0x8535ABE6L,0UL,0xFC661A72L},{4294967287UL,0UL,0x4844B467L,0xB3A0C61CL,0xFA847BCFL,0x70CF6027L,0xFA847BCFL,0xB3A0C61CL}},{{4294967291UL,4294967286UL,4294967291UL,4294967295UL,0x4272E001L,1UL,4294967289UL,0x8D3AFF71L},{9UL,0xB3A0C61CL,5UL,0x7C61A46AL,4294967292UL,4294967295UL,0x4272E001L,4294967293UL}},{{9UL,0x0C561145L,0x8535ABE6L,0xFB29DFCCL,0x4272E001L,6UL,1UL,0xE5BFAB2AL},{4294967291UL,0UL,9UL,5UL,0xFA847BCFL,0x062222DDL,0x7C61A46AL,1UL}},{{4294967287UL,0x43AF20D3L,0xFB29DFCCL,0xFA847BCFL,9UL,0x5AFCAF45L,0x5AFCAF45L,9UL},{0x0C561145L,6UL,6UL,0x0C561145L,0UL,0UL,4294967295UL,4294967288UL}},{{0UL,0x4272E001L,0x5AFCAF45L,0x39EF8152L,0xFC661A72L,0x3776624EL,4294967293UL,0x73AAA8C4L},{0UL,4294967295UL,0x39EF8152L,4294967295UL,0UL,0x7C61A46AL,0xFB29DFCCL,0xCFF7F532L}}};
            int32_t l_1378 = (-1L);
            int32_t l_1459 = 0xDC6375DEL;
            int32_t l_1460 = 0xEA230EA0L;
            int32_t l_1461 = 0xA2233E08L;
            uint32_t l_1463 = 18446744073709551610UL;
            struct S0 l_1466 = {0x9DAB2D4FE01870A7LL};
            int32_t *l_1475 = &l_1342;
            uint32_t *l_1477 = &g_888;
            uint32_t *l_1480 = (void*)0;
            uint32_t *l_1481 = &g_1057;
            int16_t **l_1484 = &l_1350[1][7][0];
            uint8_t l_1488 = 1UL;
            int i, j, k;
            if ((safe_rshift_func_uint16_t_u_s((((l_1352 <= ((((void*)0 == l_1356) == (((**g_1193) = ((0x87L == l_1357) != p_12)) , (l_1358[3][0][1] <= (((safe_sub_func_uint32_t_u_u(1UL, (*g_440))) != p_14) | (-7L))))) <= l_1357)) & 0x78L) , l_1358[3][1][7]), g_1128[4])))
            { /* block id: 648 */
                int32_t *l_1381[2];
                struct S0 l_1415[1] = {{18446744073709551608UL}};
                int i;
                for (i = 0; i < 2; i++)
                    l_1381[i] = (void*)0;
                for (g_898 = 0; (g_898 <= 0); g_898 += 1)
                { /* block id: 651 */
                    const int32_t l_1377 = 0x8D70DC6CL;
                    for (g_392 = 0; (g_392 <= 0); g_392 += 1)
                    { /* block id: 654 */
                        int i, j;
                        (*g_1379) = ((!((safe_lshift_func_uint8_t_u_s(((((safe_sub_func_int32_t_s_s((l_1378 = (safe_lshift_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(g_90[(g_392 + 2)][(g_898 + 3)], ((void*)0 != &g_489))), (safe_add_func_uint64_t_u_u((safe_unary_minus_func_uint8_t_u((safe_mul_func_uint8_t_u_u(((*g_526) = ((void*)0 == &l_1333)), 0L)))), g_357[g_898][g_898])))), l_1377))), 0x3A8CA0DEL)) || l_1352) && g_126) , 0x71L), p_12)) | g_77[1][6][0])) == p_13);
                    }
                }
                (*g_1236) = &l_1378;
                for (g_100 = 0; (g_100 <= 7); g_100 += 1)
                { /* block id: 663 */
                    struct S0 l_1385 = {18446744073709551615UL};
                    int32_t *l_1416 = &l_1413;
                    for (g_898 = 0; (g_898 <= 1); g_898 += 1)
                    { /* block id: 666 */
                        int64_t ***l_1380 = &g_893[3];
                        (*l_1380) = (void*)0;
                        return l_1381[0];
                    }
                    if ((65535UL ^ ((safe_lshift_func_int8_t_s_s(((void*)0 != l_1381[0]), 2)) , l_1358[2][0][2])))
                    { /* block id: 670 */
                        struct S0 l_1386 = {1UL};
                        l_1386 = (l_1385 = l_1384);
                    }
                    else
                    { /* block id: 673 */
                        uint32_t *l_1412[9][10][2] = {{{(void*)0,(void*)0},{&l_1358[2][0][7],&g_898},{&g_126,&l_1358[2][0][7]},{&g_1151[1][1][0],&g_358},{&g_1151[1][1][0],&l_1358[2][0][7]},{&g_126,&g_898},{&l_1358[2][0][7],(void*)0},{(void*)0,(void*)0},{&g_898,&g_1151[1][2][0]},{&g_1151[1][2][0],&g_126}},{{&l_1358[2][0][7],&l_1358[4][1][1]},{&g_1151[0][0][0],&g_146},{&g_146,&g_898},{&l_1358[0][0][5],&g_1151[0][0][0]},{(void*)0,&g_146},{&g_146,&g_146},{&g_126,&g_898},{&g_1151[0][0][0],&l_1358[4][1][3]},{&g_1151[0][0][0],&g_126},{&g_898,&g_1151[1][2][0]}},{{&g_126,&l_1358[1][0][7]},{&g_358,(void*)0},{&g_126,&g_1151[0][0][0]},{&g_146,&g_898},{&g_1151[0][0][2],&g_358},{&g_1151[1][1][0],&g_1151[0][0][0]},{&g_126,&g_146},{&l_1358[0][0][5],&l_1358[2][0][7]},{&g_358,(void*)0},{&g_126,&g_1151[0][2][2]}},{{&g_898,&g_126},{&l_1358[1][0][7],&g_146},{&l_1358[2][0][7],&g_126},{&g_146,&g_1151[0][0][0]},{&l_1358[2][0][7],&l_1358[2][0][7]},{&g_1151[0][3][3],&g_1151[0][0][0]},{&g_146,&g_1151[1][2][3]},{&g_126,&l_1358[2][0][7]},{&g_1151[0][0][2],&g_358},{&g_1151[0][0][0],&g_146}},{{&g_146,&g_1151[0][2][2]},{&g_898,&l_1358[1][0][7]},{&g_146,&l_1358[1][0][7]},{&g_898,&g_1151[0][2][2]},{&g_146,&g_146},{&g_1151[0][0][0],&g_358},{&g_1151[0][0][2],&l_1358[2][0][7]},{&g_126,&g_1151[1][2][3]},{&g_146,&g_1151[0][0][0]},{&g_1151[0][3][3],&l_1358[2][0][7]}},{{&l_1358[2][0][7],&g_1151[0][0][0]},{&g_146,&g_126},{&l_1358[2][0][7],&g_146},{&l_1358[1][0][7],&g_126},{&g_898,&g_1151[0][2][2]},{&g_126,(void*)0},{&g_358,&l_1358[2][0][7]},{&l_1358[0][0][5],&g_146},{&g_126,&g_1151[0][0][0]},{&g_1151[1][1][0],&g_358}},{{&g_1151[0][0][2],&g_898},{&g_146,&g_1151[0][0][0]},{&g_126,(void*)0},{&g_358,&l_1358[1][0][7]},{&g_126,&g_1151[1][2][0]},{&g_898,&g_126},{&g_1151[0][0][0],&l_1358[4][1][3]},{&g_1151[0][0][0],&g_898},{&g_126,&g_146},{&g_146,&g_146}},{{(void*)0,&g_1151[0][0][0]},{&l_1358[0][0][5],&g_898},{&g_146,&g_146},{&g_1151[0][0][0],&l_1358[4][1][1]},{&l_1358[2][0][7],&g_126},{&g_1151[1][2][0],&g_1151[1][2][0]},{&g_898,(void*)0},{(void*)0,(void*)0},{&l_1358[2][0][7],&g_898},{&g_126,&l_1358[2][0][7]}},{{&g_1151[1][1][0],&g_358},{&g_1151[1][1][0],&l_1358[2][0][7]},{&g_126,&g_898},{&l_1358[2][0][7],(void*)0},{(void*)0,(void*)0},{&g_898,&g_1151[1][2][0]},{&g_1151[1][2][0],&g_126},{&l_1358[2][0][7],&l_1358[4][1][1]},{&g_1151[0][0][0],&g_146},{&g_146,&g_898}}};
                        int32_t l_1414[6] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
                        int i, j, k;
                        (*g_1236) = &p_14;
                        l_1352 = ((safe_add_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((((*g_448) = (safe_mul_func_uint16_t_u_u(p_14, (l_1413 = (safe_sub_func_int32_t_s_s((safe_sub_func_uint16_t_u_u(3UL, 0UL)), ((safe_mod_func_uint32_t_u_u(((0xDFE4E4BB436529ECLL < p_13) , (p_12 = (safe_mul_func_uint16_t_u_u(p_13, (safe_lshift_func_int16_t_s_u(g_31, (safe_sub_func_int32_t_s_s((p_13 >= (+((safe_div_func_int32_t_s_s((g_98[0][4][0] = (safe_mod_func_int64_t_s_s((safe_sub_func_int32_t_s_s((***g_438), 0x24DF3140L)), p_13))), 0x1630F6D5L)) <= g_1151[0][0][0]))), p_14)))))))), g_31)) < (**g_1236)))))))) >= g_908), p_13)) | l_1414[2]), p_13)) & g_231);
                        l_1385 = l_1415[0];
                        return l_1417;
                    }
                    if ((*l_1416))
                        continue;
                }
            }
            else
            { /* block id: 685 */
                uint16_t l_1421 = 0xE507L;
                int32_t l_1453 = 4L;
                int32_t l_1456[7][1] = {{(-1L)},{6L},{(-1L)},{6L},{(-1L)},{6L},{(-1L)}};
                int i, j;
                l_1352 = l_1418;
                for (l_1342 = 7; (l_1342 >= 2); l_1342 -= 1)
                { /* block id: 689 */
                    uint32_t l_1432 = 0xA6F9D7C5L;
                    int32_t l_1433 = (-4L);
                    int32_t l_1440 = 0x37BB4623L;
                    int32_t l_1462[1];
                    struct S0 l_1467 = {18446744073709551615UL};
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1462[i] = 0x411ADADDL;
                    for (g_358 = 1; (g_358 <= 7); g_358 += 1)
                    { /* block id: 692 */
                        uint32_t *l_1439[8][7][4] = {{{&l_1358[1][0][6],&g_898,&g_358,&g_358},{&g_1151[0][2][3],&g_358,&g_898,(void*)0},{(void*)0,&g_898,&g_146,&l_1358[4][0][5]},{&g_898,&g_898,&g_1151[0][0][0],&g_1151[0][0][0]},{&g_358,&g_1151[0][0][0],&g_358,&g_898},{&g_1173,&g_358,&g_1173,&l_1358[5][1][5]},{&g_1151[0][0][0],(void*)0,&g_1151[1][0][2],&g_358}},{{(void*)0,(void*)0,&g_1151[1][0][2],&g_146},{&g_1151[0][0][0],&g_358,&g_1173,&l_1358[1][0][6]},{&g_1173,&g_358,&g_358,&l_1358[3][0][1]},{&g_358,&l_1358[3][0][1],&g_1151[0][0][0],&g_146},{&g_898,(void*)0,&g_146,&g_146},{(void*)0,&g_1151[0][0][0],&g_898,&g_1173},{&g_1151[0][2][3],&g_358,&g_358,&g_1151[0][2][3]}},{{&l_1358[1][0][6],&g_1151[1][0][2],&g_1173,&g_1151[0][0][0]},{&l_1358[4][0][5],(void*)0,&g_1151[0][0][0],&l_1358[3][0][1]},{(void*)0,&g_1151[0][2][3],(void*)0,&l_1358[3][0][1]},{&g_358,(void*)0,&g_358,&g_1151[0][0][0]},{&g_898,&g_1151[1][0][2],(void*)0,&g_1151[0][2][3]},{&g_898,&g_358,&g_358,&g_1173},{&g_146,&g_1151[0][0][0],(void*)0,&g_146}},{{&g_358,(void*)0,&g_146,&g_146},{&g_1151[1][0][2],&l_1358[3][0][1],&g_146,&l_1358[3][0][1]},{&g_1151[1][2][1],&g_358,&g_898,&l_1358[1][0][6]},{&l_1358[3][0][1],&g_358,&g_146,&g_146},{&g_146,(void*)0,&l_1358[1][0][6],&g_358},{&g_146,(void*)0,&g_146,&l_1358[5][1][5]},{&l_1358[3][0][1],&g_358,&g_898,&g_898}},{{&g_1151[1][2][1],&g_1151[0][0][0],&g_146,&g_1151[0][0][0]},{&g_1151[1][0][2],&g_898,&g_146,&l_1358[4][0][5]},{&g_358,&g_898,(void*)0,(void*)0},{&g_146,&g_358,&g_358,&g_358},{&g_898,&g_898,(void*)0,(void*)0},{&g_898,&l_1358[5][1][5],&g_358,&g_1151[1][0][2]},{&g_358,&l_1358[4][0][5],(void*)0,&g_358}},{{(void*)0,&l_1358[4][0][5],&g_1151[0][0][0],&g_1151[1][0][2]},{&l_1358[4][0][5],&l_1358[5][1][5],&g_1173,(void*)0},{&l_1358[1][0][6],&g_898,&g_358,&g_358},{&g_1151[0][2][3],&g_358,&g_898,(void*)0},{(void*)0,&g_898,&g_146,&l_1358[4][0][5]},{&g_898,&g_898,&g_1151[0][0][0],&g_1151[0][0][0]},{&g_358,&g_1151[0][0][0],&g_358,&g_898}},{{&g_1173,&g_358,&g_1173,&l_1358[5][1][5]},{&g_1151[0][0][0],(void*)0,&g_1151[1][0][2],&g_358},{(void*)0,(void*)0,&g_146,&g_898},{&g_358,&g_898,&l_1358[3][0][1],(void*)0},{&l_1358[5][1][5],&g_1151[0][2][3],&g_1151[1][2][1],&g_146},{&g_1151[1][2][1],&g_146,&g_1151[1][0][2],&g_358},{&g_1173,&l_1358[1][0][6],&g_358,&g_1151[0][0][0]}},{{&g_146,&g_1151[1][0][2],&g_146,&l_1358[3][0][1]},{(void*)0,&g_898,&g_898,(void*)0},{(void*)0,&g_146,&g_898,&g_898},{&g_1151[0][0][0],(void*)0,&g_358,(void*)0},{&g_1151[0][0][0],(void*)0,(void*)0,(void*)0},{&g_898,(void*)0,&l_1358[4][0][5],&g_898},{&l_1358[3][0][1],&g_146,&l_1358[1][0][6],(void*)0}}};
                        int32_t *l_1441 = &g_100;
                        int32_t *l_1444 = &g_98[2][0][3];
                        int32_t *l_1445 = &l_1433;
                        int32_t *l_1446 = &l_1440;
                        int32_t *l_1447 = (void*)0;
                        int32_t *l_1448 = &g_98[2][4][8];
                        int32_t *l_1449 = &g_100;
                        int32_t *l_1450 = &l_1352;
                        int32_t *l_1451[8][5] = {{&l_1413,&l_1413,&g_31,&l_1352,&l_1440},{&l_1413,&l_1342,&l_1440,(void*)0,&g_98[2][4][5]},{&l_1433,&l_1440,(void*)0,&g_31,&l_1413},{&g_98[1][8][5],&l_1342,&l_1342,&g_98[1][8][5],&g_98[1][5][8]},{&g_98[0][1][8],&l_1413,&l_1342,&l_1440,(void*)0},{&l_1440,&l_1413,(void*)0,&l_1433,&l_1342},{&l_1440,&g_98[0][1][8],&l_1440,&l_1440,&g_98[0][1][8]},{&g_98[2][4][5],(void*)0,&g_31,&g_98[1][8][5],&g_98[0][1][8]}};
                        int i, j, k;
                        (*g_1442) = ((*l_1441) ^= (safe_rshift_func_int16_t_s_s((((l_1421 > (g_20 , ((-1L) | (safe_mul_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s(((g_1173 |= ((p_13 < (safe_add_func_uint8_t_u_u((l_1433 |= (safe_unary_minus_func_uint8_t_u((l_1432 ^= (safe_add_func_int8_t_s_s(g_1128[4], (+0xE3BD3066L))))))), (g_77[0][8][0] > ((safe_add_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(0x0FL, ((*g_438) == (void*)0))), l_1438[0][5][5])) == 0xA7L))))) && 0x475BL)) <= 0x349ED5DEL), l_1421)), 0x9EL))))) && (*g_440)) <= l_1440), l_1440)));
                        (*g_1443) = ((*g_1236) = &l_1342);
                        l_1463--;
                        l_1467 = l_1466;
                    }
                    if (p_14)
                        break;
                }
            }
            for (l_1378 = 2; (l_1378 >= 0); l_1378 -= 1)
            { /* block id: 708 */
                int32_t *l_1474 = &l_1459;
                (*g_1236) = &p_14;
                for (l_1461 = 2; (l_1461 <= 7); l_1461 += 1)
                { /* block id: 712 */
                    int i, j, k;
                    (*l_1474) = (safe_add_func_int32_t_s_s(l_1438[l_1378][l_1461][l_1461], (((g_90[(l_1378 + 2)][l_1378] >= 1L) ^ ((safe_lshift_func_int16_t_s_s(9L, 7)) != ((l_1466 , &l_1413) == ((*g_1236) = l_1474)))) & l_1463)));
                    if ((***g_438))
                        break;
                    l_1475 = &p_14;
                }
            }
            (*l_1475) = (((l_1476 < (((*l_1484) = (((*l_1475) , ((*l_1481) |= (--(*l_1477)))) , ((safe_lshift_func_int8_t_s_s(g_527, 6)) , &g_77[1][4][0]))) != &l_1438[0][5][5])) && (p_13 ^ ((0UL >= (l_1485 == (safe_sub_func_int32_t_s_s(p_14, 2L)))) & l_1488))) <= l_1353);
            (*l_1475) ^= ((*g_1442) |= (l_1489 >= (!l_1352)));
        }
    }
    else
    { /* block id: 726 */
        uint16_t l_1495 = 65535UL;
        l_1352 ^= (safe_lshift_func_int8_t_s_s((safe_add_func_uint64_t_u_u(l_1495, p_12)), p_12));
    }
    for (g_39 = 0; (g_39 <= (-3)); g_39--)
    { /* block id: 731 */
        int16_t **l_1498[2][3][5] = {{{&l_1350[0][3][1],(void*)0,&l_1350[3][2][0],(void*)0,&l_1350[0][3][1]},{&l_1350[0][8][1],&l_1350[3][1][1],&l_1350[0][8][1],&l_1350[0][8][1],&l_1350[3][1][1]},{&l_1350[0][3][1],&l_1350[4][3][1],(void*)0,(void*)0,(void*)0}},{{&l_1350[3][1][1],&l_1350[3][1][1],&l_1350[3][2][0],&l_1350[3][1][1],&l_1350[3][1][1]},{(void*)0,(void*)0,(void*)0,&l_1350[4][3][1],&l_1350[0][3][1]},{&l_1350[3][1][1],&l_1350[0][8][1],&l_1350[0][8][1],&l_1350[3][1][1],&l_1350[0][8][1]}}};
        int8_t *l_1500 = &g_1276;
        uint32_t *l_1526[5];
        int32_t l_1527[2];
        uint16_t l_1528 = 65533UL;
        struct S0 l_1529 = {0UL};
        uint8_t *** const * const l_1538 = &g_1216;
        int32_t *l_1574 = &l_1531;
        int64_t *l_1688[7] = {&g_95,&g_95,&g_95,&g_95,&g_95,&g_95,&g_95};
        uint8_t *****l_1741[9][7][4] = {{{(void*)0,(void*)0,(void*)0,(void*)0},{&l_1740,(void*)0,(void*)0,&l_1740},{(void*)0,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{(void*)0,&l_1740,(void*)0,&l_1740}},{{&l_1740,(void*)0,&l_1740,(void*)0},{&l_1740,(void*)0,(void*)0,&l_1740},{(void*)0,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,&l_1740}},{{&l_1740,(void*)0,&l_1740,(void*)0},{&l_1740,(void*)0,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,(void*)0,(void*)0,&l_1740},{(void*)0,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{(void*)0,&l_1740,&l_1740,&l_1740}},{{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,(void*)0,(void*)0,&l_1740},{&l_1740,(void*)0,&l_1740,&l_1740},{(void*)0,(void*)0,&l_1740,(void*)0}},{{&l_1740,&l_1740,&l_1740,&l_1740},{(void*)0,&l_1740,(void*)0,&l_1740},{&l_1740,(void*)0,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,(void*)0,&l_1740,&l_1740}},{{&l_1740,&l_1740,&l_1740,&l_1740},{(void*)0,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,(void*)0}},{{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,(void*)0,(void*)0,&l_1740},{&l_1740,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{(void*)0,&l_1740,&l_1740,(void*)0},{(void*)0,(void*)0,&l_1740,&l_1740}},{{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,(void*)0,&l_1740,&l_1740},{&l_1740,(void*)0,&l_1740,&l_1740},{&l_1740,(void*)0,&l_1740,&l_1740},{(void*)0,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740}},{{(void*)0,&l_1740,&l_1740,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,&l_1740,(void*)0,(void*)0},{&l_1740,&l_1740,&l_1740,&l_1740},{&l_1740,(void*)0,&l_1740,&l_1740},{(void*)0,(void*)0,&l_1740,&l_1740}}};
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_1526[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_1527[i] = 1L;
        if ((((g_1003[0] = (g_1501 = (((l_1499[1] = (l_1350[1][8][0] = &g_242)) != &g_39) >= (l_1455 = ((*l_1500) = 0x2CL))))) , (safe_rshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_u(((safe_div_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_mul_func_uint8_t_u_u((--(*g_526)), (safe_sub_func_int32_t_s_s(((g_39 | (safe_add_func_int8_t_s_s((((((safe_rshift_func_uint8_t_u_u((((**g_1193) < (safe_div_func_int64_t_s_s(p_14, 0x6D2A87A66CD6F0CDLL))) , (((l_1455 = (safe_add_func_int64_t_s_s(((safe_lshift_func_int8_t_s_s(((l_1352 = g_1060) ^ l_1527[1]), p_13)) , l_1527[1]), l_1528))) , l_1529) , 0xFDL)), 5)) || 254UL) == l_1528) , l_1530[0]) , 0xBEL), p_13))) > 0x5C785312L), l_1530[0].f0)))), 4294967295UL)), l_1531)) | g_1151[0][0][0]), 14)), 8))) , p_14))
        { /* block id: 741 */
            int32_t *l_1532 = &l_1531;
            uint8_t **l_1629 = &g_526;
            uint8_t *** const l_1628[1] = {&l_1629};
            const struct S0 l_1635 = {0UL};
            int32_t l_1669 = 0xC7309691L;
            int i;
            for (g_31 = 1; (g_31 >= 0); g_31 -= 1)
            { /* block id: 744 */
                struct S0 l_1564 = {18446744073709551609UL};
                int32_t *l_1575 = &l_1455;
                int32_t l_1589[10];
                int64_t l_1600 = 0L;
                int32_t l_1607 = (-1L);
                int i;
                for (i = 0; i < 10; i++)
                    l_1589[i] = 1L;
                for (g_527 = 0; (g_527 <= 0); g_527 += 1)
                { /* block id: 747 */
                    int32_t *l_1547 = &g_1128[1];
                    uint64_t **l_1570 = &l_1333;
                    int32_t l_1571[1];
                    uint16_t *l_1598 = &g_90[2][4];
                    uint64_t *l_1599[7][10] = {{&g_131.f0,(void*)0,&l_1529.f0,&l_1529.f0,(void*)0,&l_1529.f0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0},{&l_1530[0].f0,&l_1529.f0,&g_131.f0,(void*)0,&g_1003[0],(void*)0,&g_131.f0,&l_1529.f0,&l_1530[0].f0,(void*)0}};
                    int64_t *l_1601 = (void*)0;
                    int64_t *l_1602 = (void*)0;
                    int64_t *l_1603[7][6] = {{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95},{&g_95,(void*)0,&l_1600,(void*)0,&g_95,&g_95}};
                    uint8_t l_1608 = 255UL;
                    uint8_t **l_1627 = (void*)0;
                    uint8_t ***l_1626 = &l_1627;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_1571[i] = (-4L);
                    for (l_1352 = 0; (l_1352 >= 0); l_1352 -= 1)
                    { /* block id: 750 */
                        uint16_t ***l_1542 = (void*)0;
                        int32_t l_1543 = 0x5E9A1173L;
                        (*g_1236) = func_58(func_58(l_1532, l_1476, &p_14), (safe_mul_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u((safe_mul_func_uint16_t_u_u(((void*)0 != l_1538), (~(safe_lshift_func_int8_t_s_u(((*l_1500) = ((g_1173 = p_12) & (((0xDA5EDE945F732A65LL > ((((l_1542 != &g_1193) == 1UL) > p_14) & p_13)) , g_231) | l_1531))), p_14))))))), p_13)), l_1532);
                        l_1544[1]--;
                    }
                    if ((l_1547 == (void*)0))
                    { /* block id: 756 */
                        int32_t *l_1548 = &l_1352;
                        int32_t *l_1549 = &l_1457[1][5];
                        int32_t *l_1550 = (void*)0;
                        int32_t *l_1551 = &l_1527[1];
                        int32_t *l_1552 = &l_1342;
                        int32_t *l_1553 = &l_1452;
                        int32_t *l_1554[9];
                        int i;
                        for (i = 0; i < 9; i++)
                            l_1554[i] = &l_1457[1][4];
                        (*g_1236) = &p_14;
                        (**g_1236) = 2L;
                        g_1555++;
                    }
                    else
                    { /* block id: 760 */
                        (*l_1532) = (((safe_add_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u((p_14 , ((safe_lshift_func_uint8_t_u_u(l_1529.f0, 2)) & ((((g_1080 , l_1564) , (p_13 = 4294967286UL)) != (safe_rshift_func_uint16_t_u_u(0x97D9L, 0))) && g_126))), 0)), 0x6456DC0EL)) & (g_1567 != l_1570)) || l_1571[0]);
                        l_1572 = p_14;
                    }
                    for (l_1452 = 0; (l_1452 <= 1); l_1452 += 1)
                    { /* block id: 767 */
                        int32_t *l_1573 = &l_1527[1];
                        return g_1576;
                    }
                }
                for (g_146 = 0; (g_146 <= 1); g_146 += 1)
                { /* block id: 796 */
                    uint64_t *l_1668[7][10][3] = {{{&g_1658.f0,&g_1003[5],&g_1003[0]},{&g_357[1][0],&g_357[1][0],&g_357[1][0]},{&g_1003[0],&g_1658.f0,&g_1658.f0},{&g_357[1][0],&g_357[1][0],&g_1003[7]},{&g_1003[0],&g_1003[0],&l_1485},{&g_357[1][0],&g_357[1][0],(void*)0},{&g_1658.f0,&g_1003[0],&g_1658.f0},{&g_357[1][0],&g_357[1][0],(void*)0},{&g_1003[5],&g_1658.f0,&g_1658.f0},{(void*)0,&g_357[1][0],(void*)0}},{{&g_1003[0],&g_1003[5],&l_1485},{(void*)0,(void*)0,&g_1003[7]},{&g_1003[5],&g_1003[0],&g_1658.f0},{&g_357[1][0],(void*)0,&g_357[1][0]},{&g_1658.f0,&g_1003[5],&g_1003[0]},{&g_357[1][0],&g_357[1][0],&g_357[1][0]},{&g_1003[0],&g_1658.f0,&g_1658.f0},{&g_357[1][0],&g_357[1][0],&g_1003[7]},{&g_1003[0],&g_1003[0],&l_1485},{&g_357[1][0],&g_357[1][0],(void*)0}},{{&g_1658.f0,&g_1003[0],&g_1658.f0},{&g_357[1][0],&g_357[1][0],(void*)0},{&g_1003[5],&g_1658.f0,&g_1658.f0},{(void*)0,&g_357[1][0],(void*)0},{&g_1003[0],&g_1003[5],&l_1485},{(void*)0,(void*)0,&g_1003[7]},{&g_1003[5],&g_1003[0],&g_1658.f0},{&g_357[1][0],(void*)0,&g_357[1][0]},{&g_1003[0],&g_1658.f0,&g_1003[1]},{&g_357[1][0],&g_357[1][0],&g_357[1][0]}},{{&g_1003[1],&g_1003[0],&l_1485},{(void*)0,&g_357[1][0],(void*)0},{&g_1003[1],&g_1003[1],&g_1003[0]},{&g_357[1][0],(void*)0,&g_1003[7]},{&g_1003[0],&g_1003[1],&g_1003[0]},{&g_357[1][0],&g_357[1][0],&g_357[0][0]},{&g_1658.f0,&g_1003[0],&g_1003[0]},{&g_357[0][0],&g_357[1][0],&g_1003[7]},{&g_1658.f0,&g_1658.f0,&g_1003[0]},{&g_357[0][0],&g_357[0][0],(void*)0}},{{&g_1658.f0,&g_1658.f0,&l_1485},{&g_357[1][0],&g_357[0][0],&g_357[1][0]},{&g_1003[0],&g_1658.f0,&g_1003[1]},{&g_357[1][0],&g_357[1][0],&g_357[1][0]},{&g_1003[1],&g_1003[0],&l_1485},{(void*)0,&g_357[1][0],(void*)0},{&g_1003[1],&g_1003[1],&g_1003[0]},{&g_357[1][0],(void*)0,&g_1003[7]},{&g_1003[0],&g_1003[1],&g_1003[0]},{&g_357[1][0],&g_357[1][0],&g_357[0][0]}},{{&g_1658.f0,&g_1003[0],&g_1003[0]},{&g_357[0][0],&g_357[1][0],&g_1003[7]},{&g_1658.f0,&g_1658.f0,&g_1003[0]},{&g_357[0][0],&g_357[0][0],(void*)0},{&g_1658.f0,&g_1658.f0,&l_1485},{&g_357[1][0],&g_357[0][0],&g_357[1][0]},{&g_1003[0],&g_1658.f0,&g_1003[1]},{&g_357[1][0],&g_357[1][0],&g_357[1][0]},{&g_1003[1],&g_1003[0],&l_1485},{(void*)0,&g_357[1][0],(void*)0}},{{&g_1003[1],&g_1003[1],&g_1003[0]},{&g_357[1][0],(void*)0,&g_1003[7]},{&g_1003[0],&g_1003[1],&g_1003[0]},{&g_357[1][0],&g_357[1][0],&g_357[0][0]},{&g_1658.f0,&g_1003[0],&g_1003[0]},{&g_357[0][0],&g_357[1][0],&g_1003[7]},{&g_1658.f0,&g_1658.f0,&g_1003[0]},{&g_357[0][0],&g_357[0][0],(void*)0},{&g_1658.f0,&g_1658.f0,&l_1485},{&g_357[1][0],&g_357[0][0],&g_357[1][0]}}};
                    int32_t l_1676 = 0xBB0965BEL;
                    int i, j, k;
                    (*l_1532) = ((safe_div_func_uint32_t_u_u((0xAD5BL || 0xC692L), (-3L))) != (safe_add_func_int8_t_s_s((((*l_1575) |= (safe_mul_func_int8_t_s_s((((l_1669 = (&g_894[2] != (((*l_1500) |= (l_1350[(g_31 + 3)][(g_146 + 3)][g_146] != (void*)0)) , l_1667))) >= 0x070F03FAFA154DB0LL) >= ((--g_357[1][0]) ^ (((((safe_rshift_func_uint8_t_u_u((((*l_1341)--) <= (4294967295UL <= p_12)), p_12)) > l_1353) || p_14) | 18446744073709551615UL) ^ l_1676))), p_12))) > p_13), g_1555)));
                }
            }
            if (p_14)
                break;
        }
        else
        { /* block id: 806 */
            int32_t *l_1677 = &l_1455;
            int32_t *l_1682 = &l_1527[1];
            int32_t *l_1685 = &g_98[2][2][2];
            uint64_t l_1696 = 0xDF474F706B37E1EFLL;
            struct S0 *l_1707[7][4] = {{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131},{&g_131,&g_131,&g_131,&g_131}};
            int8_t *l_1728 = &l_1716;
            const struct S0 *l_1734 = &l_1345;
            const struct S0 **l_1733 = &l_1734;
            int i, j;
            for (l_1531 = 4; (l_1531 >= 0); l_1531 -= 1)
            { /* block id: 809 */
                int32_t *l_1679 = &l_1457[2][0];
                int32_t l_1691 = 0xCC16D14EL;
                int32_t l_1692 = 0xDD006C82L;
                struct S0 l_1699[3] = {{18446744073709551606UL},{18446744073709551606UL},{18446744073709551606UL}};
                int i;
                (*g_1576) = 0xD29BEF6EL;
                for (g_1189 = 1; (g_1189 <= 4); g_1189 += 1)
                { /* block id: 813 */
                    int i;
                    (*g_1576) ^= g_1003[g_1189];
                }
                for (g_1060 = 0; (g_1060 <= 4); g_1060 += 1)
                { /* block id: 818 */
                    int32_t *l_1680[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint8_t l_1693 = 0x38L;
                    struct S0 l_1700 = {0xFB92016A64304F6BLL};
                    int i;
                    for (p_12 = 1; (p_12 <= 4); p_12 += 1)
                    { /* block id: 821 */
                        int32_t *l_1678 = &l_1454;
                        int32_t *l_1684 = &l_1352;
                        return l_1685;
                    }
                    for (g_1658.f0 = 0; (g_1658.f0 <= 8); g_1658.f0 += 1)
                    { /* block id: 826 */
                        int64_t **l_1689[10] = {&g_894[1],&l_1688[4],&l_1688[4],&l_1688[4],&l_1688[4],&g_894[1],&l_1688[4],&l_1688[4],&l_1688[4],&l_1688[4]};
                        int i;
                        (*l_1679) &= ((safe_add_func_int16_t_s_s(g_1003[(g_1060 + 4)], (g_1003[(g_1060 + 4)] || g_441))) & g_971[0]);
                        (*l_1683) ^= ((*l_1667) == (l_1690 = l_1688[4]));
                        l_1693++;
                    }
                    for (g_100 = 0; (g_100 <= 4); g_100 += 1)
                    { /* block id: 834 */
                        uint32_t l_1702 = 4294967295UL;
                        uint64_t *l_1706 = &l_1530[0].f0;
                        l_1696++;
                        l_1530[0] = l_1699[2];
                        (*g_1701) = l_1700;
                        l_1714 = ((l_1702 , ((g_888 & (!(-3L))) , (((safe_sub_func_int64_t_s_s(1L, (((*l_1706) = (*g_1568)) <= ((((void*)0 == l_1707[2][1]) | (1UL > (((safe_add_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(((((*g_526) ^= ((((safe_sub_func_int8_t_s_s(p_13, p_13)) || g_358) && g_1658.f0) == p_14)) == l_1702) >= g_971[0]), 0UL)), 0L)) , g_1057) ^ 18446744073709551615UL))) | p_13)))) ^ (*l_1679)) <= p_14))) , l_1700);
                    }
                    for (g_95 = 1; (g_95 >= 0); g_95 -= 1)
                    { /* block id: 844 */
                        if (l_1696)
                            goto lbl_1715;
                    }
                }
            }
            if (l_1716)
                break;
            (*g_1576) = ((safe_add_func_uint16_t_u_u((*g_1194), (g_1276 ^ (safe_rshift_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_s((((((*l_1682) ^= (safe_mul_func_int8_t_s_s(((*l_1728) = (!(*l_1683))), 0xCEL))) >= ((((safe_sub_func_int8_t_s_s(((l_1529 , (safe_div_func_uint8_t_u_u((&l_1530[0] != ((*l_1733) = (void*)0)), (safe_add_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(((*l_1574) < ((((l_1530[1] , p_12) >= 0x86B5B406L) <= (*l_1574)) , p_14)), 15)), p_12))))) != p_13), p_13)) && 0x50L) > g_90[3][5]) & 246UL)) | 0UL) || g_1658.f0), 9)) ^ (*l_1574)) || p_13), 1))))) != 0xADL);
        }
        (*l_1683) |= ((l_1739 = &g_1216) != (g_1744 = (g_1743 = (g_1742 = l_1740))));
    }
    if (g_1189)
        goto lbl_1715;
    return g_1746;
}


/* ------------------------------------------ */
/* 
 * reads : g_126 g_392 g_357 g_146 g_90 g_31 g_52.f0 g_358 g_526 g_98 g_100 g_93 g_242 g_30 g_685 g_527 g_77 g_95 g_52 g_558 g_39 g_448 g_438 g_439 g_362 g_361 g_686 g_908 g_898 g_971 g_888 g_231 g_131.f0 g_1003 g_1080 g_1128 g_1189 g_1193 g_1194
 * writes: g_126 g_358 g_527 g_93 g_31 g_242 g_448 g_362 g_131.f0 g_98 g_30 g_685 g_90 g_100 g_77 g_131 g_231 g_95 g_39 g_357 g_146 g_52 g_754 g_686 g_439 g_1003 g_1078
 */
static uint8_t  func_25(struct S0  p_26, int32_t * p_27, int32_t * p_28)
{ /* block id: 297 */
    uint32_t *l_592 = &g_126;
    int32_t l_597 = 0xFF17826CL;
    uint32_t *l_609 = &g_358;
    int8_t l_627 = (-1L);
    const uint32_t l_629 = 0x64A09435L;
    int32_t l_644[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int8_t l_645 = (-7L);
    uint32_t l_651 = 0x371DE1F6L;
    int32_t *l_737 = (void*)0;
    struct S0 ***l_751 = &g_686;
    uint16_t *l_757 = &g_90[3][3];
    uint16_t **l_756 = &l_757;
    int64_t l_769 = (-9L);
    int32_t l_828[1];
    int32_t l_973[3];
    uint8_t l_1002 = 0x89L;
    int32_t **l_1019 = &g_30;
    int32_t ** const *l_1018[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t **l_1027[3];
    uint64_t *l_1030 = &g_1003[6];
    uint64_t **l_1029 = &l_1030;
    int64_t l_1058[4][9][3] = {{{0x9121A41472786504LL,0xFA80788615A415F7LL,0x778F80E279A4DEB3LL},{0xE7879AACE0A1D289LL,0L,(-8L)},{0xA97CBB2A66B70E3BLL,0x1C9C90B51CBAA521LL,0x778F80E279A4DEB3LL},{0L,0xAA6C41A55B2D3CFELL,0x71C4329DC392C4B2LL},{4L,0xAA6C41A55B2D3CFELL,(-7L)},{0x65A8961428C8F24FLL,0x1C9C90B51CBAA521LL,0x5EB2F32EC811B8C1LL},{0x01121BD5DD4C2A69LL,0L,0L},{0x65A8961428C8F24FLL,0xFA80788615A415F7LL,1L},{4L,(-8L),1L}},{{0L,1L,0L},{0xA97CBB2A66B70E3BLL,(-7L),0x5EB2F32EC811B8C1LL},{0xE7879AACE0A1D289LL,1L,(-7L)},{0xF0A7AED637493176LL,(-8L),0x71C4329DC392C4B2LL},{0xF0A7AED637493176LL,0xFA80788615A415F7LL,0x778F80E279A4DEB3LL},{0xE7879AACE0A1D289LL,0L,(-8L)},{0xA97CBB2A66B70E3BLL,0x1C9C90B51CBAA521LL,0x778F80E279A4DEB3LL},{0L,0xAA6C41A55B2D3CFELL,0x71C4329DC392C4B2LL},{4L,0xAA6C41A55B2D3CFELL,(-7L)}},{{0x65A8961428C8F24FLL,0x1C9C90B51CBAA521LL,0x5EB2F32EC811B8C1LL},{0x01121BD5DD4C2A69LL,0L,0L},{0x65A8961428C8F24FLL,0xFA80788615A415F7LL,1L},{4L,(-8L),1L},{0L,1L,0L},{0xA97CBB2A66B70E3BLL,(-7L),0x5EB2F32EC811B8C1LL},{0xE7879AACE0A1D289LL,1L,(-7L)},{0xF0A7AED637493176LL,(-8L),0x71C4329DC392C4B2LL},{0xF0A7AED637493176LL,0xFA80788615A415F7LL,0x778F80E279A4DEB3LL}},{{0xE7879AACE0A1D289LL,0L,(-8L)},{0xA97CBB2A66B70E3BLL,0x1C9C90B51CBAA521LL,0x778F80E279A4DEB3LL},{0L,0xAA6C41A55B2D3CFELL,0x71C4329DC392C4B2LL},{4L,0xAA6C41A55B2D3CFELL,(-7L)},{0x65A8961428C8F24FLL,0x1C9C90B51CBAA521LL,0x5EB2F32EC811B8C1LL},{0x01121BD5DD4C2A69LL,0L,0L},{0x65A8961428C8F24FLL,0xFA80788615A415F7LL,1L},{4L,(-8L),1L},{0L,1L,0L}}};
    const int32_t *l_1076 = &l_828[0];
    const int32_t **l_1075 = &l_1076;
    uint64_t l_1152 = 18446744073709551612UL;
    uint8_t **l_1215[9] = {&g_526,(void*)0,(void*)0,&g_526,(void*)0,(void*)0,&g_526,(void*)0,(void*)0};
    uint8_t *** const l_1214 = &l_1215[8];
    int32_t l_1231 = 0xEA1B221EL;
    const uint16_t l_1312[4][6][9] = {{{0xF079L,0xF079L,0x2C08L,0xCF45L,0x7D67L,0x5C27L,0x3749L,0x5C27L,0x7D67L},{0x2C08L,0xF079L,0xF079L,0x2C08L,0xCF45L,0x7D67L,0x5C27L,0x3749L,0x5C27L},{0x3749L,65529UL,0x2C08L,0x2C08L,65529UL,0x3749L,0xBC4AL,0xF079L,6UL},{0xB353L,0x7D67L,0x3749L,0xCF45L,0xCF45L,0x3749L,0x7D67L,0xB353L,65529UL},{6UL,0x2C08L,0xB353L,0xBC4AL,0x7D67L,0x7D67L,0xBC4AL,0xB353L,0x2C08L},{0xCF45L,0xB353L,6UL,65529UL,0xF079L,0x5C27L,0x5C27L,0xF079L,65529UL}},{{0xCF45L,0x3D19L,0xCF45L,0x5C27L,0xBC4AL,6UL,0x3749L,0x3749L,6UL},{6UL,0xB353L,0xCF45L,0xB353L,6UL,65529UL,0xF079L,0x5C27L,0x5C27L},{0xB353L,0x2C08L,0x3749L,0xB353L,0x3749L,0xF079L,0x3D19L,0x7D67L,6UL},{0xCF45L,6UL,0x3D19L,0x2C08L,0x7D67L,0x2C08L,0x3D19L,6UL,0xCF45L},{0xF079L,0x2C08L,0xCF45L,0x7D67L,0x5C27L,0x3749L,0x5C27L,0x7D67L,0xCF45L},{0x5C27L,0x5C27L,0xF079L,65529UL,6UL,0xB353L,0xCF45L,0xB353L,6UL}},{{0xF079L,0x5C27L,0x5C27L,0xF079L,65529UL,6UL,0xB353L,0xCF45L,0xB353L},{0xCF45L,0x2C08L,0xF079L,0xF079L,0x2C08L,0xCF45L,0x7D67L,0x5C27L,0x3749L},{0x3D19L,6UL,0xCF45L,65529UL,65529UL,0xCF45L,6UL,0x3D19L,0x2C08L},{0x3749L,0xF079L,0x3D19L,0x7D67L,6UL,6UL,0x7D67L,0x3D19L,0xF079L},{65529UL,0x3D19L,0x3749L,0x2C08L,0x5C27L,0xB353L,0xB353L,0x5C27L,0x2C08L},{65529UL,0xBC4AL,65529UL,0xB353L,0x7D67L,0x3749L,0xCF45L,0xCF45L,0x3749L}},{{0x3749L,0x3D19L,65529UL,0x3D19L,0x3749L,0x2C08L,0x5C27L,0xB353L,0xB353L},{0x3D19L,0xF079L,0x3749L,0xB353L,0x3749L,0xF079L,0x3D19L,0x7D67L,6UL},{0xCF45L,6UL,0x3D19L,0x2C08L,0x7D67L,0x2C08L,0x3D19L,6UL,0xCF45L},{0xF079L,0x2C08L,0xCF45L,0x7D67L,0x5C27L,0x3749L,0x5C27L,0x7D67L,0xCF45L},{0x5C27L,0x5C27L,0xF079L,65529UL,6UL,0xB353L,0xCF45L,0xB353L,6UL},{0xF079L,0x5C27L,0x5C27L,0xF079L,65529UL,6UL,0xB353L,0xCF45L,0xB353L}}};
    int32_t l_1323[4][2][6] = {{{0x82BF7121L,0x4B463C55L,(-1L),1L,1L,0x420DC353L},{0L,1L,1L,(-4L),1L,1L}},{{(-4L),1L,1L,0L,(-9L),0xFC37F366L},{1L,(-1L),0x4B463C55L,0x82BF7121L,(-6L),0x09F1CC00L}},{{(-6L),(-1L),0x1DCECFD5L,0x4B463C55L,(-9L),0xCDCC233DL},{0x707534FEL,1L,1L,1L,1L,0x707534FEL}},{{0xFC37F366L,1L,0x82BF7121L,0xCDCC233DL,1L,0L},{3L,0x4B463C55L,0x5AFAA30AL,0x420DC353L,6L,0x1DCECFD5L}}};
    int16_t *l_1324 = &g_77[1][0][0];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_828[i] = (-5L);
    for (i = 0; i < 3; i++)
        l_973[i] = 0x28E6707EL;
    for (i = 0; i < 3; i++)
        l_1027[i] = &g_894[0];
    if (((safe_add_func_uint32_t_u_u((++(*l_592)), (((safe_rshift_func_uint16_t_u_u(0xC1C2L, l_597)) != ((*l_609) = ((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_add_func_int16_t_s_s((safe_sub_func_int8_t_s_s((1UL <= (-1L)), ((l_597 >= 1UL) | (safe_unary_minus_func_uint16_t_u(l_597))))), (safe_add_func_int64_t_s_s(l_597, 1L)))), 6)) , 65535UL), l_597)) <= g_392))) <= 0x73L))) >= g_357[1][0]))
    { /* block id: 300 */
        int32_t l_624 = 0xA1193F9AL;
        const int32_t l_628 = 0xE840A28BL;
        int64_t *l_630 = &g_93;
        int32_t l_639 = 1L;
        int32_t l_641 = 0x6509BFC2L;
        int32_t l_642 = 0xD5A5D858L;
        int32_t l_643 = 0x367171BFL;
        int32_t l_646 = 0x68BF88FFL;
        int32_t l_647 = 0xFE9231CEL;
        int32_t l_648 = 0x1E15A990L;
        int32_t l_649 = 0x87D9E625L;
        int32_t l_650[3];
        const uint32_t l_719 = 4294967294UL;
        int16_t l_720 = 0L;
        uint32_t l_730[8] = {0x64FCA648L,0x64FCA648L,0x64FCA648L,0x64FCA648L,0x64FCA648L,0x64FCA648L,0x64FCA648L,0x64FCA648L};
        int32_t **l_733 = (void*)0;
        int32_t *l_735[1][1];
        int32_t **l_734 = &l_735[0][0];
        int32_t **l_736[5][10][5] = {{{&g_30,&g_448,&g_30,&g_30,&g_448},{&g_448,&g_448,&g_448,(void*)0,&g_448},{(void*)0,&g_448,&g_30,&g_448,(void*)0},{(void*)0,&g_30,&g_448,(void*)0,&g_30},{&g_448,&g_448,&g_30,&g_448,&g_30},{&g_448,&g_448,(void*)0,&g_30,&g_30},{&g_30,&g_448,&g_448,&g_30,(void*)0},{&g_30,&g_448,&g_30,&g_448,&g_448},{&g_30,(void*)0,(void*)0,&g_448,&g_448},{&g_448,&g_448,(void*)0,&g_448,&g_30}},{{&g_448,(void*)0,&g_30,&g_30,(void*)0},{&g_30,&g_448,&g_448,&g_30,&g_448},{&g_448,&g_30,(void*)0,(void*)0,&g_30},{&g_30,&g_448,&g_30,&g_30,&g_448},{&g_448,&g_448,&g_448,&g_30,&g_448},{&g_30,&g_448,&g_30,&g_448,&g_448},{&g_448,&g_448,&g_448,&g_30,(void*)0},{&g_448,&g_448,&g_30,&g_30,&g_448},{&g_30,&g_30,&g_448,&g_448,&g_448},{&g_30,&g_30,&g_30,&g_30,&g_448}},{{&g_30,&g_448,&g_448,&g_30,&g_30},{&g_448,&g_448,&g_448,(void*)0,(void*)0},{&g_448,&g_448,&g_30,&g_30,&g_30},{(void*)0,&g_30,&g_448,&g_30,&g_448},{(void*)0,&g_30,&g_448,&g_448,&g_30},{&g_448,&g_448,&g_448,&g_448,&g_30},{&g_30,&g_448,(void*)0,&g_448,&g_448},{&g_448,&g_448,&g_448,&g_30,&g_30},{&g_30,&g_448,&g_448,&g_30,(void*)0},{&g_448,&g_448,&g_30,&g_448,&g_30}},{{&g_448,&g_30,&g_448,(void*)0,&g_448},{(void*)0,&g_448,&g_448,&g_448,&g_448},{&g_448,(void*)0,(void*)0,(void*)0,&g_448},{&g_30,&g_448,&g_448,&g_30,(void*)0},{&g_30,(void*)0,&g_448,&g_30,&g_448},{&g_448,&g_448,&g_448,&g_448,&g_448},{(void*)0,&g_448,&g_30,(void*)0,&g_448},{&g_448,&g_448,&g_30,(void*)0,&g_448},{&g_30,&g_448,(void*)0,&g_448,&g_448},{(void*)0,&g_30,(void*)0,&g_448,&g_448}},{{&g_448,&g_448,&g_30,&g_448,&g_448},{(void*)0,&g_448,(void*)0,&g_448,&g_30},{&g_30,&g_448,&g_448,&g_448,(void*)0},{&g_30,&g_448,&g_448,&g_448,&g_30},{&g_30,&g_30,&g_30,&g_30,&g_30},{&g_448,&g_448,&g_448,&g_448,&g_30},{&g_448,&g_448,&g_448,&g_30,&g_30},{(void*)0,&g_448,&g_448,&g_448,&g_30},{&g_30,&g_448,(void*)0,(void*)0,(void*)0},{&g_30,&g_30,&g_30,&g_30,&g_30}}};
        int64_t l_752 = (-3L);
        uint16_t l_753[2][5][1] = {{{0x9467L},{0x80FFL},{0x9467L},{0x80FFL},{0x9467L}},{{0x80FFL},{0x9467L},{0x80FFL},{0x9467L},{0x80FFL}}};
        int64_t l_755 = 0xEF0AAC5208E71D48LL;
        int16_t l_790[10];
        int64_t l_791 = 0xF1815728B15F04E5LL;
        uint64_t l_792 = 3UL;
        uint16_t *** const l_827 = &l_756;
        uint32_t l_836 = 1UL;
        const struct S0 l_874 = {18446744073709551615UL};
        struct S0 *l_905 = (void*)0;
        const struct S0 ** const *l_920 = (void*)0;
        uint64_t l_974 = 0x909B0D0533DF0C2ELL;
        const struct S0 *l_977 = (void*)0;
        int32_t *l_1023[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t ** const l_1022 = &l_1023[6];
        int32_t ** const *l_1021 = &l_1022;
        uint64_t l_1028 = 18446744073709551615UL;
        const uint32_t l_1090 = 0x9DED64D2L;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_650[i] = 0xC5EA455DL;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
                l_735[i][j] = &g_392;
        }
        for (i = 0; i < 10; i++)
            l_790[i] = 4L;
        if ((safe_rshift_func_uint8_t_u_u(((safe_div_func_int8_t_s_s((1L <= (g_146 & g_90[3][5])), (safe_rshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((((*l_630) = (safe_mod_func_int16_t_s_s(p_26.f0, (((*p_27) , (((l_597 != ((safe_sub_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s((((l_624 = ((*g_526) = (p_26.f0 && ((l_624 && ((((*l_609) |= (safe_mul_func_int8_t_s_s(g_52.f0, l_627))) && l_624) < l_624)) & l_624)))) | l_628) != 0x039BL), g_146)) , l_629), p_26.f0)) | g_98[1][5][8])) < p_26.f0) > l_597)) || l_624)))) , p_26.f0), 2)), 7)))) > p_26.f0), 5)))
        { /* block id: 305 */
            int32_t *l_638[2];
            int32_t l_640 = 0x38FD4D83L;
            int i;
            for (i = 0; i < 2; i++)
                l_638[i] = &l_597;
lbl_666:
            (*p_27) |= ((((safe_unary_minus_func_int8_t_s((safe_div_func_uint16_t_u_u(((g_100 || (((safe_sub_func_int64_t_s_s(((*l_630) ^= 0x45542368615FF5E0LL), ((((void*)0 != &p_28) > l_629) < g_98[1][5][8]))) != (safe_add_func_int64_t_s_s(p_26.f0, (p_26.f0 < 0xFC0179DA47F2A0D9LL)))) <= 0L)) <= g_392), p_26.f0)))) , 2L) , 0x64C7L) && 0L);
            l_651--;
            for (g_242 = 1; (g_242 >= 0); g_242 -= 1)
            { /* block id: 311 */
                struct S0 *l_655 = &g_52;
                struct S0 **l_656 = &g_362;
                int32_t l_661 = (-1L);
                int i;
                for (g_93 = 1; (g_93 >= 0); g_93 -= 1)
                { /* block id: 314 */
                    int32_t **l_654 = &g_448;
                    int i;
                    (*l_654) = l_638[g_93];
                }
                (*l_656) = l_655;
                if ((*p_28))
                    break;
                for (g_131.f0 = 0; (g_131.f0 < 10); g_131.f0 = safe_add_func_int32_t_s_s(g_131.f0, 3))
                { /* block id: 321 */
                    (*p_28) = ((*p_27) ^= 0xB795AB01L);
                    for (l_648 = 0; (l_648 > (-20)); l_648--)
                    { /* block id: 326 */
                        uint64_t l_662 = 0x86FDEF459B2C12CDLL;
                        int32_t **l_665 = &g_30;
                        g_30 = p_27;
                        ++l_662;
                        (*l_665) = &g_98[1][5][8];
                    }
                }
            }
            if (g_93)
                goto lbl_666;
        }
        else
        { /* block id: 334 */
            struct S0 **l_670 = &g_362;
            struct S0 ***l_669 = &l_670;
            int32_t *l_683 = &l_650[0];
            uint64_t *l_714 = &g_52.f0;
            int32_t *l_721 = &l_650[1];
            int32_t *l_722 = &l_649;
            int32_t *l_723 = (void*)0;
            int32_t *l_724 = &l_644[5];
            int32_t *l_725 = &l_649;
            int32_t *l_726 = &l_646;
            int32_t *l_727 = &l_650[2];
            int32_t *l_728 = &l_641;
            int32_t *l_729[10] = {&l_647,&l_644[0],&l_644[0],&l_647,&l_646,&l_647,&l_644[0],&l_644[0],&l_647,&l_646};
            int i;
            l_650[0] = (((p_26.f0 , l_628) && 0x476055A26245D39CLL) , ((*p_28) ^= (safe_rshift_func_uint8_t_u_s((l_669 != &g_361), (((p_26.f0 ^ (safe_div_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(((+(safe_rshift_func_uint8_t_u_s(l_641, 7))) && ((void*)0 != &p_26)), 7)), g_358))) || 1L) != (*p_27))))));
            for (l_643 = 0; (l_643 < 3); l_643++)
            { /* block id: 339 */
                int32_t *l_689 = &l_644[2];
                for (g_358 = 0; (g_358 <= 0); g_358 += 1)
                { /* block id: 342 */
                    uint64_t l_680 = 0x1436D8FDF6ACE317LL;
                    struct S0 ****l_687 = &g_685[0][2][1];
                    struct S0 ****l_688 = &l_669;
                    if ((*g_30))
                    { /* block id: 343 */
                        l_680++;
                        l_683 = p_27;
                    }
                    else
                    { /* block id: 346 */
                        uint16_t l_684[7][3][9] = {{{65535UL,65535UL,65535UL,0xF239L,0x754FL,0xF239L,65535UL,65535UL,65535UL},{0xD31EL,0x2B79L,65535UL,0xF239L,65535UL,0x2B79L,0xD31EL,0xD31EL,0x2B79L},{0xF239L,0x2B79L,65535UL,0x2B79L,0xF239L,9UL,9UL,0xF239L,0x2B79L}},{{0xD31EL,65535UL,0xD31EL,9UL,65535UL,65535UL,9UL,0xD31EL,65535UL},{65535UL,0xD31EL,9UL,65535UL,65535UL,9UL,0xD31EL,65535UL,0xD31EL},{0x2B79L,0xF239L,9UL,9UL,0xF239L,0x2B79L,65535UL,0x2B79L,0xF239L}},{{0x2B79L,0xD31EL,0xD31EL,0x2B79L,65535UL,0xF239L,65535UL,0x2B79L,0xD31EL},{65535UL,65535UL,65535UL,0xF239L,0x754FL,0xF239L,65535UL,65535UL,65535UL},{0xD31EL,0x2B79L,65535UL,0xF239L,65535UL,0x2B79L,0xD31EL,0xD31EL,0x2B79L}},{{0xF239L,0x2B79L,65535UL,0x2B79L,0xF239L,9UL,9UL,0xF239L,0x2B79L},{0xD31EL,65535UL,0xD31EL,9UL,65535UL,65535UL,65535UL,0xF239L,0x754FL},{0x754FL,0xF239L,65535UL,65535UL,65535UL,65535UL,0xF239L,0x754FL,0xF239L}},{{0xD31EL,9UL,65535UL,65535UL,9UL,0xD31EL,65535UL,0xD31EL,9UL},{0xD31EL,0xF239L,0xF239L,0xD31EL,0x754FL,9UL,0x754FL,0xD31EL,0xF239L},{0x754FL,0x754FL,65535UL,9UL,0x2B79L,9UL,65535UL,0x754FL,0x754FL}},{{0xF239L,0xD31EL,0x754FL,9UL,0x754FL,0xD31EL,0xF239L,0xF239L,0xD31EL},{9UL,0xD31EL,65535UL,0xD31EL,9UL,65535UL,65535UL,9UL,0xD31EL},{0xF239L,0x754FL,0xF239L,65535UL,65535UL,65535UL,65535UL,0xF239L,0x754FL}},{{0x754FL,0xF239L,65535UL,65535UL,65535UL,65535UL,0xF239L,0x754FL,0xF239L},{0xD31EL,9UL,65535UL,65535UL,9UL,0xD31EL,65535UL,0xD31EL,9UL},{0xD31EL,0xF239L,0xF239L,0xD31EL,0x754FL,9UL,0x754FL,0xD31EL,0xF239L}}};
                        int i, j, k;
                        if (l_684[4][2][4])
                            break;
                    }
                    (*p_28) = (((*l_687) = g_685[3][1][0]) == ((*l_688) = &g_686));
                    for (g_527 = 0; (g_527 <= 0); g_527 += 1)
                    { /* block id: 354 */
                        int32_t *l_690 = &g_558;
                        int32_t **l_695[8][10][3] = {{{&g_30,&g_30,(void*)0},{&g_448,&g_448,&l_689},{&l_683,&g_448,&l_683},{&g_448,&l_683,&g_448},{(void*)0,(void*)0,&g_448},{&l_689,&g_448,&l_683},{&l_683,(void*)0,&l_689},{&l_689,&l_689,&l_683},{(void*)0,(void*)0,&g_448},{&g_448,&l_683,&l_683}},{{&l_683,(void*)0,(void*)0},{&g_448,&g_30,&g_448},{&g_30,&l_683,(void*)0},{&g_448,&l_683,&l_683},{(void*)0,&l_683,&g_448},{&g_30,(void*)0,&l_683},{&l_683,&l_689,&l_689},{&l_683,&g_448,&l_683},{&g_30,&l_689,&g_448},{&g_448,(void*)0,&g_448}},{{&l_689,&l_683,&l_683},{&l_683,&l_683,&l_689},{&g_448,&l_683,(void*)0},{&l_683,&g_30,&l_689},{&g_448,(void*)0,&g_30},{&l_683,&l_683,(void*)0},{&l_689,(void*)0,(void*)0},{&g_448,&l_689,&l_683},{&g_30,(void*)0,&l_689},{&l_683,&g_448,&l_683}},{{&l_683,(void*)0,(void*)0},{&g_30,&l_683,(void*)0},{&l_689,(void*)0,&l_683},{&g_30,&l_683,&g_448},{&l_683,(void*)0,&l_689},{&l_689,&l_683,&g_448},{&g_30,(void*)0,&g_30},{&l_683,&g_448,&g_30},{&g_30,(void*)0,&l_683},{&g_448,&g_30,&g_448}},{{&l_683,&g_30,&l_689},{&g_448,&l_683,&l_683},{&g_30,&g_30,(void*)0},{&l_683,&l_683,&l_683},{&g_30,(void*)0,&g_30},{&l_689,&g_448,&l_689},{&l_683,&g_30,&g_30},{&g_30,&l_683,&l_683},{&l_689,&l_683,(void*)0},{&l_689,&g_30,&l_683}},{{(void*)0,(void*)0,&l_689},{&l_683,&l_689,&g_448},{(void*)0,(void*)0,&l_683},{&g_30,&g_30,&g_30},{(void*)0,&l_683,&g_30},{&l_683,&l_683,&g_448},{&l_683,&g_30,&l_689},{&g_448,&g_448,&g_448},{&l_683,(void*)0,&l_683},{&l_683,&l_683,&g_30}},{{(void*)0,&g_30,(void*)0},{&g_30,&l_683,&l_683},{(void*)0,&g_30,&g_448},{&l_683,&g_30,&l_683},{(void*)0,(void*)0,(void*)0},{&l_689,&g_448,&g_30},{&l_689,(void*)0,&l_683},{&g_30,&l_683,&g_448},{&l_683,(void*)0,&l_689},{&l_689,&l_683,&g_448}},{{&g_30,(void*)0,&g_30},{&l_683,&g_448,&g_30},{&g_30,(void*)0,&l_683},{&g_448,&g_30,&g_448},{&l_683,&g_30,&l_689},{&g_448,&l_683,&l_683},{&g_30,&g_30,(void*)0},{&l_683,&l_683,&l_683},{&g_30,(void*)0,&g_30},{&l_689,&g_448,&l_689}}};
                        int i, j, k;
                        g_448 = func_58(l_689, (((void*)0 == l_690) , ((g_77[(g_358 + 1)][(g_527 + 1)][g_358] >= ((safe_sub_func_int32_t_s_s((*g_30), 0x678AC9D2L)) | (l_597 ^ (g_77[(g_358 + 1)][(g_527 + 1)][g_358] > 0x8B525169L)))) <= 0x6DE8DA16L)), l_689);
                        return (*g_526);
                    }
                }
            }
            for (g_126 = 0; (g_126 <= 0); g_126 += 1)
            { /* block id: 362 */
                uint16_t *l_705 = &g_90[3][5];
                int16_t *l_716 = (void*)0;
                int16_t *l_717[6] = {&g_242,&g_242,&g_242,&g_242,&g_242,&g_242};
                const int32_t l_718 = 1L;
                int i;
                for (l_646 = 0; (l_646 <= 0); l_646 += 1)
                { /* block id: 365 */
                    int i, j;
                    if (g_357[l_646][l_646])
                        break;
                    for (l_649 = 0; (l_649 <= 0); l_649 += 1)
                    { /* block id: 369 */
                        int i, j, k;
                        return g_77[(l_649 + 1)][(g_126 + 1)][l_646];
                    }
                }
                (*g_30) = (p_26.f0 && (safe_mul_func_int8_t_s_s((safe_mod_func_int8_t_s_s(((safe_mul_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(((*l_683) == (safe_unary_minus_func_uint16_t_u(((*l_705) ^= 0x7358L)))), (((safe_mod_func_int32_t_s_s(((((safe_div_func_uint32_t_u_u(((l_648 = (((safe_div_func_uint16_t_u_u(p_26.f0, (safe_mod_func_uint32_t_u_u(((l_714 != &g_357[1][0]) != (((+65530UL) && ((g_231 = ((p_26.f0 ^ g_558) > 0UL)) != 0xDB73L)) , p_26.f0)), g_126)))) && l_718) || l_718)) , 0xA49C73FBL), l_649)) , 0xF4EEC1317050E87ALL) , l_630) != &g_357[1][0]), l_644[0])) & (-4L)) != l_719))), 65531UL)) < (*l_683)), 0x89L)), (-1L))));
                return l_643;
            }
            --l_730[3];
        }
        if (((((*l_734) = &g_558) == (g_754 = func_32(func_58(&g_100, g_392, &l_644[0]), g_558, p_26.f0, &g_31, p_26.f0))) ^ l_755))
        { /* block id: 384 */
            uint16_t ***l_758 = (void*)0;
            uint16_t ***l_759 = &l_756;
            uint16_t ***l_760 = (void*)0;
            uint16_t ***l_761 = (void*)0;
            uint16_t **l_763 = (void*)0;
            uint16_t ***l_762 = &l_763;
            int32_t l_764[9][9][3] = {{{(-1L),0x1D93B7EAL,0xABDA6AB0L},{0xF48F38E9L,0x07DF4D51L,0x4763C835L},{(-1L),0L,0L},{0xF48F38E9L,0L,1L},{(-1L),0L,1L},{(-1L),1L,0L},{1L,0xABDA6AB0L,0x4763C835L},{(-8L),1L,0xABDA6AB0L},{0x0CD484B6L,0L,9L}},{{0x0CD484B6L,0L,(-10L)},{(-8L),0L,0L},{1L,0x07DF4D51L,(-10L)},{(-1L),0x1D93B7EAL,9L},{(-1L),0x1D93B7EAL,0x77DAFDD0L},{1L,0x5AB89270L,0xD0078A14L},{1L,3L,3L},{1L,0x64190854L,5L},{(-10L),(-1L),5L}},{{0x1D93B7EAL,5L,3L},{0L,0x77DAFDD0L,0xD0078A14L},{0xABDA6AB0L,5L,0x77DAFDD0L},{(-1L),(-1L),(-6L)},{(-1L),0x64190854L,0x0BC76099L},{0xABDA6AB0L,3L,(-1L)},{0L,0x5AB89270L,0x0BC76099L},{0x1D93B7EAL,(-2L),(-6L)},{(-10L),(-2L),0x77DAFDD0L}},{{1L,0x5AB89270L,0xD0078A14L},{1L,3L,3L},{1L,0x64190854L,5L},{(-10L),(-1L),5L},{0x1D93B7EAL,5L,3L},{0L,0x77DAFDD0L,0xD0078A14L},{0xABDA6AB0L,5L,0x77DAFDD0L},{(-1L),(-1L),(-6L)},{(-1L),0x64190854L,0x0BC76099L}},{{0xABDA6AB0L,3L,(-1L)},{0L,0x5AB89270L,0x0BC76099L},{0x1D93B7EAL,(-2L),(-6L)},{(-10L),(-2L),0x77DAFDD0L},{1L,0x5AB89270L,0xD0078A14L},{1L,3L,3L},{1L,0x64190854L,5L},{(-10L),(-1L),5L},{0x1D93B7EAL,5L,3L}},{{0L,0x77DAFDD0L,0xD0078A14L},{0xABDA6AB0L,5L,0x77DAFDD0L},{(-1L),(-1L),(-6L)},{(-1L),0x64190854L,0x0BC76099L},{0xABDA6AB0L,3L,(-1L)},{0L,0x5AB89270L,0x0BC76099L},{0x1D93B7EAL,(-2L),(-6L)},{(-10L),(-2L),0x77DAFDD0L},{1L,0x5AB89270L,0xD0078A14L}},{{1L,3L,3L},{1L,0x64190854L,5L},{(-10L),(-1L),5L},{0x1D93B7EAL,5L,3L},{0L,0x77DAFDD0L,0xD0078A14L},{0xABDA6AB0L,5L,0x77DAFDD0L},{(-1L),(-1L),(-6L)},{(-1L),0x64190854L,0x0BC76099L},{0xABDA6AB0L,3L,(-1L)}},{{0L,0x5AB89270L,0x0BC76099L},{0x1D93B7EAL,(-2L),(-6L)},{(-10L),(-2L),0x77DAFDD0L},{1L,0x5AB89270L,0xD0078A14L},{1L,3L,3L},{1L,0x64190854L,5L},{(-10L),(-1L),5L},{0x1D93B7EAL,5L,3L},{0L,0x77DAFDD0L,0xD0078A14L}},{{0xABDA6AB0L,5L,0x77DAFDD0L},{(-1L),(-1L),(-6L)},{(-1L),0x64190854L,0x0BC76099L},{0xABDA6AB0L,3L,(-1L)},{0L,0x5AB89270L,0x0BC76099L},{(-2L),0x8D275DD8L,(-1L)},{0x0BC76099L,0x8D275DD8L,(-1L)},{0xB784D672L,0x73F5DD8FL,1L},{5L,(-8L),(-8L)}}};
            int8_t l_789 = (-4L);
            int32_t l_809 = (-4L);
            uint8_t l_865[8];
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_865[i] = 250UL;
            (*l_762) = ((*l_759) = l_756);
            if (l_764[1][6][1])
            { /* block id: 387 */
                for (l_647 = 0; (l_647 < (-10)); l_647 = safe_sub_func_uint16_t_u_u(l_647, 5))
                { /* block id: 390 */
                    for (g_146 = 27; (g_146 < 58); g_146++)
                    { /* block id: 393 */
                        return p_26.f0;
                    }
                    if (l_769)
                        break;
                }
            }
            else
            { /* block id: 398 */
                uint32_t l_775 = 1UL;
                int32_t l_780 = 0xE1A2CC09L;
                int32_t l_784 = 0xEA5EF9AFL;
                int32_t l_787[1][2][1];
                int32_t l_788 = 0L;
                uint32_t *l_829 = &l_730[3];
                int64_t *l_830[8] = {&l_791,&l_791,&l_791,&l_791,&l_791,&l_791,&l_791,&l_791};
                struct S0 **l_858 = &g_362;
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 2; j++)
                    {
                        for (k = 0; k < 1; k++)
                            l_787[i][j][k] = 1L;
                    }
                }
                for (g_93 = 0; (g_93 >= (-12)); g_93 = safe_sub_func_uint32_t_u_u(g_93, 8))
                { /* block id: 401 */
                    const uint32_t l_774[4][10][6] = {{{0x727F2DF2L,0x48592EC7L,4UL,0UL,6UL,0x8D6DB367L},{0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL,0xAA4F42FCL},{0x8D6DB367L,0x727F2DF2L,0xB14CC699L,0xB14CC699L,0x727F2DF2L,0x8D6DB367L},{0xF6FDC8B9L,0xB14CC699L,4UL,0UL,0x48592EC7L,18446744073709551615UL},{0xE7087BBEL,0x727F2DF2L,0UL,0UL,0x8D6DB367L,0xDD72629AL},{0xE7087BBEL,0x65194B29L,0UL,0UL,0xF6FDC8B9L,0xAA4F42FCL},{0xF6FDC8B9L,0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL},{0x8D6DB367L,0xB14CC699L,18446744073709551615UL,0xE7087BBEL,0xE7087BBEL,18446744073709551615UL},{0x48592EC7L,0x48592EC7L,0xAA4F42FCL,0UL,0xF6FDC8B9L,0x8D6DB367L},{0x727F2DF2L,0x65194B29L,18446744073709551615UL,0xE7087BBEL,0x8D6DB367L,0xAA4F42FCL}},{{0xDD72629AL,0x727F2DF2L,18446744073709551615UL,0xB14CC699L,0x48592EC7L,0x8D6DB367L},{6UL,0xB14CC699L,0xAA4F42FCL,0UL,0x727F2DF2L,18446744073709551615UL},{0UL,0x727F2DF2L,18446744073709551615UL,0UL,0xDD72629AL,0xDD72629AL},{0UL,0x65194B29L,0x65194B29L,0UL,6UL,0xAA4F42FCL},{6UL,0x48592EC7L,0UL,0xB14CC699L,0UL,0xDD72629AL},{0xDD72629AL,0xB14CC699L,0UL,0xE7087BBEL,0UL,18446744073709551615UL},{0x727F2DF2L,0x48592EC7L,4UL,0UL,6UL,0x8D6DB367L},{0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL,0xAA4F42FCL},{0x8D6DB367L,0x727F2DF2L,0xB14CC699L,0xB14CC699L,0x727F2DF2L,0x8D6DB367L},{0xF6FDC8B9L,0xB14CC699L,4UL,0UL,0x48592EC7L,18446744073709551615UL}},{{0xE7087BBEL,0x727F2DF2L,0UL,0UL,0x8D6DB367L,0xDD72629AL},{0xE7087BBEL,0x65194B29L,0UL,0UL,0xF6FDC8B9L,0xAA4F42FCL},{0xF6FDC8B9L,0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL},{0x8D6DB367L,0xB14CC699L,18446744073709551615UL,0xE7087BBEL,0xE7087BBEL,18446744073709551615UL},{0x48592EC7L,0x48592EC7L,0xAA4F42FCL,0UL,0xF6FDC8B9L,0x8D6DB367L},{0x727F2DF2L,0x65194B29L,18446744073709551615UL,0xE7087BBEL,0x8D6DB367L,0xAA4F42FCL},{0xDD72629AL,0x727F2DF2L,18446744073709551615UL,0xB14CC699L,0x48592EC7L,0x8D6DB367L},{6UL,0xB14CC699L,0xAA4F42FCL,0UL,0x727F2DF2L,18446744073709551615UL},{0UL,0x727F2DF2L,18446744073709551615UL,0UL,0xDD72629AL,0xDD72629AL},{0UL,0x65194B29L,0x65194B29L,0UL,6UL,0xAA4F42FCL}},{{6UL,0x48592EC7L,0UL,0xB14CC699L,0UL,0xDD72629AL},{0xDD72629AL,0xB14CC699L,0UL,0xE7087BBEL,0UL,18446744073709551615UL},{0x727F2DF2L,0x48592EC7L,4UL,0UL,6UL,0x8D6DB367L},{0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL,0xAA4F42FCL},{0x8D6DB367L,0x727F2DF2L,0xB14CC699L,0xB14CC699L,0x727F2DF2L,0x8D6DB367L},{0xF6FDC8B9L,0xB14CC699L,4UL,0UL,0x48592EC7L,18446744073709551615UL},{0xE7087BBEL,0x727F2DF2L,0UL,0UL,0x8D6DB367L,0xDD72629AL},{0xE7087BBEL,0x65194B29L,0UL,0UL,0xF6FDC8B9L,0xAA4F42FCL},{0xF6FDC8B9L,0x48592EC7L,0x65194B29L,0xB14CC699L,0xE7087BBEL,0xDD72629AL},{0x8D6DB367L,0xB14CC699L,18446744073709551615UL,0xE7087BBEL,0xE7087BBEL,18446744073709551615UL}}};
                    int32_t l_778 = 1L;
                    int32_t l_779 = 0x6D20084CL;
                    int32_t l_781 = 1L;
                    int32_t l_782 = 0xC0C83CB9L;
                    int32_t l_783 = 7L;
                    int32_t l_785 = 3L;
                    int32_t l_786[4];
                    uint64_t *l_808 = &l_792;
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_786[i] = 0x4FF18D15L;
                    for (l_627 = 0; (l_627 > 19); ++l_627)
                    { /* block id: 404 */
                        if (l_774[0][5][2])
                            break;
                        l_775--;
                    }
                    --l_792;
                    l_809 |= ((1UL >= ((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((((((*p_28) & (safe_mul_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(0xF0CEL, 8)), ((l_764[5][4][1] > ((((*l_808) ^= (safe_mod_func_uint32_t_u_u(0x2436358BL, (safe_rshift_func_uint16_t_u_u((((l_778 ^ (p_26.f0 == ((~l_764[1][6][1]) <= g_98[1][0][0]))) , (void*)0) == (void*)0), l_787[0][1][0]))))) > 0xE398011B3E80CCD6LL) , g_31)) == g_358)))) > 0xA8DEF468L) < p_26.f0) > (-2L)), 7)), g_358)) < 0xDFFCL)) > g_90[4][5]);
                }
                (*g_30) = (safe_div_func_uint32_t_u_u(((((((*l_829) = ((**g_361) , ((safe_mul_func_uint16_t_u_u((((((((*p_27) | ((*l_592) = ((((safe_mod_func_uint8_t_u_u(0UL, (~(safe_add_func_uint16_t_u_u(((p_26.f0 >= (safe_div_func_int64_t_s_s(3L, (safe_lshift_func_uint8_t_u_s(((((void*)0 == &p_27) >= ((((((safe_mod_func_int64_t_s_s((((safe_lshift_func_int8_t_s_s(p_26.f0, 1)) , (*g_526)) ^ 0x5EL), 0xA61958D774750872LL)) < 0L) , (void*)0) == l_827) == l_828[0]) || (*p_28))) | 0UL), g_357[1][0]))))) != 18446744073709551611UL), p_26.f0))))) || g_95) | 0x2626F88BL) >= g_558))) >= g_357[1][0]) == g_146) < l_789) > l_809) & (*g_30)), g_31)) == l_775))) , l_830[6]) == &g_93) >= 0x676AE0E6L) | l_775), (*g_30)));
                for (l_752 = 0; (l_752 != 8); ++l_752)
                { /* block id: 417 */
                    int8_t l_833 = 7L;
                    int32_t l_834 = (-1L);
                    int32_t l_835 = 0xC5CAB801L;
                    int16_t *l_841[5] = {&g_77[1][7][0],&g_77[1][7][0],&g_77[1][7][0],&g_77[1][7][0],&g_77[1][7][0]};
                    int32_t l_848 = 0x2DBE78BEL;
                    int i;
                    l_836++;
                    if (((*p_27) = ((safe_lshift_func_uint16_t_u_u(g_242, 2)) | (((g_77[1][4][0] ^= (p_26.f0 || 2L)) >= ((safe_sub_func_int64_t_s_s((g_242 & (safe_sub_func_uint64_t_u_u(0x0419BC6C968A7A03LL, g_358))), ((safe_lshift_func_int8_t_s_s(p_26.f0, p_26.f0)) ^ 0xD87637D3L))) || l_834)) != l_833))))
                    { /* block id: 421 */
                        uint32_t l_849 = 0xD2D220A5L;
                        l_849--;
                    }
                    else
                    { /* block id: 423 */
                        (**l_858) = func_40((safe_lshift_func_int16_t_s_u((safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(((l_775 & (((*l_751) = l_858) == (void*)0)) && l_764[1][6][1]), (((p_26.f0 <= ((safe_rshift_func_uint16_t_u_s(((l_809 > p_26.f0) != ((safe_div_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(1UL, ((g_357[0][0] < p_26.f0) , l_833))), p_26.f0)) && g_90[3][5])), 7)) | p_26.f0)) , l_787[0][0][0]) || 0x64L))), p_26.f0)), 0)), l_835, p_26.f0);
                    }
                    if ((*p_28))
                        break;
                    l_865[7]--;
                }
            }
        }
        else
        { /* block id: 431 */
            int64_t * const *l_876[8][5] = {{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630},{(void*)0,&l_630,(void*)0,&l_630,&l_630}};
            int32_t l_881 = (-10L);
            uint64_t *l_885 = &g_357[1][0];
            int32_t l_900[1][3];
            int32_t l_931 = 0xCDF0EA36L;
            int32_t l_932[10][9][2] = {{{0xA380864FL,1L},{(-1L),0x0F12CD90L},{(-6L),0L},{(-1L),0x2304CA79L},{(-1L),0xEED59B84L},{0L,(-1L)},{0x7A49E7B7L,0xAF6BB176L},{1L,0xF8FAE3C6L},{0L,(-1L)}},{{0xCCD2EFFFL,4L},{0xB07D0F2FL,(-1L)},{(-1L),1L},{0x3C851754L,0xE913468FL},{(-1L),(-1L)},{0xFC4C2933L,0xC0C0876BL},{(-6L),1L},{0xF8FAE3C6L,0xD7DDF550L},{0x3C851754L,0xEED59B84L}},{{9L,0xD51530D9L},{0xA7B827B0L,4L},{1L,1L},{0xF166294DL,1L},{1L,4L},{0xA7B827B0L,0xD51530D9L},{9L,0xEED59B84L},{0x3C851754L,0xD7DDF550L},{0xF8FAE3C6L,1L}},{{(-6L),0xC0C0876BL},{0xFC4C2933L,(-1L)},{(-1L),0xE913468FL},{0x3C851754L,1L},{(-1L),(-1L)},{0xB07D0F2FL,4L},{0xCCD2EFFFL,(-1L)},{0L,0xF8FAE3C6L},{1L,0xAF6BB176L}},{{0x7A49E7B7L,(-1L)},{0L,0xEED59B84L},{0x7A49E7B7L,1L},{0xF166294DL,0xB07D0F2FL},{(-3L),(-1L)},{(-10L),0xA7B827B0L},{(-1L),(-4L)},{0x7A49E7B7L,0xF8FAE3C6L},{(-1L),0x4580F878L}},{{0xCBB45344L,0x565872B4L},{0x1F8338C3L,0L},{0x4FB87F62L,7L},{0xC0C0876BL,0xC0C0876BL},{0x58BB74E8L,0x4580F878L},{0x250579B4L,(-1L)},{0xB07D0F2FL,0xE1D2F976L},{(-1L),0xB07D0F2FL},{0xEED59B84L,0L}},{{0xEED59B84L,0xB07D0F2FL},{(-1L),0xE1D2F976L},{0xB07D0F2FL,(-1L)},{0x250579B4L,0x4580F878L},{0x58BB74E8L,0xC0C0876BL},{0xC0C0876BL,7L},{0x4FB87F62L,0L},{0x1F8338C3L,0x565872B4L},{0xCBB45344L,0x4580F878L}},{{(-1L),0xF8FAE3C6L},{0x7A49E7B7L,(-4L)},{(-1L),0xA7B827B0L},{(-10L),(-1L)},{(-3L),0xB07D0F2FL},{0xF166294DL,1L},{0x7A49E7B7L,0xA380864FL},{0x250579B4L,0x2304CA79L},{(-1L),0x565872B4L}},{{(-1L),7L},{4L,0xF166294DL},{0xC0C0876BL,0x1F8338C3L},{0xCBB45344L,0x2304CA79L},{(-6L),(-1L)},{0x1BD49A2BL,(-4L)},{0xF166294DL,0x7A49E7B7L},{0xEED59B84L,0x3C851754L},{(-3L),0xA7B827B0L}},{{7L,0xE1D2F976L},{0x1BD49A2BL,0xA380864FL},{(-1L),0xE913468FL},{0x58BB74E8L,0x1F8338C3L},{(-1L),0L},{1L,0L},{(-1L),0x1F8338C3L},{0x58BB74E8L,0xE913468FL},{(-1L),0xA380864FL}}};
            uint32_t l_970 = 4294967295UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_900[i][j] = (-1L);
            }
            if ((safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_u(0x0EL, 2)), (func_40((safe_sub_func_uint8_t_u_u((((l_874 , (p_26.f0 == ((~(l_876[2][1] != &l_630)) & ((g_98[2][8][6] ^ (l_627 ^ (safe_mul_func_int8_t_s_s((((safe_mod_func_uint16_t_u_u(((*g_526) , 0x52A2L), 0x1A92L)) <= p_26.f0) >= 0x26L), g_95)))) && l_629)))) >= l_881) == p_26.f0), 0x7AL)), g_93, g_527) , (*g_526)))))
            { /* block id: 432 */
                uint16_t l_897[1][2][2] = {{{3UL,3UL},{3UL,3UL}}};
                int32_t *l_921 = (void*)0;
                int i, j, k;
                for (l_648 = 0; (l_648 < 10); l_648++)
                { /* block id: 435 */
                    uint16_t l_884[2][7] = {{1UL,1UL,0UL,9UL,0x47B4L,9UL,0UL},{1UL,1UL,0UL,9UL,0x47B4L,9UL,0UL}};
                    uint64_t *l_887 = &g_357[0][0];
                    uint64_t **l_886 = &l_887;
                    uint32_t l_899 = 5UL;
                    int i, j;
                }
                for (l_645 = 0; (l_645 < 17); l_645 = safe_add_func_int16_t_s_s(l_645, 8))
                { /* block id: 452 */
                    struct S0 *l_904 = &g_131;
                    struct S0 **l_903[3];
                    const struct S0 *l_919[9];
                    const struct S0 **l_918 = &l_919[2];
                    const struct S0 ** const *l_917[3][6] = {{&l_918,&l_918,&l_918,&l_918,&l_918,&l_918},{&l_918,&l_918,&l_918,&l_918,&l_918,&l_918},{&l_918,&l_918,&l_918,&l_918,&l_918,&l_918}};
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_903[i] = &l_904;
                    for (i = 0; i < 9; i++)
                        l_919[i] = &g_52;
                    l_905 = ((**l_751) = (void*)0);
                    l_921 = (((1UL <= (safe_sub_func_uint32_t_u_u((g_908 < ((safe_mod_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(g_358, ((g_146 | l_900[0][1]) , (safe_div_func_uint32_t_u_u((0x94C3L <= ((safe_div_func_int8_t_s_s(((l_900[0][0] >= p_26.f0) | ((((l_920 = l_917[0][3]) == (void*)0) && p_26.f0) , p_26.f0)), g_898)) || p_26.f0)), 0x7B4BCA85L))))), 0x84301EBEL)) | l_900[0][1])), g_908))) & g_242) , (void*)0);
                }
                l_932[2][1][1] ^= (safe_div_func_int32_t_s_s((((*p_28) = ((l_931 = (p_26.f0 , ((safe_lshift_func_int8_t_s_s(0xF5L, 6)) , (l_900[0][1] ^= ((0xBFA4AE5DL & g_98[1][5][8]) || (p_26.f0 > (safe_mod_func_int32_t_s_s((+(g_90[3][5] >= (-3L))), (safe_div_func_uint64_t_u_u((l_897[0][0][0] , ((l_881 <= p_26.f0) <= (*p_28))), g_357[1][0])))))))))) & p_26.f0)) , (*p_27)), 1L));
            }
            else
            { /* block id: 462 */
                uint32_t l_949 = 0x010241B8L;
                int32_t l_972[7][3][1] = {{{(-1L)},{0xC1002C3CL},{0x06943315L}},{{0xC1002C3CL},{(-1L)},{0xC1002C3CL}},{{0x06943315L},{0xC1002C3CL},{(-1L)}},{{0xC1002C3CL},{0x06943315L},{0xC1002C3CL}},{{(-1L)},{0xC1002C3CL},{0x06943315L}},{{0xC1002C3CL},{(-1L)},{0xC1002C3CL}},{{0x06943315L},{0xC1002C3CL},{(-1L)}}};
                uint32_t l_995 = 4294967286UL;
                int i, j, k;
                for (l_649 = 0; (l_649 != 22); l_649++)
                { /* block id: 465 */
                    int32_t l_948 = 0L;
                    int16_t *l_956 = &l_790[4];
                    if ((safe_mod_func_uint32_t_u_u(((*l_609) = (safe_mul_func_uint8_t_u_u((~(((safe_rshift_func_uint8_t_u_s((((safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint64_t_u_u(18446744073709551609UL, l_948)) == l_949), (*g_526))), (safe_mul_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s(p_26.f0, ((*l_956) &= (safe_rshift_func_uint16_t_u_u(0xEBE3L, 10))))) < ((((*p_27) |= 0xC07DE312L) < ((safe_sub_func_int32_t_s_s((safe_mul_func_int16_t_s_s(0xA1C0L, ((*l_757) = (safe_mul_func_int16_t_s_s((!((*l_592) |= (safe_mod_func_uint64_t_u_u((safe_lshift_func_int16_t_s_s((safe_div_func_uint16_t_u_u(0x47A7L, 1UL)), 1)), p_26.f0)))), 0x69F4L))))), l_948)) && l_970)) == 1L)), g_971[0])))) | 0x54L) && p_26.f0), l_932[2][0][1])) , g_888) != (-8L))), l_948))), (*p_28))))
                    { /* block id: 471 */
                        (*g_438) = (*g_438);
                        return p_26.f0;
                    }
                    else
                    { /* block id: 474 */
                        return p_26.f0;
                    }
                }
                ++l_974;
                if (l_970)
                { /* block id: 479 */
                    struct S0 **l_988 = &g_362;
                    int32_t l_1000 = 0x60043CCDL;
                    int32_t l_1005 = 1L;
                    int8_t l_1006 = 0x9DL;
                    uint32_t l_1007 = 4294967295UL;
                    l_977 = (void*)0;
                    if (l_752)
                        goto lbl_1004;
                    (*p_27) = (0x52438A0A4D84DD62LL && p_26.f0);
                    for (l_639 = 0; (l_639 != 27); l_639 = safe_add_func_int8_t_s_s(l_639, 7))
                    { /* block id: 484 */
                        uint8_t **l_996[1];
                        uint8_t ***l_997 = (void*)0;
                        uint8_t **l_999 = &g_526;
                        uint8_t ***l_998 = &l_999;
                        int8_t *l_1001 = &l_645;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_996[i] = (void*)0;
                        g_1003[0] ^= (((safe_mul_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((((((((((((safe_lshift_func_int16_t_s_s(g_242, 1)) <= (((((void*)0 == l_988) != (((0x65L ^ (safe_lshift_func_int8_t_s_s(((*l_1001) = (safe_rshift_func_uint8_t_u_s((((safe_sub_func_uint16_t_u_u((l_995 , 0x8024L), (((l_996[0] == ((*l_998) = l_996[0])) , ((((g_98[1][5][8] , 0x4F521A7C0F505C57LL) ^ l_1000) != (*g_30)) > l_881)) , g_358))) & 1UL) >= p_26.f0), g_242))), g_39))) | 0x7DC8L) && g_392)) <= g_231) <= 0x44CBL)) || l_1002) , l_1000) || l_1000) != g_90[0][8]) & g_131.f0) != 0L) >= g_100) == p_26.f0) != l_900[0][1]), g_90[3][2])) & 8L), p_26.f0)), 0L)) & g_77[1][7][0]) <= (*g_526));
                    }
                    if ((*p_27))
                    { /* block id: 489 */
lbl_1004:
                        g_448 = &l_972[3][1][0];
                        --l_1007;
                        return l_949;
                    }
                    else
                    { /* block id: 494 */
                        int32_t *l_1010 = &l_932[2][1][0];
                        int32_t ** const **l_1020 = (void*)0;
                        p_27 = l_1010;
                        (*l_1010) = l_972[3][1][0];
                        (*g_30) = ((safe_mul_func_int16_t_s_s((((p_26.f0 | ((safe_lshift_func_int8_t_s_u((!g_77[0][4][0]), ((l_1021 = l_1018[4]) == &g_439))) < (+(*g_526)))) & 0x6C2EACD2871F4235LL) & (g_1003[0] != ((*l_592) = g_126))), (safe_mod_func_int32_t_s_s(((l_1027[0] == (void*)0) != 0x7153E8B7ADFF584BLL), 0x31A9B839L)))) , l_1028);
                    }
                }
                else
                { /* block id: 501 */
                    int16_t l_1040 = 0L;
                    int8_t *l_1041 = &l_627;
                    if ((l_1029 != (((safe_div_func_int8_t_s_s(0x8BL, p_26.f0)) , func_40((+(safe_add_func_int16_t_s_s(((safe_add_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((-8L) || ((*l_1041) = l_1040)), (safe_mul_func_uint16_t_u_u(0x5D22L, ((safe_mod_func_uint32_t_u_u((((safe_lshift_func_int8_t_s_s((~l_972[1][2][0]), g_898)) && ((*l_885) = (++(*l_1030)))) & p_26.f0), 4294967288UL)) > g_358))))), 0x5FB98E00A05EB736LL)) != 0x331BL), p_26.f0))), l_1040, g_93)) , (void*)0)))
                    { /* block id: 505 */
                        (**g_686) = p_26;
                    }
                    else
                    { /* block id: 507 */
                        uint16_t *l_1055 = (void*)0;
                        uint16_t *l_1056 = &l_753[1][1][0];
                        uint16_t *l_1059 = &g_1060;
                        (*l_1022) = p_28;
                    }
                }
            }
            (*l_1019) = &g_100;
            (*l_1019) = (*l_1022);
        }
        for (g_231 = 0; (g_231 == (-5)); g_231--)
        { /* block id: 522 */
            const int32_t ***l_1077[9][6][4] = {{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,(void*)0},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{(void*)0,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0}},{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075}},{{(void*)0,&l_1075,&l_1075,&l_1075},{(void*)0,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,(void*)0,&l_1075}},{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,(void*)0,&l_1075,(void*)0},{(void*)0,(void*)0,&l_1075,&l_1075},{(void*)0,&l_1075,(void*)0,&l_1075}},{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{(void*)0,&l_1075,&l_1075,&l_1075}},{{(void*)0,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075}},{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,(void*)0,&l_1075,(void*)0},{(void*)0,(void*)0,&l_1075,&l_1075},{(void*)0,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075}},{{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,(void*)0,&l_1075},{(void*)0,&l_1075,&l_1075,&l_1075},{(void*)0,&l_1075,&l_1075,&l_1075}},{{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,(void*)0},{&l_1075,&l_1075,(void*)0,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075},{&l_1075,&l_1075,&l_1075,&l_1075}}};
            int32_t ***l_1085 = &l_734;
            int32_t ****l_1084 = &l_1085;
            int32_t l_1086 = (-10L);
            const int32_t l_1089 = (-1L);
            int i, j, k;
            (*l_1022) = &g_100;
            (*p_28) = (safe_sub_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((safe_unary_minus_func_uint32_t_u((safe_mod_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((((***l_827)++) & (~((p_26.f0 | (((p_26 , &g_754) != (g_1078 = l_1075)) & ((safe_add_func_int16_t_s_s((safe_unary_minus_func_uint32_t_u(((g_971[0] , &l_734) == ((*l_1084) = &l_734)))), ((l_1086 = ((*l_630) ^= p_26.f0)) | (safe_mul_func_uint16_t_u_u(g_971[0], g_527))))) ^ g_98[2][5][5]))) < g_1003[3]))), l_1089)), l_1090)))), 1L)), p_26.f0));
        }
    }
    else
    { /* block id: 531 */
        int32_t l_1093 = 0x554ABCF4L;
        int32_t l_1118 = 0L;
        int32_t l_1121 = (-1L);
        int32_t l_1123[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        int32_t l_1172 = 0xAAC47C3AL;
        int32_t *l_1174 = &g_98[1][5][8];
        struct S0 *l_1177 = &g_131;
        struct S0 ***l_1206 = &g_686;
        int32_t l_1220 = 0xF501F928L;
        int32_t l_1230 = 0x94F02536L;
        uint32_t l_1233 = 0x4C642036L;
        int64_t l_1252 = (-4L);
        int i;
        for (g_358 = 0; (g_358 <= 7); g_358 += 1)
        { /* block id: 534 */
            int32_t **** const l_1100 = (void*)0;
            uint32_t *l_1109 = &g_898;
            int32_t l_1112 = 1L;
            int32_t l_1114 = 0L;
            int32_t l_1115 = 0x6250ABABL;
            int32_t l_1120 = 3L;
            int32_t l_1122[10] = {0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL,0xF60C2D7BL};
            int16_t l_1150 = 0L;
            uint8_t l_1205 = 0UL;
            int64_t l_1209 = (-1L);
            int8_t l_1255[6];
            int32_t l_1257 = 0x20FA813AL;
            uint16_t l_1258[9][1][2] = {{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}},{{0UL,0UL}}};
            int64_t **l_1274 = &g_894[0];
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_1255[i] = 5L;
        }
    }
    (*p_28) |= (p_26.f0 == ((safe_lshift_func_uint16_t_u_u((((safe_add_func_int16_t_s_s(g_1080, (safe_add_func_uint64_t_u_u((&g_438 != &l_1018[5]), (safe_mul_func_uint8_t_u_u((((*g_526) = (safe_add_func_uint64_t_u_u(l_1312[2][4][1], (safe_add_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(((*l_1324) = (safe_rshift_func_uint8_t_u_s((g_357[1][0] > p_26.f0), (((*l_592) = g_1128[1]) & (((safe_div_func_uint16_t_u_u(((*l_757) = (p_26.f0 , p_26.f0)), p_26.f0)) , 0xCA200E3DL) >= l_1323[2][1][1]))))), 11)), (*g_526)))))) , 250UL), p_26.f0)))))) , g_39) ^ g_1189), (**g_1193))) , 0x4836L));
    return (*g_526);
}


/* ------------------------------------------ */
/* 
 * reads : g_98 g_95 g_126 g_39 g_52 g_31 g_77 g_90 g_93 g_100 g_30 g_448 g_438 g_439 g_358 g_357 g_362 g_361
 * writes: g_95 g_77 g_39 g_90 g_93 g_98 g_100 g_126 g_131 g_448 g_357 g_358 g_146 g_52
 */
static int32_t * func_32(int32_t * p_33, int16_t  p_34, const int32_t  p_35, int32_t * p_36, int8_t  p_37)
{ /* block id: 291 */
    uint8_t **l_573 = &g_526;
    uint8_t ***l_572 = &l_573;
    struct S0 l_574 = {0x2C534D3ED2520C61LL};
    struct S0 **l_577 = &g_362;
    struct S0 ***l_576 = &l_577;
    uint8_t l_587[7] = {0xCFL,0xF5L,0xF5L,0xCFL,0xF5L,0xF5L,0xCFL};
    int64_t *l_588 = &g_95;
    int16_t *l_589 = &g_77[1][7][0];
    int i;
    (**g_361) = func_40(g_98[2][6][0], (safe_div_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_s((l_572 != (void*)0), (g_39 |= ((*l_589) = (((l_574 , (~(l_576 == &l_577))) , (((*l_588) = (safe_div_func_int64_t_s_s((g_95 && (safe_div_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s(g_95, ((safe_mul_func_int16_t_s_s((+0xD066A9ABL), p_34)) == 0xDBL))) , p_35) >= l_587[3]), g_98[1][5][8]))), (-2L)))) < 0xDAC72CA895AA6AD0LL)) ^ g_126))))) | 1UL), 0x20FA3370L)), p_35);
    return &g_98[1][1][7];
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_31 g_77 g_90 g_93 g_95 g_98 g_100 g_30 g_448 g_438 g_439 g_358 g_357 g_362 g_361
 * writes: g_77 g_90 g_93 g_98 g_100 g_126 g_131 g_448 g_357 g_358 g_146 g_52
 */
static struct S0  func_40(uint32_t  p_41, uint64_t  p_42, int8_t  p_43)
{ /* block id: 2 */
    int32_t l_69 = 5L;
    int32_t l_561 = (-9L);
    int32_t l_564 = (-5L);
    struct S0 l_565 = {0xFBC4AC5FD0A58B77LL};
    for (p_42 = (-12); (p_42 == 42); p_42 = safe_add_func_int64_t_s_s(p_42, 7))
    { /* block id: 5 */
        struct S0 l_65 = {0x4E785E8A77F2A5CFLL};
        uint8_t l_76 = 0xE5L;
        int32_t *l_78 = &g_31;
        int16_t *l_450 = &g_231;
        uint32_t l_562 = 4UL;
        int32_t *l_563[10];
        int i;
        for (i = 0; i < 10; i++)
            l_563[i] = (void*)0;
        for (p_41 = 0; (p_41 < 15); ++p_41)
        { /* block id: 8 */
            return g_52;
        }
        l_564 |= ((l_561 = (~func_54(g_52.f0, func_58(&g_31, g_52.f0, (((0x71L <= ((+(((g_77[1][7][0] = ((safe_add_func_uint8_t_u_u((l_65 , (safe_lshift_func_int8_t_s_s((4294967295UL > (((~l_69) & 0x24L) & ((safe_lshift_func_int16_t_s_s(((((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((g_52.f0 , p_42), g_52.f0)), (-1L))) != p_42) && p_41) < l_76), l_76)) & l_69))), l_65.f0))), l_69)) <= g_52.f0)) > p_43) ^ 0xF27260E9L)) ^ p_43)) < g_31) , l_78)), l_450))) || l_562);
        l_565 = ((*g_362) = (*g_362));
    }
    return (**g_361);
}


/* ------------------------------------------ */
/* 
 * reads : g_30 g_31 g_448 g_90 g_100 g_438 g_439 g_358 g_357 g_362 g_98
 * writes: g_448 g_357 g_358 g_100 g_146 g_52 g_131
 */
static const int16_t  func_54(int32_t  p_55, int32_t * p_56, int16_t * p_57)
{ /* block id: 213 */
    const struct S0 *l_451 = (void*)0;
    int32_t * const l_452 = &g_100;
    int32_t **l_453 = &g_448;
    int64_t l_454 = 0x4BC294E54C70C715LL;
    struct S0 **l_455[8][5] = {{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362}};
    struct S0 ***l_456 = &l_455[3][1];
    uint8_t l_462[2];
    int32_t l_502 = 0x66C01BCCL;
    int32_t l_505 = 1L;
    int32_t l_506 = 7L;
    uint32_t l_508 = 4294967295UL;
    uint8_t l_523 = 252UL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_462[i] = 252UL;
lbl_560:
    (*l_453) = ((l_451 == l_451) , l_452);
    if ((0x7FAD0970L == ((l_454 , ((((((((*l_456) = l_455[3][1]) != (void*)0) && (g_357[1][0] = (~((*g_30) == (safe_lshift_func_int16_t_s_u(((safe_rshift_func_uint8_t_u_u(((((*l_453) != p_56) || g_90[3][7]) , 8UL), p_55)) | (*l_452)), l_462[1])))))) , (*g_438)) != (*g_438)) && 0x8FC4L) , (**l_453))) & 2L)))
    { /* block id: 217 */
        int16_t l_476 = 8L;
        int32_t l_486 = 0L;
        int64_t *l_492 = &g_95;
        int32_t l_500[7] = {1L,1L,1L,1L,1L,1L,1L};
        int32_t l_521 = (-1L);
        uint8_t **l_549 = &g_526;
        uint8_t ***l_548 = &l_549;
        int i;
        for (g_358 = (-26); (g_358 > 5); g_358 = safe_add_func_int8_t_s_s(g_358, 8))
        { /* block id: 220 */
            uint16_t *l_470 = &g_90[0][8];
            uint16_t **l_469 = &l_470;
            struct S0 l_479 = {1UL};
            int32_t l_485 = 0x8DA17335L;
            int32_t l_501 = 0x5F1B1279L;
            int32_t l_503 = 0xFF68BFCFL;
            int32_t l_504 = 0x7CB71112L;
            int32_t l_507 = 0x5E761DEEL;
            uint32_t * const l_544 = &g_126;
            if ((0xA44EL && (((((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_uint16_t_u_u(((((g_357[1][0] , ((*l_469) = p_57)) != &g_90[3][5]) | (0x610EE2F0L == (*l_452))) >= (safe_div_func_int32_t_s_s((*l_452), (safe_lshift_func_uint8_t_u_u(0xD5L, ((p_55 == (**l_453)) , g_100)))))), 5)) == 18446744073709551610UL), 15)) , (-1L)) > 0xA4DEB1430C35EC6DLL) , 1L) < p_55)))
            { /* block id: 222 */
                const uint32_t l_475[7] = {6UL,1UL,1UL,6UL,1UL,1UL,6UL};
                int i;
                for (g_100 = 0; (g_100 <= 0); g_100 += 1)
                { /* block id: 225 */
                    return l_475[3];
                }
                if (l_476)
                    break;
            }
            else
            { /* block id: 229 */
                for (g_146 = (-7); (g_146 != 23); g_146 = safe_add_func_int16_t_s_s(g_146, 5))
                { /* block id: 232 */
                    g_131 = ((*g_362) = l_479);
                }
            }
        }
    }
    else
    { /* block id: 281 */
        if (g_100)
            goto lbl_560;
    }
    return (*l_452);
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_77 g_52.f0 g_90 g_93 g_95 g_98 g_100 g_52
 * writes: g_90 g_93 g_98 g_100 g_126 g_77 g_131
 */
static int32_t * func_58(int32_t * p_59, uint16_t  p_60, int32_t * p_61)
{ /* block id: 12 */
    uint16_t *l_89 = &g_90[3][5];
    int8_t l_91 = 0xE0L;
    int64_t *l_92 = &g_93;
    int64_t *l_94[3][6] = {{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95}};
    int32_t l_96 = (-4L);
    int32_t *l_97 = &g_98[1][5][8];
    int32_t *l_99 = &g_100;
    int64_t l_114[7] = {0x79AB5F6EBE0C2A5ALL,0x71B4AC46EA07D533LL,0x79AB5F6EBE0C2A5ALL,0x79AB5F6EBE0C2A5ALL,0x71B4AC46EA07D533LL,0x79AB5F6EBE0C2A5ALL,0x79AB5F6EBE0C2A5ALL};
    int32_t **l_124 = &l_97;
    uint32_t *l_125 = &g_126;
    int16_t *l_127 = &g_77[1][7][0];
    int32_t l_161 = 0L;
    uint32_t l_164 = 4294967295UL;
    int32_t l_211 = 1L;
    int32_t l_212 = (-1L);
    int32_t l_215 = 0x43F57621L;
    uint32_t l_219[1];
    uint32_t l_271[2][1][3] = {{{0x239F2672L,0x239F2672L,18446744073709551615UL}},{{0x239F2672L,0x239F2672L,18446744073709551615UL}}};
    uint16_t l_318 = 0x1FFFL;
    uint8_t l_375 = 1UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_219[i] = 0x4A3F93A2L;
    (*l_99) |= ((((*l_97) &= (((safe_lshift_func_int8_t_s_u(((l_96 |= ((*l_92) |= (((((safe_mod_func_int64_t_s_s((safe_add_func_int8_t_s_s(0x81L, (((safe_rshift_func_uint8_t_u_u(0x0FL, ((g_31 != (1L >= 7UL)) != g_77[1][7][0]))) || (g_52.f0 < 0x01L)) != ((*l_89) ^= g_77[1][7][0])))), l_91)) , (*p_61)) , (*p_61)) < l_91) >= 0UL))) , g_95), l_91)) & p_60) != p_60)) , 255UL) ^ (-1L));
    if (((safe_rshift_func_uint8_t_u_s((0UL > (safe_add_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u((((((*l_127) = (((safe_sub_func_uint32_t_u_u((((((safe_rshift_func_int16_t_s_s(((!6UL) , (*l_99)), 3)) < ((g_52 , g_95) == ((*l_125) = (((*l_124) = ((l_114[3] >= (safe_div_func_uint16_t_u_u(((g_98[0][6][3] , (~(p_60 && (safe_add_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(((safe_sub_func_int16_t_s_s(0L, 65535UL)) | 0UL), (*l_99))), (-3L)))))) || 0xD851L), 0xD7FBL))) , &g_100)) != p_59)))) > 1UL) , 0UL) && (*p_61)), p_60)) == p_60) , 1L)) > p_60) , (*l_124)) != (void*)0), (*l_99))), p_60))), 5)) < g_98[1][5][8]))
    { /* block id: 21 */
        struct S0 *l_130 = &g_131;
        struct S0 l_132 = {0xC66F32F13A919A52LL};
        for (p_60 = 21; (p_60 > 4); p_60 = safe_sub_func_uint64_t_u_u(p_60, 6))
        { /* block id: 24 */
            (*l_99) |= 0xB4C71692L;
        }
        l_132 = ((*l_130) = g_52);
    }
    else
    { /* block id: 29 */
        uint8_t l_136 = 0x0DL;
        int32_t l_144 = (-1L);
        int64_t **l_145[8][6] = {{&l_94[0][1],&l_94[2][2],(void*)0,(void*)0,&l_94[2][2],&l_94[0][3]},{&l_94[2][4],&l_94[0][3],(void*)0,&l_94[0][3],&l_94[2][4],&l_92},{&l_92,&l_94[0][3],&l_94[0][1],&l_94[0][0],&l_94[2][2],&l_94[0][0]},{&l_92,&l_94[2][2],&l_92,&l_94[0][3],&l_94[0][1],&l_94[0][0]},{&l_94[2][4],&l_92,&l_94[0][1],(void*)0,&l_94[0][1],&l_92},{&l_94[0][1],&l_94[2][2],(void*)0,(void*)0,&l_94[2][2],&l_94[0][3]},{&l_94[2][4],&l_94[0][3],(void*)0,&l_94[0][3],&l_94[2][4],&l_92},{&l_92,&l_94[0][3],&l_94[0][1],&l_94[0][0],&l_94[2][2],&l_94[0][0]}};
        int32_t l_152 = (-1L);
        const uint16_t *l_156 = &g_90[3][2];
        const uint16_t **l_155[1][4][5] = {{{&l_156,&l_156,&l_156,&l_156,&l_156},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_156,&l_156,&l_156,&l_156,&l_156},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
        int32_t l_226 = (-1L);
        int32_t l_229 = 5L;
        int32_t l_230 = 1L;
        uint32_t *l_262 = &g_146;
        struct S0 *l_266 = &g_131;
        uint8_t *l_351 = &l_136;
        uint8_t **l_350[4][3][4] = {{{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351}},{{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351}},{{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351}},{{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351},{&l_351,&l_351,&l_351,&l_351}}};
        int i, j, k;
    }
    return p_61;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_52.f0, "g_52.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_77[i][j][k], "g_77[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_90[i][j], "g_90[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_98[i][j][k], "g_98[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_131.f0, "g_131.f0", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    transparent_crc(g_231, "g_231", print_hash_value);
    transparent_crc(g_242, "g_242", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_357[i][j], "g_357[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_358, "g_358", print_hash_value);
    transparent_crc(g_392, "g_392", print_hash_value);
    transparent_crc(g_441, "g_441", print_hash_value);
    transparent_crc(g_527, "g_527", print_hash_value);
    transparent_crc(g_558, "g_558", print_hash_value);
    transparent_crc(g_888, "g_888", print_hash_value);
    transparent_crc(g_898, "g_898", print_hash_value);
    transparent_crc(g_908, "g_908", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_971[i], "g_971[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1003[i], "g_1003[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1057, "g_1057", print_hash_value);
    transparent_crc(g_1060, "g_1060", print_hash_value);
    transparent_crc(g_1080, "g_1080", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1128[i], "g_1128[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1151[i][j][k], "g_1151[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1173, "g_1173", print_hash_value);
    transparent_crc(g_1189, "g_1189", print_hash_value);
    transparent_crc(g_1276, "g_1276", print_hash_value);
    transparent_crc(g_1458, "g_1458", print_hash_value);
    transparent_crc(g_1501, "g_1501", print_hash_value);
    transparent_crc(g_1555, "g_1555", print_hash_value);
    transparent_crc(g_1569, "g_1569", print_hash_value);
    transparent_crc(g_1658.f0, "g_1658.f0", print_hash_value);
    transparent_crc(g_1766, "g_1766", print_hash_value);
    transparent_crc(g_1992, "g_1992", print_hash_value);
    transparent_crc(g_2030, "g_2030", print_hash_value);
    transparent_crc(g_2043, "g_2043", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_2343[i][j][k], "g_2343[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_2603[i][j], "g_2603[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2737, "g_2737", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2776[i], "g_2776[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2786, "g_2786", print_hash_value);
    transparent_crc(g_2791, "g_2791", print_hash_value);
    transparent_crc(g_2863, "g_2863", print_hash_value);
    transparent_crc(g_2975, "g_2975", print_hash_value);
    transparent_crc(g_3053, "g_3053", print_hash_value);
    transparent_crc(g_3114, "g_3114", print_hash_value);
    transparent_crc(g_3118, "g_3118", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3155[i], "g_3155[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 797
   depth: 1, occurrence: 55
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 274
   depth: 2, occurrence: 90
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 18, occurrence: 2
   depth: 19, occurrence: 5
   depth: 21, occurrence: 3
   depth: 22, occurrence: 4
   depth: 23, occurrence: 5
   depth: 24, occurrence: 3
   depth: 25, occurrence: 4
   depth: 27, occurrence: 1
   depth: 29, occurrence: 2
   depth: 30, occurrence: 6
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 36, occurrence: 1
   depth: 38, occurrence: 2
   depth: 40, occurrence: 1
   depth: 41, occurrence: 1

XXX total number of pointers: 547

XXX times a variable address is taken: 1571
XXX times a pointer is dereferenced on RHS: 433
breakdown:
   depth: 1, occurrence: 335
   depth: 2, occurrence: 75
   depth: 3, occurrence: 17
   depth: 4, occurrence: 6
XXX times a pointer is dereferenced on LHS: 449
breakdown:
   depth: 1, occurrence: 401
   depth: 2, occurrence: 43
   depth: 3, occurrence: 5
XXX times a pointer is compared with null: 54
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 27
XXX times a pointer is qualified to be dereferenced: 10475

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2970
   level: 2, occurrence: 448
   level: 3, occurrence: 129
   level: 4, occurrence: 90
   level: 5, occurrence: 2
XXX number of pointers point to pointers: 212
XXX number of pointers point to scalars: 315
XXX number of pointers point to structs: 20
XXX percent of pointers has null in alias set: 28
XXX average alias set size: 1.54

XXX times a non-volatile is read: 2630
XXX times a non-volatile is write: 1340
XXX times a volatile is read: 179
XXX    times read thru a pointer: 135
XXX times a volatile is write: 40
XXX    times written thru a pointer: 20
XXX times a volatile is available for access: 1.27e+03
XXX percentage of non-volatile access: 94.8

XXX forward jumps: 2
XXX backward jumps: 12

XXX stmts: 296
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 29
   depth: 2, occurrence: 39
   depth: 3, occurrence: 51
   depth: 4, occurrence: 61
   depth: 5, occurrence: 88

XXX percentage a fresh-made variable is used: 16.3
XXX percentage an existing variable is used: 83.7
********************* end of statistics **********************/

