/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2130180488
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U5 {
   volatile unsigned f0 : 25;
   int32_t  f1;
   int8_t * const  f2;
   const volatile int64_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_2[2][8][4] = {{{0x43836745L,4294967295UL,0x809B4AF7L,0x809B4AF7L},{0x5741311EL,0x5741311EL,0x43836745L,0x809B4AF7L},{4294967290UL,4294967295UL,4294967290UL,0x43836745L},{4294967290UL,0x43836745L,0x43836745L,4294967290UL},{0x5741311EL,0x43836745L,0x809B4AF7L,0x43836745L},{0x43836745L,4294967295UL,0x809B4AF7L,0x809B4AF7L},{0x5741311EL,0x5741311EL,0x43836745L,0x809B4AF7L},{4294967290UL,4294967295UL,4294967290UL,0x43836745L}},{{4294967290UL,0x43836745L,0x43836745L,4294967290UL},{0x5741311EL,0x43836745L,0x809B4AF7L,0x43836745L},{0x43836745L,4294967295UL,0x809B4AF7L,0x809B4AF7L},{0x5741311EL,0x5741311EL,4294967290UL,4294967295UL},{0x809B4AF7L,0x5741311EL,0x809B4AF7L,4294967290UL},{0x809B4AF7L,4294967290UL,4294967290UL,0x809B4AF7L},{0x43836745L,4294967290UL,4294967295UL,4294967290UL},{4294967290UL,0x5741311EL,4294967295UL,4294967295UL}}};
static int32_t g_4[8][10] = {{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L},{0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L,0x7FC0336AL,0x7FC0336AL,0x52E4A6B2L,0x0A117216L,0x52E4A6B2L}};
static union U5 g_5 = {5UL};/* VOLATILE GLOBAL g_5 */


/* --- FORWARD DECLARATIONS --- */
static union U5  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5
 * writes: g_4
 */
static union U5  func_1(void)
{ /* block id: 0 */
    int32_t *l_3 = &g_4[7][0];
    (*l_3) = g_2[1][5][1];
    return g_5;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_4[i][j], "g_4[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_5.f0, "g_5.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 2
XXX total union variables: 1

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 1
breakdown:
   indirect level: 0, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 1
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 1
breakdown:
   depth: 1, occurrence: 3

XXX total number of pointers: 3

XXX times a variable address is taken: 1
XXX times a pointer is dereferenced on RHS: 0
breakdown:
XXX times a pointer is dereferenced on LHS: 1
breakdown:
   depth: 1, occurrence: 1
XXX times a pointer is compared with null: 0
XXX times a pointer is compared with address of another variable: 0
XXX times a pointer is compared with another pointer: 0
XXX times a pointer is qualified to be dereferenced: 0

XXX max dereference level: 1
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1
XXX number of pointers point to pointers: 0
XXX number of pointers point to scalars: 3
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 0
XXX average alias set size: 1

XXX times a non-volatile is read: 2
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 100
XXX percentage an existing variable is used: 0
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

