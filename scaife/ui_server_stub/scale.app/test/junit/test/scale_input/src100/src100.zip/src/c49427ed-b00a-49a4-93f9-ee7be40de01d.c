/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      392740751
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int64_t  f0;
   volatile unsigned f1 : 11;
   unsigned f2 : 21;
};

#pragma pack(push)
#pragma pack(1)
struct S1 {
   volatile uint16_t  f0;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static uint16_t g_13[5] = {0UL,0UL,0UL,0UL,0UL};
static int16_t g_17 = 1L;
static uint32_t g_37 = 0x74307976L;
static struct S0 g_49 = {0x574417F95E19F8C5LL,30,15};/* VOLATILE GLOBAL g_49 */
static uint64_t g_60 = 0x133D4965DA1F7977LL;
static volatile uint64_t g_77[9][6] = {{18446744073709551612UL,18446744073709551612UL,0x9E59FA6B86D5672FLL,0UL,8UL,0x5FEC6B039B7C392ALL},{0x247AFAE861E80F96LL,0x3944077424270207LL,0xA558E0D3184BAFC8LL,0x9E59FA6B86D5672FLL,0x89B64D43D039428FLL,0x9E59FA6B86D5672FLL},{0xA558E0D3184BAFC8LL,0x247AFAE861E80F96LL,0xA558E0D3184BAFC8LL,18446744073709551608UL,18446744073709551612UL,0x5FEC6B039B7C392ALL},{0UL,18446744073709551608UL,0x9E59FA6B86D5672FLL,1UL,0x6799626DAC17B1ABLL,0x6799626DAC17B1ABLL},{1UL,0x6799626DAC17B1ABLL,0x6799626DAC17B1ABLL,1UL,0x9E59FA6B86D5672FLL,18446744073709551608UL},{0UL,0x5FEC6B039B7C392ALL,18446744073709551612UL,18446744073709551608UL,0xA558E0D3184BAFC8LL,0x247AFAE861E80F96LL},{0xA558E0D3184BAFC8LL,0x9E59FA6B86D5672FLL,0x89B64D43D039428FLL,0x9E59FA6B86D5672FLL,0xA558E0D3184BAFC8LL,8UL},{0UL,0x6799626DAC17B1ABLL,0x89B64D43D039428FLL,18446744073709551608UL,0x247AFAE861E80F96LL,0x9E59FA6B86D5672FLL},{0x9E59FA6B86D5672FLL,1UL,0x6799626DAC17B1ABLL,0x6799626DAC17B1ABLL,1UL,0x9E59FA6B86D5672FLL}};
static volatile struct S0 g_80[3][3][7] = {{{{0x4096A604C9466B01LL,11,230},{0x15503957630D1EF0LL,40,481},{0x34983969C113E7BELL,43,1232},{0L,12,1158},{0x37236CF92AC6B8A9LL,37,184},{-1L,24,696},{0x4096A604C9466B01LL,11,230}},{{-10L,36,1134},{0L,12,1158},{0x15503957630D1EF0LL,40,481},{0x37236CF92AC6B8A9LL,37,184},{0x7B07E043BC77BB9FLL,16,1396},{0x37236CF92AC6B8A9LL,37,184},{0x15503957630D1EF0LL,40,481}},{{0L,12,1158},{0L,12,1158},{-7L,5,1261},{0L,0,207},{0x9097B3892EBBAE66LL,18,938},{0x4AADAB70C6870442LL,32,1055},{-1L,19,987}}},{{{0x59084C010B496A2ALL,29,1238},{0x15503957630D1EF0LL,40,481},{1L,44,192},{0x59084C010B496A2ALL,29,1238},{0xAB26C3A74F57033CLL,3,625},{0L,25,963},{0L,0,207}},{{9L,14,960},{0x9097B3892EBBAE66LL,18,938},{0xAB26C3A74F57033CLL,3,625},{0x37236CF92AC6B8A9LL,37,184},{0x9097B3892EBBAE66LL,18,938},{-10L,36,1134},{1L,44,192}},{{-1L,19,987},{0xC6DFA21EB82DDC79LL,2,778},{0x4AADAB70C6870442LL,32,1055},{0x7B07E043BC77BB9FLL,16,1396},{0x7B07E043BC77BB9FLL,16,1396},{0x4AADAB70C6870442LL,32,1055},{0xC6DFA21EB82DDC79LL,2,778}}},{{{-1L,19,987},{1L,44,192},{-10L,36,1134},{0x9097B3892EBBAE66LL,18,938},{0x37236CF92AC6B8A9LL,37,184},{0xAB26C3A74F57033CLL,3,625},{0x9097B3892EBBAE66LL,18,938}},{{9L,14,960},{0L,0,207},{0L,25,963},{0xAB26C3A74F57033CLL,3,625},{0x59084C010B496A2ALL,29,1238},{1L,44,192},{0x15503957630D1EF0LL,40,481}},{{0x59084C010B496A2ALL,29,1238},{-1L,19,987},{0x4AADAB70C6870442LL,32,1055},{0x9097B3892EBBAE66LL,18,938},{0L,0,207},{-7L,5,1261},{0L,12,1158}}}};
static struct S0 g_83 = {-7L,24,454};/* VOLATILE GLOBAL g_83 */
static struct S0 *g_82 = &g_83;
static int32_t g_88[3][7] = {{(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)},{(-9L),0xEB5E7B38L,(-9L),0xEB5E7B38L,(-9L),0xEB5E7B38L,(-9L)},{(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)}};
static const int32_t *g_87[2] = {&g_88[1][2],&g_88[1][2]};
static uint32_t g_99 = 0x6D1E2CAAL;
static int32_t g_103 = (-10L);
static int32_t ** volatile g_121[4][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
static volatile int64_t *g_123 = (void*)0;
static uint32_t g_128 = 0xBE99D439L;
static uint32_t *g_130 = (void*)0;
static uint64_t g_137 = 0x01195FD4EE7BA79BLL;
static struct S1 g_144 = {0xC3BBL};/* VOLATILE GLOBAL g_144 */
static struct S1 * volatile g_145 = &g_144;/* VOLATILE GLOBAL g_145 */
static volatile struct S1 g_158[5] = {{0xB59FL},{0xB59FL},{0xB59FL},{0xB59FL},{0xB59FL}};
static uint32_t g_195[6] = {0xE50C56BDL,0xE50C56BDL,0xE50C56BDL,0xE50C56BDL,0xE50C56BDL,0xE50C56BDL};
static int64_t g_210 = 0x0662998B48CC5D8ELL;
static struct S1 ** volatile g_311 = (void*)0;/* VOLATILE GLOBAL g_311 */
static int16_t g_316 = 5L;
static struct S1 g_333 = {0xD128L};/* VOLATILE GLOBAL g_333 */
static volatile uint32_t * const *g_343 = (void*)0;
static volatile uint32_t * const * volatile *g_342 = &g_343;
static int64_t g_345 = 1L;
static int32_t *g_366 = &g_88[1][2];
static int32_t ** volatile g_365 = &g_366;/* VOLATILE GLOBAL g_365 */
static struct S1 *g_381 = &g_144;
static struct S1 **g_380 = &g_381;
static uint8_t g_384 = 0x90L;
static uint16_t g_386[10][8][1] = {{{0UL},{0xFF3FL},{0UL},{1UL},{0xB3D6L},{0UL},{0xC27EL},{0UL}},{{0xB3D6L},{1UL},{0UL},{0xFF3FL},{0UL},{1UL},{0xB3D6L},{0UL}},{{0xC27EL},{0UL},{0xB3D6L},{1UL},{0UL},{0xFF3FL},{0UL},{1UL}},{{0xB3D6L},{0UL},{0xC27EL},{0UL},{0xB3D6L},{1UL},{0UL},{0xFF3FL}},{{0UL},{1UL},{0xB3D6L},{0UL},{0xC27EL},{0UL},{0xB3D6L},{1UL}},{{0UL},{0xFF3FL},{0UL},{1UL},{0xB3D6L},{0UL},{0xC27EL},{0UL}},{{0xB3D6L},{1UL},{0UL},{0xFF3FL},{0UL},{1UL},{0xB3D6L},{0UL}},{{0xC27EL},{0UL},{0xB3D6L},{1UL},{0UL},{0xFF3FL},{0UL},{1UL}},{{0xB3D6L},{0UL},{0xC27EL},{0UL},{0xB3D6L},{1UL},{0UL},{0xFF3FL}},{{0UL},{0x019CL},{1UL},{0xFF3FL},{0xB3D6L},{0xFF3FL},{1UL},{0x019CL}}};
static struct S0 g_392 = {0x931F43052055CDA7LL,21,1250};/* VOLATILE GLOBAL g_392 */
static int8_t g_399 = 0xD3L;
static struct S1 g_400 = {0xF9B6L};/* VOLATILE GLOBAL g_400 */
static const struct S0 g_540 = {4L,24,136};/* VOLATILE GLOBAL g_540 */
static uint64_t g_569 = 5UL;
static uint8_t g_668 = 0UL;
static int64_t g_671 = (-1L);
static volatile int16_t g_690 = (-10L);/* VOLATILE GLOBAL g_690 */
static struct S1 g_703[3][7] = {{{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L}},{{0xA9CFL},{0UL},{0xA9CFL},{0UL},{0xA9CFL},{0UL},{0xA9CFL}},{{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L},{0x3F37L}}};
static uint32_t g_729 = 0x32D63910L;
static struct S1 g_733 = {1UL};/* VOLATILE GLOBAL g_733 */
static int32_t ** const  volatile g_739 = &g_366;/* VOLATILE GLOBAL g_739 */
static uint32_t * const **g_749 = (void*)0;
static uint32_t * const ***g_748 = &g_749;
static struct S1 g_751 = {0UL};/* VOLATILE GLOBAL g_751 */
static struct S0 g_778 = {9L,37,248};/* VOLATILE GLOBAL g_778 */
static volatile struct S1 g_782[5][2] = {{{0x0F7FL},{0x44CDL}},{{0x0F7FL},{0x44CDL}},{{0x0F7FL},{0x44CDL}},{{0x0F7FL},{0x44CDL}},{{0x0F7FL},{0x44CDL}}};
static uint16_t g_792 = 7UL;
static int8_t g_797 = 0xABL;
static uint32_t g_836[3][10] = {{4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL,4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL},{4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL,4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL},{4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL,4294967295UL,0x0F87294FL,1UL,1UL,0x0F87294FL}};
static volatile struct S1 g_863 = {65529UL};/* VOLATILE GLOBAL g_863 */
static uint64_t * volatile g_867 = &g_60;/* VOLATILE GLOBAL g_867 */
static uint64_t * volatile *g_866 = &g_867;
static int32_t ** volatile g_934 = &g_366;/* VOLATILE GLOBAL g_934 */
static struct S1 g_940[3] = {{0x7393L},{0x7393L},{0x7393L}};
static volatile struct S0 *g_959 = &g_80[2][2][0];
static uint64_t **g_968 = (void*)0;
static int32_t ** volatile g_974 = &g_366;/* VOLATILE GLOBAL g_974 */
static int32_t * volatile g_978 = &g_103;/* VOLATILE GLOBAL g_978 */
static int32_t g_998 = (-1L);
static volatile struct S1 g_1006 = {0xE941L};/* VOLATILE GLOBAL g_1006 */
static volatile struct S0 g_1016 = {0xA27B5C0EAA1BC4FCLL,11,1132};/* VOLATILE GLOBAL g_1016 */
static uint32_t **g_1032 = &g_130;
static uint32_t ***g_1031 = &g_1032;
static uint32_t ****g_1030 = &g_1031;
static int32_t ** volatile g_1043 = &g_366;/* VOLATILE GLOBAL g_1043 */
static const uint8_t g_1051[10][8] = {{0x90L,0x70L,7UL,0x0DL,7UL,0x70L,0x90L,1UL},{0UL,0x0DL,0x8CL,250UL,247UL,255UL,250UL,0x90L},{5UL,1UL,0x70L,0x4EL,247UL,0xA4L,0xECL,0x0DL},{0UL,1UL,0x4EL,0x90L,7UL,0xB7L,1UL,0xA4L},{0x90L,247UL,0xB3L,0x86L,0x86L,0xB3L,247UL,0x90L},{0x70L,0xD6L,0xECL,1UL,1UL,7UL,5UL,250UL},{0x86L,0xF2L,0x4EL,0x0DL,1UL,7UL,0xE0L,0xECL},{0xE0L,0xD6L,0UL,0x0DL,0xD6L,0xB3L,250UL,1UL},{0xECL,247UL,1UL,0xB7L,250UL,0xB7L,1UL,247UL},{0x86L,1UL,7UL,0xD6L,5UL,0xA4L,0x0DL,5UL}};
static const uint8_t *g_1050 = &g_1051[7][0];
static const uint8_t **g_1049 = &g_1050;
static const uint8_t **g_1052 = &g_1050;
static uint8_t g_1060 = 0x1BL;
static volatile uint32_t g_1077[9] = {4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL};


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int8_t  func_4(uint16_t  p_5, int64_t  p_6);
static uint8_t  func_22(uint64_t  p_23, uint32_t  p_24, int16_t * p_25, int16_t * const  p_26);
static int16_t * const  func_28(int16_t * p_29, int16_t * const  p_30, int16_t * p_31);
static int16_t * func_32(const int16_t * p_33);
static const int16_t * func_34(int16_t * const  p_35);
static int32_t  func_40(uint32_t * p_41, const uint32_t  p_42, uint16_t  p_43);
static uint32_t * func_44(struct S0 * p_45, uint16_t  p_46, int32_t  p_47);
static uint32_t * func_51(uint8_t  p_52, struct S0 * p_53, int16_t * const  p_54, int16_t  p_55);
static int16_t  func_70(int64_t  p_71, int16_t * const  p_72, const uint64_t * const  p_73);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_17 g_37 g_60 g_49.f0 g_77 g_80 g_82 g_83.f0 g_49.f1 g_49.f2 g_88 g_103 g_137 g_158.f0 g_128 g_392 g_130 g_384 g_316 g_366 g_365 g_400 g_739 g_99 g_399 g_748 g_751 g_195 g_668 g_386 g_978 g_782.f0 g_778.f2 g_866 g_867 g_1006 g_1016 g_1030 g_210 g_1043 g_1050 g_1051 g_797 g_671 g_1060 g_778.f0 g_569 g_1077
 * writes: g_17 g_37 g_60 g_49.f0 g_77 g_80 g_87 g_83.f0 g_99 g_88 g_103 g_128 g_83 g_316 g_384 g_366 g_392.f0 g_748 g_399 g_668 g_792 g_998 g_345 g_1030 g_1049 g_1052 g_1060 g_1077
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t *l_16 = &g_17;
    int32_t l_27 = 0x5A63A74AL;
    uint64_t l_1056[7];
    int32_t l_1057 = (-2L);
    uint8_t *l_1071 = (void*)0;
    uint8_t **l_1070 = &l_1071;
    uint8_t ***l_1069 = &l_1070;
    int32_t *l_1074 = &g_88[1][2];
    int32_t l_1075 = 0x84F0914DL;
    int32_t *l_1076[7];
    int i;
    for (i = 0; i < 7; i++)
        l_1056[i] = 0xDA12322767DE6BEBLL;
    for (i = 0; i < 7; i++)
        l_1076[i] = &l_27;
    g_1060 ^= (safe_div_func_int8_t_s_s(func_4(((safe_sub_func_int8_t_s_s((safe_lshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((((((g_13[2] & (safe_add_func_int32_t_s_s(((((*l_16) |= g_13[2]) && (safe_mul_func_int16_t_s_s(((g_17 >= (safe_add_func_uint8_t_u_u(func_22(l_27, l_27, l_16, func_28(func_32(func_34(&g_17)), &g_17, l_16)), 0UL))) != 0xE1L), l_27))) || l_27), 1UL))) & 0UL) >= l_27) , l_1056[4]) >= l_1057), g_797)), 11)), g_671)) < l_1056[5]), g_13[1]), (-5L)));
    l_1075 = ((l_1056[4] || ((*l_1074) = (safe_add_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s((safe_add_func_uint16_t_u_u((0x46L == (((l_1056[6] | (l_1056[1] , (((safe_mul_func_int16_t_s_s((((((-4L) == (l_1057 || ((void*)0 != l_1069))) == (safe_mul_func_int16_t_s_s((0UL && l_27), g_158[4].f0))) , l_1056[2]) , g_137), l_27)) != g_778.f0) , 0x40B7D263ED2A2628LL))) , 0x86L) ^ 0x6DL)), 2UL)), g_569)), l_1056[4])))) , (-1L));
    g_1077[8]--;
    return g_49.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_103
 * writes: g_103
 */
static int8_t  func_4(uint16_t  p_5, int64_t  p_6)
{ /* block id: 449 */
    for (g_103 = (-22); (g_103 < (-12)); ++g_103)
    { /* block id: 452 */
        return p_6;
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_1050 g_1051
 * writes:
 */
static uint8_t  func_22(uint64_t  p_23, uint32_t  p_24, int16_t * p_25, int16_t * const  p_26)
{ /* block id: 446 */
    int32_t *l_1054[8] = {(void*)0,&g_88[1][2],(void*)0,&g_88[1][2],(void*)0,&g_88[1][2],(void*)0,&g_88[1][2]};
    int32_t **l_1055 = (void*)0;
    int i;
    l_1054[0] = l_1054[2];
    return (*g_1050);
}


/* ------------------------------------------ */
/* 
 * reads : g_399 g_748 g_37 g_751 g_195 g_392.f0 g_99 g_88 g_668 g_386 g_366 g_978 g_103 g_782.f0 g_778.f2 g_17 g_866 g_867 g_1006 g_392.f2 g_128 g_1016 g_82 g_1030 g_49.f1 g_210 g_1043 g_49.f0
 * writes: g_49.f0 g_392.f0 g_99 g_748 g_88 g_37 g_399 g_668 g_792 g_103 g_316 g_998 g_60 g_345 g_128 g_83 g_1030 g_366 g_1049 g_1052
 */
static int16_t * const  func_28(int16_t * p_29, int16_t * const  p_30, int16_t * p_31)
{ /* block id: 286 */
    int32_t l_764 = 0x243D9458L;
    uint32_t **l_784 = (void*)0;
    uint32_t ***l_783 = &l_784;
    int32_t l_821 = 0x71B5C714L;
    int32_t l_829 = (-8L);
    int32_t l_831[8];
    int32_t l_833 = (-10L);
    uint32_t l_840[9];
    struct S0 *l_854 = &g_49;
    uint16_t **l_900 = (void*)0;
    uint16_t l_935[3][6] = {{6UL,0x1E09L,6UL,0x1E09L,6UL,0x1E09L},{0x4D02L,0x1E09L,0x4D02L,0x1E09L,0x4D02L,0x1E09L},{6UL,0x1E09L,6UL,0x1E09L,6UL,0x1E09L}};
    uint64_t l_956 = 0UL;
    uint32_t l_976 = 9UL;
    int64_t *l_1013[9] = {&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0,&g_778.f0};
    int64_t l_1018 = 9L;
    int64_t l_1020[2][7] = {{0x45B51AE2FE4FB1B1LL,(-10L),0x45B51AE2FE4FB1B1LL,0x45B51AE2FE4FB1B1LL,(-10L),0x45B51AE2FE4FB1B1LL,0x45B51AE2FE4FB1B1LL},{(-10L),(-10L),0x7C1179AAD7115735LL,(-10L),(-10L),0x7C1179AAD7115735LL,(-10L)}};
    const uint64_t *l_1041 = &g_569;
    const uint64_t **l_1040 = &l_1041;
    const uint64_t ***l_1039 = &l_1040;
    uint64_t ***l_1042[5];
    const uint8_t *l_1045 = (void*)0;
    const uint8_t **l_1044[7] = {&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045,&l_1045};
    const uint8_t ***l_1046 = &l_1044[3];
    const uint8_t **l_1048 = &l_1045;
    const uint8_t ***l_1047[8];
    int16_t * const l_1053 = &g_17;
    int i, j;
    for (i = 0; i < 8; i++)
        l_831[i] = (-6L);
    for (i = 0; i < 9; i++)
        l_840[i] = 4294967291UL;
    for (i = 0; i < 5; i++)
        l_1042[i] = &g_968;
    for (i = 0; i < 8; i++)
        l_1047[i] = &l_1048;
lbl_845:
    for (g_49.f0 = 2; (g_49.f0 >= 0); g_49.f0 -= 1)
    { /* block id: 289 */
        uint8_t l_741 = 0xFEL;
        int32_t *l_785 = &g_103;
        uint64_t *l_815 = &g_569;
        const int32_t *l_819 = &g_103;
        int32_t l_825 = 0xC1E3F01EL;
        int32_t l_830[4][2] = {{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)}};
        int64_t l_835[6][3][4] = {{{4L,0x0FA4114D3D39CC59LL,4L,1L},{1L,0x73070C8026C881C3LL,4L,0L},{4L,0L,4L,0x73070C8026C881C3LL}},{{1L,1L,4L,0x0FA4114D3D39CC59LL},{4L,0x0FA4114D3D39CC59LL,4L,1L},{1L,0x73070C8026C881C3LL,4L,0L}},{{4L,0L,4L,0x73070C8026C881C3LL},{1L,1L,4L,0x0FA4114D3D39CC59LL},{4L,0x0FA4114D3D39CC59LL,4L,1L}},{{1L,0x73070C8026C881C3LL,4L,0L},{4L,0L,4L,0x73070C8026C881C3LL},{1L,1L,4L,0x0FA4114D3D39CC59LL}},{{4L,0x0FA4114D3D39CC59LL,4L,1L},{1L,0x73070C8026C881C3LL,4L,0L},{4L,0L,4L,0x73070C8026C881C3LL}},{{1L,1L,4L,0x0FA4114D3D39CC59LL},{4L,0x0FA4114D3D39CC59LL,4L,1L},{1L,0x73070C8026C881C3LL,4L,0L}}};
        int32_t *l_839[10] = {(void*)0,&l_831[0],(void*)0,(void*)0,(void*)0,(void*)0,&l_831[0],(void*)0,(void*)0,(void*)0};
        int i, j, k;
        for (g_392.f0 = 0; (g_392.f0 <= 2); g_392.f0 += 1)
        { /* block id: 292 */
            int64_t l_761 = 1L;
            const uint32_t *l_763 = &g_99;
            const uint32_t **l_762 = &l_763;
            int32_t *l_786 = &g_88[0][5];
            int32_t l_823 = (-1L);
            int32_t l_824 = (-7L);
            int32_t l_826 = 2L;
            int32_t l_827[5][1][9] = {{{(-1L),(-8L),(-1L),(-1L),(-8L),(-1L),(-1L),(-8L),(-1L)}},{{0x010D3246L,0x4650D37AL,0x010D3246L,0x010D3246L,0x4650D37AL,0x010D3246L,0x010D3246L,0x4650D37AL,0x010D3246L}},{{(-1L),(-8L),(-1L),(-1L),(-8L),(-1L),(-1L),(-8L),(-1L)}},{{0x010D3246L,0x4650D37AL,0x010D3246L,0x010D3246L,0x4650D37AL,0x010D3246L,0x010D3246L,0x4650D37AL,0x010D3246L}},{{(-1L),(-8L),(-1L),(-1L),(-8L),(-1L),(-1L),(-8L),(-1L)}}};
            int16_t l_828 = 0x6F89L;
            int i, j, k;
            for (g_99 = 0; (g_99 <= 2); g_99 += 1)
            { /* block id: 295 */
                uint32_t * const ****l_750 = &g_748;
                int32_t l_754 = 0x9FE32902L;
                uint32_t *l_760 = &g_195[3];
                uint32_t **l_759 = &l_760;
                int8_t *l_781 = &g_399;
                int32_t l_804[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
                int32_t *l_820 = &g_88[1][2];
                int32_t *l_822[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int8_t l_832 = 1L;
                int8_t l_834 = 1L;
                int i, j;
                if (l_741)
                    break;
                g_88[g_392.f0][(g_99 + 3)] &= (safe_mod_func_int16_t_s_s(((safe_mod_func_int32_t_s_s((((((g_399 >= ((((safe_sub_func_uint16_t_u_u((&g_342 != ((*l_750) = g_748)), g_37)) , (g_751 , ((safe_add_func_uint64_t_u_u(l_754, ((void*)0 != &g_87[1]))) , ((safe_mod_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u((((*l_759) = (void*)0) != (void*)0), g_195[3])) != 252UL), l_761)) || 0x894CL)))) >= (-6L)) || 0UL)) , (void*)0) == l_762) && 0x6EL) | 7L), l_764)) < l_761), l_754));
            }
            for (g_37 = 0; (g_37 <= 2); g_37 += 1)
            { /* block id: 323 */
                int i, j;
                g_88[g_392.f0][(g_37 + 3)] ^= 0L;
            }
        }
        l_840[2]++;
    }
    for (g_49.f0 = 0; (g_49.f0 != (-18)); g_49.f0 = safe_sub_func_uint32_t_u_u(g_49.f0, 2))
    { /* block id: 331 */
        int16_t l_868 = 0x9FDCL;
        int32_t l_873[9];
        uint32_t l_893[4][4];
        int16_t * const l_975 = &g_17;
        uint16_t l_991 = 0xF904L;
        int32_t *l_1017[5] = {&l_821,&l_821,&l_821,&l_821,&l_821};
        int16_t l_1019[7][4][9] = {{{0x1A6CL,0x0561L,0xB53FL,(-1L),0x5D10L,0x7D25L,0x5D10L,(-1L),0xB53FL},{(-1L),0x02C2L,0x883AL,(-1L),0xDC23L,(-1L),0x4D0FL,5L,(-1L)},{4L,0L,(-3L),2L,(-1L),0L,0xFB7AL,(-5L),0x6A92L},{0x48A4L,0x967FL,0x883AL,0x6719L,(-1L),0x951CL,0x951CL,(-1L),0x6719L}},{{0x6FB3L,0xEC5AL,0x6FB3L,(-9L),0x5D10L,0x1673L,6L,0x7D25L,(-1L)},{0x02C2L,0x8525L,0x951CL,0x883AL,0x406EL,0x7B0AL,0x82D1L,5L,0x8525L},{0x6A92L,0x0E59L,0x830EL,(-9L),0x793CL,0x0561L,0x1306L,0x0561L,0x793CL},{0xA439L,0x82D1L,0x6F64L,0x6719L,0x02C2L,1L,1L,0xA439L,0L}},{{(-1L),7L,0x5D10L,2L,0x1A6CL,0x0E59L,0x5D10L,0xEC5AL,(-1L)},{0L,0x6719L,1L,(-1L),0x02C2L,0xA439L,0x6F64L,0x6F64L,0xA439L},{0x793CL,0L,0x1306L,0L,0x793CL,0x0E02L,0x830EL,2L,0x6A92L},{0x8525L,1L,0x82D1L,0xFA63L,0x406EL,0x4D0FL,0x951CL,0L,0x02C2L}},{{(-1L),(-5L),6L,0x723BL,0x5D10L,0x0E02L,0x6FB3L,7L,0x6FB3L},{0x6719L,0x48A4L,0x951CL,0xE32AL,(-1L),0xA439L,0x883AL,0xA3FFL,0x48A4L},{0x6A92L,0x7D25L,0xFB7AL,0x0561L,(-1L),0x0E59L,(-3L),0x0561L,4L},{(-1L),1L,0x4D0FL,0x48A4L,0xDC23L,1L,0x883AL,(-1L),(-1L)}},{{0x6FB3L,0x0561L,(-1L),2L,(-1L),0x0561L,0x6FB3L,(-5L),0xB53FL},{(-1L),0x6719L,0x883AL,0x967FL,0x48A4L,0x7B0AL,0x951CL,1L,0xA439L},{4L,0xEC5AL,0xFB7AL,0x0E02L,0xD0E9L,0x1673L,0x830EL,(-5L),(-1L)},{0x02C2L,0x82D1L,0xE32AL,(-1L),0x406EL,0x951CL,0x6F64L,(-1L),0x8525L}},{{0xB53FL,2L,6L,(-9L),0L,0L,0x5D10L,0x0561L,0L},{0x6719L,0x8525L,0x6F64L,0x967FL,(-1L),(-1L),1L,0xA3FFL,0x8525L},{(-1L),7L,(-3L),(-9L),0x6A92L,(-9L),(-3L),0x2FF8L,(-8L)},{(-1L),0x82D1L,0x3156L,0xFA63L,0xDC23L,0x6F64L,(-1L),(-1L),0L}},{{6L,0x7D25L,(-1L),(-5L),6L,0x723BL,0x5D10L,0x0E02L,0x6FB3L},{(-1L),0xDC23L,(-1L),0x883AL,0x02C2L,(-1L),0x4D0FL,1L,0xD072L},{(-8L),2L,0x1306L,0xEC5AL,(-1L),0x1673L,(-2L),(-1L),0x793CL},{0x8525L,0xE32AL,0x883AL,(-1L),0x7B0AL,0x6F64L,5L,0L,0xFA63L}}};
        int32_t l_1021 = 0xBB56D8B6L;
        uint8_t l_1022[6][10] = {{255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL},{1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL},{255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL},{1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL},{255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL,255UL,0x7BL},{1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL,1UL,0x7BL}};
        uint32_t ****l_1029 = &l_783;
        uint32_t *****l_1033 = &g_1030;
        uint32_t ****l_1034 = &g_1031;
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_873[i] = 1L;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 4; j++)
                l_893[i][j] = 9UL;
        }
        for (g_399 = 0; (g_399 >= 0); g_399 -= 1)
        { /* block id: 334 */
            uint64_t l_850 = 1UL;
            const uint64_t l_865[8] = {0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL,0x8DED0FA3C1F2C16FLL};
            int16_t * const l_869 = &g_17;
            int32_t l_871 = 1L;
            int32_t l_874 = 1L;
            uint16_t *l_902 = &g_13[2];
            uint16_t **l_901 = &l_902;
            int8_t l_941 = (-10L);
            int64_t *l_1008 = &g_392.f0;
            int i;
            for (g_668 = 0; (g_668 <= 0); g_668 += 1)
            { /* block id: 337 */
                if (g_668)
                    goto lbl_845;
            }
            for (g_792 = 0; (g_792 <= 1); g_792 += 1)
            { /* block id: 342 */
                int32_t l_872 = 0xC930A3C1L;
                uint32_t l_875 = 0xDC049B30L;
                int32_t *l_881 = &l_833;
                uint8_t *l_945 = &g_384;
                int32_t l_955[1];
                uint64_t *l_970 = &l_956;
                uint64_t **l_969 = &l_970;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_955[i] = 3L;
                if (g_386[(g_399 + 7)][(g_399 + 1)][g_399])
                    break;
            }
            for (g_392.f0 = 0; (g_392.f0 >= 0); g_392.f0 -= 1)
            { /* block id: 408 */
                int32_t *l_977 = (void*)0;
                uint32_t **l_993 = &g_130;
                uint32_t ***l_992 = &l_993;
                int16_t *l_994 = (void*)0;
                int16_t *l_995 = &g_316;
                (*g_978) |= ((*g_366) = 1L);
                if (l_821)
                    continue;
                if ((+(safe_mod_func_int64_t_s_s((safe_sub_func_int16_t_s_s(((l_865[4] | ((safe_mod_func_int16_t_s_s((l_840[8] ^ ((*g_366) = l_831[7])), g_782[4][0].f0)) ^ (((((*l_995) = ((l_840[1] == (~g_778.f2)) , (((*l_783) = &g_130) == ((*l_992) = ((safe_mul_func_int16_t_s_s((l_868 & ((l_991 , l_833) > l_868)), 1L)) , (void*)0))))) , (-6L)) , 0x108676BAL) > l_893[3][2]))) & l_871), 0x785EL)), 0x23E6A2C88408BCE4LL))))
                { /* block id: 416 */
                    int8_t *l_999[2];
                    int32_t **l_1000 = &l_977;
                    uint32_t l_1003[3][4][8] = {{{3UL,0xE3CD992AL,0x1D60CF19L,18446744073709551615UL,0UL,3UL,0xE41F41A0L,0x88158FDBL},{0x8F7B7610L,0x88158FDBL,1UL,0x0E4CA917L,0UL,5UL,0x1D60CF19L,0UL},{0x88158FDBL,0x4CF433D4L,18446744073709551615UL,18446744073709551609UL,4UL,0UL,4UL,18446744073709551609UL},{0x0D907575L,4UL,0x0D907575L,0x1D60CF19L,1UL,8UL,0xD3372299L,0x0D907575L}},{{18446744073709551607UL,0x20CE61D4L,0x873B4208L,0UL,1UL,0xE3CD992AL,1UL,18446744073709551615UL},{18446744073709551607UL,0xA6467D42L,0x1D60CF19L,0x873B4208L,1UL,0x93EB5E05L,0xA6467D42L,0x20CE61D4L},{0x0D907575L,0x88158FDBL,0x20CE61D4L,0x8F7B7610L,4UL,0x0E4CA917L,18446744073709551614UL,18446744073709551614UL},{0x88158FDBL,0UL,18446744073709551615UL,18446744073709551615UL,0UL,0x88158FDBL,0x5601F5C0L,18446744073709551609UL}},{{0x8F7B7610L,18446744073709551609UL,8UL,0x88158FDBL,0UL,5UL,0xD3372299L,18446744073709551615UL},{18446744073709551614UL,0x8F7B7610L,0UL,0x0D907575L,18446744073709551615UL,0x1D60CF19L,0x21197DD1L,0x4CF433D4L},{0UL,18446744073709551615UL,0x8F7B7610L,0x5601F5C0L,3UL,0x20CE61D4L,1UL,0x8F7B7610L},{18446744073709551615UL,0x21197DD1L,3UL,18446744073709551615UL,3UL,18446744073709551615UL,3UL,0x21197DD1L}}};
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_999[i] = (void*)0;
                    (*g_366) &= ((((safe_lshift_func_int16_t_s_s((g_998 = ((*l_995) = (*p_30))), 15)) , l_999[1]) == (void*)0) != 0xA4707339L);
                    (*l_1000) = &l_873[7];
                    (*g_366) &= ((*p_30) >= ((*l_995) = (+((**g_866) = ((*l_977) = (!l_1003[0][1][0]))))));
                }
                else
                { /* block id: 425 */
                    int64_t *l_1007 = &g_345;
                    int32_t l_1014[9] = {(-1L),(-8L),(-8L),(-1L),(-8L),(-8L),(-1L),(-8L),(-8L)};
                    int32_t l_1015[7][3] = {{0x07A5C782L,0x07A5C782L,0x07A5C782L},{0xF94CBA15L,0xBFC1B9FEL,0xF94CBA15L},{0x07A5C782L,0x07A5C782L,0x07A5C782L},{0xF94CBA15L,0xBFC1B9FEL,0xF94CBA15L},{0x07A5C782L,0x07A5C782L,0x07A5C782L},{0xF94CBA15L,0xBFC1B9FEL,0xF94CBA15L},{0x07A5C782L,0x07A5C782L,0x07A5C782L}};
                    int i, j;
                    l_1015[3][1] |= (((*l_1007) = ((g_1006 , l_1007) == l_1008)) | ((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((l_1007 != l_1013[2]), l_1014[8])), 15)) < g_392.f2));
                }
                for (g_128 = 0; (g_128 <= 0); g_128 += 1)
                { /* block id: 431 */
                    (*g_82) = g_1016;
                }
            }
        }
        ++l_1022[1][7];
        (*g_366) = (((safe_add_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((l_1029 == (l_1034 = ((*l_1033) = g_1030))), g_195[5])), ((g_49.f1 >= 0x28EAL) , (safe_sub_func_int64_t_s_s((safe_add_func_int64_t_s_s((l_1039 == l_1042[0]), 5L)), (&l_1021 != &l_1021)))))) > g_210) <= 0x3A3DL);
    }
    (*g_1043) = &l_821;
    g_1052 = (g_1049 = ((*l_1046) = l_1044[5]));
    return l_1053;
}


/* ------------------------------------------ */
/* 
 * reads : g_739
 * writes: g_366
 */
static int16_t * func_32(const int16_t * p_33)
{ /* block id: 282 */
    uint16_t l_735 = 5UL;
    int32_t *l_738 = &g_88[0][4];
    int16_t *l_740 = (void*)0;
    l_735++;
    (*g_739) = l_738;
    return l_740;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_37 g_60 g_49.f0 g_77 g_80 g_17 g_82 g_83.f0 g_49.f1 g_49.f2 g_88 g_103 g_137 g_158.f0 g_128 g_392 g_130 g_384 g_316 g_366 g_365 g_400
 * writes: g_37 g_60 g_49.f0 g_77 g_80 g_87 g_83.f0 g_99 g_88 g_103 g_128 g_83 g_316 g_384 g_366
 */
static const int16_t * func_34(int16_t * const  p_35)
{ /* block id: 2 */
    uint32_t *l_36 = &g_37;
    struct S0 *l_48 = &g_49;
    int64_t l_50 = 0L;
    uint64_t *l_59[5][4] = {{&g_60,&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60,&g_60},{&g_60,&g_60,&g_60,&g_60}};
    int32_t l_61 = (-1L);
    struct S0 **l_396 = &l_48;
    int8_t *l_398 = &g_399;
    struct S1 ***l_403 = &g_380;
    uint8_t *l_412 = &g_384;
    uint8_t l_413 = 1UL;
    uint8_t *l_414 = &l_413;
    int32_t **l_415 = (void*)0;
    int32_t **l_416 = &g_366;
    int32_t l_421 = 0L;
    int64_t l_422[6][9][4] = {{{0x181275483D43F8D3LL,1L,(-1L),(-8L)},{3L,0xD110966B84EDE662LL,0x8BD7C63EB3C3E4DCLL,(-8L)},{8L,1L,8L,1L},{0xE6869287168DBB40LL,1L,0xBFB05631D7939AF1LL,5L},{3L,1L,(-8L),1L},{0x8BD7C63EB3C3E4DCLL,1L,(-8L),0xFDFBBA52F3F660C1LL},{3L,0x0ACFC79905F58DAFLL,0xBFB05631D7939AF1LL,(-8L)},{0xE6869287168DBB40LL,0x4E524CA44B69D266LL,8L,1L},{8L,1L,0x8BD7C63EB3C3E4DCLL,(-1L)}},{{3L,1L,(-1L),1L},{0x181275483D43F8D3LL,0x4E524CA44B69D266LL,(-8L),(-8L)},{0x75CA79990798ED29LL,0x0ACFC79905F58DAFLL,0x8BD7C63EB3C3E4DCLL,0xFDFBBA52F3F660C1LL},{0xE6869287168DBB40LL,1L,(-1L),1L},{0xE6869287168DBB40LL,1L,0x8BD7C63EB3C3E4DCLL,5L},{0x75CA79990798ED29LL,1L,(-8L),1L},{0x181275483D43F8D3LL,1L,(-1L),(-8L)},{3L,0xD110966B84EDE662LL,0x8BD7C63EB3C3E4DCLL,(-8L)},{8L,1L,8L,1L}},{{0xE6869287168DBB40LL,1L,0xBFB05631D7939AF1LL,5L},{3L,1L,(-8L),1L},{0x8BD7C63EB3C3E4DCLL,1L,(-8L),0xFDFBBA52F3F660C1LL},{3L,0x0ACFC79905F58DAFLL,0xBFB05631D7939AF1LL,(-8L)},{0xE6869287168DBB40LL,0x4E524CA44B69D266LL,8L,1L},{8L,1L,0x8BD7C63EB3C3E4DCLL,(-1L)},{3L,1L,(-1L),1L},{0x181275483D43F8D3LL,0x4E524CA44B69D266LL,(-8L),(-8L)},{0x75CA79990798ED29LL,0x0ACFC79905F58DAFLL,0x8BD7C63EB3C3E4DCLL,0xFDFBBA52F3F660C1LL}},{{0xE6869287168DBB40LL,1L,(-1L),1L},{0xE6869287168DBB40LL,1L,0x8BD7C63EB3C3E4DCLL,0xFDFBBA52F3F660C1LL},{0xBFB05631D7939AF1LL,(-1L),0x5B5AC59ABE2777A3LL,0xC53CC7EE489344F5LL},{8L,0xD110966B84EDE662LL,0xDFE44A103A164675LL,0x4E524CA44B69D266LL},{0x8BD7C63EB3C3E4DCLL,0xAC1C3FA0F31A7FE2LL,(-1L),0x4E524CA44B69D266LL},{(-1L),0xD110966B84EDE662LL,(-1L),0xC53CC7EE489344F5LL},{(-8L),(-1L),0xE6869287168DBB40LL,0xFDFBBA52F3F660C1LL},{0x8BD7C63EB3C3E4DCLL,0xC53CC7EE489344F5LL,0x5B5AC59ABE2777A3LL,(-1L)},{(-1L),0xD110966B84EDE662LL,0x5B5AC59ABE2777A3LL,0x95F43F999A675BDBLL}},{{0x8BD7C63EB3C3E4DCLL,1L,0xE6869287168DBB40LL,0x4E524CA44B69D266LL},{(-8L),0x10662D8ED43A3B5ELL,(-1L),(-1L)},{(-1L),(-1L),(-1L),3L},{0x8BD7C63EB3C3E4DCLL,(-1L),0xDFE44A103A164675LL,(-1L)},{8L,0x10662D8ED43A3B5ELL,0x5B5AC59ABE2777A3LL,0x4E524CA44B69D266LL},{0xBFB05631D7939AF1LL,1L,(-1L),0x95F43F999A675BDBLL},{(-8L),0xD110966B84EDE662LL,(-1L),(-1L)},{(-8L),0xC53CC7EE489344F5LL,(-1L),0xFDFBBA52F3F660C1LL},{0xBFB05631D7939AF1LL,(-1L),0x5B5AC59ABE2777A3LL,0xC53CC7EE489344F5LL}},{{8L,0xD110966B84EDE662LL,0xDFE44A103A164675LL,0x4E524CA44B69D266LL},{0x8BD7C63EB3C3E4DCLL,0xAC1C3FA0F31A7FE2LL,(-1L),0x4E524CA44B69D266LL},{(-1L),0xD110966B84EDE662LL,(-1L),0xC53CC7EE489344F5LL},{(-8L),(-1L),0xE6869287168DBB40LL,0xFDFBBA52F3F660C1LL},{0x8BD7C63EB3C3E4DCLL,0xC53CC7EE489344F5LL,0x5B5AC59ABE2777A3LL,(-1L)},{(-1L),0xD110966B84EDE662LL,0x5B5AC59ABE2777A3LL,0x95F43F999A675BDBLL},{0x8BD7C63EB3C3E4DCLL,1L,0xE6869287168DBB40LL,0x4E524CA44B69D266LL},{(-8L),0x10662D8ED43A3B5ELL,(-1L),(-1L)},{(-1L),(-1L),(-1L),3L}}};
    int32_t l_423 = 7L;
    int32_t l_424 = 0L;
    int32_t l_425 = 0x99759896L;
    int32_t l_426[10] = {0xA8FA176EL,0xA8FA176EL,0xF1222FC0L,0xA8FA176EL,0xA8FA176EL,0xF1222FC0L,0xA8FA176EL,0xA8FA176EL,0xF1222FC0L,0xA8FA176EL};
    int64_t l_427 = 1L;
    uint16_t l_429 = 65535UL;
    uint32_t **l_461 = &g_130;
    uint32_t ***l_460 = &l_461;
    uint64_t l_514 = 6UL;
    uint16_t l_539 = 5UL;
    const int16_t *l_734[8][1][10] = {{{&g_17,&g_17,&g_17,&g_17,&g_316,&g_17,&g_17,&g_316,&g_17,&g_316}},{{&g_316,&g_316,&g_316,&g_316,&g_316,&g_316,&g_17,&g_17,&g_17,&g_17}},{{&g_316,(void*)0,&g_17,&g_17,(void*)0,&g_17,&g_316,(void*)0,&g_17,(void*)0}},{{&g_316,(void*)0,&g_316,&g_17,&g_316,(void*)0,&g_316,&g_17,&g_17,&g_316}},{{&g_316,&g_316,&g_316,&g_316,(void*)0,&g_316,&g_17,&g_316,&g_316,&g_17}},{{&g_316,&g_316,&g_316,(void*)0,&g_316,&g_17,&g_316,&g_316,&g_17,(void*)0}},{{&g_316,(void*)0,&g_316,&g_316,&g_17,&g_17,&g_316,&g_316,(void*)0,&g_316}},{{(void*)0,(void*)0,&g_316,&g_17,(void*)0,&g_316,&g_17,&g_316,&g_316,&g_316}}};
    int i, j, k;
    (*l_396) = ((g_13[2] & ((&g_17 == (void*)0) || ((++(*l_36)) >= (func_40(func_44(l_48, (((l_50 , func_51(((4294967295UL != ((void*)0 == p_35)) , ((safe_mod_func_int8_t_s_s((~(g_60--)), (safe_lshift_func_uint16_t_u_u((safe_div_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((func_70(l_61, &g_17, l_59[1][1]) | 0x06E9L) != g_17), l_61)), l_50)), g_13[2])))) < l_50)), g_82, &g_17, l_50)) == l_36) == g_137), l_61), l_61, g_384) > l_61)))) , l_48);
    (*l_416) = func_44(&g_49, (!(l_398 == (void*)0)), (((*l_414) = ((g_400 , 18446744073709551611UL) == ((safe_add_func_uint64_t_u_u(l_50, ((void*)0 == l_403))) , ((safe_rshift_func_uint8_t_u_s(((safe_add_func_int32_t_s_s((safe_div_func_uint8_t_u_u(((*l_412) = (safe_mod_func_int8_t_s_s((g_392.f0 > g_392.f2), 0x68L))), (-4L))), l_61)) <= 0L), l_413)) , 0L)))) , l_413));
    for (l_413 = 0; (l_413 <= 1); l_413 += 1)
    { /* block id: 173 */
        int32_t *l_417 = &g_88[1][5];
        int32_t *l_418 = &g_88[1][5];
        int32_t *l_419 = &g_88[1][2];
        int32_t *l_420[10][8] = {{&g_88[1][3],&g_88[1][3],&g_103,&g_88[2][2],&g_103,&g_88[2][2],&g_103,&g_88[1][3]},{&g_88[1][3],&g_88[1][1],(void*)0,&g_103,&g_103,(void*)0,&g_88[1][1],&g_88[1][3]},{&g_88[1][1],&g_88[0][2],&g_88[1][3],&g_88[2][2],&g_88[1][3],&g_88[0][2],&g_88[1][1],&g_88[1][1]},{&g_88[0][2],&g_88[2][2],(void*)0,(void*)0,&g_88[2][2],&g_88[0][2],&g_103,&g_88[0][2]},{&g_88[2][2],&g_88[0][2],&g_103,&g_88[0][2],&g_88[2][2],(void*)0,(void*)0,&g_88[2][2]},{&g_88[0][2],&g_88[1][1],&g_88[1][1],&g_88[0][2],&g_88[1][3],&g_88[2][2],&g_88[1][3],&g_88[0][2]},{&g_88[1][1],&g_88[1][3],&g_88[1][1],(void*)0,&g_103,&g_103,(void*)0,&g_88[1][1]},{&g_88[1][3],&g_88[1][3],&g_103,&g_88[2][2],&g_103,&g_88[2][2],&g_103,&g_88[1][3]},{&g_88[1][3],&g_88[1][1],(void*)0,&g_103,&g_103,(void*)0,&g_88[1][1],&g_88[1][3]},{&g_88[1][1],&g_88[0][2],&g_88[1][3],&g_88[2][2],&g_88[1][3],&g_88[0][2],&g_88[1][1],&g_88[1][1]}};
        int16_t l_428 = (-1L);
        struct S1 ***l_450[8];
        int8_t l_568 = (-2L);
        struct S0 **l_712 = &l_48;
        const uint64_t l_714[7][7] = {{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL},{0x8B421B77C21E2B8FLL,0x476B6CD2D82D2679LL,2UL,2UL,0x476B6CD2D82D2679LL,0x8B421B77C21E2B8FLL,0xBF154AF4FC41CC9ELL}};
        int i, j;
        for (i = 0; i < 8; i++)
            l_450[i] = &g_380;
        l_429--;
    }
    return l_734[0][0][6];
}


/* ------------------------------------------ */
/* 
 * reads : g_316 g_366 g_88 g_365
 * writes: g_316
 */
static int32_t  func_40(uint32_t * p_41, const uint32_t  p_42, uint16_t  p_43)
{ /* block id: 155 */
    uint8_t l_395 = 9UL;
    for (p_43 = 0; (p_43 <= 22); ++p_43)
    { /* block id: 158 */
        if (l_395)
            break;
    }
    for (g_316 = 5; (g_316 >= 1); g_316 -= 1)
    { /* block id: 163 */
        return (*g_366);
    }
    return (**g_365);
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_83.f0 g_103 g_158.f0 g_128 g_392 g_82 g_88 g_130
 * writes: g_60 g_83.f0 g_103 g_88 g_128 g_83 g_392
 */
static uint32_t * func_44(struct S0 * p_45, uint16_t  p_46, int32_t  p_47)
{ /* block id: 77 */
    int32_t *l_248 = (void*)0;
    int32_t *l_249 = &g_88[1][2];
    int32_t *l_250 = &g_88[1][2];
    int32_t *l_251 = &g_88[1][2];
    int32_t *l_252 = &g_103;
    int32_t *l_253 = &g_88[1][2];
    int32_t *l_254 = &g_103;
    int32_t *l_255 = (void*)0;
    int32_t *l_256 = &g_88[1][2];
    int32_t *l_257 = &g_88[1][2];
    int32_t *l_258[4][7] = {{&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103},{&g_103,&g_88[1][2],&g_88[1][2],&g_103,&g_88[1][2],&g_88[1][2],&g_103},{&g_88[1][2],&g_103,&g_88[1][2],&g_88[1][2],&g_103,&g_88[1][2],&g_88[1][2]},{&g_103,&g_103,(void*)0,&g_103,&g_103,(void*)0,&g_103}};
    uint32_t l_259[2][10][4] = {{{0UL,0x0B683A1FL,0x0B683A1FL,0UL},{4294967295UL,0x657B257FL,0x0B683A1FL,4294967295UL},{0UL,0x8EEF7C79L,2UL,0x8EEF7C79L},{0x8EEF7C79L,0x0B683A1FL,4294967295UL,0x8EEF7C79L},{4294967295UL,0x8EEF7C79L,4294967295UL,4294967295UL},{0x657B257FL,0x657B257FL,2UL,0UL},{0x657B257FL,0x0B683A1FL,4294967295UL,0x657B257FL},{4294967295UL,0UL,4294967295UL,4294967295UL},{0x8EEF7C79L,0UL,0x657B257FL,4294967295UL},{0x0B683A1FL,2UL,2UL,0x0B683A1FL}},{{8UL,4294967295UL,2UL,0x3CEFC9DAL},{0x0B683A1FL,4294967295UL,0x657B257FL,4294967295UL},{4294967295UL,2UL,8UL,4294967295UL},{8UL,4294967295UL,0x3CEFC9DAL,0x3CEFC9DAL},{4294967295UL,4294967295UL,0x657B257FL,0x0B683A1FL},{4294967295UL,2UL,0x3CEFC9DAL,4294967295UL},{8UL,0x0B683A1FL,8UL,0x3CEFC9DAL},{4294967295UL,0x0B683A1FL,0x657B257FL,4294967295UL},{0x0B683A1FL,2UL,2UL,0x0B683A1FL},{8UL,4294967295UL,2UL,0x3CEFC9DAL}}};
    uint32_t **l_279 = &g_130;
    uint32_t ***l_278 = &l_279;
    uint32_t l_294 = 0x365FFFEBL;
    struct S1 *l_310[3][6] = {{&g_144,&g_144,&g_144,&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144,&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144,&g_144,&g_144,&g_144}};
    const int16_t *l_319 = &g_17;
    struct S1 **l_379 = &l_310[2][3];
    int i, j, k;
    l_259[1][6][0]++;
    for (g_60 = 7; (g_60 >= 15); g_60 = safe_add_func_uint64_t_u_u(g_60, 8))
    { /* block id: 81 */
        int32_t l_271[10] = {0x929EA8D3L,0x16943C44L,1L,0x16943C44L,0x929EA8D3L,0x929EA8D3L,0x16943C44L,1L,0x16943C44L,0x929EA8D3L};
        int32_t l_285 = 0xB9DBF9F7L;
        int32_t l_290 = (-5L);
        int32_t l_293[1];
        int64_t *l_390 = &g_345;
        int i;
        for (i = 0; i < 1; i++)
            l_293[i] = 0x3F59F7A6L;
        for (g_83.f0 = (-1); (g_83.f0 >= 0); g_83.f0 = safe_add_func_uint16_t_u_u(g_83.f0, 8))
        { /* block id: 84 */
            uint8_t l_266[3][10][6] = {{{0x76L,1UL,0x47L,0xCCL,255UL,2UL},{0x19L,0UL,1UL,0x58L,0x18L,0x19L},{0x10L,0UL,0UL,0x70L,0UL,0x93L},{1UL,0x76L,247UL,0xAEL,247UL,0x76L},{0UL,0x9EL,0xAEL,0xE6L,0x0EL,255UL},{2UL,0UL,255UL,1UL,0x3CL,1UL},{0x19L,0UL,0x53L,0x10L,0x0EL,0x58L},{8UL,0x9EL,0x9DL,0x53L,247UL,1UL},{0xABL,0x76L,0x70L,0xAFL,0UL,0x3CL},{2UL,0UL,249UL,0xB6L,0x18L,0UL}},{{0x46L,0UL,255UL,1UL,255UL,0x78L},{0UL,1UL,0UL,255UL,0x1FL,8UL},{0x9DL,0UL,0x71L,0x53L,0x70L,0x93L},{0x76L,0x3CL,0x51L,0x6EL,0x53L,2UL},{0UL,0x18L,1UL,1UL,0x18L,0UL},{2UL,255UL,0x47L,0x70L,2UL,0UL},{3UL,0UL,247UL,0x19L,0x65L,8UL},{3UL,0x9EL,0x19L,0x70L,0x51L,255UL},{2UL,2UL,0UL,1UL,1UL,1UL},{0UL,0x2FL,247UL,0UL,5UL,3UL}},{{0xCCL,0UL,0x0BL,8UL,2UL,0UL},{1UL,0x10L,0x58L,247UL,255UL,255UL},{0xE6L,0UL,0UL,0x19L,250UL,0xB6L},{0UL,1UL,250UL,0x2FL,8UL,0x71L},{0x9DL,1UL,0UL,0x9EL,0x3CL,0x10L},{1UL,8UL,0xC5L,8UL,1UL,0x51L},{0x6EL,3UL,0x71L,0xAFL,0x76L,249UL},{249UL,0x46L,255UL,3UL,250UL,249UL},{255UL,0x71L,0x71L,0x0BL,1UL,0x51L},{250UL,2UL,0xC5L,0UL,1UL,0x10L}}};
            uint32_t ***l_281 = &l_279;
            uint32_t ****l_280 = &l_281;
            const uint32_t *l_284 = &l_259[1][6][0];
            const uint32_t **l_283 = &l_284;
            const uint32_t *** const l_282 = &l_283;
            int32_t l_286 = 6L;
            int32_t l_291[4];
            int32_t l_297 = (-2L);
            int8_t l_307 = (-1L);
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_291[i] = 0xA428A5F0L;
            (*l_252) = 0L;
            l_266[2][2][0]--;
            l_286 ^= ((safe_div_func_uint32_t_u_u((l_271[5] & ((safe_rshift_func_int16_t_s_u(((safe_div_func_int64_t_s_s(p_46, (safe_div_func_uint32_t_u_u((*l_252), l_271[8])))) > (l_266[0][5][3] || ((void*)0 == l_278))), 3)) ^ (l_285 = ((((*l_256) = 6L) || (((*l_280) = &l_279) == l_282)) > p_47)))), l_271[7])) != g_158[4].f0);
            for (g_128 = (-22); (g_128 > 4); g_128++)
            { /* block id: 93 */
                int32_t l_289 = 0x6B19BEA2L;
                int32_t l_308 = 0x7C2D6C3EL;
                int32_t l_309 = 0xA91875BBL;
                struct S1 *l_312 = &g_144;
                int16_t l_361[2][9] = {{0L,0x8CABL,0x3575L,0x8CABL,0L,(-10L),(-10L),0L,0x8CABL},{0x5312L,(-3L),0x5312L,(-10L),0x3575L,0x3575L,(-10L),0x5312L,(-3L)}};
                int32_t **l_391 = &l_253;
                int i, j;
            }
        }
        (*g_82) = g_392;
        (*l_252) &= (*l_256);
    }
    return (**l_278);
}


/* ------------------------------------------ */
/* 
 * reads : g_49.f0 g_17 g_83.f0 g_77 g_49.f1 g_49.f2 g_88 g_103
 * writes: g_87 g_49.f0 g_83.f0 g_99 g_88 g_103 g_60
 */
static uint32_t * func_51(uint8_t  p_52, struct S0 * p_53, int16_t * const  p_54, int16_t  p_55)
{ /* block id: 15 */
    const int32_t *l_86 = (void*)0;
    struct S0 *l_124 = &g_83;
    int32_t l_138 = (-1L);
    int32_t l_169[9][10][2] = {{{(-2L),0x936BB2FCL},{(-1L),(-2L)},{1L,0x7992E5D7L},{1L,(-2L)},{(-1L),0x936BB2FCL},{(-2L),0xE4EFEDF9L},{1L,(-1L)},{(-5L),1L},{1L,0xD8830F48L},{0x7578BEDBL,0x2CB54C83L}},{{0x6FE971D6L,1L},{1L,0x88D6F10EL},{0xE4EFEDF9L,0x88D6F10EL},{1L,1L},{0x6FE971D6L,0x2CB54C83L},{0x7578BEDBL,0xD8830F48L},{1L,1L},{(-5L),(-1L)},{1L,0xE4EFEDF9L},{(-2L),0x936BB2FCL}},{{(-1L),(-2L)},{1L,0x7992E5D7L},{1L,(-2L)},{(-1L),0x936BB2FCL},{(-2L),0xE4EFEDF9L},{1L,(-1L)},{(-5L),1L},{1L,0xD8830F48L},{0x7578BEDBL,0x2CB54C83L},{0x6FE971D6L,1L}},{{1L,0x88D6F10EL},{0xE4EFEDF9L,0x88D6F10EL},{1L,1L},{0x6FE971D6L,0x2CB54C83L},{0x7578BEDBL,0xD8830F48L},{1L,1L},{(-5L),(-1L)},{1L,0xE4EFEDF9L},{(-2L),0x936BB2FCL},{(-1L),(-2L)}},{{1L,0x7992E5D7L},{1L,(-2L)},{(-1L),0x936BB2FCL},{(-2L),0xE4EFEDF9L},{1L,(-1L)},{(-5L),1L},{1L,0xD8830F48L},{0x7578BEDBL,0x2CB54C83L},{0x6FE971D6L,1L},{1L,0x88D6F10EL}},{{0xE4EFEDF9L,0x88D6F10EL},{1L,1L},{0x6FE971D6L,0x2CB54C83L},{0x7578BEDBL,0xD8830F48L},{1L,1L},{0x936BB2FCL,0x88D6F10EL},{(-5L),0xD8830F48L},{0xE4EFEDF9L,0xFB0DACC5L},{0x88D6F10EL,0xE4EFEDF9L},{1L,0x82C73545L}},{{1L,0xE4EFEDF9L},{0x88D6F10EL,0xFB0DACC5L},{0xE4EFEDF9L,0xD8830F48L},{(-5L),0x88D6F10EL},{0x936BB2FCL,1L},{1L,1L},{1L,0x7992E5D7L},{2L,(-5L)},{0x7578BEDBL,0x6FE971D6L},{0xD8830F48L,0x6FE971D6L}},{{0x7578BEDBL,(-5L)},{2L,0x7992E5D7L},{1L,1L},{1L,1L},{0x936BB2FCL,0x88D6F10EL},{(-5L),0xD8830F48L},{0xE4EFEDF9L,0xFB0DACC5L},{0x88D6F10EL,0xE4EFEDF9L},{1L,0x82C73545L},{1L,0xE4EFEDF9L}},{{0x88D6F10EL,0xFB0DACC5L},{0xE4EFEDF9L,0xD8830F48L},{(-5L),0x88D6F10EL},{0x936BB2FCL,1L},{1L,1L},{1L,0x7992E5D7L},{2L,(-5L)},{0x7578BEDBL,0x6FE971D6L},{0xD8830F48L,0x6FE971D6L},{0x7578BEDBL,(-5L)}}};
    struct S1 *l_212[8][8][3] = {{{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144}},{{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144}},{{(void*)0,(void*)0,(void*)0},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144},{&g_144,&g_144,&g_144},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144}},{{(void*)0,&g_144,&g_144},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144}},{{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144},{&g_144,(void*)0,&g_144},{(void*)0,(void*)0,(void*)0},{&g_144,(void*)0,&g_144}},{{(void*)0,&g_144,(void*)0},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,(void*)0,&g_144},{&g_144,&g_144,&g_144}},{{(void*)0,&g_144,&g_144},{(void*)0,&g_144,(void*)0},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,(void*)0,&g_144},{&g_144,&g_144,&g_144},{&g_144,&g_144,(void*)0},{&g_144,&g_144,&g_144}},{{&g_144,&g_144,&g_144},{(void*)0,&g_144,&g_144},{(void*)0,&g_144,(void*)0},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{&g_144,&g_144,&g_144},{(void*)0,&g_144,(void*)0},{&g_144,&g_144,(void*)0}}};
    uint32_t *l_243 = &g_128;
    uint32_t **l_246 = &g_130;
    uint32_t *l_247 = &g_99;
    int i, j, k;
    for (p_52 = (-23); (p_52 >= 45); p_52 = safe_add_func_uint16_t_u_u(p_52, 9))
    { /* block id: 18 */
        g_87[1] = l_86;
    }
    for (g_49.f0 = 0; (g_49.f0 > 15); g_49.f0 = safe_add_func_uint32_t_u_u(g_49.f0, 7))
    { /* block id: 23 */
        int64_t *l_93 = (void*)0;
        int64_t *l_94 = &g_83.f0;
        uint32_t *l_98 = &g_99;
        const int32_t l_100 = 1L;
        int32_t *l_101 = &g_88[1][1];
        int32_t *l_102 = &g_103;
        uint32_t l_140 = 0x63353D15L;
        int32_t l_170 = 0L;
        int32_t l_172 = 0xE170EDF9L;
        int32_t l_178 = 9L;
        int64_t l_179 = 0xD9819071DA066FCELL;
        int32_t l_181 = 0L;
        int32_t l_183 = 0L;
        int32_t l_185 = 0xFE86CE72L;
        int32_t l_187[8][8] = {{0x5156066CL,0xDC2B71B2L,(-1L),0x5156066CL,0L,0L,0x5156066CL,(-1L)},{(-1L),(-1L),0x4F09A9BCL,0x15E18F19L,0x5156066CL,0x4F09A9BCL,0x5156066CL,0x15E18F19L},{(-1L),0x15E18F19L,(-1L),0L,0x15E18F19L,0xDC2B71B2L,0xDC2B71B2L,0x15E18F19L},{0x15E18F19L,0xDC2B71B2L,0xDC2B71B2L,0x15E18F19L,0L,(-1L),0x15E18F19L,(-1L)},{0x15E18F19L,0x5156066CL,0x4F09A9BCL,0x5156066CL,0x15E18F19L,0x4F09A9BCL,(-1L),(-1L)},{(-1L),0x5156066CL,0L,0L,0x5156066CL,(-1L),0xDC2B71B2L,0x5156066CL},{(-1L),0xDC2B71B2L,0L,(-1L),0L,0xDC2B71B2L,(-1L),(-1L)},{0x5156066CL,0x15E18F19L,0x4F09A9BCL,(-1L),(-1L),0x4F09A9BCL,0x15E18F19L,0x5156066CL}};
        uint32_t **l_245 = &g_130;
        uint32_t ***l_244[6] = {&l_245,&l_245,&l_245,&l_245,&l_245,&l_245};
        int i, j;
        (*l_102) = ((*l_101) ^= (safe_mul_func_int8_t_s_s(((void*)0 != &g_88[2][2]), ((*p_54) <= (((*l_94) &= g_49.f0) | (((((safe_mul_func_int16_t_s_s(4L, (8UL < (p_55 >= ((*l_98) = (+g_77[0][4])))))) < (&g_17 != &g_17)) , l_100) , g_49.f1) != g_49.f2))))));
        for (g_83.f0 = 0; (g_83.f0 <= 5); ++g_83.f0)
        { /* block id: 30 */
            uint32_t *l_129 = &g_128;
            int32_t l_135[1][3];
            uint16_t l_141 = 0x7858L;
            int32_t l_241 = 0xA211ECB1L;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_135[i][j] = 0xBCC78BB9L;
            }
            (*l_102) ^= (*l_101);
            for (g_60 = 0; (g_60 <= 2); g_60 += 1)
            { /* block id: 34 */
                uint16_t l_110 = 0UL;
                int32_t l_120[4][8] = {{1L,0x2D252A4FL,1L,1L,0x2D252A4FL,0xD7E63684L,0xD7E63684L,0x2D252A4FL},{0x2D252A4FL,0xD7E63684L,0xD7E63684L,0x2D252A4FL,1L,1L,0x2D252A4FL,1L},{0x2D252A4FL,0x628F5DBBL,0xA5080F12L,0x628F5DBBL,0x2D252A4FL,0xA5080F12L,0xFE5016CBL,0xFE5016CBL},{1L,0x628F5DBBL,1L,1L,0x628F5DBBL,1L,0xD7E63684L,0x628F5DBBL}};
                uint32_t *l_127 = &g_128;
                int64_t l_209 = (-1L);
                struct S1 *l_213 = &g_144;
                uint8_t l_228 = 0xFFL;
                int i, j;
                for (p_52 = 0; (p_52 <= 2); p_52 += 1)
                { /* block id: 37 */
                    int16_t *l_116 = &g_17;
                    int16_t **l_115 = &l_116;
                    const int32_t l_117 = (-10L);
                    int16_t *l_118 = (void*)0;
                    int16_t *l_119[2];
                    uint64_t *l_163 = (void*)0;
                    uint64_t *l_164 = &g_137;
                    int32_t l_171 = 9L;
                    int32_t l_173 = 0L;
                    int32_t l_174 = 0x0F172A51L;
                    int32_t l_176 = 0L;
                    int32_t l_177 = 0x737C675BL;
                    int32_t l_180 = (-7L);
                    int8_t l_182 = 0x7DL;
                    int32_t l_184 = 0xCF5502DBL;
                    int32_t l_186 = 0x14F84DE0L;
                    int32_t l_188 = (-6L);
                    int32_t l_189 = (-9L);
                    int32_t l_190 = (-1L);
                    int32_t l_191 = (-10L);
                    int16_t l_192 = 0xDA3EL;
                    int32_t l_193 = (-9L);
                    int32_t l_194 = 0x2E318422L;
                    uint16_t *l_214 = &l_141;
                    int32_t *l_215 = &l_120[2][0];
                    int32_t *l_242[5][7] = {{&l_178,&l_178,&g_88[0][2],(void*)0,&l_120[3][6],&l_120[3][6],(void*)0},{&l_187[5][7],&l_120[2][0],&l_187[5][7],&l_188,&l_187[5][7],&l_120[2][0],&l_187[5][7]},{&l_178,(void*)0,(void*)0,&l_178,&l_120[3][6],&g_88[0][2],&g_88[0][2]},{(void*)0,&l_120[2][0],&l_183,&l_120[2][0],(void*)0,&l_120[2][0],&l_183},{&l_120[3][6],&l_178,(void*)0,(void*)0,&l_178,&l_120[3][6],&g_88[0][2]}};
                    int i, j;
                    for (i = 0; i < 2; i++)
                        l_119[i] = (void*)0;
                }
                return l_243;
            }
        }
        l_246 = &l_98;
        if (p_52)
            continue;
    }
    return l_247;
}


/* ------------------------------------------ */
/* 
 * reads : g_49.f0 g_77 g_13 g_80 g_17
 * writes: g_49.f0 g_77 g_80
 */
static int16_t  func_70(int64_t  p_71, int16_t * const  p_72, const uint64_t * const  p_73)
{ /* block id: 5 */
    uint8_t l_74[10];
    int i;
    for (i = 0; i < 10; i++)
        l_74[i] = 0x3CL;
    for (g_49.f0 = 3; (g_49.f0 <= 9); g_49.f0 += 1)
    { /* block id: 8 */
        int32_t *l_75 = (void*)0;
        int32_t *l_76 = (void*)0;
        volatile struct S0 *l_81 = &g_80[1][1][4];
        int i;
        if (l_74[g_49.f0])
            break;
        --g_77[0][4];
        if (g_13[2])
            continue;
        (*l_81) = g_80[1][1][4];
    }
    return g_17;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_49.f0, "g_49.f0", print_hash_value);
    transparent_crc(g_49.f1, "g_49.f1", print_hash_value);
    transparent_crc(g_49.f2, "g_49.f2", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_77[i][j], "g_77[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_80[i][j][k].f0, "g_80[i][j][k].f0", print_hash_value);
                transparent_crc(g_80[i][j][k].f1, "g_80[i][j][k].f1", print_hash_value);
                transparent_crc(g_80[i][j][k].f2, "g_80[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_83.f0, "g_83.f0", print_hash_value);
    transparent_crc(g_83.f1, "g_83.f1", print_hash_value);
    transparent_crc(g_83.f2, "g_83.f2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_88[i][j], "g_88[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_144.f0, "g_144.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_158[i].f0, "g_158[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_195[i], "g_195[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_316, "g_316", print_hash_value);
    transparent_crc(g_333.f0, "g_333.f0", print_hash_value);
    transparent_crc(g_345, "g_345", print_hash_value);
    transparent_crc(g_384, "g_384", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_386[i][j][k], "g_386[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_392.f0, "g_392.f0", print_hash_value);
    transparent_crc(g_392.f1, "g_392.f1", print_hash_value);
    transparent_crc(g_392.f2, "g_392.f2", print_hash_value);
    transparent_crc(g_399, "g_399", print_hash_value);
    transparent_crc(g_400.f0, "g_400.f0", print_hash_value);
    transparent_crc(g_540.f0, "g_540.f0", print_hash_value);
    transparent_crc(g_540.f1, "g_540.f1", print_hash_value);
    transparent_crc(g_540.f2, "g_540.f2", print_hash_value);
    transparent_crc(g_569, "g_569", print_hash_value);
    transparent_crc(g_668, "g_668", print_hash_value);
    transparent_crc(g_671, "g_671", print_hash_value);
    transparent_crc(g_690, "g_690", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_703[i][j].f0, "g_703[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_729, "g_729", print_hash_value);
    transparent_crc(g_733.f0, "g_733.f0", print_hash_value);
    transparent_crc(g_751.f0, "g_751.f0", print_hash_value);
    transparent_crc(g_778.f0, "g_778.f0", print_hash_value);
    transparent_crc(g_778.f1, "g_778.f1", print_hash_value);
    transparent_crc(g_778.f2, "g_778.f2", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_782[i][j].f0, "g_782[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_792, "g_792", print_hash_value);
    transparent_crc(g_797, "g_797", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_836[i][j], "g_836[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_863.f0, "g_863.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_940[i].f0, "g_940[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_998, "g_998", print_hash_value);
    transparent_crc(g_1006.f0, "g_1006.f0", print_hash_value);
    transparent_crc(g_1016.f0, "g_1016.f0", print_hash_value);
    transparent_crc(g_1016.f1, "g_1016.f1", print_hash_value);
    transparent_crc(g_1016.f2, "g_1016.f2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1051[i][j], "g_1051[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1060, "g_1060", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1077[i], "g_1077[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 260
   depth: 1, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 12
breakdown:
   indirect level: 0, occurrence: 5
   indirect level: 1, occurrence: 6
   indirect level: 2, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 12
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 10
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 22

XXX max expression depth: 35
breakdown:
   depth: 1, occurrence: 76
   depth: 2, occurrence: 24
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 20, occurrence: 1
   depth: 23, occurrence: 2
   depth: 25, occurrence: 1
   depth: 30, occurrence: 1
   depth: 35, occurrence: 1

XXX total number of pointers: 245

XXX times a variable address is taken: 381
XXX times a pointer is dereferenced on RHS: 76
breakdown:
   depth: 1, occurrence: 69
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 143
breakdown:
   depth: 1, occurrence: 139
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 21
XXX times a pointer is compared with address of another variable: 4
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 3646

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 511
   level: 2, occurrence: 54
   level: 3, occurrence: 15
   level: 4, occurrence: 5
XXX number of pointers point to pointers: 86
XXX number of pointers point to scalars: 143
XXX number of pointers point to structs: 16
XXX percent of pointers has null in alias set: 27.3
XXX average alias set size: 1.39

XXX times a non-volatile is read: 712
XXX times a non-volatile is write: 402
XXX times a volatile is read: 32
XXX    times read thru a pointer: 1
XXX times a volatile is write: 11
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 3.16e+03
XXX percentage of non-volatile access: 96.3

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 79
XXX max block depth: 4
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 21
   depth: 2, occurrence: 11
   depth: 3, occurrence: 11
   depth: 4, occurrence: 5

XXX percentage a fresh-made variable is used: 17.4
XXX percentage an existing variable is used: 82.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

