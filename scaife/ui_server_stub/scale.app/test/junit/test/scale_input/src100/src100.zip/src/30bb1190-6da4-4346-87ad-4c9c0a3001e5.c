/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      922890970
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint16_t  f0;
   int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-8L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = (-10L);/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 7L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5[3] = {0x2D149FEBL,0x2D149FEBL,0x2D149FEBL};
static int32_t g_8[9] = {0xDD952EAAL,0x33843046L,0xDD952EAAL,0xDD952EAAL,0x33843046L,0xDD952EAAL,0xDD952EAAL,0x33843046L,0xDD952EAAL};
static union U0 g_15 = {0x5A40L};
static int16_t g_26 = 1L;
static int16_t *g_35 = (void*)0;
static int32_t g_52 = 0xA2D3C5EBL;
static uint64_t g_65 = 4UL;
static int32_t g_71 = 0xC9F93B76L;
static uint16_t g_74[5][5] = {{0xB8FCL,0xBFCCL,0xBFCCL,0xB8FCL,7UL},{0xB8FCL,0xBFCCL,0xBFCCL,0xB8FCL,7UL},{0xB8FCL,0xBFCCL,0xBFCCL,0xB8FCL,7UL},{0xB8FCL,0xBFCCL,0xBFCCL,0xB8FCL,7UL},{0xB8FCL,0xBFCCL,0xBFCCL,0xB8FCL,7UL}};
static uint8_t g_97 = 1UL;
static int16_t g_100[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int64_t g_113[3] = {0x4ACF1AFC50B83611LL,0x4ACF1AFC50B83611LL,0x4ACF1AFC50B83611LL};
static uint32_t g_133 = 0UL;
static uint64_t g_135 = 0x9C2EEFDD5005B569LL;
static uint64_t *g_134 = &g_135;
static int32_t g_141 = 0xDB8BB06CL;
static int32_t *g_144 = &g_52;
static int32_t **g_143 = &g_144;
static uint32_t g_169 = 0xA02FE386L;
static int8_t g_188 = 0xAAL;
static int32_t ***g_209 = &g_143;
static int32_t g_245 = 0xFECA6743L;
static int32_t g_250 = 0xC483BAE3L;
static uint32_t g_251[7] = {18446744073709551608UL,18446744073709551608UL,5UL,18446744073709551608UL,18446744073709551608UL,5UL,18446744073709551608UL};
static uint8_t g_256 = 255UL;
static int64_t g_289 = 0x8619DA543B9BA44DLL;
static int32_t *g_337 = &g_141;
static uint64_t g_346 = 0xE029866E211E06A4LL;
static int32_t g_354 = 0L;
static union U0 g_374 = {0x0660L};
static union U0 *g_373[9] = {&g_374,&g_374,&g_374,&g_374,&g_374,&g_374,&g_374,&g_374,&g_374};
static int32_t g_390 = 0xDF952F90L;
static int32_t g_392 = 1L;
static int8_t g_393[10][3][6] = {{{1L,(-4L),(-1L),0xB1L,0L,0x09L},{0x09L,1L,2L,1L,0x09L,(-4L)},{0x09L,1L,1L,0xB1L,1L,1L}},{{1L,0L,0L,1L,2L,1L},{(-1L),1L,1L,(-4L),0xB1L,(-4L)},{2L,1L,2L,0x40L,0xB1L,0x09L}},{{1L,1L,(-1L),2L,2L,(-1L)},{0L,0L,1L,2L,1L,0x40L},{1L,1L,0x09L,0x40L,0x09L,1L}},{{2L,1L,0x09L,(-4L),0L,0x40L},{(-1L),(-4L),1L,1L,(-4L),(-1L)},{1L,(-4L),(-1L),0xB1L,0L,0x09L}},{{0x09L,1L,2L,1L,0x09L,(-4L)},{0x09L,1L,1L,0xB1L,1L,1L},{1L,0L,0L,1L,2L,1L}},{{(-1L),1L,1L,(-4L),0xB1L,(-4L)},{2L,1L,2L,0x40L,0xB1L,0x09L},{1L,1L,(-1L),2L,2L,(-1L)}},{{0L,0L,1L,2L,1L,0x40L},{1L,1L,0x09L,0x40L,0x09L,1L},{2L,1L,0x09L,(-4L),0L,0x40L}},{{(-1L),(-4L),1L,1L,(-4L),(-1L)},{1L,(-4L),(-1L),0xB1L,0L,0x09L},{0x09L,1L,2L,1L,0x09L,(-4L)}},{{0x09L,1L,1L,0xB1L,1L,1L},{1L,0L,0L,1L,2L,1L},{(-1L),1L,1L,(-4L),0xB1L,(-4L)}},{{2L,1L,2L,0x40L,0xB1L,0x09L},{1L,1L,(-1L),2L,2L,(-1L)},{0L,0x40L,0L,(-4L),0x09L,1L}}};
static int32_t g_394 = (-1L);
static uint32_t g_495[7] = {1UL,18446744073709551615UL,18446744073709551615UL,1UL,18446744073709551615UL,18446744073709551615UL,1UL};
static uint64_t g_517 = 18446744073709551608UL;
static int32_t g_650[4] = {0x9181DBFAL,0x9181DBFAL,0x9181DBFAL,0x9181DBFAL};
static uint32_t *g_652 = &g_133;
static uint32_t **g_651 = &g_652;
static uint8_t *g_660[10][7][3] = {{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{(void*)0,&g_256,&g_97},{&g_97,&g_256,&g_256},{&g_256,(void*)0,&g_256},{&g_97,&g_97,&g_256},{(void*)0,&g_256,&g_256}},{{&g_256,&g_97,&g_97},{&g_256,(void*)0,&g_256},{&g_256,&g_97,&g_256},{&g_256,&g_97,&g_97},{&g_256,&g_256,&g_97},{&g_256,&g_256,&g_97},{&g_256,&g_256,&g_97}},{{&g_97,&g_256,&g_256},{&g_97,&g_256,&g_256},{&g_256,&g_97,&g_256},{&g_256,&g_97,&g_97},{&g_256,&g_256,&g_97},{&g_256,&g_256,&g_97},{&g_256,&g_256,&g_97}}};
static uint8_t **g_659 = &g_660[5][2][0];
static int32_t g_675 = 0x40597E97L;
static int32_t g_679[1] = {9L};
static int32_t g_680 = (-1L);
static int64_t g_681 = 0x8989CFCE40A3AB3BLL;
static uint32_t g_682 = 4294967290UL;
static int32_t *g_715[5] = {&g_392,&g_392,&g_392,&g_392,&g_392};
static int8_t g_717 = (-4L);
static volatile int32_t g_810 = (-2L);/* VOLATILE GLOBAL g_810 */
static int32_t ** volatile g_861[9] = {&g_337,&g_337,&g_337,&g_337,&g_337,&g_337,&g_337,&g_337,&g_337};
static uint32_t g_909[3] = {8UL,8UL,8UL};
static int32_t * volatile *g_932 = &g_144;
static int32_t * volatile * volatile * const g_931 = &g_932;
static int32_t * volatile * volatile * const *g_930[2] = {&g_931,&g_931};
static int32_t * volatile * volatile * const ** volatile g_929[6] = {&g_930[1],&g_930[1],&g_930[1],&g_930[1],&g_930[1],&g_930[1]};
static int16_t g_950 = (-1L);
static union U0 **g_1023[3][4] = {{&g_373[8],&g_373[8],&g_373[8],&g_373[8]},{&g_373[8],&g_373[8],&g_373[8],&g_373[8]},{&g_373[8],&g_373[8],&g_373[8],&g_373[8]}};
static union U0 **g_1025 = &g_373[2];
static union U0 *** volatile g_1024[2] = {&g_1025,&g_1025};
static int32_t ** volatile g_1031 = &g_715[4];/* VOLATILE GLOBAL g_1031 */
static int32_t ** const  volatile g_1034 = &g_715[0];/* VOLATILE GLOBAL g_1034 */
static uint16_t *g_1053 = &g_74[0][2];
static uint16_t **g_1052 = &g_1053;
static uint64_t **g_1085 = &g_134;
static volatile uint8_t g_1092[9][1][3] = {{{0xBBL,0x00L,0xBBL}},{{255UL,249UL,2UL}},{{251UL,251UL,9UL}},{{0xE7L,249UL,249UL}},{{9UL,0x00L,0x63L}},{{0xE7L,1UL,0xE7L}},{{251UL,9UL,0x63L}},{{255UL,255UL,249UL}},{{0xBBL,9UL,9UL}}};
static const union U0 g_1118[9] = {{0x1193L},{2UL},{2UL},{0x1193L},{2UL},{2UL},{0x1193L},{2UL},{2UL}};
static const union U0 *g_1120 = (void*)0;
static const union U0 ** volatile g_1119 = &g_1120;/* VOLATILE GLOBAL g_1119 */
static const volatile int32_t g_1181 = 0xE5B2DA20L;/* VOLATILE GLOBAL g_1181 */
static const int16_t g_1189 = 0x03B8L;
static int8_t *g_1285 = &g_374.f1;
static const volatile uint32_t g_1468 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1468 */
static uint32_t g_1474 = 1UL;
static const int64_t g_1479 = 0x09CC1D358F83BB1ALL;
static const int64_t g_1481 = 0x00C7634E4DC82DBBLL;
static const int64_t *g_1480 = &g_1481;
static volatile uint32_t g_1578[5] = {0UL,0UL,0UL,0UL,0UL};
static int32_t ****g_1589 = (void*)0;
static int32_t *****g_1588 = &g_1589;
static uint32_t g_1600[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static int64_t ***g_1620 = (void*)0;
static volatile int32_t g_1633 = 9L;/* VOLATILE GLOBAL g_1633 */
static volatile int64_t g_1767 = 0xA8E484B22D9BC361LL;/* VOLATILE GLOBAL g_1767 */
static uint32_t g_1976 = 0x88B4448EL;
static union U0 ** volatile g_2001 = &g_373[2];/* VOLATILE GLOBAL g_2001 */
static volatile uint16_t * volatile *g_2116 = (void*)0;
static volatile uint16_t * volatile **g_2115[7][4][2] = {{{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116}},{{&g_2116,(void*)0},{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116}},{{&g_2116,&g_2116},{(void*)0,&g_2116},{&g_2116,(void*)0},{&g_2116,&g_2116}},{{&g_2116,(void*)0},{&g_2116,&g_2116},{(void*)0,&g_2116},{&g_2116,&g_2116}},{{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,(void*)0},{&g_2116,&g_2116}},{{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116}},{{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,&g_2116},{&g_2116,(void*)0}}};
static volatile uint16_t * volatile ***g_2114 = &g_2115[4][1][1];
static uint16_t g_2192 = 0xCE97L;
static int32_t g_2194 = 0xF31E3591L;
static volatile int16_t g_2214 = (-3L);/* VOLATILE GLOBAL g_2214 */
static const union U0 g_2271[2][4][7] = {{{{0x97E9L},{0x8B68L},{0x9E8DL},{0x8B68L},{0x97E9L},{1UL},{0xDB5CL}},{{4UL},{1UL},{0xDC8EL},{65530UL},{1UL},{0xC1DCL},{1UL}},{{0x4B0FL},{0x4B0FL},{0xDB5CL},{1UL},{0x97E9L},{0x8B68L},{0x9E8DL}},{{0x2F3DL},{0xC1DCL},{0x94ADL},{0x94ADL},{0xC1DCL},{0x2F3DL},{1UL}}},{{{0x55CEL},{0xDB5CL},{0xB46CL},{0xAFC7L},{0x97E9L},{0x97E9L},{0xAFC7L}},{{65530UL},{0x31B6L},{65530UL},{0xDC8EL},{1UL},{4UL},{0x2F3DL}},{{0xB46CL},{0xDB5CL},{0x55CEL},{0x8B68L},{0x55CEL},{0xDB5CL},{0xB46CL}},{{0x94ADL},{0xC1DCL},{0x2F3DL},{1UL},{0x0FAEL},{4UL},{0x0FAEL}}}};
static volatile uint32_t g_2279[4][7][9] = {{{0UL,18446744073709551615UL,0UL,3UL,0xA15D84FFL,0x3469082BL,0x739F1CA8L,18446744073709551615UL,0xB2A932B5L},{0xD25912F9L,0xCD08209BL,0x415D4941L,0xD25912F9L,0UL,3UL,0x415D4941L,18446744073709551610UL,0xD25912F9L},{1UL,0xC69BA395L,0UL,3UL,18446744073709551613UL,7UL,5UL,1UL,5UL},{8UL,0UL,0x33F4B781L,0x33F4B781L,0UL,8UL,18446744073709551615UL,18446744073709551610UL,1UL},{0x0BD38D90L,0xCCADBCDAL,0xB2A932B5L,18446744073709551615UL,0xA15D84FFL,7UL,0x0BD38D90L,0xC69BA395L,18446744073709551610UL},{0xD25912F9L,18446744073709551615UL,3UL,8UL,18446744073709551610UL,3UL,18446744073709551615UL,0x155AD214L,8UL},{0x3DD53685L,0xC69BA395L,5UL,0x3469082BL,18446744073709551609UL,0x3469082BL,5UL,0xC69BA395L,0x3DD53685L}},{{0x1931129AL,18446744073709551610UL,0x33F4B781L,0x415D4941L,18446744073709551615UL,0x1931129AL,0x415D4941L,18446744073709551610UL,8UL},{0xB2A932B5L,18446744073709551615UL,18446744073709551610UL,18446744073709551615UL,18446744073709551615UL,3UL,0x739F1CA8L,1UL,18446744073709551610UL},{0x1931129AL,18446744073709551606UL,0x415D4941L,1UL,18446744073709551610UL,0x9D974DE7L,0x9D974DE7L,18446744073709551610UL,1UL},{0x3DD53685L,18446744073709551615UL,0x3DD53685L,3UL,0xB1B6AB82L,0x3469082BL,0UL,18446744073709551615UL,5UL},{0xD25912F9L,18446744073709551610UL,0x415D4941L,3UL,0UL,0xD25912F9L,0x415D4941L,0xCD08209BL,0xD25912F9L},{0x0BD38D90L,0xC69BA395L,18446744073709551610UL,3UL,18446744073709551615UL,7UL,0xB2A932B5L,1UL,0xB2A932B5L},{8UL,18446744073709551615UL,0x33F4B781L,1UL,0UL,0x415D4941L,18446744073709551615UL,0x285B74CAL,1UL}},{{1UL,0xCCADBCDAL,5UL,18446744073709551615UL,0xB1B6AB82L,7UL,1UL,0xC69BA395L,0UL},{0xD25912F9L,0UL,3UL,0x415D4941L,18446744073709551610UL,0xD25912F9L,18446744073709551615UL,0xC23A98DBL,8UL},{0UL,0xC69BA395L,0x549BD509L,0x8247FFBCL,0x0BD38D90L,0x8247FFBCL,0x549BD509L,0x3469082BL,18446744073709551612UL},{0xB7182DF4L,3UL,0UL,0UL,8UL,18446744073709551612UL,0x773BE044L,0UL,0UL},{0xC45BCF21L,7UL,0x111DE981L,5UL,1UL,1UL,1UL,18446744073709551611UL,0x111DE981L},{0xB7182DF4L,8UL,0x773BE044L,0UL,0xD25912F9L,0xB7182DF4L,18446744073709551612UL,3UL,18446744073709551615UL},{18446744073709551612UL,7UL,18446744073709551612UL,1UL,0UL,0x8247FFBCL,0xBB694E0BL,18446744073709551615UL,0x549BD509L}},{{2UL,3UL,0x773BE044L,2UL,0x1931129AL,0xFB35AA9BL,0x773BE044L,0xD25912F9L,2UL},{0x8D65E77DL,0x3469082BL,0x111DE981L,1UL,5UL,0UL,0xC45BCF21L,18446744073709551611UL,0xC45BCF21L},{0UL,0x1931129AL,0UL,0UL,0x1931129AL,0UL,9UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,3UL,0x549BD509L,5UL,0UL,0UL,18446744073709551615UL,0x3469082BL,0UL},{2UL,0x9D974DE7L,0xFB35AA9BL,0UL,0xD25912F9L,0xFB35AA9BL,9UL,1UL,0UL},{0x0F9D404DL,0x3469082BL,0xC45BCF21L,0x8247FFBCL,1UL,0x8247FFBCL,0xC45BCF21L,0x3469082BL,0x0F9D404DL},{0xB7182DF4L,0xD25912F9L,0UL,0x773BE044L,8UL,0xB7182DF4L,0x773BE044L,18446744073709551615UL,0UL}}};
static volatile uint32_t ** volatile g_2348 = (void*)0;/* VOLATILE GLOBAL g_2348 */
static uint8_t g_2436[8] = {0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL};
static const uint64_t g_2443 = 18446744073709551611UL;
static const uint64_t g_2445[7][4] = {{0x4A22506B0F822861LL,0xCEB63D19799441F9LL,9UL,9UL},{0x9F4142C4E7C1DA21LL,0xCEB63D19799441F9LL,0x9F4142C4E7C1DA21LL,0x10C65574E9D438A0LL},{0xCEB63D19799441F9LL,0x3AF67E15FF329CA2LL,18446744073709551615UL,0x12BF3FEF99F4FE02LL},{0x12BF3FEF99F4FE02LL,9UL,0x4A22506B0F822861LL,0x3AF67E15FF329CA2LL},{18446744073709551615UL,0x4A22506B0F822861LL,0x4A22506B0F822861LL,18446744073709551615UL},{0x12BF3FEF99F4FE02LL,0x10C65574E9D438A0LL,18446744073709551615UL,0x9F4142C4E7C1DA21LL},{0xCEB63D19799441F9LL,0xA966AEB5C9B73928LL,0x9F4142C4E7C1DA21LL,7UL}};
static const uint64_t *g_2444 = &g_2445[4][3];
static uint16_t g_2647[5][8][6] = {{{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL}},{{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL}},{{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL}},{{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL}},{{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL},{0UL,65535UL,0UL,65535UL,0UL,65535UL},{0x5188L,65535UL,0x5188L,65535UL,0x5188L,65535UL}}};
static uint32_t g_2661 = 0x5C2471F3L;
static uint64_t * volatile * volatile * volatile *g_2737 = (void*)0;
static uint64_t * volatile * volatile * volatile **g_2736[6][2][4] = {{{&g_2737,&g_2737,&g_2737,&g_2737},{&g_2737,&g_2737,(void*)0,&g_2737}},{{(void*)0,&g_2737,&g_2737,(void*)0},{&g_2737,&g_2737,&g_2737,(void*)0}},{{&g_2737,&g_2737,(void*)0,&g_2737},{(void*)0,&g_2737,&g_2737,&g_2737}},{{&g_2737,&g_2737,&g_2737,&g_2737},{(void*)0,(void*)0,(void*)0,&g_2737}},{{&g_2737,(void*)0,&g_2737,(void*)0},{&g_2737,(void*)0,&g_2737,&g_2737}},{{(void*)0,(void*)0,(void*)0,&g_2737},{&g_2737,&g_2737,&g_2737,&g_2737}}};
static uint64_t g_2754 = 0xDDB85893E5B59ACALL;
static uint32_t *g_2842 = &g_1600[0];
static uint32_t **g_2841 = &g_2842;
static volatile int32_t *g_2852 = &g_810;
static volatile int32_t ** volatile g_2851 = &g_2852;/* VOLATILE GLOBAL g_2851 */
static int16_t **g_2869[6] = {&g_35,&g_35,&g_35,&g_35,&g_35,&g_35};
static int16_t ***g_2868 = &g_2869[5];
static union U0 *** volatile g_2997 = &g_1025;/* VOLATILE GLOBAL g_2997 */
static volatile uint16_t g_3025 = 0UL;/* VOLATILE GLOBAL g_3025 */
static volatile union U0 g_3087 = {8UL};/* VOLATILE GLOBAL g_3087 */
static int32_t g_3088 = 0xA7496DD7L;
static volatile int32_t * volatile **g_3225 = (void*)0;
static volatile int32_t * volatile *** const  volatile g_3224 = &g_3225;/* VOLATILE GLOBAL g_3224 */
static int32_t **g_3230 = (void*)0;
static int16_t ** volatile *g_3248[6][5] = {{&g_2869[1],(void*)0,&g_2869[1],(void*)0,&g_2869[1]},{&g_2869[5],&g_2869[5],(void*)0,(void*)0,&g_2869[5]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_2869[5],(void*)0,(void*)0,&g_2869[5],&g_2869[5]},{&g_2869[1],(void*)0,&g_2869[1],(void*)0,&g_2869[1]},{&g_2869[5],&g_2869[5],(void*)0,(void*)0,&g_2869[5]}};
static int16_t ** volatile * volatile * volatile g_3247 = &g_3248[1][3];/* VOLATILE GLOBAL g_3247 */
static int16_t ** volatile * volatile * volatile *g_3246 = &g_3247;
static int32_t ** volatile g_3275 = &g_337;/* VOLATILE GLOBAL g_3275 */
static volatile int64_t g_3338[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
static int16_t g_3350 = (-1L);
static int64_t *g_3365 = &g_681;
static int64_t **g_3364 = &g_3365;
static uint8_t g_3430[1][8] = {{0x0FL,8UL,8UL,0x0FL,8UL,8UL,0x0FL,8UL}};
static const int32_t g_3500 = (-5L);
static volatile int16_t g_3572 = 0xF491L;/* VOLATILE GLOBAL g_3572 */
static int32_t g_3601 = 2L;
static volatile int64_t g_3638 = 0x76216DEDE311A047LL;/* VOLATILE GLOBAL g_3638 */
static uint32_t g_3642[8][10] = {{0x6F0E2681L,0x6F0E2681L,0xFEF47138L,8UL,4294967291UL,0xFEF47138L,4294967291UL,8UL,0xFEF47138L,0x6F0E2681L},{4294967291UL,0x281CB8AFL,0x5F033953L,4294967291UL,0x5E06EE64L,0x5E06EE64L,4294967291UL,0x5F033953L,0x281CB8AFL,4294967291UL},{0x5F033953L,0x6F0E2681L,0x281CB8AFL,0x5E06EE64L,0x6F0E2681L,0x5E06EE64L,0x281CB8AFL,0x6F0E2681L,0x5F033953L,0x5F033953L},{4294967291UL,8UL,0xFEF47138L,0x6F0E2681L,0x6F0E2681L,0xFEF47138L,8UL,4294967291UL,0xFEF47138L,4294967291UL},{0x6F0E2681L,0x281CB8AFL,0x5E06EE64L,0x6F0E2681L,0x5E06EE64L,0x281CB8AFL,0x6F0E2681L,0x5F033953L,0x5F033953L,0x6F0E2681L},{0x5F033953L,4294967291UL,0x5E06EE64L,0x5E06EE64L,4294967291UL,0x5F033953L,0x281CB8AFL,4294967291UL,0x281CB8AFL,0x5F033953L},{8UL,4294967291UL,0xFEF47138L,4294967291UL,8UL,0xFEF47138L,0x6F0E2681L,0x6F0E2681L,0xFEF47138L,8UL},{8UL,0x281CB8AFL,0x281CB8AFL,8UL,0x5E06EE64L,0x5F033953L,8UL,0x5F033953L,0x5E06EE64L,8UL}};
static uint16_t g_3690[5] = {65535UL,65535UL,65535UL,65535UL,65535UL};
static const volatile int32_t g_3721 = 0xD18CF828L;/* VOLATILE GLOBAL g_3721 */
static uint32_t g_3781 = 0xD233173CL;
static uint32_t *g_3796 = (void*)0;
static int16_t *g_3818 = (void*)0;
static int16_t ** const g_3817 = &g_3818;
static int16_t ** const *g_3816[8][3][6] = {{{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,&g_3817},{&g_3817,(void*)0,(void*)0,(void*)0,(void*)0,&g_3817},{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,&g_3817}},{{(void*)0,&g_3817,(void*)0,&g_3817,(void*)0,&g_3817},{(void*)0,&g_3817,&g_3817,&g_3817,&g_3817,&g_3817},{&g_3817,&g_3817,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,(void*)0},{&g_3817,&g_3817,&g_3817,&g_3817,(void*)0,&g_3817},{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,(void*)0}},{{&g_3817,&g_3817,&g_3817,&g_3817,(void*)0,(void*)0},{&g_3817,(void*)0,(void*)0,&g_3817,&g_3817,&g_3817},{&g_3817,(void*)0,&g_3817,&g_3817,&g_3817,&g_3817}},{{&g_3817,&g_3817,(void*)0,&g_3817,&g_3817,&g_3817},{&g_3817,(void*)0,&g_3817,&g_3817,&g_3817,&g_3817},{&g_3817,(void*)0,(void*)0,(void*)0,(void*)0,&g_3817}},{{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,&g_3817},{(void*)0,&g_3817,(void*)0,&g_3817,(void*)0,&g_3817},{(void*)0,&g_3817,&g_3817,&g_3817,&g_3817,&g_3817}},{{&g_3817,&g_3817,(void*)0,(void*)0,(void*)0,(void*)0},{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,(void*)0},{&g_3817,&g_3817,&g_3817,&g_3817,(void*)0,&g_3817}},{{&g_3817,&g_3817,&g_3817,&g_3817,&g_3817,(void*)0},{&g_3817,&g_3817,&g_3817,&g_3817,(void*)0,(void*)0},{&g_3817,(void*)0,(void*)0,&g_3817,&g_3817,&g_3817}}};
static int16_t ** const **g_3815[7][8] = {{&g_3816[1][0][4],(void*)0,(void*)0,&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2]},{&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],(void*)0,(void*)0},{&g_3816[1][0][4],&g_3816[2][0][2],&g_3816[3][2][4],&g_3816[2][0][2],&g_3816[5][1][2],(void*)0,&g_3816[5][1][2],&g_3816[2][0][2]},{&g_3816[3][2][4],(void*)0,&g_3816[3][2][4],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],(void*)0,&g_3816[2][0][2]},{&g_3816[5][1][2],(void*)0,&g_3816[2][0][2],(void*)0,&g_3816[2][0][2],(void*)0,&g_3816[2][0][2],(void*)0},{&g_3816[5][1][2],&g_3816[2][0][2],(void*)0,&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[2][0][2],&g_3816[3][2][4],(void*)0},{&g_3816[3][2][4],&g_3816[2][0][2],&g_3816[5][1][2],(void*)0,&g_3816[5][1][2],&g_3816[2][0][2],&g_3816[3][2][4],(void*)0}};
static int32_t *****g_3820 = &g_1589;
static uint32_t g_3936 = 0UL;
static int32_t ** volatile *g_4018 = &g_143;
static const uint8_t *g_4043[10] = {&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6],&g_3430[0][6]};
static const uint8_t * volatile *g_4042[2][3][7] = {{{&g_4043[1],(void*)0,(void*)0,&g_4043[1],(void*)0,&g_4043[1],&g_4043[1]},{&g_4043[1],&g_4043[1],(void*)0,(void*)0,&g_4043[1],&g_4043[1],&g_4043[6]},{&g_4043[5],&g_4043[1],&g_4043[8],&g_4043[7],&g_4043[7],&g_4043[8],&g_4043[1]}},{{&g_4043[1],&g_4043[6],&g_4043[1],&g_4043[1],(void*)0,(void*)0,&g_4043[1]},{&g_4043[1],&g_4043[1],&g_4043[1],(void*)0,&g_4043[1],(void*)0,(void*)0},{(void*)0,&g_4043[1],&g_4043[1],&g_4043[1],(void*)0,&g_4043[1],&g_4043[4]}}};
static const uint8_t * volatile ** volatile g_4041 = &g_4042[0][1][1];/* VOLATILE GLOBAL g_4041 */
static const uint8_t * volatile ** volatile * volatile g_4040 = &g_4041;/* VOLATILE GLOBAL g_4040 */
static volatile uint8_t ** const *g_4045 = (void*)0;
static volatile uint8_t ** const ** const g_4044 = &g_4045;
static uint16_t g_4094 = 0x8301L;
static int32_t g_4142 = (-8L);
static int64_t g_4155 = 0x0313A720CA45DF05LL;
static int16_t g_4180 = 0x5D82L;
static uint32_t g_4205 = 0x8EFF2801L;
static uint8_t g_4211[3][2] = {{0xDDL,0xE7L},{0xDDL,0xDDL},{0xE7L,0xDDL}};
static const int32_t **g_4238 = (void*)0;
static uint8_t ***g_4258[10][6] = {{&g_659,&g_659,(void*)0,&g_659,(void*)0,(void*)0},{&g_659,&g_659,&g_659,&g_659,(void*)0,(void*)0},{&g_659,&g_659,(void*)0,&g_659,(void*)0,&g_659},{&g_659,&g_659,(void*)0,&g_659,(void*)0,(void*)0},{&g_659,&g_659,&g_659,&g_659,(void*)0,(void*)0},{&g_659,&g_659,(void*)0,&g_659,(void*)0,&g_659},{&g_659,&g_659,(void*)0,&g_659,(void*)0,(void*)0},{&g_659,&g_659,&g_659,&g_659,(void*)0,(void*)0},{&g_659,&g_659,(void*)0,&g_659,(void*)0,&g_659},{&g_659,&g_659,(void*)0,&g_659,(void*)0,(void*)0}};
static uint8_t ****g_4257[9][10] = {{&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[3][2],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0]},{&g_4258[0][0],&g_4258[0][0],&g_4258[4][5],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[3][2]},{(void*)0,(void*)0,(void*)0,&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],(void*)0,(void*)0},{&g_4258[0][0],&g_4258[0][0],&g_4258[3][2],(void*)0,(void*)0,&g_4258[0][0],(void*)0,&g_4258[0][0],&g_4258[0][0],&g_4258[0][0]},{&g_4258[3][2],(void*)0,&g_4258[0][0],(void*)0,(void*)0,&g_4258[0][0],&g_4258[0][0],(void*)0,&g_4258[4][5],&g_4258[4][5]},{&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],(void*)0,(void*)0,&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[0][4],&g_4258[0][0]},{(void*)0,&g_4258[0][0],&g_4258[0][0],(void*)0,(void*)0,&g_4258[0][0],(void*)0,&g_4258[3][2],&g_4258[0][0],(void*)0},{&g_4258[0][0],&g_4258[0][0],&g_4258[0][0],&g_4258[9][4],&g_4258[0][0],&g_4258[9][3],&g_4258[0][0],(void*)0,&g_4258[0][0],&g_4258[9][3]},{&g_4258[0][0],&g_4258[0][0],(void*)0,&g_4258[0][0],&g_4258[0][0],(void*)0,&g_4258[0][0],&g_4258[3][2],(void*)0,&g_4258[0][0]}};
static int8_t **g_4305 = &g_1285;
static uint32_t g_4345 = 0x1840488CL;
static int32_t ** volatile g_4389 = &g_715[1];/* VOLATILE GLOBAL g_4389 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_11(int16_t  p_12, union U0  p_13);
static int32_t  func_28(int16_t * const  p_29, const uint64_t  p_30);
static int16_t * func_31(int16_t * p_32, int16_t * p_33, int16_t * p_34);
static int16_t * func_36(int32_t  p_37, int16_t * p_38, int8_t  p_39, int8_t  p_40, union U0  p_41);
static uint8_t  func_47(uint64_t  p_48, int32_t  p_49, int32_t  p_50);
static int8_t  func_54(int32_t  p_55);
static int16_t ** func_58(const int32_t  p_59, int32_t * p_60, uint16_t  p_61);
static int32_t * func_67(int16_t ** p_68);
static int8_t  func_77(int16_t * p_78, uint64_t  p_79);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_337 g_932 g_144 g_52 g_2868 g_2869 g_74 g_35 g_256 g_8 g_113 g_289 g_188 g_251 g_134 g_135 g_15.f1 g_100 g_141 g_245 g_97 g_346 g_71 g_143 g_209 g_250 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_4389 g_715 g_1053
 * writes: g_5 g_141 g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675 g_715
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_14 = 0x865B49D585ED0657LL;
    uint64_t l_4381[2][1];
    union U0 l_4385 = {0x11E0L};
    uint64_t ***l_4387 = &g_1085;
    uint64_t ****l_4386 = &l_4387;
    int32_t l_4388[2][6] = {{(-1L),0x44CD39AFL,(-1L),0x44CD39AFL,(-1L),0x44CD39AFL},{(-1L),0x44CD39AFL,(-1L),0x44CD39AFL,(-1L),0x44CD39AFL}};
    int32_t **l_4390 = &g_715[1];
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_4381[i][j] = 18446744073709551615UL;
    }
    for (g_5[0] = 0; (g_5[0] > 21); g_5[0] = safe_add_func_int16_t_s_s(g_5[0], 3))
    { /* block id: 3 */
        int32_t l_4382 = 0x8210B18AL;
    }
    (*g_4389) = func_67(((((*g_337) = (-1L)) >= (safe_lshift_func_uint8_t_u_u((l_4385 , ((l_4386 == ((**g_932) , &l_4387)) & l_4388[1][3])), 7))) , (*g_2868)));
    (*l_4390) = (*g_4389);
    return (*g_1053);
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_26 g_35 g_8 g_15 g_2 g_15.f1 g_52 g_3 g_74 g_256 g_113 g_289 g_188 g_251 g_134 g_135 g_100 g_141 g_245 g_97 g_346 g_71 g_143 g_144 g_209 g_250 g_337 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_652 g_1285 g_1053 g_1480 g_1481 g_1118.f1 g_1600 g_2194 g_2214 g_675 g_65 g_681 g_1976 g_1085 g_660 g_2279 g_1031 g_1052 g_2348 g_2436 g_717 g_1474 g_1034 g_2647 g_2444 g_2661 g_680 g_2736 g_950 g_3224 g_2445 g_1025 g_3246 g_932 g_909 g_2852 g_810 g_3230 g_3275 g_2851 g_1588 g_3338 g_3350 g_3364 g_3365 g_3430 g_3247 g_3248 g_3500 g_2868 g_2869 g_679 g_3638 g_3642 g_3690 g_3721 g_3781 g_1118 g_3936 g_3088 g_4345 g_4305
 * writes: g_26 g_52 g_15.f1 g_65 g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675 g_715 g_2192 g_1976 g_681 g_1120 g_134 g_2444 g_2436 g_717 g_1474 g_2194 g_2647 g_1600 g_950 g_2661 g_1052 g_3230 g_909 g_810 g_2852 g_1589 g_3350 g_679 g_3690 g_652 g_3796 g_3815 g_1588 g_3820 g_659 g_651 g_3936 g_35 g_3088 g_3430 g_4345
 */
static int32_t  func_11(int16_t  p_12, union U0  p_13)
{ /* block id: 7 */
    int32_t l_22[3][3][7] = {{{0x00EADD5DL,0xEC7E4343L,0x6F8F9ED0L,0x46758E35L,0L,4L,(-6L)},{(-1L),0x890FC520L,0x00EADD5DL,1L,0x00EADD5DL,0x890FC520L,(-1L)},{0x1FBB9CF7L,1L,0x890FC520L,(-6L),0x00EADD5DL,0xADD63529L,0xEC7E4343L}},{{0L,0xADD63529L,0x46758E35L,0x00EADD5DL,0L,0L,0x00EADD5DL},{0x890FC520L,0x826FBD10L,0x890FC520L,(-1L),4L,0L,0xADD63529L},{0x890FC520L,(-6L),0x00EADD5DL,0xADD63529L,0xEC7E4343L,0x826FBD10L,0L}},{{0L,0x1FBB9CF7L,0x6F8F9ED0L,0x6F8F9ED0L,0x1FBB9CF7L,0L,0x0920A6FFL},{0x1FBB9CF7L,0x00EADD5DL,0xEC7E4343L,0x6F8F9ED0L,0x46758E35L,0L,4L},{(-1L),0L,0xE889EC00L,0xADD63529L,(-6L),0xADD63529L,0xE889EC00L}}};
    int16_t *l_25 = &g_26;
    int32_t l_27 = 0x3CD3624BL;
    int16_t **l_3937 = &g_35;
    int32_t l_4315[5][2] = {{0x5C1C1F29L,0x5C1C1F29L},{0x5C1C1F29L,0x5C1C1F29L},{0x5C1C1F29L,0x5C1C1F29L},{0x5C1C1F29L,0x5C1C1F29L},{0x5C1C1F29L,0x5C1C1F29L}};
    int32_t *l_4316 = &g_3088;
    uint64_t * const *l_4368[10] = {(void*)0,&g_134,(void*)0,&g_134,(void*)0,(void*)0,&g_134,(void*)0,&g_134,(void*)0};
    int i, j, k;
    (*l_4316) ^= (l_4315[4][1] = ((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u(l_22[1][1][1], l_22[1][1][1])) ^ (l_27 &= (safe_add_func_uint16_t_u_u((1L & l_22[1][1][1]), ((*l_25) ^= g_5[0]))))) ^ ((((func_28(((*l_3937) = func_31(g_35, func_36(g_8[6], l_25, ((+g_5[0]) , (-5L)), l_22[2][1][1], g_15), l_25)), l_22[1][1][6]) & 0xE9F337E7L) , p_13.f1) , p_13.f0) <= 0x1344L)), l_22[1][1][1])), 4)) >= 0L));
    (*l_4316) ^= (1UL ^ (safe_lshift_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(0x8CL, (p_13.f0 <= p_12))) != 0x5D5EC738FB73719ALL), 9)));
    (*g_2852) &= (*l_4316);
    for (g_517 = 0; (g_517 <= 3); g_517 += 1)
    { /* block id: 1988 */
        union U0 *l_4325 = &g_15;
        int32_t l_4328 = 0L;
        int32_t l_4335 = 0x47218B3BL;
        (*g_2852) = ((0x28A1B20B8C973A81LL < (+((*l_25) = 0x755BL))) , (*l_4316));
        for (g_97 = 0; g_97 < 7; g_97 += 1)
        {
            g_1600[g_97] = 0x2AB06402L;
        }
        for (g_256 = 0; (g_256 <= 3); g_256 += 1)
        { /* block id: 1994 */
            int32_t *l_4322 = &l_27;
            int32_t **l_4323[7] = {&l_4316,&l_4316,&l_4316,&l_4316,&l_4316,&l_4316,&l_4316};
            uint8_t *l_4340 = (void*)0;
            uint8_t *l_4341 = &g_3430[0][6];
            uint32_t l_4344[9] = {4294967287UL,0UL,0UL,4294967287UL,0UL,0UL,4294967287UL,0UL,0UL};
            const uint64_t **l_4369 = &g_2444;
            union U0 ***l_4374 = &g_1023[2][2];
            union U0 ****l_4373 = &l_4374;
            int i;
            l_4316 = ((*g_3230) = l_4322);
            for (l_27 = 3; (l_27 >= 0); l_27 -= 1)
            { /* block id: 1999 */
                union U0 *l_4324 = &g_15;
                l_4325 = l_4324;
            }
            (*g_2852) ^= (safe_lshift_func_int16_t_s_u((((((*g_652) = (l_4328 , p_12)) == ((p_13.f0 < (safe_mul_func_int16_t_s_s((safe_sub_func_int16_t_s_s((1UL || (p_13.f0 < ((++(**g_1052)) <= (((*g_134) = 0x9F007509DA90C6BCLL) != 0x8C992A305A860732LL)))), 0x89C8L)), ((l_4335 = (safe_add_func_uint8_t_u_u(((*l_4341)--), (p_13 , p_13.f1)))) ^ 0xFB83L)))) < 0x8BL)) >= l_4344[4]) >= 0x8AF96AB8CA2FDA58LL), (*l_4316)));
            for (g_392 = 0; (g_392 <= 3); g_392 += 1)
            { /* block id: 2010 */
                int32_t l_4353 = 0xF796855FL;
                int i, j, k;
                for (g_374.f0 = 1; (g_374.f0 <= 8); g_374.f0 += 1)
                { /* block id: 2013 */
                    int8_t *l_4350 = &g_374.f1;
                    int64_t l_4362 = 0xFD71BC48CFE875B2LL;
                    int32_t l_4370 = (-1L);
                    int i, j, k;
                    ++g_4345;
                    l_4370 ^= ((safe_lshift_func_uint8_t_u_u(((l_4350 == (void*)0) , 0x8AL), g_2279[g_256][g_392][(g_256 + 5)])) <= ((((((safe_mul_func_uint8_t_u_u(l_4353, (safe_add_func_uint16_t_u_u(p_13.f0, ((((1UL > ((((*l_4316) = ((((((safe_div_func_uint64_t_u_u(((safe_mod_func_int16_t_s_s((l_4362 >= (((!(!(safe_mul_func_uint8_t_u_u(((((+p_13.f0) ^ 0x35544086L) || (**g_4305)) || (*l_4316)), 251UL)))) , (**g_3364)) >= (*g_134))), 0xB47AL)) & l_4362), 1UL)) > l_4353) , l_4353) , l_4368[8]) != l_4369) , l_4328)) ^ 0xC8C2311EL) && (**g_4305))) > l_4335) , (*l_4316)) , p_13.f0))))) && p_13.f0) > 5UL) <= 0xA9L) , 1UL) | p_13.f0));
                }
                (*g_2852) = ((*l_4316) = (safe_lshift_func_uint8_t_u_s(((void*)0 == l_4373), (safe_div_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(g_2279[g_256][g_256][(g_392 + 5)], ((((+(**g_1052)) && 0UL) != 0xE4L) | (**g_4305)))), 0x1755L)))));
                (*g_2852) = p_13.f0;
            }
        }
    }
    return p_13.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_517 g_2852 g_810 g_3230
 * writes: g_517 g_810 g_715
 */
static int32_t  func_28(int16_t * const  p_29, const uint64_t  p_30)
{ /* block id: 1763 */
    const uint16_t l_3940 = 65533UL;
    int32_t l_3944 = 0x7EEA68D4L;
    int32_t l_3947 = 0xF2DE0050L;
    int32_t l_3948[3];
    uint32_t l_3950 = 0x9710C32CL;
    int16_t **l_3953[4];
    int32_t *l_3955 = (void*)0;
    union U0 *l_3985 = (void*)0;
    uint16_t **l_3987[8][8] = {{&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053},{(void*)0,(void*)0,(void*)0,&g_1053,&g_1053,(void*)0,&g_1053,&g_1053},{&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053},{&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053},{&g_1053,&g_1053,(void*)0,&g_1053,&g_1053,(void*)0,(void*)0,(void*)0},{&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,&g_1053},{(void*)0,&g_1053,&g_1053,(void*)0,&g_1053,&g_1053,(void*)0,&g_1053},{&g_1053,&g_1053,(void*)0,(void*)0,(void*)0,(void*)0,&g_1053,&g_1053}};
    int16_t l_4000 = 1L;
    uint64_t * const *l_4080 = &g_134;
    uint64_t * const * const *l_4079 = &l_4080;
    uint64_t * const * const **l_4078 = &l_4079;
    int32_t ** const * const l_4086 = &g_3230;
    uint64_t ***l_4138 = &g_1085;
    int16_t l_4176 = 0xE99DL;
    uint32_t l_4177[4][10][6] = {{{4294967295UL,0x8A6E756EL,9UL,0x9B16F20AL,4294967295UL,0x3A940C32L},{1UL,0x8A6E756EL,0xB499486AL,3UL,8UL,0x95D9D44AL},{8UL,0xB3AE5832L,0x6ABD82D1L,0x22D7AE03L,1UL,1UL},{0UL,0UL,0x32C43A76L,0x303EEE54L,0x6FBFC68AL,1UL},{0xF1BDEBB8L,0x2DE911ABL,0UL,4294967286UL,1UL,4294967295UL},{1UL,4294967295UL,0x95D9D44AL,0x41E8FF87L,1UL,4294967286UL},{0xC9F68B9AL,4294967295UL,4294967295UL,0x5452E060L,4294967295UL,0x799CD1F0L},{0UL,4294967295UL,0x24B5D6F1L,0x3F274F87L,4294967295UL,4294967295UL},{0xD4B0CEA2L,4294967295UL,4294967295UL,0xE2C7A386L,1UL,6UL},{0xB3AE5832L,0x3F274F87L,8UL,0xDD106EE1L,0x28ABE70AL,0xE2C7A386L}},{{4294967295UL,0x948F1282L,0UL,0x62F69F48L,0x72EC37DBL,0x303EEE54L},{0UL,1UL,0x76400C45L,0xC9F68B9AL,0UL,8UL},{1UL,0x5452E060L,5UL,4294967295UL,9UL,1UL},{0x2DE911ABL,0UL,0xC9F68B9AL,1UL,1UL,0xDD106EE1L},{4294967295UL,0x841D96CAL,0x54DB15C5L,1UL,0x75C05CB7L,0x0A72DC39L},{0x6FBFC68AL,0x28ABE70AL,0xDB3FE38BL,4294967289UL,0xB80FE4C5L,0x685D98EBL},{0xD7F2C50AL,0UL,1UL,0x0A72DC39L,0x0A72DC39L,1UL},{4294967295UL,4294967295UL,4294967295UL,0xA09E798FL,8UL,0x30BE817CL},{0xFD5EF0C1L,0x5D75BAD8L,4294967286UL,0xF1BDEBB8L,4294967289UL,4294967295UL},{4294967295UL,0xFD5EF0C1L,4294967286UL,0xED754EAAL,4294967295UL,0x30BE817CL}},{{0xDB3FE38BL,0xED754EAAL,4294967295UL,0xB499486AL,0xA20E1C9EL,1UL},{0xB499486AL,0xA20E1C9EL,1UL,0x76400C45L,4294967291UL,0x685D98EBL},{0x36882A50L,3UL,0xDB3FE38BL,0x3968B3E0L,0x6C129ADFL,0x0A72DC39L},{0x6C129ADFL,0xC9F68B9AL,0x54DB15C5L,0UL,0x95D9D44AL,0xDD106EE1L},{4294967295UL,8UL,0xC9F68B9AL,0x2DE911ABL,0x685D98EBL,1UL},{0xCC2CDC7DL,9UL,5UL,0x36882A50L,4294967289UL,8UL},{4294967286UL,0x4DB87F14L,0x76400C45L,0x3CF5212CL,4294967295UL,0x303EEE54L},{1UL,0x0DEDFDD1L,0UL,9UL,0xD7F2C50AL,0xE2C7A386L},{0x32C43A76L,4294967286UL,8UL,0x34FE1598L,4294967295UL,6UL},{1UL,1UL,4294967295UL,8UL,0x9B16F20AL,4294967295UL}},{{4294967295UL,0x75C05CB7L,0x24B5D6F1L,8UL,0x0DEDFDD1L,0x799CD1F0L},{4294967289UL,0x0A72DC39L,0x6ABD82D1L,0xB3AE5832L,8UL,0x8A6E756EL},{0x62F69F48L,0xA09E798FL,0x72EC37DBL,0x28ABE70AL,0xC9F68B9AL,0xB80FE4C5L},{0x95D9D44AL,5UL,0x3A940C32L,0xA20E1C9EL,3UL,4294967295UL},{0x303EEE54L,0x3A940C32L,4294967295UL,4294967295UL,0xA20E1C9EL,4294967295UL},{0x28ABE70AL,0x75C05CB7L,0x28ABE70AL,1UL,0xED754EAAL,0x72EC37DBL},{0x9B16F20AL,0x6C129ADFL,3UL,1UL,0xFD5EF0C1L,1UL},{0x36882A50L,4294967293UL,0x32C43A76L,1UL,0x5D75BAD8L,1UL},{0x9B16F20AL,0x4DB87F14L,4294967289UL,1UL,4294967295UL,0x62F69F48L},{0x28ABE70AL,0x3F274F87L,4294967293UL,4294967295UL,0UL,4294967295UL}}};
    int32_t l_4181 = 4L;
    int32_t ***l_4197 = &g_143;
    int64_t l_4204 = 0xBC62773D59F121BCLL;
    int64_t ****l_4228[7][6] = {{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,&g_1620,&g_1620,(void*)0,&g_1620,(void*)0},{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,(void*)0},{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,(void*)0,&g_1620,(void*)0,&g_1620,&g_1620},{(void*)0,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    uint8_t ****l_4260 = &g_4258[0][0];
    int16_t l_4279 = 0x059AL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_3948[i] = 0x4C3D2611L;
    for (i = 0; i < 4; i++)
        l_3953[i] = &g_35;
    for (g_517 = 0; (g_517 < 49); ++g_517)
    { /* block id: 1766 */
        if (l_3940)
            break;
    }
    if (p_30)
    { /* block id: 1769 */
        uint32_t l_3941 = 0x185060E9L;
        int32_t *l_3945 = &g_354;
        int32_t *l_3946[1][8] = {{&g_390,&g_71,&g_390,&g_390,&g_71,&g_390,&g_390,&g_71}};
        int8_t l_3949[9] = {0xB1L,0xE0L,0xE0L,0xB1L,0xE0L,0xE0L,0xB1L,0xE0L,0xE0L};
        int i, j;
        ++l_3941;
        l_3950--;
    }
    else
    { /* block id: 1772 */
        int32_t *l_3954 = &g_5[2];
        int32_t l_3964 = 1L;
        uint16_t **l_3967[1];
        uint16_t ***l_3968 = (void*)0;
        uint16_t ***l_3969 = (void*)0;
        uint16_t **l_3970 = &g_1053;
        uint32_t l_3986 = 4UL;
        uint8_t **l_3990 = &g_660[3][3][0];
        int16_t *l_3993 = &g_3350;
        uint8_t l_4065 = 0x2DL;
        union U0 l_4085 = {65528UL};
        int16_t l_4111 = 0x3014L;
        int32_t l_4113[8][5][6] = {{{0x41FF79BAL,0x725F7C44L,0x41FF79BAL,(-8L),0L,8L},{0xEF4A1C44L,(-3L),(-1L),(-7L),0x6C3DE2D4L,1L},{1L,8L,1L,(-7L),0xEF4A1C44L,(-8L)},{0xEF4A1C44L,6L,0x246EE50FL,(-8L),(-2L),0L},{0x41FF79BAL,0xB3630F9BL,(-1L),0x725F7C44L,1L,0x4478DAC8L}},{{9L,(-7L),0xF7C31BF2L,5L,1L,(-3L)},{(-2L),0xB3630F9BL,0xEF4A1C44L,0xB3630F9BL,(-2L),5L},{0xF7C31BF2L,6L,0xAE77C080L,0L,0xEF4A1C44L,(-1L)},{0xAE77C080L,8L,(-2L),6L,0x6C3DE2D4L,(-1L)},{0x334493EBL,(-3L),0xAE77C080L,0x2B4BBE08L,0L,5L}},{{0x6C3DE2D4L,0x725F7C44L,0xEF4A1C44L,4L,0xF7C31BF2L,(-3L)},{(-8L),0x088431ADL,0xF7C31BF2L,1L,0x859FC472L,0x4478DAC8L},{(-8L),0L,(-1L),4L,(-1L),0L},{0x6C3DE2D4L,(-1L),0xF7C31BF2L,(-8L),(-1L),0L},{1L,(-8L),0xAE77C080L,0L,0x4EA76F88L,0x088431ADL}},{{0xEF4A1C44L,(-8L),0x334493EBL,1L,(-1L),5L},{9L,(-1L),0x6C3DE2D4L,6L,(-2L),8L},{1L,1L,(-8L),4L,(-10L),(-8L)},{0x4EA76F88L,0xB3630F9BL,(-8L),8L,9L,8L},{0x6C3DE2D4L,8L,0x6C3DE2D4L,0L,0x859FC472L,5L}},{{0x41FF79BAL,(-7L),0x334493EBL,0x4478DAC8L,0xBC226895L,0x088431ADL},{0x246EE50FL,5L,0xAE77C080L,0x4478DAC8L,0x41FF79BAL,0L},{0x41FF79BAL,0L,0xF7C31BF2L,0L,1L,1L},{0x6C3DE2D4L,6L,(-2L),8L,0xAE77C080L,0x725F7C44L},{0x4EA76F88L,0x4478DAC8L,9L,4L,0xAE77C080L,(-7L)}},{{1L,6L,0x41FF79BAL,6L,1L,4L},{9L,0L,0xEF4A1C44L,1L,0x41FF79BAL,(-1L)},{0xEF4A1C44L,5L,1L,0L,0xBC226895L,(-1L)},{1L,(-7L),0xEF4A1C44L,(-8L),0x859FC472L,4L},{0xBC226895L,8L,0x41FF79BAL,0x2B4BBE08L,9L,(-7L)}},{{(-1L),0xB3630F9BL,9L,0x088431ADL,(-10L),0x725F7C44L},{(-1L),1L,(-2L),0x2B4BBE08L,(-2L),1L},{0xBC226895L,(-1L),0xF7C31BF2L,(-8L),(-1L),0L},{1L,(-8L),0xAE77C080L,0L,0x4EA76F88L,0x088431ADL},{0xEF4A1C44L,(-8L),0x334493EBL,1L,(-1L),5L}},{{9L,(-1L),0x6C3DE2D4L,6L,(-2L),8L},{1L,1L,(-8L),4L,(-10L),(-8L)},{0x4EA76F88L,0xB3630F9BL,(-8L),8L,9L,8L},{0x6C3DE2D4L,8L,0x6C3DE2D4L,0L,0x859FC472L,5L},{0x41FF79BAL,(-7L),0x334493EBL,0x4478DAC8L,0xBC226895L,0x088431ADL}}};
        int64_t ** const l_4128 = &g_3365;
        uint64_t ***l_4139 = &g_1085;
        uint32_t l_4151 = 1UL;
        int32_t *l_4152 = &g_394;
        uint8_t l_4158 = 0xBCL;
        uint32_t **l_4161 = (void*)0;
        int16_t l_4175 = (-1L);
        int64_t l_4199[1][8];
        int32_t l_4202 = 0x22FBDA98L;
        int64_t ****l_4229 = &g_1620;
        int32_t l_4280 = 1L;
        int8_t **l_4306 = &g_1285;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_3967[i] = &g_1053;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 8; j++)
                l_4199[i][j] = 0xC4E30B3B5457C0CELL;
        }
        (*g_2852) &= 0x844507D7L;
        l_3955 = l_3954;
    }
    (*g_3230) = &l_4181;
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_2444 g_2445 g_135 g_1480 g_1481 g_652 g_133 g_1285 g_374.f1 g_1025 g_3246 g_932 g_144 g_337 g_5 g_141 g_651 g_909 g_1053 g_74 g_2852 g_810 g_3230 g_3275 g_2851 g_1085 g_134 g_1052 g_1588 g_3338 g_3350 g_3364 g_113 g_3365 g_681 g_35 g_256 g_8 g_289 g_188 g_52 g_251 g_15.f1 g_100 g_245 g_97 g_346 g_71 g_143 g_209 g_250 g_354 g_374.f0 g_394 g_390 g_393 g_495 g_169 g_517 g_392 g_650 g_659 g_682 g_3430 g_660 g_3247 g_3248 g_3500 g_2868 g_2869 g_717 g_679 g_3638 g_3642 g_3690 g_3721 g_3781 g_1118 g_3936 g_65
 * writes: g_3230 g_373 g_133 g_52 g_374.f1 g_909 g_810 g_715 g_188 g_337 g_2852 g_135 g_100 g_681 g_1589 g_113 g_74 g_71 g_256 g_289 g_346 g_354 g_97 g_374.f0 g_394 g_495 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_390 g_675 g_65 g_3350 g_1120 g_679 g_717 g_3690 g_652 g_3796 g_3815 g_1588 g_3820 g_659 g_651 g_1052 g_3936
 */
static int16_t * func_31(int16_t * p_32, int16_t * p_33, int16_t * p_34)
{ /* block id: 1455 */
    int16_t l_3227 = 8L;
    int32_t **l_3228 = (void*)0;
    int32_t ***l_3229 = &l_3228;
    union U0 *l_3235[10];
    int64_t *l_3237 = &g_681;
    int64_t **l_3236 = &l_3237;
    uint64_t ***l_3253[1][4];
    uint64_t ****l_3252 = &l_3253[0][1];
    int32_t l_3254[1][2];
    int32_t l_3255 = 0L;
    int8_t *l_3256[10][5] = {{&g_15.f1,&g_374.f1,&g_188,&g_188,&g_374.f1},{(void*)0,&g_15.f1,&g_393[4][1][1],&g_393[4][1][1],&g_15.f1},{&g_15.f1,&g_374.f1,&g_188,&g_188,&g_374.f1},{(void*)0,&g_15.f1,&g_393[4][1][1],&g_393[4][1][1],&g_15.f1},{&g_15.f1,&g_374.f1,&g_188,&g_188,&g_374.f1},{(void*)0,&g_15.f1,&g_393[4][1][1],&g_393[4][1][1],&g_15.f1},{(void*)0,&g_717,&g_374.f1,&g_374.f1,&g_717},{(void*)0,&g_188,&g_15.f1,&g_15.f1,&g_188},{(void*)0,&g_717,&g_374.f1,&g_374.f1,&g_717},{(void*)0,&g_188,&g_15.f1,&g_15.f1,&g_188}};
    int64_t l_3337 = 8L;
    uint16_t l_3416 = 0x826BL;
    uint8_t *l_3468 = (void*)0;
    int16_t ***l_3474 = &g_2869[3];
    int32_t **l_3558 = (void*)0;
    uint8_t l_3560 = 0xB9L;
    int64_t l_3621 = 0x2AFAF74780393C1ELL;
    uint64_t l_3635[1];
    int32_t l_3644 = (-9L);
    int32_t l_3647 = (-1L);
    int32_t *l_3748[5];
    uint8_t l_3800 = 0xCCL;
    int64_t l_3829[5][6] = {{0x60395F92869247F0LL,0x60395F92869247F0LL,1L,0x60395F92869247F0LL,0x60395F92869247F0LL,1L},{0x60395F92869247F0LL,0x60395F92869247F0LL,1L,0x60395F92869247F0LL,0x60395F92869247F0LL,1L},{0x60395F92869247F0LL,0x60395F92869247F0LL,1L,0x60395F92869247F0LL,0x60395F92869247F0LL,1L},{0x60395F92869247F0LL,0x60395F92869247F0LL,1L,0x60395F92869247F0LL,0x60395F92869247F0LL,1L},{0x60395F92869247F0LL,0x60395F92869247F0LL,1L,0x60395F92869247F0LL,0x60395F92869247F0LL,1L}};
    int32_t **l_3830 = (void*)0;
    uint32_t l_3855 = 0UL;
    uint32_t l_3869[6] = {0x19A534B5L,0x19A534B5L,0x0DB64179L,0x19A534B5L,0x19A534B5L,0x0DB64179L};
    uint16_t **l_3889 = &g_1053;
    int64_t l_3895 = 0x595292F83EE3BA0DLL;
    uint64_t l_3921 = 0xADC008FC93D2E303LL;
    uint64_t ** const * const *l_3933 = (void*)0;
    int i, j;
    for (i = 0; i < 10; i++)
        l_3235[i] = &g_15;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
            l_3253[i][j] = &g_1085;
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_3254[i][j] = (-3L);
    }
    for (i = 0; i < 1; i++)
        l_3635[i] = 0x719AA2B733BA09D6LL;
    for (i = 0; i < 5; i++)
        l_3748[i] = &l_3254[0][1];
    (*g_1025) = (((l_3227 != l_3227) >= ((l_3227 > (((*l_3229) = l_3228) != (g_3230 = &g_715[3]))) > (l_3227 && (l_3227 == (safe_rshift_func_uint8_t_u_s((l_3227 > ((safe_sub_func_int32_t_s_s((((((((*g_2444) & (*g_1480)) == 0xF7615C6BL) , 6L) || l_3227) , l_3227) ^ 0x1E3F5E35869EC177LL), (*g_652))) & 8L)), (*g_1285))))))) , l_3235[5]);
    if (((l_3236 == (void*)0) <= ((l_3254[0][0] &= (((*g_1285) = ((safe_mod_func_uint32_t_u_u(((*g_652) = (safe_rshift_func_int8_t_s_s((*g_1285), 5))), (safe_lshift_func_int8_t_s_s((((**g_932) = (safe_add_func_int16_t_s_s(l_3227, ((void*)0 == g_3246)))) , (*g_1285)), 4)))) < 1UL)) & ((((((((!(safe_rshift_func_uint8_t_u_s((0xA65CL == l_3227), l_3227))) || (*g_337)) >= l_3227) < 0x8FL) < l_3227) , l_3227) , l_3252) != &l_3253[0][1]))) == l_3255)))
    { /* block id: 1463 */
        return p_32;
    }
    else
    { /* block id: 1465 */
        union U0 l_3257 = {0x34CDL};
        uint8_t *l_3258[9][1][4] = {{{&g_2436[2],(void*)0,(void*)0,(void*)0}},{{&g_2436[1],&g_2436[1],&g_97,(void*)0}},{{(void*)0,&g_2436[2],&g_97,&g_2436[2]}},{{&g_2436[1],&g_2436[7],(void*)0,&g_97}},{{&g_2436[2],&g_2436[7],&g_2436[7],&g_2436[2]}},{{&g_2436[7],&g_2436[2],&g_2436[1],(void*)0}},{{&g_2436[7],&g_2436[1],&g_2436[7],(void*)0}},{{&g_2436[2],(void*)0,(void*)0,(void*)0}},{{&g_2436[1],&g_2436[1],&g_97,(void*)0}}};
        uint8_t l_3259 = 0xACL;
        int32_t l_3260[6] = {1L,1L,1L,1L,1L,1L};
        uint32_t *l_3261 = &g_909[2];
        int32_t l_3266 = 0xF9B34181L;
        int32_t ** const *l_3292 = &g_143;
        int32_t ** const **l_3291[4][6] = {{&l_3292,&l_3292,(void*)0,&l_3292,&l_3292,(void*)0},{&l_3292,&l_3292,(void*)0,&l_3292,&l_3292,(void*)0},{&l_3292,&l_3292,(void*)0,&l_3292,&l_3292,(void*)0},{&l_3292,&l_3292,(void*)0,&l_3292,&l_3292,(void*)0}};
        int32_t ** const ***l_3290[8] = {&l_3291[3][5],&l_3291[3][5],(void*)0,&l_3291[3][5],&l_3291[3][5],(void*)0,&l_3291[3][5],&l_3291[3][5]};
        uint16_t *l_3293 = &l_3257.f0;
        int16_t l_3297 = 4L;
        int32_t * const *l_3348[8][6] = {{(void*)0,&g_337,(void*)0,&g_715[3],&g_337,&g_715[2]},{(void*)0,&g_337,&g_715[3],&g_715[3],&g_337,(void*)0},{(void*)0,&g_337,&g_715[2],&g_715[3],&g_337,&g_715[3]},{(void*)0,&g_337,(void*)0,&g_715[3],&g_337,&g_715[2]},{(void*)0,&g_337,&g_715[3],&g_715[3],&g_337,(void*)0},{(void*)0,&g_337,&g_715[2],&g_715[3],&g_337,&g_715[3]},{(void*)0,&g_337,(void*)0,&g_715[3],&g_337,&g_715[2]},{(void*)0,&g_337,&g_715[3],&g_715[3],&g_337,(void*)0}};
        int32_t * const **l_3347 = &l_3348[7][2];
        int32_t * const ***l_3346 = &l_3347;
        uint16_t ***l_3406 = &g_1052;
        uint16_t ****l_3405 = &l_3406;
        int16_t l_3419[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
        int64_t l_3442 = (-1L);
        uint32_t l_3481[5];
        const int32_t *l_3499[5][1][2] = {{{&g_3500,&g_3500}},{{&g_3500,&g_3500}},{{&g_3500,&g_3500}},{{&g_3500,&g_3500}},{{&g_3500,&g_3500}}};
        const int32_t **l_3498 = &l_3499[4][0][0];
        uint64_t *****l_3739 = &l_3252;
        uint8_t l_3769 = 0x14L;
        uint64_t l_3799 = 0xC95302426DE22B8BLL;
        int16_t ****l_3809 = &l_3474;
        int16_t ** const *l_3811 = (void*)0;
        int16_t ** const **l_3810 = &l_3811;
        int16_t ** const ***l_3812 = &l_3810;
        int16_t ** const **l_3814 = &l_3811;
        int16_t ** const ***l_3813[10][5][5] = {{{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,(void*)0},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,(void*)0}},{{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,&l_3814,&l_3814},{(void*)0,&l_3814,(void*)0,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,&l_3814,&l_3814}},{{&l_3814,&l_3814,&l_3814,&l_3814,(void*)0},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,(void*)0},{&l_3814,&l_3814,(void*)0,&l_3814,&l_3814}},{{&l_3814,(void*)0,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,&l_3814,(void*)0},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,(void*)0,(void*)0}},{{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,(void*)0,(void*)0,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,&l_3814,&l_3814}},{{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{(void*)0,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814}},{{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,(void*)0},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814}},{{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,(void*)0},{&l_3814,&l_3814,(void*)0,(void*)0,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814}},{{&l_3814,&l_3814,&l_3814,(void*)0,(void*)0},{&l_3814,&l_3814,&l_3814,(void*)0,&l_3814},{&l_3814,(void*)0,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814}},{{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{(void*)0,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814},{&l_3814,&l_3814,(void*)0,(void*)0,&l_3814},{&l_3814,&l_3814,&l_3814,&l_3814,&l_3814}}};
        int32_t ******l_3819 = &g_1588;
        int8_t l_3831 = 0xBAL;
        int16_t l_3832 = 0x7EFCL;
        uint64_t l_3932 = 0xAB2D0FCB1ABA9696LL;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_3481[i] = 4294967294UL;
        if (((((l_3254[0][0] = (((**g_651) , l_3256[2][0]) != ((l_3260[2] &= ((l_3257 = l_3257) , (l_3259 = 0x2FL))) , &g_393[4][1][1]))) & (((((++(*l_3261)) != ((safe_mul_func_int16_t_s_s(l_3266, (safe_mul_func_uint8_t_u_u(l_3266, (*g_1285))))) ^ (((safe_lshift_func_uint16_t_u_u((0x6AC9L <= l_3266), (*g_1053))) > 0x6744L) | 18446744073709551615UL))) >= 0x341D1FD420E5A4EFLL) <= 0UL) , l_3266)) , 0x5D07L) | (-1L)))
        { /* block id: 1471 */
            int8_t l_3299 = (-1L);
            int64_t l_3300[5] = {1L,1L,1L,1L,1L};
            int i;
            (*g_2852) &= ((*g_1285) && 0xC6L);
            (*g_3230) = &l_3266;
            for (l_3259 = 0; (l_3259 <= 37); l_3259 = safe_add_func_int32_t_s_s(l_3259, 1))
            { /* block id: 1476 */
                uint64_t l_3280 = 18446744073709551615UL;
                int32_t l_3283 = 0x6E01D204L;
                int32_t *l_3295 = &g_675;
                int16_t *l_3296 = &g_100[4];
                uint16_t l_3298 = 0xB903L;
                for (g_188 = (-7); (g_188 > (-26)); g_188 = safe_sub_func_uint64_t_u_u(g_188, 2))
                { /* block id: 1479 */
                    uint64_t l_3279 = 18446744073709551615UL;
                    if (l_3260[2])
                    { /* block id: 1480 */
                        (*g_3275) = ((*g_3230) = &l_3266);
                        if (l_3260[2])
                            continue;
                        (*g_337) |= ((safe_mod_func_uint8_t_u_u(0xF1L, 0x71L)) == 6UL);
                        (*g_3230) = &l_3260[2];
                    }
                    else
                    { /* block id: 1486 */
                        volatile int32_t **l_3278 = &g_2852;
                        (*l_3278) = (*g_2851);
                        l_3266 = l_3279;
                    }
                }
                if (l_3280)
                    break;
                (*g_2852) = (((*g_1285) = (safe_mod_func_int64_t_s_s((l_3283 = l_3280), (safe_rshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_s(((((safe_div_func_uint64_t_u_u((((void*)0 != l_3290[0]) && ((l_3293 == ((l_3257 , ((safe_unary_minus_func_int16_t_s((((((****l_3252) = 0xB5216504C074FA04LL) == (((((l_3260[5] != ((*l_3296) = (l_3295 == (void*)0))) & l_3280) != l_3297) <= 0x269399FCB3FEB5C0LL) , 0xCD4506F1E0BB291ELL)) || (*g_1285)) && l_3280))) <= l_3280)) , (*g_1052))) > l_3298)), l_3299)) , l_3260[2]) > l_3299) ^ l_3300[4]), l_3280)), l_3297))))) ^ 0xECL);
            }
        }
        else
        { /* block id: 1498 */
            int32_t l_3307 = 8L;
            int32_t * const *l_3326 = &g_144;
            int32_t * const **l_3325 = &l_3326;
            int32_t * const ***l_3324 = &l_3325;
            int32_t ****l_3336[9] = {(void*)0,(void*)0,&g_209,(void*)0,(void*)0,&g_209,(void*)0,(void*)0,&g_209};
            uint8_t l_3339[8] = {0x8CL,0x8CL,0x8CL,0x8CL,0x8CL,0x8CL,0x8CL,0x8CL};
            uint16_t **** const l_3404 = (void*)0;
            uint8_t l_3407[3];
            int32_t *l_3538 = (void*)0;
            const uint8_t l_3559 = 253UL;
            int32_t l_3566 = 0xA4A694B8L;
            int32_t l_3568 = 0xFFDB1485L;
            int32_t l_3571 = (-1L);
            int32_t l_3577 = 0x53CC5481L;
            int32_t l_3583 = (-10L);
            int32_t l_3585[2];
            uint16_t l_3598 = 0x8268L;
            int32_t *l_3648 = (void*)0;
            int32_t l_3704 = (-5L);
            uint8_t l_3713 = 0x86L;
            int64_t l_3725 = (-6L);
            uint32_t l_3742 = 0xCD4EC0DDL;
            uint32_t l_3802 = 0UL;
            int i;
            for (i = 0; i < 3; i++)
                l_3407[i] = 0x46L;
            for (i = 0; i < 2; i++)
                l_3585[i] = 5L;
            for (l_3297 = 16; (l_3297 < (-19)); --l_3297)
            { /* block id: 1501 */
                int16_t l_3323 = 0x5D7AL;
                union U0 l_3381[8] = {{0UL},{65533UL},{0UL},{0UL},{65533UL},{0UL},{0UL},{65533UL}};
                int32_t l_3395 = 0x8C5F7E98L;
                int32_t l_3396 = 0xBB5438C5L;
                int32_t l_3421 = 0xD4089E0EL;
                int i;
                if ((**g_3275))
                { /* block id: 1502 */
                    if (l_3260[4])
                        break;
                    (*g_2852) = (((safe_sub_func_uint64_t_u_u((l_3307 || ((safe_rshift_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((((*g_1480) | 0xCAAA48FEBACAAB96LL) | (l_3307 == ((~(safe_sub_func_uint64_t_u_u((*g_134), 0xD45164D125A84CFFLL))) != ((safe_rshift_func_uint16_t_u_s((safe_mul_func_int8_t_s_s((((safe_mul_func_uint8_t_u_u(l_3323, (l_3324 == ((*g_1588) = ((safe_add_func_int8_t_s_s((safe_unary_minus_func_int16_t_s((safe_mod_func_int64_t_s_s(((*l_3237) = ((safe_add_func_int64_t_s_s(l_3323, 1L)) < 0L)), l_3266)))), l_3323)) , l_3336[2]))))) <= l_3337) < (**g_651)), l_3323)), g_3338[4])) > l_3307)))), 1)), l_3257.f1)) < (*g_1053)), 6)) < 4L)), l_3323)) , l_3339[5]) == l_3257.f1);
                }
                else
                { /* block id: 1507 */
                    int32_t ****l_3340 = &g_209;
                    uint32_t l_3345 = 0x8EA6AA08L;
                    int32_t * const ****l_3349 = &l_3346;
                    uint64_t *****l_3374 = (void*)0;
                    int32_t l_3378[4][7] = {{(-3L),(-3L),1L,1L,(-3L),(-3L),1L},{0x5025FF58L,(-10L),0x5025FF58L,(-10L),0x5025FF58L,(-10L),0x5025FF58L},{(-3L),1L,1L,(-3L),(-3L),1L,1L},{4L,(-10L),4L,(-10L),4L,(-10L),4L}};
                    union U0 l_3392[9][1][10] = {{{{0xE9E5L},{0xE9E5L},{0x286FL},{0x8558L},{0x8B72L},{0UL},{0x6C8DL},{0UL},{0x8B72L},{0x8558L}}},{{{0x8558L},{0xF53BL},{0x8558L},{0UL},{0xF4A8L},{0x5A27L},{0x6C8DL},{0x6C8DL},{0x5A27L},{0xF4A8L}}},{{{0x286FL},{0xE9E5L},{0xE9E5L},{0x286FL},{0x8558L},{0x8B72L},{0UL},{0x6C8DL},{0UL},{0x8B72L}}},{{{0x5A27L},{0x5E6EL},{0x8558L},{0x5E6EL},{0x5A27L},{0x67CDL},{0xE9E5L},{0UL},{0UL},{0xE9E5L}}},{{{0x6C8DL},{0x67CDL},{0x286FL},{0x286FL},{0x67CDL},{0x6C8DL},{0xF4A8L},{0xE9E5L},{0x5A27L},{0xE9E5L}}},{{{0x5E6EL},{0x286FL},{0x5A27L},{0UL},{0x5A27L},{0x286FL},{0x5E6EL},{0xF4A8L},{0x8B72L},{0x8B72L}}},{{{0x5E6EL},{0x8B72L},{0x6C8DL},{0x8558L},{0x8558L},{0x6C8DL},{0x8B72L},{0xF53BL},{0x286FL},{0x8B72L}}},{{{0x8558L},{0x5A27L},{0xF53BL},{0x286FL},{0x8B72L},{0x286FL},{0xF53BL},{0x5A27L},{0x8558L},{0x67CDL}}},{{{0x6C8DL},{0xE9E5L},{0xF53BL},{0x8B72L},{0x5A27L},{0x5A27L},{0x8B72L},{0xF53BL},{0xE9E5L},{0x6C8DL}}}};
                    int32_t l_3436 = 0x93ABFA5DL;
                    int i, j, k;
                    if ((l_3260[5] <= (((l_3340 != &l_3325) > (**g_651)) == (~((~((*g_1285) = (((l_3307 == (**g_2851)) <= (safe_div_func_int32_t_s_s(l_3345, ((((*l_3349) = l_3346) != (void*)0) & 0x0359B5EEL)))) && l_3345))) , g_3350)))))
                    { /* block id: 1510 */
                        int16_t l_3359 = 0x7D2DL;
                        int64_t **l_3366 = &l_3237;
                        int64_t **l_3368[8][4] = {{(void*)0,&g_3365,(void*)0,(void*)0},{&g_3365,&g_3365,(void*)0,&g_3365},{&g_3365,(void*)0,(void*)0,&g_3365},{(void*)0,&g_3365,(void*)0,(void*)0},{&g_3365,&g_3365,(void*)0,&g_3365},{&g_3365,(void*)0,(void*)0,&g_3365},{(void*)0,&g_3365,(void*)0,(void*)0},{&g_3365,&g_3365,(void*)0,&g_3365}};
                        int64_t ***l_3367 = &l_3368[5][3];
                        int64_t *l_3373 = &g_113[2];
                        uint64_t ******l_3375 = &l_3374;
                        int64_t l_3376 = 0xD18C13F6CB67CE49LL;
                        int32_t l_3377 = 2L;
                        int i, j;
                        (*g_2852) &= ((safe_mod_func_uint8_t_u_u((safe_div_func_int32_t_s_s(((((safe_mul_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(((((*g_1285) = l_3359) , ((safe_div_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u(((l_3366 = (l_3236 = g_3364)) == ((*l_3367) = &g_3365)), ((safe_mod_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u((((*l_3237) = l_3323) > ((*l_3373) |= (-2L))), (0x987CL >= ((*g_1053) = ((((*l_3375) = l_3374) == (l_3323 , &l_3252)) && (-4L)))))) == 4UL), l_3339[5])) == 0x903EL))) & 0xCDL), l_3359)) && (**g_651))) != (-3L)), l_3376)), l_3307)) || 0x8AL) ^ l_3307) < l_3307), l_3323)), l_3323)) || 1L);
                        l_3377 ^= (l_3307 ^= (*g_337));
                        if (l_3345)
                            break;
                    }
                    else
                    { /* block id: 1523 */
                        l_3378[0][5] ^= l_3339[1];
                        (*g_3230) = func_67(func_58((((**g_3364) < ((l_3381[0] , p_32) == p_33)) != (safe_mod_func_uint32_t_u_u(0x27C85EE9L, (**g_651)))), (*g_3275), ((void*)0 != l_3256[2][0])));
                    }
                    (*g_2852) = l_3307;
                    if ((*g_2852))
                        break;
                    if ((safe_lshift_func_uint8_t_u_u((((l_3339[6] , ((safe_lshift_func_int8_t_s_s(((safe_mod_func_int64_t_s_s((18446744073709551607UL == ((**g_1085) &= (((((safe_mod_func_uint16_t_u_u(((**g_1052) = (l_3392[7][0][7] , 0x817AL)), 0x7663L)) < ((*g_1285) = ((((((*g_3365) <= ((l_3339[5] , (l_3395 = (safe_mul_func_int8_t_s_s(l_3307, (((g_113[1] |= 1L) <= l_3339[5]) , (*g_1285)))))) < (*g_652))) & l_3396) | (*g_652)) && 0x7E0B2195L) & l_3378[0][5]))) || 0xD2963135L) | l_3381[0].f1) != 0x4F93L))), (*g_1480))) <= l_3307), l_3323)) != (*g_3365))) , (void*)0) == &g_2115[1][2][1]), 7)))
                    { /* block id: 1534 */
                        int8_t l_3408 = 0L;
                        (*g_2852) = (safe_sub_func_uint64_t_u_u((((((l_3381[4] , 0xED430293L) , (safe_mul_func_uint8_t_u_u((!(((**g_651) > (safe_lshift_func_uint16_t_u_s(8UL, (((**g_1085) = ((((l_3381[0].f1 && (((l_3381[1] , l_3404) != l_3405) < ((((l_3339[1] && 7UL) || l_3323) > l_3407[0]) || (**g_3275)))) , l_3407[2]) || 4294967295UL) < l_3408)) , l_3381[0].f1)))) >= 0xAA6DL)), (*g_1285)))) || 0x1CBEF0AD67D9BD5ALL) , (**g_1052)) >= (*g_1053)), 6UL));
                    }
                    else
                    { /* block id: 1537 */
                        const uint16_t l_3409 = 65533UL;
                        int16_t *l_3420 = &g_100[5];
                        int32_t l_3422[1][9][1] = {{{0x3BFC5D0DL},{0x93E0E1C8L},{0x3BFC5D0DL},{0x93E0E1C8L},{0x3BFC5D0DL},{0x93E0E1C8L},{0x3BFC5D0DL},{0x93E0E1C8L},{0x3BFC5D0DL}}};
                        uint16_t l_3423 = 1UL;
                        int i, j, k;
                        (**g_2851) = (l_3381[0].f1 <= l_3409);
                        l_3421 = (((((&g_717 != &g_188) , (&g_1024[1] == &g_2997)) <= (safe_rshift_func_int8_t_s_u((((((~l_3323) , ((void*)0 == &g_2997)) <= ((*l_3420) = ((((+((l_3409 && (safe_add_func_int32_t_s_s(((++l_3416) | (l_3395 ^= ((**l_3349) == (**l_3349)))), (**g_651)))) && l_3419[4])) , 1L) >= l_3396) < (**g_1052)))) | (*g_652)) == 0L), l_3409))) > 0xB050CFAA92BBFE53LL) != l_3392[7][0][7].f0);
                        l_3423++;
                        (*g_2852) ^= (safe_add_func_uint8_t_u_u((l_3407[2] & 0x0B99L), ((((safe_sub_func_uint8_t_u_u((g_3430[0][6] , (0x48L || (l_3407[0] > 0xE4C6L))), (!((+0x0C63EB16L) | ((safe_div_func_int8_t_s_s(((~((**g_1085) = (l_3436 = 0xC1F79FB91D556516LL))) | l_3381[0].f1), l_3423)) <= l_3395))))) == 1UL) | (*g_1053)) , 1L)));
                    }
                }
            }
            if (l_3407[0])
            { /* block id: 1550 */
                uint32_t l_3437 = 0xF0F4A8CAL;
                uint8_t l_3438 = 250UL;
                (*g_2852) = l_3437;
                l_3438 = 0xB862D273L;
            }
            else
            { /* block id: 1553 */
                union U0 l_3441 = {0xCBD4L};
                int32_t l_3461 = (-5L);
                uint8_t **l_3469 = &l_3258[6][0][0];
                const uint32_t l_3486 = 4294967295UL;
                int16_t *l_3502 = &l_3419[4];
                int16_t l_3537 = 0x65C9L;
                int32_t *l_3539 = &g_392;
                (**g_2851) ^= (safe_add_func_uint8_t_u_u((((l_3441 , l_3442) ^ ((safe_div_func_int8_t_s_s(((safe_sub_func_int64_t_s_s((l_3441.f1 < ((*g_652) = ((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(l_3441.f1, 5)), (safe_lshift_func_uint8_t_u_u(((246UL <= ((*g_1285) || 0xCDL)) != l_3441.f0), 2)))) | ((*g_1285) <= 0L)))), (-6L))) | (**g_1052)), 0x80L)) | l_3441.f1)) > l_3339[5]), 0xEFL));
                l_3307 = (safe_add_func_uint16_t_u_u((l_3441.f1 != 0xCC358B35L), (l_3339[5] || ((*g_1285) = (l_3441.f1 >= (safe_sub_func_uint64_t_u_u((((safe_rshift_func_uint8_t_u_s(((l_3461 |= 0x93L) | (safe_sub_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(l_3339[5], 0xE939L)), ((l_3255 = (l_3337 , l_3441.f0)) == 0x6ED6A585L)))), (*g_1285))) , l_3441.f1) ^ l_3339[5]), (*g_3365))))))));
lbl_3550:
                if ((((((((*g_134)--) < (((((l_3468 = (*g_659)) == ((*l_3469) = (*g_659))) , (l_3441.f1 || l_3441.f1)) >= ((safe_sub_func_int32_t_s_s(0xAAC4D30AL, (**g_651))) > ((safe_mod_func_int8_t_s_s((-3L), (*g_1285))) >= (*g_1053)))) >= (**g_2851))) != 0x1415L) <= (*g_1285)) < l_3441.f0) | (**g_651)))
                { /* block id: 1563 */
                    int32_t l_3484 = (-1L);
                    int16_t l_3485 = (-7L);
                    uint64_t ***** const l_3493[10] = {&l_3252,&l_3252,&l_3252,&l_3252,&l_3252,&l_3252,&l_3252,&l_3252,&l_3252,&l_3252};
                    int i;
                    l_3307 = l_3407[1];
                    if ((((((**g_3246) == l_3474) && ((safe_add_func_int32_t_s_s(((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(l_3481[1], (((((((**g_651) != 0xFB8C330AL) & ((safe_mod_func_uint64_t_u_u(((**g_1085) = 1UL), (l_3307 || ((((l_3461 = 0x566EL) != (l_3485 = (l_3484 , (-10L)))) <= l_3484) == 7UL)))) && l_3407[0])) , l_3485) , (void*)0) == (void*)0) || l_3485))), l_3441.f1)) , l_3339[5]), l_3441.f1)) & l_3486)) , (**g_3364)) , 0x310468A0L))
                    { /* block id: 1568 */
                        uint32_t l_3501 = 0x1A892F86L;
                        int16_t *l_3503[3][9] = {{&l_3485,&l_3419[4],&l_3485,(void*)0,(void*)0,&l_3485,&l_3419[4],&l_3485,(void*)0},{&l_3227,(void*)0,(void*)0,&l_3485,&g_950,&l_3419[4],&l_3419[4],&g_950,&l_3485},{&l_3227,&l_3227,&l_3227,&g_100[4],&l_3419[4],(void*)0,&g_950,(void*)0,(void*)0}};
                        int i, j;
                        (*g_2852) = (safe_add_func_int64_t_s_s((((safe_lshift_func_int16_t_s_u((((safe_sub_func_uint16_t_u_u(((l_3485 || ((((***l_3292) = ((((void*)0 != l_3493[4]) , ((*l_3261) = ((**g_651) ^= ((((*g_1285) , ((l_3339[5] <= ((((4294967295UL <= (safe_mod_func_int64_t_s_s((*g_1480), ((safe_mul_func_int8_t_s_s((((l_3498 = (void*)0) == ((*l_3229) = &g_715[1])) , l_3501), l_3407[0])) , l_3441.f0)))) , (*g_3365)) != 0L) || l_3486)) ^ l_3307)) != l_3461) || 0x1F04L)))) , 0xE10273D1L)) , l_3407[2]) > l_3407[1])) | 0L), (-1L))) , l_3441.f0) , l_3461), l_3416)) < 3UL) , 0L), (**g_1085)));
                        return p_33;
                    }
                    else
                    { /* block id: 1576 */
                        return p_34;
                    }
                }
                else
                { /* block id: 1579 */
                    uint8_t l_3506 = 0UL;
                    int32_t l_3511 = 0x0A2B7346L;
                    uint32_t l_3514 = 0x82D98954L;
                    union U0 l_3530[10][7] = {{{0xE79AL},{8UL},{0x3B09L},{65535UL},{8UL},{65535UL},{0x3B09L}},{{0x4963L},{0x4963L},{65535UL},{0x4173L},{8UL},{65535UL},{8UL}},{{0UL},{0x3B09L},{0x3B09L},{0UL},{65535UL},{0xE79AL},{0UL}},{{0xC96EL},{8UL},{0x8514L},{0x8514L},{8UL},{0xC96EL},{65532UL}},{{0UL},{0UL},{0x2259L},{8UL},{8UL},{0x2259L},{0UL}},{{8UL},{65532UL},{0xC96EL},{8UL},{0x8514L},{0x8514L},{8UL}},{{0xE79AL},{0UL},{0xE79AL},{65535UL},{0UL},{0x3B09L},{0x3B09L}},{{0x4173L},{8UL},{65535UL},{8UL},{0x4173L},{65535UL},{0x4963L}},{{8UL},{0x3B09L},{65535UL},{8UL},{65535UL},{0x3B09L},{8UL}},{{0xC96EL},{0x4963L},{65532UL},{0x8514L},{0x4963L},{0x8514L},{65532UL}}};
                    int i, j;
                    if ((safe_div_func_uint64_t_u_u((l_3486 | ((*g_652) = ((l_3506 <= ((safe_div_func_uint8_t_u_u((l_3511 = l_3407[0]), l_3441.f1)) >= (safe_mod_func_uint8_t_u_u(0x77L, (-1L))))) != l_3461))), (((0UL & 0x0FFBFA21L) > 0xF9L) , (**l_3498)))))
                    { /* block id: 1582 */
                        union U0 l_3525 = {0x80FDL};
                        ++l_3514;
                        l_3307 |= (((safe_div_func_int32_t_s_s(((((***l_3406) = (safe_lshift_func_uint8_t_u_u(l_3486, 3))) >= (safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((((l_3525 , (-1L)) , ((8L | (((safe_rshift_func_uint8_t_u_u(l_3339[5], 0)) , l_3525.f0) | (safe_mod_func_int64_t_s_s(((l_3530[5][2] , (-1L)) || (((~(safe_rshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((!l_3441.f1), l_3407[0])), l_3525.f1))) < (*g_1285)) ^ (*g_652))), l_3525.f0)))) || l_3441.f1)) || (**g_3364)) && (**g_3364)), 5)), l_3537))) ^ 0L), 0x92C467EAL)) | l_3514) & l_3506);
                    }
                    else
                    { /* block id: 1586 */
                        l_3538 = (void*)0;
                        (*l_3498) = func_67((*g_2868));
                        return p_34;
                    }
                    l_3539 = &l_3511;
                }
                for (g_65 = 0; (g_65 <= 7); g_65 += 1)
                { /* block id: 1595 */
                    const union U0 *l_3540[5][9][5] = {{{&l_3441,&g_2271[0][1][5],&l_3441,&g_374,&g_374},{&l_3441,&g_2271[0][1][5],&l_3441,&g_374,&g_374},{&l_3441,&g_2271[0][1][5],&l_3441,&g_374,&g_374},{&l_3441,&g_2271[0][1][5],&l_3441,&g_374,&g_374},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441}},{{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441}},{{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441}},{{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441}},{{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_2271[1][3][6],&g_1118[2],&l_3441,&l_3441},{&g_1118[2],&g_374,&g_2271[0][1][5],&g_1118[2],&g_1118[2]},{&g_2271[0][1][5],&g_374,&g_2271[0][1][5],&g_1118[2],&g_1118[2]},{&g_2271[0][1][5],&g_374,&g_2271[0][1][5],&g_1118[2],&g_1118[2]}}};
                    int32_t l_3549 = 0x9C0EFB12L;
                    int i, j, k;
                    for (l_3257.f1 = 0; (l_3257.f1 <= 2); l_3257.f1 += 1)
                    { /* block id: 1598 */
                        int i;
                        (*l_3498) = &l_3307;
                    }
                    for (g_3350 = 0; (g_3350 <= 7); g_3350 += 1)
                    { /* block id: 1603 */
                        const union U0 **l_3541 = &g_1120;
                        int i;
                        if (l_3441.f1)
                            break;
                        (*l_3541) = l_3540[3][4][4];
                        (*g_2852) |= (safe_rshift_func_uint16_t_u_u((**g_1052), 0));
                        (*l_3498) = &l_3461;
                    }
                    if ((safe_add_func_uint32_t_u_u((**g_651), (safe_mul_func_int8_t_s_s((!(*g_134)), l_3549)))))
                    { /* block id: 1609 */
                        return p_32;
                    }
                    else
                    { /* block id: 1611 */
                        if (l_3549)
                            goto lbl_3550;
                    }
                    for (g_169 = 0; g_169 < 1; g_169 += 1)
                    {
                        g_679[g_169] = 1L;
                    }
                    for (g_390 = 7; (g_390 >= 0); g_390 -= 1)
                    { /* block id: 1617 */
                        volatile int32_t **l_3551 = &g_2852;
                        int i;
                        (*g_3230) = &l_3307;
                        (*l_3551) = (*g_2851);
                        (*l_3498) = (*g_3275);
                    }
                }
            }
            if (((l_3339[4] & ((**g_1052) >= ((safe_rshift_func_int8_t_s_u(1L, l_3416)) > (safe_mod_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((((((((*l_3229) = (void*)0) == l_3558) <= (((1L > (*g_2444)) > ((*g_2444) != (*g_1480))) > (*g_1285))) | (-1L)) || 4294967292UL) && 0xD5L), l_3559)), l_3407[2]))))) | l_3560))
            { /* block id: 1625 */
                int32_t l_3564 = 6L;
                int32_t l_3567 = 0x5E23C145L;
                int32_t l_3569 = 0x4390092DL;
                int32_t l_3570 = 0x6885AF3FL;
                int32_t l_3573 = 0L;
                int32_t l_3574[5][10] = {{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L}};
                int32_t l_3575[4] = {0x3D8A5D63L,0x3D8A5D63L,0x3D8A5D63L,0x3D8A5D63L};
                int32_t l_3588 = 1L;
                uint8_t l_3591 = 0x0FL;
                int i, j;
                for (g_717 = 0; (g_717 <= (-18)); --g_717)
                { /* block id: 1628 */
                    int64_t l_3563 = 0x4228E3A9390675F2LL;
                    int32_t l_3565 = 0L;
                    int32_t l_3576 = 0x8BB32793L;
                    int32_t l_3578 = 0x398FB94BL;
                    int32_t l_3579 = 1L;
                    int32_t l_3580 = 1L;
                    int32_t l_3581 = 0L;
                    int32_t l_3582 = 0L;
                    int32_t l_3584 = 0xC00FD3CDL;
                    int32_t l_3586 = 5L;
                    int32_t l_3587 = 0xD15AD7E0L;
                    int32_t l_3589 = 0x791991FAL;
                    int32_t l_3590 = (-6L);
                    ++l_3591;
                    for (g_289 = 0; (g_289 <= 0); g_289 += 1)
                    { /* block id: 1632 */
                        uint8_t l_3594 = 0x48L;
                        int32_t l_3597 = (-1L);
                        uint16_t l_3602 = 0xB06BL;
                        int i;
                        l_3594--;
                        --l_3598;
                        l_3602++;
                        (*g_2852) ^= g_679[g_289];
                    }
                }
            }
            else
            { /* block id: 1639 */
                int8_t l_3611 = 0x64L;
                int64_t *l_3616[8];
                const uint32_t l_3617 = 0x1BFEF261L;
                int32_t l_3618 = (-4L);
                int32_t l_3643[10] = {0x7F9370B3L,0x7F9370B3L,0x1AC29DE6L,0x7F9370B3L,0x7F9370B3L,0x1AC29DE6L,0x7F9370B3L,0x7F9370B3L,0x1AC29DE6L,0x7F9370B3L};
                int32_t l_3680 = 0x8025E0AFL;
                int32_t ***** const l_3736 = (void*)0;
                const union U0 * const l_3770 = &g_1118[1];
                int8_t l_3797 = (-1L);
                int i;
                for (i = 0; i < 8; i++)
                    l_3616[i] = &g_113[2];
                l_3255 = ((l_3618 = (((**g_3364) >= ((safe_lshift_func_uint8_t_u_u(((2UL && (safe_mod_func_int64_t_s_s(((0x4638BF97A9264A0DLL & (safe_sub_func_int16_t_s_s(l_3559, l_3611))) ^ (((**g_1085) = ((safe_div_func_uint32_t_u_u(((safe_mod_func_uint32_t_u_u((((0x01CE8345L == l_3611) && (l_3257 , ((void*)0 != l_3616[3]))) > (**g_3275)), l_3611)) | (*g_337)), l_3611)) <= 0L)) , l_3611)), l_3617))) ^ l_3617), 7)) ^ 0x1539C7826E8894D4LL)) || l_3611)) , 0x8679488EL);
                (*g_3230) = func_67(func_58(l_3611, func_67((*g_2868)), ((safe_rshift_func_uint8_t_u_u((l_3621 = l_3618), l_3618)) > l_3577)));
                if ((l_3618 = (l_3585[1] = (*g_337))))
                { /* block id: 1647 */
                    int32_t l_3624 = 0L;
                    uint32_t l_3639 = 8UL;
                    int16_t l_3640[9][7] = {{0x6C0EL,0xE488L,0xE488L,0x6C0EL,0x0081L,9L,0x13FCL},{0x4203L,0xC666L,0xE488L,(-1L),0x13FCL,0x4203L,0x4203L},{0xC666L,0x13FCL,0x0408L,0x13FCL,0xC666L,(-4L),0x13FCL},{0x6C0EL,0x0081L,9L,0x13FCL,0xE488L,9L,0xBA0EL},{0xE488L,0xBA0EL,(-1L),(-1L),0xBA0EL,0xE488L,0x0081L},{0x6C0EL,0x13FCL,9L,0x6C0EL,0xBA0EL,1L,0x13FCL},{0xC666L,0x4203L,0xE488L,0xE1C8L,0xE488L,0x4203L,0xC666L},{0x4203L,0x13FCL,(-1L),0xE488L,0xC666L,0x4203L,0xE488L},{0x6C0EL,0xBA0EL,1L,0x13FCL,0x13FCL,1L,0xBA0EL}};
                    int16_t *l_3641 = &g_100[4];
                    int64_t *** const l_3659 = (void*)0;
                    int32_t l_3661 = 0xFB8BB8B7L;
                    int32_t l_3662 = 0x49128EEEL;
                    int32_t l_3679 = 0xD6A3D19BL;
                    int32_t l_3686 = (-8L);
                    int32_t l_3687 = (-4L);
                    int32_t l_3688[3];
                    int8_t l_3699[6] = {0x5FL,0x5FL,0x5FL,0x5FL,0x5FL,0x5FL};
                    uint8_t *l_3745 = (void*)0;
                    int32_t **l_3746 = (void*)0;
                    int32_t **l_3747[9] = {&l_3648,&l_3648,&l_3648,&l_3648,&l_3648,&l_3648,&l_3648,&l_3648,&l_3648};
                    int32_t *** const l_3767 = &g_143;
                    int16_t **l_3801 = &g_35;
                    union U0 *l_3803 = (void*)0;
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_3688[i] = (-1L);
                    if ((safe_div_func_int16_t_s_s((l_3624 |= ((**g_1085) | (**g_1085))), (((l_3643[7] = (safe_sub_func_int16_t_s_s(((*l_3641) = (l_3618 = ((safe_mul_func_uint16_t_u_u(0x44E4L, (((safe_rshift_func_uint8_t_u_u((((9L == (((*g_1053) = (((*l_3261)++) || ((1UL == (safe_rshift_func_uint16_t_u_s(l_3635[0], 5))) | (((safe_mul_func_uint16_t_u_u((*g_1053), g_3638)) == 0xC1FF3355L) , l_3639)))) > l_3618)) != 9L) != l_3611), l_3640[3][2])) == l_3639) >= (-7L)))) && (*g_1480)))), g_3642[5][2]))) >= l_3640[3][2]) && l_3644))))
                    { /* block id: 1654 */
                        uint16_t l_3645[3];
                        int32_t l_3660 = 1L;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_3645[i] = 0UL;
                        (*g_3230) = func_67((*l_3474));
                        l_3648 = func_67((l_3645[1] , ((+l_3645[1]) , (l_3647 , func_58(l_3618, ((*g_3230) = &l_3577), (*g_1053))))));
                        l_3662 = ((*g_1285) <= (l_3643[1] == ((l_3661 |= ((l_3640[2][4] | (safe_sub_func_int16_t_s_s(((+(*g_1285)) | (!(safe_mod_func_uint16_t_u_u(l_3640[3][2], l_3645[0])))), (l_3618 |= ((safe_lshift_func_uint16_t_u_u(0x4AF6L, 10)) & 0xD9L))))) >= (((((((*l_3261) = ((l_3640[3][2] == 0x862F96089D5E9961LL) , l_3645[2])) | l_3645[1]) , l_3659) == (void*)0) , (*g_1285)) ^ l_3660))) != (*g_652))));
                    }
                    else
                    { /* block id: 1662 */
                        int8_t l_3681 = 1L;
                        int32_t l_3682 = 0xA5736CC4L;
                        int32_t l_3683 = (-1L);
                        int32_t l_3684 = 0x67638482L;
                        int32_t l_3685 = 1L;
                        int32_t l_3689 = 0x855235F9L;
                        int8_t l_3714 = 2L;
                        int16_t **l_3715[8][4] = {{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0},{&l_3641,(void*)0,&l_3641,(void*)0}};
                        int i, j;
                        l_3681 &= (((safe_sub_func_uint32_t_u_u(l_3618, ((*l_3261) = 0x9F3C13B9L))) | (l_3640[3][2] && l_3643[1])) != ((safe_div_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(8L, (((l_3618 && (safe_lshift_func_uint8_t_u_s(((safe_mod_func_uint8_t_u_u(l_3679, l_3661)) >= (l_3680 = l_3624)), 5))) & (**g_1085)) <= (*g_1285)))), 6)) > l_3662), 0)) == 0xE6L), (*g_652))) <= l_3662));
                        --g_3690[3];
                        l_3687 &= (safe_mul_func_uint16_t_u_u(l_3686, (((safe_sub_func_int8_t_s_s((safe_rshift_func_int16_t_s_s((((l_3699[3] != (safe_div_func_int32_t_s_s(((((*g_1053) < ((safe_div_func_int16_t_s_s(l_3704, (l_3688[1] & 0xCAD1L))) && (g_289 |= (safe_sub_func_uint16_t_u_u((3L < (l_3661 = (*g_3365))), ((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(0x8966L, l_3685)) , (*g_1053)), l_3713)), l_3681)) < l_3688[0])))))) && 0x417F98928B2F88B9LL) & 1L), (**g_3275)))) & (*g_652)) || l_3689), l_3617)), l_3714)) <= (**g_651)) || (-6L))));
                        l_3538 = &l_3686;
                    }
                    if ((safe_rshift_func_uint8_t_u_s((+(safe_lshift_func_int16_t_s_s(g_3721, 5))), 2)))
                    { /* block id: 1672 */
                        int64_t l_3722[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                        int32_t l_3723 = 0L;
                        int32_t l_3724 = 0x21C0404DL;
                        int32_t l_3726 = 0x41BB13BFL;
                        int32_t l_3727 = (-1L);
                        int32_t l_3728 = 0x65640FE4L;
                        uint8_t l_3729 = 0x12L;
                        int i;
                        l_3729++;
                    }
                    else
                    { /* block id: 1674 */
                        uint8_t l_3732 = 0xDEL;
                        int32_t l_3735 = 0x233AF821L;
                        (*g_2852) = (**g_2851);
                        --l_3732;
                        l_3735 &= (**g_2851);
                        (*g_3275) = (l_3640[8][1] , ((l_3736 == (void*)0) , &l_3688[0]));
                    }
                    if ((((safe_add_func_int16_t_s_s(((void*)0 == l_3739), (safe_sub_func_int16_t_s_s(l_3742, ((**g_1052) = (safe_mod_func_uint32_t_u_u(((void*)0 == l_3745), (*g_652)))))))) < ((void*)0 != (*g_3364))) && ((l_3748[3] = &l_3568) != (void*)0)))
                    { /* block id: 1682 */
                        uint8_t l_3757[3][2] = {{0xDFL,0xDFL},{0xDFL,0xDFL},{0xDFL,0xDFL}};
                        uint8_t ***l_3760 = &g_659;
                        int32_t l_3765 = 0L;
                        uint16_t l_3766 = 65535UL;
                        int32_t ***l_3768 = &g_143;
                        const union U0 **l_3771 = &g_1120;
                        uint32_t **l_3794 = (void*)0;
                        uint32_t **l_3795[3][7] = {{&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261},{&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261},{&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261,&l_3261}};
                        int16_t *l_3798 = &g_3350;
                        int i, j;
                        (*l_3771) = (((safe_sub_func_int64_t_s_s(((safe_div_func_int64_t_s_s(((safe_mul_func_int8_t_s_s((*g_1285), (safe_lshift_func_uint16_t_u_s((0xCB65L == ((l_3757[0][1] & (safe_lshift_func_uint16_t_u_s((((((**g_1052) = 65535UL) == ((void*)0 == l_3760)) ^ (*g_2852)) == 1L), 13))) && (safe_div_func_int8_t_s_s((((safe_rshift_func_int16_t_s_s((l_3765 = l_3566), l_3766)) , l_3767) != l_3768), 0x73L)))), l_3757[0][1])))) && l_3769), (*g_2444))) , (*g_3365)), (*g_2444))) ^ (*g_337)) , l_3770);
                        (*g_1025) = &l_3257;
                        (**g_2851) = ((safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_unary_minus_func_uint32_t_u((0x66BC006BL <= 0x7EC681F1L))), (safe_rshift_func_int16_t_s_s(((*l_3641) = g_3781), 12)))), 8)), (*g_1285))) > ((l_3800 = (((*l_3798) = (safe_sub_func_uint32_t_u_u((((~0xC357L) <= (safe_div_func_uint16_t_u_u((((safe_rshift_func_int8_t_s_u((*g_1285), (safe_mul_func_int8_t_s_s((l_3797 = ((!(safe_add_func_int64_t_s_s(((**g_3364) = ((g_3796 = ((*g_651) = (*g_651))) != (void*)0)), 18446744073709551608UL))) != l_3611)), (*g_1285))))) , (*l_3770)) , 0x0333L), l_3766))) >= 0x6ACCL), g_682))) || l_3799)) , 0x7DDCD7ABL));
                    }
                    else
                    { /* block id: 1695 */
                        (*l_3498) = ((**g_3364) , func_67(l_3801));
                        l_3802 = (**g_3275);
                        l_3803 = (void*)0;
                        return p_34;
                    }
                }
                else
                { /* block id: 1701 */
                    int32_t *l_3806 = (void*)0;
                    for (g_135 = 0; (g_135 == 20); g_135++)
                    { /* block id: 1704 */
                        (*g_3230) = l_3806;
                        (*g_2852) = 1L;
                    }
                }
            }
            return p_33;
        }
        if ((safe_mod_func_uint16_t_u_u(((((l_3809 == (g_3815[0][0] = ((*l_3812) = l_3810))) , 8UL) || ((g_3820 = ((*l_3819) = &g_1589)) == &l_3291[3][5])) & (safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s(l_3829[2][3], ((l_3831 = (l_3830 == (void*)0)) , (1L <= (**g_651))))), (*g_1285))), (**l_3498))) || 0x3709L), l_3832))), (**l_3498))))
        { /* block id: 1717 */
            uint16_t l_3833[6] = {0x8E74L,0x8E74L,0x8E74L,0x8E74L,0x8E74L,0x8E74L};
            int32_t l_3862 = 0x70A98CCDL;
            int32_t l_3864 = 0x53CC2624L;
            uint32_t **l_3883 = &g_3796;
            int32_t l_3896 = 0L;
            int32_t l_3898 = (-1L);
            int32_t l_3902 = 0x9AE7ADAFL;
            int32_t l_3903 = 0xBE05CCE8L;
            int32_t l_3907 = 0x3DA43A98L;
            int32_t l_3910 = 0x9219871EL;
            int i;
            if (l_3833[0])
            { /* block id: 1718 */
                int8_t l_3850[2][3];
                int32_t l_3860 = 0x605EDD97L;
                int32_t l_3866 = 0L;
                int32_t l_3867 = (-9L);
                union U0 l_3872[8][3] = {{{0UL},{0x5349L},{65534UL}},{{0x79DAL},{0x79DAL},{65535UL}},{{0UL},{65535UL},{0x5349L}},{{0x5349L},{65535UL},{0UL}},{{65535UL},{0x79DAL},{0x79DAL}},{{65534UL},{0x5349L},{0UL}},{{0x308DL},{0xBFD7L},{0x5349L}},{{0x308DL},{0x0C3DL},{65535UL}}};
                int32_t *l_3894 = &g_394;
                int32_t l_3900 = 0x260EEC6DL;
                int32_t l_3901 = 0x731CCFB4L;
                int32_t l_3904 = 1L;
                int32_t l_3905 = 8L;
                int32_t l_3906[5];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_3850[i][j] = 0xEEL;
                }
                for (i = 0; i < 5; i++)
                    l_3906[i] = 0x7400F5E6L;
                for (g_346 = 1; (g_346 <= 4); g_346 += 1)
                { /* block id: 1721 */
                    int32_t l_3836 = (-1L);
                    int32_t l_3856 = 0x20BD654DL;
                    union U0 l_3891 = {0x290CL};
                    int32_t l_3908 = 1L;
                    int32_t l_3909[3][8][10] = {{{9L,0x55E55F79L,0x912200F1L,2L,0L,0x6B69E54CL,0x6B69E54CL,0L,2L,0x912200F1L},{2L,2L,(-1L),0x912200F1L,0xBBB11BA6L,0L,0L,0xEB4AC48FL,(-4L),0x4BE770D4L},{0xEB4AC48FL,(-1L),0L,0x7A5FE17BL,(-9L),0x7A5FE17BL,0L,(-1L),0xEB4AC48FL,2L},{0x55E55F79L,2L,(-4L),0xBBB11BA6L,0x4BE770D4L,(-1L),0x6B69E54CL,(-9L),(-9L),0x6B69E54CL},{(-1L),0x55E55F79L,0xBBB11BA6L,0xBBB11BA6L,0x55E55F79L,(-1L),9L,(-1L),0xEB4AC48FL,0L},{0L,(-9L),2L,0x7A5FE17BL,(-4L),(-1L),(-1L),(-1L),(-4L),0x7A5FE17BL},{0L,(-1L),0L,0x912200F1L,0x6B69E54CL,(-1L),0x7A5FE17BL,0x4BE770D4L,2L,(-1L)},{(-1L),0x7A5FE17BL,0x4BE770D4L,2L,(-1L),(-1L),2L,0x4BE770D4L,0x7A5FE17BL,(-1L)}},{{0x55E55F79L,0x9D97CE1EL,0L,(-9L),2L,0x7A5FE17BL,(-4L),(-1L),(-1L),(-1L)},{0xEB4AC48FL,0L,2L,0x9D97CE1EL,2L,0L,0xEB4AC48FL,(-1L),9L,(-1L)},{2L,(-4L),0xBBB11BA6L,0x4BE770D4L,(-1L),0x6B69E54CL,(-9L),(-9L),0x6B69E54CL,(-1L)},{9L,(-4L),(-4L),9L,0x6B69E54CL,2L,0xEB4AC48FL,(-1L),0L,0x7A5FE17BL},{0xBBB11BA6L,0L,0L,0xEB4AC48FL,(-4L),0x4BE770D4L,(-4L),0x9D97CE1EL,0x4BE770D4L,0x6B69E54CL},{0x912200F1L,9L,0x7A5FE17BL,(-1L),(-4L),0x55E55F79L,0xEB4AC48FL,0x4BE770D4L,(-1L),(-1L)},{9L,(-1L),0x55E55F79L,0xBBB11BA6L,0xBBB11BA6L,0x55E55F79L,(-1L),9L,(-1L),0xEB4AC48FL},{0x912200F1L,0x7A5FE17BL,0x9D97CE1EL,9L,2L,0xBBB11BA6L,(-9L),0xEB4AC48FL,(-9L),0xBBB11BA6L}},{{0L,2L,0x9D97CE1EL,2L,0L,0xEB4AC48FL,(-1L),9L,(-1L),0x55E55F79L},{(-1L),(-4L),0x55E55F79L,0xEB4AC48FL,0x4BE770D4L,(-1L),(-1L),0x4BE770D4L,0xEB4AC48FL,0x55E55F79L},{0xEB4AC48FL,0xEB4AC48FL,0x7A5FE17BL,0x55E55F79L,0L,0x6B69E54CL,0x4BE770D4L,0x9D97CE1EL,0L,0xBBB11BA6L},{0x9D97CE1EL,(-9L),0x4BE770D4L,(-1L),2L,(-1L),0x4BE770D4L,(-9L),0x9D97CE1EL,0xEB4AC48FL},{(-4L),0xEB4AC48FL,0L,0L,0xBBB11BA6L,0x912200F1L,(-1L),2L,2L,(-1L)},{(-9L),(-4L),0L,0L,(-4L),(-9L),(-1L),0x912200F1L,0x9D97CE1EL,0x6B69E54CL},{0x6B69E54CL,2L,0xEB4AC48FL,(-1L),0L,0x7A5FE17BL,(-9L),0x7A5FE17BL,0L,(-1L)},{0x6B69E54CL,0x7A5FE17BL,0x6B69E54CL,0x55E55F79L,(-1L),(-9L),(-1L),0xBBB11BA6L,0xEB4AC48FL,0x912200F1L}}};
                    uint32_t l_3911 = 0x407C4B02L;
                    uint32_t l_3914 = 0x9CE5899FL;
                    int i, j, k;
                    if (g_3690[g_346])
                        break;
                    if (g_3690[g_346])
                        break;
                    if (g_3690[g_346])
                    { /* block id: 1724 */
                        const uint32_t l_3857 = 0x1810BACAL;
                        uint8_t ***l_3858 = &g_659;
                        int32_t l_3859[6][2] = {{0x284575EAL,0x284575EAL},{0x997BCA09L,0x284575EAL},{0x284575EAL,0x997BCA09L},{0x284575EAL,0x284575EAL},{0x997BCA09L,0x284575EAL},{0x284575EAL,0x997BCA09L}};
                        int i, j;
                        l_3836 = (safe_rshift_func_uint8_t_u_s(255UL, 4));
                        (*g_2852) = (safe_mod_func_int8_t_s_s((((g_3690[g_346] & (g_3690[g_346] | (safe_mul_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u(((*l_3261) = (+1L)), (l_3859[1][1] &= ((((*l_3858) = ((((((((safe_sub_func_int16_t_s_s((l_3856 &= ((((safe_rshift_func_uint8_t_u_u(g_3690[g_346], 4)) >= (safe_div_func_int32_t_s_s(((l_3850[0][1] || (safe_mod_func_uint64_t_u_u(l_3850[1][2], (safe_lshift_func_uint16_t_u_s(g_3690[g_346], 4))))) && ((**g_1085) = l_3836)), l_3855))) | l_3833[0]) , 1L)), (-2L))) != l_3833[1]) ^ g_3690[g_346]) == 0UL) , l_3833[3]) , l_3857) < l_3833[0]) , &l_3258[0][0][1])) == (void*)0) , l_3856)))) == 65533UL), 0xFD05L)))) , 3UL) < 0x5293L), (*g_1285)));
                        (*g_2851) = (*g_2851);
                    }
                    else
                    { /* block id: 1733 */
                        int32_t l_3861 = 2L;
                        int32_t l_3863 = 0x4396C5D1L;
                        int32_t l_3865 = (-1L);
                        int32_t l_3868 = (-1L);
                        l_3869[0]--;
                        (*g_2852) |= (*g_337);
                        (*g_3230) = (void*)0;
                        (*g_3230) = (l_3872[2][1] , &l_3836);
                    }
                    for (g_71 = 1; (g_71 <= 4); g_71 += 1)
                    { /* block id: 1741 */
                        uint32_t ***l_3884 = &g_651;
                        int32_t l_3886 = 0x1CAB8C78L;
                        int32_t l_3897 = 0x714413B6L;
                        int32_t l_3899[10][4] = {{0x15EAEFA6L,0x15EAEFA6L,(-4L),1L},{1L,1L,(-4L),1L},{0x15EAEFA6L,0xD897AC84L,(-1L),(-4L)},{1L,0xD897AC84L,0xD897AC84L,1L},{0xD897AC84L,1L,0x15EAEFA6L,1L},{0xD897AC84L,0x15EAEFA6L,0xD897AC84L,(-1L)},{1L,1L,(-1L),(-1L)},{0x15EAEFA6L,0x15EAEFA6L,(-4L),1L},{1L,1L,(-4L),1L},{0x15EAEFA6L,0xD897AC84L,(-1L),(-4L)}};
                        int i, j;
                        (*g_2852) |= (safe_mod_func_uint8_t_u_u(((safe_add_func_uint64_t_u_u(((*g_134)++), (((*l_3261) = ((safe_div_func_uint64_t_u_u((l_3883 != ((*l_3884) = &l_3261)), l_3833[0])) ^ (safe_unary_minus_func_uint8_t_u(l_3886)))) >= (safe_mod_func_int32_t_s_s((((*l_3406) = (*l_3406)) != l_3889), l_3872[2][1].f0))))) <= (!((l_3891 , (safe_sub_func_uint32_t_u_u((l_3833[0] & 0x698AL), l_3886))) && 0x85C6L))), (*g_1285)));
                        l_3894 = &l_3886;
                        ++l_3911;
                        --l_3914;
                    }
                }
            }
            else
            { /* block id: 1752 */
                uint32_t l_3917[8] = {1UL,0x97EF43ADL,0x97EF43ADL,1UL,0x97EF43ADL,0x97EF43ADL,1UL,0x97EF43ADL};
                int32_t l_3918 = 0x32AFC9ABL;
                int32_t l_3919 = 1L;
                int32_t l_3920[1][9] = {{0xDAB070EFL,0xDAB070EFL,0x58022830L,0xDAB070EFL,0xDAB070EFL,0x58022830L,0xDAB070EFL,0xDAB070EFL,0x58022830L}};
                int i, j;
                l_3917[3] |= l_3902;
                --l_3921;
            }
        }
        else
        { /* block id: 1756 */
            return p_34;
        }
        g_3936 &= (safe_mul_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((((*g_1053) <= 1UL) >= 0x3F15L), (safe_lshift_func_int8_t_s_u((safe_mul_func_int64_t_s_s(l_3932, (l_3933 != (((**g_3275) > 0x2C5DD24BL) , (void*)0)))), ((safe_lshift_func_uint16_t_u_s((**l_3498), 14)) >= 0x80BCE47CL))))), (**l_3498)));
        return (**l_3474);
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_15.f1 g_52 g_3 g_74 g_35 g_256 g_5 g_8 g_113 g_289 g_188 g_251 g_134 g_135 g_100 g_141 g_245 g_97 g_346 g_71 g_143 g_144 g_209 g_250 g_337 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_652 g_1285 g_1053 g_1480 g_1481 g_1118.f1 g_1600 g_2194 g_2214 g_675 g_65 g_681 g_1976 g_1085 g_660 g_2279 g_1031 g_1052 g_2348 g_2436 g_717 g_1474 g_1034 g_2647 g_2444 g_2661 g_680 g_2736 g_950 g_3224
 * writes: g_52 g_15.f1 g_65 g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675 g_715 g_2192 g_1976 g_681 g_1120 g_134 g_2444 g_2436 g_717 g_1474 g_2194 g_2647 g_1600 g_950 g_2661 g_1052
 */
static int16_t * func_36(int32_t  p_37, int16_t * p_38, int8_t  p_39, int8_t  p_40, union U0  p_41)
{ /* block id: 10 */
    int32_t *l_51 = &g_52;
    int32_t l_53 = (-4L);
    uint64_t *l_2753[2];
    int32_t l_2755 = 0xC070DCE3L;
    int32_t l_2756 = 0x2CA60E73L;
    int32_t l_2757[6];
    uint16_t l_2758 = 0xABDAL;
    int32_t *l_2763 = &g_141;
    int32_t **l_2764[4];
    int32_t *l_2765[9][7][4] = {{{&g_392,&g_71,&g_390,&l_2756},{&g_394,&l_2757[4],(void*)0,(void*)0},{&g_8[1],&g_8[1],(void*)0,&l_2756},{&g_5[0],&g_392,&g_2194,&g_2194},{&l_2757[4],&l_2755,&l_2757[4],&l_2756},{(void*)0,&g_141,&l_2757[2],&g_2194},{(void*)0,&g_141,(void*)0,&g_141}},{{&g_2194,&g_354,&l_2756,&g_71},{&g_392,(void*)0,&l_2757[2],(void*)0},{&l_2755,&g_5[2],(void*)0,&l_2755},{&g_8[0],&g_8[1],&l_2756,&g_71},{(void*)0,&g_8[6],&l_2756,(void*)0},{&g_71,&g_5[0],&g_141,(void*)0},{(void*)0,&l_2757[0],&g_392,&g_8[2]}},{{&l_2757[4],(void*)0,(void*)0,&g_394},{&g_5[2],&g_392,&g_392,&l_2757[2]},{&g_2194,&g_8[1],&g_8[1],&l_2756},{&l_53,(void*)0,(void*)0,&g_5[0]},{&g_8[8],&g_8[1],&g_8[8],&l_2755},{&l_2757[4],&g_141,&g_71,(void*)0},{&g_394,&l_53,&g_141,&g_141}},{{&l_2756,&l_2756,&g_141,&l_2757[0]},{&g_394,&l_2757[2],&g_71,&l_53},{&l_2757[4],(void*)0,&g_8[8],&g_354},{&g_8[8],&g_354,(void*)0,&l_2755},{&l_53,&g_2194,&g_8[1],&g_71},{&g_2194,&g_5[0],&g_392,&g_71},{&g_5[2],&l_2755,(void*)0,(void*)0}},{{&l_2757[4],&g_8[0],&g_392,(void*)0},{(void*)0,&g_5[2],&g_141,&l_2757[3]},{&g_71,&g_141,&l_2756,&g_5[1]},{(void*)0,(void*)0,&l_2756,&l_2756},{&g_8[0],&g_5[0],(void*)0,(void*)0},{&l_2755,&g_394,&l_2757[2],&g_8[0]},{&g_392,&l_53,&l_2756,&g_8[1]}},{{&g_2194,&l_2757[4],(void*)0,&l_2755},{(void*)0,(void*)0,&l_2757[2],&g_5[2]},{(void*)0,&l_2756,&l_2757[4],&l_2757[4]},{&l_2757[4],&l_2755,&g_2194,(void*)0},{&g_5[0],&g_5[2],(void*)0,&l_2755},{(void*)0,&g_5[2],(void*)0,(void*)0},{(void*)0,(void*)0,&l_2755,&l_2756}},{{&g_8[1],(void*)0,(void*)0,&l_2756},{&l_2755,(void*)0,&g_5[1],&l_2755},{(void*)0,(void*)0,&g_392,&g_71},{&l_2757[4],&l_2757[3],&g_8[1],&g_5[2]},{&l_2755,(void*)0,(void*)0,&l_2755},{&l_2755,&g_2194,&g_5[2],&g_392},{(void*)0,&l_2755,&g_71,&g_8[6]}},{{(void*)0,&g_5[0],(void*)0,&l_2757[4]},{&l_2757[4],&g_5[0],&g_71,&l_2757[0]},{&g_71,(void*)0,&g_8[1],&g_392},{&g_392,&l_2755,&g_2194,(void*)0},{(void*)0,&g_141,&g_71,&l_2757[4]},{&g_8[2],&g_392,&g_141,&g_2194},{&g_2194,&g_394,&g_394,&l_2757[3]}},{{&g_141,&g_394,&l_2757[0],&g_394},{&g_141,&g_5[0],(void*)0,&l_2756},{&l_2756,&l_2757[2],&g_141,(void*)0},{&l_2755,(void*)0,(void*)0,&g_390},{(void*)0,(void*)0,&l_2756,&l_2756},{&l_2757[2],&g_394,&l_2755,&l_2756},{&g_5[0],&l_2756,&g_5[0],&g_8[8]}}};
    const int32_t l_2766 = 0x824CAEF5L;
    int32_t *l_2767 = &g_8[1];
    int32_t *l_2768 = &g_390;
    int32_t l_2818 = 0x8637A51EL;
    const int16_t *l_2922 = &g_950;
    uint64_t ***l_2972 = &g_1085;
    uint64_t ****l_2971 = &l_2972;
    int32_t l_3033 = 0xD03E393CL;
    int64_t *l_3036[5];
    int64_t **l_3035 = &l_3036[2];
    int64_t *** const l_3034 = &l_3035;
    int16_t l_3072 = (-3L);
    int16_t l_3074 = 0xF1EDL;
    uint8_t l_3089 = 0x63L;
    uint32_t l_3120 = 0UL;
    int32_t l_3132 = 0x067CE18CL;
    const union U0 **l_3151 = (void*)0;
    const union U0 ***l_3150[9] = {&l_3151,&l_3151,&l_3151,&l_3151,&l_3151,&l_3151,&l_3151,&l_3151,&l_3151};
    const union U0 ****l_3149 = &l_3150[5];
    int64_t l_3153 = 0L;
    union U0 *l_3218 = &g_15;
    uint16_t l_3221 = 0xB456L;
    uint16_t **l_3226 = &g_1053;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2753[i] = &g_2754;
    for (i = 0; i < 6; i++)
        l_2757[i] = 3L;
    for (i = 0; i < 4; i++)
        l_2764[i] = &l_2763;
    for (i = 0; i < 5; i++)
        l_3036[i] = &g_113[0];
    l_2765[6][3][1] = ((*g_1031) = ((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(func_47(p_37, ((*l_51) = p_37), (l_53 = l_53)), 5)), (safe_lshift_func_int16_t_s_s(((-4L) < ((safe_sub_func_uint64_t_u_u(((p_41.f0 || g_251[4]) <= ((+(safe_mod_func_int64_t_s_s((*g_1480), (++l_2758)))) != ((safe_sub_func_uint16_t_u_u(p_37, l_2757[4])) <= l_2755))), l_2757[4])) | 4294967291UL)), 2)))) , l_2763));
    (*g_1031) = func_67(func_58((*g_144), (l_2766 , (l_2768 = l_2767)), p_40));
    for (g_2661 = 0; (g_2661 <= 7); g_2661 += 1)
    { /* block id: 1217 */
        uint8_t *** const l_2786 = &g_659;
        int32_t *l_2788 = &g_5[0];
        union U0 **l_2836 = &g_373[8];
        int64_t **l_2861 = (void*)0;
        int64_t ***l_2860[3][5][9] = {{{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,(void*)0,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,(void*)0,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,(void*)0,&l_2861}},{{(void*)0,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{(void*)0,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,(void*)0}},{{&l_2861,&l_2861,(void*)0,&l_2861,(void*)0,&l_2861,&l_2861,(void*)0,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,(void*)0,&l_2861},{&l_2861,(void*)0,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,(void*)0,&l_2861,&l_2861,&l_2861,&l_2861},{&l_2861,&l_2861,&l_2861,&l_2861,(void*)0,(void*)0,&l_2861,&l_2861,(void*)0}}};
        int16_t *l_2872 = &g_100[4];
        int32_t l_2904[7] = {0x3954BF32L,0x3954BF32L,(-5L),0x3954BF32L,0x3954BF32L,(-5L),0x3954BF32L};
        uint64_t ****l_2969 = (void*)0;
        int32_t ***l_3042 = &g_143;
        int32_t ***l_3044[9] = {&g_143,&g_143,&g_143,&g_143,&g_143,&g_143,&g_143,&g_143,&g_143};
        uint8_t l_3052 = 0xD8L;
        int64_t l_3142 = 5L;
        union U0 ** const *l_3148 = &g_1023[0][1];
        union U0 ** const ** const l_3147[2] = {&l_3148,&l_3148};
        uint16_t ***l_3176 = &g_1052;
        int16_t ****l_3209 = &g_2868;
        int i, j, k;
        for (g_2194 = 7; (g_2194 >= 1); g_2194 -= 1)
        { /* block id: 1220 */
            uint64_t ***l_2778 = &g_1085;
            uint64_t ****l_2777 = &l_2778;
            uint8_t *l_2779 = &g_2436[7];
            uint8_t *l_2782 = &g_97;
            int32_t l_2785 = (-7L);
            int32_t *l_2809 = &l_2757[4];
            int16_t *l_2813 = &g_100[2];
            int16_t **l_2812 = &l_2813;
            int32_t *l_2888 = &g_394;
            int32_t l_2901[5][10] = {{9L,(-5L),9L,9L,(-5L),9L,(-1L),0x0193B9D7L,0xEACB226CL,0x0193B9D7L},{0xF8C5E71EL,9L,0xEACB226CL,1L,0xEACB226CL,9L,0xF8C5E71EL,(-1L),2L,2L},{0xF8C5E71EL,2L,9L,0xCD53A441L,0xCD53A441L,9L,2L,0xF8C5E71EL,(-5L),(-1L)},{9L,2L,0xF8C5E71EL,(-5L),(-1L),(-5L),0xF8C5E71EL,2L,9L,0xCD53A441L},{0xEACB226CL,9L,0xF8C5E71EL,(-1L),2L,2L,(-1L),0xF8C5E71EL,9L,0xEACB226CL}};
            uint16_t l_2921 = 1UL;
            uint32_t l_2940 = 8UL;
            uint16_t **l_3011 = &g_1053;
            int32_t ***l_3043[5][9];
            int32_t ****l_3045 = &l_3043[1][6];
            int8_t *l_3053 = &g_188;
            uint64_t l_3054 = 1UL;
            uint32_t l_3104 = 18446744073709551615UL;
            uint16_t l_3133 = 0xD889L;
            uint32_t *l_3152 = &g_1474;
            int8_t l_3186 = 0xADL;
            int i, j;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 9; j++)
                    l_3043[i][j] = &g_143;
            }
            if (g_2436[g_2661])
                break;
        }
        for (l_3132 = 0; (l_3132 <= 2); l_3132 += 1)
        { /* block id: 1429 */
            int16_t **l_3187 = &l_2872;
            int32_t l_3197 = (-1L);
            int16_t ****l_3206 = &g_2868;
            int16_t ****l_3208 = &g_2868;
            int16_t *****l_3207[7];
            int32_t *l_3210 = &g_392;
            union U0 *l_3217 = &g_374;
            int i;
            for (i = 0; i < 7; i++)
                l_3207[i] = &l_3208;
            for (g_1976 = 0; (g_1976 <= 5); g_1976 += 1)
            { /* block id: 1432 */
                int32_t *l_3188 = &l_2904[6];
                l_3188 = l_3188;
                (*g_1034) = l_3188;
            }
            l_3210 = func_67((((safe_mod_func_uint64_t_u_u(((*g_134)--), (safe_div_func_int64_t_s_s(p_40, l_3197)))) < ((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((-4L), 13)), p_39)), (((**g_1052) |= (p_41.f0 >= (((((*l_2763) != (l_3197 < ((l_3206 == (l_3209 = &g_2868)) , l_3197))) <= (*l_2788)) | 1UL) , (-1L)))) > 1L))), p_40)) <= p_40)) , &p_38));
            for (g_390 = 2; (g_390 >= 0); g_390 -= 1)
            { /* block id: 1444 */
                if (p_40)
                    break;
                return p_38;
            }
            (*l_3176) = (((safe_div_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s((((**g_651) &= p_37) < (l_2904[1] &= ((5UL < (safe_sub_func_uint64_t_u_u((0xACB4C3FDL != (((l_3217 != (l_3218 = &p_41)) && (safe_rshift_func_uint8_t_u_u((*l_2788), 7))) , l_3221)), 0x833FD202404D6A29LL))) != (((safe_add_func_int64_t_s_s(((void*)0 != g_3224), 18446744073709551609UL)) || p_41.f1) < 0x63633CCDL)))), (*l_2788))), p_41.f0)) | (*l_2788)) , l_3226);
        }
    }
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_15.f1 g_52 g_3 g_74 g_35 g_256 g_5 g_8 g_113 g_289 g_188 g_251 g_134 g_135 g_100 g_141 g_245 g_97 g_346 g_71 g_143 g_144 g_209 g_250 g_337 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_652 g_1285 g_1053 g_1480 g_1481 g_1118.f1 g_1600 g_2194 g_2214 g_675 g_65 g_681 g_1976 g_1085 g_660 g_2279 g_1031 g_1052 g_2348 g_2436 g_1034 g_2647 g_2444 g_2661 g_680 g_2736 g_950 g_717 g_1474
 * writes: g_15.f1 g_65 g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675 g_715 g_2192 g_1976 g_681 g_1120 g_52 g_134 g_2444 g_2436 g_717 g_1474 g_2194 g_2647 g_1600 g_950
 */
static uint8_t  func_47(uint64_t  p_48, int32_t  p_49, int32_t  p_50)
{ /* block id: 13 */
    uint32_t *l_2188 = &g_1976;
    uint16_t *l_2191 = &g_2192;
    union U0 l_2193 = {0x3E9DL};
    int64_t * const l_2215 = &g_113[2];
    int32_t *l_2218 = &g_141;
    int32_t ** const *l_2231 = &g_143;
    union U0 *l_2237 = (void*)0;
    int32_t l_2281 = 0x2919CDB1L;
    int32_t l_2288 = 0xAD0A67AEL;
    int16_t l_2289 = 0xE629L;
    uint32_t l_2371[2];
    int32_t l_2393 = 0x50A102B4L;
    int32_t l_2395 = 0x3A478E54L;
    int32_t l_2397 = 0x6933D78BL;
    int32_t l_2401 = (-4L);
    int32_t l_2403 = 0x8E270A05L;
    int32_t l_2404 = 0xFD3603FAL;
    int32_t l_2405 = 0x1B2B8B1DL;
    int32_t l_2406[7][10][2] = {{{0L,0xB9DD186FL},{(-1L),0xFCDEF65FL},{0x50F7EA90L,0x5C02B894L},{0xC0569548L,0x37354630L},{1L,0x80C1E263L},{0x8F6B651CL,0x1FE831DDL},{0xF531EAEBL,(-1L)},{5L,0L},{0x37354630L,0L},{0x4D31E591L,5L}},{{0x50588320L,0x50588320L},{0x48295CE5L,0L},{0x1FE831DDL,0x01886804L},{0xB6C46BC4L,0L},{0x80C1E263L,0xB6C46BC4L},{0x7EC4DB31L,0L},{0x7EC4DB31L,0xB6C46BC4L},{0x80C1E263L,0L},{0xB6C46BC4L,0x01886804L},{0x1FE831DDL,0L}},{{0x48295CE5L,0x50588320L},{0x50588320L,5L},{0x4D31E591L,0L},{0x37354630L,0L},{5L,(-1L)},{0xF531EAEBL,0x1FE831DDL},{0x8F6B651CL,0x80C1E263L},{1L,0x37354630L},{0xC0569548L,0x5C02B894L},{0x50F7EA90L,0xFCDEF65FL}},{{(-1L),0xB9DD186FL},{0L,0xB9DD186FL},{(-1L),0xFCDEF65FL},{0x50F7EA90L,0x5C02B894L},{0xC0569548L,0x37354630L},{1L,0x80C1E263L},{0x8F6B651CL,0x1FE831DDL},{0xF531EAEBL,(-1L)},{5L,0L},{0x37354630L,0L}},{{0x4D31E591L,5L},{0x50588320L,0x50588320L},{0x48295CE5L,0L},{0x1FE831DDL,0x01886804L},{0xB6C46BC4L,0L},{0x80C1E263L,0xB6C46BC4L},{0x7EC4DB31L,0L},{0x7EC4DB31L,0xB6C46BC4L},{0x80C1E263L,0L},{0xB6C46BC4L,0x01886804L}},{{0x1FE831DDL,0L},{0x48295CE5L,0x50588320L},{0x50588320L,5L},{0x4D31E591L,0L},{0x37354630L,0L},{5L,(-1L)},{0xF531EAEBL,0x1FE831DDL},{0x8F6B651CL,0x80C1E263L},{1L,(-1L)},{0x7EC4DB31L,9L}},{{0x51F01FE8L,0x01886804L},{0L,0x1FE831DDL},{0x6554C541L,0x1FE831DDL},{0L,0x01886804L},{0x51F01FE8L,9L},{0x7EC4DB31L,(-1L)},{0L,0xC0569548L},{(-6L),0x4D31E591L},{0x50F7EA90L,0L},{0L,0xB6C46BC4L}}};
    uint8_t **l_2435 = &g_660[5][2][0];
    int32_t *****l_2439[10] = {&g_1589,&g_1589,&g_1589,&g_1589,&g_1589,&g_1589,&g_1589,&g_1589,&g_1589,&g_1589};
    int8_t l_2516 = (-6L);
    int8_t l_2523 = 0x8EL;
    uint8_t l_2537 = 0x69L;
    const int16_t l_2549[5][6][8] = {{{0x3F77L,0x6A82L,0L,0x71B8L,0x3F77L,0x31C3L,0x6A82L,0x8BDEL},{0x3F77L,0x31C3L,0x6A82L,0x8BDEL,0x71B8L,0x31C3L,0x31C3L,0x71B8L},{0x8AB5L,0x6A82L,0x6A82L,0x8AB5L,0x416AL,0xF055L,0x6A82L,0x71B8L},{0x71B8L,7L,0L,0x8BDEL,0x416AL,0x6A82L,7L,0x8BDEL},{0x8AB5L,7L,0xF055L,0x71B8L,0x71B8L,0xF055L,7L,0x8AB5L},{0x3F77L,0x6A82L,0L,0x71B8L,0x3F77L,0x31C3L,0x6A82L,0x8BDEL}},{{0x3F77L,0x31C3L,0x6A82L,0x8BDEL,0x71B8L,0x31C3L,0x31C3L,0x71B8L},{0x8AB5L,0x6A82L,0x6A82L,0x8AB5L,0x416AL,0xF055L,0x6A82L,0x71B8L},{0x71B8L,7L,0L,0x8BDEL,0x416AL,0x6A82L,7L,0x8BDEL},{0x8AB5L,7L,0xF055L,0x71B8L,0x71B8L,0xF055L,7L,0x8AB5L},{0x3F77L,0x6A82L,0L,0x71B8L,0x3F77L,0x31C3L,0x6A82L,0x8BDEL},{0x3F77L,0x31C3L,0x6A82L,0x8BDEL,0x71B8L,0x31C3L,0x31C3L,0x71B8L}},{{0x8AB5L,0x6A82L,0x6A82L,0x8AB5L,0x416AL,0xF055L,0x6A82L,0x71B8L},{0x71B8L,7L,0L,0x8BDEL,0x416AL,0x6A82L,7L,0x8BDEL},{0x8AB5L,7L,0xF055L,0x71B8L,0x71B8L,0xF055L,7L,0x8AB5L},{0x3F77L,0x6A82L,0L,0x71B8L,0x3F77L,0x31C3L,0x6A82L,0x8BDEL},{0x3F77L,0x31C3L,0x6A82L,0x8BDEL,0x71B8L,0x31C3L,0x31C3L,0x71B8L},{0x8AB5L,0x6A82L,0x6A82L,0x8AB5L,0x416AL,0xF055L,0x6A82L,0x71B8L}},{{0x71B8L,7L,0L,0x8BDEL,0x416AL,0x6A82L,7L,0x8BDEL},{0x8AB5L,7L,0xF055L,0x71B8L,0x71B8L,0L,0x31C3L,0x8BDEL},{0x71B8L,0xF055L,7L,0x8AB5L,0x71B8L,0x6A82L,0xF055L,0x416AL},{0x71B8L,0x6A82L,0xF055L,0x416AL,0x8AB5L,0x6A82L,0x6A82L,0x8AB5L},{0x8BDEL,0xF055L,0xF055L,0x8BDEL,0x3F77L,0L,0xF055L,0x8AB5L},{0x8AB5L,0x31C3L,7L,0x416AL,0x3F77L,0xF055L,0x31C3L,0x416AL}},{{0x8BDEL,0x31C3L,0L,0x8AB5L,0x8AB5L,0L,0x31C3L,0x8BDEL},{0x71B8L,0xF055L,7L,0x8AB5L,0x71B8L,0x6A82L,0xF055L,0x416AL},{0x71B8L,0x6A82L,0xF055L,0x416AL,0x8AB5L,0x6A82L,0x6A82L,0x8AB5L},{0x8BDEL,0xF055L,0xF055L,0x8BDEL,0x3F77L,0L,0xF055L,0x8AB5L},{0x8AB5L,0x31C3L,7L,0x416AL,0x3F77L,0xF055L,0x31C3L,0x416AL},{0x8BDEL,0x31C3L,0L,0x8AB5L,0x8AB5L,0L,0x31C3L,0x8BDEL}}};
    const uint64_t ** const l_2563 = &g_2444;
    const int64_t l_2564 = 0L;
    uint16_t * const **l_2586 = (void*)0;
    uint16_t * const ***l_2585[1][3];
    int32_t * const * const *l_2716 = (void*)0;
    uint64_t l_2728 = 1UL;
    uint64_t * const **l_2735 = (void*)0;
    uint64_t * const ***l_2734 = &l_2735;
    uint64_t * const ****l_2733 = &l_2734;
    int16_t *l_2738[1][7][5] = {{{&l_2289,&g_950,&l_2289,(void*)0,(void*)0},{&g_950,&l_2289,&g_950,&l_2289,(void*)0},{&l_2289,&g_100[4],(void*)0,&g_100[4],&l_2289},{&g_950,&g_100[4],&l_2289,&l_2289,&l_2289},{&l_2289,&l_2289,(void*)0,&l_2289,&l_2289},{&g_100[4],&g_950,&g_950,&g_100[4],&l_2289},{&g_100[4],&l_2289,&l_2289,&l_2289,&l_2289}}};
    int64_t l_2739 = 0xF8DD201F806F128FLL;
    int8_t *l_2740 = &l_2193.f1;
    uint32_t l_2741 = 1UL;
    uint8_t *l_2742 = &g_256;
    int32_t *l_2743 = &l_2406[5][0][1];
    uint32_t l_2744 = 0x1730B4ADL;
    int8_t *l_2745[7][8] = {{(void*)0,&g_15.f1,(void*)0,(void*)0,&g_15.f1,(void*)0,&l_2516,(void*)0},{&l_2516,&g_188,&l_2516,&l_2516,&g_393[4][0][4],(void*)0,&l_2523,&l_2523},{&g_188,(void*)0,(void*)0,&l_2516,(void*)0,&l_2516,(void*)0,(void*)0},{&l_2523,(void*)0,&g_188,(void*)0,&l_2523,&g_15.f1,&g_188,&g_15.f1},{(void*)0,&g_393[4][1][1],(void*)0,&g_188,&l_2523,&g_188,&g_188,&l_2523},{&g_15.f1,&g_188,&g_188,&g_15.f1,(void*)0,&l_2523,(void*)0,(void*)0},{(void*)0,&l_2523,(void*)0,(void*)0,&l_2516,&l_2516,&l_2523,&g_393[4][1][1]}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2371[i] = 0xD9846C24L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_2585[i][j] = &l_2586;
    }
    if ((func_54(g_2) ^ (((p_50 || g_8[1]) > ((+((g_1118[2].f1 >= ((void*)0 != l_2188)) >= (((((safe_mul_func_uint16_t_u_u(0x2E1AL, ((*l_2191) = p_50))) , l_2193) , l_2193) , g_1600[4]) > l_2193.f0))) != l_2193.f0)) < g_2194)))
    { /* block id: 973 */
        int32_t *l_2195 = &g_8[0];
        int32_t **l_2196[3];
        int32_t *l_2197[9][3][2] = {{{&g_2194,&g_2194},{&g_141,&g_2194},{&g_2194,(void*)0}},{{&g_5[0],&g_8[5]},{&g_141,&g_5[0]},{&g_8[5],(void*)0}},{{&g_8[5],&g_5[0]},{&g_141,&g_8[5]},{&g_5[0],&g_8[1]}},{{&g_141,&g_141},{&g_5[0],&g_141},{&g_141,&g_8[1]}},{{(void*)0,(void*)0},{&g_5[0],(void*)0},{(void*)0,&g_8[1]}},{{(void*)0,(void*)0},{&g_5[0],(void*)0},{(void*)0,&g_8[1]}},{{&g_141,&g_141},{&g_5[0],&g_141},{&g_141,&g_8[1]}},{{(void*)0,(void*)0},{&g_5[0],(void*)0},{(void*)0,&g_8[1]}},{{(void*)0,(void*)0},{&g_5[0],(void*)0},{(void*)0,&g_8[1]}}};
        int64_t *l_2198 = (void*)0;
        int64_t **l_2199 = &l_2198;
        int8_t l_2204 = 0xD1L;
        uint16_t *l_2210 = &g_2192;
        int32_t l_2213 = 6L;
        union U0 *l_2269 = &l_2193;
        const union U0 *l_2270 = &g_2271[1][3][6];
        const union U0 **l_2272 = &g_1120;
        int16_t **l_2277 = &g_35;
        uint32_t *l_2278[7][5][5] = {{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_251[1],&g_495[6]},{&g_495[0],&g_251[1],&g_1600[4],&g_169,&g_495[6]},{&g_169,&g_495[0],&g_251[1],(void*)0,&g_495[6]},{&g_495[0],&g_169,&g_495[0],&g_495[0],&g_495[6]},{&g_495[6],&g_251[1],&g_169,&g_251[1],&g_495[6]}},{{&g_169,(void*)0,&g_495[0],&g_495[0],&g_495[0]},{&g_169,&g_495[0],&g_1600[3],&g_251[1],&g_495[0]},{&g_251[1],(void*)0,&g_1600[4],&g_169,&g_495[0]},{&g_251[1],&g_251[1],&g_251[3],(void*)0,&g_495[0]},{&g_495[0],&g_1600[4],&g_169,&g_1600[4],&g_495[0]}}};
        int32_t l_2301[3][6];
        int64_t *l_2338 = &g_113[0];
        uint64_t *l_2343[3];
        int64_t l_2394 = (-7L);
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2196[i] = &g_715[1];
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 6; j++)
                l_2301[i][j] = 0xB3DE31E8L;
        }
        for (i = 0; i < 3; i++)
            l_2343[i] = &g_65;
        l_2197[2][1][1] = l_2195;
        if ((((*l_2199) = l_2198) != ((safe_rshift_func_int8_t_s_u((p_49 && l_2193.f0), (((safe_mul_func_uint8_t_u_u(l_2204, ((safe_mod_func_uint16_t_u_u(((((((safe_add_func_int16_t_s_s((~(l_2191 == l_2210)), 1UL)) , ((((*l_2188) = (((safe_add_func_uint32_t_u_u(p_50, p_49)) >= 0UL) | (**g_651))) < (*g_652)) == l_2213)) == p_50) , 1L) != 0UL) && p_50), (*l_2195))) == 65535UL))) > 9UL) == g_2214))) , l_2215)))
        { /* block id: 977 */
            union U0 *l_2236 = &g_15;
            for (g_675 = (-13); (g_675 > (-20)); g_675--)
            { /* block id: 980 */
                uint32_t l_2221 = 0xC01874F0L;
                int32_t ***l_2233 = &g_143;
                for (g_65 = 0; (g_65 <= 1); g_65 += 1)
                { /* block id: 983 */
                    int16_t l_2228 = 0x8AB3L;
                    int32_t l_2235 = 4L;
                    for (g_681 = 0; (g_681 <= 1); g_681 += 1)
                    { /* block id: 986 */
                        uint16_t l_2222 = 65535UL;
                        int32_t ** const **l_2232 = &l_2231;
                        int16_t *l_2234 = &g_100[4];
                        int32_t l_2238 = 0xA4095481L;
                        int i, j, k;
                        l_2218 = &p_50;
                        l_2235 &= (((*g_1285) = (safe_mul_func_int8_t_s_s(l_2221, (l_2222 | ((p_48 <= (!(safe_rshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(((l_2228 > (safe_lshift_func_int16_t_s_u(0x593BL, (((((*l_2232) = l_2231) == l_2233) > (((*l_2234) ^= ((**g_651) == (p_48 < p_50))) & 0x92EBL)) < p_50)))) || (*g_1480)), p_48)), p_48)))) >= 1UL))))) >= p_50);
                        l_2237 = l_2236;
                        (*l_2218) = (l_2238 ^= l_2222);
                    }
                    return p_49;
                }
                return p_48;
            }
        }
        else
        { /* block id: 1000 */
            uint32_t l_2255 = 0UL;
            for (l_2193.f1 = 22; (l_2193.f1 > 20); l_2193.f1 = safe_sub_func_int16_t_s_s(l_2193.f1, 1))
            { /* block id: 1003 */
                for (g_1976 = (-7); (g_1976 == 7); ++g_1976)
                { /* block id: 1006 */
                    int32_t l_2264 = 9L;
                    l_2264 |= (p_49 > ((safe_mod_func_int8_t_s_s(0L, (safe_mul_func_uint8_t_u_u(p_50, p_48)))) >= (safe_mod_func_int32_t_s_s((((safe_mod_func_uint16_t_u_u((l_2255 < ((*g_1480) <= ((safe_add_func_int64_t_s_s((*l_2218), (p_50 && (safe_add_func_int8_t_s_s(((*g_1285) = (((safe_lshift_func_uint8_t_u_u(((*l_2195) | 1L), p_49)) & (*l_2218)) && 0x403CL)), 4L))))) == 0L))), l_2255)) != p_49) < g_681), 0x668D9E1EL))));
                }
                return p_50;
            }
        }
        if (((((safe_lshift_func_uint16_t_u_s(((g_495[0] = (((l_2269 == ((*l_2272) = (l_2270 = l_2269))) > 0x41F58E49D8229B0FLL) < ((((***g_209) = (safe_sub_func_int64_t_s_s(0x5846523FE539DABALL, ((safe_rshift_func_uint16_t_u_s((((*g_1285) , (((l_2188 = ((*g_1480) , (*g_651))) == (void*)0) >= 0UL)) , (*l_2218)), 13)) , (**g_1085))))) , (*g_659)) == (*g_659)))) , g_2279[2][3][4]), p_48)) , (*g_337)) || (*g_652)) != 0UL))
        { /* block id: 1018 */
            int64_t l_2280 = 7L;
            int32_t l_2282 = (-2L);
            int32_t l_2283[10] = {2L,1L,0xE4581878L,1L,2L,2L,1L,0xE4581878L,1L,2L};
            uint16_t l_2284[7] = {0x5C44L,8UL,0x5C44L,0x5C44L,8UL,0x5C44L,0x5C44L};
            int i;
            l_2284[4]++;
            if (g_65)
                goto lbl_2287;
lbl_2287:
            (*g_1031) = (void*)0;
            (*l_2218) = 1L;
        }
        else
        { /* block id: 1023 */
            uint16_t l_2290 = 2UL;
            int64_t **l_2321[3];
            int64_t l_2345[2][5] = {{0x1536C745D07A051ALL,0x1536C745D07A051ALL,0x99F2DC870AF03FA9LL,0x1536C745D07A051ALL,0x1536C745D07A051ALL},{0x524BE18A1676492ALL,0x1536C745D07A051ALL,0x524BE18A1676492ALL,0x524BE18A1676492ALL,0x1536C745D07A051ALL}};
            const union U0 l_2381 = {0xA6C6L};
            int32_t l_2391[1][2][6] = {{{(-2L),0xD9AAC9FEL,0xD9AAC9FEL,(-2L),0xD9AAC9FEL,0xD9AAC9FEL},{(-2L),0xD9AAC9FEL,0xD9AAC9FEL,(-2L),0xD9AAC9FEL,0xD9AAC9FEL}}};
            uint32_t l_2407 = 6UL;
            int32_t *l_2410 = &l_2301[2][5];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_2321[i] = &l_2198;
            --l_2290;
            if ((safe_sub_func_int16_t_s_s((!0xB41BE91C82B80427LL), g_650[0])))
            { /* block id: 1025 */
                uint64_t l_2302 = 0x57DE2CBAD4528099LL;
                for (l_2281 = 5; (l_2281 > (-30)); l_2281 = safe_sub_func_uint32_t_u_u(l_2281, 1))
                { /* block id: 1028 */
                    int32_t l_2300 = (-8L);
                    for (g_97 = 13; (g_97 > 22); g_97 = safe_add_func_uint64_t_u_u(g_97, 2))
                    { /* block id: 1031 */
                        (*l_2218) = 0xB64A93F4L;
                    }
                    for (g_256 = 0; (g_256 <= 6); g_256 += 1)
                    { /* block id: 1036 */
                        l_2302--;
                    }
                    for (l_2302 = 0; (l_2302 < 18); l_2302 = safe_add_func_uint8_t_u_u(l_2302, 3))
                    { /* block id: 1041 */
                        int32_t l_2307 = (-1L);
                        const int64_t * const *l_2310[10] = {&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480};
                        uint32_t **l_2331 = &l_2278[4][4][4];
                        int16_t *l_2332 = (void*)0;
                        int i;
                        (*l_2218) = (((((*l_2218) , ((l_2307 && (safe_mod_func_uint8_t_u_u((l_2310[0] != (void*)0), (((safe_rshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((safe_add_func_uint16_t_u_u((((safe_mod_func_int8_t_s_s((l_2321[2] == (((p_49 , (safe_mul_func_uint8_t_u_u(((((safe_mul_func_int16_t_s_s((g_100[4] ^= (safe_mul_func_uint16_t_u_u(((**g_1052) = ((~(1UL && (safe_mod_func_uint8_t_u_u((((&g_2279[2][3][4] == ((*l_2331) = &g_1600[4])) <= p_49) >= (**g_651)), 1L)))) , l_2307)), p_50))), g_2)) , p_48) , 0xC3L) == l_2302), 0x02L))) < p_48) , &l_2215)), p_48)) == p_48) ^ 0x52L), l_2307)), p_49)), p_50)), p_50)) , p_49) , l_2302)))) , 1L)) | p_49) ^ g_675) != p_49);
                    }
                }
            }
            else
            { /* block id: 1048 */
                union U0 l_2335 = {65529UL};
                uint64_t *l_2344 = &g_135;
                int32_t l_2372 = (-4L);
                int32_t l_2390 = 1L;
                int32_t l_2398 = 4L;
                int32_t l_2399[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_2399[i] = (-1L);
                if ((safe_mod_func_uint8_t_u_u(((((l_2335 , (safe_add_func_int16_t_s_s(l_2290, (*l_2218)))) != ((p_48 >= ((((*l_2199) = l_2338) == (void*)0) & ((((l_2343[0] = ((*g_1085) = ((safe_add_func_int64_t_s_s((*l_2218), (safe_rshift_func_int8_t_s_u(((p_50 | 0x70CCL) >= (*l_2218)), (*l_2218))))) , (*g_1085)))) != l_2344) != p_48) >= p_50))) & 0xBFL)) ^ p_48) & (-2L)), l_2345[0][1])))
                { /* block id: 1052 */
                    uint8_t *l_2363 = (void*)0;
                    uint8_t *l_2364 = &g_97;
                    int32_t l_2370 = 0x2634D7F4L;
                    for (l_2335.f1 = 0; (l_2335.f1 <= (-10)); l_2335.f1 = safe_sub_func_int32_t_s_s(l_2335.f1, 4))
                    { /* block id: 1055 */
                        if (p_49)
                            break;
                    }
                    l_2372 ^= ((g_2348 == (void*)0) != ((safe_sub_func_int64_t_s_s((safe_lshift_func_int8_t_s_u((safe_unary_minus_func_uint64_t_u(18446744073709551615UL)), ((l_2371[1] = ((safe_unary_minus_func_int8_t_s((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s((((safe_div_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u(((*l_2364) = 0UL), 0)), 0x59L)) ^ (safe_mod_func_int32_t_s_s(((p_50 , p_48) < (p_50 == (((safe_add_func_int16_t_s_s((l_2370 |= ((((safe_unary_minus_func_uint8_t_u((0xF9L >= p_50))) & 0x5606L) <= 0x6F9C2329B61F2865LL) == g_393[4][1][1])), l_2335.f1)) != p_49) ^ p_49))), (*g_652)))) > l_2335.f1), 6)) && p_48), (-10L))))) < (*g_337))) || (-1L)))), 0xFFEA059E6156CF85LL)) ^ 1L));
                }
                else
                { /* block id: 1062 */
                    uint32_t l_2385 = 0x26972581L;
                    int32_t l_2392 = (-5L);
                    int32_t l_2396 = 0x6A3224D4L;
                    int32_t l_2400 = 0x574F060BL;
                    int32_t l_2402[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2402[i] = 0x522D215CL;
                    if ((safe_mod_func_uint8_t_u_u(255UL, (safe_mod_func_uint8_t_u_u((safe_add_func_int16_t_s_s(p_49, ((safe_sub_func_int64_t_s_s(1L, (*g_134))) , (((void*)0 != &l_2237) <= ((l_2381 , (!(safe_mul_func_int16_t_s_s(l_2385, (safe_mod_func_int64_t_s_s(p_50, 1L)))))) , p_50))))), (-9L))))))
                    { /* block id: 1063 */
                        int32_t l_2388[10][6][4] = {{{0L,(-1L),(-1L),0x655ED6FAL},{(-1L),(-1L),(-1L),0x33F8A1C3L},{(-1L),0x53DE9127L,9L,9L},{9L,0x655ED6FAL,0L,0x53DE9127L},{0x4FEF511EL,0L,0L,0x4FEF511EL},{9L,0x33F8A1C3L,9L,(-1L)}},{{(-1L),(-10L),(-1L),0x8C190CC4L},{(-1L),0x8C190CC4L,(-1L),0x8C190CC4L},{0L,(-10L),0x655ED6FAL,(-1L)},{0x810CA98DL,0x33F8A1C3L,0x8C190CC4L,0x4FEF511EL},{0x655ED6FAL,0L,0x53DE9127L,0x53DE9127L},{0x655ED6FAL,0x655ED6FAL,0x8C190CC4L,9L}},{{0x810CA98DL,0x53DE9127L,0x655ED6FAL,0x33F8A1C3L},{0L,(-1L),(-1L),0x655ED6FAL},{(-1L),(-1L),(-1L),0x33F8A1C3L},{(-1L),0x53DE9127L,9L,9L},{9L,0x655ED6FAL,0L,0x53DE9127L},{0x4FEF511EL,0L,0L,0x4FEF511EL}},{{9L,0x33F8A1C3L,9L,(-1L)},{(-1L),(-10L),(-1L),0x8C190CC4L},{(-1L),0x8C190CC4L,(-1L),0x8C190CC4L},{0L,(-10L),0x655ED6FAL,(-1L)},{0x810CA98DL,0x33F8A1C3L,0x8C190CC4L,0x4FEF511EL},{0x655ED6FAL,0L,0x53DE9127L,0x53DE9127L}},{{0x655ED6FAL,0x655ED6FAL,0x8C190CC4L,9L},{0x810CA98DL,0x53DE9127L,0x655ED6FAL,0x33F8A1C3L},{0L,(-1L),(-1L),0x655ED6FAL},{(-1L),(-1L),(-1L),0x33F8A1C3L},{(-1L),0x53DE9127L,9L,9L},{9L,0x655ED6FAL,0L,0x53DE9127L}},{{0x655ED6FAL,0x4FEF511EL,0x4FEF511EL,0x655ED6FAL},{0x33F8A1C3L,(-10L),(-1L),0x53DE9127L},{9L,9L,0x53DE9127L,(-1L)},{0x53DE9127L,(-1L),0x810CA98DL,(-1L)},{0x4FEF511EL,9L,0x8C190CC4L,0x53DE9127L},{(-1L),(-10L),(-1L),0x655ED6FAL}},{{0x8C190CC4L,0x4FEF511EL,0L,0L},{0x8C190CC4L,0x8C190CC4L,(-1L),0x33F8A1C3L},{(-1L),0L,0x8C190CC4L,(-10L)},{0x4FEF511EL,9L,0x810CA98DL,0x8C190CC4L},{0x53DE9127L,9L,0x53DE9127L,(-10L)},{9L,0L,(-1L),0x33F8A1C3L}},{{0x33F8A1C3L,0x8C190CC4L,0x4FEF511EL,0L},{0x655ED6FAL,0x4FEF511EL,0x4FEF511EL,0x655ED6FAL},{0x33F8A1C3L,(-10L),(-1L),0x53DE9127L},{9L,9L,0x53DE9127L,(-1L)},{0x53DE9127L,(-1L),0x810CA98DL,(-1L)},{0x4FEF511EL,9L,0x8C190CC4L,0x53DE9127L}},{{(-1L),(-10L),(-1L),0x655ED6FAL},{0x8C190CC4L,0x4FEF511EL,0L,0L},{0x8C190CC4L,0x8C190CC4L,(-1L),0x33F8A1C3L},{(-1L),0L,0x8C190CC4L,(-10L)},{0x4FEF511EL,9L,0x810CA98DL,0x8C190CC4L},{0x53DE9127L,9L,0x53DE9127L,(-10L)}},{{9L,0L,(-1L),0x33F8A1C3L},{0x33F8A1C3L,0x8C190CC4L,0x4FEF511EL,0L},{0x655ED6FAL,0x4FEF511EL,0x4FEF511EL,0x655ED6FAL},{0x33F8A1C3L,(-10L),(-1L),0x53DE9127L},{9L,9L,0x53DE9127L,(-1L)},{0x53DE9127L,(-1L),0x810CA98DL,(-1L)}}};
                        int32_t l_2389[2];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_2389[i] = (-3L);
                        (*l_2218) |= l_2388[5][5][2];
                        ++l_2407;
                        (*l_2218) ^= p_49;
                    }
                    else
                    { /* block id: 1067 */
                        return p_48;
                    }
                    return l_2398;
                }
                l_2410 = &l_2390;
            }
            for (l_2204 = 0; (l_2204 == (-25)); --l_2204)
            { /* block id: 1076 */
                return (*l_2218);
            }
        }
        for (g_374.f1 = 0; (g_374.f1 <= 2); g_374.f1 += 1)
        { /* block id: 1082 */
            return p_50;
        }
    }
    else
    { /* block id: 1085 */
        int16_t l_2428 = 0xE5ABL;
        uint8_t **l_2494 = &g_660[5][2][0];
        int32_t l_2500 = 8L;
        int32_t l_2501 = (-1L);
        int32_t l_2502 = 0xFD1AB546L;
        int32_t l_2503 = 1L;
        int32_t l_2507 = 0xA710C7E6L;
        int32_t l_2509[8] = {(-5L),(-4L),(-5L),(-4L),(-5L),(-4L),(-5L),(-4L)};
        uint32_t l_2524 = 6UL;
        uint32_t l_2558 = 0xA4E1A8C8L;
        uint32_t l_2688 = 4294967295UL;
        int8_t l_2693[10] = {0x2DL,1L,1L,0x2DL,1L,1L,0x2DL,1L,1L,0x2DL};
        uint32_t **l_2709[2][3][8] = {{{(void*)0,&l_2188,(void*)0,(void*)0,&l_2188,(void*)0,(void*)0,&l_2188},{&l_2188,(void*)0,(void*)0,&l_2188,(void*)0,(void*)0,&l_2188,(void*)0},{&l_2188,&l_2188,(void*)0,&l_2188,&l_2188,(void*)0,&l_2188,&l_2188}},{{(void*)0,&l_2188,(void*)0,(void*)0,&l_2188,(void*)0,(void*)0,&l_2188},{&l_2188,(void*)0,(void*)0,&l_2188,(void*)0,(void*)0,&l_2188,(void*)0},{&l_2188,&l_2188,(void*)0,&l_2188,&l_2188,(void*)0,&l_2188,&l_2188}}};
        int i, j, k;
        if ((safe_add_func_uint64_t_u_u((safe_lshift_func_int16_t_s_u((+((safe_sub_func_uint32_t_u_u((*g_652), (safe_mul_func_uint8_t_u_u(((*g_134) > (((safe_add_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u(((l_2428 < ((((safe_lshift_func_int8_t_s_u((((void*)0 == &g_715[1]) <= ((p_49 != (g_100[4] ^= ((safe_sub_func_uint32_t_u_u(p_48, (safe_add_func_uint8_t_u_u((*l_2218), 0x84L)))) <= (**g_651)))) | l_2428)), p_48)) , (void*)0) != l_2435) == (*g_1053))) , p_50), 7)) || p_48), 5UL)) ^ (*l_2218)) && g_2436[3])), p_50)))) , p_48)), 7)), 0L)))
        { /* block id: 1087 */
            uint16_t l_2440 = 0UL;
            const uint64_t *l_2442 = &g_2443;
            const uint64_t **l_2441[10] = {&l_2442,&l_2442,&l_2442,&l_2442,&l_2442,&l_2442,&l_2442,&l_2442,&l_2442,&l_2442};
            uint8_t *l_2454 = (void*)0;
            uint8_t *l_2455 = &g_2436[3];
            int32_t l_2475 = 0x771265B9L;
            int32_t l_2508 = (-1L);
            int32_t l_2510 = (-1L);
            int32_t l_2511 = (-1L);
            int32_t l_2512 = 5L;
            int32_t l_2513 = 8L;
            int32_t l_2514 = 0x7388A2AFL;
            int32_t l_2515 = 1L;
            int32_t l_2517 = 0xE411B5E0L;
            int32_t l_2557[1];
            uint32_t l_2589 = 0UL;
            int64_t *l_2634 = &g_113[1];
            int64_t **l_2633 = &l_2634;
            int i;
            for (i = 0; i < 1; i++)
                l_2557[i] = 0x7AA2FA70L;
            (*l_2218) = (safe_mul_func_uint16_t_u_u((&g_930[1] != l_2439[4]), (((((l_2440 , (*g_1085)) == (g_2444 = (*g_1085))) , (safe_lshift_func_int16_t_s_s(0xA6F7L, 6))) != (safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((safe_div_func_uint8_t_u_u((((((*l_2455)--) <= (safe_mod_func_uint32_t_u_u(((((((*g_1285) = 0x32L) != (safe_mul_func_int8_t_s_s(p_49, g_1600[4]))) , 0xFCB5L) & l_2428) && 7L), 0xCE74E1F0L))) | 0x042340A125447356LL) && 0x7404176A08454084LL), 2L)), p_48)), l_2428))) < (-3L))));
lbl_2590:
            for (g_289 = 0; (g_289 <= 2); g_289 += 1)
            { /* block id: 1094 */
                int64_t l_2473[5][5][6] = {{{0x747116D0E17F5D89LL,0x75F9D22561A214B4LL,4L,0xE5F7F78D238EB0DDLL,0x61CB252DF245B795LL,0x970CD7328853CA86LL},{0xDD7CA57BEB131918LL,(-3L),0x130ACDBBD2EF351DLL,0x747116D0E17F5D89LL,0x747116D0E17F5D89LL,0x130ACDBBD2EF351DLL},{0x4E969EF097FE925ALL,0x4E969EF097FE925ALL,0x62CF26082DB208B1LL,0x747116D0E17F5D89LL,(-3L),0x42F41EC3F803F65FLL},{0xDD7CA57BEB131918LL,0x9B6659C981E7944DLL,0x970CD7328853CA86LL,0xE5F7F78D238EB0DDLL,0x8A4469B2086BB410LL,0x62CF26082DB208B1LL},{0x747116D0E17F5D89LL,0xDD7CA57BEB131918LL,0x970CD7328853CA86LL,5L,0x4E969EF097FE925ALL,0x42F41EC3F803F65FLL}},{{1L,5L,0x62CF26082DB208B1LL,0x9B6659C981E7944DLL,5L,0x130ACDBBD2EF351DLL},{0x9B6659C981E7944DLL,5L,0x130ACDBBD2EF351DLL,0x61CB252DF245B795LL,0x4E969EF097FE925ALL,0x970CD7328853CA86LL},{0x8A4469B2086BB410LL,0xDD7CA57BEB131918LL,4L,0xDD7CA57BEB131918LL,0x8A4469B2086BB410LL,(-1L)},{0x8A4469B2086BB410LL,0x9B6659C981E7944DLL,0xEE616D3F465C6300LL,0x61CB252DF245B795LL,(-3L),0xEA2AFD7560A1D963LL},{0x9B6659C981E7944DLL,0x4E969EF097FE925ALL,(-4L),0x9B6659C981E7944DLL,0x747116D0E17F5D89LL,0xEA2AFD7560A1D963LL}},{{1L,(-3L),0xEE616D3F465C6300LL,5L,0x61CB252DF245B795LL,(-1L)},{0x747116D0E17F5D89LL,0x75F9D22561A214B4LL,4L,0xE5F7F78D238EB0DDLL,0x61CB252DF245B795LL,0x970CD7328853CA86LL},{0xDD7CA57BEB131918LL,(-3L),0x130ACDBBD2EF351DLL,0x747116D0E17F5D89LL,0x747116D0E17F5D89LL,0x130ACDBBD2EF351DLL},{0x4E969EF097FE925ALL,0x4E969EF097FE925ALL,0x62CF26082DB208B1LL,0x747116D0E17F5D89LL,(-3L),0x42F41EC3F803F65FLL},{0xDD7CA57BEB131918LL,0x9B6659C981E7944DLL,0x970CD7328853CA86LL,0xE5F7F78D238EB0DDLL,0x8A4469B2086BB410LL,0x62CF26082DB208B1LL}},{{0x747116D0E17F5D89LL,0xDD7CA57BEB131918LL,0x970CD7328853CA86LL,5L,0x4E969EF097FE925ALL,0x42F41EC3F803F65FLL},{1L,5L,0x62CF26082DB208B1LL,0x9B6659C981E7944DLL,5L,0x130ACDBBD2EF351DLL},{0x9B6659C981E7944DLL,5L,0x130ACDBBD2EF351DLL,0x61CB252DF245B795LL,0x4E969EF097FE925ALL,0x970CD7328853CA86LL},{0x8A4469B2086BB410LL,0xDD7CA57BEB131918LL,4L,0xDD7CA57BEB131918LL,0x8A4469B2086BB410LL,(-1L)},{0x8A4469B2086BB410LL,0x9B6659C981E7944DLL,0xEE616D3F465C6300LL,0x61CB252DF245B795LL,(-3L),0xEA2AFD7560A1D963LL}},{{0x9B6659C981E7944DLL,0x4E969EF097FE925ALL,(-4L),0x9B6659C981E7944DLL,0x747116D0E17F5D89LL,0xEA2AFD7560A1D963LL},{1L,(-3L),0xEE616D3F465C6300LL,5L,0x61CB252DF245B795LL,(-1L)},{0x747116D0E17F5D89LL,0x75F9D22561A214B4LL,4L,0xE5F7F78D238EB0DDLL,0x61CB252DF245B795LL,0x970CD7328853CA86LL},{0xDD7CA57BEB131918LL,(-3L),0x130ACDBBD2EF351DLL,0x747116D0E17F5D89LL,0x747116D0E17F5D89LL,0x130ACDBBD2EF351DLL},{0x4E969EF097FE925ALL,0x4E969EF097FE925ALL,0x62CF26082DB208B1LL,0x747116D0E17F5D89LL,(-3L),0x42F41EC3F803F65FLL}}};
                int32_t l_2474[6] = {1L,1L,1L,1L,1L,1L};
                int64_t l_2555 = (-1L);
                int16_t l_2556 = 7L;
                int i, j, k;
                for (g_717 = 2; (g_717 >= 0); g_717 -= 1)
                { /* block id: 1097 */
                    uint16_t l_2477 = 0x13A5L;
                    int32_t l_2491 = 0x28B8E5CFL;
                    int32_t l_2504 = (-1L);
                    int32_t l_2505 = 0x89F5BDD3L;
                    int32_t l_2506[7] = {2L,2L,2L,2L,2L,2L,2L};
                    union U0 l_2544 = {0UL};
                    int i;
                    if ((+(!p_49)))
                    { /* block id: 1098 */
                        int32_t *l_2464 = &l_2405;
                        int32_t *l_2465 = &l_2397;
                        int32_t *l_2466 = &l_2404;
                        int32_t *l_2467 = &l_2401;
                        int32_t *l_2468 = &l_2406[5][0][1];
                        int32_t *l_2469 = &l_2397;
                        int32_t *l_2470 = &l_2403;
                        int32_t *l_2471 = (void*)0;
                        int32_t *l_2472[8][7][4] = {{{&l_2405,(void*)0,&l_2406[4][8][1],&l_2406[5][0][1]},{&l_2403,&l_2405,(void*)0,(void*)0},{&l_2403,&g_5[0],&l_2397,&g_392},{&l_2403,&l_2405,(void*)0,&l_2406[5][0][1]},{&l_2403,&g_392,&l_2406[4][8][1],&g_141},{&l_2405,&g_2194,&l_2403,&l_2406[4][8][1]},{(void*)0,&g_8[8],&g_8[8],(void*)0}},{{&l_2403,&l_2403,&l_2397,&l_2393},{&l_2405,&g_141,&l_2403,(void*)0},{(void*)0,(void*)0,&g_71,(void*)0},{&l_2288,&g_141,&g_390,&l_2393},{&l_2406[4][8][1],&l_2403,&g_5[0],(void*)0},{&g_354,&g_8[8],&l_2393,&l_2406[4][8][1]},{&l_2288,(void*)0,&l_2288,&g_390}},{{&g_141,(void*)0,&l_2403,&g_354},{(void*)0,&g_8[8],(void*)0,(void*)0},{&l_2403,&l_2406[4][8][1],(void*)0,&l_2393},{(void*)0,(void*)0,&l_2403,&g_141},{&g_141,(void*)0,&l_2288,(void*)0},{&l_2288,(void*)0,&l_2393,&l_2393},{&g_354,&g_354,&g_5[0],&l_2405}},{{&l_2406[4][8][1],&g_8[8],&g_390,&l_2403},{&l_2288,&l_2405,&g_71,&g_390},{(void*)0,&l_2405,&l_2403,&l_2403},{&l_2405,&g_8[8],&l_2397,&l_2405},{&l_2403,&g_354,&g_8[8],&l_2393},{(void*)0,(void*)0,&l_2403,(void*)0},{(void*)0,(void*)0,&l_2403,&g_141}},{{&l_2288,(void*)0,&g_8[1],&l_2393},{&l_2403,&l_2406[4][8][1],&g_5[0],(void*)0},{&l_2403,&g_8[8],&g_8[1],&g_354},{&l_2288,(void*)0,&l_2403,&g_390},{(void*)0,(void*)0,&l_2403,&l_2406[4][8][1]},{(void*)0,&g_8[8],&g_8[8],(void*)0},{&l_2403,&l_2403,&l_2397,&l_2393}},{{&l_2405,&g_141,&l_2403,(void*)0},{(void*)0,(void*)0,&g_71,(void*)0},{&l_2288,&g_141,&g_390,&l_2393},{&l_2406[4][8][1],&l_2403,&g_5[0],(void*)0},{&g_354,&g_8[8],&l_2393,&l_2406[4][8][1]},{&l_2288,(void*)0,&l_2288,&g_390},{&g_141,(void*)0,&l_2403,&g_354}},{{(void*)0,&g_8[8],(void*)0,(void*)0},{&l_2403,&l_2406[4][8][1],(void*)0,&l_2393},{(void*)0,(void*)0,&l_2403,&g_141},{&g_141,(void*)0,&l_2288,(void*)0},{&l_2288,(void*)0,&l_2393,&l_2393},{&g_354,&g_354,&g_5[0],&l_2405},{&l_2406[4][8][1],&g_8[8],&g_390,&l_2403}},{{&l_2288,&l_2405,&g_71,&g_390},{(void*)0,&l_2405,&l_2403,&l_2403},{&l_2405,&g_8[8],&l_2397,&l_2405},{&l_2403,&g_354,&g_8[8],&l_2393},{(void*)0,&g_8[1],&l_2403,&g_8[1]},{&l_2393,&l_2403,&l_2406[5][0][1],&g_390},{&l_2405,&l_2393,&g_392,&g_2194}}};
                        int32_t l_2476 = 0xE1E51E50L;
                        int16_t *l_2482[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i, j, k;
                        l_2477--;
                        (*l_2467) = 0L;
                        (*l_2470) ^= ((safe_mul_func_uint8_t_u_u(((((g_100[5] = (*l_2218)) > (safe_mod_func_int8_t_s_s(l_2473[4][3][4], (*l_2469)))) ^ (((((safe_lshift_func_int8_t_s_s(p_48, (((l_2474[3] |= p_48) != (((safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(((l_2491 = (1L == (((**g_1052) &= 0xA57EL) > (*l_2469)))) | (safe_sub_func_int32_t_s_s(0xD957DF1AL, l_2473[0][2][4]))), p_48)), p_48)) ^ p_50) != l_2477)) , p_49))) , (void*)0) == l_2494) > p_50) & 0x681E8187L)) > (*l_2467)), p_48)) || (*g_1285));
                    }
                    else
                    { /* block id: 1106 */
                        int32_t *l_2495 = (void*)0;
                        int32_t *l_2496 = &l_2395;
                        int32_t *l_2497 = &l_2401;
                        int32_t *l_2498 = &l_2397;
                        int32_t *l_2499[6][8] = {{(void*)0,&g_8[1],&l_2405,&l_2393,&l_2405,&g_8[1],(void*)0,&g_390},{&l_2405,&g_8[1],(void*)0,&g_390,&g_141,&g_141,&g_390,(void*)0},{&l_2395,&l_2395,&g_8[1],&l_2405,&g_141,&l_2393,&g_71,&l_2393},{&l_2405,(void*)0,&l_2405,(void*)0,&l_2405,&g_390,&l_2395,&l_2393},{(void*)0,&g_141,&g_71,&l_2405,&l_2405,&g_71,&g_141,(void*)0},{&g_8[1],&g_390,&g_71,&g_390,&l_2395,&l_2405,&l_2395,&g_390}};
                        int32_t l_2518 = 0x6E9C7430L;
                        uint32_t l_2519 = 18446744073709551610UL;
                        int32_t **l_2522 = &l_2498;
                        int i, j;
                        ++l_2519;
                        (*l_2522) = &l_2474[2];
                        --l_2524;
                    }
                    if (l_2474[4])
                    { /* block id: 1111 */
                        uint32_t l_2550[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_2550[i] = 0x5B6B8E5BL;
                        (*l_2218) = (0x0D283B58A24CD2A4LL && ((*l_2215) = (safe_div_func_uint32_t_u_u((((*l_2455)--) , (*g_652)), (safe_lshift_func_int16_t_s_u(((l_2513 , &g_2115[4][1][1]) == (void*)0), (safe_lshift_func_int16_t_s_s((l_2511 != 0x34L), ((*l_2218) <= (*g_1480))))))))));
                        (*l_2218) = (p_50 = (*l_2218));
                        l_2550[4] ^= (l_2428 | ((((*l_2215) = l_2537) | ((safe_mul_func_uint8_t_u_u((((248UL & (((((safe_sub_func_int16_t_s_s(p_50, p_48)) == (((safe_add_func_int64_t_s_s((l_2544 , ((safe_rshift_func_uint8_t_u_u(((*l_2455) = l_2501), 6)) >= (((*l_2218) &= 0x6E57411BL) > (safe_lshift_func_uint8_t_u_s((4294967293UL > l_2549[1][1][2]), 7))))), p_49)) , 0x9CL) ^ p_50)) & p_48) == 1UL) & 0x23E0L)) & p_50) | 0UL), p_48)) , 0UL)) > 0x38L));
                    }
                    else
                    { /* block id: 1121 */
                        return p_50;
                    }
                    for (g_1474 = 0; (g_1474 <= 2); g_1474 += 1)
                    { /* block id: 1126 */
                        int32_t *l_2551 = &l_2502;
                        int32_t *l_2552 = &g_71;
                        int32_t *l_2553 = &g_71;
                        int32_t *l_2554[6][6][7] = {{{(void*)0,&l_2406[5][0][1],&l_2507,(void*)0,&l_2474[2],&l_2505,&l_2401},{&g_5[0],&l_2395,(void*)0,(void*)0,&l_2508,&l_2510,&l_2508},{&l_2474[2],&g_394,&g_394,&l_2474[2],&l_2406[0][9][1],(void*)0,&g_394},{&l_2475,&g_8[2],&l_2397,&l_2406[5][2][1],&g_2194,(void*)0,&l_2507},{&g_5[0],&l_2506[1],&l_2505,&g_394,&l_2510,&l_2503,&g_394},{&l_2510,(void*)0,&l_2474[5],&l_2395,(void*)0,&g_141,&l_2508}},{{&l_2475,&l_2517,&g_5[1],&g_394,&g_5[0],(void*)0,&l_2401},{&g_394,(void*)0,(void*)0,&l_2508,&l_2406[6][2][0],&l_2515,&g_394},{&g_2194,&g_141,&l_2475,&l_2508,(void*)0,&l_2401,&l_2406[5][0][1]},{&l_2507,&l_2475,&l_2406[0][9][1],&g_394,&g_2194,&l_2505,&l_2505},{&l_2506[1],&l_2395,&l_2395,&l_2395,&l_2506[1],&g_141,&l_2517},{&l_2517,&l_2512,(void*)0,&g_394,&g_5[1],(void*)0,&g_2194}},{{&l_2512,&l_2475,&g_5[1],&l_2406[5][2][1],&l_2474[2],&l_2475,&l_2406[5][2][1]},{&l_2517,&g_394,&l_2393,&l_2474[2],&g_8[2],&l_2401,&l_2395},{&l_2506[1],(void*)0,(void*)0,(void*)0,&l_2406[5][2][1],&l_2474[5],&g_2194},{&l_2507,&l_2517,&l_2397,(void*)0,(void*)0,&l_2397,&l_2474[5]},{&g_2194,&l_2510,&l_2514,&l_2501,(void*)0,&l_2395,&g_5[0]},{&g_394,&l_2406[0][9][1],(void*)0,&l_2406[6][2][0],&l_2406[5][2][1],(void*)0,&l_2406[5][0][1]}},{{&l_2475,&l_2406[5][2][1],&l_2395,&l_2395,&l_2406[5][2][1],&l_2517,&l_2401},{&l_2505,(void*)0,&l_2474[2],(void*)0,&l_2474[5],&l_2512,&l_2406[5][2][1]},{&l_2514,&l_2505,&l_2504,&g_5[1],&g_354,&l_2509[5],&l_2507},{&l_2393,(void*)0,(void*)0,&l_2393,&l_2512,(void*)0,&l_2503},{&l_2474[5],&l_2406[5][2][1],(void*)0,(void*)0,(void*)0,&l_2506[1],&l_2475},{&l_2514,&g_354,&l_2503,&l_2397,&l_2504,&l_2401,&g_141}},{{&l_2504,&l_2505,&g_392,&l_2514,&l_2406[0][9][1],&l_2401,&g_354},{&g_5[1],&l_2405,&l_2501,(void*)0,&l_2514,&l_2506[1],&l_2406[5][2][1]},{&l_2397,(void*)0,&l_2508,&l_2507,&l_2508,(void*)0,&l_2397},{&l_2515,&l_2397,&l_2393,&g_354,&l_2505,&l_2509[5],(void*)0},{&l_2475,&l_2475,&l_2395,(void*)0,(void*)0,&l_2512,&l_2514},{&l_2512,&l_2514,&l_2393,&g_394,&g_354,&l_2517,&l_2405}},{{&g_392,&g_394,&l_2508,&l_2401,&l_2507,&l_2503,&l_2515},{&g_394,&l_2475,&l_2501,(void*)0,&l_2474[5],&l_2517,(void*)0},{&l_2405,&l_2401,&g_392,&l_2474[5],&l_2509[5],&g_141,(void*)0},{&g_354,(void*)0,&l_2503,&l_2517,(void*)0,&g_392,&l_2515},{&l_2475,&l_2405,(void*)0,(void*)0,(void*)0,(void*)0,&l_2405},{(void*)0,&l_2504,(void*)0,&l_2475,(void*)0,&l_2393,&l_2514}}};
                        int i, j, k;
                        --l_2558;
                    }
                }
                return l_2509[5];
            }
            l_2237 = &l_2193;
            if ((safe_lshift_func_int16_t_s_u(l_2517, (l_2563 == (l_2564 , &g_2444)))))
            { /* block id: 1133 */
                int32_t ***l_2575 = &g_143;
                int32_t l_2639 = 0xD1B7B006L;
                for (g_97 = (-16); (g_97 <= 59); g_97++)
                { /* block id: 1136 */
                    uint8_t l_2582 = 249UL;
                    for (g_2194 = 0; (g_2194 == (-21)); g_2194 = safe_sub_func_int64_t_s_s(g_2194, 3))
                    { /* block id: 1139 */
                        int32_t ***l_2574 = &g_143;
                        int32_t l_2587 = 1L;
                        int32_t *l_2588[2][1][2];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 1; j++)
                            {
                                for (k = 0; k < 2; k++)
                                    l_2588[i][j][k] = &l_2404;
                            }
                        }
                        p_50 = (0UL == (safe_unary_minus_func_uint8_t_u((((*l_2237) , (((safe_mod_func_uint32_t_u_u(0UL, ((*g_652) , ((*l_2218) = ((safe_sub_func_uint32_t_u_u(0UL, l_2501)) | (l_2574 == (l_2575 = &g_143))))))) == ((l_2511 | 0x5590363EL) | 0UL)) || 0x3EADAFBDL)) > l_2428))));
                        l_2589 |= ((*l_2218) ^= ((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((0x5AL | p_50), (safe_mod_func_int32_t_s_s((&g_652 != &g_652), l_2582)))), ((((p_50 && (safe_div_func_uint32_t_u_u(((((((&g_2115[1][0][1] != l_2585[0][2]) >= 0xDCL) && l_2587) & 1L) && l_2582) || p_48), (**g_651)))) > p_48) , p_48) <= l_2509[4]))) <= p_48));
                        if (g_346)
                            goto lbl_2590;
                    }
                }
                (*l_2218) ^= (safe_sub_func_int32_t_s_s((safe_mul_func_int16_t_s_s(0L, ((safe_rshift_func_int16_t_s_u(2L, p_50)) ^ p_48))), ((safe_rshift_func_int8_t_s_s((safe_mod_func_int16_t_s_s((safe_div_func_int8_t_s_s(((*g_1285) |= (-3L)), (safe_mul_func_int16_t_s_s(4L, p_48)))), (safe_sub_func_int16_t_s_s(0xE00DL, (safe_mod_func_int16_t_s_s(1L, 1UL)))))), 0)) , l_2507)));
                for (l_2503 = 4; (l_2503 >= 0); l_2503 -= 1)
                { /* block id: 1152 */
                    int32_t *l_2611 = &g_8[1];
                    int i;
                    if (g_495[l_2503])
                        break;
                    (*g_1034) = ((safe_rshift_func_uint16_t_u_u(g_495[l_2503], 13)) , l_2611);
                    for (g_169 = 0; (g_169 <= 4); g_169 += 1)
                    { /* block id: 1157 */
                        int16_t *l_2640 = (void*)0;
                        int16_t *l_2641[8] = {&g_100[2],&l_2428,&g_100[2],&l_2428,&g_100[2],&l_2428,&g_100[2],&l_2428};
                        int i, j;
                        p_50 = (safe_mod_func_int32_t_s_s(((((safe_add_func_int64_t_s_s((safe_mod_func_int32_t_s_s(0xE0F62CFAL, ((*g_1285) , ((safe_lshift_func_int16_t_s_u((g_100[4] = ((safe_add_func_int32_t_s_s((safe_rshift_func_int8_t_s_u((&l_2401 == (void*)0), 6)), ((*g_652) || ((~(g_74[l_2503][g_169] = (((safe_mul_func_int8_t_s_s((((**g_651) ^= (safe_div_func_int32_t_s_s(0L, ((safe_div_func_int16_t_s_s(((safe_lshift_func_int8_t_s_s(((void*)0 != l_2633), (safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s(l_2639, l_2440)) >= 0xA8659E73L), p_50)))) & 1L), p_48)) || l_2639)))) > l_2517), (*g_1285))) , p_50) ^ 0x252F9199L))) , p_49)))) || l_2501)), l_2500)) , 5L)))), (*l_2218))) >= 0xE1E2L) != p_48) , g_74[l_2503][g_169]), l_2509[5]));
                        return p_49;
                    }
                }
            }
            else
            { /* block id: 1165 */
                int64_t l_2642 = (-10L);
                union U0 ***l_2649 = &g_1023[2][2];
                union U0 ****l_2648 = &l_2649;
                uint32_t *l_2654 = &g_1600[4];
                uint8_t ***l_2680 = &g_659;
                int32_t l_2701[2][3];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_2701[i][j] = (-8L);
                }
                if ((((*l_2237) , l_2642) || (((*l_2654) = (safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((((((g_2647[4][1][4] |= l_2510) , ((l_2512 != (((((((((((*l_2218) && (((**g_651) = (l_2557[0] && (((*l_2648) = (void*)0) == (void*)0))) >= (((safe_add_func_uint64_t_u_u(((safe_rshift_func_int16_t_s_s(((((*l_2218) = ((((l_2642 || p_48) == 0x23L) >= l_2642) >= (-3L))) , p_50) != l_2524), 0)) >= p_50), p_50)) , 0UL) >= l_2589))) && (*g_134)) || p_50) >= (**g_1052)) ^ l_2517) , (*g_1480)) || (**g_1085)) || l_2642) || l_2510) & (*g_2444))) > p_48)) , 0x18L) >= 0x10L) ^ p_50), l_2642)), (*g_1285)))) , 0xFCL)))
                { /* block id: 1171 */
                    p_50 ^= ((*l_2218) = 0xF3D39923L);
                }
                else
                { /* block id: 1174 */
                    uint64_t **l_2676[6][10] = {{&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134},{&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,(void*)0,&g_134},{&g_134,&g_134,&g_134,(void*)0,&g_134,(void*)0,&g_134,&g_134,&g_134,&g_134},{&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134},{&g_134,(void*)0,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134,(void*)0},{&g_134,&g_134,&g_134,(void*)0,&g_134,&g_134,&g_134,&g_134,&g_134,&g_134}};
                    int32_t l_2702 = 0xDE115762L;
                    int32_t l_2703 = 0x3300FEEBL;
                    int32_t l_2704 = 0x8ED2DDA7L;
                    int32_t l_2705 = (-1L);
                    uint16_t l_2706 = 0x707FL;
                    int i, j;
                    for (p_48 = (-17); (p_48 == 2); p_48 = safe_add_func_uint32_t_u_u(p_48, 1))
                    { /* block id: 1177 */
                        uint8_t * const *l_2658 = &l_2454;
                        uint8_t * const **l_2657[1][6][9] = {{{&l_2658,&l_2658,&l_2658,(void*)0,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658},{&l_2658,&l_2658,(void*)0,&l_2658,&l_2658,&l_2658,&l_2658,(void*)0,&l_2658},{&l_2658,(void*)0,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,(void*)0},{(void*)0,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658},{(void*)0,(void*)0,(void*)0,(void*)0,&l_2658,&l_2658,&l_2658,&l_2658,(void*)0},{&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658,&l_2658}}};
                        int32_t l_2672 = 0x11797956L;
                        int64_t *l_2677[6];
                        int8_t *l_2678[7][4] = {{&g_393[4][1][1],&l_2516,(void*)0,(void*)0},{(void*)0,(void*)0,&g_393[4][1][1],(void*)0},{&g_393[5][0][4],&l_2516,&g_393[5][0][4],&g_393[4][1][1]},{&g_393[5][0][4],&g_393[4][1][1],&g_393[4][1][1],&g_393[5][0][4]},{(void*)0,&g_393[4][1][1],(void*)0,&g_393[4][1][1]},{&g_393[4][1][1],&l_2516,(void*)0,(void*)0},{(void*)0,(void*)0,&g_393[4][1][1],(void*)0}};
                        int32_t *l_2679 = &g_392;
                        int16_t *l_2689 = &g_100[5];
                        int32_t *l_2690 = &l_2406[0][4][1];
                        int32_t *l_2691 = &l_2557[0];
                        int32_t *l_2692 = &l_2557[0];
                        int32_t *l_2694 = &l_2508;
                        int32_t *l_2695 = &l_2500;
                        int32_t *l_2696 = &l_2404;
                        int32_t *l_2697 = &l_2515;
                        int32_t *l_2698 = &l_2395;
                        int32_t *l_2699 = &g_71;
                        int32_t *l_2700[1];
                        int i, j, k;
                        for (i = 0; i < 6; i++)
                            l_2677[i] = &g_289;
                        for (i = 0; i < 1; i++)
                            l_2700[i] = &l_2406[6][4][0];
                        l_2494 = (void*)0;
                        (*l_2679) = (((**l_2633) = (p_49 >= p_49)) != (((((safe_lshift_func_uint8_t_u_s(g_2661, ((*l_2218) = ((safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s(((*g_1285) = (*l_2218)), ((((safe_rshift_func_uint16_t_u_s((safe_mod_func_int64_t_s_s((g_289 = (l_2672 < (~(safe_div_func_int64_t_s_s((1L & ((((((((((g_2194 | (l_2510 , l_2642)) | (-7L)) , g_680) != l_2503) ^ p_48) , l_2676[0][1]) == (void*)0) && l_2642) && 0xEB9A52E4L) != (**g_651))), p_48))))), 7UL)), 13)) || 0x1ECDF1AEL) , (*g_337)) == p_48))) , p_48), p_49)), (-1L))) , 9L)))) > p_49) ^ p_48) & (-1L)) , 0xDD0516E1A9D5B4CCLL));
                        p_50 = (((*l_2689) = (((void*)0 != l_2680) == ((safe_div_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u((((((safe_unary_minus_func_uint16_t_u((p_49 == (*g_1480)))) ^ (*l_2679)) < (0x24A0L <= p_49)) , (void*)0) == (p_50 , (void*)0)), 4)) && l_2688), (-1L))) > l_2511))) , 0xFCF1777BL);
                        l_2706++;
                    }
                    l_2709[1][2][7] = (void*)0;
                    (*l_2218) = l_2642;
                }
            }
        }
        else
        { /* block id: 1192 */
            for (l_2524 = (-20); (l_2524 != 32); l_2524 = safe_add_func_uint8_t_u_u(l_2524, 1))
            { /* block id: 1195 */
                (*l_2218) |= (!(safe_unary_minus_func_uint64_t_u(((*l_2563) == (void*)0))));
            }
        }
    }
    (*l_2218) = ((safe_mul_func_int8_t_s_s((g_717 |= (((*g_134) | (l_2716 != (((*l_2743) ^= ((p_49 || ((*l_2742) = ((((((((safe_div_func_uint8_t_u_u((((*l_2218) <= p_48) | p_50), (safe_rshift_func_uint8_t_u_s(((((*l_2740) ^= (l_2739 = ((*g_1285) |= ((0xFD82F0B5L <= ((((safe_div_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u((safe_rshift_func_uint8_t_u_s(l_2728, 0)))), 1)) , ((safe_rshift_func_int16_t_s_u((g_950 ^= (safe_rshift_func_uint16_t_u_u((((l_2733 = l_2733) != g_2736[1][0][3]) | (*l_2218)), p_49))), (*l_2218))) < (*l_2218))), p_49)) , 0x524C2F9FDEBE46D8LL) & p_50) || 0xEFA9L)) || 0x6753ECFA0B6962A5LL)))) ^ p_49) & (*l_2218)), 1)))) == l_2741) == p_48) | p_48) != p_50) < (*l_2218)) , p_48) , 255UL))) , p_48)) , (void*)0))) || l_2744)), 0xEAL)) | p_49);
    return (*l_2218);
}


/* ------------------------------------------ */
/* 
 * reads : g_15.f1 g_52 g_3 g_74 g_35 g_256 g_5 g_8 g_113 g_289 g_188 g_251 g_134 g_135 g_100 g_141 g_245 g_97 g_346 g_71 g_143 g_144 g_209 g_250 g_337 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_652 g_1285 g_1053 g_1480 g_1481
 * writes: g_15.f1 g_65 g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675 g_715
 */
static int8_t  func_54(int32_t  p_55)
{ /* block id: 14 */
    int16_t **l_69 = &g_35;
    int32_t l_2125 = 0x9464AA52L;
    int32_t *l_2142 = &g_354;
    int32_t l_2175 = 0x2C1108C8L;
    uint16_t l_2178 = 65534UL;
    int32_t *l_2181 = &l_2125;
    int32_t *l_2182 = (void*)0;
    int32_t *l_2183[9] = {&g_8[1],&g_8[1],&g_8[1],&g_8[1],&g_8[1],&g_8[1],&g_8[1],&g_8[1],&g_8[1]};
    uint32_t l_2184 = 4294967290UL;
    int i;
    for (g_15.f1 = 0; (g_15.f1 < 8); g_15.f1 = safe_add_func_uint64_t_u_u(g_15.f1, 9))
    { /* block id: 17 */
        uint64_t *l_64 = &g_65;
        int32_t **l_713 = (void*)0;
        int32_t **l_714[2];
        int16_t ***l_2120 = &l_69;
        union U0 l_2121 = {65527UL};
        int64_t ****l_2122[7][10] = {{(void*)0,&g_1620,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620},{&g_1620,&g_1620,&g_1620,(void*)0,&g_1620,(void*)0,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,(void*)0,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620,&g_1620,(void*)0,&g_1620},{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,(void*)0,&g_1620,&g_1620,&g_1620,&g_1620},{&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620,&g_1620}};
        int i, j;
        for (i = 0; i < 2; i++)
            l_714[i] = &g_337;
        (*l_2120) = func_58((safe_add_func_uint32_t_u_u((((*l_64) = g_52) || ((!0x6A0230A2L) , g_3)), 1L)), (g_715[1] = func_67(l_69)), p_55);
        if ((((l_2121 , &g_1620) != ((**g_651) , l_2122[2][0])) <= (safe_sub_func_int8_t_s_s((l_2125 = ((((0x7F899A9E315101E4LL == ((*g_134) = (p_55 == (((((l_2125 >= ((safe_lshift_func_int16_t_s_u(p_55, l_2125)) , l_2125)) > p_55) > 0x9AEE9868FCF01F03LL) <= p_55) < (-1L))))) & p_55) , l_2125) <= 4294967291UL)), (*g_1285)))))
        { /* block id: 933 */
            l_2125 |= 0L;
            p_55 = ((*g_1285) , (-2L));
        }
        else
        { /* block id: 936 */
            int64_t l_2130[9][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
            int32_t * const *l_2169 = &g_715[1];
            int32_t * const **l_2168 = &l_2169;
            int32_t l_2176[9];
            int i, j;
            for (i = 0; i < 9; i++)
                l_2176[i] = (-6L);
            l_2142 = (((safe_mod_func_int64_t_s_s((l_2130[2][1] , (l_2121 , (safe_mul_func_uint8_t_u_u(((((*g_652) & (safe_div_func_uint8_t_u_u((0x78349FAEL < (p_55 = (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((*g_1053) , 0xD936L), (((~(!((0x559AF74DFDE5AD55LL | (+p_55)) >= (p_55 | l_2125)))) < (*g_652)) < l_2130[2][1]))), 0x6193L)))), 1L))) | (*g_1285)) > 5UL), 0x57L)))), l_2125)) <= l_2125) , &p_55);
            if (p_55)
                continue;
            for (g_354 = 0; (g_354 == (-14)); g_354--)
            { /* block id: 942 */
                int32_t *l_2147 = &g_71;
                int32_t * const ***l_2170 = &l_2168;
                int32_t l_2177 = 0L;
                for (g_346 = 4; (g_346 > 58); g_346 = safe_add_func_int64_t_s_s(g_346, 8))
                { /* block id: 945 */
                    l_2147 = &p_55;
                    (*l_2147) = (0xA9L & p_55);
                    for (g_392 = 0; (g_392 > (-2)); g_392 = safe_sub_func_uint16_t_u_u(g_392, 9))
                    { /* block id: 950 */
                        (*l_2147) = 0x29A0D19EL;
                        return (*g_1285);
                    }
                }
                l_2177 = (l_2176[3] = (((*g_1053) = p_55) , ((l_2130[2][1] && (((l_2125 = (safe_mul_func_int16_t_s_s((((safe_add_func_uint64_t_u_u(((*g_134) = (((*l_2147) = (((safe_add_func_int32_t_s_s(2L, (safe_lshift_func_int16_t_s_u(((safe_mul_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s((*l_2142), ((safe_add_func_int8_t_s_s((safe_div_func_uint64_t_u_u(((*l_64) = ((safe_lshift_func_int16_t_s_u(((((*g_1285) = (&g_861[6] != ((*l_2170) = l_2168))) | (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((((l_2121 , ((**g_651) = (**g_651))) || p_55) < 0x737F22669A4F2982LL), p_55)), p_55)) ^ (*g_1480)) || (-4L))) != p_55), 2)) == (*g_1480))), p_55)), 0xDFL)) && p_55))) == (*l_2142)), (*l_2147))) >= (*l_2142)), 3)))) , (void*)0) == (void*)0)) == 0x8F11D4CBL)), 18446744073709551609UL)) ^ (*g_1480)) ^ l_2175), l_2175))) & 0xDA7D2C3DL) , 1UL)) || p_55)));
                return p_55;
            }
        }
        --l_2178;
    }
    ++l_2184;
    return p_55;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t ** func_58(const int32_t  p_59, int32_t * p_60, uint16_t  p_61)
{ /* block id: 324 */
    int32_t *l_716[8] = {&g_390,&g_390,&g_390,&g_390,&g_390,&g_390,&g_390,&g_390};
    uint8_t l_718 = 255UL;
    uint8_t **l_721 = &g_660[5][2][0];
    union U0 l_722 = {1UL};
    int16_t **l_740 = &g_35;
    int16_t ***l_739 = &l_740;
    union U0 **l_757[8];
    uint32_t l_833[3][8] = {{0xF2333162L,0xF2333162L,0x17E89B25L,0x17E89B25L,0xF2333162L,0x17E89B25L,0x17E89B25L,0xF2333162L},{0xF2333162L,0x17E89B25L,0x17E89B25L,0xF2333162L,0x17E89B25L,0x17E89B25L,0xF2333162L,0x17E89B25L},{0xF2333162L,0xF2333162L,0x84A39758L,0xF2333162L,0xF2333162L,0x84A39758L,0xF2333162L,0xF2333162L}};
    int32_t l_834 = (-1L);
    int32_t l_855 = 0xFA289992L;
    int32_t l_875[3];
    const int32_t *l_898 = (void*)0;
    int16_t l_907 = 0x6519L;
    int32_t ****l_922 = &g_209;
    int32_t *****l_921[1];
    int32_t l_927 = (-6L);
    uint64_t *l_964 = &g_346;
    int16_t l_979 = 0xB1D2L;
    int32_t l_1016 = 0x6FE03FF5L;
    uint64_t l_1032 = 0x1F53C6768F183D28LL;
    int64_t *l_1128[10][8][3] = {{{&g_289,&g_113[2],&g_113[2]},{&g_681,&g_289,&g_113[0]},{(void*)0,&g_113[1],&g_681},{&g_113[2],(void*)0,&g_113[2]},{&g_113[2],(void*)0,&g_681},{&g_113[0],&g_113[2],&g_681},{&g_113[2],&g_681,&g_289},{&g_681,&g_113[1],(void*)0}},{{&g_289,&g_289,&g_289},{&g_289,&g_289,&g_113[2]},{&g_681,&g_113[2],&g_289},{&g_113[2],&g_113[2],&g_113[0]},{&g_113[0],&g_289,&g_681},{&g_113[2],&g_681,&g_681},{&g_113[2],&g_113[2],&g_113[2]},{(void*)0,&g_113[2],&g_681}},{{&g_681,&g_289,&g_289},{&g_289,&g_681,&g_113[2]},{(void*)0,&g_681,&g_289},{&g_289,&g_113[0],&g_681},{&g_681,&g_113[2],&g_113[2]},{&g_289,&g_113[0],&g_681},{&g_289,&g_113[2],&g_681},{&g_113[2],&g_289,&g_113[0]}},{{&g_113[2],&g_113[2],&g_289},{&g_113[2],(void*)0,&g_113[2]},{&g_681,&g_289,&g_289},{&g_113[0],&g_289,(void*)0},{(void*)0,(void*)0,&g_289},{(void*)0,&g_113[2],&g_681},{&g_681,&g_289,&g_681},{&g_113[2],&g_113[2],&g_113[2]}},{{&g_681,&g_113[0],&g_681},{(void*)0,&g_113[2],&g_113[0]},{&g_113[2],&g_113[0],&g_113[2]},{(void*)0,&g_681,&g_289},{(void*)0,&g_681,&g_113[2]},{(void*)0,&g_289,&g_113[0]},{&g_113[2],&g_113[2],&g_289},{(void*)0,&g_113[2],(void*)0}},{{&g_681,&g_681,&g_681},{&g_113[2],&g_289,&g_289},{&g_681,&g_113[2],&g_289},{(void*)0,&g_113[2],&g_681},{(void*)0,&g_289,&g_113[2]},{&g_113[0],&g_289,&g_113[2]},{&g_681,&g_113[1],&g_681},{&g_113[2],&g_681,&g_289}},{{&g_113[2],&g_113[2],&g_289},{&g_113[2],(void*)0,&g_681},{&g_289,(void*)0,(void*)0},{&g_289,&g_113[1],&g_289},{&g_681,&g_289,&g_113[0]},{&g_289,&g_113[2],&g_113[2]},{(void*)0,&g_289,&g_289},{&g_289,&g_113[2],&g_681}},{{&g_113[2],&g_113[2],&g_681},{&g_113[0],&g_289,(void*)0},{&g_113[1],&g_289,&g_681},{&g_113[2],(void*)0,&g_113[2]},{&g_113[2],&g_113[2],&g_681},{&g_113[2],&g_681,&g_113[2]},{(void*)0,&g_289,&g_113[0]},{&g_289,(void*)0,&g_113[0]}},{{&g_289,&g_113[2],&g_113[2]},{(void*)0,&g_289,&g_681},{&g_113[2],(void*)0,&g_681},{&g_113[2],&g_113[2],&g_681},{&g_113[2],&g_113[2],&g_113[2]},{&g_113[1],&g_113[1],&g_113[2]},{&g_113[0],&g_113[2],&g_113[2]},{&g_113[2],&g_113[2],&g_289}},{{&g_289,&g_681,&g_113[2]},{&g_113[2],&g_113[2],&g_289},{&g_289,&g_681,&g_113[2]},{&g_681,&g_289,&g_113[2]},{&g_681,&g_113[2],&g_113[2]},{&g_289,(void*)0,&g_681},{&g_113[2],(void*)0,&g_681},{&g_113[2],&g_113[2],&g_681}}};
    int32_t **l_1178 = &l_716[6];
    int32_t *l_1195 = &l_834;
    uint16_t ***l_1207 = &g_1052;
    uint32_t l_1213[7][2][5] = {{{4294967295UL,4294967295UL,4294967290UL,1UL,0x16FE3E2EL},{0x34DFBD77L,1UL,0x736C429DL,4294967291UL,0xB515FCDEL}},{{4294967289UL,1UL,0x3A36CD1EL,0x3A36CD1EL,1UL},{0xB515FCDEL,1UL,4294967295UL,0xF1B38EB1L,0x2F0330FFL}},{{0xCCD713B8L,4294967295UL,0xCCD713B8L,0x3A36CD1EL,4294967290UL},{0x601776F7L,4294967291UL,0x2F0330FFL,4294967291UL,0x601776F7L}},{{0xCCD713B8L,4294967289UL,4294967295UL,1UL,4294967295UL},{0xB515FCDEL,0xB531E949L,0x2F0330FFL,1UL,4294967286UL}},{{4294967289UL,0xCCD713B8L,0xCCD713B8L,4294967289UL,4294967295UL},{0x34DFBD77L,1UL,4294967295UL,4294967287UL,0x601776F7L}},{{4294967295UL,0xCCD713B8L,0x3A36CD1EL,4294967290UL,4294967290UL},{0x736C429DL,0xB531E949L,0x736C429DL,4294967287UL,0x2F0330FFL}},{{1UL,4294967289UL,4294967290UL,4294967289UL,1UL},{0x736C429DL,4294967291UL,0xB515FCDEL,1UL,0xB515FCDEL}}};
    union U0 ***l_1231 = &g_1025;
    int8_t *l_1286 = (void*)0;
    uint16_t l_1312 = 0xD027L;
    int64_t l_1315 = 4L;
    uint16_t l_1319 = 0UL;
    int16_t *l_1369 = &l_979;
    uint32_t l_1471 = 18446744073709551615UL;
    uint32_t l_1542 = 6UL;
    uint8_t l_1547 = 5UL;
    const int64_t **l_1636[6] = {&g_1480,&g_1480,&g_1480,&g_1480,&g_1480,&g_1480};
    uint16_t *l_1681 = &l_1319;
    int64_t l_1734 = 1L;
    int16_t l_1736 = (-1L);
    int16_t *l_1754 = &g_100[3];
    uint64_t ** const *l_1789[3][4] = {{&g_1085,&g_1085,&g_1085,&g_1085},{&g_1085,&g_1085,&g_1085,&g_1085},{&g_1085,&g_1085,&g_1085,&g_1085}};
    uint64_t ** const **l_1788[2][10][1] = {{{(void*)0},{&l_1789[1][0]},{(void*)0},{&l_1789[0][1]},{(void*)0},{&l_1789[1][0]},{(void*)0},{&l_1789[0][1]},{(void*)0},{&l_1789[1][0]}},{{(void*)0},{&l_1789[0][1]},{(void*)0},{&l_1789[1][0]},{(void*)0},{&l_1789[0][1]},{(void*)0},{&l_1789[1][0]},{(void*)0},{&l_1789[0][1]}}};
    int64_t l_1821 = (-1L);
    int64_t **l_1861 = &l_1128[7][4][2];
    int32_t l_1880[1][5];
    const uint64_t l_1882[7] = {0x419A3242789F9C64LL,0x419A3242789F9C64LL,0x419A3242789F9C64LL,0x419A3242789F9C64LL,0x419A3242789F9C64LL,0x419A3242789F9C64LL,0x419A3242789F9C64LL};
    int32_t l_1922 = 0x86A3CB3AL;
    int16_t l_1952 = (-8L);
    int32_t l_1953 = 8L;
    uint32_t l_2031 = 0UL;
    uint16_t l_2117 = 0xA5F4L;
    uint16_t l_2118 = 65535UL;
    int16_t **l_2119[9][2] = {{&g_35,&g_35},{&g_35,&g_35},{&g_35,&l_1754},{&g_35,&g_35},{&l_1754,&g_35},{&g_35,&l_1754},{&g_35,&g_35},{&l_1754,&g_35},{&g_35,&l_1754}};
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_757[i] = &g_373[1];
    for (i = 0; i < 3; i++)
        l_875[i] = (-3L);
    for (i = 0; i < 1; i++)
        l_921[i] = &l_922;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_1880[i][j] = 0x637C0022L;
    }
    l_718++;
    return &g_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_71 g_35 g_256 g_5 g_8 g_113 g_289 g_188 g_52 g_251 g_134 g_135 g_15.f1 g_100 g_141 g_245 g_97 g_346 g_143 g_144 g_209 g_250 g_337 g_354 g_374.f0 g_394 g_133 g_390 g_374.f1 g_393 g_495 g_169 g_517 g_392 g_650 g_651 g_659 g_682 g_675
 * writes: g_74 g_71 g_256 g_289 g_113 g_135 g_100 g_188 g_337 g_346 g_354 g_373 g_97 g_374.f0 g_394 g_495 g_133 g_169 g_517 g_392 g_141 g_144 g_245 g_393 g_682 g_374.f1 g_390 g_675
 */
static int32_t * func_67(int16_t ** p_68)
{ /* block id: 19 */
    int32_t *l_70 = &g_71;
    int32_t l_72[2][7][1] = {{{0x77138BF9L},{(-1L)},{0x77138BF9L},{(-1L)},{0x77138BF9L},{(-1L)},{0x77138BF9L}},{{(-1L)},{0x77138BF9L},{(-1L)},{0x77138BF9L},{(-1L)},{0x77138BF9L},{(-1L)}}};
    int32_t *l_73[8][6] = {{&g_71,&l_72[0][1][0],&g_71,(void*)0,(void*)0,(void*)0},{&l_72[0][1][0],&l_72[0][1][0],&l_72[0][1][0],(void*)0,(void*)0,(void*)0},{&g_71,&l_72[0][1][0],&g_71,(void*)0,(void*)0,(void*)0},{&l_72[0][1][0],&l_72[0][1][0],&l_72[0][1][0],(void*)0,(void*)0,(void*)0},{&g_71,&l_72[0][1][0],&g_71,(void*)0,(void*)0,(void*)0},{&l_72[0][1][0],&l_72[0][1][0],&l_72[0][1][0],(void*)0,(void*)0,(void*)0},{&g_71,&l_72[0][1][0],&g_71,(void*)0,(void*)0,(void*)0},{&l_72[0][1][0],&l_72[0][1][0],&l_72[0][1][0],(void*)0,(void*)0,(void*)0}};
    int16_t **l_347 = &g_35;
    uint16_t l_369 = 0x228BL;
    union U0 *l_371[3][9];
    const int64_t *l_434 = &g_113[2];
    int8_t l_501 = 0xFEL;
    int32_t *l_510[7][3] = {{&g_390,&l_72[1][2][0],&g_5[0]},{&g_390,&g_390,&l_72[1][1][0]},{&g_390,&g_8[1],&g_390},{&g_390,&l_72[1][2][0],&g_5[0]},{&g_390,&g_390,&l_72[1][1][0]},{&g_390,&g_8[1],&g_390},{&g_390,&l_72[1][2][0],&g_5[0]}};
    uint16_t l_581 = 0x2378L;
    const int32_t *l_658[5][5] = {{&g_650[2],&g_650[2],&g_650[2],&g_650[2],&g_650[2]},{&g_650[1],&g_250,&g_650[1],&g_250,&g_650[1]},{&g_650[2],&g_650[2],&g_650[2],&g_650[2],&g_650[2]},{&g_650[1],&g_250,&g_650[1],&g_250,&g_650[1]},{&g_650[2],&g_650[2],&g_650[2],&g_650[2],&g_650[2]}};
    const int32_t **l_657 = &l_658[2][0];
    const int32_t ***l_656 = &l_657;
    int64_t l_664 = 9L;
    uint64_t l_667 = 0xF997E07526DB002ELL;
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
            l_371[i][j] = (void*)0;
    }
    g_74[0][2]++;
    for (g_71 = 0; (g_71 >= 0); g_71 -= 1)
    { /* block id: 23 */
        int32_t l_80 = 5L;
        uint64_t *l_345[2][1][5];
        int32_t l_355 = 0x12024B52L;
        int32_t ** const l_368 = (void*)0;
        int32_t l_370[7][2] = {{0xEC1910D5L,0x121716B6L},{0xEC1910D5L,3L},{(-1L),(-1L)},{3L,0xEC1910D5L},{0x121716B6L,0xEC1910D5L},{3L,(-1L)},{(-1L),3L}};
        union U0 **l_372[8] = {&l_371[1][1],&l_371[0][0],&l_371[1][1],&l_371[0][0],&l_371[1][1],&l_371[0][0],&l_371[1][1],&l_371[0][0]};
        int32_t **l_375 = &l_73[6][5];
        uint8_t *l_383[5][5] = {{(void*)0,&g_97,&g_97,(void*)0,&g_256},{&g_256,(void*)0,&g_256,&g_97,&g_97},{&g_97,(void*)0,&g_97,&g_256,(void*)0},{&g_97,&g_97,&g_256,&g_97,&g_256},{&g_97,&g_97,&g_256,(void*)0,&g_256}};
        uint16_t *l_494 = &g_74[0][3];
        uint8_t **l_566 = &l_383[3][3];
        int32_t l_578 = 0x02365809L;
        int i, j, k;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 5; k++)
                    l_345[i][j][k] = &g_346;
            }
        }
        l_355 = (func_77(g_35, l_80) >= (g_141 ^ ((safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((((((g_354 = (((g_346 ^= ((void*)0 != &g_35)) , (l_347 == ((safe_lshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_s((((*l_70) >= (1UL > l_80)) < 0L), g_5[0])), 3)) , p_68))) <= 0xF49F01A5L)) | g_5[2]) , l_80) > g_71) , (*l_70)), 8UL)), l_80)), (*l_70))) != 5L)));
        l_370[6][0] &= ((safe_div_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s((l_80 != ((*l_70) ^ (safe_mul_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u(l_80, (((&l_80 == ((&g_15 == &g_15) , (*g_143))) , (((((safe_div_func_int64_t_s_s((l_368 != ((((*l_70) | (*l_70)) <= 1L) , (*g_209))), (*g_134))) || g_250) == 4294967295UL) , (*g_209)) != (*g_209))) , (-8L)))) >= 3UL), l_355)))), l_355)), l_369)), (*g_134))) | l_80);
        g_373[8] = l_371[2][6];
        (*l_375) = (void*)0;
        for (g_97 = 0; (g_97 <= 0); g_97 += 1)
        { /* block id: 138 */
            uint32_t l_376 = 0x382C0D10L;
            uint8_t *l_379 = &g_256;
            uint16_t l_382 = 1UL;
            int32_t l_385 = (-1L);
            int32_t l_423 = 0L;
            int32_t l_424 = 0xD15D58CFL;
            int32_t l_425 = (-1L);
            int32_t l_426 = 0L;
            int32_t l_427 = 0x999E632DL;
            int32_t l_429[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
            int64_t *l_451[3];
            const int64_t l_490 = 9L;
            uint16_t l_493 = 0xD1B1L;
            uint32_t *l_506 = &g_133;
            union U0 l_520 = {0x23E1L};
            uint64_t l_547 = 1UL;
            uint32_t l_563 = 0x64AA3DE2L;
            int32_t ****l_573 = &g_209;
            int32_t *****l_572 = &l_573;
            int32_t l_604 = 7L;
            int16_t **l_608 = &g_35;
            int i;
            for (i = 0; i < 3; i++)
                l_451[i] = (void*)0;
            if ((l_376 | (safe_rshift_func_uint8_t_u_s((++(*l_379)), ((0UL > (((void*)0 == &l_376) == g_250)) <= (*g_337))))))
            { /* block id: 140 */
                uint8_t l_395 = 0x31L;
                int32_t l_428 = 0xB802A2F3L;
                uint32_t l_443 = 0x48AFA09FL;
                union U0 l_445 = {0xAF09L};
                (*l_375) = &g_8[5];
                g_354 &= l_382;
                if ((l_383[4][0] != (void*)0))
                { /* block id: 143 */
                    for (g_256 = 0; (g_256 <= 0); g_256 += 1)
                    { /* block id: 146 */
                        int32_t *l_384[6] = {&l_370[6][0],&g_5[0],&l_370[6][0],&l_370[6][0],&g_5[0],&l_370[6][0]};
                        int i;
                        return &g_8[1];
                    }
                    g_354 ^= (g_135 < 0xF7L);
                    if ((*g_337))
                        break;
                }
                else
                { /* block id: 151 */
                    uint32_t l_386 = 18446744073709551615UL;
                    int32_t l_389 = (-1L);
                    int32_t l_391 = 0xBA4EC74FL;
                    const uint8_t l_450 = 0xD9L;
                    uint64_t *l_467 = (void*)0;
                    int8_t *l_489 = &g_188;
                    uint16_t *l_491 = &g_374.f0;
                    uint16_t *l_492 = &g_74[1][2];
                    for (g_374.f0 = 0; (g_374.f0 <= 0); g_374.f0 += 1)
                    { /* block id: 154 */
                        l_386++;
                        --l_395;
                    }
                    if ((((((safe_rshift_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u(((*l_379) = (((((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(g_245, ((safe_add_func_uint64_t_u_u(0x3515B0F2C9D8CCFALL, (*g_134))) && l_395))), 6)) < (~g_8[0])) , (l_382 & ((l_370[0][0] = (((((safe_add_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((0x5B6BL > ((safe_lshift_func_int16_t_s_s((((((safe_unary_minus_func_uint64_t_u((*g_134))) , ((safe_unary_minus_func_int16_t_s(((safe_add_func_uint8_t_u_u((((safe_add_func_int8_t_s_s(((safe_add_func_int32_t_s_s((*l_70), (-1L))) != g_251[1]), (-8L))) && 0x93L) > l_395), g_5[0])) < l_395))) <= 0x53E884B2BF600C53LL)) || l_391) , (*g_134)) , l_355), 11)) || 18446744073709551615UL)), 0L)), (*g_337))) , (*p_68)) == (*p_68)) , l_391) <= l_395)) > l_385))) > l_395) && l_382)), g_5[0])) == (-1L)), 7)) != l_389) < 65529UL) == l_395) || (-10L)))
                    { /* block id: 160 */
                        uint8_t l_430 = 1UL;
                        int32_t l_433 = 0xE4B08A41L;
                        ++l_430;
                        l_428 |= (*g_337);
                        l_433 = (-3L);
                    }
                    else
                    { /* block id: 164 */
                        union U0 ***l_448 = &l_372[3];
                        int32_t l_449 = 0xE0CA48ADL;
                        uint16_t *l_458 = &g_374.f0;
                        uint16_t *l_461 = &l_369;
                        l_427 = (l_425 = (l_434 != (((safe_add_func_uint8_t_u_u((((safe_sub_func_int16_t_s_s(0x716BL, (safe_mod_func_int8_t_s_s(0xFFL, (1UL & (safe_mul_func_uint16_t_u_u(l_443, ((safe_unary_minus_func_uint32_t_u(((l_445 , (safe_sub_func_int64_t_s_s((((((*l_448) = &g_373[5]) != (void*)0) == (((0x21E2236AL > l_449) , l_445.f1) , l_395)) == l_450), (*l_70)))) || l_449))) <= 0xA90DL)))))))) >= l_449) >= 4294967295UL), g_5[0])) , l_445.f1) , l_451[1])));
                        g_394 |= (((((void*)0 != &l_449) ^ (((l_391 >= (safe_sub_func_int16_t_s_s(l_443, ((safe_rshift_func_uint16_t_u_s((g_74[0][2] = ((*l_461) |= ((*l_458)--))), (0x68E690E6L == (safe_div_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((!(((((&g_135 == l_467) && (g_289 && 0xACD075D00FB13ED2LL)) , l_429[2]) || 0x0D34L) == 0xE4414D2BL)), g_5[0])), 0xCC5898F5L))))) , (*l_70))))) , 0x4E99E3B8L) < (*g_337))) & 4294967289UL) != g_289);
                        if (l_429[0])
                            break;
                        if (l_386)
                            break;
                    }
                    if (((safe_rshift_func_uint8_t_u_u(((safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int16_t_s_s(l_395, 12)) | ((((((((safe_div_func_uint16_t_u_u(((((((*l_492) = (safe_lshift_func_int8_t_s_u((g_188 && ((safe_mod_func_int64_t_s_s(((l_425 = 0xD750BC53L) & (safe_mul_func_int8_t_s_s(g_100[3], l_443))), (((safe_add_func_uint16_t_u_u(((*l_491) = ((safe_add_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(((l_428 || (safe_rshift_func_int8_t_s_s(((*l_489) &= g_74[0][1]), g_8[5]))) <= ((((l_427 = l_391) , 0L) ^ 0L) <= l_490)), g_52)), g_133)) && l_376)), 65533UL)) != 0x3AL) , g_141))) || g_390)), g_8[1]))) , l_386) == l_493) <= l_490) > 65527UL), 1UL)) || g_374.f1) , &g_134) == &g_134) & g_97) && l_389) && (-1L)) == 0L)))) != g_5[1]), g_393[4][1][1])) > l_450))
                    { /* block id: 180 */
                        (*l_375) = &l_428;
                        l_355 &= (((void*)0 == l_494) >= 3UL);
                    }
                    else
                    { /* block id: 183 */
                        g_495[0]++;
                    }
                }
            }
            else
            { /* block id: 187 */
                uint32_t l_498 = 0UL;
                l_498--;
                (*l_375) = &l_427;
            }
            if ((((g_188 > 0xCC9D1F3653151024LL) > l_501) >= ((*l_506) = (((*g_134)++) , (safe_mul_func_uint8_t_u_u(g_495[1], 255UL))))))
            { /* block id: 193 */
                uint64_t l_507 = 18446744073709551615UL;
                union U0 ***l_514 = &l_372[2];
                int32_t l_515 = 0xE20458B2L;
                int32_t l_546[4][10][6] = {{{1L,3L,3L,3L,3L,1L},{(-5L),0xF8B31B9CL,3L,1L,(-1L),6L},{0L,0L,(-1L),0L,3L,0x63386438L},{0L,0x62D90D2DL,0L,1L,0xC6BBA75FL,(-9L)},{(-5L),(-1L),0xC3C3448DL,0x1C92C593L,6L,0x55148FB7L},{0x1BD2DCFCL,0x4BE58ECAL,0xF8B31B9CL,0xC6BBA75FL,0xF8B31B9CL,0x4BE58ECAL},{0L,0L,7L,0L,0x1BD2DCFCL,(-4L)},{0x8201A1D8L,1L,6L,0x1BD2DCFCL,(-9L),0x4460107AL},{3L,1L,0x4BE58ECAL,0x4F1DCD45L,0x1BD2DCFCL,(-5L)},{0x4460107AL,0L,1L,3L,0xF8B31B9CL,7L}},{{0xC3C3448DL,0x4BE58ECAL,0xC6BBA75FL,6L,6L,0xC6BBA75FL},{(-1L),(-1L),0x4F1DCD45L,0L,0xC6BBA75FL,0x62D90D2DL},{0L,0x62D90D2DL,0xF98DF71BL,0x55148FB7L,3L,0x4F1DCD45L},{0x4F1DCD45L,0L,0xF98DF71BL,0xF8B31B9CL,(-1L),0x62D90D2DL},{1L,0xF8B31B9CL,0x4F1DCD45L,(-1L),3L,0xC6BBA75FL},{(-1L),3L,0xC6BBA75FL,7L,0x2D5AE75CL,7L},{1L,1L,1L,(-4L),0x63386438L,(-5L)},{0x63386438L,7L,0x4BE58ECAL,0x8201A1D8L,0L,0x4460107AL},{3L,0xF98DF71BL,6L,0x8201A1D8L,(-5L),(-4L)},{0x63386438L,0x1BD2DCFCL,7L,(-4L),0xC3C3448DL,0x4BE58ECAL}},{{1L,3L,0xF8B31B9CL,7L,0x55148FB7L,0x55148FB7L},{(-1L),0xC3C3448DL,0xC3C3448DL,(-1L),0xF98DF71BL,(-9L)},{1L,(-4L),0L,0xF8B31B9CL,1L,0x63386438L},{0x4F1DCD45L,0xC6BBA75FL,(-1L),0x55148FB7L,1L,6L},{0L,(-4L),3L,0L,0xF98DF71BL,0x1BD2DCFCL},{(-1L),0xC3C3448DL,0x1C92C593L,6L,0x55148FB7L,0L},{0xC3C3448DL,3L,0x4460107AL,3L,0xC3C3448DL,1L},{0x4460107AL,0x1BD2DCFCL,1L,0x4F1DCD45L,(-5L),0xC3C3448DL},{3L,0xF98DF71BL,0x2D5AE75CL,0x1BD2DCFCL,0L,0xC3C3448DL},{0x8201A1D8L,7L,1L,0L,0x63386438L,1L}},{{0L,1L,0x4460107AL,0xC6BBA75FL,0x2D5AE75CL,0L},{0x1BD2DCFCL,3L,0x1C92C593L,0x1C92C593L,3L,0x1BD2DCFCL},{(-5L),0xF8B31B9CL,3L,1L,0x1C3C972DL,0x2D5AE75CL},{0x63386438L,0xC6BBA75FL,0xC3C3448DL,(-9L),3L,0x4F1DCD45L},{0x63386438L,0x4460107AL,(-9L),0x1BD2DCFCL,6L,1L},{7L,0x1C3C972DL,0x62D90D2DL,0xF8B31B9CL,0x2D5AE75CL,0L},{3L,0L,(-5L),6L,(-5L),0L},{(-9L),0x63386438L,0x55148FB7L,0xC6BBA75FL,3L,0xF98DF71BL},{1L,(-4L),0x2D5AE75CL,3L,1L,0x4BE58ECAL},{3L,(-4L),0L,(-1L),3L,7L}}};
                int32_t ***l_558 = (void*)0;
                int32_t * const *l_560 = &g_144;
                int32_t * const * const *l_559 = &l_560;
                int i, j, k;
                for (g_169 = 0; (g_169 <= 0); g_169 += 1)
                { /* block id: 196 */
                    int8_t l_516 = 4L;
                    int32_t l_545 = 0L;
                    int32_t ***l_557[6][3] = {{&g_143,&g_143,&g_143},{&g_143,&g_143,&g_143},{&g_143,&g_143,&g_143},{&g_143,&g_143,&g_143},{&g_143,&g_143,&g_143},{&g_143,&g_143,&g_143}};
                    int i, j, k;
                    for (l_426 = 0; (l_426 <= 0); l_426 += 1)
                    { /* block id: 199 */
                        int i, j, k;
                        ++l_507;
                        l_510[0][0] = &l_72[l_426][g_71][g_71];
                        l_429[8] = (l_72[g_169][(l_426 + 3)][l_426] & (safe_add_func_uint32_t_u_u(((*l_506) = ((+0xE043L) > g_74[0][2])), (l_514 != (void*)0))));
                        g_517++;
                    }
                    l_515 = ((((l_546[3][6][1] &= ((l_427 = (l_520 , (safe_lshift_func_uint8_t_u_s((((safe_mul_func_uint16_t_u_u((l_72[(g_71 + 1)][g_71][g_71] < (safe_sub_func_uint32_t_u_u(((*l_506) = (safe_mul_func_uint16_t_u_u(g_8[8], g_346))), g_97))), (safe_mul_func_int16_t_s_s(((((safe_rshift_func_uint16_t_u_s((1UL | ((((l_545 = (safe_sub_func_int32_t_s_s((safe_mod_func_uint16_t_u_u(0x5F53L, (safe_lshift_func_int16_t_s_s(0x6AA7L, (((safe_rshift_func_int16_t_s_u(((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u((((l_516 ^ 0UL) < 1UL) && 0xF8L), g_390)), g_256)) >= l_515), g_245)) >= 0UL) <= l_507))))), 0UL))) , l_516) < l_516) != 0x2793L)), 11)) > (-7L)) || 0x3CF101AF5122942BLL) >= 0x7F8942DDL), g_135)))) ^ 0L) > l_516), 6)))) > 0x8F8EF05FL)) , &g_209) != (void*)0) <= l_507);
                    --l_547;
                    g_141 = (((safe_lshift_func_uint16_t_u_s((l_72[(g_71 + 1)][g_71][g_71] == g_289), (safe_add_func_uint8_t_u_u(l_72[(g_71 + 1)][g_71][g_71], (l_507 , ((safe_div_func_int64_t_s_s((+((l_558 = l_557[3][2]) != l_559)), (safe_mod_func_uint64_t_u_u((((l_545 = (g_392 = ((void*)0 == &g_5[0]))) ^ (g_52 || 4294967295UL)) >= 0xEDL), l_423)))) & l_563)))))) >= l_516) & l_493);
                }
            }
            else
            { /* block id: 217 */
                uint8_t **l_565 = &l_379;
                uint8_t ***l_564[2][5];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 5; j++)
                        l_564[i][j] = &l_565;
                }
                l_566 = &l_379;
            }
            if ((*g_337))
                break;
            if ((safe_lshift_func_int8_t_s_s((+((safe_div_func_int8_t_s_s(((((((*l_572) = &g_209) == ((((((l_424 || (g_113[2] > ((safe_sub_func_int64_t_s_s(g_517, (safe_mod_func_int8_t_s_s(((l_427 , l_578) , (((void*)0 != l_434) != ((*g_134) |= (safe_lshift_func_int16_t_s_s(l_426, 9))))), l_581)))) & l_425))) , (void*)0) != (void*)0) & 0xE17A7460DBC2275CLL) & 0x139DL) , &g_209)) , (*g_337)) >= 1L) & 0xF81CF008L), 0x37L)) && g_100[4])), g_97)))
            { /* block id: 223 */
                int32_t l_582 = (-1L);
                int32_t *l_593 = &l_425;
                if (l_582)
                { /* block id: 224 */
                    uint8_t l_592[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_592[i] = 0x25L;
                    (*l_375) = &l_72[0][1][0];
                    if ((l_385 < (((~g_495[0]) == ((safe_lshift_func_uint16_t_u_u(((*l_494) = g_15.f1), 5)) > (safe_mod_func_uint64_t_u_u(((safe_mod_func_int32_t_s_s(((0UL & (&g_374 == &l_520)) || l_582), (safe_sub_func_int64_t_s_s((l_592[0] , g_394), (*g_134))))) , l_592[1]), 3UL)))) || l_490)))
                    { /* block id: 227 */
                        (*l_375) = l_593;
                    }
                    else
                    { /* block id: 229 */
                        return &g_71;
                    }
                }
                else
                { /* block id: 232 */
                    g_373[8] = &l_520;
                    (*l_593) |= (safe_add_func_uint32_t_u_u((g_495[6] == 7L), (safe_mod_func_uint64_t_u_u((*g_134), (safe_rshift_func_uint8_t_u_s(0x85L, 3))))));
                }
                for (l_385 = 0; (l_385 < 7); l_385 = safe_add_func_int64_t_s_s(l_385, 6))
                { /* block id: 238 */
                    int16_t l_612 = 0L;
                    uint16_t *l_621 = &g_74[3][1];
                    int32_t l_624 = 0xC2709252L;
                    (*l_593) |= (-1L);
                    for (l_382 = 0; (l_382 >= 47); ++l_382)
                    { /* block id: 242 */
                        int64_t l_607 = 0xD45989F73D43171FLL;
                        int16_t ***l_609 = &l_347;
                        if (l_604)
                            break;
                        g_392 &= (safe_rshift_func_int8_t_s_u(((((*g_143) = (**g_209)) == l_593) > l_607), 7));
                        (*l_609) = l_608;
                    }
                    l_355 = (l_370[6][0] = ((safe_mul_func_int16_t_s_s(l_547, (0x7959L == 65530UL))) | (((l_612 |= 0xB5D7L) <= ((safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((l_624 = (g_250 == ((((l_621 == ((((safe_rshift_func_int8_t_s_s(((l_429[5] || ((*l_506) = l_624)) , (*l_593)), 7)) > (-10L)) <= g_393[4][1][1]) , &l_581)) & l_624) , g_15.f1) <= l_624))) < 0x790BL), g_52)), l_423)), g_394)) ^ 0L)) , l_425)));
                    if ((*l_593))
                    { /* block id: 253 */
                        l_593 = ((*l_375) = &l_72[0][3][0]);
                    }
                    else
                    { /* block id: 256 */
                        return &g_392;
                    }
                }
            }
            else
            { /* block id: 260 */
                uint16_t *l_629 = &l_581;
                int32_t l_632[9] = {(-10L),(-1L),(-10L),(-10L),(-1L),(-10L),(-10L),(-1L),(-10L)};
                int32_t l_639 = 0x7AA3CF77L;
                uint8_t **l_661 = (void*)0;
                int i;
                for (g_245 = (-27); (g_245 <= (-23)); g_245 = safe_add_func_uint64_t_u_u(g_245, 7))
                { /* block id: 263 */
                    const int32_t l_647 = 0xC15A3520L;
                    int8_t *l_648 = &g_393[8][2][4];
                    int32_t l_649 = 1L;
                    int8_t *l_655[3][1][6] = {{{&l_501,&g_188,&g_188,&l_501,&g_393[4][2][3],&l_501}},{{&l_501,&g_393[4][2][3],&l_501,&g_188,&g_188,&l_501}},{{&g_393[6][1][4],&g_393[6][1][4],&g_188,&l_520.f1,&g_188,&g_393[6][1][4]}}};
                    int32_t l_676 = (-1L);
                    int32_t l_677 = 0x49A3D4B1L;
                    int32_t l_678 = 0x38C7D021L;
                    int i, j, k;
                    if ((*g_337))
                        break;
                    l_649 = (l_370[3][0] = (safe_mul_func_uint16_t_u_u((((void*)0 != l_629) < ((safe_div_func_uint32_t_u_u(0x0E4DEC48L, ((l_632[2] != (safe_mul_func_uint16_t_u_u((0x7FL | (safe_mul_func_int8_t_s_s(g_495[0], ((safe_div_func_int8_t_s_s((((&g_373[4] != (l_372[1] = &g_373[3])) == ((*g_134)++)) ^ ((((*l_648) = (~(safe_lshift_func_uint16_t_u_u((((safe_sub_func_int32_t_s_s(((l_80 ^ 0xD9F8L) , (*g_337)), l_647)) < l_632[2]) <= 2UL), 0)))) , l_647) ^ 2UL)), g_392)) , l_649)))), g_650[1]))) && g_256))) > g_52)), l_649)));
                    if ((((g_651 == ((safe_rshift_func_int8_t_s_s(g_393[2][0][3], (l_632[6] ^= g_517))) , (void*)0)) >= (((l_664 = ((((void*)0 == l_656) | (((((l_661 = g_659) != &l_379) | ((safe_lshift_func_int16_t_s_u(l_649, l_426)) , 0x57CDL)) == l_647) > l_639)) ^ 0L)) & 0x9DA6848BL) || l_563)) != l_647))
                    { /* block id: 273 */
                        int32_t *l_665 = (void*)0;
                        return l_665;
                    }
                    else
                    { /* block id: 275 */
                        int8_t l_666 = 4L;
                        g_392 = (*g_337);
                        ++l_667;
                    }
                    for (l_385 = (-29); (l_385 < 23); l_385++)
                    { /* block id: 281 */
                        int32_t l_672 = 5L;
                        int32_t l_673 = 0x15D14011L;
                        int32_t l_674 = 0x45F46B51L;
                        g_682--;
                    }
                }
                if (l_426)
                    break;
            }
        }
    }
    if ((*g_337))
    { /* block id: 289 */
        int16_t l_689 = (-1L);
        uint8_t l_699 = 1UL;
        int32_t l_700[6][7][4] = {{{(-1L),0x9EF7A292L,0xC8382EA2L,0L},{(-3L),0x915148D1L,(-3L),0x028B1F52L},{0x915148D1L,0x826DB5F8L,0x826DB5F8L,0x915148D1L},{0xC8382EA2L,(-7L),0xCB45F24AL,0xA50E4DF2L},{(-2L),0xBCD9572BL,(-3L),(-3L)},{0x4B2CBB07L,0xD3C45A41L,(-1L),(-3L)},{(-1L),0xBCD9572BL,0L,0xA50E4DF2L}},{{0x028B1F52L,(-7L),0x13DC9810L,0x915148D1L},{3L,0x826DB5F8L,0xA50E4DF2L,0x028B1F52L},{(-1L),0x915148D1L,(-1L),0L},{0xBCD9572BL,0x9EF7A292L,(-3L),3L},{0x9EF7A292L,0x826DB5F8L,0xD3C45A41L,0x9EF7A292L},{0xC8382EA2L,0x028B1F52L,0xD3C45A41L,0xA50E4DF2L},{0x9EF7A292L,(-3L),(-3L),0xBCD9572BL}},{{0xBCD9572BL,0xD3C45A41L,(-1L),0x4B2CBB07L},{(-1L),0x4B2CBB07L,0xA50E4DF2L,0xA50E4DF2L},{3L,3L,0x13DC9810L,(-2L)},{0x028B1F52L,0x826DB5F8L,0L,(-7L)},{(-1L),(-2L),(-1L),0L},{0x4B2CBB07L,(-2L),(-3L),(-7L)},{(-2L),0x826DB5F8L,0xCB45F24AL,(-2L)}},{{0xC8382EA2L,3L,0x826DB5F8L,0xA50E4DF2L},{0x915148D1L,0x4B2CBB07L,(-3L),0x4B2CBB07L},{(-3L),0xD3C45A41L,0xC8382EA2L,0xBCD9572BL},{(-1L),(-3L),0x2C898304L,0xA50E4DF2L},{(-7L),0x028B1F52L,0x028B1F52L,0xD3C45A41L},{(-1L),0x5194CED6L,0xAB74F634L,(-1L)},{(-10L),0xD3C45A41L,0x0892A1AFL,0x18930865L}},{{0xA50E4DF2L,0xCB45F24AL,(-7L),0xC8382EA2L},{0xCB45F24AL,0x5194CED6L,0x5194CED6L,0xCB45F24AL},{0x0892A1AFL,(-1L),0x13DC9810L,1L},{0x826DB5F8L,0L,(-7L),0xA50E4DF2L},{0x2C898304L,(-3L),0xF05DFF27L,0xA50E4DF2L},{(-10L),0L,0x18930865L,1L},{0xC8382EA2L,(-1L),0x028B1F52L,0xCB45F24AL}},{{(-1L),0x5194CED6L,1L,0xC8382EA2L},{(-10L),0xCB45F24AL,(-10L),0x18930865L},{0L,0xD3C45A41L,(-7L),(-1L)},{0xD3C45A41L,0x5194CED6L,(-3L),0xD3C45A41L},{0x0892A1AFL,0xC8382EA2L,(-3L),1L},{0xD3C45A41L,0xA50E4DF2L,(-7L),0L},{0L,(-3L),(-10L),0x2C898304L}}};
        int i, j, k;
        for (g_374.f1 = (-1); (g_374.f1 != 23); g_374.f1++)
        { /* block id: 292 */
            uint32_t l_687[9] = {0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L,0x03FFD604L};
            int32_t l_688[3][1];
            int32_t l_704 = 0x599E7749L;
            uint64_t l_707 = 0xFFF6582244F22536LL;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 1; j++)
                    l_688[i][j] = 8L;
            }
            for (l_581 = 0; (l_581 <= 5); l_581 += 1)
            { /* block id: 295 */
                for (g_390 = 1; (g_390 <= 5); g_390 += 1)
                { /* block id: 298 */
                    for (g_97 = 0; (g_97 <= 5); g_97 += 1)
                    { /* block id: 301 */
                        int i, j;
                        l_73[(g_97 + 1)][g_390] = &g_354;
                        l_688[1][0] = (l_687[4] = (*g_337));
                    }
                }
                return &g_5[0];
            }
            if (l_689)
                continue;
            l_704 ^= (+(safe_div_func_int32_t_s_s(0xDAF20625L, (safe_rshift_func_int8_t_s_u((safe_mod_func_int8_t_s_s(0xB6L, ((safe_rshift_func_int16_t_s_s(g_8[0], (((0xB8627D01C3234183LL >= (l_699 , (l_700[1][5][0] = 0xAE047A6F2C7930D9LL))) , ((safe_mod_func_uint64_t_u_u((~0xC7L), l_688[1][0])) == 0xA6DFA15AL)) | (*l_70)))) ^ l_687[3]))), (*l_70))))));
            for (g_675 = (-9); (g_675 <= (-16)); g_675--)
            { /* block id: 314 */
                uint16_t l_710 = 65526UL;
                ++l_707;
                ++l_710;
            }
        }
    }
    else
    { /* block id: 319 */
        return &g_392;
    }
    return &g_5[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_256 g_5 g_8 g_113 g_289 g_188 g_52 g_251 g_74 g_134 g_135 g_15.f1 g_100 g_141 g_245 g_97
 * writes: g_256 g_289 g_113 g_74 g_135 g_100 g_188 g_337
 */
static int8_t  func_77(int16_t * p_78, uint64_t  p_79)
{ /* block id: 24 */
    int32_t l_83 = (-5L);
    int32_t l_98 = (-1L);
    int32_t l_101 = 0L;
    int32_t *l_140 = &l_98;
    uint64_t **l_161 = &g_134;
    int32_t l_249 = 0xD4CFF507L;
    int32_t *l_254 = (void*)0;
    int32_t *l_255[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t **l_277[1][8] = {{&l_255[0],&l_255[0],&l_255[0],&l_255[0],&l_255[0],&l_255[0],&l_255[0],&l_255[0]}};
    int64_t *l_288 = &g_289;
    uint32_t l_290 = 4294967286UL;
    uint16_t *l_291 = &g_74[0][2];
    union U0 *l_294 = (void*)0;
    int8_t l_325 = 1L;
    int i, j;
    for (p_79 = 0; (p_79 < 55); p_79++)
    { /* block id: 27 */
        int32_t *l_84 = (void*)0;
        int32_t *l_85 = &l_83;
        int16_t **l_95 = &g_35;
        uint8_t *l_96[8];
        int16_t *l_99[10] = {&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4],&g_100[4]};
        uint32_t l_102 = 0xBF216A9CL;
        int32_t ***l_207 = (void*)0;
        int32_t l_241 = 0L;
        int32_t l_248 = 0x7C34602AL;
        int i;
        for (i = 0; i < 8; i++)
            l_96[i] = &g_97;
        (*l_85) = (p_79 == l_83);
    }
    g_256++;
    if (((p_79 >= (safe_div_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((((*l_140) <= ((*l_291) = (safe_lshift_func_uint16_t_u_s((safe_add_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u((safe_div_func_int32_t_s_s((safe_add_func_uint16_t_u_u(((safe_div_func_int64_t_s_s(((safe_mod_func_uint16_t_u_u((l_277[0][0] == ((safe_rshift_func_int8_t_s_s(0x92L, ((g_113[2] = (((safe_rshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((0xDA5D0A9E49857D90LL != ((*l_288) |= ((safe_mul_func_int16_t_s_s(g_5[0], (safe_mod_func_uint64_t_u_u(p_79, (((4L < 0x52L) == g_8[1]) , g_113[2]))))) ^ 0L))), g_188)), 2)) ^ 65531UL) >= g_52)) & (-1L)))) , &l_255[0])), g_251[1])) && 0x587139D684D458F6LL), g_8[7])) , p_79), 0x4065L)), g_74[0][2])), (*g_134))) & g_15.f1) > p_79), 1L)), l_290)))) == g_251[1]), p_79)), p_79))) | 65535UL))
    { /* block id: 106 */
        union U0 *l_292 = (void*)0;
        union U0 **l_293[9][9] = {{(void*)0,&l_292,&l_292,&l_292,(void*)0,(void*)0,&l_292,&l_292,(void*)0},{&l_292,(void*)0,&l_292,&l_292,&l_292,&l_292,&l_292,&l_292,(void*)0},{(void*)0,(void*)0,(void*)0,&l_292,&l_292,&l_292,(void*)0,(void*)0,(void*)0},{&l_292,&l_292,(void*)0,(void*)0,(void*)0,&l_292,(void*)0,&l_292,(void*)0},{&l_292,(void*)0,&l_292,(void*)0,&l_292,(void*)0,(void*)0,(void*)0,&l_292},{&l_292,(void*)0,(void*)0,(void*)0,&l_292,&l_292,&l_292,(void*)0,(void*)0},{(void*)0,(void*)0,&l_292,&l_292,&l_292,&l_292,&l_292,&l_292,(void*)0},{&l_292,(void*)0,&l_292,&l_292,(void*)0,(void*)0,&l_292,&l_292,&l_292},{(void*)0,&l_292,&l_292,&l_292,&l_292,&l_292,(void*)0,&l_292,&l_292}};
        uint64_t l_299 = 0x444B370CEAD33181LL;
        int32_t l_324 = 0xBA4FA0E6L;
        uint64_t l_335 = 5UL;
        int i, j;
        l_294 = l_292;
        for (g_135 = 0; (g_135 <= 6); g_135 += 1)
        { /* block id: 110 */
            int32_t ** const *l_313 = &g_143;
            int32_t ** const ** const l_312 = &l_313;
            for (l_101 = 1; (l_101 <= 5); l_101 += 1)
            { /* block id: 113 */
                uint32_t *l_297 = (void*)0;
                uint32_t *l_298[4];
                uint8_t *l_314 = &g_256;
                int16_t *l_321 = &g_100[l_101];
                int64_t *l_322 = (void*)0;
                int64_t *l_323[10][5] = {{&g_289,&g_289,&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int i, j;
                for (i = 0; i < 4; i++)
                    l_298[i] = &l_290;
                (*l_140) = (safe_sub_func_uint32_t_u_u(9UL, ((l_299 = g_251[g_135]) & (((safe_lshift_func_uint16_t_u_u(((g_100[l_101] , (safe_mod_func_int8_t_s_s((g_188 &= (0xA1E28AA9EEEF5E0ALL || (l_324 ^= (safe_mul_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u(((safe_add_func_int8_t_s_s((safe_mul_func_int8_t_s_s(p_79, ((void*)0 == l_312))), ((*l_314) = 1UL))) ^ (safe_rshift_func_int16_t_s_u(((*l_321) &= (safe_mul_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((g_289 || p_79) < p_79) , g_251[g_135]), g_141)), g_74[2][0]))), 5))), p_79)) != 0xA6L), 0xD9B1L))))), l_325))) , g_8[5]), g_113[2])) ^ g_245) || 0xBBB2C9FAL))));
            }
            if (p_79)
                continue;
        }
        l_324 = (0x01C63E1AL | ((((l_299 & 5L) < (safe_add_func_uint64_t_u_u(((void*)0 == &g_133), (safe_lshift_func_int8_t_s_s((g_188 && (safe_mul_func_uint16_t_u_u(((((void*)0 == &g_97) & (!(safe_rshift_func_uint8_t_u_s(g_256, 0)))) ^ l_335), g_97))), 7))))) ^ 0x06CDDE3C59E35A50LL) == 6L));
    }
    else
    { /* block id: 124 */
        int32_t *l_336 = &g_8[1];
        int32_t l_338 = 0x844B1DD0L;
        g_337 = l_336;
        l_338 |= ((&g_135 != &g_135) , (p_79 , p_79));
    }
    g_337 = &g_5[1];
    return g_135;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15.f0, "g_15.f0", print_hash_value);
    transparent_crc(g_15.f1, "g_15.f1", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_74[i][j], "g_74[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_97, "g_97", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_100[i], "g_100[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_113[i], "g_113[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_245, "g_245", print_hash_value);
    transparent_crc(g_250, "g_250", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_251[i], "g_251[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_256, "g_256", print_hash_value);
    transparent_crc(g_289, "g_289", print_hash_value);
    transparent_crc(g_346, "g_346", print_hash_value);
    transparent_crc(g_354, "g_354", print_hash_value);
    transparent_crc(g_374.f1, "g_374.f1", print_hash_value);
    transparent_crc(g_390, "g_390", print_hash_value);
    transparent_crc(g_392, "g_392", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_393[i][j][k], "g_393[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_394, "g_394", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_495[i], "g_495[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_517, "g_517", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_650[i], "g_650[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_675, "g_675", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_679[i], "g_679[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_680, "g_680", print_hash_value);
    transparent_crc(g_681, "g_681", print_hash_value);
    transparent_crc(g_682, "g_682", print_hash_value);
    transparent_crc(g_717, "g_717", print_hash_value);
    transparent_crc(g_810, "g_810", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_909[i], "g_909[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_950, "g_950", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1092[i][j][k], "g_1092[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1118[i].f0, "g_1118[i].f0", print_hash_value);
        transparent_crc(g_1118[i].f1, "g_1118[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1181, "g_1181", print_hash_value);
    transparent_crc(g_1189, "g_1189", print_hash_value);
    transparent_crc(g_1468, "g_1468", print_hash_value);
    transparent_crc(g_1474, "g_1474", print_hash_value);
    transparent_crc(g_1479, "g_1479", print_hash_value);
    transparent_crc(g_1481, "g_1481", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1578[i], "g_1578[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1600[i], "g_1600[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1633, "g_1633", print_hash_value);
    transparent_crc(g_1767, "g_1767", print_hash_value);
    transparent_crc(g_1976, "g_1976", print_hash_value);
    transparent_crc(g_2192, "g_2192", print_hash_value);
    transparent_crc(g_2194, "g_2194", print_hash_value);
    transparent_crc(g_2214, "g_2214", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2271[i][j][k].f0, "g_2271[i][j][k].f0", print_hash_value);
                transparent_crc(g_2271[i][j][k].f1, "g_2271[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_2279[i][j][k], "g_2279[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2436[i], "g_2436[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2443, "g_2443", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_2445[i][j], "g_2445[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_2647[i][j][k], "g_2647[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2661, "g_2661", print_hash_value);
    transparent_crc(g_2754, "g_2754", print_hash_value);
    transparent_crc(g_3025, "g_3025", print_hash_value);
    transparent_crc(g_3087.f0, "g_3087.f0", print_hash_value);
    transparent_crc(g_3087.f1, "g_3087.f1", print_hash_value);
    transparent_crc(g_3088, "g_3088", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3338[i], "g_3338[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3350, "g_3350", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_3430[i][j], "g_3430[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3500, "g_3500", print_hash_value);
    transparent_crc(g_3572, "g_3572", print_hash_value);
    transparent_crc(g_3601, "g_3601", print_hash_value);
    transparent_crc(g_3638, "g_3638", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_3642[i][j], "g_3642[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3690[i], "g_3690[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3721, "g_3721", print_hash_value);
    transparent_crc(g_3781, "g_3781", print_hash_value);
    transparent_crc(g_3936, "g_3936", print_hash_value);
    transparent_crc(g_4094, "g_4094", print_hash_value);
    transparent_crc(g_4142, "g_4142", print_hash_value);
    transparent_crc(g_4155, "g_4155", print_hash_value);
    transparent_crc(g_4180, "g_4180", print_hash_value);
    transparent_crc(g_4205, "g_4205", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_4211[i][j], "g_4211[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4345, "g_4345", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1251
XXX total union variables: 39

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 408
   depth: 2, occurrence: 89
   depth: 3, occurrence: 7
   depth: 4, occurrence: 4
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 3
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 4
   depth: 13, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 4
   depth: 19, occurrence: 2
   depth: 20, occurrence: 6
   depth: 21, occurrence: 5
   depth: 22, occurrence: 2
   depth: 23, occurrence: 4
   depth: 24, occurrence: 8
   depth: 25, occurrence: 4
   depth: 26, occurrence: 6
   depth: 27, occurrence: 1
   depth: 28, occurrence: 4
   depth: 29, occurrence: 3
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 34, occurrence: 2
   depth: 36, occurrence: 2
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 41, occurrence: 3
   depth: 43, occurrence: 1
   depth: 44, occurrence: 1

XXX total number of pointers: 761

XXX times a variable address is taken: 1951
XXX times a pointer is dereferenced on RHS: 634
breakdown:
   depth: 1, occurrence: 501
   depth: 2, occurrence: 124
   depth: 3, occurrence: 9
XXX times a pointer is dereferenced on LHS: 582
breakdown:
   depth: 1, occurrence: 497
   depth: 2, occurrence: 71
   depth: 3, occurrence: 11
   depth: 4, occurrence: 3
XXX times a pointer is compared with null: 96
XXX times a pointer is compared with address of another variable: 20
XXX times a pointer is compared with another pointer: 28
XXX times a pointer is qualified to be dereferenced: 18399

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 5924
   level: 2, occurrence: 828
   level: 3, occurrence: 278
   level: 4, occurrence: 80
   level: 5, occurrence: 56
XXX number of pointers point to pointers: 422
XXX number of pointers point to scalars: 311
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.6
XXX average alias set size: 1.61

XXX times a non-volatile is read: 3670
XXX times a non-volatile is write: 1838
XXX times a volatile is read: 76
XXX    times read thru a pointer: 17
XXX times a volatile is write: 64
XXX    times written thru a pointer: 44
XXX times a volatile is available for access: 2.76e+03
XXX percentage of non-volatile access: 97.5

XXX forward jumps: 2
XXX backward jumps: 13

XXX stmts: 388
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 36
   depth: 1, occurrence: 36
   depth: 2, occurrence: 48
   depth: 3, occurrence: 59
   depth: 4, occurrence: 75
   depth: 5, occurrence: 134

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
********************* end of statistics **********************/

