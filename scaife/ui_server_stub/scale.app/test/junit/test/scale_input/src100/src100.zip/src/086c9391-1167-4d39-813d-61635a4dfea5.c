/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      818819474
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = (-1L);
static int32_t g_4[5] = {(-4L),(-4L),(-4L),(-4L),(-4L)};
static volatile uint16_t g_5 = 0x0BD2L;/* VOLATILE GLOBAL g_5 */
static int64_t g_12 = 1L;
static uint16_t g_28 = 0xB4B5L;
static uint8_t g_33 = 0xD4L;
static volatile int64_t g_74 = 0x83A56CF6D70783DBLL;/* VOLATILE GLOBAL g_74 */
static volatile int64_t * volatile g_73 = &g_74;/* VOLATILE GLOBAL g_73 */
static volatile int64_t * volatile *g_72 = &g_73;
static int32_t *g_81[3][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
static int64_t *g_86 = &g_12;
static int64_t **g_85 = &g_86;
static uint64_t g_93 = 4UL;
static uint16_t g_98 = 0xFBD0L;
static uint32_t g_137 = 0UL;
static int8_t g_169 = 0x28L;
static int64_t g_196 = 0L;
static uint16_t g_217 = 65535UL;
static volatile uint8_t g_222 = 0x3FL;/* VOLATILE GLOBAL g_222 */
static volatile uint8_t * volatile g_221 = &g_222;/* VOLATILE GLOBAL g_221 */
static volatile uint8_t * volatile *g_220 = &g_221;
static uint16_t *g_274[5] = {&g_98,&g_98,&g_98,&g_98,&g_98};
static uint16_t **g_273 = &g_274[2];
static const int8_t g_369 = 0xD3L;
static volatile int8_t * volatile *g_398 = (void*)0;
static int32_t g_405 = 0x8A75D22DL;
static uint8_t g_422 = 8UL;
static uint8_t *g_421 = &g_422;
static int32_t * volatile * const g_424 = (void*)0;
static int32_t * volatile * const *g_423[9][2][3] = {{{(void*)0,&g_424,&g_424},{(void*)0,(void*)0,(void*)0}},{{&g_424,&g_424,(void*)0},{&g_424,&g_424,&g_424}},{{&g_424,(void*)0,&g_424},{&g_424,&g_424,&g_424}},{{&g_424,&g_424,(void*)0},{&g_424,&g_424,(void*)0}},{{&g_424,&g_424,&g_424},{(void*)0,&g_424,&g_424}},{{&g_424,(void*)0,&g_424},{&g_424,&g_424,(void*)0}},{{&g_424,&g_424,&g_424},{&g_424,&g_424,&g_424}},{{&g_424,&g_424,&g_424},{&g_424,&g_424,&g_424}},{{&g_424,&g_424,&g_424},{&g_424,&g_424,(void*)0}}};
static int16_t g_437 = 1L;
static uint32_t g_444 = 0x44C1EC9DL;
static int32_t *g_460[3] = {&g_3,&g_3,&g_3};
static uint64_t g_488 = 0x4C0C06F63875BD31LL;
static int16_t g_570 = 0x6B22L;
static int32_t g_575 = 0x663FB059L;
static uint16_t *g_582 = (void*)0;
static uint16_t *g_583 = &g_98;
static uint16_t *g_584[8] = {&g_217,&g_217,&g_217,&g_217,&g_217,&g_217,&g_217,&g_217};
static int16_t g_646 = 4L;
static int16_t g_663 = 2L;
static int64_t g_698 = 0L;
static int32_t g_709 = (-10L);
static int64_t ***g_730 = &g_85;
static int64_t ***g_731 = &g_85;
static int16_t *g_810 = &g_646;
static int16_t **g_809 = &g_810;
static int16_t ** volatile *g_808[2] = {&g_809,&g_809};
static uint32_t g_812 = 4294967287UL;
static int32_t g_820 = (-9L);
static int32_t *g_819 = &g_820;
static const uint32_t *g_862 = &g_444;
static const uint32_t **g_861 = &g_862;
static uint32_t g_882[3][9][1] = {{{0xF968255FL},{0xDB338E6CL},{0xD94CB942L},{18446744073709551615UL},{0UL},{0UL},{18446744073709551615UL},{0xD94CB942L},{0xDB338E6CL}},{{0xF968255FL},{18446744073709551613UL},{0xF968255FL},{0xDB338E6CL},{0xD94CB942L},{18446744073709551615UL},{0UL},{0UL},{18446744073709551615UL}},{{0xD94CB942L},{0xDB338E6CL},{0xF968255FL},{18446744073709551613UL},{0xF968255FL},{0xDB338E6CL},{0xD94CB942L},{18446744073709551615UL},{0UL}}};
static int32_t ** volatile g_909 = (void*)0;/* VOLATILE GLOBAL g_909 */
static int32_t ** volatile g_910[10] = {&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0],&g_81[0][0]};
static volatile int64_t ** const * volatile * volatile * const g_996 = (void*)0;
static volatile int8_t g_1178[9][10] = {{0x4EL,0L,0xA3L,0xFAL,5L,1L,0L,0xFAL,0xFAL,0L},{0x4EL,5L,0xA3L,0xA3L,5L,0x4EL,0L,0xA3L,0xFAL,5L},{0x4EL,0L,0xA3L,0xFAL,5L,1L,0L,0xFAL,0xFAL,0L},{0x4EL,5L,0xA3L,0xA3L,5L,0x4EL,0L,0xA3L,0xFAL,5L},{0x4EL,0L,0xA3L,0xFAL,5L,1L,0L,0xFAL,0xFAL,0L},{0x4EL,5L,0xA3L,0xA3L,5L,0x4EL,0L,0xA3L,0xFAL,5L},{0x4EL,0L,0xA3L,0xFAL,5L,1L,0L,0xFAL,0xFAL,0L},{0x4EL,5L,0xA3L,0xA3L,5L,0x4EL,0L,0xA3L,0xFAL,5L},{0x4EL,0L,0xA3L,0xFAL,5L,1L,0L,0xFAL,0xFAL,0L}};
static int32_t ** volatile g_1269[7][1][4] = {{{&g_81[2][1],&g_81[2][0],(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_460[1]}},{{&g_81[2][1],&g_81[0][0],&g_81[0][0],&g_81[2][0]}},{{&g_81[0][0],&g_81[0][0],&g_460[1],&g_81[0][0]}},{{&g_460[1],&g_81[0][0],&g_81[0][0],&g_81[2][0]}},{{&g_81[0][0],&g_81[0][0],&g_81[2][1],&g_460[1]}},{{(void*)0,(void*)0,(void*)0,(void*)0}}};
static int32_t ** volatile g_1270 = (void*)0;/* VOLATILE GLOBAL g_1270 */
static int64_t ****g_1276[10][5] = {{&g_731,&g_731,&g_730,&g_731,&g_731},{&g_731,&g_731,&g_731,&g_731,&g_731},{&g_731,&g_730,&g_730,&g_731,&g_730},{&g_731,&g_731,&g_731,&g_731,&g_731},{&g_730,&g_731,&g_730,&g_730,&g_731},{&g_731,&g_731,&g_731,&g_731,&g_731},{&g_731,&g_731,&g_730,&g_731,&g_731},{&g_731,&g_731,&g_731,&g_731,&g_731},{&g_731,&g_730,&g_730,&g_731,&g_730},{&g_731,&g_731,&g_731,&g_731,&g_731}};
static int64_t *****g_1275 = &g_1276[3][0];
static int64_t *****g_1278 = &g_1276[8][2];
static uint64_t g_1321 = 0x840437023815E279LL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t * func_13(int8_t  p_14, int32_t  p_15, int32_t * const  p_16, int32_t * p_17, int32_t  p_18);
static int32_t * const  func_19(uint64_t  p_20);
static int64_t  func_34(const int64_t * p_35, int8_t  p_36);
static uint16_t  func_42(uint16_t * const  p_43, uint16_t  p_44);
static uint16_t * const  func_45(int64_t  p_46, uint16_t * p_47, uint8_t  p_48, int16_t  p_49, uint32_t  p_50);
static uint16_t * func_52(int64_t ** p_53, int16_t  p_54, int32_t * p_55, int8_t  p_56, const int32_t  p_57);
static int16_t  func_65(const int8_t  p_66, int8_t  p_67, const int64_t  p_68, int32_t * p_69);
static int32_t * func_75(int16_t  p_76, int32_t * p_77, int64_t * p_78, uint8_t * p_79, uint32_t  p_80);
static int32_t * const  func_87(const int32_t * p_88, int8_t  p_89, const int64_t * const  p_90, int64_t ** p_91, int32_t * p_92);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_3 g_28 g_12 g_33 g_72 g_85 g_369 g_422 g_437 g_460 g_421 g_575 g_273 g_274 g_584 g_217 g_98 g_488 g_86 g_137 g_663 g_169 g_196 g_698 g_709 g_808 g_809 g_810 g_646 g_812 g_819 g_820 g_405 g_93 g_444 g_861 g_862 g_73 g_74 g_882 g_221 g_222 g_731 g_730 g_220 g_996 g_398 g_1275 g_1276 g_1321
 * writes: g_5 g_12 g_28 g_33 g_81 g_460 g_437 g_169 g_405 g_575 g_582 g_583 g_217 g_3 g_98 g_137 g_444 g_422 g_646 g_196 g_730 g_731 g_698 g_709 g_488 g_663 g_812 g_93 g_820 g_570 g_861 g_1275 g_1278
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2[1][4];
    int64_t *l_11[9] = {&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12};
    int32_t l_59 = 0xE3E4F6F4L;
    int32_t *l_60 = &g_3;
    int32_t **l_1309 = &g_81[1][0];
    int32_t l_1320 = (-2L);
    int8_t *l_1322 = &g_169;
    uint64_t *l_1323 = &g_93;
    uint32_t *l_1324[9];
    uint32_t l_1325 = 0xBB4C510DL;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
            l_2[i][j] = &g_3;
    }
    for (i = 0; i < 9; i++)
        l_1324[i] = &g_137;
    ++g_5;
    if ((+(safe_mod_func_int64_t_s_s((g_12 = g_4[0]), (g_5 , g_3)))))
    { /* block id: 3 */
        uint16_t *l_27 = &g_28;
        uint8_t *l_31 = (void*)0;
        uint8_t *l_32[9] = {(void*)0,&g_33,(void*)0,&g_33,(void*)0,&g_33,(void*)0,&g_33,(void*)0};
        const int64_t **l_37 = (void*)0;
        const int64_t *l_39 = (void*)0;
        const int64_t **l_38 = &l_39;
        int32_t l_51 = (-10L);
        int64_t **l_58 = &l_11[3];
        uint32_t l_815 = 1UL;
        int8_t *l_816 = (void*)0;
        int8_t *l_817 = &g_169;
        int32_t **l_1294 = &l_2[0][2];
        int i;
        (*l_1294) = func_13(g_5, g_4[0], func_19(((safe_rshift_func_int8_t_s_u(((*l_817) = (safe_rshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u(((((((*l_27)--) >= ((g_12 & ((g_33 &= g_3) && (func_34(((*l_38) = l_11[0]), (((((safe_lshift_func_uint8_t_u_u(9UL, 5)) == func_42(func_45((l_51 <= g_3), func_52(l_58, l_59, l_60, g_4[0], g_3), l_51, g_217, (*l_60)), (*l_60))) && 0x0089E932647471D9LL) != g_488) , (-7L))) , l_815))) , l_815)) < 3L) >= g_4[0]) , (*g_421)), l_51)), 8))), l_51)) , g_4[3])), g_819, (*g_819));
        (*g_819) |= l_51;
    }
    else
    { /* block id: 520 */
        uint32_t l_1295 = 0UL;
        ++l_1295;
        (*l_60) = l_1295;
        if (g_98)
            goto lbl_1300;
    }
lbl_1300:
    (*g_819) |= (safe_div_func_int8_t_s_s(g_405, (*g_221)));
    (*g_819) |= ((***g_1275) != ((~(((((safe_mul_func_uint8_t_u_u((0x09EAL > 65535UL), (*l_60))) ^ ((((**g_273) = ((g_137 = (safe_div_func_uint64_t_u_u(((+(((l_1309 != (void*)0) ^ (((((*l_1323) = (((*l_1322) ^= (safe_mul_func_int16_t_s_s((((*l_60) , (safe_lshift_func_int8_t_s_u((*l_60), 6))) , (safe_div_func_uint32_t_u_u((safe_div_func_uint32_t_u_u((((safe_mul_func_uint16_t_u_u((*l_60), (*l_60))) | 0x7CEFD89966E84D2ALL) != l_1320), g_1321)), (*l_60)))), (**g_809)))) || g_575)) & g_28) >= 1L) != (-1L))) && 0x0EL)) < 0x16L), (***g_730)))) != (*l_60))) && 0x84EEL) && 0UL)) , g_882[0][4][0]) < 1L) >= l_1325)) , &l_11[7]));
    return (*l_60);
}


/* ------------------------------------------ */
/* 
 * reads : g_405 g_663 g_4 g_93 g_169 g_86 g_444 g_819 g_820 g_137 g_861 g_862 g_73 g_74 g_810 g_646 g_882 g_273 g_274 g_221 g_222 g_421 g_422 g_731 g_85 g_12 g_33 g_809 g_730 g_196 g_220 g_812 g_369 g_575 g_996 g_28 g_98 g_437 g_72 g_398 g_709 g_1275
 * writes: g_405 g_663 g_812 g_93 g_169 g_12 g_820 g_137 g_444 g_646 g_488 g_570 g_861 g_575 g_98 g_460 g_28 g_81 g_422 g_1275 g_1278
 */
static int32_t * func_13(int8_t  p_14, int32_t  p_15, int32_t * const  p_16, int32_t * p_17, int32_t  p_18)
{ /* block id: 349 */
    int16_t l_841 = (-1L);
    int32_t l_856 = (-1L);
    uint8_t l_879 = 0UL;
    uint64_t l_898 = 18446744073709551613UL;
    int8_t * const *l_906 = (void*)0;
    int32_t l_919 = 0x4AF578BAL;
    int32_t l_922[1];
    int32_t **l_950 = &g_81[0][0];
    int32_t l_959 = 0x8EF62472L;
    uint32_t *l_977 = &g_882[2][6][0];
    uint16_t *l_989 = &g_28;
    const int64_t l_1017[5] = {0x99B1F2823EF159E4LL,0x99B1F2823EF159E4LL,0x99B1F2823EF159E4LL,0x99B1F2823EF159E4LL,0x99B1F2823EF159E4LL};
    int32_t l_1024 = 0x97CD24C3L;
    uint16_t l_1135 = 65527UL;
    int32_t l_1160 = 0x98D21CF8L;
    int16_t l_1168 = 1L;
    uint32_t *l_1284[5][9][5] = {{{(void*)0,&g_137,&g_812,&g_812,&g_444},{&g_444,(void*)0,&g_812,(void*)0,&g_812},{&g_812,&g_812,&g_444,&g_137,&g_812},{&g_444,&g_137,&g_137,&g_812,&g_137},{(void*)0,(void*)0,&g_812,&g_812,&g_137},{&g_137,&g_444,&g_137,&g_137,(void*)0},{&g_812,&g_812,&g_812,(void*)0,&g_812},{(void*)0,&g_444,&g_444,&g_812,&g_812},{&g_137,(void*)0,&g_137,&g_812,&g_812}},{{&g_812,&g_137,&g_444,&g_812,&g_812},{&g_444,&g_812,&g_444,&g_812,(void*)0},{&g_137,(void*)0,&g_444,&g_812,&g_137},{&g_812,&g_137,&g_137,&g_812,&g_137},{&g_812,&g_812,&g_444,(void*)0,&g_812},{&g_137,&g_444,&g_812,&g_444,&g_812},{&g_444,&g_137,&g_137,(void*)0,&g_444},{&g_812,&g_812,&g_812,&g_812,&g_812},{&g_137,&g_812,&g_137,&g_812,(void*)0}},{{(void*)0,&g_137,&g_444,&g_812,&g_137},{&g_812,&g_444,&g_812,&g_812,(void*)0},{&g_137,&g_812,&g_812,&g_812,&g_812},{(void*)0,&g_137,&g_812,&g_812,&g_444},{&g_444,(void*)0,&g_812,(void*)0,&g_812},{&g_812,&g_137,&g_444,&g_812,&g_812},{&g_812,&g_812,&g_137,&g_812,&g_137},{&g_137,&g_137,(void*)0,&g_812,&g_137},{&g_812,&g_812,&g_444,&g_812,&g_137}},{{&g_137,&g_444,&g_812,&g_444,&g_444},{&g_137,&g_812,&g_812,&g_137,&g_137},{&g_444,&g_137,&g_444,&g_812,&g_137},{&g_812,&g_812,&g_444,&g_137,&g_444},{&g_812,&g_137,&g_137,&g_812,&g_137},{&g_137,&g_137,&g_444,&g_444,&g_137},{&g_137,&g_444,&g_444,&g_137,&g_137},{&g_137,&g_812,&g_812,&g_444,&g_812},{&g_137,&g_812,&g_812,&g_444,&g_137}},{{&g_812,&g_137,&g_444,&g_444,&g_444},{&g_812,&g_137,(void*)0,&g_137,&g_812},{&g_444,&g_137,&g_137,&g_444,&g_137},{&g_137,&g_137,&g_444,&g_812,&g_137},{&g_137,&g_812,&g_812,&g_137,&g_137},{&g_812,&g_812,&g_812,&g_812,&g_812},{&g_137,&g_444,&g_812,&g_137,&g_444},{&g_812,&g_137,&g_812,&g_444,&g_137},{&g_444,&g_137,&g_444,&g_812,&g_812}}};
    int32_t *l_1285 = &l_856;
    int32_t *l_1286[10][4] = {{&g_575,(void*)0,(void*)0,&g_575},{&g_405,&l_919,&l_856,&l_1160},{&g_820,&l_856,&l_1160,(void*)0},{&l_1160,(void*)0,&l_922[0],(void*)0},{(void*)0,&l_856,&g_575,&l_1160},{(void*)0,&l_919,(void*)0,&g_575},{&g_575,(void*)0,&l_919,&l_919},{&g_575,&g_575,(void*)0,&g_405},{(void*)0,&l_919,&g_575,&l_919},{(void*)0,&g_820,&l_922[0],&g_575}};
    int32_t *l_1287[7];
    int32_t *l_1288 = &l_922[0];
    int32_t *l_1289 = &l_922[0];
    int32_t *l_1290 = &l_919;
    int32_t *l_1291[10] = {&l_1160,&l_1160,&l_1160,&l_1160,&l_1160,&l_1160,&l_1160,&l_1160,&l_1160,&l_1160};
    int32_t *l_1292 = &l_919;
    int32_t *l_1293 = &g_3;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_922[i] = (-2L);
    for (i = 0; i < 7; i++)
        l_1287[i] = &l_919;
lbl_1041:
    for (g_405 = 4; (g_405 >= 0); g_405 -= 1)
    { /* block id: 352 */
        int32_t *l_842 = (void*)0;
        for (g_663 = 4; (g_663 >= 0); g_663 -= 1)
        { /* block id: 355 */
            uint32_t *l_831[9];
            uint16_t l_832 = 0x7F25L;
            uint64_t *l_833 = &g_93;
            int8_t *l_837 = (void*)0;
            int8_t *l_838 = (void*)0;
            int8_t *l_839 = (void*)0;
            int8_t *l_840 = &g_169;
            int i;
            for (i = 0; i < 9; i++)
                l_831[i] = (void*)0;
            (*g_819) |= (((*g_86) = (((safe_mod_func_int64_t_s_s((safe_add_func_int16_t_s_s((g_4[g_663] != (0UL < 0x828B32DBL)), (safe_mul_func_int8_t_s_s(((*l_840) ^= (((safe_lshift_func_int8_t_s_u(0x80L, 3)) , 0xC06F1681L) || (((safe_lshift_func_int8_t_s_u(((g_812 = g_4[g_663]) < (((*l_833) |= l_832) , (!(safe_div_func_int64_t_s_s(l_832, l_832))))), 5)) && 0x6A20305BL) ^ (-1L)))), 247UL)))), p_18)) & l_841) | l_841)) || g_444);
        }
        for (l_841 = 0; (l_841 <= 2); l_841 += 1)
        { /* block id: 364 */
            int i;
            return l_842;
        }
    }
lbl_843:
    for (g_137 = 0; (g_137 <= 1); g_137 += 1)
    { /* block id: 370 */
        return &g_3;
    }
    if (((*p_17) ^= l_841))
    { /* block id: 374 */
        uint8_t *l_852 = &g_422;
        const uint32_t *l_860 = &g_137;
        const uint32_t **l_859[1];
        int32_t l_881[10] = {0xD729A3A9L,0xD729A3A9L,0x1DE60941L,0xD729A3A9L,0xD729A3A9L,0x1DE60941L,0xD729A3A9L,0xD729A3A9L,0x1DE60941L,0xD729A3A9L};
        int8_t *l_905 = &g_169;
        int8_t **l_904 = &l_905;
        int32_t l_915 = 0xF9E11AAEL;
        int i;
        for (i = 0; i < 1; i++)
            l_859[i] = &l_860;
        if (g_137)
            goto lbl_843;
        for (g_444 = 21; (g_444 < 1); --g_444)
        { /* block id: 378 */
            int8_t l_851 = 1L;
            int16_t l_853 = 0x36D2L;
            int32_t l_880 = (-5L);
            int32_t l_918 = 0x4117AB19L;
            for (g_169 = 0; (g_169 <= (-30)); --g_169)
            { /* block id: 381 */
                int8_t l_850 = 1L;
                for (g_646 = 5; (g_646 >= 13); g_646 = safe_add_func_int64_t_s_s(g_646, 7))
                { /* block id: 384 */
                    l_851 &= l_850;
                }
            }
            l_853 = ((void*)0 != l_852);
            if ((*g_819))
                continue;
            for (g_488 = (-18); (g_488 >= 60); g_488 = safe_add_func_int16_t_s_s(g_488, 1))
            { /* block id: 392 */
                const int32_t l_867 = 0xBE68635FL;
                int32_t l_916 = 0L;
                int32_t l_917 = (-1L);
                int32_t l_921 = 0xA25E5587L;
                uint64_t l_923 = 0x960D806B09844CC3LL;
                int16_t ***l_926 = &g_809;
                l_856 ^= 0x42179B61L;
                for (g_570 = (-9); (g_570 != (-23)); --g_570)
                { /* block id: 396 */
                    uint16_t l_872 = 1UL;
                    int64_t ****l_876 = &g_730;
                    int64_t *****l_875 = &l_876;
                    int32_t l_920[6][6] = {{0L,(-1L),0xDE5B2ACCL,(-1L),0L,0L},{0x7D3AB46CL,(-1L),(-1L),0x7D3AB46CL,3L,0x7D3AB46CL},{0x7D3AB46CL,3L,0x7D3AB46CL,(-1L),(-1L),0x7D3AB46CL},{0L,0L,(-1L),0xDE5B2ACCL,0x7D3AB46CL,(-1L)},{0x7D3AB46CL,0L,3L,3L,0L,0x7D3AB46CL},{(-1L),0x7D3AB46CL,3L,0x7D3AB46CL,(-1L),(-1L)}};
                    int i, j;
                    for (g_169 = 1; (g_169 >= 0); g_169 -= 1)
                    { /* block id: 399 */
                        g_861 = l_859[0];
                    }
                    if ((((safe_mod_func_int64_t_s_s((safe_div_func_uint8_t_u_u((((l_880 &= ((**g_861) > (l_867 >= ((((p_14 | (((safe_sub_func_uint8_t_u_u((((((((safe_sub_func_uint32_t_u_u((l_872 , (*g_862)), (((0xD0BD82C8L & (safe_add_func_int64_t_s_s(((&g_730 != ((*l_875) = (void*)0)) , (safe_add_func_int32_t_s_s(((*p_16) = 0x7C7C6DE0L), 0xF6562723L))), (*g_73)))) ^ 0xB2EDC00AL) | 65535UL))) != (*g_810)) <= g_137) < 0x0F48F41629DA3E89LL) , 0x9BL) != l_867) ^ l_872), g_4[0])) > 0UL) , p_15)) || p_15) <= l_879) , p_15)))) & l_881[7]) <= 0x04795C6C9D9DA2DALL), l_881[7])), g_882[2][6][0])) <= 18446744073709551606UL) == 0x279A67F6L))
                    { /* block id: 405 */
                        uint16_t *l_907 = (void*)0;
                        uint16_t *l_908 = &l_872;
                        (*p_17) &= (((safe_lshift_func_int16_t_s_u((safe_sub_func_int8_t_s_s(l_853, (safe_mod_func_uint8_t_u_u(((safe_unary_minus_func_uint64_t_u((safe_add_func_uint8_t_u_u((+(+((safe_mod_func_int8_t_s_s(((l_898 , (0x2BL || ((~0xE69ECB0FC65E48AFLL) , (safe_rshift_func_int8_t_s_u((safe_mul_func_uint16_t_u_u(0xBA61L, l_879)), 7))))) >= ((l_904 != l_906) != (l_881[0] = ((*l_908) = ((**g_273) = (0xD44A8A48L ^ 0L)))))), p_18)) | p_15))), (-1L))))) < (*g_221)), (*g_421))))), p_15)) >= p_18) ^ 0x3242L);
                    }
                    else
                    { /* block id: 410 */
                        int32_t **l_911 = &g_460[2];
                        int32_t *l_912 = &l_881[7];
                        int32_t *l_913 = &g_709;
                        int32_t *l_914[6] = {&g_709,&g_709,&g_709,&g_709,&g_709,&g_709};
                        int i;
                        (*l_911) = &p_18;
                        --l_923;
                        (*l_912) = (*p_17);
                        if (l_917)
                            break;
                    }
                }
                (*p_16) = (l_926 == &g_809);
                for (l_917 = 16; (l_917 < (-5)); l_917 = safe_sub_func_uint32_t_u_u(l_917, 5))
                { /* block id: 420 */
                    uint64_t *l_943 = &g_93;
                    uint64_t *l_949 = (void*)0;
                    uint64_t **l_948 = &l_949;
                    (*p_17) = (safe_div_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((((safe_add_func_uint8_t_u_u(((((safe_rshift_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u((safe_div_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u(((*l_943) = g_663), ((***g_731) || (safe_add_func_uint64_t_u_u((g_33 , ((safe_rshift_func_uint16_t_u_s((&l_923 != ((*l_948) = (void*)0)), 5)) , (l_950 != (((((*p_16) = (((g_405 < ((***g_730) = (p_15 ^ (~((**l_904) |= (safe_rshift_func_int8_t_s_u((((***l_926) |= (((safe_unary_minus_func_int16_t_s((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((l_917 && 8UL), p_15)), 14)))) > 0UL) != l_881[5])) <= 1UL), 4))))))) && l_881[7]) != l_853)) == l_881[2]) || l_959) , (void*)0)))), 0xA8E9280190C4685FLL))))) && 0L), (**g_861))), p_18)) && 0x68L), p_15)) <= p_14) || (-1L)) , 0xD3L), p_15)) , l_881[7]) , l_950) == l_950), (*g_221))), 0xEAE5L));
                }
            }
        }
    }
    else
    { /* block id: 431 */
        uint16_t l_967 = 0xA40DL;
        uint32_t * const l_976[2] = {&g_882[2][6][0],&g_882[2][6][0]};
        int32_t l_986 = 0xE3D0E777L;
        uint32_t *l_987 = &g_812;
        uint64_t l_1011 = 1UL;
        uint8_t l_1023 = 0x8BL;
        int32_t l_1034 = (-1L);
        uint16_t l_1070 = 1UL;
        int32_t l_1111 = 0x58C31061L;
        int32_t l_1112 = (-5L);
        int32_t l_1117 = (-2L);
        int32_t l_1118 = 0L;
        int32_t l_1170 = 0x4F77D6D2L;
        int32_t l_1171 = 0x7C088EE0L;
        int32_t l_1172 = 0x144CBD6AL;
        int32_t l_1174 = 0x8DB68B95L;
        int32_t l_1175 = (-4L);
        int32_t l_1176 = 0xC2994514L;
        int32_t l_1177[2][9] = {{0x1846268EL,0x1846268EL,0x70746C47L,0x1846268EL,0x1846268EL,0x70746C47L,0x1846268EL,0x1846268EL,0x70746C47L},{0x1846268EL,0x1846268EL,0x70746C47L,0x1846268EL,0x1846268EL,0x70746C47L,0x1846268EL,0x1846268EL,0x70746C47L}};
        int32_t l_1259 = (-6L);
        int64_t ******l_1277[10] = {&g_1275,(void*)0,&g_1275,&g_1275,&g_1275,&g_1275,(void*)0,&g_1275,&g_1275,&g_1275};
        int32_t ** const l_1279 = &g_819;
        int8_t *l_1280[9] = {&g_169,&g_169,&g_169,&g_169,&g_169,&g_169,&g_169,&g_169,&g_169};
        int i, j;
        if (((((safe_lshift_func_int16_t_s_u((((((safe_rshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u(p_18, (~(l_967 ^= g_93)))), (p_18 || (*g_810)))) && (safe_lshift_func_int16_t_s_s((((safe_add_func_uint16_t_u_u((7UL == ((*l_987) ^= ((safe_rshift_func_uint16_t_u_s(((((**g_809) = (safe_mul_func_int16_t_s_s((l_976[0] != l_977), ((((((safe_lshift_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(((((~((~((safe_lshift_func_int8_t_s_u(0x1EL, 1)) == ((-10L) > p_14))) | l_967)) | l_922[0]) | g_196) , 248UL), p_15)), 7)) < 0UL) == 0xB194D17CL) || l_967) == (**g_220)) | (*g_862))))) ^ (-1L)) < l_986), p_14)) , 0x3262CE1AL))), 0UL)) & g_882[2][6][0]) || g_369), l_967))) , (*g_273)) == (void*)0) <= 0x65L), 11)) , (*p_16)) != (*p_17)) || p_14))
        { /* block id: 435 */
            int32_t *l_988 = &l_922[0];
            return l_987;
        }
        else
        { /* block id: 437 */
            const int64_t l_1001 = 0x7027CBDA3BCAEB8BLL;
            const uint64_t l_1016[5][1] = {{0x56BC447BE39E42BCLL},{0x6173724286B1D4BELL},{0x56BC447BE39E42BCLL},{0x6173724286B1D4BELL},{0x56BC447BE39E42BCLL}};
            uint64_t l_1025 = 0x676CC0BB72D974ECLL;
            int32_t l_1071[8] = {(-1L),(-1L),0xD4F0A643L,(-1L),(-1L),0xD4F0A643L,(-1L),(-1L)};
            uint8_t l_1086 = 0x1AL;
            int32_t l_1165 = 0xEA9D6D09L;
            uint8_t **l_1194 = &g_421;
            uint8_t ***l_1193 = &l_1194;
            int32_t *l_1205 = (void*)0;
            uint32_t l_1263 = 4294967295UL;
            int i, j;
            (*p_16) = (l_989 == (void*)0);
            if ((safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_u(((safe_rshift_func_int8_t_s_u(((void*)0 != g_996), 5)) | (safe_sub_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s(l_1001, 11)) | (safe_mod_func_int8_t_s_s((~((*g_862) , (safe_sub_func_int16_t_s_s((safe_sub_func_int8_t_s_s((safe_div_func_int16_t_s_s(l_1011, (0x0064L & ((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s((l_1016[4][0] | ((l_1017[2] >= ((*g_819) = ((safe_rshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s(((*l_989) ^= (+l_1023)), p_14)), l_1001)) , l_1024))) > l_1025)), p_15)) && (**g_861)), (**g_273))) != 0xEEL)))), 4L)), 0UL)))), p_15))), (*p_16)))), 1)), (*g_810))))
            { /* block id: 441 */
                int16_t l_1026 = 1L;
                int32_t l_1039[8][8] = {{0x6CB324BDL,0xCEC43963L,0x496C8724L,0x496C8724L,0xCEC43963L,0x6CB324BDL,0x496C8724L,0L},{0xCEC43963L,0x6CB324BDL,0x496C8724L,0L,0x6CB324BDL,0x6CB324BDL,0L,0x496C8724L},{0xCEC43963L,0xCEC43963L,1L,0L,0xCEC43963L,(-1L),0L,0L},{0x6CB324BDL,0xCEC43963L,0x496C8724L,0x496C8724L,0xCEC43963L,0x6CB324BDL,0x496C8724L,0L},{0xCEC43963L,0x6CB324BDL,0x496C8724L,0L,0x6CB324BDL,0x6CB324BDL,0L,0x496C8724L},{0xCEC43963L,0xCEC43963L,1L,0L,0xCEC43963L,(-1L),0L,0L},{0x6CB324BDL,0xCEC43963L,0x496C8724L,0x496C8724L,0xCEC43963L,0x6CB324BDL,0x496C8724L,0L},{0xCEC43963L,0x6CB324BDL,0x496C8724L,0L,0x6CB324BDL,0x6CB324BDL,0L,0x496C8724L}};
                int i, j;
                if (l_1026)
                { /* block id: 442 */
                    int16_t *l_1033[6][4] = {{&g_437,&g_437,&g_663,&g_663},{&g_437,&g_437,&g_663,&g_663},{&g_437,&g_437,&g_663,&g_663},{&g_437,&g_437,&g_663,&g_663},{&g_437,&g_437,&g_663,&g_663},{&g_437,&g_437,&g_663,&g_663}};
                    int32_t l_1040 = 5L;
                    int i, j;
                    (*g_819) = ((safe_sub_func_uint32_t_u_u((l_1026 >= (**g_809)), (0x98L == (safe_unary_minus_func_int16_t_s((safe_unary_minus_func_uint8_t_u((safe_sub_func_uint64_t_u_u((l_1025 && ((l_1034 = 0x122CL) < l_1016[3][0])), (l_1039[4][6] = (safe_mul_func_int16_t_s_s(1L, ((safe_add_func_int64_t_s_s(((***g_731) = 0x817621A2747070AELL), p_14)) != p_14))))))))))))) && l_1040);
                    if (l_986)
                        goto lbl_1041;
                }
                else
                { /* block id: 448 */
                    int32_t *l_1042 = &g_405;
                    return l_1042;
                }
            }
            else
            { /* block id: 451 */
                uint8_t l_1056 = 0xA6L;
                uint64_t *l_1066 = &l_898;
                uint64_t *l_1067 = (void*)0;
                uint64_t *l_1068 = &g_488;
                int8_t *l_1069[7];
                int32_t l_1084[4][4] = {{(-8L),0x38E276BFL,(-8L),(-8L)},{(-1L),0xA52F5619L,(-8L),(-8L)},{0x38E276BFL,0x38E276BFL,0xFBB05F74L,0xA52F5619L},{0xA52F5619L,(-1L),0xFBB05F74L,(-1L)}};
                int64_t l_1102[3][10] = {{0L,0x91A381C96101F741LL,0xC8DA15DF5E062E79LL,0x91A381C96101F741LL,0L,0x7C347FCFC32A2638LL,(-7L),(-9L),(-9L),(-7L)},{0x39871F76C878F861LL,0x7C347FCFC32A2638LL,0x7EBE942FE7C2516DLL,0x7EBE942FE7C2516DLL,0x7C347FCFC32A2638LL,0xC8DA15DF5E062E79LL,(-1L),(-9L),0x39871F76C878F861LL,(-9L)},{1L,(-7L),0x39871F76C878F861LL,0x91A381C96101F741LL,0x39871F76C878F861LL,(-7L),1L,(-1L),0L,0L}};
                int32_t l_1173 = 0L;
                int i, j;
                for (i = 0; i < 7; i++)
                    l_1069[i] = &g_169;
                if ((safe_lshift_func_int16_t_s_s((((+(((((*l_987) ^= (safe_sub_func_int8_t_s_s((g_169 = (safe_div_func_uint8_t_u_u((((safe_sub_func_int64_t_s_s((18446744073709551614UL <= ((safe_mul_func_int16_t_s_s(((0x6EL > (*g_421)) & ((((safe_sub_func_int8_t_s_s(l_1056, (((((safe_mul_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s((safe_add_func_uint64_t_u_u((safe_add_func_int64_t_s_s(p_15, ((-9L) < (**g_861)))), (safe_unary_minus_func_uint16_t_u(((*p_16) && (((*l_1068) = ((*l_1066) = p_18)) != 0xD00FA404138E6BFALL)))))), 1)), 0x05F6L)) , 1L) >= 1L) , l_986) & 0xD4L))) == 0xEDA799D2A1CBEB2ALL) >= l_1016[4][0]) , (***g_730))), 65535UL)) && (**g_273))), (-1L))) != p_15) || g_98), p_15))), l_1011))) && 0xB55387EAL) <= g_437) , l_1070)) , l_1056) <= 0x38129281L), 4)))
                { /* block id: 456 */
                    uint8_t l_1081[6][10];
                    int32_t l_1085 = 0xA389EFD2L;
                    int32_t l_1113 = 0xFEB18299L;
                    int32_t l_1114 = 0x38E7DA0BL;
                    int32_t l_1115 = 0x7BE3FC4CL;
                    int32_t l_1116 = (-1L);
                    int32_t l_1119 = 1L;
                    uint8_t l_1120 = 255UL;
                    int32_t *l_1159 = &g_405;
                    int32_t l_1166 = (-1L);
                    int32_t l_1167 = 0x2FF27999L;
                    int32_t l_1169[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                    int32_t *l_1182 = (void*)0;
                    int i, j;
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_1081[i][j] = 255UL;
                    }
                    if ((*p_17))
                    { /* block id: 457 */
                        int32_t *l_1072 = &l_922[0];
                        int32_t *l_1073 = &l_1071[0];
                        int32_t *l_1074 = &l_856;
                        int32_t *l_1075 = &g_709;
                        int32_t *l_1076 = &l_922[0];
                        int32_t *l_1077 = &l_1071[0];
                        int32_t *l_1078 = &g_405;
                        int32_t *l_1079 = &g_3;
                        int32_t *l_1080[2][5] = {{&l_856,&l_856,&l_856,&l_856,&l_856},{&l_922[0],&l_856,&l_922[0],&l_922[0],&l_856}};
                        int i, j;
                        l_1081[4][9]++;
                        l_1086++;
                        (*l_950) = func_75((p_18 , (safe_add_func_int64_t_s_s((**g_72), (safe_lshift_func_uint16_t_u_u(p_15, (g_812 | (!((safe_sub_func_uint32_t_u_u(((void*)0 != (*g_861)), (((((*g_421) <= (safe_mod_func_uint8_t_u_u(p_15, (safe_sub_func_int32_t_s_s((safe_add_func_uint32_t_u_u((p_18 , 4294967289UL), 0x19FD83D9L)), l_1102[0][6]))))) ^ (*g_86)) || g_663) == l_1081[4][4]))) ^ l_1071[1])))))))), &l_1085, (*g_85), &l_1086, p_18);
                    }
                    else
                    { /* block id: 461 */
                        uint32_t l_1103 = 0x82425D7FL;
                        int32_t *l_1106 = (void*)0;
                        int32_t *l_1107 = (void*)0;
                        int32_t *l_1108 = &l_1085;
                        int32_t *l_1109 = (void*)0;
                        int32_t *l_1110[3][9][7] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1085,&l_922[0],&g_575,&l_919,&g_575,&l_922[0],&l_1085},{&l_856,(void*)0,(void*)0,(void*)0,&l_856,&l_856,(void*)0},{(void*)0,(void*)0,(void*)0,&l_1071[0],&g_575,&l_1084[2][2],&l_856},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_1071[0],&g_575,&l_1084[2][2],&l_856,&l_1084[2][2],&g_575},{&l_856,&l_856,(void*)0,(void*)0,(void*)0,&l_856,&l_856},{&l_1085,&l_1071[0],&l_919,&l_1071[0],&l_1085,&l_922[0],&g_575},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_575,(void*)0,&l_919,&l_919,&l_856,&l_1071[0],&l_856},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1085,&l_922[0],&g_575,&l_919,&g_575,&l_922[0],&l_1085},{&l_856,(void*)0,(void*)0,(void*)0,&l_856,&l_856,(void*)0},{(void*)0,(void*)0,(void*)0,&l_1071[0],&g_575,&l_1084[2][2],&l_856},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_1071[0],&g_575,&l_1084[2][2],&l_856,&l_1084[2][2],&g_575},{&l_856,&l_856,(void*)0,(void*)0,(void*)0,&l_856,&l_856},{&l_1085,&l_1071[0],&l_919,&l_1071[0],&l_1085,&l_922[0],&g_575}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_575,(void*)0,&l_919,&l_919,&l_856,&l_1071[0],&l_856},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1085,&l_922[0],&g_575,&l_919,&g_575,&l_922[0],&l_1085},{&l_856,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_919,&l_922[0],&l_919,&l_1084[2][2],(void*)0,&l_919,&l_1085},{(void*)0,&l_856,(void*)0,(void*)0,&l_856,(void*)0,&l_856},{&l_919,&l_1084[2][2],(void*)0,&l_919,&l_1085,&l_919,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
                        int i, j, k;
                        (*l_950) = &p_18;
                        l_1103--;
                        (*l_950) = (p_15 , &p_18);
                        --l_1120;
                    }
                    for (l_1120 = 0; (l_1120 <= 4); l_1120 += 1)
                    { /* block id: 469 */
                        int32_t *l_1123 = &l_922[0];
                        int32_t *l_1124 = (void*)0;
                        int32_t *l_1125 = &l_1034;
                        int32_t *l_1126 = (void*)0;
                        int32_t *l_1127 = &g_405;
                        int32_t *l_1128 = &g_575;
                        int32_t *l_1129 = &l_922[0];
                        int32_t *l_1130 = (void*)0;
                        int32_t *l_1131 = &l_1112;
                        int32_t *l_1132 = (void*)0;
                        int32_t *l_1133 = (void*)0;
                        int32_t *l_1134[7][8] = {{&l_919,&g_405,&g_575,&l_1112,&g_820,&l_1112,&g_575,&g_405},{&l_919,&l_1116,(void*)0,&l_919,&g_575,&l_1114,&l_1118,&g_405},{&l_1118,&l_1085,&l_919,&l_1112,&l_919,&l_1085,&l_1118,&l_1116},{&l_1084[3][0],&l_1112,(void*)0,&l_1114,(void*)0,&l_1085,&g_575,&l_1085},{(void*)0,&l_1085,&g_575,&l_1085,(void*)0,&l_1114,(void*)0,&l_1112},{&l_1084[3][0],&l_1116,&l_1118,&l_1085,&l_919,&l_1112,&l_919,&l_1085},{&l_1118,&g_405,&l_1118,&l_1114,&g_575,&l_919,(void*)0,&l_1116}};
                        int i, j;
                        l_1135++;
                    }
                    if (((((safe_mul_func_uint16_t_u_u(8UL, (safe_div_func_uint16_t_u_u((l_1112 = l_1102[1][6]), ((((~((*l_1159) = ((*p_17) = (safe_mul_func_int8_t_s_s((((((((safe_sub_func_int32_t_s_s(((*g_220) == (void*)0), ((*p_16) = (*p_17)))) , (safe_mul_func_uint8_t_u_u((((safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_u(((g_169 ^= 0xD5L) || 0x85L), 0)), (safe_add_func_uint32_t_u_u((safe_add_func_uint8_t_u_u(((*g_421)--), ((g_398 == g_398) , p_14))), (*p_17))))) >= l_1120) == l_1016[4][0]), 0x2CL))) | 0xF6L) == 0x2537L) < (**g_809)) , 0xF5128FA7L) >= p_18), l_1102[0][6]))))) & 0xD5DFL) < (-10L)) && 65531UL))))) && p_14) && l_1160) | 0UL))
                    { /* block id: 478 */
                        int32_t *l_1161 = &l_1034;
                        int32_t *l_1162 = &l_1115;
                        int32_t *l_1163[3];
                        int8_t l_1164 = 0L;
                        uint64_t l_1179 = 18446744073709551613UL;
                        int16_t *l_1191 = (void*)0;
                        int16_t *l_1192[9][2] = {{&g_570,&l_841},{&g_646,&l_841},{&g_570,&l_841},{&g_646,&l_841},{&g_570,&l_841},{&g_646,&l_841},{&g_570,&l_841},{&g_646,&l_841},{&g_570,&l_841}};
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_1163[i] = &l_1071[6];
                        ++l_1179;
                        (*l_950) = l_1182;
                        p_17 = func_75((**g_809), func_75(p_18, func_75((l_1084[1][1] = (safe_sub_func_int32_t_s_s((l_1070 != (safe_rshift_func_int16_t_s_u((**g_809), 3))), ((*l_1162) = ((safe_unary_minus_func_uint16_t_u(((safe_unary_minus_func_int32_t_s(((((l_919 |= (safe_rshift_func_uint16_t_u_u(1UL, 14))) , l_1193) != (void*)0) & (safe_sub_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_s(0x09C1L, (safe_mul_func_int8_t_s_s((safe_add_func_int16_t_s_s(p_14, p_15)), l_1170)))), (**g_861))) != p_14), g_882[1][0][0]))))) == 65530UL))) && 0xB710EB4927E6ACE4LL))))), l_1205, (*g_85), &g_33, p_14), &l_1102[1][0], &l_1023, g_4[1]), (*g_85), &l_879, g_369);
                    }
                    else
                    { /* block id: 485 */
                        uint32_t l_1222 = 0x3CF658B2L;
                        int32_t *l_1225 = (void*)0;
                        int32_t *l_1226 = &l_1071[2];
                        int32_t *l_1227 = &l_922[0];
                        int32_t *l_1228 = &l_1119;
                        int32_t *l_1229 = &l_1071[6];
                        int32_t *l_1230 = &l_1114;
                        int32_t *l_1231 = (void*)0;
                        int32_t *l_1232 = &l_1169[6];
                        int32_t *l_1233 = &l_1170;
                        int32_t *l_1234 = &l_922[0];
                        int32_t *l_1235 = &l_1166;
                        int32_t *l_1236 = &l_1085;
                        int32_t *l_1237 = &l_1170;
                        int32_t *l_1238 = (void*)0;
                        int32_t *l_1239 = &l_1169[6];
                        int32_t *l_1240 = &l_919;
                        int32_t *l_1241 = &l_1113;
                        int32_t *l_1242 = &l_1084[1][1];
                        int32_t *l_1243 = &l_1169[2];
                        int32_t *l_1244 = &l_1112;
                        int32_t *l_1245 = &l_922[0];
                        int32_t l_1246 = 0L;
                        int32_t *l_1247[4][3];
                        uint8_t l_1248[7][10] = {{249UL,2UL,0x9AL,2UL,249UL,0xA1L,249UL,2UL,0x9AL,2UL},{0x65L,246UL,0xF5L,2UL,0xF5L,246UL,0x65L,246UL,0xF5L,2UL},{255UL,2UL,255UL,246UL,249UL,246UL,255UL,2UL,255UL,246UL},{0x65L,2UL,0x82L,2UL,0x65L,0xA1L,0x65L,2UL,0x82L,2UL},{249UL,246UL,255UL,2UL,255UL,246UL,249UL,246UL,255UL,2UL},{0xF5L,2UL,0xF5L,246UL,0x65L,246UL,0xF5L,2UL,0xF5L,246UL},{249UL,2UL,0x9AL,2UL,249UL,0xA1L,249UL,2UL,0x9AL,2UL}};
                        int i, j;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_1247[i][j] = (void*)0;
                        }
                        l_1171 = (safe_mul_func_uint16_t_u_u((safe_add_func_int64_t_s_s((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_s(((((*p_16) |= ((safe_mul_func_int8_t_s_s(((void*)0 == &l_1025), (safe_lshift_func_int16_t_s_u(p_18, p_14)))) | (safe_rshift_func_int8_t_s_u(0L, p_18)))) || 1UL) || p_18), 2)), ((safe_rshift_func_uint8_t_u_s(((*g_421) != (*g_421)), 2)) == 0x72B0L))), g_663)), 0UL));
                        --l_1222;
                        ++l_1248[1][2];
                    }
                    (*g_819) = (*p_16);
                }
                else
                { /* block id: 492 */
                    l_1084[1][1] ^= 0L;
                }
            }
            if (((+(~(7UL >= ((((safe_add_func_uint64_t_u_u((((void*)0 == l_906) != (p_15 , (safe_add_func_uint64_t_u_u(g_33, 0x1F8F5C61A397FAC1LL)))), (g_882[0][5][0] ^ (*g_421)))) || ((*g_220) == &l_1023)) , 1UL) == p_15)))) ^ 0x89DAC069L))
            { /* block id: 496 */
                (*g_819) &= (-1L);
            }
            else
            { /* block id: 498 */
                int32_t *l_1257 = &g_820;
                int32_t *l_1258 = &l_1112;
                int32_t *l_1260 = &l_1118;
                int32_t *l_1261 = &l_1118;
                int32_t *l_1262[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int i;
                --l_1263;
            }
            for (l_1160 = (-4); (l_1160 <= (-3)); l_1160++)
            { /* block id: 503 */
                int32_t **l_1268 = (void*)0;
                p_17 = func_19(g_709);
            }
        }
        (*p_16) = ((((-2L) && ((safe_rshift_func_int8_t_s_u(((safe_sub_func_uint32_t_u_u(l_1070, ((g_1275 = g_1275) != (g_1278 = &g_1276[3][0])))) != (-1L)), (((***g_730) ^= ((-1L) >= (p_14 = (l_1279 != l_950)))) , ((((***g_731) = (safe_mod_func_int32_t_s_s(((*g_819) = ((((1L && 1UL) , (*g_221)) < p_14) , (*p_16))), 0x58A7688EL))) , 0xA53062571C16A587LL) & p_14)))) && (*g_221))) < 0UL) , (-1L));
    }
    (*g_819) &= (0x2D9E19C1L & (~(g_812 = (*g_862))));
    return l_1293;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * const  func_19(uint64_t  p_20)
{ /* block id: 347 */
    int32_t * const l_818 = &g_575;
    return l_818;
}


/* ------------------------------------------ */
/* 
 * reads : g_217 g_86 g_12 g_421 g_422 g_575 g_137 g_85 g_273 g_274 g_98 g_663 g_169 g_196 g_698 g_33 g_369 g_4 g_709 g_488 g_437 g_808 g_809 g_810 g_646 g_812
 * writes: g_217 g_3 g_98 g_137 g_575 g_460 g_444 g_81 g_422 g_646 g_196 g_169 g_33 g_730 g_731 g_698 g_709 g_488 g_663
 */
static int64_t  func_34(const int64_t * p_35, int8_t  p_36)
{ /* block id: 224 */
    uint32_t l_598 = 4294967291UL;
    int32_t l_600 = 0x2F135FC3L;
    int8_t l_623 = 0xD8L;
    int32_t l_748 = 0x4D89C632L;
    int32_t *l_785[5][1][8] = {{{&g_3,&g_405,&g_709,&g_405,&g_3,&g_709,&g_709,&g_3}},{{(void*)0,&g_3,&g_3,(void*)0,&g_709,&g_709,&g_709,(void*)0}},{{&g_3,&g_709,&g_3,&g_709,&l_600,&l_600,&g_709,&g_3}},{{&g_709,&g_709,&l_600,&g_709,&g_405,&g_709,&l_600,&g_709}},{{&g_709,&g_3,&g_709,&l_600,&l_600,&g_709,&g_3,&g_709}}};
    int8_t l_786 = 0x89L;
    int i, j, k;
    for (g_217 = 0; (g_217 <= 1); g_217 += 1)
    { /* block id: 227 */
        int32_t *l_597[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        const int64_t *l_674 = &g_12;
        int i;
        l_598 &= p_36;
        for (g_3 = 0; (g_3 <= 7); g_3 += 1)
        { /* block id: 231 */
            int64_t l_602 = 1L;
            uint32_t l_624 = 0x1E6A2BB5L;
            int32_t l_628 = 0xE035B02DL;
            int32_t l_629 = 1L;
            int32_t l_630 = 0L;
            int64_t l_635 = 0L;
            uint32_t l_676 = 1UL;
            uint16_t l_749 = 0UL;
            if ((safe_unary_minus_func_int32_t_s((l_600 = p_36))))
            { /* block id: 233 */
                int32_t l_605 = 0x59CFD178L;
                int32_t l_609[1];
                uint32_t l_631 = 4294967291UL;
                uint16_t l_679 = 65528UL;
                int32_t l_700 = 0x6F3849E8L;
                int32_t l_702 = (-1L);
                int32_t **l_710 = (void*)0;
                int16_t l_745 = 0xADF7L;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_609[i] = 0x51F6F106L;
                for (l_600 = 2; (l_600 >= 0); l_600 -= 1)
                { /* block id: 236 */
                    int16_t l_601 = 0x91DFL;
                    for (g_98 = 0; (g_98 <= 1); g_98 += 1)
                    { /* block id: 239 */
                        int i, j;
                        l_602 ^= l_601;
                        return (*g_86);
                    }
                }
                for (g_98 = 0; (g_98 <= 2); g_98 += 1)
                { /* block id: 246 */
                    uint32_t *l_608 = &g_137;
                    int32_t l_626 = 4L;
                    int32_t l_627 = 1L;
                    int i;
                    l_609[0] = (((*g_421) == (g_217 | ((l_602 , (safe_add_func_uint32_t_u_u(l_605, ((*l_608) = ((((&l_602 != (void*)0) && (p_36 >= ((0x90L == (l_600 &= (((safe_sub_func_uint16_t_u_u(3UL, 0x456EL)) , p_36) == 0x57L))) > 0x6CBAABEAL))) == p_36) > 2L))))) >= l_605))) & (*g_86));
                    for (g_575 = 2; (g_575 >= 0); g_575 -= 1)
                    { /* block id: 252 */
                        int i;
                        g_460[g_575] = (void*)0;
                        l_624 &= (safe_mod_func_uint8_t_u_u((((g_217 & (+(safe_sub_func_uint32_t_u_u((--g_137), l_609[0])))) | (((safe_sub_func_uint16_t_u_u(p_36, ((safe_mul_func_int8_t_s_s(((l_600 = 0L) , (((((safe_rshift_func_uint16_t_u_s(p_36, (l_602 & (&g_369 == ((((p_36 <= (p_36 , g_12)) && (**g_85)) || 0x0C91L) , &g_369))))) , l_609[0]) || (**g_273)) , &g_421) == (void*)0)), l_623)) ^ 6L))) , (*p_35)) , p_36)) ^ (-4L)), g_575));
                    }
                    for (g_444 = 0; (g_444 <= 1); g_444 += 1)
                    { /* block id: 260 */
                        int32_t l_625 = 1L;
                        int32_t **l_634 = &g_81[(g_217 + 1)][g_444];
                        int i, j, k;
                        l_631--;
                        (*l_634) = &l_605;
                        l_605 = 0x935DFFB7L;
                    }
                    g_460[g_217] = &g_575;
                }
                for (g_422 = 0; (g_422 <= 7); g_422 += 1)
                { /* block id: 269 */
                    int64_t l_643 = 1L;
                    int64_t *l_673[6] = {&g_196,&l_635,&g_196,&g_196,&l_635,&g_196};
                    int8_t *l_675 = &g_169;
                    int32_t l_721 = 0x08646A4CL;
                    int32_t l_722 = (-3L);
                    int32_t l_746 = 0x93C55DCAL;
                    int i;
                    if ((l_635 || ((safe_div_func_int32_t_s_s(((safe_add_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(((g_646 = (!(--(**g_273)))) >= ((safe_mod_func_int32_t_s_s((p_36 , (((safe_add_func_int64_t_s_s(8L, (0xC494L == (safe_mod_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_div_func_int64_t_s_s((((((l_600 &= (safe_lshift_func_int8_t_s_u((safe_div_func_int64_t_s_s((*g_86), ((1UL & ((*l_675) = (((safe_lshift_func_int16_t_s_s(((g_663 , (safe_lshift_func_int16_t_s_s((~((l_628 &= (g_196 &= ((safe_div_func_int64_t_s_s((((safe_rshift_func_uint8_t_u_u(((safe_sub_func_uint16_t_u_u(p_36, g_169)) | p_36), 6)) & l_624) , 0x64A3AC908BD19C60LL), l_643)) != p_36))) >= (*p_35))), 6))) != 0x974EB4301AD3F975LL), 8)) , (void*)0) == l_674))) && 0xB02495E23625B56ALL))), p_36))) && l_635) <= p_36) & (*g_421)) <= p_36), 0x52422B692E474C26LL)), l_623)), l_605))))) != g_422) , l_628)), l_598)) != p_36)), p_36)), l_623)) , 0x2E1C7490L), p_36)) < 0L)))
                    { /* block id: 276 */
                        const int8_t l_697 = (-7L);
                        uint32_t *l_699 = &l_676;
                        int32_t l_701 = (-10L);
                        l_676 ^= p_36;
                        l_702 = (l_701 |= ((p_36 <= p_36) || ((g_169 = (((l_700 = ((*l_699) = (safe_sub_func_int8_t_s_s(l_679, (safe_unary_minus_func_uint32_t_u((safe_rshift_func_int16_t_s_s(((!((void*)0 == &g_274[3])) != ((l_679 <= ((l_605 = (~(((0x56FDF0121C8729C0LL <= (safe_mul_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(0x9D7FL, (((((safe_mul_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u((safe_mod_func_int32_t_s_s(p_36, p_36)), 5)) , p_36), 1L)) , l_697) , 1UL) , (void*)0) != &g_169))), 1UL)) , g_698), 0x04L))) && (*p_35)) != (**g_273)))) > l_628)) <= (-8L))), 0)))))))) < p_36) > p_36)) != 0xBBL)));
                    }
                    else
                    { /* block id: 284 */
                        int32_t * const **l_705 = (void*)0;
                        int32_t * const l_708 = &g_709;
                        int32_t * const *l_707[3][2][3] = {{{(void*)0,(void*)0,(void*)0},{(void*)0,&l_708,&l_708}},{{(void*)0,(void*)0,&l_708},{(void*)0,&l_708,&l_708}},{{&l_708,(void*)0,&l_708},{(void*)0,(void*)0,(void*)0}}};
                        int32_t * const **l_706 = &l_707[2][1][2];
                        uint8_t *l_713 = &g_33;
                        int64_t ***l_728 = &g_85;
                        int64_t ****l_729[3][10][7] = {{{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,(void*)0,&l_728,(void*)0,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,(void*)0,(void*)0},{&l_728,&l_728,(void*)0,&l_728,&l_728,&l_728,(void*)0},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,(void*)0,&l_728,(void*)0,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,(void*)0,(void*)0,(void*)0,&l_728,&l_728,&l_728}},{{(void*)0,&l_728,&l_728,&l_728,&l_728,(void*)0,&l_728},{(void*)0,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,(void*)0,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,(void*)0,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,(void*)0,&l_728,&l_728,(void*)0,&l_728,&l_728},{&l_728,&l_728,(void*)0,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,(void*)0,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,(void*)0}},{{&l_728,(void*)0,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,(void*)0},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,(void*)0,&l_728,(void*)0,&l_728},{&l_728,(void*)0,&l_728,&l_728,&l_728,(void*)0,&l_728},{&l_728,&l_728,(void*)0,&l_728,&l_728,(void*)0,&l_728},{&l_728,&l_728,(void*)0,&l_728,(void*)0,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728},{&l_728,&l_728,&l_728,&l_728,&l_728,&l_728,&l_728}}};
                        int i, j, k;
                        l_600 |= (safe_add_func_uint8_t_u_u(((((void*)0 == &g_570) , 0x2D094074D78BF7B7LL) >= (0xD3849CBBL || ((((*l_706) = &g_460[2]) == l_710) , (0x4C2FL != (safe_sub_func_uint8_t_u_u((l_722 = (((*l_713)--) ^ (+(((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint64_t_u_u((((*p_35) & ((p_36 == p_36) & g_698)) > p_36), g_369)) ^ 0xF0L), l_721)) , g_4[2]) , (**g_85))))), p_36)))))), 0L));
                        if (l_722)
                            break;
                        if (p_36)
                            break;
                        l_746 = (safe_sub_func_uint32_t_u_u(0UL, (l_722 = (((safe_unary_minus_func_uint16_t_u(((p_36 & (((&g_72 == (g_731 = ((safe_div_func_int16_t_s_s(g_217, l_721)) , (g_730 = l_728)))) | (safe_mul_func_uint16_t_u_u((safe_div_func_int8_t_s_s(((safe_div_func_int8_t_s_s(((*l_675) = (safe_div_func_int32_t_s_s(((p_36 < 0x2DACL) | (!(safe_mod_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(1UL, p_36)), p_36)))), p_36))), p_36)) > g_12), 0x97L)), p_36))) | (*g_421))) , l_745))) , g_709) && (*g_421)))));
                    }
                    return (**g_85);
                }
                l_702 = 0L;
            }
            else
            { /* block id: 300 */
                uint32_t *l_773 = &l_676;
                uint32_t *l_778 = &l_598;
                uint8_t l_779 = 0UL;
                int32_t l_780 = (-9L);
                int64_t *l_781 = (void*)0;
                int32_t **l_782 = (void*)0;
                int32_t **l_783 = &l_597[4];
                int32_t **l_784 = (void*)0;
                for (g_698 = 1; (g_698 <= 7); g_698 += 1)
                { /* block id: 303 */
                    int64_t l_747 = 0x3EDC3E7E328C30C3LL;
                    int32_t l_767 = 0x783AC685L;
                    for (g_709 = 0; (g_709 <= 7); g_709 += 1)
                    { /* block id: 306 */
                        uint64_t *l_756 = &g_488;
                        int i;
                        l_749++;
                        l_767 ^= (l_748 , (l_748 = ((+(~((*g_421) = (0xC4F8L >= (safe_sub_func_uint32_t_u_u(((++(*l_756)) , ((void*)0 == &g_424)), (safe_lshift_func_int8_t_s_u(((65530UL <= (safe_add_func_int64_t_s_s(l_747, (safe_sub_func_uint16_t_u_u(((0x38CC82AD3F67E3A3LL < (safe_sub_func_uint16_t_u_u(l_602, 0x0432L))) | l_623), l_602))))) >= (-5L)), l_747)))))))) && p_36)));
                    }
                }
                g_460[(g_217 + 1)] = ((*l_783) = func_75(((safe_mul_func_int8_t_s_s((((l_780 &= (safe_lshift_func_uint8_t_u_u((~((((*l_773) = g_437) && (-4L)) == (p_36 , ((p_36 == ((void*)0 == &l_748)) , ((((*p_35) > (safe_mul_func_int16_t_s_s(g_98, (safe_div_func_uint32_t_u_u(((*l_778) ^= (g_709 , g_369)), 0x9B1B5CD2L))))) != p_36) >= l_779))))), 5))) < l_748) && g_575), 7UL)) && g_369), &l_628, l_781, &l_779, l_628));
                for (g_169 = 7; (g_169 >= 0); g_169 -= 1)
                { /* block id: 321 */
                    return (*p_35);
                }
            }
        }
    }
    l_786 &= 0xA80C520AL;
    for (g_422 = 2; (g_422 <= 7); g_422 += 1)
    { /* block id: 330 */
        uint8_t l_788 = 246UL;
        int64_t l_811 = 0xD263EF855E39DFBELL;
        int32_t l_814 = 0xFBC1DD27L;
        for (g_663 = 0; (g_663 <= 1); g_663 += 1)
        { /* block id: 333 */
            int32_t *l_787 = (void*)0;
            int32_t l_813[5][1] = {{0L},{(-3L)},{0L},{(-3L)},{0L}};
            int i, j;
            for (l_748 = 1; (l_748 <= 7); l_748 += 1)
            { /* block id: 336 */
                int64_t *l_802 = &g_12;
                uint64_t *l_803[7][8] = {{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93},{&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93,&g_93}};
                int32_t l_804 = (-2L);
                int16_t * const l_807 = &g_646;
                int16_t * const *l_806 = &l_807;
                int16_t * const ** const l_805 = &l_806;
                int i, j;
                l_788 = ((void*)0 != l_787);
                l_813[3][0] = ((safe_div_func_uint32_t_u_u(g_196, (safe_sub_func_uint64_t_u_u((0xE66E9A8BL ^ (safe_rshift_func_uint16_t_u_u((((**g_809) ^= (safe_rshift_func_int16_t_s_s(((g_169 > ((((safe_lshift_func_uint8_t_u_u((!((l_804 = ((safe_div_func_uint8_t_u_u((l_788 , (*g_421)), 0xDCL)) & ((void*)0 == l_802))) && (**g_85))), 7)) , l_805) == g_808[1]) <= (*g_421))) , (-9L)), 8))) >= l_811), p_36))), g_812)))) & p_36);
            }
        }
        l_814 &= 0xA8FAAC4BL;
    }
    return (**g_85);
}


/* ------------------------------------------ */
/* 
 * reads : g_98
 * writes:
 */
static uint16_t  func_42(uint16_t * const  p_43, uint16_t  p_44)
{ /* block id: 221 */
    int32_t *l_591 = &g_575;
    int32_t *l_592[8][6][1] = {{{&g_3},{&g_405},{&g_3},{(void*)0},{&g_3},{&g_405}},{{&g_3},{(void*)0},{&g_3},{&g_405},{&g_3},{(void*)0}},{{&g_3},{&g_405},{&g_3},{(void*)0},{&g_3},{&g_405}},{{&g_3},{(void*)0},{&g_3},{&g_405},{&g_3},{(void*)0}},{{&g_3},{&g_405},{&g_3},{(void*)0},{&g_3},{&g_405}},{{&g_3},{(void*)0},{&g_3},{&g_405},{&g_3},{(void*)0}},{{&g_3},{&g_405},{&g_3},{(void*)0},{&g_3},{&g_405}},{{&g_3},{(void*)0},{&g_3},{&g_405},{&g_3},{(void*)0}}};
    int16_t l_593[8][7][4] = {{{0L,0xE643L,0xD8C8L,0x1B21L},{0xA14FL,0xA2A7L,0xC593L,0x4F8EL},{0x31C3L,0L,0x4712L,0L},{0x97F9L,(-1L),0xF153L,1L},{(-1L),0xC593L,0x7CA7L,(-1L)},{0xBC7AL,0xCCE6L,7L,7L},{1L,1L,0xF153L,0x4F8EL}},{{0L,(-1L),0xC266L,0L},{0x31C3L,0x5E24L,0xBC7AL,0xC266L},{(-1L),0x5E24L,0xD8C8L,0L},{0x5E24L,(-1L),0x3BD5L,0x4F8EL},{6L,1L,0xC593L,7L},{0x97F9L,0xCCE6L,0L,(-1L)},{1L,0xC593L,0xBC7AL,1L}},{{6L,(-1L),7L,0L},{0L,0L,0xD8C8L,0x4F8EL},{1L,0xA2A7L,0L,0x1B21L},{0x31C3L,0L,0x31C3L,0L},{1L,0x5E24L,0xF153L,0L},{0xA14FL,0xC593L,0x3BD5L,0x5E24L},{0xBC7AL,0L,0x3BD5L,7L}},{{0xA14FL,(-1L),0xF153L,(-4L)},{1L,(-1L),0x31C3L,(-1L)},{0x31C3L,(-1L),0L,0xC266L},{1L,0L,0xD8C8L,0x5E24L},{0L,(-1L),7L,0x1B21L},{6L,0xA14FL,0xBC7AL,7L},{1L,0L,0L,0L}},{{0x97F9L,0xC593L,0xC593L,0x97F9L},{6L,0L,0x3BD5L,0L},{0x5E24L,0xCCE6L,0xD8C8L,(-4L)},{(-1L),0xA2A7L,0xBC7AL,(-4L)},{0x31C3L,0xCCE6L,0xC266L,0L},{0L,0L,0xF153L,0x97F9L},{1L,0xC593L,7L,0L}},{{0xBC7AL,0L,0x7CA7L,7L},{(-1L),0xA14FL,0xF153L,0x1B21L},{0x97F9L,(-1L),0x4712L,0x5E24L},{0x31C3L,0L,0xC593L,0xC266L},{0xA14FL,(-1L),0xD8C8L,(-1L)},{(-1L),(-1L),0x7CA7L,(-4L)},{6L,(-1L),0L,7L}},{{0L,0L,0L,0x5E24L},{0L,0xC593L,0L,0L},{6L,0x5E24L,0x7CA7L,0L},{(-1L),0L,0xD8C8L,0x1B21L},{0xA14FL,0xA2A7L,0xC593L,0x4F8EL},{0x31C3L,0L,0x4712L,0L},{0x3BD5L,0xC266L,0L,7L}},{{0L,0L,8L,0xC266L},{0L,0xAFE6L,0x9ECCL,0x9ECCL},{0xBC7AL,0xBC7AL,0L,(-1L)},{0x7CA7L,0x05BAL,0xE643L,0x31C3L},{0x5290L,0x4712L,0L,0xE643L},{0L,0x4712L,0L,0x31C3L},{0x4712L,0x05BAL,8L,(-1L)}}};
    uint32_t l_594[1][10] = {{0x2F40CF78L,1UL,0x2F40CF78L,0x2F40CF78L,1UL,0x2F40CF78L,0x2F40CF78L,1UL,0x2F40CF78L,0x2F40CF78L}};
    int i, j, k;
    l_594[0][7]++;
    return (*p_43);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t * const  func_45(int64_t  p_46, uint16_t * p_47, uint8_t  p_48, int16_t  p_49, uint32_t  p_50)
{ /* block id: 219 */
    uint16_t * const l_590 = &g_98;
    return l_590;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_72 g_85 g_4 g_369 g_422 g_437 g_460 g_3 g_421 g_575 g_273 g_274 g_584
 * writes: g_33 g_81 g_460 g_437 g_169 g_405 g_575 g_582 g_583
 */
static uint16_t * func_52(int64_t ** p_53, int16_t  p_54, int32_t * p_55, int8_t  p_56, const int32_t  p_57)
{ /* block id: 7 */
    int64_t l_530 = (-9L);
    uint64_t *l_578 = (void*)0;
    int32_t *l_585 = &g_3;
    int32_t **l_586 = (void*)0;
    int32_t **l_587[6];
    int32_t *l_588 = &g_405;
    uint16_t *l_589 = &g_217;
    int i;
    for (i = 0; i < 6; i++)
        l_587[i] = &g_81[1][0];
    for (g_33 = 0; (g_33 >= 40); ++g_33)
    { /* block id: 10 */
        int8_t l_82 = (-1L);
        int32_t **l_529 = &g_460[0];
        const uint32_t l_531 = 0x0BF463CBL;
        uint32_t l_572[9][5] = {{0x14AF06EAL,0x14AF06EAL,0x77806206L,0x14AF06EAL,0x14AF06EAL},{0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL},{0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L},{0x14AF06EAL,0x14AF06EAL,0x77806206L,0x14AF06EAL,0x14AF06EAL},{0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL},{0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L},{0x14AF06EAL,0x14AF06EAL,0x77806206L,0x14AF06EAL,0x14AF06EAL},{0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL},{0x14AF06EAL,0x15B8BAC8L,0x15B8BAC8L,0x14AF06EAL,0x15B8BAC8L}};
        int i, j;
        if (((safe_sub_func_int16_t_s_s(func_65((safe_add_func_uint16_t_u_u((((p_53 == g_72) , &p_57) == ((*l_529) = func_75((((&p_57 == (g_81[0][0] = (void*)0)) & (l_82 >= ((((safe_sub_func_uint8_t_u_u((g_85 != (void*)0), (253UL == g_4[4]))) < 0x09CEL) >= l_82) != 1UL))) , 5L), p_55, (*p_53), &g_33, l_82))), g_369)), l_530, l_531, p_55), p_54)) , 0xA5F19B91L))
        { /* block id: 202 */
            int32_t l_549 = (-8L);
            int8_t *l_550 = &l_82;
            int16_t *l_566 = &g_437;
            int32_t ***l_567[4][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529,&l_529}};
            int8_t *l_568 = &g_169;
            int16_t *l_569[7][8][4] = {{{(void*)0,&g_570,(void*)0,&g_570},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,(void*)0,(void*)0,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,(void*)0},{&g_570,(void*)0,&g_570,&g_570}},{{&g_570,&g_570,&g_570,(void*)0},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,(void*)0,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570}},{{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,(void*)0,(void*)0,&g_570},{&g_570,(void*)0,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570}},{{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,(void*)0},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,(void*)0,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,(void*)0,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570}},{{(void*)0,&g_570,&g_570,(void*)0},{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,&g_570,(void*)0,&g_570},{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,(void*)0},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570}},{{&g_570,(void*)0,&g_570,&g_570},{&g_570,&g_570,(void*)0,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,(void*)0,(void*)0},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570}},{{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,(void*)0,(void*)0,&g_570},{&g_570,(void*)0,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{(void*)0,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570}}};
            int64_t *l_571[4][4][9] = {{{&g_196,&g_12,&g_196,&l_530,&g_12,&l_530,&g_196,&g_12,&g_196},{&g_12,&g_196,(void*)0,&g_196,&g_196,&g_196,(void*)0,&g_196,&g_12},{&g_196,&g_12,&g_196,&l_530,&g_12,&l_530,&g_196,&g_12,&g_196},{&g_12,&g_196,(void*)0,&g_196,&g_196,&g_196,(void*)0,&g_196,&g_196}},{{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196},{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196}},{{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196},{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196}},{{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196},{&g_12,&g_196,&g_196,&l_530,&g_196,&l_530,&g_196,&g_196,&g_12},{&g_196,&g_12,(void*)0,&g_196,&g_12,&g_196,(void*)0,&g_12,&g_196}}};
            int i, j, k;
            l_572[3][3] ^= (safe_add_func_int16_t_s_s(((((*l_550) = l_549) | (p_56 != (((safe_div_func_int8_t_s_s((0L >= ((((safe_lshift_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((p_54 |= ((safe_rshift_func_int8_t_s_s(((*l_568) = (&l_529 != (((~((safe_div_func_int16_t_s_s(l_549, (safe_mul_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u(p_56, 5UL)) != l_549), ((*l_566) &= 0xE21BL))))) != p_57)) | (**l_529)) , l_567[0][6]))), 1)) != 0L)), p_56)), (*g_421))) != 0xE8L) , (*p_53)) != l_571[0][0][8])), 0xB1L)) , (void*)0) == l_571[0][0][8]))) | 1L), p_56));
        }
        else
        { /* block id: 208 */
            int32_t *l_573 = &g_405;
            int32_t *l_574 = &g_575;
            uint64_t * const l_579 = &g_93;
            uint16_t *l_581 = &g_217;
            uint16_t **l_580[6][1] = {{&l_581},{&l_581},{&l_581},{&l_581},{&l_581},{&l_581}};
            int i, j;
            (*l_574) ^= ((*l_573) = l_530);
            (*l_573) = (safe_sub_func_int16_t_s_s((l_578 == l_579), ((*g_273) != (g_583 = (g_582 = (void*)0)))));
            return g_584[2];
        }
    }
    l_588 = l_585;
    return l_589;
}


/* ------------------------------------------ */
/* 
 * reads : g_422
 * writes:
 */
static int16_t  func_65(const int8_t  p_66, int8_t  p_67, const int64_t  p_68, int32_t * p_69)
{ /* block id: 196 */
    uint32_t l_533 = 1UL;
    int32_t l_534 = 1L;
    int32_t *l_535[8];
    int32_t l_536 = 6L;
    int8_t l_537 = (-1L);
    uint8_t l_538 = 0xABL;
    int64_t l_541 = 0x23C3F02C3EEBAF6ALL;
    uint32_t l_542 = 0xD239411AL;
    int64_t l_543[7];
    uint16_t l_544 = 65535UL;
    int i;
    for (i = 0; i < 8; i++)
        l_535[i] = &g_405;
    for (i = 0; i < 7; i++)
        l_543[i] = 5L;
    l_533 &= (!9L);
    l_538++;
    l_542 = l_541;
    l_544++;
    return g_422;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_75(int16_t  p_76, int32_t * p_77, int64_t * p_78, uint8_t * p_79, uint32_t  p_80)
{ /* block id: 12 */
    const int32_t *l_96 = &g_3;
    uint16_t *l_97 = &g_98;
    const int64_t * const l_105 = (void*)0;
    int64_t **l_106 = (void*)0;
    int32_t l_402 = 0xA2CFD249L;
    int32_t l_403 = 0L;
    int32_t l_404[7][5] = {{0L,0x3A99D003L,1L,0xDCC79A11L,7L},{(-1L),1L,2L,1L,(-1L)},{0L,0x3A99D003L,0x823C9C4AL,(-1L),0x139F3F89L},{0L,0x139F3F89L,7L,(-2L),(-2L)},{(-1L),0xE0FBEBB0L,(-1L),0x3A99D003L,0x139F3F89L},{0L,(-2L),0x139F3F89L,0x3A99D003L,(-1L)},{0x139F3F89L,7L,(-2L),(-2L),7L}};
    uint32_t l_406 = 0xA3DB543AL;
    uint32_t l_490 = 1UL;
    uint16_t ***l_503[5][8][4] = {{{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,(void*)0,(void*)0},{&g_273,(void*)0,&g_273,&g_273},{&g_273,&g_273,&g_273,(void*)0},{&g_273,&g_273,(void*)0,&g_273},{(void*)0,&g_273,&g_273,&g_273},{(void*)0,&g_273,&g_273,&g_273}},{{(void*)0,(void*)0,(void*)0,&g_273},{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,(void*)0,&g_273},{&g_273,(void*)0,&g_273,(void*)0},{(void*)0,(void*)0,&g_273,&g_273},{(void*)0,&g_273,(void*)0,&g_273},{(void*)0,&g_273,&g_273,&g_273}},{{&g_273,&g_273,&g_273,&g_273},{&g_273,(void*)0,&g_273,&g_273},{&g_273,&g_273,&g_273,(void*)0},{&g_273,&g_273,&g_273,(void*)0},{&g_273,(void*)0,&g_273,(void*)0},{&g_273,&g_273,&g_273,&g_273},{(void*)0,&g_273,(void*)0,&g_273},{(void*)0,&g_273,&g_273,&g_273}},{{(void*)0,&g_273,&g_273,&g_273},{&g_273,&g_273,(void*)0,&g_273},{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,(void*)0},{&g_273,(void*)0,&g_273,(void*)0},{&g_273,&g_273,(void*)0,(void*)0},{(void*)0,&g_273,(void*)0,&g_273},{&g_273,(void*)0,&g_273,&g_273}},{{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,(void*)0,&g_273},{&g_273,(void*)0,&g_273,(void*)0},{(void*)0,(void*)0,&g_273,&g_273},{(void*)0,&g_273,(void*)0,&g_273},{(void*)0,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273}}};
    int32_t *l_511 = &l_402;
    int32_t *l_512 = &g_405;
    int32_t *l_513 = &g_405;
    int32_t *l_514 = &l_404[5][1];
    int32_t *l_515 = &l_402;
    int32_t *l_516 = &l_403;
    int32_t *l_517 = &l_404[5][1];
    int32_t *l_518 = (void*)0;
    int32_t *l_519 = &l_404[5][0];
    int32_t *l_520 = &l_404[5][1];
    int32_t *l_521 = &g_405;
    int32_t *l_522 = (void*)0;
    int32_t *l_523 = &l_404[5][1];
    int32_t *l_524[10][3][1] = {{{(void*)0},{&l_404[5][1]},{(void*)0}},{{&l_404[5][1]},{(void*)0},{&l_404[5][1]}},{{(void*)0},{&l_404[5][1]},{(void*)0}},{{&l_404[5][1]},{(void*)0},{&l_404[5][1]}},{{(void*)0},{&l_404[5][1]},{(void*)0}},{{&l_404[5][1]},{(void*)0},{&l_404[5][1]}},{{(void*)0},{&l_404[5][1]},{(void*)0}},{{&l_404[5][1]},{(void*)0},{&l_404[5][1]}},{{(void*)0},{&l_404[5][1]},{(void*)0}},{{&l_404[5][1]},{(void*)0},{&l_404[5][1]}}};
    int64_t l_525 = 0L;
    uint32_t l_526 = 0UL;
    int i, j, k;
    for (p_76 = 0; (p_76 <= 1); p_76 += 1)
    { /* block id: 15 */
        int32_t l_99[1][4] = {{0x3869515BL,0x3869515BL,0x3869515BL,0x3869515BL}};
        uint16_t *l_100 = &g_98;
        uint16_t **l_101 = &l_100;
        int32_t **l_104 = &g_81[1][0];
        int32_t **l_399 = (void*)0;
        int32_t **l_400 = &g_81[0][1];
        int32_t *l_401[6] = {&l_99[0][2],&l_99[0][2],&l_99[0][2],&l_99[0][2],&l_99[0][2],&l_99[0][2]};
        uint8_t *l_420 = &g_33;
        uint8_t **l_419 = &l_420;
        int16_t *l_436 = &g_437;
        int16_t **l_435 = &l_436;
        int i, j;
    }
    --l_526;
    return p_77;
}


/* ------------------------------------------ */
/* 
 * reads : g_98 g_12 g_4 g_33 g_85 g_86 g_217 g_3 g_169 g_137 g_273 g_220 g_93 g_196 g_81 g_274 g_369 g_398
 * writes: g_98 g_169 g_81 g_93
 */
static int32_t * const  func_87(const int32_t * p_88, int8_t  p_89, const int64_t * const  p_90, int64_t ** p_91, int32_t * p_92)
{ /* block id: 19 */
    int64_t **l_118 = &g_86;
    int32_t l_121 = 0x636CD8D4L;
    int32_t **l_128 = &g_81[0][1];
    int16_t l_156 = 0x209EL;
    uint8_t l_183 = 1UL;
    int32_t l_203 = (-2L);
    int32_t l_204[4][5][3] = {{{3L,3L,(-1L)},{0L,0xFA74B5D4L,1L},{0x2C77FF3CL,0x30D896A6L,0L},{0L,0xF7613724L,1L},{3L,0x2C77FF3CL,0L}},{{0x32703BF9L,0x32703BF9L,1L},{(-1L),0x2C77FF3CL,(-1L)},{0xFA74B5D4L,0xF7613724L,(-2L)},{(-1L),0x30D896A6L,(-3L)},{0x32703BF9L,0xFA74B5D4L,(-2L)}},{{3L,0xD21D9937L,(-1L)},{0xCFA680EFL,(-9L),0L},{0xE951E9A9L,0xD79527A0L,0x30D896A6L},{0xCFA680EFL,(-5L),0xB212F535L},{0xD21D9937L,0xE951E9A9L,0x30D896A6L}},{{(-1L),(-1L),0L},{0x84D8DA12L,0xE951E9A9L,(-1L)},{(-9L),(-5L),0xF7613724L},{0x84D8DA12L,0xD79527A0L,(-1L)},{(-1L),(-9L),0xF7613724L}}};
    int64_t **l_225 = &g_86;
    int8_t *l_234 = &g_169;
    uint16_t *l_235 = (void*)0;
    uint16_t *l_236 = (void*)0;
    uint16_t *l_237 = &g_98;
    int32_t l_326 = 0x90CB32F4L;
    int64_t l_327 = 5L;
    int8_t l_329 = 0x0AL;
    int8_t l_366[4][6][5] = {{{(-1L),0L,7L,0L,(-1L)},{8L,1L,(-3L),0xF8L,0x8DL},{1L,(-1L),8L,0x74L,(-1L)},{0x51L,0L,(-2L),1L,0x8DL},{0x29L,0x74L,1L,0L,(-1L)},{0x8DL,0x45L,8L,0x51L,0L}},{{0L,(-1L),1L,0x51L,0x51L},{0xE4L,0xB7L,0xE4L,0L,(-1L)},{1L,0L,0x29L,1L,0xF8L},{0x74L,0x8DL,9L,0x74L,0x51L},{1L,0x74L,0x29L,0xF8L,(-1L)},{(-1L),0x29L,0xE4L,0L,1L}},{{0x74L,1L,1L,(-1L),0x8DL},{(-3L),1L,8L,8L,1L},{0x51L,0x29L,1L,1L,0x45L},{0L,0x74L,(-2L),0x44L,(-1L)},{0x45L,0x8DL,8L,0xE4L,(-1L)},{0L,0L,(-3L),0x51L,0xE4L}},{{0x51L,0xB7L,7L,0x44L,(-1L)},{(-3L),(-1L),0x29L,(-1L),(-1L)},{0x74L,0x45L,0x45L,0x74L,0xE4L},{(-1L),0x74L,0x7DL,(-1L),(-1L)},{1L,0L,0xE4L,0x29L,(-1L)},{0x74L,(-1L),(-3L),(-1L),0x45L}}};
    int8_t l_373 = 2L;
    uint16_t l_389 = 65535UL;
    int i, j, k;
    for (g_98 = (-2); (g_98 < 25); g_98 = safe_add_func_uint8_t_u_u(g_98, 3))
    { /* block id: 22 */
        int64_t **l_115 = &g_86;
        int64_t ***l_116 = (void*)0;
        int64_t ***l_117[3];
        int32_t l_122 = 0xF1BCD962L;
        int32_t l_123 = 0x31AB994FL;
        int32_t l_124 = 0x154EA94EL;
        uint32_t *l_136 = &g_137;
        uint8_t *l_191 = &g_33;
        int16_t l_193 = (-8L);
        uint8_t l_194 = 248UL;
        uint32_t l_197 = 18446744073709551608UL;
        int32_t l_201 = (-10L);
        int32_t l_202 = 1L;
        int32_t l_205 = (-10L);
        int32_t l_207 = 0x499DE0AFL;
        int32_t l_208 = 0L;
        int32_t l_209[10] = {(-10L),(-10L),(-1L),(-10L),(-10L),(-1L),(-10L),(-10L),(-1L),(-10L)};
        int64_t l_210 = 0L;
        uint64_t l_211 = 0x9D36A7B672675DE2LL;
        int i;
        for (i = 0; i < 3; i++)
            l_117[i] = &g_85;
        l_124 ^= ((l_123 &= (safe_rshift_func_int8_t_s_u((((p_89 , (safe_add_func_int64_t_s_s((((void*)0 != &g_3) ^ g_98), (((safe_mul_func_int8_t_s_s(((l_118 = l_115) == (void*)0), (g_12 & (-1L)))) & (safe_div_func_int32_t_s_s(((((-1L) != p_89) ^ p_89) || g_4[3]), l_121))) != g_33)))) <= g_33) > l_122), g_33))) == (**g_85));
    }
    if ((((*l_237) = (((*l_234) &= ((**g_85) , (g_217 , (((l_225 == l_118) >= ((safe_rshift_func_uint16_t_u_u(p_89, 10)) , (**g_85))) != (safe_mul_func_int8_t_s_s((+(safe_add_func_uint16_t_u_u(((0x7FL | (safe_unary_minus_func_int32_t_s((&g_85 == &g_85)))) , p_89), g_33))), g_3)))))) | p_89)) ^ p_89))
    { /* block id: 61 */
        int32_t *l_238 = &l_204[0][2][0];
        uint16_t **l_276[2];
        int32_t l_279 = 0x161C1880L;
        int32_t l_280[7] = {4L,4L,4L,4L,4L,4L,4L};
        int16_t l_281 = 1L;
        int16_t l_324 = 0x7892L;
        uint32_t l_348[2];
        uint8_t l_349 = 0xF9L;
        int i;
        for (i = 0; i < 2; i++)
            l_276[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_348[i] = 2UL;
        if ((((*l_238) = 5L) | g_3))
        { /* block id: 63 */
            int32_t **l_239 = &g_81[1][0];
            int64_t l_262 = 0L;
            uint16_t l_282 = 1UL;
            int8_t l_302[9];
            int32_t l_317 = 0L;
            int32_t l_318 = 6L;
            int32_t l_320 = 0xA5D2842BL;
            int32_t l_321 = 0x7D687358L;
            int32_t l_322[2];
            int32_t l_325 = 0x36EC54ABL;
            int64_t l_328 = 0xEE3586771EE5A731LL;
            int i;
            for (i = 0; i < 9; i++)
                l_302[i] = 9L;
            for (i = 0; i < 2; i++)
                l_322[i] = 0x0886D678L;
            l_239 = &g_81[0][0];
            for (l_203 = (-2); (l_203 > (-15)); l_203--)
            { /* block id: 67 */
                int8_t l_260[2];
                int32_t * const l_264 = &l_121;
                int8_t *l_301 = &l_260[1];
                int32_t l_315[5];
                int32_t l_316[9];
                int32_t l_319 = 0x2F1D17CBL;
                int16_t l_323[8][7] = {{(-4L),(-1L),0L,(-1L),0L,4L,0x5FC1L},{0x012CL,1L,0x62A4L,0x7A67L,0x7A67L,0x62A4L,1L},{(-4L),(-1L),0L,(-1L),0L,4L,0x5FC1L},{0x012CL,1L,0x62A4L,0x7A67L,0x012CL,0x7A67L,0xE8B8L},{0xEF9AL,0xBE48L,0L,0x9C15L,(-4L),(-1L),0xBCB5L},{0x616AL,0xE8B8L,0x7A67L,0x012CL,0x012CL,0x7A67L,0xE8B8L},{0xEF9AL,0xBE48L,0L,0x9C15L,(-4L),(-1L),0xBCB5L},{0x616AL,0xE8B8L,0x7A67L,0x012CL,0x012CL,0x7A67L,0xE8B8L}};
                uint64_t l_330[5][10][5] = {{{5UL,18446744073709551610UL,0UL,0x76C9A4FBDB784356LL,18446744073709551615UL},{0x60EA393E002ECA2ELL,0x99706BEA9332367ELL,0xBC76516F5BABD9F5LL,0x240475B19B664EFALL,1UL},{8UL,18446744073709551613UL,18446744073709551615UL,1UL,18446744073709551611UL},{3UL,0x21FE613C0B622416LL,3UL,18446744073709551611UL,0x76C9A4FBDB784356LL},{0UL,0x9E7EAD6E3870329BLL,0x74611BECE6332B88LL,18446744073709551615UL,0xBEC88CB0C1F3DE26LL},{0x2065D6BEC47878FDLL,0x0E5B0C7E112AFEF8LL,0UL,0x0E5B0C7E112AFEF8LL,0x2065D6BEC47878FDLL},{0UL,0xB0D73167C10AD38DLL,0x33D5E6A82CC0347BLL,3UL,0UL},{0xDA1F4D01495B19ACLL,0UL,1UL,0UL,0x74611BECE6332B88LL},{0xEB1831B8121743C2LL,0x5753D1A51D5DA4B8LL,18446744073709551608UL,0xB0D73167C10AD38DLL,0UL},{18446744073709551611UL,0UL,0x9E7EAD6E3870329BLL,0x24F08A8B31EB4D04LL,0x2065D6BEC47878FDLL}},{{0UL,0UL,18446744073709551610UL,0xC35533DD5F45DA57LL,0xBEC88CB0C1F3DE26LL},{4UL,0xA7AB968F13899728LL,0UL,0x0EFE1D1738F0D1F3LL,0x76C9A4FBDB784356LL},{18446744073709551615UL,0xE27F2D186D5F52EDLL,5UL,18446744073709551615UL,18446744073709551611UL},{18446744073709551613UL,0UL,0x2065D6BEC47878FDLL,0xBC76516F5BABD9F5LL,1UL},{18446744073709551615UL,0xC8451B01560E901ALL,0UL,3UL,18446744073709551615UL},{0x0E5B0C7E112AFEF8LL,3UL,1UL,18446744073709551611UL,0x8AC8BC69DE854506LL},{0x76C9A4FBDB784356LL,3UL,0x21FE613C0B622416LL,0UL,0x84D5809CD3F009AFLL},{18446744073709551615UL,0xC8451B01560E901ALL,18446744073709551615UL,18446744073709551607UL,18446744073709551615UL},{0xA7AB968F13899728LL,0UL,18446744073709551615UL,18446744073709551615UL,3UL},{18446744073709551610UL,0xE27F2D186D5F52EDLL,0xDCCD15C780BEFE5CLL,0x5FC40BD5225C5E89LL,18446744073709551615UL}},{{0x54A12E70FA249955LL,0xA7AB968F13899728LL,0UL,18446744073709551615UL,18446744073709551610UL},{0xDCCD15C780BEFE5CLL,0UL,0UL,0xDCCD15C780BEFE5CLL,4UL},{18446744073709551613UL,0UL,0xEB1831B8121743C2LL,18446744073709551613UL,0x8EAAB78E7ED49D87LL},{18446744073709551615UL,0x5753D1A51D5DA4B8LL,0UL,18446744073709551609UL,0xC8451B01560E901ALL},{0x99706BEA9332367ELL,0UL,0xB4181C599C64521CLL,18446744073709551613UL,18446744073709551608UL},{0x53AC31E297CCEA3CLL,0xB0D73167C10AD38DLL,18446744073709551615UL,0xDCCD15C780BEFE5CLL,1UL},{4UL,0x0E5B0C7E112AFEF8LL,0x240475B19B664EFALL,18446744073709551615UL,18446744073709551611UL},{0UL,0x9E7EAD6E3870329BLL,18446744073709551611UL,0x5FC40BD5225C5E89LL,0UL},{18446744073709551611UL,0x21FE613C0B622416LL,0x84D5809CD3F009AFLL,18446744073709551615UL,9UL},{0xC8451B01560E901ALL,18446744073709551613UL,0xDA1F4D01495B19ACLL,18446744073709551607UL,0UL}},{{0x21FE613C0B622416LL,0x99706BEA9332367ELL,18446744073709551613UL,0UL,0x53AC31E297CCEA3CLL},{3UL,18446744073709551610UL,18446744073709551613UL,18446744073709551611UL,0UL},{18446744073709551610UL,0x240475B19B664EFALL,1UL,18446744073709551609UL,0x9E7EAD6E3870329BLL},{3UL,0UL,0x5753D1A51D5DA4B8LL,0UL,3UL},{3UL,18446744073709551613UL,1UL,0UL,0x76C9A4FBDB784356LL},{0UL,0x74611BECE6332B88LL,0xA96AC5459EF36716LL,18446744073709551613UL,3UL},{0UL,18446744073709551609UL,9UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551613UL,18446744073709551615UL,18446744073709551613UL,18446744073709551607UL,0xE27F2D186D5F52EDLL},{0xA96AC5459EF36716LL,0UL,4UL,0x0EFE1D1738F0D1F3LL,18446744073709551610UL},{0x8EAAB78E7ED49D87LL,8UL,0xA7AB968F13899728LL,5UL,0x60EA393E002ECA2ELL}},{{0x2065D6BEC47878FDLL,1UL,4UL,18446744073709551610UL,0xDA1F4D01495B19ACLL},{0x33D5E6A82CC0347BLL,0UL,18446744073709551613UL,9UL,0x0E5B0C7E112AFEF8LL},{3UL,18446744073709551615UL,9UL,0x2065D6BEC47878FDLL,4UL},{0x8AC8BC69DE854506LL,0xDA1F4D01495B19ACLL,0xA96AC5459EF36716LL,4UL,0xBD6B5F47294724DCLL},{0xBEC88CB0C1F3DE26LL,0xA7AB968F13899728LL,1UL,0UL,18446744073709551613UL},{3UL,0x76C9A4FBDB784356LL,0x5753D1A51D5DA4B8LL,0x0E5B0C7E112AFEF8LL,18446744073709551610UL},{1UL,18446744073709551607UL,1UL,8UL,18446744073709551607UL},{8UL,0UL,0x33D5E6A82CC0347BLL,0xBC76516F5BABD9F5LL,18446744073709551607UL},{9UL,0xDCCD15C780BEFE5CLL,18446744073709551613UL,0UL,18446744073709551610UL},{0UL,0UL,0UL,18446744073709551615UL,18446744073709551613UL}}};
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_260[i] = (-2L);
                for (i = 0; i < 5; i++)
                    l_315[i] = 0x8E30AD3EL;
                for (i = 0; i < 9; i++)
                    l_316[i] = 0x0D67AFB2L;
                for (g_169 = 8; (g_169 != 18); ++g_169)
                { /* block id: 70 */
                    uint32_t *l_258 = (void*)0;
                    int32_t l_259 = 0x5E02EBC2L;
                    int32_t *l_261 = &l_121;
                    uint8_t *l_263 = &l_183;
                    uint8_t l_277 = 0x60L;
                    if ((safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s(((*l_238) > (**g_85)), p_89)), ((g_137 < (g_3 || (((((((*l_263) = (safe_mod_func_uint8_t_u_u((((*l_261) = (safe_mul_func_int16_t_s_s((((safe_mod_func_int64_t_s_s(((safe_div_func_int64_t_s_s(p_89, 18446744073709551612UL)) <= (1L || ((safe_sub_func_uint32_t_u_u(((l_259 = 0x007F3C8AL) , 0xD50F805FL), (-4L))) >= l_260[0]))), g_4[1])) , p_89) && g_169), 65534UL))) && 0xCCB0C8A6L), l_262))) < p_89) , 8UL) , &p_89) == &l_260[0]) && (*g_86)))) && g_4[3]))))
                    { /* block id: 74 */
                        return &g_3;
                    }
                    else
                    { /* block id: 76 */
                        uint32_t *l_271[10] = {&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137,&g_137};
                        int32_t l_272 = (-10L);
                        uint16_t ***l_275[9][6] = {{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273}};
                        int i, j;
                        (*l_238) = (g_4[0] , (safe_rshift_func_uint8_t_u_s(((*p_88) >= (safe_rshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u((1UL < g_4[0]), ((-4L) <= ((*l_261) = p_89)))), (l_272 || ((l_276[1] = g_273) != &l_237))))), l_277)));
                    }
                    if ((*p_88))
                    { /* block id: 81 */
                        return p_92;
                    }
                    else
                    { /* block id: 83 */
                        int32_t *l_278[10] = {&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0],&l_204[1][2][0]};
                        int i;
                        (*l_264) = (*p_88);
                        if ((*l_264))
                            break;
                        --l_282;
                    }
                    for (g_98 = 0; (g_98 != 39); g_98++)
                    { /* block id: 90 */
                        int32_t ***l_293 = &l_128;
                        int32_t l_294 = 0x613677A5L;
                        (*l_238) = (((9UL <= ((g_4[3] <= (safe_rshift_func_uint8_t_u_u(((*l_263) |= (g_220 != (((p_89 = g_93) < (safe_mod_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((*l_293) = &g_81[1][1]) != (l_294 , (void*)0)), (*l_264))), ((((*l_264) < 0x316402E33435BB41LL) < 0L) | (*l_261))))) , g_220))), g_196))) && 0x9AAD8E4E223B1705LL)) != (*l_238)) || (*l_264));
                        (*l_238) |= l_262;
                        (**l_293) = p_92;
                    }
                }
                if ((((((((p_92 = p_92) != (*l_128)) != (safe_mod_func_int64_t_s_s(0xCF8998E158F53D3CLL, (((*l_264) | ((*l_234) = (safe_mul_func_int16_t_s_s(g_4[0], (&p_90 != &p_90))))) ^ ((*l_301) ^= ((void*)0 == &g_220)))))) & l_302[3]) == 247UL) >= p_89) <= 1UL))
                { /* block id: 102 */
                    uint32_t l_311[9] = {4294967287UL,0xF9160525L,0xF9160525L,4294967287UL,0xF9160525L,0xF9160525L,4294967287UL,0xF9160525L,0xF9160525L};
                    int32_t *l_314[7][10] = {{&l_279,&l_280[4],(void*)0,(void*)0,&l_280[4],&l_279,&l_280[4],(void*)0,(void*)0,&l_280[4]},{&l_279,&l_280[4],(void*)0,(void*)0,&l_280[4],&l_279,&l_280[4],&l_280[4],&l_280[4],&l_204[0][2][0]},{&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0],&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0]},{&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0],&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0]},{&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0],&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0]},{&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0],&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0]},{&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0],&l_280[0],&l_204[0][2][0],&l_280[4],&l_280[4],&l_204[0][2][0]}};
                    int i, j;
                    for (l_262 = 0; (l_262 == (-11)); l_262 = safe_sub_func_int64_t_s_s(l_262, 3))
                    { /* block id: 105 */
                        int32_t *l_305 = &l_280[3];
                        int32_t *l_306 = &l_204[2][4][0];
                        int32_t *l_307 = &l_280[3];
                        int32_t *l_308 = &l_121;
                        int32_t *l_309 = &l_280[4];
                        int32_t *l_310[8] = {&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121};
                        int i;
                        (*l_128) = (void*)0;
                        ++l_311[6];
                        return &g_3;
                    }
                    l_330[2][0][0]--;
                    return &g_3;
                }
                else
                { /* block id: 112 */
                    for (l_319 = (-20); (l_319 <= 22); l_319++)
                    { /* block id: 115 */
                        (*l_238) &= (safe_mul_func_int8_t_s_s(((void*)0 != (*g_85)), p_89));
                    }
                    if ((*p_92))
                        continue;
                }
            }
        }
        else
        { /* block id: 121 */
            uint64_t *l_343 = (void*)0;
            uint64_t *l_344 = (void*)0;
            uint64_t *l_345[6] = {&g_93,&g_93,&g_93,&g_93,&g_93,&g_93};
            int32_t *l_354 = &l_121;
            int16_t *l_363 = &l_324;
            const int8_t *l_368 = &g_369;
            const int8_t **l_367 = &l_368;
            int i;
            p_92 = (*l_128);
            (*l_354) |= (((*p_88) && ((safe_sub_func_uint8_t_u_u(0xEAL, (((safe_lshift_func_uint8_t_u_u((p_89 >= (p_89 != (safe_mul_func_int16_t_s_s(((**g_85) || (++g_93)), l_348[0])))), 0)) && 0xB919L) , l_349))) && (safe_sub_func_int64_t_s_s((safe_div_func_int32_t_s_s((0UL >= 65534UL), (*p_88))), (-1L))))) < (*l_238));
            (*l_354) &= (((safe_mod_func_int64_t_s_s((safe_lshift_func_int16_t_s_s(0x9E9AL, 8)), (safe_rshift_func_int16_t_s_s((((((safe_sub_func_int16_t_s_s(p_89, ((*l_363) = g_4[2]))) && ((safe_mul_func_int16_t_s_s(((void*)0 == g_274[2]), ((l_366[3][4][1] , 0xD9143CAAL) >= ((&g_169 == ((*l_367) = (void*)0)) >= 0x54L)))) == p_89)) < (*l_238)) && 7L) >= (*g_86)), 12)))) > p_89) | (*l_238));
        }
        return p_92;
    }
    else
    { /* block id: 130 */
        int32_t l_375 = (-1L);
        int32_t l_388 = (-1L);
        for (l_329 = 0; (l_329 < (-17)); --l_329)
        { /* block id: 133 */
            int32_t *l_372 = &l_204[2][3][1];
            int32_t *l_374 = (void*)0;
            int32_t *l_376 = &l_204[1][4][2];
            int32_t *l_377 = &l_326;
            int32_t *l_378 = &l_375;
            int32_t *l_379 = &l_375;
            int32_t *l_380 = (void*)0;
            int32_t *l_381 = &l_203;
            int32_t *l_382 = &l_203;
            int32_t *l_383 = &l_375;
            int32_t *l_384 = &l_204[0][2][0];
            int32_t *l_385 = (void*)0;
            int32_t *l_386 = (void*)0;
            int32_t *l_387[8][5][2] = {{{&l_121,&l_204[2][1][1]},{&l_204[2][0][0],(void*)0},{&l_204[3][0][0],&l_204[2][0][0]},{(void*)0,&l_204[2][1][1]},{(void*)0,&l_204[2][0][0]}},{{&l_204[3][0][0],(void*)0},{&l_204[2][0][0],&l_204[2][1][1]},{&l_121,&l_121},{&l_204[3][0][0],&l_121},{&l_121,&l_204[2][1][1]}},{{&l_204[2][0][0],(void*)0},{&l_204[3][0][0],&l_204[2][0][0]},{(void*)0,&l_204[2][1][1]},{(void*)0,&l_204[2][0][0]},{&l_204[3][0][0],(void*)0}},{{&l_204[2][0][0],&l_204[2][1][1]},{&l_121,&l_121},{&l_204[3][0][0],&l_121},{&l_121,&l_204[2][1][1]},{&l_204[2][0][0],(void*)0}},{{&l_204[3][0][0],&l_204[2][0][0]},{(void*)0,&l_204[2][1][1]},{(void*)0,&l_204[2][0][0]},{&l_204[3][0][0],(void*)0},{&l_204[2][0][0],&l_204[2][1][1]}},{{&l_121,&l_121},{&l_204[3][0][0],&l_121},{&l_121,&l_204[2][1][1]},{&l_204[2][0][0],(void*)0},{&l_204[3][0][0],&l_204[2][0][0]}},{{(void*)0,&l_204[2][1][1]},{(void*)0,&l_204[2][0][0]},{&l_204[3][0][0],(void*)0},{&l_204[2][0][0],&l_204[2][1][1]},{&l_121,&l_121}},{{&l_204[3][0][0],&l_121},{&l_121,&l_204[2][1][1]},{&l_204[2][0][0],(void*)0},{&l_204[3][0][0],&l_204[2][0][0]},{(void*)0,&l_204[2][1][1]}}};
            int i, j, k;
            --l_389;
        }
    }
    l_204[0][2][1] &= (((safe_mul_func_int16_t_s_s((0x2FL || ((p_89 | g_4[0]) > p_89)), (((safe_add_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s(((g_369 ^ (((void*)0 != g_398) < p_89)) > 18446744073709551613UL), p_89)), l_121)) && 8UL) != (*p_92)))) & p_89) < p_89);
    return p_92;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_196, "g_196", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    transparent_crc(g_222, "g_222", print_hash_value);
    transparent_crc(g_369, "g_369", print_hash_value);
    transparent_crc(g_405, "g_405", print_hash_value);
    transparent_crc(g_422, "g_422", print_hash_value);
    transparent_crc(g_437, "g_437", print_hash_value);
    transparent_crc(g_444, "g_444", print_hash_value);
    transparent_crc(g_488, "g_488", print_hash_value);
    transparent_crc(g_570, "g_570", print_hash_value);
    transparent_crc(g_575, "g_575", print_hash_value);
    transparent_crc(g_646, "g_646", print_hash_value);
    transparent_crc(g_663, "g_663", print_hash_value);
    transparent_crc(g_698, "g_698", print_hash_value);
    transparent_crc(g_709, "g_709", print_hash_value);
    transparent_crc(g_812, "g_812", print_hash_value);
    transparent_crc(g_820, "g_820", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_882[i][j][k], "g_882[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1178[i][j], "g_1178[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1321, "g_1321", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 307
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 46
breakdown:
   depth: 1, occurrence: 177
   depth: 2, occurrence: 46
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 3
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 3
   depth: 28, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 4
   depth: 36, occurrence: 1
   depth: 40, occurrence: 1
   depth: 43, occurrence: 2
   depth: 46, occurrence: 1

XXX total number of pointers: 338

XXX times a variable address is taken: 634
XXX times a pointer is dereferenced on RHS: 157
breakdown:
   depth: 1, occurrence: 125
   depth: 2, occurrence: 28
   depth: 3, occurrence: 4
XXX times a pointer is dereferenced on LHS: 123
breakdown:
   depth: 1, occurrence: 111
   depth: 2, occurrence: 7
   depth: 3, occurrence: 5
XXX times a pointer is compared with null: 24
XXX times a pointer is compared with address of another variable: 2
XXX times a pointer is compared with another pointer: 11
XXX times a pointer is qualified to be dereferenced: 7086

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 465
   level: 2, occurrence: 152
   level: 3, occurrence: 19
XXX number of pointers point to pointers: 84
XXX number of pointers point to scalars: 254
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.7
XXX average alias set size: 1.4

XXX times a non-volatile is read: 913
XXX times a non-volatile is write: 432
XXX times a volatile is read: 20
XXX    times read thru a pointer: 12
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 471
XXX percentage of non-volatile access: 98.5

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 175
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 21
   depth: 2, occurrence: 23
   depth: 3, occurrence: 21
   depth: 4, occurrence: 29
   depth: 5, occurrence: 48

XXX percentage a fresh-made variable is used: 12
XXX percentage an existing variable is used: 88
********************* end of statistics **********************/

