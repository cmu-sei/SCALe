/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3613061159
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint32_t  f0;
   signed f1 : 27;
   volatile uint32_t  f2;
   const volatile signed f3 : 24;
   int64_t  f4;
};

union U1 {
   const signed f0 : 13;
   int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static const uint8_t g_12 = 0xDCL;
static int8_t g_16 = 1L;
static int8_t g_23 = (-7L);
static int8_t *g_22 = &g_23;
static int16_t g_40 = 0xD2A7L;
static int16_t g_45 = 0x10A8L;
static int16_t *g_44 = &g_45;
static union U0 g_63 = {3UL};/* VOLATILE GLOBAL g_63 */
static uint16_t g_80[10][3][1] = {{{0x15B6L},{1UL},{0x3CECL}},{{0x23EBL},{65535UL},{65534UL}},{{65535UL},{0x23EBL},{0x3CECL}},{{1UL},{0x15B6L},{1UL}},{{0x3CECL},{0x23EBL},{65535UL}},{{65534UL},{65535UL},{0x23EBL}},{{0x3CECL},{1UL},{0x15B6L}},{{1UL},{0x3CECL},{0x23EBL}},{{65535UL},{65534UL},{65535UL}},{{0x23EBL},{0x3CECL},{1UL}}};
static union U0 g_83 = {4294967286UL};/* VOLATILE GLOBAL g_83 */
static int32_t g_87 = 0L;
static int32_t * volatile g_86[6] = {&g_87,&g_87,&g_87,&g_87,&g_87,&g_87};
static union U1 g_91 = {-6L};
static union U1 *g_93[2] = {&g_91,&g_91};
static union U1 ** volatile g_92[10][1][1] = {{{(void*)0}},{{&g_93[0]}},{{(void*)0}},{{&g_93[0]}},{{(void*)0}},{{&g_93[0]}},{{(void*)0}},{{&g_93[0]}},{{(void*)0}},{{&g_93[0]}}};
static union U1 ** volatile g_94 = &g_93[0];/* VOLATILE GLOBAL g_94 */
static union U0 *g_111 = &g_63;
static union U0 ** volatile g_110 = &g_111;/* VOLATILE GLOBAL g_110 */
static uint8_t g_117[7] = {0xF3L,0x1AL,0xF3L,0xF3L,0x1AL,0xF3L,0xF3L};
static uint8_t g_120 = 0UL;
static int32_t g_137 = (-7L);
static uint32_t g_138 = 0x9A40ACC8L;
static union U0 g_146[7] = {{8UL},{8UL},{8UL},{8UL},{8UL},{8UL},{8UL}};
static int16_t g_148 = (-1L);
static int64_t g_158 = 1L;
static const uint16_t g_176 = 0UL;
static union U0 ** volatile g_179[9][7][4] = {{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}},{{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111},{&g_111,&g_111,&g_111,&g_111}}};
static union U0 ** volatile g_180 = &g_111;/* VOLATILE GLOBAL g_180 */
static union U0 g_183 = {0xEB548387L};/* VOLATILE GLOBAL g_183 */
static int32_t *g_185 = &g_87;
static int32_t ** volatile g_184 = &g_185;/* VOLATILE GLOBAL g_184 */
static int32_t g_207 = 0x194AD0A1L;
static uint64_t g_216[4] = {0UL,0UL,0UL,0UL};
static volatile union U0 g_237 = {0x9A06C5AAL};/* VOLATILE GLOBAL g_237 */
static uint8_t *g_249 = (void*)0;
static uint8_t * volatile *g_248 = &g_249;
static union U0 g_275 = {0x43D0A16CL};/* VOLATILE GLOBAL g_275 */
static union U0 g_372 = {1UL};/* VOLATILE GLOBAL g_372 */
static union U0 g_385[4] = {{0x78AD23AAL},{0x78AD23AAL},{0x78AD23AAL},{0x78AD23AAL}};
static const volatile union U0 g_401[2][3][9] = {{{{0x43462783L},{0xE4F21E1CL},{0xE4F21E1CL},{0x43462783L},{0x36DD3460L},{0x43462783L},{0xE4F21E1CL},{0xE4F21E1CL},{0x43462783L}},{{0x9CB992B3L},{1UL},{0x784428FEL},{1UL},{0x9CB992B3L},{0x9CB992B3L},{1UL},{0x784428FEL},{1UL}},{{0xE4F21E1CL},{0x36DD3460L},{1UL},{1UL},{0x36DD3460L},{0xE4F21E1CL},{0x36DD3460L},{1UL},{1UL}}},{{{0x9CB992B3L},{0x9CB992B3L},{1UL},{0x784428FEL},{1UL},{0x9CB992B3L},{0x9CB992B3L},{1UL},{0x784428FEL}},{{0x43462783L},{0x36DD3460L},{0x43462783L},{0xE4F21E1CL},{0xE4F21E1CL},{0x43462783L},{0x36DD3460L},{0x43462783L},{0xE4F21E1CL}},{{4294967292UL},{1UL},{1UL},{4294967292UL},{3UL},{4294967292UL},{1UL},{1UL},{4294967292UL}}}};
static int32_t ** volatile g_414[3][5][9] = {{{&g_185,&g_185,&g_185,(void*)0,(void*)0,&g_185,&g_185,&g_185,&g_185},{(void*)0,(void*)0,&g_185,&g_185,&g_185,(void*)0,&g_185,&g_185,(void*)0},{&g_185,(void*)0,&g_185,(void*)0,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,(void*)0,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,(void*)0,(void*)0,(void*)0,&g_185,&g_185,&g_185,(void*)0,(void*)0}},{{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,(void*)0,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{(void*)0,(void*)0,(void*)0,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,(void*)0,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185}},{{&g_185,(void*)0,(void*)0,&g_185,&g_185,(void*)0,&g_185,(void*)0,&g_185},{&g_185,(void*)0,&g_185,&g_185,&g_185,&g_185,&g_185,(void*)0,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,(void*)0,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,(void*)0}}};
static int32_t ** volatile g_415 = &g_185;/* VOLATILE GLOBAL g_415 */
static int32_t ** volatile g_436 = &g_185;/* VOLATILE GLOBAL g_436 */
static uint16_t **g_437[3] = {(void*)0,(void*)0,(void*)0};
static int32_t g_462 = (-9L);
static int32_t ** volatile g_512 = &g_185;/* VOLATILE GLOBAL g_512 */
static volatile int64_t g_591 = (-1L);/* VOLATILE GLOBAL g_591 */
static union U0 g_664 = {0UL};/* VOLATILE GLOBAL g_664 */
static const union U0 *g_666 = (void*)0;
static int32_t g_704 = 0xC7C67BB5L;
static union U0 g_727 = {0x70FDDC16L};/* VOLATILE GLOBAL g_727 */
static union U1 ** volatile g_730 = &g_93[0];/* VOLATILE GLOBAL g_730 */
static volatile uint64_t g_733 = 18446744073709551611UL;/* VOLATILE GLOBAL g_733 */
static volatile uint64_t * const  volatile g_732 = &g_733;/* VOLATILE GLOBAL g_732 */
static volatile uint64_t * const  volatile *g_731 = &g_732;
static const volatile uint32_t *g_734 = (void*)0;
static int8_t g_766 = 0L;
static int8_t *g_767 = &g_766;
static int32_t ** volatile g_808 = &g_185;/* VOLATILE GLOBAL g_808 */
static union U0 g_843[2] = {{1UL},{1UL}};
static int32_t *g_902 = &g_462;
static int64_t g_937[3] = {1L,1L,1L};
static int32_t ** volatile g_952 = &g_902;/* VOLATILE GLOBAL g_952 */
static int32_t * volatile g_961 = &g_462;/* VOLATILE GLOBAL g_961 */
static int32_t * volatile g_978 = &g_87;/* VOLATILE GLOBAL g_978 */
static int32_t * volatile g_1047 = &g_704;/* VOLATILE GLOBAL g_1047 */
static uint32_t g_1055 = 18446744073709551615UL;
static uint32_t *g_1054 = &g_1055;
static uint32_t **g_1053 = &g_1054;
static uint32_t *** volatile g_1052 = &g_1053;/* VOLATILE GLOBAL g_1052 */
static union U0 g_1058 = {0xC5B351B9L};/* VOLATILE GLOBAL g_1058 */
static union U1 **g_1143 = &g_93[0];
static int32_t ** volatile g_1150 = &g_902;/* VOLATILE GLOBAL g_1150 */
static union U0 g_1159 = {4294967289UL};/* VOLATILE GLOBAL g_1159 */
static int32_t **g_1164 = &g_902;
static int32_t **g_1165 = &g_185;
static const uint64_t g_1171 = 0x34EBE21A7B8D75BALL;
static int32_t g_1178[2] = {3L,3L};
static int8_t g_1233[5] = {0x38L,0x38L,0x38L,0x38L,0x38L};
static int64_t *g_1329 = (void*)0;
static int64_t **g_1328 = &g_1329;
static int64_t ***g_1327[1][5][10] = {{{&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,(void*)0},{&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328},{&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328},{(void*)0,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328},{&g_1328,&g_1328,&g_1328,(void*)0,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,(void*)0}}};
static volatile union U0 g_1354 = {1UL};/* VOLATILE GLOBAL g_1354 */
static uint64_t *g_1368 = (void*)0;
static uint64_t **g_1367 = &g_1368;
static volatile union U0 g_1388 = {0x9F33A209L};/* VOLATILE GLOBAL g_1388 */
static int32_t g_1447 = 0L;
static union U0 ** volatile g_1474 = &g_111;/* VOLATILE GLOBAL g_1474 */
static int32_t *g_1510 = &g_87;
static int32_t ** volatile g_1509[1] = {&g_1510};
static int32_t ** volatile g_1511 = &g_1510;/* VOLATILE GLOBAL g_1511 */
static int16_t **g_1541 = (void*)0;
static volatile int32_t g_1557 = 1L;/* VOLATILE GLOBAL g_1557 */
static volatile int32_t *g_1556 = &g_1557;
static volatile int32_t ** const g_1555 = &g_1556;
static uint16_t g_1626 = 0x63D2L;
static volatile union U0 g_1696 = {8UL};/* VOLATILE GLOBAL g_1696 */
static const volatile union U0 g_1712 = {8UL};/* VOLATILE GLOBAL g_1712 */
static volatile int16_t g_1719 = 1L;/* VOLATILE GLOBAL g_1719 */
static int32_t * volatile g_1812 = &g_87;/* VOLATILE GLOBAL g_1812 */
static union U0 g_1874 = {0x7C86554BL};/* VOLATILE GLOBAL g_1874 */
static int8_t * volatile * volatile g_1887 = &g_22;/* VOLATILE GLOBAL g_1887 */
static int8_t * volatile * volatile * volatile g_1886 = &g_1887;/* VOLATILE GLOBAL g_1886 */
static int32_t g_1892 = (-1L);
static uint64_t ***g_1899 = &g_1367;
static volatile union U0 g_1935 = {4UL};/* VOLATILE GLOBAL g_1935 */
static int64_t **g_1946[6][1] = {{&g_1329},{(void*)0},{&g_1329},{(void*)0},{&g_1329},{(void*)0}};
static int64_t *** const g_1945 = &g_1946[2][0];
static int64_t *** const *g_1944 = &g_1945;
static volatile union U0 g_1964[5][10][5] = {{{{0x8204B795L},{5UL},{6UL},{0x74B4AE5CL},{0x82791F99L}},{{0x9E2EBDE7L},{0UL},{5UL},{0x9E2EBDE7L},{4294967286UL}},{{0x8204B795L},{4294967292UL},{0xEBF416B9L},{0UL},{0x75EAFF39L}},{{0UL},{0x777C08F2L},{0x7616D8FAL},{4294967292UL},{1UL}},{{0UL},{4294967286UL},{0x75EAFF39L},{0x9BD9E3C9L},{0UL}},{{0UL},{6UL},{2UL},{0UL},{5UL}},{{4294967288UL},{0x74B4AE5CL},{4294967295UL},{0x74B4AE5CL},{4294967288UL}},{{0x74BB47CCL},{0x747970D9L},{0x7616D8FAL},{0xF15284E3L},{2UL}},{{0x639094E9L},{7UL},{0x82E1A70EL},{0x6E0A0103L},{4294967289UL}},{{1UL},{0x697E51A3L},{0UL},{0x747970D9L},{2UL}}},{{{6UL},{0x6E0A0103L},{7UL},{4294967295UL},{4294967292UL}},{{2UL},{0xC2917B86L},{4294967286UL},{5UL},{0xC2917B86L}},{{4294967293UL},{0xEBF416B9L},{0x74B4AE5CL},{4294967292UL},{0x830AAAE6L}},{{4UL},{0x4B0E6DFCL},{0xF15284E3L},{0x328392A9L},{1UL}},{{0UL},{0x82E1A70EL},{0x82E1A70EL},{0UL},{4UL}},{{0x697E51A3L},{5UL},{1UL},{6UL},{4294967291UL}},{{0x82E1A70EL},{0x9BD9E3C9L},{1UL},{7UL},{4294967286UL}},{{2UL},{1UL},{0x328392A9L},{6UL},{0x7616D8FAL}},{{4294967289UL},{0xBE23B9E6L},{0x8204B795L},{0UL},{4294967293UL}},{{0xF15284E3L},{4294967291UL},{1UL},{0x328392A9L},{1UL}}},{{{0x639094E9L},{4294967295UL},{4294967295UL},{4294967292UL},{7UL}},{{6UL},{2UL},{0UL},{5UL},{5UL}},{{0xAC42E8A7L},{0x9BD9E3C9L},{0xAC42E8A7L},{4294967295UL},{0x75EAFF39L}},{{4294967295UL},{4294967286UL},{1UL},{0x747970D9L},{0xF15284E3L}},{{0x75EAFF39L},{4294967293UL},{0xFD16AC4BL},{0x6E0A0103L},{4294967293UL}},{{0xC2917B86L},{0x4B0E6DFCL},{1UL},{0xF15284E3L},{0UL}},{{0x9BD9E3C9L},{1UL},{0xAC42E8A7L},{0xBD86FA52L},{1UL}},{{0UL},{0x9E2EBDE7L},{0UL},{0UL},{4294967291UL}},{{4294967293UL},{0x6E0A0103L},{4294967295UL},{0xAEAB9A29L},{0xBD86FA52L}},{{0x9E2EBDE7L},{4UL},{1UL},{2UL},{1UL}}},{{{0x75EAFF39L},{0x75EAFF39L},{0x8204B795L},{0x639094E9L},{0x830AAAE6L}},{{0UL},{0x747970D9L},{0x328392A9L},{0x967B942DL},{0x9E2EBDE7L}},{{4294967292UL},{4UL},{1UL},{0xBD86FA52L},{0xAC42E8A7L}},{{6UL},{0x747970D9L},{1UL},{1UL},{2UL}},{{0xAEAB9A29L},{0x75EAFF39L},{0x82E1A70EL},{4294967289UL},{0x6E0A0103L}},{{1UL},{4UL},{0xF15284E3L},{0x747970D9L},{1UL}},{{4294967289UL},{0x6E0A0103L},{0x74B4AE5CL},{0xBE23B9E6L},{4294967292UL}},{{1UL},{0x9E2EBDE7L},{4294967286UL},{4294967286UL},{0x9E2EBDE7L}},{{4294967293UL},{1UL},{7UL},{4294967292UL},{4294967295UL}},{{0x697E51A3L},{0x4B0E6DFCL},{0UL},{4294967291UL},{1UL}}},{{{4294967295UL},{4294967293UL},{0x82E1A70EL},{4294967295UL},{0xBD86FA52L}},{{0x697E51A3L},{4294967286UL},{0x7616D8FAL},{6UL},{0x328392A9L}},{{4294967293UL},{0x9BD9E3C9L},{0x54C0C65DL},{0x75EAFF39L},{4294967286UL}},{{1UL},{2UL},{0x328392A9L},{0x74BB47CCL},{0UL}},{{4294967289UL},{4294967295UL},{4UL},{0UL},{0x82E1A70EL}},{{1UL},{4UL},{4294967295UL},{4UL},{4294967286UL}},{{5UL},{1UL},{0x54C0C65DL},{0xFD16AC4BL},{4UL}},{{0x2F3B8B16L},{0x777C08F2L},{4294967292UL},{0xC2917B86L},{0UL}},{{4294967289UL},{0xAEAB9A29L},{0x6E0A0103L},{1UL},{4UL}},{{0UL},{0xC2917B86L},{0x777C08F2L},{4294967295UL},{4294967286UL}}}};
static union U0 g_1967 = {0xDF39EABEL};/* VOLATILE GLOBAL g_1967 */
static union U0 ** volatile g_2006 = &g_111;/* VOLATILE GLOBAL g_2006 */
static union U1 g_2064 = {-1L};
static volatile union U0 g_2068 = {4294967295UL};/* VOLATILE GLOBAL g_2068 */
static int8_t g_2138 = 0x47L;
static volatile union U0 g_2173[9] = {{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL},{0x06B7F59CL}};
static volatile union U0 g_2175 = {9UL};/* VOLATILE GLOBAL g_2175 */
static union U1 *** volatile g_2184 = &g_1143;/* VOLATILE GLOBAL g_2184 */
static union U0 g_2203 = {4294967287UL};/* VOLATILE GLOBAL g_2203 */
static union U0 g_2256 = {0x9656C558L};/* VOLATILE GLOBAL g_2256 */
static volatile union U0 g_2339 = {1UL};/* VOLATILE GLOBAL g_2339 */
static union U0 g_2364 = {0x3BEFBD48L};/* VOLATILE GLOBAL g_2364 */
static volatile union U0 g_2411 = {0x2F149E76L};/* VOLATILE GLOBAL g_2411 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static union U1  func_2(int32_t  p_3, uint8_t  p_4, uint8_t  p_5, int32_t  p_6, union U1  p_7);
static int32_t  func_8(const int8_t  p_9, int8_t  p_10, const union U1  p_11);
static const union U1  func_17(int8_t * p_18, uint8_t  p_19, int16_t  p_20, int8_t  p_21);
static uint32_t  func_24(int8_t * p_25, union U1  p_26, int32_t  p_27);
static uint32_t  func_30(uint64_t  p_31, int8_t * p_32);
static int16_t  func_41(int16_t * p_42, uint32_t  p_43);
static int16_t  func_47(int8_t * p_48, int16_t * const  p_49);
static int8_t * func_50(uint8_t  p_51, int8_t * p_52, int16_t * p_53, int16_t * p_54, int16_t * p_55);
static uint8_t  func_56(uint64_t  p_57, int16_t * p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_16 g_22 g_44 g_23 g_63.f0 g_45 g_83.f4 g_87 g_94 g_63.f4 g_184 g_63 g_385.f1 g_591 g_180 g_111 g_80 g_91 g_385.f3 g_275.f3 g_158 g_237.f2 g_437 g_462 g_176 g_704 g_372.f1 g_93 g_512 g_185 g_730 g_731 g_734 g_183.f0 g_436 g_183.f1 g_207 g_766 g_148 g_808 g_732 g_733 g_146.f1 g_83.f1 g_843 g_216 g_120 g_664.f0 g_138 g_183.f2 g_137 g_937 g_952 g_961 g_978 g_902 g_275.f0 g_727.f1 g_1054 g_1055 g_843.f0 g_1150 g_1159 g_1171 g_1164 g_1178 g_183.f4 g_372.f0 g_1233 g_1047 g_843.f3 g_843.f2 g_1327 g_117 g_1354 g_1053 g_1367 g_1388 g_1052 g_1447 g_1474 g_1511 g_401.f3 g_275.f2 g_664.f1 g_1555 g_1510 g_1143 g_401.f0 g_1165 g_1626 g_83.f0 g_1354.f3 g_1696 g_1712 g_727.f3 g_1812 g_1556 g_1557 g_1712.f2 g_1874 g_1886 g_1892 g_146.f0 g_1935 g_248 g_249 g_1964 g_1967 g_2006 g_843.f1 g_237.f0 g_2068 g_2138 g_1887 g_2173 g_2175 g_2184 g_2203 g_2203.f0 g_1058.f0 g_2256 g_2339 g_1368 g_2364 g_2411 g_237.f1 g_91.f1
 * writes: g_16 g_40 g_63.f0 g_80 g_83.f4 g_87 g_93 g_63.f4 g_185 g_117 g_45 g_23 g_158 g_462 g_666 g_183.f0 g_767 g_148 g_216 g_120 g_91.f1 g_83.f0 g_902 g_207 g_704 g_275.f0 g_138 g_1143 g_275.f4 g_1164 g_1165 g_664.f0 g_1178 g_183.f4 g_372.f0 g_1159.f4 g_766 g_1055 g_137 g_937 g_727.f4 g_1327 g_385.f0 g_111 g_1053 g_1510 g_1541 g_1368 g_1626 g_664.f4 g_1058.f0 g_1874.f4 g_1899 g_1944 g_727.f0 g_437 g_2138 g_2064.f1 g_2339.f4
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_14 = 0x38B6B0E1L;
    int8_t *l_15 = &g_16;
    int16_t *l_39 = &g_40;
    int32_t l_1622 = 0L;
    union U1 l_1623 = {0x1A115B70L};
    int32_t *l_2425 = &g_1178[1];
    l_1622 = ((func_2(func_8(g_12, ((*l_15) ^= (safe_unary_minus_func_uint32_t_u(l_14))), func_17(g_22, l_14, (func_24(((safe_mul_func_int8_t_s_s((((l_14 <= (g_12 >= ((func_30((safe_sub_func_uint32_t_u_u((safe_div_func_int32_t_s_s(0x92085949L, (safe_mul_func_int16_t_s_s(((*l_39) = g_12), func_41(g_44, g_23))))), 1UL)), &g_766) && g_401[0][2][5].f0) , l_14))) , 0xEBAD7A8E0A9CCF87LL) >= l_14), l_1622)) , (void*)0), l_1623, l_14) && g_1626), l_1622)), l_1623.f0, l_1622, l_1622, l_1623) , (*g_732)) && l_1623.f0);
    for (g_91.f1 = 0; (g_91.f1 > (-1)); g_91.f1 = safe_sub_func_uint64_t_u_u(g_91.f1, 2))
    { /* block id: 1109 */
        int8_t l_2424 = 0xBCL;
        return l_2424;
    }
    (*l_2425) ^= ((l_1623.f0 || 0xDAL) & l_1623.f0);
    return (*l_2425);
}


/* ------------------------------------------ */
/* 
 * reads : g_978 g_87 g_2203 g_44 g_22 g_2203.f0 g_1047 g_704 g_727.f1 g_1164 g_1886 g_1887 g_23 g_45 g_2138 g_117 g_2256 g_138 g_1052 g_1053 g_1054 g_1055 g_148 g_80 g_2339 g_1367 g_1368 g_2364 g_1165 g_1555 g_1556 g_2411 g_83.f0 g_237.f1 g_462 g_1058.f0
 * writes: g_45 g_40 g_23 g_462 g_937 g_185 g_902 g_1058.f0 g_117 g_2138 g_80 g_148 g_1178 g_2064.f1 g_2339.f4 g_216 g_120 g_87 g_83.f0
 */
static union U1  func_2(int32_t  p_3, uint8_t  p_4, uint8_t  p_5, int32_t  p_6, union U1  p_7)
{ /* block id: 992 */
    int32_t l_2195 = 0xE3B3AB69L;
    int32_t l_2200 = 1L;
    int64_t **l_2201 = &g_1329;
    int64_t **l_2202 = &g_1329;
    int16_t *l_2204 = &g_40;
    int32_t l_2206 = 0x29C787D0L;
    int32_t *l_2229 = (void*)0;
    int32_t * const * const l_2228 = &l_2229;
    int32_t l_2319 = 0xC3858A5CL;
    int32_t l_2320 = 0xE8B9DAA0L;
    int32_t l_2321 = 0xCCA9DCD8L;
    int32_t l_2322 = (-7L);
    int32_t l_2323 = (-2L);
    int32_t l_2324 = 4L;
    uint64_t ***l_2342[1][2][9] = {{{&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367},{&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367,&g_1367}}};
    union U1 l_2359 = {2L};
    int32_t l_2370 = 0x0B4139D4L;
    int i, j, k;
lbl_2387:
    p_6 = (*g_978);
    if (((safe_rshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((safe_rshift_func_int8_t_s_u((safe_mod_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(l_2195, (safe_add_func_int32_t_s_s((((*g_22) = ((-6L) && ((safe_add_func_uint32_t_u_u(((((*l_2204) = ((*g_44) = (((l_2200 = l_2195) <= (l_2201 != (l_2202 = (void*)0))) | (g_2203 , p_4)))) >= ((l_2206 ^= ((((!(((((&p_4 != (void*)0) != p_6) == 0x2AF6ACCBL) | l_2195) > 1UL)) > p_6) > l_2195) < 0x029AL)) < p_4)) >= (-5L)), l_2195)) > 1L))) < p_3), g_2203.f0)))), 5L)), 3)), l_2195)), 7)) , 1L))
    { /* block id: 1000 */
        union U1 l_2207 = {-1L};
        return l_2207;
    }
    else
    { /* block id: 1002 */
        int64_t l_2219 = 0xFA89D4EF6E0B3425LL;
        int32_t **l_2248 = &l_2229;
        int32_t ***l_2247 = &l_2248;
        union U1 l_2253 = {0L};
        int32_t l_2268 = 0x3964C9BEL;
        int32_t l_2281[2];
        int16_t l_2313 = 5L;
        const uint64_t *l_2353[6];
        uint64_t l_2354 = 0x289D6520171E4438LL;
        uint32_t l_2368 = 4294967295UL;
        uint16_t l_2420 = 0UL;
        int i;
        for (i = 0; i < 2; i++)
            l_2281[i] = 0x615698E9L;
        for (i = 0; i < 6; i++)
            l_2353[i] = &g_1171;
        for (g_462 = 0; (g_462 != 5); ++g_462)
        { /* block id: 1005 */
            int16_t l_2214 = (-1L);
            int64_t *l_2215 = (void*)0;
            int64_t *l_2216 = &g_937[2];
            int32_t l_2280[9];
            uint64_t l_2282 = 0UL;
            int64_t l_2297 = 7L;
            uint64_t l_2326[3][2] = {{0xB17CE5BA4C46D6E6LL,0xB17CE5BA4C46D6E6LL},{0xB17CE5BA4C46D6E6LL,0xB17CE5BA4C46D6E6LL},{0xB17CE5BA4C46D6E6LL,0xB17CE5BA4C46D6E6LL}};
            uint64_t ***l_2343 = &g_1367;
            uint16_t *l_2350 = &g_80[0][1][0];
            int32_t l_2365[6][1] = {{0xA0A39687L},{(-9L)},{0xA0A39687L},{0xA0A39687L},{(-9L)},{0xA0A39687L}};
            uint32_t *l_2405 = &g_83.f0;
            int32_t l_2421 = 0L;
            int i, j;
            for (i = 0; i < 9; i++)
                l_2280[i] = 0xE11C813AL;
            if ((l_2206 = (p_6 = (&p_6 != ((safe_mul_func_uint8_t_u_u(0xD7L, (p_3 > (safe_div_func_int64_t_s_s(l_2214, (p_3 , ((*l_2216) = 0x000E43954C8BA4E7LL))))))) , (p_4 , &p_6))))))
            { /* block id: 1009 */
                int32_t **l_2230 = &l_2229;
                int32_t l_2249 = 0L;
                uint16_t l_2264[2][2][6] = {{{0UL,65526UL,65526UL,0UL,0UL,65526UL},{0UL,0UL,65526UL,65526UL,0UL,0UL}},{{0UL,65526UL,65526UL,0UL,0UL,65526UL},{0UL,0UL,65526UL,65526UL,0UL,0UL}}};
                int32_t l_2314 = 0xFCFF4C78L;
                int32_t l_2325 = 0x492D9BD5L;
                int i, j, k;
                if ((*g_1047))
                { /* block id: 1010 */
                    (*g_1164) = ((p_5 == g_727.f1) , (void*)0);
                }
                else
                { /* block id: 1012 */
                    int64_t l_2237 = (-1L);
                    for (g_1058.f0 = 0; (g_1058.f0 <= 0); g_1058.f0 += 1)
                    { /* block id: 1015 */
                        uint16_t l_2250 = 65531UL;
                        uint8_t *l_2251 = &g_117[6];
                        int32_t *l_2252 = &l_2200;
                        (*l_2252) = ((safe_lshift_func_uint16_t_u_s(l_2219, ((***g_1886) ^ ((*l_2251) = ((safe_sub_func_int32_t_s_s(((((safe_sub_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((*g_44) = (0xD58C6B626EC3C3C3LL < ((safe_mul_func_uint16_t_u_u((((p_7 , l_2228) == l_2230) , (safe_lshift_func_int16_t_s_u((safe_div_func_int16_t_s_s(((safe_rshift_func_int8_t_s_u(l_2237, ((0x6DB5438EL || ((((((safe_unary_minus_func_int32_t_s((p_6 = ((safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((safe_add_func_int32_t_s_s((((l_2247 == &g_1555) , (void*)0) != &g_1327[0][3][0]), 1UL)), 7)), p_7.f0)) , 0L)))) <= l_2249) <= p_4) , (-8L)) <= l_2249) < 8L)) && l_2250))) ^ p_5), (*g_44))), l_2206))), 0L)) | p_5))), 1L)), l_2250)) == 0x6FL) | 1L) , p_6), 0x614C9253L)) && (*g_22)))))) , 0x8982E11DL);
                        if (l_2195)
                            break;
                        if (l_2214)
                            break;
                        return l_2253;
                    }
                }
                for (g_2138 = 0; (g_2138 <= 0); g_2138 += 1)
                { /* block id: 1027 */
                    uint16_t *l_2263 = &g_80[7][2][0];
                    int32_t l_2279 = 7L;
                    int32_t **l_2291 = (void*)0;
                    int32_t *l_2316 = &l_2280[7];
                    int32_t *l_2317 = (void*)0;
                    int32_t *l_2318[9][7] = {{(void*)0,&l_2279,&g_1178[0],&g_1178[0],(void*)0,&g_1178[0],&l_2281[0]},{&l_2280[7],&l_2280[7],&g_87,&l_2281[0],&g_87,&l_2280[7],&l_2280[7]},{&g_1178[0],&l_2280[7],&l_2268,&l_2280[7],&l_2200,&l_2280[7],&g_87},{&g_87,&l_2279,&g_87,&l_2268,&l_2281[0],&g_1178[1],&l_2280[4]},{&g_1178[0],&l_2280[4],&l_2268,&g_87,&l_2280[7],&g_87,&l_2268},{&l_2200,&l_2200,&g_87,&g_87,&g_1178[1],(void*)0,(void*)0},{&l_2280[7],&g_1178[1],&g_1178[0],&l_2268,&g_87,&l_2280[4],&l_2279},{&g_1178[0],(void*)0,(void*)0,&l_2280[7],&g_1178[1],&l_2281[1],&g_1178[1]},{&l_2281[0],&g_87,&g_87,&l_2281[0],&l_2280[7],&l_2281[1],&g_87}};
                    int i, j;
                    if (((safe_add_func_int64_t_s_s(g_117[(g_2138 + 6)], ((g_2256 , 9L) && p_6))) , (safe_mul_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(((safe_add_func_uint16_t_u_u(((*l_2263) = (p_6 > p_3)), ((((l_2200 == l_2264[1][1][4]) ^ (safe_div_func_uint32_t_u_u((l_2206 , g_138), 0x1F0907C7L))) ^ l_2206) && 0x6779D512E7B20E02LL))) , p_3), 0xABL)), g_117[(g_2138 + 6)]))))
                    { /* block id: 1029 */
                        int32_t *l_2267 = (void*)0;
                        (*g_1164) = (void*)0;
                        l_2249 &= 0xC9DAF693L;
                    }
                    else
                    { /* block id: 1032 */
                        int32_t *l_2269 = &l_2249;
                        int32_t *l_2270 = &g_1178[1];
                        int32_t *l_2271 = &l_2268;
                        int32_t *l_2272 = &l_2206;
                        int32_t *l_2273 = (void*)0;
                        int32_t *l_2274 = &g_87;
                        int32_t *l_2275 = &l_2268;
                        int32_t *l_2276 = &g_1178[1];
                        int32_t *l_2277 = &l_2268;
                        int32_t *l_2278[1];
                        uint16_t **l_2309 = &l_2263;
                        int16_t *l_2315 = &l_2214;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_2278[i] = &g_704;
                        ++l_2282;
                        (*l_2275) ^= (((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u(4294967295UL, (0xE00B1578L < l_2264[1][1][4]))) , ((p_5 , l_2291) == &g_185)), 5)), ((~(((safe_mul_func_uint16_t_u_u(((***g_1052) , (safe_lshift_func_int8_t_s_s((255UL ^ l_2297), p_3))), p_7.f0)) , p_3) || l_2281[0])) > 9L))) >= l_2206) >= 0xB0E4L);
                        (*l_2276) = (safe_div_func_int64_t_s_s(l_2297, (((*l_2315) ^= (g_148 |= ((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((*l_2269), 2)), ((((!l_2281[0]) < (l_2314 = (safe_add_func_int32_t_s_s(((safe_sub_func_uint16_t_u_u((((void*)0 == l_2309) , (((l_2264[1][0][4] != (((*g_22) = (((safe_mul_func_int16_t_s_s(((void*)0 == &l_2309), ((*l_2204) = ((*g_44) |= (+((p_3 || 1L) < l_2313)))))) > l_2280[5]) > 0x91B9L)) && 6L)) & 7UL) , (*l_2272))), l_2280[7])) || 0x0B95L), l_2282)))) || 0L) | l_2264[1][1][4]))) , (-9L)))) || p_6)));
                    }
                    l_2326[0][0]--;
                    for (g_2064.f1 = 0; (g_2064.f1 <= 0); g_2064.f1 += 1)
                    { /* block id: 1046 */
                        union U1 l_2329 = {-1L};
                        int i, j, k;
                        (*g_1164) = (l_2329 , &p_6);
                        if (g_80[(g_2138 + 2)][(g_2138 + 2)][g_2138])
                            break;
                    }
                    p_6 |= l_2281[0];
                    for (l_2319 = 0; (l_2319 <= 0); l_2319 += 1)
                    { /* block id: 1053 */
                        return p_7;
                    }
                }
                if (l_2200)
                    continue;
                (*g_1164) = &l_2280[2];
            }
            else
            { /* block id: 1059 */
                int8_t l_2332 = 0xF9L;
                int32_t l_2336 = 0xF3065D15L;
                for (l_2268 = (-5); (l_2268 > 27); l_2268++)
                { /* block id: 1062 */
                    uint32_t l_2333 = 0xFA423F30L;
                    l_2333--;
                    l_2336 = p_3;
                }
                return p_7;
            }
            if (((safe_add_func_int64_t_s_s(0x04004CF2F89DD736LL, (((p_7.f0 != (g_2339 , (safe_mul_func_uint16_t_u_u((0xABED7521C9854DEELL | (((l_2343 = l_2342[0][1][8]) != (((((safe_mul_func_uint8_t_u_u(((p_3 && ((safe_sub_func_uint64_t_u_u((l_2281[0] = (safe_mod_func_int16_t_s_s(l_2319, ((*l_2350)--)))), ((*g_1367) == l_2353[0]))) == p_4)) > l_2200), l_2219)) | p_4) == 65535UL) || l_2354) , (void*)0)) & p_3)), p_7.f0)))) , 0xCA596D05B676D428LL) , p_7.f0))) ^ l_2320))
            { /* block id: 1071 */
                for (g_2339.f4 = 0; g_2339.f4 < 4; g_2339.f4 += 1)
                {
                    g_216[g_2339.f4] = 0xCE13FDC67D1AF38DLL;
                }
            }
            else
            { /* block id: 1073 */
                int16_t l_2360 = 0x9EB9L;
                int16_t l_2366 = 1L;
                uint8_t *l_2367 = &g_120;
                union U1 l_2369 = {0x9E7239F3L};
                int32_t l_2386[7][6] = {{0xCADD0262L,8L,7L,0x89F4A61CL,7L,(-9L)},{7L,2L,(-2L),4L,7L,4L},{0L,8L,0L,0x3A9C8974L,5L,2L},{7L,7L,0x60986147L,(-9L),0xCADD0262L,5L},{0x89F4A61CL,4L,0x3A9C8974L,(-9L),(-9L),0x3A9C8974L},{7L,7L,8L,0x3A9C8974L,0x60986147L,0L},{0L,7L,7L,4L,7L,4L}};
                int i, j;
                if (((((safe_mod_func_uint32_t_u_u(((((safe_mul_func_uint16_t_u_u(l_2322, ((l_2359 , l_2360) & (~(safe_add_func_uint64_t_u_u((l_2281[0] == (l_2268 = (0UL >= ((g_2364 , ((((*l_2367) = (p_3 == ((((((((((p_6 && ((void*)0 == l_2204)) , p_7.f0) > 0UL) > (**g_1887)) , 0x95L) <= l_2253.f0) < p_3) ^ l_2365[0][0]) < 18446744073709551615UL) < l_2366))) || p_6) && l_2214)) == p_3)))), l_2368)))))) >= p_3) , l_2219) == 0x5119383977E41F34LL), l_2297)) > 0x7754L) , l_2326[0][0]) | p_7.f0))
                { /* block id: 1076 */
                    return l_2369;
                }
                else
                { /* block id: 1078 */
                    int32_t l_2376 = 0L;
                    int32_t l_2406 = 0x69D9D2A7L;
                    l_2386[3][5] = (l_2280[7] = (l_2370 , (safe_add_func_uint64_t_u_u((((!(l_2369.f0 ^ l_2282)) || ((*l_2216) = (safe_add_func_int16_t_s_s(0x2835L, ((l_2376 & ((((safe_rshift_func_uint16_t_u_u(l_2365[0][0], 14)) != (safe_rshift_func_int8_t_s_u((safe_mod_func_uint32_t_u_u(((*g_44) && l_2280[7]), (+(safe_div_func_int16_t_s_s(0x690AL, l_2313))))), 2))) , p_7.f0) < 0x373AL)) ^ 1UL))))) >= l_2297), p_3))));
                    if (g_23)
                        goto lbl_2387;
                    for (l_2369.f1 = 0; (l_2369.f1 == 11); l_2369.f1 = safe_add_func_uint16_t_u_u(l_2369.f1, 1))
                    { /* block id: 1085 */
                        int32_t l_2404 = 0x82C08F44L;
                        l_2406 &= (safe_mod_func_int8_t_s_s((((p_4 != (p_6 = (safe_rshift_func_uint8_t_u_s(0UL, ((*g_22) ^= ((l_2359 , 1L) <= (safe_mod_func_int64_t_s_s(((((safe_rshift_func_int16_t_s_s(((l_2365[0][0] , (safe_rshift_func_uint8_t_u_s(p_6, (((safe_add_func_uint16_t_u_u(l_2404, l_2386[6][4])) ^ l_2404) , p_7.f0)))) , p_5), p_7.f0)) , (void*)0) != l_2405) <= l_2376), 0xD9E7639E725EF1F0LL)))))))) && (-1L)) == p_3), l_2195));
                        if (l_2320)
                            continue;
                        (*g_1165) = &p_6;
                        if (p_5)
                            break;
                    }
                }
            }
            for (g_87 = 0; (g_87 >= 6); g_87++)
            { /* block id: 1097 */
                int32_t l_2414[10][10][2] = {{{0x19682825L,3L},{1L,3L},{3L,0xE5D7D659L},{(-1L),1L},{(-9L),0x19682825L},{0x382630C0L,(-5L)},{0x0B619A2DL,(-5L)},{0x382630C0L,0x19682825L},{(-9L),1L},{(-1L),0xE5D7D659L}},{{3L,3L},{1L,3L},{0x19682825L,0x0B619A2DL},{0x6AD0BDDAL,1L},{3L,0x6AD0BDDAL},{9L,4L},{9L,0x6AD0BDDAL},{3L,1L},{0x6AD0BDDAL,0x0B619A2DL},{0x19682825L,3L}},{{1L,3L},{3L,0xE5D7D659L},{(-1L),1L},{(-9L),0x19682825L},{0x382630C0L,(-5L)},{0x0B619A2DL,(-5L)},{0x382630C0L,0x19682825L},{(-9L),1L},{(-1L),0xE5D7D659L},{3L,3L}},{{1L,3L},{0x19682825L,0x0B619A2DL},{0x6AD0BDDAL,1L},{3L,0x6AD0BDDAL},{9L,4L},{9L,0x6AD0BDDAL},{3L,1L},{0x6AD0BDDAL,0x0B619A2DL},{0x19682825L,3L},{1L,3L}},{{3L,0xE5D7D659L},{(-1L),1L},{(-9L),0x19682825L},{0x382630C0L,(-5L)},{0x0B619A2DL,(-5L)},{0x382630C0L,0x19682825L},{(-9L),1L},{(-1L),0xE5D7D659L},{3L,3L},{1L,3L}},{{0x19682825L,0x0B619A2DL},{0x6AD0BDDAL,1L},{3L,0x6AD0BDDAL},{9L,4L},{9L,0x6AD0BDDAL},{3L,1L},{0x6AD0BDDAL,0x0B619A2DL},{0x19682825L,3L},{1L,3L},{3L,0xE5D7D659L}},{{(-1L),1L},{(-9L),0x19682825L},{0x382630C0L,(-5L)},{0x0B619A2DL,(-5L)},{0x382630C0L,0x19682825L},{(-9L),1L},{(-1L),0xE5D7D659L},{3L,3L},{1L,3L},{0x19682825L,0x0B619A2DL}},{{0x6AD0BDDAL,1L},{3L,0x6AD0BDDAL},{9L,4L},{9L,0x6AD0BDDAL},{3L,1L},{0x6AD0BDDAL,0x0B619A2DL},{0x19682825L,3L},{1L,3L},{3L,0xE5D7D659L},{(-1L),1L}},{{(-9L),0x19682825L},{0x382630C0L,(-5L)},{0x0B619A2DL,(-5L)},{0x382630C0L,0x19682825L},{(-9L),1L},{(-1L),0xE5D7D659L},{3L,3L},{1L,3L},{0x19682825L,0x0B619A2DL},{0x6AD0BDDAL,1L}},{{3L,0x6AD0BDDAL},{9L,4L},{9L,0x6AD0BDDAL},{3L,1L},{0x6AD0BDDAL,0xE5D7D659L},{1L,(-5L)},{1L,9L},{9L,3L},{0x19682825L,4L},{4L,1L}}};
                int i, j, k;
                l_2421 = ((4294967295UL && ((*g_1555) == (**l_2247))) == (safe_lshift_func_uint16_t_u_s(((l_2323 = (g_2411 , (safe_mul_func_uint8_t_u_u((l_2280[4] = (p_3 & l_2414[3][6][1])), ((safe_lshift_func_int16_t_s_u(0x6E29L, (((*l_2405) &= (safe_rshift_func_int16_t_s_s(((p_3 <= (((!(l_2420 >= l_2365[0][0])) <= l_2282) >= p_7.f0)) ^ 0x45L), p_5))) < g_237.f1))) < p_4))))) | (-4L)), l_2282)));
            }
        }
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_2184 g_1555 g_1556 g_1557
 * writes: g_1143
 */
static int32_t  func_8(const int8_t  p_9, int8_t  p_10, const union U1  p_11)
{ /* block id: 989 */
    union U1 **l_2183[2];
    int i;
    for (i = 0; i < 2; i++)
        l_2183[i] = &g_93[0];
    (*g_2184) = l_2183[1];
    return (**g_1555);
}


/* ------------------------------------------ */
/* 
 * reads : g_83.f0 g_216 g_1367 g_731 g_732 g_275.f0 g_44 g_45 g_1354.f3 g_23 g_1696 g_1712 g_462 g_22 g_1047 g_704 g_237.f2 g_120 g_978 g_117 g_727.f3 g_1626 g_733 g_1812 g_1555 g_1556 g_1557 g_1164 g_1712.f2 g_766 g_1874 g_1886 g_1892 g_146.f0 g_1935 g_1474 g_111 g_87 g_248 g_249 g_1143 g_1964 g_1967 g_1165 g_185 g_2006 g_843.f1 g_237.f0 g_1052 g_1053 g_2068 g_80 g_91 g_1178 g_2138 g_1887 g_2173 g_2175
 * writes: g_83.f0 g_216 g_1368 g_1626 g_45 g_664.f4 g_87 g_462 g_23 g_120 g_767 g_63.f4 g_117 g_1143 g_1058.f0 g_185 g_902 g_766 g_80 g_1874.f4 g_1899 g_1944 g_727.f0 g_93 g_704 g_111 g_138 g_137 g_437
 */
static const union U1  func_17(int8_t * p_18, uint8_t  p_19, int16_t  p_20, int8_t  p_21)
{ /* block id: 772 */
    int32_t l_1627 = 0x5D2474FCL;
    int32_t l_1628 = 0x5D6B019EL;
    const union U0 **l_1669 = (void*)0;
    int16_t ***l_1707[5][6][7] = {{{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,(void*)0,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,(void*)0,&g_1541}},{{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,(void*)0,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541},{(void*)0,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,(void*)0}},{{&g_1541,&g_1541,(void*)0,&g_1541,(void*)0,&g_1541,(void*)0},{&g_1541,&g_1541,&g_1541,(void*)0,(void*)0,&g_1541,&g_1541},{(void*)0,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541,&g_1541},{(void*)0,&g_1541,(void*)0,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541}},{{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{(void*)0,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{(void*)0,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,(void*)0,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541}},{{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,(void*)0,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,(void*)0,&g_1541,(void*)0,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541,(void*)0,(void*)0}}};
    int32_t l_1717 = 1L;
    int32_t l_1718[6][2] = {{0x66709D67L,(-1L)},{(-1L),0xE59FA813L},{(-1L),0xE59FA813L},{(-1L),(-1L)},{0x66709D67L,0x66709D67L},{0x66709D67L,(-1L)}};
    const uint16_t *l_1841 = &g_80[0][1][0];
    uint16_t l_1842 = 1UL;
    int8_t * const *l_1883 = &g_22;
    int8_t * const **l_1882[6][5] = {{&l_1883,(void*)0,&l_1883,&l_1883,&l_1883},{(void*)0,(void*)0,(void*)0,&l_1883,&l_1883},{&l_1883,(void*)0,&l_1883,&l_1883,&l_1883},{(void*)0,(void*)0,(void*)0,&l_1883,&l_1883},{&l_1883,(void*)0,&l_1883,&l_1883,&l_1883},{(void*)0,(void*)0,(void*)0,&l_1883,&l_1883}};
    int64_t **l_1901 = &g_1329;
    uint8_t *l_1942 = &g_117[0];
    int64_t **** const l_1943 = &g_1327[0][0][2];
    int64_t *** const *l_1948 = (void*)0;
    int64_t *** const **l_1947 = &l_1948;
    int64_t *** const *l_1950 = &g_1945;
    int64_t *** const **l_1949 = &l_1950;
    union U1 l_1951 = {-1L};
    union U1 **l_1954[9] = {&g_93[0],&g_93[1],&g_93[0],&g_93[1],&g_93[0],&g_93[1],&g_93[0],&g_93[1],&g_93[0]};
    const int8_t *l_2155 = (void*)0;
    const int8_t **l_2154[7] = {&l_2155,&l_2155,&l_2155,&l_2155,&l_2155,&l_2155,&l_2155};
    union U1 ***l_2176 = &l_1954[0];
    int32_t l_2178 = (-4L);
    int32_t *l_2180[4];
    const union U1 l_2181 = {0xF1AF8809L};
    const union U1 l_2182[3] = {{0xA5035C75L},{0xA5035C75L},{0xA5035C75L}};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_2180[i] = &g_1178[1];
    l_1628 = l_1627;
    for (g_83.f0 = (-8); (g_83.f0 < 60); g_83.f0 = safe_add_func_int16_t_s_s(g_83.f0, 6))
    { /* block id: 776 */
        int32_t l_1631 = 0x59967927L;
        uint64_t *l_1633 = &g_216[1];
        union U1 l_1634 = {0x7030BA0DL};
        uint16_t *l_1642 = &g_1626;
        int32_t l_1668[4] = {7L,7L,7L,7L};
        uint32_t l_1689 = 0xF307B37AL;
        int32_t l_1714 = 0x5436C4D1L;
        uint32_t l_1735 = 0x3E7515ECL;
        uint64_t l_1770 = 0x607E64E2AAE23FE5LL;
        uint8_t l_1793 = 250UL;
        int32_t l_1843 = (-4L);
        int64_t l_1857[7][4][7] = {{{0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL},{0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x194B11B065D6A712LL,0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x194B11B065D6A712LL,0xB94B9B00D86C24CBLL},{(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L)},{0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL}},{{(-4L),(-4L),0x20A130AA96469E66LL,(-4L),(-4L),0x20A130AA96469E66LL,(-4L)},{0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL},{0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL},{0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x194B11B065D6A712LL,0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x194B11B065D6A712LL,0xB94B9B00D86C24CBLL}},{{(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L)},{0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL},{(-4L),(-4L),0x20A130AA96469E66LL,(-4L),(-4L),0x20A130AA96469E66LL,(-4L)},{0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL}},{{0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL},{0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x194B11B065D6A712LL,0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL},{0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL},{0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL}},{{0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL},{0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL},{0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL},{0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL}},{{0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL},{0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL},{0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL,0x042C1FA3C98C2D77LL,(-4L),0x042C1FA3C98C2D77LL},{0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL}},{{0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL},{0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL,0x6BBB191A7450D050LL,0xB94B9B00D86C24CBLL,0x6BBB191A7450D050LL},{0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL,0x20A130AA96469E66LL,0x20A130AA96469E66LL,0x042C1FA3C98C2D77LL},{0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL,0x6BBB191A7450D050LL,0x194B11B065D6A712LL,0x194B11B065D6A712LL}}};
        uint32_t l_1872[3][10][8] = {{{1UL,0x5B887DC4L,0xB3F88110L,4294967295UL,0x4F6DE347L,0x5B887DC4L,1UL,4UL},{0x4F6DE347L,0x5B887DC4L,1UL,4UL,4294967295UL,0xAAB05E28L,6UL,1UL},{0UL,0x68B0437DL,0x5B887DC4L,0x288B27D3L,4294967295UL,0x31E211DBL,0x2290128AL,4294967295UL},{0x4F6DE347L,1UL,0UL,1UL,0x4F6DE347L,0xC4C9601FL,0x68B0437DL,4294967295UL},{1UL,0xAAB05E28L,0x2290128AL,0x288B27D3L,0x288B27D3L,0x2290128AL,0xAAB05E28L,1UL},{0xF2974550L,0xC4C9601FL,0x2290128AL,4UL,0UL,0xB3F88110L,0x68B0437DL,4UL},{0x288B27D3L,0xB7B0185EL,0UL,4294967295UL,4UL,0xB3F88110L,0x2290128AL,4294967294UL},{4294967294UL,0xC4C9601FL,0x5B887DC4L,0xF2974550L,0x94EBD44FL,0x2290128AL,6UL,0UL},{4294967294UL,0xAAB05E28L,1UL,0x94EBD44FL,4UL,0xC4C9601FL,1UL,4294967295UL},{0x288B27D3L,1UL,0xB3F88110L,0x94EBD44FL,0UL,0x31E211DBL,0x31E211DBL,0UL}},{{0xF2974550L,0x68B0437DL,0x68B0437DL,0xF2974550L,0x288B27D3L,0xAAB05E28L,0x31E211DBL,4294967294UL},{1UL,0x5B887DC4L,0x2290128AL,1UL,4294967294UL,0x68B0437DL,0xB7B0185EL,4294967295UL},{4294967294UL,0x68B0437DL,0xB7B0185EL,4294967295UL,0x4F6DE347L,0xB3F88110L,0xAAB05E28L,3UL},{4294967295UL,0x31E211DBL,0x68B0437DL,0x94EBD44FL,0x4F6DE347L,1UL,0UL,1UL},{4294967294UL,0xB7B0185EL,0xC4C9601FL,3UL,4294967294UL,0x5B887DC4L,0x31E211DBL,1UL},{3UL,0xB3F88110L,0UL,0x94EBD44FL,0x94EBD44FL,0UL,0xB3F88110L,3UL},{0UL,0x5B887DC4L,0UL,4294967295UL,4294967295UL,0x2290128AL,0x31E211DBL,4294967295UL},{0x94EBD44FL,6UL,0xC4C9601FL,1UL,4294967295UL,0x2290128AL,0UL,0x288B27D3L},{0x288B27D3L,0x5B887DC4L,0x68B0437DL,0UL,0xF2974550L,0UL,0xAAB05E28L,4294967295UL},{0x288B27D3L,0xB3F88110L,0xB7B0185EL,0xF2974550L,4294967295UL,0x5B887DC4L,0xB7B0185EL,0x4F6DE347L}},{{0x94EBD44FL,0xB7B0185EL,0x2290128AL,0xF2974550L,4294967295UL,1UL,1UL,4294967295UL},{0UL,0x31E211DBL,0x31E211DBL,0UL,0x94EBD44FL,0xB3F88110L,1UL,0x288B27D3L},{3UL,0x68B0437DL,0x2290128AL,1UL,4294967294UL,0x68B0437DL,0xB7B0185EL,4294967295UL},{4294967294UL,0x68B0437DL,0xB7B0185EL,4294967295UL,0x4F6DE347L,0xB3F88110L,0xAAB05E28L,3UL},{4294967295UL,0x31E211DBL,0x68B0437DL,0x94EBD44FL,0x4F6DE347L,1UL,0UL,1UL},{4294967294UL,0xB7B0185EL,0xC4C9601FL,3UL,4294967294UL,0x5B887DC4L,0x31E211DBL,1UL},{3UL,0xB3F88110L,0UL,0x94EBD44FL,0x94EBD44FL,0UL,0xB3F88110L,3UL},{0UL,0x5B887DC4L,0UL,4294967295UL,4294967295UL,0x2290128AL,0x31E211DBL,4294967295UL},{0x94EBD44FL,6UL,0xC4C9601FL,1UL,4294967295UL,0x2290128AL,0UL,0x288B27D3L},{0x288B27D3L,0x5B887DC4L,0x68B0437DL,0UL,0xF2974550L,0UL,0xAAB05E28L,4294967295UL}}};
        uint64_t l_1876[2];
        union U0 *l_1936 = (void*)0;
        int32_t *l_1937 = &g_87;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1876[i] = 0UL;
        if (((((*g_1367) = (((*l_1633) ^= (l_1631 , (l_1631 < (+0xEFL)))) , (void*)0)) == (l_1634 , (l_1631 , (*g_731)))) & ((((safe_mod_func_int32_t_s_s(((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(((*l_1642) = (l_1634.f0 , (!0x28DB320771FFEBD6LL))), p_19)), p_21)) != p_21), p_19)) || 65532UL) & 0x80L) , l_1631)))
        { /* block id: 780 */
            uint16_t l_1667 = 1UL;
            uint32_t **l_1673 = &g_1054;
            int32_t l_1683[1][7];
            int64_t l_1780[7];
            union U1 *l_1850 = &l_1634;
            const int64_t *l_1885 = &l_1857[1][0][4];
            const int64_t **l_1884 = &l_1885;
            int64_t **l_1897 = &g_1329;
            int64_t **l_1900 = (void*)0;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 7; j++)
                    l_1683[i][j] = 7L;
            }
            for (i = 0; i < 7; i++)
                l_1780[i] = 0x4D5E96AC947FEDFBLL;
            l_1668[3] = (safe_div_func_int16_t_s_s(p_21, ((((((safe_mod_func_int64_t_s_s((safe_rshift_func_int16_t_s_u(0xE8FCL, (safe_rshift_func_uint16_t_u_s((((safe_sub_func_int64_t_s_s((((p_21 && (((safe_mod_func_uint8_t_u_u(g_275.f0, (safe_sub_func_int16_t_s_s(((safe_add_func_uint32_t_u_u((((l_1631 , (safe_sub_func_int16_t_s_s(((safe_mul_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(p_19, (safe_rshift_func_uint8_t_u_u((((*g_44) ^= (-2L)) & (p_19 < ((l_1634.f0 > l_1667) < g_1354.f3))), l_1631)))), l_1631)) , p_21), l_1667))) ^ p_21) , l_1667), 4294967295UL)) , 7L), 0x3152L)))) != l_1634.f0) , 0UL)) <= l_1631) != l_1631), l_1667)) & l_1667) | 0x70BD18510FE28E88LL), 2)))), 0x08B9D6579FA6C597LL)) != 0x40C036EA581E25FCLL) != (*p_18)) || 0xE570382BBDB6C8C2LL) >= l_1627) , (*g_44))));
            for (l_1667 = 0; (l_1667 <= 1); l_1667 += 1)
            { /* block id: 785 */
                uint32_t **l_1672 = (void*)0;
                int32_t l_1713 = 0L;
                int32_t l_1716[4] = {(-1L),(-1L),(-1L),(-1L)};
                int8_t *l_1758 = &l_1634.f1;
                uint8_t l_1782[4] = {3UL,3UL,3UL,3UL};
                uint16_t l_1787[3];
                int8_t l_1822 = 0xE3L;
                union U1 *l_1849 = &l_1634;
                union U0 **l_1855[9];
                uint64_t * const l_1856 = &l_1770;
                int64_t **l_1895 = (void*)0;
                int i;
                for (i = 0; i < 3; i++)
                    l_1787[i] = 0xC55AL;
                for (i = 0; i < 9; i++)
                    l_1855[i] = &g_111;
                l_1628 = ((l_1669 != (void*)0) && (safe_lshift_func_int16_t_s_u(((0x936957EDD546D6A2LL ^ p_19) ^ ((l_1672 == l_1673) , ((l_1628 && p_21) , (safe_rshift_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(l_1627, p_19)) , l_1668[0]), 0))))), 12)));
                for (g_664.f4 = 0; (g_664.f4 <= 1); g_664.f4 += 1)
                { /* block id: 789 */
                    int64_t l_1682 = 0xEA9B336050EBCAE8LL;
                    int32_t l_1715[5];
                    uint8_t l_1720 = 255UL;
                    int32_t *l_1723 = &g_462;
                    int32_t *l_1724 = (void*)0;
                    int32_t *l_1725 = (void*)0;
                    int32_t *l_1726 = &l_1683[0][1];
                    int32_t *l_1727 = &l_1715[1];
                    int32_t *l_1728 = (void*)0;
                    int32_t *l_1729 = &l_1716[1];
                    int32_t *l_1730 = &l_1668[1];
                    int32_t *l_1731 = &l_1668[3];
                    int32_t *l_1732 = (void*)0;
                    int32_t *l_1733 = &l_1668[3];
                    int32_t *l_1734[8] = {&g_87,&l_1668[3],&g_87,&g_87,&l_1668[3],&g_87,&g_87,&l_1668[3]};
                    int8_t **l_1746 = &g_767;
                    int8_t ***l_1745 = &l_1746;
                    uint8_t *l_1763 = &g_120;
                    uint32_t l_1764 = 0x2EA56E06L;
                    uint64_t l_1767 = 18446744073709551607UL;
                    int32_t l_1781 = 0x8140AD8DL;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1715[i] = 0xA13DA936L;
                    for (g_87 = 1; (g_87 >= 0); g_87 -= 1)
                    { /* block id: 792 */
                        int32_t *l_1678 = &g_462;
                        int32_t *l_1679 = &g_1178[0];
                        int32_t *l_1680 = &g_1178[1];
                        int32_t *l_1681 = &g_462;
                        int32_t *l_1684 = &g_462;
                        int32_t *l_1685 = &g_704;
                        int32_t *l_1686 = (void*)0;
                        int32_t *l_1687 = &l_1683[0][3];
                        int32_t *l_1688[7][1] = {{&g_87},{&l_1683[0][6]},{&g_87},{&g_87},{&l_1683[0][6]},{&g_87},{&g_87}};
                        union U1 l_1697 = {0x1D0BDB56L};
                        int16_t ****l_1708 = (void*)0;
                        int16_t ****l_1709 = &l_1707[4][3][6];
                        int i, j;
                        ++l_1689;
                        (*l_1678) = ((safe_add_func_uint16_t_u_u(l_1668[3], l_1682)) == (safe_add_func_uint16_t_u_u((((((g_1696 , (l_1697 , (safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((safe_add_func_uint16_t_u_u(l_1682, p_19)), 9)), ((~((l_1683[0][6] &= (safe_add_func_int8_t_s_s((((((*l_1709) = l_1707[4][3][6]) == (void*)0) >= (safe_div_func_int32_t_s_s((g_1712 , l_1682), 0x610EA6FEL))) <= p_21), (*l_1681)))) >= p_19)) < (*g_22)))))) != p_21) < 0xE678BA84B2D61C1ELL) , p_19) ^ 0L), (*g_44))));
                        l_1720++;
                    }
                    l_1735++;
                    l_1668[1] ^= (((*g_22) = (!(*g_1047))) || (safe_sub_func_int8_t_s_s(0xBAL, ((safe_lshift_func_uint8_t_u_s(0x35L, (l_1714 > (safe_sub_func_int8_t_s_s((((*l_1745) = &p_18) == (void*)0), (&l_1673 == (void*)0)))))) , ((safe_lshift_func_int16_t_s_s(5L, 4)) & 0xF6BD6CDFB6A2E6D3LL)))));
                    if ((((*p_18) = (*p_18)) >= (safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((l_1713 != g_237.f2), (safe_mod_func_int16_t_s_s((0xD77A3051ABDAEF14LL || ((safe_div_func_uint64_t_u_u(((+((((l_1758 = &g_1233[2]) != &p_21) > (safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_s(((*l_1763) = 0xD6L), 2)), 14))) , p_21)) && (((*g_44) <= l_1631) < p_19)), l_1668[3])) && l_1683[0][3])), p_19)))), p_19))))
                    { /* block id: 806 */
                        l_1764--;
                        if (l_1767)
                            continue;
                    }
                    else
                    { /* block id: 809 */
                        union U1 l_1775 = {0xFF77D071L};
                        (*g_978) = ((*l_1733) = (l_1683[0][6] , (((*l_1633) = (safe_mul_func_int8_t_s_s((((((((((((0UL != (l_1770 >= (safe_mul_func_uint8_t_u_u(((*l_1763)++), (&l_1720 != (void*)0))))) , l_1775) , &p_21) != ((**l_1745) = &g_23)) != (safe_lshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((*g_44), p_21)), 6))) , p_20) | p_20) >= 1UL) <= l_1780[0]) | l_1781) <= l_1668[3]), l_1780[0]))) <= 1L)));
                        l_1782[1]--;
                    }
                }
                for (g_63.f4 = 0; (g_63.f4 <= 0); g_63.f4 += 1)
                { /* block id: 820 */
                    uint8_t *l_1788 = (void*)0;
                    union U1 **l_1823 = &g_93[0];
                    const int32_t l_1844 = 0x86266DE6L;
                    int i;
                    if ((safe_mul_func_uint8_t_u_u((p_19 != ((((l_1717 = (0UL >= 1L)) | l_1787[0]) ^ ((g_117[2] |= p_19) && (l_1718[5][0] = ((void*)0 != &g_1053)))) || ((((*g_44) ^= (p_19 >= (0xB7DAL & 0x7324L))) ^ 1L) ^ 0x89BB1CF9L))), g_727.f3)))
                    { /* block id: 825 */
                        uint16_t l_1810 = 0x4C19L;
                        int32_t l_1811[6][7] = {{0L,(-7L),(-4L),(-7L),0L,(-7L),(-4L)},{0L,0L,0x8B12DFDDL,(-6L),(-5L),(-5L),(-6L)},{0xBA63FB71L,1L,0xBA63FB71L,(-7L),0xBA63FB71L,1L,0xBA63FB71L},{0L,(-6L),(-6L),0L,(-5L),0x8B12DFDDL,0x8B12DFDDL},{0L,1L,(-4L),1L,0L,1L,(-4L)},{(-5L),0L,(-6L),(-6L),0L,(-5L),0x8B12DFDDL}};
                        int i, j;
                        l_1668[1] = (0xD5831D41BAACA20DLL & (((((l_1717 || ((safe_lshift_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s(l_1793, (((((safe_rshift_func_int8_t_s_u(((p_21 < (safe_sub_func_uint8_t_u_u((p_20 | ((safe_lshift_func_uint16_t_u_u(((*l_1642)--), (safe_sub_func_uint64_t_u_u((**g_731), p_21)))) && ((safe_div_func_int32_t_s_s((1UL | (safe_rshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u(l_1735, l_1810)), p_20))), l_1718[5][1])) ^ p_20))), (*p_18)))) < 65535UL), l_1716[2])) , 0x6CE22AED62A51ED5LL) == l_1780[0]) , p_19) , (-6L)))) > p_21) < l_1810), (*g_44))) == l_1634.f0)) >= (*g_44)) && 0L) | g_120) < p_21));
                        (*g_1812) = (l_1811[1][0] = 1L);
                        if (l_1683[0][6])
                            continue;
                    }
                    else
                    { /* block id: 831 */
                        int32_t *l_1813 = (void*)0;
                        int32_t *l_1814 = &l_1713;
                        int32_t *l_1815[10][4][6] = {{{&l_1628,(void*)0,&l_1716[2],&l_1683[0][5],&l_1718[5][1],&g_87},{(void*)0,&l_1628,&l_1718[5][1],&l_1628,&l_1718[2][1],&l_1628},{(void*)0,&l_1718[5][1],(void*)0,&g_1178[0],&l_1683[0][0],&g_704},{&l_1718[5][1],(void*)0,(void*)0,&l_1713,&l_1683[0][6],(void*)0}},{{&l_1628,(void*)0,(void*)0,&l_1713,&l_1718[5][1],&g_1178[0]},{&l_1718[5][1],&g_87,&l_1718[5][1],&g_1178[0],&l_1628,&l_1718[5][1]},{(void*)0,&l_1716[2],&l_1718[5][1],&l_1628,(void*)0,(void*)0},{(void*)0,&l_1683[0][5],&g_1178[0],&l_1683[0][5],&g_1178[0],&l_1718[4][0]}},{{&l_1628,(void*)0,&g_1178[1],&l_1718[5][1],&l_1718[2][1],&l_1717},{&l_1716[2],&l_1683[0][6],&l_1683[0][5],&l_1718[5][1],&g_704,&g_704},{(void*)0,&l_1716[2],&l_1716[2],(void*)0,(void*)0,&l_1683[0][6]},{&l_1628,&g_1178[0],&l_1683[0][5],&l_1718[5][1],(void*)0,&l_1718[5][1]}},{{&l_1718[5][1],&g_87,&g_87,&l_1716[2],(void*)0,&l_1716[2]},{&l_1628,&g_1178[0],&l_1718[5][1],&l_1717,(void*)0,&l_1713},{&l_1717,&l_1716[2],&l_1718[4][0],&l_1683[0][5],&g_704,&l_1716[2]},{&l_1718[5][1],&l_1683[0][6],&l_1683[0][0],(void*)0,&l_1718[2][1],&g_87}},{{&l_1683[0][5],(void*)0,&l_1668[3],&l_1718[5][1],&g_1178[0],&g_704},{&g_1178[0],&l_1683[0][5],&l_1628,(void*)0,(void*)0,(void*)0},{&l_1628,&l_1716[2],&g_1178[0],&l_1716[2],&l_1628,&l_1718[5][1]},{(void*)0,&g_87,&l_1718[5][1],&g_87,&l_1718[5][1],&l_1718[5][1]}},{{&l_1668[3],(void*)0,&l_1718[5][1],&g_87,&l_1683[0][6],&l_1718[5][1]},{&l_1628,(void*)0,&l_1718[5][1],&l_1683[0][5],&l_1683[0][0],&l_1718[5][1]},{&l_1683[0][6],&l_1718[5][1],&g_1178[0],&l_1683[0][6],&l_1718[2][1],(void*)0},{(void*)0,&l_1628,&l_1628,&l_1716[2],&l_1718[5][1],&g_704}},{{&l_1716[2],(void*)0,&l_1668[3],&g_1178[0],&l_1628,&g_87},{&l_1628,&l_1713,&l_1683[0][0],&l_1718[5][1],&l_1683[0][6],&l_1716[2]},{&l_1713,&g_87,&l_1718[4][0],&l_1718[4][0],&g_87,&l_1713},{&l_1668[3],&l_1718[5][1],&l_1718[5][1],(void*)0,&l_1717,&l_1668[3]}},{{(void*)0,&l_1717,&l_1718[5][1],(void*)0,(void*)0,&g_1178[0]},{(void*)0,&l_1718[2][1],(void*)0,&l_1718[4][0],&g_1178[0],&g_1178[0]},{&l_1683[0][6],&g_87,(void*)0,&g_704,(void*)0,&l_1628},{&l_1683[0][5],&l_1683[0][6],&l_1628,(void*)0,(void*)0,&g_87}},{{&l_1718[5][1],&l_1628,&l_1718[5][1],&l_1716[2],&g_87,&g_704},{&l_1668[3],&l_1718[5][1],&l_1683[0][0],(void*)0,&l_1716[2],&l_1668[3]},{&g_87,(void*)0,&l_1668[3],&g_1178[0],&l_1668[3],(void*)0},{&g_462,&l_1718[5][1],&l_1683[0][5],(void*)0,&l_1718[5][1],&l_1683[0][0]}},{{(void*)0,&l_1717,(void*)0,&l_1718[5][1],&g_1178[0],&l_1716[2]},{&l_1718[5][1],&l_1717,&g_87,&l_1718[5][1],&l_1718[5][1],&l_1628},{&l_1628,&l_1718[5][1],(void*)0,&l_1668[3],&l_1668[3],&l_1718[5][1]},{&l_1718[5][1],(void*)0,&l_1628,&l_1628,&l_1716[2],&l_1718[5][1]}}};
                        uint64_t l_1816 = 0xDE29B5316608F8C8LL;
                        union U1 ***l_1824 = &g_1143;
                        int i, j, k;
                        ++l_1816;
                        if ((*l_1814))
                            continue;
                        if (p_20)
                            continue;
                        (*l_1814) = (l_1683[0][4] = ((((safe_div_func_uint32_t_u_u(p_21, (safe_unary_minus_func_int8_t_s(l_1716[2])))) , (((l_1822 < ((g_120 = (((l_1823 == ((*l_1824) = &g_93[0])) || (safe_add_func_int8_t_s_s(((safe_lshift_func_int16_t_s_s(((++p_19) != (safe_mul_func_uint8_t_u_u((g_117[0]++), (safe_lshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s((*g_44), (p_21 || ((((((*l_1633) = (**g_731)) < (safe_sub_func_int32_t_s_s(((l_1841 == l_1642) == l_1780[0]), l_1842))) > 0UL) , (*p_18)) >= p_20)))), l_1843))))), (*g_44))) <= p_20), (*p_18)))) > l_1844)) > 0x58L)) > 0x93L) < (-1L))) || 255UL) , 0L));
                    }
                    l_1628 = (safe_sub_func_uint32_t_u_u(((**g_1555) , (safe_mul_func_int16_t_s_s(0L, (((*g_44) = ((l_1849 != l_1850) , ((safe_rshift_func_int16_t_s_s(0xF9BCL, (((*l_1633)++) < ((((*g_22) = (l_1855[4] != ((((*l_1849) , ((l_1856 != &l_1770) ^ (*g_732))) , l_1857[1][2][3]) , (void*)0))) && 0x01L) != 0L)))) != p_20))) == p_21)))), 5L));
                    l_1713 = l_1782[1];
                    for (g_1058.f0 = 0; (g_1058.f0 >= 48); g_1058.f0 = safe_add_func_int8_t_s_s(g_1058.f0, 9))
                    { /* block id: 850 */
                        const union U1 l_1869 = {0xFC4FEAC6L};
                        (*g_1164) = (void*)0;
                        l_1718[5][1] = (g_1712.f2 == (safe_lshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u(((5L ^ ((((~(l_1668[3] & p_19)) <= (*g_44)) == (safe_add_func_uint32_t_u_u((safe_div_func_int64_t_s_s(((*g_22) > p_20), p_19)), l_1667))) > l_1716[2])) && (*p_18)), l_1787[0])), p_20)));
                        return l_1869;
                    }
                }
                for (g_766 = 0; (g_766 <= 0); g_766 += 1)
                { /* block id: 858 */
                    uint16_t l_1873 = 0x0237L;
                    int32_t *l_1875[7] = {&l_1668[3],&l_1668[3],&l_1668[3],&l_1668[3],&l_1668[3],&l_1668[3],&l_1668[3]};
                    int64_t *l_1888 = (void*)0;
                    int64_t *l_1889 = &g_1874.f4;
                    int64_t ***l_1896[10] = {&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328,&g_1328};
                    int i, j, k;
                    l_1876[0] = (0x30L & (safe_sub_func_int16_t_s_s(((*g_44) = l_1872[0][5][0]), ((g_80[(g_766 + 9)][(l_1667 + 1)][g_766] = ((p_20 , 0xB0E8D74D017760D2LL) > l_1873)) < (g_1874 , p_19)))));
                    l_1713 = ((l_1716[2] &= (((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((((*l_1856) = (!(l_1882[3][0] == (((void*)0 == l_1884) , g_1886)))) | ((*l_1889) = p_20)), 14)), ((safe_add_func_int16_t_s_s((g_1892 & ((safe_lshift_func_int8_t_s_u(((l_1897 = l_1895) != (l_1901 = (((!(p_19 ^ ((((*l_1633) = (((l_1683[0][6] = ((g_1899 = (void*)0) == (void*)0)) & (*p_18)) != 0L)) ^ l_1668[3]) | (*p_18)))) , l_1683[0][6]) , l_1900))), 1)) || 0xA6148FA8L)), 0x042EL)) >= g_146[3].f0))) == (*p_18)) | 0UL)) & 1L);
                }
            }
        }
        else
        { /* block id: 873 */
            const union U1 l_1902 = {6L};
            return l_1902;
        }
        (*l_1937) ^= (l_1843 = (safe_rshift_func_int8_t_s_s(((((((safe_mod_func_uint64_t_u_u(((0UL || (safe_add_func_uint16_t_u_u((((~((l_1876[1] || (0x57C9L ^ l_1718[2][1])) , (safe_sub_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u(((*g_44) = ((safe_rshift_func_uint16_t_u_u((&l_1628 == &l_1668[0]), 13)) < (((*l_1633) &= l_1718[0][0]) || (safe_sub_func_uint64_t_u_u(((safe_add_func_uint32_t_u_u(p_20, (safe_sub_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u((safe_add_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((!(safe_add_func_int32_t_s_s((g_1935 , (-1L)), l_1842))), l_1718[5][1])), 250UL)) & p_19), p_21)), l_1718[5][1])), l_1714)))) || l_1770), l_1627))))), p_20)), p_20)), l_1718[5][1])))) >= 6L) > l_1628), l_1627))) && p_19), p_19)) && p_20) <= (-1L)) ^ 0xE4L) , (*g_1474)) != l_1936), (*p_18))));
    }
    if ((safe_sub_func_int16_t_s_s(1L, (((safe_rshift_func_uint8_t_u_u((l_1717 = (((*g_248) != l_1942) & 0L)), 6)) > ((l_1628 , l_1943) != ((*l_1949) = ((*l_1947) = (g_1944 = &g_1327[0][3][2]))))) & (l_1951 , ((((l_1628 && (-6L)) | l_1627) > 0x985FL) || 0xAEL))))))
    { /* block id: 885 */
        uint32_t l_1955 = 18446744073709551615UL;
        l_1628 = (((safe_sub_func_int32_t_s_s((l_1954[7] == l_1954[7]), (g_727.f0 = l_1955))) >= 0x1A604476L) ^ p_20);
    }
    else
    { /* block id: 888 */
        union U1 *l_1956 = (void*)0;
        union U1 **l_1970 = &g_93[1];
        int32_t l_1974 = 0L;
        int32_t l_1991 = 0x3CEA8500L;
        const int32_t *l_2049 = &l_1717;
        int32_t l_2055 = 0x74217C36L;
        int32_t l_2056[7];
        int64_t * const ***l_2071 = (void*)0;
        int64_t * const ****l_2070 = &l_2071;
        uint64_t *l_2073[3];
        int8_t l_2085[6][8] = {{0x05L,(-10L),0L,0L,(-10L),0x05L,(-1L),0x47L},{0x05L,0x84L,(-4L),(-10L),(-1L),(-10L),(-4L),0x84L},{0x8AL,(-4L),0x2BL,(-10L),0x47L,0xFFL,0xFFL,0x47L},{0L,0x47L,0x47L,0L,0x8AL,0x84L,0xFFL,0x05L},{(-4L),0L,0x2BL,0xFFL,0x2BL,0L,(-4L),(-1L)},{0x2BL,0L,(-4L),(-1L),0x84L,0x84L,(-1L),(-4L)}};
        int64_t **l_2105 = (void*)0;
        int32_t l_2114 = 0L;
        union U1 l_2174 = {0x385F84BEL};
        int i, j;
        for (i = 0; i < 7; i++)
            l_2056[i] = 0x372D6E1DL;
        for (i = 0; i < 3; i++)
            l_2073[i] = &g_216[2];
        (*g_1143) = l_1956;
        for (l_1951.f1 = 13; (l_1951.f1 >= 5); l_1951.f1 = safe_sub_func_int64_t_s_s(l_1951.f1, 8))
        { /* block id: 892 */
            int32_t l_1961 = 0x7FA6CD4CL;
            union U1 ***l_1968 = (void*)0;
            union U1 ***l_1969[6][6] = {{(void*)0,&g_1143,&g_1143,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1143,&g_1143,(void*)0},{&l_1954[7],&l_1954[7],&g_1143,(void*)0,&g_1143,&l_1954[7]},{&g_1143,(void*)0,(void*)0,(void*)0,(void*)0,&g_1143},{&l_1954[7],&g_1143,(void*)0,&g_1143,&l_1954[7],&l_1954[7]},{(void*)0,&g_1143,&g_1143,(void*)0,(void*)0,(void*)0}};
            int32_t l_1995[8] = {0xABD89932L,0xABD89932L,0xABD89932L,0xABD89932L,0xABD89932L,0xABD89932L,0xABD89932L,0xABD89932L};
            int32_t *l_2022 = &l_1961;
            int32_t **l_2021 = &l_2022;
            int32_t ***l_2020 = &l_2021;
            union U1 *l_2062 = &g_91;
            uint8_t **l_2065[4][9];
            uint32_t l_2069 = 0xD0D0BC79L;
            int64_t **l_2107 = &g_1329;
            uint8_t l_2108 = 255UL;
            uint32_t l_2158 = 1UL;
            uint16_t *l_2165 = (void*)0;
            uint16_t *l_2166[5][9] = {{&l_1842,&g_80[5][2][0],&g_1626,&g_80[5][2][0],&l_1842,&g_1626,&g_80[5][2][0],&l_1842,&g_80[0][1][0]},{&l_1842,&g_80[0][1][0],&g_1626,&g_80[6][2][0],&g_80[0][1][0],&g_80[0][1][0],&g_80[0][1][0],&g_80[6][2][0],&g_1626},{(void*)0,(void*)0,&g_80[0][1][0],&g_80[6][2][0],&l_1842,&g_80[5][2][0],(void*)0,&l_1842,&g_1626},{&l_1842,&g_80[0][1][0],&l_1842,&l_1842,&l_1842,&l_1842,&g_80[0][1][0],&l_1842,&g_80[0][1][0]},{&l_1842,&l_1842,&g_80[0][1][0],&l_1842,&g_80[0][1][0],&l_1842,&l_1842,&l_1842,&l_1842}};
            uint32_t *l_2177[7] = {(void*)0,(void*)0,&g_1159.f0,(void*)0,(void*)0,&g_1159.f0,(void*)0};
            int32_t *l_2179[1];
            int i, j;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 9; j++)
                    l_2065[i][j] = &g_249;
            }
            for (i = 0; i < 1; i++)
                l_2179[i] = &l_1717;
            if ((safe_add_func_uint32_t_u_u((p_21 > l_1961), ((l_1951.f1 && (((p_21 == ((*g_44) = (l_1718[5][1] = ((g_1964[3][6][2] , (safe_rshift_func_uint8_t_u_s((g_1967 , 1UL), 3))) > ((&g_93[0] == (l_1970 = &g_93[0])) | p_21))))) && p_20) || (-10L))) && 0xF2L))))
            { /* block id: 896 */
                int32_t *l_1973 = (void*)0;
                int32_t *l_1978 = &l_1974;
                int32_t l_1985 = 0L;
                int32_t l_1987 = 0x5D9A8316L;
                int32_t l_1988 = 0x26ABD061L;
                int32_t l_1989 = 0L;
                int32_t l_1990 = 1L;
                int32_t l_1993 = (-7L);
                int32_t l_1996 = (-1L);
                int32_t l_1998 = 0xD9B819FDL;
                int32_t l_2000 = 0x40B568A6L;
                const union U1 l_2004 = {0L};
                uint32_t l_2058 = 6UL;
                uint32_t ** const l_2061 = &g_1054;
                union U1 *l_2063 = &g_2064;
                int64_t l_2087[1];
                int32_t l_2111 = 0x1A4EE577L;
                uint8_t l_2115 = 0x41L;
                int i;
                for (i = 0; i < 1; i++)
                    l_2087[i] = 0xC03F6F24E339BFB9LL;
                if (((*g_1047) |= (+0xECABL)))
                { /* block id: 898 */
                    uint32_t l_1972 = 4294967295UL;
                    int64_t l_1983 = 0x1D7FB706D62F5F2ALL;
                    int32_t l_1986 = 0x02D9B9F7L;
                    int32_t l_1992 = (-3L);
                    int32_t l_1994 = (-7L);
                    int32_t l_1997 = (-10L);
                    int32_t l_1999 = 0xA07A2FF4L;
                    union U0 *l_2005 = &g_63;
                    uint32_t *l_2014 = (void*)0;
                    uint32_t *l_2015 = (void*)0;
                    uint32_t *l_2016 = (void*)0;
                    uint32_t *l_2017[10][5][2] = {{{&g_1058.f0,&g_275.f0},{(void*)0,&g_843[1].f0},{&g_1967.f0,(void*)0},{(void*)0,&g_1967.f0},{&g_843[1].f0,&g_843[1].f0}},{{&g_1967.f0,&g_843[1].f0},{&g_843[1].f0,&g_275.f0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_385[2].f0,(void*)0}},{{&g_1058.f0,&g_843[1].f0},{&g_1874.f0,&g_1967.f0},{(void*)0,(void*)0},{&g_843[1].f0,&g_843[1].f0},{(void*)0,&g_843[1].f0}},{{&g_138,&g_275.f0},{(void*)0,&g_1967.f0},{&g_1967.f0,(void*)0},{&g_385[2].f0,&g_1967.f0},{&g_385[2].f0,(void*)0}},{{&g_1967.f0,&g_1967.f0},{(void*)0,&g_275.f0},{&g_138,&g_843[1].f0},{(void*)0,&g_843[1].f0},{&g_843[1].f0,(void*)0}},{{(void*)0,&g_1967.f0},{&g_1874.f0,&g_843[1].f0},{&g_1058.f0,(void*)0},{&g_385[2].f0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,&g_275.f0},{&g_843[1].f0,&g_843[1].f0},{&g_1967.f0,&g_843[1].f0},{&g_843[1].f0,&g_1967.f0},{(void*)0,(void*)0}},{{&g_1967.f0,&g_843[1].f0},{(void*)0,&g_275.f0},{&g_1058.f0,(void*)0},{(void*)0,&g_385[2].f0},{(void*)0,(void*)0}},{{&g_138,&g_843[1].f0},{&g_1874.f0,&g_843[1].f0},{&g_138,(void*)0},{(void*)0,&g_385[2].f0},{(void*)0,(void*)0}},{{&g_1058.f0,&g_275.f0},{(void*)0,&g_843[1].f0},{&g_1967.f0,(void*)0},{(void*)0,&g_1967.f0},{&g_843[1].f0,&g_843[1].f0}}};
                    int i, j, k;
                    if (l_1972)
                    { /* block id: 899 */
                        if ((*g_1812))
                            break;
                        (*g_1165) = l_1973;
                        l_1973 = l_1973;
                        if (l_1974)
                            break;
                    }
                    else
                    { /* block id: 904 */
                        uint8_t l_1977 = 0x99L;
                        (*g_1165) = ((safe_div_func_uint16_t_u_u(l_1977, l_1974)) , l_1978);
                        if (p_20)
                            continue;
                    }
                    if ((*g_978))
                    { /* block id: 908 */
                        (*g_1165) = &l_1628;
                        if ((*l_1978))
                            continue;
                        (**g_1165) = (((safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_u(((*l_1942) ^= (0xD2L | p_21)), 0)), 3)) == l_1983) , (*g_1047));
                        if (p_21)
                            continue;
                    }
                    else
                    { /* block id: 914 */
                        int32_t *l_1984[3][9] = {{&l_1974,&g_87,&l_1974,&g_462,&g_462,&l_1974,&g_87,&l_1974,&g_462},{&l_1718[5][1],&g_1178[1],&g_1178[1],&l_1718[5][1],&g_704,&l_1718[5][1],&g_1178[1],&g_1178[1],&l_1718[5][1]},{&l_1717,&g_462,(void*)0,&g_462,&l_1717,&l_1717,&g_462,(void*)0,&g_462}};
                        uint32_t l_2001 = 18446744073709551611UL;
                        int i, j;
                        l_2001++;
                        return l_2004;
                    }
                    (*g_2006) = l_2005;
                    if ((safe_mul_func_int16_t_s_s(l_1991, ((+(safe_add_func_int64_t_s_s((p_20 <= 18446744073709551606UL), ((safe_lshift_func_int8_t_s_u(((g_138 = l_1991) ^ p_19), (safe_div_func_int32_t_s_s(((l_1718[1][0] = p_21) || l_1961), g_843[1].f1)))) && ((void*)0 == l_2020))))) , 0x7E0DL))))
                    { /* block id: 921 */
                        uint64_t *l_2028 = (void*)0;
                        uint64_t *l_2029[2][9] = {{(void*)0,&g_216[2],(void*)0,(void*)0,&g_216[2],(void*)0,(void*)0,&g_216[2],(void*)0},{(void*)0,&g_216[2],(void*)0,(void*)0,&g_216[2],(void*)0,(void*)0,&g_216[2],(void*)0}};
                        int i, j;
                        l_1974 &= ((p_20 != 0xD1L) >= ((g_216[2] |= ((~(safe_lshift_func_uint16_t_u_u((safe_div_func_int32_t_s_s(p_21, (((**g_731) && (**g_731)) , l_1991))), 2))) == 0x7271BDF09C30959CLL)) >= ((1UL >= ((&g_1233[1] == (void*)0) || (**g_1165))) , 0x824272C6AE547098LL)));
                    }
                    else
                    { /* block id: 924 */
                        uint64_t l_2044 = 0x70C72298EC6137E2LL;
                        l_1992 = (p_20 || (safe_lshift_func_int8_t_s_u(((safe_sub_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(0L, (l_1994 || (safe_rshift_func_int16_t_s_u(p_20, (safe_add_func_int64_t_s_s((safe_div_func_uint64_t_u_u((safe_lshift_func_int16_t_s_s(l_1951.f1, 2)), p_19)), (0x7CL || (*p_18))))))))), (((1UL <= g_237.f0) & l_2044) & (-6L)))) ^ 7UL), 1)));
                    }
                }
                else
                { /* block id: 927 */
                    const int32_t *l_2047[1];
                    int32_t l_2050 = 3L;
                    int32_t l_2053 = 0L;
                    int32_t l_2054 = 0x3AD56DECL;
                    int32_t l_2057 = 0x7FE1392DL;
                    uint64_t *l_2072[4][10][1] = {{{(void*)0},{(void*)0},{&g_216[2]},{&g_216[3]},{&g_216[2]},{&g_216[0]},{&g_216[2]},{&g_216[2]},{&g_216[2]},{(void*)0}},{{&g_216[2]},{(void*)0},{&g_216[2]},{&g_216[2]},{&g_216[2]},{&g_216[0]},{&g_216[2]},{&g_216[3]},{&g_216[2]},{&g_216[0]}},{{&g_216[2]},{&g_216[2]},{&g_216[2]},{(void*)0},{&g_216[2]},{(void*)0},{&g_216[2]},{&g_216[2]},{&g_216[2]},{&g_216[0]}},{{&g_216[2]},{&g_216[3]},{&g_216[2]},{&g_216[0]},{&g_216[2]},{&g_216[2]},{&g_216[2]},{(void*)0},{&g_216[2]},{(void*)0}}};
                    union U1 *l_2074 = &l_1951;
                    int64_t **l_2106 = &g_1329;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_2047[i] = &g_1178[1];
                    for (g_137 = (-6); (g_137 <= 3); ++g_137)
                    { /* block id: 930 */
                        const int32_t **l_2048 = (void*)0;
                        int32_t *l_2051 = &l_1996;
                        int32_t *l_2052[8] = {&l_1628,&l_1628,&g_87,&l_1628,&l_1628,&g_87,&l_1628,&l_1628};
                        int i;
                        l_2049 = l_2047[0];
                        l_2058--;
                        if (p_19)
                            continue;
                        (*l_2051) &= ((*g_1052) != l_2061);
                    }
                    (*g_1143) = (l_2063 = l_2062);
                    if (((*l_1978) = (((void*)0 != l_2065[0][2]) || (safe_rshift_func_uint16_t_u_s((((p_21 > 0xB23463A0L) >= (((g_2068 , ((((((((l_2069 ^= l_1628) == 6UL) >= (l_2053 = (*l_1978))) || (l_2070 == &g_1944)) > l_1995[0]) || 0xEFDCFE6AL) < 0x238C7AB3358E0C6ELL) | p_21)) , l_2072[2][7][0]) == l_2073[2])) > (*l_1978)), (*g_44))))))
                    { /* block id: 941 */
                        union U1 *l_2075 = (void*)0;
                        uint32_t *l_2082 = &g_183.f0;
                        uint32_t **l_2081 = &l_2082;
                        uint16_t *l_2086 = &g_1626;
                        uint32_t l_2088 = 1UL;
                        int32_t l_2089 = 1L;
                        l_2075 = l_2074;
                        (*l_1978) = ((((+g_80[1][0][0]) == ((*l_2063) , (safe_mod_func_uint8_t_u_u((((*g_44) = (9L == (((l_1995[0] = (safe_div_func_uint32_t_u_u((p_21 & (((*l_2081) = &g_138) == l_2049)), (safe_mul_func_uint16_t_u_u(((*l_2086) ^= l_2085[4][5]), p_19))))) ^ (l_2088 = l_2087[0])) > p_20))) , 8UL), (*l_1978))))) <= l_2089) ^ 0x4BL);
                        (*l_1978) = p_21;
                    }
                    else
                    { /* block id: 950 */
                        uint32_t *l_2092 = &g_727.f0;
                        uint32_t l_2095 = 0x32F7DD8AL;
                        uint16_t *l_2103 = (void*)0;
                        uint16_t **l_2102[4][9][1] = {{{(void*)0},{(void*)0},{(void*)0},{(void*)0},{&l_2103},{(void*)0},{(void*)0},{(void*)0},{(void*)0}},{{&l_2103},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{&l_2103},{(void*)0},{(void*)0},{(void*)0}},{{(void*)0},{&l_2103},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{&l_2103},{(void*)0},{(void*)0}},{{(void*)0},{(void*)0},{&l_2103},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{&l_2103},{(void*)0}}};
                        uint16_t ***l_2104[2][3];
                        int32_t l_2112 = (-4L);
                        int32_t l_2113[4][5] = {{0x19886692L,0xE0E87BE9L,0x19886692L,0x19886692L,0xE0E87BE9L},{0xE0E87BE9L,0x19886692L,0x19886692L,0xE0E87BE9L,0x19886692L},{0xE0E87BE9L,0xE0E87BE9L,0xF3878DE1L,0xE0E87BE9L,0xE0E87BE9L},{0x19886692L,0xE0E87BE9L,0x19886692L,0x19886692L,0xE0E87BE9L}};
                        uint16_t l_2139 = 65535UL;
                        int64_t l_2140[8] = {(-10L),1L,1L,(-10L),1L,1L,(-10L),1L};
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_2104[i][j] = &g_437[1];
                        }
                        (*g_1164) = &l_1995[2];
                        l_2055 = (safe_unary_minus_func_int16_t_s(((+((*l_2092) = 0x305DF1BDL)) != (safe_sub_func_int64_t_s_s(l_2095, ((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((void*)0 != &l_2004), (p_21 != (safe_mul_func_int16_t_s_s((((p_20 &= (l_1718[0][0] = ((g_437[2] = l_2102[3][1][0]) != (void*)0))) <= 0UL) , ((l_2106 = l_2105) == l_2107)), 0xD25CL))))), (*l_2049))) >= l_2108))))));
                        l_1974 = p_20;
                        (*l_1978) = ((safe_add_func_uint64_t_u_u((l_2140[2] = (((++l_2115) <= (+(l_2069 < (1UL < 0L)))) != (safe_add_func_uint32_t_u_u((~(l_1628 & (((((**g_731) & (safe_mod_func_uint8_t_u_u(l_1995[0], l_1961))) & (safe_mod_func_int16_t_s_s(((safe_div_func_int64_t_s_s((((((safe_lshift_func_int8_t_s_u((((*g_22) &= l_1995[0]) , ((safe_add_func_int16_t_s_s((safe_div_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s(p_20, l_1961)), l_2112)), l_1627)), l_1995[0])) | 1L)), p_21)) == 8L) > g_2138) && (*p_18)) != p_21), p_21)) || 0xA6FAL), (*g_44)))) || p_19) , l_2139))), p_21)))), p_19)) , p_20);
                    }
                }
            }
            else
            { /* block id: 965 */
                const int8_t **l_2156 = &l_2155;
                int32_t l_2157 = (-1L);
                const union U1 l_2159 = {0xF22E109FL};
                for (g_704 = 0; (g_704 > 6); g_704++)
                { /* block id: 968 */
                    int32_t *l_2143 = &l_2056[0];
                    uint64_t ***l_2148[6];
                    uint64_t ****l_2149 = &g_1899;
                    int8_t **l_2153 = &g_767;
                    int8_t ***l_2152 = &l_2153;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_2148[i] = &g_1367;
                    (*l_2143) ^= p_19;
                    l_2157 = ((safe_add_func_uint32_t_u_u(p_21, ((p_19 != (safe_mod_func_int64_t_s_s((((*l_2149) = l_2148[5]) != &g_731), (safe_sub_func_int64_t_s_s((((*l_2143) = ((((((*l_2152) = &p_18) != (l_2156 = l_2154[5])) | p_21) == ((*l_2143) != l_2157)) ^ (**g_1887))) != 0xC0AC0195L), l_2158))))) >= p_21))) != 0x293EL);
                    return l_2159;
                }
            }
            l_1718[5][1] = (safe_add_func_int8_t_s_s((!(g_704 ^= ((safe_mul_func_int16_t_s_s((*g_44), (l_2055 = 0UL))) > (safe_lshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((l_2178 &= ((0x2387E2D3L ^ ((safe_sub_func_uint8_t_u_u((g_2173[2] , ((((((((l_2069 != 251UL) <= ((l_1628 = ((l_2174 , &l_1954[7]) != (l_2176 = (g_2175 , l_1969[3][5])))) | p_20)) || 0xA2L) != 1UL) , (*g_1886)) != &g_22) | l_1717) < p_19)), l_1718[1][0])) ^ (*g_44))) && l_1842)) == 0x1D7378999E887483LL), 7)), 4))))), l_1718[0][1]));
            (*g_1164) = l_2180[3];
        }
        return l_2181;
    }
    return l_2182[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_1165
 * writes: g_185
 */
static uint32_t  func_24(int8_t * p_25, union U1  p_26, int32_t  p_27)
{ /* block id: 768 */
    uint32_t l_1624 = 0UL;
    int32_t l_1625 = 0x301C619CL;
    l_1625 = ((((-4L) && l_1624) , 0x5858F847L) & 0xF583987FL);
    (*g_1165) = &l_1625;
    return p_26.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_183.f4 g_372.f0 g_937 g_216 g_766 g_22 g_23 g_1233 g_437 g_1178 g_1054 g_1055 g_1047 g_704 g_843.f0 g_732 g_733 g_843.f3 g_44 g_45 g_843.f2 g_176 g_1327 g_117 g_1354 g_1053 g_1367 g_731 g_1388 g_1052 g_1164 g_80 g_63.f0 g_1447 g_1474 g_111 g_1511 g_401.f3 g_275.f2 g_664.f1 g_1555 g_1510 g_87 g_1143 g_83.f4 g_664.f0
 * writes: g_183.f4 g_207 g_372.f0 g_1159.f4 g_63.f0 g_216 g_766 g_1178 g_1055 g_80 g_137 g_937 g_727.f4 g_83.f0 g_704 g_91.f1 g_45 g_1327 g_117 g_185 g_902 g_23 g_385.f0 g_111 g_1053 g_1510 g_664.f0 g_1541 g_87 g_93 g_83.f4 g_40
 */
static uint32_t  func_30(uint64_t  p_31, int8_t * p_32)
{ /* block id: 552 */
    int16_t l_1224 = (-1L);
    int64_t *l_1232 = &g_937[0];
    int64_t * const *l_1231 = &l_1232;
    int64_t * const **l_1230 = &l_1231;
    int32_t l_1234[8] = {1L,0x1372F126L,1L,0x1372F126L,1L,0x1372F126L,1L,0x1372F126L};
    int32_t l_1259 = (-9L);
    int32_t l_1291 = 0x4E2CBB56L;
    uint8_t l_1295[8] = {1UL,255UL,1UL,1UL,255UL,1UL,1UL,255UL};
    uint64_t **l_1371 = &g_1368;
    uint64_t l_1446 = 0x49F9322D9E0C970ALL;
    uint32_t l_1488 = 1UL;
    union U0 **l_1501 = &g_111;
    int16_t **l_1542 = &g_44;
    int32_t ** const *l_1551 = (void*)0;
    int32_t *l_1594 = &g_137;
    union U1 l_1615 = {0xAD087F2DL};
    uint32_t **l_1616 = &g_1054;
    uint32_t ***l_1617 = &g_1053;
    int16_t *l_1618 = (void*)0;
    int16_t *l_1619 = &g_40;
    uint8_t *l_1620 = &l_1295[5];
    int32_t *l_1621 = &g_1178[1];
    int i;
    for (g_183.f4 = 0; (g_183.f4 > (-28)); --g_183.f4)
    { /* block id: 555 */
        uint64_t l_1201[2][3] = {{1UL,1UL,1UL},{0x1A22CD1A04607B26LL,0x1A22CD1A04607B26LL,0x1A22CD1A04607B26LL}};
        union U1 l_1263 = {-8L};
        int32_t l_1281 = 2L;
        int32_t l_1288 = 0xADECDF67L;
        int32_t l_1289 = (-8L);
        int32_t l_1290 = 0xC1486712L;
        int32_t l_1292 = (-10L);
        int32_t l_1293 = 0x0ED38090L;
        int32_t l_1294 = 0x731A70DBL;
        uint64_t *l_1362[1][10][2] = {{{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]},{(void*)0,&l_1201[0][1]}}};
        uint16_t l_1373 = 0xD514L;
        int32_t **l_1425 = &g_902;
        uint8_t l_1466 = 0x47L;
        uint32_t l_1495 = 0x85D2F96FL;
        uint8_t l_1496[4][8][7] = {{{4UL,0xE7L,4UL,0x18L,0UL,0xE7L,0UL},{0xE3L,0UL,0x01L,246UL,248UL,0xBAL,0xBAL},{0UL,8UL,255UL,8UL,0UL,0xE7L,255UL},{0xF7L,0xE3L,0UL,0x01L,246UL,248UL,0xBAL},{0UL,0x18L,4UL,0xE7L,4UL,0x18L,0UL},{0xF7L,0x01L,0xBAL,246UL,0xE3L,7UL,0UL},{0UL,0x18L,255UL,0x5CL,0UL,0x5CL,255UL},{0xE3L,0xE3L,0xBAL,0UL,0xF7L,248UL,0x01L}},{{4UL,8UL,4UL,0x5CL,0UL,8UL,0UL},{246UL,0UL,0UL,246UL,0xF7L,0xBAL,7UL},{0UL,0xE7L,255UL,0xE7L,0UL,8UL,255UL},{248UL,0xE3L,0x01L,0x01L,0xE3L,248UL,7UL},{0UL,0x5CL,4UL,8UL,4UL,0x5CL,0UL},{248UL,0x01L,7UL,246UL,246UL,7UL,0x01L},{0UL,0x5CL,255UL,0x18L,0UL,0x18L,255UL},{246UL,0xE3L,7UL,0UL,248UL,248UL,0UL}},{{4UL,0xE7L,4UL,0x18L,0UL,0xE7L,0UL},{0xE3L,0UL,0x01L,246UL,248UL,0xBAL,0xBAL},{0UL,8UL,255UL,8UL,0UL,0xE7L,255UL},{0xF7L,0xE3L,0UL,0x01L,246UL,248UL,0xBAL},{0UL,0x18L,4UL,0xE7L,4UL,0x18L,0UL},{0xF7L,0x01L,0xBAL,246UL,0xE3L,7UL,0UL},{0UL,0x18L,255UL,0x5CL,0UL,0x5CL,255UL},{0xE3L,0xE3L,0xBAL,0UL,0xF7L,248UL,0x01L}},{{4UL,8UL,4UL,0x5CL,0UL,8UL,0UL},{246UL,0UL,0UL,246UL,0xF7L,0xBAL,7UL},{0UL,0xE7L,255UL,0xE7L,0UL,8UL,255UL},{248UL,0xE3L,0x01L,0x01L,0xE3L,248UL,7UL},{0UL,0x5CL,4UL,8UL,4UL,0x5CL,0UL},{248UL,0x01L,7UL,246UL,246UL,7UL,0x01L},{0UL,0x5CL,255UL,0x18L,0UL,0x18L,255UL},{246UL,0xE3L,7UL,0UL,248UL,248UL,0UL}}};
        int64_t l_1554 = 1L;
        int32_t l_1559 = (-8L);
        uint16_t l_1605[3];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1605[i] = 3UL;
        for (g_207 = 0; (g_207 == 8); g_207 = safe_add_func_int64_t_s_s(g_207, 5))
        { /* block id: 558 */
            uint32_t l_1188 = 4294967295UL;
            uint32_t l_1228 = 0x816C154BL;
            int32_t l_1258[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
            int32_t *l_1275[7][8][3] = {{{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207}},{{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207}},{{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207}},{{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207}},{{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207}},{{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207}},{{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207},{&g_207,&g_207,&g_207},{&g_207,(void*)0,&g_207},{(void*)0,&g_207,&g_207}}};
            int32_t *l_1287[7];
            uint64_t l_1341 = 18446744073709551615UL;
            int16_t l_1384 = 0x0D26L;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_1287[i] = &l_1234[3];
            for (g_372.f0 = 0; (g_372.f0 <= 1); g_372.f0 += 1)
            { /* block id: 561 */
                int64_t l_1207 = 0x3606FBBBF9150019LL;
                const uint64_t *l_1216 = &g_216[2];
                const uint64_t **l_1215 = &l_1216;
                const uint64_t ***l_1214 = &l_1215;
                int32_t l_1237 = 0x6693DD13L;
                uint8_t l_1248[2];
                uint16_t *l_1254 = &g_80[8][1][0];
                uint16_t **l_1253 = &l_1254;
                uint8_t *l_1280[6];
                uint64_t *l_1286 = &g_216[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_1248[i] = 0x8BL;
                for (i = 0; i < 6; i++)
                    l_1280[i] = &g_117[0];
                for (g_1159.f4 = 2; (g_1159.f4 >= 0); g_1159.f4 -= 1)
                { /* block id: 564 */
                    int8_t l_1187 = 6L;
                    int32_t l_1196 = 0x3C876A50L;
                    int8_t *l_1227[5][4] = {{&g_23,&g_23,&g_91.f1,&g_23},{&g_23,&g_23,&g_23,&g_23},{&g_23,&g_23,&g_23,&g_23},{&g_23,&g_23,&g_91.f1,&g_23},{&g_23,&g_23,&g_91.f1,&g_23}};
                    uint32_t *l_1229 = &l_1188;
                    uint8_t l_1257 = 0x85L;
                    int i, j;
                    for (g_63.f0 = 0; (g_63.f0 <= 2); g_63.f0 += 1)
                    { /* block id: 567 */
                        uint64_t *l_1195[4] = {&g_216[2],&g_216[2],&g_216[2],&g_216[2]};
                        int i;
                        g_1178[g_372.f0] = (safe_mod_func_int8_t_s_s((g_937[g_372.f0] == (safe_mod_func_uint8_t_u_u(l_1187, (l_1188 , ((*p_32) = (~(p_31 || ((~(safe_mod_func_uint8_t_u_u(0x21L, (-5L)))) > (++g_216[2]))))))))), 0x82L));
                        if (l_1187)
                            continue;
                        l_1196 = ((safe_mod_func_int32_t_s_s(l_1201[0][1], p_31)) , (0x30L > 6UL));
                    }
                    if ((g_1178[g_372.f0] = (safe_rshift_func_int8_t_s_s(((safe_unary_minus_func_uint8_t_u((g_937[g_372.f0] == (safe_lshift_func_uint8_t_u_u(l_1207, 4))))) || (((safe_mod_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(4294967295UL, ((safe_rshift_func_uint8_t_u_s(((((void*)0 == l_1214) , ((p_31 > (safe_rshift_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(((*l_1229) = (((((((safe_unary_minus_func_int64_t_s((safe_mod_func_uint32_t_u_u(l_1224, (((safe_rshift_func_int8_t_s_s((*p_32), (l_1196 |= (*g_22)))) , 1L) , l_1228))))) ^ 0xB9EF383DL) | (*p_32)) , (void*)0) == (void*)0) | l_1228) && g_937[g_372.f0])), 5UL)), 11))) , (void*)0)) == l_1230), 7)) , 0x8BB6DA04L))), l_1224)) | g_1233[3]) <= 0L)), (*p_32)))))
                    { /* block id: 577 */
                        l_1234[3] |= l_1201[0][1];
                        l_1196 |= l_1188;
                    }
                    else
                    { /* block id: 580 */
                        int32_t *l_1235 = &g_1178[g_372.f0];
                        int32_t *l_1236 = &l_1196;
                        int32_t *l_1238[3];
                        uint8_t l_1239 = 6UL;
                        uint8_t ** const l_1249[9] = {&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249};
                        uint16_t *l_1252 = &g_80[0][1][0];
                        uint16_t **l_1251 = &l_1252;
                        uint16_t ***l_1250[4];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1238[i] = &g_462;
                        for (i = 0; i < 4; i++)
                            l_1250[i] = &l_1251;
                        ++l_1239;
                        l_1259 ^= (safe_sub_func_uint32_t_u_u((l_1234[3] |= 4294967294UL), ((safe_rshift_func_uint16_t_u_u(((*l_1252) = ((*g_22) , (safe_mod_func_uint32_t_u_u((((*g_1054) ^= ((l_1248[1] <= (l_1249[5] != l_1249[5])) && ((g_437[1] == (l_1253 = g_437[2])) , (safe_div_func_int16_t_s_s(((l_1258[0] ^= l_1257) <= l_1196), (*l_1235)))))) , 0UL), 0x21443031L)))), l_1248[1])) & (*l_1236))));
                        (*l_1235) ^= (*g_1047);
                    }
                }
                for (g_137 = (-27); (g_137 != 6); g_137 = safe_add_func_uint32_t_u_u(g_137, 9))
                { /* block id: 593 */
                    int32_t *l_1262[1][2];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 2; j++)
                            l_1262[i][j] = &l_1234[0];
                    }
                    l_1258[0] = p_31;
                    l_1234[3] |= ((g_727.f4 = ((***l_1230) |= g_843[1].f0)) , (l_1263 , 0xF90624FAL));
                    for (g_83.f0 = (-1); (g_83.f0 <= 46); g_83.f0 = safe_add_func_int64_t_s_s(g_83.f0, 3))
                    { /* block id: 600 */
                        l_1237 = p_31;
                    }
                    if (p_31)
                        break;
                }
                l_1237 = (safe_div_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((!((*l_1254) = (((safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((void*)0 != l_1275[6][2][0]), l_1201[0][0])), (safe_rshift_func_int8_t_s_s(l_1201[1][0], 4)))) != ((*l_1286) |= (safe_mod_func_uint64_t_u_u((65535UL ^ ((l_1281 = l_1248[0]) & ((*g_732) < (((safe_rshift_func_int16_t_s_s(p_31, 5)) == (safe_sub_func_uint64_t_u_u((7L > p_31), 0x9E4AD3B5CD8708EDLL))) != p_31)))), 0x4E39D119D59B2E67LL)))) <= 2UL))) , p_31), l_1234[2])), 0x55CFL));
            }
            l_1295[5]--;
            for (g_704 = 0; (g_704 < (-20)); --g_704)
            { /* block id: 613 */
                int64_t l_1346 = 0x7CF5BE16BF4D0545LL;
                int32_t l_1357 = (-8L);
                uint64_t **l_1370 = &g_1368;
                const uint8_t *l_1390[6][3] = {{&l_1295[1],&l_1295[1],&g_120},{&l_1295[1],&l_1295[1],&g_120},{&l_1295[1],&l_1295[1],&g_120},{&l_1295[1],&l_1295[1],&g_120},{&l_1295[1],&l_1295[1],&g_120},{&l_1295[1],&l_1295[1],&g_120}};
                const uint8_t **l_1389 = &l_1390[2][2];
                int i, j;
                for (l_1291 = (-8); (l_1291 != 16); l_1291 = safe_add_func_int64_t_s_s(l_1291, 1))
                { /* block id: 616 */
                    int16_t l_1309 = 0x5E54L;
                    int64_t ***l_1331 = &g_1328;
                    uint64_t ***l_1369[4] = {&g_1367,&g_1367,&g_1367,&g_1367};
                    int32_t l_1372 = 0L;
                    int i;
                    if (p_31)
                        break;
                    for (g_63.f0 = 0; (g_63.f0 <= 10); ++g_63.f0)
                    { /* block id: 620 */
                        uint16_t *l_1314 = &g_80[4][0][0];
                        int8_t *l_1320 = (void*)0;
                        int64_t ****l_1330 = &g_1327[0][2][1];
                        int64_t ****l_1332 = (void*)0;
                        int64_t ****l_1333 = &l_1331;
                        const int32_t l_1340 = 0x472A6D96L;
                        uint8_t *l_1347 = &g_117[6];
                        g_1178[0] |= ((safe_mod_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u(((((*g_44) &= ((3UL > (safe_rshift_func_uint16_t_u_u(l_1309, 12))) , ((1UL & ((safe_add_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u(((*l_1314) = (p_31 < (*g_22))), 0)), (safe_rshift_func_int8_t_s_s((g_91.f1 = ((*p_32) = (((!0xB2803F26L) <= 9L) , (safe_mod_func_int8_t_s_s((*p_32), (1UL & g_843[1].f3)))))), l_1309)))) & 0x8963L)) && 2L))) , (void*)0) == p_32))), p_31)) >= p_31);
                        l_1234[3] |= (((!(g_843[1].f2 == (safe_lshift_func_int16_t_s_s(((p_31 >= ((safe_unary_minus_func_uint8_t_u((p_31 < g_176))) | ((((safe_add_func_uint16_t_u_u((((*l_1330) = g_1327[0][4][0]) == ((*l_1333) = l_1331)), p_31)) > ((safe_mul_func_int16_t_s_s(p_31, ((safe_mod_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(0xC9L, 247UL)), p_31)) <= l_1295[5]))) && 3UL)) , 0x477C0FE0C678852DLL) ^ (-1L)))) <= 0x8F37L), l_1263.f0)))) , l_1340) || (*g_44));
                        l_1357 = ((((0x74AB70B8E22D53B6LL != ((l_1341 , (((((safe_sub_func_uint32_t_u_u(l_1309, 0x33504052L)) , (safe_mod_func_uint8_t_u_u((--(*l_1347)), (safe_mod_func_uint16_t_u_u((0xC6L >= ((*g_22) != ((g_1354 , p_31) <= (safe_rshift_func_uint8_t_u_u(((((void*)0 == &g_93[1]) & p_31) == 1L), 4))))), (*g_44)))))) < (*p_32)) , (void*)0) == (*g_1053))) , 0x754D371392EC68C3LL)) > l_1263.f0) , p_31) > p_31);
                        return p_31;
                    }
                    if ((safe_sub_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((l_1362[0][9][1] = l_1362[0][1][0]) == l_1232), p_31)), (((1L > (safe_lshift_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_s(9UL, ((l_1370 = g_1367) == (p_31 , l_1371)))) < (((l_1357 ^= (l_1234[3] = 1UL)) != (**g_731)) != 0x36AE7A49DCE93F9BLL)), 4))) , p_31) , (*g_22)))))
                    { /* block id: 637 */
                        --l_1373;
                        l_1234[1] = (*g_1047);
                    }
                    else
                    { /* block id: 640 */
                        uint8_t *l_1391 = (void*)0;
                        uint8_t *l_1392 = (void*)0;
                        uint8_t *l_1393 = &g_117[0];
                        int32_t l_1394 = 0x112F6587L;
                        l_1234[3] ^= (safe_lshift_func_uint16_t_u_u(((l_1259 = ((safe_add_func_uint8_t_u_u(((-8L) && (safe_sub_func_int64_t_s_s(l_1384, (safe_div_func_uint16_t_u_u((+(g_1388 , (**g_731))), l_1295[5]))))), ((*l_1393) ^= ((void*)0 != l_1389)))) || (p_31 >= ((++g_216[2]) <= p_31)))) && l_1372), 0));
                        l_1234[2] |= (safe_rshift_func_uint16_t_u_u((((void*)0 == (**g_1052)) == p_31), 0));
                        return p_31;
                    }
                    return p_31;
                }
                for (l_1292 = 0; (l_1292 <= 7); l_1292 += 1)
                { /* block id: 652 */
                    int i;
                    if ((l_1234[l_1292] && (l_1263 , l_1234[l_1292])))
                    { /* block id: 653 */
                        int i;
                        l_1291 &= (l_1234[l_1292] = 0x76E0EED9L);
                        l_1291 = (!(&g_666 == (void*)0));
                        (*g_1164) = &l_1258[6];
                        if (p_31)
                            continue;
                    }
                    else
                    { /* block id: 659 */
                        uint8_t l_1404[5] = {0xABL,0xABL,0xABL,0xABL,0xABL};
                        uint16_t *l_1411 = &g_80[0][1][0];
                        uint8_t *l_1414 = &g_117[0];
                        int i;
                        l_1234[3] = (safe_add_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((*l_1414) |= ((((l_1404[0] || (l_1259 = ((l_1234[l_1292] <= (((*g_1054) |= (safe_rshift_func_int8_t_s_u((l_1346 > (*g_22)), 5))) , p_31)) != (((p_31 != (safe_rshift_func_int16_t_s_u(0L, (safe_sub_func_uint16_t_u_u((--(*l_1411)), (0L < l_1404[0])))))) , l_1263) , 0UL)))) == 0xE645683DL) , p_31) | (*g_22))), 5)), 4L));
                    }
                }
            }
        }
        if (l_1234[3])
        { /* block id: 669 */
            uint16_t l_1415 = 3UL;
            uint32_t *l_1418 = &g_63.f0;
            int32_t ***l_1426 = &l_1425;
            int32_t *l_1448 = &l_1259;
            l_1415 = 0xFE88DF55L;
            (*l_1448) = (((((safe_lshift_func_int8_t_s_s((((--(*l_1418)) < (safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((((*l_1426) = l_1425) != ((safe_sub_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(((void*)0 == &g_138), (safe_lshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u((18446744073709551613UL | (safe_sub_func_int16_t_s_s(((0UL || ((safe_add_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(l_1234[5], ((safe_rshift_func_int16_t_s_s((249UL | p_31), (~((*g_22) = l_1201[0][1])))) ^ 1UL))) == g_733), 0x5421L)) , (-9L))) == (-1L)), (*g_44)))), p_31)), 14)))), l_1373)) || 0x8A38B9CBL), 0x20L)) , &g_86[1])), (-4L))), p_31))) < 0x48L), l_1446)) & p_31) != 0x57943F466470BA45LL) > p_31) , g_1447);
            l_1234[4] ^= ((void*)0 != &g_730);
        }
        else
        { /* block id: 676 */
            uint32_t *l_1449 = &g_385[2].f0;
            int32_t l_1465 = 0x1FD08514L;
            uint32_t l_1470 = 0x8CB2D2D7L;
            int8_t l_1489 = 0xF3L;
            uint32_t **l_1494 = &g_1054;
            int32_t l_1543 = 0x387FDC8EL;
            int32_t l_1565 = 0xDB2F3C65L;
            uint8_t l_1567 = 255UL;
            uint8_t *l_1601 = &l_1567;
            uint8_t *l_1602[8];
            int32_t *l_1604 = &l_1465;
            int32_t **l_1603 = &l_1604;
            int i;
            for (i = 0; i < 8; i++)
                l_1602[i] = &l_1466;
            if (((l_1295[5] != ((*l_1449) = g_176)) > (safe_rshift_func_int8_t_s_u((safe_add_func_int64_t_s_s(((0x6FA80EE9L <= ((void*)0 == (*l_1230))) >= (safe_div_func_int8_t_s_s(((*p_32) |= (*g_22)), (safe_sub_func_int64_t_s_s((safe_mod_func_int16_t_s_s((safe_div_func_int16_t_s_s(((~((((safe_lshift_func_int16_t_s_s(p_31, ((p_31 , ((l_1465 &= 0x64L) <= 0x4CL)) || p_31))) == p_31) , &l_1224) != &g_40)) < 0xB3B79AE2L), (*g_44))), (-5L))), l_1466))))), p_31)), 6))))
            { /* block id: 680 */
                int32_t *l_1485 = &g_1178[0];
                uint32_t l_1530 = 0x585540DAL;
                int32_t l_1564 = 0x5DD0F655L;
                int32_t l_1566 = 0xD767806AL;
                (*g_1164) = l_1449;
                for (g_372.f0 = (-7); (g_372.f0 >= 28); g_372.f0 = safe_add_func_uint16_t_u_u(g_372.f0, 2))
                { /* block id: 684 */
                    int32_t *l_1469 = (void*)0;
                    union U0 *l_1473 = (void*)0;
                    ++l_1470;
                    (*g_1474) = l_1473;
                }
                if (((safe_mul_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s(l_1224, 7)), (!(l_1234[0] = (p_31 = ((*p_32) & ((((safe_div_func_int8_t_s_s((((*l_1449) = (((safe_unary_minus_func_int32_t_s(((*l_1485) = p_31))) , (safe_mod_func_int32_t_s_s(l_1488, l_1465))) <= 4UL)) > l_1489), (safe_lshift_func_int16_t_s_s(((safe_add_func_uint64_t_u_u((g_216[3] = ((((*g_1052) = l_1494) != (void*)0) < 0x7E6D4620E5B019A1LL)), l_1470)) , p_31), (*g_44))))) , l_1489) ^ 1UL) || l_1495))))))) || (*p_32)) || (*p_32)), l_1496[3][4][4])) | l_1291))
                { /* block id: 694 */
                    uint32_t ***l_1506 = &g_1053;
                    uint32_t ***l_1507 = &l_1494;
                    for (g_766 = 4; (g_766 >= 1); g_766 -= 1)
                    { /* block id: 697 */
                        uint8_t *l_1502 = &l_1295[5];
                        uint16_t *l_1505 = &g_80[0][1][0];
                        int i;
                        (*g_1164) = &l_1291;
                        (*l_1501) = ((g_1233[g_766] <= ((((*g_22) = (*g_22)) > ((((safe_rshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u(((l_1224 == ((*l_1502) = (((l_1501 == &g_666) <= 0xDC4D2C7CL) , g_1233[g_766]))) , ((safe_lshift_func_uint16_t_u_u(((*l_1505) |= ((void*)0 == &g_1367)), 3)) < (*p_32))), 6)), 0)) , l_1506) != l_1507) < p_31)) || l_1295[5])) , (*l_1501));
                        return p_31;
                    }
                }
                else
                { /* block id: 705 */
                    int32_t **l_1508 = &l_1485;
                    int16_t l_1529[2];
                    uint32_t *l_1531 = &g_664.f0;
                    uint64_t l_1550 = 18446744073709551615UL;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1529[i] = (-4L);
                    (*g_1511) = ((*l_1508) = ((*g_1164) = &l_1259));
                    if (((p_31 && 0xDBDAF1338AA789E0LL) , ((safe_mul_func_int8_t_s_s((safe_div_func_uint32_t_u_u((safe_unary_minus_func_uint32_t_u(((*l_1531) = ((*l_1449) = (safe_mul_func_uint16_t_u_u((p_31 && (((safe_add_func_int8_t_s_s((*g_22), (((*l_1485) = 250UL) > ((((((((safe_lshift_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((l_1234[7] > l_1291), (((safe_mod_func_int16_t_s_s((p_31 == ((*p_32) = l_1465)), (-9L))) && 18446744073709551609UL) && p_31))), l_1470)) && l_1529[0]) != 4294967295UL), 7)) >= p_31) , 0L) ^ 251UL) && p_31) , l_1530) || l_1465) >= l_1465)))) || (**l_1508)) >= g_401[0][2][5].f3)), p_31)))))), p_31)), (*g_22))) && p_31)))
                    { /* block id: 713 */
                        union U1 l_1540 = {-6L};
                        l_1292 = (((*p_32) ^ (((safe_rshift_func_int8_t_s_u((l_1543 = (safe_mod_func_uint8_t_u_u((((p_31 = 0UL) && (((*g_22) = (safe_lshift_func_uint16_t_u_s((p_31 , ((p_31 | (*p_32)) > (p_31 ^ ((*l_1485) = ((safe_add_func_int8_t_s_s(((l_1540 , (g_1541 = &g_44)) == l_1542), 0xC4L)) , l_1540.f0))))), 11))) ^ (*p_32))) || 0x0CBBD124L), (*p_32)))), 6)) == (*p_32)) | l_1489)) < l_1291);
                    }
                    else
                    { /* block id: 720 */
                        int32_t **l_1558 = (void*)0;
                        int32_t *l_1560 = &g_87;
                        int32_t *l_1561 = &l_1259;
                        int32_t *l_1562 = &l_1281;
                        int32_t *l_1563[5] = {&g_704,&g_704,&g_704,&g_704,&g_704};
                        int i;
                        (*g_1510) = (((safe_lshift_func_int16_t_s_u((**l_1508), (p_31 < (safe_mul_func_int8_t_s_s((0x9B5FF27195E29603LL > (safe_div_func_int16_t_s_s((-3L), 0x6965L))), ((((((((((*g_44) &= l_1550) , &g_1511) == l_1551) < ((safe_mul_func_int8_t_s_s((*p_32), l_1554)) & g_275.f2)) & g_664.f1) , (*p_32)) == (*g_22)) <= p_31) < p_31)))))) , g_1555) != l_1558);
                        ++l_1567;
                    }
                    if (l_1567)
                        break;
                }
            }
            else
            { /* block id: 727 */
                (*g_1510) |= p_31;
            }
            for (l_1293 = (-29); (l_1293 == 14); l_1293++)
            { /* block id: 732 */
                const int32_t *l_1572 = &l_1543;
                for (l_1489 = 0; (l_1489 <= 0); l_1489 += 1)
                { /* block id: 735 */
                    uint64_t l_1578 = 18446744073709551614UL;
                    (*g_1510) = p_31;
                    l_1572 = l_1572;
                    for (l_1488 = 0; (l_1488 <= 0); l_1488 += 1)
                    { /* block id: 740 */
                        int32_t *l_1582[9][7][4] = {{{&g_462,&l_1290,&l_1559,&l_1559},{&l_1543,&l_1543,&g_87,&g_87},{&g_462,&g_87,&l_1292,&l_1293},{&l_1559,&l_1291,&l_1293,&l_1292},{&l_1292,&l_1291,&l_1543,&l_1293},{&l_1291,&g_87,&l_1291,&g_87},{&l_1290,&l_1543,&l_1565,&l_1559}},{{&l_1259,&l_1290,&g_87,&l_1543},{&l_1293,&g_704,&g_87,&g_704},{&l_1259,&l_1565,&l_1565,&l_1259},{&l_1290,&l_1293,&l_1291,(void*)0},{&l_1291,(void*)0,&l_1543,&g_704},{&l_1292,&g_462,&l_1293,&g_704},{&l_1559,(void*)0,&l_1292,(void*)0}},{{&g_462,&l_1293,&g_87,&l_1259},{&l_1543,&l_1565,&l_1559,&g_704},{&g_462,&g_704,&g_704,&l_1543},{&g_462,&l_1290,&l_1559,&l_1559},{&l_1543,&l_1543,&g_87,&g_87},{&g_462,&g_87,&l_1292,&l_1293},{&l_1559,&l_1291,&l_1293,&l_1292}},{{&l_1292,&l_1291,&l_1543,&l_1293},{&l_1291,&g_87,&l_1291,&g_87},{&l_1290,&l_1543,&l_1565,&l_1559},{&l_1259,&l_1290,&g_87,&l_1543},{&l_1293,&g_704,&g_87,&g_704},{&l_1259,&l_1565,&l_1565,&l_1259},{&l_1290,&l_1293,&l_1291,(void*)0}},{{&l_1291,(void*)0,&l_1543,&g_704},{&l_1292,&g_462,&l_1293,&g_704},{&l_1559,(void*)0,&l_1292,(void*)0},{&g_462,&l_1293,&g_87,&l_1259},{&l_1543,&l_1565,&l_1559,&g_704},{&g_462,&g_704,&g_704,&l_1543},{&g_462,&l_1290,&l_1559,&l_1559}},{{&l_1543,&l_1543,&g_87,&g_87},{&g_87,&g_704,&l_1293,&l_1259},{&l_1291,&g_704,&g_704,&l_1293},{&l_1293,&g_704,&l_1292,&l_1259},{&g_704,&g_704,&g_704,&l_1290},{&l_1565,&l_1292,&l_1293,&l_1291},{&g_462,&l_1565,&l_1290,&l_1292}},{{&l_1259,&g_462,&l_1290,&l_1559},{&g_462,&l_1293,&l_1293,&g_462},{&l_1565,&l_1259,&g_704,&l_1543},{&g_704,&l_1543,&l_1292,&g_462},{&l_1293,(void*)0,&g_704,&g_462},{&l_1291,&l_1543,&l_1293,&l_1543},{&g_87,&l_1259,&g_704,&g_462}},{{&l_1292,&l_1293,&l_1291,&l_1559},{(void*)0,&g_462,&l_1559,&l_1292},{(void*)0,&l_1565,&l_1291,&l_1291},{&l_1292,&l_1292,&g_704,&l_1290},{&g_87,&g_704,&l_1293,&l_1259},{&l_1291,&g_704,&g_704,&l_1293},{&l_1293,&g_704,&l_1292,&l_1259}},{{&g_704,&g_704,&g_704,&l_1290},{&l_1565,&l_1292,&l_1293,&l_1291},{&g_462,&l_1565,&l_1290,&l_1292},{&l_1259,&g_462,&l_1290,&l_1559},{&g_462,&l_1293,&l_1293,&g_462},{&l_1565,&l_1259,&g_704,&l_1543},{&g_704,&l_1543,&l_1292,&g_462}}};
                        int i, j, k;
                        (*g_1510) &= (~(((p_31 < ((safe_sub_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((l_1578 < (safe_unary_minus_func_uint8_t_u((p_31 & 1UL)))), 0x57DE2B13BE20939CLL)), ((safe_sub_func_uint8_t_u_u(p_31, (*g_22))) > g_733))) == (l_1578 > 0x93654E704FCBBFC2LL))) >= (*g_22)) > p_31));
                        (*g_1510) &= 0x066ACD49L;
                        (*g_1143) = &l_1263;
                        (*g_1164) = l_1582[0][1][1];
                    }
                }
            }
            for (g_83.f4 = 0; (g_83.f4 >= 5); g_83.f4++)
            { /* block id: 750 */
                return g_664.f0;
            }
            (*l_1425) = (((((((safe_mul_func_int8_t_s_s((+((safe_mod_func_int8_t_s_s((*p_32), (safe_div_func_int8_t_s_s(((l_1465 && (safe_div_func_uint32_t_u_u(((l_1594 == ((*l_1603) = ((safe_sub_func_int64_t_s_s(((safe_rshift_func_uint8_t_u_s((((p_31 ^ ((*l_1232) = ((((safe_rshift_func_int8_t_s_s((p_31 , (((*l_1601) = 0x34L) == ((void*)0 == (*l_1501)))), ((l_1565 = 0x6EL) , (-9L)))) <= 0xAD2E892146E136CFLL) , 2L) , p_31))) == p_31) >= l_1465), 1)) != p_31), p_31)) , (void*)0))) == 0x844AL), 0x80FF2C1AL))) == 0UL), l_1605[2])))) >= 0x5F7482DDL)), p_31)) >= (*p_32)) == 0xB4L) <= (*p_32)) <= p_31) ^ (*g_22)) , (void*)0);
        }
    }
    (*l_1621) = ((*g_1510) = ((safe_mod_func_uint64_t_u_u(p_31, p_31)) > ((9L ^ ((safe_div_func_uint32_t_u_u((0L <= (!(((*l_1620) &= (safe_mod_func_uint64_t_u_u((**g_731), ((safe_div_func_int16_t_s_s((l_1234[5] ^= ((*l_1619) = (l_1615 , ((*g_44) = ((*g_1510) == (l_1616 != ((*l_1617) = &g_1054))))))), 0x9E75L)) & 0xD8FAEDE7L)))) > (*g_22)))), 0xFC5E5D1DL)) , 0UL)) <= p_31)));
    return (*l_1621);
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_63.f0 g_45 g_23 g_83.f4 g_87 g_94 g_63.f4 g_184 g_63 g_385.f1 g_591 g_180 g_111 g_80 g_91 g_385.f3 g_22 g_275.f3 g_158 g_237.f2 g_437 g_462 g_176 g_704 g_372.f1 g_93 g_512 g_185 g_730 g_731 g_734 g_183.f0 g_436 g_183.f1 g_44 g_207 g_766 g_148 g_808 g_732 g_733 g_146.f1 g_83.f1 g_843 g_216 g_120 g_664.f0 g_138 g_183.f2 g_137 g_937 g_952 g_961 g_978 g_902 g_275.f0 g_727.f1 g_1054 g_1055 g_843.f0 g_1150 g_1159 g_1171 g_1164 g_1178
 * writes: g_63.f0 g_80 g_83.f4 g_87 g_93 g_63.f4 g_185 g_117 g_45 g_23 g_158 g_462 g_666 g_183.f0 g_767 g_148 g_216 g_120 g_91.f1 g_83.f0 g_902 g_207 g_704 g_275.f0 g_138 g_1143 g_275.f4 g_1164 g_1165 g_664.f0 g_1178
 */
static int16_t  func_41(int16_t * p_42, uint32_t  p_43)
{ /* block id: 3 */
    int16_t *l_59 = &g_45;
    int8_t *l_765[6][6][7] = {{{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,(void*)0,&g_766,&g_766,(void*)0,&g_766,&g_766}},{{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{(void*)0,&g_766,&g_766,&g_766,(void*)0,&g_766,&g_766},{&g_766,(void*)0,(void*)0,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,(void*)0,(void*)0,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{(void*)0,(void*)0,&g_766,&g_766,&g_766,&g_766,(void*)0}},{{(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,(void*)0,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,(void*)0},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{(void*)0,&g_766,(void*)0,&g_766,&g_766,(void*)0,&g_766}},{{&g_766,(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,(void*)0,(void*)0,&g_766,&g_766,(void*)0},{&g_766,&g_766,&g_766,&g_766,(void*)0,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,(void*)0,&g_766,&g_766,&g_766,(void*)0},{&g_766,(void*)0,(void*)0,(void*)0,&g_766,(void*)0,(void*)0}},{{(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{(void*)0,&g_766,&g_766,&g_766,(void*)0,&g_766,&g_766},{(void*)0,(void*)0,&g_766,(void*)0,&g_766,&g_766,(void*)0},{&g_766,&g_766,&g_766,&g_766,(void*)0,&g_766,&g_766}},{{&g_766,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,(void*)0,&g_766,&g_766,&g_766},{(void*)0,&g_766,&g_766,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,(void*)0,&g_766,&g_766,&g_766,&g_766},{&g_766,&g_766,&g_766,(void*)0,(void*)0,&g_766,&g_766},{(void*)0,&g_766,(void*)0,&g_766,(void*)0,&g_766,(void*)0}}};
    int8_t **l_1174 = (void*)0;
    int8_t **l_1175 = &l_765[5][2][5];
    int32_t l_1176 = (-1L);
    int32_t *l_1177 = &g_1178[0];
    int i, j, k;
    (*l_1177) &= (+(func_47(((*l_1175) = func_50(func_56(g_12, l_59), (g_767 = l_765[5][4][4]), l_59, &g_148, p_42)), g_44) != l_1176));
    return (*p_42);
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_45
 * writes:
 */
static int16_t  func_47(int8_t * p_48, int16_t * const  p_49)
{ /* block id: 548 */
    return (*g_44);
}


/* ------------------------------------------ */
/* 
 * reads : g_87 g_44 g_45 g_22 g_23 g_766 g_148 g_808 g_731 g_732 g_733 g_183.f1 g_146.f1 g_83.f1 g_207 g_63.f0 g_843 g_216 g_120 g_437 g_80 g_664.f0 g_138 g_385.f3 g_183.f2 g_137 g_704 g_937 g_952 g_185 g_961 g_462 g_978 g_902 g_275.f0 g_727.f1 g_1054 g_1055 g_843.f0 g_512 g_1150 g_184 g_1159 g_1171 g_1164
 * writes: g_87 g_148 g_45 g_80 g_185 g_216 g_63.f0 g_120 g_23 g_91.f1 g_83.f0 g_902 g_207 g_704 g_275.f0 g_138 g_462 g_158 g_1143 g_275.f4 g_93 g_1164 g_1165 g_664.f0
 */
static int8_t * func_50(uint8_t  p_51, int8_t * p_52, int16_t * p_53, int16_t * p_54, int16_t * p_55)
{ /* block id: 315 */
    int8_t l_769 = 0x88L;
    int16_t l_772 = 0x00A9L;
    int32_t l_773 = 1L;
    int32_t l_774[6][6] = {{0x6384807BL,0x658B4231L,0x72D141EBL,(-1L),(-6L),0xCAFA011AL},{0xCAFA011AL,0x4A348C62L,0L,0x4A348C62L,0xCAFA011AL,0x658B4231L},{0xCAFA011AL,0x6384807BL,0x4A348C62L,(-1L),(-9L),(-9L)},{0x6384807BL,(-6L),(-6L),(-6L),0x658B4231L,0xCAFA011AL},{0L,0xCAFA011AL,0L,0x6384807BL,(-9L),0x6384807BL},{0x658B4231L,(-1L),0x658B4231L,0x4A348C62L,(-9L),0x72D141EBL}};
    uint16_t *l_787 = &g_80[0][1][0];
    int32_t l_788 = 6L;
    int64_t *l_797 = &g_158;
    int64_t **l_796 = &l_797;
    int64_t ***l_795 = &l_796;
    uint32_t l_806[2][5][3] = {{{18446744073709551615UL,0x89990F39L,18446744073709551615UL},{0x973D764AL,1UL,0x973D764AL},{18446744073709551615UL,0x89990F39L,18446744073709551615UL},{0x973D764AL,1UL,0x973D764AL},{18446744073709551615UL,0x89990F39L,18446744073709551615UL}},{{0x973D764AL,1UL,0x973D764AL},{18446744073709551615UL,0x89990F39L,18446744073709551615UL},{0x973D764AL,1UL,0x973D764AL},{18446744073709551615UL,0x89990F39L,18446744073709551615UL},{0x973D764AL,1UL,0x973D764AL}}};
    int32_t **l_833 = &g_185;
    uint64_t l_839 = 0xD3DE88DE82A3B38BLL;
    int32_t l_859 = 0xEA32D2A1L;
    uint16_t l_875 = 0x0CC8L;
    int32_t l_900 = 0xAF280D6FL;
    uint32_t *l_925 = &l_806[1][4][2];
    uint32_t **l_924 = &l_925;
    int16_t * const *l_979 = &g_44;
    int32_t l_1071 = 0xF12E5CF8L;
    int64_t l_1101 = 0xA39AC5749EA5F41ELL;
    int32_t *l_1173 = &g_87;
    int i, j, k;
    if (p_51)
    { /* block id: 316 */
        int32_t *l_770 = &g_87;
        int32_t *l_771[4] = {&g_462,&g_462,&g_462,&g_462};
        uint32_t l_775 = 7UL;
        int64_t *l_786 = (void*)0;
        uint32_t l_838[2];
        uint8_t *l_874 = (void*)0;
        int i;
        for (i = 0; i < 2; i++)
            l_838[i] = 0x3398A278L;
        (*l_770) &= (0xAB53B939L == (safe_unary_minus_func_uint8_t_u((l_769 ^= p_51))));
lbl_809:
        --l_775;
        l_788 = (l_774[2][2] = ((safe_add_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((*g_44) >= ((((((safe_rshift_func_uint16_t_u_u(((*l_770) , (p_51 | ((*l_770) = ((safe_add_func_int16_t_s_s(((*p_54) = (((l_773 = (((((*g_22) , ((0xBF26DB67L >= ((*g_44) == l_772)) , (*g_22))) && 0xFFL) ^ l_769) & 0L)) >= 0x94B8L) != 0x30ECL)), (*p_53))) , g_766)))), l_774[2][2])) >= p_51) , (*g_22)) <= 1L) , l_787) != (void*)0)), l_774[0][2])), (*g_44))) ^ (-1L)));
        if (((safe_mod_func_int8_t_s_s(((l_806[1][4][1] = (safe_sub_func_int8_t_s_s(((((safe_rshift_func_int16_t_s_s(((((l_795 == (void*)0) ^ ((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s((p_51 && (l_769 <= (*l_770))), 2)), (((*l_787) = (safe_rshift_func_uint8_t_u_u((p_51 || ((safe_div_func_int16_t_s_s(((*p_54) &= ((*p_55) = 0xB04AL)), (p_51 , p_51))) && l_769)), 3))) , (*g_44)))) , (*l_770))) <= l_773) & p_51), p_51)) , l_774[4][5]) > 1UL) ^ p_51), p_51))) != 0x1B6CL), 0x51L)) & p_51))
        { /* block id: 329 */
            int32_t **l_807 = (void*)0;
            (*g_808) = &l_774[2][2];
        }
        else
        { /* block id: 331 */
            int8_t l_812 = 0xD3L;
            int32_t **l_834 = &l_770;
            uint64_t *l_835[7] = {&g_216[0],&g_216[0],&g_216[0],&g_216[0],&g_216[0],&g_216[0],&g_216[0]};
            int32_t l_836 = 0xDE1BF37EL;
            uint16_t l_837 = 0UL;
            uint32_t l_840 = 0xF4B94D5FL;
            union U1 l_893[5] = {{3L},{3L},{3L},{3L},{3L}};
            int i;
            if (l_772)
                goto lbl_809;
            if ((safe_unary_minus_func_uint64_t_u((g_216[2] = (p_51 ^ ((((((((0UL <= ((safe_unary_minus_func_int16_t_s((l_812 < 0xAE3CL))) & (p_51 > (**g_731)))) | (((safe_lshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s((((((safe_sub_func_int32_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((l_836 = ((safe_rshift_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((((((((*p_55) = (safe_mod_func_uint32_t_u_u(((safe_sub_func_uint16_t_u_u(p_51, (safe_rshift_func_int16_t_s_u(((l_834 = l_833) == (((void*)0 != p_53) , &l_770)), 0)))) && g_183.f1), l_812))) || (*p_53)) , 0L) , g_146[3].f1) != g_83.f1) > g_207), 4)) < 0x77829CAFF80291EELL), (*p_54))) != p_51)), p_51)), p_51)), 0xF11735C5L)) >= l_812) ^ l_837) <= l_812) > l_838[1]), p_51)), l_839)) || l_840) , (-1L))) && p_51) , l_833) == l_833) <= p_51) != (*l_770)) || (*g_44)))))))
            { /* block id: 337 */
                (*l_770) = (-8L);
            }
            else
            { /* block id: 339 */
                uint16_t *l_870 = &l_837;
                int32_t l_871 = 0L;
                int8_t *l_872 = (void*)0;
                int8_t *l_873[2];
                union U1 l_883 = {0x63D26519L};
                int i;
                for (i = 0; i < 2; i++)
                    l_873[i] = &l_769;
                for (g_63.f0 = 0; (g_63.f0 <= 59); g_63.f0 = safe_add_func_int64_t_s_s(g_63.f0, 2))
                { /* block id: 342 */
                    uint8_t *l_852 = &g_120;
                    uint16_t **l_858[6][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                    uint16_t ***l_857 = &l_858[0][4];
                    int i, j;
                    (*l_770) = ((((&g_249 == (g_843[1] , &g_249)) != (safe_mod_func_uint64_t_u_u((safe_add_func_int32_t_s_s(p_51, (~p_51))), ((!(((g_216[0] && (((safe_lshift_func_uint8_t_u_u((++(*l_852)), ((g_437[1] != ((*l_857) = ((p_51 , (--(*l_787))) , g_437[1]))) , p_51))) , p_51) <= 1L)) , (-5L)) , 0xB3F0L)) || p_51)))) ^ 0xBAL) > l_859);
                }
                (*l_770) = 0xCCB800B7L;
                if (((l_875 = ((*l_770) = ((g_664.f0 , ((l_835[5] == (((((g_91.f1 = (safe_sub_func_uint64_t_u_u(p_51, (safe_lshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u(((*l_787) = p_51), 15)), (((safe_sub_func_uint32_t_u_u(((&g_45 != (void*)0) | (g_138 >= ((*g_22) = (((0xF446BEBAL > ((safe_mul_func_int16_t_s_s(((((*l_870) = (0UL > p_51)) , l_871) || 0xA5CAAA05D2467C34LL), (*g_44))) == 0xE7C372B3687D07D9LL)) || 5L) , (*g_22))))), l_871)) , (-1L)) <= (-10L))))))) >= p_51) == g_385[2].f3) && (-9L)) , (*l_796))) , l_874)) == &g_117[0]))) & p_51))
                { /* block id: 355 */
                    (*l_770) ^= p_51;
                }
                else
                { /* block id: 357 */
                    uint32_t *l_884 = &g_83.f0;
                    int32_t l_903 = 0xBBD187CDL;
                    (*l_770) = (0x842A2C17L != 3UL);
                    for (l_836 = (-3); (l_836 > 2); l_836++)
                    { /* block id: 361 */
                        int32_t l_878 = 4L;
                        (*l_770) &= p_51;
                        if (l_878)
                            break;
                    }
                    (*l_770) |= (p_51 | (((*l_884) = (((((p_51 ^ (safe_add_func_int32_t_s_s(1L, (((((void*)0 != &g_591) >= (g_183.f2 , ((safe_div_func_int8_t_s_s((((p_51 != 6L) != 3UL) || (-7L)), (*g_22))) , 0x2BL))) != l_871) || 0x3221L)))) || p_51) , l_883) , (void*)0) != l_786)) || 0x6EEC4B86L));
                    if ((safe_rshift_func_int16_t_s_s((p_51 | (safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((p_51 == ((safe_add_func_int8_t_s_s(l_871, (l_893[2] , (*g_22)))) == (((p_51 || (((((*l_770) & (safe_div_func_uint16_t_u_u((((safe_div_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(250UL, 1)), p_51)) || p_51) == g_137), (*g_44)))) <= p_51) < 0xA1L) != p_51)) , l_883.f0) & p_51))), 3)), l_836))), (*g_44))))
                    { /* block id: 367 */
                        uint32_t l_901 = 9UL;
                        g_902 = ((l_901 = l_900) , ((*l_833) = (void*)0));
                        (*l_770) = l_903;
                    }
                    else
                    { /* block id: 372 */
                        int32_t l_915[5] = {6L,6L,6L,6L,6L};
                        int i;
                        l_836 = (safe_mod_func_int32_t_s_s((safe_sub_func_uint32_t_u_u(((&p_52 != &g_767) | (((*g_44) = ((l_903 != (l_871 & (safe_rshift_func_uint16_t_u_s(((((safe_unary_minus_func_uint32_t_u(((p_51 && (-5L)) || ((((((0xDEC0L <= ((*l_787) = (((safe_lshift_func_int16_t_s_s((p_51 == (safe_mul_func_int8_t_s_s(l_871, (*g_22)))), (*p_53))) >= (*p_55)) , p_51))) , (void*)0) != l_870) | 2L) | l_915[3]) > 0xE909AA7F836FB029LL)))) || l_806[1][4][1]) , p_51) && p_51), 14)))) == (*l_770))) & 0xBC3BL)), p_51)), 3L));
                        return p_52;
                    }
                }
            }
        }
    }
    else
    { /* block id: 381 */
        int64_t l_932 = 0xDACEBE47CC2D113CLL;
        int32_t l_934 = 0x04B896B1L;
        uint32_t l_950 = 0UL;
        int64_t l_964 = 0L;
        const uint64_t *l_1076 = &l_839;
        const uint64_t **l_1075 = &l_1076;
        const uint64_t ***l_1074[4] = {&l_1075,&l_1075,&l_1075,&l_1075};
        int32_t l_1089 = 1L;
        int32_t l_1090 = 0L;
        int32_t l_1099 = (-4L);
        int32_t l_1100[6] = {0L,0L,0L,0L,0L,0L};
        uint64_t l_1102 = 1UL;
        uint8_t l_1140 = 0x33L;
        union U1 **l_1141[10] = {&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0],&g_93[0]};
        int8_t *l_1149 = &l_769;
        uint32_t l_1152 = 0x6603C3FFL;
        int i;
lbl_1153:
        for (g_207 = 5; (g_207 >= 0); g_207 -= 1)
        { /* block id: 384 */
            const uint16_t l_931 = 0x259DL;
            uint16_t l_967[7];
            const uint32_t l_976 = 0x99C7E439L;
            int32_t l_1028 = 0x28501B22L;
            int32_t *l_1046 = &l_900;
            int32_t l_1088 = 0x3AF12ED6L;
            int32_t l_1091[1];
            int32_t *l_1095 = &l_773;
            int32_t *l_1096 = &l_1088;
            int32_t *l_1097 = &l_1089;
            int32_t *l_1098[10][2][1];
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_967[i] = 0xE2B1L;
            for (i = 0; i < 1; i++)
                l_1091[i] = 0x0C7CB4A6L;
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_1098[i][j][k] = (void*)0;
                }
            }
            for (g_704 = 0; (g_704 <= 5); g_704 += 1)
            { /* block id: 387 */
                uint32_t ***l_926 = &l_924;
                uint8_t *l_927[2];
                int32_t l_928 = 0x288C6686L;
                uint32_t *l_933 = &g_275.f0;
                const int32_t l_949[3][5][6] = {{{0xACEED624L,0x8156A6E6L,0x3693D82DL,0L,0xF8EB2C69L,0xF8EB2C69L},{0xC54A02E2L,0x8156A6E6L,0x8156A6E6L,0xC54A02E2L,0L,0x4967A5CEL},{0L,0x3A74C6B7L,0x76E521D5L,(-10L),(-4L),0xF4C8EBC4L},{0xACEED624L,(-1L),(-9L),3L,(-4L),0xF8EB2C69L},{0L,0x3A74C6B7L,0x4234649AL,2L,0L,(-9L)}},{{(-9L),0x8156A6E6L,0xE6AD22CAL,(-10L),0xF8EB2C69L,(-1L)},{0xD3981616L,0x8156A6E6L,(-9L),0xD3981616L,0L,0x76E521D5L},{0xC54A02E2L,0x3A74C6B7L,0xF4C8EBC4L,0L,(-4L),0x4967A5CEL},{(-9L),(-1L),(-4L),0xA2C729EFL,(-4L),(-1L)},{0L,0x3A74C6B7L,0x3693D82DL,3L,0L,(-4L)}},{{4L,0x8156A6E6L,0x4234649AL,0L,0xF8EB2C69L,0x1F2BCF22L},{0L,0x8156A6E6L,(-4L),0x3693D82DL,0L,(-1L)},{0xE6AD22CAL,0xB3EEF7F8L,0x4E947C75L,0x76E521D5L,0x455E73EDL,0x8F6342B3L},{0x8156A6E6L,0L,0x541FAE4AL,0x3A74C6B7L,0x455E73EDL,1L},{0x4967A5CEL,0xB3EEF7F8L,(-3L),0x75877197L,0L,0x541FAE4AL}}};
                uint64_t *l_951 = &l_839;
                uint32_t l_1023 = 0x41DBF8F0L;
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_927[i] = &g_117[5];
                l_934 = (safe_add_func_uint32_t_u_u(l_774[g_704][g_704], ((*l_933) = ((safe_mul_func_uint8_t_u_u(l_774[g_207][g_207], 250UL)) ^ (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((l_928 |= (((*l_926) = l_924) != &l_925)), (safe_lshift_func_uint16_t_u_u((0x02L && ((l_774[g_207][g_207] != (-4L)) == ((p_51 & l_931) >= p_51))), p_51)))), l_932))))));
                if ((p_51 ^ ((*l_951) ^= (g_733 >= (safe_div_func_int8_t_s_s((g_937[0] != ((((safe_div_func_int8_t_s_s((((~0x698FD95B5C165F52LL) == (g_138 |= ((*l_933) = ((l_934 | (safe_lshift_func_uint16_t_u_u(p_51, 9))) ^ ((((safe_lshift_func_int16_t_s_u((l_928 , ((*p_55) ^= (safe_add_func_uint64_t_u_u(2UL, (safe_lshift_func_uint8_t_u_s(p_51, l_932)))))), l_934)) , l_931) >= l_949[2][1][2]) || l_950))))) ^ l_774[g_704][g_704]), 254UL)) <= 0x27B0CA7EL) < p_51) || l_774[g_704][g_704])), 0x15L))))))
                { /* block id: 396 */
                    uint32_t * const *l_953 = &l_925;
                    (*g_952) = ((*l_833) = &l_934);
                    for (l_839 = 0; (l_839 <= 2); l_839 += 1)
                    { /* block id: 401 */
                        uint8_t l_956[1][8];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 8; j++)
                                l_956[i][j] = 0x22L;
                        }
                        (**l_833) = ((l_953 != (void*)0) <= g_183.f1);
                        (*g_185) = (safe_sub_func_uint8_t_u_u((p_51 = p_51), (l_956[0][2] | l_956[0][4])));
                    }
                    for (l_932 = 0; (l_932 <= 2); l_932 += 1)
                    { /* block id: 408 */
                        const uint64_t *l_958[8];
                        const uint64_t **l_957 = &l_958[4];
                        const uint64_t ***l_959 = &l_957;
                        int32_t l_960 = 0x1668992FL;
                        int i;
                        for (i = 0; i < 8; i++)
                            l_958[i] = &g_216[2];
                        (*g_961) |= (((((p_51 > l_949[1][3][5]) & ((**l_833) , 0xF7L)) <= ((((*l_959) = l_957) != (void*)0) | 0xACL)) || p_51) != l_960);
                        return &g_23;
                    }
                }
                else
                { /* block id: 413 */
                    int64_t * const l_962[1][7] = {{&g_83.f4,&g_83.f4,&g_83.f4,&g_83.f4,&g_83.f4,&g_83.f4,&g_83.f4}};
                    int32_t l_977 = 0xEE93E007L;
                    union U1 *l_988 = (void*)0;
                    int i, j;
                    for (g_275.f0 = 0; (g_275.f0 <= 2); g_275.f0 += 1)
                    { /* block id: 416 */
                        int32_t l_963 = 0xF6D36021L;
                        int i;
                        l_928 = (l_962[0][0] != (void*)0);
                        (*g_978) ^= (l_963 & ((l_931 || ((((l_964 == (safe_div_func_int16_t_s_s(l_934, ((((((1UL != ((l_967[4] >= 1UL) && ((safe_mod_func_int32_t_s_s((safe_sub_func_uint64_t_u_u(((*l_951) &= ((safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s((l_772 < 0xFB01L), p_51)), (*g_44))) && l_963)), l_976)), 0x23E35F19L)) != l_967[5]))) | (*g_44)) , l_976) != l_977) ^ l_964) | p_51)))) > g_462) == p_51) <= 0x9B8C4F39L)) || p_51));
                        (*g_902) &= 1L;
                    }
                    (*l_833) = (*g_952);
                    (*g_902) = ((&p_55 == l_979) && ((*l_787) = l_774[g_704][g_704]));
                    (*g_902) = (safe_sub_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_s((((g_216[3] = (safe_add_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(p_51, l_934)) || (((l_988 = l_988) != (void*)0) > ((*l_933) &= (safe_mul_func_int8_t_s_s(((((l_934 & l_977) , (safe_unary_minus_func_uint16_t_u((**l_833)))) ^ 0UL) >= (safe_mul_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u(253UL, 4)) , (*g_44)), p_51))), l_976))))), (*g_44)))) >= l_964) != p_51), 3)) != l_977), 0x0272L));
                }
                (*l_833) = (l_950 , (*l_833));
                for (g_83.f0 = 0; (g_83.f0 == 39); ++g_83.f0)
                { /* block id: 433 */
                    const uint32_t *l_1019 = &l_806[1][0][2];
                    const uint32_t **l_1018 = &l_1019;
                    const uint32_t ***l_1020 = &l_1018;
                    const uint32_t **l_1022 = (void*)0;
                    const uint32_t ***l_1021 = &l_1022;
                    int8_t *l_1026 = &l_769;
                    int32_t *l_1027[8][6] = {{&l_774[g_704][g_704],(void*)0,&g_462,&l_900,&l_900,&g_462},{&l_900,&l_900,&g_462,(void*)0,&l_774[g_704][g_704],&l_774[g_704][g_704]},{&l_900,(void*)0,(void*)0,&l_900,&l_774[g_704][g_704],&g_462},{&l_774[g_704][g_704],&l_900,(void*)0,(void*)0,&l_900,&l_774[g_704][g_704]},{&l_774[g_704][g_704],(void*)0,&g_462,&l_900,&l_900,&g_462},{&l_900,&l_900,&g_462,(void*)0,&l_774[g_704][g_704],&l_774[g_704][g_704]},{&l_900,(void*)0,(void*)0,&l_900,&l_774[g_704][g_704],&g_462},{&l_774[g_704][g_704],&l_900,(void*)0,(void*)0,&l_900,&l_774[g_704][g_704]}};
                    int i, j;
                    l_1028 |= (safe_lshift_func_int8_t_s_s((~(safe_lshift_func_uint16_t_u_s(((safe_mul_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((**l_833), (safe_mul_func_int8_t_s_s(l_964, (*g_22))))), (safe_sub_func_int8_t_s_s((*g_22), ((*l_1026) = (+((safe_sub_func_uint64_t_u_u(((*l_951) |= ((p_51 != ((safe_add_func_int64_t_s_s(((((*l_1021) = ((*l_1020) = l_1018)) == (void*)0) >= l_1023), (safe_mod_func_int8_t_s_s((*g_22), 0x4CL)))) || l_976)) , p_51)), g_727.f1)) && 0UL))))))) || l_928), (*g_44)))), 3));
                }
            }
            for (l_964 = 0; (l_964 >= 16); l_964 = safe_add_func_int64_t_s_s(l_964, 8))
            { /* block id: 443 */
                int16_t l_1038[10] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
                uint8_t *l_1039 = (void*)0;
                uint8_t *l_1040[5][6][8] = {{{&g_117[0],&g_117[0],&g_117[0],&g_117[0],&g_117[5],&g_117[2],&g_120,&g_117[0]},{&g_117[2],&g_117[0],&g_117[0],&g_117[6],&g_120,(void*)0,&g_117[5],&g_117[5]},{&g_117[2],&g_117[5],(void*)0,(void*)0,&g_117[5],&g_117[2],&g_117[0],&g_117[0]},{&g_117[0],(void*)0,(void*)0,&g_117[0],&g_117[0],&g_120,&g_117[0],&g_117[0]},{&g_120,&g_117[0],&g_120,&g_117[0],&g_120,&g_117[0],&g_120,&g_117[0]},{&g_117[0],&g_120,&g_117[6],(void*)0,&g_117[0],&g_117[0],&g_120,&g_117[5]}},{{(void*)0,&g_117[2],&g_117[0],&g_117[6],&g_117[0],&g_120,&g_120,&g_117[0]},{&g_117[0],&g_117[6],&g_117[6],&g_117[0],&g_117[0],&g_117[0],&g_120,&g_117[2]},{&g_117[0],&g_117[0],&g_120,&g_117[2],&g_120,&g_117[0],&g_117[0],&g_117[2]},{&g_117[0],&g_117[0],(void*)0,&g_117[0],(void*)0,&g_117[0],&g_117[0],(void*)0},{&g_120,&g_117[6],(void*)0,&g_117[0],&g_117[0],&g_120,&g_117[5],(void*)0},{(void*)0,&g_117[2],&g_117[0],&g_120,&g_117[0],&g_117[0],&g_120,&g_117[0]}},{{&g_120,&g_120,&g_117[0],(void*)0,(void*)0,&g_117[0],&g_117[0],&g_120},{&g_117[0],(void*)0,&g_120,&g_117[0],&g_120,&g_117[0],&g_120,&g_117[0]},{(void*)0,&g_117[6],&g_117[0],&g_117[6],(void*)0,&g_117[0],&g_117[0],(void*)0},{&g_117[0],&g_120,&g_117[2],&g_120,&g_117[0],&g_117[0],&g_117[0],&g_117[6]},{&g_117[0],&g_117[0],&g_117[2],(void*)0,(void*)0,&g_117[2],&g_117[0],&g_117[0]},{&g_117[0],&g_117[2],&g_117[0],(void*)0,&g_120,&g_120,&g_120,&g_117[2]}},{{(void*)0,&g_120,&g_120,&g_117[0],(void*)0,&g_120,(void*)0,&g_117[0]},{&g_117[0],&g_117[2],&g_117[0],&g_117[0],&g_120,&g_117[2],&g_120,&g_117[0]},{&g_117[0],&g_117[0],(void*)0,&g_120,(void*)0,&g_117[0],&g_120,&g_120},{&g_117[0],&g_120,&g_117[0],&g_117[0],&g_120,&g_117[0],&g_117[2],(void*)0},{&g_117[0],&g_117[6],&g_117[0],&g_117[2],(void*)0,&g_117[0],&g_117[0],(void*)0},{(void*)0,(void*)0,&g_117[0],&g_117[2],&g_120,&g_117[2],&g_117[0],(void*)0}},{{&g_117[0],&g_120,&g_120,&g_117[0],(void*)0,&g_117[0],(void*)0,&g_120},{&g_117[0],&g_117[2],(void*)0,&g_120,&g_117[0],(void*)0,(void*)0,&g_117[0]},{&g_117[0],&g_120,&g_120,&g_117[0],(void*)0,(void*)0,&g_117[0],&g_117[0]},{(void*)0,(void*)0,&g_117[0],&g_117[0],&g_120,&g_117[0],&g_117[0],&g_117[2]},{&g_117[2],(void*)0,&g_117[0],(void*)0,&g_117[0],(void*)0,&g_117[2],&g_117[0]},{&g_120,&g_120,&g_117[0],(void*)0,&g_117[0],(void*)0,&g_120,&g_117[6]}}};
                uint16_t *l_1041 = &g_80[0][1][0];
                uint64_t *l_1050 = &g_216[2];
                uint64_t **l_1049 = &l_1050;
                uint64_t ***l_1048 = &l_1049;
                int32_t l_1086[5] = {0xC828034BL,0xC828034BL,0xC828034BL,0xC828034BL,0xC828034BL};
                int32_t *l_1087[6] = {&l_788,&l_788,&l_788,&l_788,&l_788,&l_788};
                uint16_t l_1092 = 65532UL;
                int i, j, k;
            }
            l_1102--;
        }
        for (l_900 = 0; (l_900 != 12); l_900 = safe_add_func_uint64_t_u_u(l_900, 6))
        { /* block id: 487 */
            uint32_t l_1117[6][7][2];
            int32_t l_1139 = 0x48CC7EB3L;
            union U1 **l_1144 = &g_93[0];
            uint64_t *l_1151[6];
            int32_t l_1172 = (-1L);
            int i, j, k;
            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 7; j++)
                {
                    for (k = 0; k < 2; k++)
                        l_1117[i][j][k] = 0xCA1BC970L;
                }
            }
            for (i = 0; i < 6; i++)
                l_1151[i] = (void*)0;
            if ((safe_mul_func_uint16_t_u_u(((safe_add_func_int8_t_s_s((safe_mod_func_int16_t_s_s((l_1090 &= ((1L > (((safe_sub_func_int32_t_s_s(((safe_add_func_uint64_t_u_u((--l_1117[1][2][0]), (safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s((++(*l_787)), 6)) , l_964), p_51)), l_1100[4])))) , (*g_961)), (safe_rshift_func_uint8_t_u_s((((+((safe_add_func_uint64_t_u_u(g_183.f1, ((*l_797) = ((safe_sub_func_uint16_t_u_u(0x8C9AL, ((safe_add_func_uint64_t_u_u((l_1139 = (g_216[1] = (safe_mod_func_int8_t_s_s(((((*g_1054) , ((((*p_54) , &p_51) == &p_51) ^ (-1L))) >= (*p_55)) & g_146[3].f1), 6UL)))), l_1140)) || 0L))) >= g_843[1].f0)))) < l_950)) , 0x3465E09B08DAF22ELL) >= l_950), 0)))) | (*g_44)) < 0x8D8124A4E9ACB9ADLL)) , l_1100[4])), (*p_55))), 0xECL)) == (-3L)), 0x7AEEL)))
            { /* block id: 494 */
                union U1 ***l_1142[4] = {&l_1141[8],&l_1141[8],&l_1141[8],&l_1141[8]};
                int i;
                l_1144 = (g_1143 = l_1141[3]);
                for (g_148 = 29; (g_148 <= 25); g_148 = safe_sub_func_uint8_t_u_u(g_148, 4))
                { /* block id: 499 */
                    int8_t *l_1147 = &g_23;
                    if (p_51)
                        break;
                    return l_1147;
                }
                for (l_769 = 2; (l_769 >= 0); l_769 -= 1)
                { /* block id: 505 */
                    return p_52;
                }
                (*g_512) = (*g_808);
            }
            else
            { /* block id: 509 */
                int8_t l_1148[10][4][6] = {{{0L,0xE1L,0xD4L,(-2L),1L,(-6L)},{0xC6L,0xC2L,0xB3L,(-2L),0x65L,0L},{0L,0xE1L,0x62L,0L,0x62L,0xE1L},{(-1L),0x7EL,0xB5L,0xB7L,0xC6L,0L}},{{0xD4L,0xB7L,9L,0xE1L,0x94L,(-6L)},{0xB3L,0xB7L,0x5EL,6L,0xC6L,1L},{0x62L,0x7EL,1L,0x7EL,0xD4L,0xE1L},{0x5EL,0xC2L,0x7BL,0xE1L,0xB5L,1L}},{{9L,0L,1L,0xC2L,0x94L,1L},{(-1L),1L,0x7BL,0xE1L,0x65L,0xE1L},{0x94L,6L,0x94L,0x7EL,0xFCL,(-6L)},{0x7BL,1L,(-1L),0xB7L,0L,(-2L)}},{{1L,0L,9L,0xB7L,0x62L,0x7EL},{0x7BL,0xC2L,0x5EL,0x7EL,0x5EL,0xC2L},{0x94L,0xCBL,0xD4L,0xE1L,1L,0x7EL},{(-1L),0xE1L,0xC6L,0xC2L,0xB3L,(-2L)}},{{9L,0xE1L,1L,0xE1L,1L,(-6L)},{0x5EL,0xCBL,0L,0xCBL,0x5EL,0xE1L},{0xD4L,0xC2L,0x40L,0xE1L,0x62L,1L},{0xC6L,0L,0x79L,0xC2L,0L,1L}},{{1L,1L,0x40L,0xE1L,0xFCL,0xE1L},{0L,6L,0L,0x7EL,0x65L,(-6L)},{0x40L,1L,1L,0xB7L,0x94L,(-2L)},{0x79L,0L,0xC6L,0xB7L,0xB5L,0x7EL}},{{0x40L,0xC2L,0xD4L,0x7EL,0xD4L,0xC2L},{0L,0xCBL,0x5EL,0xE1L,0x79L,0x7EL},{1L,0xE1L,9L,0xC2L,9L,(-2L)},{0xC6L,0xE1L,(-1L),0xE1L,0x79L,(-6L)}},{{0xD4L,0xCBL,0x94L,0xCBL,0xD4L,0xE1L},{0x5EL,0xC2L,0x7BL,0xE1L,0xB5L,1L},{9L,0L,1L,0xC2L,0x94L,1L},{(-1L),1L,0x7BL,0xE1L,0x65L,0xE1L}},{{0x94L,6L,0x94L,0x7EL,0xFCL,(-6L)},{0x7BL,1L,(-1L),0xB7L,0L,(-2L)},{1L,0L,9L,0xB7L,0x62L,0x7EL},{0x7BL,0xC2L,0x5EL,0x7EL,0x5EL,0xC2L}},{{0x94L,0xCBL,0xD4L,0xE1L,1L,0x7EL},{(-1L),0xE1L,0xC6L,0xC2L,0xB3L,(-2L)},{9L,0xE1L,1L,1L,0L,(-2L)},{(-1L),6L,0xB3L,6L,(-1L),0xC2L}}};
                int i, j, k;
                for (g_158 = 5; (g_158 >= 0); g_158 -= 1)
                { /* block id: 512 */
                    if (l_1148[8][1][0])
                        break;
                    return p_52;
                }
            }
            (*g_1150) = ((*l_833) = &l_1100[1]);
            if ((((**l_833) = 18446744073709551615UL) < 0L))
            { /* block id: 520 */
                union U1 *l_1156[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_1156[i] = &g_91;
                if (l_1152)
                    break;
                if (p_51)
                    continue;
                if (l_769)
                    goto lbl_1153;
                for (g_275.f4 = 0; (g_275.f4 > 29); g_275.f4 = safe_add_func_uint16_t_u_u(g_275.f4, 2))
                { /* block id: 526 */
                    l_1139 = p_51;
                    for (g_45 = 0; (g_45 <= 3); g_45 += 1)
                    { /* block id: 530 */
                        (*l_1144) = l_1156[0];
                        if ((**g_184))
                            break;
                    }
                }
            }
            else
            { /* block id: 535 */
                int32_t ***l_1162 = (void*)0;
                int32_t ***l_1163[3][7] = {{&l_833,&l_833,&l_833,&l_833,&l_833,&l_833,&l_833},{(void*)0,&l_833,(void*)0,&l_833,&l_833,(void*)0,&l_833},{&l_833,&l_833,&l_833,&l_833,&l_833,&l_833,&l_833}};
                uint32_t *l_1169 = (void*)0;
                uint32_t *l_1170[10];
                int i, j;
                for (i = 0; i < 10; i++)
                    l_1170[i] = (void*)0;
                (*g_902) = p_51;
                l_1172 ^= ((((safe_mod_func_int16_t_s_s((g_1159 , (+(((!((((*p_54) < (((((g_1164 = &g_185) == (g_1165 = &g_185)) & p_51) , (safe_mul_func_int16_t_s_s((*g_44), 0x24C4L))) <= 0xAC21205DL)) != ((g_664.f0 = (~l_1139)) , (*g_22))) , 18446744073709551609UL)) , (*g_732)) , (**l_833)))), (*g_44))) != g_1171) > 0xD107D608L) >= (*g_22));
            }
        }
        l_1173 = ((*g_1164) = (*l_833));
    }
    return p_52;
}


/* ------------------------------------------ */
/* 
 * reads : g_63.f0 g_45 g_23 g_12 g_87 g_94 g_184 g_63 g_385.f1 g_591 g_180 g_111 g_80 g_91 g_385.f3 g_22 g_275.f3 g_63.f4 g_158 g_237.f2 g_437 g_462 g_176 g_704 g_372.f1 g_93 g_512 g_185 g_730 g_731 g_734 g_183.f0 g_436 g_183.f1 g_44 g_83.f4 g_207
 * writes: g_63.f0 g_80 g_83.f4 g_87 g_93 g_63.f4 g_185 g_117 g_45 g_23 g_158 g_462 g_666 g_183.f0
 */
static uint8_t  func_56(uint64_t  p_57, int16_t * p_58)
{ /* block id: 4 */
    union U0 * const l_62 = &g_63;
    const int16_t *l_72 = &g_45;
    uint32_t *l_75 = &g_63.f0;
    int32_t l_78 = 0x51CC0D68L;
    uint32_t *l_79[4];
    union U0 *l_82[3];
    union U0 **l_81 = &l_82[1];
    union U1 *l_90 = &g_91;
    int8_t *l_98[9][2][9] = {{{&g_23,&g_23,&g_23,(void*)0,&g_23,&g_23,&g_23,&g_23,&g_23},{&g_23,&g_23,(void*)0,(void*)0,&g_23,&g_23,(void*)0,(void*)0,&g_23}},{{&g_23,&g_23,&g_23,&g_23,(void*)0,&g_23,&g_23,&g_23,&g_23},{&g_23,(void*)0,&g_23,&g_23,(void*)0,&g_23,(void*)0,&g_23,&g_23}},{{&g_23,&g_23,(void*)0,&g_23,(void*)0,&g_23,(void*)0,&g_23,&g_23},{&g_23,&g_23,(void*)0,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23}},{{(void*)0,&g_23,(void*)0,&g_23,&g_23,&g_23,(void*)0,&g_23,(void*)0},{&g_23,(void*)0,&g_23,(void*)0,(void*)0,&g_23,&g_23,&g_23,(void*)0}},{{&g_23,&g_23,&g_23,&g_23,(void*)0,(void*)0,&g_23,&g_23,(void*)0},{&g_23,(void*)0,(void*)0,&g_23,&g_23,(void*)0,&g_23,&g_23,(void*)0}},{{(void*)0,&g_23,&g_23,&g_23,(void*)0,&g_23,(void*)0,(void*)0,&g_23},{(void*)0,(void*)0,&g_23,&g_23,(void*)0,(void*)0,&g_23,&g_23,&g_23}},{{&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,(void*)0,&g_23},{&g_23,&g_23,&g_23,(void*)0,&g_23,(void*)0,&g_23,&g_23,&g_23}},{{&g_23,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_23,&g_23,&g_23},{(void*)0,&g_23,(void*)0,&g_23,(void*)0,&g_23,&g_23,(void*)0,&g_23}},{{&g_23,(void*)0,&g_23,(void*)0,(void*)0,&g_23,(void*)0,&g_23,&g_23},{&g_23,&g_23,&g_23,(void*)0,&g_23,&g_23,&g_23,&g_23,&g_23}}};
    int32_t l_129 = 0x43F0C890L;
    int32_t l_131[5];
    uint32_t l_132 = 18446744073709551610UL;
    const uint16_t *l_175[8][7] = {{&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176},{(void*)0,&g_176,&g_176,&g_176,&g_176,&g_176,(void*)0},{&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176},{(void*)0,&g_176,&g_176,&g_176,(void*)0,&g_176,(void*)0},{&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176},{&g_176,&g_176,&g_176,&g_176,(void*)0,&g_176,&g_176},{&g_176,&g_176,&g_176,&g_176,&g_176,&g_176,&g_176},{(void*)0,&g_176,&g_176,&g_176,&g_176,&g_176,(void*)0}};
    uint32_t l_190 = 18446744073709551611UL;
    int64_t l_306 = 6L;
    int16_t * const *l_405 = &g_44;
    int16_t * const **l_404[4] = {&l_405,&l_405,&l_405,&l_405};
    uint8_t *l_461 = &g_117[0];
    uint8_t l_483 = 0UL;
    int16_t l_532 = 0xD341L;
    int32_t *l_534[3];
    int32_t * const *l_533 = &l_534[1];
    int32_t l_568 = 0x6F3CB65BL;
    uint64_t l_626 = 0x9C9CEACA92FCE6FDLL;
    const int32_t l_628 = 0L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_79[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_82[i] = &g_83;
    for (i = 0; i < 5; i++)
        l_131[i] = 0xAD646978L;
    for (i = 0; i < 3; i++)
        l_534[i] = &g_137;
lbl_89:
    (*l_81) = ((safe_div_func_int32_t_s_s(((void*)0 == l_62), (g_80[0][1][0] = (((((safe_lshift_func_uint8_t_u_s(p_57, 3)) | (safe_add_func_int64_t_s_s((((safe_mod_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((((p_58 != ((&g_45 != &g_45) , l_72)) , (((safe_add_func_uint32_t_u_u(((*l_75) ^= 4294967291UL), (safe_mod_func_int8_t_s_s((((p_57 , g_45) | (*p_58)) ^ 0xD526L), 0x5CL)))) >= g_45) | g_23)) , p_57), l_78)), p_57)) < l_78) && 18446744073709551615UL), g_12))) ^ 6UL) | 0x6DE45221L) , 1UL)))) , (void*)0);
    for (g_83.f4 = 3; (g_83.f4 < (-24)); g_83.f4 = safe_sub_func_int32_t_s_s(g_83.f4, 5))
    { /* block id: 10 */
        int32_t *l_88 = &g_87;
        (*l_88) &= (l_78 & l_78);
        (*l_88) ^= p_57;
        if (g_12)
            goto lbl_89;
        (*g_94) = l_90;
    }
    for (g_63.f4 = 0; (g_63.f4 <= 0); g_63.f4 += 1)
    { /* block id: 18 */
        int8_t *l_99 = &g_23;
        int32_t l_103 = (-6L);
        int32_t l_127 = 0L;
        int32_t l_128[10][4][5] = {{{1L,0x4854C362L,0x66FFE497L,(-1L),(-1L)},{0L,8L,0L,0xB3BFA596L,8L},{(-1L),0L,0x0527DF68L,(-1L),0x0527DF68L},{0x35B57BD3L,0x35B57BD3L,0x188D8CC6L,8L,0x3435D61FL}},{{(-4L),1L,0x0527DF68L,0x0527DF68L,1L},{0x3435D61FL,0L,0L,0x3435D61FL,0xB3BFA596L},{0x4854C362L,1L,0x66FFE497L,1L,0x4854C362L},{0L,0x35B57BD3L,0L,0xB3BFA596L,0x35B57BD3L}},{{0x4854C362L,0L,0L,0x4854C362L,0x0527DF68L},{0x3435D61FL,8L,0x188D8CC6L,0x35B57BD3L,0x35B57BD3L},{(-4L),0x4854C362L,(-4L),0x0527DF68L,0x4854C362L},{0x35B57BD3L,0L,0xB3BFA596L,0x35B57BD3L,0xB3BFA596L}},{{(-1L),(-1L),0x66FFE497L,0x4854C362L,1L},{0L,0x3435D61FL,0xB3BFA596L,0xB3BFA596L,0x3435D61FL},{1L,0L,(-4L),1L,0x0527DF68L},{8L,0x3435D61FL,0x188D8CC6L,0x3435D61FL,8L}},{{(-4L),(-1L),0L,0x0527DF68L,(-1L)},{8L,0L,0L,8L,0xB3BFA596L},{1L,0x4854C362L,0x66FFE497L,(-1L),(-1L)},{0L,8L,0L,0xB3BFA596L,8L}},{{(-1L),0L,0x0527DF68L,(-1L),0x0527DF68L},{0x35B57BD3L,0x35B57BD3L,0x188D8CC6L,8L,0x3435D61FL},{(-4L),1L,0x0527DF68L,0x0527DF68L,1L},{0x3435D61FL,0L,0L,0x3435D61FL,0xB3BFA596L}},{{0x4854C362L,1L,0x66FFE497L,1L,0x4854C362L},{0L,0x35B57BD3L,0L,0xB3BFA596L,0L},{0L,0x66FFE497L,0x66FFE497L,0L,0x595B8C60L},{0xB3BFA596L,0L,0x35B57BD3L,0L,0L}},{{1L,0L,1L,0x595B8C60L,0L},{0L,0x188D8CC6L,0x02F93315L,0L,0x02F93315L},{(-4L),(-4L),(-1L),0L,0x0527DF68L},{1L,0xB3BFA596L,0x02F93315L,0x02F93315L,0xB3BFA596L}},{{0x0527DF68L,0x66FFE497L,1L,0x0527DF68L,0x595B8C60L},{0L,0xB3BFA596L,0x35B57BD3L,0xB3BFA596L,0L},{1L,(-4L),0x66FFE497L,0x595B8C60L,(-4L)},{0L,0x188D8CC6L,0x188D8CC6L,0L,0x02F93315L}},{{0x0527DF68L,0L,(-1L),(-4L),(-4L)},{1L,0L,1L,0x02F93315L,0L},{(-4L),0x66FFE497L,0x595B8C60L,(-4L),0x595B8C60L},{0L,0L,0x35B57BD3L,0L,0xB3BFA596L}}};
        int8_t l_189 = (-10L);
        union U1 l_241 = {-1L};
        uint16_t l_292[7];
        uint16_t ** const l_305 = (void*)0;
        uint16_t l_395 = 0xE426L;
        int32_t l_435[2][5][5] = {{{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L}},{{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L},{(-2L),(-2L),7L,0xEF1913D5L,7L}}};
        int8_t l_563 = (-9L);
        int64_t l_570 = 0x389BD78D6FBD9EF4LL;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_292[i] = 0x3EBFL;
    }
    for (l_568 = 0; (l_568 <= 0); l_568 += 1)
    { /* block id: 229 */
        int32_t *l_574 = &l_131[0];
        int32_t *l_575 = &g_87;
        int32_t *l_576 = (void*)0;
        int32_t *l_577 = &l_131[0];
        int32_t *l_578 = &g_87;
        int32_t *l_579 = (void*)0;
        int32_t *l_580[4];
        uint64_t l_581 = 0xE0D16FD0BA5949A2LL;
        int32_t **l_584[9][10] = {{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185,&g_185}};
        uint16_t l_598 = 5UL;
        union U0 *l_662 = &g_372;
        union U1 l_669 = {0x3D1D808DL};
        int8_t **l_707[1][5][1] = {{{&g_22},{(void*)0},{&g_22},{(void*)0},{&g_22}}};
        union U1 *l_729 = &l_669;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_580[i] = &g_462;
        l_581++;
        (*g_184) = (void*)0;
        l_129 = ((*l_62) , ((safe_mod_func_uint16_t_u_u((p_57 | (safe_mul_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u(6UL, g_385[2].f1)) < p_57), g_591))), p_57)) , ((safe_mod_func_int64_t_s_s(0L, (safe_mul_func_int16_t_s_s((((**g_180) , p_57) != 0x179CCE44L), p_57)))) | p_57)));
        for (l_532 = 0; (l_532 <= 0); l_532 += 1)
        { /* block id: 235 */
            int64_t l_597 = 0L;
            int32_t l_643 = (-1L);
            int64_t *l_680 = &l_306;
            int64_t **l_679 = &l_680;
            union U1 *l_693 = &l_669;
            union U0 *l_725 = &g_664;
            uint8_t l_728 = 253UL;
            for (l_483 = 0; (l_483 <= 0); l_483 += 1)
            { /* block id: 238 */
                int8_t l_596 = 1L;
                ++l_598;
            }
            for (g_87 = 0; (g_87 >= 0); g_87 -= 1)
            { /* block id: 243 */
                int64_t *l_611 = &l_306;
                int64_t **l_612 = &l_611;
                union U1 l_615[9] = {{0xCFD169A8L},{1L},{0xCFD169A8L},{1L},{0xCFD169A8L},{1L},{0xCFD169A8L},{1L},{0xCFD169A8L}};
                uint8_t *l_637[3];
                int32_t **l_651 = &l_534[1];
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_637[i] = (void*)0;
                if (g_80[(g_87 + 7)][(l_532 + 1)][l_532])
                    break;
                if (l_78)
                    goto lbl_89;
                if ((safe_lshift_func_uint16_t_u_s((g_80[(l_568 + 4)][(l_532 + 1)][g_87] = (safe_rshift_func_uint8_t_u_s(((*l_461) = (p_57 >= (-1L))), 5))), ((safe_div_func_uint8_t_u_u(((((*l_90) , (safe_mul_func_int16_t_s_s((safe_div_func_int64_t_s_s((((p_57 , &g_591) == ((*l_612) = l_611)) > (safe_mod_func_int16_t_s_s((g_385[2].f3 , 0x8D43L), ((*p_58) &= 1L)))), l_597)), p_57))) , l_615[5]) , l_131[1]), p_57)) || p_57))))
                { /* block id: 250 */
                    uint16_t *l_627 = &l_598;
                    if ((safe_rshift_func_int8_t_s_s((safe_add_func_int32_t_s_s(0x3A784D35L, ((*l_75) = ((safe_div_func_uint64_t_u_u(p_57, (((0xF8A1C4C7FDF33184LL && (safe_rshift_func_uint8_t_u_u(p_57, 6))) > p_57) ^ g_80[(g_87 + 7)][(l_532 + 1)][l_532]))) , (((*l_627) = ((safe_sub_func_uint64_t_u_u(p_57, ((**l_612) = ((l_626 ^ 9UL) != (*g_22))))) | 0x7BL)) & (-4L)))))), 1)))
                    { /* block id: 254 */
                        return p_57;
                    }
                    else
                    { /* block id: 256 */
                        uint8_t l_629[9][3];
                        int i, j;
                        for (i = 0; i < 9; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_629[i][j] = 0x82L;
                        }
                        l_78 &= ((l_628 < l_615[5].f0) == 248UL);
                        if (l_629[4][2])
                            break;
                        return l_597;
                    }
                }
                else
                { /* block id: 261 */
                    uint16_t *l_634 = &g_80[(l_568 + 4)][(l_532 + 1)][g_87];
                    uint16_t *l_640 = (void*)0;
                    uint16_t *l_641 = (void*)0;
                    uint16_t *l_642[7][8] = {{(void*)0,(void*)0,&l_598,&l_598,(void*)0,&l_598,&l_598,(void*)0},{&l_598,(void*)0,&l_598,&l_598,(void*)0,&l_598,&l_598,(void*)0},{(void*)0,&l_598,&l_598,(void*)0,&l_598,&l_598,(void*)0,&l_598},{&l_598,(void*)0,&l_598,&l_598,&l_598,&l_598,&l_598,&l_598},{&l_598,(void*)0,&l_598,&l_598,&l_598,&l_598,&l_598,(void*)0},{(void*)0,&l_598,&l_598,&l_598,&l_598,&l_598,&l_598,&l_598},{&l_598,(void*)0,&l_598,(void*)0,(void*)0,&l_598,&l_598,&l_598}};
                    int32_t l_650 = (-1L);
                    int i, j;
                    (*l_574) = (l_532 <= (p_57 == ((p_57 ^ (safe_mul_func_int8_t_s_s(((&g_44 == (void*)0) > ((*g_22) = (safe_rshift_func_uint8_t_u_s((((*l_634)--) == (l_637[1] == ((safe_rshift_func_uint16_t_u_s((l_643 = 9UL), 12)) , (void*)0))), ((safe_mod_func_int32_t_s_s((safe_div_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((((g_275.f3 ^ l_650) <= p_57) , l_651) == (void*)0), 1UL)), 0x8FL)), g_63.f4)) , p_57))))), l_597))) > p_57)));
                    if (l_650)
                        break;
                }
            }
            if (((*l_575) = p_57))
            { /* block id: 270 */
                uint16_t *l_661 = &g_80[9][0][0];
                uint16_t * const *l_660 = &l_661;
                union U0 *l_663 = &g_664;
                int32_t l_705 = 0x157F5AFCL;
                uint32_t l_724[5] = {0xE1080DC3L,0xE1080DC3L,0xE1080DC3L,0xE1080DC3L,0xE1080DC3L};
                int i;
                for (g_158 = 0; (g_158 == (-26)); --g_158)
                { /* block id: 273 */
                    int64_t *l_659 = &l_306;
                    const union U0 *l_665 = &g_146[3];
                    const int32_t l_684 = 0xBB54D2A1L;
                    int32_t l_692 = 0xB9211B6AL;
                    int32_t *l_706[10][2][4] = {{{(void*)0,&g_87,(void*)0,&l_705},{&l_692,(void*)0,&l_692,(void*)0}},{{&l_643,&g_704,(void*)0,&l_643},{(void*)0,(void*)0,&l_643,&g_704}},{{(void*)0,(void*)0,&l_643,&l_643},{(void*)0,(void*)0,(void*)0,&l_705}},{{&l_643,(void*)0,&l_692,&g_704},{&l_692,&g_704,(void*)0,&l_692}},{{(void*)0,&g_704,&g_87,&g_704},{&g_704,(void*)0,&l_643,&l_705}},{{&g_87,(void*)0,(void*)0,&l_643},{&l_643,(void*)0,(void*)0,&g_704}},{{&l_643,(void*)0,(void*)0,&l_643},{&g_87,&g_704,&l_643,(void*)0}},{{&g_704,(void*)0,&g_87,&l_705},{(void*)0,&g_87,(void*)0,&l_705}},{{&l_692,(void*)0,&l_692,(void*)0},{&l_643,&g_704,(void*)0,&l_643}},{{(void*)0,(void*)0,&l_643,&g_704},{(void*)0,(void*)0,&l_643,&l_643}}};
                    union U1 *l_717[9];
                    int64_t l_723 = 0x05E2550533139F84LL;
                    int i, j, k;
                    for (i = 0; i < 9; i++)
                        l_717[i] = &l_669;
                    g_462 |= (0UL ^ (((((*l_659) = (~(safe_div_func_uint32_t_u_u(g_237.f2, (safe_div_func_uint64_t_u_u(p_57, (*l_574))))))) < (0xAC16B911CB144BCELL >= 0xA6256DB0726DE4C1LL)) , g_437[1]) != l_660));
                    if (((l_663 = l_662) == (g_666 = l_665)))
                    { /* block id: 278 */
                        return p_57;
                    }
                    else
                    { /* block id: 280 */
                        uint64_t **l_667 = (void*)0;
                        uint64_t *l_668 = &l_626;
                        union U1 l_672 = {0x54D5ABD1L};
                        int64_t ***l_681 = &l_679;
                        union U1 **l_718[7] = {&l_717[1],&l_717[1],&l_90,&l_717[1],&l_717[1],&l_90,&l_717[1]};
                        union U0 *l_726 = &g_727;
                        int i;
                        l_643 = ((*l_577) = ((l_668 = &p_57) != ((((((l_669 , (safe_rshift_func_uint16_t_u_u((((*g_22) = ((l_672 , (safe_lshift_func_uint8_t_u_s((safe_div_func_int32_t_s_s(((*l_575) &= (8L >= (safe_sub_func_uint16_t_u_u((((*l_681) = l_679) == (void*)0), (safe_lshift_func_uint16_t_u_u(l_684, 14)))))), (safe_mod_func_int8_t_s_s(l_597, ((+((safe_add_func_uint8_t_u_u(((safe_add_func_int8_t_s_s((l_692 ^= p_57), p_57)) && p_57), 0x70L)) , 4294967295UL)) , (*g_22)))))), 3))) && (*g_22))) ^ p_57), p_57))) < l_132) && 0L) && p_57) | l_129) , &p_57)));
                        l_706[8][0][1] = ((l_693 == ((p_57 , ((-1L) | (((safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((((safe_rshift_func_int16_t_s_u((0x94L > (p_57 && (((((*l_574) = ((safe_mul_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((p_58 == p_58) > ((p_58 == &l_598) , g_176)), l_672.f0)), g_704)) >= 65531UL)) != g_372.f1) && p_57) && p_57))), p_57)) > p_57) < l_705), (*p_58))), p_57)) & 0xA5C3451C2796F77BLL) != l_672.f0))) , (*g_94))) , (*g_512));
                        (*l_575) ^= (((void*)0 == l_707[0][2][0]) && (p_57 | (safe_add_func_int8_t_s_s((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((*p_58), 8)), p_57)), (safe_sub_func_int64_t_s_s(((p_57 & (~(((l_90 = l_717[1]) != ((safe_mod_func_uint64_t_u_u(l_705, (safe_mul_func_int8_t_s_s((*g_22), l_723)))) , l_717[1])) == 0x8E26C9F664D8CC15LL))) & 0xA6L), l_724[0]))))));
                        l_726 = l_725;
                    }
                    if (l_728)
                        continue;
                }
            }
            else
            { /* block id: 296 */
                uint32_t l_735 = 0xE1925B80L;
                uint32_t *l_761 = (void*)0;
                uint32_t **l_760 = &l_761;
                uint32_t * const l_762 = &l_132;
                (*g_730) = l_729;
                (*l_577) = (l_577 == ((p_57 > ((*l_575) = ((void*)0 != g_731))) , g_734));
                for (g_183.f0 = 0; (g_183.f0 <= 6); g_183.f0 += 1)
                { /* block id: 302 */
                    --l_735;
                    (*g_512) = (*g_436);
                }
                (*g_512) = ((safe_mod_func_uint8_t_u_u((((((safe_div_func_uint32_t_u_u((safe_add_func_int8_t_s_s((*g_22), ((safe_sub_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_div_func_int64_t_s_s(((l_735 , (safe_add_func_uint32_t_u_u(g_183.f1, (safe_rshift_func_int16_t_s_s(((safe_div_func_int64_t_s_s((((safe_sub_func_uint32_t_u_u(((-2L) >= (((**l_405) = (safe_div_func_uint16_t_u_u((((*g_22) & (((*l_760) = g_185) != l_762)) , ((safe_mul_func_uint16_t_u_u((l_532 || (g_591 , (*g_44))), l_568)) , l_129)), 0xE930L))) != g_462)), g_83.f4)) == 0xE28945E3L) ^ (*l_578)), p_57)) || (*p_58)), l_735))))) == l_735), (*l_578))), p_57)), p_57)) != 0x8FL))), g_207)) | l_626) | 0x20L) , (-2L)) , p_57), p_57)) , (*g_436));
            }
            return l_132;
        }
    }
    return p_57;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_63.f0, "g_63.f0", print_hash_value);
    transparent_crc(g_63.f1, "g_63.f1", print_hash_value);
    transparent_crc(g_63.f2, "g_63.f2", print_hash_value);
    transparent_crc(g_63.f3, "g_63.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_80[i][j][k], "g_80[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_83.f0, "g_83.f0", print_hash_value);
    transparent_crc(g_83.f1, "g_83.f1", print_hash_value);
    transparent_crc(g_83.f2, "g_83.f2", print_hash_value);
    transparent_crc(g_83.f3, "g_83.f3", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_91.f1, "g_91.f1", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_117[i], "g_117[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_146[i].f0, "g_146[i].f0", print_hash_value);
        transparent_crc(g_146[i].f1, "g_146[i].f1", print_hash_value);
        transparent_crc(g_146[i].f2, "g_146[i].f2", print_hash_value);
        transparent_crc(g_146[i].f3, "g_146[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_183.f0, "g_183.f0", print_hash_value);
    transparent_crc(g_183.f1, "g_183.f1", print_hash_value);
    transparent_crc(g_183.f2, "g_183.f2", print_hash_value);
    transparent_crc(g_183.f3, "g_183.f3", print_hash_value);
    transparent_crc(g_183.f4, "g_183.f4", print_hash_value);
    transparent_crc(g_207, "g_207", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_216[i], "g_216[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_237.f0, "g_237.f0", print_hash_value);
    transparent_crc(g_237.f1, "g_237.f1", print_hash_value);
    transparent_crc(g_237.f2, "g_237.f2", print_hash_value);
    transparent_crc(g_237.f3, "g_237.f3", print_hash_value);
    transparent_crc(g_275.f0, "g_275.f0", print_hash_value);
    transparent_crc(g_275.f1, "g_275.f1", print_hash_value);
    transparent_crc(g_275.f2, "g_275.f2", print_hash_value);
    transparent_crc(g_275.f3, "g_275.f3", print_hash_value);
    transparent_crc(g_372.f0, "g_372.f0", print_hash_value);
    transparent_crc(g_372.f1, "g_372.f1", print_hash_value);
    transparent_crc(g_372.f2, "g_372.f2", print_hash_value);
    transparent_crc(g_372.f3, "g_372.f3", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_385[i].f0, "g_385[i].f0", print_hash_value);
        transparent_crc(g_385[i].f1, "g_385[i].f1", print_hash_value);
        transparent_crc(g_385[i].f2, "g_385[i].f2", print_hash_value);
        transparent_crc(g_385[i].f3, "g_385[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_401[i][j][k].f0, "g_401[i][j][k].f0", print_hash_value);
                transparent_crc(g_401[i][j][k].f1, "g_401[i][j][k].f1", print_hash_value);
                transparent_crc(g_401[i][j][k].f2, "g_401[i][j][k].f2", print_hash_value);
                transparent_crc(g_401[i][j][k].f3, "g_401[i][j][k].f3", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_462, "g_462", print_hash_value);
    transparent_crc(g_591, "g_591", print_hash_value);
    transparent_crc(g_664.f0, "g_664.f0", print_hash_value);
    transparent_crc(g_664.f1, "g_664.f1", print_hash_value);
    transparent_crc(g_664.f2, "g_664.f2", print_hash_value);
    transparent_crc(g_664.f3, "g_664.f3", print_hash_value);
    transparent_crc(g_704, "g_704", print_hash_value);
    transparent_crc(g_727.f0, "g_727.f0", print_hash_value);
    transparent_crc(g_727.f1, "g_727.f1", print_hash_value);
    transparent_crc(g_727.f2, "g_727.f2", print_hash_value);
    transparent_crc(g_727.f3, "g_727.f3", print_hash_value);
    transparent_crc(g_733, "g_733", print_hash_value);
    transparent_crc(g_766, "g_766", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_843[i].f0, "g_843[i].f0", print_hash_value);
        transparent_crc(g_843[i].f1, "g_843[i].f1", print_hash_value);
        transparent_crc(g_843[i].f2, "g_843[i].f2", print_hash_value);
        transparent_crc(g_843[i].f3, "g_843[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_937[i], "g_937[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1055, "g_1055", print_hash_value);
    transparent_crc(g_1058.f0, "g_1058.f0", print_hash_value);
    transparent_crc(g_1058.f1, "g_1058.f1", print_hash_value);
    transparent_crc(g_1058.f2, "g_1058.f2", print_hash_value);
    transparent_crc(g_1058.f3, "g_1058.f3", print_hash_value);
    transparent_crc(g_1159.f0, "g_1159.f0", print_hash_value);
    transparent_crc(g_1159.f1, "g_1159.f1", print_hash_value);
    transparent_crc(g_1159.f2, "g_1159.f2", print_hash_value);
    transparent_crc(g_1159.f3, "g_1159.f3", print_hash_value);
    transparent_crc(g_1171, "g_1171", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1178[i], "g_1178[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1233[i], "g_1233[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1354.f0, "g_1354.f0", print_hash_value);
    transparent_crc(g_1354.f1, "g_1354.f1", print_hash_value);
    transparent_crc(g_1354.f2, "g_1354.f2", print_hash_value);
    transparent_crc(g_1354.f3, "g_1354.f3", print_hash_value);
    transparent_crc(g_1388.f0, "g_1388.f0", print_hash_value);
    transparent_crc(g_1388.f1, "g_1388.f1", print_hash_value);
    transparent_crc(g_1388.f2, "g_1388.f2", print_hash_value);
    transparent_crc(g_1388.f3, "g_1388.f3", print_hash_value);
    transparent_crc(g_1447, "g_1447", print_hash_value);
    transparent_crc(g_1557, "g_1557", print_hash_value);
    transparent_crc(g_1626, "g_1626", print_hash_value);
    transparent_crc(g_1696.f0, "g_1696.f0", print_hash_value);
    transparent_crc(g_1696.f1, "g_1696.f1", print_hash_value);
    transparent_crc(g_1696.f2, "g_1696.f2", print_hash_value);
    transparent_crc(g_1696.f3, "g_1696.f3", print_hash_value);
    transparent_crc(g_1712.f0, "g_1712.f0", print_hash_value);
    transparent_crc(g_1712.f1, "g_1712.f1", print_hash_value);
    transparent_crc(g_1712.f2, "g_1712.f2", print_hash_value);
    transparent_crc(g_1712.f3, "g_1712.f3", print_hash_value);
    transparent_crc(g_1719, "g_1719", print_hash_value);
    transparent_crc(g_1874.f0, "g_1874.f0", print_hash_value);
    transparent_crc(g_1874.f1, "g_1874.f1", print_hash_value);
    transparent_crc(g_1874.f2, "g_1874.f2", print_hash_value);
    transparent_crc(g_1874.f3, "g_1874.f3", print_hash_value);
    transparent_crc(g_1892, "g_1892", print_hash_value);
    transparent_crc(g_1935.f0, "g_1935.f0", print_hash_value);
    transparent_crc(g_1935.f1, "g_1935.f1", print_hash_value);
    transparent_crc(g_1935.f2, "g_1935.f2", print_hash_value);
    transparent_crc(g_1935.f3, "g_1935.f3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1964[i][j][k].f0, "g_1964[i][j][k].f0", print_hash_value);
                transparent_crc(g_1964[i][j][k].f1, "g_1964[i][j][k].f1", print_hash_value);
                transparent_crc(g_1964[i][j][k].f2, "g_1964[i][j][k].f2", print_hash_value);
                transparent_crc(g_1964[i][j][k].f3, "g_1964[i][j][k].f3", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1967.f0, "g_1967.f0", print_hash_value);
    transparent_crc(g_1967.f1, "g_1967.f1", print_hash_value);
    transparent_crc(g_1967.f2, "g_1967.f2", print_hash_value);
    transparent_crc(g_1967.f3, "g_1967.f3", print_hash_value);
    transparent_crc(g_2068.f0, "g_2068.f0", print_hash_value);
    transparent_crc(g_2068.f1, "g_2068.f1", print_hash_value);
    transparent_crc(g_2068.f2, "g_2068.f2", print_hash_value);
    transparent_crc(g_2068.f3, "g_2068.f3", print_hash_value);
    transparent_crc(g_2138, "g_2138", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2173[i].f0, "g_2173[i].f0", print_hash_value);
        transparent_crc(g_2173[i].f1, "g_2173[i].f1", print_hash_value);
        transparent_crc(g_2173[i].f2, "g_2173[i].f2", print_hash_value);
        transparent_crc(g_2173[i].f3, "g_2173[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2175.f0, "g_2175.f0", print_hash_value);
    transparent_crc(g_2175.f1, "g_2175.f1", print_hash_value);
    transparent_crc(g_2175.f2, "g_2175.f2", print_hash_value);
    transparent_crc(g_2175.f3, "g_2175.f3", print_hash_value);
    transparent_crc(g_2203.f0, "g_2203.f0", print_hash_value);
    transparent_crc(g_2203.f1, "g_2203.f1", print_hash_value);
    transparent_crc(g_2203.f2, "g_2203.f2", print_hash_value);
    transparent_crc(g_2203.f3, "g_2203.f3", print_hash_value);
    transparent_crc(g_2256.f0, "g_2256.f0", print_hash_value);
    transparent_crc(g_2256.f1, "g_2256.f1", print_hash_value);
    transparent_crc(g_2256.f2, "g_2256.f2", print_hash_value);
    transparent_crc(g_2256.f3, "g_2256.f3", print_hash_value);
    transparent_crc(g_2339.f0, "g_2339.f0", print_hash_value);
    transparent_crc(g_2339.f1, "g_2339.f1", print_hash_value);
    transparent_crc(g_2339.f2, "g_2339.f2", print_hash_value);
    transparent_crc(g_2339.f3, "g_2339.f3", print_hash_value);
    transparent_crc(g_2364.f0, "g_2364.f0", print_hash_value);
    transparent_crc(g_2364.f1, "g_2364.f1", print_hash_value);
    transparent_crc(g_2364.f2, "g_2364.f2", print_hash_value);
    transparent_crc(g_2364.f3, "g_2364.f3", print_hash_value);
    transparent_crc(g_2411.f0, "g_2411.f0", print_hash_value);
    transparent_crc(g_2411.f1, "g_2411.f1", print_hash_value);
    transparent_crc(g_2411.f2, "g_2411.f2", print_hash_value);
    transparent_crc(g_2411.f3, "g_2411.f3", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 567
XXX total union variables: 54

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 2
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 92
breakdown:
   indirect level: 0, occurrence: 54
   indirect level: 1, occurrence: 26
   indirect level: 2, occurrence: 11
   indirect level: 3, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 25
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 66
XXX times a single bitfield on LHS: 2
XXX times a single bitfield on RHS: 59

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 329
   depth: 2, occurrence: 76
   depth: 3, occurrence: 9
   depth: 4, occurrence: 7
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 6
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 5
   depth: 18, occurrence: 4
   depth: 19, occurrence: 5
   depth: 20, occurrence: 4
   depth: 21, occurrence: 9
   depth: 22, occurrence: 4
   depth: 23, occurrence: 4
   depth: 24, occurrence: 3
   depth: 25, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 4
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 31, occurrence: 2
   depth: 32, occurrence: 2
   depth: 33, occurrence: 5
   depth: 34, occurrence: 1
   depth: 35, occurrence: 2
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 2
   depth: 44, occurrence: 1

XXX total number of pointers: 524

XXX times a variable address is taken: 1106
XXX times a pointer is dereferenced on RHS: 280
breakdown:
   depth: 1, occurrence: 248
   depth: 2, occurrence: 30
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 324
breakdown:
   depth: 1, occurrence: 312
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 45
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 6616

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1345
   level: 2, occurrence: 390
   level: 3, occurrence: 23
   level: 4, occurrence: 10
   level: 5, occurrence: 3
XXX number of pointers point to pointers: 195
XXX number of pointers point to scalars: 300
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.2
XXX average alias set size: 1.49

XXX times a non-volatile is read: 1924
XXX times a non-volatile is write: 972
XXX times a volatile is read: 122
XXX    times read thru a pointer: 34
XXX times a volatile is write: 30
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4.9e+03
XXX percentage of non-volatile access: 95

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 338
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 26
   depth: 2, occurrence: 32
   depth: 3, occurrence: 54
   depth: 4, occurrence: 82
   depth: 5, occurrence: 115

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

