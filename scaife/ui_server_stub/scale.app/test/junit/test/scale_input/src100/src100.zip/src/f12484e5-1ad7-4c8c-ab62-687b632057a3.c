/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      387830438
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_6 = 255UL;
static uint64_t g_37[8] = {18446744073709551612UL,0xE483BBB66EFE0CD1LL,18446744073709551612UL,18446744073709551612UL,0xE483BBB66EFE0CD1LL,18446744073709551612UL,18446744073709551612UL,0xE483BBB66EFE0CD1LL};
static uint8_t g_54 = 0xF4L;
static uint32_t g_56 = 18446744073709551615UL;
static int8_t g_76 = 0xD2L;
static int32_t g_78 = 0x40E81688L;
static int64_t g_117 = 0L;
static uint64_t g_132 = 0x193F739521466050LL;
static uint32_t g_142 = 9UL;
static int32_t g_148[8] = {1L,0L,0L,1L,0L,0L,1L,0L};
static uint8_t g_151 = 246UL;
static int16_t g_171 = 0x1240L;
static uint8_t g_208 = 1UL;
static uint8_t g_210[8] = {255UL,255UL,255UL,255UL,255UL,255UL,255UL,255UL};
static const int32_t ** volatile g_237 = (void*)0;/* VOLATILE GLOBAL g_237 */
static uint64_t g_264 = 0x66084F89FB70B172LL;
static int32_t * volatile g_265[1] = {&g_148[4]};
static int32_t * volatile g_266[3][9][9] = {{{(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0},{&g_148[4],(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6]},{(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6]},{&g_148[4],&g_148[4],&g_148[4],(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0}},{{&g_148[4],(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6]},{(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6]},{&g_148[4],&g_148[4],&g_148[4],(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0},{&g_148[4],(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]}},{{&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6]},{(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],(void*)0},{&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6],(void*)0,(void*)0,(void*)0,&g_148[6]},{&g_148[4],&g_148[4],&g_148[4],(void*)0,(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0,(void*)0,(void*)0,&g_148[7],(void*)0},{&g_148[4],(void*)0,&g_148[4],&g_148[4],(void*)0,&g_148[4],&g_148[4],&g_148[4],&g_148[4]},{&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6],&g_148[7],(void*)0,&g_148[7],&g_148[6]}}};
static const uint32_t *g_295 = &g_56;
static const uint32_t **g_294 = &g_295;
static uint16_t g_353 = 0UL;
static int16_t g_405 = 0x124EL;
static uint32_t g_423[8] = {0x5140A278L,0x5140A278L,5UL,0x5140A278L,0x5140A278L,5UL,0x5140A278L,0x5140A278L};
static volatile uint32_t * volatile g_435 = (void*)0;/* VOLATILE GLOBAL g_435 */
static volatile uint32_t * volatile * const  volatile g_434[6] = {&g_435,&g_435,&g_435,&g_435,&g_435,&g_435};
static int64_t g_483 = (-8L);
static volatile int8_t g_510 = 0xFEL;/* VOLATILE GLOBAL g_510 */
static volatile int8_t *g_509 = &g_510;
static volatile int8_t **g_508 = &g_509;
static volatile uint8_t * volatile g_535 = (void*)0;/* VOLATILE GLOBAL g_535 */
static volatile uint8_t * const  volatile * volatile g_534 = &g_535;/* VOLATILE GLOBAL g_534 */
static volatile int16_t g_567 = 0x81F3L;/* VOLATILE GLOBAL g_567 */
static volatile int16_t *g_566[6] = {&g_567,&g_567,&g_567,&g_567,&g_567,&g_567};
static volatile int16_t **g_565 = &g_566[0];
static int32_t g_578 = (-7L);
static int32_t *g_585 = &g_78;
static uint32_t *g_606[2] = {&g_423[2],&g_423[2]};
static uint32_t **g_605[10][4][6] = {{{(void*)0,&g_606[0],&g_606[0],&g_606[0],&g_606[1],&g_606[1]},{&g_606[0],(void*)0,&g_606[0],&g_606[0],&g_606[1],(void*)0},{&g_606[0],(void*)0,&g_606[1],(void*)0,&g_606[1],(void*)0},{&g_606[1],&g_606[0],&g_606[0],&g_606[0],(void*)0,&g_606[1]}},{{(void*)0,(void*)0,(void*)0,&g_606[1],&g_606[0],&g_606[0]},{&g_606[0],&g_606[0],&g_606[0],&g_606[0],&g_606[0],&g_606[0]},{(void*)0,&g_606[0],&g_606[0],&g_606[0],&g_606[0],(void*)0},{&g_606[1],&g_606[1],&g_606[1],(void*)0,&g_606[1],(void*)0}},{{&g_606[1],&g_606[1],(void*)0,&g_606[0],&g_606[1],&g_606[1]},{(void*)0,&g_606[0],&g_606[1],&g_606[0],(void*)0,&g_606[1]},{&g_606[0],&g_606[0],&g_606[1],&g_606[1],&g_606[1],&g_606[0]},{(void*)0,&g_606[0],&g_606[0],&g_606[0],(void*)0,&g_606[0]}},{{&g_606[1],&g_606[0],&g_606[1],(void*)0,&g_606[0],&g_606[1]},{&g_606[0],&g_606[1],&g_606[1],&g_606[0],(void*)0,&g_606[1]},{&g_606[0],(void*)0,&g_606[1],&g_606[0],(void*)0,&g_606[0]},{(void*)0,&g_606[1],&g_606[0],&g_606[1],&g_606[1],&g_606[0]}},{{(void*)0,(void*)0,&g_606[1],&g_606[1],&g_606[1],&g_606[1]},{&g_606[1],&g_606[1],&g_606[1],&g_606[1],&g_606[1],&g_606[1]},{&g_606[1],&g_606[1],(void*)0,&g_606[0],&g_606[0],(void*)0},{(void*)0,(void*)0,&g_606[1],&g_606[0],&g_606[0],(void*)0}},{{&g_606[1],&g_606[1],&g_606[0],&g_606[1],&g_606[1],&g_606[0]},{&g_606[0],&g_606[1],&g_606[0],(void*)0,&g_606[1],&g_606[0]},{&g_606[1],(void*)0,(void*)0,&g_606[1],&g_606[1],&g_606[0]},{&g_606[1],&g_606[1],&g_606[1],(void*)0,&g_606[1],&g_606[0]}},{{&g_606[1],&g_606[0],&g_606[1],&g_606[0],(void*)0,&g_606[1]},{(void*)0,(void*)0,&g_606[1],&g_606[0],&g_606[0],(void*)0},{&g_606[1],(void*)0,&g_606[1],(void*)0,&g_606[1],&g_606[1]},{&g_606[1],&g_606[0],(void*)0,&g_606[0],&g_606[1],&g_606[1]}},{{&g_606[0],(void*)0,&g_606[0],&g_606[1],&g_606[1],&g_606[0]},{&g_606[1],&g_606[1],&g_606[1],&g_606[1],&g_606[1],&g_606[1]},{&g_606[1],&g_606[1],&g_606[0],&g_606[1],&g_606[0],&g_606[1]},{&g_606[1],&g_606[1],&g_606[0],&g_606[0],&g_606[1],&g_606[1]}},{{&g_606[0],&g_606[0],&g_606[1],&g_606[1],&g_606[0],&g_606[0]},{&g_606[1],&g_606[0],&g_606[0],(void*)0,(void*)0,&g_606[1]},{&g_606[0],&g_606[1],(void*)0,&g_606[1],(void*)0,&g_606[1]},{(void*)0,(void*)0,&g_606[1],&g_606[1],&g_606[0],(void*)0}},{{&g_606[1],(void*)0,&g_606[1],(void*)0,&g_606[0],&g_606[1]},{&g_606[1],(void*)0,&g_606[1],&g_606[0],&g_606[0],&g_606[0]},{&g_606[1],(void*)0,&g_606[1],&g_606[0],(void*)0,&g_606[0]},{&g_606[1],&g_606[1],&g_606[1],&g_606[0],(void*)0,(void*)0}}};
static uint8_t g_611[2][2] = {{255UL,255UL},{255UL,255UL}};
static volatile int64_t g_621 = 0xF1E9CBE9C67E829ELL;/* VOLATILE GLOBAL g_621 */
static uint16_t g_622 = 0UL;
static int32_t ** volatile g_677 = &g_585;/* VOLATILE GLOBAL g_677 */
static uint32_t *** volatile g_679 = (void*)0;/* VOLATILE GLOBAL g_679 */
static uint32_t *g_682 = &g_56;
static uint32_t **g_681 = &g_682;
static uint32_t *** volatile g_680 = &g_681;/* VOLATILE GLOBAL g_680 */
static int32_t g_701 = 0xB8414626L;
static volatile uint8_t * volatile *g_809 = &g_535;
static volatile uint8_t * volatile ** volatile g_808 = &g_809;/* VOLATILE GLOBAL g_808 */
static uint16_t *g_845 = (void*)0;
static uint32_t * volatile *g_1020 = &g_606[1];
static uint32_t * volatile **g_1019 = &g_1020;
static int16_t *g_1110 = &g_171;
static int16_t **g_1109 = &g_1110;
static uint64_t g_1141 = 0x1FB9BF55B97A2CD4LL;
static volatile uint32_t g_1152 = 0x5D4E5021L;/* VOLATILE GLOBAL g_1152 */
static volatile uint32_t *g_1151 = &g_1152;
static int32_t *g_1221 = &g_701;
static int32_t **g_1220 = &g_1221;
static int32_t *** volatile g_1223 = &g_1220;/* VOLATILE GLOBAL g_1223 */
static int8_t *g_1236 = (void*)0;
static int8_t **g_1235 = &g_1236;
static int8_t ***g_1234 = &g_1235;
static volatile int32_t g_1348 = 0xED358B9DL;/* VOLATILE GLOBAL g_1348 */
static volatile int32_t *g_1347 = &g_1348;
static volatile int32_t ** volatile g_1349 = &g_1347;/* VOLATILE GLOBAL g_1349 */
static int8_t ** const g_1350 = &g_1236;
static uint32_t g_1368[3] = {0x863C4676L,0x863C4676L,0x863C4676L};
static int32_t * volatile * const  volatile g_1373 = &g_265[0];/* VOLATILE GLOBAL g_1373 */
static int64_t g_1409 = 0x7E6A93C06B280B47LL;
static const int32_t *g_1437[7] = {&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4],&g_148[4]};
static const int32_t ** volatile g_1436 = &g_1437[2];/* VOLATILE GLOBAL g_1436 */
static uint32_t * const **g_1589 = (void*)0;
static volatile int8_t g_1597 = (-3L);/* VOLATILE GLOBAL g_1597 */
static uint32_t g_1636 = 0xD8091321L;
static int32_t ** volatile g_1643 = &g_585;/* VOLATILE GLOBAL g_1643 */
static int32_t ** volatile g_1644 = (void*)0;/* VOLATILE GLOBAL g_1644 */
static int32_t ** const  volatile g_1646[9][2][9] = {{{&g_585,(void*)0,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585},{&g_585,&g_585,&g_585,&g_585,(void*)0,(void*)0,&g_585,&g_585,&g_585}},{{(void*)0,&g_585,(void*)0,&g_585,(void*)0,&g_585,(void*)0,&g_585,(void*)0},{&g_585,(void*)0,&g_585,&g_585,(void*)0,&g_585,&g_585,(void*)0,(void*)0}},{{(void*)0,&g_585,&g_585,&g_585,&g_585,&g_585,(void*)0,&g_585,(void*)0},{&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585,&g_585,&g_585,&g_585}},{{&g_585,&g_585,&g_585,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585},{&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585,&g_585,(void*)0}},{{&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585,&g_585,&g_585,&g_585},{&g_585,&g_585,(void*)0,(void*)0,(void*)0,&g_585,(void*)0,(void*)0,(void*)0}},{{&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585,(void*)0,&g_585},{(void*)0,(void*)0,&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585}},{{&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585},{&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585,(void*)0,(void*)0,&g_585}},{{(void*)0,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585,&g_585},{(void*)0,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585,(void*)0,&g_585}},{{&g_585,&g_585,&g_585,&g_585,&g_585,(void*)0,&g_585,&g_585,&g_585},{&g_585,&g_585,&g_585,&g_585,&g_585,&g_585,&g_585,(void*)0,(void*)0}}};
static int32_t ** volatile g_1647[1] = {(void*)0};
static int32_t ** volatile g_1648 = &g_585;/* VOLATILE GLOBAL g_1648 */
static int8_t *g_1659 = &g_76;
static uint32_t g_1666[6] = {0UL,7UL,7UL,0UL,7UL,7UL};
static const int32_t **g_1668[7] = {&g_1437[0],&g_1437[0],&g_1437[0],&g_1437[0],&g_1437[0],&g_1437[0],&g_1437[0]};
static const int32_t *** volatile g_1667 = &g_1668[3];/* VOLATILE GLOBAL g_1667 */
static int32_t * volatile g_1669 = &g_148[7];/* VOLATILE GLOBAL g_1669 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_2(int64_t  p_3, int16_t  p_4, uint16_t  p_5);
static const uint32_t  func_11(int8_t  p_12);
static uint64_t  func_14(int32_t  p_15, const int64_t  p_16, uint64_t  p_17, uint16_t  p_18);
static int32_t  func_27(int16_t  p_28, int64_t  p_29, int32_t  p_30, uint32_t  p_31);
static int16_t  func_32(uint32_t  p_33, uint32_t  p_34, const int32_t  p_35);
static uint64_t  func_46(uint64_t * p_47, const uint64_t * const  p_48);
static uint64_t * func_49(uint32_t  p_50, uint64_t * p_51);
static uint64_t * func_57(const int16_t  p_58, uint64_t * p_59, uint8_t  p_60, const uint8_t * p_61, int16_t  p_62);
static uint8_t  func_63(uint32_t  p_64, uint16_t  p_65, uint32_t  p_66, const uint16_t  p_67, int32_t  p_68);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_37 g_54 g_76 g_78 g_117 g_148 g_151 g_171 g_142 g_132 g_210 g_208 g_264 g_585 g_605 g_508 g_509 g_510 g_565 g_566 g_622 g_483 g_701 g_353 g_294 g_295 g_681 g_682 g_56 g_578 g_567 g_611 g_423 g_405 g_677 g_808 g_266 g_809 g_1019 g_1020 g_606 g_680 g_1151 g_1109 g_1110 g_1347 g_1349 g_1350 g_1368 g_265 g_1373 g_1141 g_1669
 * writes: g_54 g_56 g_76 g_78 g_132 g_142 g_148 g_151 g_171 g_208 g_264 g_117 g_578 g_605 g_611 g_622 g_483 g_37 g_353 g_585 g_809 g_405 g_845 g_210 g_266 g_423 g_682 g_1347 g_1235 g_1348 g_1368 g_265
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_13[6] = {(-1L),0x9570A50B5F0B101ALL,(-1L),(-1L),0x9570A50B5F0B101ALL,(-1L)};
    uint64_t *l_36[5][5] = {{&g_37[0],&g_37[0],&g_37[0],&g_37[0],&g_37[0]},{&g_37[6],&g_37[7],&g_37[7],&g_37[7],&g_37[7]},{&g_37[0],&g_37[0],(void*)0,&g_37[0],&g_37[0]},{&g_37[7],&g_37[7],&g_37[7],&g_37[7],&g_37[6]},{&g_37[0],&g_37[0],&g_37[0],&g_37[0],&g_37[0]}};
    int32_t l_38 = 2L;
    uint32_t l_41 = 18446744073709551609UL;
    int16_t *l_691[7] = {&g_405,&g_405,&g_405,&g_405,&g_405,&g_405,&g_405};
    int32_t l_692 = 0x0296D7E4L;
    int8_t l_1375 = 6L;
    int i, j;
    (*g_1669) = func_2(g_6, (safe_div_func_uint16_t_u_u((((safe_div_func_int32_t_s_s((func_11((g_6 , (l_13[4] & (((4294967290UL && ((func_14(g_6, (safe_rshift_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s(1UL, 2)) & (safe_sub_func_int32_t_s_s(((*g_585) = ((safe_rshift_func_uint8_t_u_s(g_6, 1)) <= ((func_27((l_692 = func_32(((l_38 = g_6) <= (safe_sub_func_int16_t_s_s(g_37[1], l_41))), l_13[4], g_37[7])), g_210[6], l_13[4], l_13[4]) , 0x8A4AEBDF094AB823LL) , 0x34C2ED97C8F4784CLL))), g_701))), g_353)), g_37[7], l_41) , 7L) >= l_13[0])) , g_56) < 0xE775E4EC06B34C9DLL)))) < l_13[5]), l_1375)) && l_13[4]) > l_41), 0xD4FDL)), g_1141);
    for (g_578 = 5; (g_578 >= 0); g_578 -= 1)
    { /* block id: 760 */
        int i;
        return g_210[(g_578 + 2)];
    }
    return (*g_1110);
}


/* ------------------------------------------ */
/* 
 * reads : g_405 g_56
 * writes: g_405 g_56
 */
static int32_t  func_2(int64_t  p_3, int16_t  p_4, uint16_t  p_5)
{ /* block id: 619 */
    int8_t *l_1383 = &g_76;
    int32_t l_1391 = (-1L);
    int8_t * const *l_1433 = (void*)0;
    int8_t * const ** const l_1432 = &l_1433;
    const int32_t *l_1435 = &l_1391;
    int32_t l_1456 = 0x97A559F9L;
    uint64_t *l_1551[3][1][2] = {{{&g_1141,&g_132}},{{&g_1141,&g_1141}},{{&g_132,&g_1141}}};
    uint16_t l_1579[2][5] = {{0x6478L,0x6478L,0x6478L,0x6478L,0x6478L},{0UL,0UL,0UL,0UL,0UL}};
    int32_t l_1635 = 0x8452DF4CL;
    int i, j, k;
    for (g_405 = (-1); (g_405 > (-1)); ++g_405)
    { /* block id: 622 */
        int8_t * const l_1384 = &g_76;
        uint64_t l_1392 = 0UL;
        int32_t l_1410 = 6L;
        int8_t * const l_1479 = &g_76;
        int64_t l_1480[5][6] = {{(-1L),0xF29B131DD8746A7DLL,0x529DA897CAD2D1CFLL,3L,0x529DA897CAD2D1CFLL,0xF29B131DD8746A7DLL},{0x529DA897CAD2D1CFLL,(-1L),2L,0x5FB53D5BA1D15A8FLL,0x5FB53D5BA1D15A8FLL,2L},{0x529DA897CAD2D1CFLL,0x529DA897CAD2D1CFLL,0x5FB53D5BA1D15A8FLL,3L,0x0A971C94168C882FLL,3L},{(-1L),0x529DA897CAD2D1CFLL,(-1L),2L,0x5FB53D5BA1D15A8FLL,0x5FB53D5BA1D15A8FLL},{0xF29B131DD8746A7DLL,(-1L),(-1L),0xF29B131DD8746A7DLL,0x529DA897CAD2D1CFLL,3L}};
        uint64_t l_1534[9] = {0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL,0x0E59C5AC689CFC05LL};
        uint32_t *l_1582 = (void*)0;
        int32_t l_1612[2];
        int32_t l_1616 = 0x7B41CEC7L;
        int32_t l_1617 = (-5L);
        int32_t l_1619 = 0x7384B107L;
        int32_t l_1621[1][6] = {{0L,0L,0L,0L,0L,0L}};
        int i, j;
        for (i = 0; i < 2; i++)
            l_1612[i] = 0L;
        for (g_56 = 0; (g_56 > 34); g_56++)
        { /* block id: 625 */
            int64_t l_1411 = 8L;
            int32_t l_1443[7] = {0L,0xCBC6199CL,0L,0L,0xCBC6199CL,0L,0L};
            const int32_t *l_1444 = &g_148[4];
            uint8_t l_1470 = 1UL;
            uint8_t *l_1489 = &g_6;
            uint8_t **l_1488 = &l_1489;
            int8_t **l_1490 = &g_1236;
            int32_t l_1497[1][3];
            uint64_t *l_1528 = &g_37[6];
            uint64_t *l_1530 = &g_132;
            uint32_t *l_1542 = (void*)0;
            uint16_t l_1625 = 1UL;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_1497[i][j] = (-1L);
            }
        }
        if (l_1621[0][0])
            break;
    }
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_680 g_681 g_682 g_1151 g_353 g_148 g_1109 g_1110 g_171 g_405 g_578 g_585 g_1347 g_1349 g_1350 g_677 g_1368 g_264 g_265 g_1373 g_208 g_622 g_78 g_151
 * writes: g_208 g_622 g_682 g_353 g_148 g_78 g_585 g_578 g_54 g_1347 g_1235 g_151 g_1348 g_1368 g_264 g_265
 */
static const uint32_t  func_11(int8_t  p_12)
{ /* block id: 467 */
    int32_t l_1032[7] = {0x3A86F5C8L,0x3A86F5C8L,8L,0x3A86F5C8L,0x3A86F5C8L,8L,0x3A86F5C8L};
    uint32_t l_1044 = 18446744073709551610UL;
    int64_t l_1051 = 1L;
    int32_t l_1052 = 4L;
    int32_t l_1108[9] = {0x3FF1E5D6L,0xECC991FAL,0x3FF1E5D6L,0xECC991FAL,0x3FF1E5D6L,0xECC991FAL,0x3FF1E5D6L,0xECC991FAL,0x3FF1E5D6L};
    uint8_t *l_1155 = &g_54;
    uint64_t l_1157 = 0x2CBA8E8630A8AD6ALL;
    int8_t l_1167 = 0L;
    int32_t l_1168 = (-5L);
    uint8_t l_1169 = 0x17L;
    uint16_t l_1195 = 0x111CL;
    int32_t *l_1242 = &l_1032[0];
    int32_t *l_1251 = (void*)0;
    uint64_t *l_1286 = &g_37[6];
    uint64_t **l_1285 = &l_1286;
    int8_t l_1289 = 0xEFL;
    int i;
lbl_1354:
    for (g_208 = 0; (g_208 <= 0); g_208 += 1)
    { /* block id: 470 */
        uint32_t **l_1027 = (void*)0;
        l_1027 = l_1027;
    }
    if (((safe_div_func_int16_t_s_s(((((safe_mul_func_uint16_t_u_u(l_1032[0], 0UL)) , (safe_mul_func_uint16_t_u_u((l_1032[5] < (((p_12 , (((safe_rshift_func_uint8_t_u_s((((l_1032[0] || p_12) ^ p_12) == ((safe_add_func_int32_t_s_s(p_12, (safe_add_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((+4UL), 255UL)), l_1032[0])))) && l_1032[0])), l_1032[5])) ^ 0L) , &g_508)) == (void*)0) & 0x445DL)), l_1032[0]))) == l_1032[2]) , 0L), l_1044)) & l_1044))
    { /* block id: 473 */
        int32_t *l_1045 = &g_148[7];
        int32_t *l_1046 = &g_148[6];
        int32_t *l_1047 = &g_148[5];
        int32_t l_1048 = 0L;
        int32_t *l_1049 = &g_148[3];
        int32_t *l_1050[3];
        uint32_t l_1053[7][3][7] = {{{1UL,0xD12EC23CL,0x17FD3B12L,0x48369EBAL,1UL,0xA3C36A14L,0xC2D54117L},{0xD12EC23CL,0x4A89C49EL,18446744073709551612UL,3UL,18446744073709551615UL,0UL,1UL},{18446744073709551615UL,0UL,0UL,0x1F3CB1EFL,0x1F3CB1EFL,0UL,0UL}},{{6UL,0x46E5814BL,0x2A84A5B3L,0x7714ADF6L,0UL,0x22839A6AL,0xE1C62924L},{0x79479F37L,0x48369EBAL,18446744073709551612UL,18446744073709551610UL,0x2D691CAEL,0x8DBB073FL,3UL},{18446744073709551610UL,0xEB5B2DFBL,18446744073709551615UL,0x7714ADF6L,0xC2D54117L,0x2EB67A34L,0x7714ADF6L}},{{0xD9294E8CL,3UL,1UL,0x1F3CB1EFL,18446744073709551612UL,1UL,6UL},{0x2D48F388L,0x2A54B7F9L,0xB0A3C926L,3UL,0x2D691CAEL,0x46E5814BL,0xA3C36A14L},{0x0C197593L,0UL,18446744073709551611UL,0x48369EBAL,0UL,0UL,18446744073709551615UL}},{{0x1F3CB1EFL,1UL,3UL,0xD9294E8CL,0x22839A6AL,18446744073709551612UL,18446744073709551615UL},{0UL,0xE1C62924L,18446744073709551610UL,0x2A84A5B3L,18446744073709551615UL,0x8DBB073FL,0xA3C36A14L},{0xEB5B2DFBL,0xC2D54117L,0xAE05A72AL,0x84353B6AL,0xF6A5B42CL,18446744073709551615UL,6UL}},{{0x7714ADF6L,0x2A84A5B3L,0x46E5814BL,6UL,0x46E5814BL,0x2A84A5B3L,0x7714ADF6L},{0x22839A6AL,18446744073709551610UL,0xD12EC23CL,1UL,0xD9294E8CL,0UL,3UL},{0x0C197593L,0xC2D54117L,0UL,0UL,6UL,3UL,0xE1C62924L}},{{0x48369EBAL,0x17FD3B12L,0xD12EC23CL,1UL,0x2A84A5B3L,0UL,0UL},{1UL,0xD9294E8CL,0x46E5814BL,0UL,0UL,18446744073709551610UL,1UL},{18446744073709551610UL,0UL,0xAE05A72AL,0UL,0x0C197593L,18446744073709551615UL,0xC2D54117L}},{{0x84353B6AL,0x8DBB073FL,18446744073709551610UL,18446744073709551615UL,0xB0A3C926L,1UL,0UL},{0UL,0x0C197593L,3UL,0UL,18446744073709551610UL,1UL,0xFD4C02D9L},{18446744073709551615UL,0xEB5B2DFBL,18446744073709551611UL,0x84353B6AL,6UL,18446744073709551615UL,1UL}}};
        int32_t **l_1056 = &l_1045;
        uint8_t *l_1063 = &g_210[2];
        int32_t l_1091 = (-4L);
        uint64_t l_1100[2];
        int32_t l_1275[3];
        uint64_t *l_1278 = &g_37[7];
        uint64_t **l_1277 = &l_1278;
        int8_t *l_1284 = &l_1167;
        int16_t l_1290[6][6][6] = {{{(-1L),0x7153L,0x7DC2L,(-2L),1L,1L},{0x41DCL,(-2L),1L,0x09FAL,1L,0xABEFL},{0x3D04L,0xBA8AL,0xABEFL,0L,0x7E2DL,1L},{0xABEFL,(-1L),(-6L),0xC7A4L,0x6518L,(-1L)},{0x6518L,(-1L),0x7153L,(-6L),0x7E2DL,(-1L)},{1L,0xBA8AL,0L,0L,0xBA8AL,1L}},{{1L,0xABEFL,0xC7A4L,(-1L),0L,0L},{0x47DFL,(-6L),1L,0x1A37L,(-2L),0x7153L},{0x47DFL,0x7153L,0x1A37L,(-1L),(-1L),(-2L)},{1L,0L,0x6518L,0L,1L,1L},{1L,0xC7A4L,(-1L),(-6L),0x09FAL,0x7DC2L},{0x6518L,1L,0x8EE4L,0xC7A4L,0x3D04L,0x7DC2L}},{{0xABEFL,0x1A37L,(-1L),0L,1L,1L},{0x3D04L,0x6518L,0x6518L,0x3D04L,0xABEFL,(-2L)},{0L,(-1L),0x1A37L,0xABEFL,(-1L),0x7153L},{0xC7A4L,0x8EE4L,1L,0x6518L,(-1L),0L},{(-6L),(-1L),0xC7A4L,1L,0xABEFL,1L},{0L,0x6518L,0L,1L,1L,(-1L)}},{{(-1L),0x1A37L,0x7153L,0x47DFL,0x3D04L,(-1L)},{0x1A37L,1L,(-6L),0x47DFL,0x09FAL,1L},{(-1L),0xC7A4L,0xABEFL,1L,1L,0xABEFL},{0L,0L,0xBA8AL,1L,(-1L),0x1A37L},{(-6L),0x7153L,(-1L),0x6518L,(-2L),0xBA8AL},{0xC7A4L,(-6L),(-1L),0xABEFL,0L,0x1A37L}},{{0L,0xABEFL,0xBA8AL,0x3D04L,0xBA8AL,0xABEFL},{0x3D04L,0xBA8AL,0xABEFL,0L,0x7E2DL,1L},{0xABEFL,(-1L),(-6L),0xC7A4L,0x6518L,(-1L)},{0x6518L,(-1L),0x7153L,(-6L),0x7E2DL,(-1L)},{1L,0xBA8AL,0L,0L,0xBA8AL,1L},{1L,0xABEFL,0xC7A4L,(-1L),0L,0L}},{{0x47DFL,(-6L),1L,0x1A37L,(-2L),0x7153L},{0x47DFL,0x7153L,0x1A37L,(-1L),(-1L),(-2L)},{1L,0L,0x6518L,0L,1L,1L},{1L,0xC7A4L,(-1L),(-1L),0x3D04L,(-1L)},{0x41DCL,0xBA8AL,0x47DFL,1L,0x7DC2L,(-1L)},{0x6518L,(-1L),1L,0x7153L,0xBA8AL,0xBA8AL}}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1050[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_1100[i] = 0xA79BD39B5BDE5F28LL;
        for (i = 0; i < 3; i++)
            l_1275[i] = 0L;
        ++l_1053[1][1][6];
        (*l_1056) = &l_1032[1];
        if (l_1051)
        { /* block id: 476 */
            uint8_t l_1065 = 0x55L;
            uint16_t **l_1066 = &g_845;
            int32_t l_1093 = 1L;
            int32_t l_1096 = 0xABDCE3BDL;
            int32_t l_1097 = 0x78CCE3A5L;
            int32_t l_1098 = 0x4DD59313L;
            int32_t l_1099 = 6L;
            uint32_t l_1139 = 0UL;
            int32_t l_1142 = (-5L);
            const int32_t *l_1144 = (void*)0;
            for (g_622 = 0; (g_622 == 49); g_622++)
            { /* block id: 479 */
                uint8_t **l_1064 = &l_1063;
                uint16_t ***l_1067 = &l_1066;
                int32_t *l_1092 = &g_148[4];
                int32_t l_1095 = 3L;
            }
        }
        else
        { /* block id: 516 */
            uint8_t **l_1156 = &l_1155;
            int32_t l_1160 = 6L;
            uint16_t *l_1161 = &g_353;
            uint8_t l_1166 = 0xA7L;
            int32_t l_1170 = 0xB0B87395L;
            int32_t l_1171 = 0xD766AD9EL;
            uint8_t l_1172 = 0xD7L;
            uint32_t **l_1189 = (void*)0;
            int8_t ***l_1239[2][5] = {{&g_1235,&g_1235,&g_1235,&g_1235,&g_1235},{&g_1235,&g_1235,&g_1235,&g_1235,&g_1235}};
            int8_t l_1241 = 0x69L;
            int i, j;
            (*l_1047) = (((((safe_add_func_int64_t_s_s(((safe_rshift_func_int8_t_s_u(((safe_sub_func_uint8_t_u_u((((*g_681) = (**g_680)) == g_1151), p_12)) < (safe_mul_func_int8_t_s_s((((*l_1156) = l_1155) != &g_151), ((l_1157 , ((((((safe_rshift_func_int8_t_s_u((((((*l_1161) |= l_1160) && (safe_sub_func_uint32_t_u_u(((safe_add_func_int64_t_s_s(l_1166, ((((*l_1047) > 1UL) ^ l_1167) && (**g_1109)))) , 0x83E621FDL), 0UL))) < 0xACL) | p_12), g_148[0])) < g_405) | 0x3D80CEE99D05ECF8LL) <= 0xA6DBF940L) & p_12) >= l_1168)) > p_12)))), p_12)) & p_12), 0xAA180875CFB11376LL)) && (-1L)) , l_1108[5]) && l_1169) <= (-1L));
            --l_1172;
            for (g_78 = 7; (g_78 >= 0); g_78 -= 1)
            { /* block id: 524 */
                int16_t l_1175[1];
                uint32_t **l_1188 = &g_606[0];
                int8_t *l_1190 = &l_1167;
                int32_t l_1193 = 0xAB2DEF02L;
                uint64_t *l_1257 = &g_37[3];
                uint64_t *l_1274 = &g_1141;
                int i;
                for (i = 0; i < 1; i++)
                    l_1175[i] = 1L;
            }
            (*l_1056) = (*l_1056);
        }
        (*l_1046) = ((safe_unary_minus_func_int32_t_s((((*l_1242) = p_12) != ((p_12 , (void*)0) == ((*l_1277) = &l_1157))))) || (safe_unary_minus_func_uint32_t_u(((safe_mul_func_int16_t_s_s((safe_add_func_int32_t_s_s((((1UL & ((((*l_1284) = (*l_1242)) , l_1285) != (void*)0)) == (safe_mod_func_int64_t_s_s(p_12, l_1289))) == p_12), (*l_1242))), l_1290[1][4][5])) | 1UL))));
    }
    else
    { /* block id: 572 */
        int32_t **l_1291 = &g_585;
        uint64_t **l_1359 = (void*)0;
        int32_t **l_1364 = &g_1221;
        (*l_1291) = &l_1032[4];
        for (g_578 = 0; (g_578 != (-8)); g_578 = safe_sub_func_int16_t_s_s(g_578, 8))
        { /* block id: 576 */
            uint32_t l_1299 = 1UL;
            uint16_t *l_1321 = &g_622;
            uint8_t * const l_1345 = &g_210[5];
            if ((p_12 , ((p_12 != ((*l_1242) = ((~(0x888BL & ((safe_mod_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u(l_1299, 0x53L)) | (1UL != (safe_mul_func_uint16_t_u_u(((safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((**l_1291) < (~(*l_1242))), ((*l_1155) = (**l_1291)))), (-2L))) & 18446744073709551612UL), 0xF62DL)))), p_12)) && (*l_1242)))) , 0xCE2762A8L))) || 0x7BL)))
            { /* block id: 579 */
                uint64_t l_1311 = 18446744073709551611UL;
                int8_t ***l_1351 = &g_1235;
                for (l_1299 = 0; (l_1299 <= 48); l_1299 = safe_add_func_uint16_t_u_u(l_1299, 1))
                { /* block id: 582 */
                    int32_t l_1330[6][4] = {{(-10L),(-10L),0x4F411095L,0xCE8346B3L},{(-8L),4L,8L,(-1L)},{0xFF0DFA01L,8L,0xCE8346B3L,8L},{0xCE8346B3L,8L,0xFF0DFA01L,(-1L)},{8L,4L,(-8L),0xCE8346B3L},{0x4F411095L,(-10L),(-10L),0x4F411095L}};
                    int i, j;
                    for (g_208 = 0; (g_208 > 19); ++g_208)
                    { /* block id: 585 */
                        uint16_t *l_1322 = &g_622;
                        int32_t l_1323 = 0x1F988B61L;
                        int32_t **l_1326 = (void*)0;
                        uint8_t *l_1346 = &g_611[1][1];
                        if (p_12)
                            break;
                        if (l_1311)
                            continue;
                    }
                    (*g_1349) = g_1347;
                    return p_12;
                }
                if ((*g_585))
                    continue;
                (*l_1351) = g_1350;
            }
            else
            { /* block id: 597 */
                for (g_151 = (-28); (g_151 <= 1); ++g_151)
                { /* block id: 600 */
                    uint16_t **l_1365 = &l_1321;
                    int32_t *l_1366 = &g_148[3];
                    int32_t *l_1367[10][5] = {{&l_1168,&g_148[4],&l_1032[0],&l_1032[5],&l_1032[0]},{&g_148[4],(void*)0,(void*)0,(void*)0,(void*)0},{&l_1052,&g_148[4],&l_1052,&g_148[4],&l_1032[0]},{&g_148[0],(void*)0,&l_1168,&g_78,&l_1168},{&l_1032[0],&l_1032[0],&l_1168,&l_1052,(void*)0},{&g_148[0],(void*)0,&g_148[4],&g_78,&g_78},{&l_1052,&g_148[4],&l_1052,&l_1032[2],&l_1032[5]},{&g_148[4],(void*)0,&g_148[0],(void*)0,&g_148[4]},{&l_1168,&l_1032[0],&l_1032[0],&l_1168,&l_1052},{&l_1168,(void*)0,&g_148[0],&g_148[4],(void*)0}};
                    int i, j;
                    if (g_578)
                        goto lbl_1354;
                    (*g_1347) = (((safe_lshift_func_uint8_t_u_u(((*l_1155) = (safe_rshift_func_uint16_t_u_u(((((*l_1242) = p_12) & ((((l_1359 == &l_1286) & (!(safe_mul_func_int16_t_s_s(0x47B1L, (!((l_1364 = (p_12 , (void*)0)) != (void*)0)))))) , l_1365) == &g_845)) <= 65529UL), p_12))), l_1299)) != 0x58L) , (**g_677));
                    --g_1368[0];
                    (*g_585) |= (safe_lshift_func_uint16_t_u_s(l_1299, 8));
                }
                for (g_264 = 0; (g_264 <= 0); g_264 += 1)
                { /* block id: 611 */
                    volatile int32_t **l_1374 = &g_1347;
                    int i;
                    (*g_1373) = g_265[g_264];
                    (*l_1374) = (*g_1349);
                }
            }
        }
    }
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_483 g_37 g_76 g_294 g_295 g_681 g_682 g_56 g_578 g_565 g_566 g_567 g_611 g_210 g_585 g_78 g_508 g_509 g_510 g_423 g_622 g_353 g_405 g_151 g_148 g_677 g_808 g_117 g_266 g_6 g_142 g_264 g_171 g_54 g_809 g_1019 g_1020 g_606 g_132
 * writes: g_483 g_76 g_56 g_78 g_37 g_132 g_353 g_585 g_171 g_809 g_405 g_117 g_845 g_210 g_622 g_266 g_264 g_54 g_578 g_423 g_611
 */
static uint64_t  func_14(int32_t  p_15, const int64_t  p_16, uint64_t  p_17, uint16_t  p_18)
{ /* block id: 318 */
    uint64_t *l_702 = &g_37[4];
    int32_t l_703 = 0xA8B2FBC4L;
    int64_t *l_704 = &g_483;
    int8_t *l_737[1];
    int8_t **l_736 = &l_737[0];
    uint32_t *l_743 = (void*)0;
    int32_t **l_750 = &g_585;
    int32_t l_764 = 0xEA9913E8L;
    int32_t l_765 = 0x0E7159FCL;
    int32_t l_766 = 0xEAF8D3DDL;
    int32_t l_767 = 0x526BA023L;
    int32_t l_769[9][7] = {{0xC3174B4EL,0xC3174B4EL,0x516FEABBL,4L,0x1394C7BFL,0xF8DEA814L,0xD0758725L},{0xD20D1392L,1L,(-1L),0x1394C7BFL,0xC3174B4EL,0x74938A68L,0x32BDED5EL},{1L,0x0BDB8EBBL,4L,1L,0x1394C7BFL,0x398F5E18L,0x0BDB8EBBL},{0x516FEABBL,(-4L),5L,5L,(-4L),0x516FEABBL,0x0BDB8EBBL},{0x398F5E18L,0x1394C7BFL,1L,4L,0x0BDB8EBBL,1L,0x32BDED5EL},{0x74938A68L,0xC3174B4EL,0x1394C7BFL,(-1L),1L,0xD20D1392L,0xD0758725L},{0xF8DEA814L,0x1394C7BFL,4L,0x516FEABBL,0xC3174B4EL,0xC3174B4EL,0x516FEABBL},{4L,(-4L),4L,0x516FEABBL,0x32BDED5EL,0x26A82596L,(-4L)},{0x516FEABBL,0x0BDB8EBBL,0xE4D35B60L,(-1L),(-10L),0x516FEABBL,0xA2C05424L}};
    uint16_t *l_843 = &g_622;
    uint32_t l_847[10][9] = {{0x6BEEFAE7L,1UL,4294967295UL,0x6BEEFAE7L,1UL,1UL,0x6BEEFAE7L,4294967295UL,1UL},{4294967295UL,4294967286UL,4294967295UL,4294967295UL,0x8E15D010L,0x8E15D010L,4294967295UL,4294967295UL,4294967286UL},{0x6BEEFAE7L,1UL,4294967295UL,0x6BEEFAE7L,1UL,1UL,0x6BEEFAE7L,4294967295UL,1UL},{4294967295UL,4294967286UL,0x970DAA26L,0x8E15D010L,0x054F7EDEL,0x054F7EDEL,0x8E15D010L,0x970DAA26L,0UL},{1UL,0UL,0x970C67ADL,1UL,8UL,8UL,1UL,0x970C67ADL,0UL},{0x8E15D010L,0UL,0x970DAA26L,0x8E15D010L,0x054F7EDEL,0x054F7EDEL,0x8E15D010L,0x970DAA26L,0UL},{1UL,0UL,0x970C67ADL,1UL,8UL,8UL,1UL,0x970C67ADL,0UL},{0x8E15D010L,0UL,0x970DAA26L,0x8E15D010L,0x054F7EDEL,0x054F7EDEL,0x8E15D010L,0x970DAA26L,0UL},{1UL,0UL,0x970C67ADL,1UL,8UL,8UL,1UL,0x970C67ADL,0UL},{0x8E15D010L,0UL,0x970DAA26L,0x8E15D010L,0x054F7EDEL,0x054F7EDEL,0x8E15D010L,0x970DAA26L,0UL}};
    int8_t **l_908[7];
    uint8_t l_1002 = 0xF7L;
    uint32_t l_1021 = 0xEDC500E4L;
    int32_t *l_1026 = &l_765;
    int i, j;
    for (i = 0; i < 1; i++)
        l_737[i] = (void*)0;
    for (i = 0; i < 7; i++)
        l_908[i] = (void*)0;
    if (((l_702 != (((((*l_704) ^= l_703) < ((safe_lshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_s((safe_sub_func_int64_t_s_s(l_703, l_703)), (safe_div_func_int8_t_s_s(((0x35L <= (g_37[7] <= (1UL == (((safe_lshift_func_int8_t_s_s(((safe_div_func_uint32_t_u_u((safe_mod_func_int64_t_s_s(((((**g_681) |= (safe_rshift_func_int16_t_s_s(((safe_lshift_func_int8_t_s_u((g_76 |= p_18), 0)) >= (safe_rshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(((safe_unary_minus_func_uint64_t_u(((void*)0 == (*g_294)))) >= 1L), l_703)), l_703)), 7))), 13))) , p_18) && (-1L)), g_578)), l_703)) & 0x06L), p_18)) , 0L) , (**g_565))))) && l_703), p_16)))) , g_611[1][0]), 0x2A8BL)), p_15)) < g_210[4])) | 0xFFEAF855L) , &p_17)) , (-1L)))
    { /* block id: 322 */
        int32_t *l_732 = &g_701;
        int8_t *l_734 = &g_76;
        int8_t **l_733 = &l_734;
        int8_t ***l_735[1];
        uint32_t ***l_740 = (void*)0;
        int32_t l_744 = 0x2053A33FL;
        uint8_t *l_745[4];
        uint32_t l_754 = 0x6CF5147CL;
        uint32_t l_803 = 0UL;
        int i;
        for (i = 0; i < 1; i++)
            l_735[i] = &l_733;
        for (i = 0; i < 4; i++)
            l_745[i] = &g_151;
lbl_779:
        (*g_585) = ((l_703 = ((((l_732 != l_732) | ((l_736 = l_733) == &l_737[0])) & ((safe_add_func_uint8_t_u_u(((*g_585) && ((void*)0 != l_740)), (((safe_mul_func_uint8_t_u_u((((l_743 != l_743) <= 0xCC6BL) | p_18), l_744)) || p_18) , (**g_508)))) , 8UL)) == l_744)) < g_423[2]);
        (**l_750) = ((g_622 == ((~(safe_mod_func_uint16_t_u_u((+(**g_565)), 0x0897L))) != ((void*)0 == l_750))) > ((*l_702) = ((l_744 < (safe_mul_func_uint8_t_u_u((safe_unary_minus_func_uint16_t_u(l_754)), (safe_mul_func_uint16_t_u_u(g_353, p_18))))) <= l_754)));
        for (g_132 = 0; (g_132 != 27); g_132 = safe_add_func_int32_t_s_s(g_132, 3))
        { /* block id: 330 */
            int64_t l_763 = 0xB59B02D502948699LL;
            int32_t l_768 = 0xF36B078EL;
            int32_t l_770 = 0x0D86BC9AL;
            int32_t l_771 = (-1L);
            int32_t l_794 = 0x9209DC80L;
            for (p_17 = 0; (p_17 != 38); p_17 = safe_add_func_int64_t_s_s(p_17, 4))
            { /* block id: 333 */
                int32_t *l_761 = &g_78;
                int32_t *l_762[7][2][3] = {{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}},{{&g_148[6],&g_148[6],&g_148[6]},{&g_148[4],&g_148[6],&g_148[4]}}};
                uint32_t l_772 = 0x55152E0CL;
                int8_t l_795 = 0L;
                int i, j, k;
                ++l_772;
                for (g_56 = (-11); (g_56 > 21); g_56 = safe_add_func_uint32_t_u_u(g_56, 3))
                { /* block id: 337 */
                    uint16_t *l_788 = &g_353;
                    int32_t l_791 = 0x0AA3C373L;
                    for (g_483 = 0; (g_483 != 19); g_483 = safe_add_func_int32_t_s_s(g_483, 4))
                    { /* block id: 340 */
                        if ((**l_750))
                            break;
                        if (g_78)
                            goto lbl_779;
                    }
                    l_791 &= ((safe_rshift_func_int8_t_s_u((*g_509), 6)) != ((((l_768 || (((safe_lshift_func_int16_t_s_u((((safe_div_func_int32_t_s_s(((*g_508) != (*g_508)), (g_405 , (safe_mul_func_uint16_t_u_u(0x8A26L, (++(*l_788))))))) > 0L) , g_578), 6)) < g_151) & p_16)) | p_16) <= g_148[1]) <= (-1L)));
                    for (l_770 = 0; (l_770 <= 1); l_770 += 1)
                    { /* block id: 348 */
                        int32_t l_792 = 0xD3366E39L;
                        int32_t l_793[3];
                        uint8_t l_796[8];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_793[i] = (-1L);
                        for (i = 0; i < 8; i++)
                            l_796[i] = 0UL;
                        ++l_796[3];
                        return l_792;
                    }
                }
            }
            if ((safe_sub_func_int16_t_s_s(p_16, 65535UL)))
            { /* block id: 354 */
                (*l_750) = (*g_677);
            }
            else
            { /* block id: 356 */
                int32_t *l_801 = &l_703;
                int32_t *l_802[3][5];
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 5; j++)
                        l_802[i][j] = &l_764;
                }
                (*l_750) = l_801;
                --l_803;
                (*g_585) = 1L;
            }
            for (g_171 = 0; (g_171 != (-7)); --g_171)
            { /* block id: 363 */
                (*g_808) = &g_535;
            }
            (*g_677) = &p_15;
        }
    }
    else
    { /* block id: 368 */
        int8_t l_810 = 0x0EL;
        int32_t l_813 = 0L;
        int32_t l_827 = 5L;
        int32_t l_828 = 0x76C39AF6L;
        int32_t l_853 = (-1L);
        int32_t l_855 = 9L;
        int32_t l_856 = 0xEF73A70EL;
        int32_t l_857 = (-1L);
        int8_t l_858 = 1L;
        int32_t l_859 = 0x26E7447EL;
        int32_t l_860 = 0x3385A753L;
        int32_t l_861 = 0L;
        for (g_405 = 0; (g_405 <= 2); g_405 += 1)
        { /* block id: 371 */
            int32_t *l_811 = (void*)0;
            int32_t *l_812 = &g_78;
            int32_t *l_814 = &l_765;
            int32_t *l_815 = (void*)0;
            int32_t *l_816 = &g_148[1];
            int32_t *l_817 = (void*)0;
            int32_t *l_818 = &l_703;
            int32_t *l_819 = &l_769[7][3];
            int32_t *l_820 = &l_769[5][1];
            int32_t *l_821 = &l_769[8][4];
            int32_t *l_822 = &l_764;
            int32_t *l_823 = &l_767;
            int32_t *l_824 = &l_767;
            int32_t l_825 = 0xE02E974CL;
            int32_t *l_826[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t l_829 = 0UL;
            uint32_t l_862 = 5UL;
            int i;
            l_829++;
            for (p_18 = 0; (p_18 <= 2); p_18 += 1)
            { /* block id: 375 */
                return g_622;
            }
            (*l_750) = (*l_750);
            for (g_117 = 2; (g_117 >= 0); g_117 -= 1)
            { /* block id: 381 */
                uint64_t l_836 = 0UL;
                int32_t l_849 = 1L;
                int32_t l_850 = (-1L);
                int32_t l_851 = 9L;
                int32_t l_852[5][9] = {{(-1L),0xB2FFB9E6L,0xB2FFB9E6L,(-1L),0x70504FE9L,0L,(-1L),0L,0x70504FE9L},{(-5L),0x98BDA710L,0x98BDA710L,(-5L),0x3DF47AFDL,0L,(-5L),0L,0x3DF47AFDL},{(-1L),0xB2FFB9E6L,0xB2FFB9E6L,(-1L),0x70504FE9L,0L,(-1L),0L,0x70504FE9L},{(-5L),0x98BDA710L,0x98BDA710L,(-5L),0x3DF47AFDL,0L,(-5L),0L,0x3DF47AFDL},{(-1L),0xB2FFB9E6L,0xB2FFB9E6L,(-1L),0x70504FE9L,0L,(-1L),0L,0x70504FE9L}};
                int32_t l_854 = 1L;
                int8_t * const *l_871 = &l_737[0];
                int i, j;
                for (g_56 = 0; (g_56 <= 2); g_56 += 1)
                { /* block id: 384 */
                    uint16_t **l_844[5][6] = {{&l_843,(void*)0,(void*)0,&l_843,(void*)0,(void*)0},{&l_843,(void*)0,(void*)0,&l_843,(void*)0,(void*)0},{&l_843,(void*)0,(void*)0,&l_843,(void*)0,(void*)0},{&l_843,(void*)0,(void*)0,&l_843,(void*)0,(void*)0},{&l_843,(void*)0,(void*)0,&l_843,(void*)0,(void*)0}};
                    uint8_t *l_846[7][1];
                    int32_t l_848[10][6] = {{(-1L),0x4D75CD67L,0L,(-1L),0x25EC8461L,0x25EC8461L},{0x4D75CD67L,0xA777F6F0L,0xA777F6F0L,0x4D75CD67L,0x25EC8461L,0x5D868E67L},{0L,0xA777F6F0L,0x25EC8461L,0L,0x25EC8461L,0xA777F6F0L},{0x8A595653L,0xA777F6F0L,0x5D868E67L,0x8A595653L,0x25EC8461L,0x25EC8461L},{0x4D75CD67L,0xA777F6F0L,0xA777F6F0L,0x4D75CD67L,0x25EC8461L,0x5D868E67L},{0L,0xA777F6F0L,0x25EC8461L,0L,0x25EC8461L,0xA777F6F0L},{0x8A595653L,0xA777F6F0L,0x5D868E67L,0x8A595653L,0x25EC8461L,0x25EC8461L},{0x4D75CD67L,0xA777F6F0L,0xA777F6F0L,0x4D75CD67L,0x25EC8461L,0x5D868E67L},{0L,0xA777F6F0L,0x25EC8461L,0L,0x25EC8461L,0xA777F6F0L},{0x8A595653L,0xA777F6F0L,0x5D868E67L,0x8A595653L,0x25EC8461L,0x25EC8461L}};
                    int i, j, k;
                    for (i = 0; i < 7; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_846[i][j] = &g_210[7];
                    }
                    (*l_814) ^= (0xAF76L || ((((safe_mul_func_uint8_t_u_u(0x7DL, (safe_mul_func_int8_t_s_s(((l_836 ^ (safe_lshift_func_int16_t_s_s((((**l_750) ^= (safe_lshift_func_uint8_t_u_u(((void*)0 == g_266[g_117][(g_56 + 5)][g_56]), ((safe_sub_func_int32_t_s_s((((l_847[0][1] = ((g_845 = l_843) != &g_353)) >= l_848[1][3]) , l_848[1][3]), p_17)) , p_18)))) >= p_17), 8))) >= g_578), l_836)))) || l_827) ^ l_827) ^ p_17));
                }
                --l_862;
                for (l_810 = 2; (l_810 >= 0); l_810 -= 1)
                { /* block id: 393 */
                    uint8_t *l_868 = &g_210[1];
                    const int32_t l_883 = 1L;
                    int i, j, k;
                    (*l_821) &= ((~((((((((safe_mul_func_uint8_t_u_u((g_6 >= (((((void*)0 == g_266[l_810][(g_117 + 5)][(g_117 + 3)]) , ((((**l_750) & (((((*l_868) &= p_18) > (safe_lshift_func_int8_t_s_s(((void*)0 != l_871), ((safe_mul_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((safe_div_func_int8_t_s_s((g_76 ^= (+(safe_div_func_int16_t_s_s(((safe_div_func_int16_t_s_s((**g_565), g_148[0])) || (**l_750)), 0xB1F6L)))), 1UL)), 0xED3121D58A26FCEELL)), p_18)) || (*l_823))))) <= 0x70L) >= l_828)) >= l_883) >= g_142)) & 1UL) != l_883)), 255UL)) || (*g_585)) == 0x2BF51855L) , g_78) != p_16) & 0x7552L) , 0x65B4EFB3L) >= (*g_585))) | 0x8DL);
                    g_266[l_810][(l_810 + 6)][(l_810 + 3)] = ((safe_sub_func_uint16_t_u_u((--(*l_843)), (safe_mod_func_int32_t_s_s(p_17, 1UL)))) , (void*)0);
                    for (l_855 = 0; (l_855 <= 2); l_855 += 1)
                    { /* block id: 401 */
                        const uint64_t l_890 = 0UL;
                        int i, j, k;
                        (*l_822) |= l_890;
                        g_266[g_117][l_855][(g_405 + 4)] = (*l_750);
                    }
                }
            }
        }
        (*l_750) = &p_15;
    }
    for (g_264 = 15; (g_264 >= 30); g_264 = safe_add_func_int64_t_s_s(g_264, 8))
    { /* block id: 412 */
        int32_t *l_893[3][2];
        int8_t **l_903 = &l_737[0];
        int8_t ***l_904 = (void*)0;
        int8_t ***l_905 = (void*)0;
        int8_t ***l_906 = &l_736;
        int8_t ***l_907[7][8] = {{(void*)0,&l_903,&l_903,&l_736,&l_903,&l_903,(void*)0,(void*)0},{&l_903,&l_736,&l_903,&l_903,&l_736,&l_903,(void*)0,&l_903},{&l_736,&l_903,(void*)0,&l_903,&l_736,&l_903,&l_903,&l_736},{&l_903,(void*)0,(void*)0,&l_903,&l_903,&l_736,&l_903,&l_903},{(void*)0,&l_903,(void*)0,&l_903,(void*)0,(void*)0,&l_903,(void*)0},{&l_903,&l_903,(void*)0,&l_736,&l_736,&l_736,(void*)0,&l_903},{&l_903,(void*)0,&l_903,(void*)0,(void*)0,&l_903,(void*)0,&l_903}};
        uint32_t l_909 = 18446744073709551608UL;
        uint16_t l_993 = 65526UL;
        const uint32_t *l_1018 = &l_847[6][2];
        const uint32_t **l_1017 = &l_1018;
        const uint32_t *** const l_1016 = &l_1017;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 2; j++)
                l_893[i][j] = &l_769[7][6];
        }
        (*l_750) = l_893[1][0];
        if (p_17)
            break;
        if (((((((safe_rshift_func_int16_t_s_u((&g_845 == &l_843), 9)) >= ((void*)0 != &l_743)) || (*g_509)) || (safe_mul_func_int8_t_s_s((g_622 & (((0x3661L ^ ((((safe_sub_func_int16_t_s_s((!p_17), (((l_908[2] = l_903) == &l_737[0]) , (**g_565)))) ^ p_17) < g_611[1][0]) | 4294967292UL)) != g_171) & p_15)), (-1L)))) | p_16) > l_909))
        { /* block id: 416 */
            for (g_54 = 0; (g_54 == 30); g_54 = safe_add_func_uint8_t_u_u(g_54, 1))
            { /* block id: 419 */
                (**l_750) ^= (-1L);
            }
        }
        else
        { /* block id: 422 */
            int32_t l_918 = (-3L);
            uint64_t l_939 = 18446744073709551615UL;
            uint32_t * const l_943 = (void*)0;
            int32_t l_987 = 0x6AA18CACL;
            int32_t l_988 = 1L;
            for (g_578 = 0; (g_578 <= 1); g_578 += 1)
            { /* block id: 425 */
                int16_t l_938 = 7L;
                int32_t l_1001 = 6L;
                if ((0UL <= (safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((safe_sub_func_int64_t_s_s(((*l_704) |= p_16), l_918)), p_18)), ((safe_rshift_func_int8_t_s_u(((((safe_mul_func_int16_t_s_s((safe_unary_minus_func_int32_t_s(((safe_rshift_func_uint16_t_u_u((((safe_div_func_uint32_t_u_u(0xC425557FL, 1L)) , (((safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((((safe_lshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s(g_578, ((((((safe_rshift_func_uint16_t_u_s(l_938, (p_15 == p_17))) , 65528UL) < (**l_750)) == (**l_750)) <= g_148[5]) | (**g_565)))), g_611[0][1])) == (-2L)) < l_938) || 1L), p_16)), 0x693EL)) & 1L) , 0xB9L)) || l_938), 8)) , 0x3EE6B8ACL))), g_611[0][1])) <= (**l_750)) && l_939) >= g_151), 7)) , (-8L))))))
                { /* block id: 427 */
                    uint32_t *l_940 = &g_423[2];
                    const int32_t l_944 = (-1L);
                    const uint32_t l_955 = 0x6C7C1755L;
                    int32_t l_956 = 3L;
                    uint16_t l_999 = 0xADF2L;
                    int32_t l_1000[7] = {(-1L),(-1L),0xBAD8B529L,(-1L),(-1L),0xBAD8B529L,(-1L)};
                    int i;
                    if (((l_956 = (((*l_940)--) > (((**l_750) & ((void*)0 != l_943)) && (1L ^ (0xD41914A354169408LL ^ ((l_944 == ((safe_add_func_uint32_t_u_u((0x07L != (safe_rshift_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s(((-3L) > ((*l_843) = ((safe_mul_func_int16_t_s_s((-8L), 0xC2D9L)) != p_17))), l_955)) && g_567), p_16)), g_210[7]))), 0x8F432BA0L)) && p_16)) , 0xAE9B4969A88306E0LL)))))) , (**l_750)))
                    { /* block id: 431 */
                        uint8_t l_967 = 0UL;
                        int8_t **l_972 = &l_737[0];
                        uint8_t *l_973 = (void*)0;
                        uint8_t *l_974 = &g_611[1][0];
                        if (p_17)
                            break;
                        (**l_750) = ((safe_unary_minus_func_int64_t_s((safe_rshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_s(((*l_974) |= ((0x88L > (((((**l_750) < (~(safe_mul_func_int16_t_s_s((-1L), (safe_sub_func_uint16_t_u_u(p_18, (((l_967 , (((safe_mul_func_uint16_t_u_u((1UL != (**g_677)), p_15)) >= ((safe_sub_func_int32_t_s_s(0L, 0x4EF787D5L)) , p_16)) && p_16)) , l_972) != (void*)0))))))) ^ g_78) >= 0UL) != p_15)) || 0x0A81EC3339A47342LL)), 0)) && 0xABBEL), 3)))) == 2UL);
                    }
                    else
                    { /* block id: 435 */
                        g_78 &= ((safe_rshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s(p_17, 0)), ((**l_750) , ((((safe_div_func_uint8_t_u_u(((18446744073709551615UL > (-1L)) || (p_18 , ((safe_add_func_uint16_t_u_u(0UL, (safe_sub_func_int64_t_s_s((safe_div_func_uint16_t_u_u((((void*)0 != (*g_808)) | ((l_987 = p_16) == (-1L))), p_15)), 0x797EEECA02863363LL)))) < 18446744073709551615UL))), (-3L))) == 0x9816B051L) > l_988) & 1L)))) | p_15);
                    }
                    for (p_15 = 0; (p_15 >= 0); p_15 -= 1)
                    { /* block id: 441 */
                        int i;
                        (*g_585) = g_210[p_15];
                        l_1001 = (safe_add_func_uint8_t_u_u(((g_423[(g_578 + 6)] ^= ((18446744073709551615UL || ((l_1000[4] |= ((((((l_993 | ((l_956 ^= (p_17 <= (-4L))) <= ((safe_rshift_func_uint16_t_u_u(0x0C11L, l_955)) | p_17))) , (safe_mod_func_uint8_t_u_u((g_210[(g_578 + 3)] = ((+8UL) ^ ((&g_483 == l_702) , p_16))), 1UL))) != 1L) , g_210[7]) >= l_999) ^ 7L)) < 0x9FL)) | l_988)) , l_944), p_16));
                    }
                }
                else
                { /* block id: 449 */
                    l_1002++;
                }
                if ((**l_750))
                    break;
                for (l_938 = 6; (l_938 >= 1); l_938 -= 1)
                { /* block id: 455 */
                    int i;
                    return g_148[(l_938 + 1)];
                }
            }
        }
        g_78 ^= (safe_mod_func_uint64_t_u_u(((**g_508) > (safe_div_func_int64_t_s_s((((((**l_750) <= (safe_mod_func_uint16_t_u_u(0xE5B9L, (safe_rshift_func_int16_t_s_u((((~(**l_750)) >= ((*l_702) = ((&l_847[5][3] != l_893[1][0]) > (((safe_add_func_uint8_t_u_u(((void*)0 == l_1016), 0x7DL)) ^ p_15) ^ 0x36D3L)))) || p_16), 11))))) , (void*)0) != g_1019) == (**g_1020)), (**l_750)))), g_6));
    }
    (**l_750) = l_1021;
    (*l_1026) = (((**l_750) = ((safe_rshift_func_int8_t_s_u((**l_750), 2)) == p_16)) , ((safe_rshift_func_int8_t_s_u(p_18, 5)) ^ p_18));
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_27(int16_t  p_28, int64_t  p_29, int32_t  p_30, uint32_t  p_31)
{ /* block id: 314 */
    int32_t *l_693 = &g_148[1];
    int32_t *l_694 = &g_148[1];
    int16_t l_695[2][9] = {{0xECF7L,0x15A0L,(-7L),(-3L),(-7L),0x15A0L,0xECF7L,0xECF7L,0x15A0L},{(-3L),0x15A0L,(-2L),0x15A0L,(-3L),0x3FA2L,0x3FA2L,(-3L),0x15A0L}};
    int32_t *l_696[4][7] = {{&g_78,&g_148[4],&g_78,&g_78,&g_148[4],&g_148[4],&g_78},{&g_78,&g_148[4],&g_78,&g_78,&g_148[4],&g_148[4],&g_78},{&g_78,&g_148[4],&g_78,&g_78,&g_148[4],&g_148[4],&g_78},{&g_78,&g_148[4],&g_78,&g_78,&g_148[4],&g_148[4],&g_78}};
    int8_t l_697 = (-9L);
    uint16_t l_698 = 0UL;
    int i, j;
    l_698++;
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_6 g_54 g_76 g_78 g_117 g_148 g_151 g_171 g_142 g_132 g_210 g_208 g_264 g_585 g_605 g_508 g_509 g_510 g_565 g_566 g_622 g_483
 * writes: g_54 g_56 g_76 g_78 g_132 g_142 g_148 g_151 g_171 g_208 g_264 g_117 g_578 g_605 g_611 g_622 g_483
 */
static int16_t  func_32(uint32_t  p_33, uint32_t  p_34, const int32_t  p_35)
{ /* block id: 2 */
    int32_t *l_625 = &g_78;
    const uint64_t *l_633 = &g_37[0];
    uint16_t *l_641 = &g_622;
    int32_t l_686 = (-6L);
    int32_t l_687[5][7] = {{0xDC0FC550L,0xB5D85E22L,0xB5D85E22L,0xDC0FC550L,0x4358AE7EL,0xDC0FC550L,0xB5D85E22L},{0x62D3755EL,0x62D3755EL,0x35B33501L,1L,0x35B33501L,0x62D3755EL,0x62D3755EL},{0x3E42BE89L,0xB5D85E22L,0L,0xB5D85E22L,0x3E42BE89L,0x3E42BE89L,0xB5D85E22L},{0L,1L,0L,0x35B33501L,0L,1L,0x62D3755EL},{0xDC0FC550L,0x3E42BE89L,0x4358AE7EL,0x4358AE7EL,0x3E42BE89L,0xDC0FC550L,0x3E42BE89L}};
    int i, j;
    for (p_34 = 2; (p_34 > 43); ++p_34)
    { /* block id: 5 */
        const uint8_t *l_152 = &g_6;
        const uint64_t * const l_592[1] = {&g_37[6]};
        int32_t *l_627 = &g_148[5];
        uint32_t **l_647 = &g_606[1];
        int32_t l_685[2];
        uint64_t l_688 = 0x87F6CF9DF2F57C5CLL;
        int i;
        for (i = 0; i < 2; i++)
            l_685[i] = (-9L);
        for (p_33 = 17; (p_33 < 55); p_33 = safe_add_func_uint8_t_u_u(p_33, 9))
        { /* block id: 8 */
            uint8_t *l_53 = &g_54;
            uint32_t *l_55 = &g_56;
            int32_t l_71 = 0x5D0C9AD5L;
            int32_t **l_626[5] = {&l_625,&l_625,&l_625,&l_625,&l_625};
            int i;
            (*g_585) = ((5UL >= (func_46(func_49((g_37[7] , ((*l_55) = (+((*l_53) &= (g_6 == 255UL))))), func_57((((void*)0 == &p_33) , 0L), &g_37[1], func_63((safe_add_func_uint64_t_u_u(p_35, p_33)), g_6, l_71, g_6, g_6), l_152, g_37[3])), l_592[0]) , 0x73L)) ^ p_34);
            l_627 = l_625;
        }
        for (g_151 = 0; (g_151 <= 0); g_151 += 1)
        { /* block id: 275 */
            int i;
            (*l_625) = g_37[(g_151 + 5)];
        }
        for (g_483 = 2; (g_483 >= 0); g_483 -= 1)
        { /* block id: 280 */
            uint8_t *l_630 = &g_210[3];
            uint32_t *l_634 = &g_423[2];
            int8_t *l_635[1];
            int32_t l_636[7] = {0x0E8C3949L,0x0E8C3949L,0x0E8C3949L,0x0E8C3949L,0x0E8C3949L,0x0E8C3949L,0x0E8C3949L};
            int8_t l_656[9][5][5] = {{{5L,(-1L),(-4L),(-1L),5L},{0x95L,(-9L),4L,1L,0x5CL},{0x9BL,0xBEL,0xAFL,0x02L,9L},{(-5L),4L,0x5CL,(-9L),0x5CL},{0x02L,0x02L,(-9L),0xAFL,5L}},{{0x5CL,0x57L,0x5DL,0xB5L,0L},{(-4L),1L,9L,0x1AL,(-1L)},{0x07L,0x57L,0x57L,0x07L,0x18L},{0xBEL,0x02L,0xA3L,5L,1L},{0x5DL,4L,0x12L,(-5L),0x57L}},{{1L,0xBEL,5L,5L,0xBEL},{0L,(-9L),(-1L),0x07L,0x95L},{0x80L,(-1L),0x02L,0x1AL,0xA3L},{(-9L),1L,(-1L),0xB5L,0xB5L},{0x80L,(-9L),0x80L,0xAFL,0x3AL}},{{0L,(-1L),(-5L),(-9L),1L},{1L,0x1AL,1L,0x02L,0x84L},{0x5DL,1L,(-5L),1L,0x5DL},{0xBEL,(-6L),0x80L,(-1L),0x02L},{0x07L,0x95L,(-1L),0x5CL,0x12L}},{{(-4L),0x80L,0x02L,(-6L),0x02L},{0x5CL,0x5CL,(-1L),(-1L),0x5DL},{0x02L,0xA3L,5L,1L,0x84L},{(-5L),0x30L,0x12L,1L,1L},{0x9BL,0xA3L,0xA3L,0x9BL,0x3AL}},{{0x95L,0x5CL,0x57L,0x5DL,0xB5L},{5L,0x80L,9L,(-4L),0xA3L},{0x30L,0x95L,0x5DL,0x5DL,0x95L},{0x84L,(-6L),(-9L),0x9BL,0xBEL},{4L,1L,0x5CL,1L,0x57L}},{{(-6L),0x1AL,0xAFL,1L,1L},{4L,(-1L),4L,(-1L),0x18L},{0x84L,(-9L),(-4L),(-6L),(-1L)},{0x30L,1L,0xB5L,(-5L),(-1L)},{0x80L,0x02L,(-6L),0x02L,0x80L}},{{0x57L,0x07L,0x18L,0x5CL,(-5L)},{0x84L,0xA3L,0xBEL,(-4L),1L},{(-9L),0x18L,(-5L),0x07L,(-5L)},{(-4L),(-4L),0x1AL,0xBEL,0x80L},{(-5L),0x12L,4L,0x5DL,(-1L)}},{{(-6L),(-1L),1L,1L,0x02L},{0L,0x12L,0x12L,0L,(-1L)},{0xA3L,(-4L),9L,0x80L,5L},{4L,0x18L,0xB5L,(-9L),0x12L},{(-1L),0xA3L,0x80L,0x80L,0xA3L}}};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_635[i] = (void*)0;
        }
    }
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_585 g_78 g_142 g_605 g_508 g_509 g_510 g_565 g_566 g_622 g_37 g_578
 * writes: g_578 g_78 g_605 g_76 g_611 g_622
 */
static uint64_t  func_46(uint64_t * p_47, const uint64_t * const  p_48)
{ /* block id: 247 */
    int32_t *l_593[6][2] = {{&g_148[2],&g_148[2]},{&g_148[2],&g_148[2]},{&g_148[2],&g_148[2]},{&g_148[2],&g_148[2]},{&g_148[2],&g_148[2]},{&g_148[2],&g_148[2]}};
    uint16_t l_594[2];
    uint32_t **l_608 = (void*)0;
    uint32_t **l_617[6][1] = {{&g_606[1]},{&g_606[1]},{&g_606[1]},{&g_606[1]},{&g_606[1]},{&g_606[1]}};
    int i, j;
    for (i = 0; i < 2; i++)
        l_594[i] = 65535UL;
lbl_604:
    ++l_594[0];
    for (g_578 = 0; (g_578 < 20); g_578 = safe_add_func_uint64_t_u_u(g_578, 7))
    { /* block id: 251 */
        uint16_t l_599 = 0x713BL;
        uint32_t ***l_607 = &g_605[5][3][5];
        uint32_t **l_609 = &g_606[1];
        int8_t *l_610[8];
        uint32_t ***l_614 = (void*)0;
        uint32_t **l_616 = &g_606[1];
        uint32_t ***l_615[5][2] = {{&l_616,&l_616},{&l_616,&l_616},{&l_616,&l_616},{&l_616,&l_616},{&l_616,&l_616}};
        uint32_t l_618[3][4][5] = {{{0x90D3998EL,0x342FC89BL,0x90D3998EL,4294967293UL,4294967288UL},{0x22D896E5L,0xE1BB42C9L,1UL,0xE1BB42C9L,0x22D896E5L},{0x90D3998EL,4294967295UL,0x342FC89BL,0x81C403D4L,0x342FC89BL},{1UL,1UL,1UL,0x22D896E5L,0xD50906A9L}},{{4294967295UL,0x90D3998EL,0x90D3998EL,4294967295UL,0x342FC89BL},{0xE1BB42C9L,0x22D896E5L,0UL,0UL,0x22D896E5L},{0x342FC89BL,0x90D3998EL,4294967293UL,4294967288UL,4294967288UL},{0x77B1D39FL,1UL,0x77B1D39FL,0UL,1UL}},{{0x81C403D4L,4294967295UL,4294967288UL,4294967295UL,0x81C403D4L},{0x77B1D39FL,0xE1BB42C9L,1UL,0x22D896E5L,1UL},{0x342FC89BL,0x342FC89BL,4294967288UL,0x81C403D4L,0x553FD135L},{0xE1BB42C9L,0x77B1D39FL,0x77B1D39FL,0xE1BB42C9L,1UL}}};
        uint32_t **l_619 = (void*)0;
        uint64_t l_620 = 18446744073709551611UL;
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_610[i] = &g_76;
        l_599--;
        if (l_599)
        { /* block id: 253 */
            if ((*g_585))
                break;
            (*g_585) = (safe_add_func_int64_t_s_s(0x8F9924089EBD89B4LL, g_142));
            if (l_599)
                continue;
        }
        else
        { /* block id: 257 */
            if (g_78)
                goto lbl_604;
        }
        l_620 = (((((*l_607) = g_605[7][1][0]) == (l_609 = l_608)) <= l_599) | (((g_611[1][0] = (g_76 = (**g_508))) & (((l_618[0][2][4] = ((l_617[3][0] = l_608) == l_608)) && (l_619 != &g_295)) && (((*g_565) != (void*)0) , 0L))) >= l_599));
    }
    g_622++;
    return (*p_48);
}


/* ------------------------------------------ */
/* 
 * reads : g_132 g_76 g_37 g_264 g_208 g_117
 * writes: g_264 g_208 g_117
 */
static uint64_t * func_49(uint32_t  p_50, uint64_t * p_51)
{ /* block id: 89 */
    int64_t l_261 = 0xA9CDB1E1FFC80131LL;
    uint64_t *l_263 = &g_264;
    int32_t l_267[2][4] = {{(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L)}};
    int32_t *l_269 = (void*)0;
    int32_t **l_268 = &l_269;
    int32_t *l_296[3][4] = {{&g_78,&l_267[1][0],&g_78,&g_78},{&l_267[1][0],&l_267[1][0],&g_78,&l_267[1][0]},{&l_267[1][0],&g_78,&g_78,&l_267[1][0]}};
    uint8_t *l_386 = (void*)0;
    uint64_t l_402 = 0xCE6463C702A619F6LL;
    uint16_t l_446 = 0x2349L;
    uint32_t l_478 = 0xBB8548AEL;
    int i, j;
    l_267[1][3] ^= (((*l_263) &= (g_132 < ((((safe_mod_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(p_50, (((safe_mul_func_int16_t_s_s((~(p_50 >= (-1L))), (((((safe_mul_func_int8_t_s_s((-1L), l_261)) == (((p_50 >= (~p_50)) && g_76) > l_261)) & l_261) ^ p_50) >= (*p_51)))) , p_50) >= p_50))) <= 0x3D0893F3L), p_50)) < (-2L)) , 0x83001185A11B485FLL) != 0x8AB036926210D50ELL))) && l_261);
    (*l_268) = &l_267[1][3];
    for (p_50 = 0; (p_50 == 52); ++p_50)
    { /* block id: 95 */
        uint32_t *l_285 = &g_142;
        int32_t l_305 = 0xCF774277L;
        int32_t **l_424[4][8] = {{&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3]},{&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3]},{&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3]},{&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3],&l_296[1][3]}};
        uint64_t l_426 = 0UL;
        const uint16_t l_442 = 0x03C6L;
        int32_t l_460 = 0x3A2BF0E4L;
        int32_t l_461 = 0x6B022F53L;
        int16_t *l_492 = (void*)0;
        uint8_t **l_499 = &l_386;
        int i, j;
        for (g_208 = 27; (g_208 >= 19); g_208--)
        { /* block id: 98 */
            int32_t l_276 = 0L;
            int16_t l_374 = 5L;
            uint32_t *l_385 = &g_56;
            const int32_t *l_410 = &l_276;
            const int32_t **l_409 = &l_410;
            uint8_t l_419 = 1UL;
            uint32_t l_420 = 4UL;
            uint64_t *l_428 = &g_37[7];
        }
        for (g_117 = 0; (g_117 <= 0); g_117 = safe_add_func_int16_t_s_s(g_117, 1))
        { /* block id: 166 */
            uint16_t l_451 = 0UL;
            int32_t l_453 = (-2L);
            uint32_t **l_474 = (void*)0;
            uint32_t l_481[8][6] = {{0x1622A05FL,0x1622A05FL,0UL,18446744073709551615UL,0x0A009970L,7UL},{0x0A29E181L,0UL,0xA3CEE7E9L,7UL,0xA3CEE7E9L,0UL},{18446744073709551615UL,0x0A29E181L,0xA3CEE7E9L,0UL,0x1622A05FL,7UL},{0x048A7D49L,0UL,0UL,0UL,0UL,0x048A7D49L},{0UL,0UL,0x048A7D49L,0x4B3D6CBAL,0x1622A05FL,0xA3CEE7E9L},{0xA3CEE7E9L,0x0A29E181L,18446744073709551615UL,0x0A29E181L,0xA3CEE7E9L,0UL},{0xA3CEE7E9L,0UL,0x0A29E181L,0x4B3D6CBAL,0x0A009970L,0x0A009970L},{0UL,0x1622A05FL,0x1622A05FL,0UL,18446744073709551615UL,0x0A009970L}};
            int32_t l_515 = 0x30CA9BB8L;
            int32_t l_516 = 3L;
            int32_t l_519 = 0L;
            int32_t l_521 = (-2L);
            int32_t l_523 = 0xAFB7D94BL;
            int32_t l_527 = 0xBD608A87L;
            int32_t l_529 = 0x881AFF97L;
            uint8_t **l_533 = &l_386;
            int16_t **l_568 = &l_492;
            int32_t *l_586[8][3][1] = {{{(void*)0},{&l_529},{(void*)0}},{{&l_529},{(void*)0},{&l_529}},{{(void*)0},{&l_529},{(void*)0}},{{&l_529},{(void*)0},{&l_529}},{{(void*)0},{&l_529},{(void*)0}},{{&l_529},{(void*)0},{&l_529}},{{(void*)0},{&l_529},{(void*)0}},{{&l_529},{(void*)0},{&l_529}}};
            int i, j, k;
        }
    }
    return &g_37[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_171 g_142 g_132 g_6 g_117 g_76 g_148 g_151 g_37 g_78 g_210 g_208
 * writes: g_78 g_171 g_76 g_142 g_208
 */
static uint64_t * func_57(const int16_t  p_58, uint64_t * p_59, uint8_t  p_60, const uint8_t * p_61, int16_t  p_62)
{ /* block id: 41 */
    int32_t *l_160 = (void*)0;
    int32_t *l_161[4] = {&g_148[4],&g_148[4],&g_148[4],&g_148[4]};
    int16_t *l_170 = &g_171;
    uint32_t l_176[9] = {0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL,0xCAC61BAFL};
    int8_t *l_177 = &g_76;
    uint64_t *l_251 = &g_37[2];
    int i;
    if (((safe_sub_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(((*l_177) = ((+(g_78 = 0x02195449L)) ^ (1UL == (safe_add_func_uint32_t_u_u(p_60, ((p_59 != ((safe_mod_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(0UL, (safe_add_func_int64_t_s_s(((((*l_170) |= 0xE641L) > ((((safe_rshift_func_int8_t_s_s((g_142 & ((((safe_add_func_int8_t_s_s((g_132 && (p_62 |= (g_142 | (-1L)))), 0x3AL)) | (*p_61)) && p_58) && 0UL)), g_117)) & (*p_61)) == g_76) && g_6)) || l_176[0]), 0x39712D87D7775BE2LL)))), g_148[4])) , (void*)0)) <= g_142)))))), g_132)) >= 0x64L), g_151)) ^ g_37[7]))
    { /* block id: 46 */
        int64_t l_203 = 1L;
        int32_t l_211[9][8] = {{0x1E35D45CL,(-1L),0x4D80B7E5L,0x073E9785L,(-1L),0x073E9785L,0x4D80B7E5L,(-1L)},{7L,0x4D80B7E5L,0x1E35D45CL,7L,0x073E9785L,0x073E9785L,7L,0x1E35D45CL},{(-1L),(-1L),0x784C6000L,0x13A27DD6L,7L,0x784C6000L,7L,0x13A27DD6L},{0x1E35D45CL,0x13A27DD6L,0x1E35D45CL,0x073E9785L,0x13A27DD6L,0x4D80B7E5L,0x4D80B7E5L,0x13A27DD6L},{0x13A27DD6L,0x4D80B7E5L,0x4D80B7E5L,0x13A27DD6L,0x073E9785L,0x1E35D45CL,0x13A27DD6L,0x1E35D45CL},{0x13A27DD6L,7L,0x784C6000L,7L,0x13A27DD6L,0x784C6000L,(-1L),(-1L)},{0x1E35D45CL,7L,0x073E9785L,0x073E9785L,7L,0x1E35D45CL,0x4D80B7E5L,7L},{(-1L),0x4D80B7E5L,0x073E9785L,(-1L),0x073E9785L,0x4D80B7E5L,(-1L),0x1E35D45CL},{7L,0x13A27DD6L,0x784C6000L,(-1L),(-1L),0x784C6000L,0x13A27DD6L,7L}};
        const uint64_t l_231 = 0xD450DD38C2C0AFCBLL;
        int i, j;
        for (g_78 = 0; (g_78 == (-10)); g_78 = safe_sub_func_int64_t_s_s(g_78, 2))
        { /* block id: 49 */
            int64_t l_201 = (-2L);
            int64_t *l_202 = &l_201;
            int32_t l_204 = 0L;
            uint32_t *l_205 = &g_142;
            uint8_t *l_206 = (void*)0;
            uint8_t *l_207 = &g_208;
            uint8_t *l_209[1];
            int16_t l_232 = 0xC871L;
            int i;
            for (i = 0; i < 1; i++)
                l_209[i] = &g_210[7];
            if (((safe_add_func_int32_t_s_s(p_62, ((g_151 > (((((p_60 = (((p_62 | 0UL) , g_151) , ((*l_207) = (safe_mul_func_int8_t_s_s(g_148[7], (((*l_177) = (((safe_mul_func_int8_t_s_s((((((*l_205) = (safe_mod_func_uint8_t_u_u((((l_203 &= (safe_div_func_int32_t_s_s(0xE40056FDL, ((safe_div_func_int16_t_s_s((safe_mod_func_uint8_t_u_u((~((*l_202) = ((((((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(((*p_59) & (-5L)), (*p_61))), 1)) > (*p_59)) && (-4L)) & 0L) < g_151) & l_201))), g_132)), g_37[7])) ^ 0x7C93L)))) & g_117) && l_204), l_204))) , p_59) == &g_117) & 1UL), 1L)) ^ p_58) > g_37[0])) , 0x99L)))))) <= l_211[6][4]) >= l_211[6][4]) && g_142) , 0x32DBL)) < l_204))) , l_204))
            { /* block id: 56 */
                uint32_t l_212 = 0xCB20ABD1L;
                uint32_t l_222 = 4294967295UL;
                ++l_212;
                l_204 = (!(l_211[6][4] < (safe_div_func_uint64_t_u_u((((((safe_sub_func_uint32_t_u_u(((((void*)0 != &g_142) , (0xAAD41626L > (safe_add_func_uint16_t_u_u(l_203, g_210[5])))) < (l_222 < (safe_lshift_func_uint16_t_u_s((((((p_58 >= ((safe_mod_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((((safe_sub_func_uint16_t_u_u(g_148[4], l_231)) & g_37[7]) >= l_204) | g_78), 0L)), p_62)) | 0x199AC2BE0499F85CLL)) , l_232) || g_208) , 0x6F187A65L) >= l_204), 15)))), 1L)) != 0x6C2FE16EL) <= g_37[3]) && p_60) , 0xACB64CFAA4016F25LL), 0x6E5F86D9A3061BA6LL))));
            }
            else
            { /* block id: 59 */
                uint64_t l_233 = 3UL;
                const int32_t *l_236 = &g_78;
                const int32_t **l_238 = &l_236;
                if (g_117)
                    break;
                l_233--;
                (*l_238) = l_236;
            }
        }
    }
    else
    { /* block id: 65 */
        uint32_t l_239[1][8][4] = {{{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L},{0x9F783361L,0x7F1B2592L,0x9F783361L,0x7F1B2592L}}};
        int i, j, k;
lbl_249:
        l_239[0][1][1] = 0xEB803190L;
        for (g_208 = 10; (g_208 >= 4); g_208 = safe_sub_func_uint32_t_u_u(g_208, 6))
        { /* block id: 69 */
            int8_t l_244[1];
            uint64_t l_245 = 18446744073709551615UL;
            int32_t *l_250 = (void*)0;
            int i;
            for (i = 0; i < 1; i++)
                l_244[i] = 0x60L;
            for (p_60 = 13; (p_60 >= 41); p_60++)
            { /* block id: 72 */
                for (g_142 = 0; (g_142 <= 0); g_142 += 1)
                { /* block id: 75 */
                    l_245--;
                    for (p_62 = 0; (p_62 <= 0); p_62 += 1)
                    { /* block id: 79 */
                        uint64_t *l_248 = &g_37[7];
                        return l_248;
                    }
                    if (g_132)
                        goto lbl_249;
                }
                l_250 = (void*)0;
            }
        }
    }
    return l_251;
}


/* ------------------------------------------ */
/* 
 * reads : g_76 g_78 g_37 g_6 g_117 g_148 g_151
 * writes: g_76 g_78 g_132 g_142 g_148 g_151
 */
static uint8_t  func_63(uint32_t  p_64, uint16_t  p_65, uint32_t  p_66, const uint16_t  p_67, int32_t  p_68)
{ /* block id: 11 */
    uint32_t l_74 = 18446744073709551615UL;
    int8_t *l_91 = &g_76;
    int8_t *l_98 = &g_76;
    int32_t l_118 = (-1L);
    int32_t *l_134 = &l_118;
    for (p_65 = 0; (p_65 >= 46); ++p_65)
    { /* block id: 14 */
        int8_t *l_75 = &g_76;
        int32_t *l_77 = &g_78;
        const int8_t *l_90 = (void*)0;
        const int8_t **l_89 = &l_90;
        const uint16_t l_106 = 65528UL;
        uint8_t l_129[5][8] = {{0xF6L,0x66L,0x66L,0xF6L,0x18L,0x5FL,0xF6L,0x5FL},{0xF6L,0UL,0xADL,0UL,0xF6L,0xADL,0UL,0UL},{0x5FL,0UL,0x18L,0x18L,0UL,0x5FL,0x66L,0UL},{0UL,0x66L,0x18L,0UL,0x18L,0x66L,0UL,0x5FL},{0UL,0xF6L,0xADL,0UL,0UL,0xADL,0xF6L,0UL}};
        uint32_t *l_141[6] = {&g_142,&g_142,&g_142,&g_142,&g_142,&g_142};
        uint64_t l_143[6] = {4UL,4UL,4UL,4UL,4UL,4UL};
        int32_t *l_146 = (void*)0;
        int32_t *l_147[4][8];
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 8; j++)
                l_147[i][j] = &g_148[4];
        }
        (*l_77) |= (l_74 <= ((*l_75) |= p_65));
        if (((((safe_rshift_func_uint8_t_u_u((((((*l_77) = (((&p_66 != &p_66) , (safe_rshift_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_div_func_int32_t_s_s(((safe_mul_func_int8_t_s_s((((*l_89) = l_75) == l_91), (safe_rshift_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u(((safe_lshift_func_uint16_t_u_u(0x3935L, 10)) , ((l_98 = &g_76) == l_75)), 10)) > ((safe_rshift_func_uint8_t_u_u((((!(safe_mod_func_uint8_t_u_u(((((((safe_rshift_func_int16_t_s_s((&g_76 != (void*)0), g_76)) & l_74) <= (*l_77)) != 8UL) || p_65) <= 4294967288UL), (*l_77)))) <= g_37[4]) , 0xC7L), (*l_77))) , p_68)), g_6)))) ^ 0L), (*l_77))), p_68)) & p_64), (*l_77)))) == g_6)) < p_68) == l_106) <= (-1L)), 5)) && p_65) && g_6) && g_78))
        { /* block id: 20 */
            int64_t *l_116[7][8][3] = {{{&g_117,&g_117,&g_117},{&g_117,(void*)0,&g_117},{(void*)0,&g_117,&g_117},{&g_117,(void*)0,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117}},{{(void*)0,(void*)0,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117}},{{&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,(void*)0},{&g_117,(void*)0,&g_117}},{{&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117}},{{&g_117,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,(void*)0,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117}},{{&g_117,&g_117,(void*)0},{(void*)0,&g_117,(void*)0},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117},{&g_117,&g_117,&g_117}}};
            uint32_t *l_122[4][9][2] = {{{(void*)0,(void*)0},{&l_74,(void*)0},{(void*)0,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{(void*)0,(void*)0},{&l_74,(void*)0}},{{(void*)0,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{(void*)0,(void*)0},{&l_74,(void*)0},{(void*)0,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{(void*)0,(void*)0},{&l_74,(void*)0},{(void*)0,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74}},{{&l_74,&l_74},{(void*)0,(void*)0},{&l_74,(void*)0},{(void*)0,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{&l_74,&l_74},{(void*)0,(void*)0}}};
            uint32_t **l_121 = &l_122[0][0][1];
            int16_t *l_130 = (void*)0;
            int16_t *l_131 = (void*)0;
            int i, j, k;
            if (((*l_77) = (safe_lshift_func_uint16_t_u_u((g_37[7] == p_66), (safe_sub_func_uint32_t_u_u(g_78, ((safe_add_func_uint16_t_u_u(p_66, (-1L))) > ((safe_add_func_int16_t_s_s((g_132 = ((~(l_118 |= p_64)) || ((((safe_mod_func_uint16_t_u_u((((*l_121) = &p_64) != &p_64), (safe_sub_func_uint16_t_u_u((safe_div_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(0x6A87L, (*l_77))), g_78)), l_129[4][6])))) , 0x1CL) , (*l_77)) <= g_37[7]))), (*l_77))) , p_64))))))))
            { /* block id: 25 */
                return p_66;
            }
            else
            { /* block id: 27 */
                p_68 &= 1L;
            }
        }
        else
        { /* block id: 30 */
            int32_t **l_133[1][1];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                    l_133[i][j] = &l_77;
            }
            l_134 = &g_78;
        }
        (*l_77) = (safe_lshift_func_uint16_t_u_s((((safe_rshift_func_uint16_t_u_u(((g_117 || (g_151 |= ((*l_134) == ((g_142 = (l_143[0] = ((*l_134) , (safe_sub_func_uint64_t_u_u(p_65, p_66))))) && (safe_add_func_int32_t_s_s((((p_68 = (g_148[4] &= 0xE7100029L)) , g_76) < ((safe_add_func_int16_t_s_s(((void*)0 != &l_129[4][6]), (*l_134))) == p_66)), (*l_134))))))) , p_66), 2)) && (*l_77)) || p_66), g_37[3]));
    }
    return g_6;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_37[i], "g_37[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_148[i], "g_148[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_208, "g_208", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_210[i], "g_210[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_264, "g_264", print_hash_value);
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_405, "g_405", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_423[i], "g_423[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_483, "g_483", print_hash_value);
    transparent_crc(g_510, "g_510", print_hash_value);
    transparent_crc(g_567, "g_567", print_hash_value);
    transparent_crc(g_578, "g_578", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_611[i][j], "g_611[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_621, "g_621", print_hash_value);
    transparent_crc(g_622, "g_622", print_hash_value);
    transparent_crc(g_701, "g_701", print_hash_value);
    transparent_crc(g_1141, "g_1141", print_hash_value);
    transparent_crc(g_1152, "g_1152", print_hash_value);
    transparent_crc(g_1348, "g_1348", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1368[i], "g_1368[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1409, "g_1409", print_hash_value);
    transparent_crc(g_1597, "g_1597", print_hash_value);
    transparent_crc(g_1636, "g_1636", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1666[i], "g_1666[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 363
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 147
   depth: 2, occurrence: 45
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1
   depth: 17, occurrence: 3
   depth: 18, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 3
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 27, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 36, occurrence: 1
   depth: 39, occurrence: 1
   depth: 41, occurrence: 2

XXX total number of pointers: 331

XXX times a variable address is taken: 673
XXX times a pointer is dereferenced on RHS: 177
breakdown:
   depth: 1, occurrence: 125
   depth: 2, occurrence: 51
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 217
breakdown:
   depth: 1, occurrence: 186
   depth: 2, occurrence: 27
   depth: 3, occurrence: 4
XXX times a pointer is compared with null: 36
XXX times a pointer is compared with address of another variable: 7
XXX times a pointer is compared with another pointer: 14
XXX times a pointer is qualified to be dereferenced: 3918

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 667
   level: 2, occurrence: 169
   level: 3, occurrence: 21
XXX number of pointers point to pointers: 118
XXX number of pointers point to scalars: 213
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.5
XXX average alias set size: 1.36

XXX times a non-volatile is read: 1291
XXX times a non-volatile is write: 641
XXX times a volatile is read: 52
XXX    times read thru a pointer: 31
XXX times a volatile is write: 24
XXX    times written thru a pointer: 8
XXX times a volatile is available for access: 745
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 155
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 33
   depth: 2, occurrence: 27
   depth: 3, occurrence: 29
   depth: 4, occurrence: 23
   depth: 5, occurrence: 14

XXX percentage a fresh-made variable is used: 17.4
XXX percentage an existing variable is used: 82.6
********************* end of statistics **********************/

