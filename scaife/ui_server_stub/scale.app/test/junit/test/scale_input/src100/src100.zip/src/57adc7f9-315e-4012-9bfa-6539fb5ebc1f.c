/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      853502100
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile unsigned f0 : 24;
   volatile int8_t  f1;
   const volatile uint32_t  f2;
};

union U1 {
   int16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_8 = 2UL;
static const struct S0 *g_42 = (void*)0;
static struct S0 g_48 = {3467,0x24L,0x9AFFF74BL};/* VOLATILE GLOBAL g_48 */
static struct S0 *g_47 = &g_48;
static int64_t g_66 = 0x2517922C1E9780CELL;
static struct S0 ** volatile * volatile g_69 = (void*)0;/* VOLATILE GLOBAL g_69 */
static int32_t g_73 = (-1L);
static int32_t g_81[6] = {0x0AFC6290L,2L,0x0AFC6290L,0x0AFC6290L,2L,0x0AFC6290L};
static uint16_t g_97 = 0x8CD7L;
static int64_t g_99 = 0x1657FB82E29568EBLL;
static int32_t g_101 = 0xA3610563L;
static int32_t *g_105 = &g_73;
static int32_t ** volatile g_104 = &g_105;/* VOLATILE GLOBAL g_104 */
static const struct S0 g_115 = {2677,0x39L,6UL};/* VOLATILE GLOBAL g_115 */
static uint32_t g_119[4][9] = {{4294967295UL,1UL,4294967295UL,4294967295UL,1UL,4294967295UL,4294967295UL,1UL,4294967295UL},{1UL,4294967295UL,1UL,1UL,4294967295UL,1UL,1UL,4294967295UL,1UL},{4294967295UL,1UL,4294967295UL,4294967295UL,1UL,4294967295UL,4294967295UL,1UL,4294967295UL},{1UL,4294967295UL,1UL,1UL,4294967295UL,1UL,1UL,4294967295UL,1UL}};
static union U1 g_122 = {0L};
static int32_t * volatile g_123 = (void*)0;/* VOLATILE GLOBAL g_123 */
static int32_t * volatile g_124 = &g_101;/* VOLATILE GLOBAL g_124 */
static uint16_t g_148 = 3UL;
static volatile uint32_t g_170 = 4294967291UL;/* VOLATILE GLOBAL g_170 */
static int32_t * volatile g_188 = &g_101;/* VOLATILE GLOBAL g_188 */
static uint64_t g_214 = 0xDE78DB23535E1361LL;
static uint32_t g_217 = 0xA238C1CBL;
static int8_t g_219 = (-1L);
static uint8_t g_232[10] = {0x03L,253UL,0x03L,0x03L,0x03L,248UL,248UL,0x03L,248UL,248UL};
static int16_t * const  volatile g_252 = &g_122.f0;/* VOLATILE GLOBAL g_252 */
static volatile int64_t g_257 = 0x1F13ED7A34FC8B02LL;/* VOLATILE GLOBAL g_257 */
static volatile int64_t *g_256 = &g_257;
static volatile int64_t ** volatile g_255 = &g_256;/* VOLATILE GLOBAL g_255 */
static const int32_t g_259[10][9][2] = {{{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)}},{{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L}},{{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L}},{{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L}},{{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)}},{{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)}},{{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L}},{{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L}},{{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L}},{{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)},{0xCC197FE0L,0x7204BD95L},{1L,1L},{1L,0x7204BD95L},{0xCC197FE0L,(-1L)},{0x7204BD95L,(-1L)}}};
static int32_t *g_284 = &g_101;
static int8_t g_308 = 0x6CL;
static int64_t g_345[3][4] = {{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L}};
static uint64_t g_347[5] = {0x96347A8C65C01DDELL,0x96347A8C65C01DDELL,0x96347A8C65C01DDELL,0x96347A8C65C01DDELL,0x96347A8C65C01DDELL};
static uint16_t g_354[3] = {65529UL,65529UL,65529UL};
static uint64_t g_406 = 18446744073709551615UL;
static volatile uint32_t g_409[4][7][9] = {{{0xACD6FC0DL,0xAC200E61L,0UL,0x81537DBFL,0x71E52DDFL,18446744073709551610UL,0xF21D5573L,0xF21D5573L,18446744073709551610UL},{2UL,0UL,1UL,0UL,2UL,18446744073709551615UL,0x78F8003AL,1UL,1UL},{1UL,0xFB93EAB8L,0x730888E4L,18446744073709551607UL,0x47376F4DL,1UL,0x71E52DDFL,18446744073709551609UL,0x89D7D271L},{0x64E77AF3L,0xB0B04B00L,6UL,0x017CB9F2L,1UL,18446744073709551615UL,0x510A37C3L,1UL,0xA7518A81L},{0x81537DBFL,0xD92B2E51L,0x81537DBFL,1UL,0UL,18446744073709551610UL,0xD92B2E51L,0x593DA989L,9UL},{18446744073709551609UL,0x0E79639FL,0x78F8003AL,0UL,18446744073709551610UL,0xD3F37361L,0xAD79A0A0L,0xF80EC286L,0x60217982L},{18446744073709551612UL,0xF21D5573L,0x89D7D271L,1UL,18446744073709551611UL,18446744073709551611UL,1UL,0x89D7D271L,0xF21D5573L}},{{0UL,18446744073709551610UL,0x8DBBC1B4L,0x017CB9F2L,0xC174908FL,0x0E79639FL,18446744073709551610UL,1UL,0xEE461B69L},{0x2C931901L,18446744073709551611UL,0xF21D5573L,18446744073709551607UL,0xAC200E61L,0xEA31AFB0L,0x35818E4EL,1UL,18446744073709551607UL},{0UL,18446744073709551610UL,0x83E0AA7AL,0UL,0xAD79A0A0L,0UL,0xB3478E54L,1UL,6UL},{0x593DA989L,0xF21D5573L,0xAC200E61L,0x81537DBFL,0xFB93EAB8L,0UL,0UL,9UL,18446744073709551610UL},{0xF50A1A2DL,0x0E79639FL,0xEE461B69L,1UL,2UL,0x9CD38E18L,6UL,0x600A6180L,6UL},{1UL,0xD92B2E51L,0x5379CB44L,0x5379CB44L,0xD92B2E51L,1UL,0xFB93EAB8L,0x730888E4L,18446744073709551607UL},{0x46D1E40FL,0xB0B04B00L,1UL,0x600A6180L,0UL,0xE5CBDF15L,0x510A37C3L,0UL,0xEE461B69L}},{{0UL,0xFB93EAB8L,0x81537DBFL,0xAC200E61L,0xF21D5573L,0x593DA989L,0xFB93EAB8L,0x593DA989L,0xF21D5573L},{0x83E0AA7AL,0UL,0xAD79A0A0L,0UL,0xB3478E54L,1UL,6UL,0x0E79639FL,0x60217982L},{0xEA31AFB0L,0xAC200E61L,18446744073709551607UL,0xF21D5573L,18446744073709551611UL,0x2C931901L,0UL,18446744073709551607UL,9UL},{0UL,1UL,0xA7518A81L,18446744073709551607UL,0xB3478E54L,0x0E79639FL,0xB3478E54L,18446744073709551607UL,0xA7518A81L},{18446744073709551611UL,18446744073709551611UL,1UL,0x89D7D271L,0xF21D5573L,18446744073709551612UL,0x35818E4EL,0xAC200E61L,0x89D7D271L},{0xC18769B8L,18446744073709551615UL,0x83E0AA7AL,0UL,0xC18769B8L,1UL,0xF50A1A2DL,0x017CB9F2L,0UL},{0x730888E4L,0x593DA989L,0xACD6FC0DL,18446744073709551607UL,18446744073709551611UL,18446744073709551607UL,0xACD6FC0DL,0x593DA989L,0x730888E4L}},{{1UL,1UL,18446744073709551610UL,0x19647536L,0UL,0UL,0x83E0AA7AL,18446744073709551615UL,0xC18769B8L},{0xACD6FC0DL,0x2C931901L,18446744073709551613UL,0x71E52DDFL,0xEA31AFB0L,0xACD6FC0DL,18446744073709551611UL,0xD92B2E51L,0xD92B2E51L},{1UL,0x0E79639FL,0x83E0AA7AL,3UL,0x83E0AA7AL,0x0E79639FL,1UL,0xACF7F68FL,0x97E76A8AL},{0x730888E4L,18446744073709551612UL,18446744073709551607UL,0x593DA989L,0UL,0x89D7D271L,18446744073709551612UL,18446744073709551609UL,0xACD6FC0DL},{0x8DBBC1B4L,0x19647536L,0UL,1UL,0x46D1E40FL,0x600A6180L,0x60217982L,0xACF7F68FL,0xEE461B69L},{1UL,0x81537DBFL,0xD92B2E51L,0x81537DBFL,1UL,0UL,18446744073709551610UL,0xD92B2E51L,0x593DA989L},{0xC18769B8L,0xE2D05048L,0xC174908FL,18446744073709551610UL,0xF50A1A2DL,0xD3F37361L,0x46D1E40FL,18446744073709551615UL,0x35685CE0L}}};
static volatile int64_t g_413 = 3L;/* VOLATILE GLOBAL g_413 */
static uint32_t g_414[9][2] = {{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL}};
static volatile struct S0 g_447 = {3104,0xFBL,2UL};/* VOLATILE GLOBAL g_447 */
static volatile uint64_t g_454[8] = {0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL,0xA4E525C4B519BC06LL};
static volatile uint16_t g_500 = 0x187FL;/* VOLATILE GLOBAL g_500 */
static volatile uint16_t *g_499 = &g_500;
static volatile uint16_t ** volatile g_498 = &g_499;/* VOLATILE GLOBAL g_498 */
static uint16_t g_506 = 0UL;
static union U1 ** volatile g_507 = (void*)0;/* VOLATILE GLOBAL g_507 */
static volatile struct S0 g_524 = {93,9L,4294967295UL};/* VOLATILE GLOBAL g_524 */
static uint32_t g_560 = 0x793DC912L;
static int8_t g_563 = (-4L);
static volatile struct S0 g_575 = {3272,0x09L,0xD81C3ACCL};/* VOLATILE GLOBAL g_575 */
static int32_t ** volatile g_582 = &g_105;/* VOLATILE GLOBAL g_582 */
static uint64_t g_599[1] = {0x7D7F46C31DB3D7B3LL};
static uint32_t *g_632 = &g_119[3][7];
static uint32_t **g_631 = &g_632;
static uint64_t **g_713 = (void*)0;
static struct S0 **g_733 = &g_47;
static struct S0 ***g_732[9] = {&g_733,&g_733,&g_733,&g_733,&g_733,&g_733,&g_733,&g_733,&g_733};
static const volatile struct S0 g_756 = {2861,0L,0xDDBEB870L};/* VOLATILE GLOBAL g_756 */
static uint8_t *g_765 = &g_232[6];
static uint8_t * const  volatile * const  volatile g_764 = &g_765;/* VOLATILE GLOBAL g_764 */
static int16_t g_773 = (-1L);
static int64_t g_778 = 0x293242C430ABA833LL;
static volatile uint16_t g_814 = 65528UL;/* VOLATILE GLOBAL g_814 */
static struct S0 g_835[8][1] = {{{2570,0x73L,4294967295UL}},{{2713,0x90L,4294967295UL}},{{2713,0x90L,4294967295UL}},{{2570,0x73L,4294967295UL}},{{2713,0x90L,4294967295UL}},{{2713,0x90L,4294967295UL}},{{2570,0x73L,4294967295UL}},{{2713,0x90L,4294967295UL}}};
static int16_t g_848 = 4L;
static uint8_t **g_864 = &g_765;
static uint8_t ***g_863[2][7] = {{&g_864,&g_864,&g_864,&g_864,&g_864,&g_864,&g_864},{&g_864,&g_864,&g_864,&g_864,&g_864,&g_864,&g_864}};
static const volatile struct S0 g_925[10] = {{2499,0x6EL,0x2E966999L},{322,-6L,0UL},{322,-6L,0UL},{2499,0x6EL,0x2E966999L},{3453,3L,0x5C50F2E3L},{2499,0x6EL,0x2E966999L},{322,-6L,0UL},{322,-6L,0UL},{2499,0x6EL,0x2E966999L},{3453,3L,0x5C50F2E3L}};
static int8_t g_974 = 0x64L;
static const uint32_t g_977 = 0x6EDEB657L;
static int32_t ** volatile g_1022 = &g_105;/* VOLATILE GLOBAL g_1022 */
static volatile struct S0 g_1045 = {3793,0x73L,0x2E64A03BL};/* VOLATILE GLOBAL g_1045 */
static volatile int64_t g_1070 = 0L;/* VOLATILE GLOBAL g_1070 */
static volatile int16_t g_1071 = 0x33ABL;/* VOLATILE GLOBAL g_1071 */
static int8_t g_1072 = 0x1AL;
static volatile int16_t g_1073 = 0x2694L;/* VOLATILE GLOBAL g_1073 */
static volatile int32_t g_1074 = 1L;/* VOLATILE GLOBAL g_1074 */
static volatile int32_t g_1075[7] = {1L,1L,1L,1L,1L,1L,1L};
static int16_t *g_1107 = (void*)0;
static int16_t **g_1106 = &g_1107;
static struct S0 g_1188 = {2795,0L,4294967290UL};/* VOLATILE GLOBAL g_1188 */
static uint32_t * volatile * volatile * volatile g_1195 = (void*)0;/* VOLATILE GLOBAL g_1195 */
static volatile int8_t *g_1241 = (void*)0;
static volatile int8_t * volatile *g_1240 = &g_1241;
static volatile int8_t * volatile ** volatile g_1242[8] = {&g_1240,(void*)0,&g_1240,(void*)0,&g_1240,(void*)0,&g_1240,(void*)0};
static volatile int8_t * volatile ** volatile g_1243 = (void*)0;/* VOLATILE GLOBAL g_1243 */
static int32_t ** volatile g_1259 = &g_284;/* VOLATILE GLOBAL g_1259 */
static int32_t ** const  volatile g_1260 = &g_105;/* VOLATILE GLOBAL g_1260 */
static int64_t * const *g_1267 = (void*)0;
static struct S0 g_1294 = {2223,0x2FL,0xF8F6CB36L};/* VOLATILE GLOBAL g_1294 */
static struct S0 g_1295 = {528,1L,4294967291UL};/* VOLATILE GLOBAL g_1295 */
static struct S0 g_1297 = {138,0x36L,0UL};/* VOLATILE GLOBAL g_1297 */
static uint8_t g_1301[8] = {0x5BL,0x5BL,0x5BL,0x5BL,0x5BL,0x5BL,0x5BL,0x5BL};
static struct S0 g_1383 = {851,0x5BL,4294967294UL};/* VOLATILE GLOBAL g_1383 */
static uint8_t ****g_1392[2][4] = {{&g_863[1][6],&g_863[1][6],&g_863[1][6],&g_863[1][6]},{&g_863[1][6],&g_863[1][6],&g_863[1][6],&g_863[1][6]}};
static volatile uint64_t g_1452 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1452 */
static int32_t ** const  volatile g_1497 = &g_284;/* VOLATILE GLOBAL g_1497 */
static struct S0 g_1527 = {3080,0xBCL,0xB983F454L};/* VOLATILE GLOBAL g_1527 */
static volatile struct S0 g_1555 = {1231,0x10L,0xB0FE2E07L};/* VOLATILE GLOBAL g_1555 */
static uint64_t g_1564 = 0xF748855530D28796LL;
static uint64_t g_1567 = 2UL;
static uint64_t g_1568[4][4] = {{2UL,1UL,2UL,2UL},{1UL,1UL,1UL,1UL},{1UL,2UL,2UL,1UL},{2UL,1UL,2UL,1UL}};
static uint64_t g_1569 = 1UL;
static uint64_t * const g_1566[2][3] = {{&g_1569,&g_1569,&g_1567},{&g_1569,&g_1569,&g_1567}};
static uint64_t * const *g_1565[2] = {&g_1566[1][0],&g_1566[1][0]};
static volatile int8_t g_1612 = 0x4FL;/* VOLATILE GLOBAL g_1612 */
static union U1 *g_1626 = &g_122;
static union U1 ** volatile g_1625 = &g_1626;/* VOLATILE GLOBAL g_1625 */
static uint8_t ****g_1653 = &g_863[1][2];
static struct S0 g_1663 = {2430,0x58L,4294967288UL};/* VOLATILE GLOBAL g_1663 */
static int32_t ** volatile g_1680[2] = {&g_105,&g_105};
static int32_t ** volatile g_1681 = &g_105;/* VOLATILE GLOBAL g_1681 */
static volatile struct S0 g_1724 = {883,0xEEL,4294967294UL};/* VOLATILE GLOBAL g_1724 */
static int32_t ** volatile g_1815 = &g_105;/* VOLATILE GLOBAL g_1815 */
static int32_t ** volatile g_1818 = &g_105;/* VOLATILE GLOBAL g_1818 */
static uint16_t *g_1823[5] = {&g_506,&g_506,&g_506,&g_506,&g_506};
static uint16_t **g_1822 = &g_1823[1];
static const int64_t ***g_1843 = (void*)0;
static const int64_t ****g_1842 = &g_1843;
static struct S0 g_1847 = {24,1L,0xB91B9DBDL};/* VOLATILE GLOBAL g_1847 */
static struct S0 g_1914 = {2709,0x9AL,4294967290UL};/* VOLATILE GLOBAL g_1914 */
static struct S0 g_1915 = {470,0x02L,1UL};/* VOLATILE GLOBAL g_1915 */
static struct S0 g_1916[5] = {{2926,0xF9L,0UL},{2926,0xF9L,0UL},{2926,0xF9L,0UL},{2926,0xF9L,0UL},{2926,0xF9L,0UL}};
static struct S0 g_1917 = {100,0xD9L,4294967287UL};/* VOLATILE GLOBAL g_1917 */
static struct S0 g_1918 = {3935,0x98L,0xCC2903CDL};/* VOLATILE GLOBAL g_1918 */
static struct S0 g_1919 = {2350,1L,4294967289UL};/* VOLATILE GLOBAL g_1919 */
static struct S0 g_1920 = {985,0x1BL,2UL};/* VOLATILE GLOBAL g_1920 */
static struct S0 g_1921[4][1] = {{{2047,0xE2L,0xD8803802L}},{{2047,0xE2L,0xD8803802L}},{{2047,0xE2L,0xD8803802L}},{{2047,0xE2L,0xD8803802L}}};
static struct S0 g_1922[8] = {{3301,0x4FL,4294967295UL},{4069,1L,0x65B0354EL},{3301,0x4FL,4294967295UL},{4069,1L,0x65B0354EL},{3301,0x4FL,4294967295UL},{4069,1L,0x65B0354EL},{3301,0x4FL,4294967295UL},{4069,1L,0x65B0354EL}};
static struct S0 g_1923[6] = {{1161,1L,0x579379E4L},{1161,1L,0x579379E4L},{1161,1L,0x579379E4L},{1161,1L,0x579379E4L},{1161,1L,0x579379E4L},{1161,1L,0x579379E4L}};
static struct S0 g_1924 = {1258,0x3DL,0x540E7961L};/* VOLATILE GLOBAL g_1924 */
static struct S0 g_1925[2] = {{1159,1L,0UL},{1159,1L,0UL}};
static struct S0 g_1926 = {2719,0xE8L,0xB8318E5EL};/* VOLATILE GLOBAL g_1926 */
static struct S0 g_1927 = {581,-1L,0x37105EC1L};/* VOLATILE GLOBAL g_1927 */
static struct S0 g_1928 = {1155,0x5DL,0xE2065EC7L};/* VOLATILE GLOBAL g_1928 */
static struct S0 g_1929 = {3332,0x6DL,0xE49C4FA0L};/* VOLATILE GLOBAL g_1929 */
static struct S0 g_1930 = {1874,7L,0xEC59B54EL};/* VOLATILE GLOBAL g_1930 */
static struct S0 g_1931 = {1480,7L,4294967293UL};/* VOLATILE GLOBAL g_1931 */
static const volatile uint8_t g_1966 = 0UL;/* VOLATILE GLOBAL g_1966 */
static const volatile uint8_t *g_1965[10][7][3] = {{{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966}},{{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0}},{{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966}},{{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0}},{{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966}},{{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0}},{{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966}},{{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0}},{{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966}},{{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0},{&g_1966,&g_1966,&g_1966},{(void*)0,(void*)0,(void*)0}}};
static const volatile uint8_t * volatile * volatile g_1964 = &g_1965[1][2][2];/* VOLATILE GLOBAL g_1964 */
static const volatile uint8_t * volatile * volatile *g_1963 = &g_1964;
static const volatile uint8_t * volatile * volatile **g_1962[7] = {&g_1963,&g_1963,&g_1963,&g_1963,&g_1963,&g_1963,&g_1963};
static const volatile uint8_t * volatile * volatile ** volatile *g_1961 = &g_1962[0];
static const volatile uint8_t * volatile * volatile ** volatile ** volatile g_1960 = &g_1961;/* VOLATILE GLOBAL g_1960 */
static struct S0 g_2063 = {655,0x36L,1UL};/* VOLATILE GLOBAL g_2063 */
static struct S0 *g_2062 = &g_2063;
static struct S0 g_2070[8] = {{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL},{3863,0x36L,4294967295UL}};
static volatile union U1 *g_2075 = (void*)0;
static volatile union U1 ** volatile g_2074[6][6] = {{&g_2075,(void*)0,&g_2075,(void*)0,&g_2075,(void*)0},{&g_2075,&g_2075,&g_2075,(void*)0,&g_2075,&g_2075},{&g_2075,&g_2075,&g_2075,&g_2075,(void*)0,(void*)0},{&g_2075,&g_2075,&g_2075,&g_2075,&g_2075,(void*)0},{&g_2075,&g_2075,(void*)0,&g_2075,&g_2075,(void*)0},{&g_2075,(void*)0,&g_2075,(void*)0,&g_2075,(void*)0}};
static volatile union U1 ** volatile *g_2073 = &g_2074[1][3];
static int64_t g_2091 = 0x9723EAB7515B3F41LL;
static int64_t g_2171 = 1L;
static struct S0 ** volatile g_2184 = (void*)0;/* VOLATILE GLOBAL g_2184 */
static struct S0 ** const  volatile g_2185 = &g_2062;/* VOLATILE GLOBAL g_2185 */
static int32_t ** volatile g_2203 = &g_284;/* VOLATILE GLOBAL g_2203 */
static const struct S0 g_2233 = {3234,0x40L,0xF55CCA2CL};/* VOLATILE GLOBAL g_2233 */
static volatile uint8_t g_2237 = 5UL;/* VOLATILE GLOBAL g_2237 */
static int8_t g_2248[4][10][1] = {{{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L}},{{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L}},{{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L}},{{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L},{0x5CL},{0xF1L}}};
static uint16_t g_2256 = 0x765DL;
static int32_t ** volatile g_2268 = &g_105;/* VOLATILE GLOBAL g_2268 */
static const volatile int16_t g_2286 = 2L;/* VOLATILE GLOBAL g_2286 */
static const volatile uint64_t * volatile * volatile * volatile g_2313 = (void*)0;/* VOLATILE GLOBAL g_2313 */
static const volatile uint64_t * volatile * volatile * volatile *g_2312 = &g_2313;
static uint16_t g_2338 = 65535UL;
static volatile int16_t g_2339 = (-10L);/* VOLATILE GLOBAL g_2339 */
static const uint8_t *g_2343 = &g_232[5];
static const uint8_t **g_2342[5] = {&g_2343,&g_2343,&g_2343,&g_2343,&g_2343};
static const uint8_t ***g_2341 = &g_2342[1];
static int32_t ** volatile g_2347 = &g_105;/* VOLATILE GLOBAL g_2347 */
static int32_t ** volatile g_2438 = &g_105;/* VOLATILE GLOBAL g_2438 */
static const int64_t g_2466 = 0x4E8C28246A680227LL;
static const int64_t * const g_2470 = (void*)0;
static const int64_t * const *g_2469 = &g_2470;
static const int64_t * const **g_2468[3][1][2] = {{{&g_2469,&g_2469}},{{&g_2469,&g_2469}},{{&g_2469,&g_2469}}};
static const int64_t * const ***g_2467 = &g_2468[2][0][0];
static struct S0 g_2476 = {3670,5L,0UL};/* VOLATILE GLOBAL g_2476 */
static struct S0 g_2479 = {1272,0L,0xD9698A88L};/* VOLATILE GLOBAL g_2479 */
static volatile uint16_t g_2480 = 65535UL;/* VOLATILE GLOBAL g_2480 */
static int32_t ** volatile g_2481[8][3][10] = {{{&g_105,&g_284,&g_284,&g_284,&g_105,&g_284,&g_105,(void*)0,&g_105,&g_105},{(void*)0,&g_105,(void*)0,&g_105,&g_284,&g_105,&g_105,&g_284,&g_105,(void*)0},{&g_284,&g_284,&g_284,&g_105,&g_105,&g_105,(void*)0,&g_284,(void*)0,&g_284}},{{(void*)0,&g_105,(void*)0,&g_105,&g_105,&g_105,(void*)0,&g_284,&g_105,(void*)0},{(void*)0,&g_284,&g_105,&g_284,&g_284,&g_105,&g_105,&g_284,&g_105,&g_105},{&g_105,&g_284,&g_284,&g_105,&g_105,&g_284,&g_105,&g_284,&g_105,&g_105}},{{&g_105,&g_105,(void*)0,&g_284,&g_284,&g_105,(void*)0,&g_105,&g_105,(void*)0},{&g_284,(void*)0,&g_105,&g_284,(void*)0,&g_105,&g_284,&g_105,&g_105,&g_105},{&g_105,&g_284,&g_284,(void*)0,&g_284,&g_105,&g_284,(void*)0,&g_284,&g_105}},{{&g_284,&g_105,(void*)0,&g_105,&g_105,&g_284,(void*)0,&g_284,&g_105,&g_105},{&g_284,&g_105,&g_284,(void*)0,&g_284,&g_284,&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_284,&g_105,&g_284,(void*)0,&g_284,&g_284,&g_105,&g_284,&g_105}},{{&g_105,&g_105,&g_284,&g_105,&g_105,&g_284,&g_105,&g_284,&g_284,&g_105},{(void*)0,&g_105,(void*)0,&g_105,&g_284,&g_284,&g_105,(void*)0,&g_284,&g_105},{&g_284,&g_105,&g_284,&g_105,&g_105,&g_284,&g_284,&g_105,&g_105,&g_284}},{{&g_105,&g_105,&g_105,(void*)0,&g_105,&g_105,&g_105,&g_105,&g_284,&g_284},{&g_105,&g_105,(void*)0,&g_105,&g_105,&g_105,&g_284,&g_284,(void*)0,&g_105},{&g_284,(void*)0,&g_284,&g_105,&g_105,&g_105,&g_284,&g_284,&g_105,&g_105}},{{(void*)0,&g_105,&g_105,(void*)0,&g_105,&g_105,&g_284,&g_284,&g_284,&g_284},{&g_284,&g_105,(void*)0,(void*)0,&g_284,&g_105,&g_105,&g_284,&g_284,&g_105},{(void*)0,(void*)0,&g_105,(void*)0,&g_284,&g_284,(void*)0,&g_105,&g_105,&g_105}},{{&g_105,&g_105,(void*)0,&g_105,&g_284,&g_284,&g_105,&g_105,(void*)0,&g_105},{&g_105,&g_105,&g_284,&g_284,&g_105,&g_105,&g_105,(void*)0,&g_284,&g_284},{&g_105,(void*)0,&g_105,(void*)0,&g_105,&g_105,&g_284,&g_284,&g_284,&g_105}}};
static const volatile struct S0 g_2524 = {490,0L,0x1A8FB665L};/* VOLATILE GLOBAL g_2524 */
static uint32_t g_2529 = 0xBA1AC6A4L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static struct S0 * const  func_2(uint8_t  p_3, uint8_t  p_4, uint32_t  p_5);
static uint8_t  func_6(uint16_t  p_7);
static int32_t  func_9(union U1  p_10, struct S0 * const  p_11, int32_t  p_12);
static const union U1  func_14(uint8_t  p_15, struct S0 * p_16, int32_t  p_17, struct S0 * p_18);
static uint64_t  func_21(int32_t  p_22);
static int16_t  func_25(uint8_t  p_26, const struct S0 * const  p_27, int64_t  p_28, int8_t  p_29);
static uint64_t  func_32(union U1  p_33, struct S0 * p_34, uint32_t  p_35);
static uint8_t  func_40(const struct S0 * p_41);
static int32_t  func_44(uint32_t  p_45, int16_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_42 g_47 g_48.f1 g_66 g_69 g_73 g_81 g_48 g_97 g_104 g_105 g_101 g_414 g_732 g_563 g_119 g_232 g_631 g_632 g_308 g_345 g_347 g_756 g_219 g_259 g_252 g_284 g_122.f0 g_170 g_764 g_506 g_778 g_814 g_99 g_835 g_848 g_499 g_500 g_863 g_256 g_257 g_733 g_122 g_498 g_255 g_582 g_115.f1 g_864 g_765 g_124 g_925 g_773 g_406 g_974 g_977 g_217 g_148 g_1022 g_1045 g_507 g_188 g_214 g_1188 g_1195 g_354 g_599 g_1240 g_1259 g_1260 g_1267 g_1294 g_1295 g_1301 g_1497 g_1527 g_1555 g_713 g_1625 g_1663 g_1626 g_1681 g_1724 g_1653 g_1815 g_1818 g_1822 g_1842 g_1847 g_1823 g_1568 g_1960 g_447.f2 g_1564 g_454 g_2070 g_2073 g_2091 g_1915 g_2185
 * writes: g_47 g_66 g_73 g_81 g_97 g_99 g_105 g_119 g_563 g_732 g_308 g_347 g_560 g_599 g_219 g_122.f0 g_101 g_506 g_345 g_773 g_778 g_814 g_354 g_848 g_217 g_406 g_232 g_148 g_214 g_632 g_284 g_1106 g_1072 g_974 g_1267 g_1301 g_1565 g_1626 g_1392 g_1653 g_631 g_8 g_713 g_1564 g_1822 g_1567 g_1680 g_2062 g_2171
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t *l_2170 = &g_2171;
    int32_t l_2172 = (-1L);
    union U1 l_2173 = {0x04B3L};
    struct S0 **l_2183[5];
    int32_t l_2186 = 0xD30B201FL;
    int32_t l_2187[2][6][4] = {{{1L,0x9B79C48FL,0xBC6AB8C3L,0x9B79C48FL},{0x9B79C48FL,(-10L),0xBC6AB8C3L,0xBC6AB8C3L},{1L,1L,0x9B79C48FL,0xBC6AB8C3L},{0x830622F0L,(-10L),0x830622F0L,0x9B79C48FL},{0x830622F0L,0x9B79C48FL,0x9B79C48FL,0x830622F0L},{1L,0x9B79C48FL,0xBC6AB8C3L,0x9B79C48FL}},{{0x9B79C48FL,(-10L),0xBC6AB8C3L,0xBC6AB8C3L},{1L,1L,0x9B79C48FL,0xBC6AB8C3L},{0x830622F0L,(-10L),0x830622F0L,0x9B79C48FL},{0x830622F0L,0x9B79C48FL,0x9B79C48FL,0x830622F0L},{1L,0x9B79C48FL,0xBC6AB8C3L,0x9B79C48FL},{0x9B79C48FL,(-10L),0xBC6AB8C3L,0xBC6AB8C3L}}};
    uint64_t *l_2188 = &g_214;
    uint16_t *l_2191[1];
    int32_t *l_2197 = &g_73;
    uint32_t l_2198 = 4294967291UL;
    int8_t *l_2199 = &g_219;
    struct S0 **l_2314[7][8] = {{&g_2062,&g_2062,&g_2062,&g_2062,&g_2062,&g_2062,&g_2062,&g_2062},{&g_2062,(void*)0,&g_47,(void*)0,&g_2062,&g_47,(void*)0,(void*)0},{&g_2062,(void*)0,&g_2062,&g_2062,(void*)0,&g_2062,&g_2062,(void*)0},{(void*)0,&g_2062,&g_2062,(void*)0,&g_2062,&g_2062,(void*)0,&g_2062},{(void*)0,&g_2062,&g_47,(void*)0,(void*)0,&g_47,&g_2062,(void*)0},{&g_2062,(void*)0,&g_2062,&g_2062,(void*)0,&g_2062,&g_2062,(void*)0},{(void*)0,&g_2062,&g_2062,(void*)0,&g_2062,&g_2062,(void*)0,&g_2062}};
    const uint8_t l_2366 = 0xFEL;
    const uint8_t l_2380 = 0x05L;
    uint32_t l_2472 = 8UL;
    const int16_t l_2474 = 3L;
    struct S0 *l_2475 = &g_2476;
    uint8_t l_2477 = 0xD1L;
    struct S0 *l_2478 = &g_2479;
    int8_t l_2491 = 0xECL;
    uint8_t ** const ****l_2506 = (void*)0;
    int8_t l_2517 = 0xC4L;
    int8_t l_2522 = 1L;
    uint8_t l_2523[2];
    uint32_t l_2525 = 0UL;
    uint64_t l_2526 = 0x02C5DCA2D12A1F4DLL;
    uint64_t *l_2527 = &g_347[4];
    int16_t *l_2528 = &g_773;
    int32_t *l_2530 = &g_101;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_2183[i] = &g_2062;
    for (i = 0; i < 1; i++)
        l_2191[i] = &g_354[0];
    for (i = 0; i < 2; i++)
        l_2523[i] = 246UL;
    (*g_2185) = func_2(func_6(g_8), (safe_sub_func_int64_t_s_s((((*l_2170) = g_2091) < 1L), (((g_414[5][1] , l_2172) <= ((l_2173 , l_2172) < ((safe_sub_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_u((&g_1961 == &g_1961), 7)) ^ l_2172), g_2091)) , l_2173.f0))) > 255UL))), l_2173.f0);
    (*g_733) = (void*)0;
    return (*l_2530);
}


/* ------------------------------------------ */
/* 
 * reads : g_974
 * writes: g_974
 */
static struct S0 * const  func_2(uint8_t  p_3, uint8_t  p_4, uint32_t  p_5)
{ /* block id: 1017 */
    uint32_t l_2178 = 1UL;
    struct S0 * const l_2182 = &g_1928;
    l_2178 = p_4;
    for (g_974 = 0; (g_974 > 7); ++g_974)
    { /* block id: 1021 */
        struct S0 * const l_2181 = (void*)0;
        return l_2181;
    }
    return l_2182;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_42 g_47 g_48.f1 g_66 g_69 g_73 g_81 g_48 g_97 g_104 g_99 g_105 g_101 g_414 g_563 g_732 g_119 g_232 g_631 g_632 g_308 g_345 g_347 g_756 g_219 g_259 g_252 g_284 g_122.f0 g_170 g_764 g_506 g_778 g_814 g_835 g_848 g_499 g_500 g_863 g_256 g_257 g_733 g_122 g_498 g_255 g_582 g_115.f1 g_864 g_765 g_124 g_925 g_773 g_406 g_974 g_977 g_217 g_148 g_1022 g_214 g_1045 g_507 g_188 g_1072 g_560 g_1188 g_1195 g_354 g_599 g_1240 g_1259 g_1260 g_1267 g_1294 g_1295 g_1301 g_1497 g_1527 g_1555 g_713 g_1625 g_1663 g_1626 g_1681 g_1724 g_1653 g_1815 g_1818 g_1822 g_1842 g_1847 g_1823 g_1568 g_1960 g_447.f2 g_1564 g_454 g_2070 g_2073 g_2091 g_1915
 * writes: g_47 g_66 g_73 g_81 g_97 g_99 g_105 g_119 g_563 g_732 g_308 g_347 g_560 g_599 g_219 g_122.f0 g_101 g_506 g_345 g_773 g_778 g_814 g_354 g_848 g_217 g_406 g_232 g_148 g_214 g_632 g_284 g_1106 g_1072 g_974 g_1267 g_1301 g_1565 g_1626 g_1392 g_1653 g_631 g_8 g_713 g_1564 g_1822 g_1567 g_1680 g_2062
 */
static uint8_t  func_6(uint16_t  p_7)
{ /* block id: 1 */
    union U1 l_726 = {0x008CL};
    struct S0 *l_727[7];
    int8_t *l_1834 = &g_974;
    int64_t * const ***l_1849 = (void*)0;
    int64_t * const *** const *l_1848 = &l_1849;
    int32_t *l_1879 = &g_73;
    int32_t **l_1893[6][1] = {{&g_284},{&g_105},{&g_284},{&g_105},{&g_284},{&g_105}};
    int32_t ***l_1892 = &l_1893[2][0];
    const uint64_t l_2009[10][9] = {{18446744073709551608UL,0x141492C3FBCD02EBLL,0x9FC064AD601BE6BALL,0x141492C3FBCD02EBLL,18446744073709551608UL,0UL,0x141492C3FBCD02EBLL,18446744073709551615UL,0xC77016B2C301BD92LL},{0x141492C3FBCD02EBLL,0xD269B1FC3106314CLL,0x9FC064AD601BE6BALL,18446744073709551615UL,0xD269B1FC3106314CLL,0xC77016B2C301BD92LL,0xD269B1FC3106314CLL,18446744073709551615UL,0x9FC064AD601BE6BALL},{18446744073709551608UL,18446744073709551608UL,0xC77016B2C301BD92LL,18446744073709551615UL,0x141492C3FBCD02EBLL,0UL,18446744073709551608UL,0x141492C3FBCD02EBLL,0x9FC064AD601BE6BALL},{0xCA5786B9FDF687E4LL,0xD269B1FC3106314CLL,18446744073709551615UL,0x141492C3FBCD02EBLL,0x141492C3FBCD02EBLL,18446744073709551615UL,0xD269B1FC3106314CLL,0xCA5786B9FDF687E4LL,0xC77016B2C301BD92LL},{0xCA5786B9FDF687E4LL,0x141492C3FBCD02EBLL,0xC77016B2C301BD92LL,0xCA5786B9FDF687E4LL,0xD269B1FC3106314CLL,18446744073709551615UL,0x141492C3FBCD02EBLL,0x141492C3FBCD02EBLL,18446744073709551615UL},{18446744073709551608UL,0x141492C3FBCD02EBLL,0x9FC064AD601BE6BALL,0x141492C3FBCD02EBLL,18446744073709551608UL,0UL,0x141492C3FBCD02EBLL,18446744073709551615UL,0xC77016B2C301BD92LL},{0x141492C3FBCD02EBLL,0xD269B1FC3106314CLL,0x9FC064AD601BE6BALL,18446744073709551615UL,0xD269B1FC3106314CLL,0xC77016B2C301BD92LL,0x8084512262AAB7A8LL,0x9EAB5B51909A0C0CLL,0xD269B1FC3106314CLL},{0x1F16B71BB680A4CCLL,0x1F16B71BB680A4CCLL,0xCA5786B9FDF687E4LL,0x9EAB5B51909A0C0CLL,0xC84F9D07DAFF2557LL,0x141492C3FBCD02EBLL,0x1F16B71BB680A4CCLL,0xC84F9D07DAFF2557LL,0xD269B1FC3106314CLL},{0UL,0x8084512262AAB7A8LL,18446744073709551615UL,0xC84F9D07DAFF2557LL,0xC84F9D07DAFF2557LL,18446744073709551615UL,0x8084512262AAB7A8LL,0UL,0xCA5786B9FDF687E4LL},{0UL,0xC84F9D07DAFF2557LL,0xCA5786B9FDF687E4LL,0UL,0x8084512262AAB7A8LL,18446744073709551615UL,0xC84F9D07DAFF2557LL,0xC84F9D07DAFF2557LL,18446744073709551615UL}};
    uint32_t l_2024 = 4294967295UL;
    int8_t l_2049 = 0x2FL;
    uint32_t ***l_2114[6] = {&g_631,&g_631,(void*)0,&g_631,&g_631,(void*)0};
    int32_t *l_2167 = &g_101;
    int i, j;
    for (i = 0; i < 7; i++)
        l_727[i] = (void*)0;
    if (func_9((((0x7BL && (!(func_14((safe_mul_func_int16_t_s_s((g_8 | func_21((safe_add_func_int16_t_s_s(func_25(g_8, ((safe_sub_func_uint64_t_u_u(func_32(((p_7 < (safe_lshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(0x6B42L, ((-7L) == func_40(g_42)))), 0))) , l_726), l_727[0], g_414[5][1]), p_7)) , l_727[0]), p_7, p_7), g_414[5][1])))), p_7)), l_727[0], p_7, l_727[1]) , l_726.f0))) != 247UL) , (*g_1626)), l_727[0], l_726.f0))
    { /* block id: 877 */
        int8_t *l_1833 = (void*)0;
        int32_t l_1835 = 0L;
        const int64_t ****l_1846 = (void*)0;
        int32_t l_1877 = 0x91C8CEF1L;
        struct S0 *l_1913[2][4][6] = {{{&g_1917,(void*)0,&g_1927,&g_1923[4],&g_1914,&g_1915},{(void*)0,&g_1928,&g_1930,(void*)0,(void*)0,&g_1915},{&g_1921[1][0],&g_1926,&g_1927,(void*)0,&g_1928,&g_1928},{(void*)0,(void*)0,(void*)0,(void*)0,&g_1921[1][0],&g_1920}},{{(void*)0,&g_1927,&g_1926,&g_1921[1][0],&g_1924,(void*)0},{(void*)0,&g_1930,&g_1928,(void*)0,&g_1924,(void*)0},{&g_1923[4],&g_1927,(void*)0,&g_1917,&g_1921[1][0],&g_1917},{&g_1918,(void*)0,&g_1918,&g_1925[1],&g_1928,&g_1924}}};
        int32_t *l_1935[2][1];
        uint8_t ** const *l_1959[2];
        uint8_t ** const **l_1958 = &l_1959[1];
        uint8_t ** const ***l_1957 = &l_1958;
        uint8_t ** const ****l_1956 = &l_1957;
        int8_t l_2017 = 0x91L;
        uint64_t *l_2025 = &g_214;
        uint64_t *l_2040 = &g_347[4];
        int i, j, k;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 1; j++)
                l_1935[i][j] = &g_101;
        }
        for (i = 0; i < 2; i++)
            l_1959[i] = (void*)0;
        for (g_214 = (-30); (g_214 > 34); g_214++)
        { /* block id: 880 */
            int32_t *l_1821 = &g_73;
            uint16_t ***l_1824 = &g_1822;
            int16_t l_1852 = 0x976DL;
            int64_t ****l_1859 = (void*)0;
            int64_t *****l_1858[9] = {&l_1859,&l_1859,&l_1859,&l_1859,&l_1859,&l_1859,&l_1859,&l_1859,&l_1859};
            int8_t **l_1860 = &l_1833;
            uint64_t ** const *l_1872 = &g_713;
            uint64_t ** const **l_1871 = &l_1872;
            int i;
            if ((((*l_1821) = p_7) < ((((*l_1824) = g_1822) != &g_1823[1]) != (p_7 <= (safe_add_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((l_1835 ^= (safe_mul_func_int16_t_s_s(2L, (l_1833 == l_1834)))), 9)), (safe_mul_func_int16_t_s_s(((p_7 , l_726.f0) <= p_7), 0xABEBL)))), p_7))))))
            { /* block id: 884 */
                const int64_t *****l_1844 = (void*)0;
                const int64_t *****l_1845[2];
                const int32_t l_1853 = (-4L);
                const uint8_t *l_1854 = &g_1301[5];
                uint16_t *l_1857 = &g_8;
                struct S0 *l_1932 = (void*)0;
                int32_t l_1933 = 0x3D4D8CC2L;
                int i;
                for (i = 0; i < 2; i++)
                    l_1845[i] = &g_1842;
                (*l_1821) = (((((safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((*l_1834) = ((((((l_1846 = g_1842) == ((((((g_1847 , l_1848) == ((g_122.f0 , (safe_add_func_uint16_t_u_u(((l_1852 > ((((l_1853 , l_1833) == l_1854) & ((*l_1857) = ((**g_1822) = (safe_add_func_int32_t_s_s((((l_1835 && 18446744073709551615UL) && l_1853) < 0xDDL), (*g_632)))))) > 0UL)) , l_726.f0), p_7))) , l_1858[0])) , l_1860) != (void*)0) , (*l_1821)) , &g_1843)) < p_7) & p_7) <= 0xC56508D584B2089CLL) , p_7)), g_599[0])), 0xBA3FL)) > 0xC3L) , p_7) , 0L) & p_7);
                if ((safe_div_func_int16_t_s_s((safe_div_func_uint64_t_u_u((safe_add_func_uint64_t_u_u((l_1835 = (safe_sub_func_uint8_t_u_u((((safe_sub_func_int16_t_s_s(p_7, ((*g_252) , (**g_498)))) , p_7) || ((void*)0 == l_1871)), (safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(p_7, ((*l_1857) = l_1835))), l_1835))))), l_726.f0)), l_1877)), p_7)))
                { /* block id: 892 */
                    int32_t **l_1878 = &g_284;
                    (*l_1878) = &l_1835;
                }
                else
                { /* block id: 894 */
                    int32_t **l_1880[7] = {&l_1821,&l_1821,&l_1821,&l_1821,&l_1821,&l_1821,&l_1821};
                    uint64_t *l_1901 = &g_1567;
                    int i;
                    l_1821 = l_1879;
                    (*l_1879) ^= (((safe_mul_func_int16_t_s_s((((l_1835 || (p_7 | (safe_add_func_int8_t_s_s((0x5385CB02L || (safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(1L, ((*l_1834) ^= ((safe_unary_minus_func_int8_t_s((l_1853 < (safe_mul_func_int8_t_s_s((&g_582 == l_1892), ((safe_mul_func_uint8_t_u_u(0x76L, (!p_7))) & 0x41C6A552L)))))) , p_7)))), p_7))), l_1853)))) == 18446744073709551615UL) ^ l_1835), 0x565DL)) <= (*g_632)) < l_1853);
                    (*l_1821) = (((p_7 >= ((((l_1933 = (safe_sub_func_uint16_t_u_u(p_7, (safe_add_func_int64_t_s_s(((func_14((((*l_1901) = p_7) > (((safe_lshift_func_int16_t_s_u(((safe_mod_func_uint8_t_u_u(((l_1877 == (((safe_div_func_uint8_t_u_u(((!(safe_lshift_func_int8_t_s_s(p_7, 7))) && (((((*l_1860) = l_1833) == ((safe_mod_func_uint64_t_u_u((0xF1L & 1L), l_1877)) , l_1854)) < (*g_256)) | p_7)), g_66)) || (*g_632)) ^ p_7)) || p_7), p_7)) != p_7), 14)) < (-1L)) >= p_7)), l_1913[1][2][4], g_1301[7], l_1932) , (*l_1821)) >= 0x4BL), p_7))))) & p_7) >= g_1568[3][3]) == p_7)) < (-1L)) || 0x9A2D8AECL);
                }
                if (p_7)
                    continue;
            }
            else
            { /* block id: 904 */
                int32_t *l_1934[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_1934[i] = &l_1835;
                (*l_1879) = l_1877;
                l_1935[0][0] = ((**l_1892) = l_1934[1]);
                (**l_1892) = l_1934[1];
            }
        }
        for (g_773 = (-27); (g_773 < 22); g_773 = safe_add_func_int64_t_s_s(g_773, 3))
        { /* block id: 913 */
            uint32_t l_1955[1][2];
            int64_t l_1979 = 0xA107AD8F81ACD2D1LL;
            int32_t l_1985[8][9][2] = {{{0x2D7C287AL,0x795A25CCL},{0x7DC75534L,9L},{1L,9L},{0x7DC75534L,0x795A25CCL},{0x2D7C287AL,(-3L)},{0L,2L},{(-1L),0L},{0x00E870D8L,0L},{(-8L),0xF9327F5EL}},{{(-8L),0L},{0x00E870D8L,0L},{(-1L),2L},{0L,(-3L)},{0x2D7C287AL,0x795A25CCL},{0x7DC75534L,9L},{1L,9L},{0x7DC75534L,0x795A25CCL},{0x2D7C287AL,(-3L)}},{{0L,2L},{(-1L),0L},{0x00E870D8L,0L},{(-8L),0xF9327F5EL},{(-8L),0L},{0x00E870D8L,0L},{(-1L),2L},{0L,(-3L)},{0x2D7C287AL,0x795A25CCL}},{{0x7DC75534L,9L},{1L,9L},{0x7DC75534L,0x795A25CCL},{0x2D7C287AL,(-3L)},{0L,2L},{(-1L),0L},{0x00E870D8L,0L},{(-8L),0xF9327F5EL},{(-8L),0L}},{{0x00E870D8L,0L},{(-1L),2L},{0L,(-3L)},{0x2D7C287AL,0x795A25CCL},{0x7DC75534L,9L},{1L,9L},{0x7DC75534L,0x795A25CCL},{0x2D7C287AL,(-3L)},{0L,2L}},{{(-1L),4L},{1L,(-1L)},{1L,0L},{1L,(-1L)},{1L,4L},{0x2D7C287AL,9L},{(-8L),0L},{0xD97BF29EL,0xF9327F5EL},{0x14185346L,0x45FF4D49L}},{{0x7DC75534L,0x45FF4D49L},{0x14185346L,0xF9327F5EL},{0xD97BF29EL,0L},{(-8L),9L},{0x2D7C287AL,4L},{1L,(-1L)},{1L,0L},{1L,(-1L)},{1L,4L}},{{0x2D7C287AL,9L},{(-8L),0L},{0xD97BF29EL,0xF9327F5EL},{0x14185346L,0x45FF4D49L},{0x7DC75534L,0x45FF4D49L},{0x14185346L,0xF9327F5EL},{0xD97BF29EL,0L},{(-8L),9L},{0x2D7C287AL,4L}}};
            uint16_t l_2006[2];
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1955[i][j] = 0xE2D76529L;
            }
            for (i = 0; i < 2; i++)
                l_2006[i] = 4UL;
            for (g_148 = 0; (g_148 == 49); g_148 = safe_add_func_int64_t_s_s(g_148, 1))
            { /* block id: 916 */
                int64_t l_1980 = 1L;
                for (l_726.f0 = (-19); (l_726.f0 < (-13)); ++l_726.f0)
                { /* block id: 919 */
                    union U1 *l_1977 = (void*)0;
                    int64_t *l_1978 = &g_345[2][3];
                    uint16_t *l_1981 = &g_8;
                    int32_t l_1982 = 0xE815DFDFL;
                    uint64_t l_1983 = 2UL;
                    uint64_t *l_1984 = &g_406;
                    l_1985[0][7][1] = (safe_mod_func_int64_t_s_s(((safe_sub_func_int64_t_s_s((p_7 < (safe_sub_func_uint8_t_u_u(((0x4271E57E9FA40919LL ^ ((*l_1984) = ((safe_mul_func_int16_t_s_s((((((~((safe_sub_func_int8_t_s_s(p_7, ((****g_1653) = (l_1955[0][1] || ((((l_1956 != g_1960) & (safe_lshift_func_uint16_t_u_s(((**g_1822) = 0x4841L), (((+((safe_mod_func_uint32_t_u_u(((**g_631) ^= ((((safe_sub_func_uint16_t_u_u(((((*l_1981) = (255UL > (((((((*l_1978) ^= ((!((safe_div_func_int64_t_s_s((&l_726 == l_1977), 1L)) <= (-1L))) > 0xD1L)) , 4294967290UL) , l_1979) && 1L) != p_7) <= l_1980))) == 0x2F39L) == g_308), l_1982)) , p_7) , (void*)0) == (void*)0)), (-7L))) & p_7)) > g_974) > l_1955[0][1])))) || 0xC75CL) ^ 0x4336L))))) > 0x9511L)) ^ (-1L)) , 0x82B5L) & p_7) ^ l_1983), 8L)) > p_7))) != p_7), 251UL))), (*l_1879))) > l_1979), 0x4121723EF5BB0BE7LL));
                    if ((*l_1879))
                    { /* block id: 927 */
                        int32_t l_1986 = 0L;
                        l_1986 = (l_1982 = p_7);
                        (**l_1892) = &l_1835;
                    }
                    else
                    { /* block id: 931 */
                        int16_t *l_2005 = &g_848;
                        if (p_7)
                            break;
                        l_1985[3][4][0] = (safe_rshift_func_uint16_t_u_s(((safe_mod_func_int64_t_s_s((safe_div_func_int64_t_s_s(((((safe_sub_func_int64_t_s_s((safe_mod_func_uint16_t_u_u(((*l_1981)--), ((safe_sub_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(5UL, (safe_mul_func_uint16_t_u_u((**g_1822), (((((*l_2005) ^= l_1983) > l_2006[0]) < (((*g_765)++) , l_2009[4][8])) < ((((!((safe_div_func_uint32_t_u_u(((((l_1980 , (l_2017 = (safe_sub_func_uint32_t_u_u(0x93EA7CD5L, (0xE6E34F2DL || ((safe_add_func_uint32_t_u_u(((*g_631) == (void*)0), 0xE6639085L)) | 0x34L)))))) >= 0xF999B40AL) , g_447.f2) , l_1982), l_1980)) || 0x45L)) != p_7) != p_7) <= 0x11EEC58CFC751CD8LL)))))) > p_7), p_7)) ^ l_2006[0]))), 0x7DE4BB6C8B64FA78LL)) , (**g_631)) , (**g_1625)) , 0xCACC62691FDB514ALL), 1UL)), l_1982)) > p_7), p_7));
                    }
                }
            }
            return (**g_864);
        }
        (*l_1879) = ((p_7 , ((safe_lshift_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(65531UL, 3)) <= ((((safe_mod_func_uint64_t_u_u(((*l_2025) = l_2024), ((((*l_2040) ^= ((safe_sub_func_int8_t_s_s((-1L), (!(~p_7)))) | ((*g_499) <= ((((l_726 = l_726) , ((safe_lshift_func_int8_t_s_u(p_7, (safe_lshift_func_int16_t_s_s((((((safe_add_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((p_7 & g_259[4][6][0]) == 0x6BBBL) <= (*g_765)), (****g_1653))), 0xE8L)), p_7)) < (*l_1879)) , 0L) <= g_1568[2][2]) != p_7), p_7)))) , &g_631)) == (void*)0) , p_7)))) | p_7) & p_7))) , (-1L)) == 1L) || (**g_764))), 11)) ^ g_1564)) != p_7);
        return p_7;
    }
    else
    { /* block id: 948 */
        const int32_t l_2048 = 0xCA1689D9L;
        for (g_506 = 0; (g_506 <= 1); g_506 += 1)
        { /* block id: 951 */
            uint16_t l_2041 = 0x4BE8L;
            --l_2041;
        }
        (*l_1879) = ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_u(8UL, 3)), 4)) & l_2048);
    }
    if (((*g_256) == l_2049))
    { /* block id: 956 */
        uint16_t l_2050 = 0UL;
        l_2050--;
        for (g_66 = 0; g_66 < 2; g_66 += 1)
        {
            g_1680[g_66] = &g_284;
        }
    }
    else
    { /* block id: 959 */
        int32_t * const l_2057 = &g_101;
        int8_t l_2082 = 0x0EL;
        const uint8_t *l_2142 = &g_1301[5];
        for (g_974 = (-18); (g_974 > 18); g_974++)
        { /* block id: 962 */
            int32_t **l_2058[2][3];
            struct S0 *l_2061 = &g_1922[0];
            union U1 **l_2072 = &g_1626;
            union U1 ***l_2071 = &l_2072;
            uint32_t l_2100 = 4294967295UL;
            uint8_t ***l_2160 = &g_864;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 3; j++)
                    l_2058[i][j] = &l_1879;
            }
            (*g_1815) = ((safe_mul_func_int16_t_s_s(p_7, 9L)) , l_2057);
            for (l_726.f0 = 2; (l_726.f0 <= 7); l_726.f0 += 1)
            { /* block id: 966 */
                uint64_t *l_2060 = &g_347[1];
                uint64_t **l_2059[9][5][4] = {{{&l_2060,&l_2060,(void*)0,(void*)0},{&l_2060,&l_2060,&l_2060,(void*)0},{&l_2060,(void*)0,(void*)0,&l_2060},{(void*)0,&l_2060,&l_2060,(void*)0},{&l_2060,&l_2060,&l_2060,&l_2060}},{{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,(void*)0},{(void*)0,&l_2060,&l_2060,&l_2060}},{{&l_2060,(void*)0,&l_2060,(void*)0},{&l_2060,&l_2060,(void*)0,(void*)0},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,&l_2060}},{{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{(void*)0,(void*)0,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,(void*)0}},{{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,(void*)0,&l_2060,&l_2060},{(void*)0,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060}},{{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,(void*)0},{&l_2060,&l_2060,&l_2060,(void*)0},{&l_2060,(void*)0,(void*)0,&l_2060}},{{(void*)0,&l_2060,&l_2060,(void*)0},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,(void*)0,&l_2060,&l_2060}},{{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060},{(void*)0,&l_2060,&l_2060,&l_2060},{&l_2060,&l_2060,(void*)0,&l_2060}},{{&l_2060,&l_2060,(void*)0,&l_2060},{&l_2060,&l_2060,&l_2060,(void*)0},{(void*)0,(void*)0,&l_2060,(void*)0},{&l_2060,(void*)0,&l_2060,&l_2060},{&l_2060,&l_2060,&l_2060,&l_2060}}};
                int8_t *l_2068[9] = {&g_219,&g_974,&g_219,&g_974,&g_219,&g_974,&g_219,&g_974,&g_219};
                int32_t l_2069 = 0x414A6061L;
                int16_t *l_2076 = &g_848;
                int32_t l_2077 = (-6L);
                struct S0 *l_2083 = &g_1915;
                int32_t *l_2163 = &g_101;
                int i, j, k;
                (*l_1879) &= (((*l_2060) &= (g_454[l_726.f0] < ((****g_1653) = ((void*)0 != l_2059[0][3][1])))) , p_7);
                g_2062 = l_2061;
                if ((safe_add_func_int16_t_s_s((((safe_rshift_func_int8_t_s_u(((-10L) | ((*l_2076) = ((((l_2069 ^= p_7) , g_2070[6]) , l_2071) != g_2073))), 2)) & (l_2077 & ((safe_add_func_int16_t_s_s(p_7, (safe_add_func_uint16_t_u_u(((**g_1822) = ((void*)0 == &l_2058[0][2])), p_7)))) , l_2082))) | p_7), p_7)))
                { /* block id: 974 */
                    union U1 l_2084 = {0xE3D0L};
                    int32_t l_2117 = 0L;
                    int32_t l_2135 = 0x91F26A11L;
                    (*g_733) = l_2083;
                    for (g_778 = 0; (g_778 <= 0); g_778 += 1)
                    { /* block id: 978 */
                        uint32_t ***l_2113 = (void*)0;
                        uint32_t ****l_2112[3];
                        int32_t l_2115 = 0x47B376C5L;
                        uint32_t ** const *l_2116 = &g_631;
                        int16_t **l_2130 = &g_1107;
                        int64_t *l_2136 = (void*)0;
                        int64_t *l_2137 = &g_345[0][0];
                        int64_t *l_2138[10] = {&g_778,&g_99,&g_99,&g_778,&g_99,&g_99,&g_778,&g_99,&g_99,&g_778};
                        int32_t l_2139 = (-1L);
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2112[i] = &l_2113;
                        (*l_1879) &= (((0xB041C7768211F299LL > (g_599[g_778] ^= 9UL)) ^ (((l_2084 , (g_81[g_778] <= ((((safe_sub_func_uint64_t_u_u((safe_lshift_func_int8_t_s_u(((!((+(((****g_1653) = ((0x9909L <= g_2091) , (safe_rshift_func_int8_t_s_u(1L, 2)))) <= ((safe_div_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u((p_7 == (safe_add_func_uint8_t_u_u(l_2069, p_7))), l_2100)) && g_81[g_778]), (*l_2057))) != p_7))) > 0xB0D9398F95F45B1FLL)) == l_2084.f0), 4)), p_7)) < (*l_2057)) == 0x540AA8F42A3AC319LL) , p_7))) | (*l_2057)) , (-1L))) && 1L);
                        l_2117 = (p_7 > (((((((p_7 && ((((safe_sub_func_int16_t_s_s(l_2084.f0, (0xD87B96B7L > (*g_632)))) | ((safe_rshift_func_int16_t_s_u((-10L), 11)) == (safe_rshift_func_uint8_t_u_u(0x35L, 6)))) ^ (+(((safe_add_func_uint16_t_u_u((((l_2114[3] = &g_631) != (((l_2115 |= (((*g_765) = (0xB4L & p_7)) < 0x51L)) >= 1L) , l_2116)) < g_454[l_726.f0]), 0L)) , p_7) || l_2069))) && p_7)) > l_2084.f0) == g_414[1][1]) , &g_1566[1][0]) != (void*)0) != p_7) != (-7L)));
                        (*l_1879) = (safe_add_func_uint32_t_u_u((((l_2139 |= ((*l_2137) = (safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((((safe_mod_func_uint8_t_u_u(0x5AL, p_7)) , ((safe_add_func_int8_t_s_s((l_2117 = (((l_2115 ^= ((*l_2057) &= (--(*g_632)))) < ((l_2130 == (void*)0) , (safe_div_func_int64_t_s_s(p_7, (safe_sub_func_uint64_t_u_u(18446744073709551606UL, ((*g_256) , ((((((*l_2076) = 0x8BD2L) == p_7) & l_2135) < 0xAC14A6D2L) < g_81[g_778])))))))) == 0x8136L)), 5L)) > (-1L))) != g_354[0]), l_2135)), 0x58L)))) , g_119[1][6]) , 0x10A9E7D6L), g_414[3][1]));
                    }
                }
                else
                { /* block id: 995 */
                    int8_t l_2161 = 0L;
                    if (p_7)
                    { /* block id: 996 */
                        uint32_t l_2162 = 4294967288UL;
                        (*l_2057) = p_7;
                        l_2163 = ((p_7 & (((p_7 == ((l_2142 == (void*)0) != ((-3L) != (((safe_div_func_int64_t_s_s(((*l_2083) , (safe_div_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_u(((**g_1822) = ((safe_add_func_uint32_t_u_u((0UL < ((+(safe_lshift_func_uint8_t_u_u(((((((safe_lshift_func_int8_t_s_u(g_454[l_726.f0], (((*l_2060) = (((safe_mul_func_int8_t_s_s((((safe_add_func_int8_t_s_s(0x9BL, p_7)) , (*g_1653)) == l_2160), (**g_864))) < l_2077) || (-1L))) || 0x738AE064585767E3LL))) , &g_256) != (void*)0) > p_7) && 0x07A96D472501C5CCLL) & l_2077), 7))) >= l_2161)), p_7)) >= (*l_2057))), 12)) | p_7), p_7))), l_2162)) , 0L) && g_454[l_726.f0])))) , p_7) , p_7)) , (*g_1815));
                        return (*l_2163);
                    }
                    else
                    { /* block id: 1002 */
                        int16_t **l_2166 = &l_2076;
                        (*l_2163) &= p_7;
                        if ((**g_582))
                            continue;
                        (*l_2057) &= (((void*)0 != &l_2009[9][6]) , ((++(***l_2160)) | ((l_2166 = (p_7 , (void*)0)) == &g_1107)));
                    }
                }
            }
            (*l_1879) |= 0x8C1EA723L;
        }
        (*g_1815) = l_2167;
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_148 g_1653 g_863 g_864 g_765 g_232 g_764 g_599 g_631 g_632 g_188 g_101 g_252 g_122.f0 g_498 g_499 g_500 g_414 g_73 g_1815 g_974 g_1818
 * writes: g_148 g_773 g_119 g_101 g_105 g_1564 g_73 g_974
 */
static int32_t  func_9(union U1  p_10, struct S0 * const  p_11, int32_t  p_12)
{ /* block id: 847 */
    uint16_t l_1735 = 9UL;
    uint16_t *l_1736 = &g_148;
    uint8_t *l_1746 = &g_1301[5];
    int16_t *l_1747 = &g_773;
    uint32_t *l_1748[3];
    int32_t l_1749 = 0x0E132764L;
    int32_t l_1753 = 0L;
    int32_t l_1754[9] = {6L,6L,6L,6L,6L,6L,6L,6L,6L};
    struct S0 **l_1786 = (void*)0;
    union U1 **l_1804[3][8][9] = {{{(void*)0,&g_1626,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,&g_1626},{(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626},{(void*)0,(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0},{&g_1626,&g_1626,(void*)0,(void*)0,&g_1626,&g_1626,&g_1626,(void*)0,&g_1626},{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626},{&g_1626,(void*)0,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,(void*)0},{&g_1626,&g_1626,&g_1626,&g_1626,(void*)0,(void*)0,(void*)0,(void*)0,&g_1626},{&g_1626,&g_1626,&g_1626,(void*)0,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626}},{{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,(void*)0,(void*)0,(void*)0},{&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,&g_1626,&g_1626},{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626},{(void*)0,&g_1626,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,&g_1626},{(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626},{(void*)0,(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626},{&g_1626,(void*)0,(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,&g_1626},{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,(void*)0}},{{&g_1626,(void*)0,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,(void*)0},{&g_1626,&g_1626,&g_1626,(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,(void*)0},{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626},{&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,(void*)0,(void*)0,&g_1626,&g_1626},{&g_1626,(void*)0,&g_1626,&g_1626,&g_1626,(void*)0,&g_1626,&g_1626,&g_1626},{&g_1626,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,&g_1626,&g_1626},{(void*)0,(void*)0,&g_1626,&g_1626,(void*)0,&g_1626,(void*)0,&g_1626,&g_1626},{(void*)0,(void*)0,(void*)0,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626}}};
    union U1 ***l_1805[5][1][10] = {{{&l_1804[0][6][4],(void*)0,(void*)0,(void*)0,&l_1804[1][0][5],&l_1804[0][4][5],&l_1804[0][4][5],&l_1804[1][5][3],&l_1804[2][2][8],&l_1804[2][1][4]}},{{&l_1804[2][6][2],(void*)0,&l_1804[0][6][2],(void*)0,&l_1804[1][0][5],(void*)0,&l_1804[0][6][2],(void*)0,&l_1804[2][6][2],&l_1804[0][4][5]}},{{&l_1804[1][0][5],&l_1804[0][4][5],(void*)0,&l_1804[2][4][3],(void*)0,&l_1804[2][6][2],&l_1804[0][4][5],&l_1804[0][4][5],&l_1804[0][6][2],&l_1804[0][6][2]}},{{(void*)0,(void*)0,&l_1804[1][5][3],&l_1804[2][4][3],&l_1804[2][4][3],&l_1804[1][5][3],(void*)0,(void*)0,&l_1804[2][6][2],&l_1804[1][3][3]}},{{(void*)0,&l_1804[0][4][5],&l_1804[0][4][5],(void*)0,(void*)0,&l_1804[0][6][2],&l_1804[0][6][4],&l_1804[2][4][3],&l_1804[2][2][8],&l_1804[2][4][3]}}};
    union U1 **l_1806 = &g_1626;
    uint64_t *l_1812 = (void*)0;
    uint64_t *l_1813 = &g_1564;
    int32_t l_1814 = 0xC897DB5DL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1748[i] = &g_217;
    if (((l_1749 = ((**g_631) = (safe_unary_minus_func_int16_t_s((safe_lshift_func_uint8_t_u_s((safe_sub_func_uint16_t_u_u((p_12 , 1UL), ((*l_1747) = (safe_div_func_int16_t_s_s((safe_add_func_uint64_t_u_u((((*l_1736) &= l_1735) != (((safe_lshift_func_uint8_t_u_s((****g_1653), 0)) == (safe_mod_func_uint16_t_u_u((((((((safe_unary_minus_func_uint16_t_u(((safe_unary_minus_func_int16_t_s(1L)) ^ (!(safe_sub_func_uint64_t_u_u(((l_1735 , ((l_1735 , l_1746) != (*g_764))) == 6UL), l_1735)))))) , 0x83L) && p_12) & p_10.f0) != p_10.f0) && 0UL) , p_10.f0), g_599[0]))) <= 0x45E16546B1DA8D59LL)), l_1735)), l_1735))))), 0)))))) <= p_10.f0))
    { /* block id: 852 */
        int32_t **l_1750 = &g_105;
        (*g_188) |= 1L;
        (*l_1750) = &l_1749;
    }
    else
    { /* block id: 855 */
        int32_t *l_1751 = &g_73;
        int32_t *l_1752[5];
        int32_t l_1755 = 0L;
        uint8_t l_1756 = 0xEBL;
        uint8_t ***l_1779 = &g_864;
        const int32_t l_1780[4] = {1L,1L,1L,1L};
        int32_t l_1781 = 0x41985FCDL;
        int i;
        for (i = 0; i < 5; i++)
            l_1752[i] = &g_101;
        l_1756--;
        l_1749 |= (p_10 , (((safe_div_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((safe_lshift_func_uint16_t_u_u(((*l_1736) = ((****g_1653) ^ 255UL)), (safe_div_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(((safe_sub_func_int32_t_s_s(((p_12 > p_10.f0) != p_12), 0x6CF5BF0BL)) | ((((safe_rshift_func_uint8_t_u_u((**g_864), (safe_add_func_uint16_t_u_u(((0xD3F5L != (*g_252)) , (**g_498)), p_12)))) >= p_12) , (void*)0) == l_1779)), 8)), g_414[4][1])))) ^ p_12) & 0xB9L), (-6L))), l_1780[2])), p_12)), l_1781)) , 18446744073709551609UL) , 9L));
        for (l_1756 = 16; (l_1756 <= 29); l_1756 = safe_add_func_int64_t_s_s(l_1756, 9))
        { /* block id: 861 */
            p_12 ^= (safe_sub_func_uint16_t_u_u(((*l_1736) |= (p_10.f0 || (0x4783L & 0xDF0BL))), (&l_1781 == &p_12)));
        }
        l_1786 = l_1786;
    }
    g_73 ^= ((((safe_div_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((+(safe_rshift_func_int8_t_s_u((((safe_add_func_int8_t_s_s(((l_1735 , p_12) >= 0x4DE5744EL), (safe_lshift_func_uint8_t_u_u((l_1749 == (safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(l_1754[8], l_1735)), (safe_rshift_func_uint8_t_u_s(((((*l_1813) = (((l_1806 = l_1804[0][4][5]) != ((safe_add_func_uint16_t_u_u((safe_div_func_int8_t_s_s(((~p_12) | 0x8A8BDB86L), l_1754[7])), (**g_498))) , &g_1626)) <= 0x27D5L)) > p_12) , (**g_864)), 6))))), 1)))) <= l_1754[4]) <= l_1749), l_1753))), 0L)), p_12)) > l_1735) , l_1754[8]) <= l_1814);
    (*g_1815) = &l_1753;
    for (g_974 = 1; (g_974 != 3); g_974++)
    { /* block id: 873 */
        (*g_1818) = &p_12;
    }
    return l_1749;
}


/* ------------------------------------------ */
/* 
 * reads : g_498 g_499 g_500 g_81 g_217 g_599 g_864 g_765 g_232 g_406 g_101 g_631 g_632 g_73 g_1240 g_1259 g_1260 g_1267 g_764 g_122.f0 g_506 g_1294 g_1295 g_733 g_1301 g_345 g_1072 g_252 g_863 g_347 g_119 g_1497 g_284 g_124 g_414 g_1527 g_848 g_99 g_8 g_255 g_256 g_257 g_1555 g_713 g_974 g_148 g_1625 g_1663 g_1626 g_122 g_1681 g_66 g_105 g_1724
 * writes: g_599 g_345 g_506 g_101 g_119 g_73 g_284 g_105 g_1267 g_122.f0 g_47 g_1301 g_1072 g_232 g_219 g_848 g_66 g_99 g_347 g_732 g_1565 g_148 g_1626 g_1392 g_1653 g_631 g_8 g_713
 */
static const union U1  func_14(uint8_t  p_15, struct S0 * p_16, int32_t  p_17, struct S0 * p_18)
{ /* block id: 606 */
    const int64_t l_1218 = 0x9A41756E76D550F6LL;
    int32_t l_1225[8];
    uint64_t *l_1226 = &g_599[0];
    int64_t *l_1231 = &g_345[2][1];
    int16_t l_1232 = 0x25D1L;
    uint16_t *l_1233 = &g_506;
    uint16_t l_1234[6][9] = {{65529UL,6UL,0x6779L,4UL,0xCFA5L,0xCFA5L,4UL,0x6779L,6UL},{4UL,0xCC0EL,5UL,4UL,0UL,0x96BFL,1UL,1UL,0x96BFL},{65528UL,0x6779L,0xBBEDL,0x6779L,65528UL,0xE0D2L,0xA229L,0xF160L,4UL},{0UL,0xCC0EL,4UL,65528UL,0UL,65528UL,4UL,0xCC0EL,0UL},{0UL,6UL,0x9430L,65528UL,0xF160L,0x9430L,4UL,0x9430L,0x6779L},{5UL,3UL,3UL,5UL,0UL,0xCC0EL,4UL,65528UL,0UL}};
    int32_t *l_1235 = &g_101;
    int64_t l_1236 = (-6L);
    int32_t *l_1237 = &l_1225[1];
    uint64_t l_1238[9][3][8] = {{{18446744073709551609UL,1UL,7UL,0x1847293F1722C5F8LL,0UL,18446744073709551611UL,0x0BB3976B1A68DBD9LL,1UL},{1UL,1UL,1UL,18446744073709551610UL,2UL,0x39312096CB802644LL,7UL,0UL},{0x48A523A094A25B10LL,0x7260CD92F141535ELL,0x3DED55DDA9E9BB84LL,1UL,0x401E8EDE04694BC0LL,0UL,3UL,0x6BC21B0C89B4B2F1LL}},{{1UL,0xDD1ECE32BC030074LL,2UL,3UL,18446744073709551615UL,1UL,18446744073709551615UL,3UL},{1UL,18446744073709551611UL,1UL,18446744073709551609UL,0x6BC21B0C89B4B2F1LL,18446744073709551609UL,0UL,18446744073709551606UL},{0x081CD13FFD8CC5D7LL,18446744073709551610UL,18446744073709551611UL,18446744073709551615UL,0x0BB3976B1A68DBD9LL,0x48A523A094A25B10LL,0x6BC21B0C89B4B2F1LL,18446744073709551615UL}},{{0x081CD13FFD8CC5D7LL,0x625411F51C2CC138LL,18446744073709551609UL,1UL,0x6BC21B0C89B4B2F1LL,0xBF84A5771D57A2D1LL,1UL,0UL},{1UL,0x0BB3976B1A68DBD9LL,0x39312096CB802644LL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL,18446744073709551615UL,18446744073709551609UL},{1UL,2UL,0x1847293F1722C5F8LL,0x9EAEDBC6DA4ADB8DLL,0x401E8EDE04694BC0LL,0x7260CD92F141535ELL,18446744073709551609UL,1UL}},{{0x48A523A094A25B10LL,0x081CD13FFD8CC5D7LL,0UL,0UL,2UL,2UL,0UL,0UL},{1UL,1UL,1UL,2UL,0UL,0x1A36BF02D66705BELL,0x0702B75404A09FB9LL,5UL},{18446744073709551609UL,1UL,0x7260CD92F141535ELL,7UL,1UL,18446744073709551615UL,1UL,5UL}},{{1UL,18446744073709551615UL,0x625411F51C2CC138LL,2UL,1UL,1UL,0xDF50551DDB103F74LL,0UL},{0UL,3UL,0x9EAEDBC6DA4ADB8DLL,0UL,18446744073709551609UL,18446744073709551606UL,0x8B424A308E35E208LL,1UL},{0xBF84A5771D57A2D1LL,18446744073709551615UL,18446744073709551609UL,0x9EAEDBC6DA4ADB8DLL,0x081CD13FFD8CC5D7LL,0x0BB3976B1A68DBD9LL,2UL,18446744073709551609UL}},{{0xDF50551DDB103F74LL,0UL,0xBF84A5771D57A2D1LL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0xBF84A5771D57A2D1LL,0UL},{0xDD1ECE32BC030074LL,0xB36B7D44763A2834LL,0x401E8EDE04694BC0LL,1UL,18446744073709551614UL,18446744073709551609UL,1UL,18446744073709551615UL},{0UL,7UL,1UL,18446744073709551615UL,0xDD1ECE32BC030074LL,0x0702B75404A09FB9LL,1UL,18446744073709551606UL}},{{1UL,18446744073709551615UL,0x401E8EDE04694BC0LL,18446744073709551609UL,0xB36B7D44763A2834LL,0x1847293F1722C5F8LL,0xBF84A5771D57A2D1LL,3UL},{0xB36B7D44763A2834LL,0x1847293F1722C5F8LL,0xBF84A5771D57A2D1LL,3UL,1UL,0x081CD13FFD8CC5D7LL,2UL,0x6BC21B0C89B4B2F1LL},{0x401E8EDE04694BC0LL,18446744073709551609UL,18446744073709551609UL,1UL,0x1A36BF02D66705BELL,0xB36B7D44763A2834LL,0x8B424A308E35E208LL,0UL}},{{1UL,0xDF50551DDB103F74LL,0x9EAEDBC6DA4ADB8DLL,18446744073709551610UL,18446744073709551610UL,0x9EAEDBC6DA4ADB8DLL,0xDF50551DDB103F74LL,1UL},{0x9EAEDBC6DA4ADB8DLL,0UL,0UL,0x081CD13FFD8CC5D7LL,0x48A523A094A25B10LL,0x39312096CB802644LL,3UL,18446744073709551615UL},{0xDD1ECE32BC030074LL,18446744073709551606UL,1UL,1UL,0x081CD13FFD8CC5D7LL,0x39312096CB802644LL,0x7260CD92F141535ELL,0xDF50551DDB103F74LL}},{{1UL,0UL,1UL,18446744073709551609UL,0x9EAEDBC6DA4ADB8DLL,2UL,18446744073709551611UL,0x401E8EDE04694BC0LL},{0xDF50551DDB103F74LL,0x8B424A308E35E208LL,18446744073709551609UL,7UL,2UL,0xB210B8DC02B56B29LL,18446744073709551614UL,0x1A36BF02D66705BELL},{5UL,18446744073709551614UL,0x081CD13FFD8CC5D7LL,0x7260CD92F141535ELL,1UL,1UL,0x3DED55DDA9E9BB84LL,0xB210B8DC02B56B29LL}}};
    volatile int8_t * volatile *l_1245 = &g_1241;
    int16_t ** const l_1253 = &g_1107;
    uint8_t ****l_1254 = &g_863[1][2];
    union U1 l_1257 = {1L};
    int64_t **l_1281 = (void*)0;
    int64_t ***l_1280[10] = {&l_1281,&l_1281,&l_1281,&l_1281,&l_1281,&l_1281,&l_1281,&l_1281,&l_1281,&l_1281};
    int32_t **l_1346 = (void*)0;
    int32_t ***l_1345 = &l_1346;
    struct S0 * const l_1364[7] = {&g_1297,&g_1297,&g_1297,&g_1297,&g_1297,&g_1297,&g_1297};
    uint32_t **l_1393 = &g_632;
    union U1 *l_1486[9][6] = {{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257},{&l_1257,&l_1257,&l_1257,&l_1257,&l_1257,&l_1257}};
    uint16_t l_1549 = 65529UL;
    struct S0 ****l_1583 = (void*)0;
    uint32_t l_1619[8][5] = {{1UL,1UL,0x6E8BDB08L,0x0A6EB3A5L,0x6E8BDB08L},{0x92C9776CL,0x92C9776CL,0xF5A1BA15L,0x213F07ADL,0xF5A1BA15L},{1UL,1UL,0x6E8BDB08L,0x0A6EB3A5L,0x6E8BDB08L},{0x92C9776CL,0x92C9776CL,0xF5A1BA15L,0x213F07ADL,0xF5A1BA15L},{1UL,1UL,0x6E8BDB08L,0x0A6EB3A5L,0x6E8BDB08L},{0x92C9776CL,0x92C9776CL,0xF5A1BA15L,0x213F07ADL,0xF5A1BA15L},{1UL,1UL,0x6E8BDB08L,0x0A6EB3A5L,0x6E8BDB08L},{0x92C9776CL,0x92C9776CL,0xF5A1BA15L,0x213F07ADL,0xF5A1BA15L}};
    union U1 l_1642 = {0x9947L};
    int8_t l_1655 = 0L;
    int16_t l_1664 = 0x7CABL;
    uint32_t l_1678 = 0x964405E0L;
    const uint32_t l_1719 = 0x77574BD8L;
    int32_t **l_1725 = &g_105;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_1225[i] = 4L;
    if ((((safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(0xD6B2L, (**g_498))), l_1218)) ^ (((*l_1237) = (g_73 |= (g_81[0] > ((safe_mul_func_uint16_t_u_u(((((**g_631) = ((safe_unary_minus_func_int32_t_s(((*l_1235) ^= ((((*l_1233) = ((2UL != (+(safe_div_func_int64_t_s_s(g_217, ((((*l_1226)++) ^ (safe_sub_func_uint64_t_u_u((p_17 <= ((*l_1231) = (((0x3E5C2F3E85DC587ALL || (l_1225[6] , p_17)) , (**g_864)) != g_406))), p_17))) , l_1232))))) && l_1218)) > 1L) & l_1234[2][5])))) <= l_1218)) ^ l_1236) > 0x99L), 0UL)) != 0x766D627D5E11DFD5LL)))) ^ p_17)) > l_1238[0][2][6]))
    { /* block id: 614 */
        int32_t **l_1239 = &l_1235;
        volatile int8_t * volatile **l_1244[4] = {&g_1240,&g_1240,&g_1240,&g_1240};
        int i;
        (*l_1239) = &l_1225[3];
        l_1245 = g_1240;
    }
    else
    { /* block id: 617 */
        uint32_t l_1246[3];
        int64_t **l_1266 = &l_1231;
        union U1 l_1270[1] = {{0L}};
        int32_t l_1275 = 0x80F64854L;
        int32_t l_1288 = 0x805099E8L;
        struct S0 *l_1296 = &g_1297;
        int32_t l_1317 = 0xFC71D40DL;
        uint8_t ****l_1390 = &g_863[1][5];
        int32_t l_1410 = 0x95DDB09BL;
        int32_t l_1411 = 0x918FCBC4L;
        int32_t l_1417 = 0L;
        int32_t l_1418 = 0x4264E3B7L;
        int32_t l_1420 = (-1L);
        int32_t l_1422[6] = {0x7817A605L,0x7817A605L,0x7817A605L,0x7817A605L,0x7817A605L,0x7817A605L};
        int64_t l_1427 = 0xABEC67FE8AB436EFLL;
        uint64_t l_1429 = 0x805865D2587ADE87LL;
        int32_t l_1439 = 0xC8430455L;
        uint16_t l_1467[9][4][6] = {{{0x1F83L,1UL,0UL,8UL,0xED86L,0xED86L},{1UL,0xDED4L,0xDED4L,1UL,0UL,0xF01EL},{9UL,0xDED4L,0UL,0xD666L,0xED86L,1UL},{8UL,1UL,65530UL,65535UL,0xED86L,65535UL}},{{0x2370L,0xDED4L,0x7E81L,0x2370L,0UL,0UL},{65530UL,65526UL,0xE567L,0xF01EL,0xE567L,65526UL},{0xED86L,1UL,0xDF46L,0UL,0xE567L,65535UL},{1UL,65526UL,1UL,1UL,65535UL,0x49E8L}},{{0UL,65526UL,0x3E00L,65530UL,0xE567L,0x3A90L},{0UL,1UL,0x6464L,65535UL,0xE567L,0xE567L},{0x7E81L,65526UL,65526UL,0x7E81L,65535UL,0xDF46L},{0xF01EL,65526UL,65535UL,0UL,0xE567L,1UL}},{{65535UL,1UL,0x49E8L,0xED86L,0xE567L,0x3E00L},{0xDED4L,65526UL,0x3A90L,0xDED4L,65535UL,0x6464L},{65530UL,65526UL,0xE567L,0xF01EL,0xE567L,65526UL},{0xED86L,1UL,0xDF46L,0UL,0xE567L,65535UL}},{{1UL,65526UL,1UL,1UL,65535UL,0x49E8L},{0UL,65526UL,0x3E00L,65530UL,0xE567L,0x3A90L},{0UL,1UL,0x6464L,65535UL,0xE567L,0xE567L},{0x7E81L,65526UL,65526UL,0x7E81L,65535UL,0xDF46L}},{{0xF01EL,65526UL,65535UL,0UL,0xE567L,1UL},{65535UL,1UL,0x49E8L,0xED86L,0xE567L,0x3E00L},{0xDED4L,65526UL,0x3A90L,0xDED4L,65535UL,0x6464L},{65530UL,65526UL,0xE567L,0xF01EL,0xE567L,65526UL}},{{0xED86L,1UL,0xDF46L,0UL,0xE567L,65535UL},{1UL,65526UL,1UL,1UL,65535UL,0x49E8L},{0UL,65526UL,0x3E00L,65530UL,0xE567L,0x3A90L},{0UL,1UL,0x6464L,65535UL,0xE567L,0xE567L}},{{0x7E81L,65526UL,65526UL,0x7E81L,65535UL,0xDF46L},{0xF01EL,65526UL,65535UL,0UL,0xE567L,1UL},{65535UL,1UL,0x49E8L,0xED86L,0xE567L,0x3E00L},{0xDED4L,65526UL,0x3A90L,0xDED4L,65535UL,0x6464L}},{{65530UL,65526UL,0xE567L,0xF01EL,0xE567L,65526UL},{0xED86L,1UL,0xDF46L,0UL,0xE567L,65535UL},{1UL,65526UL,1UL,1UL,65535UL,0x49E8L},{0UL,65526UL,0x3E00L,65530UL,0xE567L,0x3A90L}}};
        int8_t *l_1495 = (void*)0;
        int8_t *l_1496 = &g_219;
        int32_t l_1519 = 0xEE1911CCL;
        uint64_t * const *l_1560 = &l_1226;
        uint16_t **l_1573[9][1];
        const uint8_t *l_1595 = (void*)0;
        int32_t l_1636 = 0x83FBCB6CL;
        uint32_t ***l_1667 = &g_631;
        uint32_t l_1690 = 0x15F5134FL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1246[i] = 1UL;
        for (i = 0; i < 9; i++)
        {
            for (j = 0; j < 1; j++)
                l_1573[i][j] = &l_1233;
        }
        l_1246[2]++;
lbl_1318:
        if (((((safe_sub_func_int16_t_s_s(p_17, ((l_1253 == &g_1107) | (l_1254 != &g_863[1][2])))) && ((safe_rshift_func_int16_t_s_u(((l_1257 , p_15) & 0xF202CED093049D9DLL), 13)) != ((0xF02AL < 65535UL) && (*g_765)))) ^ l_1246[2]) , l_1246[0]))
        { /* block id: 619 */
            int32_t *l_1258 = &l_1225[6];
            (*g_1259) = l_1258;
            (*g_1260) = &l_1225[6];
        }
        else
        { /* block id: 622 */
            uint64_t l_1263 = 18446744073709551615UL;
            int64_t * const **l_1268 = (void*)0;
            int64_t * const **l_1269 = &g_1267;
            int8_t *l_1273[6][5] = {{&g_1072,&g_974,&g_974,&g_974,&g_1072},{&g_974,&g_1072,&g_308,&g_1072,&g_974},{&g_974,&g_1072,&g_308,&g_1072,&g_974},{&g_974,&g_1072,&g_308,&g_1072,&g_974},{&g_974,&g_1072,&g_308,&g_1072,&g_974},{&g_974,&g_1072,&g_308,&g_1072,&g_974}};
            int32_t l_1274[7] = {4L,0x7D257B46L,0x7D257B46L,4L,0x7D257B46L,0x7D257B46L,4L};
            int16_t *l_1276 = &g_122.f0;
            int64_t ***l_1277 = (void*)0;
            int64_t ****l_1278 = (void*)0;
            int64_t ****l_1279[1];
            int8_t **l_1289 = &l_1273[1][0];
            const union U1 *l_1299 = &l_1257;
            const union U1 **l_1298[7][1];
            uint8_t *l_1300 = &g_1301[5];
            int32_t * const **l_1315 = (void*)0;
            int i, j;
            for (i = 0; i < 1; i++)
                l_1279[i] = (void*)0;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1298[i][j] = &l_1299;
            }
            p_18 = ((safe_mod_func_int16_t_s_s(p_15, ((*l_1276) |= (l_1263 == ((p_17 , (((*l_1237) = (safe_lshift_func_int16_t_s_s(p_15, ((p_17 , (l_1275 = (l_1274[1] &= (((l_1266 = l_1266) == ((*l_1269) = g_1267)) != ((l_1270[0] , (safe_mul_func_int8_t_s_s(((((void*)0 == &g_256) <= l_1263) >= p_15), p_15))) , p_17))))) == 0x2EL)))) & (**g_764))) >= 0x2CL))))) , p_18);
            (*l_1235) = ((&g_255 != (l_1280[4] = l_1277)) & (((safe_mul_func_uint8_t_u_u((*g_765), (((l_1288 &= ((safe_lshift_func_uint16_t_u_u(((*l_1233)++), 10)) ^ 0x5238L)) , (((*l_1289) = (void*)0) != ((safe_lshift_func_uint8_t_u_s(((*l_1300) |= ((l_1274[6] & (((((((l_1274[1] || (((*g_733) = (l_1296 = ((g_1294 , g_1295) , (void*)0))) == (void*)0)) , (void*)0) == l_1298[5][0]) , (void*)0) != l_1276) && (*l_1237)) && 0UL)) != 0L)), g_345[1][1])) , l_1300))) >= l_1275))) || (*l_1235)) ^ p_15));
            if (l_1275)
                goto lbl_1318;
            for (g_1072 = 14; (g_1072 == (-22)); g_1072--)
            { /* block id: 640 */
                int32_t ***l_1314 = (void*)0;
                int32_t *l_1316 = &l_1275;
                l_1317 |= ((*l_1316) &= ((*l_1235) ^= (((((****l_1254) = (safe_mul_func_int16_t_s_s(((*g_252) |= (&g_499 != &l_1233)), p_17))) <= (((((void*)0 == &g_259[5][4][0]) && (safe_add_func_uint16_t_u_u((2L | (255UL & p_15)), (safe_mul_func_int16_t_s_s((((safe_mod_func_uint8_t_u_u((p_17 | (*l_1237)), p_15)) , l_1314) != l_1315), 0x80D7L))))) & 0L) ^ (-1L))) != g_347[4]) || p_17)));
            }
        }
        for (l_1275 = 0; (l_1275 < 5); l_1275++)
        { /* block id: 651 */
            struct S0 *l_1335 = &g_1297;
            int32_t l_1337 = 0x5D361D82L;
            uint8_t ***l_1340 = &g_864;
            int32_t l_1363 = (-4L);
            int16_t l_1366 = (-4L);
            int32_t l_1413 = 0L;
            int32_t l_1414 = (-1L);
            int32_t l_1419[6][5][8] = {{{0x950C3691L,0xA1F2CF30L,0xA1F2CF30L,0x950C3691L,(-1L),8L,0xE1CAD90CL,0xB95B3E1AL},{(-1L),8L,0xE1CAD90CL,0xB95B3E1AL,2L,0L,(-1L),0x21C95BEAL},{0L,8L,(-6L),8L,(-6L),8L,0L,0xCE3341E5L},{(-9L),0xA1F2CF30L,0xCE3341E5L,8L,0x950C3691L,0xE2518FA9L,4L,0L},{0L,0x21C95BEAL,8L,2L,0x950C3691L,0x950C3691L,2L,8L}},{{(-9L),(-9L),0L,0L,(-6L),0L,8L,0xE1CAD90CL},{0L,(-1L),(-9L),(-6L),2L,0xE1CAD90CL,0xA1F2CF30L,0xE1CAD90CL},{(-1L),0L,0x950C3691L,0L,(-1L),0xB95B3E1AL,0L,8L},{0x950C3691L,4L,0x21C95BEAL,2L,(-1L),(-6L),0xCE3341E5L,0L},{0xCE3341E5L,0L,0x21C95BEAL,8L,8L,0x21C95BEAL,0L,0xCE3341E5L}},{{(-1L),0L,0x950C3691L,8L,(-9L),4L,0xA1F2CF30L,0x21C95BEAL},{0xE2518FA9L,2L,(-9L),0xB95B3E1AL,8L,4L,8L,0xB95B3E1AL},{0L,0L,0L,0x950C3691L,4L,0x21C95BEAL,2L,(-1L)},{0xB95B3E1AL,0L,8L,0xA1F2CF30L,0xE2518FA9L,(-6L),4L,4L},{0xB95B3E1AL,4L,0xCE3341E5L,0xCE3341E5L,4L,0xB95B3E1AL,0L,(-1L)}},{{0L,0L,(-6L),0L,8L,0xE1CAD90CL,(-1L),8L},{0xE2518FA9L,(-1L),0xE1CAD90CL,0L,(-9L),0L,0xE1CAD90CL,(-1L)},{(-1L),(-9L),0xA1F2CF30L,0xCE3341E5L,8L,0x950C3691L,0xE2518FA9L,4L},{0xCE3341E5L,0x21C95BEAL,(-1L),0xA1F2CF30L,(-1L),0xE2518FA9L,0xE2518FA9L,(-1L)},{0x950C3691L,0xA1F2CF30L,0xA1F2CF30L,0x950C3691L,(-1L),8L,0xE1CAD90CL,8L}},{{0L,(-6L),0L,8L,0xE1CAD90CL,(-1L),8L,0xB95B3E1AL},{0x21C95BEAL,(-6L),(-1L),0xCE3341E5L,(-1L),(-6L),0x21C95BEAL,0x950C3691L},{0xE2518FA9L,(-9L),0x950C3691L,(-6L),0L,(-6L),2L,0xA1F2CF30L},{0xA1F2CF30L,0xB95B3E1AL,0xCE3341E5L,0xE1CAD90CL,0L,0L,0xE1CAD90CL,0xCE3341E5L},{0xE2518FA9L,0xE2518FA9L,(-1L),0xA1F2CF30L,(-1L),0x21C95BEAL,0xCE3341E5L,0L}},{{0x21C95BEAL,0L,0xE2518FA9L,(-1L),0xE1CAD90CL,0L,(-9L),0L},{0L,0xA1F2CF30L,0L,0xA1F2CF30L,0L,8L,(-1L),0xCE3341E5L},{0L,2L,0xB95B3E1AL,0xE1CAD90CL,8L,(-1L),0x950C3691L,0xA1F2CF30L},{0x950C3691L,(-1L),0xB95B3E1AL,(-6L),(-6L),0xB95B3E1AL,(-1L),0x950C3691L},{8L,0x21C95BEAL,0L,0xCE3341E5L,0xE2518FA9L,2L,(-9L),0xB95B3E1AL}}};
            int32_t l_1440 = 6L;
            union U1 l_1470 = {0xEDAAL};
            int i, j, k;
        }
        if ((((*l_1496) = ((5UL || ((safe_rshift_func_uint16_t_u_s((**g_498), (safe_div_func_uint64_t_u_u((*l_1237), ((l_1486[8][4] == (void*)0) || (l_1417 &= (++(**l_1393)))))))) == (safe_sub_func_int32_t_s_s((((*l_1226) |= (safe_lshift_func_uint16_t_u_u(p_17, 0))) > ((l_1270[0] , p_17) == (safe_div_func_int8_t_s_s(0xADL, p_17)))), p_15)))) >= p_15)) , p_15))
        { /* block id: 708 */
            int32_t l_1498 = 1L;
            int32_t l_1518 = 0xE9E0D35AL;
            uint64_t *l_1543 = &g_347[2];
            const union U1 l_1546 = {0x0B83L};
            struct S0 ***l_1557 = &g_733;
            int16_t l_1570 = 0L;
            uint16_t **l_1574 = &l_1233;
            uint8_t ** const *l_1592 = &g_864;
            uint8_t ** const **l_1591 = &l_1592;
            uint8_t ** const ***l_1590[9] = {&l_1591,&l_1591,&l_1591,&l_1591,&l_1591,&l_1591,&l_1591,&l_1591,&l_1591};
            int32_t l_1613 = (-2L);
            int32_t l_1614[4][8][8] = {{{1L,(-1L),0x91B965CBL,(-5L),0xF8D752CFL,0x084E6D24L,0x01C6BBD9L,0x260DB5D8L},{0x8B82F0A8L,0xAEF8B975L,1L,0x19F95013L,(-6L),0x260DB5D8L,0x8205CC9BL,0x260DB5D8L},{0x1318957EL,(-5L),(-1L),(-5L),0x1318957EL,(-6L),0x91B965CBL,0x47C9AAEBL},{(-1L),0x5E1AC532L,0L,1L,0x7F6EDAADL,0x19F95013L,(-4L),(-5L)},{(-4L),0xB1C6A468L,0L,0x349FFBC5L,9L,0x1EBCDC52L,0x91B965CBL,0xCECCFD4FL},{0x7F6EDAADL,0x084E6D24L,(-1L),0x47C9AAEBL,1L,0x5E1AC532L,0x8205CC9BL,0x1EBCDC52L},{0x0FF36A2AL,1L,1L,(-6L),0x01C6BBD9L,0x5E1AC532L,0x01C6BBD9L,(-6L)},{0x91B965CBL,0x084E6D24L,0x91B965CBL,(-4L),0x509A909EL,0x1EBCDC52L,(-6L),(-8L)}},{{(-1L),0xB1C6A468L,0x01C6BBD9L,1L,0x0FF36A2AL,0x19F95013L,0x509A909EL,0x5E1AC532L},{(-1L),0x5E1AC532L,(-4L),0xCECCFD4FL,0x509A909EL,(-6L),0x8B82F0A8L,0xAEF8B975L},{0x91B965CBL,(-5L),0xF8D752CFL,0x084E6D24L,0x01C6BBD9L,0x260DB5D8L,0x7F6EDAADL,0x349FFBC5L},{0x0FF36A2AL,0xAEF8B975L,8L,0x084E6D24L,1L,0x084E6D24L,8L,0xAEF8B975L},{0x7F6EDAADL,(-1L),0x8205CC9BL,0xCECCFD4FL,0xF8D752CFL,0xB1C6A468L,(-4L),1L},{(-1L),(-6L),0x249041DEL,(-1L),9L,(-6L),(-4L),0x349FFBC5L},{0x91B965CBL,(-1L),1L,0xB1C6A468L,0x249041DEL,0x19F95013L,0x8B82F0A8L,0x47C9AAEBL},{0x249041DEL,0x19F95013L,0x8B82F0A8L,0x47C9AAEBL,8L,(-8L),9L,(-6L)}},{{0L,0x19F95013L,0x1318957EL,0xCECCFD4FL,0x1318957EL,0x19F95013L,0L,(-4L)},{0x0FF36A2AL,(-1L),(-1L),0x19F95013L,0x91B965CBL,(-6L),(-6L),1L},{0x8205CC9BL,(-6L),(-4L),0x260DB5D8L,0x91B965CBL,0xB1C6A468L,8L,0xCECCFD4FL},{0x0FF36A2AL,0L,0x7F6EDAADL,1L,0x1318957EL,0x1EBCDC52L,(-4L),0x084E6D24L},{0L,(-5L),0x0FF36A2AL,0xAEF8B975L,8L,0x084E6D24L,1L,0x084E6D24L},{0x249041DEL,1L,0x91B965CBL,1L,0x249041DEL,0x47C9AAEBL,0x7F6EDAADL,0xCECCFD4FL},{0x91B965CBL,1L,(-1L),0x260DB5D8L,9L,0xAEF8B975L,(-1L),1L},{(-1L),(-8L),(-1L),0x19F95013L,0xF8D752CFL,(-6L),0x7F6EDAADL,(-4L)}},{{9L,0x1EBCDC52L,0x91B965CBL,0xCECCFD4FL,0x0FF36A2AL,1L,1L,(-6L)},{(-4L),0x260DB5D8L,0x0FF36A2AL,0x47C9AAEBL,(-4L),1L,(-4L),0x47C9AAEBL},{0x7F6EDAADL,0x1EBCDC52L,0x7F6EDAADL,0xB1C6A468L,(-6L),(-6L),8L,0x349FFBC5L},{0x01C6BBD9L,(-8L),(-4L),(-1L),(-4L),0xAEF8B975L,(-6L),1L},{0x01C6BBD9L,1L,(-1L),(-4L),(-6L),0x47C9AAEBL,0L,(-5L)},{0x7F6EDAADL,1L,0x1318957EL,0x1EBCDC52L,(-4L),0x084E6D24L,9L,0x19F95013L},{(-4L),(-5L),0x8B82F0A8L,0x1EBCDC52L,0x0FF36A2AL,0x1EBCDC52L,0x8B82F0A8L,(-5L)},{9L,0L,1L,(-4L),0xF8D752CFL,0xB1C6A468L,(-4L),1L}}};
            int32_t *l_1658 = (void*)0;
            int i, j, k;
            for (l_1317 = 7; (l_1317 >= 0); l_1317 -= 1)
            { /* block id: 711 */
                struct S0 ***l_1558 = &g_733;
                int32_t l_1604 = (-1L);
                int32_t l_1607 = 0xEB2B283DL;
                int32_t l_1608 = 2L;
                int32_t l_1609 = 0xBAD4877FL;
                int32_t l_1610 = 0x8D7E536FL;
                int32_t l_1611 = 1L;
                int32_t l_1615 = 0x14B43489L;
                int32_t l_1616 = 0xCD1739BDL;
                int16_t l_1617 = 4L;
                int32_t l_1618[3][6][8] = {{{0xE8C37F45L,0x7AA742ACL,0x129FC3C8L,(-2L),0x39FB33A4L,0x39FB33A4L,(-2L),0x129FC3C8L},{0L,0L,0x7AA742ACL,0xD5A285BFL,0x39FB33A4L,0x6C17A8E6L,0x8376C509L,0x6C17A8E6L},{0xE8C37F45L,0x129FC3C8L,0xD5A285BFL,0x129FC3C8L,0xE8C37F45L,0x9C787BA0L,0L,0x6C17A8E6L},{0x129FC3C8L,0x39FB33A4L,0x8376C509L,0xD5A285BFL,0xD5A285BFL,0x8376C509L,0x39FB33A4L,0x129FC3C8L},{0x7AA742ACL,0x9C787BA0L,0x8376C509L,0x39FB33A4L,0x6C17A8E6L,0x8376C509L,0x6C17A8E6L,0x39FB33A4L},{0x9C787BA0L,(-2L),0x9C787BA0L,0x129FC3C8L,0x39FB33A4L,0x8376C509L,0xD5A285BFL,0xD5A285BFL}},{{0xD5A285BFL,0x7AA742ACL,0L,0L,0x7AA742ACL,0xD5A285BFL,0x39FB33A4L,0x6C17A8E6L},{0xD5A285BFL,0xE8C37F45L,0xAA4299C7L,0x7AA742ACL,0x39FB33A4L,0x7AA742ACL,0xAA4299C7L,0xE8C37F45L},{0x9C787BA0L,0xAA4299C7L,0x8376C509L,0x7AA742ACL,0x6C17A8E6L,0x129FC3C8L,0x129FC3C8L,0x6C17A8E6L},{0L,0x6C17A8E6L,0x6C17A8E6L,0L,0x9C787BA0L,0xE8C37F45L,0x129FC3C8L,0xD5A285BFL},{0xAA4299C7L,0L,0x8376C509L,0x129FC3C8L,0x8376C509L,0L,0xAA4299C7L,0x39FB33A4L},{0x8376C509L,0L,0xAA4299C7L,0x39FB33A4L,0xE8C37F45L,0xE8C37F45L,0x39FB33A4L,0xAA4299C7L}},{{0x6C17A8E6L,0x6C17A8E6L,0L,0x9C787BA0L,0xE8C37F45L,0x129FC3C8L,0xD5A285BFL,0x129FC3C8L},{0x8376C509L,0xAA4299C7L,0x9C787BA0L,0xAA4299C7L,0x8376C509L,0x7AA742ACL,0x6C17A8E6L,0x129FC3C8L},{0xAA4299C7L,0xE8C37F45L,0xD5A285BFL,0x9C787BA0L,0x9C787BA0L,0xD5A285BFL,0xE8C37F45L,0xAA4299C7L},{0L,0x7AA742ACL,0xD5A285BFL,0x39FB33A4L,0x6C17A8E6L,0x8376C509L,0x6C17A8E6L,0x39FB33A4L},{0x9C787BA0L,(-2L),0x9C787BA0L,0x129FC3C8L,0x39FB33A4L,0x8376C509L,0xD5A285BFL,0xD5A285BFL},{0xD5A285BFL,0x7AA742ACL,0L,0L,0x7AA742ACL,0xD5A285BFL,0x39FB33A4L,0x6C17A8E6L}}};
                int i, j, k;
                if (l_1225[l_1317])
                { /* block id: 712 */
                    uint32_t l_1517[9][7] = {{4294967293UL,0xBBDD89FBL,0x56E764C1L,0xF248ECD1L,0x51D19E64L,0x56E764C1L,4294967292UL},{1UL,1UL,4294967295UL,0x213B4369L,1UL,0xD76CB13CL,0x213B4369L},{0UL,0xBBDD89FBL,4294967295UL,0xF38ABA3AL,0x1A986011L,0x02DCDB82L,0x02DCDB82L},{0x1A986011L,1UL,0x56E764C1L,1UL,0x1A986011L,4294967294UL,0x51D19E64L},{0x05ED3E75L,0x02DCDB82L,0xF38ABA3AL,0x51D19E64L,1UL,1UL,0x05ED3E75L},{4294967295UL,0x05ED3E75L,1UL,1UL,0x51D19E64L,0xF38ABA3AL,0x02DCDB82L},{0x05ED3E75L,0x51D19E64L,4294967294UL,0x1A986011L,1UL,0x56E764C1L,1UL},{0x1A986011L,0x02DCDB82L,0x02DCDB82L,0x1A986011L,0xF38ABA3AL,4294967295UL,0xBBDD89FBL},{0UL,0x213B4369L,0xD76CB13CL,1UL,0x213B4369L,4294967295UL,1UL}};
                    int i, j;
                    for (l_1417 = 0; (l_1417 <= 7); l_1417 += 1)
                    { /* block id: 715 */
                        (*g_1497) = &l_1411;
                        l_1498 &= (*g_284);
                        if (p_17)
                            continue;
                    }
                    (*l_1235) = (((safe_mul_func_uint8_t_u_u(p_15, p_15)) , (safe_sub_func_int8_t_s_s((l_1518 |= (safe_add_func_uint32_t_u_u(((((l_1498 != (*g_124)) | ((safe_sub_func_uint32_t_u_u(((safe_add_func_int8_t_s_s(g_122.f0, p_17)) != (0x6EC68EDF437E0309LL < 0xC4FF1015625FAC1DLL)), (safe_div_func_uint16_t_u_u(((((safe_rshift_func_uint16_t_u_s((safe_add_func_uint32_t_u_u((safe_mul_func_int8_t_s_s((-9L), l_1467[1][1][1])), (*l_1237))), l_1422[1])) < (*g_632)) || 18446744073709551609UL) || p_17), l_1517[4][2])))) >= p_17)) < (**g_631)) && l_1427), 4L))), l_1519))) , l_1517[4][4]);
                }
                else
                { /* block id: 722 */
                    int32_t *l_1521 = &l_1411;
                    struct S0 *l_1552 = &g_1297;
                    for (l_1410 = 0; (l_1410 <= 9); l_1410 += 1)
                    { /* block id: 725 */
                        int32_t *l_1520 = &l_1317;
                        l_1521 = l_1520;
                    }
                    for (l_1427 = 1; (l_1427 >= 0); l_1427 -= 1)
                    { /* block id: 730 */
                        int16_t *l_1544 = &g_848;
                        int16_t *l_1545[1][3][4] = {{{&l_1270[0].f0,&l_1270[0].f0,(void*)0,&l_1270[0].f0},{&l_1270[0].f0,&l_1270[0].f0,&l_1270[0].f0,&l_1270[0].f0},{&l_1270[0].f0,&l_1270[0].f0,&l_1270[0].f0,&l_1270[0].f0}}};
                        int i, j, k;
                        l_1498 = ((((g_99 &= (g_66 = (l_1225[l_1317] = (((!((safe_mod_func_int32_t_s_s(((*l_1235) = (((l_1418 = (l_1518 = ((*l_1544) ^= ((safe_lshift_func_uint16_t_u_s(g_414[l_1317][l_1427], 13)) ^ (g_1527 , (!(p_17 , (safe_lshift_func_int8_t_s_u((((*g_632) = ((safe_rshift_func_int8_t_s_u(((&l_1429 == (((safe_div_func_uint8_t_u_u((safe_sub_func_int64_t_s_s(p_17, ((**l_1266) = (((((safe_div_func_int16_t_s_s((((****l_1390) = p_17) < ((safe_mod_func_uint32_t_u_u((!(safe_unary_minus_func_int64_t_s((l_1420 , (0x7DD16A5FL < (*g_124)))))), 4294967294UL)) != p_15)), p_17)) , p_15) ^ l_1498) >= 1UL) , l_1422[3])))), l_1225[l_1317])) & 0x067CC6BDL) , l_1543)) | p_17), p_15)) <= 0x9FL)) & (-8L)), 1))))))))) | 0x9A71L) || l_1518)), l_1498)) , (*l_1237))) ^ (*l_1521)) , l_1498)))) && p_17) != g_8) >= l_1422[0]);
                        return l_1546;
                    }
                    l_1498 = ((*l_1235) = (l_1422[1] = ((safe_rshift_func_int16_t_s_u(l_1549, 8)) , ((0x8C5D69378CD4D634LL && ((safe_mod_func_int64_t_s_s((((((*g_733) = p_18) != (p_16 = l_1552)) | l_1418) | ((*l_1543) = ((*l_1226) = 0xA3F037950EA05F1CLL))), (*l_1521))) , ((*l_1231) = ((**g_255) && ((safe_div_func_int32_t_s_s(0xE915E9F6L, 0xCA84E363L)) < 0x3EBC35FFB53E088ALL))))) && p_17))));
                }
                for (g_99 = 0; (g_99 <= 1); g_99 += 1)
                { /* block id: 755 */
                    int16_t l_1556 = 0x185FL;
                    struct S0 ****l_1559 = &g_732[3];
                    uint64_t * const l_1563 = &g_1564;
                    uint64_t * const *l_1562[10] = {(void*)0,(void*)0,&l_1563,(void*)0,(void*)0,&l_1563,(void*)0,&l_1563,(void*)0,&l_1563};
                    uint64_t * const **l_1561[4][2] = {{&l_1562[0],(void*)0},{&l_1562[0],&l_1562[0]},{(void*)0,&l_1562[0]},{&l_1562[0],(void*)0}};
                    uint16_t **l_1571 = &l_1233;
                    uint16_t ***l_1572[7] = {&l_1571,&l_1571,&l_1571,&l_1571,&l_1571,&l_1571,&l_1571};
                    int8_t * const l_1585[1] = {&g_974};
                    int32_t l_1605 = 0L;
                    int32_t l_1606[4][2];
                    int i, j;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 2; j++)
                            l_1606[i][j] = 0xB29F8CCBL;
                    }
                    if (((l_1574 = (l_1573[1][0] = (((g_1555 , ((l_1556 = 0x2A99L) | (((l_1557 != ((*l_1559) = l_1558)) > (*g_499)) ^ (l_1560 != (g_1565[0] = g_713))))) > (l_1570 | (0x300CAC4DL >= l_1225[l_1317]))) , l_1571))) != (void*)0))
                    { /* block id: 761 */
                        int32_t l_1584 = 9L;
                        uint8_t ** const ****l_1593 = &l_1590[4];
                        int32_t l_1594 = 3L;
                        (*l_1235) &= (safe_mod_func_uint64_t_u_u(p_15, (safe_add_func_int64_t_s_s((safe_add_func_int32_t_s_s(((l_1584 &= (&g_732[0] == ((++(*g_765)) , l_1583))) < ((void*)0 == l_1585[0])), ((safe_div_func_uint32_t_u_u((&p_15 == ((safe_sub_func_int8_t_s_s((((*g_252) == ((((*l_1593) = l_1590[6]) != (void*)0) == l_1225[l_1317])) ^ l_1594), 0x82L)) , l_1595)), l_1270[0].f0)) < p_17))), g_974))));
                    }
                    else
                    { /* block id: 766 */
                        int32_t *l_1596 = &l_1422[1];
                        int32_t *l_1597 = &l_1498;
                        int32_t *l_1598 = &l_1225[6];
                        int32_t *l_1599 = &l_1498;
                        int32_t l_1600 = 1L;
                        int32_t *l_1601 = &l_1418;
                        int32_t *l_1602 = &l_1225[2];
                        int32_t *l_1603[1][8][3];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 8; j++)
                            {
                                for (k = 0; k < 3; k++)
                                    l_1603[i][j][k] = &l_1422[1];
                            }
                        }
                        ++l_1619[5][4];
                        if (p_15)
                            continue;
                        (*l_1597) = p_15;
                    }
                }
            }
            if (p_17)
            { /* block id: 773 */
                for (g_148 = 0; (g_148 > 31); g_148 = safe_add_func_uint8_t_u_u(g_148, 9))
                { /* block id: 776 */
                    union U1 **l_1624 = (void*)0;
                    if (p_17)
                        break;
                    (*g_1625) = &g_122;
                }
            }
            else
            { /* block id: 780 */
                int16_t *l_1643 = &l_1257.f0;
                uint8_t ****l_1651 = &g_863[1][4];
                int32_t *l_1668 = (void*)0;
                if (((((safe_sub_func_int16_t_s_s(((safe_add_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((((*l_1643) = ((safe_rshift_func_uint16_t_u_u((l_1546 , (((*l_1226) = (((~0x55D3L) < l_1636) || p_15)) >= ((*l_1543)--))), (+(safe_lshift_func_int16_t_s_s((l_1642 , (p_15 || ((**g_498) | (*l_1235)))), p_15))))) != 0xC2L)) && (*g_499)), p_17)), (-1L))) >= p_15), 0x1B4AL)) < g_99) , (*g_498)) != &g_354[1]))
                { /* block id: 784 */
                    uint8_t *****l_1652 = &g_1392[1][2];
                    int32_t l_1654 = 0x0E84D8C9L;
                    (*l_1235) = ((safe_sub_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u(p_15, ((*l_1643) = (safe_lshift_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(((((((void*)0 == p_18) == ((((((void*)0 == &g_498) , l_1651) == (g_1653 = ((*l_1652) = l_1254))) < 0L) || p_17)) ^ 1UL) , 0UL) == 0L))), l_1654))))) && (-1L)), p_15)) , l_1655);
                }
                else
                { /* block id: 789 */
                    int32_t *l_1656 = &l_1417;
                    int32_t **l_1657[5];
                    uint64_t * const **l_1669 = &g_1565[1];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1657[i] = &l_1237;
                    l_1658 = l_1656;
                    for (l_1232 = (-2); (l_1232 == 26); l_1232 = safe_add_func_int32_t_s_s(l_1232, 1))
                    { /* block id: 793 */
                        (*l_1235) ^= ((*l_1658) = (0x1AA1L < 0x51ECL));
                        (*l_1658) |= (l_1317 = (((p_15 && 0x460D0971216274C2LL) , p_15) >= (((**g_498) != p_15) >= 0x00AE663688D59996LL)));
                        l_1422[1] ^= (((p_17 == (safe_sub_func_uint64_t_u_u((((g_1663 , l_1664) > (safe_rshift_func_uint16_t_u_s((&g_631 == l_1667), (((*l_1656) , &g_1566[0][1]) == l_1560)))) | 9L), (*l_1237)))) != 0xA0FFA42547739347LL) ^ 0x02F35E9CL);
                    }
                    l_1668 = ((*g_1259) = &l_1317);
                    (*l_1669) = &g_1566[0][0];
                }
            }
            (*l_1237) |= ((*l_1557) == (void*)0);
        }
        else
        { /* block id: 806 */
            const union U1 *l_1671 = &g_122;
            union U1 *l_1672 = &l_1642;
            union U1 **l_1673 = &l_1672;
            int32_t l_1677 = 0x27B0CBE9L;
            int32_t l_1682 = 0xE549F78CL;
            int32_t l_1685 = 0x3E1C34A3L;
            int32_t l_1686 = 0xC3A01CFFL;
            int32_t *l_1691[5];
            uint64_t **l_1711 = (void*)0;
            int i;
            for (i = 0; i < 5; i++)
                l_1691[i] = &l_1420;
            if (((((0x6DL >= (*l_1235)) & p_15) & (((**l_1560) &= (+(l_1671 == ((*l_1673) = l_1672)))) & ((**g_1625) , l_1317))) , (((*l_1667) = l_1393) != (void*)0)))
            { /* block id: 810 */
                (*l_1235) ^= ((0x8DL != ((((safe_lshift_func_int16_t_s_u(((**l_1673) , 0x4DBCL), ((p_17 ^ (~l_1677)) , 0xB804L))) && (0xE8L || ((l_1678 <= ((p_15 | p_17) != p_17)) != 1L))) | p_17) & l_1422[1])) == (*g_499));
                (*l_1237) = p_17;
            }
            else
            { /* block id: 813 */
                int32_t *l_1679 = &l_1422[1];
                int32_t *l_1683 = &l_1422[1];
                int32_t *l_1684[2];
                uint8_t l_1687 = 1UL;
                int i;
                for (i = 0; i < 2; i++)
                    l_1684[i] = &g_101;
                (*g_1681) = l_1679;
                --l_1687;
            }
            for (g_8 = 0; (g_8 <= 1); g_8 += 1)
            { /* block id: 819 */
                uint64_t ***l_1710 = &g_713;
                int32_t l_1717 = (-7L);
                (*g_1260) = &l_1682;
                l_1691[0] = (l_1690 , &l_1685);
                for (g_66 = 1; (g_66 >= 0); g_66 -= 1)
                { /* block id: 824 */
                    int8_t l_1714 = 0x3AL;
                    int16_t *l_1718[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1718[i] = &l_1270[0].f0;
                    (*g_105) ^= (safe_lshift_func_uint16_t_u_s(65535UL, (safe_lshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(((0L && ((safe_mul_func_uint16_t_u_u(((*l_1233) |= ((safe_mul_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((**g_631), (safe_div_func_int16_t_s_s(((*g_252) &= (l_1422[0] = (safe_sub_func_uint32_t_u_u((((**l_1266) = ((void*)0 != l_1710)) | (l_1711 != ((*l_1710) = g_713))), ((((safe_div_func_uint64_t_u_u(((l_1714 && (safe_lshift_func_uint8_t_u_u(l_1717, p_17))) == p_15), p_15)) , l_1714) <= p_17) , 0x6E04C0A3L))))), p_17)))), 65535UL)) | 9UL)), p_17)) <= l_1275)) > l_1719), 6L)), p_17))));
                    for (l_1519 = 0; (l_1519 <= 1); l_1519 += 1)
                    { /* block id: 833 */
                        const int32_t * const l_1720 = &l_1422[1];
                        const int32_t *l_1722[1];
                        const int32_t **l_1721[3];
                        const int32_t **l_1723 = &l_1722[0];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1722[i] = (void*)0;
                        for (i = 0; i < 3; i++)
                            l_1721[i] = &l_1722[0];
                        (*l_1723) = l_1720;
                        (*l_1723) = &l_1717;
                        if (l_1714)
                            continue;
                    }
                    l_1422[1] = (g_1724 , (**g_1681));
                    if (l_1717)
                        break;
                }
            }
            (*l_1237) = (-1L);
        }
    }
    (*l_1725) = &l_1225[3];
    return (**g_1625);
}


/* ------------------------------------------ */
/* 
 * reads : g_73 g_188 g_101 g_765 g_232 g_354 g_764 g_259
 * writes: g_73 g_101
 */
static uint64_t  func_21(int32_t  p_22)
{ /* block id: 601 */
    int16_t l_1203[3][10][7] = {{{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L}},{{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L}},{{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L},{0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL,0x3CAAL},{0x1636L,4L,0x1636L,4L,0x1636L,4L,0x1636L},{0x34F5L,0x34F5L,0x3CAAL,0x3CAAL,0x34F5L,0x34F5L,0x3CAAL},{0L,4L,0L,4L,0L,4L,0L}}};
    int32_t *l_1208 = &g_73;
    int16_t * const l_1211 = &g_773;
    int32_t *l_1212 = &g_101;
    int32_t l_1213[8][8] = {{0x0026597DL,0x8DF33216L,0xF528F48FL,0xF528F48FL,0x8DF33216L,0x0026597DL,5L,0x05F86379L},{0x0026597DL,0xC2D4B21EL,(-4L),0x8DF33216L,5L,0x8DF33216L,(-4L),0xC2D4B21EL},{8L,(-4L),0xDDE2899BL,0x8DF33216L,0x05F86379L,6L,6L,0x05F86379L},{0xF528F48FL,0x05F86379L,0x05F86379L,0xF528F48FL,8L,0xC2D4B21EL,6L,0x0026597DL},{(-4L),0xF528F48FL,0xDDE2899BL,6L,0xDDE2899BL,0xF528F48FL,(-4L),5L},{0xDDE2899BL,0xF528F48FL,(-4L),5L,0xC2D4B21EL,0xC2D4B21EL,5L,(-4L)},{0x05F86379L,0x05F86379L,0xF528F48FL,8L,0xC2D4B21EL,6L,0x0026597DL,6L},{0xDDE2899BL,(-4L),8L,(-4L),0xDDE2899BL,0x8DF33216L,0x05F86379L,6L}};
    int i, j, k;
    l_1213[5][7] ^= (l_1203[2][5][0] >= (safe_add_func_int32_t_s_s(((*l_1212) = ((1UL > l_1203[2][5][0]) , ((((safe_sub_func_uint32_t_u_u((((*l_1208) &= p_22) == (*g_188)), ((safe_rshift_func_uint16_t_u_u(((p_22 , l_1211) != (((249UL > (*g_765)) == p_22) , &g_848)), g_354[0])) == 1UL))) || (**g_764)) != p_22) , (*l_1208)))), g_259[8][8][1])));
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_214 g_284 g_73 g_101 g_124 g_733 g_122.f0 g_631 g_632 g_835 g_1045 g_255 g_256 g_507 g_252 g_188 g_308 g_773 g_414 g_47 g_1188 g_257 g_1195 g_119 g_232 g_765 g_354 g_347 g_1072 g_560
 * writes: g_214 g_101 g_73 g_47 g_122.f0 g_632 g_308 g_284 g_773 g_1106 g_1072 g_974 g_599 g_560 g_66
 */
static int16_t  func_25(uint8_t  p_26, const struct S0 * const  p_27, int64_t  p_28, int8_t  p_29)
{ /* block id: 492 */
    int32_t ** const l_1026 = &g_284;
    int32_t l_1063 = 0L;
    int32_t l_1065 = 1L;
    int32_t l_1066 = (-2L);
    int32_t l_1068[7];
    uint32_t l_1078 = 0x03563E0EL;
    struct S0 **l_1088 = &g_47;
    uint32_t * const l_1098 = &g_119[3][7];
    int32_t l_1101 = 3L;
    int8_t l_1124 = 1L;
    int i;
    for (i = 0; i < 7; i++)
        l_1068[i] = 0xF9B031ADL;
    for (g_214 = 1; (g_214 <= 5); g_214 += 1)
    { /* block id: 495 */
        int32_t *l_1023 = &g_73;
        (*l_1023) |= ((*g_284) = (-1L));
    }
    if ((safe_lshift_func_int16_t_s_u((p_28 , (((void*)0 == l_1026) & (**l_1026))), 15)))
    { /* block id: 499 */
        struct S0 *l_1027 = (void*)0;
        struct S0 ***l_1030 = &g_733;
        struct S0 *l_1034 = &g_835[5][0];
        struct S0 ** const l_1033 = &l_1034;
        struct S0 ** const *l_1032 = &l_1033;
        const union U1 *l_1049 = &g_122;
        const union U1 **l_1048 = &l_1049;
        int32_t l_1053 = (-1L);
        int16_t l_1055 = 6L;
        int32_t l_1061 = 1L;
        int32_t l_1064[5][2][7] = {{{1L,(-5L),0L,1L,0xA910E3BBL,1L,(-5L)},{0x2B51CC7DL,0x5D4DB284L,1L,1L,1L,0x5D4DB284L,0x2B51CC7DL}},{{0x5D4DB284L,(-5L),1L,1L,0x2B51CC7DL,0x5D4DB284L,1L},{1L,0xA910E3BBL,1L,(-5L),(-5L),1L,0xA910E3BBL}},{{(-5L),0x9B916DE9L,1L,1L,0x9B916DE9L,1L,0xA910E3BBL},{1L,(-5L),1L,1L,0xA910E3BBL,1L,1L}},{{0x2B51CC7DL,0x2B51CC7DL,0L,1L,(-5L),0xBAADA92CL,0x2B51CC7DL},{0x2B51CC7DL,1L,1L,(-5L),0x5D4DB284L,0x5D4DB284L,(-5L)}},{{1L,0xA910E3BBL,1L,1L,(-5L),1L,0x9B916DE9L},{(-5L),0xA910E3BBL,(-6L),1L,0xA910E3BBL,0L,0xA910E3BBL}}};
        int i, j, k;
        (*g_124) |= 0xAB11DA29L;
        (*g_733) = l_1027;
        for (g_122.f0 = (-7); (g_122.f0 != 20); ++g_122.f0)
        { /* block id: 504 */
            struct S0 ****l_1031 = &l_1030;
            int32_t l_1050 = 0xFB0993CAL;
            int32_t l_1062 = 0x7A7BEF2AL;
            int32_t l_1067 = 0L;
            int32_t l_1069 = 0xCFD2EADCL;
            int32_t l_1077 = (-1L);
            if ((((*l_1031) = l_1030) != (l_1032 = &g_733)))
            { /* block id: 507 */
                uint64_t *l_1051 = (void*)0;
                uint64_t *l_1052[2];
                uint32_t *l_1054 = &g_217;
                int32_t *l_1056 = &g_101;
                int32_t *l_1057 = &l_1053;
                int32_t *l_1058 = &l_1053;
                int32_t *l_1059 = &g_73;
                int32_t *l_1060[5] = {&g_73,&g_73,&g_73,&g_73,&g_73};
                int32_t l_1076 = 0x96913762L;
                int i;
                for (i = 0; i < 2; i++)
                    l_1052[i] = &g_599[0];
                (*g_284) = ((((safe_add_func_int8_t_s_s(((1L | (safe_rshift_func_int16_t_s_u((((*g_631) = (*g_631)) != ((safe_div_func_int32_t_s_s((**l_1026), (safe_div_func_uint16_t_u_u(((l_1053 = ((*l_1034) , (((safe_mul_func_int8_t_s_s((g_1045 , (safe_add_func_uint32_t_u_u((**l_1026), ((((&p_28 != (*g_255)) , g_507) == l_1048) <= (-6L))))), p_26)) > p_26) , l_1050))) != p_28), 0xCDB2L)))) , l_1054)), 5))) == 0x84L), 1L)) , (*g_252)) == p_29) >= l_1055);
                --l_1078;
            }
            else
            { /* block id: 512 */
                int32_t *l_1081[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint32_t l_1082 = 6UL;
                union U1 *l_1085 = &g_122;
                int i;
                l_1082++;
                (*l_1048) = l_1085;
                return l_1061;
            }
            l_1053 |= (safe_add_func_uint16_t_u_u((&p_27 == l_1088), ((safe_add_func_uint8_t_u_u(((*g_188) && p_28), (p_28 ^ (**l_1026)))) == l_1062)));
            return p_29;
        }
    }
    else
    { /* block id: 520 */
        uint32_t l_1095[5][6][8] = {{{0xBD37318DL,0UL,0x0AE4955AL,4294967295UL,0xC7087C56L,0xD41D21C1L,4294967288UL,0x4C1AF304L},{4294967286UL,3UL,0x7D58B570L,0UL,0xBD37318DL,4294967295UL,0xE34BD237L,0x3CFEC9D4L},{0x7D58B570L,4294967295UL,0x4C1AF304L,0xA448AE6FL,1UL,0x605A5B8FL,0UL,1UL},{0xED5AF955L,0UL,2UL,4294967295UL,0x29CCE6F0L,0xACE75569L,0x76B5E3DFL,0x76B5E3DFL},{0xDDB2C642L,0UL,4294967295UL,4294967295UL,0UL,0xDDB2C642L,4294967295UL,0x1A0ECA69L},{0x15F977D1L,0x7D58B570L,1UL,2UL,0xEB6D13C0L,1UL,0x94EB5A87L,1UL}},{{0UL,0xEBEB8A3BL,0UL,2UL,4UL,1UL,4294967288UL,0x1A0ECA69L},{0xD881536EL,4UL,4294967286UL,4294967295UL,0x051090CCL,0xED6CE14DL,0x9393DF0EL,0x76B5E3DFL},{2UL,0UL,0x82E2940DL,4294967295UL,2UL,0x94EB5A87L,4294967295UL,1UL},{4294967295UL,0x73BF6F6CL,0xED6CE14DL,0xA448AE6FL,2UL,4UL,4294967295UL,0x3CFEC9D4L},{0xA5C90D5BL,0xFDB85C79L,0x878DBB5DL,0UL,3UL,4294967295UL,0xED6CE14DL,0x4C1AF304L},{0xFD6FCB4AL,1UL,2UL,0x1D4F6BC4L,1UL,0x4C1AF304L,0xEB6D13C0L,4294967295UL}},{{0x22D74EAEL,4294967291UL,0x4E019A94L,1UL,0UL,0UL,4294967295UL,1UL},{2UL,4294967291UL,0x8916D995L,0UL,0xE32FA97EL,0xED4CE0D2L,0x7D58B570L,0UL},{0x94EB5A87L,0x3CFEC9D4L,0x26BC4E9BL,4294967295UL,0x43ADC7B8L,0UL,0xDDB2C642L,0xA448AE6FL},{0x80266BF3L,9UL,0x73BF6F6CL,3UL,9UL,4294967289UL,1UL,4294967291UL},{4294967295UL,0xBD37318DL,0xC7087C56L,0UL,0UL,2UL,1UL,7UL},{4294967295UL,0xCAA49973L,1UL,4UL,0x94EB5A87L,1UL,0x22D74EAEL,0x878DBB5DL}},{{0x015F6217L,0xB84D26A9L,0xED4CE0D2L,0x66FAD415L,0xED4CE0D2L,0xB84D26A9L,0x015F6217L,0x94EB5A87L},{0x9C32DC7EL,1UL,0UL,0x4C1AF304L,0xDDB2C642L,0x7DA02CB2L,0xFDB85C79L,0xED5AF955L},{0x384864AAL,0x8916D995L,1UL,0xBD37318DL,0xDDB2C642L,3UL,0x6EB3490BL,0x66FAD415L},{0x9C32DC7EL,0x9AF0F2EEL,4294967295UL,0xED5AF955L,0xED4CE0D2L,0UL,0x26BC4E9BL,1UL},{0x015F6217L,0x1D4F6BC4L,0x8E222E15L,2UL,0x94EB5A87L,0UL,1UL,0xC7087C56L},{4294967295UL,0xD881536EL,0x9393DF0EL,4294967295UL,0UL,0xA448AE6FL,0x051090CCL,0xB84D26A9L}},{{4294967295UL,0x29D622C7L,1UL,0x0AE4955AL,9UL,0xEBEB8A3BL,0xE34BD237L,0xDDB2C642L},{0xE34BD237L,0UL,0xD41D21C1L,0x4C1AF304L,0xED6CE14DL,4294967295UL,3UL,0UL},{0x22D74EAEL,2UL,0x9393DF0EL,0x488053F7L,0xA5C90D5BL,0x29D622C7L,0x29CCE6F0L,1UL},{1UL,1UL,0xE34BD237L,4294967295UL,0x9C32DC7EL,0x1E77ACBBL,0x8E222E15L,4294967295UL},{0x66FAD415L,0x15F977D1L,1UL,0x8916D995L,0UL,4294967295UL,0UL,1UL},{0x3CFEC9D4L,7UL,0UL,0x22D74EAEL,0x29D622C7L,0x15F977D1L,0UL,1UL}}};
        int32_t l_1099 = 0x2C32DEB3L;
        int16_t *l_1105 = (void*)0;
        int16_t **l_1104[1];
        int32_t l_1108 = 1L;
        uint16_t l_1110 = 4UL;
        uint64_t *l_1119 = &g_214;
        int32_t l_1128 = (-6L);
        int32_t l_1129 = (-3L);
        int32_t l_1131[7];
        uint32_t l_1177[7][1] = {{18446744073709551615UL},{0x36360DA2L},{18446744073709551615UL},{0x36360DA2L},{18446744073709551615UL},{0x36360DA2L},{18446744073709551615UL}};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1104[i] = &l_1105;
        for (i = 0; i < 7; i++)
            l_1131[i] = 7L;
        for (g_308 = (-14); (g_308 == 14); g_308 = safe_add_func_int8_t_s_s(g_308, 5))
        { /* block id: 523 */
            uint32_t *l_1097 = &l_1095[2][2][6];
            uint32_t **l_1096 = &l_1097;
            int32_t *l_1100 = &l_1068[0];
            l_1099 = (((safe_sub_func_int32_t_s_s(p_26, l_1095[1][0][2])) <= 0xFDL) | (((*l_1096) = ((*g_631) = (*g_631))) != l_1098));
            l_1100 = (*l_1026);
        }
        if (l_1101)
        { /* block id: 529 */
lbl_1141:
            (*l_1026) = &l_1099;
            for (g_773 = 0; (g_773 < 8); g_773 = safe_add_func_int32_t_s_s(g_773, 1))
            { /* block id: 533 */
                g_1106 = l_1104[0];
            }
        }
        else
        { /* block id: 536 */
            int32_t *l_1109[5];
            int16_t **l_1114 = (void*)0;
            uint16_t *l_1191 = &l_1110;
            int i;
            for (i = 0; i < 5; i++)
                l_1109[i] = &l_1065;
            l_1110++;
lbl_1149:
            if (p_29)
            { /* block id: 538 */
                uint32_t l_1113 = 4294967291UL;
                int32_t l_1127 = 6L;
                int32_t l_1132 = (-7L);
                int16_t l_1133[6][7] = {{1L,0x7B2BL,0L,1L,0L,0x7B2BL,1L},{1L,1L,0x7B2BL,0L,1L,0L,0x7B2BL},{1L,1L,0x2B4CL,0xADBEL,0xDF5CL,0x2B4CL,0xDF5CL},{0xADBEL,0x7B2BL,0x7B2BL,0xADBEL,0L,1L,0xADBEL},{1L,0xDF5CL,0L,0L,0xDF5CL,1L,0x7B2BL},{0xDF5CL,0xADBEL,0x2B4CL,1L,1L,0x2B4CL,0xADBEL}};
                int32_t l_1134 = 0x0D70FE7AL;
                int32_t l_1136 = (-1L);
                int32_t l_1137 = (-2L);
                uint32_t l_1138 = 18446744073709551610UL;
                int i, j;
                (*g_284) = (l_1113 != ((l_1114 != (void*)0) >= l_1095[1][0][2]));
                for (g_1072 = 0; (g_1072 < (-28)); g_1072 = safe_sub_func_uint8_t_u_u(g_1072, 2))
                { /* block id: 542 */
                    int32_t **l_1118 = &l_1109[1];
                    int32_t ***l_1117 = &l_1118;
                    int8_t *l_1123[4][8][6] = {{{&g_1072,&g_563,&g_1072,&g_219,(void*)0,(void*)0},{&g_563,&g_974,&g_974,&g_563,&g_308,(void*)0},{&g_563,&g_974,&g_1072,(void*)0,&g_219,&g_308},{&g_308,&g_1072,&g_563,&g_563,&g_563,(void*)0},{&g_974,&g_219,&g_563,&g_1072,&g_1072,&g_974},{&g_219,&g_563,&g_974,&g_219,&g_974,(void*)0},{&g_563,(void*)0,(void*)0,&g_219,(void*)0,&g_219},{&g_1072,&g_1072,&g_1072,&g_308,&g_563,&g_563}},{{&g_219,&g_1072,&g_308,&g_308,&g_219,&g_219},{&g_974,&g_974,&g_308,&g_974,&g_219,&g_308},{(void*)0,&g_308,&g_219,&g_219,&g_563,&g_308},{(void*)0,&g_974,&g_563,&g_563,(void*)0,(void*)0},{(void*)0,&g_563,&g_219,&g_563,&g_308,&g_1072},{(void*)0,&g_219,&g_1072,&g_219,(void*)0,&g_974},{(void*)0,(void*)0,&g_219,&g_219,(void*)0,(void*)0},{&g_308,(void*)0,&g_563,&g_308,&g_219,&g_1072}},{{&g_308,(void*)0,&g_1072,&g_563,&g_974,(void*)0},{&g_563,&g_563,&g_563,&g_219,&g_219,&g_308},{&g_308,&g_563,&g_219,&g_219,&g_308,(void*)0},{&g_563,(void*)0,(void*)0,&g_974,&g_563,&g_308},{&g_219,&g_563,&g_974,(void*)0,(void*)0,(void*)0},{&g_563,&g_219,&g_974,&g_219,&g_308,&g_974},{&g_308,&g_974,&g_563,&g_974,&g_563,&g_563},{(void*)0,&g_219,&g_974,&g_219,&g_1072,&g_219}},{{&g_563,&g_563,&g_563,&g_308,&g_219,&g_219},{&g_563,&g_563,(void*)0,(void*)0,&g_974,&g_563},{&g_308,(void*)0,&g_563,&g_974,&g_563,&g_308},{&g_308,&g_563,&g_308,&g_974,(void*)0,(void*)0},{&g_974,&g_308,&g_563,&g_974,&g_308,&g_563},{&g_219,&g_308,&g_974,&g_308,&g_974,&g_308},{&g_563,(void*)0,(void*)0,&g_974,&g_974,&g_219},{&g_308,&g_563,(void*)0,&g_308,&g_974,(void*)0}}};
                    int32_t l_1130 = 0xE2B7449CL;
                    int32_t l_1135[1][9] = {{(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)}};
                    int i, j, k;
                    (**l_1026) = ((((0L || (((*l_1117) = &g_284) == (void*)0)) ^ (((((void*)0 != l_1119) <= (safe_mod_func_uint16_t_u_u(((*g_124) && p_28), ((~((p_28 & ((p_29 = (((((p_26 ^ g_773) < p_28) < p_28) , g_414[5][1]) || p_29)) <= p_26)) , l_1124)) , p_29)))) > p_28) < 6L)) | p_26) ^ p_26);
                    if (p_28)
                    { /* block id: 546 */
                        int32_t **l_1125 = &l_1109[1];
                        (*l_1125) = ((*l_1026) = &l_1099);
                    }
                    else
                    { /* block id: 549 */
                        uint8_t l_1126 = 255UL;
                        return l_1126;
                    }
                    --l_1138;
                }
            }
            else
            { /* block id: 554 */
                uint32_t l_1144 = 0UL;
                if (g_122.f0)
                    goto lbl_1141;
                for (l_1065 = 0; (l_1065 >= (-19)); l_1065--)
                { /* block id: 558 */
                    for (g_974 = 0; g_974 < 1; g_974 += 1)
                    {
                        g_599[g_974] = 0xA71D1C73F24F6604LL;
                    }
                    for (l_1124 = 0; (l_1124 <= 1); l_1124 += 1)
                    { /* block id: 562 */
                        int i, j;
                        (*g_733) = (*l_1088);
                        ++l_1144;
                        return g_414[(l_1124 + 3)][l_1124];
                    }
                }
            }
            for (g_560 = 23; (g_560 < 3); g_560--)
            { /* block id: 571 */
                int32_t l_1154 = 0xA93F4FE8L;
                int32_t l_1156 = 0xFCB55158L;
                int32_t l_1160 = 0xEFD2525EL;
                int32_t l_1166[9] = {8L,(-3L),8L,(-3L),8L,(-3L),8L,(-3L),8L};
                int i;
                if (g_214)
                    goto lbl_1149;
                if (p_29)
                    break;
                for (g_214 = 0; (g_214 == 10); ++g_214)
                { /* block id: 576 */
                    int32_t *l_1155 = &l_1101;
                    int32_t l_1162 = 0xFBE43F28L;
                    int32_t l_1163 = 0xFF3DC568L;
                    int32_t l_1164 = 0x0EE41D8FL;
                    int32_t l_1165 = (-1L);
                    int32_t l_1167 = 0xDBD9B180L;
                    int32_t l_1169 = 0x7C78FF79L;
                    int32_t l_1171[1][1];
                    int32_t l_1172 = 0x2919FDD6L;
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_1171[i][j] = 0xF4F5240BL;
                    }
                    for (g_66 = 0; (g_66 == (-2)); g_66--)
                    { /* block id: 579 */
                        return l_1154;
                    }
                    for (g_122.f0 = 0; (g_122.f0 <= 2); g_122.f0 += 1)
                    { /* block id: 584 */
                        int64_t l_1157[9];
                        int32_t l_1158 = 0x86E0152DL;
                        int32_t l_1159 = 0xA0816518L;
                        int32_t l_1161 = 1L;
                        int32_t l_1168 = 0x66580F15L;
                        int32_t l_1170 = 0x93E0EC3AL;
                        int32_t l_1173 = 0xB6918584L;
                        int32_t l_1174 = 6L;
                        int32_t l_1175 = 7L;
                        int32_t l_1176 = 0x82EE6ED8L;
                        int i;
                        for (i = 0; i < 9; i++)
                            l_1157[i] = 0x96786CDB7907A6BFLL;
                        (*l_1026) = l_1155;
                        --l_1177[2][0];
                    }
                    (*g_284) |= (+0x541B27CCL);
                    (**l_1026) = (~(safe_div_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((safe_sub_func_int8_t_s_s(((((p_29 , g_1188) , (safe_lshift_func_uint16_t_u_s(((*g_256) , (l_1191 != ((safe_sub_func_int8_t_s_s((!(g_1195 != (void*)0)), ((((safe_mul_func_int16_t_s_s((~((((safe_mod_func_uint16_t_u_u((p_29 == 2L), 0x1053L)) ^ g_73) <= (*g_632)) || l_1129)), p_26)) != p_28) || 0x92L) ^ g_232[5]))) , (void*)0))), 10))) ^ p_29) , 0x36L), (*g_765))) <= g_354[0]), 4L)), g_347[4])));
                }
                l_1066 = ((l_1131[0] = (l_1068[5] ^= (l_1063 = ((*g_284) |= p_26)))) && ((p_28 > (**g_255)) <= 0x01D5L));
            }
        }
        return p_26;
    }
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_563 g_66 g_732 g_119 g_97 g_232 g_631 g_632 g_308 g_345 g_347 g_756 g_219 g_259 g_105 g_73 g_252 g_284 g_122.f0 g_170 g_764 g_506 g_81 g_778 g_814 g_99 g_835 g_101 g_848 g_499 g_500 g_863 g_256 g_257 g_733 g_47 g_48 g_122 g_498 g_255 g_582 g_115.f1 g_864 g_765 g_124 g_925 g_773 g_406 g_974 g_977 g_217 g_414 g_148 g_1022
 * writes: g_563 g_66 g_732 g_308 g_97 g_347 g_560 g_73 g_599 g_219 g_122.f0 g_101 g_99 g_506 g_345 g_773 g_778 g_814 g_354 g_848 g_217 g_406 g_119 g_47 g_232 g_148 g_105
 */
static uint64_t  func_32(union U1  p_33, struct S0 * p_34, uint32_t  p_35)
{ /* block id: 317 */
    uint64_t l_760[9][3][8] = {{{7UL,2UL,0x856D2AF94C7072A9LL,18446744073709551615UL,0x54D532B7250F7056LL,0x856D2AF94C7072A9LL,0x671F5F075EE0C0AFLL,0x3D2B2564EF7D8969LL},{7UL,0x671F5F075EE0C0AFLL,0xEDED18D0BE9114DBLL,18446744073709551615UL,18446744073709551615UL,0xEDED18D0BE9114DBLL,0x671F5F075EE0C0AFLL,7UL},{0x3D2B2564EF7D8969LL,0x671F5F075EE0C0AFLL,0x856D2AF94C7072A9LL,0x54D532B7250F7056LL,18446744073709551615UL,0x856D2AF94C7072A9LL,2UL,7UL}},{{7UL,2UL,0x856D2AF94C7072A9LL,18446744073709551615UL,0x54D532B7250F7056LL,0x856D2AF94C7072A9LL,0x671F5F075EE0C0AFLL,0x3D2B2564EF7D8969LL},{7UL,0x671F5F075EE0C0AFLL,0xEDED18D0BE9114DBLL,18446744073709551615UL,18446744073709551615UL,0xEDED18D0BE9114DBLL,0x671F5F075EE0C0AFLL,7UL},{0x3D2B2564EF7D8969LL,0x671F5F075EE0C0AFLL,0x856D2AF94C7072A9LL,0x54D532B7250F7056LL,18446744073709551615UL,0x856D2AF94C7072A9LL,2UL,7UL}},{{7UL,2UL,0x856D2AF94C7072A9LL,18446744073709551615UL,0x54D532B7250F7056LL,0x856D2AF94C7072A9LL,0x671F5F075EE0C0AFLL,0x3D2B2564EF7D8969LL},{7UL,0x671F5F075EE0C0AFLL,0xEDED18D0BE9114DBLL,18446744073709551615UL,18446744073709551615UL,0xEDED18D0BE9114DBLL,0x671F5F075EE0C0AFLL,7UL},{0x3D2B2564EF7D8969LL,0x671F5F075EE0C0AFLL,0x856D2AF94C7072A9LL,0x54D532B7250F7056LL,18446744073709551615UL,0x856D2AF94C7072A9LL,2UL,7UL}},{{7UL,2UL,0x856D2AF94C7072A9LL,18446744073709551615UL,0x54D532B7250F7056LL,0x856D2AF94C7072A9LL,0x671F5F075EE0C0AFLL,0x3D2B2564EF7D8969LL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}},{{0x3D2B2564EF7D8969LL,0xEDBC97B9E7E80357LL,0xEDED18D0BE9114DBLL,0x54D532B7250F7056LL,18446744073709551613UL,0xEDED18D0BE9114DBLL,2UL,18446744073709551614UL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}},{{0x3D2B2564EF7D8969LL,0xEDBC97B9E7E80357LL,0xEDED18D0BE9114DBLL,0x54D532B7250F7056LL,18446744073709551613UL,0xEDED18D0BE9114DBLL,2UL,18446744073709551614UL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}},{{0x3D2B2564EF7D8969LL,0xEDBC97B9E7E80357LL,0xEDED18D0BE9114DBLL,0x54D532B7250F7056LL,18446744073709551613UL,0xEDED18D0BE9114DBLL,2UL,18446744073709551614UL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}},{{0x3D2B2564EF7D8969LL,0xEDBC97B9E7E80357LL,0xEDED18D0BE9114DBLL,0x54D532B7250F7056LL,18446744073709551613UL,0xEDED18D0BE9114DBLL,2UL,18446744073709551614UL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}},{{0x3D2B2564EF7D8969LL,0xEDBC97B9E7E80357LL,0xEDED18D0BE9114DBLL,0x54D532B7250F7056LL,18446744073709551613UL,0xEDED18D0BE9114DBLL,2UL,18446744073709551614UL},{0x3D2B2564EF7D8969LL,2UL,0UL,0x54D532B7250F7056LL,0x54D532B7250F7056LL,0UL,2UL,0x3D2B2564EF7D8969LL},{18446744073709551614UL,2UL,0xEDED18D0BE9114DBLL,18446744073709551613UL,0x54D532B7250F7056LL,0xEDED18D0BE9114DBLL,0xEDBC97B9E7E80357LL,0x3D2B2564EF7D8969LL}}};
    int32_t l_805 = (-3L);
    int32_t l_813 = 0x309517D6L;
    struct S0 ***l_836 = &g_733;
    uint32_t * const *l_870[6] = {&g_632,&g_632,&g_632,&g_632,&g_632,&g_632};
    uint32_t * const **l_869 = &l_870[1];
    uint8_t * const *l_907 = &g_765;
    uint8_t **l_910 = &g_765;
    int32_t l_928 = 2L;
    int32_t *l_934[10] = {&g_73,&l_928,&l_928,&g_73,&l_928,&l_928,&g_73,&l_928,&l_928,&g_73};
    int8_t l_1015 = 0L;
    int32_t **l_1021 = (void*)0;
    int i, j, k;
    for (g_563 = 3; (g_563 >= 0); g_563 -= 1)
    { /* block id: 320 */
        uint16_t l_729 = 7UL;
        int32_t *l_735 = (void*)0;
        int32_t l_802[6][7][4] = {{{1L,0x43B79961L,0x04E7679AL,0x54608FB0L},{0xF4E975CCL,(-9L),0xEB78E20DL,0L},{1L,0x04E7679AL,0L,1L},{1L,0L,0x54608FB0L,0x98256512L},{1L,1L,0L,0L},{0x43B79961L,0x86DC2684L,0x98256512L,0x88819643L},{0x33F406E2L,1L,0x33F406E2L,0x98256512L}},{{1L,0xBC7559EFL,0x1C2BBDEFL,0x9E218B16L},{1L,0x04E7679AL,0L,0xBC7559EFL},{0L,1L,0L,7L},{0x04E7679AL,0x98256512L,0x9E218B16L,0xAB10B01EL},{0x54608FB0L,6L,(-1L),0xCF4BD077L},{(-1L),0xCF4BD077L,0xEE430607L,0x041A94F2L},{0L,0x33F406E2L,1L,1L}},{{0x33F406E2L,6L,7L,0x07CF3AA6L},{0xB602C9B8L,0x04E7679AL,2L,7L},{0x54608FB0L,0x86DC2684L,0x88819643L,0x33F406E2L},{0L,0xEB78E20DL,0xEB78E20DL,0L},{0xB602C9B8L,0x33F406E2L,0x0E93C201L,0xEE430607L},{1L,0x26C8C4FAL,1L,0xAB10B01EL},{0x98256512L,0x1C2BBDEFL,2L,0xAB10B01EL}},{{(-1L),0x26C8C4FAL,0x041A94F2L,0xEE430607L},{0x615F5D53L,0x33F406E2L,0x9E218B16L,0L},{0L,0xEB78E20DL,7L,0x33F406E2L},{2L,0x86DC2684L,0x73A939E0L,7L},{0x98256512L,0x04E7679AL,0x9E218B16L,0x07CF3AA6L},{0L,6L,0L,1L},{(-1L),0x33F406E2L,0xEB78E20DL,0x041A94F2L}},{{0x04E7679AL,0xCF4BD077L,1L,0xCF4BD077L},{0xCF4BD077L,6L,0x73A939E0L,0xAB10B01EL},{0xB602C9B8L,0x98256512L,0xEE430607L,7L},{0x615F5D53L,1L,0x88819643L,1L},{0x615F5D53L,0xEB78E20DL,0xEE430607L,0x615F5D53L},{0xB602C9B8L,1L,0x73A939E0L,0xEE430607L},{0xCF4BD077L,0x86DC2684L,1L,0x07CF3AA6L}},{{0x04E7679AL,0x1C2BBDEFL,0xEB78E20DL,9L},{(-1L),1L,0L,0xEE430607L},{0L,0xCF4BD077L,0x9E218B16L,0x54608FB0L},{0x98256512L,0xEB78E20DL,0x73A939E0L,0xCF4BD077L},{2L,0x26C8C4FAL,7L,7L},{0L,0L,0x9E218B16L,9L},{0x615F5D53L,6L,0x041A94F2L,0x33F406E2L}}};
        struct S0 *l_903 = &g_835[0][0];
        union U1 l_918[1][1][1] = {{{{0x661BL}}}};
        uint64_t *l_952[5][9] = {{&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4]},{&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406},{&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4]},{&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406,&g_406},{&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4],&l_760[8][0][3],&g_347[4]}};
        uint64_t **l_951 = &l_952[0][8];
        uint32_t l_956 = 0x0B6C4108L;
        uint8_t ***l_989 = &l_910;
        int32_t l_1014 = 0xB906F901L;
        int16_t l_1017 = 0x09F3L;
        union U1 *l_1019 = &l_918[0][0][0];
        int16_t l_1020 = (-2L);
        int i, j, k;
        for (g_66 = 3; (g_66 >= 0); g_66 -= 1)
        { /* block id: 323 */
            int32_t *l_728[7][6][3] = {{{&g_73,&g_73,(void*)0},{&g_73,&g_73,(void*)0},{&g_73,&g_73,(void*)0},{&g_73,&g_73,(void*)0},{&g_73,&g_73,(void*)0},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}},{{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73},{&g_101,&g_101,&g_73}}};
            struct S0 ****l_734 = &g_732[7];
            uint8_t l_847 = 0UL;
            uint8_t ***l_867 = &g_864;
            uint32_t ***l_872 = &g_631;
            int32_t l_980[5] = {0x2C94F76AL,0x2C94F76AL,0x2C94F76AL,0x2C94F76AL,0x2C94F76AL};
            union U1 **l_1018 = (void*)0;
            int i, j, k;
            ++l_729;
            if ((((*l_734) = g_732[7]) == (void*)0))
            { /* block id: 326 */
                int32_t *l_737 = &g_73;
                int16_t *l_779 = (void*)0;
                int32_t l_810 = 0x7915C9BBL;
                int32_t l_811 = 9L;
                int32_t l_812[9][4] = {{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L},{8L,0xAF4F9037L,8L,0xAF4F9037L}};
                int32_t **l_849[2][6][6] = {{{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735},{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735},{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735},{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735},{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735},{&l_735,(void*)0,&l_735,&l_735,(void*)0,&l_735}},{{&l_735,(void*)0,&l_735,&g_284,&l_735,&g_284},{&g_284,&l_735,&g_284,&g_284,&l_735,&g_284},{&g_284,&l_735,&g_284,&g_284,&l_735,&g_284},{&g_284,&l_735,&g_284,&g_284,&l_735,&g_284},{&g_284,&l_735,&g_284,&g_284,&l_735,&g_284},{&g_284,&l_735,&g_284,&g_284,&l_735,&g_284}}};
                int i, j, k;
                if (g_119[g_563][(g_563 + 1)])
                { /* block id: 327 */
                    int32_t **l_736[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_736[i] = (void*)0;
                    l_737 = l_735;
                }
                else
                { /* block id: 329 */
                    int32_t l_738 = 1L;
                    for (g_308 = 0; (g_308 <= 2); g_308 += 1)
                    { /* block id: 332 */
                        uint16_t *l_743 = &g_97;
                        int32_t l_757 = 0L;
                        uint64_t *l_758 = &g_599[0];
                        int8_t *l_759[8][9][1] = {{{(void*)0},{(void*)0},{&g_563},{&g_219},{&g_563},{&g_308},{&g_219},{(void*)0},{&g_219}},{{(void*)0},{(void*)0},{&g_563},{&g_308},{&g_219},{&g_308},{&g_563},{(void*)0},{(void*)0}},{{&g_219},{(void*)0},{&g_219},{&g_308},{&g_563},{&g_219},{&g_563},{(void*)0},{(void*)0}},{{&g_563},{&g_219},{&g_563},{&g_308},{&g_219},{(void*)0},{&g_219},{(void*)0},{(void*)0}},{{&g_563},{&g_308},{&g_219},{&g_308},{&g_563},{(void*)0},{(void*)0},{&g_219},{(void*)0}},{{&g_219},{&g_308},{&g_563},{&g_219},{&g_563},{(void*)0},{(void*)0},{&g_563},{&g_219}},{{&g_563},{&g_308},{&g_219},{(void*)0},{&g_219},{(void*)0},{(void*)0},{&g_563},{&g_308}},{{&g_219},{&g_308},{&g_563},{(void*)0},{(void*)0},{&g_219},{(void*)0},{&g_219},{&g_308}}};
                        int i, j, k;
                        l_738 &= g_119[g_563][g_66];
                        (*g_284) = (safe_lshift_func_int8_t_s_u((((safe_div_func_int16_t_s_s(((*g_252) = ((((*l_743)++) ^ ((!((g_232[(g_563 + 2)] == (((*g_631) != (((((g_219 |= (g_345[g_308][g_66] | (((*l_758) = (((safe_unary_minus_func_uint64_t_u((g_347[1]++))) | g_119[g_563][g_66]) != (((*l_737) = (safe_mod_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((((g_756 , (g_560 = (l_757 ^= 1UL))) < ((void*)0 != &l_743)) | 0x98779B49L), 1UL)), g_232[(g_563 + 2)]))) >= (*g_632)))) || 0xBC847413CE96AA4FLL))) < 0xD4L) , p_33.f0) & g_259[5][4][0]) , (void*)0)) , (*g_105))) | p_33.f0)) >= 0x4DE36BD6F2D03AF8LL)) != 255UL)), (-1L))) , g_345[g_308][g_66]) ^ (**g_631)), l_760[0][1][2]));
                        (*g_284) = ((*g_252) >= p_33.f0);
                        return g_170;
                    }
                }
                for (g_99 = 5; (g_99 >= 0); g_99 -= 1)
                { /* block id: 349 */
                    uint8_t *l_762 = &g_232[0];
                    uint8_t **l_761 = &l_762;
                    int32_t l_800 = 0x90605673L;
                    uint32_t l_806[9];
                    int32_t l_809[1][1][5] = {{{0xE552216FL,0xE552216FL,0xE552216FL,0xE552216FL,0xE552216FL}}};
                    struct S0 ***l_837 = (void*)0;
                    uint16_t *l_838 = &g_506;
                    uint64_t *l_841 = &l_760[3][2][4];
                    uint16_t *l_842 = &g_354[1];
                    int8_t l_843 = 0xA8L;
                    uint64_t *l_844 = &g_347[4];
                    uint16_t *l_845 = (void*)0;
                    uint16_t *l_846 = &l_729;
                    int i, j, k;
                    for (i = 0; i < 9; i++)
                        l_806[i] = 0x7BEC2BC4L;
                    for (g_122.f0 = 5; (g_122.f0 >= 0); g_122.f0 -= 1)
                    { /* block id: 352 */
                        uint8_t ***l_763 = &l_761;
                        uint16_t *l_771 = &g_506;
                        int64_t *l_772 = &g_345[0][1];
                        int64_t *l_777 = &g_778;
                        uint16_t *l_799 = &g_148;
                        uint16_t *l_801[7] = {&g_97,&g_97,&g_97,&g_97,&g_97,&g_97,&g_97};
                        int32_t **l_803 = &g_284;
                        int i;
                        (*g_105) = (((((*l_763) = l_761) != g_764) != (g_773 = ((*l_772) = ((safe_lshift_func_uint16_t_u_u(((*l_771) |= (+6UL)), 5)) | (((void*)0 == g_732[(g_66 + 4)]) == g_81[g_122.f0]))))) & ((~(safe_div_func_uint16_t_u_u(((((*l_777) |= (g_347[(g_563 + 1)] , ((-1L) && g_347[(g_66 + 1)]))) || (-7L)) , 0UL), l_760[0][1][2]))) == g_259[5][4][0]));
                    }
                    for (g_308 = 0; (g_308 <= 2); g_308 += 1)
                    { /* block id: 367 */
                        int64_t l_804 = 0xD343A1702E8E05BALL;
                        int i;
                        ++l_806[5];
                        return g_81[(g_563 + 2)];
                    }
                    --g_814;
                    g_848 |= (l_847 &= (safe_rshift_func_uint8_t_u_u(255UL, ((~g_81[g_99]) != ((safe_mul_func_int8_t_s_s((((*l_846) = ((safe_rshift_func_uint8_t_u_u(((safe_unary_minus_func_uint16_t_u(((((*g_105) = (((safe_mod_func_uint32_t_u_u((((*l_844) = (((((*l_842) = (((*l_841) ^= (safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((3UL <= (((safe_mul_func_uint16_t_u_u(g_347[g_563], ((*l_838) = (g_835[0][0] , (0UL < (((*l_734) = l_836) != l_837)))))) <= (safe_mul_func_int8_t_s_s(1L, p_35))) || p_33.f0)), l_809[0][0][3])), p_33.f0))) | p_35)) == g_81[g_99]) == l_843) != p_33.f0)) < l_800), (*g_105))) < p_35) != p_35)) | (*g_632)) < (*g_284)))) <= p_33.f0), p_33.f0)) && 0L)) < 65535UL), 0xF7L)) <= l_805)))));
                }
                l_728[0][4][1] = &l_802[5][6][3];
                for (l_813 = 2; (l_813 >= 0); l_813 -= 1)
                { /* block id: 385 */
                    int64_t l_850 = 0x4649EAA56359BD63LL;
                    for (g_217 = 0; (g_217 <= 9); g_217 += 1)
                    { /* block id: 388 */
                        if (l_850)
                            break;
                    }
                    for (g_219 = 0; (g_219 <= 1); g_219 += 1)
                    { /* block id: 393 */
                        (*g_105) = l_850;
                        if (p_35)
                            continue;
                        (*g_105) ^= p_35;
                    }
                }
            }
            else
            { /* block id: 399 */
                uint32_t l_852 = 18446744073709551615UL;
                uint8_t ***l_866[2];
                int32_t l_904 = 0x4B1D5239L;
                int32_t *l_905 = &l_802[3][4][1];
                int32_t l_932 = 0xF21DF179L;
                int i;
                for (i = 0; i < 2; i++)
                    l_866[i] = (void*)0;
                for (g_406 = 0; (g_406 <= 4); g_406 += 1)
                { /* block id: 402 */
                    uint8_t ****l_865[7] = {&g_863[1][2],&g_863[1][2],&g_863[1][2],&g_863[1][2],&g_863[1][2],&g_863[1][2],&g_863[1][2]};
                    uint32_t *l_868 = &g_560;
                    uint32_t * const **l_871[1][8][10] = {{{&l_870[1],&l_870[1],&l_870[4],&l_870[0],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1]},{&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[4],&l_870[1],&l_870[4]},{&l_870[1],(void*)0,(void*)0,&l_870[4],(void*)0,(void*)0,&l_870[1],&l_870[1],&l_870[1],&l_870[1]},{&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1],&l_870[1]},{&l_870[1],&l_870[1],&l_870[1],&l_870[0],&l_870[4],&l_870[1],&l_870[1],&l_870[1],&l_870[4],&l_870[0]},{&l_870[0],(void*)0,&l_870[0],&l_870[1],&l_870[4],&l_870[3],&l_870[1],(void*)0,(void*)0,&l_870[1]},{&l_870[4],&l_870[1],&l_870[3],&l_870[3],&l_870[1],&l_870[4],&l_870[1],&l_870[1],&l_870[4],&l_870[1]},{&l_870[1],&l_870[1],&l_870[3],(void*)0,&l_870[1],(void*)0,&l_870[3],&l_870[1],&l_870[1],&l_870[1]}}};
                    int i, j, k;
                    for (g_778 = 4; (g_778 >= 1); g_778 -= 1)
                    { /* block id: 405 */
                        int32_t *l_851 = &g_73;
                        l_851 = l_851;
                        return l_852;
                    }
                    if (l_802[3][3][2])
                        break;
                    (*g_284) ^= ((*g_105) |= ((*g_499) || ((safe_sub_func_int32_t_s_s(p_33.f0, 0xAA8A1ED9L)) & ((safe_add_func_uint32_t_u_u(((safe_div_func_uint16_t_u_u((l_760[7][1][1] && p_33.f0), ((!(((l_871[0][1][7] = (l_869 = (((p_35 < ((((~((*l_868) = ((**g_631) = (((l_866[0] = g_863[1][2]) == l_867) >= ((*g_256) < l_852))))) , (***l_836)) , g_122) , l_852)) >= g_97) , l_869))) != l_872) || (**g_498))) | 0x5504C684CE8A35E0LL))) > 0x60ACL), p_33.f0)) , (**g_255)))));
                }
                if (l_852)
                    continue;
                for (g_99 = 0; (g_99 <= 2); g_99 += 1)
                { /* block id: 421 */
                    int8_t l_885 = 9L;
                    int8_t *l_889[7];
                    int32_t l_890 = 0xB31A7272L;
                    int32_t **l_906 = &l_905;
                    uint8_t * const **l_908 = (void*)0;
                    uint8_t * const **l_909 = &l_907;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_889[i] = &g_219;
                    (*g_105) = (safe_add_func_int8_t_s_s(l_852, (safe_sub_func_int16_t_s_s(((safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((safe_add_func_int8_t_s_s((safe_div_func_uint64_t_u_u((((***l_872) = 4294967288UL) > p_33.f0), l_885)), ((**g_864) |= (+(((safe_mod_func_int8_t_s_s((l_890 = p_33.f0), (safe_lshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_s(p_33.f0, ((((*l_909) = ((((*l_906) = (((safe_mod_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(l_805, 14)) > ((+(l_904 = ((((((+(safe_mul_func_uint16_t_u_u(0UL, (((*g_733) = l_903) != l_903)))) > l_852) || p_35) ^ (-8L)) >= l_885) || (**g_582)))) > 18446744073709551615UL)), l_805)) , p_35) , l_905)) == &l_802[4][2][0]) , l_907)) != l_910) , l_760[6][2][3]))), 5)))) && g_115.f1) != p_35))))) , (*l_905)), p_33.f0)), 0x04L)) , (*l_905)), 0x01FCL))));
                }
                for (g_778 = 0; (g_778 <= 2); g_778 += 1)
                { /* block id: 433 */
                    uint32_t l_911 = 1UL;
                    uint16_t *l_931 = &g_354[0];
                    int32_t **l_933[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_933[i] = &l_905;
                    for (g_101 = 2; (g_101 >= 0); g_101 -= 1)
                    { /* block id: 436 */
                        return p_33.f0;
                    }
                    for (g_506 = 0; (g_506 <= 2); g_506 += 1)
                    { /* block id: 441 */
                        if ((*g_124))
                            break;
                        ++l_911;
                    }
                    (*g_105) |= (p_35 , (l_911 , ((((((safe_mod_func_uint16_t_u_u(((((safe_lshift_func_uint16_t_u_u((*g_499), 4)) && (l_918[0][0][0] , (safe_add_func_uint16_t_u_u(((((((safe_rshift_func_int8_t_s_s((safe_div_func_int32_t_s_s((g_925[6] , (safe_sub_func_uint16_t_u_u(l_928, 0xA38EL))), (((**g_631) &= 1UL) ^ ((((safe_div_func_uint16_t_u_u(((*l_931) = p_33.f0), g_773)) >= p_33.f0) <= l_932) || (-1L))))), 5)) ^ p_33.f0) != p_35) | p_35) && (*g_632)) ^ (*g_284)), (-1L))))) ^ l_911) ^ 5UL), (*l_905))) || 0x70L) , (*l_903)) , l_813) & p_35) && (-9L))));
                    l_934[6] = &l_802[0][3][0];
                }
            }
            for (g_97 = 0; (g_97 <= 2); g_97 += 1)
            { /* block id: 453 */
                uint64_t **l_953 = (void*)0;
                const int32_t l_970 = 0x028124F1L;
                const int32_t *l_979 = &l_813;
                const int32_t **l_978 = &l_979;
                int32_t l_981 = 1L;
                uint8_t l_982 = 1UL;
                int8_t l_994 = 1L;
                for (g_217 = 0; (g_217 <= 2); g_217 += 1)
                { /* block id: 456 */
                    int8_t *l_939 = &g_308;
                    int16_t *l_946 = &g_848;
                    uint16_t *l_954 = &g_148;
                    int32_t l_955[5][4] = {{(-2L),9L,9L,(-2L)},{(-2L),9L,9L,(-2L)},{(-2L),9L,9L,(-2L)},{(-2L),9L,9L,(-2L)},{(-2L),9L,9L,(-2L)}};
                    struct S0 ****l_969 = (void*)0;
                    const uint8_t l_971[4] = {0x3EL,0x3EL,0x3EL,0x3EL};
                    const int32_t l_996 = 1L;
                    int i, j;
                    if ((safe_sub_func_uint32_t_u_u((((***l_869) = (((safe_rshift_func_int8_t_s_s(((*l_939) = 0xF3L), 0)) , (((p_35 >= (p_35 , (safe_rshift_func_int16_t_s_s(p_35, (safe_add_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u((((*g_252) = ((*l_946) ^= (-10L))) ^ (1L ^ (((**l_951) &= (safe_div_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_u((&l_836 != (void*)0), ((*l_954) = (l_951 != l_953)))) || p_35), p_33.f0))) >= 0xD2464D6B132EFCC0LL))), 1UL)) , (**g_498)), 0x3362L)))))) , 0UL) ^ (-6L))) <= 1UL)) | (-7L)), l_955[4][0])))
                    { /* block id: 463 */
                        int i, j;
                        (*g_284) = (l_956 != (safe_rshift_func_uint8_t_u_s((p_33.f0 && ((((**g_631) = ((safe_lshift_func_uint16_t_u_s((**g_498), 10)) >= (safe_rshift_func_int8_t_s_u(((*l_939) = ((safe_mod_func_uint8_t_u_u(((*g_765) = p_35), l_955[3][2])) || ((safe_mul_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u(5UL, ((g_219 == (l_969 != &g_732[6])) & p_35))) | 0x89057BABL), p_33.f0)) < l_970))), p_33.f0)))) | l_970) && 1UL)), 4)));
                        (*g_105) = (*g_105);
                        (*g_284) = ((l_802[1][5][3] = ((**g_733) , ((((l_971[3] || (((*g_256) <= (safe_div_func_int64_t_s_s((9UL <= (p_33 , (g_974 & (g_345[g_217][g_66] = ((safe_lshift_func_uint8_t_u_s((&l_934[6] != (g_977 , l_978)), 5)) & 9UL))))), 1UL))) ^ 0x3BC4E11D4479DBC1LL)) <= l_980[3]) <= l_955[4][0]) || g_778))) , 7L);
                    }
                    else
                    { /* block id: 472 */
                        int32_t l_995 = (-6L);
                        uint8_t l_1016 = 251UL;
                        int i, j;
                        --l_982;
                        (*g_284) = ((safe_div_func_int16_t_s_s((((safe_sub_func_int8_t_s_s(((p_34 == ((l_989 != ((p_33.f0 && (((****l_734) , p_33.f0) <= ((((l_995 |= (g_345[g_97][g_563] = (p_33.f0 | ((safe_mul_func_uint8_t_u_u((p_33.f0 >= ((**l_951)++)), (l_994 , 0xBBL))) == 0x45L)))) , g_506) != 1UL) | p_35))) , l_989)) , p_34)) & (*l_979)), 4UL)) & l_996) && (*g_765)), p_35)) | p_33.f0);
                        (*g_284) ^= ((safe_sub_func_int32_t_s_s((-9L), (safe_add_func_int8_t_s_s(((l_955[2][2] = p_33.f0) & 9L), (safe_mod_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(((safe_sub_func_uint64_t_u_u((((void*)0 != &g_631) > 0x7751B887L), (!((safe_mod_func_uint16_t_u_u(((*l_954) |= ((((*g_47) , ((*l_939) = ((safe_mod_func_int32_t_s_s((~(p_35 < (((+((((((((*g_499) > l_971[3]) && l_1014) != 0xC7E62221L) >= 1UL) >= g_99) <= g_414[0][0]) == g_232[5])) > (*l_979)) | l_1015))), p_35)) < l_1016))) > g_506) > p_33.f0)), g_73)) != l_1017)))) != p_35), 0UL)) > 0xC682L), g_73)))))) && 0xE0L);
                    }
                }
            }
            l_1019 = &p_33;
        }
        return l_1020;
    }
    (*g_1022) = &l_928;
    (*g_284) ^= ((void*)0 != l_907);
    return p_33.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_47 g_48.f1 g_8 g_66 g_69 g_73 g_81 g_48 g_97 g_104 g_99 g_105 g_101
 * writes: g_47 g_66 g_73 g_81 g_97 g_99 g_105 g_119
 */
static uint8_t  func_40(const struct S0 * p_41)
{ /* block id: 2 */
    union U1 l_43[5][9][5] = {{{{0x4B05L},{0x0245L},{1L},{-5L},{-1L}},{{1L},{-4L},{-4L},{1L},{0x5674L}},{{0x7903L},{-4L},{0xEBB6L},{0x8FADL},{0L}},{{-5L},{0x0245L},{0L},{0x0A06L},{0x1D25L}},{{3L},{-1L},{0xBF3FL},{0x8FADL},{0x7985L}},{{0x725DL},{0xA798L},{-1L},{1L},{1L}},{{0x725DL},{1L},{0xE91CL},{-5L},{0x53D9L}},{{3L},{0xBF3FL},{0x0245L},{0xE49CL},{0xA8C9L}},{{-5L},{0x3020L},{0xE91CL},{0x97EEL},{-9L}}},{{{0x7903L},{0L},{-1L},{-1L},{-9L}},{{1L},{0x6377L},{0xBF3FL},{0L},{0xA8C9L}},{{0x4B05L},{6L},{0L},{0x4132L},{0x53D9L}},{{0x4132L},{0x6377L},{0xEBB6L},{3L},{1L}},{{0L},{0L},{-4L},{3L},{0x7985L}},{{0L},{0x3020L},{1L},{0x4132L},{0x1D25L}},{{-1L},{0xBF3FL},{-8L},{0L},{0L}},{{0L},{1L},{0L},{-1L},{0x5674L}},{{0L},{0xA798L},{0L},{0x97EEL},{-1L}}},{{{0x4132L},{-1L},{-8L},{0xE49CL},{0x4C01L}},{{0x4B05L},{0x0245L},{1L},{-5L},{-1L}},{{1L},{-4L},{-4L},{1L},{0x5674L}},{{0x7903L},{-4L},{0xEBB6L},{0x8FADL},{0L}},{{-5L},{0x0245L},{0L},{0x0A06L},{0x1D25L}},{{3L},{-1L},{0xBF3FL},{0x8FADL},{0x7985L}},{{0x725DL},{0xA798L},{-1L},{1L},{1L}},{{0x725DL},{1L},{0xE91CL},{-5L},{0x53D9L}},{{3L},{0xBF3FL},{0x0245L},{0xE49CL},{0xA8C9L}}},{{{-5L},{0x3020L},{0xE91CL},{0x97EEL},{-9L}},{{0x7903L},{0L},{-1L},{-1L},{-9L}},{{1L},{0x6377L},{0xBF3FL},{0L},{0xA8C9L}},{{0x4B05L},{6L},{0L},{0x62BFL},{-1L}},{{0x62BFL},{0L},{1L},{5L},{0xA6AEL}},{{-4L},{0x4B05L},{0x7903L},{5L},{0x6D7DL}},{{1L},{0x0A06L},{-5L},{0x62BFL},{0xBADCL}},{{0x497CL},{0x4132L},{3L},{0x8FF0L},{7L}},{{1L},{0xE49CL},{0x725DL},{0x497CL},{0x06A9L}}},{{{-4L},{1L},{0x725DL},{1L},{0x8D27L}},{{0x62BFL},{0L},{3L},{0xA341L},{0L}},{{8L},{-1L},{-5L},{-1L},{0x8D27L}},{{0x991FL},{0x7903L},{0x7903L},{0x991FL},{0x06A9L}},{{-6L},{0x7903L},{1L},{-2L},{7L}},{{-1L},{-1L},{0x4B05L},{1L},{0xBADCL}},{{5L},{0L},{0x4132L},{-2L},{0x6D7DL}},{{0L},{1L},{0L},{0x991FL},{0xA6AEL}},{{0L},{0xE49CL},{0L},{-1L},{-1L}}}};
    struct S0 **l_49 = &g_47;
    const int32_t * const l_72 = &g_73;
    int32_t *l_78 = &g_73;
    int64_t *l_79 = &g_66;
    int64_t l_80 = 0L;
    const struct S0 *l_114 = &g_115;
    int32_t l_150 = 0L;
    int32_t l_169 = 0x07F30BC1L;
    uint8_t l_260[4][7][1] = {{{6UL},{5UL},{0xF8L},{1UL},{0xF8L},{5UL},{6UL}},{{7UL},{1UL},{7UL},{6UL},{5UL},{0xF8L},{1UL}},{{0xF8L},{5UL},{6UL},{7UL},{1UL},{7UL},{6UL}},{{5UL},{0xF8L},{1UL},{0xF8L},{5UL},{6UL},{7UL}}};
    uint32_t l_402 = 0xFC5B0755L;
    int64_t l_412 = 0L;
    uint64_t l_442 = 0x5FC6D5E83C0ED96DLL;
    int32_t l_558 = 0xC39127B2L;
    int32_t l_559 = 0x0056F20EL;
    const struct S0 **l_568 = &l_114;
    const struct S0 ***l_567 = &l_568;
    int16_t l_598 = 0x1F98L;
    union U1 * const l_602 = &g_122;
    uint32_t l_720 = 0xF7D79F69L;
    int i, j, k;
    g_66 ^= (l_43[4][5][4] , func_44((p_41 == (void*)0), (p_41 == ((*l_49) = g_47))));
lbl_121:
    g_81[0] = (((((safe_rshift_func_int8_t_s_s((((g_69 == (void*)0) | (l_43[4][5][4] , (9L && (&l_49 != &l_49)))) < ((((((*l_79) = (((safe_sub_func_int32_t_s_s((l_72 != l_72), ((*l_78) = (safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_u((*l_72), (*l_72))), (*l_72)))))) < 0x18FE3B64D7EEACC2LL) <= g_66)) >= 0x95E77405739219ECLL) , &l_49) != &l_49) || 65535UL)), 6)) < g_8) != l_80) <= l_80) && 0x6F70L);
    for (g_73 = 4; (g_73 >= 0); g_73 -= 1)
    { /* block id: 20 */
        int32_t *l_95 = &g_73;
        const struct S0 **l_102 = &g_42;
        const int64_t l_116 = (-1L);
        int32_t l_120[9][1] = {{(-2L)},{0xD339D48EL},{(-2L)},{0xD339D48EL},{(-2L)},{0xD339D48EL},{(-2L)},{0xD339D48EL},{(-2L)}};
        int8_t l_149 = 0x46L;
        uint16_t *l_164 = &g_148;
        uint32_t l_212 = 1UL;
        int32_t l_218 = 0xED59904FL;
        struct S0 **l_227 = (void*)0;
        int64_t *l_332 = &g_66;
        uint32_t l_380 = 0UL;
        int8_t l_383 = 0L;
        union U1 l_390[4][2][3] = {{{{0L},{0L},{-3L}},{{1L},{-3L},{0x9116L}}},{{{0x9116L},{-3L},{1L}},{{-3L},{0L},{0L}}},{{{0xC4F5L},{0x9116L},{1L}},{{0x7844L},{-10L},{0x9116L}}},{{{0x7844L},{1L},{-3L}},{{0xC4F5L},{0x8844L},{0xC4F5L}}}};
        struct S0 *l_523 = &g_48;
        uint8_t l_694 = 247UL;
        uint32_t l_723 = 0xAFB7F62CL;
        int i, j, k;
        if (g_81[(g_73 + 1)])
            break;
        for (l_80 = 0; (l_80 <= 5); l_80 += 1)
        { /* block id: 24 */
            int64_t l_94 = 0x8105A18A5C6425F0LL;
            for (g_66 = 5; (g_66 >= 1); g_66 -= 1)
            { /* block id: 27 */
                int64_t *l_89 = &l_80;
                uint16_t *l_96 = &g_97;
                int64_t *l_98 = &l_94;
                int32_t *l_100 = &g_101;
                const struct S0 **l_103 = (void*)0;
                int i;
                g_99 = (g_81[l_80] && ((*l_98) = (+(safe_div_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((*l_96) &= (safe_div_func_int32_t_s_s((g_81[l_80] , g_73), ((g_81[(g_73 + 1)] != (((**l_49) , (l_89 == ((safe_lshift_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((0xD276L | l_94), (l_95 != (void*)0))) <= (*l_72)), g_48.f2)) , (void*)0))) & 0x11L)) , 0x4A016C9CL)))), 3UL)), (*l_95))))));
                l_100 = &g_73;
                l_103 = l_102;
            }
            (*g_104) = l_78;
            for (g_99 = 0; (g_99 <= 5); g_99 += 1)
            { /* block id: 37 */
                int32_t **l_106 = &l_95;
                int64_t **l_111 = &l_79;
                uint32_t *l_117 = (void*)0;
                uint32_t *l_118 = &g_119[3][7];
                int i;
                (*l_106) = (*g_104);
                l_120[6][0] = (((*l_118) = (safe_add_func_int8_t_s_s(((safe_add_func_uint32_t_u_u(0UL, (&l_94 == ((*l_111) = &l_94)))) > (g_81[l_80] >= ((((safe_sub_func_int64_t_s_s(((g_48.f2 ^ (0L && (0x11D2751B8D994F87LL || g_8))) == (((0x33L > g_101) , l_114) != p_41)), g_97)) > 0x46ECL) ^ l_116) , (*l_72)))), 0x3BL))) == g_101);
                return (**l_106);
            }
        }
        l_95 = l_78;
        for (l_80 = 5; (l_80 >= 1); l_80 -= 1)
        { /* block id: 48 */
            uint32_t *l_134 = &g_119[3][7];
            uint16_t *l_147[7];
            int32_t l_168 = 4L;
            int64_t l_177[4];
            int32_t l_234 = (-10L);
            uint16_t l_293[4] = {0x616EL,0x616EL,0x616EL,0x616EL};
            int32_t l_349 = 6L;
            int32_t l_351[7][4][4] = {{{0L,0xA130B2A4L,0xE6463BC8L,0xC3F39495L},{0x48195563L,0xA130B2A4L,0L,5L},{0xA130B2A4L,0x17E70857L,0x75AB8D4AL,2L},{0x72BA6D88L,0xE8C61DE7L,0x8AEFC81AL,0x1AB46CC7L}},{{0xC3F39495L,8L,0xC3F39495L,0xA130B2A4L},{0L,0xE6463BC8L,0x00C429CBL,0xC3F39495L},{0xA47CB311L,0x00C429CBL,1L,0xE6463BC8L},{0xA130B2A4L,0L,1L,0L}},{{0xA47CB311L,0xE8C61DE7L,0x00C429CBL,0x75AB8D4AL},{0L,0xBC6659E4L,0xC3F39495L,0x8AEFC81AL},{0xC3F39495L,0x8AEFC81AL,0x8AEFC81AL,0xC3F39495L},{0x72BA6D88L,5L,0x75AB8D4AL,0x00C429CBL}},{{0xA130B2A4L,0xA2662F6EL,0L,1L},{0x48195563L,0xE8C61DE7L,6L,0xBC6659E4L},{0x1AB46CC7L,0xA47CB311L,1L,0L},{0L,0L,(-1L),1L}},{{0xA130B2A4L,0xC3F39495L,8L,0xC3F39495L},{(-1L),0x72BA6D88L,0xA2662F6EL,0L},{0x8AEFC81AL,0xA130B2A4L,0L,0x17E70857L},{2L,0x48195563L,1L,6L}},{{2L,0L,0L,1L},{0x8AEFC81AL,6L,0xA2662F6EL,(-1L)},{(-1L),0xE8C61DE7L,8L,8L},{0xA130B2A4L,0xA130B2A4L,(-1L),0xA2662F6EL}},{{0L,0x4B08019DL,1L,0L},{0x1AB46CC7L,(-1L),6L,1L},{0x00C429CBL,(-1L),0x17E70857L,0L},{(-1L),0x4B08019DL,0L,0xA2662F6EL}}};
            uint64_t l_362 = 18446744073709551608UL;
            uint32_t l_368 = 8UL;
            int32_t **l_510 = &l_95;
            const struct S0 ***l_569 = (void*)0;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_147[i] = &g_148;
            for (i = 0; i < 4; i++)
                l_177[i] = (-1L);
            if (g_8)
                goto lbl_121;
        }
        for (l_442 = 1; (l_442 <= 4); l_442 += 1)
        { /* block id: 242 */
            uint16_t l_615 = 0xFE9AL;
            int32_t *l_618[4] = {&l_558,&l_558,&l_558,&l_558};
            uint8_t *l_668[2][6][9] = {{{&l_260[3][0][0],(void*)0,(void*)0,&l_260[3][0][0],&g_232[5],&g_232[4],&g_232[5],&l_260[3][0][0],(void*)0},{(void*)0,(void*)0,&l_260[3][0][0],&l_260[3][5][0],&l_260[3][5][0],(void*)0,&g_232[4],&l_260[3][0][0],&g_232[4]},{(void*)0,&g_232[0],(void*)0,(void*)0,&g_232[0],(void*)0,&l_260[3][5][0],&g_232[4],(void*)0},{&l_260[3][0][0],&l_260[3][0][0],&l_260[3][0][0],(void*)0,&g_232[0],&g_232[0],(void*)0,&l_260[3][0][0],&l_260[3][0][0]},{&g_232[0],&l_260[3][0][0],(void*)0,&g_232[5],&l_260[3][5][0],&l_260[3][0][0],&l_260[3][5][0],&l_260[3][5][0],&l_260[3][0][0]},{&g_232[5],&l_260[3][0][0],&g_232[4],&l_260[3][0][0],&g_232[5],&l_260[3][0][0],&g_232[4],(void*)0,(void*)0}},{{&g_232[4],&l_260[3][0][0],&g_232[5],&l_260[3][0][0],&g_232[4],&l_260[3][0][0],&g_232[5],&l_260[3][0][0],&g_232[4]},{&l_260[3][5][0],&l_260[3][0][0],&l_260[3][5][0],&g_232[5],(void*)0,&l_260[3][0][0],&g_232[0],&l_260[3][0][0],(void*)0},{(void*)0,&g_232[0],&g_232[0],(void*)0,&l_260[3][0][0],&l_260[3][0][0],&l_260[3][0][0],(void*)0,&l_260[3][5][0]},{&l_260[3][5][0],(void*)0,&g_232[0],(void*)0,(void*)0,&g_232[0],(void*)0,&l_260[3][5][0],&g_232[4]},{&g_232[4],(void*)0,&l_260[3][5][0],&l_260[3][5][0],&l_260[3][0][0],(void*)0,(void*)0,&l_260[3][0][0],&l_260[3][5][0]},{&g_232[5],&g_232[4],&g_232[5],&l_260[3][0][0],(void*)0,(void*)0,&l_260[3][0][0],&g_232[4],&g_232[4]}}};
            uint8_t **l_669 = (void*)0;
            uint8_t **l_670 = &l_668[0][3][1];
            uint8_t *l_671 = &l_260[3][6][0];
            int32_t l_684 = 0x76FB8723L;
            uint64_t *l_690 = (void*)0;
            uint64_t *l_691 = &g_599[0];
            const int32_t l_704 = (-1L);
            union U1 l_711 = {9L};
            int i, j, k;
        }
    }
    return (*l_72);
}


/* ------------------------------------------ */
/* 
 * reads : g_48.f1 g_8
 * writes:
 */
static int32_t  func_44(uint32_t  p_45, int16_t  p_46)
{ /* block id: 4 */
    int64_t l_54 = 4L;
    const struct S0 *l_55[6][3][8];
    const struct S0 **l_62 = &l_55[3][2][5];
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
                l_55[i][j][k] = &g_48;
        }
    }
    for (p_45 = 0; (p_45 <= 31); p_45 = safe_add_func_uint8_t_u_u(p_45, 2))
    { /* block id: 7 */
        struct S0 **l_61 = &g_47;
        struct S0 ***l_60 = &l_61;
        int32_t l_63 = (-7L);
        int32_t l_64 = 1L;
        int32_t *l_65 = &l_64;
        (*l_65) = (safe_rshift_func_uint8_t_u_s(((((p_46 || (-6L)) | ((l_54 , l_55[3][2][5]) == (void*)0)) ^ ((safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s((p_46 , (g_48.f1 > (l_63 = ((((*l_60) = &g_47) == (l_62 = l_62)) <= l_63)))), l_64)), g_8)) ^ p_46)) == 0UL), 7));
    }
    return p_45;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_48.f0, "g_48.f0", print_hash_value);
    transparent_crc(g_48.f1, "g_48.f1", print_hash_value);
    transparent_crc(g_48.f2, "g_48.f2", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_81[i], "g_81[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_115.f0, "g_115.f0", print_hash_value);
    transparent_crc(g_115.f1, "g_115.f1", print_hash_value);
    transparent_crc(g_115.f2, "g_115.f2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_119[i][j], "g_119[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_122.f0, "g_122.f0", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_214, "g_214", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    transparent_crc(g_219, "g_219", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_232[i], "g_232[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_257, "g_257", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_259[i][j][k], "g_259[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_308, "g_308", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_345[i][j], "g_345[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_347[i], "g_347[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_354[i], "g_354[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_406, "g_406", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_409[i][j][k], "g_409[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_413, "g_413", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_414[i][j], "g_414[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_447.f0, "g_447.f0", print_hash_value);
    transparent_crc(g_447.f1, "g_447.f1", print_hash_value);
    transparent_crc(g_447.f2, "g_447.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_454[i], "g_454[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_506, "g_506", print_hash_value);
    transparent_crc(g_524.f0, "g_524.f0", print_hash_value);
    transparent_crc(g_524.f1, "g_524.f1", print_hash_value);
    transparent_crc(g_524.f2, "g_524.f2", print_hash_value);
    transparent_crc(g_560, "g_560", print_hash_value);
    transparent_crc(g_563, "g_563", print_hash_value);
    transparent_crc(g_575.f0, "g_575.f0", print_hash_value);
    transparent_crc(g_575.f1, "g_575.f1", print_hash_value);
    transparent_crc(g_575.f2, "g_575.f2", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_599[i], "g_599[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_756.f0, "g_756.f0", print_hash_value);
    transparent_crc(g_756.f1, "g_756.f1", print_hash_value);
    transparent_crc(g_756.f2, "g_756.f2", print_hash_value);
    transparent_crc(g_773, "g_773", print_hash_value);
    transparent_crc(g_778, "g_778", print_hash_value);
    transparent_crc(g_814, "g_814", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_835[i][j].f0, "g_835[i][j].f0", print_hash_value);
            transparent_crc(g_835[i][j].f1, "g_835[i][j].f1", print_hash_value);
            transparent_crc(g_835[i][j].f2, "g_835[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_848, "g_848", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_925[i].f0, "g_925[i].f0", print_hash_value);
        transparent_crc(g_925[i].f1, "g_925[i].f1", print_hash_value);
        transparent_crc(g_925[i].f2, "g_925[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_974, "g_974", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_1045.f0, "g_1045.f0", print_hash_value);
    transparent_crc(g_1045.f1, "g_1045.f1", print_hash_value);
    transparent_crc(g_1045.f2, "g_1045.f2", print_hash_value);
    transparent_crc(g_1070, "g_1070", print_hash_value);
    transparent_crc(g_1071, "g_1071", print_hash_value);
    transparent_crc(g_1072, "g_1072", print_hash_value);
    transparent_crc(g_1073, "g_1073", print_hash_value);
    transparent_crc(g_1074, "g_1074", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1075[i], "g_1075[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1188.f0, "g_1188.f0", print_hash_value);
    transparent_crc(g_1188.f1, "g_1188.f1", print_hash_value);
    transparent_crc(g_1188.f2, "g_1188.f2", print_hash_value);
    transparent_crc(g_1294.f0, "g_1294.f0", print_hash_value);
    transparent_crc(g_1294.f1, "g_1294.f1", print_hash_value);
    transparent_crc(g_1294.f2, "g_1294.f2", print_hash_value);
    transparent_crc(g_1295.f0, "g_1295.f0", print_hash_value);
    transparent_crc(g_1295.f1, "g_1295.f1", print_hash_value);
    transparent_crc(g_1295.f2, "g_1295.f2", print_hash_value);
    transparent_crc(g_1297.f0, "g_1297.f0", print_hash_value);
    transparent_crc(g_1297.f1, "g_1297.f1", print_hash_value);
    transparent_crc(g_1297.f2, "g_1297.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1301[i], "g_1301[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1383.f0, "g_1383.f0", print_hash_value);
    transparent_crc(g_1383.f1, "g_1383.f1", print_hash_value);
    transparent_crc(g_1383.f2, "g_1383.f2", print_hash_value);
    transparent_crc(g_1452, "g_1452", print_hash_value);
    transparent_crc(g_1527.f0, "g_1527.f0", print_hash_value);
    transparent_crc(g_1527.f1, "g_1527.f1", print_hash_value);
    transparent_crc(g_1527.f2, "g_1527.f2", print_hash_value);
    transparent_crc(g_1555.f0, "g_1555.f0", print_hash_value);
    transparent_crc(g_1555.f1, "g_1555.f1", print_hash_value);
    transparent_crc(g_1555.f2, "g_1555.f2", print_hash_value);
    transparent_crc(g_1564, "g_1564", print_hash_value);
    transparent_crc(g_1567, "g_1567", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1568[i][j], "g_1568[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1569, "g_1569", print_hash_value);
    transparent_crc(g_1612, "g_1612", print_hash_value);
    transparent_crc(g_1663.f0, "g_1663.f0", print_hash_value);
    transparent_crc(g_1663.f1, "g_1663.f1", print_hash_value);
    transparent_crc(g_1663.f2, "g_1663.f2", print_hash_value);
    transparent_crc(g_1724.f0, "g_1724.f0", print_hash_value);
    transparent_crc(g_1724.f1, "g_1724.f1", print_hash_value);
    transparent_crc(g_1724.f2, "g_1724.f2", print_hash_value);
    transparent_crc(g_1847.f0, "g_1847.f0", print_hash_value);
    transparent_crc(g_1847.f1, "g_1847.f1", print_hash_value);
    transparent_crc(g_1847.f2, "g_1847.f2", print_hash_value);
    transparent_crc(g_1914.f0, "g_1914.f0", print_hash_value);
    transparent_crc(g_1914.f1, "g_1914.f1", print_hash_value);
    transparent_crc(g_1914.f2, "g_1914.f2", print_hash_value);
    transparent_crc(g_1915.f0, "g_1915.f0", print_hash_value);
    transparent_crc(g_1915.f1, "g_1915.f1", print_hash_value);
    transparent_crc(g_1915.f2, "g_1915.f2", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1916[i].f0, "g_1916[i].f0", print_hash_value);
        transparent_crc(g_1916[i].f1, "g_1916[i].f1", print_hash_value);
        transparent_crc(g_1916[i].f2, "g_1916[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1917.f0, "g_1917.f0", print_hash_value);
    transparent_crc(g_1917.f1, "g_1917.f1", print_hash_value);
    transparent_crc(g_1917.f2, "g_1917.f2", print_hash_value);
    transparent_crc(g_1918.f0, "g_1918.f0", print_hash_value);
    transparent_crc(g_1918.f1, "g_1918.f1", print_hash_value);
    transparent_crc(g_1918.f2, "g_1918.f2", print_hash_value);
    transparent_crc(g_1919.f0, "g_1919.f0", print_hash_value);
    transparent_crc(g_1919.f1, "g_1919.f1", print_hash_value);
    transparent_crc(g_1919.f2, "g_1919.f2", print_hash_value);
    transparent_crc(g_1920.f0, "g_1920.f0", print_hash_value);
    transparent_crc(g_1920.f1, "g_1920.f1", print_hash_value);
    transparent_crc(g_1920.f2, "g_1920.f2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1921[i][j].f0, "g_1921[i][j].f0", print_hash_value);
            transparent_crc(g_1921[i][j].f1, "g_1921[i][j].f1", print_hash_value);
            transparent_crc(g_1921[i][j].f2, "g_1921[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1922[i].f0, "g_1922[i].f0", print_hash_value);
        transparent_crc(g_1922[i].f1, "g_1922[i].f1", print_hash_value);
        transparent_crc(g_1922[i].f2, "g_1922[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1923[i].f0, "g_1923[i].f0", print_hash_value);
        transparent_crc(g_1923[i].f1, "g_1923[i].f1", print_hash_value);
        transparent_crc(g_1923[i].f2, "g_1923[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1924.f0, "g_1924.f0", print_hash_value);
    transparent_crc(g_1924.f1, "g_1924.f1", print_hash_value);
    transparent_crc(g_1924.f2, "g_1924.f2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1925[i].f0, "g_1925[i].f0", print_hash_value);
        transparent_crc(g_1925[i].f1, "g_1925[i].f1", print_hash_value);
        transparent_crc(g_1925[i].f2, "g_1925[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1926.f0, "g_1926.f0", print_hash_value);
    transparent_crc(g_1926.f1, "g_1926.f1", print_hash_value);
    transparent_crc(g_1926.f2, "g_1926.f2", print_hash_value);
    transparent_crc(g_1927.f0, "g_1927.f0", print_hash_value);
    transparent_crc(g_1927.f1, "g_1927.f1", print_hash_value);
    transparent_crc(g_1927.f2, "g_1927.f2", print_hash_value);
    transparent_crc(g_1928.f0, "g_1928.f0", print_hash_value);
    transparent_crc(g_1928.f1, "g_1928.f1", print_hash_value);
    transparent_crc(g_1928.f2, "g_1928.f2", print_hash_value);
    transparent_crc(g_1929.f0, "g_1929.f0", print_hash_value);
    transparent_crc(g_1929.f1, "g_1929.f1", print_hash_value);
    transparent_crc(g_1929.f2, "g_1929.f2", print_hash_value);
    transparent_crc(g_1930.f0, "g_1930.f0", print_hash_value);
    transparent_crc(g_1930.f1, "g_1930.f1", print_hash_value);
    transparent_crc(g_1930.f2, "g_1930.f2", print_hash_value);
    transparent_crc(g_1931.f0, "g_1931.f0", print_hash_value);
    transparent_crc(g_1931.f1, "g_1931.f1", print_hash_value);
    transparent_crc(g_1931.f2, "g_1931.f2", print_hash_value);
    transparent_crc(g_1966, "g_1966", print_hash_value);
    transparent_crc(g_2063.f0, "g_2063.f0", print_hash_value);
    transparent_crc(g_2063.f1, "g_2063.f1", print_hash_value);
    transparent_crc(g_2063.f2, "g_2063.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2070[i].f0, "g_2070[i].f0", print_hash_value);
        transparent_crc(g_2070[i].f1, "g_2070[i].f1", print_hash_value);
        transparent_crc(g_2070[i].f2, "g_2070[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2091, "g_2091", print_hash_value);
    transparent_crc(g_2171, "g_2171", print_hash_value);
    transparent_crc(g_2233.f0, "g_2233.f0", print_hash_value);
    transparent_crc(g_2233.f1, "g_2233.f1", print_hash_value);
    transparent_crc(g_2233.f2, "g_2233.f2", print_hash_value);
    transparent_crc(g_2237, "g_2237", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_2248[i][j][k], "g_2248[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2256, "g_2256", print_hash_value);
    transparent_crc(g_2286, "g_2286", print_hash_value);
    transparent_crc(g_2338, "g_2338", print_hash_value);
    transparent_crc(g_2339, "g_2339", print_hash_value);
    transparent_crc(g_2466, "g_2466", print_hash_value);
    transparent_crc(g_2476.f0, "g_2476.f0", print_hash_value);
    transparent_crc(g_2476.f1, "g_2476.f1", print_hash_value);
    transparent_crc(g_2476.f2, "g_2476.f2", print_hash_value);
    transparent_crc(g_2479.f0, "g_2479.f0", print_hash_value);
    transparent_crc(g_2479.f1, "g_2479.f1", print_hash_value);
    transparent_crc(g_2479.f2, "g_2479.f2", print_hash_value);
    transparent_crc(g_2480, "g_2480", print_hash_value);
    transparent_crc(g_2524.f0, "g_2524.f0", print_hash_value);
    transparent_crc(g_2524.f1, "g_2524.f1", print_hash_value);
    transparent_crc(g_2524.f2, "g_2524.f2", print_hash_value);
    transparent_crc(g_2529, "g_2529", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 633
   depth: 1, occurrence: 19
XXX total union variables: 20

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 65
breakdown:
   indirect level: 0, occurrence: 19
   indirect level: 1, occurrence: 24
   indirect level: 2, occurrence: 9
   indirect level: 3, occurrence: 11
   indirect level: 4, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 36
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 20
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 3

XXX max expression depth: 48
breakdown:
   depth: 1, occurrence: 274
   depth: 2, occurrence: 69
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 2
   depth: 12, occurrence: 2
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 2
   depth: 19, occurrence: 7
   depth: 20, occurrence: 3
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 3
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 3
   depth: 28, occurrence: 3
   depth: 29, occurrence: 2
   depth: 31, occurrence: 2
   depth: 32, occurrence: 3
   depth: 35, occurrence: 3
   depth: 36, occurrence: 1
   depth: 37, occurrence: 3
   depth: 39, occurrence: 1
   depth: 44, occurrence: 1
   depth: 48, occurrence: 1

XXX total number of pointers: 577

XXX times a variable address is taken: 1305
XXX times a pointer is dereferenced on RHS: 342
breakdown:
   depth: 1, occurrence: 258
   depth: 2, occurrence: 77
   depth: 3, occurrence: 2
   depth: 4, occurrence: 5
XXX times a pointer is dereferenced on LHS: 383
breakdown:
   depth: 1, occurrence: 338
   depth: 2, occurrence: 36
   depth: 3, occurrence: 3
   depth: 4, occurrence: 6
XXX times a pointer is compared with null: 46
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 13
XXX times a pointer is qualified to be dereferenced: 7745

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2522
   level: 2, occurrence: 558
   level: 3, occurrence: 64
   level: 4, occurrence: 60
   level: 5, occurrence: 6
   level: 6, occurrence: 2
XXX number of pointers point to pointers: 264
XXX number of pointers point to scalars: 265
XXX number of pointers point to structs: 31
XXX percent of pointers has null in alias set: 27.7
XXX average alias set size: 1.47

XXX times a non-volatile is read: 1946
XXX times a non-volatile is write: 1098
XXX times a volatile is read: 166
XXX    times read thru a pointer: 44
XXX times a volatile is write: 42
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5.71e+03
XXX percentage of non-volatile access: 93.6

XXX forward jumps: 1
XXX backward jumps: 8

XXX stmts: 271
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 39
   depth: 2, occurrence: 38
   depth: 3, occurrence: 51
   depth: 4, occurrence: 52
   depth: 5, occurrence: 59

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

