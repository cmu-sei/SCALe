/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2891779627
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S6 {
   uint64_t  f0;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static int8_t g_3 = 0xC3L;
static int8_t *g_2 = &g_3;
static int32_t g_5 = (-9L);
static struct S6 g_6[10][5] = {{{18446744073709551615UL},{18446744073709551615UL},{1UL},{1UL},{0x44694486CAE8EF33LL}},{{0xE9A5A165F5C9B8DBLL},{1UL},{18446744073709551612UL},{1UL},{1UL}},{{1UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0x44694486CAE8EF33LL},{18446744073709551612UL},{18446744073709551615UL},{18446744073709551615UL},{1UL}},{{0xABFD090D790F9584LL},{1UL},{18446744073709551610UL},{1UL},{1UL}},{{8UL},{1UL},{1UL},{1UL},{18446744073709551615UL}},{{0xABFD090D790F9584LL},{8UL},{18446744073709551615UL},{8UL},{0xABFD090D790F9584LL}},{{0x44694486CAE8EF33LL},{0x2FB29D945AD33D2ALL},{18446744073709551615UL},{1UL},{18446744073709551612UL}},{{1UL},{0x0A1EE3199F2DC870LL},{1UL},{18446744073709551615UL},{0xE9A5A165F5C9B8DBLL}},{{0xE9A5A165F5C9B8DBLL},{8UL},{0x2FB29D945AD33D2ALL},{1UL},{0xE9A5A165F5C9B8DBLL}}};


/* --- FORWARD DECLARATIONS --- */
static struct S6  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6
 * writes: g_5
 */
static struct S6  func_1(void)
{ /* block id: 0 */
    int32_t *l_4 = &g_5;
    (*l_4) = ((void*)0 == g_2);
    return g_6[8][0];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_6[i][j].f0, "g_6[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 2
   depth: 2, occurrence: 1

XXX total number of pointers: 2

XXX times a variable address is taken: 2
XXX times a pointer is dereferenced on RHS: 0
breakdown:
XXX times a pointer is dereferenced on LHS: 1
breakdown:
   depth: 1, occurrence: 1
XXX times a pointer is compared with null: 1
XXX times a pointer is compared with address of another variable: 0
XXX times a pointer is compared with another pointer: 0
XXX times a pointer is qualified to be dereferenced: 0

XXX max dereference level: 1
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1
XXX number of pointers point to pointers: 0
XXX number of pointers point to scalars: 2
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 0
XXX average alias set size: 1

XXX times a non-volatile is read: 2
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 100
XXX percentage an existing variable is used: 0
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

