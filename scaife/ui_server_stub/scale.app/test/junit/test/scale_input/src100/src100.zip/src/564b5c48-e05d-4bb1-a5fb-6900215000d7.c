/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2948617305
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t *g_34 = (void*)0;
static int8_t g_36[8] = {0xE1L,0xE1L,0xE1L,0xE1L,0xE1L,0xE1L,0xE1L,0xE1L};
static int32_t g_40 = 6L;
static int8_t g_60 = 1L;
static int32_t g_72 = 1L;
static int32_t * volatile g_71[7] = {&g_72,&g_72,&g_72,&g_72,&g_72,&g_72,&g_72};
static int32_t * const  volatile g_73[8][1] = {{&g_72},{&g_72},{&g_72},{&g_72},{&g_72},{&g_72},{&g_72},{&g_72}};
static int32_t *g_83 = &g_72;
static int32_t *g_84 = (void*)0;
static uint64_t g_93 = 18446744073709551615UL;
static uint64_t g_112 = 0x733C455447BFCA48LL;
static uint32_t g_121 = 0x92D143BFL;
static uint16_t g_134 = 65535UL;
static uint16_t g_136 = 0x39EDL;
static volatile uint32_t g_164 = 18446744073709551609UL;/* VOLATILE GLOBAL g_164 */
static int64_t g_166 = (-5L);
static int16_t g_240 = 0x26B3L;
static int16_t *g_239 = &g_240;
static int16_t **g_238 = &g_239;
static int16_t *** volatile g_237 = &g_238;/* VOLATILE GLOBAL g_237 */
static uint32_t g_369 = 4294967293UL;
static const int32_t *g_387[3] = {&g_40,&g_40,&g_40};
static const int32_t ** volatile g_386 = &g_387[1];/* VOLATILE GLOBAL g_386 */
static volatile int64_t g_407 = 0x872142D83BD102BELL;/* VOLATILE GLOBAL g_407 */
static uint8_t g_412 = 0xBDL;
static const int32_t ** volatile g_449 = &g_387[1];/* VOLATILE GLOBAL g_449 */
static const int16_t g_463[1][10] = {{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)}};
static int64_t g_493 = 0x1EDD4D42CCD141AALL;
static int32_t g_494 = 0L;
static uint8_t g_515[2][6][10] = {{{0x57L,0x86L,247UL,0xCAL,0x11L,0x57L,0xCAL,0x39L,0xCAL,0x57L},{0xCAL,0xB4L,255UL,0xB4L,0xCAL,0x86L,0xB4L,0x04L,1UL,0xCAL},{0xCAL,0x36L,247UL,0xB4L,0xDBL,0xDBL,0xB4L,247UL,0x36L,0xCAL},{0xDBL,0xB4L,247UL,0x36L,0xCAL,0xDBL,0x36L,0x04L,0x36L,0xDBL},{0xCAL,0xB4L,255UL,0xB4L,0xCAL,0x86L,0xB4L,0x04L,1UL,0xCAL},{0xCAL,0x36L,247UL,0xB4L,0xDBL,0xDBL,0xB4L,247UL,0x36L,0xCAL}},{{0xDBL,0xB4L,247UL,0x36L,0xCAL,0xDBL,0x36L,0x04L,0x36L,0xDBL},{0xCAL,0xB4L,255UL,0xB4L,0xCAL,0x86L,0xB4L,0x04L,1UL,0xCAL},{0xCAL,0x36L,247UL,0xB4L,0xDBL,0xDBL,0xB4L,247UL,0x36L,0xCAL},{0xDBL,0xB4L,247UL,0x36L,0xCAL,0xDBL,0x36L,0x04L,0x36L,0xDBL},{0xCAL,0xB4L,255UL,0xB4L,0xCAL,0x86L,0xB4L,0x04L,1UL,0xCAL},{0xCAL,0x36L,247UL,0xB4L,0xDBL,0xDBL,0xB4L,247UL,0x36L,0xCAL}}};
static uint8_t * volatile g_514 = &g_515[1][5][6];/* VOLATILE GLOBAL g_514 */
static const int32_t ** volatile g_577 = (void*)0;/* VOLATILE GLOBAL g_577 */
static const int32_t ** volatile g_578 = &g_387[1];/* VOLATILE GLOBAL g_578 */
static volatile uint32_t g_593 = 4294967295UL;/* VOLATILE GLOBAL g_593 */
static int16_t ***g_652 = &g_238;
static int16_t ****g_651 = &g_652;
static uint8_t *g_703 = &g_515[0][4][9];
static const int32_t ** volatile g_738 = &g_387[1];/* VOLATILE GLOBAL g_738 */
static uint16_t **g_764 = (void*)0;
static const int32_t ** volatile g_815 = &g_387[1];/* VOLATILE GLOBAL g_815 */
static const int32_t ** const  volatile g_817 = (void*)0;/* VOLATILE GLOBAL g_817 */
static const int32_t ** const  volatile g_818[2] = {(void*)0,(void*)0};
static const int32_t ** const  volatile g_819[7] = {&g_387[0],&g_387[0],&g_387[0],&g_387[0],&g_387[0],&g_387[0],&g_387[0]};
static const int32_t ** volatile g_820[8][1][1] = {{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}},{{&g_387[1]}}};
static int16_t g_836 = 0x8639L;
static int16_t * const g_835 = &g_836;
static int16_t * const *g_834[8][9][3] = {{{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,(void*)0,(void*)0},{&g_835,&g_835,&g_835}},{{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,(void*)0,&g_835}},{{&g_835,&g_835,(void*)0},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,(void*)0,&g_835},{&g_835,(void*)0,(void*)0},{(void*)0,&g_835,&g_835}},{{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,(void*)0,(void*)0}},{{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,(void*)0,&g_835},{&g_835,&g_835,(void*)0},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{(void*)0,&g_835,&g_835}},{{&g_835,(void*)0,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,(void*)0,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835}},{{&g_835,&g_835,&g_835},{&g_835,&g_835,(void*)0},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,(void*)0,&g_835},{&g_835,(void*)0,(void*)0},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835}},{{&g_835,&g_835,&g_835},{(void*)0,&g_835,&g_835},{(void*)0,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,&g_835,&g_835},{&g_835,(void*)0,(void*)0},{&g_835,&g_835,&g_835}}};
static int16_t * const **g_833 = &g_834[2][4][0];
static int16_t * const ***g_832[10] = {&g_833,&g_833,&g_833,&g_833,&g_833,&g_833,&g_833,&g_833,&g_833,&g_833};
static int16_t * const ****g_831 = &g_832[4];
static int32_t ** volatile g_896 = &g_84;/* VOLATILE GLOBAL g_896 */
static int64_t g_951 = 7L;
static int8_t g_977 = (-10L);
static int32_t ** volatile g_1054[3][10][7] = {{{(void*)0,&g_84,&g_83,&g_83,(void*)0,&g_84,&g_83},{(void*)0,&g_83,&g_83,(void*)0,&g_84,&g_83,&g_83},{&g_83,&g_83,&g_83,(void*)0,(void*)0,&g_84,&g_84},{&g_84,&g_84,&g_84,&g_83,(void*)0,&g_84,&g_83},{(void*)0,&g_84,&g_83,(void*)0,&g_83,(void*)0,&g_83},{(void*)0,&g_84,&g_83,(void*)0,&g_83,&g_84,&g_84},{&g_83,&g_83,&g_84,&g_83,&g_84,&g_84,(void*)0},{&g_84,&g_83,(void*)0,&g_83,&g_83,&g_83,(void*)0},{&g_83,(void*)0,&g_84,&g_84,&g_83,&g_84,&g_83},{&g_84,&g_84,&g_84,(void*)0,&g_84,&g_84,&g_84}},{{(void*)0,&g_84,&g_84,(void*)0,&g_84,&g_83,&g_83},{&g_84,&g_83,&g_83,&g_83,(void*)0,&g_83,&g_84},{(void*)0,(void*)0,&g_83,&g_84,&g_83,&g_83,&g_83},{&g_83,&g_83,&g_83,&g_83,&g_83,(void*)0,&g_84},{&g_84,&g_83,&g_84,&g_83,&g_83,&g_83,&g_83},{&g_84,&g_84,&g_84,&g_83,&g_83,&g_83,(void*)0},{&g_84,&g_83,&g_83,&g_83,&g_84,&g_83,(void*)0},{&g_83,&g_83,&g_84,&g_84,&g_83,&g_83,&g_84},{(void*)0,&g_84,&g_83,&g_83,&g_84,&g_83,&g_83},{&g_83,(void*)0,&g_83,&g_84,&g_83,&g_83,&g_84}},{{&g_83,&g_84,&g_84,&g_84,&g_84,&g_84,&g_83},{(void*)0,&g_83,&g_83,&g_84,&g_83,&g_84,&g_84},{&g_84,&g_83,&g_84,&g_84,(void*)0,&g_84,&g_83},{&g_84,(void*)0,&g_84,&g_84,(void*)0,(void*)0,&g_84},{&g_83,(void*)0,&g_83,&g_83,&g_84,&g_84,(void*)0},{(void*)0,(void*)0,&g_83,(void*)0,&g_83,&g_84,&g_83},{&g_83,(void*)0,&g_83,&g_84,&g_83,&g_84,&g_83},{&g_84,&g_83,&g_84,&g_83,&g_83,(void*)0,&g_84},{&g_84,&g_83,&g_84,&g_84,&g_83,&g_84,&g_83},{&g_83,&g_83,&g_84,(void*)0,&g_84,&g_84,&g_84}}};
static int32_t ** volatile g_1055 = (void*)0;/* VOLATILE GLOBAL g_1055 */
static int32_t ** volatile g_1056 = &g_83;/* VOLATILE GLOBAL g_1056 */
static uint16_t *** volatile g_1150 = &g_764;/* VOLATILE GLOBAL g_1150 */
static uint64_t *g_1162 = &g_93;
static uint64_t **g_1161 = &g_1162;
static volatile int8_t g_1193 = 0x5DL;/* VOLATILE GLOBAL g_1193 */
static volatile uint16_t g_1230 = 0x212CL;/* VOLATILE GLOBAL g_1230 */
static int32_t g_1263 = 0x94F4B7E4L;
static int32_t g_1265 = (-1L);
static int32_t ** volatile g_1445 = &g_84;/* VOLATILE GLOBAL g_1445 */
static uint32_t g_1510 = 8UL;
static uint8_t **g_1564 = &g_703;
static uint8_t ***g_1563 = &g_1564;
static int32_t ** volatile g_1614 = &g_84;/* VOLATILE GLOBAL g_1614 */
static volatile uint16_t g_1616[7] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static int64_t g_1627 = 6L;
static int8_t g_1710 = (-1L);
static const uint64_t g_1734 = 0xDB29D616F9455EA1LL;
static uint8_t g_1751 = 0x00L;
static int32_t ** const  volatile g_1782 = &g_84;/* VOLATILE GLOBAL g_1782 */
static int32_t ** volatile g_1783 = (void*)0;/* VOLATILE GLOBAL g_1783 */
static uint32_t g_1850 = 0xA24AB0B7L;
static volatile int8_t g_1881 = 5L;/* VOLATILE GLOBAL g_1881 */
static int64_t *** volatile g_1971 = (void*)0;/* VOLATILE GLOBAL g_1971 */
static int16_t ***g_2019 = (void*)0;
static int16_t ***g_2020[1] = {&g_238};
static int16_t **** const g_2018[7][2] = {{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]},{&g_2020[0],&g_2020[0]}};
static int16_t **** const *g_2017 = &g_2018[2][1];
static const int32_t g_2242 = 9L;
static uint32_t g_2244[8][2][3] = {{{4294967287UL,0x7BEBA78AL,0xD1A56830L},{4294967287UL,4294967287UL,0x7BEBA78AL}},{{4294967295UL,0x7BEBA78AL,0x7BEBA78AL},{0x7BEBA78AL,0x84A77F9EL,0xD1A56830L}},{{4294967295UL,0x84A77F9EL,4294967295UL},{4294967287UL,0x7BEBA78AL,0xD1A56830L}},{{4294967287UL,4294967287UL,0x7BEBA78AL},{4294967295UL,0x7BEBA78AL,0x7BEBA78AL}},{{0x7BEBA78AL,0x84A77F9EL,0xD1A56830L},{4294967295UL,0x84A77F9EL,4294967295UL}},{{4294967287UL,0x7BEBA78AL,0xD1A56830L},{4294967287UL,4294967287UL,0x7BEBA78AL}},{{4294967295UL,0x7BEBA78AL,0x7BEBA78AL},{0x7BEBA78AL,0x84A77F9EL,0xD1A56830L}},{{4294967295UL,0x84A77F9EL,4294967295UL},{4294967287UL,0x7BEBA78AL,0xD1A56830L}}};
static volatile uint32_t **g_2302 = (void*)0;
static volatile uint32_t ***g_2301 = &g_2302;
static uint8_t *** volatile g_2373 = &g_1564;/* VOLATILE GLOBAL g_2373 */
static volatile uint16_t g_2418 = 65528UL;/* VOLATILE GLOBAL g_2418 */
static uint64_t ***g_2469[6][6][6] = {{{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161,(void*)0,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,(void*)0}},{{&g_1161,&g_1161,&g_1161,(void*)0,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,(void*)0},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161}},{{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161,(void*)0,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,(void*)0},{&g_1161,&g_1161,&g_1161,(void*)0,&g_1161,&g_1161}},{{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,(void*)0},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,(void*)0,&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,(void*)0,&g_1161,&g_1161,&g_1161}},{{&g_1161,&g_1161,(void*)0,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{(void*)0,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{(void*)0,(void*)0,&g_1161,&g_1161,&g_1161,&g_1161},{(void*)0,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161,&g_1161,(void*)0,&g_1161}},{{&g_1161,&g_1161,&g_1161,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161,&g_1161,(void*)0,&g_1161},{&g_1161,(void*)0,&g_1161,(void*)0,&g_1161,&g_1161},{&g_1161,&g_1161,(void*)0,&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,(void*)0,&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,(void*)0,&g_1161,&g_1161,&g_1161}}};
static volatile uint32_t g_2488 = 0xC69F49F4L;/* VOLATILE GLOBAL g_2488 */
static const uint64_t *g_2532 = &g_1734;
static const uint64_t **g_2531 = &g_2532;
static const uint64_t ***g_2530 = &g_2531;
static const int32_t ** volatile g_2568 = &g_387[1];/* VOLATILE GLOBAL g_2568 */
static int32_t g_2577[2][8] = {{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L}};
static uint32_t *g_2580 = &g_2244[4][1][2];
static uint32_t * const *g_2579[6] = {&g_2580,&g_2580,&g_2580,&g_2580,&g_2580,&g_2580};
static uint32_t * const **g_2578 = &g_2579[1];


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t * func_2(int32_t  p_3, uint16_t  p_4);
static uint64_t  func_8(int32_t  p_9, int32_t  p_10, int32_t * const  p_11, int8_t  p_12, int32_t  p_13);
static int32_t  func_14(uint32_t  p_15, int64_t  p_16, int64_t  p_17);
static int32_t  func_22(int32_t * p_23, uint32_t  p_24);
static int32_t * func_25(uint8_t  p_26, int16_t  p_27, int32_t * p_28);
static int8_t  func_29(uint32_t  p_30, uint32_t  p_31, int32_t  p_32, int16_t  p_33);
static int8_t  func_42(uint32_t  p_43);
static uint8_t  func_49(int32_t * p_50, const int32_t * p_51, int8_t * p_52, int32_t * p_53);
static int32_t * func_54(int8_t * p_55, const int32_t * p_56, uint8_t  p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_34 g_36 g_121 g_835 g_836 g_136 g_240 g_166 g_93 g_515 g_896 g_514 g_40 g_239 g_493 g_652 g_238 g_831 g_832 g_237 g_112 g_369 g_703 g_951 g_83 g_72 g_977 g_164 g_134 g_738 g_387 g_449 g_1056 g_463 g_494 g_386 g_412 g_593 g_1150 g_1161 g_1162 g_764 g_1193 g_1230 g_815 g_1263 g_60 g_651 g_1445 g_1265 g_1510 g_407 g_1564 g_1751 g_1710 g_1563 g_84 g_1782 g_578 g_1734 g_1616 g_1971 g_2017 g_2018 g_2301 g_1850 g_2373 g_1627 g_2244 g_2418 g_2302 g_2488 g_2530 g_2242 g_2568 g_2578
 * writes: g_36 g_121 g_93 g_369 g_84 g_515 g_72 g_836 g_493 g_112 g_83 g_652 g_136 g_951 g_60 g_977 g_764 g_240 g_1230 g_1263 g_1265 g_166 g_412 g_40 g_134 g_1510 g_1563 g_1751 g_238 g_1627 g_387 g_2244 g_1710 g_1161 g_1564 g_1850 g_2469 g_2530 g_494 g_2577 g_2578
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_5 = 18446744073709551606UL;
    int8_t *l_35[5] = {&g_36[7],&g_36[7],&g_36[7],&g_36[7],&g_36[7]};
    int32_t *l_39 = &g_40;
    const uint64_t l_923[6][7] = {{0x3DB8AD71E1881D5ELL,0xEAF3151B5F15FAE0LL,0xEAF3151B5F15FAE0LL,0x3DB8AD71E1881D5ELL,1UL,0x3DB8AD71E1881D5ELL,0xEAF3151B5F15FAE0LL},{0UL,0UL,0xDBF6E15E3ECAEA6FLL,0x630C9C15FF0EB163LL,0xDBF6E15E3ECAEA6FLL,0UL,0UL},{0x083A5DA7978D3B4BLL,0xEAF3151B5F15FAE0LL,0UL,0xEAF3151B5F15FAE0LL,0x083A5DA7978D3B4BLL,0x083A5DA7978D3B4BLL,0xEAF3151B5F15FAE0LL},{0UL,0xD6BDB6E3910E239CLL,0UL,0xDBF6E15E3ECAEA6FLL,0xDBF6E15E3ECAEA6FLL,0UL,0xD6BDB6E3910E239CLL},{0xEAF3151B5F15FAE0LL,1UL,0UL,0UL,1UL,0xEAF3151B5F15FAE0LL,1UL},{0UL,0xDBF6E15E3ECAEA6FLL,0xDBF6E15E3ECAEA6FLL,0UL,0xD6BDB6E3910E239CLL,0UL,0xDBF6E15E3ECAEA6FLL}};
    const int8_t l_1381 = 0x6CL;
    int32_t **l_1383 = &l_39;
    int32_t **l_1384[4] = {&g_83,&g_83,&g_83,&g_83};
    uint32_t l_1418 = 1UL;
    int32_t *l_2243[3][7][9] = {{{&g_1263,&g_1263,&g_1263,&g_1265,&g_1265,&g_1265,&g_1263,&g_1263,&g_1263},{&g_1263,(void*)0,(void*)0,&g_1265,(void*)0,(void*)0,&g_1263,&g_1265,&g_1263},{&g_1265,(void*)0,&g_1263,(void*)0,&g_1265,&g_1263,&g_1263,&g_1265,(void*)0},{&g_1263,&g_1263,&g_1263,&g_1265,&g_1265,&g_1263,&g_1265,&g_1265,&g_1265},{&g_1265,&g_1265,&g_1263,&g_1263,&g_1263,&g_1263,&g_1265,&g_1265,&g_1265},{&g_1263,&g_1265,&g_1265,(void*)0,&g_1265,&g_1265,(void*)0,&g_1265,&g_1265},{(void*)0,&g_1265,&g_1265,(void*)0,&g_1265,&g_1263,&g_1265,(void*)0,&g_1265}},{{&g_1265,&g_1265,(void*)0,&g_1265,&g_1263,&g_1265,(void*)0,&g_1265,&g_1265},{&g_1265,(void*)0,&g_1265,&g_1263,&g_1265,(void*)0,&g_1265,&g_1265,(void*)0},{&g_1265,&g_1265,(void*)0,&g_1265,&g_1265,(void*)0,&g_1265,&g_1265,&g_1263},{&g_1265,&g_1265,&g_1265,&g_1263,&g_1263,&g_1263,&g_1263,&g_1265,&g_1265},{&g_1265,&g_1265,&g_1265,&g_1263,(void*)0,(void*)0,(void*)0,&g_1265,(void*)0},{(void*)0,&g_1263,&g_1263,&g_1263,&g_1263,(void*)0,&g_1263,(void*)0,&g_1263},{&g_1263,&g_1265,(void*)0,&g_1265,&g_1265,&g_1265,&g_1265,&g_1265,(void*)0}},{{&g_1265,&g_1265,&g_1263,&g_1263,(void*)0,&g_1263,&g_1263,&g_1265,&g_1265},{(void*)0,&g_1265,&g_1265,&g_1265,&g_1265,&g_1265,(void*)0,&g_1265,&g_1263},{&g_1263,(void*)0,&g_1263,(void*)0,&g_1263,&g_1263,&g_1263,&g_1263,(void*)0},{(void*)0,&g_1265,(void*)0,(void*)0,(void*)0,&g_1263,&g_1265,&g_1265,&g_1265},{&g_1265,&g_1265,&g_1263,&g_1263,&g_1263,&g_1263,&g_1265,&g_1265,&g_1265},{&g_1263,&g_1265,&g_1265,(void*)0,&g_1265,&g_1265,(void*)0,&g_1265,&g_1265},{(void*)0,&g_1265,&g_1265,(void*)0,&g_1265,&g_1263,&g_1265,(void*)0,&g_1265}}};
    int64_t l_2245 = 0L;
    uint16_t l_2246 = 0xA085L;
    int32_t l_2247[6];
    uint32_t l_2248 = 6UL;
    int16_t l_2249 = 0x48EDL;
    int16_t l_2377 = 0x4DCAL;
    int32_t l_2385 = 0x0C79545CL;
    uint32_t l_2408 = 0x9C5D2D45L;
    uint16_t l_2413 = 7UL;
    int32_t l_2415 = 0xB8B9EB6CL;
    int32_t l_2456 = (-1L);
    int16_t l_2489[9][3][3] = {{{0xFEF2L,0x5E2FL,1L},{(-3L),0x88CFL,0x7A65L},{0xFEF2L,0x7A65L,0x5E2FL}},{{0x33BDL,0x7A65L,3L},{0L,0x88CFL,0x88CFL},{0xF91AL,0x5E2FL,3L}},{{(-1L),(-6L),0x5E2FL},{(-1L),0x7524L,0x7A65L},{0xF91AL,1L,1L}},{{0L,0x7524L,(-1L)},{0x33BDL,(-6L),(-1L)},{(-1L),0x553CL,0x152EL}},{{0x1D22L,(-4L),0x5B44L},{(-1L),0x5B44L,0x553CL},{1L,0x5B44L,6L}},{{0x88CFL,(-4L),(-4L)},{0x7524L,0x553CL,6L},{1L,0x181AL,0x553CL}},{{1L,0L,0x5B44L},{0x7524L,(-10L),0x152EL},{0x88CFL,0L,8L}},{{1L,0x181AL,8L},{(-1L),0x553CL,0x152EL},{0x1D22L,(-4L),0x5B44L}},{{(-1L),0x5B44L,0x553CL},{1L,0x5B44L,6L},{0x88CFL,(-4L),(-4L)}}};
    uint8_t *l_2520 = &g_515[0][0][7];
    uint8_t **l_2519 = &l_2520;
    uint8_t l_2525 = 255UL;
    uint16_t l_2571[10][6][4] = {{{0x4167L,0xA5FDL,4UL,2UL},{1UL,0xA2BBL,0xA2BBL,1UL},{1UL,0x4167L,0xE5A6L,6UL},{0xE5A6L,6UL,65535UL,0xA5FDL},{2UL,0xD577L,0UL,0xA5FDL},{65535UL,6UL,2UL,6UL}},{{0x7830L,0x4167L,0x442CL,1UL},{65535UL,0xA2BBL,65535UL,2UL},{0xD577L,0xA5FDL,2UL,65535UL},{0xD577L,1UL,65535UL,65535UL},{65535UL,65535UL,0x442CL,4UL},{0x7830L,0x442CL,2UL,0x4167L}},{{65535UL,0xE5A6L,0UL,2UL},{2UL,0xE5A6L,65535UL,0x4167L},{0xE5A6L,0x442CL,0xE5A6L,4UL},{1UL,65535UL,0xA2BBL,65535UL},{1UL,1UL,4UL,65535UL},{0x4167L,0xA5FDL,4UL,2UL}},{{1UL,0xA2BBL,0xA2BBL,1UL},{1UL,0x4167L,0xE5A6L,6UL},{0xE5A6L,6UL,65535UL,0xA5FDL},{2UL,0xD577L,0UL,0xA5FDL},{65535UL,6UL,2UL,6UL},{0x7830L,0x4167L,0x442CL,1UL}},{{65535UL,0xA2BBL,65535UL,2UL},{0xD577L,0xA5FDL,2UL,65535UL},{0xD577L,1UL,65535UL,65535UL},{65535UL,65535UL,0x442CL,4UL},{0x7830L,0x442CL,2UL,0x4167L},{65535UL,0xE5A6L,0UL,2UL}},{{2UL,0xE5A6L,65535UL,0x4167L},{0xE5A6L,0x442CL,0xE5A6L,4UL},{1UL,65535UL,0xA2BBL,65535UL},{1UL,1UL,4UL,65535UL},{0x4167L,0xA5FDL,4UL,2UL},{1UL,0xA2BBL,0xA2BBL,0x7830L}},{{0xA2BBL,1UL,0xAACCL,65535UL},{0xAACCL,65535UL,2UL,0xD577L},{0x4167L,6UL,2UL,0xD577L},{0xE5A6L,65535UL,0x4167L,65535UL},{4UL,1UL,0xA5FDL,0x7830L},{2UL,0UL,0xE5A6L,65535UL}},{{6UL,0xD577L,65535UL,2UL},{6UL,0xA2BBL,0xE5A6L,0xE5A6L},{2UL,2UL,0xA5FDL,1UL},{4UL,0xA5FDL,0x4167L,1UL},{0xE5A6L,0xAACCL,2UL,0x4167L},{0x4167L,0xAACCL,2UL,1UL}},{{0xAACCL,0xA5FDL,0xAACCL,1UL},{0xA2BBL,2UL,0UL,0xE5A6L},{0x7830L,0xA2BBL,1UL,2UL},{1UL,0xD577L,1UL,65535UL},{0x7830L,0UL,0UL,0x7830L},{0xA2BBL,1UL,0xAACCL,65535UL}},{{0xAACCL,65535UL,2UL,0xD577L},{0x4167L,6UL,2UL,0xD577L},{0xE5A6L,65535UL,0x4167L,65535UL},{4UL,1UL,0xA5FDL,0x7830L},{2UL,0UL,0xE5A6L,65535UL},{6UL,0xD577L,65535UL,2UL}}};
    uint64_t l_2589 = 0x8E751DB89D625989LL;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_2247[i] = 1L;
    (*l_1383) = func_2((l_2249 = ((((((l_5 , ((safe_div_func_int64_t_s_s((-10L), func_8((l_2245 = (g_2244[4][1][2] = func_14((safe_add_func_int32_t_s_s((safe_mul_func_int16_t_s_s((((l_5 || (l_1418 = func_22(((*g_896) = ((*l_1383) = func_25(((1UL != (func_29((((g_36[3] = ((void*)0 == g_34)) && (safe_sub_func_uint64_t_u_u(((void*)0 != l_39), (+((func_42(((((safe_mul_func_int8_t_s_s((safe_unary_minus_func_uint32_t_u((safe_rshift_func_uint8_t_u_s(((*g_514) = func_49(func_54(l_35[0], l_39, g_36[5]), l_39, &g_60, l_39)), 4)))), (*l_39))) , (*g_239)) == g_36[1]) | (*l_39))) ^ (*l_39)) != 0x24EB508CL))))) <= l_923[5][1]), g_493, (*l_39), (***g_652)) , l_1381)) , (*l_39)), l_1381, &g_494))), g_463[0][7]))) == (-1L)) && 0x7C50B50DL), 0xB088L)), g_463[0][9])), g_463[0][1], g_463[0][4]))), g_494, &g_494, g_1734, g_463[0][4]))) , 65535UL)) || g_1616[2]) && (*g_514)) >= l_2246) , l_2247[1]) , l_2248)), g_494);
lbl_2572:
    (*l_1383) = (void*)0;
    if ((*g_83))
    { /* block id: 1081 */
        int32_t l_2367 = (-10L);
        return l_2367;
    }
    else
    { /* block id: 1083 */
        uint8_t l_2370 = 5UL;
        int32_t l_2371 = 0x6C89EFCAL;
        uint8_t **l_2372 = (void*)0;
        int32_t l_2374 = 0x37DB2F1FL;
        int64_t *l_2378 = &g_1627;
        uint32_t *l_2381 = &g_2244[0][1][2];
        int64_t *l_2382 = &l_2245;
        int32_t l_2384 = 2L;
        int32_t l_2387 = (-1L);
        int32_t l_2389 = 0x3A865814L;
        int32_t l_2390 = 0L;
        int32_t l_2391 = 1L;
        int32_t l_2392 = 0L;
        int32_t l_2393 = (-1L);
        int32_t l_2394 = (-1L);
        int32_t **l_2414 = &g_83;
        (*g_2373) = (l_2372 = ((safe_mul_func_int16_t_s_s(((**g_238) = l_2370), ((*g_835) = (l_2371 |= 0xB4ADL)))) , l_2372));
        if (((l_2374 | ((l_2371 , l_2374) || ((((*l_2378) &= (safe_lshift_func_uint8_t_u_s(l_2377, 6))) ^ 1L) || 0x4514AF70L))) ^ (safe_mod_func_int64_t_s_s(g_1751, ((*l_2382) = ((((*l_2381) |= (0L == g_36[1])) <= 0L) & l_2374))))))
        { /* block id: 1092 */
            int64_t l_2383[8] = {1L,0xBB51946FF8D6F025LL,0xBB51946FF8D6F025LL,1L,0xBB51946FF8D6F025LL,0xBB51946FF8D6F025LL,1L,0xBB51946FF8D6F025LL};
            int32_t l_2386 = (-6L);
            int32_t l_2388[8][2];
            uint32_t l_2395[4][4];
            int i, j;
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 2; j++)
                    l_2388[i][j] = 0x7D706192L;
            }
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 4; j++)
                    l_2395[i][j] = 0x3EF0E739L;
            }
            l_2395[0][3]--;
        }
        else
        { /* block id: 1094 */
            int32_t l_2398 = 0x6ED11156L;
            int32_t l_2399 = 8L;
            int32_t l_2400[1][6] = {{0x34C7AB59L,0x34C7AB59L,0x34C7AB59L,0x34C7AB59L,0x34C7AB59L,0x34C7AB59L}};
            uint64_t l_2401[5][7] = {{0xCE09499CAD8E44A9LL,0xCE09499CAD8E44A9LL,0x8DC6AC73B26C908BLL,0xCE09499CAD8E44A9LL,0xCE09499CAD8E44A9LL,0x8DC6AC73B26C908BLL,0xCE09499CAD8E44A9LL},{0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL},{0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL},{0xCE09499CAD8E44A9LL,0xCE09499CAD8E44A9LL,0x8DC6AC73B26C908BLL,0xCE09499CAD8E44A9LL,0xCE09499CAD8E44A9LL,0x8DC6AC73B26C908BLL,0xCE09499CAD8E44A9LL},{0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL,0xE98FB27FCA385497LL,0xE98FB27FCA385497LL,0xCE09499CAD8E44A9LL}};
            int i, j;
            l_2401[4][5]++;
            l_2399 = ((l_2400[0][2] &= ((*g_239) = (((*g_1161) == (void*)0) >= ((*g_83) = (safe_mul_func_uint16_t_u_u(l_2394, 65530UL)))))) <= ((safe_rshift_func_int16_t_s_s(l_2408, 2)) ^ 0x5E5BL));
            (**l_2414) |= (safe_rshift_func_uint8_t_u_u(((l_2387 && (((((safe_div_func_int8_t_s_s(g_515[1][5][6], l_2400[0][2])) > l_2401[4][5]) > l_2413) , l_2414) == (void*)0)) < (0L ^ 5L)), (*g_703)));
            (**l_2414) = l_2415;
        }
    }
    for (g_369 = 0; (g_369 <= 1); g_369 += 1)
    { /* block id: 1106 */
        int16_t *l_2454[8] = {(void*)0,&l_2249,(void*)0,(void*)0,&l_2249,(void*)0,(void*)0,&l_2249};
        int32_t l_2461 = 0L;
        int64_t l_2478 = 0x106DEA3CB6E05511LL;
        const int16_t *l_2508[10] = {&g_463[0][7],&l_2489[5][1][1],&l_2489[8][1][1],&l_2489[8][1][1],&l_2489[5][1][1],&g_463[0][7],&l_2489[5][1][1],&l_2489[8][1][1],&l_2489[8][1][1],&l_2489[5][1][1]};
        const int16_t **l_2507[6][7] = {{&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0]},{&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0]},{&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0]},{&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0]},{&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0],&l_2508[2],&l_2508[0]},{&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0],&l_2508[0]}};
        const int16_t ***l_2506 = &l_2507[2][1];
        int32_t l_2573 = (-1L);
        uint16_t l_2586[9] = {0x3ACAL,0x7F0AL,0x3ACAL,0x7F0AL,0x3ACAL,0x7F0AL,0x3ACAL,0x7F0AL,0x3ACAL};
        int i, j;
        g_387[g_369] = (*g_1056);
        for (g_240 = 1; (g_240 >= 0); g_240 -= 1)
        { /* block id: 1110 */
            int16_t l_2439[7] = {0x73F4L,0x73F4L,0x73F4L,0x73F4L,0x73F4L,0x73F4L,0x73F4L};
            int32_t l_2455 = 0x47A3887CL;
            uint32_t *l_2460 = &g_1850;
            uint8_t ** const l_2521 = &l_2520;
            int64_t l_2522 = 0x92017A1B5571592FLL;
            uint32_t *l_2560[2];
            uint32_t **l_2559 = &l_2560[1];
            int8_t l_2584 = 0x2AL;
            int i;
            for (i = 0; i < 2; i++)
                l_2560[i] = &g_121;
            for (g_977 = 0; (g_977 <= 2); g_977 += 1)
            { /* block id: 1113 */
                uint16_t l_2425[1][3][4] = {{{6UL,6UL,0UL,6UL},{6UL,0x94D7L,0x94D7L,6UL},{0x94D7L,6UL,0x94D7L,0x94D7L}}};
                uint32_t **l_2448 = (void*)0;
                int32_t l_2449 = 0xD6F1835DL;
                uint32_t *l_2470 = &l_2248;
                int32_t l_2490 = 0x0F128A65L;
                uint8_t **l_2546 = (void*)0;
                const int32_t *l_2567 = &l_2449;
                uint32_t * const ***l_2581 = &g_2578;
                int i, j, k;
                if ((safe_rshift_func_uint16_t_u_s(0x96FDL, g_2418)))
                { /* block id: 1114 */
                    int64_t l_2419 = 1L;
                    for (l_2385 = 2; (l_2385 >= 0); l_2385 -= 1)
                    { /* block id: 1117 */
                        uint64_t l_2420 = 0xE2DDB6612338FDF0LL;
                        l_2420++;
                    }
                    l_2449 = (safe_div_func_int32_t_s_s(l_2425[0][0][3], ((safe_unary_minus_func_int16_t_s(((*g_514) & ((safe_mul_func_uint16_t_u_u(l_2425[0][0][3], (safe_div_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((safe_sub_func_int32_t_s_s(l_2439[6], (safe_mul_func_int8_t_s_s((g_36[3] ^= (safe_sub_func_uint16_t_u_u((((safe_add_func_int32_t_s_s(((safe_sub_func_uint8_t_u_u(l_2419, (l_2439[6] >= ((((*g_2301) == l_2448) >= 0x88616C9711037760LL) ^ l_2419)))) & 1L), (*g_83))) == g_72) != l_2439[0]), l_2439[6]))), l_2439[3])))), g_515[1][5][6])), g_369)), l_2439[6])) < (***g_652)), g_493)))) , g_136)))) , l_2425[0][2][2])));
                }
                else
                { /* block id: 1122 */
                    (*g_83) ^= (l_2455 = ((safe_lshift_func_uint8_t_u_s(l_2449, 6)) | ((void*)0 == l_2454[3])));
                    for (l_2248 = 0; (l_2248 <= 2); l_2248 += 1)
                    { /* block id: 1127 */
                        uint32_t l_2457 = 0x35399324L;
                        (*g_83) = l_2456;
                        --l_2457;
                    }
                    for (g_1850 = 0; (g_1850 <= 1); g_1850 += 1)
                    { /* block id: 1133 */
                        uint64_t ***l_2466[2][8][3] = {{{&g_1161,&g_1161,(void*)0},{&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161},{&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161},{(void*)0,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161}},{{&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,(void*)0},{&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,(void*)0},{&g_1161,&g_1161,&g_1161},{&g_1161,&g_1161,&g_1161},{&g_1161,(void*)0,&g_1161},{&g_1161,&g_1161,&g_1161}}};
                        uint64_t ****l_2465 = &l_2466[1][1][1];
                        uint64_t ***l_2468[5] = {&g_1161,&g_1161,&g_1161,&g_1161,&g_1161};
                        uint64_t ****l_2467[3];
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_2467[i] = &l_2468[4];
                        l_2461 ^= ((*g_83) = ((void*)0 == l_2460));
                        g_387[g_977] = ((*l_1383) = func_54(((!(g_60 > (((*l_2465) = &g_1161) == (g_2469[4][5][4] = &g_1161)))) , &g_1710), &l_2449, l_2439[3]));
                    }
                }
                if ((((*l_2470) = 8UL) < (l_2425[0][0][3] > (safe_mul_func_uint16_t_u_u((safe_add_func_int32_t_s_s((l_2490 ^= ((l_2439[6] && (safe_mul_func_int16_t_s_s((((!1UL) == l_2478) ^ ((+l_2449) <= (safe_div_func_uint32_t_u_u((0x82L || (((safe_lshift_func_uint8_t_u_u(0xFFL, ((safe_lshift_func_int16_t_s_s(((((safe_add_func_uint8_t_u_u(0xACL, (*g_703))) | g_2488) ^ l_2425[0][0][3]) && l_2425[0][0][3]), l_2425[0][1][1])) , l_2449))) > l_2489[5][1][1]) || l_2439[3])), (*g_83))))), 1UL))) ^ l_2439[6])), g_951)), g_60)))))
                { /* block id: 1144 */
                    uint32_t l_2495 = 0x9889D183L;
                    uint8_t **l_2518[1][8][2] = {{{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703},{&g_703,&g_703}}};
                    uint64_t ***l_2535 = (void*)0;
                    int i, j, k;
                    if ((l_2455 < (safe_sub_func_int32_t_s_s((((l_2495 > (((**g_1056) > ((safe_mod_func_int16_t_s_s((((safe_mod_func_int8_t_s_s(((*g_703) > ((safe_mod_func_uint8_t_u_u(((g_493 ^= (safe_mod_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u(l_2495, (l_2495 != ((void*)0 != l_2506)))), (((safe_lshift_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s((+(safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((((l_2519 = l_2518[0][7][1]) != l_2521) >= l_2439[6]), g_1710)), g_951))), 1)) | 0x144CL), g_36[1])) != (-2L)) && l_2495)))) != 0x2DFF457AF73D9572LL), l_2439[6])) | 0xB5A4L)), g_136)) | (*g_703)) & (-1L)), (**g_238))) != 0x1F61L)) , 0UL)) ^ g_977) , l_2495), g_40))))
                    { /* block id: 1147 */
                        return (**g_238);
                    }
                    else
                    { /* block id: 1149 */
                        uint16_t l_2526 = 65535UL;
                        const uint64_t ****l_2533 = (void*)0;
                        const uint64_t ****l_2534 = &g_2530;
                        int i, j, k;
                        l_2522 = 6L;
                        (*g_83) |= (safe_mul_func_int8_t_s_s(((g_494 ^ l_2525) && (-6L)), l_2495));
                        (*g_83) = (((l_2526 == (safe_unary_minus_func_int16_t_s(((((*l_2534) = ((safe_lshift_func_int16_t_s_u(((-4L) != g_1710), 1)) , g_2530)) == (l_2535 = &g_1161)) <= (safe_sub_func_uint8_t_u_u((g_515[g_369][(g_240 + 1)][(g_369 + 3)]++), (safe_mul_func_int16_t_s_s((safe_unary_minus_func_int64_t_s((-9L))), (safe_unary_minus_func_int32_t_s((safe_lshift_func_int8_t_s_u((l_2546 == (*g_2373)), (l_2461 = l_2449))))))))))))) || l_2439[2]) & 0xE2L);
                    }
                }
                else
                { /* block id: 1158 */
                    uint8_t *l_2561 = &g_1751;
                    int32_t l_2566 = 0x7C3A4338L;
                    if (((safe_div_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_u(1UL, 15)) && (l_2449 ^= (safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_s((&l_2522 != (((*l_2561) = ((**l_2519) |= (g_36[2] & (((*g_835) , l_2559) != (void*)0)))) , (void*)0)), 4)), 1)), (((l_2461 = (safe_mul_func_int16_t_s_s((255UL > (safe_sub_func_int8_t_s_s(7L, g_1265))), l_2425[0][0][3]))) <= g_951) & 0x599BL))))), g_2242)), l_2566)) , l_2566))
                    { /* block id: 1163 */
                        (*g_2568) = l_2567;
                        return (**g_238);
                    }
                    else
                    { /* block id: 1166 */
                        uint16_t l_2570 = 0xAC20L;
                        l_2490 ^= ((!l_2570) , (l_2571[3][3][0] == ((*g_83) = (*l_2567))));
                    }
                    for (g_1263 = 0; (g_1263 <= 2); g_1263 += 1)
                    { /* block id: 1172 */
                        if (l_2456)
                            goto lbl_2572;
                        (*l_1383) = &l_2461;
                    }
                }
                for (g_166 = 0; (g_166 <= 2); g_166 += 1)
                { /* block id: 1179 */
                    uint64_t l_2574 = 0x98A66508A08634DDLL;
                    l_2574--;
                    for (g_494 = 0; (g_494 <= 2); g_494 += 1)
                    { /* block id: 1183 */
                        if ((*g_83))
                            break;
                    }
                    g_2577[0][4] = ((void*)0 != &l_2560[1]);
                }
                (*g_83) = (((*l_2581) = g_2578) == (void*)0);
            }
            (*g_83) = l_2522;
            for (g_93 = 0; (g_93 <= 2); g_93 += 1)
            { /* block id: 1194 */
                int16_t l_2582 = 0xB21FL;
                int32_t l_2583 = 3L;
                int32_t l_2585 = 0L;
                l_2586[8]++;
            }
            for (g_93 = 0; (g_93 <= 2); g_93 += 1)
            { /* block id: 1199 */
                (*l_1383) = &l_2461;
            }
        }
    }
    return l_2589;
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_72 g_238 g_239 g_240 g_1971 g_494 g_93 g_836 g_1161 g_1162 g_412 g_1710 g_83 g_2017 g_2018 g_1230 g_1564 g_703 g_515 g_40 g_652 g_2301 g_36 g_1056 g_463 g_1850 g_514
 * writes: g_60 g_72 g_121 g_493 g_1710 g_40 g_240 g_134 g_1161 g_93 g_515
 */
static int32_t * func_2(int32_t  p_3, uint16_t  p_4)
{ /* block id: 1035 */
    const int16_t l_2263 = 0xA7BFL;
    const int32_t *l_2282 = &g_494;
    uint8_t **l_2283 = &g_703;
    int32_t l_2284 = 0xF0768CA9L;
    int64_t *l_2285 = (void*)0;
    int64_t *l_2286 = &g_493;
    int8_t *l_2287 = &g_1710;
    int16_t ****l_2288 = &g_2019;
    int32_t l_2338 = 0x3FC29A35L;
    int32_t l_2339 = 0L;
    int32_t l_2340 = 0xC75241B7L;
    uint8_t l_2341 = 0x65L;
    uint64_t **l_2357[7];
    uint64_t ***l_2358 = &l_2357[3];
    int32_t l_2363 = 0x67A11B7BL;
    uint64_t ***l_2364 = &g_1161;
    int8_t *l_2365 = &g_60;
    int32_t *l_2366[1][6] = {{&g_40,&g_40,&g_40,&g_40,&g_40,&g_40}};
    int i, j;
    for (i = 0; i < 7; i++)
        l_2357[i] = &g_1162;
    for (g_60 = 0; (g_60 <= 29); g_60++)
    { /* block id: 1038 */
        uint8_t l_2254 = 0xECL;
        for (g_72 = 29; (g_72 == (-17)); g_72 = safe_sub_func_int16_t_s_s(g_72, 8))
        { /* block id: 1041 */
            if (l_2254)
                break;
        }
    }
    if (((((g_40 &= (((+((((safe_mul_func_uint8_t_u_u(((safe_div_func_int16_t_s_s(((**g_238) & ((((*l_2287) = ((((((safe_sub_func_uint8_t_u_u(((p_4 == (((~l_2263) >= 0x7EB2L) , ((*l_2286) = (g_1971 == ((((safe_add_func_int8_t_s_s((((l_2284 = (g_121 = ((safe_sub_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_s(((safe_lshift_func_int8_t_s_s((!(!((((((safe_rshift_func_uint16_t_u_s((((((l_2263 || ((!(safe_unary_minus_func_uint16_t_u((safe_add_func_uint32_t_u_u(g_60, (l_2282 == l_2282)))))) , (*l_2282))) >= p_3) == (*l_2282)) == g_93) | g_836), 7)) , &g_703) == l_2283) != (*l_2282)) & p_4) <= (**g_1161)))), (*l_2282))) | p_3), (*l_2282))) , 5L), 5)) , p_4), 0x1C78L)) < p_4))) | (*l_2282)) == g_412), g_1710)) , l_2282) != l_2282) , (void*)0))))) < p_3), p_3)) , (-1L)) , p_3) || (*l_2282)) ^ (*g_1162)) != (*g_83))) , l_2288) != (*g_2017))), 9L)) || g_1230), (**g_1564))) >= p_3) > 2UL) || 247UL)) | p_4) , 0xD08A1AE8L)) > (*g_83)) >= (*g_83)) , 0x19AEE28DL))
    { /* block id: 1050 */
        int16_t l_2308[1];
        int32_t *l_2315 = &l_2284;
        int i;
        for (i = 0; i < 1; i++)
            l_2308[i] = 0x7E92L;
        (*g_83) = 0x5420B66CL;
        if ((*l_2282))
        { /* block id: 1052 */
            (*g_83) = (safe_div_func_int16_t_s_s((*l_2282), ((***g_652) = (safe_div_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u(0xED34L, 7)), (**g_1161))))));
        }
        else
        { /* block id: 1055 */
            uint32_t l_2300 = 0x458FD588L;
            uint16_t *l_2311 = (void*)0;
            uint16_t *l_2312 = &g_134;
            int8_t l_2313[5][9][5] = {{{0xCAL,0x2EL,(-6L),1L,1L},{0x1FL,0xFFL,1L,5L,0xFFL},{0x85L,0x90L,0xDDL,0x45L,0xB2L},{0x06L,0xCAL,1L,0xDBL,(-1L)},{(-1L),1L,1L,0xA1L,0x70L},{0x3FL,0x0FL,0x9FL,(-1L),0xA1L},{(-1L),(-4L),0xB5L,0x07L,1L},{0x1FL,8L,2L,0x63L,1L},{0L,0xFAL,(-1L),0L,0xA1L}},{{2L,0L,0x83L,1L,0x70L},{0xEFL,0x3FL,0x4AL,2L,(-1L)},{0xCAL,0xDBL,(-1L),0x69L,0xB2L},{(-2L),0x45L,0L,(-7L),0xFFL},{0x23L,1L,0xEFL,0x63L,1L},{0x3FL,1L,3L,6L,3L},{0xEDL,0xEDL,0x28L,0xDBL,0xDEL},{1L,0xDEL,0xDAL,6L,0x63L},{0x63L,1L,1L,2L,3L}},{{0x4AL,0xDEL,(-4L),5L,0x0FL},{5L,0xEDL,0L,4L,0L},{(-1L),(-1L),(-7L),0x0FL,0xFBL},{0x9FL,0x2FL,0xFFL,(-4L),0x1FL},{5L,1L,0x9AL,3L,0xABL},{0x23L,0L,4L,(-1L),4L},{0L,(-4L),5L,1L,0x06L},{1L,0xB2L,3L,0L,0x9FL},{0x06L,0L,5L,0x63L,0xFBL}},{{0x2FL,0xDEL,(-1L),0x63L,0xDBL},{1L,(-1L),0x3AL,0L,0x3AL},{0x4AL,1L,(-7L),1L,3L},{0xB2L,0xABL,0xDBL,(-1L),0L},{(-1L),0xFAL,1L,3L,0xDDL},{0x1FL,(-7L),6L,(-4L),3L},{(-1L),1L,(-1L),0x0FL,0x06L},{0x9AL,5L,4L,4L,5L},{0x63L,(-7L),(-1L),5L,(-2L)}},{{0x2FL,0xB2L,5L,2L,(-1L)},{(-8L),0xEDL,(-1L),6L,0xEFL},{0x2FL,1L,0xB5L,0xDBL,6L},{0x63L,0x75L,0xFFL,6L,0x3AL},{0x9AL,0xDDL,1L,4L,0x0FL},{(-1L),0L,(-2L),(-1L),6L},{0x1FL,(-1L),(-4L),0x0FL,0xDEL},{(-1L),0xEEL,6L,(-5L),0x9FL},{0xB2L,0L,0x9AL,0x93L,(-2L)}}};
            const uint32_t l_2318 = 0UL;
            int i, j, k;
            (*g_83) = (safe_unary_minus_func_int16_t_s(((safe_sub_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_s(((l_2300 & (((g_2301 == &g_2302) == p_4) > (safe_add_func_uint64_t_u_u((~p_3), 0x44D0107DBF3D6430LL)))) || (safe_div_func_int16_t_s_s((p_4 >= (l_2308[0] = l_2300)), ((*l_2312) = (safe_mod_func_int32_t_s_s(((((0xD1F539C6CFD2AAB7LL > 0x25399B90E4931B0BLL) | 1L) , p_3) <= 0x3EAAL), g_36[1])))))), l_2313[3][3][0])) | p_3), p_4)) || 1UL)));
            if (((!(l_2308[0] != p_4)) , 0x5BC7D399L))
            { /* block id: 1059 */
                return (*g_1056);
            }
            else
            { /* block id: 1061 */
                int32_t l_2323[2];
                int32_t l_2334[2][7] = {{7L,7L,0x965632E7L,7L,7L,0x965632E7L,7L},{(-10L),0xD347270AL,0xD347270AL,(-10L),0xD347270AL,0xD347270AL,(-10L)}};
                int i, j;
                for (i = 0; i < 2; i++)
                    l_2323[i] = 0x8510D5B5L;
                (*g_83) = ((safe_lshift_func_uint8_t_u_u((0x838A191DL < l_2318), 3)) <= ((safe_sub_func_int8_t_s_s(p_4, (safe_mul_func_int8_t_s_s((l_2323[1] && (safe_rshift_func_int8_t_s_u((-8L), 6))), (*l_2315))))) | (safe_lshift_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_u(0x95L, ((*l_2315) || ((safe_sub_func_uint16_t_u_u(1UL, 0x0F43L)) <= (*l_2315))))) | 5L), l_2334[1][4])), 7))));
            }
        }
        l_2282 = l_2315;
    }
    else
    { /* block id: 1066 */
        int32_t *l_2335 = &l_2284;
        int32_t *l_2336 = &g_494;
        int32_t *l_2337[4];
        int i;
        for (i = 0; i < 4; i++)
            l_2337[i] = (void*)0;
        l_2341++;
    }
    (*g_83) = ((safe_mod_func_uint64_t_u_u(((~(*l_2282)) , (0xE7747F3B22E1C9E0LL <= (safe_mul_func_int8_t_s_s(((*l_2287) ^= p_4), ((safe_sub_func_int64_t_s_s((-3L), (**g_1161))) ^ ((safe_lshift_func_int8_t_s_s((1UL > p_4), (safe_rshift_func_int8_t_s_s((*l_2282), 7)))) || ((((*g_238) != &l_2263) > 0x825EA8C4L) , (-6L)))))))), 0xF9AAEA8AA2FDAF06LL)) >= p_3);
    l_2340 &= (safe_lshift_func_int8_t_s_u(((*l_2365) = ((*l_2282) , ((*l_2287) = (((*l_2358) = l_2357[0]) == ((safe_lshift_func_uint8_t_u_s(((**l_2283) = (((safe_mod_func_int8_t_s_s(((p_4 != ((((*g_1162) = (((((g_463[0][7] ^ (l_2363 > 0xF7E3C99A5FCF52D2LL)) && p_4) , (void*)0) == ((*l_2364) = &g_1162)) != (*l_2282))) >= 18446744073709551615UL) || g_1850)) | p_3), 4L)) , 0x573D2036L) , (*g_514))), 6)) , (*l_2364)))))), 4));
    return (*g_1056);
}


/* ------------------------------------------ */
/* 
 * reads : g_1162 g_93
 * writes:
 */
static uint64_t  func_8(int32_t  p_9, int32_t  p_10, int32_t * const  p_11, int8_t  p_12, int32_t  p_13)
{ /* block id: 1032 */
    return (*g_1162);
}


/* ------------------------------------------ */
/* 
 * reads : g_514 g_515 g_651 g_652 g_238 g_239 g_977 g_1263 g_166 g_134 g_493 g_83 g_1445 g_1265 g_36 g_93 g_369 g_593 g_1162 g_1510 g_1161 g_463 g_703 g_407 g_40 g_72 g_112 g_1564 g_835 g_136 g_60 g_1751 g_1710 g_1563 g_896 g_84 g_1782 g_240 g_951 g_578 g_387 g_1056
 * writes: g_240 g_60 g_134 g_72 g_84 g_493 g_951 g_369 g_1510 g_93 g_36 g_515 g_166 g_1563 g_836 g_136 g_1751 g_238 g_1627 g_40 g_387
 */
static int32_t  func_14(uint32_t  p_15, int64_t  p_16, int64_t  p_17)
{ /* block id: 593 */
    uint32_t *l_1428[4][9][7] = {{{&g_369,&g_369,&g_369,&g_121,(void*)0,&g_121,&g_121},{(void*)0,(void*)0,&g_121,&g_369,&g_121,&g_369,(void*)0},{(void*)0,(void*)0,&g_121,(void*)0,&g_369,&g_121,&g_121},{(void*)0,&g_121,&g_121,&g_121,(void*)0,&g_121,(void*)0},{(void*)0,&g_121,&g_121,&g_121,(void*)0,&g_121,&g_121},{&g_369,(void*)0,&g_121,&g_369,&g_121,(void*)0,(void*)0},{(void*)0,&g_121,(void*)0,&g_121,(void*)0,(void*)0,&g_121},{&g_121,&g_121,(void*)0,(void*)0,&g_121,&g_121,&g_369},{&g_121,&g_121,&g_121,(void*)0,&g_121,&g_369,&g_369}},{{&g_121,(void*)0,&g_121,&g_121,&g_369,&g_121,&g_121},{(void*)0,&g_369,&g_121,&g_369,&g_121,&g_121,&g_121},{&g_369,&g_369,(void*)0,&g_369,&g_121,(void*)0,&g_121},{(void*)0,&g_369,(void*)0,&g_369,&g_121,&g_121,&g_369},{&g_121,&g_369,&g_121,&g_369,&g_121,&g_121,&g_121},{&g_121,&g_121,&g_121,&g_121,(void*)0,&g_121,&g_369},{(void*)0,&g_121,&g_121,(void*)0,(void*)0,&g_369,&g_121},{&g_369,&g_121,(void*)0,(void*)0,&g_369,(void*)0,&g_369},{(void*)0,&g_369,&g_121,&g_121,&g_121,&g_121,&g_121}},{{&g_121,&g_121,(void*)0,&g_369,&g_369,(void*)0,&g_369},{&g_121,&g_121,&g_121,&g_121,&g_121,&g_121,&g_121},{&g_369,(void*)0,&g_121,&g_121,(void*)0,&g_369,&g_121},{(void*)0,&g_121,(void*)0,&g_121,&g_121,&g_121,&g_121},{&g_121,&g_121,&g_121,&g_369,&g_121,(void*)0,&g_369},{&g_121,&g_369,(void*)0,&g_121,&g_121,&g_121,&g_369},{&g_121,(void*)0,&g_121,(void*)0,&g_121,(void*)0,&g_121},{&g_369,&g_369,&g_121,&g_121,(void*)0,&g_121,(void*)0},{(void*)0,&g_121,&g_121,(void*)0,&g_369,&g_369,&g_121}},{{&g_121,&g_369,(void*)0,(void*)0,&g_121,&g_121,(void*)0},{&g_121,&g_369,(void*)0,(void*)0,&g_121,(void*)0,&g_121},{&g_121,&g_121,&g_121,&g_121,&g_369,&g_121,&g_121},{&g_369,&g_369,&g_121,(void*)0,&g_121,&g_121,(void*)0},{(void*)0,&g_121,&g_121,&g_121,&g_121,(void*)0,&g_121},{&g_121,&g_369,(void*)0,&g_121,(void*)0,(void*)0,&g_121},{&g_121,&g_121,&g_369,&g_369,&g_121,&g_121,&g_369},{(void*)0,&g_121,&g_121,(void*)0,&g_369,&g_121,(void*)0},{&g_121,&g_121,&g_121,&g_121,&g_121,&g_121,&g_369}}};
    int32_t l_1429[3][9] = {{0xC84B0846L,0x3E43FF5AL,1L,0x3E43FF5AL,0xC84B0846L,0xC84B0846L,0x3E43FF5AL,1L,0x3E43FF5AL},{0xF982D3FAL,0x5E66456EL,(-6L),(-6L),0x5E66456EL,0xF982D3FAL,0x5E66456EL,(-6L),(-6L)},{0xC84B0846L,0xC84B0846L,0x3E43FF5AL,1L,0x3E43FF5AL,0xC84B0846L,0xC84B0846L,0x3E43FF5AL,1L}};
    uint64_t **l_1430 = (void*)0;
    int32_t l_1436[9] = {0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL,0x9EC476FDL};
    int8_t *l_1437 = (void*)0;
    int8_t *l_1438 = &g_60;
    uint8_t l_1483 = 255UL;
    uint8_t **l_1542 = &g_703;
    uint8_t ***l_1541[9] = {&l_1542,&l_1542,&l_1542,&l_1542,&l_1542,&l_1542,&l_1542,&l_1542,&l_1542};
    int8_t l_1622 = 0x6EL;
    int16_t l_1624 = 0xF56CL;
    uint32_t l_1628 = 5UL;
    int32_t l_1743 = 0x5922470CL;
    int16_t **l_1755 = (void*)0;
    int8_t l_1762[7] = {0x30L,0x12L,0x30L,0x30L,0x12L,0x30L,0x30L};
    int16_t l_1781 = 0x0596L;
    uint16_t l_1814 = 1UL;
    uint8_t ****l_1829 = &l_1541[0];
    int32_t * const l_1877 = (void*)0;
    int32_t l_1883 = 0x0BE3715BL;
    int32_t **l_1952 = &g_83;
    int64_t *l_1987[3];
    int16_t *** const **l_2014 = (void*)0;
    uint32_t l_2163 = 7UL;
    int64_t l_2197 = 0xDA879BEF017ECE44LL;
    int8_t l_2198 = 0x79L;
    int8_t l_2219 = 0L;
    const int32_t *l_2241[6][10][4] = {{{&g_2242,&g_2242,(void*)0,&g_2242},{(void*)0,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{(void*)0,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,(void*)0,(void*)0}},{{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,(void*)0,&g_2242,&g_2242},{&g_2242,(void*)0,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,(void*)0,&g_2242,&g_2242},{(void*)0,&g_2242,&g_2242,&g_2242},{&g_2242,(void*)0,&g_2242,&g_2242},{(void*)0,&g_2242,(void*)0,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242}},{{&g_2242,(void*)0,&g_2242,&g_2242},{&g_2242,(void*)0,&g_2242,&g_2242},{(void*)0,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{(void*)0,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242}},{{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242}},{{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,(void*)0,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,(void*)0,(void*)0},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242}},{{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,&g_2242,&g_2242},{&g_2242,&g_2242,(void*)0,&g_2242},{&g_2242,&g_2242,&g_2242,(void*)0}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1987[i] = &g_493;
    if ((safe_div_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_s((safe_lshift_func_uint16_t_u_s(65526UL, (!(safe_sub_func_uint32_t_u_u((((l_1429[2][8] = 0xC67A4F30L) | (((void*)0 == l_1430) ^ (((*g_514) && 0xEFL) , (safe_mod_func_int8_t_s_s(((*l_1438) = ((~(safe_lshift_func_int16_t_s_u(((****g_651) = l_1436[6]), 12))) || p_16)), (((p_16 != g_977) ^ g_1263) && l_1436[4])))))) != g_166), 0UL))))), p_16)) > p_16), g_515[1][4][0])))
    { /* block id: 597 */
        int32_t l_1447[8] = {0x623FDB3EL,0xD25AFDA2L,0x623FDB3EL,0xD25AFDA2L,0x623FDB3EL,0xD25AFDA2L,0x623FDB3EL,0xD25AFDA2L};
        int32_t l_1465 = 0x628CE9C6L;
        uint64_t l_1544 = 0xB2EC2476F8888497LL;
        int16_t **l_1547 = &g_239;
        uint16_t *l_1588 = &g_134;
        int32_t l_1619 = 0x3ED7132DL;
        int32_t l_1620[4][10][6] = {{{1L,6L,7L,6L,1L,0x95A09C24L},{(-3L),0x23760360L,0L,0x5DF76BCAL,(-6L),0x066D7B74L},{0x5210E7F6L,0xBB2DA987L,0xA73A0777L,0x23760360L,8L,0x066D7B74L},{0x95A09C24L,0x62AD36B2L,0L,0xF2C52E57L,(-1L),0x95A09C24L},{8L,0L,7L,0xB6C5C7A0L,0L,(-1L)},{0x5438BDBCL,0x5FA6144AL,(-4L),(-1L),2L,0xD731DDD5L},{4L,1L,(-1L),1L,1L,0x5DF76BCAL},{6L,0L,(-4L),0x327622A7L,0xC0837FA1L,(-1L)},{0xBE2BF50AL,8L,0x5210E7F6L,0L,0L,0x5FA6144AL},{0x327622A7L,0xBBA052E5L,(-1L),1L,(-2L),0L}},{{(-10L),0x066D7B74L,0xBF4FE1F8L,0x465A2ECAL,0x5FA6144AL,0x0A488C78L},{0x0912FCD1L,0xC0837FA1L,4L,0xB6C5C7A0L,0xD731DDD5L,1L},{0x6485ADE7L,0x66B20664L,0x4A3F252FL,(-2L),0x066D7B74L,0x1D46693EL},{8L,0x0A488C78L,6L,8L,1L,(-1L)},{(-1L),2L,(-1L),1L,0xD9889EEBL,0xA73A0777L},{0x23760360L,0L,0L,6L,(-1L),(-1L)},{(-1L),(-3L),(-3L),(-1L),0x66B20664L,0x684F5EF7L},{1L,0x9C3C32F3L,1L,(-2L),0x5210E7F6L,0x4A3F252FL},{1L,(-1L),0x066D7B74L,2L,0x5210E7F6L,0xC716EC58L},{1L,0x9C3C32F3L,8L,0xFB4F287AL,0x66B20664L,1L}},{{(-10L),(-3L),(-6L),0xC0837FA1L,(-1L),1L},{7L,0L,1L,(-4L),0xD9889EEBL,0x6485ADE7L},{0xB6C5C7A0L,2L,7L,0x327622A7L,1L,0xB6C5C7A0L},{1L,0x0A488C78L,(-1L),0L,0x066D7B74L,0xC716EC58L},{(-2L),0x66B20664L,(-1L),0x555AE24FL,0xD731DDD5L,4L},{0x0A488C78L,0xC0837FA1L,0x555AE24FL,0x5210E7F6L,0x5FA6144AL,(-1L)},{0x0F505BFCL,0x066D7B74L,(-3L),7L,(-2L),(-1L)},{0xB6C5C7A0L,0xBBA052E5L,0xF2C52E57L,(-3L),0L,1L},{0xBA4D92B3L,8L,0L,1L,0xC0837FA1L,(-1L)},{0x066D7B74L,0xFAD97441L,0xBF4FE1F8L,0xFB4F287AL,1L,(-2L)}},{{6L,0xC0837FA1L,0L,1L,(-1L),8L},{0x6485ADE7L,1L,4L,0x1D46693EL,0xFAD97441L,0x1D46693EL},{1L,0x2DCB9533L,1L,(-1L),1L,0xD93FC922L},{(-1L),0xC716EC58L,0L,1L,0x5DF76BCAL,0x5FA6144AL},{0x465A2ECAL,0x95A09C24L,0L,1L,0x424E86FEL,(-1L)},{(-1L),(-3L),0L,(-1L),6L,(-1L)},{1L,0x465A2ECAL,0xA73A0777L,0x1D46693EL,0L,0x4A3F252FL},{0x6485ADE7L,0xD731DDD5L,0x531A903CL,1L,0x5210E7F6L,8L},{6L,0x23760360L,(-1L),0xFB4F287AL,1L,0xBE2BF50AL},{0x066D7B74L,(-10L),0x424E86FEL,1L,8L,0xE185E82FL}}};
        int64_t l_1625 = (-1L);
        int64_t l_1673 = 0x10D00DC9CD24A593LL;
        uint16_t * const *l_1688[6];
        int16_t ****l_1832 = &g_652;
        int32_t *l_1938[5][10] = {{(void*)0,&g_72,(void*)0,&g_494,(void*)0,&g_494,(void*)0,&g_72,(void*)0,&g_494},{(void*)0,&g_72,&l_1620[1][7][5],&g_72,(void*)0,(void*)0,(void*)0,&g_72,&l_1620[1][7][5],&g_72},{(void*)0,&g_494,(void*)0,&g_72,(void*)0,&g_494,(void*)0,&g_494,(void*)0,&g_72},{(void*)0,&g_72,(void*)0,&g_494,(void*)0,&g_494,(void*)0,&g_72,(void*)0,&g_494},{(void*)0,&g_72,&l_1620[1][7][5],&g_72,(void*)0,(void*)0,(void*)0,&g_72,&l_1620[1][7][5],&g_72}};
        uint8_t **l_1972 = &g_703;
        int32_t l_1986[3];
        uint32_t l_2006[5][6][4] = {{{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL},{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL}},{{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL},{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL}},{{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL},{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL}},{{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL},{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL}},{{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL},{4294967295UL,0xBF17DD14L,0xBF17DD14L,4294967295UL},{0xBF17DD14L,4294967295UL,0xBF17DD14L,0xBF17DD14L},{4294967295UL,4294967295UL,0xAB82B479L,4294967295UL}}};
        int32_t l_2057 = 0L;
        int8_t l_2065[10];
        int32_t l_2066[8][4][3] = {{{(-10L),(-10L),0x5063E64AL},{0x701300C5L,1L,0xEB827762L},{0x701300C5L,4L,0xAF6460E1L},{(-10L),0x876B70CDL,1L}},{{0xAF6460E1L,0x701300C5L,0xAF6460E1L},{(-1L),4L,0xD8CB3154L},{0xAF6460E1L,4L,0x701300C5L},{0xFD7C0021L,(-1L),0x0F229B68L}},{{(-10L),0xFD7C0021L,0xFD7C0021L},{0xFD7C0021L,0xEB827762L,0x5063E64AL},{0xAF6460E1L,0x876B70CDL,0x5063E64AL},{0x736A7176L,0x5063E64AL,0xFD7C0021L}},{{1L,0x701300C5L,0x0F229B68L},{0x5063E64AL,0x5063E64AL,0x701300C5L},{(-1L),0x876B70CDL,0xD8CB3154L},{(-1L),0xEB827762L,1L}},{{0x5063E64AL,0xFD7C0021L,0x876B70CDL},{1L,(-1L),1L},{0x736A7176L,4L,0xD8CB3154L},{0xAF6460E1L,4L,0x701300C5L}},{{0xFD7C0021L,(-1L),0x0F229B68L},{(-10L),0xFD7C0021L,0xFD7C0021L},{0xFD7C0021L,0xEB827762L,0x5063E64AL},{0xAF6460E1L,0x876B70CDL,0x5063E64AL}},{{0x736A7176L,0x5063E64AL,0xFD7C0021L},{1L,0x701300C5L,0x0F229B68L},{0x5063E64AL,0x5063E64AL,0x701300C5L},{(-1L),0x876B70CDL,0xD8CB3154L}},{{(-1L),0xEB827762L,1L},{0x5063E64AL,0xFD7C0021L,0x876B70CDL},{1L,(-1L),1L},{0x736A7176L,4L,0xD8CB3154L}}};
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_1688[i] = &l_1588;
        for (i = 0; i < 3; i++)
            l_1986[i] = 0xAEB89055L;
        for (i = 0; i < 10; i++)
            l_2065[i] = 0x9FL;
        for (g_134 = 0; (g_134 > 34); g_134++)
        { /* block id: 600 */
            int32_t *l_1444[3];
            uint16_t *l_1489 = &g_136;
            uint16_t **l_1488 = &l_1489;
            int16_t **l_1512 = &g_239;
            int8_t l_1522 = 0xD2L;
            uint32_t l_1543 = 0x9B3C3155L;
            int32_t l_1615[2][9] = {{0x9FDCDD88L,6L,6L,0x9FDCDD88L,6L,6L,0x9FDCDD88L,6L,6L},{1L,1L,1L,1L,1L,1L,1L,1L,1L}};
            int i, j;
            for (i = 0; i < 3; i++)
                l_1444[i] = &l_1436[6];
            for (g_240 = 0; (g_240 != (-13)); --g_240)
            { /* block id: 603 */
                int64_t l_1446 = (-1L);
                uint64_t *l_1502 = &g_93;
                uint32_t l_1536 = 0xA0DC4804L;
                int16_t l_1552 = (-8L);
                uint8_t *** const l_1560 = &l_1542;
                int32_t l_1575[5];
                int32_t l_1578 = 0xEE747E18L;
                int i;
                for (i = 0; i < 5; i++)
                    l_1575[i] = (-4L);
                for (g_72 = 2; (g_72 >= 0); g_72 -= 1)
                { /* block id: 606 */
                    int32_t **l_1443 = &g_84;
                    int i, j, k;
                    (*l_1443) = &l_1429[2][8];
                }
                for (g_493 = 1; (g_493 >= 0); g_493 -= 1)
                { /* block id: 611 */
                    int i, j, k;
                    (*g_83) = (g_515[g_493][(g_493 + 2)][(g_493 + 6)] < 0xA893L);
                    for (p_16 = 0; (p_16 <= 9); p_16 += 1)
                    { /* block id: 615 */
                        uint32_t l_1448[3][7][5] = {{{0x88B71BC3L,2UL,5UL,9UL,5UL},{18446744073709551615UL,18446744073709551615UL,0x9C6EC053L,0xCF34DC8CL,18446744073709551615UL},{18446744073709551614UL,9UL,18446744073709551614UL,2UL,0x7871AC53L},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0xB73DD1EBL},{0x88B71BC3L,9UL,0x6B88E900L,9UL,0x88B71BC3L},{0xB73DD1EBL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x7871AC53L,2UL,18446744073709551614UL,9UL,18446744073709551614UL}},{{18446744073709551615UL,0xCF34DC8CL,0x9C6EC053L,18446744073709551615UL,18446744073709551615UL},{5UL,9UL,5UL,2UL,0x88B71BC3L},{18446744073709551615UL,0xB73DD1EBL,18446744073709551615UL,0xCF34DC8CL,0xB73DD1EBL},{0x7871AC53L,9UL,0xDBAD4B5DL,9UL,0x7871AC53L},{0xB73DD1EBL,0xCF34DC8CL,18446744073709551615UL,0xB73DD1EBL,18446744073709551615UL},{0x88B71BC3L,2UL,5UL,9UL,5UL},{18446744073709551615UL,18446744073709551615UL,0x9C6EC053L,0xCF34DC8CL,18446744073709551615UL}},{{18446744073709551614UL,9UL,18446744073709551614UL,2UL,0x7871AC53L},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0xB73DD1EBL},{0x88B71BC3L,9UL,0x6B88E900L,9UL,0x88B71BC3L},{0xB73DD1EBL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x7871AC53L,2UL,0xDBAD4B5DL,2UL,0xDBAD4B5DL},{0xB73DD1EBL,18446744073709551615UL,0xCF34DC8CL,0xB73DD1EBL,0xB73DD1EBL},{0x6B88E900L,2UL,0x6B88E900L,18446744073709551615UL,5UL}}};
                        int i, j, k;
                        (*g_1445) = l_1444[2];
                        l_1448[2][2][2]--;
                    }
                    if (g_515[g_493][(g_493 + 4)][(g_493 + 8)])
                        continue;
                }
                for (p_15 = 0; (p_15 <= 3); p_15++)
                { /* block id: 623 */
                    int64_t *l_1464[5][8][3] = {{{&g_166,&g_166,&g_951},{&g_166,(void*)0,&g_166},{&g_166,&l_1446,&l_1446},{&g_166,(void*)0,(void*)0},{&g_166,&g_166,&l_1446},{&g_166,&g_951,&g_166},{&g_166,&l_1446,&g_951},{&g_166,&g_951,(void*)0}},{{&g_166,&g_166,&g_951},{&g_166,(void*)0,&g_166},{&g_166,&l_1446,&l_1446},{&g_166,(void*)0,(void*)0},{&g_166,&g_166,&l_1446},{&g_166,&g_951,&g_166},{&g_166,&l_1446,&g_951},{&g_166,&g_951,(void*)0}},{{&g_166,&g_166,&g_951},{&g_166,(void*)0,&g_166},{&g_166,&l_1446,&l_1446},{&g_166,(void*)0,(void*)0},{&g_166,&g_166,&l_1446},{&g_166,&g_951,&g_166},{&g_166,&l_1446,&g_951},{&g_166,&g_951,(void*)0}},{{&g_166,&g_166,&g_951},{&g_166,(void*)0,&g_166},{&g_166,&l_1446,&l_1446},{&g_166,(void*)0,(void*)0},{&g_166,&g_166,&l_1446},{&g_166,&g_951,&g_166},{&g_166,&l_1446,&g_951},{&g_166,&g_951,(void*)0}},{{&g_166,&g_166,&g_951},{&g_166,(void*)0,&g_166},{&g_166,&l_1446,&l_1446},{&g_166,(void*)0,(void*)0},{&g_166,&g_166,&l_1446},{&g_166,&g_951,&g_166},{&g_166,&l_1446,&g_951},{&g_166,&g_951,(void*)0}}};
                    int32_t l_1472 = 0xA2D4BDCDL;
                    int32_t l_1524 = 0x4BBD75DBL;
                    int i, j, k;
                    if (((*g_83) = (safe_rshift_func_uint8_t_u_s(((safe_mod_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u(((l_1465 &= (safe_lshift_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((~(l_1447[0] || (g_951 = g_1265))), 5)), (p_17 , 0x8AL)))) == (safe_mod_func_int32_t_s_s(((((g_36[1] , (safe_mul_func_int8_t_s_s(g_93, (safe_add_func_uint32_t_u_u((++g_369), (safe_rshift_func_uint8_t_u_s(p_17, 1))))))) , (p_16 = (safe_lshift_func_uint8_t_u_u((safe_div_func_int8_t_s_s((((safe_sub_func_int32_t_s_s(((l_1483 && ((((((safe_lshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s((l_1488 == (void*)0), p_17)), l_1429[2][7])) || l_1447[5]) , 0x7A2A2FEFL) & (-4L)) > 0UL) ^ g_593)) <= 0xDDC31791A3BCC71BLL), l_1446)) > 0x7641L) , p_15), g_1263)), 1)))) ^ p_17) , 1L), p_15))), 0xDF30DBFFL)), 0x8652F6F4L)) | 1UL), 3))))
                    { /* block id: 629 */
                        uint64_t l_1492[8][6][5] = {{{0x26D539AB89CA0136LL,0xFB46FEA04A513D7DLL,8UL,0x4FA809F3127A0C71LL,1UL},{0x774C0DBD1C6A53CALL,8UL,18446744073709551615UL,0x73330836EC79F140LL,0xDF694079539CF3D3LL},{0x26D539AB89CA0136LL,0x7B4694507A58B8F8LL,0x774C0DBD1C6A53CALL,18446744073709551615UL,8UL},{0xED065A6FA87FE93ALL,1UL,0xA5C8559E42C81119LL,0x1C096516231760A5LL,0x0FA36714CC084A0BLL},{0x7041F5A9176DEFD6LL,18446744073709551611UL,0x6053130C8A942EB2LL,0x1C096516231760A5LL,0x6053130C8A942EB2LL},{0x9501B64E4A0F7C49LL,0x9501B64E4A0F7C49LL,0UL,18446744073709551615UL,0x1C096516231760A5LL}},{{1UL,18446744073709551609UL,18446744073709551611UL,0x73330836EC79F140LL,0xED065A6FA87FE93ALL},{0UL,0x1C096516231760A5LL,0x1644ED5AE3A331A1LL,0x4FA809F3127A0C71LL,18446744073709551613UL},{0x73330836EC79F140LL,18446744073709551609UL,1UL,0x26D539AB89CA0136LL,1UL},{0xDF694079539CF3D3LL,0x9501B64E4A0F7C49LL,0x6B4B327A2A7E40C0LL,18446744073709551615UL,18446744073709551615UL},{0x6B4B327A2A7E40C0LL,18446744073709551611UL,0x1C096516231760A5LL,18446744073709551615UL,18446744073709551615UL},{1UL,1UL,1UL,8UL,0UL}},{{0x1644ED5AE3A331A1LL,8UL,18446744073709551613UL,0xDF694079539CF3D3LL,0x7041F5A9176DEFD6LL},{0x774C0DBD1C6A53CALL,1UL,18446744073709551615UL,1UL,18446744073709551613UL},{1UL,0xA5C8559E42C81119LL,18446744073709551613UL,0x7041F5A9176DEFD6LL,18446744073709551615UL},{18446744073709551611UL,1UL,0x73330836EC79F140LL,0x774C0DBD1C6A53CALL,0xDF694079539CF3D3LL},{0x6B4B327A2A7E40C0LL,18446744073709551615UL,18446744073709551615UL,0x4FA809F3127A0C71LL,18446744073709551615UL},{0x6B4B327A2A7E40C0LL,0xFB46FEA04A513D7DLL,0xFB46FEA04A513D7DLL,0x6B4B327A2A7E40C0LL,1UL}},{{18446744073709551611UL,1UL,0x1644ED5AE3A331A1LL,0x9501B64E4A0F7C49LL,18446744073709551609UL},{1UL,0x1C096516231760A5LL,0x6B4B327A2A7E40C0LL,18446744073709551613UL,0x774C0DBD1C6A53CALL},{0x774C0DBD1C6A53CALL,0x7B4694507A58B8F8LL,0x26D539AB89CA0136LL,0x9501B64E4A0F7C49LL,1UL},{0x1644ED5AE3A331A1LL,0xDF694079539CF3D3LL,0x9501B64E4A0F7C49LL,0x6B4B327A2A7E40C0LL,18446744073709551615UL},{0x73330836EC79F140LL,0x774C0DBD1C6A53CALL,0xDF694079539CF3D3LL,0x4FA809F3127A0C71LL,0xED065A6FA87FE93ALL},{0xFB46FEA04A513D7DLL,0x774C0DBD1C6A53CALL,18446744073709551611UL,0x774C0DBD1C6A53CALL,0xFB46FEA04A513D7DLL}},{{18446744073709551609UL,0xDF694079539CF3D3LL,18446744073709551615UL,0x7041F5A9176DEFD6LL,0xB7427E20EA21D4AFLL},{18446744073709551613UL,0x7B4694507A58B8F8LL,0x0FA36714CC084A0BLL,1UL,0xB1D94293C64C23C5LL},{0x9501B64E4A0F7C49LL,0x1C096516231760A5LL,1UL,0xDF694079539CF3D3LL,0xB7427E20EA21D4AFLL},{0UL,1UL,0x4FA809F3127A0C71LL,8UL,0xFB46FEA04A513D7DLL},{0xB7427E20EA21D4AFLL,0xFB46FEA04A513D7DLL,0x6053130C8A942EB2LL,0x0FA36714CC084A0BLL,0xED065A6FA87FE93ALL},{1UL,18446744073709551615UL,0x6053130C8A942EB2LL,0x6053130C8A942EB2LL,18446744073709551615UL}},{{18446744073709551613UL,1UL,0x4FA809F3127A0C71LL,0x1C096516231760A5LL,1UL},{0x1C096516231760A5LL,0xA5C8559E42C81119LL,1UL,0xED065A6FA87FE93ALL,0x774C0DBD1C6A53CALL},{18446744073709551615UL,1UL,0x0FA36714CC084A0BLL,18446744073709551613UL,18446744073709551609UL},{0x1C096516231760A5LL,8UL,18446744073709551615UL,1UL,1UL},{18446744073709551613UL,0x1644ED5AE3A331A1LL,18446744073709551611UL,18446744073709551615UL,18446744073709551615UL},{1UL,0x26D539AB89CA0136LL,0xDF694079539CF3D3LL,18446744073709551615UL,0xDF694079539CF3D3LL}},{{0xB7427E20EA21D4AFLL,0xB7427E20EA21D4AFLL,0x9501B64E4A0F7C49LL,1UL,18446744073709551615UL},{0UL,0x4FA809F3127A0C71LL,0x26D539AB89CA0136LL,18446744073709551613UL,18446744073709551613UL},{0x9501B64E4A0F7C49LL,18446744073709551615UL,0x6B4B327A2A7E40C0LL,0xED065A6FA87FE93ALL,0x7041F5A9176DEFD6LL},{18446744073709551613UL,0x4FA809F3127A0C71LL,0x1644ED5AE3A331A1LL,0x1C096516231760A5LL,0UL},{18446744073709551609UL,0xB7427E20EA21D4AFLL,0xFB46FEA04A513D7DLL,0x6053130C8A942EB2LL,0x0FA36714CC084A0BLL},{0xFB46FEA04A513D7DLL,0x26D539AB89CA0136LL,18446744073709551615UL,0x0FA36714CC084A0BLL,0x0FA36714CC084A0BLL}},{{0x73330836EC79F140LL,0x1644ED5AE3A331A1LL,0x73330836EC79F140LL,8UL,0UL},{0x1644ED5AE3A331A1LL,8UL,18446744073709551613UL,0xDF694079539CF3D3LL,0x7041F5A9176DEFD6LL},{0x774C0DBD1C6A53CALL,1UL,18446744073709551615UL,1UL,18446744073709551613UL},{1UL,0xA5C8559E42C81119LL,18446744073709551613UL,0x7041F5A9176DEFD6LL,18446744073709551615UL},{18446744073709551611UL,1UL,0x73330836EC79F140LL,0x774C0DBD1C6A53CALL,0xDF694079539CF3D3LL},{0x6B4B327A2A7E40C0LL,18446744073709551615UL,18446744073709551615UL,0x4FA809F3127A0C71LL,18446744073709551615UL}}};
                        uint32_t *l_1509 = &g_1510;
                        int i, j, k;
                        (*g_83) = ((safe_sub_func_int32_t_s_s(l_1492[2][1][4], (safe_add_func_int64_t_s_s((((p_17 ^ (((safe_lshift_func_int8_t_s_s(p_15, ((*g_1162) == 3L))) , ((*l_1509) ^= ((safe_rshift_func_uint16_t_u_s((safe_mod_func_uint32_t_u_u(((~(((((((l_1502 == l_1502) ^ ((p_16 = p_17) <= ((((((safe_add_func_int8_t_s_s(((g_951 = ((safe_mod_func_int16_t_s_s((p_17 , l_1447[4]), l_1472)) || p_15)) ^ 0x21DC9119C4B8FA8ALL), 254UL)) > p_15) || l_1492[2][1][4]) >= 0x64808296L) & p_15) <= p_15))) <= 0x9D4EC882L) > l_1436[3]) && l_1447[5]) ^ p_17) , (-3L))) && p_16), p_17)), 13)) , 0x6FA29DCCL))) , (**g_1161))) || 0xDBL) <= p_17), p_15)))) <= 0x4AL);
                    }
                    else
                    { /* block id: 634 */
                        int16_t **l_1511[2][7][7] = {{{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,&g_239},{&g_239,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239},{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239},{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239}},{{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239},{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239},{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0},{&g_239,(void*)0,&g_239,&g_239,(void*)0,&g_239,&g_239},{(void*)0,&g_239,(void*)0,(void*)0,&g_239,(void*)0,(void*)0}}};
                        int32_t l_1515 = 0L;
                        int8_t *l_1523 = &g_36[3];
                        int i, j, k;
                        l_1524 = ((g_493 = ((l_1511[0][1][0] = (void*)0) == ((l_1502 != (*g_1161)) , l_1512))) , (((safe_mod_func_uint32_t_u_u((l_1515 , (l_1436[6] = (l_1515 = ((((g_493 = (((safe_lshift_func_uint8_t_u_s(((((*l_1523) = ((*l_1438) = (safe_add_func_int64_t_s_s(l_1436[6], (l_1472 = (safe_mul_func_int8_t_s_s((((((**g_1161) = (((*g_83) = l_1522) || p_17)) == (g_463[0][7] && p_17)) && (*g_703)) < p_17), 1L))))))) == 1UL) | 0x37L), g_407)) < p_15) , (-2L))) < 0UL) , 1L) || g_40)))), 0x4F028580L)) , l_1429[2][8]) , l_1515));
                        (*g_83) = (safe_lshift_func_int16_t_s_u(((safe_mod_func_uint8_t_u_u(8UL, (safe_lshift_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((safe_add_func_uint16_t_u_u(l_1446, ((+((l_1543 = (((**g_1161) &= (((p_15 >= (l_1536 < g_407)) == 0x9BEC549F19C2665ALL) <= (safe_lshift_func_int16_t_s_u(((p_16 == (safe_add_func_uint64_t_u_u(l_1536, (l_1541[2] != &l_1542)))) && 2UL), 10)))) & (-10L))) >= p_17)) >= p_16))), 0UL)), 7)))) ^ 1UL), l_1544));
                        l_1515 = (((((*g_703) = p_15) & ((safe_mod_func_uint16_t_u_u((((void*)0 != l_1547) , (3UL || ((*g_83) &= ((safe_div_func_int64_t_s_s((g_166 = 0x2C3275D97B0FC70BLL), l_1465)) && (1UL == (safe_mod_func_int64_t_s_s((p_15 , 5L), p_15))))))), l_1552)) > g_112)) && 0x4C04L) , 0x4B1D65EAL);
                        (*g_83) |= 0x89ACF240L;
                    }
                    for (l_1446 = 0; (l_1446 < 18); ++l_1446)
                    { /* block id: 657 */
                        uint16_t l_1555 = 65535UL;
                        uint8_t ***l_1561[4];
                        uint8_t ****l_1562[3][3][7] = {{{&l_1561[0],&l_1541[2],(void*)0,&l_1561[0],&l_1561[0],(void*)0,&l_1561[0]},{&l_1541[2],&l_1541[2],&l_1541[2],&l_1541[0],(void*)0,&l_1541[3],(void*)0},{&l_1541[2],&l_1561[0],&l_1561[0],&l_1561[0],&l_1561[0],&l_1541[2],&l_1541[2]}},{{&l_1541[2],(void*)0,&l_1561[0],&l_1561[0],(void*)0,&l_1561[0],&l_1561[0]},{&l_1561[0],(void*)0,&l_1541[2],&l_1541[2],(void*)0,&l_1561[0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1541[2],&l_1561[0],&l_1541[3]}},{{(void*)0,&l_1561[0],&l_1561[3],(void*)0,&l_1561[0],&l_1541[0],&l_1561[0]},{&l_1561[0],&l_1541[2],&l_1541[3],&l_1541[2],&l_1541[2],&l_1541[2],&l_1541[3]},{&l_1541[2],&l_1541[2],&l_1561[0],&l_1541[2],&l_1541[0],&l_1541[2],(void*)0}}};
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_1561[i] = &l_1542;
                        l_1555--;
                        (*g_83) = (safe_lshift_func_uint8_t_u_s((l_1560 != (g_1563 = l_1561[0])), 5));
                    }
                    for (l_1536 = 0; (l_1536 < 8); l_1536++)
                    { /* block id: 664 */
                        return g_72;
                    }
                    (*g_83) = (safe_rshift_func_int8_t_s_s(((l_1552 | (safe_add_func_int16_t_s_s(((*g_835) = (safe_div_func_int16_t_s_s(((-3L) || (l_1524 < ((+(((**g_1564) , (+p_16)) == 0UL)) == (l_1575[1] & ((safe_rshift_func_int16_t_s_s(((l_1575[1] | p_17) || 0xC3CE2AE4L), l_1524)) != 0x31F0AE9FL))))), 0x7EA3L))), 0xA812L))) && p_17), 5));
                }
                l_1578 ^= ((*g_83) &= l_1575[2]);
            }
            if (p_16)
                continue;
            for (l_1543 = 0; (l_1543 < 32); l_1543 = safe_add_func_int8_t_s_s(l_1543, 2))
            { /* block id: 676 */
                uint16_t l_1583[10][7] = {{0xECC8L,0x6EBAL,65534UL,0x1C49L,0x9441L,0x9441L,0x1C49L},{0x5151L,65533UL,0x5151L,0x1C49L,0xB4C7L,0xCCC7L,65533UL},{0x1C49L,0x14C4L,6UL,1UL,0xB8D5L,0x1C49L,0UL},{4UL,1UL,0xB4C7L,0x5151L,0UL,0xCCC7L,0x6EBAL},{65535UL,0x9441L,3UL,1UL,3UL,0x9441L,65535UL},{65535UL,0xB4C7L,65527UL,0x7D6CL,0x1C49L,0x6EBAL,0x5151L},{65534UL,1UL,1UL,0xCCC7L,4UL,1UL,1UL},{4UL,0xECC8L,0xB8D5L,0x14C4L,65535UL,4UL,65535UL},{1UL,0x5151L,0x5151L,1UL,65535UL,65527UL,0x7D6CL},{3UL,0x1C49L,0x311EL,0UL,4UL,1UL,0xB4C7L}};
                int32_t l_1610 = 0x43F8E343L;
                int32_t l_1621[4][5][4] = {{{0x5E927DE7L,(-1L),0x5E927DE7L,1L},{0x371C5969L,0x62CC9DD3L,0x5E927DE7L,0x9B480C2AL},{0x5E927DE7L,0x9B480C2AL,0x5E927DE7L,0x62CC9DD3L},{0x371C5969L,1L,0x5E927DE7L,(-1L)},{0x5E927DE7L,(-1L),0x5E927DE7L,1L}},{{0x371C5969L,0x62CC9DD3L,0x5E927DE7L,0x9B480C2AL},{0x5E927DE7L,0x9B480C2AL,0x5E927DE7L,0x62CC9DD3L},{0x371C5969L,1L,0x5E927DE7L,(-1L)},{0x5E927DE7L,(-1L),0x5E927DE7L,1L},{0x371C5969L,0x62CC9DD3L,0x5E927DE7L,0x9B480C2AL}},{{0x5E927DE7L,0x9B480C2AL,0x5E927DE7L,0x62CC9DD3L},{0x371C5969L,1L,0x5E927DE7L,(-1L)},{0x5E927DE7L,(-1L),0x5E927DE7L,1L},{0x371C5969L,0x62CC9DD3L,0x5E927DE7L,0x9B480C2AL},{0x5E927DE7L,0x9B480C2AL,0x5E927DE7L,0x62CC9DD3L}},{{0x371C5969L,1L,0x5E927DE7L,(-1L)},{0x5E927DE7L,(-1L),0x5E927DE7L,1L},{0x371C5969L,0x62CC9DD3L,0x5E927DE7L,0x9B480C2AL},{0x5E927DE7L,0x9B480C2AL,0x5E927DE7L,0x62CC9DD3L},{0x371C5969L,1L,0x5E927DE7L,(-1L)}}};
                int64_t l_1623 = 0x52F2DD7FFC461495LL;
                int16_t l_1626[7] = {0L,0L,0x1D2DL,0L,0L,0x1D2DL,0L};
                int i, j, k;
                for (l_1544 = 0; (l_1544 <= 9); l_1544 += 1)
                { /* block id: 679 */
                    uint32_t l_1611 = 0x44B7B22CL;
                    int32_t l_1612 = (-9L);
                    for (g_136 = 0; (g_136 <= 2); g_136 += 1)
                    { /* block id: 682 */
                        uint16_t *l_1589 = (void*)0;
                        int32_t **l_1613 = &g_83;
                        int i, j;
                    }
                    return l_1429[1][1];
                }
                ++l_1628;
                l_1429[0][4] = (l_1436[5] ^= (((safe_mul_func_uint8_t_u_u((*g_703), ((*g_514) != (safe_rshift_func_int16_t_s_u((safe_mod_func_int32_t_s_s((!0x14BA300A1B2286D7LL), 1L)), (((safe_mod_func_int8_t_s_s((safe_sub_func_int8_t_s_s((g_36[1] = ((l_1429[2][8] , &g_1161) != &l_1430)), ((*l_1438) &= 0x9CL))), (safe_mul_func_int16_t_s_s(((0x5E4F554D4C028808LL != g_40) != g_463[0][2]), l_1429[2][8])))) < 0x6B7E7B6E49363CC9LL) != p_16)))))) <= l_1620[2][0][0]) < l_1625));
            }
        }
lbl_1754:
        for (l_1625 = 2; (l_1625 >= 0); l_1625 -= 1)
        { /* block id: 705 */
            int16_t l_1658[7] = {(-10L),3L,3L,(-10L),3L,3L,(-10L)};
            uint16_t * const l_1660 = (void*)0;
            int16_t ***l_1676[9] = {&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547};
            int32_t l_1683 = 8L;
            const int32_t l_1711 = 0x3244366DL;
            int i;
            (*g_83) = l_1447[(l_1625 + 5)];
            for (g_136 = 0; (g_136 <= 2); g_136 += 1)
            { /* block id: 709 */
                int64_t l_1657 = 0x724B0C8EAAC1AF76LL;
                int64_t *l_1659 = &g_1627;
                uint32_t l_1661 = 0xF63201D9L;
                int32_t l_1675 = 0x1730E52EL;
            }
        }
        for (l_1544 = (-20); (l_1544 <= 7); l_1544 = safe_add_func_uint64_t_u_u(l_1544, 2))
        { /* block id: 749 */
            int16_t l_1723 = 5L;
            int32_t l_1740 = 0x8206A744L;
            int32_t l_1741 = 0x8BAB0638L;
            int32_t l_1742 = 0x615E9CDAL;
            int32_t l_1744 = 0xDAC55359L;
            int32_t l_1745[1];
            int16_t **l_1756 = &g_239;
            int32_t *l_1766 = &g_1263;
            uint64_t l_1770 = 1UL;
            int16_t *l_1789[8] = {&g_240,&g_240,&g_240,&g_240,&g_240,&g_240,&g_240,&g_240};
            int16_t **l_1788 = &l_1789[6];
            int32_t *l_1833[7] = {&l_1429[2][8],&l_1741,&l_1741,&l_1429[2][8],&l_1741,&l_1741,&l_1429[2][8]};
            int i;
            for (i = 0; i < 1; i++)
                l_1745[i] = (-3L);
            for (l_1619 = 0; (l_1619 == (-19)); l_1619--)
            { /* block id: 752 */
                const uint64_t *l_1733 = &g_1734;
                const uint64_t **l_1732 = &l_1733;
                int16_t ***l_1735[4][10] = {{&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547},{&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547},{&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547},{&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547,&l_1547}};
                int32_t l_1746 = 0x74842131L;
                int32_t l_1747 = 0x17DEF425L;
                int32_t l_1748 = (-1L);
                int32_t l_1749 = 0xDCC670C5L;
                int32_t l_1750[2];
                int i, j;
                for (i = 0; i < 2; i++)
                    l_1750[i] = 0xAB9CEBF9L;
                if (((*g_83) = (safe_sub_func_uint16_t_u_u((safe_mod_func_int16_t_s_s((0x9FAE270BD88E7EF0LL & 1UL), ((safe_mul_func_int16_t_s_s(l_1723, (((((safe_rshift_func_int16_t_s_u((((((p_16 >= p_17) , &l_1541[1]) != &g_1563) && (--g_369)) < (safe_mul_func_uint8_t_u_u(0x6CL, (safe_sub_func_int8_t_s_s(((((*l_1732) = (void*)0) == (void*)0) > 0x0F2DD4C01063D567LL), p_17))))), 0)) , l_1735[3][7]) != &l_1547) <= l_1723) != 246UL))) , 0xB351L))), l_1620[1][7][5]))))
                { /* block id: 756 */
                    int8_t l_1736 = 0xADL;
                    int32_t *l_1737 = (void*)0;
                    int32_t *l_1738 = (void*)0;
                    int32_t *l_1739[2][9][9] = {{{&g_40,&l_1620[1][7][5],&g_72,&l_1436[0],&g_72,&l_1620[1][7][5],&l_1429[2][8],&g_494,&l_1436[0]},{&l_1620[3][2][0],&l_1620[3][8][4],&l_1619,&l_1436[6],&l_1465,&g_40,&l_1620[3][8][4],&g_494,&l_1436[6]},{&g_40,&l_1465,&l_1436[6],&l_1619,&l_1620[3][8][4],&l_1620[3][2][0],&g_494,&g_494,&l_1620[3][2][0]},{&l_1620[1][7][5],&g_72,&l_1436[0],&g_72,&l_1620[1][7][5],&l_1429[2][8],&g_494,&l_1436[0],&l_1436[6]},{&l_1436[6],(void*)0,&g_40,&l_1429[2][8],&l_1429[0][6],&l_1436[6],&l_1620[3][8][4],&l_1619,&l_1436[0]},{(void*)0,&l_1620[1][7][5],&l_1465,&l_1619,&l_1436[6],&l_1429[2][8],&l_1429[2][8],&l_1436[6],&l_1619},{&l_1619,(void*)0,&l_1619,&l_1436[6],&l_1436[6],&l_1620[3][2][0],(void*)0,&g_494,&g_72},{&l_1436[0],&l_1436[6],&g_494,&l_1619,&l_1429[0][6],&g_40,&g_72,&l_1465,&l_1620[3][2][0]},{&l_1620[1][7][5],&g_494,&l_1436[0],&l_1436[6],&l_1620[1][7][5],&l_1620[1][7][5],&l_1436[6],&l_1436[0],&g_494}},{{&l_1436[6],&g_40,&l_1436[0],&l_1619,&l_1620[3][8][4],&l_1436[6],&l_1429[0][6],&l_1429[2][8],&g_40},{&l_1619,&l_1620[1][7][5],&g_494,&l_1429[2][8],&l_1465,(void*)0,&l_1429[2][8],&l_1436[6],&l_1429[2][8]},{&g_494,&g_40,&l_1619,&g_72,&g_72,&l_1619,&g_40,&g_494,&l_1465},{&g_494,&g_494,&l_1465,&l_1619,(void*)0,&l_1436[0],&l_1436[6],&g_72,&l_1620[3][2][0]},{&l_1619,&l_1436[6],&g_40,&l_1436[6],&l_1620[1][7][5],&l_1620[1][7][5],&l_1465,&g_40,&l_1465},{&l_1436[6],(void*)0,&l_1436[0],&l_1436[0],(void*)0,&l_1436[6],(void*)0,&g_40,&l_1429[2][8]},{&l_1620[1][7][5],&l_1620[1][7][5],&l_1436[6],&g_40,&l_1436[6],&l_1619,&l_1429[2][8],&g_72,&g_40},{&l_1436[0],(void*)0,&l_1619,&l_1465,&g_494,&g_494,(void*)0,&g_494,&g_494},{&l_1619,&g_72,&g_72,&l_1619,&g_40,&g_494,&l_1465,&l_1436[6],&l_1620[3][2][0]}}};
                    int i, j, k;
                    g_1751++;
                    if (p_17)
                        goto lbl_1754;
                    for (g_493 = 1; (g_493 <= 7); g_493 += 1)
                    { /* block id: 761 */
                        return l_1745[0];
                    }
                }
                else
                { /* block id: 764 */
                    uint32_t l_1769[10][10] = {{4294967295UL,0x3CC0EF72L,0x3CC0EF72L,4294967295UL,0x34CF351AL,0x02299562L,1UL,4294967295UL,0x8A8F34A6L,0UL},{0x54C64181L,4294967289UL,0x3D8FE027L,4294967295UL,1UL,8UL,0x3CC0EF72L,1UL,0x8A8F34A6L,0UL},{4294967295UL,4294967294UL,4294967295UL,4294967295UL,0x257B1321L,7UL,0x46D333FEL,0x54C64181L,0UL,1UL},{4294967286UL,4294967288UL,7UL,2UL,4294967289UL,1UL,0xE189820FL,0x6830B0EEL,1UL,4294967295UL},{0x257B1321L,0UL,0x276E261AL,7UL,4294967295UL,0UL,4294967295UL,7UL,0x276E261AL,0UL},{0UL,0x0D0E0800L,0xAA89CE26L,0x257B1321L,0x46D333FEL,0x8A8F34A6L,0x34CF351AL,0UL,0x3D8FE027L,0xE189820FL},{4294967287UL,0x8E409D54L,0x807B9C05L,0x34CF351AL,4UL,0x8A8F34A6L,0x54C64181L,1UL,0UL,0x6830B0EEL},{0UL,0x807B9C05L,4294967287UL,1UL,0UL,0UL,0xF14B1119L,0x0D0E0800L,0x34CF351AL,0xF9453757L},{0x257B1321L,0x276E261AL,0xF9453757L,1UL,0xAA89CE26L,1UL,4294967294UL,3UL,0UL,0UL},{4294967286UL,1UL,1UL,8UL,8UL,1UL,1UL,4294967286UL,4294967295UL,0x02299562L}};
                    int32_t **l_1787 = &g_84;
                    int i, j;
                    if ((((((*g_652) = (l_1755 = l_1547)) == l_1756) > (((safe_lshift_func_uint8_t_u_u(((safe_unary_minus_func_uint64_t_u(((safe_add_func_int32_t_s_s(((((l_1762[0] && p_16) >= (safe_div_func_int64_t_s_s(((((safe_unary_minus_func_int16_t_s(((l_1766 != ((((p_15 , (safe_mod_func_uint64_t_u_u(((*g_1162) = (0x503365B1L != (((4UL & p_16) < 0xBDD585F0L) != (-5L)))), l_1750[1]))) , l_1762[5]) == l_1742) , &g_1265)) || l_1740))) < l_1750[1]) || p_15) == g_1710), g_40))) > l_1544) != p_15), p_15)) ^ 1UL))) , l_1750[1]), 5)) | l_1769[4][8]) , l_1770)) , l_1769[4][8]))
                    { /* block id: 768 */
                        int8_t l_1773[3][2] = {{0x87L,0x87L},{0x87L,0x87L},{0x87L,0x87L}};
                        int i, j;
                        (*g_83) |= ((safe_rshift_func_uint8_t_u_u((l_1773[0][1] ^ 0xAD38D3D5L), 3)) , (l_1620[2][5][4] = ((((***g_1563) = (safe_div_func_int32_t_s_s(((safe_div_func_int8_t_s_s((safe_unary_minus_func_int8_t_s(p_15)), (((safe_rshift_func_int8_t_s_s(((*l_1438) = l_1773[0][1]), l_1781)) == 0x9E5AL) , (**g_1564)))) , 4L), 0xBF663CC0L))) , l_1773[1][1]) & 8UL)));
                        return p_17;
                    }
                    else
                    { /* block id: 774 */
                        int32_t **l_1784 = &g_84;
                        (*g_1782) = (*g_896);
                        (*l_1784) = func_54(&g_60, &l_1620[1][7][5], l_1447[5]);
                    }
                    for (l_1465 = 0; (l_1465 > (-1)); l_1465 = safe_sub_func_uint16_t_u_u(l_1465, 1))
                    { /* block id: 780 */
                        (*g_84) = p_15;
                        if (p_17)
                            continue;
                    }
                    (*l_1787) = &l_1429[2][8];
                }
            }
            (*g_83) = ((***g_651) != ((*l_1788) = (*l_1756)));
            for (l_1622 = 0; (l_1622 == 28); ++l_1622)
            { /* block id: 791 */
                int32_t l_1804 = (-1L);
                int64_t *l_1809[7] = {(void*)0,&l_1673,&l_1673,(void*)0,&l_1673,&l_1673,(void*)0};
                int32_t l_1815 = 0xD03A4530L;
                const uint8_t l_1830 = 0x40L;
                int i;
                (*g_83) = (safe_div_func_int16_t_s_s(((safe_div_func_int16_t_s_s(((safe_rshift_func_int16_t_s_u((l_1745[0] = ((safe_mul_func_uint16_t_u_u(p_17, (safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(l_1804, (0UL <= (((((*l_1438) = (((l_1465 & (safe_mul_func_uint8_t_u_u(((safe_div_func_int64_t_s_s(l_1620[1][7][5], (g_1627 = p_17))) != (l_1447[7] <= (safe_div_func_int8_t_s_s(p_17, (((l_1815 ^= (safe_mul_func_uint16_t_u_u(65531UL, l_1814))) , (-10L)) || p_17))))), l_1620[1][7][5]))) && l_1673) | l_1436[6])) & p_17) >= 65529UL) < 0xC9L)))) || 0x280D641EL), l_1723)))) , p_17)), 12)) , l_1436[2]), p_15)) , l_1619), 0x2566L));
                for (g_493 = 0; (g_493 <= 3); g_493 += 1)
                { /* block id: 799 */
                    int32_t l_1823[4];
                    uint8_t ****l_1828 = (void*)0;
                    int32_t l_1831[9][9][3] = {{{0xE53D3D53L,0xEFA03371L,0x93956E0CL},{(-9L),0x36E322FAL,0x0B1332A0L},{0xB2620C82L,5L,0x8C8B72F7L},{0L,0x2F71D88EL,0L},{0xE53D3D53L,(-9L),0x8C8B72F7L},{0x95E5E914L,0xE3B87FADL,0x0B1332A0L},{(-3L),9L,0x93956E0CL},{1L,0x2F71D88EL,0x65C9465CL},{(-3L),(-8L),0x351D9A80L}},{{0x95E5E914L,0x36E322FAL,0x4059BF28L},{0xE53D3D53L,0x860D4D3FL,0x93956E0CL},{0L,0x36E322FAL,1L},{0xB2620C82L,(-8L),0x8C8B72F7L},{(-9L),0x2F71D88EL,(-9L)},{0xE53D3D53L,9L,0x8C8B72F7L},{0x8B8FEA05L,0xE3B87FADL,1L},{(-3L),(-9L),0x93956E0CL},{0x0B1332A0L,0x2F71D88EL,0x4059BF28L}},{{(-3L),5L,0x351D9A80L},{0x8B8FEA05L,0x36E322FAL,0x65C9465CL},{0xE53D3D53L,0xEFA03371L,0x93956E0CL},{(-9L),0x36E322FAL,0x0B1332A0L},{0xB2620C82L,5L,0x8C8B72F7L},{0L,0x2F71D88EL,0L},{0xE53D3D53L,(-9L),0x8C8B72F7L},{0x95E5E914L,0xE3B87FADL,0x0B1332A0L},{(-3L),9L,0x93956E0CL}},{{1L,0x2F71D88EL,0x65C9465CL},{(-3L),(-8L),0x351D9A80L},{0x95E5E914L,0x36E322FAL,0x4059BF28L},{0xE53D3D53L,0x860D4D3FL,0x93956E0CL},{0L,0x36E322FAL,1L},{0xB2620C82L,(-8L),0x8C8B72F7L},{(-9L),0x2F71D88EL,(-9L)},{0xE53D3D53L,9L,0x8C8B72F7L},{0x8B8FEA05L,0xE3B87FADL,0x5BE94370L}},{{0xFC471BC4L,(-3L),9L},{0xD7B4F582L,0L,0xB855C529L},{0xFC471BC4L,0x0133FF65L,1L},{0xFCC2735BL,(-10L),0xE03088A3L},{0x26A48699L,0xB2620C82L,9L},{0L,(-10L),0xD7B4F582L},{0x10B17C35L,0x0133FF65L,(-3L)},{(-1L),0L,(-1L)},{0x26A48699L,(-3L),(-3L)}},{{(-9L),0x1A46F02BL,0xD7B4F582L},{0xFC471BC4L,0x351D9A80L,9L},{0x5BE94370L,0L,0xE03088A3L},{0xFC471BC4L,0xE53D3D53L,1L},{(-9L),(-10L),0xB855C529L},{0x26A48699L,0x93956E0CL,9L},{(-1L),(-10L),0x5BE94370L},{0x10B17C35L,0xE53D3D53L,(-3L)},{0L,0L,0L}},{{0x26A48699L,0x351D9A80L,(-3L)},{0xFCC2735BL,0x1A46F02BL,0x5BE94370L},{0xFC471BC4L,(-3L),9L},{0xD7B4F582L,0L,0xB855C529L},{0xFC471BC4L,0x0133FF65L,1L},{0xFCC2735BL,(-10L),0xE03088A3L},{0x26A48699L,0xB2620C82L,9L},{0L,(-10L),0xD7B4F582L},{0x10B17C35L,0x0133FF65L,(-3L)}},{{(-1L),0L,(-1L)},{0x26A48699L,(-3L),(-3L)},{(-9L),0x1A46F02BL,0xD7B4F582L},{0xFC471BC4L,0x351D9A80L,9L},{0x5BE94370L,0L,0xE03088A3L},{0xFC471BC4L,0xE53D3D53L,1L},{(-9L),(-10L),0xB855C529L},{0x26A48699L,0x93956E0CL,9L},{(-1L),(-10L),0x5BE94370L}},{{0x10B17C35L,0xE53D3D53L,(-3L)},{0L,0L,0L},{0x26A48699L,0x351D9A80L,(-3L)},{0xFCC2735BL,0x1A46F02BL,0x5BE94370L},{0xFC471BC4L,(-3L),9L},{0xD7B4F582L,0L,0xB855C529L},{0xFC471BC4L,0x0133FF65L,1L},{0xFCC2735BL,(-10L),0xE03088A3L},{0x26A48699L,0xB2620C82L,9L}}};
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_1823[i] = 0xCC43888FL;
                    l_1823[3] = (((safe_mod_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(l_1620[0][7][4], (safe_unary_minus_func_uint32_t_u((l_1436[6] = ((l_1831[7][2][0] ^= (g_951 ^= ((safe_mul_func_int8_t_s_s(l_1815, (l_1823[2] | ((***g_652) <= ((safe_mul_func_uint8_t_u_u(0x78L, ((***g_1563) ^= ((((safe_rshift_func_uint16_t_u_s((1L || (&l_1541[0] == (l_1829 = l_1828))), l_1483)) , 0xD711224756209DF0LL) | 0xEF9A8A7DB7D2F368LL) || l_1436[8])))) & l_1447[5]))))) & l_1830))) && 0L)))))), p_15)) , (void*)0) != l_1832);
                    for (l_1744 = 0; (l_1744 <= 8); l_1744 += 1)
                    { /* block id: 808 */
                        uint64_t l_1845 = 2UL;
                        int i;
                        l_1833[5] = func_54(&g_60, (*g_578), l_1436[(g_493 + 2)]);
                        l_1815 = (safe_mul_func_uint8_t_u_u(((safe_div_func_int16_t_s_s(((((safe_add_func_int8_t_s_s((safe_div_func_uint32_t_u_u(l_1830, p_17)), ((l_1436[5] = 0x007E1217L) >= (safe_sub_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(p_17)), (***g_1563)))))) ^ p_16) <= (l_1845 , ((((**l_1547) &= (safe_add_func_int64_t_s_s((-4L), 6L))) && l_1831[7][2][0]) | p_16))) | l_1845), p_15)) > 255UL), 254UL));
                        return l_1436[(g_493 + 2)];
                    }
                }
            }
        }
        for (g_951 = 0; (g_951 >= 0); g_951 -= 1)
        { /* block id: 820 */
            uint32_t l_1871 = 0UL;
            int64_t *l_1887 = (void*)0;
            int64_t *l_1888 = &l_1625;
            int64_t *l_1889 = (void*)0;
            int64_t *l_1890 = &l_1673;
            int32_t l_1899 = 0x83716C6BL;
            int32_t l_1900 = 0xBB6AF1BCL;
            int32_t l_1901 = 0xD912301EL;
            int32_t l_1916[7][9][4] = {{{0x897F6839L,0x8745B1AAL,0x897F6839L,0x3E863255L},{2L,(-1L),0x9C564989L,0x8745B1AAL},{2L,6L,0x897F6839L,(-1L)},{0x897F6839L,(-1L),0x897F6839L,6L},{2L,0x8745B1AAL,0x9C564989L,(-1L)},{2L,0x3E863255L,0x897F6839L,0x8745B1AAL},{0x897F6839L,0x8745B1AAL,0x897F6839L,0x3E863255L},{2L,(-1L),0x9C564989L,0x8745B1AAL},{2L,6L,0x897F6839L,(-1L)}},{{0x897F6839L,(-1L),0x897F6839L,6L},{2L,0x8745B1AAL,0x9C564989L,(-1L)},{2L,0x3E863255L,0x897F6839L,0x8745B1AAL},{0x897F6839L,0x8745B1AAL,0x897F6839L,0x3E863255L},{2L,(-1L),0x9C564989L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L}},{{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L},{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L}},{{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L},{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L}},{{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L},{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L}},{{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L},{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L}},{{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,2L,6L},{0x897F6839L,(-9L),0x9C564989L,0x3E863255L},{0x9C564989L,0x3E863255L,0x9C564989L,(-9L)},{0x897F6839L,6L,2L,0x3E863255L},{0x897F6839L,(-1L),0x9C564989L,6L},{0x9C564989L,6L,0x9C564989L,(-1L)},{0x897F6839L,0x3E863255L,0x897F6839L,(-9L)},{0x9C564989L,0x8745B1AAL,2L,(-1L)}}};
            int64_t **l_1988 = &l_1890;
            const uint16_t *l_1996 = &l_1814;
            const uint16_t **l_1995 = &l_1996;
            int16_t **** const l_2023 = (void*)0;
            int16_t **** const *l_2022 = &l_2023;
            uint32_t l_2054[2];
            const uint8_t l_2091 = 2UL;
            int32_t l_2094 = 0x322B4026L;
            uint16_t l_2132 = 65531UL;
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_2054[i] = 4294967295UL;
        }
    }
    else
    { /* block id: 997 */
        int32_t *l_2188 = (void*)0;
        int32_t *l_2189 = (void*)0;
        int32_t l_2190[8][7] = {{5L,5L,(-5L),0xA33634C7L,(-5L),5L,5L},{5L,(-5L),0xA33634C7L,(-5L),5L,5L,(-5L)},{0xEF148A9BL,0L,0xEF148A9BL,(-5L),(-5L),0xEF148A9BL,0L},{(-5L),0L,0xA33634C7L,0xA33634C7L,0L,(-5L),0L},{0xEF148A9BL,(-5L),(-5L),0xEF148A9BL,0L,0xEF148A9BL,(-5L)},{5L,5L,(-5L),0xA33634C7L,(-5L),5L,5L},{5L,(-5L),0xA33634C7L,(-5L),5L,5L,(-5L)},{0xEF148A9BL,0L,0xEF148A9BL,(-5L),(-5L),0xEF148A9BL,0L}};
        int32_t *l_2191 = &g_72;
        int32_t *l_2192 = &l_1436[6];
        int32_t *l_2193 = (void*)0;
        int32_t *l_2194 = &l_2190[3][2];
        int32_t *l_2195 = &g_40;
        int32_t *l_2196[10][4][5] = {{{&l_2190[3][2],&g_494,(void*)0,&l_1436[6],(void*)0},{&g_40,&g_40,&l_1429[0][6],&g_40,&g_40},{(void*)0,&l_1436[6],(void*)0,&g_494,&l_2190[3][2]},{&g_40,&g_72,&g_72,&g_40,&g_72}},{{&l_2190[3][2],&l_1436[6],&g_40,&l_1436[6],&l_2190[3][2]},{&g_72,&g_40,&g_72,&g_72,&g_40},{&l_2190[3][2],&g_494,(void*)0,&l_1436[6],(void*)0},{&g_40,&g_40,&l_1429[0][6],&g_40,&g_40}},{{(void*)0,&l_1436[6],(void*)0,&g_494,&l_2190[3][2]},{&g_40,&g_72,&g_72,&g_40,&g_72},{&l_2190[3][2],&l_1436[6],&g_40,&l_1436[6],&l_2190[3][2]},{&g_72,&g_40,&g_72,&g_72,&g_40}},{{&l_2190[3][2],&g_494,(void*)0,&l_1436[6],(void*)0},{&g_40,&g_40,&l_1429[0][6],&g_40,&g_40},{(void*)0,&l_1436[6],(void*)0,&g_494,&l_2190[3][2]},{&g_40,&g_72,&g_72,&g_40,&g_72}},{{&l_2190[3][2],&l_1436[6],&g_40,&l_1436[6],&l_2190[3][2]},{&g_72,&g_40,&g_72,&g_72,&g_40},{&l_2190[3][2],&g_494,(void*)0,&l_1436[6],(void*)0},{&g_40,&g_40,&l_1429[0][6],&g_40,&g_40}},{{(void*)0,&l_1436[6],(void*)0,&g_494,&l_2190[3][2]},{&g_40,&g_72,&g_72,&g_40,&g_72},{&l_2190[3][2],&l_1436[6],&g_40,&l_1436[6],&l_2190[3][2]},{&g_72,&g_40,&g_72,&g_72,&g_40}},{{&l_2190[3][2],&g_494,(void*)0,&l_1436[6],(void*)0},{&g_40,&g_40,&l_1429[0][6],&g_72,&g_72},{&g_40,&g_494,&g_40,&g_40,(void*)0},{&g_72,&l_1429[0][6],&l_1429[0][6],&g_72,&l_1429[0][6]}},{{(void*)0,&g_494,&l_2190[3][2],&g_494,(void*)0},{&l_1429[0][6],&g_72,&l_1429[0][6],&l_1429[0][6],&g_72},{(void*)0,&g_40,&g_40,&g_494,&g_40},{&g_72,&g_72,&g_40,&g_72,&g_72}},{{&g_40,&g_494,&g_40,&g_40,(void*)0},{&g_72,&l_1429[0][6],&l_1429[0][6],&g_72,&l_1429[0][6]},{(void*)0,&g_494,&l_2190[3][2],&g_494,(void*)0},{&l_1429[0][6],&g_72,&l_1429[0][6],&l_1429[0][6],&g_72}},{{(void*)0,&g_40,&g_40,&g_494,&g_40},{&g_72,&g_72,&g_40,&g_72,&g_72},{&g_40,&g_494,&g_40,&g_40,(void*)0},{&g_72,&l_1429[0][6],&l_1429[0][6],&g_72,&l_1429[0][6]}}};
        uint16_t l_2199 = 8UL;
        int32_t l_2218[9];
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_2218[i] = 0xE12CC033L;
        --l_2199;
        if (p_16)
        { /* block id: 999 */
            (*l_2194) &= p_15;
        }
        else
        { /* block id: 1001 */
            return p_15;
        }
        for (g_1751 = 0; (g_1751 <= 6); g_1751 += 1)
        { /* block id: 1006 */
            uint16_t l_2202 = 65531UL;
            uint16_t *l_2215[1];
            int32_t l_2220 = 0xEACDF3ACL;
            const int32_t *l_2222 = &l_1436[7];
            int i;
            for (i = 0; i < 1; i++)
                l_2215[i] = &g_134;
            l_2220 = ((((l_2202 = 4294967295UL) < (((!(l_2218[1] = (safe_add_func_int32_t_s_s(((((*l_2192) |= ((*l_2195) ^= ((~(safe_mod_func_uint8_t_u_u(246UL, (safe_sub_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(l_1762[g_1751], (((**l_1952) = (0UL & (((l_2215[0] != &l_2199) || (*g_1162)) && (0UL | (safe_mul_func_int8_t_s_s(0xFCL, l_1762[g_1751])))))) <= p_15))), p_17)), p_15))))) , (-8L)))) <= 7UL) >= 18446744073709551609UL), (-1L))))) || g_407) && l_2219)) , 0L) < (-10L));
            for (l_1622 = 0; (l_1622 <= 6); l_1622 += 1)
            { /* block id: 1015 */
                const int32_t **l_2221 = &g_387[1];
                int32_t l_2239 = 1L;
                l_2222 = ((*l_2221) = &l_2218[1]);
                (*l_2192) = (!((((((safe_sub_func_uint16_t_u_u(((((safe_add_func_int16_t_s_s((((safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(p_16, 13)), (g_136 < p_17))) <= (**l_1952)) & (safe_div_func_int16_t_s_s((p_16 != (((~(l_2239 = ((****l_1829) = (0L != ((safe_sub_func_int64_t_s_s(((p_15 > 6UL) , (safe_add_func_int32_t_s_s((**g_1056), (**l_2221)))), 0xAA67BEE1DDF88960LL)) >= (**g_1564)))))) , (-1L)) || p_17)), 0xE2C5L))), (**l_2221))) != 0x2441L) == 1L) , 0x2713L), 0xC50AL)) >= 0x2571L) < 1UL) && (**l_2221)) <= p_17) , p_16));
            }
            (*l_2194) |= (+((**g_1161) = p_17));
        }
    }
    l_1436[1] |= (l_1429[0][4] ^= ((**l_1952) , ((l_2241[0][9][2] = &g_1265) == (void*)0)));
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_831 g_832 g_651 g_652 g_238 g_239 g_240 g_515 g_136 g_977 g_369 g_494 g_703 g_83 g_72 g_36 g_836 g_1162 g_93
 * writes: g_240 g_369 g_515 g_72 g_36 g_977
 */
static int32_t  func_22(int32_t * p_23, uint32_t  p_24)
{ /* block id: 583 */
    uint32_t l_1389[9][7] = {{1UL,0UL,0x1835ECEBL,6UL,9UL,0x4996CEEEL,0xC9F2301EL},{18446744073709551615UL,0x3CA2F165L,18446744073709551611UL,1UL,0x41F1691DL,4UL,9UL},{1UL,6UL,1UL,0xEC95FC4FL,1UL,0x75B2CC75L,0x9FB456CDL},{0x3CA2F165L,1UL,18446744073709551612UL,18446744073709551612UL,1UL,0x3CA2F165L,4UL},{0x9FB456CDL,0xC9F2301EL,0x3CA2F165L,18446744073709551606UL,0x41F1691DL,9UL,0UL},{1UL,0x401B7561L,0x50716475L,0UL,9UL,0x41F1691DL,18446744073709551606UL},{18446744073709551606UL,0xC9F2301EL,0x401B7561L,4UL,0x3CA2F165L,1UL,18446744073709551612UL},{0xEC95FC4FL,1UL,0x75B2CC75L,0x9FB456CDL,0x75B2CC75L,1UL,0xEC95FC4FL},{18446744073709551607UL,6UL,0x9FB456CDL,9UL,4UL,0x41F1691DL,1UL}};
    int32_t *l_1400 = &g_494;
    uint32_t *l_1403 = &g_369;
    int16_t l_1404[10][6][4] = {{{0L,0x8D42L,0L,0x538FL},{0xA338L,0xCB63L,(-1L),(-5L)},{(-3L),7L,0x368BL,0xB385L},{7L,0x8D42L,0xB343L,0x37DEL},{1L,0xC9F7L,0xCB63L,0xABCBL},{0x9AF2L,0xE5A4L,(-4L),(-1L)}},{{0xA338L,1L,(-1L),0L},{(-1L),0xB385L,0L,0x538FL},{9L,0x4B18L,(-1L),0L},{0x8607L,1L,0xBF40L,6L},{(-10L),0xCB2CL,8L,0xCBF7L},{1L,1L,0xCB63L,(-4L)}},{{0x8607L,0xCBF7L,0x6F11L,0xC795L},{1L,0xAEE6L,0L,0x37DEL},{0xEAECL,0xCB63L,(-1L),0x93A1L},{(-1L),1L,0x73ADL,8L},{0x368BL,0x462CL,0x462CL,0x368BL},{0L,1L,(-6L),0x099CL}},{{0L,0xC89CL,0xE5A4L,0xB562L},{0xCB63L,0xEAECL,0L,0xB562L},{(-1L),0xC89CL,0xB343L,0x099CL},{(-1L),1L,0xA338L,0x368BL},{(-10L),0x462CL,2L,8L},{0xD2BBL,1L,0x597BL,0x93A1L}},{{0x40D8L,0xCB63L,1L,0x5242L},{8L,0x5E61L,(-1L),8L},{3L,(-4L),0L,1L},{(-10L),(-10L),0xA8C4L,(-4L)},{(-4L),1L,0xED73L,(-3L)},{(-5L),0x40D8L,0L,0xED73L}},{{0x368BL,1L,0x37DEL,1L},{8L,0xD2BBL,0L,(-1L)},{0L,(-10L),0x597BL,0L},{1L,0x1D5DL,4L,0xB562L},{(-10L),(-5L),(-1L),0x5242L},{0x6F11L,1L,0xB343L,0xD2BBL}},{{(-1L),0L,(-5L),0xCA89L},{0xCB63L,0x462CL,0x597BL,1L},{0x462CL,1L,(-6L),0x1A58L},{0x40D8L,(-10L),0L,0xB562L},{0x368BL,(-8L),1L,8L},{(-1L),(-10L),(-1L),0x6F11L}},{{(-1L),1L,0xA8C4L,1L},{(-10L),0L,2L,0xAEE6L},{0xBF40L,0x40D8L,0x462CL,0x93A1L},{8L,1L,1L,(-4L)},{8L,0L,0x462CL,0L},{0xBF40L,(-4L),2L,0L}},{{(-10L),0xC89CL,0xA8C4L,0x5242L},{(-1L),0xBF40L,(-1L),(-3L)},{(-1L),1L,1L,(-1L)},{0x368BL,0L,0L,0x368BL},{0x40D8L,0xD2BBL,(-6L),(-4L)},{0x462CL,0xC89CL,0x597BL,2L}},{{0xCB63L,(-1L),(-5L),0xB562L},{(-1L),0x5E61L,0xB343L,(-4L)},{0x6F11L,1L,(-1L),3L},{(-10L),0L,4L,8L},{1L,0L,0x597BL,(-3L)},{0L,0xCB63L,0L,0x1A58L}}};
    uint64_t ***l_1409 = &g_1161;
    int16_t ** const **l_1412 = (void*)0;
    int16_t l_1413 = 0x4BCDL;
    int8_t *l_1414 = &g_36[3];
    int8_t *l_1415 = (void*)0;
    int8_t *l_1416 = &g_977;
    uint64_t l_1417[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1417[i] = 0x4D00443F15F92D0ELL;
    (*g_83) |= (((*g_703) = ((((((*l_1403) &= (safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(((l_1389[6][6] == 8L) ^ ((((safe_div_func_int8_t_s_s(((void*)0 == (*g_831)), (safe_div_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u(((((****g_651) &= (-1L)) & ((safe_mod_func_int8_t_s_s((1L & (l_1400 != l_1400)), (safe_rshift_func_uint16_t_u_s(65535UL, p_24)))) | g_515[1][5][6])) , 0x9C53C03D1C298CCCLL), 0x75E9E20F0B231D4ALL)), g_136)))) | g_977) || g_515[0][0][6]) , 9L)), 9)), p_24))) ^ (*l_1400)) && p_24) | 1L) & p_24)) & l_1404[3][5][1]);
    l_1417[0] = (((*g_703) != (((*l_1400) > (safe_mul_func_uint8_t_u_u((p_24 && (((*l_1416) = ((safe_mul_func_uint16_t_u_u(((p_24 , l_1409) == l_1409), (*l_1400))) , ((*l_1414) ^= ((((((safe_lshift_func_int16_t_s_u((l_1412 != l_1412), p_24)) <= l_1413) && 0x06AAL) && (*l_1400)) || 0UL) >= (*g_703))))) > g_836)), p_24))) != (*g_1162))) || p_24);
    return (*l_1400);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_25(uint8_t  p_26, int16_t  p_27, int32_t * p_28)
{ /* block id: 579 */
    int32_t *l_1382 = (void*)0;
    return l_1382;
}


/* ------------------------------------------ */
/* 
 * reads : g_831 g_832 g_515 g_237 g_238 g_239 g_240 g_112 g_369 g_703 g_951 g_136 g_121 g_652 g_83 g_72 g_977 g_164 g_134 g_835 g_836 g_514 g_738 g_387 g_40 g_449 g_1056 g_463 g_494 g_386 g_412 g_36 g_593 g_1150 g_1161 g_1162 g_93 g_764 g_1193 g_1230 g_815 g_1263 g_60
 * writes: g_515 g_72 g_836 g_493 g_112 g_369 g_121 g_83 g_652 g_136 g_36 g_951 g_60 g_977 g_764 g_240 g_1230 g_93 g_1263 g_1265 g_166 g_412 g_40 g_134
 */
static int8_t  func_29(uint32_t  p_30, uint32_t  p_31, int32_t  p_32, int16_t  p_33)
{ /* block id: 407 */
    int16_t ****l_927 = &g_652;
    int16_t *****l_928 = &l_927;
    int32_t l_932 = 0x4700B3D5L;
    uint64_t *l_940 = &g_112;
    uint8_t l_1013 = 0UL;
    int32_t l_1043 = 1L;
    int32_t l_1045 = 0xE0B01340L;
    int16_t * const **l_1192 = &g_834[5][3][2];
    uint32_t l_1194 = 0xBBED9718L;
    int32_t l_1204 = 0x737572F7L;
    int32_t l_1205 = 1L;
    int32_t l_1206 = 0x0467DEA4L;
    int32_t *l_1221 = (void*)0;
    uint8_t **l_1222 = &g_703;
    uint64_t l_1284 = 0x43C06653108D6173LL;
    int32_t l_1310 = 0x570AB311L;
    const uint64_t l_1337 = 0x9C5F7C2DE48B994ELL;
    if ((safe_rshift_func_uint16_t_u_s(((!((*g_831) != ((*l_928) = l_927))) && (safe_sub_func_int8_t_s_s((+l_932), g_515[1][3][8]))), 7)))
    { /* block id: 409 */
        uint64_t **l_941 = &l_940;
        uint64_t *l_943 = &g_112;
        uint64_t **l_942 = &l_943;
        uint8_t *l_949[10][2][3] = {{{(void*)0,&g_412,(void*)0},{&g_412,&g_412,&g_412}},{{&g_412,&g_412,(void*)0},{&g_412,&g_412,&g_412}},{{&g_412,&g_412,(void*)0},{&g_412,&g_412,&g_412}},{{&g_412,(void*)0,&g_412},{&g_412,&g_412,(void*)0}},{{&g_412,&g_412,&g_412},{&g_412,&g_412,&g_412}},{{&g_412,&g_412,(void*)0},{&g_412,&g_412,&g_412}},{{&g_412,&g_412,(void*)0},{&g_412,&g_412,&g_412}},{{&g_412,(void*)0,&g_412},{&g_412,&g_412,(void*)0}},{{&g_412,&g_412,&g_412},{&g_412,&g_412,&g_412}},{{&g_412,&g_412,(void*)0},{&g_412,&g_412,&g_412}}};
        int32_t l_950[4][1] = {{3L},{0x50CDAC7AL},{3L},{0x50CDAC7AL}};
        uint16_t *l_957 = &g_136;
        uint16_t **l_956 = &l_957;
        uint16_t l_1002 = 65535UL;
        uint64_t *l_1031[7];
        int16_t *l_1076 = &g_836;
        int16_t ** const l_1075 = &l_1076;
        int16_t ** const *l_1074 = &l_1075;
        uint16_t l_1207 = 1UL;
        int32_t *l_1226 = &l_1043;
        int32_t *l_1227 = &l_1205;
        int32_t *l_1228 = (void*)0;
        int32_t *l_1229[5][3][1] = {{{(void*)0},{&l_1204},{(void*)0}},{{&l_1204},{(void*)0},{&l_1204}},{{(void*)0},{&l_1204},{(void*)0}},{{&l_1204},{(void*)0},{&l_1204}},{{(void*)0},{&l_1204},{(void*)0}}};
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_1031[i] = &g_93;
        if ((((safe_mul_func_int16_t_s_s(((+((***g_237) & (safe_div_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_u(((((((*l_941) = l_940) == ((*l_942) = &g_112)) < (p_32 && 247UL)) & (((!((g_112 , (safe_mul_func_uint8_t_u_u(((l_950[2][0] = ((*g_703) = (((l_932 & (l_932 , (safe_sub_func_uint64_t_u_u(g_112, g_369)))) == l_932) <= 7UL))) , p_30), p_33))) | 0xDC041084L)) == 65535UL) , 0x052DL)) ^ p_32), p_32)) != 0L), 0x72D8F629416B2144LL)))) , p_33), p_30)) , l_950[2][0]) >= g_951))
        { /* block id: 414 */
            uint64_t l_968[6][10][4] = {{{2UL,0x99BBC7428D11F3BFLL,0x365E059D09EE9981LL,0UL},{0xAC0A8E07C4215410LL,6UL,6UL,0UL},{0UL,0x0A2E592043527F11LL,0x3DCE5D57BD8EC8EALL,18446744073709551615UL},{0UL,1UL,0x8E67548A45F05B7CLL,0x4A93EA6612EBA501LL},{18446744073709551615UL,8UL,0x4A93EA6612EBA501LL,0xDC4AD4557D250DC4LL},{0UL,1UL,0x86DA7324913F3844LL,0x1099CA6CC092AD09LL},{0x15C0522EFAF8348FLL,6UL,0UL,18446744073709551615UL},{0x9D7531C25BCB08C4LL,0x2E9B854570E7755CLL,0xEF817433AA99F471LL,0x9C304FC5AA24CD92LL},{0x70C15E2EBB41607FLL,0UL,18446744073709551615UL,1UL},{6UL,1UL,1UL,0x4C5D87691020C271LL}},{{6UL,0xEF817433AA99F471LL,0xCA3AF74FAE9ECB3DLL,0UL},{0x098A061C6B35FA6ELL,0x5F980C227EF6B329LL,0x351347A0FA632206LL,1UL},{0x2E9B854570E7755CLL,0UL,0UL,0x2E9B854570E7755CLL},{0xDC4AD4557D250DC4LL,0xC092AF1C663E3D23LL,0x9C304FC5AA24CD92LL,0x86DA7324913F3844LL},{18446744073709551612UL,0xAC0A8E07C4215410LL,0x1099CA6CC092AD09LL,0x4FE71ECB5A77BA9ELL},{0x54A16DD1E50BF1B3LL,0x365E059D09EE9981LL,0xB2E98B9F422C1256LL,0x4FE71ECB5A77BA9ELL},{0x8FC8B6378AD99BECLL,0xAC0A8E07C4215410LL,0xFE38EAE46811F570LL,0x86DA7324913F3844LL},{0xCF0BF8D7AA90586ALL,0xC092AF1C663E3D23LL,18446744073709551614UL,0x2E9B854570E7755CLL},{0xC74AE975F37864DFLL,0UL,0x9D7531C25BCB08C4LL,1UL},{0xAF731DEA822A13F4LL,0x5F980C227EF6B329LL,6UL,0UL}},{{0xFE38EAE46811F570LL,0xEF817433AA99F471LL,0xCAE1E06E333C7908LL,0x4C5D87691020C271LL},{6UL,1UL,0xC092AF1C663E3D23LL,1UL},{0x6614A35CF3823001LL,0UL,0x8FC8B6378AD99BECLL,0x9C304FC5AA24CD92LL},{0xC092AF1C663E3D23LL,0x2E9B854570E7755CLL,0x70C15E2EBB41607FLL,18446744073709551615UL},{18446744073709551615UL,6UL,0x3F0AF599B31D9651LL,0x1099CA6CC092AD09LL},{0xD09A1D47C1A6FAE4LL,1UL,1UL,0xDC4AD4557D250DC4LL},{0x0A2E592043527F11LL,8UL,18446744073709551612UL,0x4A93EA6612EBA501LL},{0UL,1UL,18446744073709551607UL,18446744073709551615UL},{1UL,0x0A2E592043527F11LL,0xAF731DEA822A13F4LL,0UL},{0x86DA7324913F3844LL,6UL,0xCF0BF8D7AA90586ALL,18446744073709551615UL}},{{6UL,0xC092AF1C663E3D23LL,18446744073709551615UL,0xC092AF1C663E3D23LL},{0x4A93EA6612EBA501LL,0x098A061C6B35FA6ELL,6UL,1UL},{0UL,18446744073709551615UL,0UL,1UL},{0xB2E98B9F422C1256LL,0x8E67548A45F05B7CLL,0xC092AF1C663E3D23LL,0x70C15E2EBB41607FLL},{0xB2E98B9F422C1256LL,2UL,0UL,1UL},{0UL,0x70C15E2EBB41607FLL,6UL,0xB2E98B9F422C1256LL},{0x4A93EA6612EBA501LL,0xAC0A8E07C4215410LL,18446744073709551615UL,0x3CF89A6863FE4A66LL},{6UL,0x4A93EA6612EBA501LL,0xCF0BF8D7AA90586ALL,0x021C8671AAF26530LL},{0x4FE71ECB5A77BA9ELL,0x5F980C227EF6B329LL,0xCAE1E06E333C7908LL,0xCA3AF74FAE9ECB3DLL},{18446744073709551615UL,0xAB1008F88BC085A9LL,0UL,0xDA88F8633B263DB0LL}},{{0x3CF89A6863FE4A66LL,0xD09A1D47C1A6FAE4LL,0xE452CCF3382A8A4CLL,0UL},{0UL,0x54A16DD1E50BF1B3LL,18446744073709551615UL,18446744073709551607UL},{0x87C61B194448D9C5LL,1UL,0x9D7531C25BCB08C4LL,0UL},{18446744073709551612UL,0x351347A0FA632206LL,0xAF731DEA822A13F4LL,18446744073709551615UL},{0x1099CA6CC092AD09LL,1UL,0x351347A0FA632206LL,6UL},{0xCA3AF74FAE9ECB3DLL,0xDC4AD4557D250DC4LL,0x1099CA6CC092AD09LL,0x87C61B194448D9C5LL},{8UL,0UL,1UL,0x6614A35CF3823001LL},{0xAC0A8E07C4215410LL,0x365E059D09EE9981LL,0x8FC8B6378AD99BECLL,0x54A16DD1E50BF1B3LL},{0xCAE1E06E333C7908LL,18446744073709551615UL,0UL,0UL},{1UL,1UL,0x9C304FC5AA24CD92LL,0UL}},{{0x3DCE5D57BD8EC8EALL,18446744073709551612UL,0xAC0A8E07C4215410LL,0x1099CA6CC092AD09LL},{0x351347A0FA632206LL,0xE452CCF3382A8A4CLL,1UL,0xAC0A8E07C4215410LL},{0x4C5D87691020C271LL,0xE452CCF3382A8A4CLL,0x365E059D09EE9981LL,0x1099CA6CC092AD09LL},{0xE452CCF3382A8A4CLL,18446744073709551612UL,0xD09A1D47C1A6FAE4LL,0UL},{0xCF0BF8D7AA90586ALL,1UL,0x3CF89A6863FE4A66LL,0UL},{18446744073709551608UL,18446744073709551615UL,6UL,0x54A16DD1E50BF1B3LL},{0x70C15E2EBB41607FLL,0x365E059D09EE9981LL,0xDC4AD4557D250DC4LL,0x6614A35CF3823001LL},{0x99BBC7428D11F3BFLL,0UL,18446744073709551615UL,0x87C61B194448D9C5LL},{0x8FC8B6378AD99BECLL,0xDC4AD4557D250DC4LL,0x18A1321D2AAC3F84LL,6UL},{0xAF731DEA822A13F4LL,1UL,0x0A2E592043527F11LL,18446744073709551615UL}}};
            int i, j, k;
            for (p_30 = 0; (p_30 <= 2); p_30 += 1)
            { /* block id: 417 */
                (*g_83) = (((p_33 == p_31) , ((safe_sub_func_int8_t_s_s(l_950[2][0], (safe_lshift_func_uint16_t_u_s(p_31, ((((((void*)0 != l_956) , ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((p_31 , (g_951 != (safe_mod_func_int8_t_s_s((g_136 > l_968[4][1][3]), l_932)))), (*g_703))), g_121)), 0)), 8)) && (-9L))) & g_515[1][5][6]) > (*g_703)) , 0xABA2L))))) <= (***g_652))) , (-1L));
            }
            return g_112;
        }
        else
        { /* block id: 421 */
            uint32_t l_969 = 4294967291UL;
            int32_t l_1008 = 0x1026BB32L;
            int32_t l_1009 = 0xF7D63653L;
            int32_t l_1010 = 4L;
            int32_t l_1042[2][2][7] = {{{(-1L),8L,0xF012822CL,0x127D6076L,0xE64274BEL,1L,0xE64274BEL},{(-1L),0xE64274BEL,0xE64274BEL,(-1L),8L,(-5L),0x0C4AB606L}},{{0L,(-5L),0xF012822CL,8L,8L,0xF012822CL,(-5L)},{8L,0L,1L,8L,0xE64274BEL,0x0C4AB606L,0x0C4AB606L}}};
            int16_t *l_1079[1][3][6] = {{{&g_240,&g_240,&g_240,&g_240,&g_240,&g_240},{&g_240,&g_240,&g_240,&g_240,&g_240,&g_240},{&g_240,&g_240,&g_240,&g_240,&g_240,&g_240}}};
            int16_t ** const l_1078 = &l_1079[0][0][2];
            int16_t ** const *l_1077[2];
            int32_t *l_1195 = &l_1043;
            int64_t l_1202 = 0xCA3336D822E43B1DLL;
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_1077[i] = &l_1078;
            l_969--;
            for (p_32 = 0; (p_32 >= (-16)); p_32 = safe_sub_func_uint32_t_u_u(p_32, 5))
            { /* block id: 425 */
                const uint32_t l_1003 = 1UL;
                int32_t l_1006 = 1L;
                int32_t l_1011 = 4L;
                int32_t l_1044[8];
                uint64_t **l_1159[8][9] = {{&l_940,&l_1031[1],&l_943,(void*)0,&l_1031[1],(void*)0,&l_943,&l_1031[1],&l_940},{(void*)0,&l_1031[1],&l_943,&l_1031[1],&l_1031[4],&l_1031[0],&l_1031[4],&l_1031[1],&l_943},{&l_1031[1],&l_1031[1],&l_940,&l_940,&l_1031[1],&l_943,&l_940,&l_943,&l_1031[1]},{&l_1031[4],&l_940,&l_940,&l_1031[4],&l_1031[1],&l_1031[0],&l_1031[1],&l_940,&l_1031[1]},{&l_940,&l_940,&l_1031[1],&l_1031[1],&l_940,&l_940,&l_1031[1],(void*)0,&l_940},{(void*)0,&l_1031[0],&l_940,&l_1031[1],&l_1031[1],&l_940,&l_1031[0],(void*)0,(void*)0},{&l_940,&l_1031[1],(void*)0,&l_1031[1],&l_1031[1],&l_1031[1],&l_1031[1],(void*)0,&l_1031[1]},{&l_1031[1],(void*)0,&l_943,(void*)0,&l_940,&l_1031[1],&l_1031[1],&l_940,(void*)0}};
                uint64_t l_1177 = 5UL;
                int8_t *l_1187 = &g_977;
                int32_t *l_1220 = &l_1205;
                int i, j;
                for (i = 0; i < 8; i++)
                    l_1044[i] = 0x96454077L;
                for (g_836 = 0; (g_836 <= (-26)); g_836 = safe_sub_func_int8_t_s_s(g_836, 9))
                { /* block id: 428 */
                    int16_t l_976[9][5] = {{(-10L),7L,(-10L),(-10L),7L},{0xD0C4L,(-2L),(-2L),0xD0C4L,(-2L)},{7L,7L,(-2L),7L,7L},{(-2L),0xD0C4L,(-2L),(-2L),0xD0C4L},{7L,(-10L),(-10L),7L,(-10L)},{0xD0C4L,0xD0C4L,(-7L),0xD0C4L,0xD0C4L},{(-10L),7L,(-10L),(-10L),7L},{0xD0C4L,(-2L),(-2L),0xD0C4L,(-2L)},{7L,7L,(-2L),7L,7L}};
                    int i, j;
                    (*g_83) ^= l_976[3][2];
                }
                if (l_969)
                { /* block id: 431 */
                    return g_977;
                }
                else
                { /* block id: 433 */
                    uint8_t l_1007 = 0UL;
                    int32_t l_1012[4][6] = {{0x0FE84BE4L,0L,8L,8L,0L,0x0FE84BE4L},{0xED6F2918L,0x0FE84BE4L,8L,0x0FE84BE4L,0xED6F2918L,0xED6F2918L},{(-3L),0x0FE84BE4L,0x0FE84BE4L,(-3L),0L,(-3L)},{(-3L),0L,(-3L),0x0FE84BE4L,0x0FE84BE4L,(-3L)}};
                    uint64_t *l_1032[7];
                    int16_t l_1041[6][7][2] = {{{0x0562L,2L},{0x758EL,0xE9D1L},{0x6CB4L,0x0562L},{(-9L),0x6CB4L},{0x883EL,0x9251L},{0x883EL,0x6CB4L},{(-9L),0x0562L}},{{0x6CB4L,0xE9D1L},{0x758EL,2L},{0x0562L,0xC30DL},{0xC30DL,0xC30DL},{0x0562L,2L},{0x758EL,0xE9D1L},{0x6CB4L,0x0562L}},{{(-9L),0x6CB4L},{0x883EL,0x9251L},{0x883EL,0x6CB4L},{(-9L),0x0562L},{0x6CB4L,0xE9D1L},{0x758EL,2L},{0x0562L,0xC30DL}},{{0xC30DL,0xC30DL},{0x0562L,2L},{0x758EL,0xE9D1L},{0x6CB4L,0x0562L},{(-9L),0x6CB4L},{0x883EL,0x9251L},{0x883EL,0x6CB4L}},{{(-9L),0x0562L},{0x6CB4L,0xE9D1L},{0x758EL,2L},{0x0562L,0xC30DL},{0xC30DL,0xC30DL},{0x0562L,2L},{0x758EL,0xE9D1L}},{{0x6CB4L,0x0562L},{0x758EL,0x9251L},{2L,(-7L)},{2L,0x9251L},{0x758EL,0xC30DL},{0x9251L,(-9L)},{0x883EL,0x0562L}}};
                    int i, j, k;
                    for (i = 0; i < 7; i++)
                        l_1032[i] = &g_93;
                    for (g_493 = 2; (g_493 >= 0); g_493 -= 1)
                    { /* block id: 436 */
                        uint16_t l_992 = 0xAF0EL;
                        uint32_t *l_1000 = &g_369;
                        int16_t * const ****l_1001 = &g_832[4];
                        int32_t *l_1004 = (void*)0;
                        int32_t *l_1005[4][6] = {{&g_40,&g_40,&g_40,&g_40,&g_40,&g_40},{&g_40,&g_40,&g_40,&g_40,&g_40,&g_40},{&g_40,&g_40,&g_40,&g_40,&g_40,&g_40},{&g_40,&g_40,&g_40,&g_40,&g_40,&g_40}};
                        int i, j;
                        l_1007 ^= (l_1006 = (((safe_lshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_s(g_164, 4)) & ((safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_u(((((safe_lshift_func_int16_t_s_u(((l_950[2][0] >= (safe_add_func_uint32_t_u_u((((p_32 & ((*l_940) = ((g_515[0][3][5] , p_30) & (l_992 &= 252UL)))) , ((((safe_add_func_int16_t_s_s((((safe_div_func_uint8_t_u_u((*g_703), (safe_rshift_func_uint16_t_u_s((safe_unary_minus_func_uint32_t_u(((*l_1000) = 4294967286UL))), (((*g_83) = (l_1001 == &g_832[3])) < g_134))))) & l_1002) , 0L), p_32)) == 0x374C85C3L) > l_1003) , p_31)) || p_32), 0UL))) < g_977), l_950[2][0])) | l_932) && p_32) ^ (-1L)), 13)), (*g_835))) != l_950[2][0])), l_950[2][0])) < l_950[0][0]) | 1L));
                        ++l_1013;
                    }
                    for (g_369 = (-30); (g_369 > 48); g_369++)
                    { /* block id: 447 */
                        int32_t *l_1033 = &g_40;
                        int32_t *l_1034 = (void*)0;
                        int32_t *l_1035 = &l_1008;
                        int32_t *l_1036 = &l_1012[2][4];
                        int32_t *l_1037 = &l_1010;
                        int32_t *l_1038 = &l_950[2][0];
                        int32_t *l_1039 = (void*)0;
                        int32_t *l_1040[1];
                        uint32_t l_1046 = 0x3755296EL;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1040[i] = &g_40;
                        (*g_83) = ((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(p_30, (safe_div_func_uint64_t_u_u(0x78D9BC1A4CFE079ALL, 0x73C2886249ABD22BLL)))), (0x4667L | (~0x3AL)))), 7)) != (1L > (safe_add_func_int64_t_s_s((((safe_rshift_func_int8_t_s_s(p_30, 4)) , ((((l_1031[1] == l_1032[3]) | (*g_514)) != p_30) == p_30)) || (*g_703)), 1L))));
                        if ((**g_738))
                            continue;
                        l_1046--;
                    }
                }
                if (p_31)
                { /* block id: 453 */
                    uint32_t *l_1050 = &g_121;
                    (*g_83) &= (safe_unary_minus_func_uint16_t_u(((++(*l_1050)) | l_1011)));
                }
                else
                { /* block id: 456 */
                    int8_t *l_1053 = &g_36[1];
                    int16_t ** const l_1081 = (void*)0;
                    int16_t ** const *l_1080 = &l_1081;
                    int32_t l_1099 = (-1L);
                    if (l_1008)
                        break;
                    (*g_1056) = func_54(l_1053, (*g_449), p_30);
                    for (g_369 = 0; (g_369 <= 0); g_369 += 1)
                    { /* block id: 461 */
                        int16_t ***l_1065 = &g_238;
                        int16_t *l_1071 = &g_836;
                        int16_t ** const l_1070 = &l_1071;
                        int16_t ** const *l_1069[7] = {&l_1070,&l_1070,&l_1070,&l_1070,&l_1070,&l_1070,&l_1070};
                        int16_t ** const **l_1068 = &l_1069[5];
                        int16_t ** const *l_1073 = &l_1070;
                        int16_t ** const **l_1072[3][2][3] = {{{&l_1073,&l_1073,&l_1073},{&l_1073,&l_1073,&l_1073}},{{&l_1073,(void*)0,&l_1073},{&l_1073,(void*)0,&l_1073}},{{&l_1073,&l_1073,&l_1073},{&l_1073,&l_1073,&l_1073}}};
                        int i, j, k;
                        l_1044[(g_369 + 6)] = ((l_1044[(g_369 + 4)] == (0x04C4L > ((1L < ((((safe_lshift_func_int16_t_s_u((safe_mod_func_uint16_t_u_u(((*l_957) = (((*l_927) = l_1065) == (l_1080 = (l_1077[1] = (l_1074 = ((*l_1068) = (((l_950[(g_369 + 2)][g_369] | (safe_mul_func_int16_t_s_s((-1L), 0xCCEAL))) , l_950[0][0]) , (void*)0))))))), (-6L))), l_950[2][0])) < p_30) && p_31) >= g_40)) < l_1045))) && g_977);
                    }
                    if ((safe_add_func_uint32_t_u_u(((g_463[0][7] > (safe_unary_minus_func_int16_t_s(3L))) == (g_463[0][7] || ((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((**g_238), ((p_31 | ((safe_lshift_func_int8_t_s_s((0xEDL <= ((safe_mul_func_int8_t_s_s(p_33, (safe_mod_func_int64_t_s_s((0x4FL < ((safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_u(((*l_1053) = 0xF3L), 7)), (***g_652))) , 7UL)), 0xB6C61690099DDFCDLL)))) >= p_33)), g_494)) , p_30)) , l_1045))), p_32)) & l_1044[2]))), l_1099)))
                    { /* block id: 471 */
                        int64_t *l_1121 = &g_951;
                        int32_t l_1124 = 1L;
                        int8_t *l_1125 = &g_60;
                        (*g_83) |= (**g_386);
                        (*g_83) = (safe_sub_func_uint64_t_u_u(((safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(((*l_957) |= (safe_add_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u((((*l_1125) = (((*l_1053) |= ((((+((((l_1124 = (!(((safe_div_func_int64_t_s_s(p_30, (safe_div_func_int16_t_s_s((((*l_1121) = (!(((&l_1077[1] != ((*l_928) = &g_652)) , &g_60) != (void*)0))) | g_121), l_1003)))) >= (((*g_703) != (safe_add_func_uint16_t_u_u(1UL, l_950[2][0]))) , p_30)) & p_33))) == g_412) < l_950[2][0]) < p_33)) , g_412) < 0x9E1090D510751E98LL) != p_30)) & l_1044[2])) <= l_1013), p_31)) , 2UL) , g_72), l_1099))), 2)) , p_33), p_33)), 1)), 1L)) < p_32), l_1010));
                    }
                    else
                    { /* block id: 480 */
                        int64_t * const l_1144 = &g_951;
                        int32_t l_1145 = 1L;
                        int8_t *l_1146 = &g_977;
                        if (l_1099)
                            break;
                        (*g_83) = (safe_unary_minus_func_int8_t_s(((safe_unary_minus_func_int32_t_s((safe_sub_func_int8_t_s_s(l_1009, ((safe_sub_func_int32_t_s_s((((*l_1146) = ((safe_lshift_func_int8_t_s_u(((*l_1053) = g_121), ((void*)0 == &g_977))) <= ((safe_lshift_func_int16_t_s_u((l_1044[4] ^= (((~(g_40 ^ (l_932 , ((*g_514) , (l_950[3][0] >= (+(safe_mul_func_uint16_t_u_u((((((safe_sub_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((((*g_239) || 1L) & g_593), p_32)), 0L)) > 18446744073709551606UL) >= (*g_703)) , l_1144) == &g_166), l_1099)))))))) & (*g_703)) > l_1145)), 1)) , 0xB1B2L))) > 0x29L), 0L)) < l_1145))))) ^ 0xA319L)));
                    }
                }
                if (p_31)
                { /* block id: 488 */
                    for (g_60 = 4; (g_60 >= 27); g_60 = safe_add_func_int16_t_s_s(g_60, 9))
                    { /* block id: 491 */
                        uint16_t **l_1149 = &l_957;
                        uint32_t *l_1152 = &g_369;
                        uint64_t ***l_1160 = &l_941;
                        uint64_t ***l_1163 = &l_942;
                        (*g_1150) = l_1149;
                        if (p_33)
                            break;
                        (*g_83) = (+((((*l_1152)++) > (((safe_add_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((((*l_1160) = l_1159[6][5]) != ((*l_1163) = g_1161)), 1)), (l_1042[0][0][3] && g_121))) < (safe_mul_func_uint8_t_u_u(((*g_703)--), (safe_div_func_int8_t_s_s((+(safe_rshift_func_uint16_t_u_s(p_31, 7))), (safe_add_func_int16_t_s_s((p_33 = ((**l_1078) &= (safe_rshift_func_uint16_t_u_s(l_1177, (safe_sub_func_int16_t_s_s(0xE2FFL, ((((p_30 <= p_30) | 0xD6FBA6030652A356LL) | (**g_1161)) < g_977))))))), 0x10F6L))))))) <= (***g_1150))) > 4294967295UL));
                    }
                }
                else
                { /* block id: 502 */
                    const int32_t *l_1188 = &g_72;
                    int16_t * const **l_1191 = &g_834[2][4][0];
                    int32_t l_1203[9][8][2] = {{{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L}},{{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L}},{{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L}},{{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L}},{{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L}},{{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L},{0x8BBB58F9L,0x47EF6C05L}},{{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L},{0x3F61540DL,0xA5D70FC1L}},{{0x8BBB58F9L,0x47EF6C05L},{0x8EA441A7L,0x8EA441A7L},{0x3F61540DL,0x8EA441A7L},{0x8EA441A7L,0x47EF6C05L},{0x8BBB58F9L,0xA5D70FC1L},{0x3F61540DL,0x8BBB58F9L},{0xA5D70FC1L,0x47EF6C05L},{0xA5D70FC1L,0x8BBB58F9L}},{{0x3F61540DL,0xA5D70FC1L},{0x47EF6C05L,0xEA639BFAL},{0x3F61540DL,0x3F61540DL},{0x1D4BFBF1L,0x3F61540DL},{0x3F61540DL,0xEA639BFAL},{0x47EF6C05L,(-1L)},{0x1D4BFBF1L,0x47EF6C05L},{(-1L),0xEA639BFAL}}};
                    uint16_t **l_1215 = (void*)0;
                    int i, j, k;
                    for (g_72 = 0; (g_72 == 24); g_72++)
                    { /* block id: 505 */
                        if (p_33)
                            break;
                        if (p_33)
                            break;
                    }
                    if (((safe_add_func_int16_t_s_s((((-1L) & (-1L)) <= (&l_950[2][0] != (l_1195 = func_54(((p_30 > (!l_1013)) , l_1187), l_1188, ((((safe_mul_func_uint16_t_u_u(((((((l_1192 = l_1191) == (void*)0) != 0x7CFCL) == (-1L)) , (*g_703)) > g_1193), l_1194)) | p_33) & l_1011) , p_31))))), (*g_239))) <= p_33))
                    { /* block id: 511 */
                        int32_t *l_1196 = &l_1042[0][0][6];
                        int32_t *l_1197 = &l_1011;
                        int32_t *l_1198 = &l_1011;
                        int32_t *l_1199 = &l_1043;
                        int32_t *l_1200[8] = {&g_40,&g_40,&l_1042[0][0][1],&g_40,&g_40,&l_1042[0][0][1],&g_40,&g_40};
                        int64_t l_1201 = 0x3F78BB55F29BE8ACLL;
                        int8_t *l_1210[7] = {&g_36[4],&g_60,&g_36[4],&g_36[4],&g_60,&g_36[4],&g_36[4]};
                        uint32_t *l_1211 = &g_121;
                        int32_t **l_1216 = &l_1200[1];
                        int32_t **l_1217 = (void*)0;
                        int32_t **l_1218 = (void*)0;
                        int32_t **l_1219[7][7][4] = {{{&g_83,&l_1198,&l_1196,&l_1199},{&g_83,&l_1195,&l_1195,&l_1199},{(void*)0,&l_1198,&l_1199,&l_1195},{&l_1198,&g_83,&l_1196,&g_83},{&l_1198,&g_83,&l_1195,&g_84},{&l_1196,&g_83,&g_83,&l_1196},{&g_83,&g_83,&g_83,&l_1198}},{{&g_83,(void*)0,&g_83,&l_1199},{&l_1196,&l_1198,&l_1195,&l_1195},{&l_1198,&l_1198,&l_1196,&l_1198},{&l_1198,&l_1196,&l_1199,&g_83},{(void*)0,&g_83,&l_1195,&l_1199},{&g_83,&g_83,&l_1196,&g_83},{&g_83,&l_1196,(void*)0,&l_1198}},{{&g_83,&l_1198,&g_83,&l_1195},{&g_83,&l_1198,(void*)0,&l_1199},{&l_1198,(void*)0,&l_1199,&l_1198},{&l_1195,&g_83,&l_1199,&l_1196},{&l_1198,&g_83,(void*)0,&g_84},{&g_83,&g_83,&g_83,&g_83},{&g_83,&g_83,(void*)0,&l_1195}},{{&g_83,&l_1198,&l_1196,&l_1199},{&g_83,&l_1195,&l_1195,&l_1199},{(void*)0,&l_1198,&l_1199,&l_1195},{&l_1198,&g_83,&l_1196,&g_83},{&l_1198,&g_83,&l_1195,&g_84},{&l_1196,&g_83,&g_83,&l_1196},{&g_83,&g_83,&g_83,&l_1198}},{{&g_83,(void*)0,&g_83,&l_1199},{&l_1196,&l_1198,&l_1195,&l_1195},{&l_1198,&l_1198,&l_1196,&l_1198},{&l_1198,&l_1196,&l_1199,&g_83},{(void*)0,&g_83,&l_1195,&l_1199},{&g_83,&g_83,&l_1196,&g_83},{&g_83,&l_1196,(void*)0,&l_1198}},{{&g_83,&l_1198,&g_83,&l_1195},{&g_83,&l_1198,(void*)0,&l_1199},{&l_1198,(void*)0,&l_1199,&l_1198},{&l_1195,&g_83,&l_1199,&l_1196},{&l_1198,&g_83,(void*)0,&g_84},{&g_83,&g_83,&l_1199,&g_83},{&l_1199,&g_83,(void*)0,(void*)0}},{{&l_1195,(void*)0,&l_1198,&l_1199},{&g_83,(void*)0,&l_1196,&l_1199},{(void*)0,(void*)0,&g_83,(void*)0},{&l_1195,&g_83,&l_1198,&g_83},{(void*)0,&l_1199,&l_1196,(void*)0},{&l_1196,&l_1195,&l_1199,&l_1196},{&l_1195,&g_83,&l_1197,&l_1195}}};
                        int i, j, k;
                        l_1207++;
                        l_1221 = (l_1220 = ((*l_1216) = func_54(l_1210[6], func_54((((*l_1211)++) , l_949[0][1][0]), func_54(l_1187, ((!(l_1215 == (void*)0)) , func_54(l_1187, &l_950[2][0], ((*g_703) |= p_32))), p_30), p_32), p_33)));
                        (*l_1221) = (-4L);
                    }
                    else
                    { /* block id: 519 */
                        uint8_t ***l_1223 = &l_1222;
                        uint8_t **l_1225 = &l_949[1][0][1];
                        uint8_t ***l_1224 = &l_1225;
                        (*l_1220) = (((*l_1223) = l_1222) == ((*l_1224) = &g_703));
                    }
                }
            }
        }
        l_950[0][0] &= l_1045;
        g_1230++;
    }
    else
    { /* block id: 529 */
        uint16_t l_1233 = 7UL;
        int32_t l_1238[4][6];
        int16_t ***l_1245[10][3][8] = {{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}},{{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238},{&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238,&g_238}}};
        uint8_t **l_1258 = &g_703;
        int32_t l_1267 = (-1L);
        int i, j, k;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 6; j++)
                l_1238[i][j] = 0x002003C6L;
        }
        (*g_83) &= ((p_30 >= g_164) | 0xB58D7193L);
        (*g_83) |= ((((p_31 , (&g_493 != (void*)0)) & (l_1238[1][2] ^= ((l_1233 < p_32) || ((+(+(safe_div_func_uint64_t_u_u(l_1233, (l_1233 || p_32))))) <= l_1233)))) >= 0x3908D01BL) != (*g_514));
        if (((*g_83) = 0x2D272EF8L))
        { /* block id: 534 */
            int32_t l_1264 = (-9L);
            for (g_93 = 0; (g_93 > 17); ++g_93)
            { /* block id: 537 */
                int32_t *l_1261 = (void*)0;
                int32_t *l_1262 = &g_1263;
                int64_t *l_1266 = &g_166;
                int32_t *l_1268 = &l_1204;
                int32_t *l_1269 = &g_40;
                int32_t *l_1270 = &l_1204;
                int32_t *l_1271 = (void*)0;
                int32_t *l_1272 = &l_932;
                int32_t l_1273[1];
                int32_t *l_1274 = &g_72;
                int32_t *l_1275 = &l_932;
                int32_t *l_1276 = (void*)0;
                int32_t *l_1277 = &l_1238[2][2];
                int32_t *l_1278 = &l_1238[2][2];
                int32_t *l_1279 = &l_1045;
                int32_t *l_1280 = &l_1273[0];
                int32_t *l_1281 = &l_1238[3][3];
                int32_t *l_1282 = &g_72;
                int32_t *l_1283[7][1][10] = {{{&l_1273[0],&l_1273[0],&l_1238[1][2],(void*)0,&l_1238[2][1],&l_1238[1][2],&l_1043,&l_1205,&l_1273[0],&l_1205}},{{&l_1264,&l_1264,&l_1238[2][1],&l_1206,&g_494,&l_1238[1][2],&l_1238[1][2],&g_494,&l_1206,&l_1238[2][1]}},{{&l_1273[0],&l_1273[0],(void*)0,&g_494,&l_1043,&l_1238[3][1],(void*)0,&l_1273[0],&g_494,(void*)0}},{{&l_1264,&l_1264,&l_1238[1][2],&l_1205,&l_1264,&l_1206,(void*)0,&l_1206,&l_1264,&l_1205}},{{&l_1273[0],&l_1273[0],&l_1273[0],&l_1238[1][2],(void*)0,&l_1238[2][1],&l_1238[1][2],&l_1043,&l_1205,&l_1273[0]}},{{&l_1043,&l_1264,&g_494,&g_494,&l_1273[0],(void*)0,&l_1043,&l_1043,(void*)0,&l_1273[0]}},{{&l_1264,&l_1273[0],&l_1273[0],&l_1264,&l_1205,&l_1264,&l_1273[0],&l_1206,&l_1273[0],&l_1043}}};
                uint64_t l_1336 = 0xBF4FB22F792CD452LL;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_1273[i] = (-1L);
                l_1267 &= ((safe_mul_func_int8_t_s_s(((((g_72 , (safe_rshift_func_int16_t_s_u(((void*)0 == l_1245[9][1][2]), 13))) , ((safe_rshift_func_uint16_t_u_s((safe_mod_func_uint8_t_u_u(p_32, p_31)), ((p_32 > (+(safe_mod_func_int32_t_s_s((((((*g_1162) == ((*l_1266) = (g_493 = ((g_1265 = (!(safe_sub_func_int32_t_s_s((safe_div_func_int32_t_s_s(((l_1258 == (((((*l_1262) = ((((safe_sub_func_int16_t_s_s((g_112 != 18446744073709551615UL), 0x0BCFL)) > 0UL) ^ l_1238[1][3]) <= 0x19097DE5L)) , l_1238[1][2]) > l_1264) , &g_703)) & 5UL), l_1264)), 0x8C8843F1L)))) , p_33)))) || g_93) > p_33) , p_31), 0x69838C49L)))) && p_33))) > l_1264)) < (*g_514)) > 65535UL), p_33)) , 0x38B71D70L);
                ++l_1284;
                for (g_412 = 0; (g_412 <= 17); g_412 = safe_add_func_int8_t_s_s(g_412, 1))
                { /* block id: 546 */
                    uint16_t l_1303 = 65532UL;
                    int16_t ***l_1309[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1309[i] = &g_238;
                    (*l_1278) = (0x14ECCE5BA0B859BBLL == ((safe_lshift_func_int16_t_s_s(((((((*l_1272) = (g_593 , ((safe_div_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u((p_32 & (safe_rshift_func_int16_t_s_s((((**l_1258)--) , 0xEFBFL), ((((p_31 == ((g_121 , ((safe_lshift_func_uint8_t_u_s((safe_mod_func_int64_t_s_s(l_1303, 1L)), 5)) != ((!((((safe_rshift_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(((((65535UL | l_1303) <= p_33) & 0x29L) | 0x70L), p_30)), 13)) & 0xB588L) || 0x72D38DD4L) && 0x44DF8175276A6B09LL)) < (**g_815)))) | g_121)) , l_1309[1]) == l_1309[0]) & p_32)))), 12)), p_32)) && l_1310))) , l_1264) , l_1303) <= 9UL) || 1UL), 13)) || 0x3386F1C4L));
                    (*l_1279) |= ((safe_rshift_func_int16_t_s_s(((safe_sub_func_int16_t_s_s(((l_1303 , ((*l_1269) = (((safe_div_func_uint8_t_u_u((safe_add_func_int32_t_s_s(((*g_83) = p_32), (safe_rshift_func_int16_t_s_u(((safe_unary_minus_func_uint64_t_u(((safe_div_func_int32_t_s_s((safe_sub_func_uint64_t_u_u((*l_1280), (safe_mod_func_int8_t_s_s((g_593 || 0x71BEF6136D6AF100LL), (safe_lshift_func_uint16_t_u_u(0x9A72L, (safe_div_func_uint32_t_u_u(((((((*l_1277) = (p_32 < (0x78L >= (safe_rshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_u(p_33, (*g_703))), 3))))) && p_32) > 0xA4B8L) & g_1263) == (***g_652)), l_1336)))))))), p_30)) ^ (*l_1275)))) > g_463[0][7]), l_1337)))), (*g_703))) , 2L) , p_30))) && (*l_1274)), l_1264)) <= 0xE594L), 15)) ^ l_1303);
                }
            }
        }
        else
        { /* block id: 556 */
            return l_1238[1][0];
        }
        for (l_1205 = (-9); (l_1205 == 20); ++l_1205)
        { /* block id: 561 */
            uint16_t l_1378 = 65535UL;
            for (l_1206 = 0; (l_1206 != (-2)); --l_1206)
            { /* block id: 564 */
                int32_t l_1362 = 0x153AEF3EL;
                for (g_60 = 4; (g_60 >= (-13)); g_60 = safe_sub_func_int16_t_s_s(g_60, 7))
                { /* block id: 567 */
                    uint16_t *l_1363 = (void*)0;
                    uint16_t *l_1364 = (void*)0;
                    uint16_t *l_1365 = &g_134;
                    int8_t *l_1379 = &g_977;
                    int32_t *l_1380 = &l_1238[1][2];
                    (*l_1380) ^= (((*g_239) ^= p_32) >= (safe_lshift_func_int8_t_s_u(((*l_1379) = (safe_lshift_func_uint16_t_u_s(((safe_mod_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(((safe_sub_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s(0x1F62L, (safe_sub_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(0x913CL, ((safe_div_func_int64_t_s_s((((*g_83) |= l_1362) , (((*l_1365)--) >= (safe_mul_func_int8_t_s_s(0x73L, (safe_add_func_uint64_t_u_u(((void*)0 != &l_1284), (safe_sub_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u(p_32, (safe_mul_func_uint8_t_u_u(p_30, p_31)))) && 1L), 1UL)))))))), 4UL)) >= p_33))) > g_1230), p_33)))), p_33)) , l_1378), 10)), p_32)) || p_30), 13))), l_1378)));
                }
            }
            return g_593;
        }
    }
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_121 g_36
 * writes: g_121
 */
static int8_t  func_42(uint32_t  p_43)
{ /* block id: 399 */
    int64_t l_898 = (-3L);
    int32_t l_909 = 0xE569ECA1L;
    int32_t l_910 = 0xAF4665F2L;
    int16_t l_911[2][3];
    int32_t l_912 = 6L;
    int32_t l_913 = (-2L);
    int32_t l_914 = 0x1B6362D4L;
    int32_t l_915 = (-2L);
    int32_t l_916 = 0xA408FE74L;
    int32_t l_917 = 0x9FF591B5L;
    int32_t l_918 = 0xEE4DA94DL;
    int32_t l_919[10] = {0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL,0xA9C8BC9FL};
    uint64_t l_920[8] = {3UL,3UL,3UL,3UL,3UL,3UL,3UL,3UL};
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
            l_911[i][j] = 0xAF4CL;
    }
    for (g_121 = 0; (g_121 <= 7); g_121 += 1)
    { /* block id: 402 */
        int32_t *l_897 = &g_494;
        int32_t *l_899 = &g_494;
        int32_t *l_900 = (void*)0;
        int32_t *l_901 = &g_40;
        int32_t l_902 = 0x6079A927L;
        int32_t *l_903 = &l_902;
        int32_t *l_904 = &g_72;
        int32_t *l_905 = &g_40;
        int32_t *l_906 = &g_40;
        int32_t l_907 = (-1L);
        int32_t *l_908[1][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
        int i, j;
        l_920[5]--;
        return g_36[g_121];
    }
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_121 g_835 g_836 g_136 g_240 g_166 g_93 g_515 g_896 g_514
 * writes: g_121 g_93 g_369 g_84
 */
static uint8_t  func_49(int32_t * p_50, const int32_t * p_51, int8_t * p_52, int32_t * p_53)
{ /* block id: 388 */
    uint16_t l_885[3][10][8] = {{{65532UL,65526UL,65526UL,65532UL,0x029BL,0xA68CL,3UL,6UL},{65535UL,0UL,65534UL,0x029BL,1UL,65535UL,0x3A2FL,3UL},{65532UL,3UL,0x029BL,0x3A2FL,1UL,0UL,0xA68CL,0xA68CL},{0x029BL,65532UL,65526UL,65526UL,65532UL,0x029BL,0xA68CL,3UL},{65534UL,65526UL,0x029BL,0UL,0x3A2FL,9UL,0x3A2FL,0UL},{0x3A2FL,9UL,0x3A2FL,0UL,0x029BL,65526UL,65534UL,3UL},{0xA68CL,0x029BL,65532UL,65526UL,65526UL,65532UL,0x029BL,0xA68CL},{0xA68CL,0UL,1UL,0x3A2FL,0x029BL,3UL,65532UL,3UL},{0x3A2FL,65535UL,3UL,65535UL,0x3A2FL,3UL,9UL,0x029BL},{65534UL,0UL,65535UL,6UL,65532UL,65532UL,6UL,65535UL}},{{0x029BL,0x029BL,65535UL,0xA68CL,1UL,65526UL,9UL,65534UL},{65532UL,9UL,3UL,0x029BL,3UL,9UL,65532UL,65534UL},{9UL,65526UL,1UL,0xA68CL,65535UL,0x029BL,0x029BL,65535UL},{6UL,65532UL,65532UL,6UL,65535UL,0UL,65534UL,0x029BL},{9UL,3UL,0x3A2FL,65535UL,3UL,65535UL,0x3A2FL,3UL},{65532UL,3UL,0x029BL,0x3A2FL,1UL,0UL,0xA68CL,0xA68CL},{0x029BL,65532UL,65526UL,65526UL,65532UL,0x029BL,0xA68CL,3UL},{65534UL,65526UL,0x029BL,0UL,0x3A2FL,9UL,0x3A2FL,0UL},{0x3A2FL,9UL,0x3A2FL,0UL,0x029BL,65526UL,65534UL,3UL},{0xA68CL,0x029BL,65532UL,65526UL,65526UL,65532UL,0x029BL,0xA68CL}},{{0xA68CL,0UL,1UL,0x3A2FL,0x029BL,3UL,65532UL,3UL},{0x3A2FL,65535UL,3UL,65535UL,0x3A2FL,3UL,9UL,0x029BL},{65534UL,0UL,65535UL,6UL,65532UL,65532UL,6UL,65535UL},{0x029BL,0x029BL,65535UL,0xA68CL,1UL,65526UL,9UL,65534UL},{65532UL,9UL,3UL,0x029BL,3UL,9UL,65532UL,65534UL},{9UL,65526UL,1UL,0UL,9UL,65535UL,65535UL,9UL},{0x029BL,6UL,6UL,0x029BL,9UL,3UL,0x3A2FL,65535UL},{0xA68CL,1UL,65526UL,9UL,65534UL,9UL,65526UL,1UL},{6UL,1UL,65535UL,65526UL,3UL,3UL,0UL,0UL},{65535UL,6UL,65532UL,65532UL,6UL,65535UL,0UL,65534UL}}};
    const int32_t *l_893[7][5][6] = {{{&g_494,&g_494,(void*)0,&g_40,&g_72,&g_72},{(void*)0,&g_494,&g_72,&g_40,&g_72,&g_40},{&g_40,&g_494,&g_40,&g_40,&g_494,&g_72},{&g_72,&g_72,&g_72,&g_72,&g_494,&g_494},{&g_40,&g_72,&g_40,&g_72,(void*)0,&g_40}},{{&g_72,(void*)0,(void*)0,&g_40,&g_72,&g_40},{&g_40,&g_72,&g_72,&g_40,&g_72,(void*)0},{(void*)0,(void*)0,&g_72,&g_40,(void*)0,&g_40},{&g_494,&g_494,(void*)0,&g_494,&g_494,&g_40},{&g_494,&g_494,&g_40,&g_72,&g_40,&g_494}},{{&g_72,&g_494,&g_72,&g_72,&g_494,&g_72},{&g_40,&g_494,&g_40,&g_72,(void*)0,&g_40},{&g_72,(void*)0,&g_72,(void*)0,&g_72,&g_72},{&g_72,&g_72,(void*)0,&g_72,&g_72,&g_72},{&g_40,(void*)0,&g_494,&g_72,(void*)0,&g_494}},{{&g_72,&g_72,&g_72,&g_72,&g_494,&g_494},{&g_494,&g_72,&g_494,&g_494,&g_494,&g_72},{&g_494,&g_494,(void*)0,&g_40,&g_72,&g_72},{(void*)0,&g_494,&g_72,&g_40,&g_72,&g_40},{&g_40,&g_494,&g_40,&g_40,&g_494,&g_72}},{{&g_72,&g_72,&g_72,&g_72,&g_494,&g_494},{&g_40,&g_72,&g_40,&g_72,(void*)0,&g_40},{&g_72,(void*)0,(void*)0,&g_40,&g_72,&g_40},{&g_40,&g_72,&g_72,&g_40,&g_72,(void*)0},{(void*)0,(void*)0,&g_72,&g_40,(void*)0,&g_40}},{{&g_494,&g_494,(void*)0,&g_494,&g_494,(void*)0},{&g_40,&g_494,(void*)0,&g_494,&g_72,&g_40},{(void*)0,&g_494,&g_40,&g_40,&g_494,(void*)0},{&g_494,&g_494,&g_72,(void*)0,(void*)0,(void*)0},{&g_40,&g_494,&g_494,&g_494,&g_72,&g_494}},{{&g_40,&g_72,&g_494,(void*)0,&g_40,&g_494},{&g_494,(void*)0,&g_494,&g_40,&g_72,&g_72},{(void*)0,&g_72,&g_494,&g_494,&g_40,&g_72},{&g_40,&g_72,&g_494,&g_40,(void*)0,&g_494},{&g_72,&g_40,&g_494,&g_494,&g_72,&g_494}}};
    int i, j, k;
    for (g_121 = 0; (g_121 <= 34); g_121 = safe_add_func_uint8_t_u_u(g_121, 8))
    { /* block id: 391 */
        uint64_t *l_888 = &g_93;
        int32_t l_891 = 0L;
        uint32_t *l_892 = &g_369;
        int8_t l_894 = 0xBFL;
        int32_t *l_895 = &g_72;
        (*g_896) = (((l_885[2][0][4] & (l_885[2][0][4] , (*g_835))) | g_136) , (l_895 = func_54(((safe_rshift_func_int8_t_s_u(g_240, ((-1L) >= ((((*l_892) = (0x9BL != (((*l_888) |= g_166) || (safe_mod_func_uint8_t_u_u((((l_891 <= l_891) != g_240) | g_515[0][2][8]), l_885[2][0][4]))))) >= l_891) || 0x32EBE38EL)))) , (void*)0), l_893[5][4][1], l_894)));
    }
    return (*g_514);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_54(int8_t * p_55, const int32_t * p_56, uint8_t  p_57)
{ /* block id: 2 */
    int16_t l_58 = 0xE40CL;
    int8_t *l_59[10] = {&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60};
    uint64_t l_70 = 0UL;
    int32_t l_74 = 0xE376A952L;
    int32_t *l_77 = &g_72;
    int32_t *l_79 = &g_72;
    int32_t **l_78 = &l_79;
    int32_t **l_80 = (void*)0;
    int32_t *l_82[5][8] = {{&g_40,(void*)0,(void*)0,&g_40,(void*)0,(void*)0,&g_40,&g_40},{(void*)0,&g_40,&g_40,&g_40,&g_40,(void*)0,&g_40,(void*)0},{&g_40,(void*)0,&g_40,(void*)0,&g_40,&g_40,&g_40,&g_40},{(void*)0,&g_40,&g_40,(void*)0,(void*)0,&g_40,(void*)0,(void*)0},{&g_40,(void*)0,&g_40,&g_40,&g_40,&g_40,&g_40,&g_40}};
    int32_t **l_81[8][2][4] = {{{&l_77,&l_77,(void*)0,&l_82[4][2]},{&l_77,&l_82[0][7],(void*)0,(void*)0}},{{&l_77,&l_77,&l_82[0][2],&l_82[3][0]},{&l_82[3][3],&l_77,(void*)0,&l_82[4][2]}},{{(void*)0,&l_82[4][2],&l_77,(void*)0},{&l_77,&l_82[4][2],&l_82[4][1],&l_82[4][2]}},{{&l_82[4][2],&l_77,(void*)0,&l_82[3][0]},{(void*)0,&l_77,&l_77,(void*)0}},{{&l_82[3][3],&l_82[0][7],&l_77,&l_82[4][2]},{&l_82[3][3],&l_77,&l_77,&l_82[3][3]}},{{(void*)0,&l_82[4][2],(void*)0,&l_77},{&l_82[4][2],&l_82[0][7],&l_82[4][1],&l_82[3][0]}},{{&l_77,(void*)0,&l_77,&l_82[3][0]},{(void*)0,&l_82[0][7],(void*)0,&l_77}},{{&l_82[3][3],&l_82[4][2],&l_82[0][2],&l_82[3][3]},{&l_77,&l_77,(void*)0,&l_82[4][2]}}};
    int32_t l_139 = 0x4726A7E7L;
    uint64_t l_234 = 0x309D12F06FB0A4E4LL;
    int16_t *l_236[10][7] = {{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{(void*)0,&l_58,&l_58,&l_58,(void*)0,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{(void*)0,&l_58,&l_58,&l_58,(void*)0,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{&l_58,&l_58,&l_58,&l_58,&l_58,&l_58,&l_58},{(void*)0,&l_58,&l_58,&l_58,(void*)0,&l_58,&l_58}};
    int16_t **l_235 = &l_236[5][6];
    int16_t l_371 = 0x968DL;
    int16_t l_452 = 0xF3F5L;
    const int16_t *l_467 = &g_463[0][2];
    const int16_t **l_466 = &l_467;
    const int16_t ***l_465[8][7][4] = {{{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466}},{{&l_466,&l_466,&l_466,(void*)0},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0}},{{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0},{&l_466,&l_466,&l_466,&l_466}},{{&l_466,&l_466,&l_466,(void*)0},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0}},{{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,(void*)0},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466}},{{&l_466,&l_466,(void*)0,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,(void*)0,&l_466,&l_466},{&l_466,(void*)0,(void*)0,&l_466}},{{(void*)0,&l_466,&l_466,&l_466},{&l_466,&l_466,(void*)0,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,&l_466,&l_466},{(void*)0,(void*)0,&l_466,(void*)0},{&l_466,&l_466,&l_466,&l_466}},{{&l_466,(void*)0,(void*)0,&l_466},{&l_466,&l_466,&l_466,&l_466},{(void*)0,&l_466,(void*)0,(void*)0},{&l_466,&l_466,&l_466,(void*)0},{&l_466,&l_466,&l_466,&l_466},{&l_466,&l_466,&l_466,&l_466},{&l_466,(void*)0,&l_466,&l_466}}};
    const int16_t ****l_464 = &l_465[2][6][0];
    int32_t l_596[7] = {0x832F8C57L,0x832F8C57L,0x832F8C57L,0x832F8C57L,0x832F8C57L,0x832F8C57L,0x832F8C57L};
    uint16_t l_714 = 0x9646L;
    int32_t *l_717 = &g_72;
    uint32_t l_721[3];
    uint16_t *l_767 = &g_134;
    uint16_t **l_766[1];
    int8_t l_784 = 0x3AL;
    uint8_t l_882 = 255UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_721[i] = 8UL;
    for (i = 0; i < 1; i++)
        l_766[i] = &l_767;
    return &g_72;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_166, "g_166", print_hash_value);
    transparent_crc(g_240, "g_240", print_hash_value);
    transparent_crc(g_369, "g_369", print_hash_value);
    transparent_crc(g_407, "g_407", print_hash_value);
    transparent_crc(g_412, "g_412", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_463[i][j], "g_463[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_493, "g_493", print_hash_value);
    transparent_crc(g_494, "g_494", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_515[i][j][k], "g_515[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_593, "g_593", print_hash_value);
    transparent_crc(g_836, "g_836", print_hash_value);
    transparent_crc(g_951, "g_951", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_1193, "g_1193", print_hash_value);
    transparent_crc(g_1230, "g_1230", print_hash_value);
    transparent_crc(g_1263, "g_1263", print_hash_value);
    transparent_crc(g_1265, "g_1265", print_hash_value);
    transparent_crc(g_1510, "g_1510", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1616[i], "g_1616[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1627, "g_1627", print_hash_value);
    transparent_crc(g_1710, "g_1710", print_hash_value);
    transparent_crc(g_1734, "g_1734", print_hash_value);
    transparent_crc(g_1751, "g_1751", print_hash_value);
    transparent_crc(g_1850, "g_1850", print_hash_value);
    transparent_crc(g_1881, "g_1881", print_hash_value);
    transparent_crc(g_2242, "g_2242", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2244[i][j][k], "g_2244[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2418, "g_2418", print_hash_value);
    transparent_crc(g_2488, "g_2488", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_2577[i][j], "g_2577[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 577
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 64
breakdown:
   depth: 1, occurrence: 189
   depth: 2, occurrence: 58
   depth: 3, occurrence: 6
   depth: 4, occurrence: 7
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 3
   depth: 12, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 3
   depth: 17, occurrence: 4
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 21, occurrence: 5
   depth: 22, occurrence: 3
   depth: 23, occurrence: 3
   depth: 24, occurrence: 2
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 29, occurrence: 2
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 2
   depth: 34, occurrence: 1
   depth: 36, occurrence: 4
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 59, occurrence: 1
   depth: 64, occurrence: 1

XXX total number of pointers: 452

XXX times a variable address is taken: 1326
XXX times a pointer is dereferenced on RHS: 300
breakdown:
   depth: 1, occurrence: 212
   depth: 2, occurrence: 66
   depth: 3, occurrence: 21
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 343
breakdown:
   depth: 1, occurrence: 312
   depth: 2, occurrence: 24
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
XXX times a pointer is compared with null: 51
XXX times a pointer is compared with address of another variable: 14
XXX times a pointer is compared with another pointer: 13
XXX times a pointer is qualified to be dereferenced: 8482

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1193
   level: 2, occurrence: 241
   level: 3, occurrence: 93
   level: 4, occurrence: 10
   level: 5, occurrence: 10
XXX number of pointers point to pointers: 197
XXX number of pointers point to scalars: 255
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 33.2
XXX average alias set size: 1.42

XXX times a non-volatile is read: 2090
XXX times a non-volatile is write: 1064
XXX times a volatile is read: 86
XXX    times read thru a pointer: 0
XXX times a volatile is write: 26
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.58e+03
XXX percentage of non-volatile access: 96.6

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 213
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 27
   depth: 2, occurrence: 34
   depth: 3, occurrence: 29
   depth: 4, occurrence: 44
   depth: 5, occurrence: 54

XXX percentage a fresh-made variable is used: 15.1
XXX percentage an existing variable is used: 84.9
********************* end of statistics **********************/

