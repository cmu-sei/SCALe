/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2474582571
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   const volatile int8_t * volatile  f0;
   volatile uint32_t  f1;
};

union U1 {
   uint32_t  f0;
   volatile int32_t  f1;
   int16_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_3 = 0x01L;
static int8_t * volatile g_2 = &g_3;/* VOLATILE GLOBAL g_2 */
static int32_t g_10 = (-1L);
static int16_t g_12 = 0x4B0AL;
static int32_t g_39 = 0x4FFDEABFL;
static volatile int32_t g_42 = 2L;/* VOLATILE GLOBAL g_42 */
static volatile int32_t g_43 = 8L;/* VOLATILE GLOBAL g_43 */
static volatile int32_t g_44[4] = {1L,1L,1L,1L};
static volatile int32_t g_45 = 0xF03FA9A1L;/* VOLATILE GLOBAL g_45 */
static volatile int32_t g_46[8] = {(-1L),(-1L),(-8L),(-1L),(-1L),(-8L),(-1L),(-1L)};
static volatile int32_t g_47 = (-3L);/* VOLATILE GLOBAL g_47 */
static int32_t g_48 = 1L;
static int32_t *g_62 = &g_39;
static int32_t **g_61 = &g_62;
static volatile int32_t g_63[3] = {4L,4L,4L};
static volatile int32_t g_64 = 0x83BE7680L;/* VOLATILE GLOBAL g_64 */
static volatile int32_t g_65 = (-3L);/* VOLATILE GLOBAL g_65 */
static int32_t g_66 = 0x229656D2L;
static int32_t g_67 = 0x99E855C7L;
static uint8_t g_82 = 0x5DL;
static uint32_t g_99 = 9UL;
static uint32_t g_103 = 6UL;
static int64_t g_109 = 0L;
static uint64_t g_113 = 0xDA97B9B40DC3605ALL;
static uint32_t g_117 = 0x7343453DL;
static uint8_t g_119 = 0xBDL;
static uint16_t g_124 = 65530UL;
static int8_t g_157[7][9] = {{(-10L),0x25L,(-10L),0x60L,0x52L,0x52L,0x60L,(-10L),0x25L},{(-1L),0x11L,0xECL,1L,1L,0xECL,0x11L,(-1L),0x11L},{0xFBL,0L,0x60L,0x60L,0L,0xFBL,0x52L,0xFBL,0L},{0x50L,0x11L,0x11L,0x50L,(-5L),0xECL,(-5L),0x11L,8L},{0xDDL,0xDDL,0x25L,0x60L,0xFBL,0x60L,0x25L,0xDDL,0xDDL},{8L,0x11L,(-5L),0xECL,(-5L),0x11L,8L,8L,0x11L},{0x60L,(-10L),0x25L,(-10L),0x60L,0x52L,0x52L,0x60L,(-10L)}};
static int32_t g_161 = 0x6941ECE2L;
static union U0 g_163 = {0};/* VOLATILE GLOBAL g_163 */
static union U0 g_164 = {0};/* VOLATILE GLOBAL g_164 */
static union U0 g_165 = {0};/* VOLATILE GLOBAL g_165 */
static union U0 g_166 = {0};/* VOLATILE GLOBAL g_166 */
static union U0 g_167 = {0};/* VOLATILE GLOBAL g_167 */
static union U0 g_168 = {0};/* VOLATILE GLOBAL g_168 */
static union U0 g_169[3] = {{0},{0},{0}};
static union U0 g_186[2] = {{0},{0}};
static volatile union U0 g_189 = {0};/* VOLATILE GLOBAL g_189 */
static volatile union U0 *g_188 = &g_189;
static int32_t g_211 = 0x4D1492C1L;
static int32_t g_212 = 0x1540130CL;
static uint64_t g_215 = 0xC4DB3155C3D3C4ABLL;
static uint8_t g_238[8][2][3] = {{{1UL,0xECL,0xB1L},{0UL,1UL,1UL}},{{0UL,0x87L,9UL},{0UL,9UL,1UL}},{{0UL,0x3FL,254UL},{1UL,6UL,0x99L}},{{6UL,0x3FL,3UL},{0xECL,9UL,0xECL}},{{0x3FL,0x87L,0xECL},{0xB1L,1UL,3UL}},{{3UL,0xECL,0x99L},{0x87L,0x73L,254UL}},{{3UL,0xD4L,1UL},{0xB1L,0xB1L,9UL}},{{0x3FL,0xB1L,1UL},{0xECL,0xD4L,0xB1L}}};
static volatile int32_t g_274 = (-2L);/* VOLATILE GLOBAL g_274 */
static volatile int32_t *g_273 = &g_274;
static volatile int32_t ** const g_272 = &g_273;
static int64_t g_296 = 0xFC9DFD79E2B91921LL;
static uint32_t g_297 = 4294967287UL;
static int64_t g_325 = (-7L);
static int16_t g_327 = 0x9C9EL;
static uint32_t g_328 = 0xE66D6284L;
static uint32_t g_384[5][2] = {{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL},{18446744073709551609UL,18446744073709551609UL}};
static const uint32_t *g_388 = (void*)0;
static const uint32_t **g_387 = &g_388;
static union U0 g_408 = {0};/* VOLATILE GLOBAL g_408 */
static union U0 g_410 = {0};/* VOLATILE GLOBAL g_410 */
static uint32_t g_439 = 0xAB4A7388L;
static uint64_t *g_445 = &g_215;
static uint64_t **g_444 = &g_445;
static uint16_t g_452 = 0UL;
static volatile uint8_t g_495[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static volatile uint8_t *g_494[10] = {&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4],&g_495[4]};
static volatile uint8_t **g_493 = &g_494[7];
static uint8_t *g_497[6] = {&g_238[4][1][1],&g_238[4][1][1],&g_238[4][1][1],&g_238[4][1][1],&g_238[4][1][1],&g_238[4][1][1]};
static uint8_t **g_496[9][5][2] = {{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[1],&g_497[1]},{&g_497[5],&g_497[5]},{&g_497[5],&g_497[1]},{&g_497[1],&g_497[0]}},{{&g_497[1],&g_497[0]},{&g_497[0],&g_497[1]},{&g_497[1],&g_497[1]},{&g_497[1],&g_497[1]},{&g_497[0],&g_497[5]}},{{&g_497[1],&g_497[5]},{&g_497[0],&g_497[1]},{&g_497[1],&g_497[1]},{&g_497[1],&g_497[1]},{&g_497[0],&g_497[5]}}};
static uint32_t *g_546 = &g_384[3][1];
static uint32_t g_553[6][6] = {{0UL,9UL,0xF055C84AL,0xF055C84AL,9UL,0UL},{0x26241198L,0xDE82F215L,0xF055C84AL,0UL,18446744073709551612UL,0x26241198L},{18446744073709551606UL,0xDE82F215L,0UL,18446744073709551606UL,9UL,18446744073709551606UL},{18446744073709551606UL,9UL,18446744073709551606UL,0UL,0xDE82F215L,18446744073709551606UL},{0x26241198L,18446744073709551612UL,0UL,0xF055C84AL,0xDE82F215L,0x26241198L},{0UL,9UL,0xF055C84AL,0xF055C84AL,9UL,0UL}};
static int32_t g_583 = 7L;
static uint32_t g_585[6][3] = {{1UL,1UL,0x3CFF6984L},{1UL,0UL,0xD949654DL},{1UL,0x69644BDAL,1UL},{1UL,1UL,0x3CFF6984L},{1UL,0UL,0xD949654DL},{1UL,0x69644BDAL,1UL}};
static volatile uint16_t g_590 = 65535UL;/* VOLATILE GLOBAL g_590 */
static volatile uint16_t * volatile g_589 = &g_590;/* VOLATILE GLOBAL g_589 */
static volatile uint16_t * volatile *g_588 = &g_589;
static uint64_t g_594 = 0xFE2688400371E74CLL;
static union U0 g_614 = {0};/* VOLATILE GLOBAL g_614 */
static volatile int32_t g_642 = 1L;/* VOLATILE GLOBAL g_642 */
static uint32_t *g_780 = &g_297;
static uint32_t g_792 = 4294967294UL;
static int8_t g_837 = 0xFFL;
static int8_t g_840 = (-1L);
static uint32_t g_899 = 0UL;
static int8_t g_933 = 1L;
static int64_t g_934 = 0xB6698D30D4986968LL;
static uint32_t g_935 = 0xF8BF6392L;
static uint16_t *g_945 = &g_124;
static uint16_t * const *g_944 = &g_945;
static uint16_t * const **g_943 = &g_944;
static uint16_t **g_948 = &g_945;
static uint16_t ***g_947 = &g_948;
static volatile int8_t **g_1067 = (void*)0;
static int64_t g_1084 = 1L;
static union U1 g_1110[10][8] = {{{0xD04695A0L},{0xA0832D11L},{0x8959C6D8L},{0x8959C6D8L},{0xA0832D11L},{0xD04695A0L},{0x7C7B9E60L},{0xB80E968DL}},{{0UL},{4294967295UL},{1UL},{0xA0832D11L},{0x7C7B9E60L},{0UL},{0x195CAC9CL},{4294967295UL}},{{1UL},{0x195CAC9CL},{8UL},{0xA0832D11L},{0xB80E968DL},{0x70DF5A78L},{1UL},{0xB80E968DL}},{{0x8959C6D8L},{0xB80E968DL},{0UL},{0x8959C6D8L},{1UL},{4294967295UL},{1UL},{0UL}},{{0x195CAC9CL},{0x8959C6D8L},{0x5045CFCCL},{1UL},{0x5045CFCCL},{0x8959C6D8L},{0x195CAC9CL},{0x7C7B9E60L}},{{0xA06F18D0L},{0xDE2866D0L},{0x2E0F5977L},{1UL},{0xC065501EL},{0xEBD1046BL},{1UL},{0x195CAC9CL}},{{0UL},{0xB80E968DL},{0x8959C6D8L},{0x6F0E654BL},{0xC065501EL},{1UL},{0xD04695A0L},{1UL}},{{0xA06F18D0L},{1UL},{0x6F0E654BL},{0x195CAC9CL},{0x5045CFCCL},{0UL},{0xB80E968DL},{1UL}},{{0x195CAC9CL},{0xC065501EL},{0xD730281EL},{1UL},{1UL},{0xD730281EL},{0xC065501EL},{0x195CAC9CL}},{{0x8959C6D8L},{0xA0832D11L},{0xD04695A0L},{0x7C7B9E60L},{0xB80E968DL},{0x5045CFCCL},{0UL},{1UL}}};
static volatile union U1 g_1173 = {0xB20CCB4AL};/* VOLATILE GLOBAL g_1173 */
static const int32_t g_1210 = 6L;
static volatile int32_t g_1273 = (-1L);/* VOLATILE GLOBAL g_1273 */
static volatile union U0 g_1317 = {0};/* VOLATILE GLOBAL g_1317 */
static int32_t *g_1330 = &g_211;
static int32_t ** volatile g_1329[7] = {&g_1330,&g_1330,&g_1330,&g_1330,&g_1330,&g_1330,&g_1330};
static int32_t ** const  volatile g_1331[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** volatile g_1332 = &g_1330;/* VOLATILE GLOBAL g_1332 */
static volatile int32_t g_1369 = 0L;/* VOLATILE GLOBAL g_1369 */
static volatile uint64_t * volatile g_1472 = (void*)0;/* VOLATILE GLOBAL g_1472 */
static volatile uint64_t * volatile * volatile g_1471 = &g_1472;/* VOLATILE GLOBAL g_1471 */
static volatile uint64_t * volatile * volatile *g_1470[7][9][4] = {{{&g_1471,&g_1471,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}},{{&g_1471,(void*)0,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}},{{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}},{{&g_1471,&g_1471,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471}},{{&g_1471,(void*)0,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}},{{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471},{&g_1471,(void*)0,&g_1471,&g_1471},{(void*)0,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}},{{&g_1471,&g_1471,&g_1471,(void*)0},{&g_1471,(void*)0,&g_1471,(void*)0},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,(void*)0,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,(void*)0,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471},{&g_1471,&g_1471,&g_1471,&g_1471}}};
static volatile uint64_t * volatile * volatile **g_1469 = &g_1470[0][3][2];
static volatile uint8_t g_1480[7] = {1UL,1UL,0xC1L,1UL,1UL,0xC1L,1UL};
static int16_t *g_1495 = &g_327;
static int16_t **g_1494[9] = {&g_1495,&g_1495,&g_1495,&g_1495,&g_1495,&g_1495,&g_1495,&g_1495,&g_1495};
static volatile union U1 g_1601 = {0UL};/* VOLATILE GLOBAL g_1601 */
static uint64_t * const **g_1645 = (void*)0;
static uint64_t * const ***g_1644 = &g_1645;
static const volatile union U1 * const g_1668 = &g_1173;
static const volatile union U1 * const *g_1667 = &g_1668;
static union U1 g_1671 = {0UL};/* VOLATILE GLOBAL g_1671 */
static int16_t *g_1672 = &g_1110[3][1].f2;
static union U0 *g_1701 = &g_165;
static union U0 ** const  volatile g_1700 = &g_1701;/* VOLATILE GLOBAL g_1700 */
static union U0 **g_1738 = &g_1701;
static uint64_t ***g_1772 = &g_444;
static union U1 g_1774 = {4294967295UL};/* VOLATILE GLOBAL g_1774 */
static union U1 g_1777 = {0x27884FE9L};/* VOLATILE GLOBAL g_1777 */
static volatile int16_t *g_1814[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int16_t **g_1813[3] = {&g_1814[0],&g_1814[0],&g_1814[0]};
static volatile int16_t ** const * volatile g_1812 = &g_1813[2];/* VOLATILE GLOBAL g_1812 */
static volatile union U1 g_1821 = {0x9A3B4A2AL};/* VOLATILE GLOBAL g_1821 */
static union U1 g_1850 = {0x084071DEL};/* VOLATILE GLOBAL g_1850 */
static uint8_t ** const  volatile *g_1880 = &g_496[6][4][0];
static uint8_t ** const  volatile ** volatile g_1879 = &g_1880;/* VOLATILE GLOBAL g_1879 */
static union U1 g_1886 = {0x6026BA85L};/* VOLATILE GLOBAL g_1886 */
static volatile union U1 g_1889 = {0x6AE916B9L};/* VOLATILE GLOBAL g_1889 */
static uint64_t g_1914 = 0x4550C8AC28C55F4ALL;
static int8_t *g_1985 = &g_157[2][7];
static int8_t **g_1984[3] = {&g_1985,&g_1985,&g_1985};
static int8_t *** volatile g_1983 = &g_1984[1];/* VOLATILE GLOBAL g_1983 */
static union U1 g_1988 = {4294967286UL};/* VOLATILE GLOBAL g_1988 */
static int8_t g_2024 = (-1L);
static uint32_t g_2049[9][3] = {{8UL,8UL,8UL},{0xE6864222L,0xE6864222L,0xE6864222L},{8UL,8UL,8UL},{0xE6864222L,0xE6864222L,0xE6864222L},{8UL,8UL,8UL},{0xE6864222L,0xE6864222L,0xE6864222L},{8UL,8UL,8UL},{0xE6864222L,0xE6864222L,0xE6864222L},{8UL,8UL,8UL}};
static union U1 g_2060 = {0x87BA6E2AL};/* VOLATILE GLOBAL g_2060 */
static union U1 g_2087 = {0x98E13F92L};/* VOLATILE GLOBAL g_2087 */
static union U0 * volatile **g_2089 = (void*)0;
static union U0 * volatile *** const g_2088 = &g_2089;
static uint32_t **g_2112 = &g_780;
static uint64_t *****g_2117 = (void*)0;
static int64_t *g_2155 = (void*)0;
static union U1 g_2185 = {0xEA3D57FBL};/* VOLATILE GLOBAL g_2185 */
static union U0 g_2187 = {0};/* VOLATILE GLOBAL g_2187 */
static union U0 g_2188 = {0};/* VOLATILE GLOBAL g_2188 */
static uint8_t ***g_2211 = &g_496[4][2][0];
static uint8_t ****g_2210 = &g_2211;
static union U1 g_2218[4][2][1] = {{{{0xEE3404A8L}},{{0xEE3404A8L}}},{{{0xEE3404A8L}},{{0xEE3404A8L}}},{{{0xEE3404A8L}},{{0xEE3404A8L}}},{{{0xEE3404A8L}},{{0xEE3404A8L}}}};
static union U0 g_2241 = {0};/* VOLATILE GLOBAL g_2241 */
static union U1 g_2282 = {1UL};/* VOLATILE GLOBAL g_2282 */
static volatile int32_t **g_2295[5] = {&g_273,&g_273,&g_273,&g_273,&g_273};
static volatile int32_t ***g_2294[7] = {&g_2295[4],&g_2295[4],&g_2295[0],&g_2295[4],&g_2295[4],&g_2295[0],&g_2295[4]};
static volatile int32_t ****g_2293 = &g_2294[4];
static const union U0 g_2298 = {0};/* VOLATILE GLOBAL g_2298 */
static int32_t g_2322 = 0x2CBD1A1AL;
static int64_t g_2330[1][5] = {{0x9A55BFAA99894D9BLL,0x9A55BFAA99894D9BLL,0x9A55BFAA99894D9BLL,0x9A55BFAA99894D9BLL,0x9A55BFAA99894D9BLL}};
static volatile union U0 g_2448 = {0};/* VOLATILE GLOBAL g_2448 */
static int8_t g_2467 = 1L;
static const volatile union U1 *g_2521 = &g_1821;
static const volatile union U1 ** volatile g_2520 = &g_2521;/* VOLATILE GLOBAL g_2520 */
static int16_t g_2531 = 7L;
static volatile union U0 g_2541 = {0};/* VOLATILE GLOBAL g_2541 */
static int8_t g_2616 = 0x29L;
static union U0 g_2698 = {0};/* VOLATILE GLOBAL g_2698 */
static uint16_t * volatile * volatile g_2702[2][7] = {{&g_945,&g_945,&g_945,&g_945,&g_945,&g_945,&g_945},{&g_945,&g_945,&g_945,&g_945,&g_945,&g_945,&g_945}};
static uint16_t * volatile * volatile *g_2701 = &g_2702[1][4];
static uint16_t * volatile * volatile * const *g_2700[6][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_2701,&g_2701,&g_2701,&g_2701,&g_2701},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_2701,&g_2701,&g_2701,&g_2701,&g_2701},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_2701,&g_2701,&g_2701,&g_2701,&g_2701}};
static uint16_t * volatile * volatile * const ** volatile g_2699 = &g_2700[3][2];/* VOLATILE GLOBAL g_2699 */
static union U1 g_2704 = {0x2B8B1C4EL};/* VOLATILE GLOBAL g_2704 */
static union U1 g_2810 = {0xEC44FEF4L};/* VOLATILE GLOBAL g_2810 */
static int16_t g_2918 = (-3L);
static int32_t ** volatile g_2926[3] = {&g_1330,&g_1330,&g_1330};
static volatile union U0 g_3008 = {0};/* VOLATILE GLOBAL g_3008 */
static union U1 g_3009 = {4294967287UL};/* VOLATILE GLOBAL g_3009 */
static union U1 g_3056 = {0UL};/* VOLATILE GLOBAL g_3056 */
static uint8_t g_3101 = 0UL;
static int32_t ** volatile g_3126 = &g_1330;/* VOLATILE GLOBAL g_3126 */
static union U1 g_3127 = {4294967291UL};/* VOLATILE GLOBAL g_3127 */
static int16_t *g_3169[1] = {(void*)0};
static int16_t *g_3170 = &g_2060.f2;
static int16_t *g_3171 = &g_327;
static int16_t *g_3172 = &g_1886.f2;
static int16_t *g_3173 = &g_1671.f2;
static int16_t *g_3174[10][3] = {{&g_3056.f2,(void*)0,&g_1671.f2},{&g_2087.f2,&g_1988.f2,(void*)0},{&g_3127.f2,&g_2087.f2,&g_2087.f2},{&g_2087.f2,&g_12,(void*)0},{&g_3056.f2,&g_2918,(void*)0},{&g_1777.f2,(void*)0,&g_2087.f2},{(void*)0,&g_1988.f2,&g_3056.f2},{&g_1671.f2,&g_1671.f2,&g_1988.f2},{&g_1777.f2,&g_2087.f2,(void*)0},{&g_1777.f2,&g_3009.f2,&g_2918}};
static int16_t ** const g_3168[10][4] = {{&g_3170,&g_3173,&g_3172,(void*)0},{&g_3173,&g_3174[2][1],(void*)0,&g_3170},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_3171},{&g_3173,(void*)0,&g_3172,&g_3169[0]},{&g_3170,(void*)0,&g_3170,&g_3169[0]},{&g_3172,(void*)0,&g_3173,&g_3171},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_3170},{(void*)0,&g_3174[2][1],&g_3173,(void*)0}};
static int16_t ** const *g_3167 = &g_3168[3][2];
static union U0 g_3177 = {0};/* VOLATILE GLOBAL g_3177 */


/* --- FORWARD DECLARATIONS --- */
static union U1  func_1(void);
static int64_t  func_15(uint32_t  p_16, uint32_t  p_17);
static union U0  func_22(int32_t * p_23, int32_t * p_24, int8_t * p_25, int32_t  p_26);
static union U1  func_27(int16_t * p_28, uint16_t  p_29);
static int16_t * func_30(int8_t * p_31, int32_t * p_32, uint32_t  p_33, int16_t * p_34);
static int32_t  func_36(int32_t * p_37, int16_t * p_38);
static int32_t ** func_51(int16_t * p_52, int8_t * p_53, uint32_t  p_54);
static int16_t * func_55(int32_t * p_56, uint16_t  p_57, uint32_t  p_58, int32_t ** p_59);
static uint16_t  func_74(const uint32_t  p_75);
static int8_t  func_76(int32_t ** p_77, uint16_t  p_78);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_10 g_61 g_62 g_2112 g_780 g_297 g_1701 g_165 g_39 g_1330 g_943 g_944 g_945 g_124 g_3126 g_3127 g_2210 g_2211 g_496 g_497 g_238 g_1495 g_327 g_119 g_594 g_837 g_2521 g_1821
 * writes: g_3 g_10 g_62 g_325 g_48 g_211 g_124 g_297 g_1330 g_238 g_119 g_594 g_837
 */
static union U1  func_1(void)
{ /* block id: 0 */
    int32_t * const l_21 = (void*)0;
    int8_t *l_2453 = &g_933;
    int32_t l_2468 = (-4L);
    int32_t l_2816 = (-9L);
    int32_t l_2817 = 0xFFA1521EL;
    int32_t l_2819 = 4L;
    int32_t l_2820 = 0x69161175L;
    int32_t l_2821 = (-6L);
    int32_t l_2822[1][1];
    uint64_t l_2825 = 1UL;
    uint8_t l_2829 = 0x2BL;
    int16_t l_2866 = 1L;
    uint16_t l_2921 = 65526UL;
    uint32_t l_2994 = 18446744073709551609UL;
    int8_t l_3027 = (-10L);
    volatile int32_t *l_3055 = (void*)0;
    int32_t l_3084 = (-2L);
    int32_t l_3123 = 9L;
    int32_t l_3124 = 0xD544666EL;
    uint32_t l_3131[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    uint8_t l_3134 = 0xB6L;
    int32_t *l_3183 = &g_48;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_2822[i][j] = 3L;
    }
    if ((g_2 == &g_3))
    { /* block id: 1 */
        int64_t l_6[6] = {1L,1L,0x2443AC46DDCD1665LL,1L,1L,0x2443AC46DDCD1665LL};
        int32_t *l_20 = &g_10;
        int16_t ***l_2802[6][2][3] = {{{&g_1494[2],(void*)0,(void*)0},{&g_1494[2],(void*)0,&g_1494[8]}},{{(void*)0,&g_1494[8],&g_1494[8]},{&g_1494[8],(void*)0,&g_1494[2]}},{{(void*)0,(void*)0,(void*)0},{(void*)0,&g_1494[4],(void*)0}},{{&g_1494[2],&g_1494[2],&g_1494[2]},{&g_1494[2],(void*)0,&g_1494[8]}},{{&g_1494[4],(void*)0,&g_1494[8]},{&g_1494[2],&g_1494[2],(void*)0}},{{&g_1494[2],&g_1494[2],(void*)0},{(void*)0,&g_1494[2],&g_1494[2]}}};
        uint32_t ***l_2807 = &g_2112;
        int32_t l_2818 = 0x3AEF1938L;
        int32_t l_2823 = 0x54225877L;
        int32_t l_2824 = 0xD1D845EBL;
        int32_t l_2828 = 0x6800FB45L;
        uint32_t l_2842 = 8UL;
        int16_t l_2860[3];
        int32_t * const *l_2891 = &g_1330;
        int32_t * const **l_2890 = &l_2891;
        uint32_t l_2924 = 4294967295UL;
        uint64_t * const *l_3045 = &g_445;
        uint64_t * const * const *l_3044 = &l_3045;
        uint64_t * const * const **l_3043[10];
        const int16_t l_3054 = (-9L);
        uint8_t **l_3063 = &g_497[5];
        int8_t *l_3071 = &g_933;
        int64_t **l_3079 = &g_2155;
        uint64_t l_3097 = 18446744073709551615UL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2860[i] = 0xC025L;
        for (i = 0; i < 10; i++)
            l_3043[i] = &l_3044;
        for (g_3 = 7; (g_3 <= (-8)); g_3--)
        { /* block id: 4 */
            if (l_6[0])
                break;
            if (g_3)
                goto lbl_2811;
            if (g_3)
                continue;
        }
lbl_2811:
        for (g_3 = 18; (g_3 <= 25); g_3 = safe_add_func_int16_t_s_s(g_3, 9))
        { /* block id: 10 */
            int32_t *l_9 = &g_10;
            int16_t *l_11 = &g_12;
            int8_t *l_35 = (void*)0;
            (*l_9) = 0x64C7B7F6L;
        }
        for (g_10 = 3; (g_10 == (-30)); g_10 = safe_sub_func_int8_t_s_s(g_10, 4))
        { /* block id: 1346 */
            int32_t *l_2814 = &g_39;
            int32_t *l_2815[10] = {&g_48,&g_48,&g_66,&g_48,&g_48,&g_66,&g_48,&g_48,&g_66,&g_48};
            int i;
            (*g_61) = (*g_61);
            if (g_3)
                goto lbl_2811;
            ++l_2825;
            l_2829--;
        }
        for (g_325 = 12; (g_325 < 9); g_325 = safe_sub_func_int64_t_s_s(g_325, 4))
        { /* block id: 1354 */
            uint32_t l_2841 = 0x6C186E48L;
            uint64_t *l_2843 = &l_2825;
            uint32_t l_2853 = 0xD140373FL;
            uint64_t l_2856 = 0x056D0770E1C998FDLL;
            uint32_t l_2857[3][8] = {{0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L,0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L},{0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L,0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L},{0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L,0xBAE327D8L,0x72D6932EL,0x72D6932EL,0xBAE327D8L}};
            int32_t l_2865 = 0L;
            int32_t * const **l_2892 = &l_2891;
            uint32_t l_2910 = 0UL;
            int32_t l_2919 = 0x0CA4A02CL;
            int32_t l_2920 = (-10L);
            int32_t *l_2928 = (void*)0;
            const uint64_t l_2978 = 0xE3B7CF498C6C651FLL;
            int16_t l_3037 = 0xCA5DL;
            int32_t l_3072 = 6L;
            union U0 **l_3078 = (void*)0;
            const int16_t l_3089 = 4L;
            int i, j;
        }
    }
    else
    { /* block id: 1465 */
        int8_t l_3102 = 0xA5L;
        int32_t *l_3103 = &g_161;
        int32_t *l_3104 = (void*)0;
        int32_t *l_3105 = &l_2819;
        int32_t *l_3106 = (void*)0;
        int32_t *l_3107 = &g_10;
        int32_t l_3108 = (-10L);
        int32_t *l_3109 = &g_10;
        int32_t *l_3110 = &l_2820;
        int32_t *l_3111 = &l_2817;
        int32_t *l_3112 = &g_161;
        int32_t *l_3113[6][9][1] = {{{&l_3108},{(void*)0},{&g_161},{&l_2822[0][0]},{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108},{(void*)0}},{{&g_161},{&l_2822[0][0]},{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108},{(void*)0},{&g_161},{&l_2822[0][0]}},{{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108},{(void*)0},{&g_161},{&l_2822[0][0]},{&l_2822[0][0]},{&g_161}},{{(void*)0},{&l_3108},{(void*)0},{&g_161},{&l_2822[0][0]},{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108}},{{(void*)0},{&g_161},{&l_2822[0][0]},{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108},{(void*)0},{&g_161}},{{&l_2822[0][0]},{&l_2822[0][0]},{&g_161},{(void*)0},{&l_3108},{(void*)0},{&g_161},{&l_2822[0][0]},{&l_2822[0][0]}}};
        uint8_t l_3114 = 1UL;
        const int64_t l_3135[2][8] = {{0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL},{0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL,0x27BE34FE1B1F102CLL}};
        int16_t l_3162 = 0x377BL;
        int i, j, k;
lbl_3182:
        l_3114++;
        if ((((**g_2112) = ((((void*)0 == l_3109) != (((safe_sub_func_int8_t_s_s((-1L), (((**g_2112) && ((*l_3111) = (*l_3111))) >= ((*g_1701) , ((***g_943) |= (safe_sub_func_int64_t_s_s((safe_mod_func_int32_t_s_s(l_3123, (*l_3107))), (((*g_1330) = (**g_61)) && (*l_3107))))))))) != l_3124) > l_2819)) || (*l_3105))) ^ (*l_3110)))
        { /* block id: 1471 */
            int32_t * const l_3125 = &g_48;
            (*g_3126) = l_3125;
        }
        else
        { /* block id: 1473 */
            return g_3127;
        }
        for (l_2866 = 2; (l_2866 >= 0); l_2866 -= 1)
        { /* block id: 1478 */
            const uint32_t l_3143 = 1UL;
            int16_t ** const *l_3165 = (void*)0;
            (*l_3107) ^= (((~((safe_mul_func_uint16_t_u_u(65535UL, l_3131[4])) , (((****g_2210)--) == (l_3134 , (l_3135[1][5] || (safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u(((safe_sub_func_uint8_t_u_u((safe_unary_minus_func_int16_t_s((*g_1495))), (0UL <= 0x9D489D8AL))) && ((0x24L != (l_3143 > l_3143)) ^ 0xCCL)), 4)), l_3143))))))) <= (-6L)) == (-1L));
            for (l_2829 = 0; (l_2829 <= 2); l_2829 += 1)
            { /* block id: 1483 */
                uint16_t l_3146[2];
                uint16_t **l_3153 = &g_945;
                uint16_t l_3156 = 1UL;
                int64_t **l_3161 = (void*)0;
                int16_t ** const **l_3166[2][6][6] = {{{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,(void*)0,&l_3165,&l_3165,(void*)0,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,(void*)0,&l_3165,&l_3165,(void*)0,&l_3165}},{{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,(void*)0,&l_3165,&l_3165,(void*)0,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,&l_3165,&l_3165,&l_3165,&l_3165,&l_3165},{&l_3165,(void*)0,&l_3165,&l_3165,(void*)0,&l_3165}}};
                uint64_t *l_3179 = &g_1914;
                uint64_t **l_3178 = &l_3179;
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_3146[i] = 0x5FCEL;
            }
            for (g_119 = 0; (g_119 <= 2); g_119 += 1)
            { /* block id: 1495 */
                for (g_594 = 0; (g_594 <= 2); g_594 += 1)
                { /* block id: 1498 */
                    for (g_837 = 2; (g_837 >= 0); g_837 -= 1)
                    { /* block id: 1501 */
                        if (l_2817)
                            goto lbl_3182;
                    }
                }
            }
        }
        if (l_2817)
            goto lbl_3182;
    }
    (*g_61) = l_3183;
    return (*g_2521);
}


/* ------------------------------------------ */
/* 
 * reads : g_1985 g_1495 g_327 g_944 g_945 g_124 g_445 g_215 g_439 g_1330 g_211 g_61 g_82 g_157 g_1667 g_1668 g_2520 g_1983 g_1984 g_780 g_297 g_2541 g_943 g_1880 g_496 g_497 g_238 g_1672 g_1772 g_444 g_546 g_384 g_947 g_948 g_2112 g_1110.f2 g_2531 g_2211 g_2616 g_1480 g_1332 g_2210 g_1879 g_1777.f1 g_272 g_188 g_189 g_48 g_2698 g_2699 g_62 g_2704 g_273 g_2700 g_1494 g_1774.f0 g_2087 g_119
 * writes: g_157 g_439 g_215 g_583 g_211 g_2185.f2 g_62 g_119 g_82 g_2521 g_238 g_2531 g_1110.f2 g_444 g_384 g_327 g_2616 g_2282.f2 g_297 g_2155 g_2210 g_496 g_273 g_48 g_117 g_2282.f0 g_2330 g_933
 */
static int64_t  func_15(uint32_t  p_16, uint32_t  p_17)
{ /* block id: 1141 */
    int16_t l_2469 = (-9L);
    int32_t l_2470 = 0xEEACEC73L;
    int64_t l_2483 = 2L;
    uint8_t **l_2489 = &g_497[5];
    int32_t l_2490 = 0xF5AFD644L;
    int64_t l_2491[7][10] = {{1L,0x4954D294146DAECBLL,0xCF3A8F29297DF4E3LL,(-4L),0xE436B7812B0F541CLL,0xE436B7812B0F541CLL,(-4L),0xCF3A8F29297DF4E3LL,0x4954D294146DAECBLL,1L},{0x4954D294146DAECBLL,7L,0x22BB25A7F1F701E5LL,(-4L),0x8CD1A6861B9D3E6BLL,1L,0x8CD1A6861B9D3E6BLL,(-4L),0x22BB25A7F1F701E5LL,7L},{0xA026CAB087E37E90LL,0xCF3A8F29297DF4E3LL,1L,7L,0x8CD1A6861B9D3E6BLL,0xF341BFEF1067176ALL,0xF341BFEF1067176ALL,0x8CD1A6861B9D3E6BLL,7L,1L},{0x8CD1A6861B9D3E6BLL,0x8CD1A6861B9D3E6BLL,0x4954D294146DAECBLL,0xA026CAB087E37E90LL,0xE436B7812B0F541CLL,0xF341BFEF1067176ALL,0x22BB25A7F1F701E5LL,0xF341BFEF1067176ALL,0xE436B7812B0F541CLL,0xA026CAB087E37E90LL},{0xA026CAB087E37E90LL,0x44FD400845B95835LL,0xA026CAB087E37E90LL,0xF341BFEF1067176ALL,(-4L),1L,0x22BB25A7F1F701E5LL,0x22BB25A7F1F701E5LL,1L,(-4L)},{0x4954D294146DAECBLL,0x8CD1A6861B9D3E6BLL,0x8CD1A6861B9D3E6BLL,0x4954D294146DAECBLL,0xA026CAB087E37E90LL,0xE436B7812B0F541CLL,0xF341BFEF1067176ALL,0x22BB25A7F1F701E5LL,0xF341BFEF1067176ALL,0xE436B7812B0F541CLL},{1L,0xCF3A8F29297DF4E3LL,0xA026CAB087E37E90LL,0xCF3A8F29297DF4E3LL,1L,7L,0x8CD1A6861B9D3E6BLL,0xF341BFEF1067176ALL,0xF341BFEF1067176ALL,0x8CD1A6861B9D3E6BLL}};
    uint64_t l_2509 = 0x1E2E946E780D9DC8LL;
    int32_t l_2513[2][8][5] = {{{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L}},{{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L},{1L,1L,1L,1L,1L},{0L,(-1L),0L,(-1L),0L}}};
    int16_t l_2514 = (-1L);
    uint64_t l_2515 = 0xB3630F9BB4F0BD9DLL;
    int16_t * const l_2530 = &g_2531;
    int16_t * const *l_2529 = &l_2530;
    int16_t * const **l_2528 = &l_2529;
    int8_t ***l_2559 = (void*)0;
    uint64_t **l_2571 = &g_445;
    int64_t l_2584 = 1L;
    uint8_t ****l_2676 = &g_2211;
    uint16_t ****l_2729 = &g_947;
    int i, j, k;
    if (((((l_2470 = ((*g_1985) = l_2469)) | (safe_lshift_func_int8_t_s_u((((p_16 <= ((((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s(p_16, (safe_mul_func_uint16_t_u_u((l_2490 ^= ((0xF4E9L ^ (((l_2483 || (*g_1495)) && (safe_rshift_func_int16_t_s_s((safe_rshift_func_int16_t_s_s((+((l_2489 == (void*)0) , ((l_2469 , p_17) | p_17))), 15)), l_2469))) & 0x97A5EEC5L)) & (**g_944))), l_2483)))) & 0x5241L), (-7L))), l_2469)) && (*g_445)), 4)) >= p_17) && l_2491[6][0]) ^ l_2469)) , &g_1879) != (void*)0), p_17))) >= 6L) > p_17))
    { /* block id: 1145 */
        int32_t *l_2493 = &g_212;
        uint32_t l_2494[3][2] = {{0x9A4F92E9L,0xE7831625L},{0xE7831625L,0x9A4F92E9L},{0xE7831625L,0xE7831625L}};
        int32_t l_2506 = 0L;
        int32_t l_2508[6][2] = {{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}};
        int i, j;
        for (g_439 = 0; (g_439 <= 1); g_439 += 1)
        { /* block id: 1148 */
            int32_t l_2495 = 1L;
            int32_t l_2497[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
            int16_t l_2507 = 3L;
            int i;
            for (g_215 = 0; (g_215 <= 1); g_215 += 1)
            { /* block id: 1151 */
                if (p_17)
                    break;
            }
            for (l_2490 = 1; (l_2490 >= 0); l_2490 -= 1)
            { /* block id: 1156 */
                int32_t *l_2492[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_2492[i] = &g_583;
                l_2493 = l_2492[1];
                (*g_1330) |= ((*l_2493) = p_16);
            }
            for (g_2185.f2 = 1; (g_2185.f2 >= 0); g_2185.f2 -= 1)
            { /* block id: 1163 */
                int32_t *l_2496 = &g_39;
                int32_t *l_2498 = &l_2497[2];
                int32_t *l_2499 = &l_2497[5];
                int32_t *l_2500 = (void*)0;
                int32_t *l_2501 = &l_2497[2];
                int32_t *l_2502 = &g_583;
                int32_t *l_2503 = &l_2497[5];
                int32_t *l_2504 = (void*)0;
                int32_t *l_2505[8][4] = {{&g_211,&g_211,(void*)0,&g_211},{&g_211,&g_161,&g_161,&g_211},{&g_161,&g_211,&g_161,&g_161},{&g_211,&g_211,(void*)0,&g_211},{&g_211,&g_161,&g_161,&g_211},{&g_161,&g_211,&g_161,&g_161},{&g_211,&g_211,(void*)0,&g_211},{&g_211,&g_161,&g_161,&g_211}};
                int i, j;
                l_2494[0][0] = ((p_17 == 5L) > 0UL);
                --l_2509;
                (*g_61) = &l_2497[6];
            }
        }
    }
    else
    { /* block id: 1169 */
        int32_t *l_2512[5][3] = {{&g_39,&g_583,&g_39},{&g_39,&l_2470,&g_583},{&l_2470,&g_39,&g_39},{&g_583,&g_39,&l_2470},{&g_10,&l_2470,(void*)0}};
        int16_t l_2623 = 0x59B6L;
        uint16_t ****l_2682 = &g_947;
        uint8_t **l_2697 = &g_497[5];
        int32_t l_2703 = (-3L);
        uint64_t ** const *l_2732 = (void*)0;
        int i, j;
lbl_2585:
        --l_2515;
        for (g_119 = (-25); (g_119 != 16); g_119 = safe_add_func_int8_t_s_s(g_119, 8))
        { /* block id: 1173 */
            int32_t l_2534 = (-1L);
            const uint64_t ****l_2576 = (void*)0;
            uint8_t *****l_2594 = (void*)0;
            union U0 **l_2602 = (void*)0;
            int32_t l_2607[6] = {0x24F88C11L,0x24F88C11L,0x24F88C11L,0x24F88C11L,0x24F88C11L,0x24F88C11L};
            int64_t l_2658[9][8][3] = {{{0x1924C026D39625A9LL,1L,4L},{1L,(-1L),0x5431493BB85391ACLL},{5L,0x1924C026D39625A9LL,(-1L)},{0x2C05F70B01AA1EC4LL,1L,9L},{0x5F9F679CEDCC4AB3LL,(-3L),0x90F62EB7B5DC4542LL},{0x5431493BB85391ACLL,4L,2L},{0x2020794590A91788LL,0x31468BD1E8AE57A5LL,0L},{(-2L),0xE1F98D32190EF9F6LL,0x24513F91E7325C60LL}},{{7L,5L,1L},{(-1L),(-2L),1L},{1L,1L,0x3BFF73A4BFF4CCE4LL},{0x0093E2C01BB24D46LL,(-4L),0x35E89B0255DAF8E4LL},{1L,1L,0x91174088AFD6114BLL},{0L,(-1L),0L},{0x8A208FD8E19E2ED9LL,(-1L),0x1924C026D39625A9LL},{0x51342B15AC177D18LL,8L,0x5431493BB85391ACLL}},{{(-3L),0x8A208FD8E19E2ED9LL,0x1924C026D39625A9LL},{0xD9AC2FE1997BD6D7LL,2L,0L},{0x5F9F679CEDCC4AB3LL,6L,0x91174088AFD6114BLL},{4L,0x5431493BB85391ACLL,0x35E89B0255DAF8E4LL},{0L,0x31468BD1E8AE57A5LL,0x3BFF73A4BFF4CCE4LL},{0xAD63BEFA01E2AC5FLL,0xA3003AF45EF5D7ADLL,0x4CF0FE1AEB3B6C1DLL},{1L,7L,1L},{0x51342B15AC177D18LL,(-1L),0xA216BAB3D6DB513CLL}},{{9L,0x31468BD1E8AE57A5LL,0x84671509B2EA336CLL},{0x9152248422EE889CLL,(-2L),0x2C05F70B01AA1EC4LL},{0x4BCE18E90175C14CLL,0L,0x30DF63A0E5F25790LL},{(-2L),0L,0xEC10F2CAE24E5D96LL},{1L,1L,1L},{0xA216BAB3D6DB513CLL,2L,(-1L)},{(-1L),1L,0x31468BD1E8AE57A5LL},{(-1L),0x4CF0FE1AEB3B6C1DLL,(-1L)}},{{(-1L),1L,1L},{(-1L),0xBCB29D2F47574C55LL,0xA48E5C97493B5762LL},{(-1L),0L,0xD1AE7A549A7EFCC6LL},{0xA216BAB3D6DB513CLL,5L,0xB202198C40119894LL},{1L,0x1924C026D39625A9LL,1L},{(-2L),0xA216BAB3D6DB513CLL,0x0093E2C01BB24D46LL},{0x4BCE18E90175C14CLL,0x5F9F679CEDCC4AB3LL,(-4L)},{0x9152248422EE889CLL,1L,0x5431493BB85391ACLL}},{{9L,0x3539CAC1228708D2LL,1L},{0x51342B15AC177D18LL,0L,2L},{1L,0L,0x5F9F679CEDCC4AB3LL},{(-1L),0xAD63BEFA01E2AC5FLL,(-1L)},{1L,1L,1L},{0xD6C54523D0AF2EBDLL,0xCF51ADC77BC62773LL,(-10L)},{(-1L),1L,1L},{0xA3003AF45EF5D7ADLL,0xECF37D808B432A05LL,0xE1F98D32190EF9F6LL}},{{4L,0L,0x90F62EB7B5DC4542LL},{0xCF51ADC77BC62773LL,0xECF37D808B432A05LL,(-1L)},{5L,1L,1L},{1L,0xCF51ADC77BC62773LL,0x84A4DC89BD50C841LL},{1L,1L,0x91174088AFD6114BLL},{0x9152248422EE889CLL,0xAD63BEFA01E2AC5FLL,0xD9AC2FE1997BD6D7LL},{1L,0L,1L},{1L,0L,0xD96589387CB90AFELL}},{{0x5F9F679CEDCC4AB3LL,0x3539CAC1228708D2LL,0L},{0x0093E2C01BB24D46LL,1L,(-1L)},{1L,0x5F9F679CEDCC4AB3LL,5L},{(-1L),0xA216BAB3D6DB513CLL,0x9145A4F9042C8AC7LL},{(-1L),0x1924C026D39625A9LL,0x6B95FC1DD83CB06CLL},{5L,5L,(-1L)},{0x8A208FD8E19E2ED9LL,0L,0x913EF991E517F063LL},{0x4CF0FE1AEB3B6C1DLL,0xBCB29D2F47574C55LL,0xCF51ADC77BC62773LL}},{{0x9DB43F150FDF9F9DLL,1L,1L},{0xAD63BEFA01E2AC5FLL,0x4CF0FE1AEB3B6C1DLL,0xCF51ADC77BC62773LL},{0L,1L,0x913EF991E517F063LL},{0x9152248422EE889CLL,2L,(-1L)},{0L,1L,0x6B95FC1DD83CB06CLL},{0x24513F91E7325C60LL,0L,0x9145A4F9042C8AC7LL},{0x31468BD1E8AE57A5LL,0L,5L},{0xB202198C40119894LL,(-2L),(-1L)}}};
            int64_t l_2659[10][8] = {{0x5485A9B4FB0B04AALL,0x68A156A7B958418DLL,(-4L),(-4L),0xFBA0E2E69A2289B7LL,0x41FD33E800ADB170LL,0x5FD56046493B66AFLL,0x5485A9B4FB0B04AALL},{0x845578D77B4968E5LL,0xFBA0E2E69A2289B7LL,0x64D15AFFB5E83B3BLL,9L,(-1L),(-1L),9L,0x64D15AFFB5E83B3BLL},{9L,9L,1L,1L,0xD685B67D8BC617F6LL,0x99CE3922E0D36818LL,(-1L),0xFBA0E2E69A2289B7LL},{(-1L),0x3B0D5B00EC888E09LL,9L,0x03798E47A8F7DD28LL,0xACD4B1B73CF63262LL,(-1L),0x3B0D5B00EC888E09LL,0xFBA0E2E69A2289B7LL},{0x3B0D5B00EC888E09LL,(-1L),(-1L),1L,0x5FD56046493B66AFLL,(-4L),0x68A156A7B958418DLL,(-1L)},{0x64D15AFFB5E83B3BLL,0x627FB3206E961C82LL,(-6L),0x03798E47A8F7DD28LL,(-1L),0x64D15AFFB5E83B3BLL,9L,0x64D15AFFB5E83B3BLL},{9L,(-4L),0x5FD56046493B66AFLL,(-4L),9L,1L,0x03798E47A8F7DD28LL,9L},{0x3B0D5B00EC888E09LL,0x1C9F68FA652D3703LL,0x41FD33E800ADB170LL,0x68A156A7B958418DLL,1L,9L,0xD685B67D8BC617F6LL,(-4L)},{1L,1L,0x41FD33E800ADB170LL,(-6L),9L,(-1L),0x03798E47A8F7DD28LL,0x41FD33E800ADB170LL},{1L,(-1L),0x5FD56046493B66AFLL,9L,0x42BFBA12D9ECA6FCLL,(-1L),9L,0xD3352EEFF2A67DBELL}};
            union U1 *l_2661[5][6] = {{&g_1850,&g_1850,&g_1850,&g_1850,&g_1850,&g_1850},{&g_1850,&g_1850,&g_1850,&g_1850,&g_1850,&g_1850},{&g_1850,&g_1850,&g_1850,&g_1850,&g_1850,&g_1850},{&g_1850,&g_1850,&g_1850,&g_1850,&g_1850,&g_1850},{&g_1850,&g_1850,&g_1850,&g_1850,&g_1850,&g_1850}};
            union U1 **l_2660[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int8_t *l_2696[10] = {&g_2024,&g_2024,&g_157[2][7],&g_2024,&g_2024,&g_157[2][7],&g_2024,&g_2024,&g_157[2][7],&g_2024};
            int8_t ** const *l_2707[9];
            int32_t *l_2723 = (void*)0;
            int64_t l_2746 = (-6L);
            uint32_t l_2752[5][5] = {{0xB1BDAA67L,1UL,0xB1BDAA67L,0xC9C5F0FBL,0xC9C5F0FBL},{0xB1BDAA67L,1UL,0xB1BDAA67L,0xC9C5F0FBL,0xC9C5F0FBL},{0xB1BDAA67L,1UL,0xB1BDAA67L,0xC9C5F0FBL,0xC9C5F0FBL},{0xB1BDAA67L,1UL,0xB1BDAA67L,0xC9C5F0FBL,0xC9C5F0FBL},{0xB1BDAA67L,1UL,0xB1BDAA67L,0xC9C5F0FBL,0xC9C5F0FBL}};
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_2707[i] = &g_1984[1];
            for (g_82 = 0; (g_82 <= 2); g_82 += 1)
            { /* block id: 1176 */
                int i, j;
                if (g_157[(g_82 + 4)][(g_82 + 1)])
                    break;
            }
            (*g_2520) = (*g_1667);
            if ((~18446744073709551615UL))
            { /* block id: 1180 */
                uint16_t l_2527 = 0x0B27L;
                int16_t ***l_2533 = &g_1494[2];
                int16_t ****l_2532 = &l_2533;
                const uint8_t ***l_2562[3];
                const uint8_t *** const *l_2561 = &l_2562[1];
                uint8_t ****l_2565 = &g_2211;
                uint64_t ****l_2575 = &g_1772;
                int32_t l_2586 = 0x3976F1CBL;
                union U0 **l_2603 = &g_1701;
                int32_t l_2606 = 1L;
                int32_t l_2613 = 1L;
                int32_t l_2614 = 0L;
                int32_t l_2617 = 0xBEFA4263L;
                int32_t l_2619 = 0xE798F473L;
                int32_t l_2621[9][1][6] = {{{(-1L),(-9L),(-4L),0xE0EB0F03L,9L,1L}},{{0xE756EA54L,(-4L),(-1L),0xE4C55AFAL,0xE4C55AFAL,(-1L)}},{{(-4L),(-4L),(-8L),0xE756EA54L,9L,0xE4C55AFAL}},{{1L,(-9L),0xE0EB0F03L,(-8L),0L,(-8L)}},{{0xE0EB0F03L,1L,0xE0EB0F03L,1L,(-4L),0xE4C55AFAL}},{{0xA1D9D269L,1L,(-8L),0x6F20A709L,(-1L),(-1L)}},{{0x6F20A709L,(-1L),(-1L),0x6F20A709L,(-8L),1L}},{{0xA1D9D269L,0xE4C55AFAL,(-4L),1L,0xE0EB0F03L,1L}},{{0xE0EB0F03L,(-8L),0L,(-8L),0xE0EB0F03L,(-9L)}}};
                int8_t l_2626 = 1L;
                uint32_t l_2633 = 0xAC39B398L;
                uint16_t ****l_2684[7][7] = {{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,(void*)0,&g_947,(void*)0,&g_947,&g_947,(void*)0},{(void*)0,&g_947,&g_947,(void*)0,&g_947,&g_947,(void*)0},{&g_947,(void*)0,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,(void*)0,&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,(void*)0}};
                int8_t ****l_2708 = &l_2559;
                int64_t l_2721 = (-1L);
                int64_t l_2743 = 1L;
                int16_t l_2747 = 0xB362L;
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_2562[i] = (void*)0;
                if ((l_2534 = ((((***g_1983) = p_17) >= ((safe_mod_func_uint32_t_u_u((*g_780), ((safe_sub_func_uint8_t_u_u((((-4L) == l_2527) < (p_17 ^ (((l_2528 = (void*)0) == ((*l_2532) = &g_1494[2])) && 0x9CFB56F5D935AA3DLL))), (p_16 | l_2534))) & p_16))) < 9L)) != (*g_780))))
                { /* block id: 1185 */
                    (*g_1330) ^= p_17;
                    if (l_2534)
                        break;
                }
                else
                { /* block id: 1188 */
                    uint32_t ***l_2550 = (void*)0;
                    uint32_t **l_2552 = &g_546;
                    uint32_t ***l_2551 = &l_2552;
                    uint64_t l_2557 = 0UL;
                    int8_t ***l_2558 = &g_1984[1];
                    uint8_t l_2560 = 0xE0L;
                    const uint8_t *** const **l_2563 = (void*)0;
                    const uint8_t *** const **l_2564 = &l_2561;
                    int32_t l_2581 = 0xC42AE31CL;
                    uint8_t ******l_2595 = &l_2594;
                    int32_t l_2608 = 9L;
                    int32_t l_2609 = 0xD52DF1F8L;
                    int32_t l_2610 = (-1L);
                    int32_t l_2611 = 0x9A2D4A20L;
                    int32_t l_2620 = 5L;
                    int32_t l_2622 = 0x47225C6BL;
                    int32_t l_2624 = 0x3263F184L;
                    int32_t l_2625 = 0x331EE066L;
                    int32_t l_2627 = 4L;
                    int32_t l_2628 = 0xB1B055CCL;
                    int32_t l_2629 = 0xAA165420L;
                    if (((safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((p_17 | (g_2541 , l_2513[1][3][1])), ((*g_1672) = ((**l_2529) = (((***g_943) || (((***g_1880) ^= (safe_add_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s(0x04L, l_2527)), ((((*l_2564) = ((((((safe_add_func_int32_t_s_s(((((*l_2551) = (void*)0) == (void*)0) < ((safe_rshift_func_int8_t_s_s((safe_add_func_int16_t_s_s(l_2557, 0x3AC8L)), 7)) <= p_16)), 0x40DF943CL)) , l_2558) == l_2559) <= l_2560) , 0x4460CC1EB75E5D90LL) , l_2561)) != l_2565) , l_2527))), l_2557))) > p_16)) | p_16))))), p_17)) || l_2534), 8)) <= l_2534))
                    { /* block id: 1194 */
                        uint64_t ***l_2572 = &l_2571;
                        (*g_1330) = ((l_2469 == ((safe_div_func_uint8_t_u_u((~(0x6F6C1A03L < (((*g_1772) = (*g_1772)) == ((*l_2572) = l_2571)))), ((((*g_546)--) , (l_2575 != l_2576)) && (safe_div_func_uint16_t_u_u(((((***g_947) <= ((l_2515 < (((safe_mul_func_int8_t_s_s(1L, p_17)) & p_17) & p_16)) ^ l_2581)) <= 1UL) ^ 0x5E446141L), l_2491[5][2]))))) < 65535UL)) >= 0xCA45DF055336DCA6LL);
                        l_2584 |= (safe_rshift_func_int8_t_s_u((&g_546 != &g_546), 2));
                        (*g_1330) = l_2515;
                        return p_16;
                    }
                    else
                    { /* block id: 1202 */
                        uint64_t l_2587 = 0UL;
                        if (g_211)
                            goto lbl_2585;
                        l_2587++;
                    }
                    if ((((safe_div_func_int32_t_s_s(p_16, (safe_rshift_func_uint8_t_u_u((&g_2210 != ((*l_2595) = l_2594)), 4)))) , (safe_sub_func_int16_t_s_s((p_17 >= (0UL & (**g_2112))), (safe_sub_func_uint64_t_u_u(l_2514, (safe_mul_func_int8_t_s_s(((***l_2558) &= 0L), (l_2602 == l_2603)))))))) , 0x9FC48124L))
                    { /* block id: 1208 */
                        int64_t l_2604 = 8L;
                        int32_t l_2605 = 0L;
                        int32_t l_2612 = 0xEDFBE8B0L;
                        int32_t l_2615 = (-1L);
                        int32_t l_2618[3][8][6] = {{{6L,0xCCC7BDB1L,0x465A4388L,0xCCC7BDB1L,6L,(-2L)},{0x5D75BAD8L,0xCCC7BDB1L,(-1L),0x5D75BAD8L,1L,1L},{0x5D75BAD8L,1L,1L,0xCCC7BDB1L,0xCCC7BDB1L,1L},{6L,6L,(-1L),0x88544C51L,0xCCC7BDB1L,(-2L)},{0xCCC7BDB1L,1L,0x465A4388L,0x88544C51L,1L,(-1L)},{6L,0xCCC7BDB1L,0x465A4388L,0xCCC7BDB1L,6L,(-2L)},{0x5D75BAD8L,0xCCC7BDB1L,(-1L),0x5D75BAD8L,1L,1L},{0x5D75BAD8L,1L,1L,0xCCC7BDB1L,0xCCC7BDB1L,1L}},{{6L,6L,(-1L),0x88544C51L,0xCCC7BDB1L,(-2L)},{0xCCC7BDB1L,1L,0x465A4388L,0x88544C51L,1L,(-1L)},{6L,0xCCC7BDB1L,0x465A4388L,0xCCC7BDB1L,6L,(-2L)},{0x5D75BAD8L,0xCCC7BDB1L,(-1L),0x5D75BAD8L,1L,1L},{0x5D75BAD8L,1L,1L,0xCCC7BDB1L,0xCCC7BDB1L,1L},{6L,6L,(-1L),0x88544C51L,0xCCC7BDB1L,(-2L)},{0xCCC7BDB1L,1L,0x465A4388L,0x88544C51L,1L,(-1L)},{6L,0xCCC7BDB1L,0x465A4388L,0xCCC7BDB1L,6L,(-2L)}},{{0x5D75BAD8L,0xCCC7BDB1L,(-1L),0x5D75BAD8L,1L,1L},{0x5D75BAD8L,1L,1L,0xCCC7BDB1L,0xCCC7BDB1L,1L},{6L,6L,(-1L),0x88544C51L,0xCCC7BDB1L,(-2L)},{0xCCC7BDB1L,1L,0x465A4388L,0x88544C51L,1L,(-1L)},{6L,0xCCC7BDB1L,0x465A4388L,0xCCC7BDB1L,6L,(-2L)},{0x5D75BAD8L,0xCCC7BDB1L,(-1L),0x5D75BAD8L,1L,1L},{0x5D75BAD8L,1L,1L,0xCCC7BDB1L,0xCCC7BDB1L,1L},{6L,6L,(-1L),0x88544C51L,0xCCC7BDB1L,(-2L)}}};
                        uint32_t l_2630 = 0x1D7FEAE2L;
                        int i, j, k;
                        if (g_327)
                            goto lbl_2585;
                        l_2630--;
                        ++l_2633;
                        l_2610 ^= l_2607[1];
                    }
                    else
                    { /* block id: 1213 */
                        (*g_61) = &l_2607[2];
                    }
                    for (l_2584 = 0; (l_2584 >= (-14)); l_2584--)
                    { /* block id: 1218 */
                        uint8_t l_2638[4][5][3] = {{{1UL,1UL,0x89L},{0x0AL,1UL,249UL},{1UL,1UL,0x89L},{0x0AL,1UL,249UL},{1UL,1UL,0x89L}},{{0x0AL,1UL,249UL},{1UL,1UL,0x89L},{0x0AL,1UL,0x0AL},{6UL,6UL,1UL},{0x7AL,0x1EL,0x0AL}},{{6UL,6UL,1UL},{0x7AL,0x1EL,0x0AL},{6UL,6UL,1UL},{0x7AL,0x1EL,0x0AL},{6UL,6UL,1UL}},{{0x7AL,0x1EL,0x0AL},{6UL,6UL,1UL},{0x7AL,0x1EL,0x0AL},{6UL,6UL,1UL},{0x7AL,0x1EL,0x0AL}}};
                        int i, j, k;
                        l_2638[1][0][2]++;
                    }
                }
                if (((((void*)0 != &g_1813[2]) == (safe_mod_func_int16_t_s_s(p_16, ((*l_2530) &= ((*g_1672) ^= (0x29768275L || (18446744073709551613UL || l_2626))))))) & (safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((safe_add_func_int64_t_s_s((((((((((safe_div_func_uint64_t_u_u(((l_2534 = (safe_mod_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_u(((*g_1495) ^= ((!(((safe_mul_func_uint8_t_u_u((***g_2211), l_2607[3])) >= p_16) && 3UL)) >= p_16)), 11)) & l_2534), 0x9FA49BFEL))) , 0UL), p_17)) , p_17) && l_2584) != l_2470) >= p_17) == p_17) > l_2658[1][7][2]) , l_2513[0][1][1]) || l_2659[2][3]), p_17)) == l_2633), 0x5626L)), p_17))))
                { /* block id: 1226 */
                    if (l_2509)
                        goto lbl_2585;
                }
                else
                { /* block id: 1228 */
                    int32_t *l_2663[8][6][4] = {{{&g_67,&g_67,&l_2470,&l_2619},{&g_67,&g_67,&g_211,&g_67},{(void*)0,&l_2619,(void*)0,&g_211},{&g_212,&l_2619,&l_2470,&g_67},{&l_2619,&g_67,&g_67,&l_2619},{(void*)0,&g_67,&g_67,&g_211}},{{&l_2619,&g_212,&l_2470,&g_212},{&g_212,&g_67,(void*)0,&g_212},{(void*)0,&g_212,&g_211,&g_211},{&g_67,&g_67,&l_2470,&l_2619},{&g_67,&g_67,&g_211,&g_67},{(void*)0,&l_2619,(void*)0,&g_211}},{{&g_212,&l_2619,&l_2470,&g_67},{&l_2619,&g_67,&g_67,&l_2619},{(void*)0,&g_67,&g_67,&g_211},{&l_2619,&g_212,&l_2470,&g_212},{&g_212,&g_67,(void*)0,&g_212},{(void*)0,&g_212,&g_211,&g_211}},{{&g_67,&g_67,&l_2470,&l_2619},{&g_67,&g_67,&g_211,&g_67},{(void*)0,&l_2619,(void*)0,&g_211},{&g_212,&l_2619,&l_2470,&g_67},{&l_2619,&g_67,&g_67,&l_2619},{(void*)0,&g_67,&g_67,&g_211}},{{&l_2619,&g_212,&l_2470,&g_212},{&g_212,&g_67,(void*)0,&g_212},{(void*)0,&g_212,&g_211,&g_211},{&g_67,&g_67,&l_2470,&l_2619},{&g_67,&g_67,&g_211,&g_67},{(void*)0,&l_2619,(void*)0,&g_211}},{{&g_212,&l_2619,&l_2470,&g_67},{&l_2619,&g_67,&g_67,&l_2619},{(void*)0,&g_67,&g_67,&g_211},{&l_2619,&g_212,&l_2470,&g_212},{&g_212,&g_67,(void*)0,&g_212},{(void*)0,&g_212,&g_211,&g_211}},{{&g_67,&g_67,&l_2470,&l_2619},{&g_67,&g_67,&g_211,&g_67},{(void*)0,&l_2619,&g_212,&l_2613},{&g_211,&g_67,&g_67,(void*)0},{&g_67,&l_2470,&l_2470,&g_67},{&g_212,(void*)0,&l_2470,&l_2613}},{{&g_67,&g_211,&g_67,&g_211},{&g_211,&l_2470,&g_212,&g_211},{&g_212,&g_211,&l_2613,&l_2613},{(void*)0,(void*)0,&g_67,&g_67},{(void*)0,&l_2470,&l_2613,(void*)0},{&g_212,&g_67,&g_212,&l_2613}}};
                    int64_t **l_2666 = &g_2155;
                    uint8_t *l_2669 = &g_82;
                    uint8_t *****l_2677 = &g_2210;
                    int64_t *l_2678 = (void*)0;
                    int64_t *l_2679[4] = {&l_2483,&l_2483,&l_2483,&l_2483};
                    uint16_t ****l_2683[6][9][4] = {{{&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,(void*)0},{&g_947,&g_947,(void*)0,&g_947},{(void*)0,&g_947,(void*)0,&g_947},{(void*)0,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,&g_947},{(void*)0,&g_947,&g_947,(void*)0},{&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,(void*)0,&g_947}},{{&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,(void*)0,&g_947},{(void*)0,&g_947,&g_947,(void*)0},{&g_947,&g_947,(void*)0,&g_947}},{{&g_947,&g_947,(void*)0,&g_947},{(void*)0,&g_947,(void*)0,&g_947},{(void*)0,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{(void*)0,&g_947,&g_947,&g_947},{(void*)0,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,(void*)0}},{{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,(void*)0},{(void*)0,&g_947,&g_947,&g_947},{&g_947,&g_947,(void*)0,(void*)0},{&g_947,&g_947,&g_947,&g_947},{(void*)0,(void*)0,&g_947,(void*)0}},{{&g_947,(void*)0,(void*)0,&g_947},{&g_947,&g_947,(void*)0,&g_947},{&g_947,(void*)0,&g_947,&g_947},{&g_947,&g_947,(void*)0,(void*)0},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{(void*)0,(void*)0,&g_947,(void*)0},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,(void*)0,(void*)0}},{{&g_947,(void*)0,&g_947,&g_947},{&g_947,(void*)0,&g_947,&g_947},{(void*)0,&g_947,(void*)0,&g_947},{&g_947,&g_947,&g_947,(void*)0},{&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947},{&g_947,(void*)0,&g_947,(void*)0},{&g_947,&g_947,&g_947,(void*)0},{&g_947,(void*)0,(void*)0,&g_947}}};
                    uint16_t *****l_2685 = &l_2684[0][3];
                    int32_t *l_2695 = &g_48;
                    int i, j, k;
                    for (g_2616 = 6; (g_2616 >= 0); g_2616 -= 1)
                    { /* block id: 1231 */
                        union U1 ***l_2662 = &l_2660[1];
                        int i;
                        (*l_2662) = l_2660[4];
                        if (g_1480[g_2616])
                            continue;
                        l_2663[4][5][2] = (*g_1332);
                    }
                    for (g_2282.f2 = 0; g_2282.f2 < 10; g_2282.f2 += 1)
                    {
                        for (g_297 = 0; g_297 < 8; g_297 += 1)
                        {
                            l_2659[g_2282.f2][g_297] = 0x7BFFB87322D81C2DLL;
                        }
                    }
                    (*g_1330) &= (l_2607[3] , ((safe_mod_func_uint16_t_u_u((0xF2L && 0xABL), ((l_2490 = (((((*l_2666) = &l_2659[2][3]) != ((safe_lshift_func_uint8_t_u_s(((*l_2669) ^= (***g_2211)), 4)) , &l_2658[4][4][1])) , (l_2607[3] = (((****g_2210) || ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_u(((p_17 && (safe_add_func_uint16_t_u_u(((((*l_2677) = l_2676) != l_2676) > l_2470), 0x3D06L))) , l_2659[8][5]), (****g_1879))), l_2607[2])) && (-8L))) > l_2513[0][7][2]))) <= l_2534)) | p_17))) != p_17));
                    if ((((l_2682 != l_2683[5][4][0]) ^ (-1L)) < (((*l_2685) = l_2684[6][3]) != ((((((~(((safe_rshift_func_int8_t_s_u(((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_u(p_16, (safe_div_func_int16_t_s_s(((((**l_2565) = (**g_2210)) != (func_22(((*g_61) = l_2663[2][3][1]), l_2695, l_2696[1], g_1777.f1) , l_2697)) <= l_2513[1][3][3]), 1UL)))), l_2607[3])) <= 9L), l_2490)) < (*g_445)) & (*l_2695))) >= l_2534) , 0UL) || (*g_780)) || (**g_948)) , l_2682))))
                    { /* block id: 1246 */
                        (*g_61) = &l_2586;
                        (*l_2695) = ((g_2698 , ((g_2699 == &l_2682) >= p_16)) == l_2614);
                        (*g_61) = &l_2607[4];
                        if ((*g_62))
                            continue;
                    }
                    else
                    { /* block id: 1251 */
                        return l_2703;
                    }
                }
                if ((g_2704 , ((safe_mul_func_int16_t_s_s((*g_1672), ((l_2707[6] == ((*l_2708) = l_2559)) & ((safe_sub_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u(l_2614, 0x826330A3237C0BC5LL)) , ((1L < (p_17 && l_2621[1][0][5])) , p_16)), 9UL)) && 0x22FEL)))) , p_17)))
                { /* block id: 1256 */
                    uint32_t l_2715 = 0xEC821C75L;
                    for (g_117 = 0; (g_117 < 55); g_117 = safe_add_func_uint64_t_u_u(g_117, 2))
                    { /* block id: 1259 */
                        (*g_61) = &l_2607[3];
                        (**g_61) = (((**g_2112) != 0xA4D68258L) || p_16);
                        return p_17;
                    }
                    l_2715--;
                    if (l_2715)
                        continue;
                }
                else
                { /* block id: 1266 */
                    volatile int32_t *l_2720 = &g_274;
                    uint64_t ******l_2742 = &g_2117;
                    uint64_t *******l_2741 = &l_2742;
                    int64_t *l_2753 = &g_2330[0][3];
                    for (g_2282.f0 = 13; (g_2282.f0 >= 42); g_2282.f0 = safe_add_func_uint16_t_u_u(g_2282.f0, 4))
                    { /* block id: 1269 */
                        int32_t *l_2722 = &g_48;
                        l_2720 = (*g_272);
                        (*g_1330) = (((**l_2697) = (l_2721 <= 0xFEDEC0B913E92123LL)) == (-1L));
                        l_2723 = l_2722;
                        if ((*l_2722))
                            break;
                    }
                    (*g_1330) = (l_2513[1][3][1] = ((((safe_mul_func_int8_t_s_s((+(safe_mod_func_int16_t_s_s(((((*g_61) = l_2512[0][2]) != (*g_272)) < ((l_2729 = &g_947) != (*g_2699))), (safe_div_func_int8_t_s_s((l_2732 != &l_2571), (*g_1985)))))), (safe_div_func_uint64_t_u_u(((((0x83B648F1D9C005DBLL >= ((****l_2575) ^= 0xAD27CE31F70DFA86LL)) && 0xF1AE5059L) && p_17) , 4UL), p_16)))) && p_16) <= p_17) < 1UL));
                    (*g_1330) = ((p_17 && ((*g_445) = (safe_mod_func_int32_t_s_s((((*l_2753) = ((safe_lshift_func_uint16_t_u_s(65527UL, (safe_add_func_int16_t_s_s((((*l_2741) = &g_2117) == (void*)0), (((*g_1985) = l_2743) >= (((safe_lshift_func_int16_t_s_u(((l_2746 , (((l_2747 != 0x866361A5L) & (((((***l_2533) &= ((safe_div_func_uint32_t_u_u(((safe_div_func_int16_t_s_s((((l_2621[6][0][0] |= (**g_948)) != 0x81EFL) != l_2752[4][2]), 8L)) ^ 0L), p_17)) | p_16)) | 0x85EFL) , 3UL) < 0UL)) | p_16)) ^ 0xCCL), 12)) ^ l_2509) && p_17)))))) , 1L)) ^ p_16), p_16)))) == (-5L));
                }
                if (((*g_1330) = (safe_div_func_int16_t_s_s(((**l_2529) = (+0x1B148711L)), 1L))))
                { /* block id: 1291 */
                    int64_t l_2775 = 0x92E97B37DF5FCC09LL;
                    uint8_t ** const *l_2779 = &g_496[6][3][0];
                    uint8_t ** const **l_2778 = &l_2779;
                    uint8_t ** const *** const l_2777 = &l_2778;
                    for (g_2282.f0 = 0; (g_2282.f0 <= 4); g_2282.f0 += 1)
                    { /* block id: 1294 */
                        int8_t *l_2769[1];
                        uint8_t ***l_2774 = &l_2489;
                        int16_t *l_2776 = (void*)0;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_2769[i] = &g_840;
                        (*g_1330) = (safe_rshift_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(0x58L, (safe_rshift_func_int16_t_s_s((p_17 <= ((safe_mul_func_int8_t_s_s(((((safe_add_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((g_1774.f0 > ((void*)0 != &g_2700[3][2])), ((*****l_2777) = ((func_27(&l_2623, p_16) , &g_2210) == l_2777)))), p_17)) && p_17) >= l_2613) > 0x3EEF999CL), p_17)) | 18446744073709551615UL)), 1)))), 5));
                        if (p_16)
                            break;
                        (*g_1330) = 0x6E3D103FL;
                        (*g_61) = &l_2490;
                    }
                    if (l_2490)
                        continue;
                    l_2512[0][2] = (void*)0;
                }
                else
                { /* block id: 1305 */
                    for (g_933 = 28; (g_933 >= 14); --g_933)
                    { /* block id: 1308 */
                        int32_t *l_2782 = &l_2534;
                        (*g_61) = l_2782;
                        if (p_16)
                            continue;
                        l_2619 = 1L;
                    }
                }
            }
            else
            { /* block id: 1314 */
                uint8_t l_2783 = 0x4AL;
                int32_t l_2786[5];
                uint16_t l_2787 = 65531UL;
                int i;
                for (i = 0; i < 5; i++)
                    l_2786[i] = 0L;
                l_2783++;
                if (p_17)
                    break;
                --l_2787;
                if (l_2658[1][7][2])
                    break;
            }
        }
    }
    return l_2491[0][9];
}


/* ------------------------------------------ */
/* 
 * reads : g_272 g_188 g_189
 * writes: g_273
 */
static union U0  func_22(int32_t * p_23, int32_t * p_24, int8_t * p_25, int32_t  p_26)
{ /* block id: 1137 */
    int32_t l_2454 = 0x033A82ACL;
    int32_t *l_2455 = &g_583;
    int32_t *l_2456 = &g_67;
    int32_t *l_2457 = (void*)0;
    int32_t *l_2458 = &g_212;
    int32_t *l_2459 = (void*)0;
    int32_t *l_2460 = &g_39;
    int32_t l_2461 = (-6L);
    int32_t *l_2462[3];
    int32_t l_2463 = (-3L);
    uint64_t l_2464 = 0xCD495AF5C71B32FFLL;
    int i;
    for (i = 0; i < 3; i++)
        l_2462[i] = &g_212;
    (*g_272) = (void*)0;
    l_2464--;
    return (*g_188);
}


/* ------------------------------------------ */
/* 
 * reads : g_2087
 * writes:
 */
static union U1  func_27(int16_t * p_28, uint16_t  p_29)
{ /* block id: 745 */
    uint64_t ***l_1676 = &g_444;
    uint64_t ****l_1675 = &l_1676;
    uint64_t *****l_1674 = &l_1675;
    uint64_t ******l_1673 = &l_1674;
    int32_t l_1683[9];
    uint8_t **l_1684 = &g_497[2];
    int32_t l_1694 = (-10L);
    int16_t l_1706 = 6L;
    uint32_t l_1711 = 0x3C10729AL;
    uint32_t l_1762 = 0xAAAD393EL;
    int32_t l_1773 = 1L;
    uint32_t l_1851 = 0xC977852BL;
    volatile int32_t *l_1979[5][7] = {{&g_42,&g_274,&g_274,&g_42,&g_274,&g_274,&g_42},{(void*)0,&g_46[1],(void*)0,(void*)0,&g_64,(void*)0,(void*)0},{&g_42,&g_42,&g_44[2],&g_42,&g_42,&g_44[2],&g_42},{&g_64,(void*)0,(void*)0,&g_46[1],(void*)0,(void*)0,&g_64},{&g_274,&g_42,&g_274,&g_274,&g_42,&g_274,&g_274}};
    int8_t **l_1982 = (void*)0;
    uint64_t *l_2002 = &g_1914;
    const union U0 *l_2023 = &g_165;
    const union U0 **l_2022 = &l_2023;
    const union U0 ***l_2021 = &l_2022;
    int64_t l_2047 = 0L;
    uint8_t l_2048 = 246UL;
    union U1 *l_2086 = &g_2087;
    const uint16_t *l_2142 = (void*)0;
    const uint16_t **l_2141[9] = {&l_2142,&l_2142,&l_2142,&l_2142,&l_2142,&l_2142,&l_2142,&l_2142,&l_2142};
    const uint16_t ***l_2140 = &l_2141[0];
    const uint16_t ****l_2139 = &l_2140;
    uint8_t ***l_2206 = &g_496[0][0][0];
    uint8_t ****l_2205 = &l_2206;
    const uint8_t l_2213 = 1UL;
    int64_t l_2221 = 7L;
    int64_t l_2225[5] = {8L,8L,8L,8L,8L};
    uint32_t **l_2228 = &g_780;
    int16_t l_2232 = 0x826AL;
    int32_t * const l_2452 = (void*)0;
    int i, j;
    for (i = 0; i < 9; i++)
        l_1683[i] = (-4L);
    return (*l_2086);
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_48 g_445 g_215 g_212 g_66 g_780 g_297 g_61 g_62 g_493 g_494 g_495 g_944 g_945 g_124 g_10 g_1330 g_211 g_1495 g_327 g_1601 g_943 g_272 g_273 g_188 g_189 g_1332 g_840 g_1110.f0 g_583 g_496 g_497 g_238 g_328 g_1273 g_1667 g_1672
 * writes: g_39 g_48 g_215 g_66 g_297 g_792 g_211 g_327 g_274 g_109 g_124 g_161 g_1110.f0 g_238 g_62 g_1644 g_328
 */
static int16_t * func_30(int8_t * p_31, int32_t * p_32, uint32_t  p_33, int16_t * p_34)
{ /* block id: 13 */
    int16_t l_1604 = 0L;
    uint8_t ***l_1606 = &g_496[1][2][0];
    uint8_t ****l_1605 = &l_1606;
    int32_t l_1617 = 9L;
    int32_t l_1619 = 0x3D96B486L;
    int32_t l_1622[9][4] = {{(-1L),0x9730220AL,(-1L),(-5L)},{8L,4L,(-5L),0x56EC9AF5L},{(-5L),0x56EC9AF5L,0x4A08DF1DL,0x56EC9AF5L},{0xB86738CCL,4L,5L,(-5L)},{0xD6251BDFL,0x9730220AL,0x56EC9AF5L,(-2L)},{5L,0xB86738CCL,(-1L),(-1L)},{5L,5L,0x56EC9AF5L,(-1L)},{0xD6251BDFL,(-1L),5L,0x9730220AL},{0xB86738CCL,8L,0x4A08DF1DL,5L}};
    int64_t l_1634 = 0xC8A0BA805C8D722DLL;
    uint8_t l_1640 = 255UL;
    uint64_t * const ***l_1646 = &g_1645;
    union U1 *l_1670 = &g_1671;
    union U1 **l_1669 = &l_1670;
    int i, j;
    (**g_272) = (func_36(p_32, p_34) , (safe_mod_func_uint64_t_u_u(((((safe_rshift_func_int16_t_s_u(((*g_1495) &= p_33), 15)) != 0x35869EC1L) < ((((g_1601 , ((((((safe_rshift_func_int16_t_s_s(l_1604, ((p_33 == l_1604) > l_1604))) && (***g_943)) < 18446744073709551615UL) , (*g_780)) == (*p_32)) , l_1605)) == &l_1606) > p_33) & l_1604)) , l_1604), 0xC5764DEA79F2B502LL)));
    for (g_215 = 0; (g_215 < 53); ++g_215)
    { /* block id: 698 */
        int16_t l_1618 = 0xF433L;
        int32_t l_1620 = 0xE49DC545L;
        int32_t l_1621 = (-9L);
        uint64_t l_1623 = 1UL;
        int32_t l_1638 = 0xA1A3DA5DL;
        int32_t l_1639 = (-1L);
        uint64_t * const ****l_1643[1];
        int64_t * const l_1657 = (void*)0;
        int i;
        for (i = 0; i < 1; i++)
            l_1643[i] = (void*)0;
        for (g_109 = 11; (g_109 != 11); ++g_109)
        { /* block id: 701 */
            int32_t *l_1611 = &g_39;
            int32_t *l_1612 = &g_39;
            int32_t *l_1613 = &g_161;
            int32_t *l_1614 = &g_583;
            int64_t l_1615 = (-1L);
            int32_t *l_1616[4][6] = {{&g_39,&g_583,&g_39,&g_39,&g_583,&g_39},{&g_39,&g_583,&g_39,&g_39,&g_583,&g_39},{&g_39,&g_583,&g_39,&g_39,&g_583,&g_39},{&g_39,&g_583,&g_39,&g_39,&g_583,&g_39}};
            int64_t *l_1633 = (void*)0;
            uint32_t *l_1635 = &g_1110[3][1].f0;
            int i, j;
            l_1623++;
            l_1617 ^= (l_1621 |= (((*g_188) , (((safe_mod_func_uint16_t_u_u((((*g_1495) = (((****l_1605) |= ((((*g_945) = 3UL) | 0xF95EL) && (safe_mul_func_uint16_t_u_u((((*l_1635) &= ((((*g_780)--) , p_33) , ((((!((((**g_61) && ((((p_33 <= ((*l_1613) = (p_33 <= (**g_1332)))) != 0x93505251645C891DLL) ^ (***g_943)) != l_1618)) >= 4294967289UL) != 0UL)) && g_840) ^ l_1634) , l_1622[7][1]))) , (*l_1614)), (**g_944))))) > 248UL)) | p_33), 0xC39BL)) | g_211) | p_33)) , l_1620));
            for (g_66 = 0; (g_66 >= (-12)); g_66 = safe_sub_func_uint16_t_u_u(g_66, 1))
            { /* block id: 713 */
                (*g_61) = p_32;
            }
            --l_1640;
        }
        (*g_273) = (l_1620 = ((*g_1330) = ((g_1644 = (void*)0) == l_1646)));
        for (l_1617 = 6; (l_1617 > (-19)); --l_1617)
        { /* block id: 724 */
            uint32_t l_1666[1][10][8] = {{{0x3FDD9A5BL,0xB0D71704L,0x159FD3F1L,0x159FD3F1L,0xB0D71704L,0x3FDD9A5BL,18446744073709551614UL,0x3FDD9A5BL},{0xB0D71704L,0x3FDD9A5BL,18446744073709551614UL,0x3FDD9A5BL,0xB0D71704L,0x159FD3F1L,18446744073709551614UL,0x159FD3F1L},{0xEE0E6876L,0xB0D71704L,0xB0D71704L,0xEE0E6876L,0UL,0x159FD3F1L,0UL,0xEE0E6876L},{0xB0D71704L,0UL,0xB0D71704L,18446744073709551614UL,0xB851EFA7L,0xB851EFA7L,18446744073709551614UL,0xB0D71704L},{0UL,0UL,0xB851EFA7L,0x159FD3F1L,0x3FDD9A5BL,0x159FD3F1L,0xB851EFA7L,0UL},{0UL,0xB0D71704L,18446744073709551614UL,0xB851EFA7L,0xB851EFA7L,18446744073709551614UL,0xB0D71704L,0UL},{0xB0D71704L,0xEE0E6876L,0UL,0x159FD3F1L,0UL,0xEE0E6876L,0xB0D71704L,0xB0D71704L},{0xEE0E6876L,0x159FD3F1L,18446744073709551614UL,18446744073709551614UL,0x159FD3F1L,0xEE0E6876L,0xB851EFA7L,0xEE0E6876L},{0x159FD3F1L,0xEE0E6876L,0xB851EFA7L,0xEE0E6876L,0x159FD3F1L,18446744073709551614UL,18446744073709551614UL,0x159FD3F1L},{0xEE0E6876L,0xB0D71704L,0xB0D71704L,0xEE0E6876L,0UL,0x159FD3F1L,0UL,0xEE0E6876L}}};
            int i, j, k;
            for (g_48 = 22; (g_48 >= 9); g_48 = safe_sub_func_int8_t_s_s(g_48, 1))
            { /* block id: 727 */
                for (l_1619 = 0; (l_1619 <= 3); l_1619 += 1)
                { /* block id: 730 */
                    int32_t l_1665 = 0xCFF4B8E9L;
                    for (g_328 = 0; (g_328 <= 3); g_328 += 1)
                    { /* block id: 733 */
                        int i, j;
                        (*g_1330) &= (((void*)0 == &p_31) & ((safe_mod_func_int32_t_s_s(l_1622[(l_1619 + 4)][l_1619], (6UL ^ ((((safe_lshift_func_int16_t_s_u(((((****l_1605) = (((p_33 , (l_1657 != &g_1084)) == (safe_lshift_func_int16_t_s_u((-5L), 2))) > ((safe_sub_func_uint64_t_u_u((+(((safe_sub_func_int32_t_s_s((l_1665 != p_33), p_33)) , p_33) & (-1L))), l_1666[0][0][0])) || g_1273))) && l_1665) ^ 1UL), 13)) , g_1601) , g_1667) != l_1669)))) > p_33));
                        if (l_1666[0][0][0])
                            continue;
                    }
                    if ((*p_32))
                        continue;
                }
                return p_34;
            }
        }
    }
    return g_1672;
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_48 g_445 g_215 g_212 g_66 g_780 g_297 g_61 g_62 g_493 g_494 g_495 g_944 g_945 g_124 g_10 g_1330 g_211
 * writes: g_39 g_48 g_215 g_66 g_297 g_792 g_211
 */
static int32_t  func_36(int32_t * p_37, int16_t * p_38)
{ /* block id: 14 */
    int32_t *l_60 = &g_39;
    int8_t *l_1323[1][3][8] = {{{&g_3,&g_837,&g_3,&g_837,&g_3,&g_3,&g_837,&g_3},{&g_3,&g_3,&g_837,&g_3,&g_837,&g_3,&g_3,&g_837},{(void*)0,&g_837,&g_837,(void*)0,&g_3,(void*)0,&g_837,&g_837}}};
    int32_t l_1360 = 0xA19A392AL;
    int32_t l_1361 = (-5L);
    int32_t l_1362[4];
    int32_t *l_1363 = &l_1362[2];
    int32_t *l_1364 = &g_66;
    int32_t *l_1365 = &g_212;
    int32_t *l_1366 = (void*)0;
    int32_t *l_1367[2];
    int8_t l_1368[3][10][2] = {{{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L}},{{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L}},{{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L},{0x28L,0x28L}}};
    int64_t l_1370 = (-3L);
    int8_t l_1371 = (-1L);
    uint32_t l_1372 = 0xB35A88DBL;
    uint8_t l_1431 = 249UL;
    const uint32_t l_1467[10][5] = {{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,4294967291UL,0x6950BCD8L,0x6950BCD8L,4294967291UL},{0xD950D764L,0x6CF253E9L,4294967291UL,4294967291UL,0x6CF253E9L},{0UL,0x6CF253E9L,4294967291UL,4294967291UL,0x6CF253E9L}};
    int32_t l_1520[9][5] = {{(-1L),0xFE137A18L,(-5L),0xB4EC3C2FL,0L},{0xC9AC058EL,0x6566C85FL,0xDB9947AFL,0xDB9947AFL,0x6566C85FL},{(-1L),0xFE137A18L,(-5L),0xB4EC3C2FL,0L},{0xC9AC058EL,0x6566C85FL,0xDB9947AFL,0xDB9947AFL,0x6566C85FL},{(-1L),0xFE137A18L,(-5L),0xB4EC3C2FL,0L},{0xC9AC058EL,0x6566C85FL,0xDB9947AFL,0xDB9947AFL,0x6566C85FL},{(-1L),0xFE137A18L,(-5L),0xB4EC3C2FL,0L},{0xC9AC058EL,0x6566C85FL,0xDB9947AFL,0xDB9947AFL,0x6566C85FL},{(-1L),0xFE137A18L,(-5L),0xB4EC3C2FL,0L}};
    uint8_t l_1524 = 0xD8L;
    union U1 *l_1562 = &g_1110[3][1];
    uint64_t ***l_1575 = &g_444;
    uint32_t *l_1595 = &g_792;
    int8_t l_1596 = 0x56L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1362[i] = 1L;
    for (i = 0; i < 2; i++)
        l_1367[i] = &g_212;
    for (g_39 = (-26); (g_39 > 15); g_39++)
    { /* block id: 17 */
        uint64_t l_1327 = 0x25D7020A919DD23ELL;
        for (g_48 = 0; (g_48 >= (-26)); g_48 = safe_sub_func_int16_t_s_s(g_48, 8))
        { /* block id: 20 */
            int8_t **l_1324 = &l_1323[0][0][0];
            int8_t *l_1326 = (void*)0;
            int8_t **l_1325 = &l_1326;
            int32_t ***l_1359[5];
            int i;
            for (i = 0; i < 5; i++)
                l_1359[i] = &g_61;
        }
    }
    l_1372--;
    for (l_1360 = 0; (l_1360 != (-14)); l_1360 = safe_sub_func_int64_t_s_s(l_1360, 9))
    { /* block id: 581 */
        uint64_t l_1383 = 0x7D2118ADF626FC67LL;
        uint64_t ***l_1422 = (void*)0;
        uint64_t **** const l_1421 = &l_1422;
        int32_t l_1476 = (-1L);
        int32_t * const *l_1489[4];
        int32_t *l_1548[4] = {&g_48,&g_48,&g_48,&g_48};
        int i;
        for (i = 0; i < 4; i++)
            l_1489[i] = (void*)0;
    }
    (*g_1330) ^= ((!(safe_lshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u((--(*g_445)), (((safe_lshift_func_uint8_t_u_s((l_1575 == l_1575), 1)) , ((0x6CL | ((safe_mod_func_uint32_t_u_u((((*l_1364) = (safe_div_func_uint64_t_u_u((*l_1365), (*l_1364)))) ^ (*l_1365)), ((*l_1595) = (safe_mod_func_int32_t_s_s(((safe_sub_func_int32_t_s_s((((*l_60) , (safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s((((safe_div_func_uint32_t_u_u((((safe_mod_func_int64_t_s_s(((safe_unary_minus_func_int64_t_s((((*g_780) ^= (safe_lshift_func_uint8_t_u_u((*l_1363), 4))) == ((l_1575 = l_1575) != (void*)0)))) & (*l_1365)), (*l_1363))) , (*l_60)) , (*l_1363)), 0x35931262L)) , (void*)0) != (void*)0), 11)), 0x07A989BCE1F0EE51LL))) >= (*l_1363)), 0x161A5E74L)) | (**g_61)), (**g_61)))))) > (**g_493))) & 4294967293UL)) > (*l_1363)))), (**g_944)))) , (*p_37));
    return l_1596;
}


/* ------------------------------------------ */
/* 
 * reads : g_61 g_62 g_944 g_945 g_124 g_943 g_780 g_1332 g_1330 g_211 g_327 g_273 g_117
 * writes: g_297 g_62 g_1330 g_211 g_274
 */
static int32_t ** func_51(int16_t * p_52, int8_t * p_53, uint32_t  p_54)
{ /* block id: 562 */
    int64_t l_1328 = 0x1D020CBBF9DFDE96LL;
    const uint64_t *l_1342 = &g_215;
    const uint64_t **l_1341 = &l_1342;
    const uint64_t ***l_1340[2];
    uint32_t **l_1351[1][8] = {{(void*)0,&g_780,&g_780,(void*)0,&g_780,&g_780,(void*)0,&g_780}};
    uint32_t ***l_1350 = &l_1351[0][3];
    uint16_t ****l_1357[4] = {&g_947,&g_947,&g_947,&g_947};
    int32_t **l_1358[8][7] = {{&g_1330,&g_62,(void*)0,&g_1330,&g_62,&g_62,&g_1330},{&g_1330,(void*)0,&g_1330,(void*)0,&g_62,(void*)0,&g_1330},{&g_1330,&g_1330,&g_1330,&g_1330,&g_1330,&g_1330,&g_1330},{&g_1330,(void*)0,&g_62,(void*)0,&g_62,(void*)0,&g_1330},{&g_62,&g_1330,(void*)0,(void*)0,&g_1330,&g_62,(void*)0},{&g_62,(void*)0,&g_62,(void*)0,&g_62,&g_62,&g_62},{&g_1330,(void*)0,(void*)0,&g_1330,&g_62,(void*)0,&g_1330},{&g_62,(void*)0,&g_62,(void*)0,&g_1330,(void*)0,&g_62}};
    int i, j;
    for (i = 0; i < 2; i++)
        l_1340[i] = &l_1341;
    if (p_54)
    { /* block id: 563 */
        int32_t *l_1333 = &g_211;
        (*g_1332) = ((*g_61) = ((p_54 != ((&g_384[0][1] == &g_384[3][0]) , ((*g_780) = (((l_1328 == ((void*)0 != (*g_61))) != 0L) <= ((((**g_944) && ((((void*)0 == p_52) , (void*)0) != (*g_943))) , &g_497[3]) != &g_497[1]))))) , (void*)0));
        (*g_61) = l_1333;
    }
    else
    { /* block id: 568 */
        const uint64_t ****l_1343 = &l_1340[0];
        int32_t l_1352 = (-1L);
        uint16_t ****l_1356 = (void*)0;
        (*g_273) = ((safe_add_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(l_1328, (safe_add_func_int64_t_s_s((((*l_1343) = l_1340[0]) != &g_444), (safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((p_54 && ((l_1350 != &g_387) >= ((p_54 , l_1352) & (((safe_add_func_int16_t_s_s((safe_unary_minus_func_int32_t_s(((*g_1330) |= (l_1328 || p_54)))), 0L)) <= l_1352) & 0x8C5DL)))) && p_54), 5)), (*p_52))))))), 0x082EDECFL)) < p_54);
        (*g_1330) = (g_117 <= (l_1356 != l_1357[0]));
    }
    return l_1358[5][5];
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_67 g_66 g_39 g_452 g_780 g_297 g_157 g_445 g_215 g_439 g_327 g_272 g_273 g_82 g_61 g_62 g_583 g_948 g_945 g_124 g_63 g_274 g_444 g_1067 g_161 g_1084 g_117 g_211
 * writes: g_66 g_67 g_82 g_934 g_840 g_215 g_212 g_327 g_46 g_44 g_62 g_274 g_124 g_297 g_161 g_273 g_119
 */
static int16_t * func_55(int32_t * p_56, uint16_t  p_57, uint32_t  p_58, int32_t ** p_59)
{ /* block id: 21 */
    int8_t **l_1068 = (void*)0;
    uint8_t l_1071 = 1UL;
    uint32_t l_1073[4][10][4] = {{{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL}},{{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL}},{{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL}},{{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL},{7UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,18446744073709551615UL,0xEA545069L,0UL}}};
    uint32_t **l_1090 = &g_780;
    int32_t l_1247 = 0x0947600CL;
    const int16_t **l_1248 = (void*)0;
    const uint32_t *l_1304 = (void*)0;
    const uint32_t **l_1303[3][8][7] = {{{&l_1304,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_1304,(void*)0,&l_1304,&l_1304,&l_1304,(void*)0},{&l_1304,(void*)0,(void*)0,&l_1304,&l_1304,(void*)0,(void*)0},{(void*)0,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,(void*)0},{(void*)0,&l_1304,(void*)0,(void*)0,&l_1304,(void*)0,(void*)0},{&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304},{&l_1304,(void*)0,(void*)0,&l_1304,(void*)0,(void*)0,(void*)0},{&l_1304,&l_1304,&l_1304,&l_1304,(void*)0,&l_1304,&l_1304}},{{&l_1304,&l_1304,(void*)0,(void*)0,&l_1304,&l_1304,(void*)0},{&l_1304,&l_1304,(void*)0,&l_1304,(void*)0,&l_1304,&l_1304},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1304,(void*)0,(void*)0},{(void*)0,&l_1304,&l_1304,&l_1304,(void*)0,&l_1304,(void*)0},{&l_1304,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_1304,(void*)0,&l_1304,(void*)0,&l_1304,&l_1304},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304}},{{&l_1304,(void*)0,(void*)0,(void*)0,(void*)0,&l_1304,(void*)0},{(void*)0,&l_1304,&l_1304,&l_1304,(void*)0,&l_1304,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1304,(void*)0,(void*)0},{&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_1304,(void*)0},{(void*)0,&l_1304,&l_1304,&l_1304,&l_1304,&l_1304,(void*)0},{&l_1304,(void*)0,(void*)0,&l_1304,(void*)0,(void*)0,(void*)0},{&l_1304,&l_1304,(void*)0,&l_1304,&l_1304,&l_1304,&l_1304}}};
    int16_t *l_1322 = &g_327;
    int i, j, k;
    for (p_57 = 0; (p_57 <= 7); p_57 += 1)
    { /* block id: 24 */
        int32_t l_1018 = (-1L);
        uint8_t *l_1025 = &g_82;
        int64_t l_1098[8][8] = {{(-8L),(-10L),0x53A441A250FC9393LL,(-1L),0x5E71E29DD1885BECLL,(-1L),0x53A441A250FC9393LL,(-10L)},{(-10L),(-10L),1L,0x53A441A250FC9393LL,0L,9L,0x3D0E9735EACB226CLL,0x3D0E9735EACB226CLL},{1L,(-10L),0x578D0F41BA380019LL,0x578D0F41BA380019LL,(-10L),1L,0x3D0E9735EACB226CLL,0x5E71E29DD1885BECLL},{8L,0x578D0F41BA380019LL,1L,9L,0x53A441A250FC9393LL,(-8L),0x53A441A250FC9393LL,9L},{0x53A441A250FC9393LL,(-8L),0x53A441A250FC9393LL,9L,1L,0x578D0F41BA380019LL,8L,0x5E71E29DD1885BECLL},{0x3D0E9735EACB226CLL,1L,(-10L),0x578D0F41BA380019LL,0x578D0F41BA380019LL,(-10L),1L,0x3D0E9735EACB226CLL},{0x3D0E9735EACB226CLL,9L,0L,0x53A441A250FC9393LL,1L,(-10L),(-10L),(-10L)},{0x53A441A250FC9393LL,(-1L),0x5E71E29DD1885BECLL,(-1L),0x53A441A250FC9393LL,(-10L),(-8L),1L}};
        int32_t l_1195 = 9L;
        const int8_t l_1236[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int16_t ** const l_1243 = (void*)0;
        int32_t *l_1295 = &g_48;
        int32_t l_1312 = (-1L);
        int i, j;
        if (g_46[p_57])
            break;
        for (p_58 = 1; (p_58 <= 7); p_58 += 1)
        { /* block id: 28 */
            uint32_t l_1000[8] = {0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL,0xA3B4CB1CL};
            int32_t l_1008 = 0x6B05ADBAL;
            int16_t *l_1036 = &g_327;
            uint32_t **l_1109 = &g_546;
            uint64_t ***l_1124 = (void*)0;
            uint8_t ***l_1174 = &g_496[5][2][1];
            uint16_t ***l_1179 = &g_948;
            int32_t l_1196[4][8] = {{0xD1A48EF3L,(-7L),(-7L),0xD1A48EF3L,(-4L),0xD1A48EF3L,(-7L),(-7L)},{(-7L),(-4L),1L,1L,(-4L),(-7L),(-4L),1L},{0xD1A48EF3L,(-4L),0xD1A48EF3L,(-7L),(-7L),0xD1A48EF3L,(-4L),0xD1A48EF3L},{0L,(-7L),1L,(-7L),0L,0L,(-7L),1L}};
            uint32_t * const *l_1302 = (void*)0;
            int32_t l_1314 = 0x19707CD3L;
            int i, j;
            for (g_66 = 3; (g_66 >= 0); g_66 -= 1)
            { /* block id: 31 */
                volatile int32_t *l_1001 = (void*)0;
                int32_t l_1019 = 9L;
                uint64_t *l_1096 = &g_215;
                int32_t *l_1141 = &g_67;
                int i;
                for (g_67 = 3; (g_67 >= 0); g_67 -= 1)
                { /* block id: 34 */
                    uint8_t *l_81 = &g_82;
                    const uint32_t l_978 = 0x963F372EL;
                    int16_t *l_999 = &g_327;
                    uint32_t *l_1077 = &g_553[4][1];
                    int32_t l_1097[4][9][6] = {{{1L,2L,1L,9L,2L,2L},{1L,0x87308566L,0x87308566L,1L,0x48CA5357L,9L},{9L,1L,2L,1L,9L,0xF6B54497L},{1L,9L,0xF6B54497L,0xF6B54497L,9L,1L},{0x87308566L,1L,0x48CA5357L,9L,0x48CA5357L,1L},{0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L,0xF6B54497L},{0x48CA5357L,0x48CA5357L,2L,9L,5L,9L},{0x87308566L,0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L},{1L,0x87308566L,0x87308566L,1L,0x48CA5357L,9L}},{{9L,1L,2L,1L,9L,0xF6B54497L},{1L,9L,0xF6B54497L,0xF6B54497L,9L,1L},{0x87308566L,1L,0x48CA5357L,9L,0x48CA5357L,1L},{0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L,0xF6B54497L},{0x48CA5357L,0x48CA5357L,2L,9L,5L,9L},{0x87308566L,0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L},{1L,0x87308566L,0x87308566L,1L,0x48CA5357L,9L},{9L,1L,2L,1L,9L,0xF6B54497L},{1L,9L,0xF6B54497L,0xF6B54497L,9L,1L}},{{0x87308566L,1L,0x48CA5357L,9L,0x48CA5357L,1L},{0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L,0xF6B54497L},{0x48CA5357L,0x48CA5357L,2L,9L,5L,9L},{0x87308566L,0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L},{1L,0x87308566L,0x87308566L,1L,0x48CA5357L,9L},{9L,1L,2L,1L,9L,0xF6B54497L},{1L,9L,0xF6B54497L,0xF6B54497L,9L,1L},{0x87308566L,1L,0x48CA5357L,9L,0x48CA5357L,1L},{0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L,0xF6B54497L}},{{0x48CA5357L,0x48CA5357L,2L,9L,5L,9L},{0x87308566L,0x48CA5357L,0x87308566L,0xF6B54497L,2L,2L},{1L,0x87308566L,0x87308566L,1L,0x48CA5357L,9L},{9L,1L,2L,1L,9L,0xF6B54497L},{1L,9L,0xF6B54497L,0xF6B54497L,9L,1L},{0x87308566L,1L,0x48CA5357L,0xF6B54497L,5L,0x87308566L},{5L,9L,2L,0x48CA5357L,0x48CA5357L,2L},{5L,5L,0x48CA5357L,0xF6B54497L,1L,0xF6B54497L},{9L,5L,9L,2L,0x48CA5357L,0x48CA5357L}}};
                    int i, j, k;
                    if ((safe_sub_func_uint32_t_u_u(g_46[(g_67 + 4)], (g_67 <= (((*l_999) ^= (safe_lshift_func_uint8_t_u_u(((((3L ^ 0L) ^ (((0x64L < p_58) <= p_57) | (safe_add_func_uint16_t_u_u(func_74(((p_57 == ((func_76((p_59 = ((safe_mod_func_uint8_t_u_u(((((*l_81) = g_66) >= g_67) < g_39), 0x9EL)) , &g_62)), g_66) < 0x27L) & 0xB43AA74AL)) , l_978)), g_439)))) , (-2L)) && 1UL), 1))) || l_1000[2])))))
                    { /* block id: 432 */
                        int i;
                        g_46[(g_67 + 1)] |= ((void*)0 == (*g_272));
                        g_44[g_67] = (p_58 <= g_82);
                        l_1001 = (*g_272);
                        (*g_61) = (*g_61);
                    }
                    else
                    { /* block id: 437 */
                        (**g_272) = ((void*)0 == (*p_59));
                    }
                    if ((p_57 && (safe_rshift_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((g_583 > ((l_1008 |= 3L) , p_57)) <= g_46[p_57]), (0xC4645EA6L & (0x0EB7B45184328EF3LL || (safe_rshift_func_uint16_t_u_u((++(**g_948)), 15)))))), (safe_sub_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u((l_1018 = p_58))), (p_57 && l_1019))), g_39)))), 9))))
                    { /* block id: 443 */
                        uint32_t l_1024 = 0x0AB94229L;
                        g_46[p_57] = (safe_div_func_uint64_t_u_u((((*g_780) = (safe_mul_func_uint8_t_u_u(l_1024, 0xFEL))) != ((void*)0 == l_1025)), ((p_57 && (0xE3A649A3715511A8LL == (safe_sub_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(p_58, p_57)), l_1018)), (-8L))), g_63[2])))) , 18446744073709551607UL)));
                        return l_1036;
                    }
                    else
                    { /* block id: 447 */
                        int32_t *l_1072 = (void*)0;
                        (*g_273) = (safe_mod_func_uint8_t_u_u(((*l_81) = (safe_add_func_int16_t_s_s(((((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(((safe_add_func_uint8_t_u_u((safe_add_func_int32_t_s_s(((safe_add_func_int32_t_s_s((**g_272), (safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(((safe_rshift_func_uint16_t_u_s((safe_div_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(0xFF89AB7CL, (g_161 &= (((safe_mul_func_uint8_t_u_u(((1L || 0x32L) < (safe_unary_minus_func_uint64_t_u((**g_444)))), (+((g_1067 == l_1068) & ((safe_lshift_func_uint16_t_u_s((0xE1CFL <= ((l_978 & 5L) , l_978)), l_1071)) > l_1000[2]))))) || 1UL) & (**g_444))))), p_58)), p_57)) , 4UL), 12)), 0UL)))) == p_57), 0xFA66FBA6L)), p_57)) > p_58), 2)), l_1008)), 8)) ^ 0UL) != g_327) == (*g_780)), 0UL))), 255UL));
                        (**g_272) = 0xD98552ACL;
                        (**g_272) &= l_1073[2][2][1];
                        l_1098[6][3] = ((((*g_61) == ((safe_mod_func_uint32_t_u_u((+(l_1077 == (void*)0)), (safe_div_func_uint16_t_u_u((safe_add_func_int32_t_s_s((safe_mod_func_uint64_t_u_u(((g_1084 && (safe_unary_minus_func_int32_t_s((safe_mul_func_int32_t_s_s((safe_lshift_func_int8_t_s_u((l_1090 != (void*)0), 6)), ((safe_mul_func_uint8_t_u_u(((*l_1025) &= ((!(((safe_sub_func_uint8_t_u_u(((-1L) > ((l_1097[3][2][2] &= ((void*)0 != l_1096)) != 1UL)), 0UL)) || p_58) ^ l_1073[3][4][1])) , l_1097[3][2][2])), 255UL)) > p_58)))))) && g_46[(g_67 + 4)]), g_117)), 0xBB083750L)), p_57)))) , (void*)0)) >= p_57) <= 0x8238FD62DA1D63CALL);
                    }
                    for (g_161 = 0; (g_161 < (-25)); --g_161)
                    { /* block id: 459 */
                        uint32_t l_1121 = 7UL;
                        uint16_t l_1122 = 0xDBBDL;
                        int32_t l_1123 = (-1L);
                        (*g_272) = (*g_272);
                    }
                }
                l_1008 &= ((*l_1141) = (((void*)0 != l_1124) < (safe_add_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_s((safe_div_func_int8_t_s_s(((g_46[(g_66 + 2)] == (safe_sub_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u(0UL, ((safe_div_func_uint64_t_u_u((l_1018 & l_1018), (((safe_rshift_func_uint16_t_u_s(((void*)0 != &g_388), ((*l_1036) = 0xCA87L))) ^ 0UL) , l_1019))) || p_57))) | (*g_780)), l_1018))) , p_57), p_57)), l_1098[4][3])) | (-1L)), (**g_61))), 0x12CDL))));
                (**g_272) = (*g_62);
            }
            for (g_119 = 0; (g_119 <= 7); g_119 += 1)
            { /* block id: 476 */
                int32_t *l_1142 = &g_67;
                int16_t *l_1170 = &g_1110[3][1].f2;
                int64_t *l_1180 = &g_325;
                uint8_t ***l_1194 = (void*)0;
                uint8_t ****l_1193 = &l_1194;
                int32_t l_1255 = 6L;
                int i;
                g_46[p_57] = ((*l_1142) |= (-1L));
            }
            return l_1036;
        }
    }
    return l_1322;
}


/* ------------------------------------------ */
/* 
 * reads : g_452 g_780 g_297 g_157 g_445 g_215
 * writes: g_934 g_840 g_215 g_212
 */
static uint16_t  func_74(const uint32_t  p_75)
{ /* block id: 424 */
    int64_t l_996 = 1L;
    int64_t *l_997 = &g_934;
    int32_t l_998 = 1L;
    g_212 = (l_998 = (safe_add_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_mul_func_int16_t_s_s(g_452, p_75)) <= ((safe_unary_minus_func_uint64_t_u(((*g_445) = (((((g_840 = (safe_add_func_int64_t_s_s(p_75, (safe_mul_func_uint8_t_u_u(p_75, ((safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u((safe_sub_func_int16_t_s_s(((*g_780) < p_75), 1UL)), 0x464AD80FL)), (((*l_997) = l_996) >= 0x671F015D793B464ELL))) >= p_75)))))) > p_75) <= 0x59C6L) < g_157[1][5]) | l_996)))) < (*g_780))), l_996)) , (*g_445)), p_75)));
    return l_996;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_76(int32_t ** p_77, uint16_t  p_78)
{ /* block id: 37 */
    uint32_t *l_98 = &g_99;
    uint32_t *l_102[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_104[9];
    uint8_t *l_107 = &g_82;
    int64_t *l_108 = &g_109;
    int32_t l_110 = 8L;
    const int64_t l_111 = 2L;
    uint64_t *l_112 = &g_113;
    int32_t l_114 = 0x9BCD9968L;
    uint32_t *l_115 = (void*)0;
    uint32_t *l_116 = &g_117;
    uint8_t *l_118[7] = {&g_82,&g_82,&g_82,&g_82,&g_82,&g_82,&g_82};
    int32_t *l_120 = &l_110;
    union U0 *l_185 = &g_186[0];
    uint16_t *l_236 = (void*)0;
    int32_t *l_390 = &g_212;
    uint8_t **l_505 = &l_118[5];
    const uint8_t l_597[4][10][6] = {{{255UL,2UL,0xEDL,0x85L,1UL,0x74L},{0xA2L,0x85L,253UL,1UL,1UL,253UL},{2UL,2UL,0xCDL,7UL,255UL,0x74L},{2UL,7UL,0x18L,1UL,0xA2L,0xCDL},{0xA2L,2UL,0x18L,0x85L,2UL,0x74L},{255UL,0x85L,0xCDL,1UL,2UL,253UL},{1UL,2UL,253UL,7UL,0xA2L,0x74L},{1UL,7UL,0xEDL,1UL,255UL,0xCDL},{255UL,2UL,0xEDL,0x85L,1UL,0x74L},{0xA2L,0x85L,253UL,1UL,1UL,253UL}},{{2UL,2UL,0xCDL,7UL,255UL,0x74L},{2UL,7UL,0x18L,1UL,0xA2L,0xCDL},{0xA2L,2UL,0x18L,0x85L,2UL,0x74L},{255UL,0x85L,0xCDL,1UL,2UL,253UL},{1UL,2UL,253UL,7UL,0xA2L,0x74L},{1UL,7UL,0xEDL,1UL,255UL,0xCDL},{255UL,2UL,0xEDL,0x85L,1UL,0x74L},{0xA2L,0x85L,253UL,1UL,1UL,253UL},{2UL,2UL,0xCDL,7UL,255UL,0x74L},{2UL,7UL,0x18L,1UL,0xA2L,0xCDL}},{{0xA2L,2UL,0x18L,0x85L,2UL,0x74L},{255UL,0x85L,0xCDL,1UL,2UL,253UL},{1UL,2UL,253UL,7UL,0xA2L,0x74L},{1UL,7UL,0xEDL,1UL,255UL,0xCDL},{255UL,2UL,0xEDL,0x85L,1UL,0x74L},{0xA2L,0x85L,253UL,1UL,1UL,0xBEL},{1UL,1UL,252UL,255UL,0xDDL,0xA2L},{1UL,255UL,0x85L,0x41L,1UL,252UL},{1UL,1UL,0x85L,1UL,1UL,0xA2L},{0xDDL,1UL,252UL,0x41L,1UL,0xBEL}},{{0x41L,1UL,0xBEL,255UL,1UL,0xA2L},{0x41L,255UL,7UL,0x41L,0xDDL,252UL},{0xDDL,1UL,7UL,1UL,0x41L,0xA2L},{1UL,1UL,0xBEL,0x41L,0x41L,0xBEL},{1UL,1UL,252UL,255UL,0xDDL,0xA2L},{1UL,255UL,0x85L,0x41L,1UL,252UL},{1UL,1UL,0x85L,1UL,1UL,0xA2L},{0xDDL,1UL,252UL,0x41L,1UL,0xBEL},{0x41L,1UL,0xBEL,255UL,1UL,0xA2L},{0x41L,255UL,7UL,0x41L,0xDDL,252UL}}};
    int32_t l_640 = 0x8E247480L;
    volatile int32_t *l_641 = &g_642;
    uint64_t **l_673[3];
    uint16_t **l_689 = (void*)0;
    uint16_t ***l_688 = &l_689;
    int32_t l_773 = (-3L);
    int32_t *l_976 = &g_161;
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_104[i] = 0x655ED6FAL;
    for (i = 0; i < 3; i++)
        l_673[i] = &g_445;
    return p_78;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_44[i], "g_44[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_45, "g_45", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_46[i], "g_46[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_63[i], "g_63[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_109, "g_109", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_157[i][j], "g_157[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_211, "g_211", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    transparent_crc(g_215, "g_215", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_238[i][j][k], "g_238[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_274, "g_274", print_hash_value);
    transparent_crc(g_296, "g_296", print_hash_value);
    transparent_crc(g_297, "g_297", print_hash_value);
    transparent_crc(g_325, "g_325", print_hash_value);
    transparent_crc(g_327, "g_327", print_hash_value);
    transparent_crc(g_328, "g_328", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_384[i][j], "g_384[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_439, "g_439", print_hash_value);
    transparent_crc(g_452, "g_452", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_495[i], "g_495[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_553[i][j], "g_553[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_583, "g_583", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_585[i][j], "g_585[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_590, "g_590", print_hash_value);
    transparent_crc(g_594, "g_594", print_hash_value);
    transparent_crc(g_642, "g_642", print_hash_value);
    transparent_crc(g_792, "g_792", print_hash_value);
    transparent_crc(g_837, "g_837", print_hash_value);
    transparent_crc(g_840, "g_840", print_hash_value);
    transparent_crc(g_899, "g_899", print_hash_value);
    transparent_crc(g_933, "g_933", print_hash_value);
    transparent_crc(g_934, "g_934", print_hash_value);
    transparent_crc(g_935, "g_935", print_hash_value);
    transparent_crc(g_1084, "g_1084", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1110[i][j].f0, "g_1110[i][j].f0", print_hash_value);
            transparent_crc(g_1110[i][j].f1, "g_1110[i][j].f1", print_hash_value);
            transparent_crc(g_1110[i][j].f2, "g_1110[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1173.f0, "g_1173.f0", print_hash_value);
    transparent_crc(g_1173.f1, "g_1173.f1", print_hash_value);
    transparent_crc(g_1173.f2, "g_1173.f2", print_hash_value);
    transparent_crc(g_1210, "g_1210", print_hash_value);
    transparent_crc(g_1273, "g_1273", print_hash_value);
    transparent_crc(g_1369, "g_1369", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1480[i], "g_1480[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1601.f0, "g_1601.f0", print_hash_value);
    transparent_crc(g_1601.f1, "g_1601.f1", print_hash_value);
    transparent_crc(g_1601.f2, "g_1601.f2", print_hash_value);
    transparent_crc(g_1671.f0, "g_1671.f0", print_hash_value);
    transparent_crc(g_1671.f1, "g_1671.f1", print_hash_value);
    transparent_crc(g_1671.f2, "g_1671.f2", print_hash_value);
    transparent_crc(g_1774.f0, "g_1774.f0", print_hash_value);
    transparent_crc(g_1774.f1, "g_1774.f1", print_hash_value);
    transparent_crc(g_1774.f2, "g_1774.f2", print_hash_value);
    transparent_crc(g_1777.f0, "g_1777.f0", print_hash_value);
    transparent_crc(g_1777.f1, "g_1777.f1", print_hash_value);
    transparent_crc(g_1777.f2, "g_1777.f2", print_hash_value);
    transparent_crc(g_1821.f0, "g_1821.f0", print_hash_value);
    transparent_crc(g_1821.f1, "g_1821.f1", print_hash_value);
    transparent_crc(g_1821.f2, "g_1821.f2", print_hash_value);
    transparent_crc(g_1850.f0, "g_1850.f0", print_hash_value);
    transparent_crc(g_1850.f1, "g_1850.f1", print_hash_value);
    transparent_crc(g_1850.f2, "g_1850.f2", print_hash_value);
    transparent_crc(g_1886.f0, "g_1886.f0", print_hash_value);
    transparent_crc(g_1886.f1, "g_1886.f1", print_hash_value);
    transparent_crc(g_1886.f2, "g_1886.f2", print_hash_value);
    transparent_crc(g_1889.f0, "g_1889.f0", print_hash_value);
    transparent_crc(g_1889.f1, "g_1889.f1", print_hash_value);
    transparent_crc(g_1889.f2, "g_1889.f2", print_hash_value);
    transparent_crc(g_1914, "g_1914", print_hash_value);
    transparent_crc(g_1988.f0, "g_1988.f0", print_hash_value);
    transparent_crc(g_1988.f1, "g_1988.f1", print_hash_value);
    transparent_crc(g_1988.f2, "g_1988.f2", print_hash_value);
    transparent_crc(g_2024, "g_2024", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2049[i][j], "g_2049[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2060.f0, "g_2060.f0", print_hash_value);
    transparent_crc(g_2060.f1, "g_2060.f1", print_hash_value);
    transparent_crc(g_2060.f2, "g_2060.f2", print_hash_value);
    transparent_crc(g_2087.f0, "g_2087.f0", print_hash_value);
    transparent_crc(g_2087.f1, "g_2087.f1", print_hash_value);
    transparent_crc(g_2087.f2, "g_2087.f2", print_hash_value);
    transparent_crc(g_2185.f0, "g_2185.f0", print_hash_value);
    transparent_crc(g_2185.f1, "g_2185.f1", print_hash_value);
    transparent_crc(g_2185.f2, "g_2185.f2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_2218[i][j][k].f0, "g_2218[i][j][k].f0", print_hash_value);
                transparent_crc(g_2218[i][j][k].f1, "g_2218[i][j][k].f1", print_hash_value);
                transparent_crc(g_2218[i][j][k].f2, "g_2218[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2282.f0, "g_2282.f0", print_hash_value);
    transparent_crc(g_2282.f1, "g_2282.f1", print_hash_value);
    transparent_crc(g_2282.f2, "g_2282.f2", print_hash_value);
    transparent_crc(g_2322, "g_2322", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_2330[i][j], "g_2330[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2467, "g_2467", print_hash_value);
    transparent_crc(g_2531, "g_2531", print_hash_value);
    transparent_crc(g_2616, "g_2616", print_hash_value);
    transparent_crc(g_2704.f0, "g_2704.f0", print_hash_value);
    transparent_crc(g_2704.f1, "g_2704.f1", print_hash_value);
    transparent_crc(g_2704.f2, "g_2704.f2", print_hash_value);
    transparent_crc(g_2810.f0, "g_2810.f0", print_hash_value);
    transparent_crc(g_2810.f1, "g_2810.f1", print_hash_value);
    transparent_crc(g_2810.f2, "g_2810.f2", print_hash_value);
    transparent_crc(g_2918, "g_2918", print_hash_value);
    transparent_crc(g_3009.f0, "g_3009.f0", print_hash_value);
    transparent_crc(g_3009.f1, "g_3009.f1", print_hash_value);
    transparent_crc(g_3009.f2, "g_3009.f2", print_hash_value);
    transparent_crc(g_3056.f0, "g_3056.f0", print_hash_value);
    transparent_crc(g_3056.f1, "g_3056.f1", print_hash_value);
    transparent_crc(g_3056.f2, "g_3056.f2", print_hash_value);
    transparent_crc(g_3101, "g_3101", print_hash_value);
    transparent_crc(g_3127.f0, "g_3127.f0", print_hash_value);
    transparent_crc(g_3127.f1, "g_3127.f1", print_hash_value);
    transparent_crc(g_3127.f2, "g_3127.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 685
XXX total union variables: 29

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 36
breakdown:
   depth: 1, occurrence: 169
   depth: 2, occurrence: 43
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 17, occurrence: 4
   depth: 18, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 22, occurrence: 3
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 26, occurrence: 2
   depth: 27, occurrence: 2
   depth: 32, occurrence: 4
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 36, occurrence: 1

XXX total number of pointers: 561

XXX times a variable address is taken: 1359
XXX times a pointer is dereferenced on RHS: 525
breakdown:
   depth: 1, occurrence: 321
   depth: 2, occurrence: 131
   depth: 3, occurrence: 65
   depth: 4, occurrence: 7
   depth: 5, occurrence: 0
   depth: 6, occurrence: 1
XXX times a pointer is dereferenced on LHS: 492
breakdown:
   depth: 1, occurrence: 405
   depth: 2, occurrence: 52
   depth: 3, occurrence: 25
   depth: 4, occurrence: 6
   depth: 5, occurrence: 1
   depth: 6, occurrence: 3
XXX times a pointer is compared with null: 68
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 23
XXX times a pointer is qualified to be dereferenced: 7993

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1871
   level: 2, occurrence: 600
   level: 3, occurrence: 277
   level: 4, occurrence: 71
   level: 5, occurrence: 5
   level: 6, occurrence: 23
XXX number of pointers point to pointers: 256
XXX number of pointers point to scalars: 283
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 33.7
XXX average alias set size: 1.59

XXX times a non-volatile is read: 2897
XXX times a non-volatile is write: 1419
XXX times a volatile is read: 102
XXX    times read thru a pointer: 50
XXX times a volatile is write: 39
XXX    times written thru a pointer: 27
XXX times a volatile is available for access: 5.07e+03
XXX percentage of non-volatile access: 96.8

XXX forward jumps: 2
XXX backward jumps: 15

XXX stmts: 170
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 21
   depth: 2, occurrence: 27
   depth: 3, occurrence: 23
   depth: 4, occurrence: 26
   depth: 5, occurrence: 49

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
********************* end of statistics **********************/

