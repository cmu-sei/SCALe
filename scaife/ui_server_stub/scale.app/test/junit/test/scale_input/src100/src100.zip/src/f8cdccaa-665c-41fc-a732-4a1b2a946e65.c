/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1060888173
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_3[3] = {0x77DD68876942A1E9LL,0x77DD68876942A1E9LL,0x77DD68876942A1E9LL};
static uint64_t g_22[7] = {0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL,0x1F1E283D1F0DFBC4LL};
static int32_t g_28 = 0x459F451DL;
static int32_t g_44 = 1L;
static uint16_t g_46 = 0x64D1L;
static int16_t g_49[1][10][2] = {{{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L},{0x15E7L,0x15E7L}}};
static uint64_t g_50[5][5] = {{1UL,1UL,1UL,1UL,1UL},{0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL},{1UL,1UL,1UL,1UL,1UL},{0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL,0xF8C21E6DB759FFDBLL},{1UL,1UL,1UL,1UL,1UL}};
static int32_t *g_56 = &g_44;
static int32_t **g_59 = &g_56;
static int32_t * const  volatile g_60 = &g_44;/* VOLATILE GLOBAL g_60 */
static uint16_t g_90 = 0x9A9CL;
static int64_t g_104 = (-1L);
static uint32_t g_120 = 0x484424FDL;
static uint8_t g_122 = 1UL;
static uint16_t g_123 = 0x1F13L;
static volatile int64_t * volatile g_126 = &g_3[2];/* VOLATILE GLOBAL g_126 */
static volatile int64_t * volatile *g_125 = &g_126;
static uint32_t g_155 = 0xFE138955L;
static int32_t g_157 = 0x3D806202L;
static int32_t * volatile g_156 = &g_157;/* VOLATILE GLOBAL g_156 */
static uint32_t g_158 = 0x2E68FD62L;
static int8_t g_211[6] = {0x95L,0x95L,0x95L,0x95L,0x95L,0x95L};
static int8_t g_218 = (-3L);
static uint8_t g_241[10][7] = {{0x72L,0x86L,1UL,0x86L,0x72L,0x72L,0x86L},{1UL,0x70L,1UL,0x86L,0x86L,1UL,0x70L},{0x86L,0x70L,1UL,1UL,0x70L,0x86L,0x70L},{1UL,0x86L,0x86L,1UL,0x70L,1UL,0x86L},{0x72L,0x72L,0x86L,1UL,0x86L,0x72L,0x72L},{0x72L,0x86L,1UL,0x86L,0x72L,0x72L,0x86L},{1UL,0x70L,1UL,0x86L,0x86L,1UL,0x70L},{0x86L,0x70L,1UL,1UL,0x70L,0x86L,0x70L},{1UL,0x86L,0x86L,1UL,0x70L,1UL,0x86L},{0x72L,0x72L,0x86L,1UL,0x86L,0x72L,0x72L}};
static uint32_t g_305 = 0x5BDB5662L;
static int32_t g_307 = (-7L);
static uint32_t g_349 = 4294967295UL;
static int32_t g_353[7] = {0xCEF595A5L,0xCEF595A5L,0xCEF595A5L,0xCEF595A5L,0xCEF595A5L,0xCEF595A5L,0xCEF595A5L};
static volatile uint64_t g_425 = 0xBE47F3CA4CC6C807LL;/* VOLATILE GLOBAL g_425 */
static volatile uint64_t *g_424 = &g_425;
static volatile uint64_t * volatile *g_423[1] = {&g_424};
static uint8_t g_452 = 255UL;
static int64_t *g_458[4] = {&g_104,&g_104,&g_104,&g_104};
static int64_t g_504 = 0xD042617E67EB7F53LL;
static int32_t *g_567 = &g_307;
static int32_t g_570 = 0x916993E9L;
static int8_t g_592 = 0x52L;
static uint16_t *g_663 = &g_123;
static uint16_t **g_662[9][10] = {{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663},{&g_663,(void*)0,&g_663,&g_663,&g_663,&g_663,(void*)0,&g_663,&g_663,&g_663}};
static uint16_t *** volatile g_661 = &g_662[5][9];/* VOLATILE GLOBAL g_661 */
static uint16_t g_678 = 0xEE84L;
static uint16_t *** volatile g_684[10] = {(void*)0,&g_662[5][9],(void*)0,&g_662[5][9],(void*)0,&g_662[5][9],(void*)0,&g_662[5][9],(void*)0,&g_662[5][9]};
static uint16_t *** volatile g_685 = &g_662[1][4];/* VOLATILE GLOBAL g_685 */
static volatile int32_t g_767 = (-9L);/* VOLATILE GLOBAL g_767 */
static int64_t **g_806 = (void*)0;
static uint8_t g_833[4] = {0xFFL,0xFFL,0xFFL,0xFFL};
static int16_t g_848[5][4][6] = {{{0x2E8CL,7L,0xC040L,(-1L),(-1L),(-1L)},{0x3869L,7L,0x3869L,0xB0DCL,0x628EL,0L},{0xFFF5L,0x29D8L,(-1L),0xD747L,0x2E8CL,(-1L)},{1L,0xD747L,0x628EL,0xD747L,1L,0xB0DCL}},{{0xFFF5L,(-1L),0x41D9L,0xB0DCL,0x5E49L,0xD747L},{0x3869L,0xD747L,7L,(-1L),7L,0xD747L},{0x2E8CL,0x29D8L,0x41D9L,0L,0xC040L,0xB0DCL},{7L,7L,0x628EL,(-1L),0x1DA0L,(-1L)}},{{(-1L),7L,(-1L),0xB0DCL,0xC040L,0L},{1L,0x29D8L,0x3869L,0xD747L,7L,(-1L)},{0x5E49L,0xD747L,0xC040L,0xD747L,0x5E49L,0xB0DCL},{1L,(-1L),0x5076L,0xB0DCL,1L,0xD747L}},{{(-1L),0xD747L,0x2E8CL,(-1L),0x2E8CL,0xD747L},{7L,0x29D8L,0x5076L,0L,0x628EL,0xB0DCL},{0x2E8CL,7L,0xC040L,(-1L),(-1L),(-1L)},{0x3869L,7L,0x3869L,0xB0DCL,0x628EL,0L}},{{0xFFF5L,0x29D8L,(-1L),0xD747L,0x2E8CL,(-1L)},{1L,0xD747L,0x628EL,0xD747L,1L,0xB0DCL},{0xFFF5L,(-1L),0x41D9L,0xB0DCL,0x5E49L,0xD747L},{0x3869L,0xD747L,7L,(-1L),7L,0xD747L}}};
static int64_t ***g_969[10] = {&g_806,&g_806,&g_806,&g_806,&g_806,&g_806,&g_806,&g_806,&g_806,&g_806};
static const int32_t g_992 = 0x0B762F4CL;
static const int32_t ** volatile g_995 = (void*)0;/* VOLATILE GLOBAL g_995 */
static const int32_t ** volatile g_996 = (void*)0;/* VOLATILE GLOBAL g_996 */
static int32_t *g_1000 = &g_570;
static volatile int8_t g_1037 = 0x9FL;/* VOLATILE GLOBAL g_1037 */
static volatile int8_t *g_1036 = &g_1037;
static volatile int8_t * const  volatile *g_1035[7] = {&g_1036,&g_1036,&g_1036,&g_1036,&g_1036,&g_1036,&g_1036};
static int32_t * volatile g_1147[7] = {&g_353[0],&g_353[0],&g_353[0],&g_353[0],&g_353[0],&g_353[0],&g_353[0]};
static uint32_t *g_1193 = &g_155;
static int16_t * volatile g_1198 = &g_848[2][0][0];/* VOLATILE GLOBAL g_1198 */
static const int64_t g_1233 = 0L;
static volatile int16_t g_1334 = 1L;/* VOLATILE GLOBAL g_1334 */
static volatile int8_t g_1398 = (-1L);/* VOLATILE GLOBAL g_1398 */
static int32_t ** volatile g_1446 = (void*)0;/* VOLATILE GLOBAL g_1446 */
static uint8_t *g_1463 = &g_241[8][1];
static uint8_t **g_1462[2] = {&g_1463,&g_1463};
static int32_t g_1485 = 0x5A92955DL;
static uint64_t *g_1498 = &g_50[2][1];
static const int64_t *g_1543 = &g_1233;
static const int64_t **g_1542 = &g_1543;
static const int64_t ***g_1541 = &g_1542;
static const int64_t ****g_1540[2][7][5] = {{{&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,(void*)0},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541}},{{&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,(void*)0,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,(void*)0,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{&g_1541,&g_1541,&g_1541,&g_1541,&g_1541},{(void*)0,&g_1541,&g_1541,&g_1541,&g_1541}}};
static const int64_t *****g_1539 = &g_1540[0][3][0];
static int32_t * volatile g_1547 = (void*)0;/* VOLATILE GLOBAL g_1547 */
static int8_t *g_1604 = (void*)0;
static int8_t ** const g_1603 = &g_1604;
static int8_t ** const *g_1602 = &g_1603;
static int32_t * volatile g_1627 = (void*)0;/* VOLATILE GLOBAL g_1627 */
static int32_t g_1644 = 0L;
static uint32_t *** volatile g_1681 = (void*)0;/* VOLATILE GLOBAL g_1681 */
static int32_t * const  volatile g_1715 = (void*)0;/* VOLATILE GLOBAL g_1715 */
static int32_t g_1840 = 0xF266B909L;
static uint64_t *** volatile g_1850 = (void*)0;/* VOLATILE GLOBAL g_1850 */
static uint64_t **g_1852 = (void*)0;
static uint64_t *** volatile g_1851 = &g_1852;/* VOLATILE GLOBAL g_1851 */
static volatile int32_t *g_1907[10] = {&g_767,&g_767,&g_767,&g_767,&g_767,&g_767,&g_767,&g_767,&g_767,&g_767};
static volatile int32_t **g_1906[5][1][3] = {{{(void*)0,(void*)0,(void*)0}},{{&g_1907[7],&g_1907[7],&g_1907[7]}},{{(void*)0,(void*)0,(void*)0}},{{&g_1907[7],&g_1907[7],&g_1907[7]}},{{(void*)0,(void*)0,(void*)0}}};
static volatile int32_t ** volatile * volatile g_1905 = &g_1906[2][0][1];/* VOLATILE GLOBAL g_1905 */
static volatile int8_t g_2027 = 0L;/* VOLATILE GLOBAL g_2027 */
static int8_t g_2058[1] = {0x35L};
static int64_t g_2059 = 0L;
static const volatile int32_t g_2109 = 0x738AB659L;/* VOLATILE GLOBAL g_2109 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint8_t  func_6(const uint32_t  p_7, uint32_t  p_8);
static uint8_t  func_9(const int8_t  p_10);
static int16_t  func_13(uint64_t  p_14, uint32_t  p_15);
static uint64_t  func_16(uint32_t  p_17, uint32_t  p_18, int16_t  p_19, int32_t  p_20);
static int32_t  func_64(int32_t ** p_65, int32_t * p_66, uint16_t  p_67, int64_t  p_68, const int32_t  p_69);
static int32_t * func_71(int32_t  p_72, int16_t  p_73);
static int32_t * func_83(uint16_t  p_84, int32_t  p_85, int32_t  p_86);
static uint16_t * func_93(int8_t  p_94, const uint8_t  p_95);
static uint8_t  func_96(const uint64_t  p_97, int32_t * p_98);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_22 g_46 g_50 g_28 g_60 g_90 g_49 g_44 g_156 g_157 g_218 g_59 g_56 g_592 g_353 g_833 g_241 g_123 g_1035 g_155 g_424 g_425 g_570 g_1036 g_1037 g_663 g_848 g_1000 g_104 g_567 g_307 g_349 g_504 g_211 g_158 g_120 g_1193 g_1198 g_678 g_1334 g_1485 g_1498 g_1463 g_1539 g_1602 g_1644 g_122 g_1541 g_1542 g_1543 g_1233 g_2027
 * writes: g_46 g_50 g_44 g_56 g_59 g_90 g_104 g_28 g_452 g_353 g_663 g_349 g_592 g_158 g_833 g_570 g_305 g_211 g_1037 g_504 g_22 g_123 g_157 g_848 g_120 g_155 g_969 g_218 g_1485 g_1000 g_1498 g_241 g_1539 g_1602 g_1193 g_1644 g_678
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2 = 0x34FDA0E6L;
    int32_t l_25 = (-1L);
    uint16_t l_26 = 65531UL;
    int32_t *l_1483 = (void*)0;
    int32_t *l_1484[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint8_t l_1937 = 0xE4L;
    int32_t *l_1939 = &g_353[4];
    int32_t l_1962[6][1];
    uint8_t l_1996 = 255UL;
    uint8_t l_2020 = 0x15L;
    uint8_t l_2032 = 6UL;
    uint64_t l_2041 = 0x0D126F642C12B5A2LL;
    uint16_t l_2084[2];
    uint8_t l_2086 = 1UL;
    int32_t l_2106 = 1L;
    uint64_t l_2133 = 9UL;
    uint64_t l_2147 = 0xD536C3AC5B6CC60ALL;
    int i, j;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_1962[i][j] = (-2L);
    }
    for (i = 0; i < 2; i++)
        l_2084[i] = 0x79D2L;
    if (((l_2 & g_3[2]) || ((0xAF14C90DL || (safe_lshift_func_uint8_t_u_u((func_6((((((g_1485 |= (1UL > func_9((safe_mod_func_uint64_t_u_u(g_3[2], (l_2 ^ func_13(func_16((~(l_25 = ((g_22[2] || 0UL) || (safe_add_func_uint8_t_u_u((7L < g_22[2]), l_2))))), l_2, l_2, l_26), l_26))))))) == 0xA29C8B64L) <= g_241[8][1]) , (*g_1193)) ^ 0xEDA1AFA7L), g_678) == 0x12L), l_1937))) == 0x3EB923B172BA337ELL)))
    { /* block id: 1098 */
        uint64_t l_1938 = 0x5C743498F2771BA4LL;
        int32_t l_1983 = 7L;
        int32_t l_1988[4] = {0xBB377C89L,0xBB377C89L,0xBB377C89L,0xBB377C89L};
        int8_t * const *l_2000 = &g_1604;
        int8_t * const ** const l_1999 = &l_2000;
        int8_t * const ** const *l_1998 = &l_1999;
        int8_t * const ** const **l_1997 = &l_1998;
        int16_t l_2011 = 0xBB44L;
        int16_t l_2016 = (-1L);
        int32_t l_2035[5];
        uint32_t *l_2038 = &g_155;
        int8_t *l_2039 = &g_592;
        int8_t *l_2040 = &g_218;
        int i;
        for (i = 0; i < 5; i++)
            l_2035[i] = 0x821BBB81L;
        for (l_25 = 3; (l_25 >= 0); l_25 -= 1)
        { /* block id: 1101 */
            uint32_t l_1960 = 0x48530CF0L;
            int32_t * const *l_1974 = &l_1484[2];
            int32_t * const **l_1973 = &l_1974;
            int32_t l_1989 = 0x1D9F0B25L;
            int16_t l_2017 = (-9L);
            int32_t l_2019[3][7][10] = {{{0xE63D14E6L,0xD7EF7D4BL,0xE63D14E6L,2L,(-9L),0x74292A4BL,0x1A5199D8L,(-5L),(-1L),0x402492A9L},{(-6L),1L,0xB442DF1BL,(-6L),0x0A4CB141L,5L,(-1L),(-5L),0x528D13C6L,0x0719396AL},{1L,0xEC54DC0CL,0xE63D14E6L,(-1L),(-1L),0L,0x5A5E530EL,0xB2A1328AL,0L,(-6L)},{0xD7EF7D4BL,0xFA04FC09L,1L,0x651DE4E8L,0x460802C3L,0x40981FB8L,(-6L),0xE09019B8L,(-1L),1L},{5L,5L,0x460802C3L,0L,(-1L),1L,1L,0x28FDDCD2L,1L,0x74292A4BL},{0x5A5E530EL,0xE09019B8L,0x562C87A5L,0L,(-1L),0x4C731C91L,(-3L),(-1L),1L,0xB245CD1CL},{0L,5L,0x483B9103L,1L,(-6L),1L,(-9L),0L,0xF7A51937L,(-10L)}},{{0x402492A9L,0xB442DF1BL,(-6L),2L,(-5L),(-3L),1L,0x6CA67350L,(-1L),0xFA04FC09L},{7L,0xB2A1328AL,(-1L),0x9863BBFDL,0x86C03970L,0xBD0A14F9L,(-1L),(-1L),0xBD0A14F9L,0x86C03970L},{0x528D13C6L,7L,7L,0x528D13C6L,0xE09019B8L,0L,0x1347F41AL,5L,0xD2B0356BL,(-6L)},{0x0A4CB141L,0L,0x2E5AFBFCL,(-9L),0x562C87A5L,1L,7L,0x1347F41AL,0xD2B0356BL,0x62C23B6AL},{0x28FDDCD2L,0xBD0A14F9L,0x460802C3L,0x528D13C6L,(-6L),0x483B9103L,(-10L),0L,0xBD0A14F9L,0xD2C5BADBL},{0xBADF3730L,0xCC9A86AAL,(-1L),1L,(-1L),1L,1L,(-4L),6L,0xB442DF1BL},{0xFA04FC09L,1L,0x74292A4BL,0x5CA14CD6L,0xE8386D81L,7L,0x5A5E530EL,0x402492A9L,0x1A5199D8L,(-5L)}},{{0L,0x90B1BE83L,(-6L),3L,1L,0xE09019B8L,0xFAD18E4DL,0x28FDDCD2L,1L,(-1L)},{0x2808DE53L,0xD2B0356BL,(-2L),1L,(-1L),0L,(-6L),(-1L),(-1L),6L},{(-1L),(-6L),0xF7A51937L,0x6CA67350L,0xA1DBB83EL,0xE8386D81L,6L,0L,0L,0xF7A51937L},{6L,0L,(-3L),5L,(-1L),3L,0x2808DE53L,(-1L),0x2808DE53L,3L},{1L,0L,0x1347F41AL,0L,1L,1L,0x651DE4E8L,0xE8386D81L,(-6L),(-1L)},{0xBADF3730L,6L,1L,0x483B9103L,1L,(-10L),0xE09019B8L,0xBADF3730L,(-1L),(-1L)},{0xE63D14E6L,0x483B9103L,0x460802C3L,0x5CA14CD6L,1L,(-1L),0xB442DF1BL,0xEC54DC0CL,0xE8386D81L,3L}}};
            int i, j, k;
            for (g_1644 = 0; (g_1644 <= 4); g_1644 += 1)
            { /* block id: 1104 */
                int i, j;
                (*g_59) = l_1939;
                return (*g_1498);
            }
            for (g_46 = 0; (g_46 == 31); g_46 = safe_add_func_int16_t_s_s(g_46, 3))
            { /* block id: 1111 */
                int16_t l_1942 = 0L;
                int32_t ***l_1985 = &g_59;
                uint32_t * const l_1987 = &g_120;
                if (l_1942)
                { /* block id: 1112 */
                    uint64_t l_1955 = 0x788A43F67B4DA9E8LL;
                    int64_t *l_1956 = &g_504;
                    int32_t l_1957 = (-1L);
                    uint16_t *l_1961 = &l_26;
                    if (((*l_1939) = ((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(((*g_1498)--), 0xA37403E395387ACCLL)), (safe_lshift_func_uint16_t_u_s((((*l_1961) = (safe_sub_func_uint32_t_u_u((((l_1957 |= ((*l_1956) = l_1955)) < 2L) && l_1938), (((((l_1938 >= 255UL) | (safe_add_func_int16_t_s_s(((l_1960 , (l_1938 & (*g_1036))) , l_1955), 0x4833L))) <= g_122) ^ 1L) || (*g_1198))))) , l_1942), g_241[8][1])))), l_1955)) , 0x97B0D1A2L)))
                    { /* block id: 1118 */
                        uint32_t l_1963 = 0x2A5BC2B6L;
                        l_1963 &= ((*l_1939) = l_1962[4][0]);
                        return (*g_424);
                    }
                    else
                    { /* block id: 1122 */
                        return (*g_1498);
                    }
                }
                else
                { /* block id: 1125 */
                    int8_t *l_1984[1][8][3] = {{{&g_211[4],&g_211[1],&g_592},{&g_211[4],&g_592,&g_211[4]},{&g_211[4],&g_592,&g_211[0]},{&g_211[4],&g_211[1],&g_592},{&g_211[4],&g_592,&g_211[4]},{&g_211[4],&g_592,&g_211[0]},{&g_211[4],&g_211[1],&g_592},{&g_211[4],&g_592,&g_211[4]}}};
                    int16_t *l_1986 = &g_848[1][3][4];
                    int32_t l_1990 = 1L;
                    int i, j, k;
                    l_1989 ^= (l_1988[2] = (safe_mul_func_int8_t_s_s(l_1960, ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_s((((safe_add_func_int16_t_s_s(((l_1960 < (safe_unary_minus_func_int32_t_s(((l_1942 ^ (((*l_1986) = (l_1973 != ((((*g_663) != (safe_add_func_int64_t_s_s((safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_u(((*g_1463) ^ (!(*g_1463))), (safe_unary_minus_func_int64_t_s(0xF32543BDE47A2DD9LL)))), ((*l_1939) ^= (l_1983 = ((0xCE8AL & (*g_1198)) < g_349))))), (*g_1498)))) , 0x2E43CCABL) , l_1985))) <= (*g_663))) || 0xEDC3399823D2F281LL)))) , (*g_1198)), 0L)) , (void*)0) == l_1987), l_1938)), 4)) & (*g_1463)))));
                    l_1990 |= 0xB89BE595L;
                }
            }
            for (g_120 = 0; (g_120 > 58); ++g_120)
            { /* block id: 1136 */
                int32_t l_2005 = (-1L);
                int32_t l_2018[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
                int i;
                for (g_155 = 7; (g_155 >= 7); g_155 = safe_add_func_int32_t_s_s(g_155, 7))
                { /* block id: 1139 */
                    int8_t l_1995 = 0x86L;
                    return l_1995;
                }
                for (g_46 = 2; (g_46 <= 6); g_46 += 1)
                { /* block id: 1144 */
                    uint16_t l_2010 = 65535UL;
                    int32_t l_2014 = 0x728C74EAL;
                    (*g_156) ^= l_1996;
                    for (g_157 = 0; (g_157 <= 6); g_157 += 1)
                    { /* block id: 1148 */
                        int8_t *l_2012 = &g_211[4];
                        const int32_t l_2013 = 1L;
                        int32_t l_2015[9][10][2] = {{{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L},{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L}},{{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L},{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L}},{{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L},{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x693C4A96L}},{{0xD3A14290L,0x693C4A96L},{0x001437A6L,0xD3A14290L},{0x41869EF9L,0x41869EF9L},{0x41869EF9L,0xD3A14290L},{0x001437A6L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}},{{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}},{{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}},{{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}},{{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}},{{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L},{0x001437A6L,0x41869EF9L},{1L,0x001437A6L},{0xD3A14290L,0xD3A14290L},{0xD3A14290L,0x001437A6L},{1L,0x41869EF9L}}};
                        int i, j, k;
                        l_2014 &= (((*l_2012) ^= ((l_1997 != ((!(+(((safe_rshift_func_int8_t_s_u(l_2005, (safe_rshift_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((((l_1938 ^ (*g_424)) , ((*g_1198) , (*l_1939))) && (*g_1036)) , (*l_1939)), l_2010)), 7)))) , g_1485) <= l_2011))) , (void*)0)) & 0xADBC1DC6L)) | l_2013);
                        l_2020--;
                    }
                }
                return l_2005;
            }
        }
        l_1983 = ((*l_1939) = ((((***g_1541) != (safe_add_func_int64_t_s_s((safe_sub_func_int8_t_s_s(((*l_2040) &= ((*l_2039) &= ((g_2027 <= (safe_mul_func_int16_t_s_s(g_349, ((*g_663) = (l_1983 >= ((((safe_mul_func_uint16_t_u_u(l_2032, (safe_add_func_uint64_t_u_u(l_1983, (l_2035[2] , (safe_div_func_uint32_t_u_u(((*l_2038) |= ((l_1983 > g_50[4][2]) ^ 0x7B9A3D2BL)), 0x744CE466L))))))) , &l_2035[2]) != (void*)0) & 0L)))))) & l_1988[1]))), l_2041)), (*l_1939)))) , (void*)0) != &g_50[3][1]));
    }
    else
    { /* block id: 1163 */
        int8_t l_2046 = (-1L);
        int32_t l_2047[7][6] = {{0x520B1D93L,(-9L),(-1L),(-1L),(-9L),0x520B1D93L},{0x8B341E2DL,0x520B1D93L,(-1L),0x520B1D93L,0x8B341E2DL,0x8B341E2DL},{0x32B64CB1L,0x520B1D93L,0x520B1D93L,0x32B64CB1L,(-9L),0x32B64CB1L},{0x32B64CB1L,(-9L),0x32B64CB1L,0x520B1D93L,0x520B1D93L,0x32B64CB1L},{0x8B341E2DL,0x8B341E2DL,0x520B1D93L,(-1L),0x520B1D93L,0x8B341E2DL},{0x520B1D93L,(-9L),(-1L),(-1L),(-9L),0x520B1D93L},{0x8B341E2DL,0x520B1D93L,(-1L),0x520B1D93L,0x8B341E2DL,0x8B341E2DL}};
        int32_t *l_2048 = &l_1962[5][0];
        uint32_t l_2060 = 18446744073709551615UL;
        int64_t l_2085 = 1L;
        int32_t l_2089 = 1L;
        int i, j;
        (*g_59) = &l_25;
        --l_2060;
        (*g_59) = &l_25;
        for (g_678 = 24; (g_678 == 2); g_678 = safe_sub_func_int16_t_s_s(g_678, 1))
        { /* block id: 1171 */
            int32_t l_2087 = 0xEEC3B350L;
            int32_t l_2088 = (-8L);
            int32_t l_2125 = 0L;
            l_2088 = ((*g_56) = ((safe_add_func_int16_t_s_s((~(safe_rshift_func_int16_t_s_u((g_307 , l_2047[3][5]), (safe_mod_func_uint16_t_u_u((((safe_mod_func_uint64_t_u_u((((*g_1198) <= ((safe_add_func_int32_t_s_s((*g_56), (safe_div_func_int16_t_s_s(l_2060, 7UL)))) , ((((((safe_mul_func_int8_t_s_s(((*l_1939) |= ((safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s(l_2046, l_2084[1])), ((l_2086 &= l_2085) <= 0x31B450DC6526D3C2LL))) >= l_2047[6][1])), (-4L))) != 0x648E3D20L) > 0xDDCA4F20L) , (**g_1542)) != (*g_1543)) > l_2047[3][5]))) , (*g_1498)), (*g_1498))) , &g_1540[0][3][3]) == (void*)0), 0x81ECL))))), 65535UL)) == l_2087));
            if (l_2089)
                break;
            for (l_2085 = 6; (l_2085 == 9); l_2085 = safe_add_func_int16_t_s_s(l_2085, 6))
            { /* block id: 1179 */
                int8_t l_2094 = 0x66L;
                int32_t l_2095[10] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
                int64_t l_2097 = 0x5AA1D5C8F78324C9LL;
                uint64_t l_2098 = 0x49C901F942517D73LL;
                uint16_t l_2131 = 3UL;
                int i;
                for (l_2089 = 11; (l_2089 == 18); ++l_2089)
                { /* block id: 1182 */
                    int32_t l_2096 = 4L;
                    uint32_t l_2123 = 1UL;
                    uint64_t l_2130[7][3][1] = {{{0x4B15D3E9973063D6LL},{0x7722ABAC89D73AE4LL},{0x6BD29A2A67F6A191LL}},{{0x3F30045702377D64LL},{0x6BD29A2A67F6A191LL},{0x7722ABAC89D73AE4LL}},{{0x4B15D3E9973063D6LL},{0x7722ABAC89D73AE4LL},{0x6BD29A2A67F6A191LL}},{{0x3F30045702377D64LL},{0x6BD29A2A67F6A191LL},{0x7722ABAC89D73AE4LL}},{{0x4B15D3E9973063D6LL},{0x7722ABAC89D73AE4LL},{0x6BD29A2A67F6A191LL}},{{0x3F30045702377D64LL},{0x6BD29A2A67F6A191LL},{0x7722ABAC89D73AE4LL}},{{0x4B15D3E9973063D6LL},{0x7722ABAC89D73AE4LL},{0x6BD29A2A67F6A191LL}}};
                    uint64_t l_2132 = 0x4F86FC3314648A57LL;
                    uint32_t **l_2144[5] = {&g_1193,&g_1193,&g_1193,&g_1193,&g_1193};
                    uint32_t *** const l_2143 = &l_2144[1];
                    int i, j, k;
                    l_2098++;
                }
                return l_2087;
            }
        }
    }
    l_2147--;
    return (*l_1939);
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_663 g_123 g_46 g_60 g_211 g_1036 g_1037 g_1498 g_50 g_1463 g_241 g_1539 g_3 g_56 g_1198 g_848 g_833 g_44 g_592 g_1602 g_120 g_218 g_156 g_157 g_22 g_1193 g_570 g_349
 * writes: g_56 g_1000 g_123 g_46 g_44 g_1498 g_349 g_50 g_592 g_211 g_241 g_1539 g_157 g_833 g_218 g_120 g_158 g_1602 g_1193 g_353 g_22 g_155 g_452 g_570
 */
static uint8_t  func_6(const uint32_t  p_7, uint32_t  p_8)
{ /* block id: 823 */
    int32_t *l_1486 = (void*)0;
    int32_t **l_1487 = &g_1000;
    int32_t l_1488[8] = {0x27F8F565L,0x27F8F565L,0x27F8F565L,0x27F8F565L,0x27F8F565L,0x27F8F565L,0x27F8F565L,0x27F8F565L};
    int64_t * const *l_1504 = &g_458[3];
    int64_t * const **l_1503[3];
    int64_t * const ***l_1502 = &l_1503[1];
    int64_t * const ****l_1501 = &l_1502;
    const uint64_t l_1536 = 18446744073709551615UL;
    int8_t *l_1574 = &g_218;
    uint8_t ***l_1616 = (void*)0;
    int32_t l_1640 = (-6L);
    int8_t l_1651 = 0xC8L;
    uint64_t l_1653 = 0xA5D5AA1BB658AC78LL;
    uint32_t l_1719[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    uint32_t l_1725 = 0x94797823L;
    int8_t ** const **l_1754 = &g_1602;
    uint32_t l_1770 = 0x27EDB27BL;
    uint64_t l_1779 = 0x71ABD22ADC6E5D4ELL;
    uint32_t **l_1815 = (void*)0;
    uint32_t ***l_1814 = &l_1815;
    uint32_t l_1855 = 4294967295UL;
    int16_t l_1936 = 0xAA6BL;
    int i;
    for (i = 0; i < 3; i++)
        l_1503[i] = &l_1504;
lbl_1699:
    (*l_1487) = (l_1486 = ((*g_59) = l_1486));
    if ((p_7 | l_1488[7]))
    { /* block id: 827 */
        uint64_t *l_1493 = &g_50[3][4];
        uint64_t **l_1494 = (void*)0;
        uint64_t **l_1495 = (void*)0;
        uint64_t *l_1497 = &g_22[1];
        uint64_t **l_1496 = &l_1497;
        uint64_t *l_1500 = (void*)0;
        uint64_t **l_1499 = &l_1500;
        int32_t l_1508[4][4][2] = {{{0xD15483AEL,4L},{0x361A134EL,(-1L)},{(-1L),0x361A134EL},{4L,0xD15483AEL}},{{4L,0x361A134EL},{(-1L),(-1L)},{0x361A134EL,4L},{0xD15483AEL,4L}},{{0x361A134EL,(-1L)},{(-1L),0x361A134EL},{4L,0xD15483AEL},{4L,0x361A134EL}},{{(-1L),(-1L)},{0x361A134EL,4L},{0xD15483AEL,4L},{0x361A134EL,(-1L)}}};
        int8_t l_1528[9] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
        int32_t *l_1530 = &g_44;
        int32_t l_1575 = 1L;
        int i, j, k;
        (*g_60) = (safe_mod_func_int16_t_s_s(0x80D2L, ((safe_rshift_func_uint16_t_u_s(((*g_663) ^= 65535UL), 8)) && p_8)));
        if ((l_1493 == ((*l_1499) = (g_1498 = ((*l_1496) = l_1493)))))
        { /* block id: 833 */
            int32_t l_1505[1][3][6] = {{{0xE92620D2L,1L,0xE92620D2L,1L,0xE92620D2L,1L},{0xE92620D2L,1L,0xE92620D2L,1L,0xE92620D2L,1L},{0xE92620D2L,1L,0xE92620D2L,1L,0xE92620D2L,1L}}};
            int64_t * const ****l_1506[2][7] = {{&l_1502,&l_1502,&l_1502,&l_1502,&l_1502,&l_1502,&l_1502},{&l_1502,&l_1502,&l_1502,&l_1502,&l_1502,&l_1502,&l_1502}};
            int32_t *l_1507[8][3] = {{&g_570,&g_353[4],(void*)0},{&g_44,&g_44,(void*)0},{&g_570,&g_353[4],(void*)0},{&g_44,&g_44,(void*)0},{&g_570,&g_353[4],(void*)0},{&g_44,&g_44,(void*)0},{&g_570,&g_353[4],(void*)0},{&g_44,&g_44,(void*)0}};
            int i, j, k;
            l_1508[3][1][0] &= (l_1501 != (l_1505[0][2][5] , l_1506[0][0]));
            for (g_349 = 0; (g_349 >= 53); g_349 = safe_add_func_int32_t_s_s(g_349, 8))
            { /* block id: 837 */
                uint8_t l_1516 = 0x71L;
                (*g_60) = ((((*l_1493) = p_7) | p_8) , p_8);
                (*l_1487) = l_1507[1][2];
                for (g_592 = 2; (g_592 >= 0); g_592 -= 1)
                { /* block id: 843 */
                    int8_t *l_1517 = &g_211[0];
                    int32_t l_1520 = 0xD268CA23L;
                    l_1488[7] = (((~0x28299714L) , (((*g_1463) |= (((4294967295UL > (safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(l_1508[0][1][0], 3)), ((*l_1517) &= l_1516)))) & (*g_1036)) & (safe_lshift_func_uint8_t_u_s((l_1520 = p_8), (+((*g_1498) , 0x6C93L)))))) ^ (0x96L ^ 0xE6L))) > 0UL);
                }
                if (p_7)
                    continue;
            }
        }
        else
        { /* block id: 851 */
            int8_t **l_1522 = (void*)0;
            int8_t *l_1524 = &g_211[1];
            int8_t **l_1523 = &l_1524;
            int32_t l_1527 = 0x3D6A8EF0L;
            int64_t *****l_1545 = (void*)0;
            l_1530 = &l_1508[3][1][0];
            for (g_44 = 0; (g_44 != (-8)); g_44--)
            { /* block id: 858 */
                int64_t l_1554 = 0L;
                const uint32_t l_1555 = 0x5C944498L;
                int32_t *l_1557 = &l_1488[6];
                for (l_1527 = 0; (l_1527 <= 1); l_1527 += 1)
                { /* block id: 861 */
                    const int64_t ******l_1544 = &g_1539;
                    int64_t ******l_1546 = &l_1545;
                    int32_t *l_1548 = &g_157;
                    (*l_1548) = (safe_add_func_int32_t_s_s((+p_7), (l_1536 & ((*l_1530) = (safe_mul_func_uint8_t_u_u(p_7, ((((*l_1544) = g_1539) == ((*l_1546) = l_1545)) < 0xF1L)))))));
                    (*l_1530) = (safe_lshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_s((~p_7), 14)), 1));
                    if (l_1554)
                        break;
                    for (p_8 = 0; (p_8 <= 2); p_8 += 1)
                    { /* block id: 870 */
                        int i, j, k;
                        if (g_3[p_8])
                            break;
                        l_1508[l_1527][(l_1527 + 2)][l_1527] = l_1555;
                    }
                    for (g_349 = 2; (g_349 <= 6); g_349 += 1)
                    { /* block id: 876 */
                        uint64_t l_1556[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1556[i] = 18446744073709551615UL;
                        return l_1556[0];
                    }
                }
                (*g_59) = l_1557;
            }
        }
        (*g_59) = (l_1486 = ((*l_1487) = (*g_59)));
        for (g_46 = 16; (g_46 > 58); g_46 = safe_add_func_int8_t_s_s(g_46, 1))
        { /* block id: 888 */
            int32_t *l_1560[2];
            int64_t l_1561 = 6L;
            uint8_t l_1562 = 0x85L;
            uint8_t *l_1571 = &g_833[1];
            int i;
            for (i = 0; i < 2; i++)
                l_1560[i] = &g_570;
            l_1562++;
            (*l_1487) = (void*)0;
            l_1575 = ((safe_sub_func_uint32_t_u_u(((*g_1198) & (((((*l_1530) = (safe_mod_func_int64_t_s_s((0xE6C5L > ((safe_rshift_func_int8_t_s_s((0x7CL <= (p_7 < (((p_8 < p_8) , (*g_1463)) ^ ((*l_1571) ^= p_8)))), 1)) | (safe_mul_func_int8_t_s_s((((0x7E2CL <= g_848[2][0][0]) > (*l_1530)) & 9UL), 0UL)))), (*g_1498)))) , &l_1528[8]) == l_1574) > p_8)), p_7)) & 0x9E18L);
        }
    }
    else
    { /* block id: 895 */
        uint8_t l_1589 = 1UL;
        int32_t l_1624 = 0L;
        int32_t l_1641 = 0xBC989490L;
        int32_t l_1642[8];
        int32_t l_1648[2];
        int64_t l_1664 = 6L;
        uint32_t l_1691 = 7UL;
        int32_t *l_1716 = &l_1648[0];
        int16_t *l_1748 = &g_49[0][1][1];
        uint64_t **l_1750[6] = {&g_1498,&g_1498,(void*)0,&g_1498,&g_1498,(void*)0};
        const int64_t l_1890 = 0xB5B8A284249ED2AFLL;
        int64_t ** const l_1934 = &g_458[0];
        int i;
        for (i = 0; i < 8; i++)
            l_1642[i] = (-1L);
        for (i = 0; i < 2; i++)
            l_1648[i] = 0L;
        for (g_592 = 6; (g_592 >= 0); g_592 -= 1)
        { /* block id: 898 */
            int8_t *l_1586 = &g_211[0];
            int32_t l_1587 = 0L;
            int32_t l_1588[8][3][6] = {{{0xDE0D90CFL,0x7C2259C5L,1L,1L,1L,(-1L)},{0x2D7FD9FDL,7L,1L,0x7C2259C5L,(-7L),(-1L)},{0x59028830L,0xF1B88EE7L,1L,0x4515E2FAL,0x2642463FL,0xCEEE7B5FL}},{{(-7L),5L,0L,0L,5L,(-7L)},{0xCEEE7B5FL,0x2642463FL,0x4515E2FAL,1L,0xF1B88EE7L,0x59028830L},{(-1L),(-7L),0x7C2259C5L,1L,7L,0x2D7FD9FDL}},{{(-1L),1L,1L,1L,0x7C2259C5L,0xDE0D90CFL},{0xCEEE7B5FL,0xF1B88EE7L,0xED4177B1L,0L,0xED4177B1L,0xF1B88EE7L},{(-7L),0L,0x2B365FD8L,0x4515E2FAL,0L,(-7L)}},{{0x59028830L,1L,1L,0x7C2259C5L,0xF1B88EE7L,1L},{0x2D7FD9FDL,1L,0x2642463FL,1L,0L,(-9L)},{0xDE0D90CFL,0L,1L,0xED4177B1L,0xED4177B1L,1L}},{{0xF1B88EE7L,(-7L),0x2D7FD9FDL,1L,(-9L),0xED4177B1L},{0x2D7FD9FDL,0x59028830L,0L,0L,1L,0x2D7FD9FDL},{1L,0x2D7FD9FDL,0L,0xDE0D90CFL,(-7L),0xED4177B1L}},{{0xB8DB42CAL,0xDE0D90CFL,0x2D7FD9FDL,1L,0xF1B88EE7L,1L},{1L,0xF1B88EE7L,1L,0x2D7FD9FDL,0xDE0D90CFL,0xB8DB42CAL},{0xED4177B1L,(-7L),0xDE0D90CFL,0L,0x2D7FD9FDL,1L}},{{0x2D7FD9FDL,1L,0L,0L,0x59028830L,0x2D7FD9FDL},{0xED4177B1L,(-9L),1L,0x2D7FD9FDL,(-7L),(-7L)},{1L,1L,1L,1L,0xCEEE7B5FL,0x4515E2FAL}},{{0xB8DB42CAL,0xC541546CL,1L,0xDE0D90CFL,(-1L),0x2B365FD8L},{1L,(-7L),(-9L),0L,(-1L),0x7C2259C5L},{0x2D7FD9FDL,0xC541546CL,7L,1L,0xCEEE7B5FL,0x2D7FD9FDL}}};
            int64_t l_1643 = 0xE7F85408E463E4AELL;
            int8_t l_1650[3][2];
            int32_t l_1652 = 0x4B0E0E1EL;
            int32_t *l_1714[4][10] = {{&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624,&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624},{&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624,&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624},{&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624,&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624},{&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624,&l_1624,&g_1485,&l_1642[2],&g_1485,&l_1624}};
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1650[i][j] = 0x57L;
            }
            (*g_60) = (safe_sub_func_int64_t_s_s(((*g_1036) || ((((safe_add_func_int64_t_s_s(((6L & 0x0CL) , (((safe_div_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(0xB6L, 253UL)) == ((safe_mul_func_int8_t_s_s((l_1587 = ((*l_1586) = ((*l_1574) = p_8))), p_8)) ^ ((l_1588[3][1][2] = (&g_1540[1][6][2] == (void*)0)) == 8L))), l_1589)) ^ 0x069EDA67382B9EFDLL) || (*g_1198))), 0UL)) , p_8) || l_1589) <= l_1589)), l_1589));
            if (p_7)
                break;
            for (g_46 = 0; (g_46 <= 3); g_46 += 1)
            { /* block id: 907 */
                int i, j;
                return g_241[(g_46 + 5)][g_592];
            }
            for (g_120 = 0; (g_120 <= 3); g_120 += 1)
            { /* block id: 912 */
                int8_t * const *l_1601[5];
                int8_t * const **l_1600[10][2] = {{&l_1601[2],&l_1601[3]},{&l_1601[2],&l_1601[2]},{&l_1601[3],&l_1601[2]},{&l_1601[2],&l_1601[3]},{&l_1601[2],&l_1601[2]},{&l_1601[3],&l_1601[2]},{&l_1601[2],&l_1601[3]},{&l_1601[2],&l_1601[2]},{&l_1601[3],&l_1601[2]},{&l_1601[2],&l_1601[3]}};
                int32_t l_1610[6][3] = {{(-2L),0xA17B5E11L,1L},{(-2L),(-2L),0xA17B5E11L},{0x85E49C18L,0xA17B5E11L,0xA17B5E11L},{0xA17B5E11L,1L,1L},{0x85E49C18L,1L,0x85E49C18L},{(-2L),0xA17B5E11L,1L}};
                int32_t l_1622[8];
                uint8_t l_1645 = 0x0DL;
                uint64_t *l_1667[2];
                uint16_t *l_1670 = &g_90;
                int32_t *l_1679 = &l_1624;
                uint32_t l_1680 = 0x90C1C13FL;
                const uint16_t l_1700[9] = {0x6249L,0x6249L,0x8E3FL,0x6249L,0x6249L,0x8E3FL,0x6249L,0x6249L,0x8E3FL};
                uint16_t **l_1702 = &l_1670;
                int32_t *l_1713 = &l_1652;
                int i, j;
                for (i = 0; i < 5; i++)
                    l_1601[i] = &l_1586;
                for (i = 0; i < 8; i++)
                    l_1622[i] = 0L;
                for (i = 0; i < 2; i++)
                    l_1667[i] = (void*)0;
                for (g_158 = 0; (g_158 <= 6); g_158 += 1)
                { /* block id: 915 */
                    int16_t *l_1595 = &g_49[0][1][1];
                    int16_t **l_1594 = &l_1595;
                    int8_t ** const **l_1605 = (void*)0;
                    int8_t ** const **l_1606 = &g_1602;
                    uint32_t **l_1607 = &g_1193;
                    uint8_t ***l_1621 = &g_1462[1];
                    int32_t *l_1628 = &l_1610[2][1];
                    int32_t l_1629[10][7][3] = {{{1L,(-4L),0x267F8199L},{0x55938527L,6L,0x8E8F6713L},{0L,0xCFBC452CL,6L},{3L,1L,6L},{1L,0x89CB6D12L,5L},{1L,0xA2C6DA3CL,0L},{4L,0x2E52FDDAL,0x6493937FL}},{{6L,(-1L),(-1L)},{0x290EFBADL,6L,1L},{7L,0xB600EAFDL,0xA55B9F6FL},{(-4L),(-1L),0L},{6L,4L,0L},{(-4L),(-1L),0x3EE4D8E7L},{1L,0L,0x89CB6D12L}},{{(-1L),0xA55B9F6FL,4L},{0x7FC1AA77L,0L,0x9E54C540L},{0x0C87FA46L,0L,0x19C0025BL},{4L,4L,6L},{0x4293F928L,0x3EE4D8E7L,1L},{0x3EE4D8E7L,1L,0x290EFBADL},{1L,0L,(-8L)}},{{1L,1L,0x1C1AF68AL},{(-1L),(-1L),1L},{(-1L),1L,1L},{1L,6L,(-1L)},{1L,0xA2C6DA3CL,0x9F126357L},{0x3EE4D8E7L,(-1L),6L},{0x4293F928L,0x8E8F6713L,0xF46ED1DCL}},{{4L,0L,6L},{0x0C87FA46L,0x55938527L,0x7FC1AA77L},{0x7FC1AA77L,0x7FC1AA77L,0x7F263134L},{(-1L),6L,0L},{1L,1L,(-3L)},{(-4L),0x49A8C653L,1L},{6L,1L,(-3L)}},{{6L,0xCFBC452CL,0L},{(-4L),0x6B2E7EDFL,0x7F263134L},{0xF46ED1DCL,5L,0x7FC1AA77L},{0xA55B9F6FL,6L,6L},{3L,2L,0xF46ED1DCL},{0x89CB6D12L,(-1L),6L},{7L,0L,0x9F126357L}},{{0x49A8C653L,1L,(-1L)},{0x8E8F6713L,0x7F263134L,1L},{0xB600EAFDL,0xD06FC594L,1L},{0x9F126357L,0xD06FC594L,0x1C1AF68AL},{0x267F8199L,0x7F263134L,(-8L)},{1L,1L,0x290EFBADL},{0xD06FC594L,0L,1L}},{{(-1L),(-1L),6L},{0x55938527L,2L,0x19C0025BL},{(-8L),6L,0x9E54C540L},{4L,5L,4L},{0L,0x6B2E7EDFL,0x89CB6D12L},{(-1L),0xCFBC452CL,0x3EE4D8E7L},{0L,1L,0L}},{{0x1C1AF68AL,0x49A8C653L,1L},{0L,1L,0xDC1B3C2BL},{(-1L),6L,1L},{0L,0x7FC1AA77L,0L},{4L,0x55938527L,(-1L)},{(-8L),0L,0x4293F928L},{0x55938527L,0x8E8F6713L,2L}},{{(-1L),(-1L),1L},{0xD06FC594L,0xA2C6DA3CL,1L},{1L,6L,0L},{0x267F8199L,1L,(-1L)},{0x9F126357L,(-1L),(-1L)},{0xB600EAFDL,1L,0L},{0x8E8F6713L,0L,1L}}};
                    int32_t *l_1630 = &l_1624;
                    int32_t *l_1631 = &l_1588[7][0][4];
                    int32_t *l_1632 = &g_1485;
                    int32_t *l_1633 = &l_1622[1];
                    int32_t *l_1634 = &g_570;
                    int32_t *l_1635 = &l_1488[5];
                    int32_t *l_1636 = &l_1587;
                    int32_t *l_1637 = (void*)0;
                    int32_t *l_1638 = &l_1488[1];
                    int32_t *l_1639[10][3] = {{&l_1488[7],&l_1488[7],&g_353[4]},{&l_1587,&g_28,&g_353[4]},{&g_28,&l_1587,&g_353[4]},{&l_1488[7],&l_1488[7],&g_353[4]},{&l_1587,&g_28,&l_1488[7]},{&g_44,&l_1488[7],&l_1488[7]},{&g_1485,&g_1485,&l_1488[7]},{&l_1488[7],&g_44,&l_1488[7]},{&g_44,&l_1488[7],&l_1488[7]},{&g_1485,&g_1485,&l_1488[7]}};
                    int32_t l_1649[7] = {0x87F440C0L,0x87F440C0L,0x8BD8D884L,0x87F440C0L,0x87F440C0L,0x8BD8D884L,0x87F440C0L};
                    int i, j, k;
                    if ((safe_lshift_func_uint8_t_u_s((safe_mul_func_int8_t_s_s(((((*l_1594) = &g_848[0][0][3]) != (((safe_mod_func_uint8_t_u_u((!((*l_1574) &= ((((((+0x22L) , l_1600[2][0]) == ((*l_1606) = g_1602)) < ((((*l_1607) = &p_8) != (void*)0) <= ((((safe_mod_func_uint32_t_u_u(((g_241[g_592][(g_120 + 3)] , 0xF7D6CD39L) <= 1L), (-1L))) , g_50[g_120][g_120]) , (void*)0) != (void*)0))) && 0xBF17978835F93B0BLL) | p_7))), 0x7FL)) >= 1UL) , &g_1334)) & p_8), (-1L))), 4)))
                    { /* block id: 920 */
                        uint32_t * const l_1613 = &g_120;
                        int32_t *l_1623 = &g_353[0];
                        (*l_1623) = (((6L > (g_50[g_120][g_120] , ((*g_156) |= (l_1610[2][1] |= 0x01610BADL)))) >= p_7) >= (((l_1622[0] = ((safe_sub_func_uint8_t_u_u(((l_1613 != &p_7) & ((((((safe_rshift_func_int8_t_s_s((l_1616 != ((safe_div_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(l_1589, 0x64360B2F747C30F1LL)), 0xF8A96347F986A83ELL)) , l_1621)), p_8)) < p_8) < g_50[g_120][g_120]) >= (*g_1498)) > 0x33F11843E8CA3D0CLL) & p_8)), p_8)) >= (*g_1498))) , &g_424) != (void*)0));
                        if (g_241[g_592][(g_120 + 3)])
                            break;
                    }
                    else
                    { /* block id: 926 */
                        (*l_1487) = (void*)0;
                        if (l_1589)
                            break;
                        if (p_7)
                            continue;
                        l_1624 &= p_8;
                    }
                    (*l_1628) ^= (((safe_add_func_uint64_t_u_u((g_22[6] = ((*g_1498) = 6UL)), 18446744073709551610UL)) , (void*)0) != (void*)0);
                    ++l_1645;
                    l_1653--;
                }
                if ((p_7 >= ((0x5704L > ((p_8 != (safe_div_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((((safe_add_func_uint64_t_u_u(l_1664, (*g_1498))) < ((++g_22[2]) <= ((l_1587 , (l_1670 != (void*)0)) , ((((safe_sub_func_int32_t_s_s(((*l_1679) &= ((safe_div_func_int64_t_s_s((safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(l_1643, 3)), l_1610[5][2])), 8UL)) ^ l_1587)), 4294967295UL)) < p_8) <= (-5L)) <= 0x47F5L)))) != l_1680), 1)), l_1648[0])), l_1641))) <= 0xE5C7F93B7F792915LL)) , (*g_60))))
                { /* block id: 940 */
                    uint32_t **l_1683 = &g_1193;
                    uint32_t ***l_1682 = &l_1683;
                    int32_t l_1684 = (-8L);
                    int32_t *l_1685 = &l_1588[3][1][2];
                    int32_t *l_1686 = (void*)0;
                    int32_t l_1687 = (-9L);
                    int32_t *l_1688 = &l_1488[1];
                    int32_t *l_1689 = &l_1622[0];
                    int32_t *l_1690[9][4][4] = {{{(void*)0,&g_1644,(void*)0,&l_1687},{&l_1488[5],(void*)0,&l_1684,&l_1687},{&l_1488[5],(void*)0,(void*)0,&g_44},{(void*)0,&l_1687,&l_1684,&l_1648[0]}},{{&g_353[4],(void*)0,&l_1687,(void*)0},{&l_1687,&g_28,&g_353[4],&l_1488[5]},{(void*)0,&g_1485,&l_1652,(void*)0},{&l_1588[1][0][4],&l_1687,(void*)0,&l_1624}},{{&l_1648[0],&l_1624,(void*)0,&g_157},{&g_353[0],(void*)0,&g_44,&l_1648[1]},{&g_44,&l_1642[0],&l_1624,(void*)0},{&g_1485,&l_1648[0],&l_1642[3],&l_1642[6]}},{{&l_1652,&g_353[4],&l_1641,(void*)0},{&l_1642[3],&l_1488[2],&l_1488[2],&l_1642[3]},{(void*)0,(void*)0,&l_1610[0][2],&g_1644},{&g_157,&l_1648[1],&l_1652,&l_1622[0]}},{{(void*)0,&g_157,&l_1624,&l_1622[0]},{(void*)0,&l_1648[1],&g_28,&g_1644},{&l_1684,(void*)0,&l_1642[0],&l_1642[3]},{&l_1588[3][1][2],&l_1488[2],(void*)0,(void*)0}},{{&l_1684,&g_353[4],(void*)0,&l_1642[6]},{&l_1642[0],&l_1648[0],(void*)0,(void*)0},{&g_44,&l_1642[0],&g_1485,&l_1648[1]},{&g_157,(void*)0,&l_1684,&g_157}},{{&l_1687,&l_1624,&l_1588[1][0][4],&l_1624},{&l_1624,&l_1687,&l_1641,(void*)0},{&g_1644,&g_1485,&l_1622[0],&l_1488[5]},{&g_1485,&g_28,&l_1488[5],(void*)0}},{{(void*)0,(void*)0,(void*)0,&l_1648[0]},{&g_353[4],&l_1687,&g_157,&g_44},{&l_1684,(void*)0,&l_1684,&l_1687},{&l_1684,(void*)0,&l_1684,&l_1687}},{{&l_1684,&g_1644,&g_157,&l_1684},{&g_353[4],&l_1648[1],(void*)0,(void*)0},{(void*)0,(void*)0,&l_1488[5],&l_1587},{&g_1485,&g_353[0],&l_1622[0],&l_1687}}};
                    int i, j, k;
                    (*l_1682) = &g_1193;
                    l_1691++;
                    if (((*l_1679) = l_1650[2][1]))
                    { /* block id: 944 */
                        return p_8;
                    }
                    else
                    { /* block id: 946 */
                        int64_t l_1694[7] = {(-5L),(-2L),(-2L),(-5L),(-2L),(-2L),(-5L)};
                        int32_t l_1695[9][1];
                        uint32_t l_1696 = 0xE6CDCBA1L;
                        int i, j;
                        for (i = 0; i < 9; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_1695[i][j] = 0x924466E4L;
                        }
                        if (l_1694[0])
                            break;
                        (*l_1688) = l_1587;
                        l_1696--;
                        if (l_1624)
                            goto lbl_1699;
                    }
                }
                else
                { /* block id: 952 */
                    uint32_t l_1701 = 1UL;
                    for (g_157 = 0; (g_157 <= 3); g_157 += 1)
                    { /* block id: 955 */
                        (*l_1679) |= (((*g_1193) = 0x54FB6889L) , l_1588[3][1][2]);
                        l_1701 = l_1700[2];
                    }
                }
                l_1488[7] = ((*l_1713) &= (((l_1641 = l_1588[5][0][5]) && p_8) && (((((*l_1586) = (((*l_1702) = func_93(p_8, p_7)) == ((l_1642[0] , (safe_rshift_func_uint8_t_u_s((~(~l_1691)), ((*l_1679) |= (safe_sub_func_uint64_t_u_u((((*g_1463) ^= (l_1588[3][1][2] > (safe_rshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s(l_1588[3][1][2], 4)), 3)))) > 1UL), (-9L))))))) , (void*)0))) , &l_1622[4]) != &l_1648[1]) & 0x5F824377D2A3173ELL)));
                (*g_59) = (l_1714[3][8] = &l_1648[0]);
            }
        }
        (*l_1716) = l_1624;
        for (g_570 = 0; (g_570 < 21); g_570 = safe_add_func_int64_t_s_s(g_570, 5))
        { /* block id: 975 */
            uint32_t l_1720 = 0x131854FDL;
            int32_t l_1732 = (-1L);
            int32_t l_1733[1][9][1] = {{{(-6L)},{1L},{(-6L)},{1L},{(-6L)},{1L},{(-6L)},{1L},{(-6L)}}};
            int16_t *l_1749 = &g_848[4][2][0];
            int8_t **l_1753 = &l_1574;
            int8_t ***l_1752 = &l_1753;
            int8_t ****l_1751 = &l_1752;
            int8_t ** const **l_1755 = (void*)0;
            uint64_t **l_1757 = &g_1498;
            int32_t *l_1818 = (void*)0;
            uint8_t l_1872 = 0x4AL;
            int32_t **l_1886 = &g_567;
            int i, j, k;
        }
    }
    return l_1936;
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_60 g_22 g_90 g_49 g_50 g_44 g_3 g_156 g_157 g_218 g_59 g_56 g_592 g_353 g_833 g_241 g_123 g_1035 g_155 g_424 g_425 g_570 g_1036 g_1037 g_28 g_663 g_848 g_1000 g_104 g_567 g_307 g_349 g_504 g_211 g_158 g_120 g_1193 g_1198 g_678 g_1334
 * writes: g_46 g_59 g_44 g_56 g_90 g_104 g_28 g_452 g_353 g_663 g_349 g_592 g_158 g_833 g_570 g_305 g_211 g_1037 g_504 g_22 g_123 g_157 g_848 g_120 g_50 g_155 g_969 g_218
 */
static uint8_t  func_9(const int8_t  p_10)
{ /* block id: 10 */
    int32_t **l_70 = &g_56;
    int64_t ** const *l_1477 = &g_806;
    for (g_46 = 12; (g_46 != 48); g_46 = safe_add_func_int8_t_s_s(g_46, 6))
    { /* block id: 13 */
        (*g_60) = ((g_59 = &g_56) != (void*)0);
    }
    for (g_46 = 0; (g_46 != 60); g_46 = safe_add_func_int32_t_s_s(g_46, 7))
    { /* block id: 19 */
        int32_t l_63 = 0L;
        int64_t ****l_1476 = &g_969[4];
        int8_t *l_1478 = (void*)0;
        int8_t *l_1479 = &g_218;
        int64_t *l_1480 = (void*)0;
        int64_t *l_1481 = &g_104;
        int32_t l_1482 = 0x97347D85L;
        (*g_1000) = (1UL && (func_13(l_63, p_10) , func_64(l_70, func_71(((l_63 && (safe_mul_func_int16_t_s_s((g_22[2] > ((safe_add_func_int8_t_s_s((safe_mod_func_int64_t_s_s(l_63, ((~l_63) | 65530UL))), 0UL)) >= p_10)), 6UL))) == p_10), l_63), l_63, p_10, l_63)));
        (*g_1000) = (((safe_sub_func_uint8_t_u_u(((l_63 , (safe_add_func_int8_t_s_s(((*g_1036) || ((safe_add_func_int16_t_s_s((&g_662[3][2] == (void*)0), (safe_mul_func_uint16_t_u_u((((g_211[0] = ((safe_sub_func_uint64_t_u_u((*g_424), (-9L))) >= ((*l_1481) |= (p_10 || (l_63 = ((*l_1479) = (safe_mul_func_int16_t_s_s((((*l_1476) = &g_806) != l_1477), l_63)))))))) , 2UL) , l_63), 0x2AC6L)))) && 0L)), l_1482))) == g_49[0][1][1]), p_10)) & g_157) , p_10);
    }
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_44 g_56
 */
static int16_t  func_13(uint64_t  p_14, uint32_t  p_15)
{ /* block id: 6 */
    int32_t l_53 = (-3L);
    int32_t *l_54 = &g_44;
    int32_t **l_55[9][7] = {{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{(void*)0,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,(void*)0,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54},{&l_54,&l_54,&l_54,&l_54,&l_54,&l_54,&l_54}};
    int i, j;
    (*l_54) = (p_14 > l_53);
    g_56 = (void*)0;
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_50 g_28
 * writes: g_46 g_50
 */
static uint64_t  func_16(uint32_t  p_17, uint32_t  p_18, int16_t  p_19, int32_t  p_20)
{ /* block id: 2 */
    int32_t *l_27 = &g_28;
    int32_t *l_29 = &g_28;
    int32_t *l_30 = (void*)0;
    int32_t *l_31 = (void*)0;
    int32_t *l_32 = &g_28;
    int32_t *l_33 = &g_28;
    int32_t *l_34 = &g_28;
    int32_t *l_35 = &g_28;
    int32_t l_36 = 0x88216928L;
    int32_t *l_37 = &l_36;
    int32_t *l_38 = &g_28;
    int32_t *l_39 = (void*)0;
    int32_t *l_40 = &l_36;
    int32_t *l_41 = &g_28;
    int32_t *l_42 = &l_36;
    int32_t *l_43[9][8][1] = {{{&l_36},{&l_36},{&g_28},{&l_36},{&g_28},{&l_36},{&l_36},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&g_28},{&l_36},{&g_28},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&g_28},{&l_36}},{{&g_28},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}},{{&g_28},{&l_36},{&g_28},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}},{{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36},{&l_36}}};
    int16_t l_45 = 1L;
    int i, j, k;
    g_46++;
    g_50[3][1]--;
    return (*l_38);
}


/* ------------------------------------------ */
/* 
 * reads : g_156 g_157 g_44 g_570 g_1000 g_60 g_28 g_104 g_504 g_424 g_425 g_567 g_307 g_90 g_49 g_46 g_50 g_3 g_218 g_59 g_56 g_592 g_353 g_833 g_241 g_123 g_1035 g_155 g_1036 g_1037 g_663 g_848 g_349 g_211 g_158 g_120 g_1193 g_22 g_1198 g_678 g_1334
 * writes: g_1037 g_211 g_44 g_570 g_504 g_22 g_123 g_157 g_28 g_104 g_848 g_90 g_56 g_452 g_353 g_663 g_349 g_592 g_158 g_833 g_305 g_120 g_50 g_155
 */
static int32_t  func_64(int32_t ** p_65, int32_t * p_66, uint16_t  p_67, int64_t  p_68, const int32_t  p_69)
{ /* block id: 573 */
    int32_t l_1110 = 0xB2B6A0F7L;
    int32_t l_1112 = 0x010C41F4L;
    int32_t l_1115[7] = {0x940B301AL,1L,0x940B301AL,0x940B301AL,1L,0x940B301AL,0x940B301AL};
    int32_t l_1118 = 3L;
    int8_t l_1144[5][8] = {{0xD4L,0x77L,9L,0x1EL,(-1L),0x1EL,9L,0x77L},{9L,0x14L,0L,0L,(-1L),0x77L,(-1L),0L},{0xD4L,0x14L,0xD4L,0x77L,9L,0x1EL,(-1L),0x1EL},{0x30L,0x77L,0L,0x77L,0x30L,1L,9L,0L},{0x30L,1L,9L,0L,9L,1L,0x30L,0x77L}};
    int64_t **l_1158 = &g_458[3];
    const uint64_t *l_1171[6][8] = {{&g_50[3][1],(void*)0,&g_22[5],&g_50[1][1],&g_22[5],(void*)0,&g_50[3][1],&g_22[2]},{(void*)0,(void*)0,&g_50[4][3],&g_50[3][1],&g_22[2],&g_50[1][1],&g_50[1][1],&g_22[2]},{&g_50[1][1],&g_22[2],&g_22[2],&g_50[1][1],(void*)0,&g_50[0][4],&g_22[2],&g_22[2]},{&g_50[3][1],&g_50[4][3],(void*)0,(void*)0,&g_22[2],(void*)0,(void*)0,&g_50[4][3]},{&g_22[2],&g_50[4][3],&g_22[2],(void*)0,&g_22[5],&g_50[0][4],(void*)0,(void*)0},{&g_22[2],&g_22[2],&g_50[3][1],&g_50[3][1],&g_22[2],&g_22[2],(void*)0,&g_22[2]}};
    const uint64_t **l_1170 = &l_1171[4][5];
    const uint64_t ***l_1169[10][2][5] = {{{&l_1170,&l_1170,(void*)0,&l_1170,(void*)0},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{(void*)0,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}},{{(void*)0,&l_1170,(void*)0,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,(void*)0}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{(void*)0,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,(void*)0,&l_1170,(void*)0},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,(void*)0}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}},{{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170},{&l_1170,&l_1170,&l_1170,&l_1170,&l_1170}}};
    int32_t **l_1172 = &g_567;
    int32_t l_1176 = 0xFB0046ADL;
    volatile uint64_t **l_1215 = &g_424;
    int8_t *l_1277 = &g_211[3];
    int8_t **l_1276 = &l_1277;
    uint32_t l_1280 = 1UL;
    uint16_t *l_1281[2];
    int16_t l_1282 = (-1L);
    uint64_t *l_1305 = &g_50[4][3];
    uint64_t l_1306 = 0x8EBD6CDCBF94C149LL;
    int64_t * const **l_1328 = (void*)0;
    uint8_t l_1344 = 0x43L;
    uint8_t l_1424[6] = {0xE6L,0xE6L,0xE6L,0xE6L,0xE6L,0xE6L};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1281[i] = &g_90;
    for (g_1037 = 0; g_1037 < 6; g_1037 += 1)
    {
        g_211[g_1037] = (-5L);
    }
    if ((*g_156))
    { /* block id: 575 */
        uint16_t l_1106 = 0xFD2BL;
        int32_t l_1116 = 0x0A6EB24AL;
        int32_t l_1117 = 0x2D077D4AL;
        uint64_t **l_1138 = (void*)0;
        (*p_66) = 0x1CCD435CL;
        for (g_44 = 5; (g_44 != 29); ++g_44)
        { /* block id: 579 */
            int8_t l_1129 = (-1L);
            if ((l_1106 = (*p_66)))
            { /* block id: 581 */
                int32_t l_1111 = 0xC51AB9ACL;
                int32_t *l_1113 = &g_570;
                int32_t *l_1114[6][3];
                uint32_t l_1119[8][4] = {{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL},{0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL,0xEAE92B9EL}};
                uint32_t l_1122[9];
                int i, j;
                for (i = 0; i < 6; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_1114[i][j] = (void*)0;
                }
                for (i = 0; i < 9; i++)
                    l_1122[i] = 4294967293UL;
                for (g_570 = 0; (g_570 >= 21); ++g_570)
                { /* block id: 584 */
                    int32_t *l_1109[6][4] = {{&g_157,&g_353[4],&g_157,&g_157},{&g_157,&g_157,&g_157,&g_157},{(void*)0,&g_157,&g_353[2],&g_157},{&g_157,&g_353[4],&g_353[2],&g_353[2]},{(void*)0,(void*)0,&g_157,&g_353[2]},{&g_157,(void*)0,&g_353[2],&g_157}};
                    int i, j;
                    l_1110 |= (-1L);
                }
                ++l_1119[4][2];
                l_1122[2]++;
            }
            else
            { /* block id: 589 */
                int64_t *l_1134 = &g_504;
                int32_t l_1139 = 0L;
                uint32_t l_1140 = 4294967293UL;
                uint64_t *l_1141[9];
                uint16_t *l_1142 = (void*)0;
                uint16_t *l_1143 = &g_123;
                int32_t *l_1145 = &g_157;
                int32_t *l_1146 = (void*)0;
                int32_t *l_1148 = &l_1118;
                int i;
                for (i = 0; i < 9; i++)
                    l_1141[i] = &g_22[1];
                (*l_1148) = (safe_add_func_int32_t_s_s((((*g_1000) &= l_1115[5]) | (safe_mul_func_int8_t_s_s(l_1129, 0UL))), (safe_add_func_int64_t_s_s((l_1106 || 2L), ((*g_60) ^ (((*l_1145) = ((((((*l_1134) = l_1117) == (p_68 = (~(safe_lshift_func_int16_t_s_u(((((*l_1143) = ((p_69 == ((g_22[6] = (((((void*)0 == l_1138) & l_1139) , (-1L)) ^ l_1140)) , 18446744073709551615UL)) || p_68)) < 6L) >= l_1129), 7))))) ^ (-7L)) | l_1144[4][1]) || l_1129)) < (*p_66)))))));
            }
        }
        for (g_28 = 0; (g_28 == (-29)); g_28 = safe_sub_func_int32_t_s_s(g_28, 6))
        { /* block id: 601 */
            return l_1118;
        }
        return l_1115[5];
    }
    else
    { /* block id: 605 */
        int16_t l_1155 = (-9L);
        int32_t **l_1173 = &g_567;
        int64_t *l_1174 = &g_104;
        int8_t *l_1175 = &l_1144[4][1];
        int16_t *l_1177 = &g_848[3][2][3];
        int32_t *l_1178 = &l_1118;
        uint16_t ***l_1214[6][10] = {{(void*)0,&g_662[0][5],&g_662[0][5],(void*)0,&g_662[5][9],&g_662[5][0],&g_662[5][9],&g_662[0][5],&g_662[5][0],&g_662[5][9]},{&g_662[5][0],&g_662[5][9],&g_662[0][5],&g_662[5][0],&g_662[5][9],&g_662[5][0],&g_662[0][5],&g_662[5][9],&g_662[5][0],&g_662[5][9]},{(void*)0,&g_662[5][9],(void*)0,(void*)0,&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9]},{(void*)0,&g_662[0][5],&g_662[0][5],(void*)0,&g_662[5][9],&g_662[5][0],&g_662[5][9],&g_662[0][5],&g_662[5][0],&g_662[5][9]},{&g_662[5][0],&g_662[5][9],&g_662[0][5],&g_662[5][0],&g_662[5][9],&g_662[5][0],&g_662[0][5],&g_662[5][9],&g_662[5][0],&g_662[5][9]},{(void*)0,&g_662[5][9],(void*)0,(void*)0,&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9],&g_662[5][9]}};
        int i, j;
        (*p_66) = (safe_mod_func_uint64_t_u_u(((safe_div_func_uint8_t_u_u(((l_1155 >= (safe_mul_func_uint8_t_u_u(((&g_567 != (void*)0) || (((p_69 & (((l_1158 == (((*l_1177) = (~(safe_lshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((*l_1175) = ((((*l_1174) |= (p_68 = (safe_add_func_int16_t_s_s(p_68, (~(l_1169[9][0][0] != ((((l_1172 == (l_1173 = l_1173)) , p_69) & p_68) , &g_423[0]))))))) || l_1144[4][1]) < l_1155)), p_67)), l_1155)), l_1176)))) , &l_1174)) , g_504) | g_28)) , l_1155) | (*g_424))), g_504))) < 0xF8L), 0x3BL)) > l_1155), 0x65998C972D58657CLL));
        l_1178 = func_71((*g_567), p_69);
        (*g_59) = func_71((*g_567), g_211[0]);
        for (g_158 = 0; (g_158 <= 5); g_158 += 1)
        { /* block id: 616 */
            int i;
        }
    }
    for (g_120 = (-5); (g_120 <= 56); g_120 = safe_add_func_int8_t_s_s(g_120, 5))
    { /* block id: 682 */
        uint64_t *l_1273 = &g_22[2];
        uint64_t *l_1274 = &g_50[0][3];
        int8_t * const *l_1275 = (void*)0;
        int8_t ***l_1278 = &l_1276;
        int32_t l_1279 = (-4L);
        l_1279 = (~(!(safe_lshift_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s(g_46, ((((safe_div_func_int64_t_s_s((safe_mul_func_int16_t_s_s((((~(safe_rshift_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u((((safe_mul_func_int8_t_s_s((1UL > ((*g_1193) , (((((*l_1274) = ((*l_1273) &= p_68)) , ((*g_1198) , l_1275)) != ((*l_1278) = l_1276)) | (0xC4AC67EEL != ((*g_1193) = p_69))))), g_211[0])) & l_1279) >= l_1279), l_1115[5])) & 0x616BL), l_1279))) == p_68) , l_1280), l_1176)), 0x5681B3ABC4C35322LL)) & l_1279) ^ p_68) < (-1L)))) != 6L), p_67)), p_68))));
        for (g_570 = 8; (g_570 >= 0); g_570 -= 1)
        { /* block id: 690 */
            (**g_59) = 0xA1F1FD00L;
            (*p_66) = (*p_66);
            for (g_157 = 0; (g_157 >= 0); g_157 -= 1)
            { /* block id: 695 */
                int i, j, k;
                (*p_66) = g_49[g_157][g_570][(g_157 + 1)];
            }
        }
    }
    if (((p_67++) , (safe_sub_func_int64_t_s_s(((safe_div_func_int8_t_s_s((p_69 > ((((*l_1305) = (safe_lshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(l_1144[4][1], 65531UL)), ((safe_mul_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(g_678, (safe_div_func_int32_t_s_s((p_68 > ((p_67++) , (l_1115[5] & ((*g_56) ^= (safe_mod_func_int16_t_s_s(0xCAE5L, (safe_rshift_func_uint8_t_u_u(l_1115[0], (p_68 || 0x14362591L))))))))), 0xF5083ADAL)))), 1UL)) & (*g_1000))))) < l_1306) < (*g_1036))), p_68)) == p_68), (-3L)))))
    { /* block id: 704 */
        int32_t l_1307[1];
        uint64_t **l_1308 = &l_1305;
        uint64_t ***l_1309 = &l_1308;
        int i;
        for (i = 0; i < 1; i++)
            l_1307[i] = 0L;
        (*g_1000) = l_1307[0];
        (*l_1309) = l_1308;
        (**g_59) = (*g_156);
    }
    else
    { /* block id: 708 */
        uint16_t l_1310 = 0UL;
        uint64_t **l_1346 = &l_1305;
        uint64_t ***l_1345 = &l_1346;
        int64_t **l_1348[2];
        uint32_t * const *l_1384 = &g_1193;
        uint16_t ***l_1453[4];
        int i;
        for (i = 0; i < 2; i++)
            l_1348[i] = &g_458[1];
        for (i = 0; i < 4; i++)
            l_1453[i] = &g_662[5][9];
        if (l_1118)
        { /* block id: 709 */
            int64_t l_1327[2];
            int64_t * const ***l_1329 = &l_1328;
            int32_t l_1347[7][7][2] = {{{1L,0x3BCC068FL},{0x508A8522L,0L},{5L,0L},{0x508A8522L,0x3BCC068FL},{1L,0x508A8522L},{2L,6L},{0L,0xF7AD937BL}},{{1L,1L},{0xF7AD937BL,0L},{6L,2L},{0x508A8522L,1L},{0x3BCC068FL,0x508A8522L},{0L,5L},{0L,0x508A8522L}},{{0x3BCC068FL,1L},{0x508A8522L,2L},{6L,0L},{0xF7AD937BL,1L},{1L,0xF7AD937BL},{0L,6L},{2L,0x508A8522L}},{{1L,0x3BCC068FL},{0x508A8522L,0L},{5L,0L},{0x508A8522L,0x3BCC068FL},{1L,0x508A8522L},{2L,6L},{0L,0xF7AD937BL}},{{1L,1L},{0xF7AD937BL,0L},{6L,2L},{0x508A8522L,1L},{0x3BCC068FL,0x508A8522L},{0L,5L},{0L,0x508A8522L}},{{0x3BCC068FL,1L},{0x508A8522L,2L},{6L,0L},{0xF7AD937BL,1L},{1L,0xF7AD937BL},{0L,6L},{2L,0x508A8522L}},{{1L,0x3BCC068FL},{0x508A8522L,0L},{5L,0L},{0x508A8522L,0x3BCC068FL},{1L,0x508A8522L},{2L,6L},{0L,0xF7AD937BL}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_1327[i] = (-1L);
            if (((((**p_65) = (l_1310 ^ ((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(g_28, (safe_mod_func_uint64_t_u_u(((safe_add_func_uint16_t_u_u((l_1310 == ((void*)0 != &l_1310)), (p_69 | ((&g_806 == ((*l_1329) = ((safe_lshift_func_int8_t_s_u((safe_mod_func_int64_t_s_s(((*g_1198) && (safe_sub_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(1L, 0x73L)), l_1327[0]))), 0xE4E4699329FD0C40LL)), g_678)) , l_1328))) | p_67)))) > g_570), 0xDEA807D3AA78B9DALL)))), 10)) != (*g_1193)))) <= 0x93E06E87L) ^ l_1110))
            { /* block id: 712 */
                int64_t ***l_1349 = &l_1348[0];
                l_1347[3][1][1] = ((safe_sub_func_uint64_t_u_u((safe_rshift_func_int16_t_s_u(p_67, 3)), ((p_67 != (g_1334 == (!l_1310))) , ((((***l_1345) = (safe_lshift_func_uint8_t_u_s(p_67, ((*l_1277) &= ((((safe_rshift_func_int16_t_s_s(((safe_div_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(l_1110, 9)), ((**p_65) = (65533UL || (((*g_567) , ((l_1306 & p_68) , &g_567)) == &g_567))))) & l_1327[1]), l_1344)) , l_1345) != &l_1346) || l_1144[3][5]))))) < p_69) > 0xBB04L)))) < p_68);
                (*l_1349) = l_1348[1];
                return (*p_66);
            }
            else
            { /* block id: 719 */
                int32_t l_1350 = 5L;
                return l_1350;
            }
        }
        else
        { /* block id: 722 */
            for (g_158 = 0; (g_158 <= 1); g_158 += 1)
            { /* block id: 725 */
                return l_1115[5];
            }
        }
    }
    return (**p_65);
}


/* ------------------------------------------ */
/* 
 * reads : g_90 g_49 g_46 g_50 g_44 g_3 g_104 g_28 g_156 g_157 g_218 g_60 g_59 g_56 g_592 g_353 g_158 g_833 g_241 g_123 g_1035 g_155 g_424 g_425 g_570 g_1036 g_1037 g_663 g_848 g_1000 g_567 g_307 g_349
 * writes: g_90 g_104 g_44 g_28 g_56 g_452 g_353 g_663 g_349 g_592 g_158 g_833 g_570 g_305 g_211
 */
static int32_t * func_71(int32_t  p_72, int16_t  p_73)
{ /* block id: 20 */
    uint16_t *l_89 = &g_90;
    int64_t *l_103 = &g_104;
    int32_t l_107 = 0x5FFC7B43L;
    int32_t *l_108 = &g_44;
    uint16_t **l_739 = &g_663;
    uint32_t *l_1092 = &g_305;
    int32_t ***l_1095[1][10] = {{&g_59,&g_59,&g_59,&g_59,&g_59,&g_59,&g_59,&g_59,&g_59,&g_59}};
    int32_t **l_1096 = (void*)0;
    uint16_t l_1097 = 0x529BL;
    uint64_t **l_1098 = (void*)0;
    int8_t *l_1099 = &g_211[2];
    uint8_t *l_1100 = (void*)0;
    uint8_t *l_1101 = &g_833[0];
    int64_t l_1102 = (-1L);
    int32_t *l_1103 = &g_44;
    int i, j;
    (*g_59) = func_83((0x73L & (safe_lshift_func_uint16_t_u_s(((*l_89)++), 9))), (((*l_739) = func_93(((((((*l_108) = (func_96((((((*l_103) = (((-1L) < g_49[0][6][1]) && (safe_sub_func_uint32_t_u_u(p_73, ((safe_div_func_int64_t_s_s(g_46, 0x62E654CDFF1806A2LL)) == 0x6CL))))) , g_50[3][1]) >= ((((safe_sub_func_uint32_t_u_u(((g_49[0][1][1] >= l_107) <= 0x2085L), g_44)) | l_107) , g_3[2]) != 18446744073709551611UL)) && 0xD3DDL), l_108) , p_73)) < l_107) , 0xA68ADC20L) < (-1L)) || 0xFB326C4EL), p_72)) == l_89), l_107);
    (*l_108) = (((safe_add_func_int32_t_s_s((*l_108), ((*g_1000) = ((((((((*l_1101) = (safe_add_func_uint64_t_u_u((((safe_add_func_uint32_t_u_u((*l_108), (safe_div_func_int8_t_s_s(((*l_1099) = ((safe_rshift_func_int16_t_s_u(((((*l_103) |= (safe_div_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u(((*l_1092) = g_155), g_425)) == ((safe_rshift_func_uint16_t_u_s(65526UL, 8)) , (*l_108))), (p_72 || (((((l_1096 = (void*)0) != ((l_1097 <= 0UL) , &g_56)) , l_1098) == l_1098) , p_73))))) , (*g_567)) , p_72), 12)) ^ 1UL)), g_349)))) , 0UL) , 18446744073709551610UL), g_848[2][0][0]))) < 0xC1L) , p_73) < 0x551CL) <= p_73) == p_73) > g_218)))) , (*l_108)) >= p_72);
    (*g_1000) ^= (l_1102 , ((*l_108) < g_3[2]));
    return l_1103;
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_59 g_592 g_353 g_104 g_56 g_158 g_833 g_241 g_123 g_1035 g_155 g_424 g_425 g_570 g_60 g_1036 g_1037 g_28 g_3 g_663 g_46 g_848 g_1000
 * writes: g_44 g_349 g_56 g_592 g_353 g_104 g_158 g_90 g_833 g_570
 */
static int32_t * func_83(uint16_t  p_84, int32_t  p_85, int32_t  p_86)
{ /* block id: 346 */
    int32_t l_740 = 1L;
    int32_t l_747 = (-1L);
    int32_t l_749 = 1L;
    int32_t l_750 = 0x84504915L;
    int32_t l_753[9] = {0x3060DAAEL,0xEAB4C608L,0x3060DAAEL,0xEAB4C608L,0x3060DAAEL,0xEAB4C608L,0x3060DAAEL,0xEAB4C608L,0x3060DAAEL};
    uint32_t l_763 = 0x73298A48L;
    uint8_t l_768[4];
    int32_t *l_778 = (void*)0;
    uint16_t l_784 = 0x96EDL;
    uint32_t *l_813 = (void*)0;
    uint32_t **l_812 = &l_813;
    int64_t l_827[9] = {3L,5L,5L,3L,5L,5L,3L,5L,5L};
    int32_t *l_900[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint32_t l_925[4] = {4294967292UL,4294967292UL,4294967292UL,4294967292UL};
    uint16_t l_947[10][4][6] = {{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0UL,65535UL}},{{0UL,65534UL,65533UL,65534UL,0UL,65535UL},{0UL,65534UL,65533UL,65534UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL}},{{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL}},{{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL},{0xDBB9L,65531UL,0UL,65531UL,0xDBB9L,65534UL}}};
    int64_t ***l_967 = &g_806;
    int32_t *l_1004 = (void*)0;
    uint8_t *l_1007 = (void*)0;
    int32_t l_1065 = 0xED2179B5L;
    int8_t *l_1073[2][4];
    int8_t **l_1072 = &l_1073[0][1];
    uint32_t *l_1074 = &l_925[0];
    int32_t *l_1075 = &l_747;
    int32_t *l_1076 = &l_1065;
    int32_t *l_1077 = &g_28;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_768[i] = 1UL;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
            l_1073[i][j] = &g_592;
    }
    if (l_740)
    { /* block id: 347 */
        int32_t l_746 = 0x480FDA3CL;
        int32_t l_748 = 0xE99F980CL;
        int64_t l_751 = (-1L);
        int32_t l_754 = 1L;
        int32_t l_756 = 0xCE386A23L;
        int32_t l_757[7] = {1L,1L,1L,1L,1L,1L,1L};
        int8_t l_762 = 0xFCL;
        int i;
        for (g_44 = (-19); (g_44 <= 27); g_44 = safe_add_func_uint8_t_u_u(g_44, 1))
        { /* block id: 350 */
            int8_t l_745 = 0xCFL;
            int32_t l_752 = 6L;
            int32_t l_755[4];
            uint64_t l_758 = 0x270C1EB8015C2729LL;
            int32_t *l_766[1][7][4];
            uint32_t l_774 = 0xF8DA05BEL;
            int32_t *l_777 = &l_748;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_755[i] = (-4L);
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 7; j++)
                {
                    for (k = 0; k < 4; k++)
                        l_766[i][j][k] = &l_752;
                }
            }
            for (g_349 = 0; (g_349 <= 2); g_349 += 1)
            { /* block id: 353 */
                int32_t *l_743 = (void*)0;
                int32_t *l_744[7][4] = {{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_353[6],&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_570,&g_570},{&g_570,&g_570,&g_353[6],&g_570},{&g_570,&g_570,&g_570,&g_570}};
                int64_t l_761 = 0L;
                int i, j;
                ++l_758;
                (*g_59) = l_744[2][3];
                l_763--;
            }
            --l_768[3];
            for (g_592 = 0; (g_592 <= 3); g_592 += 1)
            { /* block id: 361 */
                int32_t l_773 = (-1L);
                int i;
                for (l_745 = 0; (l_745 <= 6); l_745 += 1)
                { /* block id: 364 */
                    int i;
                    g_353[(g_592 + 1)] ^= (safe_sub_func_int16_t_s_s((l_755[g_592] || 0x095A5BA4C1BD83BCLL), l_753[(g_592 + 5)]));
                }
                ++l_774;
                for (g_104 = 3; (g_104 >= 0); g_104 -= 1)
                { /* block id: 370 */
                    int i;
                    (*g_59) = &l_755[g_104];
                    return l_778;
                }
            }
        }
    }
    else
    { /* block id: 376 */
        int32_t *l_787 = (void*)0;
        (*g_59) = (*g_59);
        for (l_740 = 0; (l_740 == (-19)); l_740--)
        { /* block id: 380 */
            int32_t *l_781 = &l_750;
            int32_t *l_782 = &g_353[4];
            int32_t *l_783 = &l_747;
            ++l_784;
            (*g_59) = l_787;
        }
        return (*g_59);
    }
    for (g_158 = 16; (g_158 < 6); g_158 = safe_sub_func_uint16_t_u_u(g_158, 4))
    { /* block id: 388 */
        uint64_t *l_838 = &g_50[2][1];
        uint64_t **l_837 = &l_838;
        int32_t l_839 = 0x4926BE9FL;
        int32_t l_856 = 1L;
        int32_t l_857 = (-1L);
        int32_t l_859 = 9L;
        int32_t l_860 = 0xFBD1256FL;
        int32_t l_864[8] = {0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L,0x95EDD8F9L};
        int32_t l_926 = 1L;
        int8_t l_946 = 0x8CL;
        int8_t l_983 = (-1L);
        int32_t *l_984 = &g_353[4];
        const int32_t *l_999 = (void*)0;
        int64_t *l_1015[10][7][3] = {{{&l_827[6],&l_827[5],&g_504},{&l_827[5],&l_827[5],&l_827[5]},{&g_504,&l_827[5],&g_504},{&l_827[5],&l_827[5],(void*)0},{&g_504,&g_104,(void*)0},{&g_104,&g_104,&l_827[5]},{&g_504,&g_504,&g_104}},{{&l_827[5],&l_827[5],(void*)0},{&g_504,&g_104,&g_104},{&l_827[5],(void*)0,(void*)0},{&l_827[6],&g_504,&g_104},{&g_104,&l_827[0],&l_827[5]},{(void*)0,(void*)0,(void*)0},{(void*)0,&l_827[0],(void*)0}},{{(void*)0,&g_504,&g_504},{&l_827[5],(void*)0,&l_827[5]},{&g_104,&g_104,&g_504},{&l_827[5],&l_827[5],(void*)0},{(void*)0,&g_504,&l_827[5]},{(void*)0,&g_104,&g_104},{(void*)0,&g_104,&l_827[5]}},{{&g_104,&l_827[5],(void*)0},{&l_827[6],&l_827[5],&g_504},{&l_827[5],&l_827[5],&l_827[5]},{&g_504,&l_827[5],&g_504},{&l_827[5],&l_827[5],(void*)0},{&g_504,&g_104,(void*)0},{&g_104,&g_104,&l_827[5]}},{{&g_504,&g_504,&l_827[5]},{&l_827[5],&l_827[3],&g_504},{&g_104,&l_827[5],&l_827[5]},{&l_827[0],(void*)0,&g_504},{(void*)0,&g_104,&l_827[5]},{&l_827[5],&l_827[4],&l_827[3]},{&l_827[5],&g_504,&l_827[1]}},{{&g_104,&l_827[4],&g_504},{(void*)0,&g_104,&l_827[5]},{(void*)0,(void*)0,&g_104},{&l_827[5],&l_827[5],&g_104},{(void*)0,&l_827[3],(void*)0},{(void*)0,&g_104,&g_104},{&g_104,&l_827[1],&l_827[1]}},{{&l_827[5],&l_827[5],&g_104},{&l_827[5],&l_827[6],(void*)0},{(void*)0,&l_827[1],&g_104},{&l_827[0],(void*)0,&g_104},{&g_104,&l_827[1],&l_827[5]},{&l_827[5],&l_827[6],&g_504},{&g_504,&l_827[5],&l_827[1]}},{{(void*)0,&l_827[1],&l_827[3]},{&g_504,&g_104,&l_827[5]},{&l_827[5],&l_827[3],&g_504},{&g_104,&l_827[5],&l_827[5]},{&l_827[0],(void*)0,&g_504},{(void*)0,&g_104,&l_827[5]},{&l_827[5],&l_827[4],&l_827[3]}},{{&l_827[5],&g_504,&l_827[1]},{&g_104,&l_827[4],&g_504},{(void*)0,&g_104,&l_827[5]},{(void*)0,(void*)0,&g_104},{&l_827[5],&l_827[5],&g_104},{(void*)0,&l_827[3],(void*)0},{(void*)0,&g_104,&g_104}},{{&g_104,&l_827[1],&l_827[1]},{&l_827[5],&l_827[5],&g_104},{&l_827[5],&l_827[6],(void*)0},{(void*)0,&l_827[1],&g_104},{&l_827[0],(void*)0,&g_104},{&g_104,&l_827[1],&l_827[5]},{&l_827[5],&l_827[6],&g_504}}};
        uint8_t *l_1016[10] = {&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1],&g_241[7][1]};
        int32_t ***l_1032 = &g_59;
        int8_t **l_1038 = (void*)0;
        uint16_t *l_1039 = &l_947[3][1][1];
        uint32_t *l_1040 = &g_349;
        uint32_t l_1041 = 4UL;
        int16_t l_1042[6][5][4] = {{{0xE3C7L,(-2L),(-1L),(-1L)},{(-3L),(-3L),(-7L),0x4078L},{0x2531L,(-1L),(-1L),7L},{0xE3C7L,0x4078L,0x7A6DL,(-1L)},{(-2L),0x4078L,9L,7L}},{{0x4078L,(-1L),0x209DL,0x4078L},{(-5L),(-3L),(-1L),(-1L)},{0x200AL,(-2L),9L,(-2L)},{(-3L),1L,(-5L),0xAED9L},{0xE3C7L,(-3L),(-8L),(-1L)}},{{7L,0x2531L,(-7L),0L},{7L,(-1L),(-8L),(-3L)},{0xE3C7L,0L,(-5L),(-1L)},{(-3L),0x200AL,9L,0x2531L},{0x200AL,0x5B31L,0x5B31L,0x209DL}},{{0x2B52L,0xE3C7L,(-7L),(-1L)},{(-1L),(-1L),7L,(-1L)},{(-8L),9L,5L,(-1L)},{0x5DEDL,(-1L),0xE78DL,(-1L)},{(-5L),0xE3C7L,0x2531L,0x209DL}},{{0x7A6DL,0x5B31L,(-1L),(-5L)},{0x5DEDL,0x209DL,0x5DEDL,0xE78DL},{(-1L),1L,7L,0x7A6DL},{1L,0x5B31L,9L,1L},{0x2B52L,(-5L),9L,(-1L)}},{{1L,(-1L),7L,(-1L)},{(-1L),9L,0x5DEDL,(-8L)},{0x5DEDL,(-8L),(-1L),(-1L)},{0x7A6DL,0x7A6DL,0x2531L,(-1L)},{(-5L),0x5B31L,0xE78DL,0xE3C7L}}};
        int i, j, k;
        for (g_90 = 1; (g_90 > 5); ++g_90)
        { /* block id: 391 */
            uint32_t *l_794 = &g_155;
            uint8_t *l_803 = &g_241[3][6];
            int32_t l_804 = 0x685EB8D5L;
            int8_t *l_805[7] = {&g_211[0],&g_211[0],&g_211[0],&g_211[0],&g_211[0],&g_211[0],&g_211[0]};
            uint8_t *l_807 = &g_122;
            int32_t *l_814 = &g_353[4];
            uint64_t *l_824 = &g_50[1][2];
            uint64_t **l_823 = &l_824;
            int32_t l_861 = 4L;
            int32_t l_862 = 0xFF7A8D44L;
            uint64_t * const *l_873 = &l_824;
            uint16_t l_913 = 5UL;
            int32_t l_932 = 0x36472C70L;
            int32_t l_934 = 0x972CD52FL;
            int32_t l_935 = 0xEC2797DCL;
            int32_t l_936 = 0x940CA627L;
            int32_t l_937 = 0x8CC60B6AL;
            int32_t l_938[8][9] = {{0xF9BF4E48L,5L,(-1L),0xF9BF4E48L,(-3L),1L,5L,5L,1L},{0x78B802D2L,1L,0L,1L,0x78B802D2L,3L,1L,0x61CB4A74L,6L},{5L,(-3L),0xB2FE8975L,1L,(-3L),(-1L),(-3L),1L,0xB2FE8975L},{0x78B802D2L,0x78B802D2L,6L,0x61CB4A74L,1L,3L,0x78B802D2L,1L,0L},{0xF9BF4E48L,(-3L),1L,5L,5L,1L,(-3L),0xF9BF4E48L,(-1L)},{1L,1L,6L,1L,0xA4BDAA3FL,0x76BDA43DL,1L,1L,0x76BDA43DL},{0xBB90E6C1L,5L,0xB2FE8975L,5L,0xBB90E6C1L,0x8095BFC4L,5L,1L,(-1L)},{1L,0xA4BDAA3FL,0L,0x61CB4A74L,0xA4BDAA3FL,6L,0xA4BDAA3FL,0x61CB4A74L,0L}};
            int64_t l_940 = 6L;
            const uint64_t l_963 = 0x7C7EF5721ABC7541LL;
            int i, j;
        }
        (*g_59) = &l_750;
        (*g_56) = (safe_mod_func_uint32_t_u_u((((0xB4L >= ((l_1007 == ((safe_add_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((!(((*l_984) = (safe_div_func_uint32_t_u_u((p_85 & p_84), 3L))) > (((++g_833[0]) != 0x38L) || (g_241[9][5] < (p_84 != (safe_add_func_int32_t_s_s(0x52D16866L, p_86))))))) < p_86), p_86)), p_86)) , (void*)0)) , 1UL)) >= g_241[8][1]) , 4294967295UL), g_123));
        if (((((l_1041 &= ((*l_1040) = (safe_add_func_int8_t_s_s((safe_div_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_s((((((!(((**g_59) = ((safe_add_func_int16_t_s_s((l_1032 != (void*)0), (safe_add_func_uint8_t_u_u((g_1035[4] != l_1038), (((*l_1039) |= (***l_1032)) || g_155))))) > 0UL)) | (p_85 & (p_85 , (*g_424))))) > 0xB1L) >= p_86) < 0x712F39DCL) == (*l_984)), p_84)), (*l_984))) && 0x82514917L), 0xBD969A0DL)), p_84)))) , 0UL) , g_570) , (-1L)))
        { /* block id: 545 */
            (*g_56) = (*g_60);
        }
        else
        { /* block id: 547 */
            int32_t l_1043 = 0L;
            int32_t l_1044 = 0L;
            int32_t l_1045 = 0L;
            int32_t l_1046[4];
            uint16_t l_1047 = 0x6AFBL;
            int i;
            for (i = 0; i < 4; i++)
                l_1046[i] = 0xEEFB9131L;
            l_1047++;
            if ((p_85 & ((safe_div_func_uint8_t_u_u(0xF6L, (*g_1036))) == (safe_div_func_int32_t_s_s((**g_59), (+4294967295UL))))))
            { /* block id: 549 */
                (**l_1032) = (**l_1032);
            }
            else
            { /* block id: 551 */
                if ((**g_59))
                    break;
                p_86 ^= (!0x9F40L);
                if (l_1044)
                    continue;
                (**l_1032) = &l_1045;
            }
        }
    }
    (*g_1000) = (g_28 < (safe_add_func_uint8_t_u_u((g_3[1] <= 0x9367D30BL), ((p_86 >= ((safe_rshift_func_int8_t_s_u((((*l_1074) = (!(g_123 , (safe_sub_func_int64_t_s_s((safe_div_func_uint8_t_u_u(l_1065, (safe_lshift_func_uint16_t_u_u((((safe_sub_func_uint16_t_u_u((*g_663), (safe_add_func_int16_t_s_s((((*l_1072) = l_1007) != (g_848[2][0][0] , &g_211[0])), 0xC3D4L)))) || p_86) , p_86), 11)))), p_86))))) | p_86), 6)) == g_833[0])) , 4UL))));
    return l_1077;
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_56 g_44
 * writes: g_56 g_452 g_353
 */
static uint16_t * func_93(int8_t  p_94, const uint8_t  p_95)
{ /* block id: 179 */
    int32_t * const l_471 = &g_44;
    int32_t **l_472 = &g_56;
    int32_t l_476 = 0xD87785C2L;
    uint32_t l_487 = 1UL;
    uint32_t l_531 = 0xBF1C4925L;
    int32_t l_598[8][9] = {{(-7L),(-5L),7L,0L,7L,(-5L),(-7L),0x6D039B72L,0x8F28484CL},{6L,0xEBCFC4B3L,0xCC2DD43AL,0x099D7967L,0L,(-1L),6L,6L,0x099D7967L},{1L,7L,0x6D039B72L,(-1L),1L,0xCC2DD43AL,(-3L),0x6D039B72L,(-7L)},{0x2F6DC7A6L,0x6D039B72L,0x8F2AD453L,(-3L),0x22543C3AL,0x8766B66EL,0x6D039B72L,0L,0x6D039B72L},{0x099D7967L,0x274ED090L,0x8F2AD453L,0x8F2AD453L,0x274ED090L,0x099D7967L,1L,0x8F28484CL,0L},{(-5L),(-7L),0x6D039B72L,0x2857A868L,2L,(-3L),0xA0259E46L,1L,0x274ED090L},{0xAAED65EEL,0xBC42BA49L,0L,(-1L),3L,0x8F2AD453L,0x2F6DC7A6L,0xAAED65EEL,2L},{0L,1L,2L,0x8F2AD453L,0xBC42BA49L,0L,6L,6L,0L}};
    uint8_t l_654[9];
    int32_t ***l_688 = &l_472;
    uint64_t *l_718 = &g_22[2];
    uint16_t l_735 = 0x122BL;
    uint16_t *l_738 = &g_46;
    int i, j;
    for (i = 0; i < 9; i++)
        l_654[i] = 0UL;
    (*l_472) = l_471;
    if ((**g_59))
    { /* block id: 181 */
        uint16_t *l_473 = &g_46;
        (*g_59) = (*g_59);
        return l_473;
    }
    else
    { /* block id: 184 */
        int32_t *l_474 = &g_353[4];
        int32_t *l_475 = &g_28;
        int32_t *l_477 = &g_157;
        int32_t l_478 = (-1L);
        int32_t *l_479 = &g_353[2];
        int32_t *l_480 = &g_28;
        int32_t *l_481 = &g_44;
        int32_t *l_482 = &g_44;
        int32_t *l_483 = &g_28;
        int32_t *l_484 = &g_157;
        int32_t *l_485 = &g_353[4];
        int32_t *l_486 = (void*)0;
        uint64_t l_507 = 18446744073709551609UL;
        uint32_t *l_540 = &g_349;
        int16_t *l_541 = &g_49[0][6][1];
        uint8_t *l_542 = &g_122;
        int32_t l_557 = 1L;
        int32_t l_600[5][4][5] = {{{0x1BD2C4DFL,(-7L),0xBCD321F1L,(-4L),(-7L)},{0xF21E2A7AL,0x6A0AFD5FL,7L,0xF3B0F000L,0x9E02B04DL},{0x1DA41F62L,0xF89812F9L,0xF3B0F000L,(-1L),0x3C492620L},{0x20F205E0L,(-7L),(-10L),0x20F205E0L,(-1L)}},{{0x9F178DF0L,(-4L),0L,0L,(-1L)},{(-7L),0x9F178DF0L,0x3C492620L,0x1BD2C4DFL,0x3C492620L},{0x1BD2C4DFL,0x1BD2C4DFL,0x970F96B3L,7L,0x9E02B04DL},{0x304D4EB3L,1L,0xD58D211DL,0L,(-7L)}},{{0xAC50C93FL,0xD58D211DL,0x3C492620L,(-1L),0xF3B0F000L},{7L,1L,5L,0xAC50C93FL,0x1BD2C4DFL},{0L,0x1BD2C4DFL,0xF21E2A7AL,0xB5F51031L,(-4L)},{0xAC50C93FL,0x9F178DF0L,0xF3B0F000L,1L,7L}},{{0x3F07111AL,(-4L),(-9L),1L,0xAC50C93FL},{7L,(-7L),0xB5F51031L,0xB5F51031L,(-7L)},{(-7L),0xF89812F9L,7L,0xAC50C93FL,0L},{0x1DA41F62L,0x6A0AFD5FL,0x44ED3D02L,(-1L),0x67819783L}},{{0L,(-7L),0xF21E2A7AL,0L,(-1L)},{0x1DA41F62L,0xB5F51031L,0L,7L,0xD58D211DL},{(-7L),0x1DA41F62L,0L,0x1BD2C4DFL,0x67819783L},{7L,0x1BD2C4DFL,0xD58D211DL,0L,0x9E02B04DL}}};
        uint8_t l_606 = 250UL;
        int i, j, k;
        for (g_452 = 0; g_452 < 7; g_452 += 1)
        {
            g_353[g_452] = 0x1C3E4CF9L;
        }
        ++l_487;
    }
    return l_738;
}


/* ------------------------------------------ */
/* 
 * reads : g_104 g_44 g_28 g_156 g_157 g_218 g_3 g_60 g_59 g_56
 * writes: g_104 g_44 g_28 g_56
 */
static uint8_t  func_96(const uint64_t  p_97, int32_t * p_98)
{ /* block id: 23 */
    int32_t * const l_109 = (void*)0;
    int32_t ***l_118 = &g_59;
    int32_t l_124[5][2];
    int64_t *l_131 = (void*)0;
    int64_t **l_130[9][4] = {{&l_131,&l_131,(void*)0,&l_131},{&l_131,&l_131,(void*)0,(void*)0},{&l_131,&l_131,&l_131,&l_131},{&l_131,&l_131,&l_131,&l_131},{&l_131,&l_131,&l_131,&l_131},{&l_131,&l_131,&l_131,&l_131},{&l_131,&l_131,(void*)0,&l_131},{&l_131,&l_131,&l_131,(void*)0},{&l_131,&l_131,&l_131,&l_131}};
    int64_t ***l_129 = &l_130[8][1];
    int32_t l_150 = 0xC68AEAC4L;
    uint16_t l_254 = 0x365FL;
    uint64_t l_328 = 1UL;
    uint8_t l_470 = 0x86L;
    int i, j;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
            l_124[i][j] = (-1L);
    }
    for (g_104 = 0; (g_104 <= 4); g_104 += 1)
    { /* block id: 26 */
        const int32_t *l_110[10][6] = {{(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28},{(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28},{(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28},{(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28},{(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28},{(void*)0,&g_28,(void*)0,&g_28,(void*)0,&g_28},{&g_28,&g_28,(void*)0,&g_28,(void*)0,&g_28},{&g_28,&g_28,(void*)0,&g_28,(void*)0,&g_28},{&g_28,&g_28,(void*)0,&g_28,(void*)0,&g_28},{&g_28,&g_28,(void*)0,&g_28,(void*)0,&g_28}};
        const int32_t **l_111 = &l_110[5][5];
        const int64_t *l_117 = &g_104;
        int32_t l_119 = 0L;
        uint16_t * const l_147 = &g_123;
        int32_t **l_271 = (void*)0;
        int64_t ***l_298 = &l_130[8][1];
        int64_t l_350 = 0xBA5CBCEE99220F0BLL;
        int32_t l_354 = 0x3476589CL;
        int32_t l_356 = 1L;
        int32_t l_362 = 5L;
        int32_t l_368 = 0x1E72491DL;
        int32_t l_371 = 0L;
        int32_t l_373 = (-6L);
        int32_t l_377 = (-1L);
        int32_t l_381 = (-9L);
        int64_t l_467 = (-1L);
        int i, j;
        (*p_98) = ((void*)0 != l_109);
        (*l_111) = l_110[5][5];
        (*p_98) = (*p_98);
        for (g_28 = 0; (g_28 <= 4); g_28 += 1)
        { /* block id: 32 */
            int16_t l_128 = 0x1DE7L;
            int32_t *l_161 = &l_124[1][0];
            uint64_t l_166 = 0x58E28627D2885B45LL;
            int64_t ** const l_209 = &l_131;
            int32_t l_245 = 0xC4ECCF17L;
            uint8_t *l_253[8] = {&g_241[6][5],&g_241[8][1],&g_241[6][5],&g_241[8][1],&g_241[6][5],&g_241[8][1],&g_241[6][5],&g_241[8][1]};
            const uint64_t l_348[5][7][7] = {{{0x7801207660B678B5LL,2UL,0UL,0x7801207660B678B5LL,5UL,0xFCCCF3AA1B837C6DLL,0x4D20151E4F78FD8DLL},{4UL,0x73102F56558FA1B8LL,18446744073709551615UL,5UL,18446744073709551608UL,18446744073709551615UL,1UL},{18446744073709551608UL,4UL,0UL,18446744073709551613UL,2UL,18446744073709551614UL,18446744073709551614UL},{0x8D522F74B0D35671LL,4UL,0xF947EAB82EBD33D6LL,4UL,0x8D522F74B0D35671LL,0xF0A7AF316F5AD84ELL,2UL},{0x2542F0818798A2A8LL,0x73102F56558FA1B8LL,18446744073709551609UL,18446744073709551615UL,0x251B4D85EDA7B548LL,18446744073709551613UL,4UL},{1UL,2UL,18446744073709551611UL,18446744073709551608UL,1UL,18446744073709551614UL,18446744073709551615UL},{0x2542F0818798A2A8LL,18446744073709551615UL,18446744073709551615UL,0x7801207660B678B5LL,18446744073709551615UL,18446744073709551606UL,0xC4045477F4ADE73CLL}},{{0x8D522F74B0D35671LL,18446744073709551611UL,18446744073709551609UL,0xC4045477F4ADE73CLL,0x73102F56558FA1B8LL,0x73102F56558FA1B8LL,0xC4045477F4ADE73CLL},{18446744073709551608UL,7UL,18446744073709551608UL,18446744073709551614UL,0xC4045477F4ADE73CLL,0UL,18446744073709551615UL},{4UL,0x7801207660B678B5LL,0xA6977314DBC262E3LL,0x4D20151E4F78FD8DLL,0x8D522F74B0D35671LL,18446744073709551615UL,4UL},{0x7801207660B678B5LL,18446744073709551613UL,18446744073709551615UL,0xC4045477F4ADE73CLL,1UL,0UL,2UL},{18446744073709551611UL,2UL,1UL,18446744073709551611UL,5UL,0x73102F56558FA1B8LL,18446744073709551614UL},{4UL,1UL,18446744073709551606UL,5UL,5UL,18446744073709551606UL,1UL},{5UL,18446744073709551609UL,0UL,18446744073709551615UL,1UL,18446744073709551614UL,0x4D20151E4F78FD8DLL}},{{0UL,4UL,18446744073709551608UL,18446744073709551609UL,0x8D522F74B0D35671LL,18446744073709551613UL,1UL},{0x2542F0818798A2A8LL,1UL,9UL,18446744073709551615UL,0xC4045477F4ADE73CLL,0xF0A7AF316F5AD84ELL,4UL},{2UL,1UL,18446744073709551611UL,5UL,0x73102F56558FA1B8LL,18446744073709551614UL,0x2542F0818798A2A8LL},{18446744073709551615UL,18446744073709551615UL,18446744073709551611UL,18446744073709551611UL,18446744073709551615UL,18446744073709551615UL,0x251B4D85EDA7B548LL},{0x8D522F74B0D35671LL,0x7801207660B678B5LL,9UL,0xC4045477F4ADE73CLL,1UL,0xFCCCF3AA1B837C6DLL,0xC4045477F4ADE73CLL},{5UL,18446744073709551615UL,18446744073709551608UL,0x4D20151E4F78FD8DLL,0x251B4D85EDA7B548LL,0UL,0x2542F0818798A2A8LL},{18446744073709551609UL,0x7801207660B678B5LL,0UL,18446744073709551614UL,0x8D522F74B0D35671LL,18446744073709551611UL,18446744073709551609UL}},{{0x7801207660B678B5LL,18446744073709551615UL,18446744073709551606UL,0xC4045477F4ADE73CLL,2UL,0xA6977314DBC262E3LL,2UL},{1UL,1UL,1UL,1UL,0xF0A7AF316F5AD84ELL,0xA6977314DBC262E3LL,18446744073709551609UL},{8UL,0UL,0xF947EAB82EBD33D6LL,0xF0A7AF316F5AD84ELL,18446744073709551613UL,0xF947EAB82EBD33D6LL,0xA6977314DBC262E3LL},{18446744073709551613UL,18446744073709551615UL,0x2542F0818798A2A8LL,18446744073709551611UL,18446744073709551614UL,4UL,18446744073709551609UL},{18446744073709551615UL,8UL,0xF0A7AF316F5AD84ELL,18446744073709551615UL,18446744073709551606UL,18446744073709551615UL,18446744073709551614UL},{0xF947EAB82EBD33D6LL,0UL,8UL,18446744073709551615UL,0x73102F56558FA1B8LL,18446744073709551615UL,8UL},{18446744073709551614UL,18446744073709551614UL,2UL,18446744073709551613UL,0UL,4UL,18446744073709551608UL}},{{18446744073709551608UL,18446744073709551615UL,0UL,1UL,18446744073709551615UL,0xF947EAB82EBD33D6LL,0x73102F56558FA1B8LL},{18446744073709551606UL,1UL,8UL,0xFCCCF3AA1B837C6DLL,0UL,0xA6977314DBC262E3LL,0xFCCCF3AA1B837C6DLL},{18446744073709551613UL,0x251B4D85EDA7B548LL,18446744073709551615UL,18446744073709551609UL,0x73102F56558FA1B8LL,0x2542F0818798A2A8LL,18446744073709551608UL},{18446744073709551615UL,0UL,18446744073709551606UL,18446744073709551609UL,18446744073709551606UL,0UL,18446744073709551615UL},{0UL,18446744073709551611UL,0xF947EAB82EBD33D6LL,0xFCCCF3AA1B837C6DLL,18446744073709551614UL,18446744073709551606UL,1UL},{1UL,18446744073709551614UL,0x4D20151E4F78FD8DLL,1UL,18446744073709551613UL,0x8D522F74B0D35671LL,18446744073709551609UL},{18446744073709551615UL,0xA6977314DBC262E3LL,0xF947EAB82EBD33D6LL,18446744073709551613UL,0xF0A7AF316F5AD84ELL,0xF947EAB82EBD33D6LL,0UL}}};
            int32_t l_357 = 0x8183C4D5L;
            int32_t l_360 = (-1L);
            int32_t l_363 = 0x5BB4C828L;
            int32_t l_367 = 0xB361E43FL;
            int32_t l_369[10];
            int16_t l_370[1];
            uint64_t *l_415 = &l_328;
            int i, j, k;
            for (i = 0; i < 10; i++)
                l_369[i] = 1L;
            for (i = 0; i < 1; i++)
                l_370[i] = 0x0E97L;
            if ((*p_98))
            { /* block id: 33 */
                if ((*p_98))
                    break;
            }
            else
            { /* block id: 35 */
                int32_t **l_115 = &g_56;
                int32_t *l_153 = (void*)0;
                int32_t *l_162 = &g_44;
                uint16_t l_193[2];
                int64_t **l_239 = &l_131;
                int i;
                for (i = 0; i < 2; i++)
                    l_193[i] = 65527UL;
                for (g_44 = 0; (g_44 <= 4); g_44 += 1)
                { /* block id: 38 */
                    int32_t l_136 = 0xF939D135L;
                    int32_t l_167 = 0L;
                    int64_t **l_183 = &l_131;
                    uint32_t *l_184 = &g_155;
                    uint32_t l_219 = 4294967295UL;
                    int32_t *l_242 = (void*)0;
                    int32_t *l_243 = (void*)0;
                    int32_t *l_244[10] = {&g_28,(void*)0,&g_157,&g_157,(void*)0,&g_28,(void*)0,&g_157,&g_157,(void*)0};
                    uint32_t l_246 = 0xC4C82588L;
                    int i;
                }
                if ((*g_156))
                    continue;
                if ((*p_98))
                    break;
            }
            (*p_98) |= ((((~g_218) <= ((*g_156) == (((safe_lshift_func_uint16_t_u_s(((!0x09BFBA134505B793LL) , 65526UL), 1)) ^ (*l_161)) == (l_254 |= p_97)))) ^ (safe_lshift_func_uint8_t_u_u(((void*)0 != &g_56), 3))) && g_3[2]);
            (*l_161) = (*g_60);
        }
    }
    (**l_118) = (p_98 = (**l_118));
    return l_470;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_49[i][j][k], "g_49[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_50[i][j], "g_50[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_211[i], "g_211[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_218, "g_218", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_241[i][j], "g_241[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_305, "g_305", print_hash_value);
    transparent_crc(g_307, "g_307", print_hash_value);
    transparent_crc(g_349, "g_349", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_353[i], "g_353[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_425, "g_425", print_hash_value);
    transparent_crc(g_452, "g_452", print_hash_value);
    transparent_crc(g_504, "g_504", print_hash_value);
    transparent_crc(g_570, "g_570", print_hash_value);
    transparent_crc(g_592, "g_592", print_hash_value);
    transparent_crc(g_678, "g_678", print_hash_value);
    transparent_crc(g_767, "g_767", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_833[i], "g_833[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_848[i][j][k], "g_848[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_992, "g_992", print_hash_value);
    transparent_crc(g_1037, "g_1037", print_hash_value);
    transparent_crc(g_1233, "g_1233", print_hash_value);
    transparent_crc(g_1334, "g_1334", print_hash_value);
    transparent_crc(g_1398, "g_1398", print_hash_value);
    transparent_crc(g_1485, "g_1485", print_hash_value);
    transparent_crc(g_1644, "g_1644", print_hash_value);
    transparent_crc(g_1840, "g_1840", print_hash_value);
    transparent_crc(g_2027, "g_2027", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2058[i], "g_2058[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2059, "g_2059", print_hash_value);
    transparent_crc(g_2109, "g_2109", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 552
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 37
breakdown:
   depth: 1, occurrence: 209
   depth: 2, occurrence: 52
   depth: 3, occurrence: 10
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 24, occurrence: 5
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1

XXX total number of pointers: 486

XXX times a variable address is taken: 1160
XXX times a pointer is dereferenced on RHS: 266
breakdown:
   depth: 1, occurrence: 234
   depth: 2, occurrence: 27
   depth: 3, occurrence: 5
XXX times a pointer is dereferenced on LHS: 369
breakdown:
   depth: 1, occurrence: 344
   depth: 2, occurrence: 21
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 38
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 8712

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1422
   level: 2, occurrence: 296
   level: 3, occurrence: 83
   level: 4, occurrence: 9
   level: 5, occurrence: 7
XXX number of pointers point to pointers: 187
XXX number of pointers point to scalars: 299
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 25.3
XXX average alias set size: 1.45

XXX times a non-volatile is read: 1600
XXX times a non-volatile is write: 1035
XXX times a volatile is read: 114
XXX    times read thru a pointer: 44
XXX times a volatile is write: 16
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.4e+03
XXX percentage of non-volatile access: 95.3

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 205
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 46
   depth: 2, occurrence: 35
   depth: 3, occurrence: 44
   depth: 4, occurrence: 25
   depth: 5, occurrence: 21

XXX percentage a fresh-made variable is used: 16
XXX percentage an existing variable is used: 84
********************* end of statistics **********************/

