/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4249567542
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile int8_t * volatile  f0;
   const int64_t  f1;
   volatile uint64_t  f2;
   int8_t * const  f3;
};

union U1 {
   uint32_t  f0;
   volatile int8_t * f1;
   const uint64_t  f2;
   int32_t  f3;
   int8_t * f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_14[6][8] = {{0xBA4D3EC9L,18446744073709551614UL,0x6874BE76L,0xCC254292L,0x6874BE76L,18446744073709551614UL,0xBA4D3EC9L,0x98CAFA32L},{18446744073709551614UL,1UL,0x03773672L,0x2DB785B6L,18446744073709551612UL,0xCC254292L,0xCC254292L,18446744073709551612UL},{0x1A4E6659L,0xBA4D3EC9L,0xBA4D3EC9L,0x1A4E6659L,18446744073709551612UL,18446744073709551608UL,0x98CAFA32L,0xCC254292L},{18446744073709551614UL,0x78C38EC3L,0x238E486AL,18446744073709551612UL,0x6874BE76L,18446744073709551612UL,0x238E486AL,0x78C38EC3L},{0xBA4D3EC9L,0x78C38EC3L,0xCC254292L,0x238E486AL,0x03773672L,18446744073709551608UL,0x2DB785B6L,0x2DB785B6L},{0xCC254292L,0xBA4D3EC9L,1UL,1UL,0xBA4D3EC9L,0xCC254292L,18446744073709551608UL,0x98CAFA32L}};
static int8_t g_19 = (-3L);
static int8_t *g_18 = &g_19;
static union U1 g_50 = {0xB8FFD020L};
static uint16_t g_55 = 0xE12CL;
static uint32_t g_63 = 0x2D584125L;
static int32_t *g_84[1] = {&g_50.f3};
static int8_t g_91 = 0x69L;
static uint16_t g_118[4] = {0xBED3L,0xBED3L,0xBED3L,0xBED3L};
static int64_t g_121 = 0x8548DC0916D66C25LL;
static int16_t g_154 = 0xE4CEL;
static const uint8_t g_198 = 0x21L;
static uint32_t g_205 = 0x3FB63F38L;
static int32_t g_225 = (-1L);
static uint16_t *g_236 = &g_55;
static uint8_t g_237 = 251UL;
static volatile union U0 g_281 = {0};/* VOLATILE GLOBAL g_281 */
static volatile union U0 *g_280 = &g_281;
static union U0 g_315 = {0};/* VOLATILE GLOBAL g_315 */
static union U0 g_317 = {0};/* VOLATILE GLOBAL g_317 */
static union U0 g_320 = {0};/* VOLATILE GLOBAL g_320 */
static union U0 g_321 = {0};/* VOLATILE GLOBAL g_321 */
static uint32_t g_417 = 4294967295UL;
static uint32_t *g_416 = &g_417;
static int32_t g_420 = 0xA3EF99F8L;
static int64_t g_437 = 0x61179FA2C34738FFLL;
static union U0 g_505 = {0};/* VOLATILE GLOBAL g_505 */
static int32_t *g_565 = &g_420;
static int16_t g_612 = (-6L);
static uint32_t **g_652 = &g_416;
static uint32_t ***g_651[4][7] = {{&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652},{&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652},{&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652},{&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652}};
static uint32_t * const *g_655 = &g_416;
static uint32_t * const **g_654 = &g_655;
static int8_t g_661[2][1] = {{1L},{1L}};
static const union U1 g_678 = {18446744073709551610UL};
static int8_t *g_707 = &g_661[0][0];
static int8_t **g_706 = &g_707;
static int32_t **g_728[8] = {&g_565,&g_565,&g_565,&g_565,&g_565,&g_565,&g_565,&g_565};
static uint64_t g_818 = 0UL;
static int16_t *g_831 = &g_612;
static union U0 g_839 = {0};/* VOLATILE GLOBAL g_839 */
static union U0 g_840 = {0};/* VOLATILE GLOBAL g_840 */
static union U0 *g_838[7] = {&g_840,&g_840,&g_840,&g_840,&g_840,&g_840,&g_840};
static union U0 g_843[5][5][6] = {{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}},{{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0}}}};
static int64_t * volatile *g_866 = (void*)0;
static uint8_t g_913 = 5UL;
static uint16_t g_946 = 0UL;
static volatile int16_t g_966[4] = {0xDFD8L,0xDFD8L,0xDFD8L,0xDFD8L};
static volatile int16_t g_967 = 0xFD88L;/* VOLATILE GLOBAL g_967 */
static volatile int16_t g_968 = 0x8ED4L;/* VOLATILE GLOBAL g_968 */
static volatile int16_t g_969 = (-8L);/* VOLATILE GLOBAL g_969 */
static volatile int16_t g_970 = (-8L);/* VOLATILE GLOBAL g_970 */
static volatile int16_t *g_965[8][5][6] = {{{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]}},{{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0}},{{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]}},{{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0}},{{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_966[3],&g_968,&g_966[3],(void*)0,&g_968,(void*)0},{&g_966[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_966[3]},{&g_966[3],&g_966[3],&g_967,&g_969,&g_966[3],&g_969}},{{&g_970,(void*)0,&g_970,&g_969,(void*)0,&g_967},{&g_970,(void*)0,&g_969,&g_969,(void*)0,&g_970},{&g_970,&g_966[3],&g_967,&g_969,&g_966[3],&g_969},{&g_970,(void*)0,&g_970,&g_969,(void*)0,&g_967},{&g_970,(void*)0,&g_969,&g_969,(void*)0,&g_970}},{{&g_970,&g_966[3],&g_967,&g_969,&g_966[3],&g_969},{&g_970,(void*)0,&g_970,&g_969,(void*)0,&g_967},{&g_970,(void*)0,&g_969,&g_969,(void*)0,&g_970},{&g_970,&g_966[3],&g_967,&g_969,&g_966[3],&g_969},{&g_970,(void*)0,&g_970,&g_969,(void*)0,&g_967}}};
static volatile int16_t * volatile *g_964 = &g_965[3][3][4];
static int32_t g_998[3][10][1] = {{{0xC5D0CD93L},{1L},{(-1L)},{0x7E46AA52L},{(-1L)},{1L},{0xC5D0CD93L},{4L},{0x9380316CL},{4L}},{{0xC5D0CD93L},{1L},{(-1L)},{0x7E46AA52L},{(-1L)},{1L},{0xC5D0CD93L},{4L},{0x9380316CL},{4L}},{{0xC5D0CD93L},{1L},{(-1L)},{0x7E46AA52L},{(-1L)},{1L},{0xC5D0CD93L},{4L},{0x9380316CL},{4L}}};
static uint64_t g_1115 = 0UL;
static int16_t **g_1128 = &g_831;
static int16_t ***g_1127[9][9][3] = {{{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,&g_1128},{&g_1128,(void*)0,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0}},{{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1128},{&g_1128,&g_1128,(void*)0},{(void*)0,(void*)0,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,(void*)0}},{{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,(void*)0,&g_1128},{&g_1128,&g_1128,(void*)0},{(void*)0,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0}},{{&g_1128,(void*)0,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,(void*)0,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,(void*)0,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128}},{{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,(void*)0},{(void*)0,&g_1128,(void*)0}},{{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0}},{{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,(void*)0},{(void*)0,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,(void*)0,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128}},{{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,&g_1128},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{(void*)0,(void*)0,(void*)0},{&g_1128,(void*)0,&g_1128}},{{&g_1128,(void*)0,&g_1128},{&g_1128,(void*)0,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128},{(void*)0,&g_1128,(void*)0},{&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128}}};
static uint16_t g_1209 = 0x1905L;
static union U1 g_1253[8] = {{6UL},{0x9F90004EL},{6UL},{6UL},{0x9F90004EL},{6UL},{6UL},{0x9F90004EL}};
static int32_t g_1310 = 0L;
static union U0 g_1324[10] = {{0},{0},{0},{0},{0},{0},{0},{0},{0},{0}};
static union U0 g_1326 = {0};/* VOLATILE GLOBAL g_1326 */
static union U0 g_1344 = {0};/* VOLATILE GLOBAL g_1344 */
static volatile union U0 g_1353 = {0};/* VOLATILE GLOBAL g_1353 */
static uint8_t * const g_1371 = (void*)0;
static uint8_t * const *g_1370 = &g_1371;
static int8_t g_1403 = 0xA5L;
static volatile union U0 g_1408 = {0};/* VOLATILE GLOBAL g_1408 */
static union U1 *g_1427[10] = {&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2],&g_1253[2]};
static union U1 * volatile * const g_1426 = &g_1427[3];
static volatile union U0 g_1430 = {0};/* VOLATILE GLOBAL g_1430 */
static int64_t * volatile ** volatile g_1493 = &g_866;/* VOLATILE GLOBAL g_1493 */
static volatile int8_t g_1512 = 0x00L;/* VOLATILE GLOBAL g_1512 */
static int32_t ** volatile g_1516 = &g_84[0];/* VOLATILE GLOBAL g_1516 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_2(union U1  p_3, const uint32_t  p_4);
static int32_t  func_8(int32_t  p_9, int8_t  p_10, int64_t  p_11, int8_t * p_12, const int16_t  p_13);
static const union U1  func_22(const uint16_t  p_23, const int8_t * p_24, int32_t  p_25, int8_t * p_26, int32_t  p_27);
static int8_t * func_28(int32_t  p_29, int64_t  p_30, int32_t  p_31, int8_t * p_32, int32_t  p_33);
static int8_t * func_42(const uint64_t  p_43, int8_t * p_44);
static union U1  func_45(union U1  p_46, int8_t * p_47, uint32_t  p_48, const union U1  p_49);
static union U1  func_76(int32_t * p_77, uint32_t  p_78);
static int32_t * func_79(int8_t * p_80);
static int32_t  func_85(int16_t  p_86, union U1  p_87);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_18 g_19 g_50 g_50.f3 g_55 g_63 g_565 g_420 g_154 g_437 g_237 g_121 g_818 g_661 g_612 g_838 g_678.f3 g_236 g_831 g_84 g_118 g_946 g_50.f0 g_655 g_416 g_417 g_706 g_707 g_678.f0 g_964 g_913 g_652 g_998 g_205 g_1127 g_225 g_1128 g_1209 g_1253.f0 g_1253.f3 g_1253 g_1310 g_1324 g_1326 g_198 g_1344 g_1353 g_966 g_1370 g_1403 g_1408 g_1426 g_1430 g_1427 g_1371 g_866 g_1493 g_1516
 * writes: g_55 g_63 g_50.f3 g_420 g_154 g_437 g_84 g_237 g_121 g_818 g_612 g_831 g_838 g_118 g_707 g_913 g_565 g_998 g_205 g_19 g_661 g_1115 g_946 g_417 g_416 g_1370 g_866 g_1512
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    union U1 l_5 = {0xB04800FAL};
    int8_t *l_51 = &g_19;
    uint8_t *l_953 = &g_913;
    uint32_t l_954 = 1UL;
    l_5.f3 = func_2(l_5, ((safe_lshift_func_int16_t_s_u(((func_8((g_14[3][0] <= ((safe_rshift_func_uint8_t_u_u((~((void*)0 == g_18)), 1)) && l_5.f3)), ((safe_sub_func_int64_t_s_s((((func_22(l_5.f0, func_28(g_19, (safe_rshift_func_int8_t_s_s((((((safe_add_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(((*l_953) = ((((*g_706) = func_42(g_19, (func_45(g_50, l_51, g_50.f3, l_5) , l_51))) == (void*)0) >= l_5.f3)), g_678.f0)), 5L)), 0xE8E3D09EL)) < 0x917FL) , l_5.f0) != 0xD0L) != g_417), 3)), l_954, l_953, l_5.f3), l_5.f3, l_953, l_954) , l_954) , g_1310) , l_5.f0), l_954)) < 0x266201B8L), l_5.f0, l_51, l_5.f3) , (-1L)) != g_225), g_1253[2].f3)) >= l_5.f0));
    return l_954;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_2(union U1  p_3, const uint32_t  p_4)
{ /* block id: 626 */
    uint64_t l_1523 = 0UL;
    l_1523 = (p_4 != (safe_mod_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((&g_655 != &g_652), 0x99863EC7L)), 15)), p_3.f0)));
    return p_3.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_118 g_1324 g_1326 g_236 g_55 g_154 g_198 g_1344 g_998 g_1353 g_966 g_50 g_1370 g_19 g_661 g_1403 g_1408 g_1426 g_1430 g_1253.f3 g_1427 g_1253 g_818 g_437 g_1371 g_866 g_1493 g_1516
 * writes: g_154 g_55 g_838 g_205 g_1370 g_437 g_121 g_118 g_866 g_84 g_237 g_1512 g_661
 */
static int32_t  func_8(int32_t  p_9, int8_t  p_10, int64_t  p_11, int8_t * p_12, const int16_t  p_13)
{ /* block id: 565 */
    int64_t * const *l_1311 = (void*)0;
    int16_t **** const l_1325 = &g_1127[5][6][0];
    int32_t l_1327 = 0xDBE2E9EEL;
    int32_t l_1328 = 0xA0B4AD4EL;
    int16_t *l_1329 = &g_154;
    union U0 *l_1336 = &g_505;
    uint8_t *l_1367 = &g_913;
    uint8_t **l_1366[3][9] = {{(void*)0,(void*)0,&l_1367,(void*)0,(void*)0,&l_1367,(void*)0,(void*)0,&l_1367},{(void*)0,(void*)0,&l_1367,(void*)0,(void*)0,&l_1367,(void*)0,&l_1367,(void*)0},{&l_1367,&l_1367,(void*)0,&l_1367,&l_1367,(void*)0,&l_1367,&l_1367,(void*)0}};
    int32_t l_1387 = 0x93CCAA95L;
    int32_t l_1391 = (-8L);
    int32_t l_1393 = 0x19E8D15DL;
    int32_t l_1394[8][1][5] = {{{2L,0x0FB57030L,7L,0xA59A2700L,0x0FB57030L}},{{(-3L),0x0FB57030L,6L,6L,0x0FB57030L}},{{2L,0xD1C8F947L,6L,0xA59A2700L,0xD1C8F947L}},{{2L,0x0FB57030L,7L,0xA59A2700L,0x0FB57030L}},{{(-3L),0x0FB57030L,6L,6L,0x0FB57030L}},{{2L,0xD1C8F947L,6L,0xA59A2700L,0xD1C8F947L}},{{2L,0x0FB57030L,7L,0xA59A2700L,0x0FB57030L}},{{(-3L),0x0FB57030L,6L,6L,0x0FB57030L}}};
    uint64_t *l_1433 = &g_1115;
    uint64_t *l_1434[4];
    const union U1 l_1450[8] = {{2UL},{2UL},{2UL},{2UL},{2UL},{2UL},{2UL},{2UL}};
    uint32_t l_1471 = 1UL;
    uint32_t l_1513 = 0x483C7021L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1434[i] = &g_1115;
    if ((((g_118[2] || 0UL) , l_1311) != ((((*l_1329) |= ((safe_sub_func_int32_t_s_s(((p_11 ^ (safe_mod_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s((-2L), (safe_sub_func_int32_t_s_s(((l_1328 ^= (safe_add_func_uint16_t_u_u(((p_9 || (18446744073709551607UL || (((((g_1324[4] , (((p_9 , l_1325) == (void*)0) , g_1326)) , 18446744073709551612UL) >= l_1327) | p_10) | 6L))) , p_11), p_11))) ^ l_1327), l_1327)))) , p_10), l_1327)), (*g_236)))) , p_9), 0L)) < 7UL)) , p_9) , (void*)0)))
    { /* block id: 568 */
        int64_t l_1349 = 6L;
        uint8_t **l_1369 = &l_1367;
        int32_t l_1386 = 0x8128D8BDL;
        int32_t l_1389 = 0x03BE41C7L;
        int32_t l_1390 = (-1L);
        int32_t l_1392[1];
        int64_t l_1398[10] = {0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL,0x7E2CCF884AF2F63CLL};
        uint8_t l_1443 = 0UL;
        int32_t **l_1472 = &g_565;
        uint16_t l_1477 = 3UL;
        int i;
        for (i = 0; i < 1; i++)
            l_1392[i] = 0L;
        for (l_1327 = 24; (l_1327 != (-15)); l_1327 = safe_sub_func_uint64_t_u_u(l_1327, 8))
        { /* block id: 571 */
            uint32_t l_1341[8] = {0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL,0xAF3B65ECL};
            union U0 **l_1350 = (void*)0;
            union U0 **l_1351 = &g_838[6];
            uint32_t *l_1352[9] = {&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0,&g_1253[2].f0};
            int32_t l_1354[10][9] = {{1L,3L,(-8L),0xC979CB45L,0x2E937686L,0xB6BF88ABL,0x93CF2D69L,0x7DB843E4L,0x93CF2D69L},{0x7DB843E4L,0x6E49B0ACL,0x06A53FACL,0x06A53FACL,0x6E49B0ACL,0x7DB843E4L,0xE9983791L,0x48885061L,0x93CF2D69L},{0x2E937686L,0x48885061L,0x30E6B737L,9L,5L,0xBD15709AL,0x7DB843E4L,0x06A53FACL,3L},{9L,0x30E6B737L,0x48885061L,0x2E937686L,0xE9983791L,1L,0xE9983791L,0x2E937686L,0x48885061L},{0x06A53FACL,0x06A53FACL,0x6E49B0ACL,0x7DB843E4L,0xE9983791L,0x48885061L,0x93CF2D69L,3L,0xB6BF88ABL},{0xC979CB45L,(-8L),3L,1L,5L,0x051F0DFDL,0xBD15709AL,0xE9983791L,0xE9983791L},{0xB6BF88ABL,0x1D9FD892L,0x6E49B0ACL,5L,0x6E49B0ACL,0x1D9FD892L,0xB6BF88ABL,8L,(-1L)},{0xB6BF88ABL,0xBD15709AL,0x48885061L,0x1D9FD892L,0x2E937686L,0x30E6B737L,0x051F0DFDL,1L,0x7DB843E4L},{0xC979CB45L,0xE9983791L,0x30E6B737L,1L,8L,0x2E937686L,0x2E937686L,8L,1L},{0x06A53FACL,0xC979CB45L,0x06A53FACL,(-1L),(-8L),0x2E937686L,5L,0xE9983791L,0x6E49B0ACL}};
            uint8_t ***l_1368[2];
            uint8_t * const **l_1372 = &g_1370;
            int64_t *l_1375 = &g_437;
            int32_t *l_1376 = (void*)0;
            union U1 l_1380 = {1UL};
            uint64_t l_1395 = 1UL;
            uint32_t l_1400 = 0xB4CEFECCL;
            int32_t **l_1435 = &l_1376;
            int i, j;
            for (i = 0; i < 2; i++)
                l_1368[i] = &l_1366[1][5];
            l_1354[5][0] &= (p_9 = (g_198 != ((((g_205 = ((((safe_mod_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s((l_1336 == ((*l_1351) = (((*g_236) ^= (safe_add_func_int16_t_s_s(l_1328, ((safe_mul_func_uint16_t_u_u(l_1341[3], 0UL)) != ((safe_mod_func_int16_t_s_s(((g_1344 , (safe_lshift_func_int8_t_s_s((g_998[0][1][0] && 255UL), 6))) || (((safe_rshift_func_int16_t_s_s(p_10, 7)) & l_1349) , l_1341[2])), p_13)) < (-10L)))))) , &g_321))), l_1327)) >= p_10) > (-1L)), p_9)) | p_9) >= p_10) ^ 1L)) , p_10) , g_1353) , l_1328)));
            if ((l_1328 = (l_1354[2][2] || (safe_mul_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u(((65535UL <= (((safe_div_func_int64_t_s_s((((!p_11) == (safe_div_func_uint32_t_u_u((g_966[3] | (safe_mod_func_int64_t_s_s((((l_1369 = l_1366[1][5]) != (g_50 , ((*l_1372) = g_1370))) < l_1354[5][0]), ((*l_1375) = (safe_rshift_func_int8_t_s_u((*p_12), 5)))))), p_13))) ^ p_11), (-1L))) < p_9) , 65529UL)) > p_9), l_1349)) && g_198), 65535UL)))))
            { /* block id: 581 */
                int32_t **l_1377[3][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_84[0],&g_84[0],&g_84[0],&g_84[0],&g_84[0],&g_84[0],&g_84[0],&g_84[0],&g_84[0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int i, j;
                l_1376 = &l_1328;
                return p_13;
            }
            else
            { /* block id: 584 */
                uint8_t ** const l_1379 = (void*)0;
                int32_t l_1384 = (-9L);
                int32_t l_1385 = 0x5CACC64CL;
                int32_t l_1388[10] = {0x9A01BA44L,0x9A01BA44L,0x5E3C62D3L,0x9A01BA44L,0x9A01BA44L,0x5E3C62D3L,0x9A01BA44L,0x9A01BA44L,0x5E3C62D3L,0x9A01BA44L};
                int i;
                if ((+((g_661[0][0] , (g_154 , l_1379)) == (l_1380 , l_1369))))
                { /* block id: 585 */
                    int32_t *l_1381 = &l_1354[5][0];
                    int32_t *l_1382 = &l_1380.f3;
                    int32_t *l_1383[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int32_t l_1399 = 0L;
                    int i;
                    ++l_1395;
                    l_1400++;
                    if (g_1403)
                        continue;
                }
                else
                { /* block id: 589 */
                    uint32_t l_1417 = 0UL;
                    int32_t l_1418 = 0x5A3010C2L;
                    l_1354[5][0] &= ((safe_rshift_func_uint8_t_u_u((((((safe_add_func_uint8_t_u_u((g_1408 , (p_13 , (safe_div_func_int64_t_s_s((safe_add_func_uint16_t_u_u((*g_236), (safe_sub_func_uint16_t_u_u(((l_1349 && p_13) , (p_10 != g_966[1])), ((safe_div_func_uint16_t_u_u((l_1388[4] > (l_1417 &= 0xCF974D6AL)), l_1418)) || (-1L)))))), (-1L))))), (-9L))) & l_1388[0]) == (-9L)) , l_1380) , 1UL), p_10)) ^ p_9);
                }
                for (g_121 = 0; (g_121 >= 2); g_121 = safe_add_func_int32_t_s_s(g_121, 1))
                { /* block id: 595 */
                    uint64_t *l_1432 = &l_1395;
                    uint64_t **l_1431[1][4][2] = {{{&l_1432,&l_1432},{&l_1432,&l_1432},{&l_1432,&l_1432},{&l_1432,&l_1432}}};
                    int32_t **l_1436 = &g_565;
                    const int64_t l_1437 = (-5L);
                    const int16_t l_1492 = 0x98D8L;
                    int i, j, k;
                    if (((safe_rshift_func_int8_t_s_u((safe_add_func_uint16_t_u_u((+((void*)0 != g_1426)), (((safe_div_func_int32_t_s_s(((l_1433 = (g_1430 , &g_818)) == (l_1434[0] = (void*)0)), ((-8L) && g_1253[2].f3))) , p_13) || ((l_1435 = &g_84[0]) != l_1436)))), 2)) ^ l_1437))
                    { /* block id: 599 */
                        int32_t *l_1438 = (void*)0;
                        int32_t *l_1439 = (void*)0;
                        int32_t *l_1440 = (void*)0;
                        int32_t *l_1441 = (void*)0;
                        int32_t *l_1442[2];
                        int32_t l_1455 = 0x9CB7D0BDL;
                        uint16_t *l_1456 = &g_118[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1442[i] = &g_998[2][9][0];
                        ++l_1443;
                        l_1394[7][0][0] |= (safe_add_func_uint64_t_u_u((p_9 && ((*l_1456) = ((((((l_1450[5] , l_1388[4]) == (safe_add_func_int8_t_s_s((*p_12), 0L))) == (p_9 < ((*g_236)--))) & ((**g_1426) , (l_1398[1] < (((((l_1455 || 0x34L) , p_9) < 3UL) | l_1391) < 0L)))) >= (-1L)) >= p_10))), l_1384));
                    }
                    else
                    { /* block id: 604 */
                        uint16_t l_1474 = 0xA1C8L;
                        uint16_t *l_1475 = (void*)0;
                        uint16_t *l_1476[4];
                        int32_t *l_1478 = &l_1394[7][0][1];
                        const uint8_t *l_1488 = &g_198;
                        const uint8_t **l_1487 = &l_1488;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_1476[i] = &g_946;
                        (*l_1478) = ((0L != (l_1477 = ((*g_236) = ((safe_add_func_uint32_t_u_u((((*l_1375) = (safe_mul_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_u((g_118[0] |= ((l_1474 ^= ((safe_sub_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_u(((-5L) == (p_13 == (safe_sub_func_int32_t_s_s((((*p_12) & 0xF4L) || ((l_1471 != ((void*)0 == l_1472)) || (+0x8A4953F43BA1C35DLL))), p_13)))), 2)) ^ (*p_12)), 1L)) > (*p_12))) , (*g_236))), 10)) != 1UL), 0x4CL))) ^ (-1L)), p_10)) < g_818)))) , p_10);
                        (*g_1493) = ((safe_lshift_func_uint16_t_u_s((((safe_lshift_func_uint8_t_u_s(((0x34L ^ (p_11 , (g_1253[2].f3 | (((safe_add_func_uint32_t_u_u((((*l_1487) = p_12) == (((*l_1375) ^= (safe_sub_func_uint8_t_u_u(l_1349, ((&l_1366[1][5] != &g_1370) && (+l_1394[4][0][3]))))) , (*g_1370))), l_1385)) == p_13) < l_1492)))) != p_10), 4)) >= (*p_12)) ^ 0xCC66L), 0)) , g_866);
                        return p_13;
                    }
                    return p_11;
                }
            }
        }
    }
    else
    { /* block id: 620 */
        int32_t *l_1494 = (void*)0;
        int32_t *l_1495 = &l_1327;
        int32_t *l_1496 = (void*)0;
        int32_t l_1497 = 0x799CF7A3L;
        int32_t *l_1498 = &l_1394[7][0][0];
        int32_t *l_1499 = &l_1497;
        int32_t *l_1500 = (void*)0;
        int32_t *l_1501 = &g_420;
        int32_t *l_1502 = &l_1391;
        int32_t *l_1503 = &l_1394[7][0][0];
        int32_t *l_1504 = &l_1394[7][0][0];
        int32_t *l_1505 = &g_1310;
        int32_t *l_1506 = (void*)0;
        int32_t *l_1507 = (void*)0;
        int32_t *l_1508 = &l_1394[7][0][4];
        int32_t l_1509 = (-1L);
        int32_t *l_1510 = &g_1253[2].f3;
        int32_t *l_1511[2][6][1] = {{{&l_1327},{&l_1391},{&l_1393},{&g_1310},{&l_1393},{&l_1391}},{{&l_1327},{&l_1391},{&l_1393},{&g_1310},{&l_1393},{&l_1391}}};
        int i, j, k;
        l_1513--;
        (*g_1516) = &p_9;
    }
    for (g_237 = 0; g_237 < 2; g_237 += 1)
    {
        for (g_1512 = 0; g_1512 < 1; g_1512 += 1)
        {
            g_661[g_237][g_1512] = 1L;
        }
    }
    return l_1394[4][0][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_437 g_661 g_707 g_19 g_913 g_84 g_652 g_50.f3 g_417 g_1253.f3 g_237 g_121 g_1253
 * writes: g_121 g_50.f3 g_416 g_913
 */
static const union U1  func_22(const uint16_t  p_23, const int8_t * p_24, int32_t  p_25, int8_t * p_26, int32_t  p_27)
{ /* block id: 552 */
    int32_t **l_1275 = &g_84[0];
    union U1 l_1276 = {0x4518E349L};
    int64_t *l_1277 = &g_121;
    int16_t l_1280 = 7L;
    int32_t l_1281 = 0L;
    int32_t l_1282 = 0x371584F6L;
    int32_t l_1284 = 0x4BAA690EL;
    int32_t l_1285 = (-10L);
    int32_t l_1286 = (-2L);
    int32_t l_1287 = (-5L);
    int32_t l_1288 = 0xC1AA8D19L;
    int32_t l_1289[2][7][10] = {{{0x288003C2L,0xB0D7C550L,(-6L),0x244BBB05L,0L,0x61158D64L,2L,2L,0x61158D64L,0L},{0xF63D7D22L,0x1B62461DL,0x1B62461DL,0xF63D7D22L,1L,(-4L),0x53B9F3A5L,0xD643E6A8L,2L,0x60DDFCCFL},{0x53B9F3A5L,0L,7L,(-1L),0x5E240254L,(-1L),0x1B62461DL,0x53B9F3A5L,2L,0xE70F200CL},{(-1L),0L,(-7L),0xF63D7D22L,0xFCB0B6EAL,0xF894C77DL,(-1L),(-4L),0x61158D64L,(-7L)},{(-6L),(-7L),(-9L),0x244BBB05L,0x098DC9BDL,0xFCB0B6EAL,0x5E240254L,1L,0L,0L},{9L,0xFCB0B6EAL,0xE70F200CL,0x7770E480L,0x244BBB05L,0xF63D7D22L,(-1L),0xF63D7D22L,0x244BBB05L,0x7770E480L},{9L,(-6L),9L,0xE70F200CL,(-9L),(-7L),7L,0x1B62461DL,(-6L),0L}},{{2L,0xF63D7D22L,(-6L),0xFCB0B6EAL,(-7L),0L,0L,0x1B62461DL,0xB0D7C550L,0L},{0xB0D7C550L,2L,9L,9L,(-6L),(-1L),0x53B9F3A5L,0xF63D7D22L,0x288003C2L,2L},{1L,0x288003C2L,0xE70F200CL,(-1L),0xC9C8CBF6L,(-1L),9L,1L,0x1B62461DL,6L},{(-1L),0xD643E6A8L,(-9L),0x85BEFD36L,(-4L),0x7770E480L,0x7770E480L,(-4L),0x85BEFD36L,(-9L)},{(-1L),(-1L),(-7L),0x96419D88L,0x098DC9BDL,(-1L),0L,0x53B9F3A5L,0xDEEA5E01L,(-1L)},{0x85BEFD36L,0xFCB0B6EAL,7L,0xF894C77DL,0xB8C01A05L,9L,0L,0xD643E6A8L,0x244BBB05L,(-1L)},{0x60DDFCCFL,(-1L),0x1B62461DL,(-1L),(-1L),(-7L),0x7770E480L,2L,(-1L),9L}}};
    uint32_t l_1290[2][3] = {{1UL,1UL,1UL},{0x0FD47399L,0x0FD47399L,0x0FD47399L}};
    int i, j, k;
    if (((safe_rshift_func_uint8_t_u_u((!((void*)0 == l_1275)), g_437)) | (l_1276 , (((*l_1277) = g_661[1][0]) <= ((*g_707) | 0x6BL)))))
    { /* block id: 554 */
        int32_t *l_1278 = &g_1253[2].f3;
        int32_t *l_1279[4];
        int16_t l_1283 = (-1L);
        int i;
        for (i = 0; i < 4; i++)
            l_1279[i] = (void*)0;
        ++l_1290[0][2];
    }
    else
    { /* block id: 556 */
        uint32_t * const l_1301 = (void*)0;
        int8_t *l_1302 = &g_19;
        const int16_t * const l_1305 = &l_1280;
        const int16_t * const *l_1304 = &l_1305;
        const int16_t * const **l_1303 = &l_1304;
        int32_t l_1308[1];
        uint8_t *l_1309[6] = {&g_237,&g_237,&g_237,&g_237,&g_237,&g_237};
        int i;
        for (i = 0; i < 1; i++)
            l_1308[i] = (-1L);
        p_27 = ((**l_1275) = (safe_lshift_func_int8_t_s_s((*p_26), 7)));
        (**l_1275) = (safe_div_func_uint8_t_u_u((l_1308[0] = ((safe_sub_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u((g_913 = ((l_1301 != ((*g_652) = (p_27 , func_79(l_1302)))) > (l_1303 == (((((((safe_mul_func_int16_t_s_s((**l_1275), (0x18L & l_1308[0]))) , (((&l_1275 != (void*)0) >= (**l_1275)) & g_19)) , (void*)0) != (void*)0) == 0L) , l_1308[0]) , &g_1128)))), g_417)) < g_1253[2].f3), l_1308[0])) == g_237)), g_121));
    }
    return g_1253[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_565 g_121 g_964 g_18 g_19 g_236 g_55 g_818 g_237 g_913 g_118 g_706 g_707 g_661 g_838 g_84 g_50.f3 g_420 g_63 g_946 g_612 g_652 g_416 g_417 g_154 g_998 g_205 g_678.f0 g_50.f0 g_1127 g_225 g_1128 g_831 g_1209 g_1253.f0
 * writes: g_420 g_818 g_437 g_838 g_707 g_565 g_50.f3 g_612 g_154 g_998 g_205 g_913 g_19 g_661 g_84 g_1115 g_55 g_946 g_417 g_121
 */
static int8_t * func_28(int32_t  p_29, int64_t  p_30, int32_t  p_31, int8_t * p_32, int32_t  p_33)
{ /* block id: 393 */
    uint32_t **l_957 = &g_416;
    uint32_t ** const *l_959 = &l_957;
    uint32_t ** const **l_958 = &l_959;
    int32_t l_971 = 0x456D9CFEL;
    const int8_t *l_1001 = &g_91;
    uint16_t *l_1085 = &g_946;
    int8_t *l_1107 = (void*)0;
    uint8_t *l_1111 = (void*)0;
    int16_t ***l_1129 = (void*)0;
    int32_t *l_1161 = &g_998[2][5][0];
    uint16_t **l_1179 = &l_1085;
    uint32_t l_1180 = 0UL;
    uint32_t l_1181 = 1UL;
    uint32_t l_1210 = 4294967292UL;
    union U1 *l_1250 = &g_50;
    (*g_565) = (safe_add_func_uint32_t_u_u(((l_957 == l_957) < p_31), p_30));
    if ((l_958 != &l_959))
    { /* block id: 395 */
        uint32_t l_978 = 4294967290UL;
        uint64_t *l_979 = &g_818;
        int64_t *l_982 = &g_437;
        const union U1 l_987[8] = {{1UL},{0x8AAAC73DL},{1UL},{0x8AAAC73DL},{1UL},{0x8AAAC73DL},{1UL},{0x8AAAC73DL}};
        uint32_t l_1037 = 0x391CA7BEL;
        int32_t l_1039 = 0L;
        uint32_t l_1084 = 4294967292UL;
        int16_t ***l_1125 = (void*)0;
        int16_t ****l_1126 = &l_1125;
        int16_t **l_1134 = &g_831;
        int i;
        if ((g_121 & (((*l_982) = (((((safe_add_func_uint16_t_u_u((((safe_add_func_int8_t_s_s(((void*)0 == g_964), l_971)) >= (*g_18)) >= 0x2AF8C93AL), ((((safe_add_func_int32_t_s_s(((*g_236) , (safe_rshift_func_uint16_t_u_u(((((safe_mul_func_int16_t_s_s((((*l_979) &= l_978) | (safe_sub_func_int64_t_s_s(p_31, 8L))), 0xF536L)) & g_237) | 0xC3L) | 0L), 2))), l_978)) > 0xD767L) , p_29) & (*p_32)))) & g_118[2]) , l_971) <= p_33) & (**g_706))) && 0x2287745003CA7BF7LL)))
        { /* block id: 398 */
            int32_t **l_983 = &g_565;
            uint16_t l_986 = 0x70B3L;
            int32_t l_1012 = 0x8E7DF470L;
            int8_t *l_1013 = &g_661[0][0];
lbl_999:
            g_838[6] = g_838[6];
            (*l_983) = func_79(((*g_706) = (*g_706)));
            if ((safe_mul_func_uint8_t_u_u((l_978 || l_971), 0x22L)))
            { /* block id: 402 */
                int32_t l_995 = 3L;
                union U1 l_1000 = {0x97DB2388L};
                for (p_30 = 0; (p_30 <= 0); p_30 += 1)
                { /* block id: 405 */
                    int i;
                    (**l_983) &= 1L;
                    if (p_30)
                        continue;
                    if (l_986)
                        break;
                    for (g_420 = 0; (g_420 <= 0); g_420 += 1)
                    { /* block id: 411 */
                        int16_t *l_992 = (void*)0;
                        int16_t *l_996 = &g_154;
                        int32_t *l_997 = &g_998[2][5][0];
                        int i, j;
                        (*l_997) &= ((l_987[7] , ((*l_996) |= ((((((g_661[g_420][g_420] != (p_33 > g_63)) & (safe_rshift_func_uint16_t_u_u(p_33, 4))) > (*p_32)) >= ((((((safe_lshift_func_int16_t_s_u((g_612 |= g_946), 14)) | (((((((safe_add_func_uint64_t_u_u(((p_33 != ((0xD6L >= (**g_706)) | (**g_652))) != p_29), 0x75A5C6A23EC92004LL)) & 255UL) && p_30) , p_31) & l_971) <= p_30) == 255UL)) && p_33) < (*p_32)) <= (*g_18)) && l_995)) || 0xA734L) ^ 0xD4135E67201704CBLL))) ^ (**l_983));
                        (**l_983) = p_30;
                        if (g_19)
                            goto lbl_999;
                        (**l_983) = ((l_1000 , p_32) == l_1001);
                    }
                    for (g_205 = 0; (g_205 <= 0); g_205 += 1)
                    { /* block id: 421 */
                        return (*g_706);
                    }
                }
            }
            else
            { /* block id: 425 */
                int8_t l_1005 = 0x65L;
                int32_t l_1021[3][4] = {{0xAED8E6DFL,0xAED8E6DFL,(-1L),0xAED8E6DFL},{0xAED8E6DFL,0L,0L,0xAED8E6DFL},{0L,0xAED8E6DFL,0L,0L}};
                uint8_t *l_1110 = &g_237;
                uint8_t **l_1109[10][1] = {{&l_1110},{(void*)0},{&l_1110},{(void*)0},{(void*)0},{&l_1110},{(void*)0},{&l_1110},{(void*)0},{(void*)0}};
                int i, j;
                for (p_33 = 3; (p_33 >= 0); p_33 -= 1)
                { /* block id: 428 */
                    int8_t l_1011 = 0xA0L;
                    int16_t *l_1035 = (void*)0;
                    int16_t *l_1036 = &g_154;
                    int32_t *l_1038[6][9][2] = {{{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0}},{{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0}},{{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0}},{{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]}},{{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0}},{{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0},{&g_50.f3,(void*)0},{&g_998[2][5][0],&g_998[2][5][0]},{&g_998[2][5][0],(void*)0},{&g_50.f3,(void*)0},{(void*)0,(void*)0}}};
                    int i, j, k;
                    for (g_913 = 0; (g_913 <= 3); g_913 += 1)
                    { /* block id: 431 */
                        int32_t **l_1014 = &g_84[0];
                        int i;
                        (*l_983) = (((!g_118[p_33]) , (*g_236)) , &p_33);
                        if (p_33)
                            continue;
                        l_1012 = ((safe_mul_func_uint16_t_u_u(((l_1005 , (p_29 && ((((((((((((**g_706) ^= ((*p_32) != p_30)) > (&g_198 != p_32)) || g_678.f0) != ((safe_div_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_unary_minus_func_int64_t_s(l_971)), l_987[7].f0)), (*g_236))) != l_971)) < l_971) , 0xE237L) > p_31) == g_612) < 0x80C7L) > l_1011) != g_50.f0))) > p_33), (**l_983))) == g_818);
                        (*l_1014) = ((*l_983) = func_79(l_1013));
                    }
                }
                (*g_565) &= (((l_1111 = &g_913) == (void*)0) == (p_32 == (void*)0));
                for (l_1039 = 0; (l_1039 <= 0); l_1039 += 1)
                { /* block id: 478 */
                    int32_t *l_1112 = (void*)0;
                    int32_t *l_1113 = (void*)0;
                    int32_t *l_1114 = &l_1021[0][2];
                    int i;
                    (*l_1114) ^= l_978;
                }
            }
            g_1115 = (-2L);
        }
        else
        { /* block id: 483 */
            int8_t *l_1116 = &g_661[0][0];
            return l_1116;
        }
        (*g_565) = (safe_rshift_func_int8_t_s_u((safe_rshift_func_int8_t_s_s(((safe_div_func_int64_t_s_s(l_971, ((safe_rshift_func_int8_t_s_u((((*l_1126) = l_1125) != (l_1129 = g_1127[5][6][0])), 0)) & (p_31 < (safe_mul_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(l_1039, ((((void*)0 == l_1134) , ((p_33 , &g_655) != (*l_958))) & 0xDBD4L))), p_31)))))) >= g_205), 6)), 4));
    }
    else
    { /* block id: 489 */
        uint16_t l_1139 = 65531UL;
        uint32_t l_1149 = 1UL;
        uint32_t *l_1158 = (void*)0;
        uint32_t *l_1159[3];
        uint32_t l_1160 = 0xBDB3E2F8L;
        int i;
        for (i = 0; i < 3; i++)
            l_1159[i] = &g_205;
        (*g_565) = p_33;
        if (g_50.f3)
            goto lbl_1140;
lbl_1140:
        p_29 |= (safe_mul_func_uint16_t_u_u(((*g_236) = ((safe_div_func_uint64_t_u_u((l_1139 , l_971), l_971)) && l_1139)), (&g_651[1][1] == &l_959)));
        (*g_565) = (0xB3L || ((safe_mul_func_uint16_t_u_u(((*l_1085) = 8UL), (((safe_mod_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u(((((safe_rshift_func_uint8_t_u_s((((*g_236) = l_1139) | (((p_31 && p_31) , (((**g_652) = (((*p_32) == l_1149) == ((g_205 = (safe_lshift_func_uint16_t_u_u(l_1149, (safe_mul_func_int8_t_s_s(((*g_707) = (safe_rshift_func_int8_t_s_u(((((((safe_mod_func_int64_t_s_s(p_30, p_29)) & (*p_32)) , p_31) || 65535UL) ^ g_661[0][0]) , 1L), 0))), l_1139))))) , 0x4AB4L))) && l_1149)) && p_30)), 3)) , l_1149) , p_33) , p_33), 10)) != p_33), l_1160)) & 0UL) , 0xC604L))) < 0xF0CEDA1FL));
        (*g_565) = ((l_971 , &g_654) == &g_654);
    }
    l_1161 = func_79(p_32);
    if ((+(safe_lshift_func_uint16_t_u_s((l_971 ^ ((safe_div_func_uint8_t_u_u(p_31, (safe_add_func_int32_t_s_s(((0x20C2L & (safe_sub_func_int16_t_s_s((p_29 > (*g_236)), (!((safe_rshift_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(0x14L, (l_1180 = ((**g_706) ^= ((safe_mul_func_uint8_t_u_u(g_225, (+(((l_1179 = &l_1085) != (void*)0) & 4L)))) >= p_33))))), p_31)) ^ p_30))))) , l_1181), p_33)))) ^ p_33)), 2))))
    { /* block id: 506 */
        int32_t *l_1182 = &g_420;
        int32_t l_1183[2];
        int32_t *l_1184 = &g_50.f3;
        int32_t *l_1185 = &l_971;
        int32_t *l_1186[7];
        uint32_t l_1187 = 0x5AD5106DL;
        int i;
        for (i = 0; i < 2; i++)
            l_1183[i] = 0x0918EBBDL;
        for (i = 0; i < 7; i++)
            l_1186[i] = (void*)0;
        for (g_121 = 0; (g_121 >= 0); g_121 -= 1)
        { /* block id: 509 */
            if (p_30)
                break;
            return p_32;
        }
        l_1187++;
    }
    else
    { /* block id: 514 */
        int32_t *l_1190 = &g_998[2][5][0];
        int32_t **l_1197 = &g_565;
        int16_t *l_1208 = &g_612;
        uint32_t l_1211 = 0x8D80A3C9L;
        union U1 l_1260 = {1UL};
        int64_t *l_1268[3][6] = {{&g_437,&g_437,&g_437,&g_437,&g_437,&g_437},{&g_121,&g_437,&g_121,&g_437,&g_121,&g_437},{&g_437,&g_437,&g_437,&g_437,&g_437,&g_437}};
        int64_t **l_1267 = &l_1268[2][5];
        int i, j;
        (*l_1190) = ((*l_1161) = p_31);
        (*l_1197) = func_79(((safe_rshift_func_uint16_t_u_s(0x9959L, 4)) , l_1107));
        for (p_31 = 18; (p_31 < (-16)); p_31 = safe_sub_func_uint32_t_u_u(p_31, 9))
        { /* block id: 521 */
            int64_t l_1207 = 0L;
            union U1 *l_1249[7][10][3] = {{{(void*)0,&g_50,(void*)0},{&g_50,(void*)0,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,(void*)0},{&g_50,&g_50,(void*)0},{&g_50,(void*)0,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50}},{{(void*)0,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,(void*)0},{(void*)0,&g_50,&g_50},{&g_50,&g_50,(void*)0}},{{&g_50,&g_50,&g_50},{&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50}},{{(void*)0,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,&g_50},{&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50},{(void*)0,&g_50,(void*)0},{(void*)0,(void*)0,&g_50}},{{&g_50,&g_50,(void*)0},{(void*)0,&g_50,&g_50},{(void*)0,&g_50,(void*)0},{(void*)0,&g_50,&g_50},{(void*)0,&g_50,&g_50},{&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50},{(void*)0,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,(void*)0,&g_50}},{{&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,(void*)0},{(void*)0,&g_50,&g_50},{&g_50,&g_50,(void*)0},{&g_50,&g_50,&g_50},{&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50}},{{&g_50,(void*)0,&g_50},{&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50},{(void*)0,&g_50,&g_50},{&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50}}};
            uint64_t *l_1259[6] = {&g_1115,&g_1115,&g_1115,&g_1115,&g_1115,&g_1115};
            int8_t **l_1269 = (void*)0;
            int8_t **l_1270 = &l_1107;
            int32_t *l_1271 = &g_998[1][6][0];
            int i, j, k;
            if (p_30)
                break;
            if ((safe_add_func_uint16_t_u_u((((*l_1190) |= (safe_mod_func_int8_t_s_s((!(safe_mod_func_int32_t_s_s(p_30, (**g_652)))), (*p_32)))) == (0x56EAL >= (l_1207 || ((((l_1208 != (*g_1128)) & ((0xEEL != (*p_32)) < p_30)) | g_1209) > l_1210)))), l_1211)))
            { /* block id: 524 */
                p_33 &= (**l_1197);
            }
            else
            { /* block id: 526 */
                union U1 *l_1252[1];
                uint32_t l_1254 = 3UL;
                int i;
                for (i = 0; i < 1; i++)
                    l_1252[i] = &g_1253[2];
                for (p_33 = 0; (p_33 != 7); p_33++)
                { /* block id: 529 */
                    int32_t *l_1214 = &g_998[0][7][0];
                    l_1214 = (void*)0;
                }
                for (l_1180 = 21; (l_1180 != 20); --l_1180)
                { /* block id: 534 */
                    int16_t **l_1229 = (void*)0;
                    union U1 **l_1251[9][4] = {{&l_1250,&l_1249[2][8][1],(void*)0,&l_1249[2][8][1]},{&l_1249[2][8][1],&l_1250,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1249[2][8][1],(void*)0},{&l_1250,&l_1250,&l_1250,&l_1249[2][8][1]},{&l_1250,&l_1249[2][8][1],&l_1249[2][8][1],&l_1250},{(void*)0,&l_1249[2][8][1],(void*)0,&l_1249[2][8][1]},{&l_1249[2][8][1],&l_1250,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1249[2][8][1],(void*)0},{&l_1250,&l_1250,&l_1250,&l_1249[2][8][1]}};
                    const int32_t l_1258 = 0x3025A8B9L;
                    int i, j;
                    p_29 &= (safe_rshift_func_uint16_t_u_s(65535UL, (safe_div_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((((*l_1085) = ((safe_add_func_uint8_t_u_u((l_1229 != (void*)0), (safe_div_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u((((safe_sub_func_uint16_t_u_u((((((safe_rshift_func_uint8_t_u_s(l_1207, (+(p_33 == ((safe_lshift_func_int8_t_s_s(((*g_18) = (safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((++(*g_236)), (safe_mod_func_uint8_t_u_u((l_1249[2][2][0] == (l_1252[0] = l_1250)), l_1254)))), (!((safe_lshift_func_int16_t_s_s(l_1258, 4)) , g_913))))), 2)) , l_1254))))) , g_1253[2].f0) , 0xB4L) , 0x74B3B66A51DCB275LL) != p_31), p_30)) , &g_225) == &p_31), 8L)) & (-1L)), l_1254)))) <= 0L)) != p_31) >= p_33), l_1258)), 0x6DL)), p_33))));
                    return p_32;
                }
            }
            l_1271 = func_79((l_1260 , ((*l_1270) = (p_32 = ((*g_706) = (*g_706))))));
        }
    }
    return l_1111;
}


/* ------------------------------------------ */
/* 
 * reads : g_154 g_437 g_237 g_121 g_818 g_661 g_612 g_50.f3 g_19 g_838 g_678.f3 g_236 g_55 g_831 g_84 g_118 g_565 g_946 g_50.f0 g_655 g_416 g_417 g_420 g_706 g_707
 * writes: g_154 g_437 g_84 g_237 g_121 g_818 g_612 g_50.f3 g_831 g_838 g_118 g_420 g_55
 */
static int8_t * func_42(const uint64_t  p_43, int8_t * p_44)
{ /* block id: 312 */
    uint32_t l_822 = 0xC23F5073L;
    int32_t *l_871[2][2][4] = {{{&g_420,&g_50.f3,&g_50.f3,&g_50.f3},{&g_420,&g_50.f3,&g_420,&g_50.f3}},{{&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3},{&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3}}};
    uint32_t *** const *l_880[10] = {&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6],&g_651[1][6]};
    uint64_t l_916 = 0x710723F356E618E4LL;
    int16_t *l_919 = &g_612;
    int8_t *l_933 = &g_661[0][0];
    union U1 l_947 = {0x3E796E0CL};
    const int64_t *l_949 = &g_437;
    const int64_t **l_948 = &l_949;
    int8_t l_950 = 0x06L;
    uint32_t l_952 = 0x7C1B17C4L;
    int i, j, k;
    for (g_154 = 3; (g_154 < 25); g_154 = safe_add_func_int32_t_s_s(g_154, 3))
    { /* block id: 315 */
        int16_t *l_830 = (void*)0;
        union U0 *l_842 = &g_843[4][3][3];
        union U1 *l_853 = &g_50;
        union U1 **l_852 = &l_853;
        int32_t l_865 = 1L;
        int8_t *l_886 = &g_661[0][0];
        int32_t *l_923 = (void*)0;
        int32_t l_939 = 0xE53283FAL;
        int64_t **l_951 = (void*)0;
        for (g_437 = 0; (g_437 <= 3); g_437 += 1)
        { /* block id: 318 */
            int32_t *l_811 = &g_50.f3;
            int32_t **l_812 = (void*)0;
            int32_t **l_813 = &g_84[0];
            const int64_t *l_868 = &g_437;
            const int64_t **l_867 = &l_868;
            int32_t *l_869[1][7];
            union U1 *l_911 = &g_50;
            int8_t *l_922 = &g_661[1][0];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 7; j++)
                    l_869[i][j] = (void*)0;
            }
            (*l_813) = l_811;
            for (g_237 = 0; (g_237 <= 3); g_237 += 1)
            { /* block id: 322 */
                int32_t l_816[8] = {0xFD4B5C1FL,0xFD4B5C1FL,0xED068A43L,0xFD4B5C1FL,0xFD4B5C1FL,0xED068A43L,0xFD4B5C1FL,0xFD4B5C1FL};
                uint16_t *l_876 = (void*)0;
                uint16_t *l_877 = &g_118[2];
                int16_t **l_884 = (void*)0;
                int16_t ***l_883 = &l_884;
                uint64_t *l_885 = &g_818;
                union U1 l_931 = {0x57D6AE6FL};
                int i;
                for (g_121 = 3; (g_121 >= 0); g_121 -= 1)
                { /* block id: 325 */
                    uint64_t *l_817 = &g_818;
                    int16_t *l_821[10] = {(void*)0,&g_612,&g_154,&g_612,(void*)0,(void*)0,&g_612,&g_154,&g_612,(void*)0};
                    int16_t *l_832 = &g_612;
                    const int32_t l_837 = 0xFA0DA033L;
                    int i;
                    if ((safe_add_func_uint16_t_u_u((((--(*l_817)) || g_661[1][0]) && ((g_612 &= l_816[2]) || p_43)), (0x7D133F4FL > l_822))))
                    { /* block id: 328 */
                        const int16_t l_823 = 1L;
                        (*l_811) |= l_823;
                    }
                    else
                    { /* block id: 330 */
                        union U0 **l_841 = &g_838[6];
                        (*l_811) &= (!(((safe_unary_minus_func_int8_t_s((*p_44))) , (safe_rshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u(((g_831 = l_830) == l_832), ((0x4DED1A465805C984LL == ((*l_817) = (+(safe_unary_minus_func_uint16_t_u((safe_mul_func_int8_t_s_s(l_837, ((((*l_841) = g_838[6]) != (p_43 , l_842)) < (safe_mul_func_int8_t_s_s((((l_837 & 1L) != 0x21CC9D5F5B51EA21LL) & l_837), g_678.f3)))))))))) != (*g_236)))), l_822))) ^ 1L));
                        return p_44;
                    }
                    for (g_818 = 0; (g_818 <= 3); g_818 += 1)
                    { /* block id: 339 */
                        uint32_t l_854 = 0xE78C3066L;
                        int32_t **l_870[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_870[i] = &l_869[0][0];
                    }
                    (**l_813) = ((*g_831) == (safe_sub_func_int64_t_s_s(p_43, 1UL)));
                }
                (*g_565) = (((*l_885) = (safe_mul_func_uint16_t_u_u((((0xF91D6397L >= (((*l_877) ^= (*g_236)) , (((g_818 & ((p_43 == (safe_rshift_func_uint8_t_u_u(1UL, 7))) == (l_880[9] != l_880[5]))) && ((safe_mul_func_uint8_t_u_u((((((*l_883) = &l_830) != (void*)0) < 1L) , 0xDDL), l_865)) >= (-5L))) <= p_43))) , (*p_44)) > 0x7EL), l_816[6]))) ^ g_19);
                (*l_813) = func_79(l_886);
                for (l_822 = 0; (l_822 <= 1); l_822 += 1)
                { /* block id: 357 */
                    uint8_t *l_912[5];
                    int32_t l_915 = 1L;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_912[i] = &g_913;
                }
            }
            l_865 = 1L;
        }
        (*g_565) ^= ((safe_lshift_func_uint8_t_u_u(g_154, 4)) == ((*g_236) = (!(p_43 || (safe_add_func_uint16_t_u_u(((l_939 <= (((((safe_add_func_int64_t_s_s(((safe_add_func_uint16_t_u_u(0xE566L, p_43)) ^ ((g_946 ^ ((l_947 , l_948) == ((p_43 && l_950) , l_951))) | g_50.f0)), l_952)) == g_437) || 0L) > (**g_655)) , (*p_44))) , (*g_236)), p_43))))));
    }
    return (*g_706);
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_63 g_50.f3 g_565 g_420
 * writes: g_55 g_63 g_50.f3 g_420
 */
static union U1  func_45(union U1  p_46, int8_t * p_47, uint32_t  p_48, const union U1  p_49)
{ /* block id: 1 */
    int32_t l_66[2];
    uint64_t l_425[7][6];
    int32_t l_458 = 0x5CEB2D7CL;
    int32_t l_459[4];
    int32_t *l_486 = &g_50.f3;
    uint8_t l_500 = 0UL;
    uint32_t ** const l_507[8] = {&g_416,&g_416,&g_416,&g_416,&g_416,&g_416,&g_416,&g_416};
    int64_t **l_539 = (void*)0;
    union U1 l_576 = {18446744073709551615UL};
    int32_t l_590 = 2L;
    uint8_t l_663 = 0UL;
    int32_t l_684 = 0x8095996AL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_66[i] = 0x09E00C25L;
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
            l_425[i][j] = 1UL;
    }
    for (i = 0; i < 4; i++)
        l_459[i] = 1L;
    for (p_48 = (-12); (p_48 >= 33); p_48 = safe_add_func_uint8_t_u_u(p_48, 6))
    { /* block id: 4 */
        int32_t *l_54[7] = {&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3,&g_50.f3};
        int i;
        g_55--;
        if (g_55)
            goto lbl_807;
        for (g_55 = (-19); (g_55 <= 24); g_55++)
        { /* block id: 8 */
            uint32_t *l_62[6][4][3] = {{{&g_63,(void*)0,(void*)0},{&g_63,&g_63,(void*)0},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63}},{{&g_63,&g_63,&g_63},{&g_63,&g_63,(void*)0},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63}},{{&g_63,&g_63,(void*)0},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63}},{{&g_63,&g_63,(void*)0},{&g_63,&g_63,(void*)0},{&g_63,&g_63,&g_63},{&g_63,&g_63,(void*)0}},{{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63}},{{&g_63,&g_63,&g_63},{&g_63,&g_63,&g_63},{&g_63,(void*)0,&g_63},{&g_63,(void*)0,(void*)0}}};
            int i, j, k;
            g_50.f3 &= (safe_mod_func_uint32_t_u_u((++g_63), p_48));
        }
    }
    for (p_48 = 0; (p_48 <= 1); p_48 += 1)
    { /* block id: 15 */
        int32_t *l_75[4];
        int32_t l_446 = 0xBB3B7ED9L;
        union U0 *l_504 = &g_505;
        union U0 **l_503 = &l_504;
        int32_t l_534[3][10][8] = {{{0xF8604B1CL,0x99473287L,0L,0xA55B0567L,0xE8B9A2A8L,0x97C078D3L,0xE8B9A2A8L,0xA55B0567L},{0x4D7B97B0L,0xA55B0567L,0x4D7B97B0L,0x83B44181L,0L,(-8L),0xC9DBC0B5L,0L},{(-1L),0xC9DBC0B5L,0xF6E73FE1L,(-1L),0x83B44181L,(-1L),0L,0x4D7B97B0L},{0xF6E73FE1L,1L,0x99473287L,0x83B44181L,0xC9DBC0B5L,0xF8604B1CL,(-1L),(-1L)},{(-1L),9L,0xE5114348L,0xE5114348L,9L,(-1L),0x97C078D3L,0x83B44181L},{0L,0x533D08E0L,0x51287526L,0x4D7B97B0L,0xE5114348L,0x97C078D3L,0L,3L},{9L,0xC9DBC0B5L,0x99473287L,0x4D7B97B0L,(-1L),0x99473287L,0xF6E73FE1L,0x83B44181L},{3L,(-1L),0x533D08E0L,0xE5114348L,0L,0xE5114348L,0x533D08E0L,(-1L)},{1L,0x97C078D3L,3L,0x83B44181L,0xE5114348L,0x51287526L,0x83B44181L,(-1L)},{0x4D7B97B0L,0L,0xF8604B1CL,0xF6E73FE1L,1L,0x99473287L,0x83B44181L,0xC9DBC0B5L}},{{(-1L),0xF6E73FE1L,3L,0x51287526L,(-8L),0x533D08E0L,0x533D08E0L,(-8L)},{(-8L),0x533D08E0L,0x533D08E0L,(-8L),0x51287526L,3L,0xF6E73FE1L,(-1L)},{0xC9DBC0B5L,0x83B44181L,0x99473287L,1L,0xF6E73FE1L,0xF8604B1CL,0L,0x4D7B97B0L},{(-1L),0x83B44181L,0x51287526L,0xE5114348L,0x83B44181L,3L,0x97C078D3L,1L},{(-1L),0x533D08E0L,0xE5114348L,0L,0xE5114348L,0x533D08E0L,(-1L),3L},{0x83B44181L,0xF6E73FE1L,0x99473287L,(-1L),0x4D7B97B0L,0x99473287L,0xC9DBC0B5L,9L},{3L,0L,0x97C078D3L,0xE5114348L,0x4D7B97B0L,0x51287526L,0x533D08E0L,0L},{0x83B44181L,0x97C078D3L,(-1L),9L,0xE5114348L,0xE5114348L,9L,(-1L)},{(-1L),(-1L),0xF8604B1CL,0xC9DBC0B5L,0x83B44181L,0x99473287L,1L,0xF6E73FE1L},{(-1L),0xC9DBC0B5L,0x98FEB7A1L,0x51287526L,0xF6E73FE1L,0x97C078D3L,0x533D08E0L,0xF6E73FE1L}},{{0xC9DBC0B5L,0x533D08E0L,0L,0xC9DBC0B5L,0x51287526L,(-1L),(-8L),(-1L)},{(-8L),9L,0x99473287L,9L,(-8L),0xF8604B1CL,0x4D7B97B0L,0L},{(-1L),1L,0x187688DBL,0xE5114348L,1L,0x98FEB7A1L,0x97C078D3L,9L},{0x4D7B97B0L,0x533D08E0L,0x187688DBL,(-1L),0xE5114348L,0L,0x4D7B97B0L,3L},{1L,(-8L),0x99473287L,0L,0L,0x99473287L,(-8L),1L},{3L,0x4D7B97B0L,0L,0xE5114348L,(-1L),0x187688DBL,0x533D08E0L,0x4D7B97B0L},{9L,0x97C078D3L,0x98FEB7A1L,1L,0xE5114348L,0x187688DBL,1L,(-3L)},{3L,(-1L),0L,0L,0x187688DBL,0x4D7B97B0L,0x187688DBL,0L},{(-3L),0L,(-3L),0L,0x533D08E0L,0xF8604B1CL,0x738C6A61L,0x533D08E0L},{0x97C078D3L,0x738C6A61L,0x99473287L,0x97C078D3L,0L,0xE8B9A2A8L,0x533D08E0L,(-3L)}}};
        uint32_t l_542 = 0x8AD8A29FL;
        int32_t *l_563 = &l_459[0];
        int32_t l_569 = 0L;
        const uint64_t * const l_627 = &l_425[3][4];
        uint8_t l_660 = 0x24L;
        uint16_t **l_664 = &g_236;
        uint8_t l_696 = 0x24L;
        const int32_t *l_723[5][8][4] = {{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}}};
        const int32_t **l_722[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t ***l_741[10] = {&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652,&g_652};
        int16_t *l_784 = &g_154;
        int16_t **l_783[1];
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_75[i] = &g_50.f3;
        for (i = 0; i < 1; i++)
            l_783[i] = &l_784;
    }
lbl_807:
    (*g_565) ^= ((*l_486) = 0xE057A4ECL);
    for (g_63 = 0; (g_63 <= 7); g_63 += 1)
    { /* block id: 307 */
        int32_t l_808 = 0xD7209755L;
        int i;
        if (l_808)
            break;
        (*g_565) = (p_46.f3 <= 0xE053B13124F6FBA8LL);
    }
    return p_49;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_18 g_19 g_50 g_91 g_55 g_118 g_121 g_84 g_154 g_50.f0 g_198 g_205 g_50.f3 g_225 g_237 g_280
 * writes: g_91 g_121 g_63 g_118 g_55 g_205 g_225 g_50.f3 g_236 g_280 g_154 g_237 g_84
 */
static union U1  func_76(int32_t * p_77, uint32_t  p_78)
{ /* block id: 24 */
    int8_t *l_90 = &g_91;
    int32_t l_97 = (-1L);
    int32_t l_98 = (-1L);
    uint16_t l_105 = 65534UL;
    int16_t *l_261 = (void*)0;
    int32_t l_313 = 5L;
    uint16_t **l_332 = &g_236;
    uint16_t **l_342 = &g_236;
    int32_t l_373 = 0x49D64FC4L;
    int32_t l_374 = 1L;
    int32_t l_375 = (-1L);
    int32_t l_379 = 0x0B8DA7C8L;
    int64_t l_382 = 0x7829D7283E07E041LL;
    int32_t l_386 = 0x97FF54A1L;
    int32_t l_387 = 0x872E3FFCL;
    int32_t l_388 = 4L;
    int32_t l_393 = 0xA87CF726L;
    int8_t l_402 = 4L;
    int32_t l_403[9][1] = {{0L},{0x6C9223B5L},{0L},{0L},{0x6C9223B5L},{0L},{0L},{0x6C9223B5L},{0L}};
    int32_t l_404 = 0x07B4FC8BL;
    int64_t l_405 = 1L;
    int32_t l_408 = (-9L);
    uint16_t l_409 = 0x0977L;
    union U1 l_414 = {18446744073709551615UL};
    int i, j;
    if (func_85((safe_mul_func_int8_t_s_s(((*l_90) = 1L), ((safe_rshift_func_uint16_t_u_u((((g_63 || (0x27FAAB159BBC08F5LL | (~(l_97 = (safe_div_func_int8_t_s_s((*g_18), p_78)))))) >= l_98) , (safe_lshift_func_int8_t_s_u(((((safe_mod_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(0xA1L, ((l_105 >= (safe_rshift_func_uint16_t_u_u(p_78, 13))) < 3UL))) , p_78), l_98)) == (-5L)) > l_105) , 0L), l_105))), l_105)) , l_98))), g_50))
    { /* block id: 81 */
        int8_t l_258[3][9][4] = {{{0xDDL,(-1L),0x5EL,0x91L},{0x91L,0xF0L,4L,0x5EL},{0xA7L,0xF0L,(-1L),0x91L},{0xF0L,(-1L),(-1L),(-1L)},{0x8BL,4L,0x28L,0x06L},{(-1L),0x42L,0xCBL,0x8EL},{0x06L,0xCBL,0xF0L,0x28L},{0x06L,0xDDL,0xCBL,1L},{(-1L),0x28L,0x28L,(-1L)}},{{0x8BL,0x91L,(-1L),0x00L},{0xF0L,1L,(-1L),0xABL},{0xA7L,0x8EL,4L,0xABL},{0x91L,1L,0x5EL,0x00L},{0xDDL,0x91L,0xDDL,(-1L)},{4L,0x28L,0x06L,1L},{0xABL,0xDDL,0x00L,0x28L},{(-1L),0xCBL,0x00L,0x8EL},{0xABL,0x42L,0x06L,0x06L}},{{4L,4L,0xDDL,(-1L)},{0xDDL,(-1L),0x5EL,0x91L},{0x91L,0xF0L,4L,0x5EL},{0xA7L,0xF0L,(-1L),0x91L},{0xF0L,(-1L),(-1L),(-1L)},{0x8BL,4L,0x28L,0x06L},{(-1L),0x42L,0xCBL,0x8EL},{0x06L,0xCBL,0xF0L,0x28L},{0x06L,0xDDL,0xCBL,1L}}};
        int32_t l_277 = 0L;
        uint32_t l_304 = 0x89942230L;
        int32_t l_324[6][10][1] = {{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}},{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}},{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}},{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}},{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}},{{5L},{(-4L)},{6L},{(-4L)},{5L},{0xA09B0128L},{(-8L)},{0x968A6B7EL},{(-8L)},{0xA09B0128L}}};
        uint32_t l_395[1][3][9] = {{{18446744073709551607UL,0x1CD71164L,18446744073709551607UL,0x7D9DACEBL,0x3B20187AL,0x7D9DACEBL,18446744073709551607UL,0x1CD71164L,0x1CD71164L},{0xEC931C8AL,0x4BDD194FL,0x1CD71164L,0x7D9DACEBL,0x1CD71164L,0x4BDD194FL,0xEC931C8AL,0xEC931C8AL,0x4BDD194FL},{0x7D9DACEBL,0x4BDD194FL,18446744073709551607UL,0x4BDD194FL,0x7D9DACEBL,0x39230E06L,0x39230E06L,0x7D9DACEBL,0x4BDD194FL}}};
        int i, j, k;
        l_258[0][1][0] |= (*p_77);
        for (g_205 = 0; (g_205 <= 2); g_205 += 1)
        { /* block id: 85 */
            union U1 l_267 = {0x7585B5AEL};
            union U0 *l_314 = &g_315;
            uint64_t l_354 = 18446744073709551612UL;
            int32_t l_376 = 0xA3583BD0L;
            int32_t l_377 = 1L;
            int32_t l_381 = 0x9D242D67L;
            int32_t l_389 = 0x5B41BC4CL;
            int32_t l_392 = 4L;
            int32_t l_394 = 0L;
            (*p_77) = ((g_118[2] || l_105) < ((void*)0 != l_261));
            (*p_77) = ((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_u((!(((l_267 , (*p_77)) <= l_267.f0) <= (-4L))), 6)), l_258[0][1][0])) , (safe_mod_func_int8_t_s_s(p_78, (+(safe_rshift_func_int8_t_s_u((safe_add_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((l_277 = (*g_18)), 6)), (safe_mul_func_int8_t_s_s(p_78, (0x25L >= (-5L)))))), g_63))))));
            for (l_98 = 2; (l_98 >= 0); l_98 -= 1)
            { /* block id: 91 */
                uint64_t l_292 = 0x4D6C61763957BBCELL;
                int32_t l_293 = 1L;
                union U0 *l_316 = &g_317;
                union U0 *l_319[7] = {&g_320,&g_320,&g_320,&g_320,&g_320,&g_320,&g_320};
                int16_t l_343 = 1L;
                int32_t l_378 = 0xA5A11C1BL;
                int32_t l_380 = (-1L);
                int32_t l_384 = 0x866BDBAEL;
                int i;
                for (p_78 = 0; (p_78 <= 2); p_78 += 1)
                { /* block id: 94 */
                    volatile union U0 **l_282 = &g_280;
                    (*l_282) = g_280;
                    return l_267;
                }
                l_277 ^= ((*p_77) = (l_258[1][5][2] == 0xDA75L));
                for (l_97 = 2; (l_97 >= 0); l_97 -= 1)
                { /* block id: 102 */
                    int32_t l_311 = 0xC0556BECL;
                    union U1 l_318 = {0x9B64BEFDL};
                    uint8_t *l_325 = (void*)0;
                    uint8_t *l_326 = &g_237;
                    uint16_t ***l_333 = (void*)0;
                    uint16_t ***l_334 = &l_332;
                    int64_t *l_339 = &g_121;
                    int32_t *l_344 = &l_313;
                    int16_t *l_353 = &g_154;
                    uint16_t *l_355 = &g_118[3];
                    int32_t l_383 = 0L;
                    int32_t l_385 = 0xD6B6C70EL;
                    int32_t l_390 = (-8L);
                    int32_t l_391 = 0x48A5FBA9L;
                    int i, j, k;
                    for (g_55 = 0; (g_55 <= 2); g_55 += 1)
                    { /* block id: 105 */
                        int16_t *l_310[10] = {&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154};
                        int32_t *l_312[2];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_312[i] = (void*)0;
                        l_313 ^= ((*p_77) |= (safe_mul_func_uint16_t_u_u(l_258[l_97][(g_55 + 5)][(g_55 + 1)], (((safe_sub_func_int64_t_s_s(1L, (safe_div_func_int64_t_s_s(0x82138A2B4C7A8684LL, (safe_unary_minus_func_uint16_t_u((safe_lshift_func_int16_t_s_u((l_293 = l_292), 3)))))))) != (safe_add_func_int32_t_s_s((-1L), ((((safe_mul_func_int16_t_s_s((p_78 & (0xCBEF5C30L == (((safe_lshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s((l_277 ^= (g_154 ^= (safe_mod_func_uint32_t_u_u((l_304 && (((safe_rshift_func_int8_t_s_u((safe_add_func_int8_t_s_s(((+0L) , 6L), g_19)), 3)) , g_55) , (*g_18))), g_55)))), p_78)), 5)) , p_78) <= p_78))), g_118[2])) >= l_258[0][4][1]) , l_311) , l_258[1][4][1])))) <= p_78))));
                        (*p_77) = ((l_316 = l_314) != (l_318 , l_319[1]));
                    }
                    (*l_344) &= (((safe_lshift_func_uint8_t_u_s((--(*l_326)), 1)) , (((~((safe_lshift_func_int16_t_s_u(((((*l_334) = l_332) != (void*)0) || (safe_mul_func_int16_t_s_s(4L, 0x8D5EL))), 4)) == (safe_div_func_int64_t_s_s(((*l_339) = l_293), l_311)))) <= ((l_277 ^= l_324[1][1][0]) < ((safe_lshift_func_int16_t_s_s(((l_342 != &g_236) ^ 2L), l_318.f3)) && (*g_18)))) & l_343)) , (*p_77));
                    if ((safe_sub_func_uint64_t_u_u((p_78 , ((safe_add_func_uint32_t_u_u(7UL, l_267.f3)) || ((((safe_rshift_func_uint16_t_u_u(((void*)0 != p_77), 3)) == (safe_mul_func_int16_t_s_s(((l_258[l_98][(g_205 + 5)][l_97] &= (p_78 && l_267.f0)) != (((*l_353) = p_78) > ((*l_355) |= ((l_354 < l_105) && l_293)))), (-5L)))) == l_267.f0) | g_225))), p_78)))
                    { /* block id: 122 */
                        int32_t *l_356 = (void*)0;
                        int32_t *l_357 = &l_267.f3;
                        int32_t *l_358 = (void*)0;
                        int32_t *l_359 = &l_324[1][9][0];
                        int32_t *l_360 = &l_313;
                        int32_t *l_361 = &l_267.f3;
                        int32_t *l_362 = &l_267.f3;
                        int32_t *l_363 = (void*)0;
                        int32_t *l_364 = &l_324[3][5][0];
                        int32_t *l_365 = &l_313;
                        int32_t *l_366 = &l_324[3][6][0];
                        int32_t *l_367 = &l_313;
                        int32_t *l_368 = &l_313;
                        int32_t *l_369 = &l_277;
                        int32_t *l_370 = &g_50.f3;
                        int32_t *l_371 = &l_324[3][5][0];
                        int32_t *l_372[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_372[i] = &l_313;
                        --l_395[0][0][1];
                        if ((*l_344))
                            break;
                    }
                    else
                    { /* block id: 125 */
                        (*l_344) = (*p_77);
                    }
                }
            }
        }
    }
    else
    { /* block id: 131 */
        int32_t **l_400 = &g_84[0];
        int32_t *l_401[2][9] = {{&l_373,&l_373,&l_373,&l_373,&l_373,&l_373,&l_373,&l_373,&l_373},{&l_374,&l_374,&l_374,&l_374,&l_374,&l_374,&l_374,&l_374,&l_374}};
        int32_t l_406 = 0L;
        int32_t l_407 = (-1L);
        int i, j;
        (*l_400) = ((safe_div_func_uint32_t_u_u(p_78, ((*p_77) = l_379))) , p_77);
        ++l_409;
        (*p_77) &= (safe_lshift_func_int8_t_s_u((l_414 , p_78), 4));
    }
    return l_414;
}


/* ------------------------------------------ */
/* 
 * reads : g_84
 * writes:
 */
static int32_t * func_79(int8_t * p_80)
{ /* block id: 18 */
    uint16_t l_83 = 0xBFE1L;
    if ((safe_lshift_func_uint8_t_u_s(l_83, 2)))
    { /* block id: 19 */
        return g_84[0];
    }
    else
    { /* block id: 21 */
        return g_84[0];
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_118 g_18 g_19 g_121 g_63 g_91 g_84 g_154 g_50.f0 g_198 g_205 g_50.f3 g_225 g_237
 * writes: g_91 g_121 g_63 g_118 g_55 g_205 g_225 g_50.f3 g_236
 */
static int32_t  func_85(int16_t  p_86, union U1  p_87)
{ /* block id: 27 */
    int8_t *l_116 = &g_91;
    int32_t l_137 = 0xFAE1B8E0L;
    int8_t l_138 = (-8L);
    uint8_t l_139 = 255UL;
    int32_t l_145 = 1L;
    int16_t *l_153[2][6][9] = {{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}}};
    int8_t **l_156 = &l_116;
    union U1 l_160 = {0UL};
    const uint32_t l_165 = 0xDB8EE5A8L;
    int64_t *l_166 = &g_121;
    uint32_t l_167 = 1UL;
    uint16_t *l_234 = (void*)0;
    int32_t l_246 = 0L;
    int32_t l_248[6][3] = {{(-1L),0x74D9B914L,(-1L)},{0x4B791F81L,0x4B791F81L,0x72F990AEL},{8L,0x74D9B914L,8L},{0x4B791F81L,0x72F990AEL,0x72F990AEL},{(-1L),0x74D9B914L,(-1L)},{0x4B791F81L,0x4B791F81L,0x72F990AEL}};
    int32_t *l_254 = &g_50.f3;
    int32_t *l_257[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_257[i] = (void*)0;
lbl_227:
    for (g_91 = 0; (g_91 <= 13); g_91++)
    { /* block id: 30 */
        int8_t *l_115 = (void*)0;
        int8_t **l_114 = &l_115;
        uint16_t *l_117[2][7] = {{&g_55,&g_118[2],&g_55,&g_118[2],&g_55,&g_118[2],&g_55},{&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2]}};
        int32_t l_119 = 0L;
        int16_t *l_120[5][1];
        int32_t *l_140 = (void*)0;
        int32_t *l_141 = &l_137;
        uint32_t *l_142 = &g_63;
        int8_t l_143 = 0x7EL;
        int32_t *l_144[4];
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 1; j++)
                l_120[i][j] = (void*)0;
        }
        for (i = 0; i < 4; i++)
            l_144[i] = &g_50.f3;
        l_145 &= (((safe_div_func_uint16_t_u_u(((g_121 = (0L > (l_119 ^= ((safe_add_func_uint8_t_u_u((((*l_114) = &g_19) != l_116), 0x4CL)) ^ g_55)))) , ((safe_mul_func_int16_t_s_s((((*l_142) |= ((((*l_141) = ((0x6FB9L <= (safe_div_func_uint16_t_u_u(g_118[2], (safe_add_func_uint8_t_u_u((((((((!(safe_lshift_func_uint8_t_u_s(((safe_add_func_int32_t_s_s((safe_mul_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(((l_137 , (((p_87.f3 > 0UL) > l_119) ^ p_86)) > l_119), (*g_18))) >= l_137), l_119)), (-4L))) >= l_138), (*g_18)))) & 0x4D9FAD1A43B2DE0ELL) >= g_121) ^ l_139) && 0xD16FL) >= p_87.f3) || p_86), 0xA9L))))) <= l_139)) | p_86) <= p_87.f0)) , p_87.f0), p_87.f0)) , 0x901EL)), g_91)) || p_86) > l_143);
    }
    if ((((safe_rshift_func_uint16_t_u_u(p_86, (safe_mul_func_uint8_t_u_u(((safe_add_func_int16_t_s_s((l_137 = (l_145 &= (!p_86))), (~(((g_19 >= ((g_91 , func_79(((*l_156) = &l_138))) != &g_63)) & ((l_167 = (!((*l_166) = (((safe_mul_func_uint16_t_u_u(((l_160 , (safe_sub_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s(l_160.f3, g_154)) && g_19), l_165))) & 2UL), 5UL)) == (-1L)) ^ 0xE9327043L)))) < l_138)) , g_118[1])))) | g_55), 0x2BL)))) , g_91) != p_87.f0))
    { /* block id: 43 */
        int32_t *l_168 = &l_137;
        int32_t *l_169 = &g_50.f3;
        int32_t *l_170[10][3][8] = {{{&l_137,(void*)0,(void*)0,&g_50.f3,&l_145,&g_50.f3,(void*)0,&g_50.f3},{&l_145,(void*)0,&l_145,&g_50.f3,&l_137,&l_137,(void*)0,&l_137},{&g_50.f3,&g_50.f3,&l_160.f3,&g_50.f3,&l_137,&g_50.f3,(void*)0,&l_137}},{{&l_160.f3,&g_50.f3,&l_145,&l_160.f3,(void*)0,(void*)0,(void*)0,&l_137},{&l_145,(void*)0,&l_160.f3,&g_50.f3,&l_137,&l_137,(void*)0,&l_145},{(void*)0,&l_137,&l_145,(void*)0,&l_145,&g_50.f3,(void*)0,&l_160.f3}},{{&l_137,&g_50.f3,&l_137,&l_137,(void*)0,&l_137,&l_137,&g_50.f3},{&l_145,(void*)0,&l_145,(void*)0,&g_50.f3,&l_137,&l_137,&l_160.f3},{(void*)0,&l_137,&g_50.f3,(void*)0,&l_145,&l_160.f3,&l_137,&g_50.f3}},{{&g_50.f3,(void*)0,&l_145,&l_137,&l_137,&g_50.f3,&l_137,&l_160.f3},{&l_137,&g_50.f3,&l_137,&l_160.f3,&g_50.f3,(void*)0,(void*)0,&l_145},{&g_50.f3,&l_160.f3,&l_145,&l_137,(void*)0,&g_50.f3,(void*)0,&g_50.f3}},{{(void*)0,&l_145,&l_160.f3,&l_145,(void*)0,&g_50.f3,(void*)0,&l_137},{&l_145,&l_137,&l_145,&l_160.f3,&l_137,(void*)0,(void*)0,&l_137},{&l_160.f3,&l_145,&l_160.f3,(void*)0,&g_50.f3,&g_50.f3,(void*)0,&g_50.f3}},{{&g_50.f3,&l_137,&l_145,&l_145,(void*)0,&l_137,(void*)0,(void*)0},{&g_50.f3,&l_160.f3,(void*)0,(void*)0,(void*)0,&g_50.f3,(void*)0,&l_145},{&l_160.f3,&g_50.f3,(void*)0,(void*)0,(void*)0,(void*)0,&g_50.f3,&l_160.f3}},{{&l_137,&l_137,&l_137,&g_50.f3,(void*)0,&l_137,&l_145,(void*)0},{&l_137,&l_145,&g_50.f3,&g_50.f3,&g_50.f3,&l_137,&l_145,(void*)0},{&g_50.f3,&l_137,&l_137,(void*)0,(void*)0,(void*)0,&g_50.f3,&l_137}},{{(void*)0,&g_50.f3,&g_50.f3,&g_50.f3,&l_137,&g_50.f3,&l_160.f3,&g_50.f3},{&l_145,&l_160.f3,(void*)0,&g_50.f3,(void*)0,&l_145,&l_160.f3,&g_50.f3},{&l_160.f3,&g_50.f3,&g_50.f3,&l_145,(void*)0,&l_145,(void*)0,(void*)0}},{{(void*)0,&l_137,&l_137,(void*)0,(void*)0,&g_50.f3,(void*)0,&l_145},{&g_50.f3,&l_160.f3,&l_160.f3,(void*)0,&g_50.f3,&g_50.f3,&l_145,&g_50.f3},{(void*)0,&l_137,&l_145,&l_160.f3,&l_137,&l_145,&l_137,(void*)0}},{{&l_137,&l_145,(void*)0,(void*)0,&g_50.f3,&l_160.f3,&g_50.f3,&l_145},{(void*)0,&l_137,&l_160.f3,&l_145,&l_160.f3,&l_137,(void*)0,&l_160.f3},{&l_145,&l_137,&g_50.f3,&l_145,&l_137,(void*)0,&l_145,(void*)0}}};
        uint16_t l_171 = 1UL;
        int i, j, k;
        ++l_171;
    }
    else
    { /* block id: 45 */
        uint16_t l_193 = 5UL;
        uint16_t *l_196 = (void*)0;
        uint16_t *l_197 = &g_118[2];
        int32_t l_238 = 7L;
        int32_t l_247 = 0xC6ABA3EDL;
        int32_t l_249 = (-1L);
        int32_t l_250[5][1][4] = {{{0x5547A387L,0xA0A6BE89L,0x5547A387L,0xA0A6BE89L}},{{0x5547A387L,0xA0A6BE89L,0x5547A387L,0xA0A6BE89L}},{{0x5547A387L,0xA0A6BE89L,0x5547A387L,0xA0A6BE89L}},{{0x5547A387L,0xA0A6BE89L,0x5547A387L,0xA0A6BE89L}},{{0x5547A387L,0xA0A6BE89L,0x5547A387L,0xA0A6BE89L}}};
        int i, j, k;
        if ((safe_sub_func_uint32_t_u_u(((4UL | (((+(safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_s(0xC607L, (safe_lshift_func_uint8_t_u_s(((safe_div_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(g_50.f0, 4)) <= ((((safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_s(((p_87.f0 ^ (0L >= ((l_138 > l_193) | (safe_sub_func_uint16_t_u_u(((*l_197) = p_87.f3), (p_87.f0 && 0xA823L)))))) <= l_193), p_87.f3)), l_137)) != g_50.f0) > p_87.f0) <= g_63)), 1L)) | l_160.f0), (*g_18))))) != g_198), 2UL)), p_87.f3))) || l_193) >= p_86)) > 8L), p_86)))
        { /* block id: 47 */
            int32_t *l_203 = &g_50.f3;
            uint16_t *l_214[9] = {&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2],&g_118[2]};
            uint16_t **l_235[2][2][1];
            int32_t *l_239 = (void*)0;
            int32_t *l_240 = &l_145;
            int32_t *l_241 = (void*)0;
            int32_t *l_242 = &l_145;
            int32_t *l_243 = (void*)0;
            int32_t l_244 = 5L;
            int32_t *l_245[4][3] = {{&l_145,&l_145,&l_145},{&l_244,&l_244,&l_244},{&l_145,&l_145,&l_145},{&l_244,&l_244,&l_244}};
            uint8_t l_251 = 0UL;
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_235[i][j][k] = &l_197;
                }
            }
            for (g_63 = 0; (g_63 >= 36); g_63 = safe_add_func_uint32_t_u_u(g_63, 6))
            { /* block id: 50 */
                uint32_t *l_226 = &g_63;
                for (g_55 = 29; (g_55 == 10); g_55 = safe_sub_func_int16_t_s_s(g_55, 1))
                { /* block id: 53 */
                    uint16_t l_223[10][6][4] = {{{1UL,0xAC59L,0x2A37L,1UL},{0xAC59L,65535UL,0x2A37L,0x2A37L},{1UL,1UL,0x188FL,0x5BA5L},{0xFE02L,0xFCF3L,0x62B8L,1UL},{0x62B8L,1UL,0xAC59L,0x62B8L},{1UL,1UL,0x0BBEL,1UL}},{{1UL,0xFCF3L,0x2A37L,0x5BA5L},{65535UL,1UL,0xAC59L,0x2A37L},{0xFE02L,65535UL,0x28C5L,1UL},{0xFE02L,0xAC59L,0xAC59L,0xFE02L},{65535UL,1UL,0x2A37L,0xAC59L},{1UL,65535UL,0x0BBEL,0x5BA5L}},{{1UL,65535UL,0xAC59L,0x5BA5L},{0x62B8L,65535UL,0x62B8L,0xAC59L},{0xFE02L,1UL,0x188FL,0xFE02L},{1UL,0xAC59L,0x2A37L,1UL},{0xAC59L,65535UL,0x2A37L,0x2A37L},{1UL,1UL,0x188FL,0x5BA5L}},{{0xFE02L,0xFCF3L,0x62B8L,1UL},{0x62B8L,1UL,0xAC59L,0x62B8L},{1UL,1UL,0x0BBEL,1UL},{1UL,0xFCF3L,0x2A37L,0x5BA5L},{65535UL,1UL,0xAC59L,0UL},{0x2A37L,65535UL,0x5BA5L,0x62B8L}},{{0x2A37L,0x28C5L,0x28C5L,0x2A37L},{0x188FL,0x62B8L,0UL,0x28C5L},{0x62B8L,65535UL,65535UL,0xFCF3L},{0xAC59L,0x188FL,0x28C5L,0xFCF3L},{0x0BBEL,65535UL,0x0BBEL,0x28C5L},{0x2A37L,0x62B8L,0xFE02L,0x2A37L}},{{0xAC59L,0x28C5L,0UL,0x62B8L},{0x28C5L,65535UL,0UL,0UL},{0xAC59L,0xAC59L,0xFE02L,0xFCF3L},{0x2A37L,65535UL,0x0BBEL,0x62B8L},{0x0BBEL,0x62B8L,0x28C5L,0x0BBEL},{0xAC59L,0x62B8L,65535UL,0x62B8L}},{{0x62B8L,65535UL,0UL,0xFCF3L},{0x188FL,0xAC59L,0x28C5L,0UL},{0x2A37L,65535UL,0x5BA5L,0x62B8L},{0x2A37L,0x28C5L,0x28C5L,0x2A37L},{0x188FL,0x62B8L,0UL,0x28C5L},{0x62B8L,65535UL,65535UL,0xFCF3L}},{{0xAC59L,0x188FL,0x28C5L,0xFCF3L},{0x0BBEL,65535UL,0x0BBEL,0x28C5L},{0x2A37L,0x62B8L,0xFE02L,0x2A37L},{0xAC59L,0x28C5L,0UL,0x62B8L},{0x28C5L,65535UL,0UL,0UL},{0xAC59L,0xAC59L,0xFE02L,0xFCF3L}},{{0x2A37L,65535UL,0x0BBEL,0x62B8L},{0x0BBEL,0x62B8L,0x28C5L,0x0BBEL},{0xAC59L,0x62B8L,65535UL,0x62B8L},{0x62B8L,65535UL,0UL,0xFCF3L},{0x188FL,0xAC59L,0x28C5L,0UL},{0x2A37L,65535UL,0x5BA5L,0x62B8L}},{{0x2A37L,0x28C5L,0x28C5L,0x2A37L},{0x188FL,0x62B8L,0UL,0x28C5L},{0x62B8L,65535UL,65535UL,0xFCF3L},{0xAC59L,0x188FL,0x28C5L,0xFCF3L},{0x0BBEL,65535UL,0x0BBEL,0x28C5L},{0x2A37L,0x62B8L,0xFE02L,0x2A37L}}};
                    int i, j, k;
                    if ((l_203 != &l_145))
                    { /* block id: 54 */
                        int32_t *l_204 = &l_137;
                        ++g_205;
                        if (p_87.f3)
                            break;
                    }
                    else
                    { /* block id: 57 */
                        int32_t *l_224 = &g_225;
                        p_87.f3 = ((safe_add_func_int64_t_s_s(((p_87.f3 == (safe_add_func_uint32_t_u_u(((((*l_224) ^= (((((l_214[0] != &g_118[2]) <= (((safe_div_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((((l_145 , (safe_rshift_func_int8_t_s_s(p_87.f3, 6))) && 0x722C89E7ADD9F72ELL) || ((((safe_div_func_uint32_t_u_u((9UL >= (l_223[9][0][2] && p_86)), 0x521A4600L)) < 3UL) <= l_165) || 0x5F8DL)), g_55)), 9L)) || (-10L)) <= 0x86BFL)) , p_87.f0) ^ p_86) > (*l_203))) , g_50.f0) < l_137), 4294967286UL))) >= p_86), g_121)) < 9UL);
                        (*l_203) &= (l_226 != (void*)0);
                    }
                }
                (*l_203) = p_87.f0;
                if (l_145)
                    goto lbl_227;
            }
            l_238 &= ((*l_203) = (safe_mul_func_uint8_t_u_u((((l_160.f3 , 9UL) == (((safe_rshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s(((l_234 = l_153[1][5][4]) != (g_236 = &l_193)), 1UL)), (l_193 ^ ((0x4214L & ((*l_197) = (&l_137 == g_84[0]))) != (*l_203))))) || p_87.f3) <= (-2L))) , g_205), g_237)));
            l_251++;
            (*l_203) ^= ((*l_240) |= 0x1B163B82L);
        }
        else
        { /* block id: 74 */
            return p_86;
        }
    }
    (*l_254) |= l_139;
    p_87.f3 |= (safe_mul_func_int8_t_s_s((*l_254), (0xBDE14919L == (*l_254))));
    return p_87.f3;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_14[i][j], "g_14[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_118[i], "g_118[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_198, "g_198", print_hash_value);
    transparent_crc(g_205, "g_205", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_237, "g_237", print_hash_value);
    transparent_crc(g_417, "g_417", print_hash_value);
    transparent_crc(g_420, "g_420", print_hash_value);
    transparent_crc(g_437, "g_437", print_hash_value);
    transparent_crc(g_612, "g_612", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_661[i][j], "g_661[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_678.f0, "g_678.f0", print_hash_value);
    transparent_crc(g_678.f3, "g_678.f3", print_hash_value);
    transparent_crc(g_818, "g_818", print_hash_value);
    transparent_crc(g_913, "g_913", print_hash_value);
    transparent_crc(g_946, "g_946", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_966[i], "g_966[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_967, "g_967", print_hash_value);
    transparent_crc(g_968, "g_968", print_hash_value);
    transparent_crc(g_969, "g_969", print_hash_value);
    transparent_crc(g_970, "g_970", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_998[i][j][k], "g_998[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1115, "g_1115", print_hash_value);
    transparent_crc(g_1209, "g_1209", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1253[i].f0, "g_1253[i].f0", print_hash_value);
        transparent_crc(g_1253[i].f3, "g_1253[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1310, "g_1310", print_hash_value);
    transparent_crc(g_1403, "g_1403", print_hash_value);
    transparent_crc(g_1512, "g_1512", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 359
XXX total union variables: 22

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 50
breakdown:
   depth: 1, occurrence: 143
   depth: 2, occurrence: 40
   depth: 3, occurrence: 12
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 4
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 40, occurrence: 1
   depth: 50, occurrence: 1

XXX total number of pointers: 405

XXX times a variable address is taken: 611
XXX times a pointer is dereferenced on RHS: 143
breakdown:
   depth: 1, occurrence: 119
   depth: 2, occurrence: 23
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 170
breakdown:
   depth: 1, occurrence: 154
   depth: 2, occurrence: 16
XXX times a pointer is compared with null: 24
XXX times a pointer is compared with address of another variable: 8
XXX times a pointer is compared with another pointer: 10
XXX times a pointer is qualified to be dereferenced: 4158

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 593
   level: 2, occurrence: 120
   level: 3, occurrence: 6
   level: 4, occurrence: 1
XXX number of pointers point to pointers: 110
XXX number of pointers point to scalars: 279
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.1
XXX average alias set size: 1.29

XXX times a non-volatile is read: 1143
XXX times a non-volatile is write: 532
XXX times a volatile is read: 7
XXX    times read thru a pointer: 1
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 789
XXX percentage of non-volatile access: 99.5

XXX forward jumps: 2
XXX backward jumps: 5

XXX stmts: 160
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 35
   depth: 2, occurrence: 24
   depth: 3, occurrence: 21
   depth: 4, occurrence: 25
   depth: 5, occurrence: 26

XXX percentage a fresh-made variable is used: 17.1
XXX percentage an existing variable is used: 82.9
********************* end of statistics **********************/

