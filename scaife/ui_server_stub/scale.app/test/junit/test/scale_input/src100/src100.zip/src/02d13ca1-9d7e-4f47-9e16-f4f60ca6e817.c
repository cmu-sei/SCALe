/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      703642110
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x3AE35568L;
static uint32_t g_6[3] = {0x68D526D2L,0x68D526D2L,0x68D526D2L};
static volatile int32_t g_8 = 0x1C71BC7DL;/* VOLATILE GLOBAL g_8 */
static volatile int32_t g_9[9][10] = {{1L,1L,1L,1L,3L,0x2A04F777L,0x207182B4L,0x2A4B15D3L,0xF2BA167CL,0x2A4B15D3L},{1L,0xC9FA8BC0L,0x3E763161L,0x2A4B15D3L,0x3E763161L,0xC9FA8BC0L,1L,0x207182B4L,0xF2BA167CL,0x198AB79AL},{0x207182B4L,0x2A04F777L,3L,1L,1L,1L,1L,3L,0x2A04F777L,0x207182B4L},{9L,0x2A04F777L,0xF2BA167CL,0xE8B01213L,0x2A4B15D3L,0x198AB79AL,1L,0x198AB79AL,0x2A4B15D3L,0xE8B01213L},{0xE8B01213L,0xC9FA8BC0L,0xE8B01213L,0x198AB79AL,3L,1L,0xE8B01213L,0x207182B4L,0x207182B4L,0xE8B01213L},{3L,1L,1L,1L,1L,3L,0x2A04F777L,0x207182B4L,0x2A4B15D3L,0xF2BA167CL},{9L,0xF2BA167CL,4L,0xC9FA8BC0L,0x207182B4L,0xC9FA8BC0L,4L,0xF2BA167CL,9L,3L},{9L,1L,0x3E763161L,0x2A04F777L,0xC9FA8BC0L,3L,3L,0xC9FA8BC0L,0x2A04F777L,0x3E763161L},{3L,3L,0xC9FA8BC0L,0x2A04F777L,0x3E763161L,1L,9L,0xE8B01213L,9L,1L}};
static volatile int32_t g_10 = 0L;/* VOLATILE GLOBAL g_10 */
static int32_t g_11 = 1L;
static uint32_t g_68[9][10][2] = {{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}},{{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L},{0x428827C8L,0x428827C8L}}};
static int32_t g_73 = 0xB6CC60A9L;
static uint8_t g_125 = 1UL;
static uint16_t g_127 = 1UL;
static int32_t g_131 = 0L;
static int16_t g_160 = 0xF7F4L;
static uint64_t g_175 = 0xB128D63D52EC9A0CLL;
static int32_t *g_186 = (void*)0;
static uint32_t g_207 = 0UL;
static int64_t g_225 = (-5L);
static uint16_t g_232[9] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static uint64_t *g_237 = &g_175;
static uint64_t **g_236 = &g_237;
static uint16_t * volatile * const g_295 = (void*)0;
static uint8_t g_319 = 1UL;
static uint16_t *g_354 = &g_232[0];
static uint32_t g_356 = 1UL;
static uint16_t g_380[6][2] = {{65535UL,1UL},{1UL,65535UL},{1UL,1UL},{65535UL,1UL},{1UL,65535UL},{1UL,1UL}};
static uint32_t g_403 = 0x26491130L;
static uint8_t g_413 = 4UL;
static int32_t g_414[1][9][3] = {{{0L,0L,1L},{0xAB3F0FD0L,1L,1L},{1L,0x187358BBL,1L},{0xAB3F0FD0L,0L,0xAB3F0FD0L},{0L,1L,1L},{(-5L),(-5L),1L},{0x4B2485EEL,1L,1L},{1L,0L,(-1L)},{0x4B2485EEL,0x187358BBL,0x4B2485EEL}}};
static const int64_t *g_452 = (void*)0;
static const int64_t **g_451 = &g_452;
static int64_t *g_524 = &g_225;
static int64_t **g_523 = &g_524;
static int64_t ***g_522 = &g_523;
static int16_t g_526 = 0L;
static uint32_t g_551 = 0x810F9DFCL;
static const uint32_t g_575 = 0UL;
static uint64_t ***g_615 = &g_236;
static uint64_t ****g_614 = &g_615;
static const uint8_t g_757[5] = {255UL,255UL,255UL,255UL,255UL};
static uint64_t g_814 = 0UL;
static uint16_t g_843 = 1UL;
static uint32_t *g_867 = &g_207;
static int8_t * volatile * const g_879[3] = {(void*)0,(void*)0,(void*)0};
static const uint64_t g_933 = 18446744073709551611UL;
static const uint64_t *g_932 = &g_933;
static const uint64_t **g_931 = &g_932;
static const uint32_t g_937 = 1UL;
static const uint32_t *g_936 = &g_937;
static int8_t **g_981 = (void*)0;
static int8_t *g_984 = (void*)0;
static int8_t **g_983 = &g_984;
static const uint16_t g_1013 = 65535UL;
static const uint16_t g_1014 = 1UL;
static const uint16_t g_1017 = 0UL;
static const uint16_t g_1018[4] = {0xBB4EL,0xBB4EL,0xBB4EL,0xBB4EL};
static const uint16_t g_1019[5][2] = {{0xAD07L,0xB84BL},{0xAD07L,0xB84BL},{0xAD07L,0xB84BL},{0xAD07L,0xB84BL},{0xAD07L,0xB84BL}};
static const uint16_t g_1020 = 0x95F5L;
static const uint16_t g_1021 = 0x4163L;
static const uint16_t g_1022 = 1UL;
static const uint16_t g_1023 = 0xCB6BL;
static const uint16_t g_1024[9] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static const uint16_t g_1025 = 0UL;
static const uint16_t g_1026 = 0x831FL;
static const uint16_t g_1027 = 0xC629L;
static const uint16_t g_1028 = 0UL;
static const uint16_t g_1029 = 0UL;
static const uint16_t g_1030[9][8][1] = {{{65535UL},{0x976CL},{2UL},{65529UL},{0x3549L},{0x6A78L},{0UL},{0x8384L}},{{0x8F34L},{0x3D58L},{4UL},{0xD80BL},{65528UL},{0x3AF1L},{0xE516L},{0x3C08L}},{{0x3C08L},{0xE516L},{0x3AF1L},{65528UL},{0xD80BL},{4UL},{0x3D58L},{0x8F34L}},{{0x8384L},{0UL},{0x6A78L},{0x3549L},{65529UL},{2UL},{0x976CL},{65535UL}},{{0x976CL},{2UL},{65529UL},{0x3549L},{0x6A78L},{0UL},{0x8384L},{0x8F34L}},{{0x3D58L},{4UL},{0xD80BL},{65528UL},{0x3AF1L},{0xE516L},{0x3C08L},{0x3C08L}},{{0xE516L},{0x3AF1L},{65528UL},{0xD80BL},{4UL},{0x3D58L},{0x8F34L},{0x8384L}},{{0UL},{0x6A78L},{0x3549L},{65529UL},{2UL},{0x976CL},{65535UL},{0x976CL}},{{2UL},{65529UL},{0x3549L},{0x6A78L},{0UL},{0x8384L},{0x8F34L},{0x3D58L}}};
static const uint16_t g_1031 = 0xA2C0L;
static const uint16_t g_1032 = 65535UL;
static const uint16_t g_1033 = 0xCB71L;
static const uint16_t g_1034 = 5UL;
static const uint16_t g_1035[7] = {3UL,3UL,3UL,3UL,3UL,3UL,3UL};
static const uint16_t g_1036 = 0xAA1AL;
static const uint16_t g_1037 = 0xDAA3L;
static const uint16_t g_1038 = 0xD280L;
static const uint16_t g_1039 = 0x249CL;
static const uint16_t g_1040 = 0xC6B4L;
static const uint16_t g_1041 = 0xB2C6L;
static const uint16_t g_1042 = 0x0877L;
static const uint16_t g_1043 = 65535UL;
static const uint16_t g_1044 = 1UL;
static const uint16_t * const g_1016[8][1][9] = {{{&g_1020,(void*)0,&g_1025,&g_1032,&g_1034,(void*)0,&g_1020,(void*)0,&g_1034}},{{&g_1026,&g_1031,&g_1031,&g_1026,&g_1041,&g_1023,&g_1026,&g_1023,&g_1041}},{{&g_1020,(void*)0,&g_1025,&g_1032,&g_1034,(void*)0,&g_1020,(void*)0,&g_1034}},{{&g_1026,&g_1031,&g_1031,&g_1026,&g_1041,&g_1023,&g_1026,&g_1023,&g_1041}},{{&g_1020,(void*)0,&g_1025,&g_1032,&g_1034,(void*)0,&g_1020,(void*)0,&g_1034}},{{&g_1026,&g_1031,&g_1031,&g_1026,&g_1041,&g_1023,&g_1026,&g_1023,&g_1041}},{{&g_1020,(void*)0,&g_1025,&g_1032,&g_1034,(void*)0,&g_1020,(void*)0,&g_1034}},{{&g_1026,&g_1031,&g_1031,&g_1026,&g_1041,&g_1023,&g_1026,&g_1023,&g_1041}}};
static const uint16_t * const *g_1015 = &g_1016[2][0][6];
static uint16_t **g_1047 = &g_354;
static uint16_t ***g_1046 = &g_1047;
static uint16_t ***g_1051 = &g_1047;
static uint16_t *g_1088 = &g_380[0][0];
static uint16_t *g_1089 = &g_232[3];
static uint16_t *g_1090 = (void*)0;
static uint16_t *g_1091[7] = {&g_127,&g_127,&g_127,&g_127,&g_127,&g_127,&g_127};
static uint16_t *g_1092 = &g_232[2];
static uint16_t *g_1093 = &g_380[0][0];
static uint16_t *g_1094 = &g_380[2][1];
static uint16_t *g_1095 = (void*)0;
static uint16_t *g_1096 = (void*)0;
static uint16_t *g_1097[3][5] = {{&g_380[0][0],&g_380[0][0],&g_380[0][0],&g_380[0][0],&g_380[0][0]},{&g_232[2],&g_232[2],&g_232[2],&g_232[2],&g_232[2]},{&g_380[0][0],&g_380[0][0],&g_380[0][0],&g_380[0][0],&g_380[0][0]}};
static uint16_t *g_1098 = &g_843;
static uint16_t *g_1099 = &g_232[6];
static uint16_t *g_1100 = &g_232[8];
static uint16_t *g_1101 = (void*)0;
static uint16_t *g_1102[4] = {&g_843,&g_843,&g_843,&g_843};
static uint16_t ** const g_1087[5][10] = {{(void*)0,&g_1100,&g_1091[4],&g_1092,&g_1091[4],&g_1100,(void*)0,&g_1097[1][4],&g_1099,&g_1097[1][4]},{(void*)0,&g_1100,&g_1091[4],&g_1092,&g_1091[4],&g_1100,(void*)0,&g_1097[1][4],&g_1099,&g_1097[1][4]},{(void*)0,&g_1100,&g_1091[4],&g_1092,&g_1091[4],&g_1100,(void*)0,&g_1097[1][4],&g_1099,&g_1097[1][4]},{(void*)0,&g_1100,&g_1091[4],&g_1092,&g_1091[4],&g_1100,(void*)0,&g_1097[1][4],&g_1099,&g_1097[1][4]},{(void*)0,&g_1100,&g_1091[4],&g_1092,&g_1091[4],&g_1100,(void*)0,&g_1097[1][4],&g_1099,&g_1097[1][4]}};
static uint16_t ** const *g_1086 = &g_1087[4][4];
static uint16_t ** const **g_1085 = &g_1086;
static uint64_t g_1228 = 18446744073709551615UL;
static int64_t g_1229[9] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
static int32_t g_1320 = 0x0054B5B5L;
static int32_t g_1337 = 0xA832E138L;
static int32_t g_1341 = 0x4AC40EA0L;
static int8_t g_1397 = (-10L);
static uint8_t g_1405 = 0x45L;
static int16_t *g_1523[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static uint32_t * const  volatile * volatile * volatile * volatile g_1550[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t *g_1589 = &g_131;
static int32_t **g_1588 = &g_1589;
static const int32_t ** const  volatile g_1597 = (void*)0;/* VOLATILE GLOBAL g_1597 */
static volatile int32_t g_1706 = 0xD7A728A9L;/* VOLATILE GLOBAL g_1706 */
static const uint16_t g_1762 = 0UL;
static int32_t g_1771 = (-7L);
static const volatile uint32_t g_1829 = 0x22FA5DD9L;/* VOLATILE GLOBAL g_1829 */
static uint32_t **g_1864[9] = {&g_867,&g_867,&g_867,&g_867,&g_867,&g_867,&g_867,&g_867,&g_867};
static uint32_t ***g_1863 = &g_1864[2];
static uint64_t g_1917 = 18446744073709551611UL;
static uint64_t **g_1929 = (void*)0;
static int32_t ** volatile g_1937 = &g_186;/* VOLATILE GLOBAL g_1937 */
static int32_t ** volatile g_1952 = &g_186;/* VOLATILE GLOBAL g_1952 */
static uint8_t * volatile g_1999[6][6] = {{&g_413,&g_319,&g_413,&g_125,&g_413,&g_319},{&g_1405,&g_319,&g_319,&g_319,&g_1405,&g_319},{&g_413,&g_125,&g_413,&g_319,&g_413,&g_125},{&g_1405,&g_125,&g_319,&g_125,&g_1405,&g_125},{&g_413,&g_319,&g_413,&g_125,&g_413,&g_319},{&g_1405,&g_319,&g_319,&g_319,&g_1405,&g_319}};
static uint8_t * volatile * volatile g_1998 = &g_1999[5][5];/* VOLATILE GLOBAL g_1998 */
static int32_t g_2033[8] = {0x5BE3EBC1L,0x4D24259BL,0x5BE3EBC1L,0x5BE3EBC1L,0x4D24259BL,0x5BE3EBC1L,0x5BE3EBC1L,0x4D24259BL};
static uint32_t g_2034[3][7] = {{4294967295UL,0UL,0UL,4294967295UL,0UL,0UL,4294967295UL},{0x8B0FD5BCL,0xC5F6A56FL,0x8B0FD5BCL,0x8B0FD5BCL,0xC5F6A56FL,0x8B0FD5BCL,0x8B0FD5BCL},{4294967295UL,4294967295UL,0xDD636ABDL,4294967295UL,4294967295UL,0xDD636ABDL,4294967295UL}};
static int8_t g_2076 = 0x6AL;
static uint64_t g_2096 = 1UL;
static uint32_t g_2177 = 4UL;
static int32_t ** volatile g_2263 = (void*)0;/* VOLATILE GLOBAL g_2263 */
static int32_t g_2274 = 0L;
static uint16_t ****g_2303 = &g_1046;
static uint16_t *****g_2302[1] = {&g_2303};
static int32_t * volatile g_2318[6] = {&g_73,&g_73,&g_73,&g_73,&g_73,&g_73};
static uint8_t *g_2332 = &g_1405;
static uint8_t **g_2331[5] = {&g_2332,&g_2332,&g_2332,&g_2332,&g_2332};
static int32_t * volatile g_2383 = (void*)0;/* VOLATILE GLOBAL g_2383 */
static const int64_t **g_2549[7][8][4] = {{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}},{{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452},{&g_452,&g_452,&g_452,&g_452}}};
static int32_t ** volatile g_2562 = &g_186;/* VOLATILE GLOBAL g_2562 */
static const int32_t *g_2642 = (void*)0;
static const int32_t ** volatile g_2641 = &g_2642;/* VOLATILE GLOBAL g_2641 */
static int32_t ** volatile g_2644[7][7][5] = {{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}},{{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186}}};
static int32_t ** volatile g_2645[5][3] = {{&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186}};
static int32_t ** volatile g_2646 = &g_186;/* VOLATILE GLOBAL g_2646 */
static const volatile uint8_t g_2710 = 0UL;/* VOLATILE GLOBAL g_2710 */
static const int32_t ** volatile g_2729 = &g_2642;/* VOLATILE GLOBAL g_2729 */
static int64_t g_2780 = 0x3BF1A1C19745DC78LL;
static const int32_t ** volatile g_2845 = &g_2642;/* VOLATILE GLOBAL g_2845 */
static uint16_t g_2971 = 0UL;
static const int32_t ** volatile g_2972[3] = {&g_2642,&g_2642,&g_2642};
static uint16_t * const *g_3074 = &g_1096;
static uint16_t * const **g_3073[10] = {&g_3074,&g_3074,&g_3074,&g_3074,&g_3074,&g_3074,&g_3074,&g_3074,&g_3074,&g_3074};
static uint16_t * const ***g_3072 = &g_3073[0];
static volatile uint32_t * volatile * volatile * volatile g_3096[2] = {(void*)0,(void*)0};
static uint32_t *g_3115 = (void*)0;
static uint32_t **g_3114 = &g_3115;
static const int32_t ** volatile g_3140 = &g_2642;/* VOLATILE GLOBAL g_3140 */
static int32_t * volatile g_3145 = &g_73;/* VOLATILE GLOBAL g_3145 */
static int32_t g_3264[10] = {0x7C72D068L,0xF7151C4CL,0x3E6A15D6L,0x3E6A15D6L,0xF7151C4CL,(-1L),(-8L),0xF7151C4CL,0xF7151C4CL,(-8L)};
static int32_t ** const  volatile g_3294 = &g_186;/* VOLATILE GLOBAL g_3294 */
static int32_t ** volatile g_3318 = &g_186;/* VOLATILE GLOBAL g_3318 */
static const int64_t g_3333 = 0xDBEF97FD7D54930CLL;
static int32_t ** volatile g_3372 = &g_186;/* VOLATILE GLOBAL g_3372 */
static int8_t g_3577 = 9L;
static int8_t * const g_3576[2] = {&g_3577,&g_3577};
static int8_t * const *g_3575 = &g_3576[1];
static int8_t * const **g_3574[5][1] = {{&g_3575},{&g_3575},{&g_3575},{&g_3575},{&g_3575}};
static int8_t * const ***g_3573[3][4][10] = {{{(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0],&g_3574[3][0],&g_3574[2][0],&g_3574[1][0],(void*)0},{&g_3574[1][0],&g_3574[3][0],&g_3574[2][0],&g_3574[1][0],(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0]},{(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0},{(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0],&g_3574[3][0]}},{{&g_3574[1][0],(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0]},{(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0]},{(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0],&g_3574[3][0],&g_3574[2][0],&g_3574[1][0],(void*)0},{&g_3574[1][0],&g_3574[3][0],&g_3574[2][0],&g_3574[1][0],(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0]}},{{(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0},{(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0],&g_3574[3][0]},{&g_3574[1][0],(void*)0,&g_3574[2][0],&g_3574[2][0],(void*)0,&g_3574[1][0],&g_3574[2][0],&g_3574[3][0],&g_3574[1][0],&g_3574[1][0]},{(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0],&g_3574[3][0],(void*)0,(void*)0,&g_3574[3][0]}}};
static int32_t * const  volatile g_3623 = &g_414[0][0][1];/* VOLATILE GLOBAL g_3623 */
static int32_t ** volatile g_3660[2][8] = {{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186,&g_186,&g_186},{&g_186,&g_186,&g_186,&g_186,&g_186,&g_186,&g_186,&g_186}};
static int32_t ** volatile g_3661 = &g_186;/* VOLATILE GLOBAL g_3661 */
static const int32_t *g_3678 = &g_1771;
static const int32_t **g_3677 = &g_3678;
static uint32_t g_3738 = 0x91467629L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int64_t  func_12(int32_t  p_13, int32_t * p_14, const int16_t  p_15);
static int32_t * func_27(int32_t * p_28, int32_t  p_29, uint64_t  p_30, int32_t  p_31);
static const uint16_t  func_46(int32_t  p_47, const int32_t * p_48);
static uint8_t  func_49(int8_t  p_50);
static uint64_t  func_60(int8_t  p_61, uint32_t  p_62, int8_t  p_63);
static uint32_t * func_91(uint32_t * p_92);
static uint32_t * func_93(uint32_t * p_94, const int16_t  p_95, uint32_t  p_96, int32_t * p_97, uint32_t * p_98);
static int32_t * func_100(int32_t  p_101, uint32_t  p_102);
static uint32_t * func_103(uint32_t  p_104, uint8_t  p_105);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_125 g_1863 g_1864 g_11 g_1998 g_1999 g_413 g_319 g_1405 g_522 g_523 g_524 g_225 g_1099 g_232
 * writes: g_2 g_6 g_125 g_225 g_3738
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_7 = 0xEB60L;
    int32_t *l_36 = &g_11;
    uint32_t l_3654 = 1UL;
    int32_t **l_3667 = (void*)0;
    int32_t ***l_3666 = &l_3667;
    int32_t l_3682 = 0L;
    int32_t l_3685 = 3L;
    uint8_t l_3687 = 0x27L;
    int32_t l_3702 = 1L;
    int32_t l_3703 = 0x5C782F26L;
    int32_t l_3704 = 0x54B1A4C3L;
    int32_t l_3705[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int64_t **l_3718 = &g_524;
    int i;
    for (g_2 = 0; (g_2 >= (-26)); g_2 = safe_sub_func_int8_t_s_s(g_2, 1))
    { /* block id: 3 */
        int32_t *l_5 = (void*)0;
        uint8_t ***l_3627 = &g_2331[4];
        int32_t l_3655 = 0xD6F91FDCL;
        int32_t l_3658 = 0x303B9A5FL;
        int32_t ***l_3669[1][8][8] = {{{&l_3667,&l_3667,(void*)0,&l_3667,&l_3667,&l_3667,(void*)0,&l_3667},{&l_3667,&l_3667,&l_3667,(void*)0,(void*)0,&l_3667,&l_3667,&l_3667},{&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667},{&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,(void*)0,&l_3667},{&l_3667,&l_3667,(void*)0,&l_3667,&l_3667,(void*)0,(void*)0,&l_3667},{&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667},{&l_3667,&l_3667,&l_3667,(void*)0,&l_3667,&l_3667,(void*)0,&l_3667},{&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667,&l_3667}}};
        const int32_t **l_3679[5];
        int64_t l_3695 = 0xC7B2E170FB8DAF27LL;
        uint8_t l_3706[4][5] = {{247UL,247UL,248UL,248UL,247UL},{252UL,9UL,252UL,9UL,252UL},{247UL,248UL,248UL,247UL,247UL},{0x87L,9UL,0x87L,9UL,0x87L}};
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_3679[i] = &g_3678;
        g_6[2] = (0xD09EL == 0x8311L);
    }
    for (g_125 = 0; (g_125 >= 53); g_125++)
    { /* block id: 1508 */
        uint32_t **l_3721 = &g_867;
        int32_t l_3724 = 9L;
        g_3738 = (((l_3721 == (*g_1863)) || ((safe_rshift_func_int8_t_s_u(l_3724, 6)) ^ ((safe_lshift_func_int8_t_s_u(0L, 3)) <= ((***g_522) |= (safe_rshift_func_uint8_t_u_s((safe_mod_func_uint8_t_u_u((*l_36), (**g_1998))), (safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(l_3724, (!65535UL))), (safe_mul_func_uint8_t_u_u((l_3724 || l_3724), 249UL)))))))))) != l_3724);
    }
    return (*g_1099);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int64_t  func_12(int32_t  p_13, int32_t * p_14, const int16_t  p_15)
{ /* block id: 1460 */
    int16_t l_3612 = (-5L);
    return l_3612;
}


/* ------------------------------------------ */
/* 
 * reads : g_3145 g_73 g_1589 g_131 g_522 g_523 g_524 g_225 g_1098 g_843 g_11 g_68 g_6 g_127 g_125 g_614 g_319 g_356 g_526 g_207 g_232 g_354 g_414 g_575 g_175 g_2332 g_1405 g_1051 g_1047 g_1089 g_1088 g_380 g_2303 g_3264 g_931 g_932 g_933 g_1952 g_186 g_3294 g_3140 g_2642 g_2845 g_1086 g_1087 g_3318 g_2641 g_1046 g_1100 g_1092 g_1588 g_3372 g_1099 g_451 g_452 g_615 g_236 g_237 g_1863 g_1864 g_867 g_1998 g_1999 g_413 g_2076 g_2177 g_814 g_1397
 * writes: g_73 g_526 g_125 g_127 g_131 g_414 g_319 g_68 g_232 g_225 g_160 g_186 g_1405 g_814 g_356 g_1051 g_1046 g_551 g_1771 g_2642 g_1397 g_2971 g_413 g_175 g_2076 g_1917 g_2034 g_3573 g_2177 g_3264
 */
static int32_t * func_27(int32_t * p_28, int32_t  p_29, uint64_t  p_30, int32_t  p_31)
{ /* block id: 12 */
    int32_t l_43 = 0x8D11E8E1L;
    int32_t l_3143 = (-10L);
    int8_t *l_3182 = (void*)0;
    uint64_t l_3184 = 0UL;
    uint32_t l_3191 = 1UL;
    uint16_t ****l_3206 = &g_1051;
    uint8_t l_3224 = 252UL;
    uint16_t ***l_3243 = &g_1047;
    uint32_t l_3293[3][3][8] = {{{0xF349AEC5L,4294967295UL,0xE736036BL,0x8ED8168DL,0x86F728ADL,0xF349AEC5L,0x86F728ADL,0x8ED8168DL},{4294967291UL,0xF1ACE5A8L,4294967291UL,0xF349AEC5L,0x09A1FF4AL,1UL,0xF1ACE5A8L,0x02CE9C00L},{4294967287UL,1UL,0xE0895126L,0x532D5741L,0x0C47BEEFL,0x65328846L,0x09A1FF4AL,0xE0895126L}},{{4294967287UL,0x0C47BEEFL,1UL,0xE736036BL,0x09A1FF4AL,0xE2CFAB72L,0xE2CFAB72L,0x09A1FF4AL},{4294967291UL,0UL,0UL,4294967291UL,0x86F728ADL,0x02CE9C00L,1UL,0xF349AEC5L},{0xF349AEC5L,0xC04D5F45L,0x14692A44L,0xE0895126L,5UL,0xF349AEC5L,4294967295UL,0xE736036BL}},{{4UL,0xC04D5F45L,4294967291UL,1UL,0x532D5741L,0x02CE9C00L,0xC04D5F45L,0x02CE9C00L},{0x0C47BEEFL,0UL,4294967295UL,0UL,0x0C47BEEFL,0xE2CFAB72L,0x532D5741L,4294967295UL},{0x73D1F541L,0x0C47BEEFL,0x09A1FF4AL,0x14692A44L,0xF349AEC5L,0x65328846L,0xE2CFAB72L,0UL}}};
    uint64_t l_3316 = 0x1CF38FA9DAC3A789LL;
    int32_t *l_3334[4] = {&g_414[0][0][1],&g_414[0][0][1],&g_414[0][0][1],&g_414[0][0][1]};
    uint64_t * const *l_3429[2];
    uint64_t * const **l_3428 = &l_3429[0];
    int8_t ** const *l_3451 = &g_983;
    int8_t ** const * const *l_3450 = &l_3451;
    uint16_t **** const *l_3535 = (void*)0;
    int16_t l_3549 = 0x7444L;
    int32_t **l_3582 = &g_1589;
    uint16_t l_3583 = 65532UL;
    int32_t *l_3607 = &g_3264[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_3429[i] = &g_237;
    if ((safe_mul_func_int8_t_s_s((!((safe_mod_func_uint16_t_u_u(l_43, (l_3143 = (safe_lshift_func_int16_t_s_u((-1L), func_46(((void*)0 != &l_43), &g_11)))))) ^ 18446744073709551615UL)), 1UL)))
    { /* block id: 1288 */
        uint64_t l_3144 = 18446744073709551615UL;
        uint8_t l_3164[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
        int32_t l_3165 = 0x9A9922DFL;
        const int8_t *l_3183[5][5][6] = {{{&g_2076,&g_1397,&g_2076,&g_1397,&g_2076,&g_2076},{&g_2076,&g_2076,&g_1397,&g_2076,&g_2076,&g_2076},{&g_2076,&g_2076,(void*)0,&g_2076,&g_1397,&g_2076},{&g_2076,&g_1397,&g_2076,&g_1397,&g_1397,(void*)0},{&g_2076,(void*)0,&g_1397,&g_2076,(void*)0,&g_2076}},{{&g_2076,&g_1397,&g_2076,&g_2076,&g_2076,&g_1397},{&g_2076,&g_2076,&g_2076,&g_1397,&g_1397,(void*)0},{&g_2076,&g_2076,&g_2076,&g_2076,&g_2076,&g_2076},{&g_2076,&g_2076,(void*)0,&g_2076,&g_2076,&g_1397},{&g_2076,&g_1397,&g_2076,&g_1397,&g_2076,&g_2076}},{{&g_1397,&g_1397,&g_2076,&g_2076,&g_1397,&g_2076},{&g_2076,&g_2076,&g_1397,&g_2076,&g_2076,&g_2076},{&g_1397,(void*)0,&g_1397,&g_2076,(void*)0,(void*)0},{&g_1397,&g_2076,&g_2076,&g_2076,&g_2076,&g_1397},{&g_2076,&g_2076,&g_1397,&g_2076,&g_2076,&g_2076}},{{&g_1397,&g_2076,&g_2076,&g_2076,(void*)0,&g_1397},{&g_1397,&g_1397,&g_2076,&g_2076,&g_1397,&g_1397},{&g_2076,&g_2076,(void*)0,&g_2076,&g_2076,&g_2076},{&g_1397,(void*)0,&g_1397,&g_2076,&g_2076,&g_1397},{&g_1397,&g_1397,&g_2076,&g_2076,&g_1397,&g_2076}},{{&g_2076,&g_2076,&g_1397,&g_2076,&g_2076,&g_2076},{&g_1397,(void*)0,&g_1397,&g_2076,(void*)0,(void*)0},{&g_1397,&g_2076,&g_2076,&g_2076,&g_2076,&g_1397},{&g_2076,&g_2076,&g_1397,&g_2076,&g_2076,&g_2076},{&g_1397,&g_2076,&g_2076,&g_2076,(void*)0,&g_1397}}};
        int16_t *l_3192 = &g_526;
        int16_t l_3205[2];
        uint32_t l_3275[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int16_t l_3291[4];
        int32_t *l_3371[4][10][2] = {{{&l_3143,&l_43},{&g_3264[2],&g_3264[3]},{&l_43,(void*)0},{&g_3264[3],&l_3143},{&g_3264[3],&l_3143},{&g_3264[3],(void*)0},{&l_43,&g_3264[3]},{&g_3264[2],&l_43},{&l_3143,&g_3264[3]},{&g_3264[3],&g_73}},{{&g_3264[2],&l_3143},{&g_73,(void*)0},{&l_3165,&l_3165},{&g_3264[3],&g_3264[3]},{&l_3143,(void*)0},{&g_414[0][0][1],&l_3143},{&g_3264[2],&g_414[0][0][1]},{&l_3143,&g_3264[3]},{&l_3143,&g_414[0][0][1]},{&g_3264[2],&l_3143}},{{&g_414[0][0][1],(void*)0},{&l_3143,&g_3264[3]},{&g_3264[3],&l_3165},{&l_3165,(void*)0},{&g_73,&l_3143},{&g_3264[2],&g_73},{&g_3264[3],&g_3264[3]},{&l_3143,&l_43},{&g_3264[2],&g_3264[3]},{&l_43,(void*)0}},{{&g_3264[3],&l_3143},{&g_3264[3],&l_3143},{&g_3264[3],(void*)0},{&l_43,&g_3264[3]},{&g_3264[2],&l_43},{&l_3143,&g_3264[3]},{&g_3264[3],&g_73},{&g_3264[2],&l_3143},{&g_73,(void*)0},{&l_3165,&l_3165}}};
        int64_t *l_3398[7][5][7] = {{{&g_1229[4],&g_1229[6],&g_2780,&g_225,&g_2780,(void*)0,(void*)0},{&g_225,&g_1229[5],&g_1229[5],&g_1229[5],&g_225,&g_225,(void*)0},{(void*)0,&g_1229[2],&g_1229[4],&g_2780,(void*)0,&g_1229[1],&g_2780},{&g_225,&g_1229[5],&g_225,&g_225,&g_1229[4],&g_1229[5],&g_1229[5]},{(void*)0,&g_2780,&g_1229[8],&g_2780,(void*)0,&g_1229[4],&g_2780}},{{&g_1229[4],&g_225,&g_225,&g_1229[5],&g_225,&g_1229[5],(void*)0},{(void*)0,&g_2780,&g_1229[4],&g_1229[2],(void*)0,&g_1229[1],&g_1229[1]},{&g_1229[4],&g_1229[5],&g_1229[4],&g_1229[5],&g_1229[4],&g_2780,(void*)0},{(void*)0,&g_1229[2],&g_1229[4],&g_2780,(void*)0,&g_1229[1],&g_2780},{&g_225,&g_1229[5],&g_225,&g_225,&g_1229[4],&g_1229[5],&g_1229[5]}},{{(void*)0,&g_2780,&g_1229[8],&g_2780,(void*)0,&g_1229[4],&g_2780},{&g_1229[4],&g_225,&g_225,&g_1229[5],&g_225,&g_1229[5],(void*)0},{(void*)0,&g_2780,&g_1229[4],&g_1229[2],(void*)0,&g_1229[1],&g_1229[1]},{&g_1229[4],&g_1229[5],&g_1229[4],&g_1229[5],&g_1229[4],&g_2780,(void*)0},{(void*)0,&g_1229[2],&g_1229[4],&g_2780,(void*)0,&g_1229[1],&g_2780}},{{&g_225,&g_1229[5],&g_225,&g_225,&g_1229[4],&g_1229[5],&g_1229[5]},{(void*)0,&g_2780,&g_1229[8],&g_2780,(void*)0,&g_1229[4],&g_2780},{&g_1229[4],&g_225,&g_225,&g_1229[5],&g_225,&g_1229[5],(void*)0},{(void*)0,&g_2780,&g_1229[4],&g_1229[2],(void*)0,&g_1229[1],&g_1229[1]},{&g_1229[4],&g_1229[5],&g_1229[4],&g_1229[5],&g_1229[4],&g_2780,(void*)0}},{{(void*)0,&g_1229[2],&g_1229[4],&g_2780,(void*)0,&g_1229[1],&g_2780},{&g_225,&g_1229[5],&g_225,&g_225,&g_1229[4],&g_1229[5],&g_1229[5]},{(void*)0,&g_2780,&g_1229[8],&g_2780,(void*)0,&g_1229[4],&g_2780},{&g_1229[4],&g_225,&g_225,&g_1229[5],&g_225,&g_1229[5],(void*)0},{(void*)0,&g_2780,&g_1229[4],&g_1229[2],(void*)0,&g_1229[1],&g_1229[1]}},{{&g_1229[4],&g_1229[5],&g_1229[4],&g_1229[5],&g_1229[4],&g_2780,(void*)0},{(void*)0,&g_1229[2],&g_1229[4],&g_2780,(void*)0,&g_1229[1],&g_2780},{&g_225,&g_1229[5],&g_225,&g_225,&g_1229[4],&g_1229[5],&g_1229[5]},{(void*)0,&g_2780,&g_1229[8],&g_2780,(void*)0,&g_1229[4],&g_2780},{&g_1229[4],&g_225,&g_1229[5],&g_2780,&g_2780,&g_1229[4],&g_225}},{{&g_1229[4],&g_1229[5],(void*)0,&g_2780,&g_1229[1],&g_1229[8],&g_1229[8]},{&g_1229[5],&g_2780,&g_1229[5],&g_2780,&g_1229[5],(void*)0,&g_225},{&g_1229[1],&g_2780,(void*)0,&g_1229[5],&g_1229[4],&g_1229[8],&g_1229[4]},{&g_2780,&g_2780,&g_1229[5],&g_225,&g_1229[5],&g_1229[4],&g_1229[4]},{&g_1229[1],&g_1229[5],&g_1229[5],&g_1229[5],&g_1229[1],(void*)0,&g_1229[4]}}};
        uint8_t ***l_3414[10] = {&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4],&g_2331[4]};
        uint32_t l_3436[3];
        uint64_t ***l_3536 = &g_236;
        uint32_t l_3551[6];
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_3205[i] = 0x785FL;
        for (i = 0; i < 4; i++)
            l_3291[i] = 1L;
        for (i = 0; i < 3; i++)
            l_3436[i] = 0xD1EFE268L;
        for (i = 0; i < 6; i++)
            l_3551[i] = 0UL;
        (*g_3145) |= l_3144;
lbl_3370:
        (*g_3145) |= 1L;
        for (l_3144 = 0; (l_3144 == 51); l_3144++)
        { /* block id: 1293 */
            uint32_t l_3172 = 0UL;
            int16_t *l_3181 = &g_526;
            uint64_t l_3185 = 18446744073709551608UL;
            int32_t **l_3186 = &g_186;
            (*l_3186) = func_100((safe_add_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s(((safe_sub_func_int8_t_s_s((safe_mod_func_uint64_t_u_u(((((*g_1589) , (safe_div_func_uint64_t_u_u(((safe_mod_func_uint64_t_u_u(0x362264D45092A160LL, (safe_sub_func_uint8_t_u_u(l_3164[0], l_3165)))) || ((((((safe_mul_func_int8_t_s_s((((safe_mul_func_int8_t_s_s((((safe_mod_func_uint32_t_u_u((l_3172 , (0xD8DE65283462E357LL == (safe_div_func_uint16_t_u_u(l_3164[1], (l_3165 &= (safe_sub_func_int32_t_s_s(0L, (safe_div_func_int16_t_s_s(((*l_3181) = ((safe_div_func_int32_t_s_s(((((l_3164[0] & 0x0DL) | 1UL) | p_30) >= (***g_522)), p_31)) || (-1L))), (*g_1098)))))))))), l_3144)) | l_3143) < 0x8F3DL), p_30)) , l_3182) == l_3183[2][4][4]), 0x9BL)) <= 6UL) & 0xCDFC90157B4F2499LL) | p_31) & p_30) , l_3164[0])), p_31))) >= l_3164[0]) || p_30), 0x125F1CE4AAB46CA1LL)), 0x15L)) <= 0xB966C0ADL), l_3143)) , l_3164[4]), l_3164[3])) , l_3184), l_3185)), l_3172);
        }
        if ((0x37D2005FL | (65535UL != (safe_sub_func_uint8_t_u_u(((*g_2332)++), (((*l_3192) |= l_3191) == (((***g_1051) = 0UL) , (l_43 = (safe_rshift_func_int8_t_s_u((safe_sub_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(l_3143, 65526UL)), (safe_rshift_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u((((p_30 ^ (l_3205[1] && l_3164[0])) , (void*)0) != l_3206), l_3143)) > 250UL), p_31)))), 0x40315ADEL)), l_3144))))))))))
        { /* block id: 1302 */
            uint32_t l_3225[9] = {0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L,0x419050F7L};
            uint16_t l_3228 = 6UL;
            int32_t *l_3266[5];
            const uint8_t *l_3308 = &g_757[1];
            uint16_t **l_3315[6][5] = {{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092},{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092},{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092},{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092},{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092},{&g_1102[1],&g_1095,&g_1102[1],&g_1092,&g_1092}};
            int32_t l_3317 = 0xACD4CEF0L;
            int i, j;
            for (i = 0; i < 5; i++)
                l_3266[i] = (void*)0;
            for (g_814 = 0; (g_814 > 19); ++g_814)
            { /* block id: 1305 */
                int16_t l_3229 = 0x3054L;
                int32_t *l_3232 = &g_414[0][3][1];
                int16_t l_3292[8] = {0L,(-10L),0L,0L,(-10L),0L,0L,(-10L)};
                int i;
                if ((((((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((((*g_524) &= (safe_lshift_func_int16_t_s_s(((safe_unary_minus_func_uint8_t_u(((l_3164[2] > (safe_sub_func_uint32_t_u_u(4294967288UL, ((safe_rshift_func_uint16_t_u_u(65535UL, 13)) , (0xA7357F52L < (((safe_mod_func_uint16_t_u_u(0x3CB3L, 0xCBD0L)) != (safe_add_func_uint16_t_u_u((((l_3224 >= (((l_3225[3] , ((*g_1089) = ((safe_mul_func_uint8_t_u_u(0xB8L, p_29)) < l_3228))) , p_31) , l_3229)) > (*g_2332)) & 0x2F6EL), l_3224))) , 0xA84256A8L)))))) , p_31))) == l_3229), 10))) ^ 18446744073709551615UL), (*g_1088))), 4)) != 1UL) , l_3229) <= 0xF6L) == 18446744073709551615UL))
                { /* block id: 1308 */
                    int32_t l_3237 = 0xE585BFA9L;
                    uint32_t *l_3238 = &g_356;
                    uint16_t ***l_3241 = &g_1047;
                    uint16_t ****l_3242[7][9] = {{&l_3241,(void*)0,(void*)0,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,(void*)0,(void*)0,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,(void*)0,(void*)0,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241},{&l_3241,(void*)0,(void*)0,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241,&l_3241}};
                    uint32_t l_3247 = 0UL;
                    int i, j;
                    for (g_1405 = 0; (g_1405 == 12); g_1405 = safe_add_func_uint16_t_u_u(g_1405, 6))
                    { /* block id: 1311 */
                        return l_3232;
                    }
                    if (((0x92L > (((((safe_sub_func_uint16_t_u_u(p_29, 6L)) , (safe_div_func_int32_t_s_s((l_3144 || (l_3225[3] , 1UL)), (++(*l_3238))))) <= (((((*l_3206) = (void*)0) != (l_3243 = ((*g_2303) = l_3241))) == (~(((safe_mul_func_uint8_t_u_u(p_29, l_3247)) == p_31) ^ 0UL))) && 0xE3EBL)) , p_31) , p_29)) || p_30))
                    { /* block id: 1318 */
                        uint32_t l_3265 = 18446744073709551614UL;
                        (*l_3232) = (((((void*)0 == &l_3182) != (l_3225[6] < (~(p_29 != (safe_div_func_int64_t_s_s(p_31, p_30)))))) & (safe_sub_func_uint8_t_u_u(((~(safe_div_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u(p_29, (((safe_div_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((((g_551 = g_3264[3]) || (((((p_30 >= l_3265) , (*l_3232)) == l_3265) && p_30) >= 0xAEE60818L)) <= p_30), l_3225[3])), p_29)) == (*l_3232)) , p_30))), l_3225[3])), p_31))) ^ p_31), (*l_3232)))) || l_3143);
                        if (p_29)
                            continue;
                    }
                    else
                    { /* block id: 1322 */
                        return l_3266[2];
                    }
                }
                else
                { /* block id: 1325 */
                    int8_t l_3286 = 1L;
                    (*l_3232) = ((safe_rshift_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((safe_add_func_int64_t_s_s((safe_div_func_int32_t_s_s(0L, l_3275[4])), (safe_div_func_int16_t_s_s(((((safe_sub_func_int64_t_s_s(((((safe_mul_func_uint16_t_u_u((((void*)0 != p_28) | 0UL), (safe_lshift_func_uint8_t_u_s(((0x53L < (safe_add_func_int8_t_s_s(l_3286, (-6L)))) & ((safe_lshift_func_uint16_t_u_s((((safe_add_func_uint16_t_u_u(((((l_3144 , 0xEFECL) >= 1L) , p_31) , l_3291[0]), p_31)) || (-1L)) && l_43), 2)) ^ l_3292[7])), p_30)))) < l_3165) != p_30) >= 0x90789506BDA3BBF6LL), l_3164[0])) ^ (*g_3145)) , (-6L)) & l_3293[1][1][2]), p_29)))) , (**g_931)) ^ p_30), (*l_3232))), 0)) >= p_29);
                    (*g_3294) = (*g_1952);
                    for (g_1771 = 0; (g_1771 <= 7); g_1771 += 1)
                    { /* block id: 1330 */
                        uint64_t l_3295 = 0x02254C4107E4B38FLL;
                        (*g_2845) = (*g_3140);
                        ++l_3295;
                        if (l_3165)
                            break;
                        (*l_3232) = l_3295;
                    }
                }
                (*g_3318) = ((0L ^ ((((((safe_unary_minus_func_int32_t_s((p_29 , (+(safe_mul_func_uint16_t_u_u((0xEDE978E3728D9FEDLL > (safe_mod_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s((safe_sub_func_int32_t_s_s((l_3308 != ((*g_1589) , &l_3164[3])), ((safe_sub_func_int8_t_s_s((((safe_div_func_int32_t_s_s((safe_rshift_func_uint16_t_u_s(0x8E68L, (l_3315[3][0] != (*g_1086)))), l_3293[2][2][7])) , l_3316) < p_29), 0x95L)) == p_30))), 0xA686D005L)) > 9L), (*l_3232)))), p_29)))))) && p_31) && p_31) >= l_3317) , p_29) >= 0x2FL)) , l_3232);
                (*g_186) = l_3224;
            }
        }
        else
        { /* block id: 1340 */
            uint16_t *l_3319 = &g_843;
            int32_t l_3332 = (-7L);
            const uint16_t * const **l_3388 = &g_1015;
            const uint16_t * const ***l_3387 = &l_3388;
            uint64_t l_3419 = 1UL;
            int32_t l_3464 = 1L;
            uint8_t *l_3469 = &g_413;
            int8_t ***l_3491 = &g_981;
            int32_t l_3496 = 5L;
            int32_t l_3497[8] = {0x221A68CDL,0xA786F756L,0xA786F756L,0x221A68CDL,0xA786F756L,0xA786F756L,0x221A68CDL,0xA786F756L};
            int64_t *l_3504 = &g_1229[5];
            int i;
            for (g_1397 = 0; (g_1397 <= 0); g_1397 += 1)
            { /* block id: 1343 */
                int32_t l_3320 = 0x54C164FAL;
                uint8_t *l_3326 = &g_413;
                uint16_t **l_3360 = &g_1095;
                uint32_t l_3367 = 0xED4C5B05L;
                uint16_t ****l_3378 = &g_1046;
                int64_t **l_3411 = &g_524;
                int64_t **l_3413 = &g_524;
                int32_t **l_3438[5] = {&l_3334[3],&l_3334[3],&l_3334[3],&l_3334[3],&l_3334[3]};
                int32_t ***l_3437 = &l_3438[1];
                int64_t l_3445 = 0xB6F89BC2E4F9AF50LL;
                uint32_t ***l_3452[8] = {(void*)0,&g_1864[2],(void*)0,(void*)0,&g_1864[2],(void*)0,(void*)0,&g_1864[2]};
                int64_t l_3492 = (-4L);
                int32_t *l_3502 = &g_414[0][7][2];
                int i;
                for (g_2971 = 0; (g_2971 <= 0); g_2971 += 1)
                { /* block id: 1346 */
                    uint8_t **l_3327 = (void*)0;
                    uint16_t *l_3330[1];
                    int32_t l_3331 = 0x16E08C1EL;
                    const int32_t **l_3335 = &g_2642;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_3330[i] = (void*)0;
                    l_3320 ^= (l_3319 != l_3319);
                    (*l_3335) = (*g_2641);
                }
                for (g_551 = 0; (g_551 <= 0); g_551 += 1)
                { /* block id: 1356 */
                    int8_t l_3345[6][5][8] = {{{0x59L,(-1L),0x93L,0x93L,(-1L),0x59L,0xC7L,0x80L},{0xF3L,(-5L),(-1L),1L,1L,0x01L,(-5L),1L},{0x6CL,0x15L,0x72L,1L,0x59L,(-1L),1L,0x72L},{4L,0x59L,0x78L,(-1L),0x78L,0x59L,4L,0xF3L},{1L,0xF3L,1L,(-1L),0x43L,0x93L,1L,0x78L}},{{0x15L,0x42L,0x8EL,0x72L,0x43L,0x15L,0x8AL,(-1L)},{1L,(-1L),(-1L),0x78L,0x78L,(-1L),(-1L),1L},{4L,1L,0L,1L,0x59L,6L,0x78L,0L},{0x6CL,0x59L,0xF3L,0x8EL,1L,6L,4L,0x15L},{0x80L,1L,0x15L,(-1L),0x8AL,(-1L),0x15L,1L}},{{0x15L,(-1L),0xC7L,0L,(-5L),0x15L,0x42L,0x8EL},{0x01L,0x42L,(-1L),0xF3L,0x15L,0x93L,0x42L,1L},{(-1L),0xF3L,0xC7L,0x15L,0x59L,0x59L,0x15L,0xC7L},{0x59L,0x59L,0x15L,0xC7L,0xF3L,(-1L),4L,1L},{0x93L,0x15L,0xF3L,(-1L),0x42L,0x01L,0x78L,1L}},{{0x15L,(-5L),0L,0xC7L,(-1L),0x15L,(-1L),0xC7L},{(-1L),0x8AL,(-1L),0x15L,1L,0x80L,0x8AL,1L},{6L,1L,0x8EL,0xF3L,0x59L,0x6CL,1L,0x8EL},{6L,0x59L,1L,0L,1L,4L,4L,1L},{(-1L),0x78L,0x78L,(-1L),(-1L),1L,1L,0x15L}},{{0x15L,0x43L,0x72L,0x8EL,0x42L,0x15L,(-5L),0L},{0x93L,0x43L,(-1L),1L,0xF3L,1L,0x43L,1L},{0x59L,0x78L,(-1L),0x78L,0x59L,4L,0xF3L,(-1L)},{(-1L),0x59L,1L,0x72L,0x15L,0x6CL,4L,0x78L},{0x01L,1L,1L,(-1L),(-5L),0x80L,0xF3L,0x80L}},{{0x01L,0x59L,0x8AL,0x8AL,0x59L,0x01L,6L,(-5L)},{0x72L,(-1L),0x8EL,1L,0x93L,0xC7L,(-1L),0L},{1L,0x01L,(-5L),1L,0x15L,0x78L,0x93L,(-5L)},{1L,0x15L,(-1L),0x8AL,(-1L),0x15L,1L,0x80L},{0L,0x80L,0x93L,0x8EL,6L,(-1L),1L,(-1L)}}};
                    int32_t l_3368[8] = {5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L)};
                    int32_t l_3369 = 0L;
                    uint16_t ****l_3377 = (void*)0;
                    int i, j, k;
                    l_3369 ^= (+((((**g_1588) = (safe_mul_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(((*l_3326) = (safe_sub_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u((l_3345[2][0][1] = p_31), ((l_3320 == (((safe_rshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_u((safe_lshift_func_int16_t_s_u(((safe_add_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((((safe_sub_func_int64_t_s_s((l_3320 , ((safe_lshift_func_int16_t_s_u((((***g_1046) ^= (l_3360 == (void*)0)) , ((safe_mod_func_int16_t_s_s(((0xC0C5L >= (((*g_1100) ^= p_31) , (((l_3332 == ((*l_3192) = (safe_lshift_func_int8_t_s_u(((0xEF58B421B77C21E2LL == l_3320) <= l_3320), 3)))) | 9L) <= p_31))) | 1UL), p_31)) ^ 1UL)), p_29)) | l_3367)), p_29)) <= 255UL) != l_3368[2]) <= p_29), l_3368[2])), (-7L))) <= l_3368[0]), 15)), 10)), l_3368[5])) < l_3332) || l_3332)) ^ p_31))) , (*g_1092)), 0UL))), 251UL)) , l_3332), l_3367))) , 18446744073709551610UL) && l_3332));
                    if (g_11)
                        goto lbl_3370;
                    l_3320 &= ((void*)0 != l_3192);
                    if (l_3369)
                    { /* block id: 1366 */
                        l_3368[2] &= (p_31 = l_3367);
                        if (l_3205[0])
                            continue;
                        if (l_3368[2])
                            break;
                    }
                    else
                    { /* block id: 1371 */
                        int32_t *l_3376 = &l_3143;
                        if (p_29)
                            break;
                        (*g_3372) = l_3371[1][3][0];
                        p_31 ^= (safe_unary_minus_func_int32_t_s((((((safe_lshift_func_int16_t_s_s(((void*)0 != l_3376), 13)) >= (0x95A0L > (l_3377 != l_3378))) > ((safe_rshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((p_30 > (p_29 == 0x32EEAE8AB70507AFLL)), (safe_lshift_func_uint16_t_u_s(((*g_1100) = (p_30 || (*l_3376))), 10)))), p_30)) , p_30)) , l_3367) ^ 0UL)));
                    }
                }
                for (g_125 = 0; (g_125 <= 0); g_125 += 1)
                { /* block id: 1380 */
                    uint16_t ****l_3386 = &g_1051;
                    int32_t l_3400 = 5L;
                    int32_t l_3415 = 0x171595C2L;
                    int32_t l_3416 = 1L;
                    uint8_t l_3422 = 0x12L;
                    uint16_t **** const *l_3425 = &l_3206;
                    uint16_t **** const **l_3424 = &l_3425;
                    uint16_t ******l_3426 = (void*)0;
                    int32_t *l_3431 = &g_414[0][8][1];
                    for (g_73 = 0; (g_73 <= 0); g_73 += 1)
                    { /* block id: 1383 */
                        int32_t *l_3385 = &g_11;
                        return l_3385;
                    }
                    if ((l_3386 != l_3387))
                    { /* block id: 1386 */
                        int64_t l_3389 = 9L;
                        int32_t l_3390 = 0L;
                        uint16_t l_3391 = 65532UL;
                        int64_t *l_3399 = (void*)0;
                        int64_t ***l_3412 = &l_3411;
                        --l_3391;
                        l_3332 |= 0xF732AFD8L;
                        l_3416 &= (((**g_523) , 0xE7L) ^ ((safe_sub_func_uint64_t_u_u((((*g_1092)++) && ((l_3399 = l_3398[6][2][2]) != (((l_3400 , (((safe_rshift_func_int16_t_s_s((safe_mod_func_int64_t_s_s((((*g_1099) |= 65533UL) == (safe_mul_func_uint16_t_u_u(p_30, (((((((safe_rshift_func_int8_t_s_u((l_3391 < ((((safe_sub_func_int8_t_s_s(l_3332, (((((*l_3412) = l_3411) == l_3413) , &g_523) != (void*)0))) | (*g_2332)) , &g_2331[3]) == l_3414[5])), l_3415)) >= p_30) || 1L) , &g_2318[0]) != &g_2383) , p_29) || l_3332)))), p_31)), 1)) , p_28) != (void*)0)) != 1UL) , (*g_451)))), (-4L))) && 0UL));
                    }
                    else
                    { /* block id: 1394 */
                        uint16_t *******l_3427 = &l_3426;
                        int32_t **l_3430 = &l_3371[1][3][0];
                        (*l_3430) = (((((safe_add_func_int32_t_s_s(l_3419, ((safe_lshift_func_uint16_t_u_u((((((18446744073709551615UL > ((****g_614) |= ((l_3422 <= (~(l_3424 != ((*l_3427) = (l_3419 , l_3426))))) | p_29))) || (p_31 , ((void*)0 == l_3428))) < 0x4FL) , p_31) ^ (*g_2332)), 12)) , l_3419))) < 0x0F1374B2L) == (**g_523)) < 7UL) , &p_31);
                        return l_3431;
                    }
                }
                if ((safe_lshift_func_uint16_t_u_s(((*g_237) != (((l_3436[0] >= ((l_3437 == &g_1597) != ((safe_rshift_func_int8_t_s_s(((safe_sub_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((p_29 > ((l_3445 && (((safe_lshift_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u(1L, 13)) == ((void*)0 != l_3450)), p_30)) , l_3371[1][3][0]) != (**g_1863))) <= 18446744073709551611UL)), p_30)), p_29)) , l_3419), p_29)) > p_31))) , (void*)0) != l_3452[7])), 2)))
                { /* block id: 1401 */
                    uint64_t l_3473 = 6UL;
                    int8_t *l_3477 = &g_2076;
                    int64_t **** const l_3480 = &g_522;
                    uint8_t **l_3493 = (void*)0;
                    int32_t l_3494 = 1L;
                    int32_t l_3495 = 1L;
                    int32_t *l_3501[4][4][8] = {{{&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6]},{&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3],(void*)0},{&g_3264[3],&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3]},{&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3]}},{{&g_3264[3],&g_3264[3],(void*)0,(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],(void*)0},{&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6]},{&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3],(void*)0},{&g_3264[3],&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3]}},{{&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3]},{&g_3264[3],&g_3264[3],(void*)0,(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],(void*)0},{&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6]},{&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3],(void*)0}},{{&g_3264[3],&g_3264[3],&g_3264[3],(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],&g_3264[3]},{&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3]},{&g_3264[3],&g_3264[3],(void*)0,(void*)0,&g_3264[3],&g_3264[3],&g_3264[3],(void*)0},{&g_3264[6],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[3],&g_3264[6],&g_3264[3],&g_3264[6]}}};
                    int i, j, k;
                    (**l_3437) = func_103((1UL & ((*l_3469) = (((+(((safe_sub_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(((*g_2332)--), ((safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(l_3464, (safe_mul_func_uint16_t_u_u(((l_3332 | ((safe_add_func_int64_t_s_s((l_3469 == l_3469), ((safe_sub_func_uint64_t_u_u((((!(-1L)) | l_3473) , ((((!((((((safe_rshift_func_int8_t_s_s((((*l_3477) = l_3332) <= ((safe_add_func_uint64_t_u_u((g_1917 = ((**g_236) = ((1L ^ 0x43FD749CL) & 1UL))), (*g_932))) ^ 0xD812A838L)), p_31)) , p_31) == (*g_932)) && (*g_932)) == p_31) > p_30)) , &p_28) != &l_3334[3]) & 1L)), 0xF6E0C07B05A806EBLL)) , 3L))) < l_3419)) | l_3419), 0x4512L)))), p_30)) | 0L))), (***l_3437))) && l_3464) | p_31)) | (*g_932)) , p_30))), l_3419);
                    if ((((void*)0 != l_3480) == (((safe_mod_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(((void*)0 == (*g_1863)), p_29)), (safe_sub_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((((((safe_div_func_uint32_t_u_u((p_29 || l_3332), (((void*)0 == l_3491) , l_3492))) , l_3493) == (void*)0) , l_3332) , p_29), p_29)) & p_31), p_31)))) & l_3419) & p_31)))
                    { /* block id: 1408 */
                        uint32_t l_3498 = 0x176D296EL;
                        l_3498++;
                        return l_3502;
                    }
                    else
                    { /* block id: 1411 */
                        const uint32_t l_3505 = 1UL;
                        g_414[0][0][1] &= (((**g_1998) >= p_31) | (((*l_3477) |= (safe_unary_minus_func_uint8_t_u((((**g_522) != l_3504) & l_3505)))) > p_29));
                        (*l_3502) = (safe_lshift_func_int8_t_s_s(p_30, (p_29 != ((safe_lshift_func_uint8_t_u_s(((((((safe_mul_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((safe_mul_func_int32_t_s_s((((****l_3206) &= (p_29 < 65532UL)) | l_3332), ((((-2L) <= p_29) || ((((safe_mod_func_uint16_t_u_u(p_31, (safe_rshift_func_int16_t_s_u(p_29, p_31)))) && l_3419) != 0x2A8FE7F1L) & 18446744073709551615UL)) == 0xC0L))), l_3505)), 6)) , 1UL), 0x923FL)) | 0x6D3CF3C3L) == p_31) ^ 0xABDF8889CA5A6111LL) , l_3505) , l_3505), p_30)) , p_29))));
                    }
                }
                else
                { /* block id: 1417 */
                    int32_t l_3528 = 0xCA850F2AL;
                    int32_t l_3542 = 0x881AE77AL;
                    int32_t l_3543 = 4L;
                    int32_t l_3547 = 0x93B82677L;
                    int32_t l_3550 = 0xA4BB276BL;
                    p_31 &= (-5L);
                    (**l_3437) = func_100(((safe_add_func_int8_t_s_s(p_30, (l_3497[1] = (safe_mod_func_int32_t_s_s(((((~(p_30 && ((!l_3528) < (g_2034[2][5] = (l_3496 ^ (safe_add_func_uint8_t_u_u((7L & (safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_s((((*g_867) , l_3535) != &g_3072), 0)), 0))), (p_31 != p_29)))))))) , (void*)0) != l_3536) , 5L), p_31))))) >= (**g_1998)), p_29);
                    for (l_3367 = 0; (l_3367 <= 0); l_3367 += 1)
                    { /* block id: 1424 */
                        uint32_t *l_3539 = &l_3293[0][2][4];
                        int32_t l_3544 = (-3L);
                        int32_t l_3545 = 0x3360F872L;
                        int32_t l_3546 = 5L;
                        int32_t l_3548[8][1] = {{(-9L)},{0x7633F673L},{(-9L)},{0x7633F673L},{(-9L)},{0x7633F673L},{(-9L)},{0x7633F673L}};
                        int i, j;
                        (*l_3502) |= (safe_add_func_int16_t_s_s(p_30, ((++(*l_3539)) ^ 5UL)));
                        l_3551[0]--;
                    }
                }
            }
        }
    }
    else
    { /* block id: 1432 */
        int8_t l_3566 = 1L;
        const int8_t *l_3598 = &g_2076;
        const int8_t **l_3597 = &l_3598;
        for (l_3316 = 0; (l_3316 <= 2); l_3316 += 1)
        { /* block id: 1435 */
            uint16_t l_3556 = 65528UL;
            uint64_t l_3563 = 0xFEED5AAC0706179ELL;
            int8_t * const *l_3571 = &l_3182;
            int8_t * const **l_3570 = &l_3571;
            int8_t * const ***l_3569 = &l_3570;
            int8_t * const ****l_3572 = &l_3569;
            int32_t l_3584 = 0x36B727FBL;
            l_3584 = ((((safe_add_func_uint64_t_u_u((l_3556 , ((l_3556 ^ (safe_mod_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((l_3563 < ((safe_lshift_func_uint16_t_u_u(l_3566, 5)) <= ((l_3556 == l_3566) || (p_29 < ((g_3573[2][2][3] = ((*l_3572) = l_3569)) != (((safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((l_3582 != &g_1589), 1UL)), l_3583)) , 0x62903CCCL) , &g_3574[3][0])))))), 11)), (*g_2332)))) & l_3563)), 0xB0295C8A8435DC70LL)) , (void*)0) != &g_2302[0]) | 1L);
            for (g_1405 = 0; (g_1405 <= 0); g_1405 += 1)
            { /* block id: 1441 */
                uint32_t l_3605 = 4294967291UL;
                for (g_125 = 0; (g_125 <= 8); g_125 += 1)
                { /* block id: 1444 */
                    int64_t l_3606 = (-7L);
                    for (g_2177 = 0; (g_2177 <= 8); g_2177 += 1)
                    { /* block id: 1447 */
                        int i, j, k;
                        g_3264[7] &= (safe_rshift_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u(((g_414[g_1405][g_2177][l_3316] == g_414[g_1405][g_2177][l_3316]) & 8UL), p_30)) != ((safe_sub_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u((p_30 | ((safe_sub_func_int64_t_s_s(((((l_3597 != (**l_3569)) <= (-1L)) || ((safe_add_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((void*)0 == &l_3451), l_3566)), (**g_1998))), 8L)) > 0xF7L)) | l_3605), l_3606)) || p_31)), p_29)), (-1L))) ^ l_3566)) & 0xBA5A5F6AL), 0));
                        p_31 = l_3566;
                        return (*g_3294);
                    }
                }
                return (*g_3318);
            }
        }
    }
    return l_3607;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const uint16_t  func_46(int32_t  p_47, const int32_t * p_48)
{ /* block id: 13 */
    uint32_t l_53 = 0xD0D8167EL;
    int32_t l_2007 = 0L;
    int32_t *l_2008 = &g_1337;
    int16_t *l_2024 = &g_526;
    uint8_t *l_2031 = &g_413;
    uint8_t *l_2032 = &g_1405;
    int32_t ** const l_2037 = (void*)0;
    uint32_t **l_2092 = &g_867;
    uint64_t * const * const *l_2094 = (void*)0;
    uint64_t * const * const ** const l_2093 = &l_2094;
    int32_t l_2154 = 0x6E45834EL;
    int32_t l_2155 = 0xCE9D6B10L;
    int32_t l_2157 = (-1L);
    int32_t l_2158 = 0L;
    int32_t l_2161 = 0x3FD8918AL;
    int32_t l_2163 = 0xB1D5FAEEL;
    int32_t l_2167 = 0L;
    int32_t l_2169 = 0L;
    int32_t l_2170 = 0xA732CD0BL;
    int32_t l_2217 = 0x13A4B67EL;
    int32_t l_2404 = (-10L);
    int32_t l_2405 = 0xABC9E16AL;
    int32_t l_2409 = 0xFE8B9D84L;
    int32_t l_2411 = 1L;
    int32_t l_2412 = 0x721812A9L;
    int32_t l_2414 = 1L;
    int32_t l_2415 = 3L;
    int32_t l_2416 = 1L;
    int32_t l_2417 = 0x57FF50AFL;
    int32_t l_2418 = 4L;
    int32_t l_2419 = 7L;
    int32_t l_2420 = 0x7F6366DFL;
    int32_t l_2421[9][2][5] = {{{2L,7L,7L,2L,7L},{(-2L),0x99B91A17L,(-2L),0x99B91A17L,0x99B91A17L}},{{0L,7L,0L,0L,7L},{0x99B91A17L,1L,1L,0x99B91A17L,1L}},{{7L,7L,2L,7L,7L},{1L,0x99B91A17L,1L,1L,0x99B91A17L}},{{7L,0L,0L,7L,0L},{0x99B91A17L,0x99B91A17L,(-2L),0x99B91A17L,0x99B91A17L}},{{0L,7L,0L,0L,7L},{0x99B91A17L,1L,1L,0x99B91A17L,1L}},{{7L,7L,2L,7L,7L},{1L,0x99B91A17L,1L,1L,0x99B91A17L}},{{7L,0L,0L,7L,0L},{0x99B91A17L,0x99B91A17L,(-2L),0x99B91A17L,0x99B91A17L}},{{0L,7L,0L,0L,7L},{0x99B91A17L,1L,1L,0x99B91A17L,1L}},{{7L,7L,2L,7L,7L},{1L,0x99B91A17L,1L,1L,0x99B91A17L}}};
    int8_t l_2423 = 0x50L;
    uint16_t **l_2551 = &g_1091[4];
    uint8_t **l_2621 = &l_2032;
    int16_t l_2665 = 1L;
    int64_t l_2709 = 0x29D56DC0C42D20FELL;
    int64_t ** const *l_2779 = &g_523;
    int64_t ** const **l_2778 = &l_2779;
    uint32_t *l_2809 = (void*)0;
    int8_t ****l_2853 = (void*)0;
    uint64_t l_2869 = 0x5E9866A7898F8666LL;
    uint16_t **** const *l_2927 = &g_2303;
    uint16_t **** const **l_2926 = &l_2927;
    int32_t l_2943[1];
    uint8_t l_2965 = 0UL;
    int8_t l_2967 = 0x5BL;
    int32_t l_2994 = 0x5C5D4467L;
    int32_t l_3000 = 0xE3C41C6AL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2943[i] = 0x5674C8F2L;
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_127 g_1229 g_414 g_936 g_68 g_937 g_575 g_160 g_237 g_1341 g_615 g_236 g_175 g_1550 g_526 g_867 g_932 g_933 g_356 g_524 g_225 g_1762 g_1405 g_1085 g_1086 g_614 g_1022 g_1030 g_1047 g_354 g_1829 g_9 g_1018 g_1014 g_1588 g_1589 g_551 g_319
 * writes: g_127 g_1523 g_414 g_1341 g_160 g_175 g_526 g_186 g_551 g_319 g_356 g_68 g_413 g_522 g_232 g_1397 g_225 g_1863
 */
static uint8_t  func_49(int8_t  p_50)
{ /* block id: 626 */
    int8_t l_1519 = 0x84L;
    int16_t *l_1522 = &g_526;
    int32_t l_1524 = 0L;
    int32_t l_1536 = 1L;
    int64_t **l_1575[4][9][6] = {{{&g_524,(void*)0,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,(void*)0,(void*)0},{&g_524,(void*)0,&g_524,&g_524,&g_524,(void*)0},{&g_524,&g_524,(void*)0,&g_524,&g_524,&g_524},{(void*)0,&g_524,&g_524,&g_524,&g_524,(void*)0},{&g_524,(void*)0,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524}},{{(void*)0,&g_524,&g_524,&g_524,&g_524,(void*)0},{&g_524,&g_524,&g_524,&g_524,(void*)0,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,(void*)0},{&g_524,&g_524,&g_524,&g_524,(void*)0,(void*)0},{&g_524,(void*)0,&g_524,(void*)0,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{(void*)0,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,(void*)0,&g_524,(void*)0,&g_524,&g_524}},{{&g_524,&g_524,(void*)0,&g_524,&g_524,&g_524},{&g_524,(void*)0,(void*)0,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,(void*)0,&g_524,&g_524},{&g_524,&g_524,(void*)0,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{(void*)0,&g_524,&g_524,&g_524,&g_524,(void*)0},{&g_524,(void*)0,&g_524,(void*)0,&g_524,&g_524},{(void*)0,&g_524,&g_524,&g_524,&g_524,&g_524},{(void*)0,&g_524,&g_524,&g_524,&g_524,&g_524}},{{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{(void*)0,(void*)0,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,(void*)0},{&g_524,(void*)0,&g_524,(void*)0,&g_524,(void*)0},{&g_524,&g_524,&g_524,(void*)0,&g_524,&g_524},{&g_524,&g_524,(void*)0,&g_524,(void*)0,&g_524},{&g_524,&g_524,&g_524,&g_524,&g_524,&g_524}}};
    uint32_t * const *l_1613 = &g_867;
    int32_t l_1636 = 0x369BFE9FL;
    int32_t l_1637 = 0x680DEF7CL;
    uint32_t l_1664 = 0x26DCD4C9L;
    int32_t l_1695 = 1L;
    int32_t l_1696 = 0x02310ADCL;
    int32_t l_1698[3][6][2] = {{{0x8A36091BL,0x82458B8CL},{(-1L),0x8A36091BL},{(-1L),(-4L)},{(-4L),0x5AE3A59CL},{(-1L),0x4FF18D6EL},{0x5AE3A59CL,0x4FF18D6EL}},{{(-1L),0x5AE3A59CL},{(-4L),(-4L)},{(-1L),0x8A36091BL},{(-1L),0x82458B8CL},{0x8A36091BL,0x4FF18D6EL},{(-10L),0x8A36091BL}},{{(-4L),(-1L)},{(-4L),0x8A36091BL},{(-10L),0x4FF18D6EL},{0x8A36091BL,0x82458B8CL},{(-1L),0x8A36091BL},{(-1L),(-4L)}}};
    int32_t l_1702 = 1L;
    uint64_t l_1733 = 0x36A59E1D78C3A21ALL;
    int32_t *l_1767 = &l_1524;
    int32_t *l_1768 = &l_1524;
    int32_t *l_1769 = &l_1698[1][2][1];
    int32_t *l_1770[8] = {&l_1536,&l_1536,&l_1536,&l_1536,&l_1536,&l_1536,&l_1536,&l_1536};
    uint32_t l_1772[8][8][4] = {{{0x8988C32BL,9UL,0xE2AE3C5FL,0xB6A6CD54L},{1UL,0xE654A221L,9UL,0xE654A221L},{9UL,0xE654A221L,1UL,0xB6A6CD54L},{0xE2AE3C5FL,9UL,0x8988C32BL,0UL},{0x86B82B02L,0xE84F7577L,1UL,0xA34C2852L},{0x86B82B02L,0xB6A6CD54L,0x8988C32BL,0xA734D1B5L},{0xE2AE3C5FL,0xA34C2852L,1UL,1UL},{9UL,4294967295UL,9UL,1UL}},{{1UL,0xA34C2852L,0xE2AE3C5FL,0xA734D1B5L},{0x8988C32BL,0xB6A6CD54L,1UL,0xE84F7577L},{0x789432B7L,1UL,1UL,0xB6A6CD54L},{9UL,4294967286UL,4294967292UL,0xA34C2852L},{0x8988C32BL,4294967295UL,1UL,4294967295UL},{1UL,4294967295UL,0x8988C32BL,0xA34C2852L},{4294967292UL,4294967286UL,9UL,0xB6A6CD54L},{1UL,1UL,0x789432B7L,0xE84F7577L}},{{1UL,0xA34C2852L,9UL,9UL},{4294967292UL,0xE84F7577L,0x8988C32BL,0xE654A221L},{1UL,0xA734D1B5L,1UL,0xE654A221L},{0x8988C32BL,0xE84F7577L,4294967292UL,9UL},{9UL,0xA34C2852L,1UL,0xE84F7577L},{0x789432B7L,1UL,1UL,0xB6A6CD54L},{9UL,4294967286UL,4294967292UL,0xA34C2852L},{0x8988C32BL,4294967295UL,1UL,4294967295UL}},{{1UL,4294967295UL,0x8988C32BL,0xA34C2852L},{4294967292UL,4294967286UL,9UL,0xB6A6CD54L},{1UL,1UL,0x789432B7L,0xE84F7577L},{1UL,0xA34C2852L,9UL,9UL},{4294967292UL,0xE84F7577L,0x8988C32BL,0xE654A221L},{1UL,0xA734D1B5L,1UL,0xE654A221L},{0x8988C32BL,0xE84F7577L,4294967292UL,9UL},{9UL,0xA34C2852L,1UL,0xE84F7577L}},{{0x789432B7L,1UL,1UL,0xB6A6CD54L},{9UL,4294967286UL,4294967292UL,0xA34C2852L},{0x8988C32BL,4294967295UL,1UL,4294967295UL},{1UL,4294967295UL,0x8988C32BL,0xA34C2852L},{4294967292UL,4294967286UL,9UL,0xB6A6CD54L},{1UL,1UL,0x789432B7L,0xE84F7577L},{1UL,0xA34C2852L,9UL,9UL},{4294967292UL,0xE84F7577L,0x8988C32BL,0xE654A221L}},{{1UL,0xA734D1B5L,1UL,0xE654A221L},{0x8988C32BL,0xE84F7577L,4294967292UL,9UL},{9UL,0xA34C2852L,1UL,0xE84F7577L},{0x789432B7L,1UL,1UL,0xB6A6CD54L},{9UL,4294967286UL,4294967292UL,0xA34C2852L},{0x8988C32BL,4294967295UL,1UL,4294967295UL},{1UL,4294967295UL,0x8988C32BL,0xA34C2852L},{4294967292UL,4294967286UL,9UL,0xB6A6CD54L}},{{1UL,1UL,0x789432B7L,0xE84F7577L},{1UL,0xA34C2852L,9UL,9UL},{4294967292UL,0xE84F7577L,0x8988C32BL,0xE654A221L},{1UL,0xA734D1B5L,1UL,0xE654A221L},{0x8988C32BL,0xE84F7577L,4294967292UL,9UL},{9UL,0xA34C2852L,1UL,0xE84F7577L},{0x789432B7L,1UL,1UL,0xB6A6CD54L},{9UL,4294967286UL,4294967292UL,0xA34C2852L}},{{0x8988C32BL,4294967295UL,1UL,4294967295UL},{0x86B82B02L,0xA734D1B5L,9UL,0xE84F7577L},{4294967288UL,0xA61251E4L,1UL,0xA34C2852L},{0x789432B7L,0xE654A221L,0xE2AE3C5FL,1UL},{0x789432B7L,0xE84F7577L,1UL,4294967286UL},{4294967288UL,1UL,9UL,4294967295UL},{0x86B82B02L,9UL,0x86B82B02L,4294967295UL},{9UL,1UL,4294967288UL,4294967286UL}}};
    int32_t l_1802[5];
    uint16_t l_1810[3][1];
    uint64_t ** const *l_1859 = (void*)0;
    uint8_t *l_1889 = &g_319;
    uint8_t **l_1888 = &l_1889;
    uint64_t l_1914 = 0UL;
    uint32_t ****l_1936 = &g_1863;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_1802[i] = 0x24EE7372L;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_1810[i][j] = 8UL;
    }
lbl_1882:
    for (g_127 = 0; (g_127 <= 2); g_127 += 1)
    { /* block id: 629 */
        uint32_t *l_1525 = &g_68[2][0][0];
        int32_t *l_1526 = &l_1524;
        int32_t l_1530 = 0L;
        int32_t l_1532 = 0x89BA992AL;
        int32_t l_1535 = 1L;
        uint32_t **l_1612 = (void*)0;
        int32_t l_1638 = 0x5197E57DL;
        uint8_t l_1692 = 0xB4L;
        int32_t l_1694 = 0x440557B5L;
        int32_t l_1697[8][1][10] = {{{0xF6738B38L,0x2040722CL,0xB3946A72L,(-7L),0x2040722CL,1L,0x71F0A248L,0x71C75370L,3L,0x897DAE26L}},{{1L,(-7L),3L,0xA759EC6CL,4L,0xB3946A72L,1L,0x71F0A248L,8L,8L}},{{0x49F35EA4L,(-1L),8L,1L,1L,8L,(-1L),0x49F35EA4L,0xDECB097FL,0x71F0A248L}},{{0xF6738B38L,8L,1L,(-7L),(-1L),0x2040722CL,0x49F35EA4L,8L,1L,1L}},{{3L,(-7L),1L,(-1L),(-1L),8L,(-1L),0x49F35EA4L,0xB3946A72L,3L}},{{(-7L),(-7L),8L,0x71F0A248L,0x897DAE26L,(-1L),0x897DAE26L,0x71F0A248L,8L,(-7L)}},{{1L,1L,3L,(-7L),0x71C75370L,0xA759EC6CL,0xC125BB43L,0x71C75370L,0x2040722CL,4L}},{{0x71C75370L,0x897DAE26L,0xB3946A72L,(-7L),(-1L),0xA759EC6CL,1L,0xC125BB43L,8L,(-7L)}}};
        int64_t l_1699 = 5L;
        int8_t l_1700 = (-6L);
        int8_t l_1701 = 0x02L;
        uint32_t l_1703 = 0xFF5B20ABL;
        int64_t ****l_1759 = &g_522;
        int i, j, k;
        l_1519 = g_1229[(g_127 + 4)];
        l_1524 &= (l_1519 , (g_414[0][0][2] |= (safe_sub_func_uint16_t_u_u(((l_1522 = &g_526) != (void*)0), ((g_1523[0] = &g_160) == (void*)0)))));
        for (g_1341 = 0; (g_1341 <= 2); g_1341 += 1)
        { /* block id: 637 */
            int32_t *l_1527 = &g_1337;
            int32_t *l_1528 = &l_1524;
            int32_t *l_1529 = &g_414[0][4][0];
            int32_t *l_1531 = &g_414[0][0][1];
            int32_t *l_1533 = &l_1524;
            int32_t *l_1534[6] = {&g_2,&g_2,&g_2,&g_2,&g_2,&g_2};
            uint16_t l_1537 = 0x7712L;
            int32_t **l_1551 = &l_1528;
            int i, j;
            l_1526 = func_91(l_1525);
            ++l_1537;
            (*l_1528) ^= (((safe_mul_func_uint16_t_u_u(0UL, (safe_rshift_func_int8_t_s_s(g_1229[(g_1341 + 1)], 2)))) || (((safe_sub_func_int64_t_s_s((safe_mod_func_int32_t_s_s((p_50 >= ((safe_add_func_uint32_t_u_u(((p_50 , (***g_615)) <= p_50), ((p_50 & ((*l_1522) ^= (((void*)0 != g_1550[5]) < 0xFFE1L))) != p_50))) > l_1519)), p_50)), 0x30EF96E2BFCFC5C1LL)) , 0x3ECBBA34L) & 0x4511A4A7L)) || p_50);
            (*l_1531) = (((*l_1551) = (g_186 = (void*)0)) == (void*)0);
            for (g_551 = 0; (g_551 <= 2); g_551 += 1)
            { /* block id: 647 */
                int i;
                (*l_1533) = (l_1519 & p_50);
                (*l_1533) = ((void*)0 != &g_757[1]);
            }
        }
        for (g_1341 = 0; (g_1341 <= 2); g_1341 += 1)
        { /* block id: 654 */
            uint8_t *l_1561 = (void*)0;
            int32_t l_1562 = (-4L);
            uint8_t *l_1563 = &g_413;
            uint32_t l_1576 = 0xB8E5A443L;
            int8_t *l_1577 = &l_1519;
            int32_t *l_1587 = (void*)0;
            int32_t **l_1586 = &l_1587;
            const int16_t *l_1607 = &g_526;
            uint32_t l_1642[9] = {0xF845FFC3L,0UL,0xF845FFC3L,0UL,0xF845FFC3L,0UL,0xF845FFC3L,0UL,0xF845FFC3L};
            int32_t l_1650 = 5L;
            int i;
        }
        for (g_319 = 0; (g_319 <= 2); g_319 += 1)
        { /* block id: 689 */
            int32_t *l_1693[2][10][7] = {{{&l_1638,(void*)0,&g_73,&g_73,(void*)0,&l_1638,(void*)0},{&g_73,&g_414[0][2][1],&g_2,&l_1524,&g_414[0][0][1],&l_1524,&g_2},{&g_414[0][8][0],&g_414[0][8][0],&l_1638,&g_73,&l_1638,&g_414[0][8][0],&g_414[0][8][0]},{(void*)0,&g_414[0][2][1],&l_1638,&g_414[0][2][1],(void*)0,&g_11,&g_2},{&l_1524,(void*)0,&l_1524,&l_1638,&l_1638,&l_1524,(void*)0},{&g_2,&l_1536,&l_1638,&g_414[0][0][1],&g_414[0][0][1],&g_414[0][2][1],&g_414[0][0][1]},{&l_1524,&l_1638,&l_1638,&l_1524,(void*)0,&l_1524,&l_1638},{(void*)0,&g_11,&g_2,&g_414[0][0][1],&g_2,&g_11,(void*)0},{&g_414[0][8][0],&l_1638,&g_73,&l_1638,&g_414[0][8][0],&g_414[0][8][0],&l_1638},{&g_73,&l_1536,&g_73,&g_414[0][2][1],&g_2,&g_414[0][0][1],(void*)0}},{{&l_1524,&g_414[0][8][0],(void*)0,(void*)0,&g_414[0][8][0],&l_1524,&g_414[0][8][0]},{&l_1638,&l_1524,&g_73,&g_414[0][0][1],(void*)0,&g_414[0][0][1],&g_73},{&l_1638,&l_1638,&l_1524,(void*)0,&l_1524,&l_1638,&l_1638},{&g_2,&l_1524,&g_414[0][0][1],&l_1524,&g_2,&g_414[0][2][1],&g_73},{&g_73,&g_414[0][8][0],&g_73,&l_1524,&l_1524,&g_73,&g_414[0][8][0]},{&g_73,&g_11,&g_414[0][0][1],&l_1536,(void*)0,&l_1524,(void*)0},{&g_73,&l_1524,&l_1524,&g_73,&g_414[0][8][0],&g_73,&l_1524},{&g_2,&g_414[0][2][1],&g_73,&l_1536,&g_73,&g_414[0][2][1],&g_2},{&l_1638,&l_1524,(void*)0,&l_1524,&l_1638,&l_1638,&l_1524},{&l_1638,&g_11,&l_1638,&l_1524,&g_73,&g_414[0][0][1],(void*)0}}};
            uint32_t l_1707 = 0xFAEDABC2L;
            int32_t **l_1710 = &l_1693[1][5][0];
            uint32_t *l_1727 = (void*)0;
            uint32_t **l_1728 = (void*)0;
            uint32_t *l_1730[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t **l_1729 = &l_1730[0];
            int i, j, k;
            l_1703++;
            l_1707++;
            (*l_1710) = l_1693[1][5][0];
            if ((safe_lshift_func_uint8_t_u_s((g_127 , (safe_lshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((((safe_mod_func_int16_t_s_s((0xC7L || (safe_div_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((p_50 && ((*l_1526) = (safe_lshift_func_uint16_t_u_s(((safe_add_func_int64_t_s_s(((*l_1613) != ((*l_1729) = func_91(func_91(l_1727)))), ((0xF7L >= ((((safe_mul_func_int8_t_s_s(0x00L, 0x82L)) <= (*g_932)) , (void*)0) == &g_1405)) <= p_50))) < p_50), 15)))), p_50)), 6L))), 0xB077L)) >= p_50) || 1L) | l_1733), p_50)), 4))), 5)))
            { /* block id: 695 */
                uint32_t ***l_1751 = &l_1612;
                uint16_t *** const *l_1757 = &g_1046;
                uint16_t *** const **l_1756 = &l_1757;
                const int32_t l_1761 = (-6L);
                if (((*l_1526) = p_50))
                { /* block id: 697 */
                    int32_t l_1758 = 0x3D6E1726L;
                    uint32_t *l_1763[2][3][7] = {{{&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707},{&g_356,&l_1664,(void*)0,&g_356,(void*)0,&l_1664,&g_356},{&g_551,&l_1707,&g_551,&g_551,&l_1707,&g_551,&g_551}},{{&g_356,&g_356,&g_356,&g_356,&g_356,(void*)0,&g_356},{&l_1707,&g_551,&g_551,&l_1707,&g_551,&g_551,&l_1707},{(void*)0,&g_356,(void*)0,&l_1664,&g_356,&l_1664,(void*)0}}};
                    uint16_t l_1764 = 0x7219L;
                    int i, j, k;
                    l_1536 = ((p_50 | 0xB7L) | (safe_lshift_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u(((((safe_unary_minus_func_uint32_t_u(((safe_unary_minus_func_uint32_t_u(p_50)) , (((*l_1526) && (((((safe_rshift_func_int16_t_s_u((((safe_mod_func_uint32_t_u_u((*l_1526), ((*l_1525) = (*g_936)))) , ((safe_rshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u((l_1696 = (+(&l_1612 != l_1751))), (safe_lshift_func_int16_t_s_s(((safe_add_func_uint8_t_u_u(((l_1756 != &g_1085) > 0x2AB26A1735A2FB5FLL), p_50)) == p_50), 3)))), (*l_1526))) , (-5L))) , l_1758), 11)) == l_1637) ^ (*l_1526)) , (-1L)) < 0x39L)) , (*g_936))))) , (void*)0) != l_1759) , p_50), p_50)) > 0x93D9FDB78E6C8FDALL), 6)));
                    l_1536 &= ((p_50 , p_50) != (((g_356 = (l_1758 && (safe_unary_minus_func_int8_t_s((((((*l_1525) = ((((*g_524) & (l_1758 <= (0L < (p_50 < l_1761)))) ^ (l_1761 < (-8L))) | p_50)) , p_50) , g_1762) != 0xF9E7FFB5L))))) && 0x499F4D8CL) || l_1761));
                    return l_1764;
                }
                else
                { /* block id: 705 */
                    return l_1664;
                }
            }
            else
            { /* block id: 708 */
                volatile int32_t *l_1766[6][4] = {{&g_9[0][4],&g_8,&g_8,&g_9[0][4]},{&g_9[0][1],&g_8,&g_8,&g_8},{&g_8,&g_8,&g_8,&g_8},{&g_9[0][1],&g_9[0][1],&g_8,&g_8},{&g_9[0][4],&g_8,&g_9[0][4],&g_8},{&g_9[0][4],&g_8,&g_8,&g_9[0][4]}};
                volatile int32_t **l_1765 = &l_1766[3][3];
                int i, j;
                (*l_1765) = &g_9[8][1];
            }
        }
    }
lbl_1832:
    l_1772[4][3][0]++;
    for (l_1664 = 0; (l_1664 >= 50); l_1664 = safe_add_func_int16_t_s_s(l_1664, 3))
    { /* block id: 716 */
        int8_t l_1796 = 0xD7L;
        int32_t l_1797[7] = {(-1L),(-1L),0x82D41AF4L,(-1L),(-1L),0x82D41AF4L,(-1L)};
        uint16_t ****l_1840[7][10] = {{&g_1051,&g_1051,&g_1051,(void*)0,(void*)0,&g_1051,&g_1051,&g_1051,(void*)0,(void*)0},{&g_1051,&g_1051,&g_1051,(void*)0,(void*)0,&g_1051,&g_1051,&g_1051,(void*)0,(void*)0},{&g_1051,&g_1051,&g_1051,(void*)0,(void*)0,&g_1051,&g_1051,&g_1051,(void*)0,(void*)0},{&g_1051,&g_1051,&g_1051,(void*)0,(void*)0,&g_1051,&g_1046,(void*)0,&g_1051,&g_1051},{(void*)0,&g_1046,(void*)0,&g_1051,&g_1051,(void*)0,&g_1046,(void*)0,&g_1051,&g_1051},{(void*)0,&g_1046,(void*)0,&g_1051,&g_1051,(void*)0,&g_1046,(void*)0,&g_1051,&g_1051},{(void*)0,&g_1046,(void*)0,&g_1051,&g_1051,(void*)0,&g_1046,(void*)0,&g_1051,&g_1051}};
        uint16_t *****l_1839 = &l_1840[6][5];
        uint32_t **l_1861 = &g_867;
        uint32_t ***l_1860 = &l_1861;
        int64_t *l_1874 = &g_225;
        uint32_t *l_1887 = (void*)0;
        int8_t **l_1912 = &g_984;
        uint32_t l_1913[6][8] = {{0x110ED518L,4294967289UL,0x110ED518L,4294967294UL,4294967287UL,0x1165422EL,0x8278AF03L,0x8278AF03L},{0x8278AF03L,1UL,0x0185AC8DL,0x0185AC8DL,1UL,0x8278AF03L,4294967287UL,4294967294UL},{0x8278AF03L,4294967295UL,4294967295UL,1UL,4294967287UL,1UL,4294967295UL,4294967295UL},{0x110ED518L,4294967295UL,0x1165422EL,1UL,4294967294UL,4294967294UL,4294967294UL,4294967294UL},{0x0185AC8DL,4294967294UL,4294967294UL,0x0185AC8DL,0x110ED518L,4294967295UL,4294967294UL,0x8278AF03L},{4294967295UL,0x0185AC8DL,0x1165422EL,4294967294UL,0x1165422EL,0x0185AC8DL,4294967295UL,4294967287UL}};
        uint64_t **l_1926 = &g_237;
        uint64_t **l_1928 = &g_237;
        uint64_t ***l_1927[8] = {&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928,&l_1928};
        int32_t *l_1943 = &l_1524;
        int8_t ****l_1995 = (void*)0;
        int i, j;
        for (g_413 = 0; (g_413 < 44); g_413 = safe_add_func_int8_t_s_s(g_413, 1))
        { /* block id: 719 */
            int8_t ***l_1785 = &g_981;
            int32_t l_1789 = 0xBEEBD177L;
            int32_t l_1798 = 0xFE262956L;
            int32_t l_1799 = 0x0D7C5399L;
            int32_t l_1800 = 0L;
            int32_t l_1801[3];
            uint64_t l_1803 = 0x8C1BEC17B3416EE7LL;
            uint16_t ****l_1811 = &g_1046;
            uint64_t l_1830[3];
            int8_t *l_1831 = &g_1397;
            uint16_t l_1843 = 0x2D85L;
            uint32_t ***l_1865 = &g_1864[2];
            int i;
            for (i = 0; i < 3; i++)
                l_1801[i] = 0xF212DD68L;
            for (i = 0; i < 3; i++)
                l_1830[i] = 18446744073709551615UL;
            for (g_526 = 0; (g_526 >= (-11)); g_526 = safe_sub_func_uint8_t_u_u(g_526, 4))
            { /* block id: 722 */
                int8_t ****l_1786 = &l_1785;
                int64_t ***l_1793 = &l_1575[3][7][0];
                int64_t ****l_1794[3];
                uint16_t ***l_1795[9][5][4] = {{{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,(void*)0,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,(void*)0,&g_1047,&g_1047}},{{(void*)0,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,(void*)0,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,(void*)0,&g_1047},{&g_1047,(void*)0,&g_1047,&g_1047},{&g_1047,(void*)0,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,&g_1047},{(void*)0,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,(void*)0,(void*)0,&g_1047}},{{&g_1047,&g_1047,&g_1047,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047},{(void*)0,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,(void*)0,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,(void*)0,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047}},{{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,(void*)0},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047},{&g_1047,&g_1047,&g_1047,&g_1047}}};
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_1794[i] = (void*)0;
                for (l_1636 = (-9); (l_1636 > (-12)); l_1636 = safe_sub_func_uint64_t_u_u(l_1636, 2))
                { /* block id: 725 */
                    if (p_50)
                        break;
                }
                l_1797[3] = ((safe_rshift_func_uint8_t_u_s(((((*l_1786) = l_1785) == (void*)0) && ((((safe_mul_func_uint8_t_u_u((l_1789 , l_1789), (safe_lshift_func_uint8_t_u_u((((~((((l_1793 != (g_522 = &g_523)) > g_1405) < (((l_1795[6][4][2] == (*g_1085)) || l_1796) , (****g_614))) < p_50)) < l_1796) < 0x8B2453A5L), 4)))) , (void*)0) != (void*)0) , 0x0081001FL)), p_50)) | (***g_615));
            }
            --l_1803;
            if ((g_1022 >= (l_1801[0] &= (safe_rshift_func_int8_t_s_s(((*l_1831) = (((((((l_1810[1][0] = (***g_615)) <= (&g_1046 == l_1811)) <= (((safe_div_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s(l_1800, (l_1797[3] = (safe_div_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s(((safe_mod_func_uint32_t_u_u((0x6C09L <= (2UL || ((**g_1047) = (safe_rshift_func_uint8_t_u_s(((safe_unary_minus_func_uint8_t_u(g_127)) || (((safe_mod_func_int8_t_s_s(0x3EL, g_1030[4][0][0])) < (*g_936)) , (*g_524))), 7))))), g_1829)) ^ 0x9CA2L), 4)), 1UL))))) ^ p_50), l_1830[1])), p_50)) , l_1830[2]) > l_1796)) > 4L) != 0x1791F489L) < l_1799) , p_50)), l_1796)))))
            { /* block id: 738 */
                (*l_1767) &= 0L;
                if (l_1796)
                    goto lbl_1832;
            }
            else
            { /* block id: 741 */
                uint32_t l_1848 = 6UL;
                int32_t l_1875[4][7][7] = {{{0x397594C5L,0x6F54563DL,0x07DC0264L,4L,(-1L),0xAEE3275AL,7L},{(-4L),1L,0xEC2C1271L,1L,0x9E6AB951L,0xF47279FDL,1L},{0xE7C6C030L,7L,0x6F54563DL,0x4C316FF0L,(-4L),0xC60AB3DFL,4L},{(-1L),4L,1L,0xEA2246D2L,(-4L),4L,(-2L)},{0x064DF9F7L,(-4L),(-1L),(-1L),5L,0L,(-7L)},{0x63486DCDL,(-7L),(-8L),(-8L),(-7L),0x63486DCDL,2L},{0xCD73DD92L,(-1L),0x79A25CE8L,0L,1L,0xA9E265D8L,9L}},{{1L,1L,(-1L),0xB400146DL,0x7E746DBCL,0x8252A8B9L,0xEA2246D2L},{(-7L),(-1L),0x064DF9F7L,0x397594C5L,7L,0xD23F3C46L,1L},{0xAED9DE69L,(-7L),0x8170D3D7L,4L,0x3B4389B8L,0xB400146DL,0x8252A8B9L},{7L,(-4L),0xD23F3C46L,0L,0x064DF9F7L,0x07DC0264L,0x79A25CE8L},{1L,4L,(-8L),(-7L),0x997DE565L,1L,0x997DE565L},{0x6FBAE112L,7L,7L,0x6FBAE112L,(-7L),0L,0xCD73DD92L},{0xF9153299L,1L,4L,0xE7449336L,4L,(-2L),0xA0F8E7C9L}},{{0L,0x6F54563DL,0x5FC857BCL,0L,0xE7C6C030L,0x3FF8AC0CL,0xCD73DD92L},{0L,3L,0x78AB12C7L,2L,0L,1L,0xAED9DE69L},{1L,0L,0x397594C5L,4L,(-4L),(-10L),0L},{0x9E6AB951L,(-4L),0x769C3356L,0xB8B0086AL,(-8L),4L,0L},{0L,0x79A25CE8L,(-1L),0xCD73DD92L,4L,0xCD73DD92L,(-1L)},{(-2L),(-2L),0xF9153299L,0x3B414D06L,0x3B4389B8L,(-8L),(-1L)},{(-1L),0xAEE3275AL,0x5FC857BCL,0x6FBAE112L,(-1L),0x1B1FC700L,7L}},{{0x769C3356L,(-1L),(-2L),(-4L),0x3B4389B8L,4L,(-2L)},{0xD23F3C46L,0x5FC857BCL,0xC60AB3DFL,7L,4L,(-3L),(-6L)},{1L,1L,0x8170D3D7L,0L,(-8L),0x78AB12C7L,(-2L)},{0xCD73DD92L,0xA9E265D8L,0x3FF8AC0CL,(-1L),(-4L),(-9L),0xE7C6C030L},{0xB400146DL,(-4L),0x218ABE3EL,3L,0x218ABE3EL,(-4L),0xB400146DL},{(-4L),0x02F9DC96L,(-1L),0x603646DCL,1L,0xC60AB3DFL,(-1L)},{0x3B4389B8L,(-2L),2L,0xAED9DE69L,0x7E746DBCL,(-1L),0xF9153299L}}};
                uint64_t l_1879 = 0UL;
                int i, j, k;
                (*l_1768) = ((safe_sub_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_u(l_1801[0], 1)) && ((safe_lshift_func_uint16_t_u_u((l_1839 != ((safe_add_func_int8_t_s_s((l_1843 > p_50), (safe_div_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s(8L, l_1830[1])) , (*g_932)), (*l_1767))))) , &g_1085)), 4)) == 250UL)) , 1L), (*g_936))) | l_1848);
                for (l_1799 = 11; (l_1799 != 27); ++l_1799)
                { /* block id: 745 */
                    uint64_t l_1851 = 18446744073709551609UL;
                    ++l_1851;
                    for (l_1636 = 1; (l_1636 >= 0); l_1636 -= 1)
                    { /* block id: 749 */
                        int i, j;
                        (*l_1767) = g_9[(l_1636 + 6)][l_1636];
                    }
                }
                for (g_225 = (-16); (g_225 == 29); g_225++)
                { /* block id: 755 */
                    uint32_t ****l_1862[6][6] = {{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860},{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860},{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860},{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860},{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860},{&l_1860,&l_1860,&l_1860,&l_1860,&l_1860,&l_1860}};
                    int32_t l_1872 = (-1L);
                    uint64_t l_1873 = 1UL;
                    int i, j;
                    if (((safe_div_func_int8_t_s_s((!(l_1859 == (((0xFBC1L || 0x5AE9L) >= ((((p_50 == (((g_1863 = l_1860) == l_1865) >= (safe_add_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((*l_1767), (p_50 < (safe_div_func_uint8_t_u_u((l_1872 = g_1018[2]), p_50))))), l_1796)))) <= l_1873) , l_1874) != (void*)0)) , l_1859))), p_50)) && 0xB69ABE02881531D5LL))
                    { /* block id: 758 */
                        int64_t l_1876 = 0xC86EED0B61CEB0C9LL;
                        int32_t l_1877 = 3L;
                        int32_t l_1878 = 0L;
                        l_1879++;
                        if (l_1664)
                            goto lbl_1882;
                        if (p_50)
                            continue;
                    }
                    else
                    { /* block id: 762 */
                        uint32_t l_1883 = 0x8B1830ADL;
                        if (g_1014)
                            break;
                        l_1883 ^= (*l_1768);
                    }
                    for (l_1519 = (-11); (l_1519 <= 16); ++l_1519)
                    { /* block id: 768 */
                        int32_t **l_1886 = &l_1770[3];
                        (*l_1886) = func_91(&l_1664);
                        (*l_1886) = func_91(l_1887);
                    }
                }
            }
            if (l_1800)
                continue;
        }
        l_1797[2] = (((((((void*)0 != l_1888) >= ((safe_rshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_s((safe_mul_func_int16_t_s_s((*l_1769), ((safe_rshift_func_int8_t_s_s((safe_div_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u(p_50, ((safe_mul_func_int16_t_s_s(((((void*)0 == (*g_1588)) , (!((safe_mul_func_uint16_t_u_u(p_50, (((*l_1767) |= ((safe_sub_func_int64_t_s_s(p_50, (safe_mod_func_uint64_t_u_u((((!((void*)0 != l_1912)) , 0x0D3BF8CF66E1290ELL) >= 1UL), l_1797[2])))) < 0L)) & 0UL))) < p_50))) , l_1913[0][3]), p_50)) , 0UL))) & 4UL), 7UL)), p_50)) & 8UL))), l_1913[0][3])), 9)) || p_50)) <= p_50) , 3L) > l_1914) <= p_50);
    }
    (*l_1767) |= 0x1A1EC552L;
    return p_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_73 g_68 g_11 g_127 g_131 g_125 g_614 g_319 g_356 g_524 g_225 g_526 g_207 g_232 g_354 g_414 g_575 g_523 g_175 g_615 g_236 g_522 g_413 g_186 g_757 g_2 g_843 g_879 g_160 g_551 g_936 g_937 g_237 g_1017 g_983 g_1098 g_1034 g_1228 g_1229 g_1094 g_380 g_1043 g_1100 g_932 g_933 g_1030 g_1031 g_1320 g_1091 g_814 g_1020 g_1044 g_1033 g_1092 g_1405
 * writes: g_73 g_125 g_127 g_131 g_414 g_319 g_232 g_225 g_160 g_68 g_186 g_175 g_236 g_524 g_867 g_413 g_356 g_931 g_936 g_207 g_526 g_984 g_843 g_551
 */
static uint64_t  func_60(int8_t  p_61, uint32_t  p_62, int8_t  p_63)
{ /* block id: 14 */
    int32_t l_66[1][4][5];
    int32_t l_71 = 0L;
    uint16_t **l_1203 = &g_1091[4];
    uint64_t ****l_1310 = (void*)0;
    int32_t l_1334 = 0xB4A1D8BAL;
    int32_t l_1336 = 0x3488AF61L;
    int32_t l_1338 = 7L;
    int32_t l_1342[9];
    int32_t *l_1377 = &l_1336;
    int8_t *l_1444 = &g_1397;
    int16_t l_1463 = 0x2947L;
    const uint32_t *l_1491 = &g_403;
    const uint32_t * const *l_1490[1];
    const uint32_t * const **l_1489 = &l_1490[0];
    uint32_t **l_1493[10][1] = {{&g_867},{&g_867},{&g_867},{&g_867},{&g_867},{&g_867},{&g_867},{&g_867},{&g_867},{&g_867}};
    uint32_t ***l_1492 = &l_1493[6][0];
    uint8_t l_1500 = 255UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
                l_66[i][j][k] = (-1L);
        }
    }
    for (i = 0; i < 9; i++)
        l_1342[i] = 1L;
    for (i = 0; i < 1; i++)
        l_1490[i] = &l_1491;
    for (p_62 = 0; (p_62 >= 11); ++p_62)
    { /* block id: 17 */
        uint32_t *l_67[8] = {&g_68[2][0][0],(void*)0,&g_68[2][0][0],(void*)0,&g_68[2][0][0],(void*)0,&g_68[2][0][0],(void*)0};
        int32_t l_69 = (-9L);
        int32_t *l_70 = &l_69;
        int32_t *l_72[2][2][2] = {{{(void*)0,&g_73},{&g_73,(void*)0}},{{&g_73,&g_73},{(void*)0,&g_73}}};
        int64_t * const *l_1258[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int64_t * const **l_1257 = &l_1258[1];
        int64_t * const ***l_1256 = &l_1257;
        uint16_t *l_1327 = (void*)0;
        int16_t l_1374 = (-7L);
        uint32_t l_1426 = 0xB0038CCCL;
        uint32_t **l_1449 = &g_867;
        uint32_t ***l_1448 = &l_1449;
        uint8_t *l_1469 = (void*)0;
        uint8_t *l_1470 = &g_125;
        uint32_t ****l_1494 = &l_1448;
        uint32_t ****l_1495 = &l_1492;
        int i, j, k;
        if (((((l_69 = l_66[0][3][2]) && ((*l_70) = g_6[2])) ^ l_66[0][3][2]) , (g_73 &= ((*l_70) = (l_71 = p_61)))))
        { /* block id: 23 */
            uint32_t l_74[10] = {0xF43C5EACL,18446744073709551615UL,18446744073709551615UL,0xF43C5EACL,0x8638AA3AL,0xF43C5EACL,18446744073709551615UL,18446744073709551615UL,0xF43C5EACL,0x8638AA3AL};
            uint32_t *l_90 = &g_68[2][0][0];
            uint32_t *l_99 = &g_68[2][0][0];
            int32_t l_1191 = 1L;
            int32_t l_1204 = (-5L);
            uint16_t l_1226 = 0x704FL;
            int64_t ***l_1329[1];
            uint16_t l_1331 = 65528UL;
            int32_t l_1335[7][5][6] = {{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}},{{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L},{9L,9L,9L,9L,9L,9L}}};
            uint64_t l_1346 = 18446744073709551611UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1329[i] = &g_523;
            ++l_74[0];
            for (p_61 = 19; (p_61 <= (-24)); --p_61)
            { /* block id: 27 */
                uint32_t l_87 = 0xADF13F3FL;
                int32_t l_1158 = 1L;
                uint8_t *l_1230[6];
                int i;
                for (i = 0; i < 6; i++)
                    l_1230[i] = &g_319;
                (*l_70) = p_62;
                if ((((p_63 , (safe_sub_func_uint8_t_u_u(0x00L, 0xF4L))) , (safe_div_func_uint32_t_u_u((((safe_add_func_int64_t_s_s(p_62, l_87)) & g_6[2]) >= (((l_1158 ^= (safe_sub_func_uint64_t_u_u(((*g_237) = (l_90 == (l_99 = func_91(func_93(&l_87, g_68[2][7][1], l_71, &g_2, l_99))))), l_74[1]))) >= 0L) <= 0xBD2EC0CD717BACDFLL)), l_87))) && (*g_186)))
                { /* block id: 483 */
                    return (****g_614);
                }
                else
                { /* block id: 485 */
                    uint32_t *l_1162 = &l_87;
                    int32_t **l_1167 = (void*)0;
                    int32_t **l_1168 = &l_72[1][0][0];
                    int32_t l_1198 = 0xB294A570L;
                    uint32_t **l_1232 = &g_867;
                    uint32_t ***l_1231 = &l_1232;
                    if (((safe_lshift_func_int8_t_s_s(0xFBL, ((*g_237) , ((!(l_1162 == &l_87)) || (safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(l_1158, (((*l_1168) = l_99) == ((safe_mul_func_uint8_t_u_u(((p_61 & 0xE5L) >= (safe_sub_func_int64_t_s_s((+0xEBF2L), (*g_237)))), 0x60L)) , (void*)0)))), l_87)))))) && (-1L)))
                    { /* block id: 487 */
                        uint8_t *l_1192[3][7][9] = {{{&g_125,&g_125,&g_413,&g_125,&g_319,(void*)0,&g_319,&g_413,&g_319},{(void*)0,&g_413,(void*)0,&g_125,&g_413,&g_413,&g_125,(void*)0,&g_413},{(void*)0,&g_125,&g_413,&g_319,&g_125,&g_319,&g_125,&g_413,&g_413},{(void*)0,&g_413,(void*)0,&g_125,&g_319,&g_413,(void*)0,(void*)0,&g_413},{&g_319,&g_125,(void*)0,(void*)0,&g_319,(void*)0,&g_125,(void*)0,&g_413},{&g_319,&g_413,(void*)0,&g_319,&g_413,(void*)0,&g_125,(void*)0,&g_319},{&g_125,&g_413,&g_413,(void*)0,&g_125,&g_125,(void*)0,&g_413,&g_413}},{{&g_125,&g_319,(void*)0,&g_125,&g_413,&g_319,(void*)0,(void*)0,&g_413},{&g_125,&g_125,&g_413,&g_319,&g_319,&g_125,&g_125,&g_413,&g_413},{&g_319,&g_319,(void*)0,&g_125,&g_319,(void*)0,(void*)0,(void*)0,&g_413},{&g_319,&g_413,&g_413,&g_319,&g_125,(void*)0,(void*)0,&g_413,&g_125},{(void*)0,&g_413,(void*)0,&g_125,&g_413,&g_413,&g_125,(void*)0,&g_413},{(void*)0,&g_125,&g_413,&g_319,&g_125,&g_319,&g_125,&g_413,&g_413},{(void*)0,&g_413,(void*)0,&g_125,&g_319,&g_413,(void*)0,(void*)0,&g_413}},{{&g_319,&g_125,(void*)0,(void*)0,&g_319,(void*)0,&g_125,(void*)0,&g_413},{&g_319,&g_413,(void*)0,&g_319,&g_413,(void*)0,&g_125,(void*)0,&g_319},{&g_125,&g_413,&g_413,(void*)0,&g_125,&g_125,(void*)0,&g_413,&g_413},{&g_125,&g_319,(void*)0,&g_125,&g_413,&g_319,(void*)0,(void*)0,&g_413},{&g_125,&g_125,&g_413,&g_319,&g_319,&g_125,&g_125,&g_413,&g_413},{&g_319,&g_319,(void*)0,&g_125,&g_319,(void*)0,(void*)0,(void*)0,&g_413},{&g_319,&g_413,&g_413,&g_319,&g_125,(void*)0,(void*)0,&g_413,&g_125}}};
                        int32_t l_1197 = 0x2092A4E1L;
                        int i, j, k;
                        g_73 ^= ((safe_mod_func_int8_t_s_s(((safe_unary_minus_func_uint32_t_u((safe_div_func_int64_t_s_s((p_63 < 0x41L), (((safe_sub_func_int64_t_s_s(l_74[4], (safe_lshift_func_int16_t_s_s(g_551, (safe_rshift_func_int8_t_s_s(p_62, 7)))))) ^ ((safe_add_func_int8_t_s_s((l_1191 = (safe_rshift_func_int8_t_s_u((-10L), 0))), (g_125 = l_1158))) >= ((*l_70) = (((safe_mul_func_int8_t_s_s(l_1158, (safe_rshift_func_uint16_t_u_s(l_74[0], p_61)))) <= l_1197) , (-10L))))) , l_1158))))) <= g_1017), p_61)) , 0xBC5A23E7L);
                        l_1204 |= ((((l_1158 == ((*g_524) ^= (252UL && l_1198))) || (safe_add_func_uint16_t_u_u((l_1191 |= (safe_rshift_func_int16_t_s_u((((l_1158 &= 0xBBL) && (p_63 & (((*g_983) = &p_63) != (void*)0))) <= ((*l_70) &= ((((*l_1162) = ((l_1203 == (void*)0) && 1UL)) != 0UL) <= l_74[0]))), 14))), p_62))) && (*l_70)) , (-1L));
                        if (l_1191)
                            break;
                        if (p_62)
                            break;
                    }
                    else
                    { /* block id: 501 */
                        int16_t *l_1227 = &g_160;
                        (*l_70) &= p_63;
                        l_1204 = (((*g_1098)--) || (safe_mod_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(((p_63 = p_63) , ((p_61 >= ((*l_70) = ((((safe_mod_func_int16_t_s_s(((*l_1227) |= (((safe_add_func_int64_t_s_s(((safe_rshift_func_int16_t_s_s((0x9D5F948DL && (p_63 < (safe_div_func_uint64_t_u_u(18446744073709551611UL, ((((*g_936) , (safe_sub_func_uint64_t_u_u(0x245F8D9C86ABD5DELL, ((safe_unary_minus_func_uint16_t_u((((l_1158 ^= (***g_615)) > (safe_sub_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_s(p_63, 9)) || l_71) || 0x40019B9BL), (-1L)))) & 0x02L))) < g_1034)))) | p_63) && 0x71FBL))))), l_1204)) , l_1226), 0xDD4363EC99C27764LL)) , 7L) && p_61)), g_1228)) | g_1229[5]) , &g_413) == l_1230[0]))) || (*g_936))), (***g_522))), (-5L))));
                    }
                    l_71 = ((((((((*l_1231) = &g_867) == &g_867) & (0L <= ((((safe_mod_func_uint16_t_u_u((*l_70), (~(*g_1094)))) & (((safe_sub_func_int8_t_s_s((safe_mod_func_int64_t_s_s(0xC711760E9F720727LL, (****g_614))), ((p_61 , 1UL) | (*g_186)))) < p_62) > l_87)) , l_1158) < p_62))) == 9UL) <= (*g_936)) ^ (*g_186)) >= 1UL);
                }
            }
            for (g_356 = 0; (g_356 != 58); g_356 = safe_add_func_int8_t_s_s(g_356, 8))
            { /* block id: 516 */
                int64_t ***l_1248 = &g_523;
                uint32_t *l_1252 = &g_551;
                int32_t l_1270 = 0x948313C8L;
                uint64_t ****l_1311 = &g_615;
                int32_t l_1339 = 7L;
                int32_t l_1340[9] = {0x0168CF64L,0xBD6A9E63L,0xBD6A9E63L,0x0168CF64L,0xBD6A9E63L,0xBD6A9E63L,0x0168CF64L,0xBD6A9E63L,0xBD6A9E63L};
                uint8_t l_1343 = 0xCBL;
                int i;
                for (g_125 = (-19); (g_125 >= 23); ++g_125)
                { /* block id: 519 */
                    uint32_t **l_1251 = &l_90;
                    uint8_t l_1269[1][3][3] = {{{0UL,0UL,0UL},{0xCDL,0xCDL,0xCDL},{0UL,0UL,0UL}}};
                    int32_t l_1332[7] = {(-5L),(-3L),(-3L),(-5L),(-3L),(-3L),(-5L)};
                    uint64_t *l_1333 = &g_814;
                    int i, j, k;
                    (*l_70) = (((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((void*)0 != l_1248), (safe_mul_func_uint8_t_u_u(((((((((*l_1251) = func_91(((*l_1251) = (void*)0))) != l_1252) , (safe_lshift_func_int16_t_s_s(g_356, (~(((void*)0 == l_1256) , (safe_div_func_uint64_t_u_u(((((((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((safe_sub_func_int16_t_s_s(p_62, l_1269[0][2][2])), 2)), g_1043)), 0xA6L)) == p_63) >= l_74[0]) , 0x0B9DF5B2L) || 0x0AB3BA50L) <= p_62), (*g_524)))))))) == l_1270) >= p_63) , p_62) , 5UL), (*l_70))))), (*g_1100))) || p_61) == (*g_932));
                    if (p_61)
                    { /* block id: 523 */
                        int16_t *l_1280 = &g_526;
                        int32_t l_1283 = 0L;
                        int16_t *l_1289 = (void*)0;
                        int16_t *l_1290 = &g_160;
                        (*l_70) = (safe_mul_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u((!((safe_lshift_func_int8_t_s_u(((((((*l_1280) = g_1017) == (0x7A5C76B4L < ((safe_lshift_func_int8_t_s_u(l_1283, (safe_unary_minus_func_int64_t_s(5L)))) && (g_73 = (((((p_61 ^ (~(~(((safe_mul_func_int16_t_s_s(((*l_1290) = ((*g_522) != (void*)0)), g_1030[6][5][0])) & (safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((((l_1283 <= 1L) ^ l_1270) == p_63) <= (*g_936)), g_2)), 1UL))) || g_1229[2])))) > p_61) , &g_615) == &g_615) && 0xB8735035L))))) , 0x3D6F8F26L) , (*g_936)) && (-1L)), p_62)) || 4UL)), 0xFBDDL)) & l_74[0]), p_62));
                    }
                    else
                    { /* block id: 528 */
                        uint32_t l_1298[7] = {0x1C21DFA7L,0x1C21DFA7L,0x1C21DFA7L,0x1C21DFA7L,0x1C21DFA7L,0x1C21DFA7L,0x1C21DFA7L};
                        uint8_t *l_1321 = (void*)0;
                        uint8_t *l_1322 = (void*)0;
                        uint8_t *l_1323 = &g_319;
                        const int64_t *** const l_1328 = (void*)0;
                        uint8_t *l_1330[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1330[i] = (void*)0;
                        l_1332[4] = (p_62 != ((safe_unary_minus_func_int16_t_s(((safe_mul_func_int8_t_s_s(l_1298[2], (safe_sub_func_int16_t_s_s(((l_71 & (safe_unary_minus_func_int8_t_s((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((p_63 == ((safe_add_func_int16_t_s_s(((g_1031 <= ((g_413 = ((l_1311 = l_1310) != (((((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(((safe_div_func_int8_t_s_s((safe_sub_func_int32_t_s_s((0x02L < ((*l_1323) = g_1320)), (safe_div_func_int8_t_s_s((~(l_1327 == (*l_1203))), p_61)))), 0x4BL)) & 0xEEL), 10)) & p_63), 15)) != l_66[0][2][3]) , l_1328) == l_1329[0]) , l_1310))) && 251UL)) | l_1270), 2UL)) & l_1269[0][2][2])) & p_63), 0xCC25L)), g_814)), 0))))) <= l_1331), (*l_70))))) & (-4L)))) >= 1UL));
                        (*l_70) |= ((***g_614) == l_1333);
                        (*l_70) &= g_1020;
                    }
                    return (***g_615);
                }
                ++l_1343;
                return l_1346;
            }
            for (g_131 = 3; (g_131 >= 0); g_131 -= 1)
            { /* block id: 543 */
                uint64_t l_1347[4][5][4] = {{{0x2805C6F9158A74C1LL,1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL},{4UL,0xB117536E89067335LL,0xA3788FEFC0338095LL,0xA3788FEFC0338095LL},{1UL,1UL,18446744073709551611UL,0xB117536E89067335LL},{0xB117536E89067335LL,4UL,18446744073709551611UL,4UL},{1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL,18446744073709551611UL}},{{4UL,0x2805C6F9158A74C1LL,0x2805C6F9158A74C1LL,4UL},{0x2805C6F9158A74C1LL,4UL,1UL,0xB117536E89067335LL},{0x2805C6F9158A74C1LL,1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL},{4UL,0xB117536E89067335LL,0xA3788FEFC0338095LL,0xA3788FEFC0338095LL},{1UL,1UL,18446744073709551611UL,0xB117536E89067335LL}},{{0xB117536E89067335LL,4UL,18446744073709551611UL,4UL},{1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL,18446744073709551611UL},{4UL,0x2805C6F9158A74C1LL,0x2805C6F9158A74C1LL,4UL},{0x2805C6F9158A74C1LL,4UL,1UL,0xB117536E89067335LL},{0x2805C6F9158A74C1LL,1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL}},{{4UL,0xB117536E89067335LL,0xA3788FEFC0338095LL,0xA3788FEFC0338095LL},{1UL,1UL,18446744073709551611UL,0xB117536E89067335LL},{0xB117536E89067335LL,4UL,18446744073709551611UL,4UL},{1UL,0x2805C6F9158A74C1LL,0xA3788FEFC0338095LL,18446744073709551611UL},{4UL,0x2805C6F9158A74C1LL,0x2805C6F9158A74C1LL,4UL}}};
                int i, j, k;
                if (p_61)
                    break;
                return l_1347[2][2][0];
            }
        }
        else
        { /* block id: 547 */
            int16_t l_1375 = 0x66E6L;
            int32_t l_1424 = 0xDC3C0D09L;
            const uint8_t **l_1429[2];
            int16_t *l_1450 = (void*)0;
            int16_t *l_1451[4];
            uint64_t *l_1455[10][9] = {{&g_1228,&g_814,(void*)0,&g_1228,(void*)0,&g_1228,(void*)0,&g_814,(void*)0},{&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228},{&g_1228,&g_814,(void*)0,&g_1228,(void*)0,&g_1228,(void*)0,&g_814,(void*)0},{&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228},{&g_1228,&g_814,(void*)0,&g_1228,(void*)0,&g_1228,(void*)0,&g_814,(void*)0},{&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228},{&g_1228,&g_814,(void*)0,&g_1228,(void*)0,&g_1228,(void*)0,&g_814,(void*)0},{&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228},{&g_1228,&g_814,(void*)0,&g_1228,(void*)0,&g_1228,(void*)0,&g_814,(void*)0},{&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228,&g_1228,(void*)0,&g_1228}};
            int32_t l_1460 = 0xB958E09CL;
            int32_t l_1461 = (-4L);
            int i, j;
            for (i = 0; i < 2; i++)
                l_1429[i] = (void*)0;
            for (i = 0; i < 4; i++)
                l_1451[i] = &l_1374;
            for (g_131 = (-26); (g_131 >= (-23)); g_131 = safe_add_func_uint8_t_u_u(g_131, 5))
            { /* block id: 550 */
                int32_t l_1395 = (-1L);
                int8_t l_1417 = 0L;
                int32_t l_1418 = 1L;
                int32_t l_1420 = 0x55205369L;
                uint8_t l_1421 = 255UL;
                uint32_t **l_1441 = &l_67[3];
                uint32_t ***l_1440 = &l_1441;
                for (g_175 = 1; (g_175 <= 60); ++g_175)
                { /* block id: 553 */
                    return (***g_615);
                }
                for (g_551 = (-27); (g_551 == 59); g_551 = safe_add_func_uint64_t_u_u(g_551, 7))
                { /* block id: 558 */
                    int32_t **l_1354 = (void*)0;
                    int32_t **l_1355 = &l_72[1][0][0];
                    (*l_1355) = &g_2;
                }
            }
            g_73 &= (safe_mod_func_int16_t_s_s(((*l_1377) = (l_1448 != &l_1449)), ((4L && (safe_lshift_func_uint8_t_u_u(((l_1424 &= (((*g_237) = (0x46L | ((safe_unary_minus_func_uint8_t_u(g_1044)) | (g_1044 != ((*l_70) != p_63))))) & (p_61 , 3UL))) || (*g_237)), g_937))) || 0x85EB4EAFL)));
            for (g_843 = 0; (g_843 < 44); g_843++)
            { /* block id: 604 */
                int16_t l_1458[1][6] = {{0x0D46L,0x0D46L,0x0D46L,0x0D46L,0x0D46L,0x0D46L}};
                int32_t l_1459 = 1L;
                int32_t l_1462[6] = {0xDD0E62FFL,0xEA840BD1L,0xDD0E62FFL,0xDD0E62FFL,0xEA840BD1L,0xDD0E62FFL};
                uint32_t l_1464 = 18446744073709551615UL;
                int i, j;
                if (g_1033)
                    break;
                ++l_1464;
            }
        }
        if ((((((((g_68[0][0][1] = (safe_lshift_func_uint8_t_u_u(((*l_1470) = 255UL), p_61))) >= (g_551 |= p_63)) || (safe_mod_func_int64_t_s_s((safe_div_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u(((safe_mod_func_int16_t_s_s(((((safe_div_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u((*l_1377), ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u((safe_div_func_int32_t_s_s(((((l_1489 != ((*l_1495) = ((*l_1494) = l_1492))) > 0x90L) ^ (safe_div_func_uint16_t_u_u((p_61 <= (((safe_mod_func_uint16_t_u_u(0UL, (*g_1092))) || p_61) <= g_575)), (*g_1100)))) > p_62), g_1405)), 7)), 4)) ^ (*g_932)))) <= p_62), 1UL)) ^ 4294967288UL) , (-1L)) & l_1500), (*l_1377))) , p_62), (*l_1377))), p_63)), 1L))) > 7UL) < g_11) >= p_61) , g_207))
        { /* block id: 614 */
            int32_t **l_1501 = &l_72[1][0][0];
            (*l_1501) = (void*)0;
        }
        else
        { /* block id: 616 */
            uint16_t *l_1514 = (void*)0;
            int32_t l_1517 = 7L;
            int32_t **l_1518 = &l_70;
            l_1517 = ((safe_unary_minus_func_uint32_t_u((safe_sub_func_int64_t_s_s((safe_mod_func_int32_t_s_s(p_63, (safe_unary_minus_func_uint16_t_u((((safe_lshift_func_uint16_t_u_u(0x72D4L, 14)) >= (((1L == 0x068CE4EBL) , (safe_sub_func_uint16_t_u_u(((((void*)0 != &g_131) > (safe_mod_func_int16_t_s_s((((***g_615) = ((l_1514 = l_1514) == (((*l_1377) <= (((safe_sub_func_uint16_t_u_u(0xCD5DL, 0xD03CL)) && (*g_1098)) && (*l_1377))) , l_1327))) , p_62), 0xF324L))) >= p_63), p_61))) || l_1517)) > (*l_1377)))))), p_62)))) , g_414[0][0][1]);
            for (g_131 = 0; g_131 < 10; g_131 += 1)
            {
                for (p_61 = 0; p_61 < 1; p_61 += 1)
                {
                    l_1493[g_131][p_61] = &g_867;
                }
            }
            (*l_1518) = &g_73;
            (*l_1377) = ((*l_1377) <= 65535UL);
        }
    }
    return (*g_932);
}


/* ------------------------------------------ */
/* 
 * reads : g_936 g_68 g_937 g_575 g_160 g_237
 * writes: g_160 g_175 g_526
 */
static uint32_t * func_91(uint32_t * p_92)
{ /* block id: 473 */
    uint8_t *l_1138 = (void*)0;
    uint8_t **l_1137 = &l_1138;
    int16_t *l_1143 = (void*)0;
    int16_t *l_1144 = &g_160;
    int32_t l_1145 = 0x4CEC44A1L;
    uint64_t *l_1154 = &g_175;
    uint16_t ****l_1155 = &g_1051;
    uint8_t *l_1156 = (void*)0;
    int16_t *l_1157 = &g_526;
    l_1145 = (((*l_1157) = (0x9ABDC17A96798FCCLL | ((*g_237) = (safe_sub_func_int8_t_s_s(((((((*l_1137) = (((*g_936) , 0x25220C40L) , (void*)0)) != ((safe_mul_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u(((*l_1144) |= g_575), 6)) >= ((l_1145 | l_1145) , (safe_mul_func_uint8_t_u_u(l_1145, (((safe_div_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u((safe_add_func_int16_t_s_s(((l_1154 == (void*)0) && 5L), 2L)), 0)), l_1145)) , l_1155) != &g_1051))))), 0x17D8L)) , l_1156)) | 0xB32E34FEL) || l_1145) > l_1145), l_1145))))) <= l_1145);
    return &g_356;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_68 g_6 g_127 g_131 g_125 g_73 g_614 g_319 g_356 g_524 g_225 g_526 g_207 g_232 g_354 g_414 g_575 g_523 g_175 g_615 g_236 g_522 g_413 g_186 g_2 g_757 g_843 g_879 g_160 g_551
 * writes: g_73 g_125 g_127 g_131 g_414 g_319 g_232 g_225 g_160 g_68 g_186 g_175 g_236 g_524 g_867 g_413 g_356 g_931 g_936 g_207
 */
static uint32_t * func_93(uint32_t * p_94, const int16_t  p_95, uint32_t  p_96, int32_t * p_97, uint32_t * p_98)
{ /* block id: 29 */
    int32_t **l_818 = &g_186;
    uint32_t *l_821 = (void*)0;
    int32_t *l_822 = &g_73;
    int32_t *l_823 = &g_414[0][6][1];
    int32_t *l_824 = &g_414[0][8][0];
    int32_t *l_825 = &g_73;
    int32_t *l_826[4] = {&g_11,&g_11,&g_11,&g_11};
    int32_t l_827[7][10][3] = {{{1L,0x0DFF872BL,0xC4D9DDAEL},{6L,9L,6L},{7L,1L,6L},{0x606A79BCL,1L,0xC4D9DDAEL},{0xC75E10AEL,(-1L),0x8C1339E6L},{0x40D02E25L,0x46F8E3EFL,0xC45BB5EEL},{(-7L),0x87704D6EL,9L},{(-3L),2L,0L},{9L,0x87704D6EL,0xBBBCF1BBL},{1L,0x46F8E3EFL,(-3L)}},{{0L,(-1L),(-10L)},{0x0DFF872BL,1L,0xB8844F93L},{1L,1L,0L},{1L,9L,0x08EA9538L},{0x0DFF872BL,0x0DFF872BL,(-10L)},{0L,7L,1L},{1L,0L,1L},{9L,0xABA647EBL,0xC540E1DDL},{(-3L),1L,1L},{(-7L),1L,1L}},{{0x40D02E25L,0xAB32600EL,(-10L)},{0xC75E10AEL,0x40D02E25L,0x08EA9538L},{0x606A79BCL,0x0E6484A9L,0L},{7L,0x0E6484A9L,0xB8844F93L},{6L,0x40D02E25L,(-10L)},{1L,0xAB32600EL,(-3L)},{0L,1L,0xBBBCF1BBL},{(-1L),1L,0L},{0x0E6484A9L,0xABA647EBL,9L},{(-1L),0L,0xC45BB5EEL}},{{0L,7L,0x8C1339E6L},{1L,0x0DFF872BL,0xC4D9DDAEL},{6L,9L,6L},{7L,1L,6L},{0x606A79BCL,1L,0xC4D9DDAEL},{0xC75E10AEL,(-1L),0x8C1339E6L},{0x40D02E25L,0x46F8E3EFL,0xC45BB5EEL},{(-7L),0x87704D6EL,9L},{(-3L),2L,0L},{9L,0x87704D6EL,0xBBBCF1BBL}},{{1L,0x46F8E3EFL,(-3L)},{0L,(-1L),(-10L)},{0x0DFF872BL,1L,0xB8844F93L},{1L,1L,0L},{1L,9L,0x08EA9538L},{0x0DFF872BL,0x0DFF872BL,(-10L)},{0L,7L,1L},{1L,0L,1L},{9L,0xABA647EBL,0xC540E1DDL},{(-3L),1L,1L}},{{(-7L),1L,1L},{0x40D02E25L,0xAB32600EL,(-10L)},{0xC75E10AEL,0x40D02E25L,0x08EA9538L},{0x606A79BCL,0x0E6484A9L,0L},{7L,0x0E6484A9L,0xB8844F93L},{6L,0x40D02E25L,(-10L)},{1L,0xAB32600EL,(-3L)},{0L,1L,0xBBBCF1BBL},{0x0AF0E5CBL,0xBA168446L,1L},{0L,(-1L),0x1D409EE5L}},{{0x0AF0E5CBL,0x5FED9E24L,0x58737722L},{3L,0xFE6E3ED3L,0x90B2374CL},{1L,(-4L),0L},{0L,0x0AA1D685L,1L},{0xFE6E3ED3L,0xEF0F113AL,1L},{0xD35FB65AL,0xE5586877L,0L},{0x8AAF20EBL,0x0AF0E5CBL,0x90B2374CL},{5L,0xD31300BDL,0x58737722L},{0xC1BC1076L,0xAFA902E0L,0x1D409EE5L},{0x9079B1CEL,0x9123DD05L,1L}}};
    int32_t l_828 = (-1L);
    int32_t l_829 = 0xDEC5257DL;
    uint32_t l_830[4] = {0xFCBABC7BL,0xFCBABC7BL,0xFCBABC7BL,0xFCBABC7BL};
    uint16_t **l_838 = (void*)0;
    uint64_t **l_860 = (void*)0;
    int64_t *l_861 = &g_225;
    int32_t *l_873 = &l_829;
    int64_t l_1053 = 0L;
    const int32_t l_1127 = 0xA2746852L;
    int i, j, k;
    (*l_818) = func_100(g_11, ((void*)0 != &g_68[2][0][0]));
lbl_835:
    for (g_160 = 0; (g_160 < (-15)); g_160--)
    { /* block id: 350 */
        return l_821;
    }
    ++l_830[2];
    for (g_175 = (-6); (g_175 != 19); g_175 = safe_add_func_int64_t_s_s(g_175, 4))
    { /* block id: 356 */
        uint16_t * const **l_839 = (void*)0;
        uint16_t * const l_842 = &g_843;
        uint16_t * const *l_841 = &l_842;
        uint16_t * const **l_840 = &l_841;
        int32_t l_863 = 1L;
        uint32_t *l_864 = &g_207;
        int8_t l_876[3][1];
        uint32_t *l_899[8][1] = {{&g_68[2][0][0]},{(void*)0},{&g_68[2][0][0]},{(void*)0},{&g_68[2][0][0]},{(void*)0},{&g_68[2][0][0]},{(void*)0}};
        int8_t l_935[8][8][4] = {{{7L,2L,(-1L),2L},{0xBCL,0x8AL,0L,(-1L)},{0x35L,0x14L,0L,0x94L},{(-5L),0xDFL,1L,0x41L},{(-5L),(-1L),0L,(-1L)},{0x35L,0x41L,0L,6L},{0xBCL,0x6DL,(-1L),7L},{7L,0x14L,0xBCL,0x0DL}},{{0x13L,9L,1L,1L},{(-1L),6L,0x2EL,(-1L)},{0x27L,6L,7L,1L},{0xBCL,9L,0L,0x0DL},{0x69L,0x14L,5L,7L},{1L,0x6DL,1L,6L},{0x97L,0x41L,0L,(-1L)},{0xA1L,(-1L),(-7L),0x41L}},{{0xBCL,0xDFL,(-7L),0x94L},{0xA1L,0x14L,0L,(-1L)},{0x97L,0x8AL,1L,2L},{1L,2L,5L,(-1L)},{0x69L,1L,0L,(-1L)},{0xBCL,0x30L,7L,0x53L},{0x27L,0x14L,0x2EL,0x53L},{(-1L),0x30L,1L,(-1L)}},{{0x13L,1L,0xBCL,(-1L)},{7L,2L,(-1L),2L},{0xBCL,0x8AL,0L,(-1L)},{0x35L,0x14L,0L,0x94L},{(-5L),0xDFL,1L,0x41L},{(-5L),(-1L),0L,(-1L)},{0x35L,0x41L,0L,6L},{0xBCL,0x6DL,(-1L),7L}},{{7L,0x14L,0xBCL,0x0DL},{0x13L,9L,1L,1L},{(-1L),6L,0x2EL,(-1L)},{0x27L,6L,7L,0xD1L},{(-5L),0x0EL,0x95L,0x30L},{0L,6L,1L,0x6DL},{(-7L),0x14L,(-7L),0x22L},{0L,0x87L,(-1L),0x53L}},{{0x2EL,(-3L),(-1L),0x87L},{(-5L),0x1AL,(-1L),9L},{0x2EL,6L,(-1L),0xDFL},{0L,(-7L),(-7L),(-1L)},{(-7L),(-1L),1L,0x53L},{0L,0xD1L,0x95L,(-3L)},{(-5L),(-1L),9L,0x8AL},{0L,6L,0x13L,0x8AL}},{{(-1L),(-1L),(-7L),(-3L)},{7L,0xD1L,(-5L),0x53L},{0xBCL,(-1L),0x96L,(-1L)},{(-5L),(-7L),(-8L),0xDFL},{5L,6L,0x97L,9L},{0L,0x1AL,(-7L),0x87L},{0L,(-3L),0x97L,0x53L},{5L,0x87L,(-8L),0x22L}},{{(-5L),0x14L,0x96L,0x6DL},{0xBCL,6L,(-5L),0x30L},{7L,0x0EL,(-7L),0xD1L},{(-1L),0x22L,0x13L,0x53L},{0L,0x22L,9L,0xD1L},{(-5L),0x0EL,0x95L,0x30L},{0L,6L,1L,0x6DL},{(-7L),0x14L,(-7L),0x22L}}};
        uint64_t ****l_947 = (void*)0;
        int32_t l_999 = 0x43915765L;
        uint16_t ***l_1049[5][7][7] = {{{&l_838,&l_838,&l_838,&l_838,&l_838,&g_1047,&g_1047},{&l_838,(void*)0,&l_838,&g_1047,&g_1047,(void*)0,&g_1047},{(void*)0,&g_1047,(void*)0,&l_838,(void*)0,(void*)0,&l_838},{&g_1047,&l_838,&g_1047,&l_838,&g_1047,&g_1047,&g_1047},{&g_1047,&l_838,&g_1047,&l_838,&l_838,&l_838,&g_1047},{&g_1047,&g_1047,&l_838,&l_838,&g_1047,&l_838,&l_838},{&g_1047,&g_1047,&g_1047,(void*)0,&g_1047,&g_1047,&g_1047}},{{&g_1047,&g_1047,&l_838,&g_1047,(void*)0,&l_838,&g_1047},{&g_1047,(void*)0,&g_1047,&l_838,&l_838,&l_838,&g_1047},{&l_838,&l_838,&l_838,&l_838,&g_1047,&l_838,&l_838},{&g_1047,&l_838,&g_1047,&g_1047,(void*)0,&l_838,&g_1047},{&l_838,&g_1047,&g_1047,&l_838,&g_1047,&l_838,&g_1047},{&l_838,&l_838,&l_838,&g_1047,&l_838,&l_838,&l_838},{(void*)0,(void*)0,&l_838,&g_1047,&l_838,&g_1047,(void*)0}},{{&g_1047,&g_1047,(void*)0,(void*)0,&g_1047,&g_1047,(void*)0},{&l_838,&g_1047,&l_838,&g_1047,&l_838,&l_838,&l_838},{&g_1047,&g_1047,&g_1047,&l_838,&l_838,&l_838,&l_838},{&g_1047,&g_1047,&g_1047,&l_838,&l_838,&g_1047,&l_838},{&l_838,&g_1047,&l_838,&l_838,&l_838,&l_838,(void*)0},{&g_1047,(void*)0,&g_1047,(void*)0,(void*)0,&l_838,&g_1047},{&l_838,&l_838,&g_1047,&g_1047,(void*)0,&l_838,&l_838}},{{&g_1047,&g_1047,&g_1047,&l_838,&l_838,&l_838,&l_838},{&l_838,&l_838,&l_838,&l_838,&l_838,&l_838,&l_838},{&l_838,&l_838,&l_838,&g_1047,&l_838,(void*)0,&l_838},{&l_838,(void*)0,(void*)0,&l_838,&l_838,&l_838,(void*)0},{&l_838,&g_1047,&g_1047,&l_838,&g_1047,&l_838,&l_838},{&l_838,&g_1047,&l_838,&l_838,&l_838,&g_1047,&l_838},{&g_1047,&g_1047,&l_838,&l_838,&l_838,&l_838,&g_1047}},{{&l_838,(void*)0,&l_838,&l_838,&g_1047,&l_838,&l_838},{&g_1047,&g_1047,&g_1047,&l_838,(void*)0,&g_1047,(void*)0},{&l_838,&l_838,&l_838,&l_838,(void*)0,&l_838,&l_838},{&g_1047,&g_1047,&g_1047,&l_838,&g_1047,&l_838,&g_1047},{&g_1047,&l_838,&g_1047,&g_1047,&g_1047,&l_838,&l_838},{&l_838,&l_838,&g_1047,&l_838,&g_1047,(void*)0,(void*)0},{&g_1047,&l_838,&l_838,&l_838,(void*)0,&g_1047,&l_838}}};
        uint16_t ** const *l_1081 = &g_1047;
        uint16_t ** const **l_1080 = &l_1081;
        uint16_t l_1129 = 0xD5F6L;
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_876[i][j] = (-9L);
        }
        if (g_73)
            goto lbl_835;
        if ((safe_rshift_func_uint8_t_u_u((((l_838 != ((*l_840) = l_838)) , ((safe_sub_func_int32_t_s_s(((safe_add_func_uint16_t_u_u(65535UL, (safe_rshift_func_int16_t_s_s(((((~(((0x4124L < (((safe_lshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u((!(*g_354)), 0x62L)) & (((((**g_614) = (**g_614)) != l_860) >= (((**g_522) = l_861) != (void*)0)) <= g_413)), (**l_818))), p_96)) | p_96) || p_96)) & (-1L)) != g_757[1])) , 1UL) & (*g_186)) == 0x34E7E85BL), 10)))) , (*p_97)), g_207)) <= 0x2526E636EA08C903LL)) , p_95), 5)))
        { /* block id: 361 */
            int32_t **l_862 = &l_825;
            (*l_862) = ((*l_818) = p_97);
            (*l_824) = (*p_97);
        }
        else
        { /* block id: 365 */
            uint32_t *l_866 = &g_6[2];
            uint32_t **l_865[9] = {&l_866,&l_866,&l_866,&l_866,&l_866,&l_866,&l_866,&l_866,&l_866};
            int32_t l_881 = (-1L);
            uint32_t l_885 = 6UL;
            int i;
            if (((p_95 == l_863) & (l_864 != (g_867 = p_97))))
            { /* block id: 367 */
                int64_t *** const *l_872 = &g_522;
                int32_t l_894[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_894[i] = (-3L);
                for (g_413 = 0; (g_413 <= 3); g_413 += 1)
                { /* block id: 370 */
                    uint64_t *l_880[9][2] = {{&g_175,&g_175},{&g_814,&g_175},{&g_175,&g_814},{&g_175,&g_175},{&g_814,&g_175},{&g_175,&g_814},{&g_175,&g_175},{&g_814,&g_814},{&g_814,&g_814}};
                    int16_t *l_884 = &g_160;
                    uint32_t l_895 = 0xEC549EAEL;
                    int8_t *l_896[3][1][6] = {{{(void*)0,&l_876[2][0],(void*)0,&l_876[2][0],(void*)0,&l_876[2][0]}},{{&l_876[1][0],&l_876[2][0],&l_876[1][0],&l_876[2][0],&l_876[1][0],&l_876[2][0]}},{{(void*)0,&l_876[2][0],(void*)0,&l_876[2][0],(void*)0,&l_876[2][0]}}};
                    uint8_t *l_897 = &g_319;
                    int32_t **l_898 = &l_826[2];
                    int i, j, k;
                    for (g_356 = 0; (g_356 <= 8); g_356 += 1)
                    { /* block id: 373 */
                        return l_864;
                    }
                    l_863 ^= (((-6L) || ((**g_523) = l_830[g_413])) , ((*l_823) = (((((safe_add_func_uint8_t_u_u(((((l_830[g_413] , ((void*)0 != l_872)) , (g_757[4] | 0x27173528L)) & ((void*)0 == l_873)) , g_843), g_319)) >= (*p_98)) || g_575) , (*g_524)) <= 0xC8B14D5E266298F3LL)));
                    (*l_898) = ((*l_818) = func_100(g_843, (l_830[g_413] ^= (safe_mul_func_uint16_t_u_u((l_876[1][0] >= ((((safe_add_func_uint64_t_u_u((l_881 = ((void*)0 == g_879[1])), ((0xFF15C188L || ((safe_mul_func_int16_t_s_s(((((*l_884) &= p_95) & l_885) | (safe_sub_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(((*l_897) |= ((((*l_822) |= (safe_mod_func_int64_t_s_s(((((safe_add_func_int8_t_s_s((l_876[1][0] , l_894[2]), l_876[1][0])) , (void*)0) != &l_861) ^ 247UL), l_895))) & p_96) <= 0xD8L)), 0)), 0xAD158F79L))), (*l_823))) , l_885)) >= l_885))) ^ 0x43L) >= p_95) < g_125)), p_96)))));
                }
            }
            else
            { /* block id: 387 */
                uint32_t *l_900 = &g_356;
                return l_900;
            }
            if ((*p_97))
                break;
        }
        for (l_828 = 2; (l_828 >= 0); l_828 -= 1)
        { /* block id: 394 */
            int8_t *l_903 = (void*)0;
            int8_t *l_904[8];
            int32_t l_905 = 0x5FB4046AL;
            uint64_t ***l_912 = &l_860;
            uint64_t **l_914 = (void*)0;
            uint64_t ***l_913 = &l_914;
            const uint64_t *l_928 = &g_814;
            const uint64_t **l_927[9];
            const uint64_t ***l_929 = (void*)0;
            const uint64_t ***l_930[1][1];
            int32_t l_934 = 0x8A9C490DL;
            uint32_t l_997 = 0UL;
            uint16_t ***l_1050[9] = {&l_838,&l_838,&l_838,&l_838,&l_838,&l_838,&l_838,&l_838,&l_838};
            uint32_t l_1075 = 4294967289UL;
            int i, j;
            for (i = 0; i < 8; i++)
                l_904[i] = &l_876[1][0];
            for (i = 0; i < 9; i++)
                l_927[i] = &l_928;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                    l_930[i][j] = (void*)0;
            }
            (*l_818) = func_100(((g_936 = func_103((safe_mul_func_int8_t_s_s((g_232[(l_828 + 6)] , (l_905 = l_876[1][0])), (safe_div_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s((((*l_912) = ((*g_615) = (*g_615))) != ((*l_913) = (void*)0)), 1)), (((++(*p_98)) != (safe_add_func_uint32_t_u_u((safe_div_func_uint8_t_u_u(g_11, (safe_sub_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(g_232[(l_828 + 6)], (l_934 = (safe_lshift_func_int8_t_s_s((l_876[1][0] | (***g_522)), ((g_931 = l_927[8]) == (void*)0)))))), 0x4F6CL)))), g_551))) != (**g_523)))), 18446744073709551615UL)))), l_935[0][6][1])) != (void*)0), l_935[0][6][1]);
            for (g_207 = 0; (g_207 <= 0); g_207 += 1)
            { /* block id: 406 */
                int32_t l_958 = 0L;
                uint8_t *l_959[8][1] = {{&g_413},{&g_413},{&g_125},{&g_413},{&g_413},{&g_125},{&g_413},{&g_413}};
                int32_t l_960 = 0L;
                int i, j, k;
                if (l_827[(g_207 + 4)][(g_207 + 2)][(g_207 + 1)])
                    break;
                (*l_823) = (3L == ((safe_mul_func_int8_t_s_s(g_68[(g_207 + 2)][(g_207 + 2)][(g_207 + 1)], (((safe_div_func_int32_t_s_s((((g_232[(l_828 + 6)] , (safe_mul_func_uint8_t_u_u(0x0BL, (safe_mod_func_int16_t_s_s((~((l_947 == (((l_960 &= (((safe_div_func_int8_t_s_s(((safe_mul_func_int8_t_s_s(0xB9L, (safe_div_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(((safe_div_func_uint64_t_u_u(((l_827[(g_207 + 4)][(g_207 + 2)][(g_207 + 1)] & (p_95 , (-6L))) > (*g_354)), 3L)) , l_958), p_95)), l_863)))) >= p_96), p_96)) && 0xB8438E53L) && p_95)) >= l_827[(g_207 + 4)][(g_207 + 2)][(g_207 + 1)]) , &l_930[0][0])) , p_96)), 0xD6CAL))))) , 0x6FA1L) < p_96), 0x26B8CF89L)) >= 0xB20DL) & p_95))) == p_96));
            }
        }
    }
    return &g_68[2][0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_68 g_6 g_127 g_131 g_125 g_73 g_614 g_319 g_356 g_524 g_225 g_526 g_207 g_232 g_354 g_414 g_575 g_523 g_175
 * writes: g_73 g_125 g_127 g_131 g_414 g_319 g_68 g_232 g_225 g_160
 */
static int32_t * func_100(int32_t  p_101, uint32_t  p_102)
{ /* block id: 30 */
    uint64_t l_108 = 18446744073709551606UL;
    uint32_t * const l_111 = &g_68[5][4][0];
    uint32_t *l_612[4] = {&g_551,&g_551,&g_551,&g_551};
    uint32_t **l_611 = &l_612[0];
    int32_t l_632 = 0L;
    int64_t **l_641 = &g_524;
    uint8_t l_680 = 0x9FL;
    int32_t l_720 = (-3L);
    int32_t l_723 = (-1L);
    int32_t l_724 = (-1L);
    int32_t l_726 = (-7L);
    int32_t l_727 = 0xF40DD8B7L;
    int32_t l_728 = 0L;
    int32_t l_731 = (-8L);
    int32_t l_733 = (-8L);
    int32_t l_734 = 0xFB293F52L;
    int32_t l_735[3];
    uint16_t **l_740 = (void*)0;
    int32_t *l_781 = &g_414[0][0][1];
    uint8_t l_815 = 255UL;
    int i;
    for (i = 0; i < 3; i++)
        l_735[i] = 0x45A026E6L;
    if ((((*l_611) = func_103(((safe_sub_func_int8_t_s_s((((p_101 ^ 0x2714BD4865626A28LL) > (l_108 > (safe_lshift_func_uint16_t_u_u((8UL || g_11), (l_111 == &p_102))))) != (safe_unary_minus_func_uint64_t_u(0xAD8B3B4CC26152D7LL))), (((g_68[2][0][0] != 0x94L) | l_108) & 65530UL))) & 0L), p_101)) == (void*)0))
    { /* block id: 280 */
        int32_t *l_616 = (void*)0;
        int32_t *l_617 = &g_73;
        int32_t *l_618 = &g_414[0][3][0];
        (*l_618) = ((*l_617) = (+(g_614 == (void*)0)));
    }
    else
    { /* block id: 283 */
        uint8_t *l_619 = &g_319;
        int16_t l_624 = 0xB8E3L;
        uint8_t *l_631[4];
        uint32_t l_633 = 0xEE3A12C5L;
        int32_t *l_634 = &g_73;
        int32_t **l_635 = &l_634;
        int64_t **l_640 = &g_524;
        int16_t *l_685 = &g_160;
        int32_t l_711[7][5] = {{1L,3L,0x6CFE78F3L,(-7L),1L},{1L,1L,(-1L),1L,4L},{0x91BBABF5L,0x6CFE78F3L,1L,3L,1L},{1L,1L,1L,(-1L),1L},{1L,0x8DF72612L,1L,0xEA2C5A09L,0x13BBDA33L},{0x91BBABF5L,0x4826A379L,4L,(-1L),(-7L)},{1L,0x8DF72612L,0x8DF72612L,1L,(-2L)}};
        uint64_t *l_746 = &l_108;
        const uint8_t *l_754[6][2][8] = {{{(void*)0,&g_125,(void*)0,(void*)0,(void*)0,(void*)0,&g_125,(void*)0},{&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125,(void*)0,(void*)0}},{{&g_125,&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_125,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_125,(void*)0,(void*)0,&g_125,(void*)0,&g_125,(void*)0},{(void*)0,&g_125,(void*)0,(void*)0,(void*)0,(void*)0,&g_125,(void*)0}},{{&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125,(void*)0,(void*)0},{&g_125,&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_125,(void*)0,(void*)0,(void*)0},{(void*)0,&g_125,(void*)0,(void*)0,&g_125,(void*)0,&g_125,(void*)0}},{{(void*)0,&g_125,(void*)0,(void*)0,(void*)0,(void*)0,&g_125,(void*)0},{&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125,(void*)0,(void*)0}}};
        int16_t l_775 = 0xF6BCL;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_631[i] = &g_125;
lbl_817:
        (*l_635) = func_103(p_102, (((--(*l_619)) & (((*l_634) ^= (((((safe_mul_func_int16_t_s_s(l_108, (l_108 ^ (l_624 | ((((safe_unary_minus_func_int32_t_s(((safe_rshift_func_int8_t_s_s(((~l_108) , (safe_lshift_func_uint8_t_u_u((g_356 ^ p_101), (l_632 = (p_102 ^ p_101))))), 7)) >= p_102))) <= 0xCE61L) || l_108) , (*g_524)))))) && l_633) < l_108) ^ p_101) , g_526)) || g_207)) , l_632));
        (*l_635) = func_103(((p_101 != ((void*)0 == &g_526)) > (safe_lshift_func_int8_t_s_s((safe_div_func_int32_t_s_s((l_640 == l_641), (((g_232[8] ^ (0L || (*g_354))) , ((safe_add_func_int64_t_s_s(((((**g_523) = ((safe_add_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u(((*g_354) ^= ((safe_add_func_int8_t_s_s(p_101, g_6[2])) | p_102)), g_414[0][0][1])) > g_6[2]), g_68[5][7][1])) | g_575)) && 0xC8F62102E3ADFD4ALL) == (-4L)), 1UL)) == 0x45CEL)) ^ g_175))), 1))), p_101);
        for (l_108 = (-29); (l_108 < 5); l_108++)
        { /* block id: 293 */
            int8_t l_657[9] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
            uint32_t *l_679 = &g_403;
            int32_t l_682[6];
            int8_t l_706 = (-1L);
            int32_t l_729[4];
            int8_t *l_752[8] = {&l_706,&l_657[7],&l_706,&l_706,&l_657[7],&l_706,&l_706,&l_657[7]};
            int8_t **l_751 = &l_752[2];
            int32_t l_816[4][1][9] = {{{0x2A486789L,(-8L),(-8L),0x2A486789L,(-8L),(-8L),0x2A486789L,(-8L),(-8L)}},{{0xEEDF23FCL,(-6L),(-8L),0x9CDAC833L,(-8L),(-6L),0xEEDF23FCL,(-6L),(-8L)}},{{0x2A486789L,(-8L),(-8L),0x2A486789L,(-8L),(-8L),0x2A486789L,(-8L),(-8L)}},{{0xEEDF23FCL,(-6L),(-8L),0x9CDAC833L,(-8L),(-6L),0xEEDF23FCL,(-6L),(-8L)}}};
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_682[i] = (-3L);
            for (i = 0; i < 4; i++)
                l_729[i] = 1L;
            for (g_160 = 0; (g_160 == (-13)); --g_160)
            { /* block id: 296 */
                int32_t *l_654 = &g_414[0][0][2];
                return l_654;
            }
        }
        if (l_632)
            goto lbl_817;
    }
    return &g_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_127 g_131 g_125 g_68 g_73
 * writes: g_73 g_125 g_127 g_131
 */
static uint32_t * func_103(uint32_t  p_104, uint8_t  p_105)
{ /* block id: 31 */
    int32_t *l_115[10][5] = {{(void*)0,&g_11,&g_11,&g_11,(void*)0},{&g_2,(void*)0,(void*)0,&g_73,&g_73},{&g_11,&g_73,(void*)0,(void*)0,&g_73},{&g_73,&g_11,&g_11,(void*)0,&g_73},{&g_11,(void*)0,(void*)0,&g_73,(void*)0},{&g_73,&g_73,&g_2,&g_73,&g_73},{&g_11,&g_73,&g_11,&g_11,&g_11},{&g_73,&g_11,&g_73,&g_11,&g_73},{&g_11,&g_73,&g_11,&g_73,&g_73},{&g_2,&g_73,&g_73,&g_2,&g_73}};
    int8_t l_118 = 1L;
    uint8_t *l_123 = (void*)0;
    uint8_t *l_124 = &g_125;
    uint16_t *l_126 = &g_127;
    int16_t *l_159 = &g_160;
    int16_t l_212[7];
    const int64_t *l_245[3];
    uint32_t l_341 = 4294967288UL;
    int64_t l_391 = 2L;
    int64_t **l_449 = (void*)0;
    int8_t *l_460 = (void*)0;
    int8_t l_598 = (-6L);
    int i, j;
    for (i = 0; i < 7; i++)
        l_212[i] = 0x7A14L;
    for (i = 0; i < 3; i++)
        l_245[i] = &g_225;
    if (((safe_mul_func_uint16_t_u_u((p_105 & ((g_73 = p_104) <= (safe_lshift_func_int8_t_s_u(p_105, 6)))), (l_118 & (((safe_add_func_uint16_t_u_u(((*l_126) |= ((g_6[2] & ((*l_124) = (safe_sub_func_uint64_t_u_u(18446744073709551606UL, p_105)))) , (l_123 == l_123))), 0x06A3L)) , p_104) & g_6[2])))) & p_105))
    { /* block id: 35 */
        const int64_t l_139 = 0xEF898209D2E6782ALL;
        int32_t *l_142[10] = {&g_131,&g_131,&g_131,&g_131,&g_131,&g_131,&g_131,&g_131,&g_131,&g_131};
        int32_t *l_147 = (void*)0;
        int i;
        for (g_73 = (-7); (g_73 != (-16)); g_73 = safe_sub_func_uint64_t_u_u(g_73, 6))
        { /* block id: 38 */
            int32_t *l_130 = &g_131;
            int32_t **l_143 = &l_142[6];
            int32_t **l_146 = &l_115[8][0];
            int32_t l_148 = 0x53BE29DAL;
            int32_t *l_149 = &l_148;
            (*l_149) = (((*l_130) &= ((void*)0 == &g_125)) , (0xDEB7949DL <= ((safe_lshift_func_uint8_t_u_u(0x52L, ((*l_124) |= ((safe_rshift_func_uint16_t_u_s((safe_unary_minus_func_uint8_t_u(((((safe_rshift_func_uint16_t_u_s((l_139 , (255UL <= (((((*l_143) = l_142[6]) != &g_131) > ((safe_rshift_func_uint8_t_u_s((((*l_146) = &g_2) != l_147), 3)) <= 1UL)) < l_148))), 14)) && p_104) & 4294967287UL) < l_118))), 10)) , 251UL)))) , g_68[2][0][0])));
        }
    }
    else
    { /* block id: 45 */
        g_73 |= g_68[3][7][0];
    }
    return &g_68[2][0][0];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_9[i][j], "g_9[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_68[i][j][k], "g_68[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    transparent_crc(g_207, "g_207", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_232[i], "g_232[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_319, "g_319", print_hash_value);
    transparent_crc(g_356, "g_356", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_380[i][j], "g_380[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_403, "g_403", print_hash_value);
    transparent_crc(g_413, "g_413", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_414[i][j][k], "g_414[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_526, "g_526", print_hash_value);
    transparent_crc(g_551, "g_551", print_hash_value);
    transparent_crc(g_575, "g_575", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_757[i], "g_757[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_814, "g_814", print_hash_value);
    transparent_crc(g_843, "g_843", print_hash_value);
    transparent_crc(g_933, "g_933", print_hash_value);
    transparent_crc(g_937, "g_937", print_hash_value);
    transparent_crc(g_1013, "g_1013", print_hash_value);
    transparent_crc(g_1014, "g_1014", print_hash_value);
    transparent_crc(g_1017, "g_1017", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1018[i], "g_1018[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1019[i][j], "g_1019[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1020, "g_1020", print_hash_value);
    transparent_crc(g_1021, "g_1021", print_hash_value);
    transparent_crc(g_1022, "g_1022", print_hash_value);
    transparent_crc(g_1023, "g_1023", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1024[i], "g_1024[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1025, "g_1025", print_hash_value);
    transparent_crc(g_1026, "g_1026", print_hash_value);
    transparent_crc(g_1027, "g_1027", print_hash_value);
    transparent_crc(g_1028, "g_1028", print_hash_value);
    transparent_crc(g_1029, "g_1029", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1030[i][j][k], "g_1030[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1031, "g_1031", print_hash_value);
    transparent_crc(g_1032, "g_1032", print_hash_value);
    transparent_crc(g_1033, "g_1033", print_hash_value);
    transparent_crc(g_1034, "g_1034", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1035[i], "g_1035[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1036, "g_1036", print_hash_value);
    transparent_crc(g_1037, "g_1037", print_hash_value);
    transparent_crc(g_1038, "g_1038", print_hash_value);
    transparent_crc(g_1039, "g_1039", print_hash_value);
    transparent_crc(g_1040, "g_1040", print_hash_value);
    transparent_crc(g_1041, "g_1041", print_hash_value);
    transparent_crc(g_1042, "g_1042", print_hash_value);
    transparent_crc(g_1043, "g_1043", print_hash_value);
    transparent_crc(g_1044, "g_1044", print_hash_value);
    transparent_crc(g_1228, "g_1228", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1229[i], "g_1229[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1320, "g_1320", print_hash_value);
    transparent_crc(g_1337, "g_1337", print_hash_value);
    transparent_crc(g_1341, "g_1341", print_hash_value);
    transparent_crc(g_1397, "g_1397", print_hash_value);
    transparent_crc(g_1405, "g_1405", print_hash_value);
    transparent_crc(g_1706, "g_1706", print_hash_value);
    transparent_crc(g_1762, "g_1762", print_hash_value);
    transparent_crc(g_1771, "g_1771", print_hash_value);
    transparent_crc(g_1829, "g_1829", print_hash_value);
    transparent_crc(g_1917, "g_1917", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2033[i], "g_2033[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_2034[i][j], "g_2034[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2076, "g_2076", print_hash_value);
    transparent_crc(g_2096, "g_2096", print_hash_value);
    transparent_crc(g_2177, "g_2177", print_hash_value);
    transparent_crc(g_2274, "g_2274", print_hash_value);
    transparent_crc(g_2710, "g_2710", print_hash_value);
    transparent_crc(g_2780, "g_2780", print_hash_value);
    transparent_crc(g_2971, "g_2971", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_3264[i], "g_3264[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3333, "g_3333", print_hash_value);
    transparent_crc(g_3577, "g_3577", print_hash_value);
    transparent_crc(g_3738, "g_3738", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 814
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 188
   depth: 2, occurrence: 61
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 15, occurrence: 3
   depth: 16, occurrence: 1
   depth: 17, occurrence: 4
   depth: 18, occurrence: 1
   depth: 19, occurrence: 4
   depth: 21, occurrence: 5
   depth: 22, occurrence: 5
   depth: 24, occurrence: 4
   depth: 25, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 4
   depth: 30, occurrence: 1
   depth: 31, occurrence: 3
   depth: 32, occurrence: 3
   depth: 35, occurrence: 3
   depth: 37, occurrence: 1
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 749

XXX times a variable address is taken: 1972
XXX times a pointer is dereferenced on RHS: 505
breakdown:
   depth: 1, occurrence: 403
   depth: 2, occurrence: 70
   depth: 3, occurrence: 24
   depth: 4, occurrence: 8
XXX times a pointer is dereferenced on LHS: 490
breakdown:
   depth: 1, occurrence: 439
   depth: 2, occurrence: 33
   depth: 3, occurrence: 15
   depth: 4, occurrence: 3
XXX times a pointer is compared with null: 77
XXX times a pointer is compared with address of another variable: 30
XXX times a pointer is compared with another pointer: 26
XXX times a pointer is qualified to be dereferenced: 9355

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 3309
   level: 2, occurrence: 487
   level: 3, occurrence: 176
   level: 4, occurrence: 64
   level: 5, occurrence: 1
XXX number of pointers point to pointers: 367
XXX number of pointers point to scalars: 382
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.8
XXX average alias set size: 1.61

XXX times a non-volatile is read: 3093
XXX times a non-volatile is write: 1442
XXX times a volatile is read: 56
XXX    times read thru a pointer: 17
XXX times a volatile is write: 23
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 1.46e+03
XXX percentage of non-volatile access: 98.3

XXX forward jumps: 2
XXX backward jumps: 12

XXX stmts: 213
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 27
   depth: 2, occurrence: 38
   depth: 3, occurrence: 36
   depth: 4, occurrence: 39
   depth: 5, occurrence: 48

XXX percentage a fresh-made variable is used: 15.8
XXX percentage an existing variable is used: 84.2
********************* end of statistics **********************/

