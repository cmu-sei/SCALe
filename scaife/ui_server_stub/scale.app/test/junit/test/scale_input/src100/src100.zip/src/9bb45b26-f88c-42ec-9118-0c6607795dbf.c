/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      479075574
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   unsigned f0 : 9;
   int8_t * f1;
   volatile uint16_t  f2;
   volatile int8_t  f3;
};

union U1 {
   const volatile int8_t  f0;
   int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 2L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0xD3F46721L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 1L;/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = (-9L);
static volatile int32_t g_9 = 0x72C25FCCL;/* VOLATILE GLOBAL g_9 */
static volatile int32_t g_10 = 0x012E1DFEL;/* VOLATILE GLOBAL g_10 */
static int32_t g_11 = 3L;
static int32_t g_14 = 0x6BC3EC3DL;
static int32_t g_17[1] = {0x714F98CAL};
static int32_t g_22 = (-4L);
static int8_t g_60 = 0x13L;
static int8_t *g_59 = &g_60;
static uint32_t g_80 = 18446744073709551611UL;
static uint32_t g_95 = 0x69E5F9C6L;
static uint32_t *g_94 = &g_95;
static const volatile union U0 g_108 = {0UL};/* VOLATILE GLOBAL g_108 */
static int16_t g_115 = 0x4D54L;
static int32_t g_120 = 1L;
static volatile int8_t g_122 = (-6L);/* VOLATILE GLOBAL g_122 */
static volatile uint32_t g_123 = 0xCEE8D80EL;/* VOLATILE GLOBAL g_123 */
static volatile union U0 g_134[1] = {{0xFF246F76L}};
static int16_t *g_139 = &g_115;
static int16_t **g_138 = &g_139;
static uint8_t g_144[3][1][9] = {{{0x6FL,255UL,0x5EL,255UL,0x6FL,0UL,246UL,0UL,0UL}},{{255UL,0x83L,0x6FL,0UL,0x6FL,0x83L,255UL,0xFAL,0x79L}},{{1UL,0x79L,255UL,0UL,0xFAL,0UL,255UL,0x79L,1UL}}};
static int8_t g_147[2][5][9] = {{{0L,4L,0x4EL,0xC5L,0x4EL,4L,0L,0x35L,0xCFL},{0L,0L,7L,4L,0x68L,(-4L),0xEAL,1L,0x0AL},{0xBEL,0x9BL,0xDEL,0x68L,1L,0x57L,0x57L,1L,0x68L},{0x35L,0xBEL,0x35L,7L,0x4EL,0x57L,0xEAL,0x9BL,0L},{0x4EL,0x68L,0x4EL,0L,4L,0xDEL,0xBEL,0L,3L}},{{0x57L,0xCFL,0xC8L,7L,7L,0xC8L,0xCFL,0x57L,0x35L},{0x0AL,0xCFL,0xB4L,0x68L,0xC5L,3L,0x4EL,0x35L,1L},{0xCFL,0x68L,0x9BL,0xC8L,0x35L,0L,0L,0L,0x35L},{0xEAL,0xBEL,0xBEL,0xEAL,0xC8L,4L,0L,0x0AL,3L},{0xC8L,0x9BL,0x68L,0xCFL,0xBEL,0xB4L,0x4EL,0xDEL,0L}}};
static volatile int32_t *g_154[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const int16_t *g_164 = (void*)0;
static const int16_t **g_163 = &g_164;
static const int16_t ** volatile *g_162 = &g_163;
static int32_t *g_171[3][5] = {{&g_14,&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14,&g_14}};
static int32_t ** volatile g_170 = &g_171[1][2];/* VOLATILE GLOBAL g_170 */
static const uint8_t g_186 = 0x07L;
static int16_t g_205 = 0xFB61L;
static uint32_t g_235 = 0x4722C89EL;
static int32_t ** volatile g_236[7] = {(void*)0,&g_171[0][0],&g_171[0][0],(void*)0,&g_171[0][0],&g_171[0][0],(void*)0};
static int32_t ** volatile g_253 = &g_171[0][2];/* VOLATILE GLOBAL g_253 */
static uint16_t g_290 = 65535UL;
static uint32_t g_293 = 0x084801C5L;
static union U1 g_294 = {0xA6L};/* VOLATILE GLOBAL g_294 */
static int32_t ** volatile g_304 = &g_171[0][3];/* VOLATILE GLOBAL g_304 */
static const union U1 g_316 = {0x46L};/* VOLATILE GLOBAL g_316 */
static int16_t g_317 = 0xA42AL;
static uint8_t g_353 = 0x75L;
static int32_t g_357 = 1L;
static union U0 g_359 = {0xD1AA81CAL};/* VOLATILE GLOBAL g_359 */
static uint64_t g_407 = 0x8728338B1BC0AB81LL;
static uint8_t *g_411 = &g_353;
static uint8_t * volatile *g_410[8] = {&g_411,&g_411,&g_411,&g_411,&g_411,&g_411,&g_411,&g_411};
static uint16_t g_512 = 65535UL;
static int32_t * volatile g_514 = &g_17[0];/* VOLATILE GLOBAL g_514 */
static volatile int8_t g_544 = 4L;/* VOLATILE GLOBAL g_544 */
static union U1 g_570[6] = {{0x08L},{0x08L},{0x08L},{0x08L},{0x08L},{0x08L}};
static int64_t g_661 = 0L;
static volatile union U1 g_719 = {-1L};/* VOLATILE GLOBAL g_719 */
static union U1 g_730 = {1L};/* VOLATILE GLOBAL g_730 */
static const uint16_t *g_767[4][7] = {{&g_290,&g_290,&g_290,&g_290,&g_290,&g_290,&g_290},{(void*)0,&g_290,(void*)0,&g_512,(void*)0,&g_512,(void*)0},{&g_290,&g_290,&g_512,&g_290,&g_290,&g_512,&g_290},{(void*)0,&g_512,(void*)0,&g_290,(void*)0,&g_512,(void*)0}};
static const uint16_t **g_766 = &g_767[0][4];
static const uint16_t *** volatile g_765 = &g_766;/* VOLATILE GLOBAL g_765 */
static const int32_t *g_789 = &g_6;
static const int32_t ** volatile g_788[10] = {&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789};
static const int32_t ** volatile g_790 = &g_789;/* VOLATILE GLOBAL g_790 */
static const int32_t ** volatile g_793 = &g_789;/* VOLATILE GLOBAL g_793 */
static uint32_t g_814 = 0xEB01C3BEL;
static union U1 ** volatile g_842 = (void*)0;/* VOLATILE GLOBAL g_842 */
static union U1 *g_844[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 ** volatile g_843 = &g_844[2];/* VOLATILE GLOBAL g_843 */
static volatile union U1 g_851 = {0x50L};/* VOLATILE GLOBAL g_851 */
static union U1 g_880 = {-7L};/* VOLATILE GLOBAL g_880 */
static int64_t g_882 = 0L;
static uint16_t *g_978[4] = {&g_290,&g_290,&g_290,&g_290};
static uint16_t **g_977[8][4][3] = {{{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[2],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]}},{{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],(void*)0},{&g_978[1],&g_978[2],&g_978[1]}},{{(void*)0,&g_978[1],&g_978[1]},{&g_978[1],&g_978[2],&g_978[1]},{&g_978[1],&g_978[1],(void*)0},{&g_978[1],&g_978[1],&g_978[1]}},{{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[2],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],(void*)0,&g_978[1]}},{{&g_978[1],&g_978[1],(void*)0},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]}},{{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],(void*)0,&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[2],&g_978[1]}},{{&g_978[1],&g_978[1],(void*)0},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],&g_978[2],&g_978[1]}},{{&g_978[1],&g_978[1],&g_978[1]},{&g_978[1],(void*)0,&g_978[1]},{&g_978[1],&g_978[1],(void*)0},{&g_978[1],&g_978[1],&g_978[1]}}};
static uint16_t ***g_976 = &g_977[7][0][0];
static uint64_t g_1021 = 0xA5C6A23EC92004BELL;
static uint64_t g_1024 = 0x1704CB66E30241EBLL;
static union U0 g_1047[7][10][3] = {{{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}}},{{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}}},{{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}}},{{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}}},{{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}}},{{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}}},{{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}},{{0xF5DD5776L},{0UL},{0UL}},{{0x2CFBCAD9L},{0x57D90686L},{1UL}},{{4UL},{0xF5DD5776L},{0UL}},{{0x63C3EC00L},{1UL},{0x63C3EC00L}},{{4UL},{0UL},{0x5989C5BCL}},{{0x2CFBCAD9L},{1UL},{1UL}},{{0xF5DD5776L},{0xF5DD5776L},{0x5989C5BCL}},{{0x63C3EC00L},{0x57D90686L},{0x63C3EC00L}}}};
static union U1 ** volatile g_1075 = &g_844[0];/* VOLATILE GLOBAL g_1075 */
static uint8_t **g_1079[3][10] = {{(void*)0,&g_411,&g_411,(void*)0,(void*)0,&g_411,&g_411,(void*)0,(void*)0,&g_411},{(void*)0,(void*)0,&g_411,&g_411,(void*)0,(void*)0,&g_411,&g_411,(void*)0,(void*)0},{(void*)0,&g_411,&g_411,(void*)0,(void*)0,&g_411,&g_411,(void*)0,(void*)0,&g_411}};
static uint8_t ***g_1078[8][6] = {{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]},{&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3],&g_1079[2][3]}};
static int32_t **g_1102 = &g_171[2][4];
static int32_t *** volatile g_1101[9] = {&g_1102,&g_1102,&g_1102,&g_1102,&g_1102,&g_1102,&g_1102,&g_1102,&g_1102};
static uint8_t g_1137 = 1UL;
static volatile union U1 g_1144 = {0xAAL};/* VOLATILE GLOBAL g_1144 */
static uint32_t *g_1153[5] = {&g_814,&g_814,&g_814,&g_814,&g_814};
static uint32_t **g_1152 = &g_1153[1];
static volatile union U1 g_1192 = {-1L};/* VOLATILE GLOBAL g_1192 */
static union U1 g_1205 = {0x9FL};/* VOLATILE GLOBAL g_1205 */
static union U1 g_1219 = {-1L};/* VOLATILE GLOBAL g_1219 */
static const uint32_t g_1272 = 4294967295UL;
static const union U0 *g_1321 = &g_1047[4][8][2];
static int8_t **g_1337[7] = {&g_59,&g_59,&g_59,&g_59,&g_59,&g_59,&g_59};
static int8_t *** volatile g_1336 = &g_1337[4];/* VOLATILE GLOBAL g_1336 */
static union U1 g_1353 = {1L};/* VOLATILE GLOBAL g_1353 */
static volatile union U1 g_1354 = {0xC2L};/* VOLATILE GLOBAL g_1354 */
static union U1 ** volatile g_1416 = &g_844[2];/* VOLATILE GLOBAL g_1416 */
static volatile union U1 g_1429 = {0x42L};/* VOLATILE GLOBAL g_1429 */
static union U1 g_1434 = {0x91L};/* VOLATILE GLOBAL g_1434 */
static union U1 g_1448 = {5L};/* VOLATILE GLOBAL g_1448 */
static union U1 g_1449[4] = {{0xBAL},{0xBAL},{0xBAL},{0xBAL}};
static union U0 g_1469 = {0xB60D0897L};/* VOLATILE GLOBAL g_1469 */
static union U1 g_1486 = {9L};/* VOLATILE GLOBAL g_1486 */


/* --- FORWARD DECLARATIONS --- */
static union U1  func_1(void);
static int32_t * func_36(int32_t * p_37, int8_t  p_38, int8_t * p_39, int8_t  p_40);
static int32_t * func_41(int32_t * p_42, int8_t * p_43, int32_t  p_44, int32_t * p_45, int16_t  p_46);
static int32_t * func_47(const int32_t * p_48, const int32_t  p_49);
static const int32_t * func_50(const int32_t  p_51, uint16_t  p_52, uint8_t  p_53, int64_t  p_54);
static int64_t  func_55(int8_t * p_56, uint16_t  p_57, int8_t  p_58);
static int64_t  func_61(int8_t * const  p_62, int8_t * p_63, int8_t * const  p_64);
static int8_t * func_66(const int8_t * p_67, int8_t  p_68, int8_t  p_69);
static int32_t * func_71(const uint16_t  p_72, int32_t * p_73, int8_t * p_74);
static int16_t  func_85(int64_t  p_86, const uint64_t  p_87, uint32_t * p_88, uint32_t  p_89);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_11 g_14 g_17 g_138 g_139 g_115 g_1144 g_108 g_514 g_1152 g_95 g_661 g_294.f1 g_59 g_60 g_171 g_235 g_411 g_353 g_1024 g_793 g_789 g_290 g_1192 g_1153 g_814 g_1047 g_1205 g_253 g_570.f0 g_144 g_304 g_1219 g_1144.f1 g_882 g_512 g_790 g_1336 g_1321 g_80 g_1353 g_170 g_205 g_1448 g_1449 g_1102 g_1469 g_1353.f1 g_1486
 * writes: g_6 g_11 g_14 g_17 g_661 g_235 g_1024 g_353 g_882 g_512 g_1337 g_60 g_80 g_205 g_115
 */
static union U1  func_1(void)
{ /* block id: 0 */
    uint16_t l_23 = 8UL;
    int8_t * const l_65[9] = {&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60};
    const int64_t l_1099 = (-1L);
    uint8_t l_1107 = 0x8AL;
    int32_t l_1122 = 9L;
    uint32_t * const *l_1154 = (void*)0;
    int32_t **l_1155 = &g_171[1][2];
    uint8_t **l_1164 = &g_411;
    int8_t l_1190 = 0x25L;
    int16_t l_1280 = 0x5940L;
    int32_t l_1334 = 0x737F4552L;
    int8_t **l_1335 = &g_59;
    int16_t ** const *l_1346 = &g_138;
    const uint16_t l_1367 = 0x05FBL;
    const int32_t *l_1369 = (void*)0;
    uint64_t l_1430 = 0x8D5097E2CCF884AFLL;
    int64_t *l_1465[3];
    uint64_t *l_1468 = &l_1430;
    uint64_t *l_1482 = &g_1024;
    uint32_t l_1485 = 0x074DD89EL;
    int i;
    for (i = 0; i < 3; i++)
        l_1465[i] = &g_661;
    for (g_6 = (-24); (g_6 <= (-10)); g_6 = safe_add_func_uint64_t_u_u(g_6, 6))
    { /* block id: 3 */
        uint16_t l_27[8] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL};
        int32_t l_30 = 0L;
        const int8_t *l_70 = &g_60;
        int32_t l_1089 = 6L;
        int32_t l_1105 = 0x516C6898L;
        int32_t **l_1156 = &g_171[1][3];
        int32_t l_1191[8][6][3] = {{{0xD5DD46A3L,0xA245BCC0L,0x2B175901L},{0L,0x0CAC5B6AL,(-7L)},{0L,0xA245BCC0L,0xA1A80082L},{(-7L),0xAEB8A862L,0L},{0L,0x4AA5DCD6L,0L},{0L,(-1L),0L}},{{0xD5DD46A3L,1L,0xA1A80082L},{(-1L),(-1L),(-7L)},{0xA1A80082L,0x4AA5DCD6L,0x2B175901L},{(-1L),0xAEB8A862L,(-1L)},{0xD5DD46A3L,0xA245BCC0L,0x2B175901L},{0L,0x0CAC5B6AL,(-7L)}},{{0L,0xA245BCC0L,0xA1A80082L},{(-7L),0xAEB8A862L,0L},{0L,0x4AA5DCD6L,0L},{0L,(-1L),0L},{0xD5DD46A3L,1L,0xA1A80082L},{(-1L),(-1L),(-7L)}},{{0xA1A80082L,0x4AA5DCD6L,0x2B175901L},{(-1L),0xAEB8A862L,(-1L)},{0xD5DD46A3L,0xA245BCC0L,0x2B175901L},{0L,0x0CAC5B6AL,(-7L)},{0L,0xA245BCC0L,0xA1A80082L},{(-7L),0xAEB8A862L,0L}},{{0L,0x4AA5DCD6L,0L},{0L,(-1L),0L},{0xD5DD46A3L,1L,0xA1A80082L},{(-1L),(-1L),(-7L)},{0xA1A80082L,0x4AA5DCD6L,0x2B175901L},{(-1L),0xAEB8A862L,(-1L)}},{{0xD5DD46A3L,0xA245BCC0L,0x2B175901L},{0L,0x0CAC5B6AL,(-7L)},{0L,0xA245BCC0L,0xA1A80082L},{(-7L),0xAEB8A862L,0L},{0L,0x4AA5DCD6L,0L},{0L,(-1L),0L}},{{0xD5DD46A3L,1L,0xA1A80082L},{(-1L),(-1L),(-7L)},{0xA1A80082L,0x4AA5DCD6L,0x2B175901L},{(-1L),0xAEB8A862L,(-1L)},{0xD5DD46A3L,0xA245BCC0L,0x2B175901L},{0L,0x0CAC5B6AL,(-7L)}},{{0L,0xA245BCC0L,0xA1A80082L},{(-7L),0xAEB8A862L,0L},{0L,0x4AA5DCD6L,0L},{0L,(-1L),0L},{0xD5DD46A3L,1L,0xA1A80082L},{(-1L),(-1L),(-7L)}}};
        uint8_t l_1204 = 0xAEL;
        int16_t ***l_1216[6][8][2] = {{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}},{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}},{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}},{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}},{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}},{{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138},{&g_138,&g_138}}};
        uint32_t l_1238 = 0xC867A3E0L;
        int64_t l_1239 = (-6L);
        int8_t l_1290 = (-5L);
        int i, j, k;
        for (g_11 = 0; (g_11 < (-30)); --g_11)
        { /* block id: 6 */
            int16_t l_26 = 9L;
            for (g_14 = 0; (g_14 <= 0); g_14 = safe_add_func_int64_t_s_s(g_14, 7))
            { /* block id: 9 */
                for (g_17[0] = 0; (g_17[0] >= (-23)); g_17[0] = safe_sub_func_int16_t_s_s(g_17[0], 7))
                { /* block id: 12 */
                    int32_t *l_20 = (void*)0;
                    int32_t *l_21[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_21[i] = &g_22;
                    --l_23;
                    ++l_27[7];
                }
            }
            l_30 = l_23;
        }
        for (g_14 = 0; (g_14 != (-5)); --g_14)
        { /* block id: 21 */
            uint8_t l_768 = 0xF2L;
            int32_t *l_837[9] = {&g_6,&g_11,&g_6,&g_6,&g_11,&g_6,&g_6,&g_11,&g_6};
            uint32_t *l_1132 = &g_235;
            uint16_t *l_1151 = &l_23;
            int32_t *l_1230 = &l_1089;
            uint16_t *l_1249 = &l_27[2];
            int32_t **l_1256 = &l_837[2];
            int8_t l_1305[10];
            const union U0 *l_1319 = &g_359;
            uint8_t l_1333 = 255UL;
            int i;
            for (i = 0; i < 10; i++)
                l_1305[i] = (-1L);
            for (g_11 = 0; (g_11 < 9); g_11 = safe_add_func_uint32_t_u_u(g_11, 3))
            { /* block id: 24 */
                int32_t *l_35 = &l_30;
                int16_t l_1088 = 0xB37DL;
                int32_t **l_1104 = &l_837[8];
                int32_t l_1106[10][1][9] = {{{0x99EBB5FCL,(-1L),(-9L),(-1L),(-1L),0x46813774L,0xD306CB20L,0xF402184EL,0xB4C57A5BL}},{{(-1L),0xE3FCE01BL,(-1L),(-1L),(-9L),0L,1L,(-9L),0xB4C57A5BL}},{{0xEDB5E312L,(-1L),0x4267919AL,0x46813774L,(-9L),1L,0xD306CB20L,(-1L),0x99EBB5FCL}},{{0xEDB5E312L,(-9L),(-1L),1L,(-1L),1L,(-1L),(-9L),0xEDB5E312L}},{{(-1L),(-9L),(-9L),0x46813774L,0xE3FCE01BL,0L,(-1L),0xF402184EL,0x99EBB5FCL}},{{0x99EBB5FCL,(-1L),(-9L),(-1L),(-1L),0x46813774L,0xD306CB20L,0xF402184EL,0xB4C57A5BL}},{{(-1L),0xE3FCE01BL,(-1L),(-1L),(-9L),0L,1L,(-9L),0xB4C57A5BL}},{{0xEDB5E312L,(-1L),0x4267919AL,0x46813774L,(-9L),1L,0xD306CB20L,(-1L),0x99EBB5FCL}},{{0xEDB5E312L,(-9L),(-1L),1L,(-1L),1L,(-1L),(-9L),0xEDB5E312L}},{{(-1L),(-9L),(-9L),0x46813774L,0xE3FCE01BL,0L,(-1L),0xF402184EL,0x99EBB5FCL}}};
                const int32_t **l_1111[10][8] = {{&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789},{&g_789,&g_789,&g_789,(void*)0,&g_789,&g_789,&g_789,&g_789},{(void*)0,&g_789,&g_789,(void*)0,&g_789,(void*)0,&g_789,&g_789},{&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789,&g_789},{(void*)0,&g_789,&g_789,&g_789,&g_789,&g_789,(void*)0,(void*)0},{&g_789,(void*)0,&g_789,&g_789,(void*)0,&g_789,(void*)0,&g_789},{(void*)0,&g_789,&g_789,&g_789,&g_789,(void*)0,&g_789,&g_789},{&g_789,(void*)0,&g_789,&g_789,&g_789,&g_789,(void*)0,&g_789},{(void*)0,&g_789,(void*)0,&g_789,&g_789,(void*)0,&g_789,(void*)0},{(void*)0,&g_789,&g_789,&g_789,&g_789,&g_789,(void*)0,&g_789}};
                int64_t *l_1130 = (void*)0;
                int64_t *l_1131[9];
                int64_t l_1133 = 0L;
                int32_t l_1134 = (-6L);
                int16_t *l_1135 = &l_1088;
                int32_t *l_1136 = &l_1106[9][0][8];
                int i, j, k;
                for (i = 0; i < 9; i++)
                    l_1131[i] = &g_882;
            }
            if (l_23)
                continue;
            if ((safe_mod_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((**g_138), (l_1099 > ((-1L) < (g_1144 , (safe_sub_func_uint32_t_u_u((g_108 , ((*g_514) < 8L)), (safe_sub_func_uint32_t_u_u(((((((safe_sub_func_uint16_t_u_u(((*l_1151) &= 8UL), (&g_766 == &g_977[5][3][0]))) , g_1152) == l_1154) , l_1155) == l_1156) != (**g_138)), 0xAD28EDB0L))))))))), g_95)))
            { /* block id: 566 */
                int64_t *l_1163 = &g_661;
                uint8_t **l_1165 = &g_411;
                uint64_t *l_1180 = &g_1024;
                int32_t l_1189 = 0x6E4DFCDCL;
                int8_t l_1212 = 0x72L;
                if (((safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint16_t_u_u((((*l_1163) = (safe_add_func_uint64_t_u_u(g_661, g_294.f1))) && (l_1164 != l_1165)), (safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_u(((((((+(*g_59)) & (safe_mul_func_int8_t_s_s(((**l_1155) || (--(*l_1132))), (*g_411)))) | ((safe_unary_minus_func_uint8_t_u(((((*l_1180)--) || (((safe_sub_func_int32_t_s_s(((safe_sub_func_uint16_t_u_u((**l_1156), ((safe_sub_func_int16_t_s_s(((void*)0 == l_1132), 0x2DEBL)) || (**g_793)))) < l_1189), 0x491FD1B7L)) && (**l_1156)) | g_290)) != (**l_1156)))) || 0UL)) != (**l_1156)) > (-10L)) == (**l_1155)), 2)) , 6L) || l_1190), 8)), (**l_1155))))) > (-1L)), l_1191[5][5][1])) <= 0x284AL))
                { /* block id: 570 */
                    l_1189 = (**l_1156);
                }
                else
                { /* block id: 572 */
                    uint32_t l_1203 = 0xC488B035L;
                    uint64_t l_1218[1][2][2] = {{{0UL,0UL},{0UL,0UL}}};
                    int i, j, k;
                    if (((((((g_1192 , (safe_mod_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(((*g_59) & ((((safe_div_func_uint16_t_u_u((l_1189 == (((safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(l_1203, (**g_1152))), l_1203)) || 0x3664L) != ((**l_1155) <= ((l_1203 && (**g_138)) > (**l_1155))))), l_1204)) , 0xF6L) == (**l_1155)) ^ 5UL)), 0x5A891A7AFDB0A632LL)), 2L))) , g_1047[5][5][0]) , (-6L)) , 2L) >= l_1189) || (*g_59)))
                    { /* block id: 573 */
                        return g_1205;
                    }
                    else
                    { /* block id: 575 */
                        uint16_t l_1217 = 65531UL;
                        if ((**g_253))
                            break;
                        l_1189 ^= (safe_mod_func_int16_t_s_s((((safe_lshift_func_int8_t_s_s(0L, (((l_1203 && (((((safe_div_func_uint32_t_u_u(((((*l_1164) == (*l_1165)) <= (l_1212 , (safe_mod_func_uint64_t_u_u(((*l_1180) = g_570[3].f0), g_11)))) | ((+((((void*)0 == l_1216[5][6][1]) , (*g_59)) == l_1217)) > g_95)), (**l_1156))) ^ l_1203) == l_1212) < l_1212) | (-7L))) >= g_144[0][0][7]) <= l_1218[0][1][0]))) != l_1217) , (**g_138)), 0x5D61L));
                        if ((**g_304))
                            continue;
                        return g_1219;
                    }
                }
            }
            else
            { /* block id: 583 */
                uint64_t l_1237 = 0xF24B2C30B3575C72LL;
                int32_t l_1240[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
                int8_t *l_1245 = (void*)0;
                int16_t l_1248 = 0x71D8L;
                int64_t *l_1250 = (void*)0;
                int64_t *l_1251 = (void*)0;
                int i;
                l_1240[6] |= ((g_1144.f1 || (((((~(safe_div_func_int32_t_s_s(0L, (safe_add_func_uint8_t_u_u((((safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_u((*g_139), (1L < (*g_139)))), ((**l_1164) = (!((void*)0 == l_1230))))) , (((((**g_1152) != ((safe_sub_func_uint32_t_u_u((safe_mod_func_int8_t_s_s(((((safe_add_func_uint64_t_u_u(l_1237, g_11)) , 0x356DL) > l_1237) != l_1238), (*g_59))), (**l_1156))) == 1UL)) ^ l_1239) ^ 0L) <= (**l_1155))) && (**l_1156)), l_1237))))) <= (**l_1156)) <= (**l_1155)) && 0x55AFB7796D5E4A21LL) | (**l_1156))) != l_1237);
                l_1240[6] = (((g_661 &= (safe_mul_func_uint16_t_u_u((**l_1156), (((**l_1155) > ((g_882 ^= g_290) == 1UL)) != (((safe_add_func_int8_t_s_s((**l_1155), (((l_1245 != &g_60) == (safe_sub_func_int32_t_s_s((l_1248 = 0x4E0AF030L), (l_1249 == (void*)0)))) ^ 2L))) , 0L) >= (**g_1152)))))) > 6UL) != 0xBE00L);
            }
            for (g_512 = 20; (g_512 < 13); g_512--)
            { /* block id: 593 */
                uint32_t * const l_1273 = (void*)0;
                uint32_t l_1281 = 18446744073709551614UL;
                int32_t l_1282 = 0xC898F032L;
                int32_t l_1283 = 0x6A8A724AL;
                uint32_t l_1301 = 0xAA811A5AL;
                int32_t **l_1306 = &l_837[1];
                uint64_t *l_1323[2][2];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_1323[i][j] = &g_407;
                }
            }
        }
        if ((**g_790))
            break;
        (*g_1336) = l_1335;
    }
    if ((**l_1155))
    { /* block id: 633 */
        uint64_t l_1340 = 18446744073709551607UL;
        int64_t *l_1351 = &g_882;
        int32_t *l_1352 = &l_1122;
        uint32_t l_1361 = 0xEA70D34EL;
        uint32_t **l_1398[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint8_t l_1404 = 0xA5L;
        int32_t l_1454[10] = {0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL,0xBB30585DL};
        uint16_t l_1455 = 3UL;
        int i;
        (*l_1352) ^= (safe_div_func_uint16_t_u_u(((l_1340 <= ((((((((**g_1152) || 1L) & ((**l_1155) && (((g_661 = (safe_mod_func_int16_t_s_s((((safe_div_func_uint64_t_u_u((~((l_1346 = l_1346) == &g_163)), (safe_mod_func_uint8_t_u_u(((((((**l_1335) = (((void*)0 == (*l_1155)) <= (((*l_1351) = (safe_rshift_func_uint8_t_u_u(((*g_411) = (g_294.f1 , (*g_411))), l_1340))) & (-5L)))) || l_1340) , (*g_1321)) , l_1340) == 0UL), 0xEFL)))) , (-6L)) | 0UL), (**g_138)))) == 0xC51B882B8A88C89FLL) > 0x9571C9E02FD594A2LL))) != (*g_789)) | (**l_1155)) & 4UL) , 0x3B7E213A86F7DAB7LL) < l_1340)) ^ l_1340), (**l_1155)));
        for (g_235 = 0; (g_235 <= 0); g_235 += 1)
        { /* block id: 642 */
            uint64_t l_1370 = 0x76BF829754DE869BLL;
            int32_t l_1381 = 7L;
            int32_t l_1453[2][3];
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 3; j++)
                    l_1453[i][j] = 0x917B3F20L;
            }
            for (g_80 = 0; (g_80 <= 5); g_80 += 1)
            { /* block id: 645 */
                return g_1353;
            }
            for (g_661 = 0; (g_661 <= 8); g_661 += 1)
            { /* block id: 650 */
                int32_t l_1373 = (-3L);
                int32_t l_1405[5];
                uint64_t l_1447 = 0xF3287157249EDB34LL;
                int32_t *l_1450 = &g_17[0];
                int32_t *l_1451 = &g_14;
                int32_t *l_1452[9][7][4] = {{{&g_14,&g_17[0],(void*)0,&g_120},{&l_1405[2],&g_11,&l_1405[3],&l_1405[2]},{&l_1405[3],(void*)0,&l_1405[3],(void*)0},{&l_1405[2],&l_1405[2],(void*)0,&g_11},{&g_14,&l_1122,&g_17[0],(void*)0},{&g_14,(void*)0,(void*)0,&l_1405[2]},{&g_14,&g_6,&g_17[0],&g_120}},{{&g_14,&l_1405[2],(void*)0,&l_1405[2]},{&l_1405[2],&g_6,&l_1405[3],&g_17[0]},{&l_1405[3],(void*)0,&l_1405[3],(void*)0},{&l_1405[2],&l_1122,(void*)0,&g_17[0]},{&g_14,&l_1405[2],&g_17[0],(void*)0},{&g_14,(void*)0,(void*)0,&g_17[0]},{&g_14,&g_11,&g_17[0],&l_1405[2]}},{{&g_14,&g_17[0],(void*)0,&g_120},{&l_1405[2],&g_11,&l_1405[3],&l_1405[2]},{&l_1405[3],(void*)0,&l_1405[3],(void*)0},{&l_1405[2],&l_1405[2],(void*)0,&g_11},{&g_14,&l_1122,&g_17[0],(void*)0},{&g_14,(void*)0,(void*)0,&l_1405[2]},{&g_14,&g_6,&g_17[0],&g_120}},{{&g_14,&l_1405[2],(void*)0,&l_1405[2]},{&l_1405[2],&g_6,&l_1405[3],&g_17[0]},{&l_1405[3],(void*)0,&l_1405[3],(void*)0},{&l_1405[2],&l_1122,(void*)0,&g_17[0]},{&g_14,&l_1405[2],&g_17[0],(void*)0},{&g_14,(void*)0,(void*)0,&g_120},{&l_1405[3],&g_14,&l_1122,&g_11}},{{&g_14,&g_120,&l_1405[3],&g_17[0]},{&l_1334,&g_14,(void*)0,&l_1405[2]},{&g_17[0],&l_1122,(void*)0,&l_1122},{&l_1334,&l_1405[2],&l_1405[3],&g_11},{&g_14,&g_17[0],&l_1122,&l_1122},{&l_1405[3],&l_1405[2],&l_1405[2],&l_1405[2]},{&l_1405[3],(void*)0,&l_1122,&g_17[0]}},{{&g_14,&l_1405[2],&l_1405[3],&g_11},{&l_1334,(void*)0,(void*)0,&g_120},{&g_17[0],&l_1405[2],(void*)0,&l_1405[2]},{&l_1334,&g_17[0],&l_1405[3],&g_6},{&g_14,&l_1405[2],&l_1122,&l_1405[2]},{&l_1405[3],&l_1122,&l_1405[2],&g_120},{&l_1405[3],&g_14,&l_1122,&g_11}},{{&g_14,&g_120,&l_1405[3],&g_17[0]},{&l_1334,&g_14,(void*)0,&l_1405[2]},{&g_17[0],&l_1122,(void*)0,&l_1122},{&l_1334,&l_1405[2],&l_1405[3],&g_11},{&g_14,&g_17[0],&l_1122,&l_1122},{&l_1405[3],&l_1405[2],&l_1405[2],&l_1405[2]},{&l_1405[3],(void*)0,&l_1122,&g_17[0]}},{{&g_14,&l_1405[2],&l_1405[3],&g_11},{&l_1334,(void*)0,(void*)0,&g_120},{&g_17[0],&l_1405[2],(void*)0,&l_1405[2]},{&l_1334,&g_17[0],&l_1405[3],&g_6},{&g_14,&l_1405[2],&l_1122,&l_1405[2]},{&l_1405[3],&l_1122,&l_1405[2],&g_120},{&l_1405[3],&g_14,&l_1122,&g_11}},{{&g_14,&g_120,&l_1405[3],&g_17[0]},{&l_1334,&g_14,(void*)0,&l_1405[2]},{&g_17[0],&l_1122,(void*)0,&l_1122},{&l_1334,&l_1405[2],&l_1405[3],&g_11},{&g_14,&g_17[0],&l_1122,&l_1122},{&l_1405[3],&l_1405[2],&l_1405[2],&l_1405[2]},{&l_1405[3],(void*)0,&l_1122,&g_17[0]}}};
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_1405[i] = (-6L);
                for (l_1280 = 8; (l_1280 >= 0); l_1280 -= 1)
                { /* block id: 653 */
                    int8_t l_1368 = (-2L);
                    int16_t *l_1371 = (void*)0;
                    int16_t *l_1372[9];
                    uint32_t l_1374 = 5UL;
                    uint64_t l_1412[2][1][3] = {{{0xED950FD16DAA80C6LL,0xD9E285F761A602A1LL,0xED950FD16DAA80C6LL}},{{0xED950FD16DAA80C6LL,0xD9E285F761A602A1LL,0xED950FD16DAA80C6LL}}};
                    int64_t l_1413 = 4L;
                    int32_t l_1432 = 0xA97C96D3L;
                    const uint8_t l_1433 = 0UL;
                    int i, j, k;
                    for (i = 0; i < 9; i++)
                        l_1372[i] = &g_317;
                }
                for (g_512 = 0; (g_512 <= 2); g_512 += 1)
                { /* block id: 684 */
                    const int64_t l_1439 = 0x54616F85B003254DLL;
                    int16_t *l_1442 = (void*)0;
                    (*l_1352) ^= (safe_mul_func_int8_t_s_s((*g_59), (safe_mul_func_int16_t_s_s(l_1439, 0xA443L))));
                    if ((**g_170))
                        continue;
                    if ((safe_mod_func_int16_t_s_s((**l_1155), (g_205 |= (**g_138)))))
                    { /* block id: 688 */
                        l_1447 = (safe_sub_func_int64_t_s_s((((*g_139) != ((65535UL > 1L) == ((void*)0 != &g_163))) & (l_1381 , ((0x0CEB3B539424D093LL || (safe_mul_func_int8_t_s_s(0xB4L, (*l_1352)))) == (**l_1155)))), 0xA04CCBFB65056233LL));
                        return g_1448;
                    }
                    else
                    { /* block id: 691 */
                        return g_1449[3];
                    }
                }
                l_1455++;
                if ((**l_1155))
                    break;
                for (g_115 = 2; (g_115 >= 0); g_115 -= 1)
                { /* block id: 699 */
                    (**g_1102) |= (safe_rshift_func_int8_t_s_s((*g_59), 2));
                }
            }
        }
    }
    else
    { /* block id: 704 */
        int32_t *l_1460 = &g_17[0];
        (*l_1460) |= ((*g_1321) , (**l_1155));
    }
    (**g_1102) = ((safe_div_func_int64_t_s_s((safe_add_func_int64_t_s_s((g_882 = (**l_1155)), ((*l_1468) = (safe_sub_func_uint16_t_u_u((**l_1155), (**l_1155)))))), ((g_1469 , ((safe_div_func_uint16_t_u_u((**l_1155), (safe_mod_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((**l_1155), (safe_sub_func_uint64_t_u_u(((*l_1482) |= (safe_div_func_uint64_t_u_u(1UL, 18446744073709551610UL))), (safe_div_func_uint64_t_u_u((**l_1155), 0x9DD75AC2DFA29CE2LL)))))), 6L)), (**g_1102))))) ^ l_1485)) & g_1353.f1))) | (**l_1155));
    return g_1486;
}


/* ------------------------------------------ */
/* 
 * reads : g_661 g_843 g_851 g_294 g_134.f0 g_17 g_139 g_115 g_411 g_719.f0 g_22 g_880 g_94 g_59 g_60 g_294.f1 g_514 g_316.f1 g_120 g_359 g_147 g_138 g_235 g_14 g_790 g_512 g_80 g_11 g_293 g_10 g_144 g_186 g_290 g_976 g_162 g_163 g_164 g_2 g_1021 g_1047 g_977 g_844 g_1075
 * writes: g_661 g_844 g_17 g_235 g_80 g_205 g_719.f1 g_410 g_353 g_22 g_882 g_95 g_407 g_290 g_120 g_3 g_2 g_115 g_60 g_789 g_512 g_294.f1 g_976 g_139 g_357 g_1021 g_317 g_171 g_1024
 */
static int32_t * func_36(int32_t * p_37, int8_t  p_38, int8_t * p_39, int8_t  p_40)
{ /* block id: 401 */
    union U1 *l_850 = &g_570[4];
    int32_t l_879 = 0x60F3C71CL;
    int32_t l_1025 = (-6L);
    for (g_661 = (-7); (g_661 > (-24)); g_661 = safe_sub_func_int32_t_s_s(g_661, 4))
    { /* block id: 404 */
        union U1 *l_841 = &g_294;
        int32_t *l_846 = (void*)0;
        int32_t *l_847 = &g_17[0];
        int32_t l_912 = (-1L);
        int32_t l_914[1];
        uint8_t ***l_943 = (void*)0;
        uint64_t l_946 = 0xB2B1C417BA162973LL;
        int16_t ***l_967 = &g_138;
        int16_t *l_981 = &g_205;
        int32_t l_983 = 2L;
        uint32_t l_1035 = 0x0B4B56B6L;
        int i;
        for (i = 0; i < 1; i++)
            l_914[i] = (-5L);
        (*g_843) = l_841;
        (*l_847) = (p_38 < (+0x3CE3L));
        if ((safe_rshift_func_int16_t_s_u((l_841 == l_850), (((g_851 , (*l_841)) , (-4L)) && (safe_unary_minus_func_int64_t_s(g_134[0].f0))))))
        { /* block id: 407 */
            uint64_t * const l_857 = &g_407;
            int8_t *l_872 = &g_570[3].f1;
            int16_t *l_875 = &g_317;
            int32_t l_876 = (-1L);
            uint16_t ***l_975 = (void*)0;
            uint8_t ***l_1026[9];
            int32_t l_1038 = 0x8E684188L;
            uint16_t l_1068 = 0UL;
            int i;
            for (i = 0; i < 9; i++)
                l_1026[i] = (void*)0;
            for (g_235 = (-23); (g_235 == 17); ++g_235)
            { /* block id: 410 */
                int32_t *l_903 = &g_120;
                for (g_80 = 0; (g_80 != 37); g_80 = safe_add_func_uint8_t_u_u(g_80, 1))
                { /* block id: 413 */
                    (*l_847) &= (l_857 != l_857);
                }
                for (g_205 = 0; (g_205 >= 14); g_205++)
                { /* block id: 418 */
                    int8_t **l_869 = (void*)0;
                    int8_t **l_870 = (void*)0;
                    int8_t **l_871[4][5] = {{&g_59,&g_59,&g_59,&g_59,&g_59},{&g_59,&g_59,&g_59,&g_59,&g_59},{&g_59,&g_59,&g_59,&g_59,&g_59},{&g_59,&g_59,&g_59,&g_59,&g_59}};
                    int32_t l_877[1];
                    int32_t *l_878 = &g_22;
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_877[i] = 0x42C345C2L;
                    for (g_719.f1 = 0; g_719.f1 < 8; g_719.f1 += 1)
                    {
                        g_410[g_719.f1] = &g_411;
                    }
                    if (((*l_878) ^= (safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s((+(((0x3CL | (((*g_411) = (safe_mul_func_int16_t_s_s(((p_40 < (((p_39 = &g_147[1][1][3]) == (l_872 = &g_147[0][1][8])) != (safe_sub_func_uint8_t_u_u(((((l_875 = l_875) != (void*)0) ^ ((((0xF0L < (((&g_59 == (void*)0) & g_17[0]) >= 8UL)) <= (*g_139)) & 1L) < p_40)) == 0xEE908E6E4A5829A2LL), l_876)))) != 0UL), p_40))) ^ 0x1FL)) > p_40) || g_719.f0)), 2)) ^ l_877[0]), 6)), 9UL))))
                    { /* block id: 425 */
                        l_879 = l_876;
                        (*l_847) &= l_879;
                    }
                    else
                    { /* block id: 428 */
                        int64_t *l_881 = &g_882;
                        uint16_t *l_904 = &g_290;
                        l_876 &= (g_880 , ((*l_903) &= (((*l_881) = p_38) < (((*l_847) = ((*g_94) = (*l_878))) , ((safe_div_func_uint64_t_u_u(((*l_857) = (safe_div_func_int16_t_s_s(0x717FL, (-9L)))), (safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((*g_59), (safe_rshift_func_int16_t_s_u((safe_lshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u(((*l_904) = ((((*l_847) = ((safe_div_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((0L >= 0xA49B938FD6EB8999LL) || (l_903 == p_37)), g_294.f1)), p_38)) <= (*g_514))) | p_40) == p_38)), p_38)), g_316.f1)), 7)), 7)))), (*l_878))))) > g_60)))));
                    }
                    (*l_878) &= (g_359 , p_40);
                    for (g_3 = 0; g_3 < 4; g_3 += 1)
                    {
                        for (g_2 = 0; g_2 < 5; g_2 += 1)
                        {
                            l_871[g_3][g_2] = &g_59;
                        }
                    }
                }
            }
            for (g_407 = 12; (g_407 != 5); g_407 = safe_sub_func_int64_t_s_s(g_407, 1))
            { /* block id: 444 */
                int8_t l_913[7][6] = {{0x1EL,0x40L,0x40L,0x1EL,0x40L,0x40L},{0x1EL,0x40L,0x40L,0x1EL,0x40L,0x40L},{0x1EL,0x40L,0x40L,0x1EL,0x40L,0x40L},{0x1EL,0x40L,(-1L),0x40L,(-1L),(-1L)},{0x40L,(-1L),(-1L),0x40L,(-1L),(-1L)},{0x40L,(-1L),(-1L),0x40L,(-1L),(-1L)},{0x40L,(-1L),(-1L),0x40L,(-1L),(-1L)}};
                int32_t *l_968 = &g_17[0];
                int8_t **l_997[3];
                int i, j;
                for (i = 0; i < 3; i++)
                    l_997[i] = &g_59;
                for (g_95 = 0; (g_95 <= 8); g_95 += 1)
                { /* block id: 447 */
                    const uint8_t l_930 = 0UL;
                    uint16_t *l_938 = &g_512;
                    uint32_t *l_944 = (void*)0;
                    uint32_t *l_945 = &g_235;
                    uint16_t **l_974[8][10] = {{&l_938,(void*)0,&l_938,(void*)0,&l_938,&l_938,&l_938,&l_938,&l_938,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,(void*)0,&l_938,&l_938,&l_938,(void*)0,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,&l_938,&l_938,&l_938,&l_938,&l_938,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,(void*)0,&l_938,&l_938,&l_938,(void*)0,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,&l_938,&l_938,&l_938,&l_938,&l_938,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,(void*)0,&l_938,&l_938,&l_938,(void*)0,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,&l_938,&l_938,&l_938,&l_938,&l_938,(void*)0},{&l_938,(void*)0,&l_938,(void*)0,(void*)0,&l_938,&l_938,&l_938,(void*)0,(void*)0}};
                    uint16_t ***l_973 = &l_974[1][3];
                    uint16_t ****l_979 = &g_976;
                    uint32_t l_982[10][7] = {{0xE7FD88D1L,0x78E7F3FBL,0xAA28ABF6L,0xAA28ABF6L,0x78E7F3FBL,0xE7FD88D1L,0xE90D9C83L},{18446744073709551614UL,0xAA28ABF6L,8UL,0xE90D9C83L,0UL,0xE7FD88D1L,0xE7FD88D1L},{0x2C89AF7AL,0UL,0UL,0UL,0x2C89AF7AL,0x2AF8C93AL,18446744073709551614UL},{1UL,0xAA28ABF6L,0xE7FD88D1L,2UL,0x2C89AF7AL,18446744073709551614UL,0x2C89AF7AL},{0x62AD4456L,0x78E7F3FBL,0x78E7F3FBL,0x62AD4456L,0UL,2UL,1UL},{1UL,2UL,0UL,0x62AD4456L,0x78E7F3FBL,0x78E7F3FBL,0x62AD4456L},{0x2C89AF7AL,18446744073709551614UL,0x2C89AF7AL,2UL,0xE7FD88D1L,0xAA28ABF6L,1UL},{18446744073709551614UL,0x2AF8C93AL,0x2C89AF7AL,0UL,0UL,0UL,0x2C89AF7AL},{0xE7FD88D1L,0xE7FD88D1L,0UL,0xE90D9C83L,8UL,0xAA28ABF6L,18446744073709551614UL},{0xE90D9C83L,0xE7FD88D1L,0x78E7F3FBL,0xAA28ABF6L,0xAA28ABF6L,0x78E7F3FBL,0xE7FD88D1L}};
                    int i, j;
                    for (g_120 = 7; (g_120 >= 0); g_120 -= 1)
                    { /* block id: 450 */
                        int32_t *l_907 = (void*)0;
                        int32_t *l_908 = &l_876;
                        int32_t *l_909 = &g_17[0];
                        int32_t *l_910 = &l_879;
                        int32_t *l_911[10] = {&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22};
                        uint16_t l_915 = 2UL;
                        int32_t **l_931[9][8] = {{&l_910,(void*)0,&l_910,&l_911[5],&l_911[1],&l_847,(void*)0,(void*)0},{(void*)0,&g_171[2][0],&l_911[5],&l_847,&l_911[5],&l_908,(void*)0,&l_911[5]},{&l_910,&l_911[5],&g_171[2][0],&l_908,(void*)0,&l_911[1],&l_911[1],(void*)0},{&l_911[2],&l_910,&l_910,&l_911[2],&l_910,(void*)0,&g_171[2][0],&l_911[5]},{&l_911[5],(void*)0,&l_908,&l_911[5],&l_909,&l_911[5],&l_910,&l_908},{(void*)0,(void*)0,&l_911[2],&g_171[2][0],&l_847,(void*)0,(void*)0,(void*)0},{&l_911[5],&l_910,(void*)0,&l_910,&l_911[5],&l_911[1],&l_847,(void*)0},{(void*)0,&l_911[5],(void*)0,&l_908,&l_911[5],&l_908,&l_911[1],&l_910},{&l_846,&g_171[2][0],(void*)0,&l_911[2],&l_910,&g_171[0][2],&l_847,&l_847}};
                        int i, j;
                        --l_915;
                        (*g_790) = (((*g_59) = (safe_add_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(((l_879 < (safe_mul_func_int16_t_s_s((*l_910), (((**g_138) = (safe_mod_func_uint64_t_u_u(8UL, (p_38 , (((l_930 || p_40) > (p_38 >= l_913[6][0])) ^ (*p_39)))))) != p_40)))) | 6UL), g_235)), l_879)), p_40)) ^ g_14), p_38))) , p_37);
                        if (l_930)
                            break;
                    }
                    if (((((**g_138) = (p_40 == (p_38 && (safe_sub_func_int64_t_s_s(g_14, (&g_147[0][1][8] != (void*)0)))))) > (safe_lshift_func_uint16_t_u_u(((*l_938) &= (safe_rshift_func_int8_t_s_s(1L, l_876))), ((safe_mul_func_uint16_t_u_u((((((((*l_945) ^= (((safe_add_func_int32_t_s_s(l_879, ((*l_847) = (l_943 == (void*)0)))) == 0x0DA4L) <= g_80)) | l_913[4][5]) != l_913[6][4]) <= p_38) != l_879) && g_11), l_946)) == g_293)))) >= p_38))
                    { /* block id: 461 */
                        const uint16_t l_958 = 0xFDB6L;
                        int32_t *l_959 = (void*)0;
                        l_914[0] ^= (((g_17[0] , 1UL) & (safe_sub_func_int16_t_s_s(l_879, (l_876 , (**g_138))))) >= (safe_sub_func_int16_t_s_s(((safe_unary_minus_func_uint64_t_u((safe_sub_func_uint32_t_u_u(((*l_945) ^= (l_879 || l_930)), ((safe_div_func_int64_t_s_s((safe_sub_func_uint16_t_u_u(2UL, (**g_138))), g_10)) > g_147[0][2][6]))))) <= l_958), p_38)));
                    }
                    else
                    { /* block id: 464 */
                        const uint32_t l_962 = 0x33A52CF3L;
                        int8_t *l_964 = &g_294.f1;
                        (*l_847) ^= 0xEE764F48L;
                        if (p_38)
                            continue;
                        (*l_847) = ((safe_mul_func_uint16_t_u_u(((g_144[0][0][7] >= (l_962 , ((~1L) , ((p_40 >= (((0xA1L | ((((*p_39) > ((*l_964) ^= (*p_39))) <= (safe_rshift_func_uint16_t_u_s(((void*)0 != l_967), l_962))) ^ g_186)) < g_290) || (*g_514))) || l_876)))) , p_38), 2L)) && 18446744073709551615UL);
                        return l_968;
                    }
                    (*l_968) = ((((((((safe_unary_minus_func_uint8_t_u(((*l_847) | (safe_sub_func_int16_t_s_s((((((*g_139) = p_40) && ((!((l_975 = l_973) != ((*l_979) = g_976))) >= (((0x31EDL <= (((+l_930) , (void*)0) != ((*g_138) = (*g_138)))) != (65533UL && 0xF4F6L)) | 246UL))) , (**g_162)) == l_981), 0x75B8L))))) , (-10L)) < g_2) > p_40) <= p_38) && l_982[0][1]) ^ l_983) , (*l_847));
                }
                for (g_290 = 0; (g_290 >= 9); g_290 = safe_add_func_uint32_t_u_u(g_290, 4))
                { /* block id: 479 */
                    uint16_t *l_988 = &g_512;
                    int32_t *l_991 = &l_879;
                    uint32_t *l_994 = &g_235;
                    int8_t ***l_998 = &l_997[0];
                    (*l_847) = (((*l_988) = (safe_sub_func_uint8_t_u_u(0UL, p_40))) <= l_879);
                    if ((*l_847))
                        break;
                    for (l_876 = 0; (l_876 >= (-2)); l_876--)
                    { /* block id: 485 */
                        return p_37;
                    }
                    l_876 ^= ((safe_add_func_int8_t_s_s((*p_39), ((((-1L) || ((--(*l_994)) < (p_37 != (((l_841 != l_850) | (((*l_998) = l_997[0]) != &g_59)) , func_41(l_968, &g_147[0][1][8], p_38, l_968, p_40))))) , 0UL) >= 1L))) , (*l_968));
                }
                if (p_40)
                    continue;
                return p_37;
            }
            if (p_40)
                break;
            for (g_357 = 0; (g_357 != 21); g_357 = safe_add_func_int16_t_s_s(g_357, 3))
            { /* block id: 498 */
                int16_t l_1011 = 4L;
                const int32_t l_1022[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
                uint64_t l_1039 = 0xE51A7CC56798D365LL;
                int8_t *l_1056 = &g_570[3].f1;
                int32_t l_1060[4] = {(-1L),(-1L),(-1L),(-1L)};
                int32_t *l_1061 = &l_912;
                int32_t *l_1062 = &l_879;
                int32_t *l_1063 = &g_22;
                int32_t *l_1064 = (void*)0;
                int32_t *l_1065 = &l_912;
                int32_t *l_1066 = (void*)0;
                int32_t *l_1067[7][7][5] = {{{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0}},{{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]}},{{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0},{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{(void*)0,(void*)0,&l_1038,(void*)0,(void*)0}},{{&l_914[0],(void*)0,&l_914[0],&l_914[0],(void*)0},{(void*)0,&l_914[0],&l_914[0],(void*)0,&l_914[0]},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]}},{{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038}},{{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]}},{{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]},{&l_914[0],&l_1038,&l_1038,&l_914[0],&l_1038},{&l_914[0],&l_914[0],(void*)0,&l_914[0],&l_914[0]},{&l_1038,&l_914[0],&l_1038,&l_1038,&l_914[0]}}};
                int i, j, k;
                for (g_407 = 8; (g_407 > 57); g_407 = safe_add_func_uint64_t_u_u(g_407, 6))
                { /* block id: 501 */
                    uint64_t l_1005 = 0x9682E1451E6FD3C8LL;
                    uint64_t *l_1019 = &l_946;
                    uint64_t *l_1020 = &g_1021;
                    uint64_t *l_1023[2][3][4] = {{{&g_1024,(void*)0,(void*)0,&g_1024},{(void*)0,&g_1024,(void*)0,(void*)0},{&g_1024,&g_1024,&g_1024,&g_1024}},{{&g_1024,(void*)0,(void*)0,&g_1024},{(void*)0,&g_1024,(void*)0,(void*)0},{&g_1024,&g_1024,&g_1024,&g_1024}}};
                    int32_t l_1030 = 0L;
                    int i, j, k;
                    if (((*l_847) = (safe_lshift_func_uint8_t_u_s(((**g_138) ^ l_1005), (safe_mod_func_uint16_t_u_u(((((l_1025 ^= (((safe_mul_func_int64_t_s_s((~(*g_59)), 0L)) < (l_1011 &= g_147[0][0][1])) <= (((((+(safe_sub_func_int16_t_s_s(((*l_875) = (safe_add_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u((0x901257BB2E83D570LL <= (l_876 == ((*l_1020) ^= ((*l_1019) = (65535UL != (l_879 &= 65535UL)))))), 1UL)) , p_40), 0x6D8828B1E8451CD5LL))), p_40))) > 0xE95AL) & l_1022[7]) , l_1005) , (-1L)))) , 0x720EL) , (void*)0) == l_1026[2]), p_38))))))
                    { /* block id: 509 */
                        uint16_t l_1027 = 9UL;
                        int32_t *l_1028 = &g_14;
                        if (l_1027)
                            break;
                        return l_1028;
                    }
                    else
                    { /* block id: 512 */
                        int32_t **l_1029 = &g_171[1][2];
                        int32_t *l_1031 = &l_1025;
                        int32_t *l_1032 = &l_1030;
                        int32_t *l_1033 = &l_983;
                        int32_t *l_1034[9] = {(void*)0,&l_912,&l_912,(void*)0,&l_912,&l_912,(void*)0,&l_912,&l_912};
                        int i;
                        (*l_1029) = (void*)0;
                        ++l_1035;
                        l_1039++;
                        p_37 = func_41(&l_1025, (((4294967291UL <= ((p_40 , &l_875) != ((safe_add_func_int8_t_s_s((safe_mod_func_int8_t_s_s(((((*l_1019) = 0xE83A3D970F7E07F0LL) >= (!(g_1047[2][7][1] , ((g_1024 = ((safe_add_func_int16_t_s_s((0xE856L || p_38), (safe_sub_func_uint16_t_u_u((safe_sub_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s(p_38, (*p_39))), (*l_1032))), p_38)))) < (-1L))) && g_235)))) >= l_1039), 0xA8L)), (*g_59))) , (void*)0))) < l_1011) , l_1056), p_40, &g_14, l_876);
                    }
                }
                for (l_1038 = (-30); (l_1038 < 1); ++l_1038)
                { /* block id: 523 */
                    int32_t **l_1059 = &l_846;
                    (*l_1059) = &l_1038;
                }
                --l_1068;
            }
        }
        else
        { /* block id: 528 */
            (*l_847) = ((void*)0 == (*g_976));
        }
        (*g_1075) = (((safe_mul_func_uint16_t_u_u(p_38, (p_40 || (*g_514)))) >= (safe_add_func_uint64_t_u_u(g_235, l_1025))) , (*g_843));
    }
    return p_37;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_41(int32_t * p_42, int8_t * p_43, int32_t  p_44, int32_t * p_45, int16_t  p_46)
{ /* block id: 399 */
    int32_t *l_838 = (void*)0;
    return l_838;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_4 g_407 g_730.f1 g_138 g_139 g_512 g_147 g_790 g_60 g_793 g_235 g_411 g_353 g_17 g_290 g_357
 * writes: g_407 g_290 g_17 g_789 g_60 g_294.f1 g_235 g_730.f1 g_353 g_147 g_512 g_814 g_357
 */
static int32_t * func_47(const int32_t * p_48, const int32_t  p_49)
{ /* block id: 347 */
    int32_t l_770 = 0x6E5782E8L;
    uint8_t **l_800 = &g_411;
    uint8_t ***l_799 = &l_800;
    uint8_t ****l_798[5][3];
    int32_t l_828 = 0xC4DC8CECL;
    int32_t l_829[6][10] = {{(-1L),0L,0x68A2D182L,0x68A2D182L,0L,(-1L),0xA7DA74F7L,0x156A481BL,(-3L),(-1L)},{1L,(-1L),8L,6L,0x156A481BL,6L,8L,(-1L),1L,(-1L)},{1L,0x68A2D182L,0xEF7A720EL,0xA7DA74F7L,6L,(-1L),(-1L),6L,0x7DBD2802L,0x156A481BL},{6L,6L,1L,0x7DBD2802L,0x156A481BL,0L,0xA7DA74F7L,8L,0xA7DA74F7L,0L},{0x68A2D182L,1L,0xB84CB1F8L,1L,0x68A2D182L,0xEF7A720EL,0xA7DA74F7L,6L,(-1L),(-1L)},{0x7DBD2802L,6L,(-3L),0L,0L,(-3L),6L,0x7DBD2802L,0xB84CB1F8L,(-1L)}};
    uint32_t l_830 = 1UL;
    int32_t *l_834[6][2] = {{&g_120,&g_17[0]},{&g_120,&g_120},{&g_17[0],&g_120},{&g_120,&g_17[0]},{&g_120,&g_120},{&g_17[0],&g_120}};
    int i, j;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 3; j++)
            l_798[i][j] = &l_799;
    }
    if ((*p_48))
    { /* block id: 348 */
        uint64_t *l_771 = &g_407;
        uint16_t *l_780[7] = {&g_290,(void*)0,(void*)0,&g_290,(void*)0,(void*)0,&g_290};
        int32_t *l_787 = &g_17[0];
        int32_t l_824 = 0xB1509FC7L;
        int32_t l_825 = 1L;
        int32_t l_826 = 0x05BC8CCDL;
        int32_t l_827[6][8] = {{0x60DB3C57L,0x60DB3C57L,(-1L),0xB0CABAB3L,1L,0xB0CABAB3L,(-1L),0x60DB3C57L},{0x60DB3C57L,9L,0xA684D479L,(-1L),(-1L),0xA684D479L,9L,0x60DB3C57L},{9L,6L,0x60DB3C57L,0xB0CABAB3L,0x60DB3C57L,6L,9L,9L},{6L,0xB0CABAB3L,0xA684D479L,0xA684D479L,0xB0CABAB3L,6L,(-1L),6L},{0xB0CABAB3L,6L,(-1L),6L,0xB0CABAB3L,0xA684D479L,0xA684D479L,0xB0CABAB3L},{6L,9L,9L,6L,0x60DB3C57L,0xB0CABAB3L,0x60DB3C57L,6L}};
        int i, j;
        (*g_790) = func_50(g_4, l_770, (((((*l_771)--) != p_49) & (safe_sub_func_uint32_t_u_u((safe_div_func_int64_t_s_s((safe_sub_func_int64_t_s_s(g_730.f1, 18446744073709551615UL)), ((g_290 = 1UL) , ((((safe_lshift_func_int16_t_s_s((safe_div_func_int64_t_s_s((((safe_mul_func_uint8_t_u_u((5UL >= 0xCBL), (((*l_787) = (((*g_138) == (void*)0) != p_49)) != p_49))) <= p_49) , 0L), g_512)), p_49)) ^ 0xB5C3B3422ED2F0F0LL) <= 9UL) & 0x76C6E9EF40D483C4LL)))), (-1L)))) & p_49), g_147[0][2][0]);
        for (g_60 = 0; (g_60 <= 0); g_60 += 1)
        { /* block id: 355 */
            int32_t *l_791[2];
            const int32_t **l_792 = (void*)0;
            uint8_t ****l_797 = (void*)0;
            int i;
            for (i = 0; i < 2; i++)
                l_791[i] = &g_17[0];
            for (g_294.f1 = 0; (g_294.f1 <= 0); g_294.f1 += 1)
            { /* block id: 358 */
                int i, j;
                return l_791[0];
            }
            (*g_793) = &p_49;
            for (g_235 = 0; (g_235 <= 0); g_235 += 1)
            { /* block id: 364 */
                int64_t l_794 = 0xC1F6D857EE561179LL;
                for (g_730.f1 = 0; (g_730.f1 <= 0); g_730.f1 += 1)
                { /* block id: 367 */
                    int8_t *l_813 = &g_147[0][1][8];
                    g_814 = ((*l_787) = ((l_794 & ((safe_add_func_uint8_t_u_u(0x31L, ((l_797 == l_798[0][2]) != ((((g_512 = (safe_mul_func_uint16_t_u_u(l_770, (safe_mul_func_uint8_t_u_u((--(*g_411)), (((void*)0 != &g_411) < ((safe_rshift_func_uint16_t_u_s((((*l_813) = (safe_add_func_uint16_t_u_u((0x8FL | (safe_mod_func_uint64_t_u_u(p_49, p_49))), l_794))) == (*l_787)), 15)) == (*l_787)))))))) || p_49) <= 0x89B9B753L) == p_49)))) , p_49)) , (*p_48)));
                }
                for (g_290 = 0; (g_290 <= 2); g_290 += 1)
                { /* block id: 376 */
                    uint32_t l_815[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_815[i] = 4294967294UL;
                    if (l_815[0])
                        break;
                    return l_787;
                }
            }
        }
        for (g_407 = 0; (g_407 < 1); ++g_407)
        { /* block id: 384 */
            uint8_t l_818 = 0xE7L;
            --l_818;
        }
        for (g_357 = 0; (g_357 != (-2)); g_357 = safe_sub_func_int32_t_s_s(g_357, 8))
        { /* block id: 389 */
            int32_t *l_823[6];
            int i;
            for (i = 0; i < 6; i++)
                l_823[i] = &g_17[0];
            l_830++;
            return l_823[3];
        }
    }
    else
    { /* block id: 393 */
        int32_t *l_833 = &g_6;
        return l_833;
    }
    l_828 &= (0x720FL ^ l_830);
    return l_834[1][0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int32_t * func_50(const int32_t  p_51, uint16_t  p_52, uint8_t  p_53, int64_t  p_54)
{ /* block id: 345 */
    const int32_t *l_769 = &g_14;
    return l_769;
}


/* ------------------------------------------ */
/* 
 * reads : g_235 g_115 g_108 g_11 g_60 g_59 g_138 g_139 g_357 g_147 g_514 g_17 g_120 g_411 g_144 g_186 g_765 g_317
 * writes: g_235 g_115 g_407 g_205 g_171 g_661 g_353 g_144 g_766
 */
static int64_t  func_55(int8_t * p_56, uint16_t  p_57, int8_t  p_58)
{ /* block id: 258 */
    int32_t **l_631[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_647 = 1L;
    uint64_t l_762 = 0x859ACBA2F5CC6BCALL;
    const uint16_t *l_764 = &g_290;
    const uint16_t **l_763[4];
    int i;
    for (i = 0; i < 4; i++)
        l_763[i] = &l_764;
    for (g_235 = 0; (g_235 < 45); ++g_235)
    { /* block id: 261 */
        uint16_t l_627[3][7];
        int32_t l_665[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        const int32_t *l_667 = &g_120;
        const int32_t **l_666 = &l_667;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 7; j++)
                l_627[i][j] = 0UL;
        }
        for (g_115 = 0; (g_115 >= 1); g_115 = safe_add_func_int8_t_s_s(g_115, 2))
        { /* block id: 264 */
            uint32_t l_618 = 0xC931FD94L;
            int32_t ** const l_624 = &g_171[2][0];
            int32_t l_626 = 0xCBE6606DL;
            uint8_t *l_679 = (void*)0;
            uint8_t *l_680 = &g_144[0][0][7];
            uint32_t * const l_708[2] = {&g_235,&g_235};
            uint32_t * const * const l_707 = &l_708[0];
            uint32_t *l_724 = &g_235;
            int32_t l_729 = (-1L);
            uint32_t l_736[8];
            int i;
            for (i = 0; i < 8; i++)
                l_736[i] = 0UL;
            for (g_407 = (-13); (g_407 != 21); g_407 = safe_add_func_int16_t_s_s(g_407, 6))
            { /* block id: 267 */
                int32_t *l_628[9][4] = {{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14}};
                const uint32_t *l_664 = &g_235;
                const uint32_t **l_663[7] = {&l_664,&l_664,&l_664,&l_664,&l_664,&l_664,&l_664};
                int i, j;
                for (g_205 = 0; (g_205 > 8); ++g_205)
                { /* block id: 270 */
                    int32_t **l_623 = &g_171[1][3];
                    uint32_t *l_658 = &g_235;
                    uint32_t * const *l_662 = (void*)0;
                    int32_t l_668[6] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
                    int i;
                    if ((0UL && (g_108 , 0x85L)))
                    { /* block id: 271 */
                        int32_t l_625 = 2L;
                        l_627[1][3] = ((-1L) > ((((((4294967291UL >= ((((void*)0 == p_56) ^ (safe_mod_func_int32_t_s_s((safe_mul_func_int16_t_s_s((l_618 ^ 6UL), (safe_lshift_func_int16_t_s_u(((l_618 != (l_623 != l_624)) > g_11), 4)))), l_625))) != (*p_56))) == (*g_59)) == (**g_138)) && p_58) || 0x95L) && l_626));
                        (*l_624) = l_628[8][0];
                        l_626 ^= p_58;
                    }
                    else
                    { /* block id: 275 */
                        int32_t ***l_632 = &l_631[3];
                        int64_t *l_659 = (void*)0;
                        int64_t *l_660 = &g_661;
                        int32_t l_669 = 0x5F7C3C93L;
                        l_668[2] ^= (safe_sub_func_int8_t_s_s((g_357 & ((((*l_632) = l_631[5]) != ((safe_sub_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u(((-8L) | (safe_mul_func_uint8_t_u_u((l_665[1] = (safe_mod_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(((((p_57 , ((*l_660) = ((safe_lshift_func_int16_t_s_u(1L, 11)) & (((safe_sub_func_int32_t_s_s((g_147[1][0][5] < (l_647 | (safe_sub_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((safe_add_func_int64_t_s_s(((safe_div_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u(p_58, (((void*)0 == l_658) | l_647))), 1UL)) < p_58), l_627[0][3])) == 0L), l_627[2][2])) >= 0x81L), 6L)))), p_58)) == 255UL) != 0x33D4L)))) & p_57) , l_662) != l_663[5]), l_627[1][3])), p_57))), p_58))), p_58)), p_57)) , l_666)) < p_57)), (*g_59)));
                        l_669 = (l_668[2] = p_57);
                    }
                    (*l_666) = (*l_666);
                }
                return p_58;
            }
            l_665[1] = ((p_57 , (l_626 = (65535UL != (safe_div_func_int8_t_s_s((((*l_680) |= ((safe_sub_func_int64_t_s_s(((*g_514) == 0x72EB7F0DL), ((((*g_411) = (((g_17[0] >= (g_235 ^ (safe_rshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_int16_t_s((-5L))), 0UL)), ((((9UL || p_58) != 0UL) != p_57) , (*p_56)))))) > (*l_667)) , p_58)) , 5L) > (-2L)))) < (*p_56))) != p_58), (*p_56)))))) , 0x6AADDAA1L);
        }
        return g_186;
    }
    (*g_765) = l_763[0];
    return g_317;
}


/* ------------------------------------------ */
/* 
 * reads : g_22
 * writes:
 */
static int64_t  func_61(int8_t * const  p_62, int8_t * p_63, int8_t * const  p_64)
{ /* block id: 255 */
    int32_t *l_591 = &g_22;
    int32_t *l_592 = &g_120;
    int32_t *l_593 = &g_120;
    int32_t l_594 = 0xFE594C26L;
    int32_t *l_595 = &g_22;
    int32_t *l_596 = &g_17[0];
    int32_t l_597 = 0x8938E93CL;
    int32_t *l_598 = &g_22;
    int32_t *l_599 = &l_597;
    int32_t *l_600 = &l_594;
    int32_t *l_601[1];
    uint16_t l_602 = 0xC1C5L;
    int i;
    for (i = 0; i < 1; i++)
        l_601[i] = &g_17[0];
    l_602++;
    return (*l_595);
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_17 g_5 g_22 g_94 g_95 g_108 g_11 g_4 g_6 g_14 g_123 g_59 g_134 g_138 g_115 g_139 g_162 g_170 g_3 g_144 g_120 g_235 g_171 g_253 g_134.f0 g_108.f0 g_205 g_163 g_294 g_147 g_304 g_290 g_316 g_80 g_317 g_294.f1
 * writes: g_80 g_5 g_123 g_60 g_22 g_138 g_144 g_147 g_95 g_154 g_115 g_171 g_205 g_235 g_17 g_290 g_293 g_317 g_353 g_357 g_294.f1
 */
static int8_t * func_66(const int8_t * p_67, int8_t  p_68, int8_t  p_69)
{ /* block id: 30 */
    uint32_t *l_79 = &g_80;
    int8_t *l_92[10] = {&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60};
    int8_t *l_93 = (void*)0;
    int32_t l_127 = (-8L);
    uint16_t *l_309 = (void*)0;
    uint16_t *l_310 = &g_290;
    int32_t l_322 = 0L;
    int32_t l_323[1];
    int32_t l_324 = (-10L);
    int16_t ** const *l_354 = &g_138;
    uint16_t l_366[6][1][4] = {{{0xD904L,65535UL,0x6F9DL,4UL}},{{65535UL,65535UL,9UL,0xD904L}},{{0x85BBL,0x9C6DL,0x9C6DL,0x85BBL}},{{0x85BBL,4UL,9UL,65535UL}},{{7UL,0x9C6DL,9UL,65535UL}},{{4UL,6UL,4UL,65535UL}}};
    int16_t l_425 = (-1L);
    uint64_t l_434 = 0x87A81C603833DB70LL;
    uint32_t *l_477 = (void*)0;
    uint32_t * const *l_476 = &l_477;
    union U0 *l_574[5][3][5] = {{{&g_359,(void*)0,&g_359,&g_359,&g_359},{(void*)0,(void*)0,&g_359,&g_359,(void*)0},{&g_359,&g_359,&g_359,(void*)0,&g_359}},{{(void*)0,&g_359,&g_359,(void*)0,&g_359},{&g_359,&g_359,&g_359,&g_359,&g_359},{&g_359,(void*)0,&g_359,&g_359,(void*)0}},{{&g_359,(void*)0,&g_359,&g_359,&g_359},{(void*)0,&g_359,&g_359,(void*)0,(void*)0},{&g_359,&g_359,&g_359,(void*)0,&g_359}},{{(void*)0,&g_359,&g_359,&g_359,&g_359},{&g_359,&g_359,&g_359,&g_359,&g_359},{&g_359,&g_359,&g_359,&g_359,(void*)0}},{{&g_359,(void*)0,&g_359,&g_359,&g_359},{(void*)0,(void*)0,&g_359,&g_359,(void*)0},{&g_359,&g_359,&g_359,(void*)0,&g_359}}};
    int32_t l_585 = 0x5411E077L;
    int32_t *l_586 = &g_120;
    int32_t **l_587[6] = {&g_171[1][2],&g_171[1][2],&g_171[1][2],&g_171[1][2],&g_171[1][2],&g_171[1][2]};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_323[i] = (-3L);
    (*g_304) = func_71(((*p_67) ^ (safe_mul_func_int8_t_s_s(((safe_div_func_int64_t_s_s((((*l_79) = g_17[0]) , (-8L)), (((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((func_85(g_5, g_22, ((safe_mul_func_int8_t_s_s(5L, (l_92[3] != l_93))) , g_94), (*g_94)) & 0x9381L), (*g_59))), p_68)) <= g_17[0]) && p_68))) , l_127), p_68))), &g_22, l_92[3]);
lbl_325:
    l_324 = (safe_mod_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(((*g_59) = (l_127 = ((--(*l_310)) ^ l_127))), ((safe_unary_minus_func_uint64_t_u((l_323[0] = ((safe_rshift_func_uint8_t_u_u(((g_317 = (((g_316 , p_69) > 1L) , 0xF3DCE3E1BB06D71CLL)) == (g_14 | g_80)), 2)) == (l_322 = (safe_add_func_uint8_t_u_u(((0x1F3B6397L == (safe_add_func_uint16_t_u_u(0x40B8L, l_322))) <= l_322), p_69))))))) <= l_324))) , 0x585BL), g_17[0]));
    for (l_324 = 0; (l_324 >= 0); l_324 -= 1)
    { /* block id: 161 */
        uint8_t l_333 = 0UL;
        int32_t l_365 = 0x7AF958F1L;
        uint32_t *l_399 = &g_235;
        int32_t l_423 = (-4L);
        int32_t l_426 = 0x64BDD194L;
        int32_t l_430 = 2L;
        int32_t l_431[7];
        uint8_t l_437 = 0xBDL;
        uint8_t **l_503 = &g_411;
        uint8_t ***l_502[9] = {&l_503,&l_503,&l_503,&l_503,&l_503,&l_503,&l_503,&l_503,&l_503};
        uint32_t l_563 = 1UL;
        int i;
        for (i = 0; i < 7; i++)
            l_431[i] = 0x27902D23L;
        if (g_294.f1)
            goto lbl_325;
        for (l_127 = 0; (l_127 <= 0); l_127 += 1)
        { /* block id: 165 */
            int64_t l_332 = 0x82A758E5FC13390DLL;
            union U0 *l_361 = &g_359;
            int32_t l_364[3];
            uint8_t *l_409 = &l_333;
            uint8_t **l_408 = &l_409;
            uint32_t l_417 = 1UL;
            int32_t l_427 = (-5L);
            int32_t l_489[8] = {0x7A45DEBCL,0L,0x7A45DEBCL,0L,0x7A45DEBCL,0L,0x7A45DEBCL,0L};
            const uint8_t ***l_500 = (void*)0;
            const uint8_t ****l_501 = &l_500;
            int16_t ***l_513 = &g_138;
            int32_t **l_542[3][8] = {{&g_171[1][2],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_171[1][2],&g_171[1][2]},{(void*)0,(void*)0,&g_171[0][3],&g_171[0][3],(void*)0,(void*)0,&g_171[1][2],(void*)0},{(void*)0,(void*)0,&g_171[1][2],(void*)0,(void*)0,&g_171[0][3],&g_171[0][3],(void*)0}};
            int32_t ***l_541 = &l_542[2][0];
            int i, j;
            for (i = 0; i < 3; i++)
                l_364[i] = 0xA74C0A3DL;
            if (((safe_sub_func_int8_t_s_s(((void*)0 != l_309), p_68)) , 1L))
            { /* block id: 166 */
                int32_t *l_328 = &g_120;
                int32_t *l_329 = &l_323[0];
                int32_t *l_330 = (void*)0;
                int32_t *l_331[1][10][4] = {{{(void*)0,&g_17[0],&g_11,&g_17[0]},{&g_17[0],&g_17[0],&g_120,&g_17[0]},{&g_120,&g_17[0],&l_323[0],&l_323[0]},{&l_323[0],&l_323[0],&g_11,(void*)0},{&l_323[0],&g_17[0],&l_323[0],&l_323[0]},{&g_120,(void*)0,&g_120,&l_323[0]},{&g_17[0],(void*)0,&g_11,&l_323[0]},{(void*)0,&g_17[0],&g_17[0],(void*)0},{&g_120,&l_323[0],&g_17[0],&l_323[0]},{(void*)0,&g_17[0],&g_11,&g_17[0]}}};
                uint8_t *l_351 = &g_144[0][0][7];
                uint8_t *l_352 = &g_353;
                int32_t *l_355 = (void*)0;
                int32_t *l_356 = &g_357;
                int i, j, k;
                l_333--;
                (*l_329) = (((((&g_235 != (void*)0) , l_332) & ((safe_add_func_int16_t_s_s(((((safe_rshift_func_int8_t_s_s((*p_67), 4)) ^ ((l_322 = (+(safe_mod_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s((((*l_356) = (safe_sub_func_uint8_t_u_u(l_333, (g_316 , (safe_mod_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(((l_332 | ((*l_352) = ((*l_351) = p_68))) , ((&g_163 != l_354) || p_68)), p_68)), (-1L))))))) , 0x86A8L), 14)), l_322)))) , (*p_67))) != l_333) & g_317), 0x637CL)) & p_69)) && 1UL) ^ l_324);
                if ((*l_329))
                    continue;
            }
            else
            { /* block id: 174 */
                union U0 *l_358 = &g_359;
                union U0 **l_360[3][8][5] = {{{(void*)0,(void*)0,(void*)0,&l_358,&l_358},{(void*)0,&l_358,&l_358,(void*)0,&l_358},{&l_358,&l_358,&l_358,&l_358,&l_358},{&l_358,&l_358,&l_358,&l_358,(void*)0},{&l_358,&l_358,&l_358,(void*)0,&l_358},{(void*)0,&l_358,(void*)0,&l_358,&l_358},{&l_358,&l_358,(void*)0,(void*)0,&l_358},{&l_358,&l_358,&l_358,&l_358,&l_358}},{{&l_358,(void*)0,&l_358,&l_358,&l_358},{&l_358,&l_358,&l_358,&l_358,&l_358},{&l_358,&l_358,&l_358,&l_358,(void*)0},{&l_358,&l_358,&l_358,&l_358,(void*)0},{&l_358,&l_358,&l_358,&l_358,&l_358},{(void*)0,(void*)0,&l_358,(void*)0,(void*)0},{&l_358,&l_358,&l_358,(void*)0,&l_358},{&l_358,&l_358,&l_358,&l_358,(void*)0}},{{&l_358,&l_358,&l_358,&l_358,&l_358},{&l_358,&l_358,&l_358,&l_358,(void*)0},{&l_358,&l_358,(void*)0,&l_358,&l_358},{&l_358,&l_358,(void*)0,&l_358,(void*)0},{&l_358,&l_358,&l_358,&l_358,(void*)0},{&l_358,&l_358,&l_358,(void*)0,&l_358},{(void*)0,&l_358,(void*)0,&l_358,&l_358},{&l_358,&l_358,(void*)0,(void*)0,&l_358}}};
                int32_t *l_362 = &g_17[0];
                int32_t *l_363[5];
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_363[i] = &l_323[0];
                for (g_294.f1 = 0; (g_294.f1 <= 0); g_294.f1 += 1)
                { /* block id: 177 */
                    if (g_294.f1)
                        goto lbl_325;
                }
                l_361 = l_358;
                --l_366[1][0][3];
            }
        }
    }
    (*g_304) = (l_586 = &l_323[0]);
    return &g_147[0][1][8];
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_22 g_134 g_138 g_95 g_17 g_115 g_6 g_139 g_162 g_170 g_3 g_144 g_120 g_11 g_235 g_14 g_171 g_253 g_134.f0 g_108.f0 g_205 g_163 g_294 g_5 g_147
 * writes: g_60 g_22 g_138 g_144 g_147 g_95 g_154 g_115 g_171 g_80 g_205 g_235 g_17 g_290 g_293
 */
static int32_t * func_71(const uint16_t  p_72, int32_t * p_73, int8_t * p_74)
{ /* block id: 38 */
    int16_t *l_131[6][5][1] = {{{(void*)0},{(void*)0},{&g_115},{&g_115},{(void*)0}},{{&g_115},{&g_115},{&g_115},{&g_115},{&g_115}},{{(void*)0},{&g_115},{&g_115},{(void*)0},{(void*)0}},{{(void*)0},{&g_115},{&g_115},{(void*)0},{&g_115}},{{&g_115},{&g_115},{&g_115},{&g_115},{(void*)0}},{{&g_115},{&g_115},{(void*)0},{(void*)0},{(void*)0}}};
    int32_t l_169[6][3] = {{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L},{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L},{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L},{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L},{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L},{0x3AC2B988L,0x8D4CD455L,0x8D4CD455L}};
    int32_t l_208 = (-2L);
    uint8_t *l_217 = &g_144[1][0][2];
    uint8_t **l_216 = &l_217;
    int64_t l_246 = 0x24A45322D5365362LL;
    uint8_t l_272 = 0x45L;
    int32_t l_275 = 0x10044AA3L;
    uint64_t l_303 = 18446744073709551606UL;
    int i, j, k;
    for (g_60 = (-13); (g_60 <= (-22)); g_60--)
    { /* block id: 41 */
        int16_t **l_130 = (void*)0;
        int16_t *l_133 = &g_115;
        int16_t **l_132 = &l_133;
        uint32_t *l_135 = &g_95;
        int16_t ***l_140 = &g_138;
        uint8_t *l_143 = &g_144[0][0][7];
        const int32_t l_145 = 0L;
        int8_t *l_146[9][4];
        int i, j;
        for (i = 0; i < 9; i++)
        {
            for (j = 0; j < 4; j++)
                l_146[i][j] = &g_147[0][1][8];
        }
        (*p_73) |= ((l_131[1][0][0] = &g_115) != ((*l_132) = &g_115));
        if ((p_72 , ((g_134[0] , l_135) != ((safe_add_func_uint32_t_u_u((&l_131[1][0][0] != ((*l_140) = g_138)), ((*p_73) = ((safe_add_func_uint8_t_u_u(((*l_143) = p_72), (g_147[0][3][8] = (((g_95 | (p_72 | g_17[0])) == l_145) & g_115)))) != (-10L))))) , p_73))))
        { /* block id: 49 */
            int64_t l_155 = 0x61C656C0C5E8AE31LL;
            int32_t l_157 = 0x30796FF3L;
            for (g_95 = 0; (g_95 > 23); g_95++)
            { /* block id: 52 */
                int32_t *l_156[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_156[i] = &g_17[0];
                for (g_22 = (-9); (g_22 < (-9)); g_22 = safe_add_func_uint16_t_u_u(g_22, 3))
                { /* block id: 55 */
                    volatile int32_t *l_153[8][7] = {{&g_3,&g_4,&g_4,&g_3,&g_2,&g_9,&g_3},{&g_9,&g_5,(void*)0,(void*)0,&g_5,&g_9,&g_4},{&g_10,&g_3,(void*)0,&g_5,&g_5,(void*)0,&g_3},{&g_5,&g_4,&g_9,&g_5,(void*)0,(void*)0,&g_5},{&g_9,&g_3,&g_9,&g_2,&g_3,&g_4,&g_4},{&g_2,&g_5,&g_3,&g_5,&g_2,&g_3,&g_3},{&g_9,(void*)0,&g_10,&g_9,&g_10,(void*)0,&g_9},{&g_5,&g_9,&g_3,&g_2,&g_9,&g_2,&g_3}};
                    volatile int32_t **l_152[5][10] = {{(void*)0,(void*)0,&l_153[1][5],&l_153[2][5],&l_153[0][5],&l_153[1][5],&l_153[0][5],&l_153[2][5],&l_153[1][5],(void*)0},{&l_153[0][5],(void*)0,(void*)0,&l_153[0][5],(void*)0,(void*)0,&l_153[0][5],(void*)0,(void*)0,&l_153[0][5]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_153[0][5],&l_153[2][5],&l_153[1][5],(void*)0,(void*)0,&l_153[1][5],&l_153[2][5],&l_153[0][5],&l_153[1][5],&l_153[0][5]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                    int i, j;
                    g_154[7] = &g_10;
                    if ((*p_73))
                        break;
                }
                l_157 ^= ((&g_60 == (((&g_147[0][4][8] == &g_122) | g_6) , (((*p_73) = (*p_73)) , (((**g_138) ^ ((((void*)0 == &g_10) < (l_155 = 0UL)) != 0xDB8EL)) , &g_60)))) , 0xCBD639DCL);
            }
            (*p_73) = 0x6D1ADB1FL;
        }
        else
        { /* block id: 64 */
            return &g_6;
        }
        for (g_115 = 0; (g_115 <= 3); g_115 = safe_add_func_int16_t_s_s(g_115, 2))
        { /* block id: 69 */
            (*p_73) = 0L;
            (*p_73) = (safe_div_func_uint8_t_u_u((&g_138 == g_162), (safe_rshift_func_uint16_t_u_u((0x3169L >= p_72), (safe_add_func_uint64_t_u_u(l_169[5][2], 18446744073709551615UL))))));
        }
    }
    (*g_170) = &g_17[0];
    (*p_73) = (*p_73);
    for (g_22 = (-8); (g_22 <= (-14)); --g_22)
    { /* block id: 78 */
        int16_t **l_175[1][2];
        int32_t l_184[5][6] = {{0x51E9EB33L,(-9L),0x8FBF41BDL,0x8FBF41BDL,(-9L),0x51E9EB33L},{0x51E9EB33L,1L,0x6B924B8AL,0x8FBF41BDL,1L,0x8FBF41BDL},{0x51E9EB33L,2L,0x51E9EB33L,0x8FBF41BDL,2L,0x6B924B8AL},{0x51E9EB33L,(-9L),0x8FBF41BDL,0x8FBF41BDL,(-9L),0x51E9EB33L},{0x51E9EB33L,1L,0x6B924B8AL,0x8FBF41BDL,1L,0x8FBF41BDL}};
        const uint8_t *l_185 = &g_186;
        const uint64_t l_207 = 0xD78ABA5384691195LL;
        int16_t l_239 = 2L;
        uint32_t l_284 = 2UL;
        int8_t l_297[1][4];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_175[i][j] = &g_139;
        }
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 4; j++)
                l_297[i][j] = 0xB8L;
        }
        for (g_115 = 0; (g_115 >= 0); g_115 -= 1)
        { /* block id: 81 */
            uint32_t l_209 = 0xE6576148L;
            uint8_t **l_219 = &l_217;
            int32_t *l_238[6] = {&g_11,&g_17[0],&g_11,&g_11,&g_17[0],&g_11};
            int8_t l_240 = 1L;
            uint8_t l_250 = 0xE1L;
            int8_t *l_283[9];
            int i;
            for (i = 0; i < 9; i++)
                l_283[i] = &g_147[0][3][0];
            for (g_60 = 0; (g_60 >= 0); g_60 -= 1)
            { /* block id: 84 */
                int16_t ***l_174 = &g_138;
                int32_t l_206 = 0xE296BD5CL;
                int32_t l_244 = 0L;
                int32_t l_247[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_247[i] = 0L;
                if ((((*l_174) = &g_139) == l_175[0][0]))
                { /* block id: 86 */
                    int32_t l_210 = 0L;
                    uint8_t **l_218 = &l_217;
                    uint32_t *l_234 = &g_235;
                    int32_t l_241 = 0x9119F7A4L;
                    int32_t l_242 = 0x85A3F029L;
                    int32_t l_245 = 0x185341A8L;
                    int32_t l_248 = 0x3CA3E22EL;
                    for (g_80 = 0; (g_80 <= 0); g_80 += 1)
                    { /* block id: 89 */
                        uint8_t *l_200 = (void*)0;
                        uint8_t *l_201 = (void*)0;
                        uint8_t *l_202 = &g_144[1][0][5];
                        uint8_t **l_212[6][3] = {{(void*)0,&l_201,(void*)0},{&l_202,&l_202,&l_202},{(void*)0,&l_201,(void*)0},{&l_202,&l_202,&l_202},{(void*)0,&l_201,(void*)0},{&l_202,&l_202,&l_202}};
                        uint8_t ***l_211 = &l_212[5][1];
                        int i, j;
                        (*l_211) = ((safe_lshift_func_uint8_t_u_u(((g_3 > (l_184[4][3] = (((safe_rshift_func_int8_t_s_s((((safe_add_func_uint16_t_u_u((((safe_lshift_func_uint16_t_u_u((1L <= l_184[0][1]), 12)) ^ l_184[0][0]) , ((l_185 = &g_144[1][0][2]) != (void*)0)), (safe_rshift_func_int16_t_s_s(((safe_add_func_int32_t_s_s(((g_115 , (safe_lshift_func_int16_t_s_u((safe_mod_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((l_208 = (((l_169[5][2] = ((((+((safe_lshift_func_uint8_t_u_u((g_205 = (++(*l_202))), 0)) && l_206)) && ((((l_207 > 0x559AL) >= (*p_73)) >= (-6L)) , 0L)) , 0L) && 0x23590D9DL)) , (-6L)) , l_207)), l_209)), 0x1F5AL)), 2))) && l_209), 1UL)) , 0x4229L), 2)))) & (*g_139)) , 1L), (*p_74))) , p_72) & g_95))) , l_206), l_210)) , (void*)0);
                    }
                    if (((!(((safe_add_func_uint8_t_u_u(((l_218 = l_216) == l_219), ((**l_216)++))) | 0x87L) , l_209)) ^ ((*l_234) = (safe_add_func_int32_t_s_s(0x36D0663BL, (((g_120 <= (safe_div_func_int16_t_s_s((4294967295UL <= (0x10AE63E7L >= (safe_mod_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(l_209, l_206)), 6)), p_72)))), l_169[5][2]))) && p_72) < p_72))))))
                    { /* block id: 101 */
                        int32_t **l_237 = &g_171[2][0];
                        (*l_237) = l_234;
                        if ((**g_170))
                            continue;
                        (*l_237) = l_238[1];
                        if (l_184[0][1])
                            continue;
                    }
                    else
                    { /* block id: 106 */
                        int i;
                        g_17[g_115] ^= l_239;
                    }
                    for (l_208 = 0; (l_208 <= 0); l_208 += 1)
                    { /* block id: 111 */
                        int32_t l_243 = (-1L);
                        int32_t l_249[1][7][7] = {{{(-9L),0x0448002AL,(-9L),1L,1L,0xEB74D902L,0xC22BA50AL},{0L,(-6L),1L,1L,(-6L),0L,(-6L)},{(-9L),1L,1L,0xEB74D902L,0xC22BA50AL,0xEB74D902L,1L},{0L,0L,0L,1L,0L,0L,0L},{(-7L),1L,0L,1L,(-7L),0x5B9073D2L,1L},{0xA0325BEDL,(-6L),0xA0325BEDL,0L,0L,0xA0325BEDL,(-6L)},{1L,0x0448002AL,0L,1L,0xC22BA50AL,1L,0xC22BA50AL}}};
                        int i, j, k;
                        if (l_240)
                            break;
                        l_250++;
                    }
                    (*g_253) = (*g_170);
                }
                else
                { /* block id: 116 */
                    uint8_t **l_273[4][3] = {{(void*)0,(void*)0,(void*)0},{&l_217,&l_217,&l_217},{(void*)0,(void*)0,(void*)0},{&l_217,&l_217,&l_217}};
                    int32_t l_278 = 0xBCA0A6BEL;
                    int i, j;
                    if (((safe_rshift_func_uint16_t_u_u(g_134[0].f0, l_208)) ^ p_72))
                    { /* block id: 117 */
                        int8_t *l_262 = &g_147[0][4][4];
                        int32_t l_271 = (-9L);
                        uint32_t *l_274 = &g_235;
                        l_184[0][1] = (safe_mul_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_s((((*l_262) = l_247[0]) ^ (0L == (((*l_274) = ((safe_lshift_func_uint16_t_u_s((g_108.f0 & ((safe_rshift_func_int16_t_s_u(((safe_rshift_func_uint8_t_u_u(p_72, 3)) != p_72), g_144[0][0][6])) && (((l_184[0][1] , (p_72 , ((safe_add_func_int32_t_s_s(l_271, l_272)) , l_273[0][2]))) == l_219) ^ g_205))), 4)) && l_169[5][2])) , p_72))), l_206)) | p_72) == p_72), l_271));
                        if (l_275)
                            break;
                        return p_73;
                    }
                    else
                    { /* block id: 123 */
                        const int32_t *l_277 = &g_17[0];
                        const int32_t **l_276 = &l_277;
                        l_278 = (p_72 == (l_276 == &p_73));
                    }
                }
            }
            if ((((l_185 != p_74) , ((safe_div_func_uint32_t_u_u((safe_lshift_func_int8_t_s_s((*p_74), (l_284 = ((p_72 , 65526UL) || p_72)))), 1L)) , (safe_lshift_func_uint16_t_u_s(((*g_138) == (p_72 , l_131[1][0][0])), p_72)))) & (-2L)))
            { /* block id: 129 */
                uint16_t *l_289[9][4] = {{&g_290,&g_290,&g_290,&g_290},{(void*)0,&g_290,(void*)0,&g_290},{&g_290,&g_290,&g_290,&g_290},{&g_290,(void*)0,&g_290,&g_290},{&g_290,&g_290,&g_290,&g_290},{&g_290,&g_290,&g_290,&g_290},{&g_290,&g_290,&g_290,&g_290},{&g_290,&g_290,&g_290,&g_290},{&g_290,&g_290,(void*)0,&g_290}};
                int32_t l_298 = (-4L);
                int i, j;
                if ((*p_73))
                    break;
                l_184[0][1] |= ((((safe_add_func_uint16_t_u_u((g_290 = (((*p_74) <= 250UL) && 5UL)), (((g_293 = (safe_rshift_func_uint8_t_u_u((l_175[0][0] == (l_169[2][2] , (*g_162))), 7))) <= (g_294 , ((safe_sub_func_int16_t_s_s((l_208 && g_5), g_147[0][3][2])) <= 1UL))) || l_297[0][1]))) ^ l_298) != (*g_139)) == p_72);
                for (l_208 = (-17); (l_208 >= 28); l_208 = safe_add_func_int16_t_s_s(l_208, 1))
                { /* block id: 136 */
                    for (g_293 = 0; (g_293 >= 9); g_293++)
                    { /* block id: 139 */
                        if ((*p_73))
                            break;
                        l_303 = 0xD84C9E74L;
                    }
                }
            }
            else
            { /* block id: 144 */
                p_73 = (*g_170);
                if ((*p_73))
                    break;
            }
        }
    }
    return p_73;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_108 g_11 g_4 g_6 g_95 g_14 g_123
 * writes: g_5 g_123
 */
static int16_t  func_85(int64_t  p_86, const uint64_t  p_87, uint32_t * p_88, uint32_t  p_89)
{ /* block id: 32 */
    int8_t l_98 = 0xE8L;
    int16_t *l_114[7];
    int32_t l_116 = 0x6866C5D8L;
    int32_t l_117 = 0xCAE23F11L;
    int32_t *l_118[6];
    int8_t l_119 = 0x1DL;
    int32_t l_121 = 0xA82D785AL;
    int i;
    for (i = 0; i < 7; i++)
        l_114[i] = &g_115;
    for (i = 0; i < 6; i++)
        l_118[i] = &g_22;
lbl_126:
    g_5 = ((((safe_lshift_func_int8_t_s_s(l_98, (safe_add_func_uint8_t_u_u((0x84B879C9L || (safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((1UL >= (safe_mul_func_int16_t_s_s(((l_116 = ((g_17[0] == (+(g_108 , (((safe_sub_func_int8_t_s_s(l_98, (g_11 > (safe_rshift_func_int8_t_s_u((~((l_98 & g_4) == (-8L))), g_6))))) , l_98) != g_95)))) & l_98)) != l_98), l_98))), 3)), g_14))), g_11)))) && l_98) != l_117) > p_89);
    g_123--;
    if (g_11)
        goto lbl_126;
    return p_89;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_17[i], "g_17[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_108.f0, "g_108.f0", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_134[i].f0, "g_134[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_144[i][j][k], "g_144[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_147[i][j][k], "g_147[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_186, "g_186", print_hash_value);
    transparent_crc(g_205, "g_205", print_hash_value);
    transparent_crc(g_235, "g_235", print_hash_value);
    transparent_crc(g_290, "g_290", print_hash_value);
    transparent_crc(g_293, "g_293", print_hash_value);
    transparent_crc(g_294.f0, "g_294.f0", print_hash_value);
    transparent_crc(g_294.f1, "g_294.f1", print_hash_value);
    transparent_crc(g_316.f0, "g_316.f0", print_hash_value);
    transparent_crc(g_316.f1, "g_316.f1", print_hash_value);
    transparent_crc(g_317, "g_317", print_hash_value);
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_357, "g_357", print_hash_value);
    transparent_crc(g_359.f0, "g_359.f0", print_hash_value);
    transparent_crc(g_407, "g_407", print_hash_value);
    transparent_crc(g_512, "g_512", print_hash_value);
    transparent_crc(g_544, "g_544", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_570[i].f0, "g_570[i].f0", print_hash_value);
        transparent_crc(g_570[i].f1, "g_570[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_661, "g_661", print_hash_value);
    transparent_crc(g_719.f0, "g_719.f0", print_hash_value);
    transparent_crc(g_719.f1, "g_719.f1", print_hash_value);
    transparent_crc(g_730.f0, "g_730.f0", print_hash_value);
    transparent_crc(g_730.f1, "g_730.f1", print_hash_value);
    transparent_crc(g_814, "g_814", print_hash_value);
    transparent_crc(g_851.f0, "g_851.f0", print_hash_value);
    transparent_crc(g_851.f1, "g_851.f1", print_hash_value);
    transparent_crc(g_880.f0, "g_880.f0", print_hash_value);
    transparent_crc(g_880.f1, "g_880.f1", print_hash_value);
    transparent_crc(g_882, "g_882", print_hash_value);
    transparent_crc(g_1021, "g_1021", print_hash_value);
    transparent_crc(g_1024, "g_1024", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1047[i][j][k].f0, "g_1047[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1137, "g_1137", print_hash_value);
    transparent_crc(g_1144.f0, "g_1144.f0", print_hash_value);
    transparent_crc(g_1144.f1, "g_1144.f1", print_hash_value);
    transparent_crc(g_1192.f0, "g_1192.f0", print_hash_value);
    transparent_crc(g_1192.f1, "g_1192.f1", print_hash_value);
    transparent_crc(g_1205.f0, "g_1205.f0", print_hash_value);
    transparent_crc(g_1205.f1, "g_1205.f1", print_hash_value);
    transparent_crc(g_1219.f0, "g_1219.f0", print_hash_value);
    transparent_crc(g_1219.f1, "g_1219.f1", print_hash_value);
    transparent_crc(g_1272, "g_1272", print_hash_value);
    transparent_crc(g_1353.f0, "g_1353.f0", print_hash_value);
    transparent_crc(g_1353.f1, "g_1353.f1", print_hash_value);
    transparent_crc(g_1354.f0, "g_1354.f0", print_hash_value);
    transparent_crc(g_1354.f1, "g_1354.f1", print_hash_value);
    transparent_crc(g_1429.f0, "g_1429.f0", print_hash_value);
    transparent_crc(g_1429.f1, "g_1429.f1", print_hash_value);
    transparent_crc(g_1434.f0, "g_1434.f0", print_hash_value);
    transparent_crc(g_1434.f1, "g_1434.f1", print_hash_value);
    transparent_crc(g_1448.f0, "g_1448.f0", print_hash_value);
    transparent_crc(g_1448.f1, "g_1448.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1449[i].f0, "g_1449[i].f0", print_hash_value);
        transparent_crc(g_1449[i].f1, "g_1449[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1469.f0, "g_1469.f0", print_hash_value);
    transparent_crc(g_1486.f0, "g_1486.f0", print_hash_value);
    transparent_crc(g_1486.f1, "g_1486.f1", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 332
XXX total union variables: 22

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 9
breakdown:
   indirect level: 0, occurrence: 4
   indirect level: 1, occurrence: 5
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 24
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 14
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 8

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 177
   depth: 2, occurrence: 59
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 6, occurrence: 3
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 17, occurrence: 1
   depth: 18, occurrence: 6
   depth: 19, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 4
   depth: 24, occurrence: 3
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 3
   depth: 30, occurrence: 1
   depth: 34, occurrence: 2
   depth: 36, occurrence: 1
   depth: 41, occurrence: 1

XXX total number of pointers: 323

XXX times a variable address is taken: 710
XXX times a pointer is dereferenced on RHS: 255
breakdown:
   depth: 1, occurrence: 146
   depth: 2, occurrence: 109
XXX times a pointer is dereferenced on LHS: 178
breakdown:
   depth: 1, occurrence: 160
   depth: 2, occurrence: 18
XXX times a pointer is compared with null: 29
XXX times a pointer is compared with address of another variable: 9
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 3643

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 808
   level: 2, occurrence: 302
   level: 3, occurrence: 38
XXX number of pointers point to pointers: 113
XXX number of pointers point to scalars: 201
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 26
XXX average alias set size: 1.47

XXX times a non-volatile is read: 1326
XXX times a non-volatile is write: 545
XXX times a volatile is read: 61
XXX    times read thru a pointer: 3
XXX times a volatile is write: 20
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2.55e+03
XXX percentage of non-volatile access: 95.9

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 202
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 24
   depth: 2, occurrence: 29
   depth: 3, occurrence: 38
   depth: 4, occurrence: 36
   depth: 5, occurrence: 45

XXX percentage a fresh-made variable is used: 16.6
XXX percentage an existing variable is used: 83.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

