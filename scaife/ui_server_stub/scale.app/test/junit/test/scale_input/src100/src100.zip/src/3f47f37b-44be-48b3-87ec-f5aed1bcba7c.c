/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3540825001
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   signed f0 : 19;
   const int8_t * f1;
   uint16_t  f2;
   const uint64_t  f3;
};

union U1 {
   volatile uint32_t  f0;
   uint8_t  f1;
   volatile uint64_t  f2;
};

union U2 {
   volatile unsigned f0 : 15;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3[1][6][7] = {{{0x4A6F4440L,0L,1L,5L,5L,1L,0L},{(-1L),(-8L),0x1FC9A57BL,(-8L),(-1L),(-8L),0x1FC9A57BL},{5L,5L,1L,0L,0x4A6F4440L,0x4A6F4440L,0L},{0x54BCD76CL,0xD3F5047CL,0x54BCD76CL,(-8L),0x54BCD76CL,0xD3F5047CL,0x54BCD76CL},{5L,0L,0L,5L,0x4A6F4440L,1L,1L},{(-1L),0xD3F5047CL,0x1FC9A57BL,0xD3F5047CL,(-1L),0xD3F5047CL,0x1FC9A57BL}}};
static int32_t g_4 = 9L;
static volatile int8_t g_7 = 0x88L;/* VOLATILE GLOBAL g_7 */
static volatile int8_t * volatile g_6 = &g_7;/* VOLATILE GLOBAL g_6 */
static int8_t g_9 = 0xF8L;
static int8_t *g_8 = &g_9;
static uint32_t g_41 = 0UL;
static int32_t g_52 = 0xAA7D8725L;
static uint32_t g_54 = 0xFF147090L;
static uint32_t *g_53 = &g_54;
static int16_t g_60 = 0x458BL;
static uint16_t g_61 = 65530UL;
static union U0 g_81 = {0xBFBCC831L};
static uint8_t g_104[4] = {0xCAL,0xCAL,0xCAL,0xCAL};
static int16_t g_106 = (-1L);
static const volatile int8_t * volatile *g_119 = (void*)0;
static const volatile int8_t g_122 = 0x70L;/* VOLATILE GLOBAL g_122 */
static const volatile int8_t * volatile g_121 = &g_122;/* VOLATILE GLOBAL g_121 */
static const uint64_t g_126 = 0xCC70ECFAE2F6F5F9LL;
static const uint64_t *g_125 = &g_126;
static int8_t g_132 = (-5L);
static int64_t g_154 = 0x3165A292D23B9165LL;
static int32_t g_156 = 0xA757E757L;
static union U1 g_182 = {4294967287UL};/* VOLATILE GLOBAL g_182 */
static union U1 g_183 = {0UL};/* VOLATILE GLOBAL g_183 */
static uint64_t g_202[4] = {1UL,1UL,1UL,1UL};
static union U1 g_207 = {4294967295UL};/* VOLATILE GLOBAL g_207 */
static int8_t g_218 = 0xFAL;
static union U1 g_230 = {4294967292UL};/* VOLATILE GLOBAL g_230 */
static union U1 g_232 = {3UL};/* VOLATILE GLOBAL g_232 */
static const int16_t g_254 = 1L;
static union U1 *g_262 = (void*)0;
static int64_t *g_271[9] = {&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154};
static union U1 **g_292[5][1][3] = {{{&g_262,&g_262,&g_262}},{{(void*)0,(void*)0,(void*)0}},{{&g_262,&g_262,&g_262}},{{(void*)0,(void*)0,(void*)0}},{{&g_262,&g_262,&g_262}}};
static union U1 ***g_291 = &g_292[2][0][1];
static int8_t g_319 = 0L;
static int8_t g_322 = 1L;
static uint32_t g_324 = 0x8511FF11L;
static int32_t g_401 = 0x541151AAL;
static int32_t g_408 = 0x9D33BB9BL;
static int8_t g_409 = (-1L);
static uint32_t g_410[8] = {0xC75A7728L,4294967288UL,4294967288UL,0xC75A7728L,4294967288UL,4294967288UL,0xC75A7728L,4294967288UL};
static uint8_t g_414 = 0xB4L;
static int16_t g_424[4][10] = {{0x7FD0L,0x8BE2L,0x770FL,0x7FD0L,8L,0x6549L,0x8BE2L,0x8BE2L,0x6549L,8L},{0x7FD0L,9L,9L,0x7FD0L,2L,0xA581L,0x8BE2L,9L,0xA581L,8L},{0xA581L,0x8BE2L,9L,0xA581L,8L,0xA581L,9L,0x8BE2L,0xA581L,2L},{0x7FD0L,0x8BE2L,0x770FL,0x7FD0L,8L,0x6549L,0x8BE2L,0x8BE2L,0x6549L,8L}};
static uint32_t g_425 = 0xA4F82BEEL;
static uint16_t *g_466 = &g_61;
static uint16_t **g_465 = &g_466;
static uint32_t g_471 = 9UL;
static union U2 g_484 = {0x7E93E1E0L};/* VOLATILE GLOBAL g_484 */
static int32_t g_520 = (-8L);
static uint8_t * volatile g_528 = &g_230.f1;/* VOLATILE GLOBAL g_528 */
static uint8_t * volatile *g_527 = &g_528;
static uint16_t g_550 = 0x1BEAL;
static volatile union U2 g_554[3][5] = {{{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL}},{{1UL},{1UL},{1UL},{1UL},{1UL}},{{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL},{0x520D7E9BL}}};
static volatile union U2 *g_553 = &g_554[2][2];
static volatile union U2 g_556 = {4UL};/* VOLATILE GLOBAL g_556 */
static int32_t *g_632[5][9] = {{(void*)0,&g_4,&g_52,&g_401,&g_52,&g_4,(void*)0,(void*)0,&g_4},{&g_401,&g_4,&g_156,&g_4,&g_401,&g_520,&g_520,&g_401,&g_4},{(void*)0,&g_52,(void*)0,&g_520,&g_156,&g_156,&g_520,(void*)0,&g_52},{&g_52,(void*)0,&g_520,&g_156,&g_156,&g_520,(void*)0,&g_52,(void*)0},{&g_4,&g_401,&g_520,&g_520,&g_401,&g_4,&g_156,&g_4,&g_401}};
static int32_t **g_631 = &g_632[1][6];
static uint64_t *g_665 = (void*)0;
static union U1 g_673 = {0x4950D8E5L};/* VOLATILE GLOBAL g_673 */
static union U1 g_674 = {3UL};/* VOLATILE GLOBAL g_674 */
static union U1 g_676[3] = {{1UL},{1UL},{1UL}};
static union U1 g_678 = {3UL};/* VOLATILE GLOBAL g_678 */
static volatile union U0 g_692 = {0L};/* VOLATILE GLOBAL g_692 */
static volatile union U0 *g_691 = &g_692;
static volatile union U0 ** const g_690 = &g_691;
static int16_t g_726 = 0x1042L;
static uint16_t * const *g_752 = &g_466;
static uint16_t * const **g_751[4] = {&g_752,&g_752,&g_752,&g_752};
static const int32_t *g_805[8] = {&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401,&g_401};
static volatile union U0 g_830[3] = {{0xEC56C9B1L},{0xEC56C9B1L},{0xEC56C9B1L}};
static volatile union U0 *g_829 = &g_830[0];
static union U2 g_894 = {4294967295UL};/* VOLATILE GLOBAL g_894 */
static int16_t * const g_992[7][3][1] = {{{&g_60},{&g_60},{&g_106}},{{&g_60},{&g_60},{&g_424[0][1]}},{{&g_424[0][1]},{&g_60},{&g_60}},{{&g_106},{&g_60},{&g_60}},{{&g_424[0][1]},{&g_424[0][1]},{&g_60}},{{&g_60},{&g_106},{&g_60}},{{&g_60},{&g_424[0][1]},{&g_424[0][1]}}};
static int16_t * const *g_991 = &g_992[5][1][0];
static uint16_t g_1021[1][5][9] = {{{65535UL,0x0841L,65535UL,65533UL,65535UL,0x0841L,65535UL,65535UL,0x0841L},{65535UL,65527UL,1UL,65527UL,65535UL,0UL,0UL,0UL,8UL},{65533UL,0x0085L,65533UL,65535UL,65535UL,65535UL,65535UL,65533UL,0x0085L},{65534UL,65535UL,1UL,65535UL,65535UL,1UL,65535UL,65534UL,65535UL},{65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL}}};
static union U1 g_1026 = {0x936A0DADL};/* VOLATILE GLOBAL g_1026 */
static int16_t g_1077[10] = {0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L,0xBBF5L};
static int32_t **g_1088 = &g_632[1][6];
static const union U1 g_1200 = {0xE328B83EL};/* VOLATILE GLOBAL g_1200 */
static const union U1 *g_1203 = (void*)0;
static const union U1 **g_1202[3][1] = {{&g_1203},{&g_1203},{&g_1203}};
static const union U1 ***g_1201 = &g_1202[1][0];
static int16_t g_1239 = 5L;
static uint64_t * volatile * volatile *g_1329 = (void*)0;
static int16_t g_1332 = (-3L);
static uint16_t g_1342[5] = {0xFED0L,0xFED0L,0xFED0L,0xFED0L,0xFED0L};
static union U2 g_1348 = {4294967294UL};/* VOLATILE GLOBAL g_1348 */
static union U2 g_1349 = {0x5212EF1EL};/* VOLATILE GLOBAL g_1349 */
static union U2 *g_1347[4] = {&g_1348,&g_1348,&g_1348,&g_1348};
static uint8_t g_1436 = 247UL;
static uint32_t g_1451 = 0xE6ADC4D0L;
static union U2 g_1469 = {4294967295UL};/* VOLATILE GLOBAL g_1469 */
static union U2 g_1470 = {4294967293UL};/* VOLATILE GLOBAL g_1470 */
static union U2 g_1472[2] = {{4294967291UL},{4294967291UL}};
static int8_t g_1584[2] = {0x6CL,0x6CL};
static volatile uint16_t * const ** volatile **g_1595 = (void*)0;
static int8_t g_1614 = 0L;
static uint64_t g_1615[8][7] = {{0xE54C6E8252DC9E24LL,0xFFE1062BEBC571DFLL,0xFFE1062BEBC571DFLL,0xE54C6E8252DC9E24LL,18446744073709551615UL,0xE54C6E8252DC9E24LL,0xFFE1062BEBC571DFLL},{1UL,1UL,0xFFE1062BEBC571DFLL,0xE9A7739E3B787BBFLL,0xFFE1062BEBC571DFLL,1UL,1UL},{1UL,0xFFE1062BEBC571DFLL,0xE9A7739E3B787BBFLL,0xFFE1062BEBC571DFLL,1UL,1UL,0xFFE1062BEBC571DFLL},{0xE54C6E8252DC9E24LL,18446744073709551615UL,0xE54C6E8252DC9E24LL,0xFFE1062BEBC571DFLL,0xFFE1062BEBC571DFLL,0xE54C6E8252DC9E24LL,18446744073709551615UL},{0xFFE1062BEBC571DFLL,18446744073709551615UL,0xE9A7739E3B787BBFLL,0xE9A7739E3B787BBFLL,18446744073709551615UL,0xFFE1062BEBC571DFLL,18446744073709551615UL},{0xE54C6E8252DC9E24LL,0xFFE1062BEBC571DFLL,0xFFE1062BEBC571DFLL,0xE54C6E8252DC9E24LL,18446744073709551615UL,0xE54C6E8252DC9E24LL,0xFFE1062BEBC571DFLL},{1UL,1UL,0xFFE1062BEBC571DFLL,0xE9A7739E3B787BBFLL,0xFFE1062BEBC571DFLL,1UL,1UL},{1UL,0xFFE1062BEBC571DFLL,0xE9A7739E3B787BBFLL,0xFFE1062BEBC571DFLL,1UL,1UL,0xFFE1062BEBC571DFLL}};
static int64_t * const *g_1776 = &g_271[6];
static int64_t * const **g_1775 = &g_1776;
static union U1 g_1900 = {0xC8FD1575L};/* VOLATILE GLOBAL g_1900 */
static union U2 g_1917 = {0x40CE26B4L};/* VOLATILE GLOBAL g_1917 */
static union U2 g_1919 = {4294967295UL};/* VOLATILE GLOBAL g_1919 */
static union U2 *g_1918 = &g_1919;
static union U2 g_1921 = {4294967295UL};/* VOLATILE GLOBAL g_1921 */
static union U1 g_1924 = {0x6FB580D3L};/* VOLATILE GLOBAL g_1924 */
static int16_t g_1939 = 0L;
static volatile uint64_t *g_1963 = (void*)0;
static volatile uint64_t **g_1962 = &g_1963;
static volatile uint64_t ** volatile *g_1961 = &g_1962;
static volatile uint64_t ** volatile ** const  volatile g_1960 = &g_1961;/* VOLATILE GLOBAL g_1960 */
static volatile uint64_t ** volatile ** const  volatile *g_1959 = &g_1960;
static int16_t g_1965 = 0xEEC8L;
static union U2 g_1983 = {0xDB9218B4L};/* VOLATILE GLOBAL g_1983 */
static int64_t **g_1987 = (void*)0;
static int64_t ***g_1986 = &g_1987;
static union U2 g_2101 = {4294967295UL};/* VOLATILE GLOBAL g_2101 */
static union U2 g_2126 = {2UL};/* VOLATILE GLOBAL g_2126 */
static union U2 g_2129 = {3UL};/* VOLATILE GLOBAL g_2129 */
static union U1 g_2202 = {0x93483032L};/* VOLATILE GLOBAL g_2202 */
static int8_t *g_2212 = &g_319;
static union U1 g_2398 = {4UL};/* VOLATILE GLOBAL g_2398 */
static union U0 *g_2447 = (void*)0;
static union U0 **g_2446[10] = {&g_2447,&g_2447,&g_2447,&g_2447,&g_2447,&g_2447,&g_2447,&g_2447,&g_2447,&g_2447};
static union U0 ***g_2445 = &g_2446[5];
static union U1 g_2455 = {4294967288UL};/* VOLATILE GLOBAL g_2455 */
static union U1 g_2456 = {4294967290UL};/* VOLATILE GLOBAL g_2456 */
static int32_t g_2551 = 1L;
static int16_t *g_2712 = &g_106;
static int16_t **g_2711 = &g_2712;
static int16_t ***g_2710 = &g_2711;
static int64_t g_2745 = 0xD834670EA8E11CF2LL;
static int8_t g_2765 = 0xE6L;
static int64_t g_2767 = 0xB4B3FC93EDB1A997LL;
static int16_t g_2977 = 0L;
static uint8_t *g_3035 = &g_1436;
static uint8_t **g_3034 = &g_3035;
static int8_t g_3083[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
static volatile uint64_t g_3129 = 0x5F25FBE4C1A5A110LL;/* VOLATILE GLOBAL g_3129 */
static int32_t g_3172[3] = {8L,8L,8L};
static volatile union U2 g_3217[9] = {{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}};
static union U1 g_3224 = {0x26DB002EL};/* VOLATILE GLOBAL g_3224 */
static union U2 g_3226 = {0xAF208BCBL};/* VOLATILE GLOBAL g_3226 */
static union U2 g_3245 = {0x4466AAAEL};/* VOLATILE GLOBAL g_3245 */
static volatile union U1 g_3270[7][8][4] = {{{{0x24C4F841L},{0x1D580EFDL},{1UL},{4294967291UL}},{{1UL},{0xF8339969L},{4294967295UL},{4294967295UL}},{{0x44016E2AL},{0UL},{4294967295UL},{0x82B6D562L}},{{9UL},{0x24C4F841L},{8UL},{0x4224D6D7L}},{{8UL},{0xD431FDD6L},{0x6E47BAEFL},{0xF8339969L}},{{0x77E13E66L},{0xC15EEEA5L},{0xC1F6CC2EL},{4294967288UL}},{{4294967293UL},{0UL},{0x91FCCB2FL},{0xA2FA4A60L}},{{0x54682B95L},{4294967295UL},{0x24C4F841L},{0x1C1899A4L}}},{{{4294967288UL},{0xE4E5D4B6L},{4294967288UL},{0x54682B95L}},{{0UL},{9UL},{0UL},{0x987818C2L}},{{4294967295UL},{0x0784F187L},{0x3A46405FL},{9UL}},{{5UL},{0x995A4564L},{0x3A46405FL},{4294967295UL}},{{4294967295UL},{4294967295UL},{4294967288UL},{0x55AADBD3L}},{{0x995A4564L},{4294967295UL},{0x1E21E926L},{8UL}},{{0x1E21E926L},{8UL},{0xC6A2C5AEL},{0xA2FA4A60L}},{{0x2237F6DBL},{0xF1B88052L},{0xD431FDD6L},{9UL}}},{{{0xA2FA4A60L},{0x1E21E926L},{0x4224D6D7L},{0x1C1899A4L}},{{4294967295UL},{0xFB384F5CL},{8UL},{4294967290UL}},{{5UL},{4294967295UL},{4294967291UL},{4294967295UL}},{{0x24C4F841L},{0xD431FDD6L},{0x82B6D562L},{4294967288UL}},{{3UL},{0x55AADBD3L},{0x1D580EFDL},{0UL}},{{0xFB384F5CL},{9UL},{9UL},{0xFB384F5CL}},{{0xC6A2C5AEL},{8UL},{0xC1F6CC2EL},{1UL}},{{0xE4E5D4B6L},{0x3A46405FL},{0UL},{0x6E47BAEFL}}},{{{0x08CB8FD7L},{0UL},{0xF1B88052L},{0x6E47BAEFL}},{{0xC15EEEA5L},{0x3A46405FL},{0UL},{1UL}},{{4294967295UL},{8UL},{0x0784F187L},{0xFB384F5CL}},{{0x1C1899A4L},{9UL},{0x08CB8FD7L},{0UL}},{{0x44016E2AL},{0x55AADBD3L},{0x1C1899A4L},{4294967288UL}},{{4294967291UL},{0xD431FDD6L},{4294967286UL},{4294967295UL}},{{1UL},{4294967295UL},{0x54682B95L},{4294967290UL}},{{0xC1F6CC2EL},{0xFB384F5CL},{0x3A46405FL},{0x1C1899A4L}}},{{{0xE8C83E62L},{0x1E21E926L},{0x6E47BAEFL},{9UL}},{{9UL},{0xF1B88052L},{0x77E13E66L},{0xA2FA4A60L}},{{0x3A46405FL},{8UL},{0xA2FA4A60L},{8UL}},{{0xF8339969L},{4294967295UL},{1UL},{0x55AADBD3L}},{{0xFED71F2CL},{4294967295UL},{0xE8C83E62L},{0xE4E5D4B6L}},{{0x1D580EFDL},{4294967288UL},{0x2237F6DBL},{0x24C4F841L}},{{0x1D580EFDL},{0x987818C2L},{0xE8C83E62L},{0UL}},{{0xFED71F2CL},{0x24C4F841L},{1UL},{0x2237F6DBL}}},{{{0xF8339969L},{0xFED71F2CL},{0xA2FA4A60L},{0UL}},{{0x3A46405FL},{0x82B6D562L},{0x77E13E66L},{0xC1F6CC2EL}},{{9UL},{0x995A4564L},{0x6E47BAEFL},{0x54682B95L}},{{0xE8C83E62L},{0x6E47BAEFL},{0x3A46405FL},{4294967295UL}},{{0xC1F6CC2EL},{4294967286UL},{0x54682B95L},{0xC15EEEA5L}},{{1UL},{0xC6A2C5AEL},{4294967286UL},{0xF1B88052L}},{{4294967291UL},{4294967288UL},{0x1C1899A4L},{0xE8C83E62L}},{{0x44016E2AL},{4294967295UL},{0x08CB8FD7L},{0x08CB8FD7L}}},{{{0x1C1899A4L},{0x1C1899A4L},{0x0784F187L},{4294967288UL}},{{4294967295UL},{0x1D580EFDL},{0UL},{8UL}},{{0xC15EEEA5L},{0xE4E5D4B6L},{0xF1B88052L},{0UL}},{{0x08CB8FD7L},{0xE4E5D4B6L},{0UL},{8UL}},{{0xE4E5D4B6L},{0x1D580EFDL},{0xC1F6CC2EL},{4294967288UL}},{{0xC6A2C5AEL},{0x1C1899A4L},{9UL},{0x08CB8FD7L}},{{0xFB384F5CL},{4294967295UL},{0x1D580EFDL},{0xE8C83E62L}},{{3UL},{4294967288UL},{0x82B6D562L},{0xF1B88052L}}}};
static volatile int16_t g_3310[4] = {0x8FEAL,0x8FEAL,0x8FEAL,0x8FEAL};
static int32_t *g_3312[3][1][9] = {{{(void*)0,&g_2551,&g_520,&g_2551,(void*)0,(void*)0,&g_2551,&g_520,&g_2551}},{{(void*)0,&g_2551,&g_401,&g_2551,&g_520,&g_52,&g_520,&g_2551,&g_2551}},{{&g_2551,&g_2551,&g_2551,&g_401,&g_2551,&g_2551,&g_2551,&g_2551,&g_401}}};
static int16_t ***g_3340 = (void*)0;
static union U2 g_3360[3] = {{0x43353A3FL},{0x43353A3FL},{0x43353A3FL}};


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint32_t  func_12(uint64_t  p_13, int8_t * p_14, int8_t * p_15, union U0  p_16, int32_t  p_17);
static uint64_t  func_18(union U0  p_19, int8_t * p_20, int8_t * p_21, const uint32_t  p_22);
static union U0  func_23(int8_t  p_24);
static int32_t  func_25(int8_t * p_26, uint16_t  p_27, int8_t * p_28, int8_t * p_29, int8_t * p_30);
static int8_t * func_33(int32_t  p_34, int64_t  p_35, uint8_t  p_36, int8_t * p_37, uint32_t  p_38);
static int64_t  func_42(uint8_t  p_43, uint32_t * p_44, int8_t * p_45, int8_t  p_46);
static uint64_t  func_66(union U0  p_67, int32_t  p_68, int64_t  p_69, int8_t  p_70);
static union U0  func_71(int16_t  p_72);
static uint16_t  func_74(uint64_t  p_75, union U0  p_76, uint32_t  p_77, union U0  p_78);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_631 g_632 g_1088 g_673.f1
 * writes: g_4 g_632 g_673.f1
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2[4];
    union U0 l_2979 = {0x23AB0860L};
    int32_t l_3116 = 4L;
    uint16_t l_3118 = 0x49D2L;
    uint32_t l_3121 = 9UL;
    union U0 ** const *l_3148 = &g_2446[3];
    union U0 ** const ** const l_3147[9] = {&l_3148,&l_3148,&l_3148,&l_3148,&l_3148,&l_3148,&l_3148,&l_3148,&l_3148};
    uint64_t l_3195 = 1UL;
    int64_t l_3206 = 0xAF2ED7767AB2DEBELL;
    int32_t l_3258 = 3L;
    int32_t l_3260[7];
    int8_t l_3264 = 0xFCL;
    const uint32_t l_3382[10][6] = {{0x499568D2L,2UL,18446744073709551615UL,0x9AAF9134L,0xEAA18650L,18446744073709551607UL},{18446744073709551607UL,1UL,2UL,2UL,1UL,18446744073709551607UL},{0x9AAF9134L,1UL,18446744073709551615UL,0x980E8402L,18446744073709551607UL,9UL},{1UL,0x499568D2L,18446744073709551613UL,18446744073709551607UL,18446744073709551613UL,0x499568D2L},{1UL,9UL,18446744073709551607UL,0x980E8402L,18446744073709551615UL,1UL},{0x9AAF9134L,18446744073709551607UL,1UL,2UL,2UL,1UL},{18446744073709551607UL,18446744073709551607UL,0xEAA18650L,0x9AAF9134L,18446744073709551615UL,2UL},{0x499568D2L,9UL,0x980E8402L,0xEAA18650L,18446744073709551613UL,0xEAA18650L},{0x980E8402L,0x499568D2L,0x980E8402L,1UL,18446744073709551607UL,2UL},{0x6C3E2BF0L,1UL,0xEAA18650L,8UL,1UL,1UL}};
    int i, j;
    for (i = 0; i < 4; i++)
        l_2[i] = 4294967286UL;
    for (i = 0; i < 7; i++)
        l_3260[i] = 1L;
    for (g_4 = 0; (g_4 <= 3); g_4 += 1)
    { /* block id: 3 */
        int8_t *l_2256 = (void*)0;
        int32_t *l_3117[8] = {(void*)0,&g_52,(void*)0,(void*)0,&g_52,(void*)0,(void*)0,&g_52};
        union U1 *l_3174[1][7][3] = {{{&g_207,&g_232,&g_207},{&g_183,(void*)0,&g_1900},{&g_183,&g_183,(void*)0},{&g_207,(void*)0,(void*)0},{(void*)0,&g_232,&g_1900},{&g_207,&g_232,&g_207},{&g_183,(void*)0,&g_1900}}};
        int8_t l_3225[8];
        uint16_t ***l_3234 = &g_465;
        uint16_t ****l_3233 = &l_3234;
        uint16_t *****l_3232 = &l_3233;
        uint64_t l_3286 = 0xDD7835B86EE7D5AFLL;
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_3225[i] = 0L;
    }
    for (l_3116 = 0; (l_3116 > 18); ++l_3116)
    { /* block id: 1534 */
        int16_t ***l_3337 = &g_2711;
        int16_t ****l_3338 = (void*)0;
        int16_t ****l_3339 = &l_3337;
        int32_t l_3344 = 0xBD594886L;
        int32_t *l_3348 = &l_3258;
        uint16_t ****l_3373 = (void*)0;
        uint16_t *****l_3372 = &l_3373;
        int8_t l_3422[9];
        const int32_t l_3424 = (-7L);
        int i;
        for (i = 0; i < 9; i++)
            l_3422[i] = 1L;
    }
    (*g_1088) = (*g_631);
    for (g_673.f1 = 0; (g_673.f1 >= 20); g_673.f1 = safe_add_func_int8_t_s_s(g_673.f1, 2))
    { /* block id: 1584 */
        int32_t *l_3430 = (void*)0;
        int32_t l_3431 = 0x0CB2C051L;
        l_3431 = 0x5D55B1F2L;
        (*g_1088) = (*g_631);
    }
    return l_3264;
}


/* ------------------------------------------ */
/* 
 * reads : g_2712 g_106 g_53 g_104 g_322 g_125 g_126 g_183.f1 g_1088 g_527 g_324 g_690 g_691 g_3034 g_3035 g_1436 g_2212 g_319 g_466 g_61 g_2710 g_2711 g_54 g_119 g_52 g_154 g_156 g_3083 g_752 g_1451 g_471 g_424 g_631 g_2551
 * writes: g_54 g_104 g_322 g_183.f1 g_2551 g_632 g_106 g_2447 g_3034 g_154 g_156 g_3083 g_1451 g_471 g_1436 g_202
 */
static uint32_t  func_12(uint64_t  p_13, int8_t * p_14, int8_t * p_15, union U0  p_16, int32_t  p_17)
{ /* block id: 1368 */
    uint32_t l_2984 = 0x7DFC97EEL;
    int8_t l_2990 = 0xA6L;
    int32_t l_2991 = 0xA3C670B7L;
    int32_t l_2999 = 2L;
    uint8_t *l_3000 = &g_104[1];
    int32_t l_3001 = 0xD66F16D8L;
    uint8_t *l_3002 = &g_183.f1;
    uint16_t l_3082 = 1UL;
    uint64_t ***l_3088 = (void*)0;
    uint64_t ****l_3087[1][7][2] = {{{&l_3088,&l_3088},{&l_3088,&l_3088},{&l_3088,&l_3088},{&l_3088,&l_3088},{&l_3088,&l_3088},{&l_3088,&l_3088},{&l_3088,&l_3088}}};
    uint64_t *****l_3086 = &l_3087[0][4][0];
    int i, j, k;
    if (((p_16.f0 <= (safe_sub_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u((0UL > (((((l_2984 >= ((*l_3002) ^= (((safe_rshift_func_uint16_t_u_s((safe_mod_func_int8_t_s_s((l_3001 = ((*p_14) |= (+((((*l_3000) |= (((((l_2991 = l_2990) | 3L) && p_13) > (((((*g_53) = (safe_mod_func_uint16_t_u_u(p_13, (*g_2712)))) > (!(safe_rshift_func_int16_t_s_u(l_2999, 3)))) < (-7L)) >= p_13)) ^ l_2990)) <= l_2999) | 1L)))), 0x90L)), 12)) || (*g_125)) ^ 0x1FE765B9DE5B90D9LL))) , l_2991) <= l_2990) == l_2990) | p_16.f0)), l_2990)) ^ l_2984), l_2999))) , l_2984))
    { /* block id: 1375 */
        uint8_t l_3012 = 0x94L;
        uint8_t **l_3037 = (void*)0;
        uint32_t l_3046 = 0xE73EF299L;
        int32_t l_3047 = 0xEB75196CL;
        uint32_t l_3081 = 4294967292UL;
        int32_t l_3085 = 4L;
        union U0 **l_3092 = (void*)0;
        union U0 **l_3093 = &g_2447;
        int32_t *l_3113 = &l_2991;
lbl_3114:
        for (g_2551 = 0; (g_2551 < (-25)); --g_2551)
        { /* block id: 1378 */
            int8_t l_3005 = 0x91L;
            int32_t *l_3006[2][6][9] = {{{&l_2991,&l_2991,&g_401,&l_2991,&l_2991,&g_401,&g_156,&l_2991,&g_4},{&g_156,(void*)0,&g_2551,&l_3001,&l_2991,&g_2551,&l_3001,&g_156,(void*)0},{&g_2551,&g_52,&g_401,&g_4,&g_4,&g_401,&g_52,&g_2551,&g_52},{&g_2551,&g_4,(void*)0,&l_3001,&g_4,&g_520,&l_2991,&g_2551,&g_4},{&l_2991,&g_52,&g_52,&l_2991,&g_2551,&g_4,&g_2551,&l_2991,&g_52},{(void*)0,(void*)0,&g_2551,&g_4,&g_401,&g_4,&l_2991,(void*)0,(void*)0}},{{&g_52,&l_2991,&g_156,&l_2991,&g_2551,&g_4,&g_52,&g_520,&g_52},{&g_520,&g_520,(void*)0,&g_520,&g_520,&l_2991,&g_52,&g_520,&g_156},{&g_520,&l_3001,&l_2991,&g_520,&l_2991,&g_2551,&g_520,&g_520,&g_52},{(void*)0,&g_156,&l_2991,&l_2991,&l_2991,&l_2991,&g_156,(void*)0,&g_4},{&g_52,&l_3001,&g_4,&g_520,&l_3001,&g_52,&l_2991,&g_52,&g_156},{&g_520,&g_156,&g_4,&g_520,(void*)0,&l_3001,(void*)0,&g_520,&g_4}}};
            uint16_t l_3007 = 0x40D9L;
            int64_t *l_3013[7][2][6] = {{{&g_2767,&g_154,&g_2745,&g_154,&g_2767,&g_2767},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_2767,&g_2767,&g_154,&g_2745,&g_154,&g_2767}},{{&g_154,&g_154,&g_2745,&g_2745,&g_154,&g_154},{&g_2767,&g_154,&g_2745,&g_154,&g_2767,&g_2767}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_2767,&g_2767,&g_154,&g_2745,&g_154,&g_2767},{&g_154,&g_154,&g_2745,&g_2745,&g_154,&g_154}},{{&g_2767,&g_154,&g_2745,&g_154,&g_2767,&g_2767},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_2767,&g_2767,&g_154,&g_2745,&g_154,&g_2767}}};
            int32_t l_3016 = (-3L);
            int i, j, k;
            p_16.f0 = (l_3007 ^= l_3005);
            (*g_1088) = (void*)0;
            if ((safe_sub_func_uint32_t_u_u((((safe_sub_func_int64_t_s_s((l_3001 |= l_3012), p_16.f0)) && (safe_sub_func_uint16_t_u_u(l_3016, (safe_mod_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((g_527 == (void*)0), 2)), ((*g_2712) = (safe_unary_minus_func_int16_t_s((*g_2712))))))))) | ((safe_div_func_int32_t_s_s(l_2999, (0x9265L | p_16.f0))) , g_324)), l_3012)))
            { /* block id: 1384 */
                uint16_t l_3024[4][2][10] = {{{1UL,1UL,0x89F3L,65535UL,65533UL,0xDA6FL,0xD33CL,1UL,0x3856L,0xD33CL},{0xB3AAL,1UL,0xD709L,65535UL,1UL,65534UL,0xD33CL,65534UL,1UL,65535UL}},{{65533UL,1UL,65533UL,0xD709L,0xD33CL,1UL,0xD709L,9UL,0xBD10L,65533UL},{9UL,0xB3AAL,0x3856L,65535UL,1UL,1UL,9UL,9UL,1UL,1UL}},{{0xB3AAL,65533UL,65533UL,0xB3AAL,0xBD10L,1UL,1UL,65534UL,65533UL,9UL},{0xBD10L,9UL,0xD709L,1UL,0xD33CL,0xD709L,65533UL,1UL,65533UL,0xD709L}},{{0xD709L,65533UL,1UL,65533UL,0xD709L,0xD33CL,1UL,0xD709L,9UL,0xBD10L},{5UL,0x9416L,0x3856L,0xD709L,1UL,0xD11BL,0xBD10L,0x9416L,0x9416L,0xBD10L}}};
                int i, j, k;
                ++l_3024[3][1][1];
            }
            else
            { /* block id: 1386 */
                union U0 **l_3033 = &g_2447;
                uint8_t ***l_3036 = &g_3034;
                uint8_t ***l_3038 = &l_3037;
                int32_t l_3045 = 1L;
                if ((p_16.f0 = (safe_sub_func_uint8_t_u_u((p_16 , (safe_lshift_func_uint8_t_u_u(((*l_3002) = ((safe_mul_func_int8_t_s_s((((*g_690) == ((*l_3033) = &p_16)) != (((*l_3036) = g_3034) == ((*l_3038) = (p_16 , l_3037)))), ((((l_3046 = ((safe_sub_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((*g_3035), (*g_2212))), ((l_3045 < l_3012) | l_2984))), l_3012)) != p_13)) < 0x3CL) , &g_156) == (void*)0))) < p_16.f0)), 4))), 252UL))))
                { /* block id: 1393 */
                    uint32_t l_3048 = 0UL;
                    int32_t l_3084 = (-1L);
                    int32_t l_3089 = 0xE1A66F6FL;
                    ++l_3048;
                    if ((l_3089 &= ((p_13 | (safe_mod_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((((safe_lshift_func_uint8_t_u_s(((+(safe_unary_minus_func_uint32_t_u(0xD0BEA259L))) < ((safe_lshift_func_uint8_t_u_s(((safe_mul_func_uint16_t_u_u(((((safe_mul_func_int16_t_s_s(0x53A7L, (safe_mul_func_uint16_t_u_u((*g_466), ((safe_rshift_func_int8_t_s_u(((safe_mod_func_int32_t_s_s(((l_3084 |= ((((((*g_53) = (l_3048 ^ ((*g_2712) = (safe_mod_func_int16_t_s_s((g_3083[7] |= (((*g_2710) != (*g_2710)) , (l_3048 <= (safe_lshift_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((((func_71(((***g_2710) &= ((safe_lshift_func_uint8_t_u_u(0x93L, l_3081)) < 0x1AL))) , 0xDE7F8942L) <= (*g_53)) == p_16.f0), l_3082)) >= p_16.f0), l_3012))))), (**g_752)))))) , (*g_53)) && 4294967289UL) != 18446744073709551615UL) != l_3048)) && l_3085), 1L)) , l_3046), 7)) <= 2UL))))) != 0UL) , (void*)0) == l_3086), p_13)) > p_13), (*g_2212))) ^ (*p_14))), l_3085)) != p_17) , 0x89AC35681CDB20EDLL), l_3045)), (-1L))), l_3012))) & 4294967295UL)))
                    { /* block id: 1401 */
                        if (p_13)
                            break;
                    }
                    else
                    { /* block id: 1403 */
                        return (*g_53);
                    }
                }
                else
                { /* block id: 1406 */
                    return p_13;
                }
            }
            for (g_1451 = 0; (g_1451 != 30); g_1451 = safe_add_func_int64_t_s_s(g_1451, 3))
            { /* block id: 1412 */
                for (g_471 = 0; (g_471 <= 3); g_471 += 1)
                { /* block id: 1415 */
                    int64_t ***l_3099 = &g_1987;
                    int32_t *l_3100 = (void*)0;
                    for (g_1436 = 0; (g_1436 <= 3); g_1436 += 1)
                    { /* block id: 1418 */
                        union U2 **l_3098 = &g_1918;
                        int i, j;
                        p_16.f0 = g_424[g_1436][(g_471 + 4)];
                        (*g_631) = (((((l_3092 = (void*)0) != l_3093) , 0L) <= ((safe_rshift_func_int16_t_s_u((p_16 , 1L), (safe_mul_func_int16_t_s_s(p_13, (&g_1987 != ((((***g_2710) = l_3081) == (&g_1347[2] == l_3098)) , l_3099)))))) == 1L)) , l_3100);
                    }
                }
                if (p_16.f0)
                    continue;
            }
        }
        (*l_3113) = (safe_lshift_func_uint16_t_u_s(((void*)0 == &g_3035), (safe_div_func_uint64_t_u_u(l_3012, (safe_add_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_u(((void*)0 == p_15), ((((l_3081 < (((safe_sub_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((*g_53), ((((0x3390L < p_13) > (*g_53)) && p_13) , 0x3A422A1BL))), p_17)) && 0UL) == p_13)) == 1L) , (*g_53)) <= p_17))) , 0x99DEDE0EL), l_2984))))));
        if (g_52)
            goto lbl_3114;
    }
    else
    { /* block id: 1430 */
        int32_t *l_3115 = &g_520;
        l_3115 = l_3115;
        return (*g_53);
    }
    for (g_322 = 0; g_322 < 4; g_322 += 1)
    {
        g_202[g_322] = 0x2DE1E73F345ED317LL;
    }
    return (*g_53);
}


/* ------------------------------------------ */
/* 
 * reads : g_466 g_61 g_202 g_218 g_1900.f1 g_125 g_126 g_465 g_104 g_2212 g_319 g_81 g_53 g_54 g_1088 g_1775 g_1776 g_527 g_119 g_52 g_154 g_156 g_410 g_414 g_1965 g_2445 g_408 g_401 g_1201 g_1202 g_1342 g_2398.f1 g_1347 g_678.f1 g_550 g_271 g_1961 g_1962 g_1963 g_232.f1 g_631 g_1021 g_1615 g_1584 g_132 g_752 g_2710 g_2455.f1 g_1436 g_2712 g_106 g_1077 g_9 g_676.f1 g_1026.f1 g_324 g_1924.f1 g_81.f0 g_2977 g_1939
 * writes: g_1342 g_202 g_1900.f1 g_41 g_632 g_61 g_2202.f1 g_319 g_54 g_1436 g_218 g_726 g_154 g_156 g_2398.f1 g_1965 g_2445 g_408 g_401 g_1203 g_1614 g_1347 g_678.f1 g_550 g_1939 g_414 g_1021 g_2455.f1 g_2446 g_1615 g_52 g_2456.f1 g_520 g_106 g_425 g_132 g_207.f1 g_1026.f1 g_324 g_183.f1 g_1924.f1 g_805
 */
static uint64_t  func_18(union U0  p_19, int8_t * p_20, int8_t * p_21, const uint32_t  p_22)
{ /* block id: 1038 */
    uint16_t * const l_2261 = &g_1342[4];
    uint64_t *l_2266[5] = {&g_1615[0][0],&g_1615[0][0],&g_1615[0][0],&g_1615[0][0],&g_1615[0][0]};
    int32_t l_2267 = 0L;
    int32_t l_2268 = 0xE2C0E11FL;
    int32_t l_2269 = 0x42E4D68BL;
    int32_t l_2270 = 0x7296A783L;
    int32_t l_2271 = 0x7A0CDAD1L;
    int32_t l_2272[7][10][3] = {{{0x9BBA2830L,9L,0xA7F4A7F9L},{0L,0xEBC4CD83L,(-1L)},{0L,(-1L),0x4C79ABDBL},{(-10L),(-1L),(-5L)},{0L,(-1L),0x8EFCFD6FL},{0L,0xEA840A76L,0xEBC4CD83L},{0x9BBA2830L,0x1B224140L,6L},{0x9B6F1CFDL,0x6CCD1F2FL,0x4FCB1C41L},{(-1L),0xFFCDCA35L,9L},{0x13E6959FL,5L,5L}},{{0x8EFCFD6FL,0L,0xF0374D3DL},{(-6L),2L,(-5L)},{0x7EB8CDEFL,0x08E8772BL,0L},{0xDC118DBCL,(-6L),0x13E6959FL},{0L,0x08E8772BL,0xFFCDCA35L},{0x645098A6L,2L,(-10L)},{1L,0L,0xD61BED41L},{(-1L),5L,0x2B130E85L},{6L,0xFFCDCA35L,0x578C0307L},{5L,0x6CCD1F2FL,(-3L)}},{{0x1B224140L,0x1B224140L,0x906D30DDL},{(-3L),0xEA840A76L,(-6L)},{(-1L),(-1L),0x30F725CFL},{0x6CCD1F2FL,(-1L),(-5L)},{0x906D30DDL,(-1L),0x30F725CFL},{0xC7BCFFD9L,0xEBC4CD83L,(-6L)},{8L,9L,0x906D30DDL},{(-5L),(-6L),(-3L)},{0x4C79ABDBL,0xA7F4A7F9L,0x578C0307L},{0xEA840A76L,(-10L),0x2B130E85L}},{{0xD61BED41L,8L,0xD61BED41L},{0L,0x4FCB1C41L,(-10L)},{1L,0xF0374D3DL,0xFFCDCA35L},{0x3D361CBFL,0x645098A6L,0x13E6959FL},{0xA7F4A7F9L,0x30F725CFL,0L},{0x3D361CBFL,1L,(-5L)},{1L,(-1L),0xF0374D3DL},{0L,(-1L),5L},{0xD61BED41L,0L,9L},{0xEA840A76L,(-1L),0x4FCB1C41L}},{{0x4C79ABDBL,6L,6L},{(-5L),0x3D361CBFL,0xEBC4CD83L},{8L,0xB6DB5B5DL,0x8EFCFD6FL},{0xC7BCFFD9L,(-1L),(-5L)},{0x906D30DDL,0x578C0307L,0x4C79ABDBL},{0x6CCD1F2FL,(-1L),(-1L)},{(-1L),0xB6DB5B5DL,0xA7F4A7F9L},{(-3L),0x3D361CBFL,0x9B6F1CFDL},{0x1B224140L,6L,(-5L)},{5L,(-1L),(-6L)}},{{6L,0L,1L},{(-1L),(-1L),0xDC118DBCL},{1L,(-1L),8L},{0x645098A6L,1L,(-1L)},{0L,0x30F725CFL,0xCDDE1F2FL},{(-1L),(-6L),(-6L)},{0x5DDD8C83L,(-1L),0x4C79ABDBL},{0x13E6959FL,0L,(-1L)},{0x44F6B6D5L,0x4C79ABDBL,0xFFCDCA35L},{5L,0x2B130E85L,(-5L)}},{{0L,(-5L),9L},{0xC7BCFFD9L,0x13E6959FL,0xC7BCFFD9L},{0xF0374D3DL,0x9BBA2830L,(-5L)},{0xDC118DBCL,0xD19B5FF3L,0x645098A6L},{1L,0x578C0307L,6L},{0x2B130E85L,(-6L),(-5L)},{1L,1L,0x44F6B6D5L},{0xDC118DBCL,0x6CCD1F2FL,0xD19B5FF3L},{0xF0374D3DL,0x5B71DBE4L,(-1L)},{0xC7BCFFD9L,(-10L),0L}}};
    uint32_t l_2280 = 0xC3B6492CL;
    union U0 *l_2290 = (void*)0;
    union U0 **l_2289 = &l_2290;
    int16_t l_2308 = 0xE945L;
    int64_t * const *l_2359 = &g_271[8];
    int16_t **l_2395 = (void*)0;
    int16_t ***l_2394 = &l_2395;
    union U1 * const l_2396 = (void*)0;
    const uint64_t l_2399 = 0x6286202BEAA59645LL;
    uint32_t l_2431 = 0xC8B75DDAL;
    union U2 **l_2435 = &g_1347[2];
    uint16_t ***l_2475 = (void*)0;
    uint16_t ****l_2474 = &l_2475;
    uint16_t *****l_2473 = &l_2474;
    int64_t l_2489 = (-1L);
    int64_t l_2507 = 0x76C85D2ACBB680F6LL;
    int64_t l_2589 = (-1L);
    int32_t l_2631[9][6][4] = {{{0x314EDBA5L,(-1L),0xEA1FCB93L,0xA10F7D9BL},{8L,0x2ED313E0L,1L,0L},{0x7F1944D4L,(-4L),0x8D4AAEB4L,0x6ECF455BL},{(-1L),0x34445F18L,0x9CBBB69DL,(-7L)},{0xEA1FCB93L,1L,0x7A52E213L,1L},{0x1BE428DEL,(-9L),(-5L),(-1L)}},{{0x51DDE90AL,0xA7E55EC2L,0xDC295DCCL,0x7A52E213L},{0xFA411368L,0x8D4AAEB4L,0x51DDE90AL,0xFC528B6FL},{1L,0x803D9D4CL,0x1E19E431L,(-1L)},{0xFC528B6FL,5L,(-1L),(-1L)},{(-1L),(-1L),0xF8386E96L,3L},{(-1L),(-1L),0x86825CBFL,(-6L)}},{{0x3EAAAC02L,(-1L),0x98A92F21L,0x86825CBFL},{0x34445F18L,(-1L),0L,(-6L)},{(-1L),(-1L),0xEFFCEF2EL,3L},{(-1L),(-1L),0xA8B2EC3BL,(-1L)},{(-4L),5L,(-1L),(-1L)},{0x98A92F21L,0x803D9D4CL,0x314EDBA5L,0xFC528B6FL}},{{0xB9105404L,0x8D4AAEB4L,(-6L),0x7A52E213L},{0x02C755F8L,0xA7E55EC2L,0xFA411368L,(-1L)},{0x3AF371E1L,(-9L),0xFE939E52L,1L},{0x6194BADBL,1L,(-1L),(-7L)},{0xF728D758L,0x34445F18L,0x803D9D4CL,0x6ECF455BL},{5L,(-4L),0x2ED313E0L,0L}},{{0x7C8F86E6L,0x2ED313E0L,(-1L),0xA10F7D9BL},{0x6ECF455BL,(-1L),0x6ECF455BL,0x1E19E431L},{0xF8386E96L,0x3EAAAC02L,0x7F1944D4L,1L},{(-4L),(-1L),0x3AF371E1L,0x3EAAAC02L},{0xAD9C7A45L,0x6ECF455BL,0x3AF371E1L,0x8D4AAEB4L},{(-4L),0x1BE428DEL,0x7F1944D4L,(-1L)}},{{0xF8386E96L,0xFA411368L,0x6ECF455BL,0x2267ED15L},{0x6ECF455BL,0x2267ED15L,(-1L),0x7844712AL},{0x7C8F86E6L,0xEA1FCB93L,0x2ED313E0L,0xF8386E96L},{5L,0x7A52E213L,0x803D9D4CL,(-1L)},{0xF728D758L,1L,(-1L),0xEA1FCB93L},{0x6194BADBL,0x86825CBFL,0xFE939E52L,9L}},{{0x3AF371E1L,0x7C8F86E6L,0x98A92F21L,0x8D4AAEB4L},{0x7F1944D4L,0x6194BADBL,0x1E19E431L,0x86825CBFL},{1L,0xDC295DCCL,0xA8B2EC3BL,(-5L)},{(-1L),0xF64DF6C9L,0xFE939E52L,(-1L)},{0x64EF5749L,(-4L),(-4L),0x64EF5749L},{(-6L),0x1E19E431L,1L,0x3AF371E1L}},{{0xFE939E52L,0xFA411368L,(-1L),(-4L)},{0xEA1FCB93L,(-1L),(-1L),(-4L)},{8L,0xFA411368L,0x7C8F86E6L,0x3AF371E1L},{0L,0x1E19E431L,0x2267ED15L,0x64EF5749L},{0xF8386E96L,(-4L),5L,(-1L)},{0x1BE428DEL,0xF64DF6C9L,0xEFFCEF2EL,(-5L)}},{{(-1L),0xDC295DCCL,0x34445F18L,0x86825CBFL},{0x98A92F21L,0x6194BADBL,0x2ED313E0L,0x8D4AAEB4L},{0x34445F18L,(-4L),0x7A52E213L,0x51DDE90AL},{0x7844712AL,0x7C8F86E6L,0x314EDBA5L,0x3EAAAC02L},{0x3EAAAC02L,0x803D9D4CL,0xB9105404L,0L},{0xAD9C7A45L,0x314EDBA5L,0L,0x2267ED15L}}};
    int16_t l_2675 = 0x9B2EL;
    union U0 **l_2701[9][4][5] = {{{&l_2290,&l_2290,&g_2447,&l_2290,&l_2290},{(void*)0,&g_2447,(void*)0,&g_2447,&g_2447},{(void*)0,&l_2290,&g_2447,(void*)0,(void*)0},{(void*)0,&g_2447,&l_2290,&g_2447,&g_2447}},{{&l_2290,(void*)0,&g_2447,(void*)0,&l_2290},{&g_2447,&g_2447,&l_2290,&g_2447,(void*)0},{(void*)0,(void*)0,&g_2447,&l_2290,(void*)0},{&g_2447,&g_2447,(void*)0,&g_2447,(void*)0}},{{&l_2290,&l_2290,&g_2447,&l_2290,&l_2290},{(void*)0,&g_2447,(void*)0,&g_2447,&g_2447},{(void*)0,&l_2290,&g_2447,(void*)0,(void*)0},{(void*)0,&g_2447,&l_2290,&g_2447,&g_2447}},{{&l_2290,(void*)0,&g_2447,(void*)0,&l_2290},{&g_2447,&g_2447,&l_2290,&g_2447,(void*)0},{(void*)0,(void*)0,&g_2447,&l_2290,(void*)0},{&g_2447,&g_2447,(void*)0,&g_2447,(void*)0}},{{&l_2290,&l_2290,&g_2447,&l_2290,&l_2290},{(void*)0,&g_2447,(void*)0,&g_2447,&g_2447},{(void*)0,&l_2290,&g_2447,(void*)0,(void*)0},{(void*)0,&g_2447,&l_2290,&g_2447,&g_2447}},{{&l_2290,(void*)0,&g_2447,(void*)0,&l_2290},{&g_2447,&g_2447,&l_2290,&g_2447,(void*)0},{(void*)0,(void*)0,&g_2447,&l_2290,(void*)0},{&g_2447,&g_2447,(void*)0,&g_2447,(void*)0}},{{&l_2290,&l_2290,&g_2447,&l_2290,(void*)0},{&l_2290,&l_2290,&l_2290,&g_2447,&g_2447},{(void*)0,&l_2290,&g_2447,(void*)0,(void*)0},{&l_2290,&g_2447,&l_2290,&l_2290,&g_2447}},{{(void*)0,(void*)0,&g_2447,(void*)0,(void*)0},{&g_2447,&l_2290,&l_2290,&g_2447,&l_2290},{(void*)0,(void*)0,&g_2447,&l_2290,(void*)0},{&g_2447,&g_2447,&l_2290,&l_2290,&l_2290}},{{(void*)0,&l_2290,&g_2447,&l_2290,(void*)0},{&l_2290,&l_2290,&l_2290,&g_2447,&g_2447},{(void*)0,&l_2290,&g_2447,(void*)0,(void*)0},{&l_2290,&g_2447,&l_2290,&l_2290,&g_2447}}};
    union U0 *l_2721 = &g_81;
    int8_t **l_2741 = &g_2212;
    int32_t *l_2903 = &l_2269;
    int i, j, k;
    if (((safe_add_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((*g_466), ((*l_2261) = ((void*)0 == l_2261)))) , (safe_rshift_func_int8_t_s_s((safe_add_func_uint64_t_u_u((++g_202[0]), l_2271)), l_2268))), (*p_20))) && 0L))
    { /* block id: 1041 */
        int32_t l_2277 = (-1L);
        int32_t * const l_2292 = &l_2272[3][5][0];
        union U0 *l_2297 = &g_81;
        uint16_t ***l_2303 = &g_465;
        uint16_t ****l_2302 = &l_2303;
        uint16_t ***** const l_2301[3] = {&l_2302,&l_2302,&l_2302};
        uint32_t * const *l_2358[5][2] = {{&g_53,&g_53},{&g_53,&g_53},{&g_53,&g_53},{&g_53,&g_53},{&g_53,&g_53}};
        int i, j;
        for (g_1900.f1 = 22; (g_1900.f1 > 41); g_1900.f1 = safe_add_func_int16_t_s_s(g_1900.f1, 2))
        { /* block id: 1044 */
            int64_t l_2284 = 0x39F4BD97F7E9A885LL;
            uint32_t l_2312[2];
            int32_t l_2332 = (-2L);
            int32_t l_2352 = 0x93CAEB67L;
            int32_t l_2354 = 2L;
            int32_t l_2355 = 0xE27934F0L;
            uint8_t l_2357 = 0x13L;
            const uint64_t **l_2368[7] = {&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125};
            const uint64_t ***l_2367 = &l_2368[4];
            const uint64_t **** const l_2366 = &l_2367;
            int i;
            for (i = 0; i < 2; i++)
                l_2312[i] = 0UL;
            if (l_2277)
            { /* block id: 1045 */
                int32_t l_2283 = 0x960951BDL;
                union U0 **l_2298 = &l_2297;
                uint8_t *l_2340 = &g_1436;
                uint32_t *l_2353[1][4][5] = {{{&g_410[0],&g_324,&g_41,&g_324,&g_410[0]},{&g_41,(void*)0,&g_1451,(void*)0,&g_41},{&g_410[0],&g_324,&g_41,&g_324,&g_410[0]},{&g_41,(void*)0,&g_1451,(void*)0,&g_41}}};
                int32_t l_2356 = 0x11170B8FL;
                int i, j, k;
                for (g_41 = 0; (g_41 <= 0); g_41 += 1)
                { /* block id: 1048 */
                    int16_t l_2287 = (-1L);
                    uint32_t *l_2288 = (void*)0;
                    int32_t **l_2293 = &g_632[1][6];
                    if ((safe_mod_func_uint8_t_u_u((((l_2280 & ((*p_20) , 0x980288CD61C6E2C6LL)) , (l_2272[0][5][2] = ((l_2283 , l_2284) & (((safe_div_func_int16_t_s_s((-1L), ((*g_125) , l_2287))) < p_22) == 9UL)))) , 246UL), p_22)))
                    { /* block id: 1050 */
                        return l_2287;
                    }
                    else
                    { /* block id: 1052 */
                        union U0 ***l_2291 = &l_2289;
                        (*l_2291) = l_2289;
                    }
                    (*l_2293) = l_2292;
                }
                if ((safe_lshift_func_uint8_t_u_s(p_22, (~(l_2270 &= ((((((l_2283 != p_19.f0) , (void*)0) != ((*l_2298) = ((*l_2289) = l_2297))) , (safe_sub_func_int16_t_s_s(((void*)0 != l_2301[0]), (((safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((***l_2303) = l_2268), 0x1A8FL)), p_19.f0)) | g_104[3]) != l_2308)))) && p_22) <= (*g_2212)))))))
                { /* block id: 1061 */
                    return l_2280;
                }
                else
                { /* block id: 1063 */
                    int32_t *l_2309 = &g_156;
                    int32_t *l_2310 = (void*)0;
                    int32_t *l_2311[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2311[i] = (void*)0;
                    --l_2312[0];
                    for (g_2202.f1 = 0; (g_2202.f1 < 11); g_2202.f1 = safe_add_func_uint32_t_u_u(g_2202.f1, 6))
                    { /* block id: 1067 */
                        int16_t l_2321 = (-1L);
                        int32_t l_2329 = 2L;
                        uint32_t *l_2330 = (void*)0;
                        uint32_t *l_2331 = &l_2280;
                        l_2332 ^= ((((*l_2331) = (((safe_div_func_int32_t_s_s(((l_2329 &= (safe_lshift_func_int8_t_s_s((((**l_2289) , p_22) <= (1L && ((((((*g_2212) = ((*l_2292) & 4UL)) & p_22) != p_19.f0) , ((l_2272[4][0][2] = ((safe_rshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u((((((+l_2283) , (*l_2292)) <= p_19.f0) & p_19.f0) || (*g_53)), p_19.f0)) && 0xAA45F3892041D522LL), p_22)), (*g_2212))) >= p_19.f0)) , (*g_2212))) != 0x86L))), 4))) || l_2283), p_22)) ^ g_104[1]) ^ (*g_125))) , p_22) , 1L);
                    }
                    (*g_1088) = &l_2332;
                }
                (*l_2292) = (safe_sub_func_uint16_t_u_u((~(((*g_53) = 5UL) , ((safe_sub_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(((*g_2212) && ((*l_2340) = (g_81 , l_2332))), 3)), l_2271)) < (safe_mod_func_int8_t_s_s((*g_2212), l_2284))))), (safe_rshift_func_int16_t_s_u(((((((l_2357 |= (safe_sub_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((l_2356 = (l_2355 |= (((*p_20) = (((p_22 != (l_2354 = (l_2352 &= (~(safe_rshift_func_uint8_t_u_u(p_19.f0, 4)))))) & l_2267) | 0UL)) ^ p_22))), 0x79E8E46EA2AB083ELL)), 0x519AB896L))) < 0xA120F9F73175CE54LL) , p_19.f0) , l_2358[4][1]) != (void*)0) || (-8L)), 10))));
                (*l_2292) = p_19.f0;
            }
            else
            { /* block id: 1086 */
                const union U1 ***l_2369 = &g_1202[1][0];
                int32_t **l_2370 = &g_632[1][6];
                int32_t *l_2373 = &l_2354;
                l_2359 = (*g_1775);
                (*l_2292) = l_2270;
                (*l_2373) &= ((*l_2292) = (safe_mod_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u((l_2366 == (void*)0), l_2332)) ^ (((l_2369 == (void*)0) && (l_2370 == (((*g_466) || (l_2352 , (safe_mul_func_int16_t_s_s(0xE761L, 0xFCD7L)))) , &l_2292))) >= (*l_2292))), (*l_2292))));
                return l_2272[0][5][2];
            }
        }
    }
    else
    { /* block id: 1094 */
        int32_t *l_2374 = (void*)0;
        int32_t *l_2375 = (void*)0;
        int32_t *l_2376[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int16_t *l_2391 = &g_726;
        union U1 * const l_2397 = &g_2398;
        uint8_t *l_2434 = &g_2398.f1;
        union U2 **l_2436 = &g_1347[3];
        uint16_t ** const *l_2478 = &g_465;
        uint16_t ** const **l_2477[1][7][6] = {{{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478},{&l_2478,&l_2478,&l_2478,&l_2478,&l_2478,&l_2478}}};
        uint16_t ** const ***l_2476 = &l_2477[0][1][1];
        union U0 ***l_2483 = &l_2289;
        uint64_t l_2517 = 18446744073709551607UL;
        uint8_t l_2552 = 248UL;
        int8_t **l_2558 = &g_2212;
        int8_t l_2599[8][7][2] = {{{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L}},{{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L}},{{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L}},{{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L}},{{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L}},{{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L}},{{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L}},{{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L},{0xB5L,0xB5L},{0x59L,0L},{0x59L,0xB5L},{0xB5L,0L}}};
        int i, j, k;
        p_19.f0 |= p_22;
        l_2270 |= (safe_rshift_func_int8_t_s_u((safe_mod_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(((&g_1961 == &g_1329) != (l_2272[0][5][2] > ((safe_div_func_int8_t_s_s((safe_div_func_uint64_t_u_u(((((safe_div_func_uint32_t_u_u((((((((p_19.f0 >= ((*g_53) &= (((((*l_2391) = (-1L)) , p_22) & ((0x22L | ((safe_rshift_func_int8_t_s_u(0xC6L, 1)) < (((l_2394 == (void*)0) ^ p_22) , 0L))) , p_19.f0)) > 65535UL))) || p_19.f0) | 0L) , l_2396) != l_2397) | p_19.f0) , p_19.f0), 0x761CC325L)) , (*g_53)) != p_22) , l_2399), p_22)), (*g_2212))) <= 0x82DDL))), p_22)), (*p_20))), 7));
lbl_2453:
        l_2270 |= (&g_991 == ((safe_mul_func_int16_t_s_s(((safe_add_func_int64_t_s_s((-1L), (safe_rshift_func_int16_t_s_u(((safe_div_func_uint8_t_u_u(l_2272[2][3][2], (-5L))) , (((safe_rshift_func_int16_t_s_s(p_22, 3)) , (((safe_mod_func_uint64_t_u_u((l_2271 = 0x9D824895FAA529C2LL), 0xF8B15F251A20CEC7LL)) & l_2268) , (safe_add_func_uint64_t_u_u((((func_71(((g_527 != (void*)0) > 9UL)) , (*g_53)) , p_22) < (*g_125)), p_22)))) < (*g_53))), 1)))) <= p_19.f0), p_19.f0)) , &g_991));
        if ((safe_sub_func_int8_t_s_s((safe_mod_func_int32_t_s_s(0x4491951FL, (safe_lshift_func_uint8_t_u_s(p_19.f0, 4)))), (safe_mul_func_int16_t_s_s((((((*g_53) = 0xFC163599L) , ((safe_mul_func_uint16_t_u_u((((((*p_20) = ((l_2268 = (~0x8994L)) <= ((safe_add_func_uint16_t_u_u(((((l_2431 = (l_2269 ^= (safe_add_func_int64_t_s_s((~g_410[3]), ((*g_2212) & (~2L)))))) != p_22) , ((*l_2434) = (((safe_div_func_int8_t_s_s((l_2271 & (*g_53)), 0xECL)) , 2UL) | (*g_2212)))) >= g_414), l_2267)) , (-1L)))) >= p_19.f0) , 0x3AE2L) ^ 0x6448L), (-1L))) , l_2435)) != l_2436) , 3L), 0x6D11L)))))
        { /* block id: 1107 */
            int32_t l_2452 = 0x2C5E0DF3L;
            const union U1 *l_2454[5][3] = {{&g_2455,&g_2455,&g_2455},{(void*)0,&g_2456,(void*)0},{&g_2455,&g_2455,&g_2455},{(void*)0,&g_2456,(void*)0},{&g_2455,&g_2455,&g_2455}};
            uint32_t l_2488 = 0xA014818FL;
            union U2 *l_2501 = (void*)0;
            int32_t l_2521[3];
            int8_t l_2522[7];
            uint64_t **l_2566 = &l_2266[4];
            uint64_t ***l_2565 = &l_2566;
            int i, j;
            for (i = 0; i < 3; i++)
                l_2521[i] = 4L;
            for (i = 0; i < 7; i++)
                l_2522[i] = 0x93L;
            for (g_1965 = 4; (g_1965 >= 1); g_1965 -= 1)
            { /* block id: 1110 */
                union U0 ****l_2448 = &g_2445;
                int8_t **l_2449 = &g_2212;
                const int8_t *l_2451 = &g_1614;
                const int8_t **l_2450 = &l_2451;
                l_2269 = (safe_rshift_func_int16_t_s_u((p_22 != (safe_mod_func_int32_t_s_s((p_19.f0 = (+(p_19 , ((((l_2270 , (0x0BB8L < ((~1L) >= 0x09B6AAACL))) ^ (8UL >= (l_2272[0][5][2] ^= ((((((*l_2448) = g_2445) != (((l_2449 == l_2450) , p_19.f0) , (void*)0)) < 0x577CB8CE5415742ELL) ^ l_2452) | p_22)))) <= 0x76L) ^ 0x9FL)))), p_22))), p_22));
                for (g_408 = 4; (g_408 >= 0); g_408 -= 1)
                { /* block id: 1117 */
                    for (g_401 = 1; (g_401 <= 4); g_401 += 1)
                    { /* block id: 1120 */
                        int i, j;
                        p_19.f0 &= l_2272[0][5][2];
                        if (l_2271)
                            continue;
                        if (l_2270)
                            goto lbl_2453;
                    }
                }
            }
            l_2452 &= p_19.f0;
            if ((((**g_1201) = l_2454[2][0]) == (void*)0))
            { /* block id: 1129 */
                return p_22;
            }
            else
            { /* block id: 1131 */
                uint8_t l_2458 = 0xA9L;
                for (l_2452 = 0; (l_2452 <= 8); l_2452 += 1)
                { /* block id: 1134 */
                    int64_t l_2457[5] = {0x194931995F5B5804LL,0x194931995F5B5804LL,0x194931995F5B5804LL,0x194931995F5B5804LL,0x194931995F5B5804LL};
                    int i;
                    l_2458++;
                    for (g_1614 = 8; (g_1614 >= 0); g_1614 -= 1)
                    { /* block id: 1138 */
                        (*g_1088) = &l_2270;
                    }
                }
            }
            if ((safe_rshift_func_int16_t_s_s((l_2452 = (safe_mul_func_int16_t_s_s(((safe_sub_func_int16_t_s_s((((safe_div_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u((((p_19.f0 || (9UL || ((l_2272[3][2][0] = p_22) > 0x518BL))) | (safe_sub_func_int32_t_s_s(1L, (((l_2473 == l_2476) , ((((((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((l_2483 != (((safe_mod_func_uint32_t_u_u((safe_add_func_uint8_t_u_u(((*g_2212) | 0x18L), (*p_20))), l_2452)) | 0xA1L) , (void*)0)), g_1342[3])), 13)) > 0x1487535FL) == l_2452) >= 0x0F7BC285L) > p_22) <= 0x6D49L)) <= l_2488)))) , 0xFFL), p_22)), p_22)) || l_2489) <= 18446744073709551612UL), p_19.f0)) <= l_2452), (*g_466)))), 2)))
            { /* block id: 1145 */
                uint64_t **l_2491 = &g_665;
                uint64_t ***l_2490 = &l_2491;
                int32_t l_2492[7][10] = {{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L},{3L,3L,3L,3L,3L,3L,3L,3L,3L,3L}};
                uint16_t l_2524 = 3UL;
                uint32_t *l_2550[5];
                int i, j;
                for (i = 0; i < 5; i++)
                    l_2550[i] = &g_425;
                l_2492[3][3] = (((*l_2490) = (void*)0) == &g_665);
                if ((safe_mul_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u(((***l_2478) = (safe_div_func_uint8_t_u_u((++(*l_2434)), 1UL))), (((l_2501 != ((*l_2436) = (*l_2436))) != (((*g_53) | (safe_div_func_uint64_t_u_u(0x2457F6D15A645173LL, ((((p_19 , ((((safe_rshift_func_int8_t_s_u(9L, (0xD877L > (((safe_unary_minus_func_int32_t_s((((p_22 ^ 0x0FL) & 1L) && 4L))) , p_19.f0) && p_22)))) <= l_2507) < (*g_2212)) != (-1L))) , p_22) || l_2488) & p_22)))) && p_19.f0)) != p_19.f0))) ^ p_19.f0) | 1L), p_19.f0)))
                { /* block id: 1151 */
                    uint32_t l_2518 = 0x59436022L;
                    int32_t l_2519 = (-1L);
                    int32_t l_2520 = (-3L);
                    int32_t l_2523[10][6][4] = {{{3L,(-1L),0xCE48BD4FL,0x95052FAEL},{0xFF669047L,(-1L),0xEEC7FCC9L,0xCE48BD4FL},{(-4L),(-1L),(-4L),0x95052FAEL},{(-1L),(-1L),0x866A0C81L,0x73D08617L},{0x73D08617L,0xCE48BD4FL,0xFF669047L,(-1L)},{3L,0xFF669047L,0xFF669047L,3L}},{{0x73D08617L,0x95052FAEL,0x866A0C81L,(-4L)},{(-1L),0L,(-4L),(-1L)},{(-4L),(-1L),3L,(-1L)},{3L,0x866A0C81L,(-1L),(-1L)},{(-4L),0L,(-1L),0xCE48BD4FL},{(-1L),3L,0xFF669047L,0xFF669047L}},{{(-1L),(-1L),(-1L),0x95052FAEL},{(-4L),0xFF669047L,(-1L),0L},{3L,0x73D08617L,3L,(-1L)},{(-1L),0x73D08617L,(-1L),0L},{0x73D08617L,0xFF669047L,0xEEC7FCC9L,0x95052FAEL},{0x95052FAEL,(-1L),3L,0xFF669047L}},{{0xCE48BD4FL,3L,3L,0xCE48BD4FL},{0x95052FAEL,0L,0xEEC7FCC9L,(-1L)},{0x73D08617L,0x866A0C81L,(-1L),(-1L)},{(-1L),(-1L),3L,(-1L)},{3L,0x866A0C81L,(-1L),(-1L)},{(-4L),0L,(-1L),0xCE48BD4FL}},{{(-1L),3L,0xFF669047L,0xFF669047L},{(-1L),(-1L),(-1L),0x95052FAEL},{(-4L),0xFF669047L,(-1L),0L},{3L,0x73D08617L,3L,(-1L)},{(-1L),0x73D08617L,(-1L),0L},{0x73D08617L,0xFF669047L,0xEEC7FCC9L,0x95052FAEL}},{{0x95052FAEL,(-1L),3L,0xFF669047L},{0xCE48BD4FL,3L,3L,0xCE48BD4FL},{0x95052FAEL,0L,0xEEC7FCC9L,(-1L)},{0x73D08617L,0x866A0C81L,(-1L),(-1L)},{(-1L),(-1L),3L,(-1L)},{3L,0x866A0C81L,(-1L),(-1L)}},{{(-4L),0L,(-1L),0xCE48BD4FL},{(-1L),3L,0xFF669047L,0xFF669047L},{(-1L),(-1L),(-1L),0x95052FAEL},{(-4L),0xFF669047L,(-1L),0L},{3L,0x73D08617L,3L,(-1L)},{(-1L),0x73D08617L,(-1L),0L}},{{0x73D08617L,0xFF669047L,0xEEC7FCC9L,0x95052FAEL},{0x95052FAEL,(-1L),3L,0xFF669047L},{0xCE48BD4FL,3L,3L,0xCE48BD4FL},{0x95052FAEL,0L,0xEEC7FCC9L,(-1L)},{0x73D08617L,0x866A0C81L,(-1L),(-1L)},{(-1L),(-1L),3L,(-1L)}},{{3L,0x866A0C81L,(-1L),(-1L)},{(-4L),0L,(-1L),0xCE48BD4FL},{(-1L),3L,0xFF669047L,0xFF669047L},{(-1L),(-1L),(-1L),0x95052FAEL},{(-4L),0xFF669047L,(-1L),0L},{3L,0x73D08617L,3L,(-1L)}},{{(-1L),0x73D08617L,(-1L),0L},{0x73D08617L,0xFF669047L,0xEEC7FCC9L,0x95052FAEL},{0L,(-1L),0xCE48BD4FL,3L},{(-1L),0xCE48BD4FL,0xCE48BD4FL,(-1L)},{0L,0x866A0C81L,3L,0xFF669047L},{0x95052FAEL,0xEEC7FCC9L,0xFF669047L,0x73D08617L}}};
                    int i, j, k;
                    l_2452 |= ((((p_22 == l_2270) , (safe_rshift_func_int8_t_s_s((-1L), (safe_add_func_int32_t_s_s(p_19.f0, (!(safe_rshift_func_int8_t_s_s((4294967293UL > (((((p_22 < (g_1347[0] == (void*)0)) ^ ((**g_465) | 0L)) | (*g_53)) <= l_2492[3][3]) , p_22)), (*p_20))))))))) <= l_2507) , p_19.f0);
                    l_2492[3][3] = (p_22 <= (safe_mul_func_uint8_t_u_u(l_2517, l_2518)));
                    l_2524--;
                }
                else
                { /* block id: 1155 */
                    for (g_678.f1 = 0; (g_678.f1 <= 53); g_678.f1 = safe_add_func_uint32_t_u_u(g_678.f1, 2))
                    { /* block id: 1158 */
                        if (p_22)
                            break;
                    }
                    l_2521[2] |= ((safe_sub_func_int16_t_s_s((safe_add_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(((((safe_mul_func_uint8_t_u_u(p_19.f0, p_19.f0)) | (safe_sub_func_uint64_t_u_u((l_2492[3][5] && (safe_lshift_func_int8_t_s_s((*g_2212), 7))), (!((**g_465) = (safe_rshift_func_int16_t_s_s((l_2280 <= (safe_rshift_func_uint16_t_u_s(((safe_mod_func_int64_t_s_s(((safe_sub_func_int32_t_s_s(l_2452, 0x7310FA0FL)) , (l_2550[3] == (void*)0)), (-1L))) >= 0x8C9AL), 0))), 11))))))) == 250UL) , (*g_2212)), l_2308)), p_22)), l_2308)) != (*g_125));
                    for (g_550 = 0; (g_550 <= 2); g_550 += 1)
                    { /* block id: 1165 */
                        return l_2524;
                    }
                }
                l_2552++;
            }
            else
            { /* block id: 1170 */
                int64_t *l_2557[10][5][5] = {{{&g_154,(void*)0,(void*)0,&g_154,(void*)0},{(void*)0,&l_2507,&g_154,&l_2507,&l_2489},{&l_2507,&l_2507,&l_2507,&l_2489,(void*)0},{&g_154,(void*)0,&l_2507,&l_2507,(void*)0},{&l_2507,&l_2489,(void*)0,&g_154,&g_154}},{{&l_2507,&g_154,&l_2507,&l_2489,&g_154},{&l_2489,&g_154,&l_2489,&l_2507,&l_2507},{&l_2507,&l_2489,&l_2507,&g_154,&g_154},{&l_2507,(void*)0,&l_2489,&l_2489,&l_2489},{&g_154,&l_2489,&l_2489,&l_2507,&g_154}},{{&l_2507,&l_2489,&l_2489,&l_2489,&l_2507},{(void*)0,&l_2507,&l_2507,&g_154,&l_2507},{&g_154,&g_154,&l_2489,(void*)0,&l_2507},{(void*)0,&l_2507,&l_2507,&l_2507,&l_2507},{(void*)0,(void*)0,(void*)0,&l_2489,&l_2507}},{{&l_2507,&g_154,&l_2507,&l_2489,&g_154},{&l_2489,&l_2507,&l_2507,&g_154,&l_2489},{&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,(void*)0,(void*)0,&l_2507,&l_2507},{&l_2507,&l_2507,&l_2489,(void*)0,&g_154}},{{&l_2507,&g_154,&l_2507,&l_2507,&g_154},{&g_154,&l_2507,&l_2489,&g_154,(void*)0},{&l_2507,&l_2489,(void*)0,&g_154,(void*)0},{&l_2507,&l_2489,&g_154,&l_2489,&l_2489},{&l_2507,(void*)0,&l_2507,&l_2489,(void*)0}},{{&g_154,&l_2489,(void*)0,&l_2507,&g_154},{&l_2507,&g_154,&l_2507,(void*)0,&l_2507},{&l_2507,&g_154,(void*)0,&g_154,&l_2507},{&g_154,&l_2489,&l_2507,&l_2489,(void*)0},{&g_154,(void*)0,&g_154,&l_2507,&l_2489}},{{&l_2489,&l_2507,(void*)0,&l_2489,(void*)0},{&l_2507,&l_2507,&l_2489,&g_154,&l_2507},{(void*)0,(void*)0,&l_2507,&l_2507,&l_2507},{(void*)0,&g_154,&l_2489,&l_2489,&g_154},{&g_154,(void*)0,(void*)0,&g_154,(void*)0}},{{&g_154,(void*)0,&l_2489,&l_2507,&l_2507},{&l_2507,(void*)0,&l_2507,&l_2489,&l_2507},{&g_154,&g_154,&l_2507,&l_2507,&g_154},{&l_2489,&g_154,&g_154,&l_2507,(void*)0},{&g_154,&l_2507,(void*)0,&g_154,&l_2489}},{{&g_154,&l_2507,&g_154,&l_2507,&l_2507},{&g_154,&l_2489,&g_154,(void*)0,&l_2489},{&l_2489,&g_154,&l_2489,&g_154,(void*)0},{&g_154,&g_154,&l_2507,(void*)0,&g_154},{&l_2507,(void*)0,&l_2489,(void*)0,&l_2507}},{{&g_154,&g_154,&g_154,&l_2507,(void*)0},{&l_2507,(void*)0,&g_154,&l_2489,&l_2507},{&l_2507,&g_154,(void*)0,&g_154,(void*)0},{&l_2489,&l_2489,&g_154,&g_154,&l_2507},{(void*)0,&l_2489,&l_2507,&l_2507,&g_154}}};
                int32_t l_2563[5];
                int32_t l_2598 = (-1L);
                uint32_t *l_2600 = (void*)0;
                int32_t l_2601 = (-1L);
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_2563[i] = 0x11D94D97L;
                p_19.f0 = (safe_sub_func_uint8_t_u_u(l_2267, (((*g_125) ^ ((p_19.f0 , l_2557[3][2][4]) != (*l_2359))) && (((*p_20) <= (l_2558 == &g_2212)) ^ ((*l_2434) = ((*g_125) | p_19.f0))))));
                p_19.f0 = ((((((safe_add_func_uint32_t_u_u((l_2359 == (((safe_mul_func_int8_t_s_s(l_2563[2], (safe_unary_minus_func_uint32_t_u(4294967292UL)))) > (l_2521[2] && 1L)) , &l_2557[3][2][4])), ((*g_53) = (((((void*)0 != l_2565) , (safe_div_func_uint16_t_u_u(65527UL, 1L))) ^ 0x1CCD8E6AC35CC22DLL) && 0UL)))) & l_2280) , 0UL) >= 0x7347D7F79AF5DAB1LL) , (-9L)) <= 0xEFB305B6B3E050B6LL);
                l_2601 |= (+((l_2452 = ((*g_53) = (safe_rshift_func_uint8_t_u_s(((l_2521[2] = (func_71((+(l_2270 <= (l_2563[2] &= (!(safe_div_func_int16_t_s_s(((void*)0 == (**g_1961)), p_19.f0))))))) , (safe_lshift_func_uint8_t_u_u(((((((safe_div_func_int64_t_s_s(((safe_div_func_uint16_t_u_u((l_2280 != (safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((~(safe_sub_func_int32_t_s_s((l_2589 < (safe_add_func_int16_t_s_s((((p_19.f0 , ((((safe_mul_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_u((safe_lshift_func_uint8_t_u_u(0x8DL, p_19.f0)), p_22)) ^ 0xAAL), p_19.f0)) || p_19.f0) != 1L) != p_19.f0)) == 4294967291UL) | p_19.f0), 0xE1F3L))), p_19.f0))), (*p_20))), 2))), 65530UL)) , l_2598), l_2589)) | 0xA7L) >= 18446744073709551615UL) < 0L) & l_2599[0][5][0]) != (*g_53)), 4)))) , g_232.f1), (*g_2212))))) | p_22));
            }
        }
        else
        { /* block id: 1181 */
            int32_t *l_2602 = &l_2272[0][5][2];
            int32_t **l_2603 = &l_2374;
            (*l_2603) = ((*g_631) = l_2602);
        }
    }
lbl_2926:
    for (g_1939 = 0; (g_1939 < 5); ++g_1939)
    { /* block id: 1188 */
        int32_t l_2635 = (-8L);
        int32_t l_2639 = 0x2BE3AC38L;
        int32_t l_2640 = 0x0819089EL;
        const int64_t l_2704 = (-3L);
        union U0 *l_2720 = &g_81;
        int32_t *l_2739 = &g_401;
        uint8_t *l_2740 = &g_2456.f1;
        uint8_t l_2762 = 0UL;
        int32_t l_2768 = 0x03C868A9L;
        int32_t l_2769 = 1L;
        uint16_t l_2877[2][2];
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
                l_2877[i][j] = 5UL;
        }
        for (g_414 = 0; (g_414 <= 6); g_414 += 1)
        { /* block id: 1191 */
            int16_t ***l_2632[3][7][7] = {{{(void*)0,(void*)0,&l_2395,(void*)0,(void*)0,&l_2395,(void*)0},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{&l_2395,(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,&l_2395,(void*)0},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{(void*)0,(void*)0,&l_2395,(void*)0,(void*)0,&l_2395,(void*)0}},{{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{&l_2395,(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,&l_2395,(void*)0},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{(void*)0,(void*)0,&l_2395,(void*)0,(void*)0,&l_2395,(void*)0},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395}},{{&l_2395,(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{(void*)0,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{&l_2395,&l_2395,(void*)0,&l_2395,&l_2395,(void*)0,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395},{&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395,&l_2395}}};
            int32_t l_2634 = 6L;
            uint8_t l_2657 = 3UL;
            int32_t l_2660 = 0x1CF06F38L;
            uint32_t l_2692 = 1UL;
            int32_t l_2693 = (-1L);
            union U0 **l_2702 = &l_2290;
            int8_t *l_2707 = &g_319;
            int i, j, k;
            for (l_2431 = 0; (l_2431 <= 0); l_2431 += 1)
            { /* block id: 1194 */
                int64_t *l_2633 = &g_154;
                int64_t *l_2636 = &l_2507;
                uint8_t *l_2637 = &g_678.f1;
                int32_t *l_2638 = &l_2269;
                int32_t *l_2641 = &g_52;
                int32_t *l_2642 = &l_2269;
                int32_t *l_2643 = &g_520;
                int32_t *l_2644 = &g_156;
                int32_t *l_2645 = &l_2270;
                int32_t *l_2646 = &g_401;
                int32_t *l_2647 = (void*)0;
                int32_t *l_2648 = &l_2269;
                int32_t *l_2649 = &l_2634;
                int32_t *l_2650 = &g_52;
                int32_t *l_2651 = (void*)0;
                int32_t *l_2652 = &l_2268;
                int32_t *l_2653 = (void*)0;
                int32_t *l_2654 = (void*)0;
                int32_t *l_2655 = &g_52;
                int32_t *l_2656[9] = {&g_401,(void*)0,&g_401,(void*)0,&g_401,(void*)0,&g_401,(void*)0,&g_401};
                int16_t *l_2672[6][7] = {{&g_1077[1],&g_1077[1],&g_424[3][2],&g_1965,&g_60,&g_726,&g_424[2][2]},{&g_1965,&g_1077[1],&g_106,&g_726,&g_726,&g_106,&g_1077[1]},{&g_106,(void*)0,&g_1077[1],&g_424[3][8],&g_60,&g_1077[2],&g_1965},{&g_106,&g_424[2][2],&g_424[3][6],&g_1077[1],&g_424[3][6],&g_424[2][2],&g_106},{&g_1965,&g_1077[2],&g_60,&g_424[3][8],&g_1077[1],(void*)0,&g_106},{&g_1077[1],&g_106,&g_726,&g_726,&g_106,&g_1077[1],&g_1965}};
                union U0 l_2709 = {4L};
                int i, j, k;
                if (g_1021[l_2431][(l_2431 + 1)][(g_414 + 2)])
                    break;
                (*l_2638) ^= ((((safe_lshift_func_uint8_t_u_u(((g_1615[(l_2431 + 1)][g_414] > (safe_sub_func_uint8_t_u_u(((*l_2637) = ((safe_div_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_s(((safe_sub_func_uint8_t_u_u((g_1584[(l_2431 + 1)] > ((*l_2636) = (safe_mod_func_int64_t_s_s((safe_sub_func_uint16_t_u_u(g_1615[(l_2431 + 1)][g_414], (g_1021[l_2431][(l_2431 + 2)][l_2431] = (((((safe_mul_func_int16_t_s_s((p_19.f0 == ((!(((safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((*l_2633) |= (safe_sub_func_int16_t_s_s((g_104[0] , (l_2268 &= p_19.f0)), (safe_add_func_uint16_t_u_u(l_2631[5][3][2], ((void*)0 == l_2632[0][6][4])))))), 1UL)), l_2589)) & g_1021[l_2431][(l_2431 + 1)][(g_414 + 2)]) >= g_1021[l_2431][(l_2431 + 1)][(g_414 + 2)])) , p_19.f0)), g_1021[l_2431][(l_2431 + 1)][(g_414 + 2)])) & p_22) , (*p_20)) , l_2634) <= l_2634)))), l_2635)))), p_22)) , p_19.f0), 2)) | g_1615[(l_2431 + 1)][g_414]), l_2635)) >= (*g_2212))), (*g_2212)))) <= l_2635), p_19.f0)) , l_2634) ^ l_2272[5][5][0]) , 0L);
                ++l_2657;
                for (g_2455.f1 = 1; (g_2455.f1 <= 6); g_2455.f1 += 1)
                { /* block id: 1205 */
                    uint8_t l_2661 = 0xCDL;
                    int32_t *l_2671[5][10][2] = {{{&g_156,&l_2272[0][5][2]},{&g_4,&g_156},{&l_2272[0][5][2],&g_52},{&l_2272[0][5][2],&g_156},{&g_4,&l_2272[0][5][2]},{&g_156,&g_52},{&l_2269,&l_2269},{&g_4,&l_2269},{&l_2269,&g_52},{&g_156,&l_2272[0][5][2]}},{{&g_4,&g_156},{&l_2272[0][5][2],&g_52},{&l_2272[0][5][2],&g_156},{&g_4,&l_2272[0][5][2]},{&g_156,&g_52},{&l_2269,&l_2269},{&g_4,&l_2269},{&l_2269,&g_52},{&g_156,&l_2272[0][5][2]},{&g_4,&g_156}},{{&l_2272[0][5][2],&g_52},{&l_2272[0][5][2],&g_156},{&g_4,&l_2272[0][5][2]},{&g_156,&g_52},{&l_2269,&l_2269},{&g_4,&l_2269},{&l_2269,&g_52},{&g_156,&l_2272[0][5][2]},{&g_4,&g_156},{&l_2272[0][5][2],&g_52}},{{&l_2272[0][5][2],&g_156},{&g_4,&l_2272[0][5][2]},{&g_156,&g_52},{&l_2269,&l_2269},{&g_4,&l_2269},{&l_2269,&g_52},{&g_156,&l_2272[0][5][2]},{&g_4,&g_156},{&l_2272[0][5][2],&g_52},{&l_2272[0][5][2],&g_156}},{{&g_4,&l_2272[0][5][2]},{&g_156,&g_52},{&l_2269,&l_2269},{&g_4,&l_2269},{&l_2269,&g_52},{&g_156,&l_2272[0][5][2]},{&g_4,&g_156},{&l_2272[0][5][2],&g_52},{&l_2272[0][5][2],&g_156},{&g_4,&l_2272[0][5][2]}}};
                    int16_t ***l_2713[1][5][6] = {{{&l_2395,(void*)0,&l_2395,&g_2711,&g_2711,&l_2395},{&l_2395,&l_2395,&l_2395,(void*)0,&l_2395,&g_2711},{&l_2395,&l_2395,(void*)0,(void*)0,&l_2395,&l_2395},{&g_2711,&l_2395,(void*)0,&l_2395,&g_2711,&g_2711},{(void*)0,&l_2395,&l_2395,(void*)0,&l_2395,(void*)0}}};
                    int i, j, k;
                    l_2661++;
                    if ((safe_rshift_func_int8_t_s_s((-1L), ((safe_mul_func_int8_t_s_s(((((*l_2644) <= (((((-8L) == (((~(l_2657 <= ((safe_sub_func_uint32_t_u_u(p_19.f0, 0L)) && (((l_2635 <= (((*g_2212) , l_2671[1][1][1]) == &l_2272[2][7][2])) || (*l_2650)) >= p_19.f0)))) | (*l_2650)) | p_19.f0)) < 0L) > l_2635) || p_22)) , l_2672[3][3]) == (void*)0), 249UL)) || 0L))))
                    { /* block id: 1207 */
                        int64_t l_2691 = 0x9BC00EADD5D08818LL;
                        l_2634 |= ((((*l_2261) = ((**g_752) = (p_19.f0 , 0UL))) && (safe_lshift_func_int16_t_s_s(l_2675, (safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(9UL, (safe_lshift_func_uint16_t_u_s((p_19.f0 & (safe_div_func_int8_t_s_s(0xFCL, (safe_mod_func_uint8_t_u_u(((safe_unary_minus_func_int32_t_s((p_22 < (safe_lshift_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(8UL, p_22)), 9))))) != l_2639), 254UL))))), l_2691)))), l_2692))))) != 1L);
                        (*g_631) = (void*)0;
                    }
                    else
                    { /* block id: 1212 */
                        uint64_t l_2694 = 0UL;
                        int16_t ****l_2703 = &l_2632[0][6][4];
                        int16_t l_2708 = 1L;
                        int i, j;
                        l_2694++;
                        (*l_2649) = ((((safe_add_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_u((((*g_2445) = l_2701[6][0][4]) != l_2702), (**g_752))) , (((*l_2703) = l_2632[2][3][4]) == &g_991)) || (l_2267 = (p_22 | (l_2704 > (((*l_2261) = (safe_mul_func_uint8_t_u_u(((&g_322 != l_2707) & (*p_20)), p_22))) ^ l_2708))))), l_2693)) , p_19.f0) , g_1347[2]) == (void*)0);
                        (*l_2650) &= (l_2709 , (((((*l_2289) = &p_19) == &p_19) ^ (((l_2632[0][6][4] = g_2710) != l_2713[0][0][1]) || (safe_sub_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((g_1615[g_414][g_2455.f1] = (((*l_2637) = ((safe_mul_func_int8_t_s_s((l_2720 == l_2721), (!((0x396AC63FEC725EA9LL == l_2708) <= 0x4A26E329CC96ABB4LL)))) || (**g_465))) ^ 0xDCL)) < 0x47A7A01C18E2D068LL), p_22)) , p_19.f0), p_19.f0)))) , g_1615[g_414][g_2455.f1]));
                    }
                }
            }
        }
        if ((&p_20 != (l_2635 , (l_2741 = (((safe_add_func_int8_t_s_s((-4L), ((safe_lshift_func_uint16_t_u_s(((safe_mul_func_uint8_t_u_u(((((*l_2740) = (((~(((safe_lshift_func_uint16_t_u_s(0x8015L, (l_2280 == ((p_19.f0 = ((*l_2739) |= (~(safe_sub_func_int64_t_s_s(0x1A385A40E5C4FF8CLL, (safe_div_func_uint8_t_u_u((p_22 >= ((safe_add_func_int8_t_s_s((*p_20), ((((p_22 ^ 0UL) , p_19.f0) == p_22) || 255UL))) ^ (*g_53))), 2UL))))))) != p_22)))) , (*g_466)) | (**g_752))) , l_2359) == l_2359)) > l_2269) ^ l_2635), 0xD8L)) < 4294967294UL), 0)) < (*g_53)))) < l_2399) , &p_20)))))
        { /* block id: 1232 */
            if (l_2489)
                break;
            for (g_520 = 0; (g_520 < 4); g_520++)
            { /* block id: 1236 */
                return p_19.f0;
            }
        }
        else
        { /* block id: 1239 */
            uint8_t l_2746 = 1UL;
            int32_t l_2764 = 0xDD34E5B8L;
            int32_t l_2796 = (-1L);
            int32_t l_2797 = 0x43C4930AL;
            union U0 l_2865 = {0x62C6697BL};
            union U1 **l_2872[6];
            int16_t l_2882 = 0xADA6L;
            int32_t *l_2898 = &l_2768;
            int32_t *l_2899[2];
            uint64_t l_2900 = 4UL;
            int i;
            for (i = 0; i < 6; i++)
                l_2872[i] = &g_262;
            for (i = 0; i < 2; i++)
                l_2899[i] = &l_2797;
            for (g_2398.f1 = 0; (g_2398.f1 <= 4); g_2398.f1 += 1)
            { /* block id: 1242 */
                int32_t *l_2744[2][2][7] = {{{&l_2272[0][5][2],&l_2640,&l_2640,&l_2272[0][5][2],&l_2640,&l_2640,&l_2272[0][5][2]},{&l_2640,&l_2272[0][5][2],&l_2640,&l_2640,&l_2272[0][5][2],&l_2640,&l_2640}},{{&l_2272[0][5][2],&l_2272[0][5][2],&l_2639,&l_2272[0][5][2],&l_2272[0][5][2],&l_2639,&l_2272[0][5][2]},{&l_2272[0][5][2],&l_2640,&l_2640,&l_2272[0][5][2],&l_2640,&l_2640,&l_2272[0][5][2]}}};
                int32_t **l_2777 = &l_2744[1][1][6];
                uint8_t **l_2780[10][4] = {{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,(void*)0,&l_2740},{&l_2740,&l_2740,(void*)0,&l_2740},{&l_2740,&l_2740,&l_2740,(void*)0},{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,&l_2740,&l_2740},{&l_2740,&l_2740,(void*)0,&l_2740}};
                int i, j, k;
                --l_2746;
                for (g_1436 = 0; (g_1436 <= 1); g_1436 += 1)
                { /* block id: 1246 */
                    int16_t *l_2753[1];
                    uint64_t l_2763 = 0xED4BA02FE3867A30LL;
                    int32_t l_2770 = 0xA57B682BL;
                    int32_t l_2772 = 0x92790C0AL;
                    int32_t l_2773 = (-5L);
                    int i;
                    for (i = 0; i < 1; i++)
                        l_2753[i] = &g_1239;
                    l_2640 ^= (safe_mul_func_int16_t_s_s(((*g_2712) = (l_2764 |= (g_1342[(g_1436 + 1)] < (safe_lshift_func_int16_t_s_u(((0x0CA8L < ((*l_2739) ^= (*g_2712))) <= ((l_2270 = l_2746) | (safe_mod_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(p_19.f0, 7)), (safe_rshift_func_int16_t_s_s((-5L), 12)))))), (l_2431 || (g_1342[(g_1436 + 1)] != (((*g_466) && l_2762) >= l_2763)))))))), p_22));
                    for (l_2308 = 1; (l_2308 <= 4); l_2308 += 1)
                    { /* block id: 1254 */
                        int16_t l_2766 = 0xD34EL;
                        int32_t l_2771 = 0L;
                        uint16_t l_2774 = 2UL;
                        int i, j, k;
                        (*l_2739) = 0xEA630FA3L;
                        l_2774++;
                        if (l_2764)
                            continue;
                    }
                }
                (*l_2777) = ((*g_631) = &l_2268);
                for (l_2489 = 6; (l_2489 >= 0); l_2489 -= 1)
                { /* block id: 1264 */
                    int32_t l_2789 = 0x8B82CCCDL;
                    int32_t l_2791 = 0xAAB0956CL;
                    int32_t l_2792 = (-7L);
                    int32_t l_2794[2][10];
                    int8_t l_2795 = (-5L);
                    int i, j;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_2794[i][j] = (-1L);
                    }
                    for (g_2202.f1 = 2; (g_2202.f1 <= 9); g_2202.f1 += 1)
                    { /* block id: 1267 */
                        int32_t l_2790 = 0xC89FACEBL;
                        int32_t l_2793[4][6][4] = {{{0x525A2B32L,6L,0x78003283L,0x20F3B2C5L},{(-5L),0xB6C3E7DBL,0x81A398CDL,9L},{(-5L),(-1L),0x78003283L,0x6B333FF0L},{0x525A2B32L,9L,9L,0xA6EC6CEEL},{0xB6AB9126L,0xD5CC336AL,0x6B333FF0L,0x39324AF3L},{1L,0x9D125314L,0xB5DD2DD8L,4L}},{{0x6DA5D0A9L,0xB6AB9126L,0x94AB9F6CL,0x2BD1D17AL},{9L,0x8200FA25L,0xA6EC6CEEL,0x525A2B32L},{0xB5DD2DD8L,0x77A049A3L,4L,1L},{(-5L),0x6DA5D0A9L,0xF0394342L,(-1L)},{0x908AAE12L,0xAC9DC740L,0xAC9DC740L,0x908AAE12L},{0xF0394342L,0x90F0F0B5L,6L,0x9D125314L}},{{(-1L),0x220F00DCL,0xB6AB9126L,0xB4DC75B2L},{0xD5CC336AL,0x94AB9F6CL,0x77A049A3L,0xB4DC75B2L},{0xA6EC6CEEL,0x220F00DCL,0xB6C3E7DBL,0x9D125314L},{(-1L),0x90F0F0B5L,0x20F3B2C5L,0x908AAE12L},{0xCCBBC7C8L,0xAC9DC740L,(-1L),(-1L)},{0x220F00DCL,0x6DA5D0A9L,(-5L),1L}},{{1L,0x77A049A3L,0x2D83404BL,0x525A2B32L},{0xC1EDEDEBL,0x8200FA25L,0x9D125314L,0x2BD1D17AL},{0xAC9DC740L,0xB6AB9126L,0x41331432L,4L},{0x94AB9F6CL,0x9D125314L,0L,0x39324AF3L},{0x39324AF3L,0xD5CC336AL,0x39324AF3L,0xA6EC6CEEL},{1L,9L,0x8200FA25L,0x6B333FF0L}}};
                        uint64_t l_2798[9][4] = {{0UL,0xBFC5C242C3BEC006LL,0xE862D50DE0AF2857LL,0xC176354BE98FBECFLL},{0xBFC5C242C3BEC006LL,0xE862D50DE0AF2857LL,0xE862D50DE0AF2857LL,0x4A2E4717275740A8LL},{0UL,0UL,0xE862D50DE0AF2857LL,0xC0B2DCD15B844B1DLL},{0x4A2E4717275740A8LL,0x0539DDE8CCF3A6ADLL,0xC176354BE98FBECFLL,0x0539DDE8CCF3A6ADLL},{0x0539DDE8CCF3A6ADLL,0xE862D50DE0AF2857LL,0UL,0x0539DDE8CCF3A6ADLL},{0UL,0x0539DDE8CCF3A6ADLL,0xC0B2DCD15B844B1DLL,0xC0B2DCD15B844B1DLL},{0UL,0UL,0xC176354BE98FBECFLL,0x4A2E4717275740A8LL},{0UL,0xE862D50DE0AF2857LL,0xC0B2DCD15B844B1DLL,0UL},{0UL,0x4A2E4717275740A8LL,0UL,0xC0B2DCD15B844B1DLL}};
                        int i, j, k;
                        (*l_2777) = ((((safe_lshift_func_int8_t_s_u(g_1342[g_2398.f1], (g_1342[g_2398.f1] && (0UL | 0L)))) != ((*g_466) = ((((((g_527 != l_2780[6][0]) == g_1342[g_2398.f1]) , 0x25L) > ((safe_sub_func_uint16_t_u_u(((safe_div_func_int32_t_s_s(((safe_mul_func_int8_t_s_s((safe_mod_func_uint64_t_u_u(p_19.f0, (*g_125))), (*p_20))) & (*p_20)), l_2789)) , (*g_466)), p_22)) && (*g_53))) >= (*l_2739)) , 65534UL))) ^ p_22) , (void*)0);
                        l_2798[2][2]++;
                        return p_22;
                    }
                }
            }
            if ((*l_2739))
                break;
            for (l_2267 = 0; (l_2267 >= (-22)); l_2267--)
            { /* block id: 1278 */
                uint32_t l_2847 = 0x697FA2FDL;
                int64_t l_2875 = 0x721B999902EAB4E0LL;
                int32_t *l_2890 = &l_2764;
                int32_t *l_2897 = &g_520;
                for (g_1900.f1 = 0; (g_1900.f1 != 23); g_1900.f1 = safe_add_func_uint8_t_u_u(g_1900.f1, 5))
                { /* block id: 1281 */
                    int32_t l_2832[7] = {0xF5B4925EL,0xF5B4925EL,(-1L),0xF5B4925EL,0xF5B4925EL,(-1L),0xF5B4925EL};
                    int32_t l_2846[5];
                    int64_t l_2876 = 0x851EF81353EE151FLL;
                    int64_t *l_2883 = &g_154;
                    int16_t l_2886 = (-8L);
                    int32_t *l_2887[9] = {(void*)0,&l_2269,&l_2269,(void*)0,&l_2269,&l_2269,(void*)0,&l_2269,&l_2269};
                    int i;
                    for (i = 0; i < 5; i++)
                        l_2846[i] = 0x65304174L;
                    for (l_2431 = 0; (l_2431 <= 9); l_2431 += 1)
                    { /* block id: 1284 */
                        int i;
                        if (g_1077[l_2431])
                            break;
                        return (*g_125);
                    }
                    for (g_52 = 0; (g_52 != (-16)); g_52 = safe_sub_func_uint32_t_u_u(g_52, 6))
                    { /* block id: 1290 */
                        uint32_t l_2807 = 0UL;
                        int32_t *l_2808 = &l_2640;
                        int32_t *l_2809 = &l_2271;
                        int32_t *l_2810 = &l_2272[0][5][1];
                        int32_t *l_2811 = &l_2769;
                        int32_t *l_2812 = &l_2272[0][5][2];
                        int32_t *l_2813 = &g_520;
                        int32_t *l_2814 = &l_2797;
                        int32_t *l_2815 = &g_401;
                        int32_t *l_2816 = &l_2764;
                        int32_t *l_2817 = &l_2640;
                        int32_t *l_2818 = &l_2769;
                        int32_t *l_2819 = &g_2551;
                        int32_t *l_2820 = (void*)0;
                        int32_t *l_2821 = &g_401;
                        int32_t *l_2822 = &l_2268;
                        int32_t *l_2823 = &l_2764;
                        int32_t *l_2824 = &l_2272[0][5][2];
                        int32_t *l_2825 = &l_2272[0][5][2];
                        int32_t *l_2826 = (void*)0;
                        int32_t *l_2827 = &l_2640;
                        int32_t *l_2828 = &l_2640;
                        int32_t *l_2829 = &g_156;
                        int32_t *l_2830 = &g_401;
                        int32_t *l_2831 = &l_2270;
                        int32_t *l_2833 = &g_520;
                        int32_t *l_2834 = &g_520;
                        int32_t *l_2835 = (void*)0;
                        int32_t *l_2836 = &g_401;
                        int32_t *l_2837 = &g_156;
                        int32_t *l_2838 = (void*)0;
                        int32_t *l_2839 = &l_2796;
                        int32_t *l_2840 = &l_2639;
                        int32_t *l_2841 = &l_2272[0][5][2];
                        int32_t *l_2842 = &g_156;
                        int32_t *l_2843 = &l_2640;
                        int32_t *l_2844 = &l_2764;
                        int32_t *l_2845[6][6] = {{(void*)0,&g_520,&l_2268,&l_2270,&l_2268,&g_520},{&l_2797,&l_2271,&l_2267,&l_2270,&l_2271,&l_2268},{(void*)0,&l_2268,&l_2267,&l_2797,&g_520,&g_520},{&g_4,&l_2268,&l_2268,&g_4,&l_2271,&g_156},{&g_4,&l_2271,&g_156,&l_2797,&l_2268,&g_156},{(void*)0,&g_520,&l_2268,&l_2270,&l_2268,&g_520}};
                        int i, j;
                        (*g_1088) = (l_2807 , ((p_19.f0 , (-4L)) , (void*)0));
                        ++l_2847;
                        (*l_2844) &= (((safe_sub_func_int32_t_s_s(((*l_2825) = (((!(safe_add_func_int32_t_s_s(((*l_2808) |= (p_22 | 0x9E71L)), (&g_132 == ((*l_2741) = func_33((l_2797 = (safe_lshift_func_int16_t_s_s((((safe_sub_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((safe_div_func_int8_t_s_s((p_19.f0 , ((p_19 , ((l_2865 , (g_425 = (safe_lshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_u((func_71((safe_sub_func_int8_t_s_s((((l_2872[2] == (*g_1201)) <= ((safe_rshift_func_uint8_t_u_s(0x0DL, 0)) | 0xC1L)) != p_22), 0x06L))) , l_2875), l_2846[3])), 1)))) , 18446744073709551606UL)) && 18446744073709551606UL)), l_2832[1])), l_2876)), p_22)), (*g_53))) , (*l_2739)) , (*g_2712)), 15))), (*l_2739), p_19.f0, &g_132, l_2877[0][1])))))) != 0xABL) <= 8L)), (-10L))) | 0x049AL) | p_19.f0);
                    }
                    l_2797 = (safe_mul_func_int8_t_s_s(((l_2832[1] | ((*l_2739) = ((safe_lshift_func_uint16_t_u_u(p_22, 6)) != ((*l_2883) = l_2882)))) != (p_19.f0 > (*p_20))), (safe_div_func_int8_t_s_s(((*g_2212) = ((*g_125) & 0L)), (l_2886 && (p_22 > 18446744073709551606UL))))));
                }
                for (g_207.f1 = (-1); (g_207.f1 != 44); g_207.f1 = safe_add_func_uint32_t_u_u(g_207.f1, 1))
                { /* block id: 1307 */
                    l_2890 = (void*)0;
                }
                (*l_2897) = ((safe_sub_func_uint16_t_u_u((((void*)0 == &g_1451) , (safe_lshift_func_uint8_t_u_s(((*l_2740) = p_19.f0), ((safe_mod_func_int32_t_s_s((0xB9D081BBL > 6L), 0xCAD52DBDL)) ^ ((*l_2739) ^= 9L))))), (&g_471 == &g_54))) > p_19.f0);
            }
            l_2900++;
        }
    }
lbl_2960:
    l_2903 = &l_2269;
    for (g_61 = (-3); (g_61 == 20); g_61 = safe_add_func_int16_t_s_s(g_61, 7))
    { /* block id: 1320 */
        uint8_t l_2916[7] = {0xADL,0xADL,0xADL,0xADL,0xADL,0xADL,0xADL};
        uint64_t l_2920[4];
        int32_t *l_2940 = &g_156;
        int64_t * const ***l_2964[8] = {&g_1775,&g_1775,&g_1775,&g_1775,&g_1775,&g_1775,&g_1775,&g_1775};
        union U0 l_2971[10] = {{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L},{0x944DB031L}};
        int i;
        for (i = 0; i < 4; i++)
            l_2920[i] = 0xB0F2C9D8CCFA6725LL;
        for (g_1026.f1 = 0; (g_1026.f1 <= 2); g_1026.f1 += 1)
        { /* block id: 1323 */
            uint16_t l_2917 = 0xC2FFL;
            const int32_t l_2925 = 0x94CD0198L;
            union U0 ***l_2949[9];
            int64_t *l_2976[6];
            int i;
            for (i = 0; i < 9; i++)
                l_2949[i] = &l_2701[6][0][4];
            for (i = 0; i < 6; i++)
                l_2976[i] = &l_2489;
            (*g_1088) = &l_2269;
            if ((8L | (safe_add_func_uint8_t_u_u(3UL, (((safe_add_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s((p_22 ^ (p_22 == (safe_lshift_func_int8_t_s_u(((l_2916[6] >= (0x7DL || (*g_2212))) , (((*g_53) ^= (--l_2917)) == ((l_2920[1] & (safe_div_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(0xEBL, 0xCCL)), (*l_2903)))) <= 4294967295UL))), l_2925)))), p_19.f0)), 0x6C86L)) , p_19) , 5L)))))
            { /* block id: 1327 */
                const int16_t *l_2930[9][3];
                const int16_t **l_2929 = &l_2930[7][2];
                const int16_t ***l_2928[4] = {&l_2929,&l_2929,&l_2929,&l_2929};
                const int16_t ****l_2927 = &l_2928[1];
                int32_t l_2958[6][2][7] = {{{2L,2L,(-1L),0x5E6D8CFDL,0x5693F353L,0xA84BECA5L,0xC048AFA0L},{0x6E20E515L,0x8DF36501L,0xD71F2716L,(-3L),1L,(-1L),0L}},{{0x2CFC59EDL,2L,0x326D28A6L,0x97DB6345L,0x5693F353L,0x97DB6345L,0x326D28A6L},{0x6E20E515L,0x6E20E515L,0xABF0F960L,(-3L),0x5715C263L,0xFF6EEE8EL,0L}},{{2L,0x2CFC59EDL,0x326D28A6L,0x5E6D8CFDL,0xB5AA45F1L,0x97DB6345L,0xC048AFA0L},{0x8DF36501L,0x6E20E515L,0xD71F2716L,(-1L),0x5715C263L,(-1L),0xD71F2716L}},{{2L,2L,(-1L),0x5E6D8CFDL,0x5693F353L,0xA84BECA5L,0xC048AFA0L},{0x6E20E515L,0x8DF36501L,0xD71F2716L,(-3L),1L,(-1L),0L}},{{0x2CFC59EDL,2L,0x326D28A6L,0x97DB6345L,0x5693F353L,0x97DB6345L,0x326D28A6L},{0x6E20E515L,0x6E20E515L,0xABF0F960L,(-3L),0x5715C263L,0xFF6EEE8EL,0L}},{{2L,0x2CFC59EDL,0x326D28A6L,0x5E6D8CFDL,0xB5AA45F1L,0x97DB6345L,0xC048AFA0L},{0x8DF36501L,1L,(-1L),0x42F112EAL,0xB6038993L,0x42F112EAL,(-1L)}}};
                uint16_t l_2959 = 6UL;
                int i, j, k;
                for (i = 0; i < 9; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_2930[i][j] = &l_2308;
                }
                for (g_324 = 0; (g_324 <= 2); g_324 += 1)
                { /* block id: 1330 */
                    int i, j, k;
                    if (g_408)
                        goto lbl_2926;
                    return l_2272[(g_1026.f1 + 1)][(g_1026.f1 + 5)][g_324];
                }
                for (g_207.f1 = 0; (g_207.f1 <= 2); g_207.f1 += 1)
                { /* block id: 1336 */
                    uint32_t l_2955 = 0xD0493B65L;
                    int i, j, k;
                    l_2272[g_1026.f1][(g_1026.f1 + 4)][g_1026.f1] = (l_2927 == &l_2928[3]);
                    for (g_401 = 2; (g_401 >= 0); g_401 -= 1)
                    { /* block id: 1340 */
                        int32_t *l_2939[3][7] = {{&g_156,&g_4,&g_156,&l_2268,&l_2268,&g_156,&g_4},{&l_2268,&g_4,&l_2271,&l_2271,&g_4,&l_2268,&g_4},{&g_156,&l_2268,&l_2268,&g_156,&g_4,&g_156,&l_2268}};
                        int8_t ***l_2954 = &l_2741;
                        uint8_t *l_2956 = &g_183.f1;
                        uint8_t *l_2957 = &g_1924.f1;
                        const int32_t **l_2961 = &g_805[3];
                        int i, j, k;
                        l_2272[(g_401 + 4)][(g_1026.f1 + 2)][g_1026.f1] ^= ((l_2916[6] <= (safe_sub_func_int8_t_s_s(((((safe_sub_func_int8_t_s_s((((safe_mod_func_int32_t_s_s((((((l_2940 = l_2939[0][3]) != &l_2925) & (safe_lshift_func_uint16_t_u_u(((p_19.f0 >= (safe_add_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((safe_add_func_uint64_t_u_u(((((*l_2957) &= ((((void*)0 != l_2949[0]) ^ (safe_sub_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u((l_2917 || ((*l_2956) = ((((*l_2954) = &p_20) != ((l_2955 , (-3L)) , &g_2212)) <= (*g_2212)))), p_22)) || 0x271BB696564DB512LL) , 0xDF8EL), 0L))) && 0x6E5D27EA404D1562LL)) || 0x0AL) && 0x6BBF8BFFL), l_2917)), 3)), (*g_2212)))) & 0x97C01B55BE655786LL), l_2958[1][1][3]))) != 0L) , l_2955), l_2959)) & (**g_465)) > p_22), (*g_2212))) , p_22) || p_19.f0) >= l_2955), (*g_2212)))) , 0L);
                        if (g_81.f0)
                            goto lbl_2960;
                        (*l_2961) = &l_2925;
                    }
                }
            }
            else
            { /* block id: 1350 */
                return p_22;
            }
            for (g_218 = 3; (g_218 >= 0); g_218 -= 1)
            { /* block id: 1355 */
                int32_t l_2974 = (-4L);
                int64_t *l_2975 = &l_2489;
                int32_t *l_2978 = &l_2267;
                int i;
                (*l_2978) |= ((g_202[g_1026.f1] & (((((((&g_1986 != l_2964[7]) , (l_2975 = (((safe_rshift_func_uint8_t_u_s(((safe_sub_func_uint64_t_u_u(p_19.f0, (-1L))) , ((l_2974 &= (((((p_19 , ((safe_rshift_func_int8_t_s_u(((*g_53) & ((l_2971[5] , (safe_mul_func_uint32_t_u_u((((*l_2903) = (((((p_19.f0 , (*g_2212)) != 0x60L) | (*l_2903)) ^ 0L) && l_2916[4])) && 0xAC0A195BL), 0UL))) , 4294967293UL)), 6)) >= 0UL)) <= 0xCC5898F5L) && p_19.f0) & l_2920[1]) , p_19.f0)) <= p_22)), (*p_20))) , 1L) , &l_2489))) == l_2976[0]) == 4294967293UL) , 0xC1L) <= g_2977) > (*g_2212))) <= 0UL);
            }
            (*l_2903) = l_2917;
        }
        (*g_631) = &l_2267;
        if (p_22)
            break;
        if (p_22)
            break;
    }
    return (*g_125);
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_41 g_4 g_53 g_61 g_409 g_52 g_1021 g_106 g_631 g_632 g_1088 g_54 g_1201 g_1202 g_1203 g_466 g_254 g_752 g_232.f1 g_676.f1 g_1436 g_401 g_673.f1 g_202 g_154 g_104 g_674.f1 g_991 g_992 g_424 g_465 g_1775 g_690 g_691 g_156 g_125 g_126 g_1584 g_132 g_1332 g_1077 g_1939 g_1776 g_726 g_425 g_81
 * writes: g_41 g_52 g_61 g_409 g_424 g_550 g_106 g_632 g_465 g_54 g_805 g_9 g_401 g_1584 g_154 g_1239 g_1775 g_466 g_104 g_1077 g_1347 g_1918 g_1203 g_1615 g_1021 g_553 g_425
 */
static union U0  func_23(int8_t  p_24)
{ /* block id: 5 */
    int8_t *l_31 = &g_9;
    int32_t l_32[3][10][8] = {{{0xD6B9EC49L,(-1L),0x717898A8L,0x138D7EFBL,0x1140AE77L,0x7293CC9DL,0x2231B3DFL,(-6L)},{(-1L),0x6F2C0E84L,3L,(-1L),0xB927EED0L,(-6L),(-3L),0x00B8F3BEL},{0x0D726993L,4L,0x694A98A1L,(-1L),0x59AF2C67L,(-9L),2L,(-9L)},{0xD053A657L,0x2231B3DFL,0x4BB84A8AL,0x2231B3DFL,0xD053A657L,0xE98C5348L,9L,1L},{3L,0x34D56B86L,8L,(-7L),0x36A74B4FL,(-3L),(-6L),0x2231B3DFL},{(-1L),9L,8L,0x88F57543L,(-1L),(-1L),9L,0xB506946CL},{0x36A74B4FL,0x737FB643L,0x4BB84A8AL,1L,0x88F57543L,0x717898A8L,2L,0x99E68FC7L},{(-3L),1L,0x694A98A1L,0xD2300B63L,1L,8L,(-3L),9L},{0x99E68FC7L,(-6L),3L,8L,(-1L),(-1L),0x2231B3DFL,(-9L)},{0xF53C8CBFL,0xD6B9EC49L,0x717898A8L,0xBFE21DABL,(-1L),(-1L),(-1L),0x0D726993L}},{{0x673ED132L,0x0D726993L,5L,0xD2300B63L,(-1L),(-6L),7L,2L},{0x00B8F3BEL,0x694A98A1L,(-1L),0x138D7EFBL,0x956A74ABL,0x673ED132L,0x00B8F3BEL,0xB506946CL},{0xD053A657L,0xF5592973L,0x9D684829L,0L,0xB927EED0L,0xB805D31CL,0x88F57543L,0xD6B9EC49L},{5L,(-1L),0xD2300B63L,(-7L),0x34D56B86L,(-9L),0xB2B1506FL,(-1L)},{0x2C7E12FDL,(-1L),(-7L),0xD6B9EC49L,0x956A74ABL,9L,9L,(-9L)},{0x2231B3DFL,0xB927EED0L,0xFDFDA84AL,0xF53C8CBFL,0xF53C8CBFL,0xFDFDA84AL,0xB927EED0L,0x2231B3DFL},{0x673ED132L,1L,0xB2B1506FL,(-1L),9L,0x956A74ABL,4L,0x88F57543L},{0x36A74B4FL,1L,0x6FDE0027L,(-1L),(-1L),0x956A74ABL,0x99E68FC7L,(-3L)},{0xBC1F9C85L,1L,0x7293CC9DL,0x6F2C0E84L,8L,0xFDFDA84AL,0L,0x0D726993L},{(-3L),0xB927EED0L,3L,(-1L),(-6L),9L,(-1L),0xB927EED0L}},{{(-1L),(-1L),(-1L),0xBFE21DABL,0x0B7F45B6L,0L,(-1L),0L},{4L,2L,1L,(-1L),9L,0x2C7E12FDL,3L,0x6FDE0027L},{0x6C7A88FFL,(-1L),0x4D9805F6L,1L,8L,0x13C9534CL,(-1L),0x59AF2C67L},{(-3L),1L,(-7L),(-9L),(-4L),0x717898A8L,(-9L),0x6C7A88FFL},{2L,7L,9L,0x9FBC0AE2L,(-1L),0xD6B9EC49L,1L,0xC74E2B78L},{(-6L),0x07F7A796L,0xE98C5348L,(-7L),(-3L),0x267A5E2BL,(-1L),3L},{0x4C5D19E7L,0x717898A8L,0x34FD39EFL,(-1L),0x767DBF12L,0xE54FD57EL,0x956A74ABL,0x6C7A88FFL},{5L,0x673ED132L,0xF53C8CBFL,(-6L),2L,0xBC1F9C85L,2L,(-6L)},{0x8E8B88BBL,(-3L),0x8E8B88BBL,1L,(-6L),0xFDFDA84AL,0x4BB84A8AL,1L},{1L,0x7293CC9DL,1L,4L,0x267A5E2BL,0x34FD39EFL,(-6L),0L}}};
    uint32_t *l_40 = &g_41;
    int32_t *l_51 = &g_52;
    int16_t *l_2204 = &g_60;
    uint16_t ***l_2224 = &g_465;
    int32_t *l_2230 = &g_156;
    int32_t *l_2231 = (void*)0;
    int32_t *l_2232 = &l_32[2][9][1];
    int32_t *l_2233[4];
    int32_t l_2234 = 0xD15999A8L;
    int32_t l_2235 = 0x82C59CCFL;
    int8_t l_2236 = 0xDCL;
    int32_t l_2237 = (-1L);
    uint64_t l_2238 = 18446744073709551615UL;
    union U2 **l_2241[8];
    uint8_t *l_2245 = &g_104[1];
    uint32_t *l_2246 = &g_425;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_2233[i] = &g_52;
    for (i = 0; i < 8; i++)
        l_2241[i] = &g_1347[2];
    if (func_25(l_31, l_32[2][9][1], l_31, func_33(((!((*l_40) |= g_9)) , (l_32[0][7][6] & g_4)), func_42(((g_4 && (safe_div_func_int32_t_s_s(p_24, ((*l_51) = (safe_rshift_func_uint16_t_u_u(6UL, 3)))))) ^ p_24), g_53, &g_9, l_32[2][9][1]), p_24, l_31, p_24), l_31))
    { /* block id: 860 */
        uint16_t l_1964 = 65535UL;
        int16_t **l_1991 = (void*)0;
        int16_t ***l_1990 = &l_1991;
        int16_t ****l_1989 = &l_1990;
        const uint16_t l_1992 = 0x9ACEL;
        int32_t *l_1996 = &g_156;
        int32_t l_2010 = 0x14C3B7CAL;
        uint32_t l_2013[6];
        int32_t l_2028 = 0x62F6562CL;
        int32_t l_2061 = 0L;
        union U1 **l_2074[2];
        int16_t l_2075 = (-2L);
        int64_t *l_2079[1][1][3];
        const int32_t l_2095 = 2L;
        union U2 *l_2125[3];
        int64_t l_2168[1][2];
        uint32_t l_2218[3];
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_2013[i] = 0UL;
        for (i = 0; i < 2; i++)
            l_2074[i] = &g_262;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 3; k++)
                    l_2079[i][j][k] = &g_154;
            }
        }
        for (i = 0; i < 3; i++)
            l_2125[i] = &g_2126;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_2168[i][j] = 0xB96296CD1AACF846LL;
        }
        for (i = 0; i < 3; i++)
            l_2218[i] = 0x558F13F5L;
        (*g_631) = &l_32[2][0][4];
    }
    else
    { /* block id: 1024 */
        (*l_51) = (-1L);
    }
    ++l_2238;
    g_553 = (void*)0;
    if (((*l_2232) > ((~(((*l_2246) |= ((safe_rshift_func_uint8_t_u_u((p_24 > ((p_24 & ((*l_51) , ((void*)0 != &g_631))) < ((*l_2245) &= g_726))), 3)) ^ 6L)) , ((1UL == p_24) > p_24))) > (-1L))))
    { /* block id: 1031 */
        int32_t *l_2247 = &g_401;
        int32_t **l_2248[8] = {&l_2247,&l_2247,&l_2247,&l_2247,&l_2247,&l_2247,&l_2247,&l_2247};
        int i;
        g_805[3] = ((*g_631) = l_2247);
    }
    else
    { /* block id: 1034 */
        int32_t l_2249[3][8][5] = {{{0L,0xD59E4A63L,0x00B24433L,0xA159178CL,0xA981CD0BL},{0L,0x8349854BL,(-9L),4L,0x2B621DCBL},{0xA981CD0BL,1L,0L,0x18924DE7L,0xA159178CL},{0L,0x34B0D158L,0x437EEB44L,(-1L),0L},{0x4BCC6F23L,0x9CB4ACE9L,7L,(-3L),0xDA4B178FL},{0x36C33CD5L,7L,0x0BED4A2DL,0xD59E4A63L,(-1L)},{(-1L),7L,1L,0x0ECD71B0L,8L},{0x348D3D41L,0x9CB4ACE9L,0xDA4B178FL,0x9F586B07L,0L}},{{0x18924DE7L,0x34B0D158L,0L,0xD68C1175L,0x9F586B07L},{1L,1L,1L,1L,0x5EAE8055L},{0L,0x8349854BL,0x151790FDL,1L,0x00B24433L},{0xCA855E8BL,0xD59E4A63L,0x0ECD71B0L,0L,0xA8EDBBC4L},{1L,0x5E16EF57L,0L,1L,0x437EEB44L},{(-9L),0xA159178CL,(-6L),1L,4L},{0xA159178CL,0xDA4B178FL,1L,0xD68C1175L,0x348D3D41L},{0x00B24433L,(-5L),1L,0x9F586B07L,0x23C3FEB0L}},{{1L,0x2B621DCBL,0x5E16EF57L,0x0ECD71B0L,0L},{0x151790FDL,0xA8EDBBC4L,0x5EAE8055L,0xD59E4A63L,0x2F3042B5L},{0x151790FDL,0xAA403BD7L,0L,(-3L),1L},{1L,(-9L),0xDBE13334L,(-1L),(-6L)},{0x00B24433L,0x56D1DCA0L,0x9CB4ACE9L,0x18924DE7L,0x18924DE7L},{0xA159178CL,0L,0x190D18B5L,4L,(-5L)},{0x348D3D41L,0x23C3FEB0L,0L,0x190D18B5L,0x2F3042B5L},{1L,0x5E16EF57L,(-1L),0x2B621DCBL,(-9L)}}};
        int32_t l_2250 = 6L;
        int8_t l_2251 = (-1L);
        int32_t l_2252[10][6][2] = {{{0xE83C2F0DL,0xFC163AA5L},{(-1L),1L},{0x0088977CL,(-8L)},{(-9L),0L},{0L,0L},{(-9L),(-8L)}},{{0x0088977CL,1L},{(-1L),0xFC163AA5L},{0xE83C2F0DL,0L},{0xE6C441EAL,0xA05D0F10L},{0L,0x0088977CL},{0L,0L}},{{0x9B913F8BL,(-1L)},{(-1L),(-1L)},{1L,(-1L)},{(-1L),0L},{0x9AA994B3L,0L},{0x130FC05CL,0x9AA994B3L}},{{(-8L),0L},{(-8L),0x9AA994B3L},{0x130FC05CL,0L},{0x9AA994B3L,0L},{(-1L),(-1L)},{1L,(-1L)}},{{(-1L),(-1L)},{0x9B913F8BL,0L},{0L,0x0088977CL},{0L,0xA05D0F10L},{0xE6C441EAL,0L},{0xE83C2F0DL,0xFC163AA5L}},{{(-1L),1L},{0x0088977CL,(-8L)},{(-9L),0L},{0L,0L},{(-9L),(-8L)},{0x0088977CL,1L}},{{(-1L),0xFC163AA5L},{0xE83C2F0DL,0L},{0xE6C441EAL,0xA05D0F10L},{0L,0x0088977CL},{0L,0L},{0x9B913F8BL,(-1L)}},{{(-1L),(-1L)},{1L,(-1L)},{(-1L),0L},{0x9AA994B3L,0L},{0x130FC05CL,0x9AA994B3L},{(-8L),0L}},{{(-8L),0x9AA994B3L},{0x130FC05CL,0L},{0x9AA994B3L,0L},{(-1L),(-1L)},{1L,(-1L)},{(-1L),(-1L)}},{{0x9B913F8BL,0L},{0L,0x0088977CL},{0L,0xA05D0F10L},{0xE6C441EAL,0L},{0xE83C2F0DL,0xFC163AA5L},{(-1L),1L}}};
        uint8_t l_2253 = 246UL;
        int i, j, k;
        --l_2253;
    }
    return g_81;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_53 g_54 g_401 g_673.f1 g_202 g_752 g_466 g_9 g_232.f1 g_676.f1 g_1436 g_154 g_104 g_631 g_674.f1 g_991 g_992 g_424 g_465 g_61 g_1775 g_690 g_691 g_156 g_52 g_125 g_126 g_1584 g_132 g_1088 g_1332 g_1077 g_1201 g_1202 g_1939 g_1776
 * writes: g_41 g_401 g_61 g_1584 g_154 g_632 g_805 g_1239 g_1775 g_466 g_9 g_104 g_424 g_1077 g_1347 g_1918 g_1203 g_1615 g_1021
 */
static int32_t  func_25(int8_t * p_26, uint16_t  p_27, int8_t * p_28, int8_t * p_29, int8_t * p_30)
{ /* block id: 731 */
    uint64_t ***l_1707 = (void*)0;
    uint64_t ****l_1706[9] = {&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707,&l_1707};
    int32_t l_1709 = 0L;
    int32_t l_1713 = 1L;
    union U0 *l_1714 = &g_81;
    int32_t l_1731 = (-9L);
    int32_t l_1732[2][10][7] = {{{0xE874BF50L,0x23435D1FL,4L,0x9B79743AL,0xB295D5E0L,0x9134DB07L,0x8E442017L},{0x23435D1FL,0x8E442017L,(-6L),(-1L),(-1L),(-6L),0x8E442017L},{1L,(-4L),0x02876ECFL,0x9079366AL,0x8E442017L,(-8L),0L},{0x36BBF56FL,0xE874BF50L,0x8E442017L,0xEA79DE6EL,0x6D16CC85L,1L,0xBAAD7704L},{0x8E442017L,0x9B79743AL,0x9134DB07L,0x9079366AL,(-4L),0xB295D5E0L,0xFB25192DL},{(-8L),0xBAAD7704L,0x6D16CC85L,(-1L),0x9079366AL,(-1L),0x6D16CC85L},{(-8L),(-8L),0x36BBF56FL,0x9B79743AL,0xAE964620L,0x8E442017L,0xBAAD7704L},{0xAE964620L,1L,0xB295D5E0L,0xE874BF50L,0x9134DB07L,0xC3FBEA3BL,0x23435D1FL},{0x9134DB07L,0x02876ECFL,0xFB25192DL,0x9079366AL,1L,0x23435D1FL,(-1L)},{(-1L),0x6D16CC85L,0L,1L,(-4L),(-4L),1L}},{{(-1L),0x6D16CC85L,(-1L),(-1L),0x23435D1FL,1L,0x9079366AL},{0x36BBF56FL,0x02876ECFL,(-6L),0x23435D1FL,0xC3FBEA3BL,0x9134DB07L,0xE874BF50L},{0x9B79743AL,1L,(-4L),0xBAAD7704L,0xAE964620L,1L,0x9F40E8F1L},{1L,(-1L),(-1L),0xC3FBEA3BL,0x9B79743AL,(-4L),0x9B79743AL},{(-6L),(-1L),(-1L),(-6L),0x8E442017L,0x23435D1FL,(-4L)},{0xBAAD7704L,0x9F40E8F1L,(-4L),(-1L),(-1L),0xC3FBEA3BL,0xFB25192DL},{1L,0x36BBF56FL,(-6L),0xEA79DE6EL,(-1L),0xAE964620L,(-4L)},{1L,0x23435D1FL,(-1L),0xAE964620L,0x02876ECFL,0x9B79743AL,0x9B79743AL},{4L,0xAE964620L,0L,0xAE964620L,4L,0x8E442017L,0x9F40E8F1L},{(-1L),(-1L),0xFB25192DL,0xEA79DE6EL,0x9079366AL,(-1L),0xE874BF50L}}};
    uint64_t l_1738[10];
    uint32_t l_1769 = 1UL;
    const int64_t *l_1773 = &g_154;
    const int64_t **l_1772 = &l_1773;
    const int64_t ***l_1771 = &l_1772;
    int64_t ****l_1851 = (void*)0;
    union U1 *l_1899 = &g_1900;
    union U2 *l_1920 = &g_1921;
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_1738[i] = 0x94700A6ACE8F784ELL;
    for (g_41 = 0; (g_41 > 53); ++g_41)
    { /* block id: 734 */
        int32_t *l_1702 = (void*)0;
        int32_t *l_1703 = &g_401;
        uint64_t *****l_1708 = &l_1706[0];
        int8_t *l_1710 = &g_1584[0];
        uint8_t *l_1712[5];
        uint8_t **l_1711 = &l_1712[3];
        int64_t l_1722 = 0x361752BB2D4DFC58LL;
        int32_t l_1723 = 0L;
        int32_t l_1724 = 0L;
        int32_t l_1727 = 1L;
        int32_t l_1730 = 0x7F65A332L;
        int32_t l_1736[5];
        int32_t *l_1741 = &g_401;
        int64_t l_1826 = 1L;
        int64_t l_1840[4][4][8] = {{{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L}},{{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L}},{{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L}},{{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L},{0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L,0xA93325C202B8326ELL,0x647A47BD0FDA98DFLL,0xA93325C202B8326ELL,1L}}};
        uint32_t l_1877 = 4UL;
        union U0 **l_1944[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_1712[i] = &g_104[3];
        for (i = 0; i < 5; i++)
            l_1736[i] = (-1L);
        (*l_1703) ^= (safe_add_func_int32_t_s_s(p_27, (*g_53)));
        l_1713 ^= (safe_lshift_func_int16_t_s_s(p_27, ((p_27 >= (*l_1703)) || (((*l_1711) = func_33(g_673.f1, ((((p_27 != (((*l_1708) = l_1706[0]) == &g_1329)) <= ((*l_1703) ^= l_1709)) ^ l_1709) ^ p_27), p_27, l_1710, g_202[0])) != p_30))));
        for (g_154 = 0; (g_154 <= 3); g_154 += 1)
        { /* block id: 742 */
            int32_t l_1719 = 0xDC32AC84L;
            int32_t l_1720 = 0x6FD616A8L;
            int32_t l_1721 = 0x8502F2DEL;
            int32_t l_1725 = 1L;
            int32_t l_1726 = 0L;
            int32_t l_1728 = 0xB99337C8L;
            int32_t l_1729 = 0xF6CF65FBL;
            int32_t l_1733 = 0x6101EEC9L;
            int32_t l_1734 = 0x99DA95CCL;
            int32_t l_1735 = 0x0D757619L;
            int32_t l_1737[9][3] = {{0x98265D05L,0xC14E85C7L,0x98265D05L},{0x98265D05L,0xC162E1E9L,0xC14E85C7L},{0xC162E1E9L,0x98265D05L,0x98265D05L},{0xC14E85C7L,0x98265D05L,0xDF1C7856L},{0xB92D3E61L,0xC162E1E9L,(-5L)},{0xC14E85C7L,0xC14E85C7L,(-5L)},{0xC162E1E9L,0xB92D3E61L,0xDF1C7856L},{0x98265D05L,0xC14E85C7L,0x98265D05L},{0x98265D05L,0xC162E1E9L,0xC14E85C7L}};
            int32_t *l_1799 = &l_1737[6][2];
            uint64_t ****l_1846 = &l_1707;
            uint32_t l_1870 = 4294967289UL;
            union U1 *l_1923[5];
            int i, j;
            for (i = 0; i < 5; i++)
                l_1923[i] = &g_1924;
            if (g_104[g_154])
            { /* block id: 743 */
                union U0 **l_1715 = &l_1714;
                int32_t *l_1716 = &g_520;
                int32_t *l_1717 = &g_52;
                int32_t *l_1718[6] = {&g_52,&l_1709,&l_1709,&g_52,&l_1709,&l_1709};
                int i;
                (*l_1715) = l_1714;
                --l_1738[7];
            }
            else
            { /* block id: 746 */
                int32_t l_1765 = 0x75BEC2B6L;
                int16_t * const l_1766 = (void*)0;
                int32_t l_1770 = 0x73C2606AL;
                uint64_t l_1816[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_1816[i] = 0x573EC03FCAF6A862LL;
                (*g_631) = (void*)0;
                if (p_27)
                { /* block id: 748 */
                    int16_t *l_1767 = &g_1239;
                    int32_t l_1768 = 0x9BB8F0F3L;
                    union U0 l_1778 = {0x0EF57810L};
                    uint64_t l_1779 = 0xCFD652C1A4C04B92LL;
                    uint64_t l_1800 = 1UL;
                    int32_t l_1803 = 0x3427964CL;
                    int32_t **l_1814 = &g_632[1][6];
                    g_805[1] = ((*g_631) = l_1741);
                    if ((safe_lshift_func_int16_t_s_u((l_1770 &= (l_1709 &= ((*l_1703) >= ((((*l_1710) = (((safe_sub_func_uint32_t_u_u((safe_sub_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_s((safe_sub_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s(p_27, ((g_674.f1 != ((l_1768 |= (((safe_mul_func_int8_t_s_s((((safe_mul_func_uint8_t_u_u((((*l_1767) = (safe_rshift_func_int8_t_s_u(((safe_unary_minus_func_int64_t_s((p_27 != (l_1735 <= (safe_add_func_uint32_t_u_u(0x10A5B728L, (safe_div_func_int8_t_s_s((l_1765 , ((l_1766 != (*g_991)) | l_1732[1][3][1])), 255UL)))))))) <= p_27), p_27))) | l_1765), 1UL)) | 18446744073709551608UL) < 0x1164L), 0x48L)) > l_1729) || 0UL)) != 18446744073709551613UL)) , 0x2BFCL))) , l_1738[7]), p_27)), 5)) < 0x38L), p_27)), p_27)) == l_1765) , (-1L))) < g_424[2][6]) != l_1769)))), (**g_465))))
                    { /* block id: 756 */
                        const int64_t ****l_1774 = &l_1771;
                        int64_t * const ***l_1777 = &g_1775;
                        (*l_1741) &= (((*l_1774) = l_1771) == ((*l_1777) = g_1775));
                        if (l_1713)
                            continue;
                        (*g_631) = (l_1778 , &l_1709);
                    }
                    else
                    { /* block id: 762 */
                        uint16_t *l_1788[4][8] = {{&g_61,&g_1342[1],&g_1342[1],&g_61,&g_1342[1],&g_1342[1],&g_61,&g_1342[1]},{&g_61,&g_61,(void*)0,&g_61,&g_61,(void*)0,&g_61,&g_61},{&g_1342[1],&g_61,&g_1342[1],&g_1342[1],&g_61,&g_1342[1],&g_1342[1],&g_61},{&g_61,&g_1342[1],&g_1342[1],&g_61,&g_1342[1],&g_1342[1],&g_61,&g_1342[1]}};
                        union U0 l_1789[4] = {{0xBE00747BL},{0xBE00747BL},{0xBE00747BL},{0xBE00747BL}};
                        int32_t **l_1798[1];
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_1798[i] = &l_1702;
                        ++l_1779;
                        l_1719 = (((**l_1708) != (void*)0) <= ((((*l_1703) ^= ((l_1732[1][4][6] , ((safe_rshift_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(((*p_29) = (p_27 || ((safe_mul_func_int8_t_s_s((((*g_465) = (*g_465)) == (l_1788[0][6] = &p_27)), (&l_1725 == (l_1789[0] , (l_1799 = (((safe_div_func_uint8_t_u_u((((safe_add_func_uint64_t_u_u((safe_mod_func_int64_t_s_s((safe_rshift_func_uint16_t_u_s(((*g_690) != (*g_690)), p_27)), p_27)), p_27)) || p_27) && l_1738[6]), l_1765)) , p_27) , &l_1770)))))) > (*g_53)))), g_156)) , 0x365FL), p_27)) , g_52)) ^ l_1770)) && p_27) , (*g_125)));
                        if (l_1800)
                            break;
                    }
                    for (g_61 = 0; (g_61 <= 8); g_61 += 1)
                    { /* block id: 774 */
                        const int32_t l_1810 = 0L;
                        int32_t l_1813[6][4][5] = {{{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L},{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)},{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,(-9L)},{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L}},{{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)},{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,(-9L)},{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L},{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)}},{{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,(-9L)},{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L},{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)},{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,(-9L)}},{{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L},{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)},{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,(-9L)},{3L,0x2772F9E6L,0x2772F9E6L,3L,0x92B344F9L}},{{3L,0xF2A2A767L,0x9924E134L,3L,(-9L)},{0x64D698DFL,0xF2A2A767L,0x2772F9E6L,0x64D698DFL,6L},{2L,(-1L),(-1L),2L,(-1L)},{2L,0x64D698DFL,3L,2L,6L}},{{0x9F554B9FL,0x64D698DFL,(-1L),0x9F554B9FL,6L},{2L,(-1L),(-1L),2L,(-1L)},{2L,0x64D698DFL,3L,2L,6L},{0x9F554B9FL,0x64D698DFL,(-1L),0x9F554B9FL,6L}}};
                        uint16_t *l_1815[1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_1815[i] = (void*)0;
                        (*l_1799) = ((p_27 && ((((p_27 |= (safe_mul_func_int8_t_s_s(((l_1803 , (-1L)) <= (safe_mul_func_uint16_t_u_u((4294967295UL || (safe_mul_func_uint16_t_u_u((*l_1799), (*l_1799)))), (safe_div_func_int64_t_s_s(l_1810, l_1770))))), (((((safe_add_func_uint8_t_u_u((l_1813[5][2][1] &= ((**l_1711) &= 255UL)), g_132)) , &g_805[6]) != l_1814) | (*p_28)) || l_1709)))) <= 0xAC3EL) <= l_1816[0]) == 1L)) , (*l_1703));
                        (*l_1703) = (p_27 <= ((l_1816[0] && (l_1816[0] < (*l_1799))) , p_27));
                    }
                }
                else
                { /* block id: 781 */
                    (*l_1741) = (safe_rshift_func_int16_t_s_s((*l_1799), 14));
                    return p_27;
                }
            }
            for (g_61 = 0; (g_61 <= 8); g_61 += 1)
            { /* block id: 788 */
                (*g_631) = &l_1709;
            }
            if (p_27)
                continue;
            (*g_631) = &l_1731;
            for (p_27 = 0; (p_27 <= 0); p_27 += 1)
            { /* block id: 795 */
                int32_t *l_1819[7];
                uint16_t *l_1911 = &g_1021[0][0][2];
                int i;
                for (i = 0; i < 7; i++)
                    l_1819[i] = &l_1732[1][3][1];
                (*g_1088) = l_1819[6];
                for (l_1728 = 0; (l_1728 >= 0); l_1728 -= 1)
                { /* block id: 799 */
                    int16_t *l_1836[8][3][8] = {{{&g_1077[1],&g_1077[9],&g_1239,(void*)0,&g_1239,(void*)0,&g_1077[2],&g_1239},{&g_1077[9],(void*)0,&g_106,(void*)0,(void*)0,(void*)0,&g_1239,&g_1077[3]},{&g_726,&g_1332,(void*)0,&g_424[3][6],&g_424[3][6],(void*)0,&g_1332,&g_726}},{{&g_424[3][6],(void*)0,&g_1077[3],(void*)0,&g_424[0][4],&g_1077[6],&g_1239,&g_1239},{&g_1077[6],&g_60,&g_1077[2],(void*)0,(void*)0,&g_1077[6],&g_106,(void*)0},{&g_1239,(void*)0,&g_424[3][6],&g_1239,&g_1077[2],(void*)0,&g_1077[2],(void*)0}},{{(void*)0,&g_1332,&g_1239,&g_1077[3],(void*)0,(void*)0,(void*)0,&g_1077[3]},{&g_1077[1],(void*)0,&g_1077[1],&g_1077[2],&g_424[3][6],(void*)0,&g_726,&g_1077[1]},{&g_424[0][4],&g_1077[9],&g_106,(void*)0,&g_1077[8],&g_60,&g_424[3][6],&g_1077[3]}},{{&g_424[0][4],&g_424[3][6],&g_1077[2],&g_106,&g_424[3][6],(void*)0,&g_424[3][6],&g_1077[9]},{&g_1077[1],(void*)0,&g_1077[9],&g_1239,(void*)0,&g_1239,&g_1239,&g_1239},{(void*)0,&g_1077[2],(void*)0,(void*)0,&g_1077[2],(void*)0,&g_1239,&g_1077[3]}},{{&g_1239,&g_1077[8],(void*)0,(void*)0,(void*)0,(void*)0,&g_726,&g_1239},{&g_1077[6],&g_1239,&g_1239,(void*)0,&g_424[0][4],&g_60,&g_1077[9],&g_1077[3]},{&g_424[3][6],&g_424[0][4],&g_1239,(void*)0,&g_424[3][6],&g_106,(void*)0,&g_1239}},{{&g_726,&g_1077[9],&g_424[3][6],&g_1239,(void*)0,&g_1239,&g_424[3][6],&g_1077[9]},{&g_1077[9],&g_1332,(void*)0,&g_106,&g_1239,&g_1077[2],&g_1332,&g_1077[3]},{&g_1077[1],&g_1077[8],&g_726,(void*)0,&g_1077[9],&g_1239,&g_1332,&g_1077[1]}},{{&g_1077[6],(void*)0,(void*)0,&g_1077[2],&g_60,&g_1077[6],&g_424[3][6],&g_1077[3]},{&g_60,&g_1077[6],&g_424[3][6],&g_1077[3],(void*)0,(void*)0,(void*)0,(void*)0},{&g_1239,&g_1239,&g_1239,&g_1239,&g_1077[8],(void*)0,&g_1077[9],&g_1077[1]}},{{&g_1239,&g_1077[8],&g_1077[2],&g_1239,&g_424[0][4],&g_726,&g_106,&g_1077[2]},{&g_726,&g_1077[8],&g_1077[3],(void*)0,&g_1239,(void*)0,&g_424[0][4],&g_726},{&g_1077[3],&g_1239,&g_1239,&g_726,&g_1077[9],&g_424[3][6],&g_1239,(void*)0}}};
                    int16_t **l_1835 = &l_1836[6][0][3];
                    int16_t ***l_1834 = &l_1835;
                    int16_t ****l_1833 = &l_1834;
                    uint64_t l_1837[8] = {18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL};
                    int32_t l_1838 = (-1L);
                    int64_t *l_1839[6];
                    int32_t l_1869 = 0x9022DC67L;
                    int32_t l_1876 = 0L;
                    int i, j, k;
                    for (i = 0; i < 6; i++)
                        l_1839[i] = &l_1722;
                    (*l_1703) = (safe_mod_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s((l_1826 >= (safe_div_func_int32_t_s_s((((safe_div_func_int64_t_s_s(((void*)0 != l_1833), p_27)) ^ (((l_1840[3][1][4] &= (l_1731 = (((&g_1775 != &g_1775) == (l_1838 = (p_27 && (((((l_1837[0] < (*g_53)) < 0x6BL) > l_1738[7]) ^ 4294967289UL) ^ (-10L))))) | g_1584[0]))) ^ 0UL) <= l_1713)) , (-9L)), (*l_1703)))), g_1332)) || (*p_30)), p_27)) == p_27), 0x2A3E22493583918DLL));
                    (*l_1703) = ((safe_mod_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((((+(((void*)0 == l_1846) <= (safe_mul_func_int8_t_s_s((((((safe_div_func_uint64_t_u_u(((&g_1775 != (l_1851 = l_1851)) > (l_1731 |= ((p_27 | ((safe_mod_func_int32_t_s_s((l_1838 = (safe_lshift_func_int8_t_s_s(((+p_27) != (safe_div_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s((safe_mul_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s((((*l_1710) ^= (safe_mod_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s(((-2L) > (*p_28)), (*p_30))), (*g_125)))) > p_27), l_1837[0])) <= l_1837[7]), p_27)), 0xC3L)) == p_27), p_27))), (*p_29)))), l_1837[2])) | 0xAC42L)) , p_27))), p_27)) < l_1709) || l_1837[0]) | 0x3BABCCF8L) , (*p_30)), 246UL)))) , p_27) , 6L), p_27)), (-1L))) , p_27);
                    if (p_27)
                    { /* block id: 809 */
                        int8_t l_1873 = 0x91L;
                        int32_t l_1874 = (-10L);
                        int32_t l_1875 = 5L;
                        --l_1870;
                        --l_1877;
                    }
                    else
                    { /* block id: 812 */
                        int64_t l_1880 = 0x906641F72FF2060ALL;
                        if (l_1731)
                            break;
                        return l_1880;
                    }
                    if (l_1713)
                        continue;
                }
                if (p_27)
                { /* block id: 818 */
                    int64_t *l_1885 = &l_1840[0][0][6];
                    int32_t l_1898 = 0xF62B0A8EL;
                    int32_t l_1901 = 0x316C72EBL;
                    int16_t *l_1902 = (void*)0;
                    int16_t *l_1903 = &g_424[2][4];
                    uint16_t l_1904 = 0xE9EDL;
                    uint16_t *l_1912 = &g_1342[4];
                    int i, j, k;
                    if ((((l_1713 = (((((*l_1903) = ((safe_rshift_func_uint8_t_u_u(0xA1L, (!(l_1901 = (p_27 || ((((l_1732[1][3][1] &= ((!((*l_1885) = 0x41ED0D9E7060F915LL)) , ((**g_752) > (((safe_mul_func_int8_t_s_s(((p_27 < p_27) <= ((safe_lshift_func_uint16_t_u_s(65533UL, p_27)) ^ (safe_sub_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(((safe_div_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_s((((p_27 || p_27) , p_27) | p_27), 9)) != 0x91L) && (*l_1703)), p_27)) != (*g_53)), l_1709)), l_1898)))), 0x63L)) & (-6L)) <= l_1898)))) , (void*)0) == l_1899) , p_27)))))) , (*l_1741))) > 0x9D23L) >= 6UL) , 0x46B0CFBFB3E966FCLL)) != l_1898) & p_27))
                    { /* block id: 824 */
                        uint16_t *l_1913 = &g_61;
                        int16_t *l_1914 = &g_1077[8];
                        if (p_27)
                            break;
                        l_1904++;
                        (*l_1703) |= (safe_sub_func_int16_t_s_s(((*l_1914) ^= ((*l_1903) = (((*p_26) = ((void*)0 == &g_292[2][0][1])) == ((l_1912 = l_1911) == l_1913)))), (255UL < g_673.f1)));
                        if (p_27)
                            break;
                    }
                    else
                    { /* block id: 833 */
                        union U2 **l_1915[10][5] = {{&g_1347[2],&g_1347[2],(void*)0,(void*)0,&g_1347[2]},{&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2]},{&g_1347[2],(void*)0,(void*)0,&g_1347[2],&g_1347[2]},{&g_1347[0],&g_1347[2],&g_1347[0],&g_1347[2],&g_1347[0]},{&g_1347[2],&g_1347[2],&g_1347[2],(void*)0,&g_1347[2]},{&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2]},{&g_1347[2],(void*)0,&g_1347[2],&g_1347[2],&g_1347[2]},{&g_1347[0],&g_1347[2],&g_1347[0],&g_1347[2],&g_1347[0]},{&g_1347[2],&g_1347[2],(void*)0,(void*)0,&g_1347[2]},{&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2],&g_1347[2]}};
                        union U2 *l_1916 = &g_1917;
                        int i, j;
                        l_1920 = (g_1918 = (g_1347[2] = (l_1916 = (void*)0)));
                    }
                    (*l_1741) &= ((void*)0 != l_1920);
                }
                else
                { /* block id: 840 */
                    int32_t l_1952 = 0L;
                    for (g_61 = 0; (g_61 <= 0); g_61 += 1)
                    { /* block id: 843 */
                        int32_t *l_1922 = &g_52;
                        l_1922 = &l_1709;
                        (**g_1201) = l_1923[1];
                        (*l_1741) |= (safe_rshift_func_int16_t_s_u(((safe_mod_func_int8_t_s_s((((-2L) == p_27) & 65530UL), (safe_rshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_s((**g_465), 6)) > (((safe_sub_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u(1UL, 3L)), p_27)) ^ ((*g_125) , (safe_div_func_uint32_t_u_u((*l_1922), p_27)))) , (**g_752))), 4)))) && (*p_28)), 10));
                        if (g_1939)
                            continue;
                    }
                    (*l_1741) |= ((safe_add_func_int8_t_s_s(((void*)0 == (*g_1775)), ((g_1615[4][2] = p_27) & (~(+(&g_691 != l_1944[2])))))) | ((safe_lshift_func_int16_t_s_s((~0xD6L), p_27)) && (safe_add_func_int32_t_s_s((-3L), (((safe_sub_func_uint16_t_u_u(((*l_1911) = (((*g_466) = 0UL) || p_27)), p_27)) < p_27) ^ p_27)))));
                    l_1952 ^= ((p_27 & (*l_1741)) ^ p_27);
                    if (p_27)
                        break;
                }
            }
        }
    }
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_752 g_466 g_9 g_232.f1 g_676.f1 g_1436
 * writes: g_61 g_9 g_1584 g_218 g_132
 */
static int8_t * func_33(int32_t  p_34, int64_t  p_35, uint8_t  p_36, int8_t * p_37, uint32_t  p_38)
{ /* block id: 723 */
    uint64_t l_1678 = 18446744073709551615UL;
    int32_t *l_1679[3];
    uint8_t l_1680 = 0x08L;
    uint16_t ***l_1694 = &g_465;
    uint16_t ****l_1693 = &l_1694;
    int32_t l_1695 = 0xF549AFBBL;
    uint16_t l_1696 = 1UL;
    int8_t l_1697 = 2L;
    int i;
    for (i = 0; i < 3; i++)
        l_1679[i] = &g_401;
    l_1695 |= (((l_1678 ^ ((l_1680 = l_1678) >= ((((**g_752) = p_35) <= (safe_sub_func_int8_t_s_s(((safe_mod_func_int8_t_s_s((p_35 , (safe_rshift_func_uint16_t_u_u(p_38, 6))), (safe_mod_func_int8_t_s_s(((*p_37) = (g_9 || (safe_add_func_int32_t_s_s(p_38, ((((((-9L) || ((safe_mul_func_uint8_t_u_u(((((void*)0 != l_1693) != 1UL) ^ p_34), 9L)) < p_35)) <= g_232.f1) ^ p_34) , g_676[0].f1) , p_35))))), g_1436)))) | p_38), p_38))) , 1UL))) & 0UL) , (-1L));
    l_1697 ^= (l_1696 = 0L);
    return p_37;
}


/* ------------------------------------------ */
/* 
 * reads : g_61 g_409 g_52 g_1021 g_106 g_631 g_632 g_1088 g_54 g_1201 g_1202 g_1203 g_466 g_9 g_254 g_752
 * writes: g_61 g_409 g_424 g_550 g_52 g_106 g_632 g_465 g_54 g_805
 */
static int64_t  func_42(uint8_t  p_43, uint32_t * p_44, int8_t * p_45, int8_t  p_46)
{ /* block id: 8 */
    int64_t l_58 = (-1L);
    int16_t *l_1079[1];
    int16_t **l_1078 = &l_1079[0];
    union U0 l_1107 = {-1L};
    union U1 **l_1119 = &g_262;
    uint16_t ***l_1176[10] = {&g_465,&g_465,&g_465,&g_465,&g_465,&g_465,&g_465,&g_465,&g_465,&g_465};
    uint16_t l_1180 = 1UL;
    const union U1 *l_1199 = &g_1200;
    const union U1 **l_1198 = &l_1199;
    const union U1 ***l_1197 = &l_1198;
    int32_t *l_1238 = (void*)0;
    int8_t * const l_1269 = &g_322;
    int8_t * const *l_1268 = &l_1269;
    uint32_t l_1295 = 18446744073709551613UL;
    uint64_t **l_1326[9] = {&g_665,&g_665,&g_665,&g_665,&g_665,&g_665,&g_665,&g_665,&g_665};
    uint64_t ***l_1325 = &l_1326[1];
    uint64_t l_1333[3];
    int32_t l_1338 = 0x3E9D74BFL;
    int32_t l_1340 = 1L;
    int32_t l_1341 = 0x0CEDA082L;
    int32_t l_1394 = 0L;
    union U0 **l_1499 = (void*)0;
    int16_t l_1518 = (-5L);
    int32_t l_1520 = 0x731446F6L;
    int32_t l_1521 = 0xFFB1BA91L;
    int32_t l_1522 = 0x999598A5L;
    uint32_t l_1523[9] = {5UL,5UL,0xBFCE0E7BL,5UL,5UL,0xBFCE0E7BL,5UL,5UL,0xBFCE0E7BL};
    union U2 *l_1530[9];
    int32_t l_1572[2];
    uint64_t l_1665 = 18446744073709551612UL;
    const int32_t **l_1673 = &g_805[6];
    int32_t l_1674 = 0x42D405ADL;
    uint64_t l_1675[9][9] = {{0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL},{0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL},{0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL},{0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL},{0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL},{0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL},{0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL},{0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL,0UL,0x17D78303C6DFBB96LL},{0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL,0x055C50CC5709FDAFLL}};
    int32_t *l_1676 = &l_1338;
    int32_t *l_1677 = &l_1338;
    int i, j;
    for (i = 0; i < 1; i++)
        l_1079[i] = &g_424[3][3];
    for (i = 0; i < 3; i++)
        l_1333[i] = 1UL;
    for (i = 0; i < 9; i++)
        l_1530[i] = (void*)0;
    for (i = 0; i < 2; i++)
        l_1572[i] = 0xF8DD71D0L;
    for (p_43 = 0; (p_43 < 57); p_43 = safe_add_func_uint64_t_u_u(p_43, 8))
    { /* block id: 11 */
        int32_t *l_57 = &g_52;
        int32_t *l_59 = (void*)0;
        union U0 l_82[5] = {{-9L},{-9L},{-9L},{-9L},{-9L}};
        uint64_t **l_1102[2];
        uint64_t ** const *l_1101 = &l_1102[0];
        const uint8_t l_1108 = 0x27L;
        const union U0 *l_1175 = &l_1107;
        const union U0 **l_1174 = &l_1175;
        int16_t ***l_1314[1][2][6] = {{{&l_1078,&l_1078,&l_1078,&l_1078,&l_1078,&l_1078},{&l_1078,&l_1078,&l_1078,&l_1078,&l_1078,&l_1078}}};
        union U2 *l_1345 = (void*)0;
        uint16_t *l_1364 = &g_550;
        union U1 *l_1367 = (void*)0;
        int32_t l_1387 = 0L;
        int32_t l_1389 = 0x72E6A412L;
        int32_t l_1390 = 6L;
        int32_t l_1391[6];
        uint16_t l_1397 = 0xD39BL;
        int8_t l_1434 = 6L;
        int16_t l_1437 = 5L;
        int32_t l_1554 = 8L;
        int64_t l_1599 = 0x1A64CC5FC95B7D4BLL;
        uint16_t l_1611[1];
        uint32_t l_1612 = 1UL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1102[i] = &g_665;
        for (i = 0; i < 6; i++)
            l_1391[i] = (-1L);
        for (i = 0; i < 1; i++)
            l_1611[i] = 65535UL;
        g_61--;
        for (l_58 = (-5); (l_58 == 2); l_58++)
        { /* block id: 15 */
            int8_t l_1070 = 0xFBL;
            int32_t l_1076 = (-9L);
            int32_t **l_1086 = &l_59;
            uint64_t **l_1099 = &g_665;
            uint64_t ***l_1098 = &l_1099;
            union U1 **l_1117 = &g_262;
            union U1 **l_1120 = &g_262;
            int32_t l_1143 = 0xFEE66A65L;
            volatile union U2 **l_1240 = &g_553;
            int64_t *l_1261 = &g_154;
            uint32_t *l_1270[3][8][1] = {{{(void*)0},{(void*)0},{(void*)0},{&g_410[4]},{(void*)0},{(void*)0},{(void*)0},{&g_410[4]}},{{(void*)0},{(void*)0},{(void*)0},{&g_410[4]},{(void*)0},{(void*)0},{(void*)0},{&g_410[4]}},{{(void*)0},{(void*)0},{(void*)0},{&g_410[4]},{(void*)0},{(void*)0},{(void*)0},{&g_410[4]}}};
            uint8_t *l_1271 = &g_674.f1;
            int32_t *l_1272 = &l_1076;
            int i, j, k;
        }
        for (g_409 = (-29); (g_409 == (-17)); ++g_409)
        { /* block id: 535 */
            int64_t l_1289 = 0x52007BDFBEEAE72ALL;
            uint64_t *l_1294 = &g_202[1];
            uint64_t ***l_1328 = &l_1326[1];
            int32_t l_1335 = 0x2568E115L;
            int32_t l_1336 = 0x7F245326L;
            int32_t l_1337 = 1L;
            int32_t l_1339 = (-1L);
            uint16_t *l_1363 = (void*)0;
            uint16_t ** const **l_1376 = (void*)0;
            int32_t l_1393 = 0x14DCA337L;
            int32_t l_1395 = 1L;
            int32_t l_1396[10][6] = {{0xD456F06BL,0xDC368DF1L,0x224464CAL,0xD456F06BL,(-1L),0xD456F06BL},{0xD456F06BL,(-1L),0xD456F06BL,0x224464CAL,0xDC368DF1L,0xD456F06BL},{(-2L),0x67857A4AL,0x224464CAL,0x666E6AE9L,0xDC368DF1L,(-2L)},{0x224464CAL,(-1L),0x666E6AE9L,0x666E6AE9L,(-1L),0x224464CAL},{(-2L),0xDC368DF1L,0x666E6AE9L,0x224464CAL,0x67857A4AL,(-2L)},{0xD456F06BL,0xDC368DF1L,0x224464CAL,0xD456F06BL,(-1L),0xD456F06BL},{0xD456F06BL,(-1L),0xD456F06BL,0x224464CAL,0xDC368DF1L,0xD456F06BL},{(-2L),0x67857A4AL,0x224464CAL,0x666E6AE9L,0xDC368DF1L,(-2L)},{0x224464CAL,(-1L),0x666E6AE9L,0x666E6AE9L,(-1L),0x224464CAL},{(-2L),0xDC368DF1L,0x666E6AE9L,0x224464CAL,0x67857A4AL,(-2L)}};
            union U1 **l_1477[2];
            uint64_t l_1516 = 18446744073709551609UL;
            int32_t *l_1517[5] = {&l_1387,&l_1387,&l_1387,&l_1387,&l_1387};
            int32_t l_1519[1];
            int32_t l_1547 = (-7L);
            uint64_t l_1586 = 18446744073709551608UL;
            union U0 **l_1598 = (void*)0;
            uint32_t l_1613 = 4294967295UL;
            int i, j;
            for (i = 0; i < 2; i++)
                l_1477[i] = &g_262;
            for (i = 0; i < 1; i++)
                l_1519[i] = 1L;
        }
        for (l_1341 = 0; (l_1341 == (-18)); l_1341--)
        { /* block id: 685 */
            uint32_t l_1628 = 0x0038E100L;
            int32_t l_1638 = (-6L);
            union U1 **l_1666 = (void*)0;
            l_1638 = (l_1394 = ((*l_57) = ((safe_div_func_uint8_t_u_u((((((safe_sub_func_uint16_t_u_u(0UL, ((l_1628 , ((*l_1364) = (((((*l_57) ^ (safe_rshift_func_int8_t_s_s((p_46 && (safe_add_func_int16_t_s_s((p_43 == (safe_mul_func_uint16_t_u_u(((p_43 , ((safe_rshift_func_int16_t_s_s(((**l_1078) = l_1628), 11)) & l_1628)) >= (((+(l_1341 && 2UL)) >= p_46) && 0xCD8CL)), 0x9B53L))), p_46))), 7))) , p_43) <= 0x7CL) <= 1L))) && 0x3785L))) , (void*)0) == (void*)0) > p_43) , l_1628), g_1021[0][3][2])) != (-1L))));
            for (g_106 = 0; (g_106 <= 0); g_106 += 1)
            { /* block id: 693 */
                int64_t l_1667 = 1L;
                if ((((*g_631) != (void*)0) | p_46))
                { /* block id: 694 */
                    int i, j;
                    g_632[(g_106 + 1)][(g_106 + 6)] = (*g_631);
                }
                else
                { /* block id: 696 */
                    for (l_1599 = 0; (l_1599 <= 0); l_1599 += 1)
                    { /* block id: 699 */
                        (*l_57) |= p_46;
                        if (p_46)
                            break;
                        (*g_1088) = (*g_631);
                    }
                }
                for (l_1338 = 0; (l_1338 >= 0); l_1338 -= 1)
                { /* block id: 707 */
                    uint16_t **l_1641 = &g_466;
                    int32_t l_1664 = 1L;
                    (*l_57) = ((0x028F542CF2284B62LL || ((g_465 = &g_466) == l_1641)) <= (safe_mul_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((safe_sub_func_int64_t_s_s(0x915B5AAD926A8C79LL, (safe_lshift_func_int16_t_s_u(((((safe_mul_func_uint8_t_u_u(((((safe_sub_func_int64_t_s_s((l_1638 = (safe_lshift_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u(((**l_1641) = (((*p_44) ^= 0x72E9D431L) > (l_1664 , (((void*)0 != (**g_1201)) >= 7UL)))), l_1628)), p_46)) , p_43), l_1665))), l_1664)) ^ p_43) , l_1666) != (void*)0), 0x94L)) <= (*l_57)) >= (*l_57)) | (*l_57)), 13)))), 1)), p_43)) < 0xD7534F01FB98CB25LL) >= l_1667), 0x37L)), 0xA5ECL)));
                }
            }
        }
    }
    (*l_1676) = (((((safe_sub_func_int64_t_s_s((0x9CF9F66BL <= (((((*p_45) > ((*p_45) > (p_43 = g_254))) , &g_632[0][8]) != ((safe_div_func_int8_t_s_s((*p_45), (0x2D0B95EA671962C2LL || (+2UL)))) , (l_1673 = l_1673))) >= l_1674)), l_1675[0][1])) == 0x3EL) >= 0x848C85D4177C88C9LL) && 0x49L) != (**g_752));
    (*l_1673) = ((*g_1088) = l_1677);
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_156 g_9 g_154 g_106 g_104 g_125 g_126 g_202 g_81.f0 g_53 g_54 g_4 g_218 g_183.f1 g_207.f1 g_132 g_291 g_230.f1 g_60 g_324 g_119 g_61 g_322 g_401 g_319 g_410 g_414 g_425 g_465 g_409 g_466 g_471 g_520 g_527 g_550 g_553 g_673.f1 g_424 g_690 g_631 g_726
 * writes: g_52 g_156 g_202 g_154 g_54 g_132 g_218 g_60 g_104 g_262 g_271 g_324 g_81.f0 g_410 g_414 g_425 g_465 g_409 g_319 g_424 g_183.f1 g_550 g_61 g_401 g_292 g_207.f1 g_520 g_631 g_81.f2 g_665 g_322 g_106 g_632
 */
static uint64_t  func_66(union U0  p_67, int32_t  p_68, int64_t  p_69, int8_t  p_70)
{ /* block id: 40 */
    uint8_t *l_170 = &g_104[1];
    int32_t l_177 = 0xBA9ED696L;
    union U1 *l_231 = &g_232;
    uint32_t l_256 = 18446744073709551612UL;
    union U1 **l_261[5] = {&l_231,&l_231,&l_231,&l_231,&l_231};
    int32_t l_321 = 1L;
    const int16_t l_346 = 0xA05EL;
    int8_t l_391[1];
    uint32_t l_614[2][9][9] = {{{0xF798AB47L,18446744073709551607UL,8UL,0x429729D5L,0xB679F6ACL,18446744073709551615UL,18446744073709551607UL,0x5681E31CL,0UL},{1UL,0x29B45505L,0xD81D241AL,0x1A84A191L,0x6D51D93AL,0x4E28E051L,3UL,0x1D1FC7F7L,0x2186D135L},{0x4A752ED9L,18446744073709551607UL,0x1A84A191L,0x6C4E535DL,18446744073709551612UL,0xD218CCECL,6UL,0UL,0UL},{18446744073709551610UL,0xB679F6ACL,0x1508E36AL,0UL,0UL,18446744073709551615UL,0x55581A97L,2UL,6UL},{8UL,0UL,0x429729D5L,1UL,0x1A84A191L,0x29B45505L,18446744073709551609UL,18446744073709551610UL,18446744073709551607UL},{0UL,3UL,0x4A752ED9L,0xC4478B5DL,2UL,0x29B45505L,0x666F780BL,18446744073709551614UL,1UL},{18446744073709551614UL,1UL,18446744073709551607UL,1UL,0x147367CEL,18446744073709551615UL,0xF798AB47L,0x29B45505L,0xC8AA8C38L},{0UL,0x46DF394FL,0x07F79F79L,0xD218CCECL,18446744073709551615UL,0xD218CCECL,0x07F79F79L,0x46DF394FL,18446744073709551607UL},{1UL,18446744073709551610UL,0xA79502D2L,0x34FA7B23L,18446744073709551615UL,0xB679F6ACL,1UL,0x33DC338EL,0x57F697B7L}},{{0x666F780BL,0xA79502D2L,3UL,0UL,18446744073709551615UL,0x4E28E051L,18446744073709551615UL,0x07F79F79L,4UL},{1UL,18446744073709551615UL,1UL,0x666F780BL,0UL,5UL,0xC8AA8C38L,0xD218CCECL,0UL},{18446744073709551607UL,0UL,18446744073709551615UL,0UL,0x57F697B7L,1UL,0xA79502D2L,0xC000E094L,3UL},{0xD218CCECL,0UL,0xC000E094L,8UL,0UL,0UL,0xF798AB47L,1UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,0UL,18446744073709551614UL,0UL,0xC4478B5DL,0xB180F38FL,18446744073709551615UL,0x29B45505L},{5UL,0UL,0UL,0x29B45505L,0x57F697B7L,0x2186D135L,0x1508E36AL,18446744073709551609UL,0x33DC338EL},{0xD9003B1EL,2UL,0x429729D5L,0UL,0UL,0x429729D5L,2UL,0xD9003B1EL,0x1D1FC7F7L},{2UL,0xB679F6ACL,18446744073709551610UL,1UL,18446744073709551615UL,0UL,18446744073709551615UL,3UL,0x1A84A191L},{0x04963CD5L,0x07F79F79L,18446744073709551609UL,18446744073709551610UL,18446744073709551615UL,0xD218CCECL,0UL,18446744073709551607UL,0x1D1FC7F7L}}};
    uint32_t l_656 = 0x054A840EL;
    uint64_t *l_666 = &g_202[1];
    int32_t l_682 = 0x4B01ED71L;
    int32_t l_717 = 3L;
    int32_t l_718 = 0xEC5EFB00L;
    int32_t l_720 = 8L;
    const uint32_t *l_730 = &g_471;
    const uint32_t **l_729 = &l_730;
    union U2 *l_737 = (void*)0;
    uint32_t **l_744 = &g_53;
    uint16_t **l_757 = &g_466;
    uint8_t l_811 = 3UL;
    int32_t l_822 = 1L;
    int16_t l_825 = 0x80AFL;
    uint8_t l_835[3];
    uint16_t l_838 = 0x7CE8L;
    int16_t l_897 = (-6L);
    uint16_t l_979[5][10];
    int64_t l_985 = 0x7570568EEE69B993LL;
    uint32_t l_986 = 0UL;
    union U1 *l_1025 = &g_1026;
    uint32_t l_1049 = 1UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_391[i] = 5L;
    for (i = 0; i < 3; i++)
        l_835[i] = 0x50L;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
            l_979[i][j] = 0xCD4AL;
    }
    for (g_52 = 0; (g_52 >= 22); g_52 = safe_add_func_uint64_t_u_u(g_52, 5))
    { /* block id: 43 */
        int64_t l_164[5] = {0x136648E8C8139463LL,0x136648E8C8139463LL,0x136648E8C8139463LL,0x136648E8C8139463LL,0x136648E8C8139463LL};
        union U1 *l_181[7] = {&g_183,&g_183,&g_183,&g_183,&g_183,&g_183,&g_183};
        union U1 **l_184 = &l_181[1];
        int i;
        for (g_156 = 0; (g_156 <= 15); g_156 = safe_add_func_int8_t_s_s(g_156, 8))
        { /* block id: 46 */
            int8_t l_169 = 1L;
            uint8_t **l_171 = &l_170;
            uint32_t *l_176 = &g_54;
            int32_t *l_179 = &g_52;
            int32_t **l_178 = &l_179;
            const uint32_t l_180 = 4294967295UL;
            (*l_178) = (((((((safe_rshift_func_int16_t_s_u(l_164[2], ((safe_rshift_func_uint16_t_u_s(((safe_rshift_func_int16_t_s_s((-9L), g_9)) > (l_169 ^ (((*l_171) = l_170) == &g_104[1]))), ((safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u(((void*)0 != l_176), 0L)) < p_70), l_177)) , (-1L)))) || p_69))) , 0x66L) > g_154) & g_106) & 1UL) | 0xC86C0DB8L) , l_176);
            if (l_180)
                break;
        }
        (*l_184) = l_181[1];
    }
    if ((((safe_unary_minus_func_int32_t_s(g_104[1])) && l_177) & l_177))
    { /* block id: 53 */
        return (*g_125);
    }
    else
    { /* block id: 55 */
        int64_t l_203[9][9][2] = {{{6L,(-9L)},{0L,9L},{0x37106151272D6588LL,(-1L)},{0x121B7D6B70E42B31LL,0x37106151272D6588LL},{0xDB6E0624A242812ELL,(-1L)},{0xDB6E0624A242812ELL,0x37106151272D6588LL},{0x121B7D6B70E42B31LL,(-1L)},{0x37106151272D6588LL,9L},{0L,(-9L)}},{{6L,0xC7D868F3A24A8259LL},{0xC7D868F3A24A8259LL,0x121B7D6B70E42B31LL},{0x16F4F35B7F529ED1LL,0x121B7D6B70E42B31LL},{0xC7D868F3A24A8259LL,0xC7D868F3A24A8259LL},{6L,(-9L)},{0L,9L},{0x37106151272D6588LL,(-1L)},{0x121B7D6B70E42B31LL,0x37106151272D6588LL},{0xDB6E0624A242812ELL,(-1L)}},{{0xDB6E0624A242812ELL,0x37106151272D6588LL},{0x121B7D6B70E42B31LL,(-1L)},{0x37106151272D6588LL,9L},{0L,(-9L)},{6L,0xC7D868F3A24A8259LL},{0xC7D868F3A24A8259LL,0x121B7D6B70E42B31LL},{0x16F4F35B7F529ED1LL,0x121B7D6B70E42B31LL},{0xC7D868F3A24A8259LL,0xC7D868F3A24A8259LL},{6L,(-9L)}},{{0L,9L},{0x37106151272D6588LL,(-1L)},{0x121B7D6B70E42B31LL,0x37106151272D6588LL},{0xDB6E0624A242812ELL,(-1L)},{0xDB6E0624A242812ELL,0x37106151272D6588LL},{0x121B7D6B70E42B31LL,(-1L)},{0x37106151272D6588LL,9L},{0L,(-9L)},{6L,0xC7D868F3A24A8259LL}},{{0xC7D868F3A24A8259LL,0x121B7D6B70E42B31LL},{0x16F4F35B7F529ED1LL,0x121B7D6B70E42B31LL},{0xC7D868F3A24A8259LL,0xC7D868F3A24A8259LL},{6L,(-9L)},{0L,9L},{0x37106151272D6588LL,(-1L)},{0x121B7D6B70E42B31LL,0x37106151272D6588LL},{0xDB6E0624A242812ELL,0x37106151272D6588LL},{9L,6L}},{{0x16F4F35B7F529ED1LL,0xB7C00FEE9B74624CLL},{6L,0x121B7D6B70E42B31LL},{0xDB6E0624A242812ELL,(-1L)},{(-9L),(-1L)},{(-1L),0x16F4F35B7F529ED1LL},{0xC7D868F3A24A8259LL,0x16F4F35B7F529ED1LL},{(-1L),(-1L)},{(-9L),(-1L)},{0xDB6E0624A242812ELL,0x121B7D6B70E42B31LL}},{{6L,0xB7C00FEE9B74624CLL},{0x16F4F35B7F529ED1LL,6L},{9L,0x37106151272D6588LL},{9L,6L},{0x16F4F35B7F529ED1LL,0xB7C00FEE9B74624CLL},{6L,0x121B7D6B70E42B31LL},{0xDB6E0624A242812ELL,(-1L)},{(-9L),(-1L)},{(-1L),0x16F4F35B7F529ED1LL}},{{0xC7D868F3A24A8259LL,0x16F4F35B7F529ED1LL},{(-1L),(-1L)},{(-9L),(-1L)},{0xDB6E0624A242812ELL,0x121B7D6B70E42B31LL},{6L,0xB7C00FEE9B74624CLL},{0x16F4F35B7F529ED1LL,6L},{9L,0x37106151272D6588LL},{9L,6L},{0x16F4F35B7F529ED1LL,0xB7C00FEE9B74624CLL}},{{6L,0x121B7D6B70E42B31LL},{0xDB6E0624A242812ELL,(-1L)},{(-9L),(-1L)},{(-1L),0x16F4F35B7F529ED1LL},{0xC7D868F3A24A8259LL,0x16F4F35B7F529ED1LL},{(-1L),(-1L)},{(-9L),(-1L)},{0xDB6E0624A242812ELL,0x121B7D6B70E42B31LL},{6L,0xB7C00FEE9B74624CLL}}};
        union U1 *l_229 = &g_230;
        const int16_t *l_255 = &g_60;
        uint8_t l_263 = 0x55L;
        int32_t l_342 = (-5L);
        uint8_t l_351 = 0x65L;
        int32_t l_405 = 0xCA15E359L;
        int32_t l_407[3][1];
        int16_t l_498 = (-1L);
        uint32_t l_499 = 18446744073709551606UL;
        volatile union U2 *l_555 = &g_556;
        uint32_t *l_624 = &g_410[4];
        int32_t *l_629 = &l_405;
        int32_t **l_628 = &l_629;
        uint64_t *l_667 = (void*)0;
        union U1 *l_675 = &g_676[0];
        const union U0 l_789 = {6L};
        union U1 *** const l_859 = &g_292[2][0][1];
        int32_t l_881[2];
        uint32_t l_883 = 1UL;
        int32_t l_914 = 3L;
        const uint64_t l_930 = 18446744073709551610UL;
        uint32_t l_951 = 0xFE86E679L;
        int32_t l_1013 = 0xBDC73E68L;
        int16_t l_1014 = 0L;
        uint8_t l_1032 = 251UL;
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_407[i][j] = 0x9FFAC413L;
        }
        for (i = 0; i < 2; i++)
            l_881[i] = 0L;
        for (g_156 = 0; (g_156 < (-11)); --g_156)
        { /* block id: 58 */
            uint64_t *l_201[10] = {&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0],&g_202[0]};
            union U1 *l_206 = &g_207;
            int64_t *l_215[2];
            int32_t l_216 = 0xB7AEDB7CL;
            int8_t *l_217 = &g_218;
            int16_t *l_219 = &g_60;
            const int16_t *l_253 = &g_254;
            const int16_t **l_252 = &l_253;
            int i;
            for (i = 0; i < 2; i++)
                l_215[i] = &g_154;
            g_52 = ((((*l_219) = (~(((*l_217) = (g_132 = (safe_mod_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((safe_div_func_uint16_t_u_u(0x70BDL, (((safe_unary_minus_func_uint64_t_u(p_68)) & ((safe_add_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_unary_minus_func_int8_t_s(((g_202[2] ^= p_67.f0) >= l_203[7][6][0]))), ((safe_add_func_uint16_t_u_u((l_206 == l_206), 0xEF3BL)) , ((+g_81.f0) , (((((!(~((*g_53) &= (safe_lshift_func_int16_t_s_s((safe_div_func_int64_t_s_s((g_154 = g_52), l_216)), p_69))))) != g_4) , (*g_53)) >= p_70) >= p_69))))), 0xB0B8A3AA6587CEBALL)) > l_177)) || 0x0A445FDDC11C7F1ALL))) > 65535UL), p_70)) && l_203[5][0][0]), p_70)))) || g_9))) , g_9) > g_156);
            p_68 = (safe_mod_func_int32_t_s_s((safe_div_func_uint64_t_u_u(((+(safe_lshift_func_uint16_t_u_s((safe_mul_func_int8_t_s_s((l_229 != l_231), (safe_lshift_func_int8_t_s_s(p_67.f0, (safe_div_func_int8_t_s_s((l_177 = (l_256 &= (((*g_53) |= ((((safe_lshift_func_int16_t_s_s(((safe_div_func_int64_t_s_s(0xF97D826FC9A26349LL, (~((p_70 && (((*l_170)++) < (p_67 , (((*l_252) = ((~((safe_mod_func_int32_t_s_s((((void*)0 != &p_69) == (safe_rshift_func_int8_t_s_u(((*l_217) |= (safe_mul_func_int16_t_s_s((!0x1F154393L), l_203[7][6][0]))), 5))), l_216)) && p_68)) , &g_106)) == l_255)))) | l_216)))) & 0xFAL), 7)) || p_69) ^ 0xF8107E6F1DCE19F1LL) ^ (-1L))) , l_216))), 0x5DL)))))), g_9))) & (-1L)), l_216)), p_68));
            for (l_177 = 0; (l_177 >= (-19)); --l_177)
            { /* block id: 75 */
                union U1 ***l_259 = (void*)0;
                union U1 ***l_260[5][3];
                int i, j;
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_260[i][j] = (void*)0;
                }
                l_261[1] = &l_231;
            }
            g_262 = l_229;
        }
        if (g_202[0])
        { /* block id: 80 */
            int32_t *l_264 = (void*)0;
            int32_t l_314 = 0xDBF5C2DFL;
            int32_t l_316 = (-8L);
            int32_t l_318 = 0xF106E560L;
            int32_t l_320[9][4][2] = {{{(-1L),0x6D5FB649L},{3L,1L},{0xBDF16737L,3L},{1L,0L}},{{1L,3L},{0xBDF16737L,1L},{3L,0x6D5FB649L},{(-1L),3L}},{{0L,1L},{1L,0x34A9D08FL},{(-1L),1L},{0x34A9D08FL,1L}},{{(-1L),0x34A9D08FL},{1L,1L},{0L,3L},{(-1L),0x6D5FB649L}},{{3L,1L},{0xBDF16737L,3L},{1L,0L},{1L,3L}},{{0xBDF16737L,1L},{3L,0x6D5FB649L},{(-1L),3L},{0L,1L}},{{1L,0x34A9D08FL},{(-1L),1L},{0x34A9D08FL,1L},{(-1L),0x34A9D08FL}},{{1L,1L},{0L,3L},{(-1L),0x6D5FB649L},{3L,1L}},{{0xBDF16737L,3L},{1L,0L},{1L,3L},{0xBDF16737L,1L}}};
            int32_t l_358[5];
            int16_t l_404 = (-1L);
            uint32_t l_475 = 0xDA9DA4EFL;
            union U1 *l_672[5] = {&g_673,&g_673,&g_673,&g_673,&g_673};
            int32_t l_715 = 0xEFA69EEBL;
            int64_t l_719 = (-1L);
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_358[i] = (-1L);
            if ((g_156 = l_263))
            { /* block id: 82 */
                int64_t l_274 = (-8L);
                int32_t l_315[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_315[i] = 0xD3900B72L;
                for (p_69 = 0; (p_69 <= 1); p_69 += 1)
                { /* block id: 85 */
                    int64_t *l_268 = &l_203[7][6][0];
                    int64_t **l_267 = &l_268;
                    int64_t *l_270[4][10][6] = {{{&l_203[7][6][0],&l_203[7][6][0],(void*)0,&l_203[7][6][0],&g_154,&l_203[2][1][0]},{&g_154,&l_203[0][2][1],&l_203[5][2][1],&l_203[0][2][1],&g_154,&g_154},{&g_154,&l_203[7][6][0],&l_203[7][6][0],&l_203[7][6][0],&l_203[0][2][1],(void*)0},{&l_203[7][6][0],&l_203[7][6][0],&l_203[4][5][0],&l_203[7][6][0],&l_203[7][6][0],(void*)0},{&l_203[7][6][0],&l_203[7][6][0],&l_203[7][6][0],&g_154,&l_203[7][6][0],&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][1],&l_203[7][6][0],&g_154,(void*)0,&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][0],&l_203[0][2][1],&g_154,&l_203[7][6][0],&g_154},{&g_154,&g_154,&g_154,&l_203[6][5][1],&l_203[6][5][1],&g_154},{&g_154,&g_154,&g_154,&g_154,&l_203[7][6][0],&l_203[7][6][0]},{&l_203[0][5][1],&l_203[0][5][0],&l_203[7][6][0],&l_203[7][6][0],(void*)0,&g_154}},{{&g_154,&l_203[0][5][1],&l_203[7][6][0],&g_154,&g_154,&l_203[7][6][0]},{&g_154,&g_154,&g_154,&l_203[5][2][1],&l_203[7][6][0],&g_154},{&l_203[5][2][1],&l_203[7][6][0],&g_154,&l_203[5][2][1],&l_203[7][6][0],&g_154},{&g_154,&l_203[6][5][1],&l_203[0][2][1],&g_154,&g_154,&l_203[7][6][0]},{&g_154,&l_203[7][6][0],&l_203[7][6][0],&l_203[7][6][0],&g_154,&l_203[7][6][0]},{&l_203[0][5][1],&l_203[6][5][1],&l_203[4][6][0],&g_154,&l_203[7][6][0],&l_203[0][2][1]},{&g_154,&l_203[7][6][0],&l_203[7][6][0],&l_203[6][5][1],&l_203[7][6][0],&l_203[0][2][1]},{&g_154,&g_154,&l_203[4][6][0],&g_154,&g_154,&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][1],&l_203[7][6][0],&g_154,(void*)0,&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][0],&l_203[0][2][1],&g_154,&l_203[7][6][0],&g_154}},{{&g_154,&g_154,&g_154,&l_203[6][5][1],&l_203[6][5][1],&g_154},{&g_154,&g_154,&g_154,&g_154,&l_203[7][6][0],&l_203[7][6][0]},{&l_203[0][5][1],&l_203[0][5][0],&l_203[7][6][0],&l_203[7][6][0],(void*)0,&g_154},{&g_154,&l_203[0][5][1],&l_203[7][6][0],&g_154,&g_154,&l_203[7][6][0]},{&g_154,&g_154,&g_154,&l_203[5][2][1],&l_203[7][6][0],&g_154},{&l_203[5][2][1],&l_203[7][6][0],&g_154,&l_203[5][2][1],&l_203[7][6][0],&g_154},{&g_154,&l_203[6][5][1],&l_203[0][2][1],&g_154,&g_154,&l_203[7][6][0]},{&g_154,&l_203[7][6][0],&l_203[7][6][0],&l_203[7][6][0],&g_154,&l_203[7][6][0]},{&l_203[0][5][1],&l_203[6][5][1],&l_203[4][6][0],&g_154,&l_203[7][6][0],&l_203[0][2][1]},{&g_154,&l_203[7][6][0],&l_203[7][6][0],&l_203[6][5][1],&l_203[7][6][0],&l_203[0][2][1]}},{{&g_154,&g_154,&l_203[4][6][0],&g_154,&g_154,&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][1],&l_203[7][6][0],&g_154,(void*)0,&l_203[7][6][0]},{&l_203[7][6][0],&l_203[0][5][0],&l_203[0][2][1],&g_154,&l_203[7][6][0],&g_154},{&g_154,&g_154,&g_154,&l_203[6][5][1],&l_203[6][5][1],&g_154},{&g_154,&g_154,&g_154,&g_154,&l_203[7][6][0],&l_203[7][6][0]},{&l_203[0][5][1],&l_203[0][5][0],&l_203[7][6][0],&l_203[7][6][0],(void*)0,&g_154},{&g_154,&l_203[0][5][1],&l_203[7][6][0],&l_203[7][6][0],&l_203[2][1][0],&l_203[7][6][0]},{&l_203[4][5][0],&l_203[7][6][0],&l_203[0][5][1],(void*)0,(void*)0,&l_203[5][2][1]},{(void*)0,(void*)0,&l_203[5][2][1],(void*)0,&g_154,&l_203[0][5][0]},{&l_203[4][5][0],&l_203[6][0][1],&l_203[7][6][0],&l_203[7][6][0],&g_154,&g_154}}};
                    int64_t **l_269[5][1][7] = {{{&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0]}},{{&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0]}},{{&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0]}},{{&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0]}},{{&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0],&l_270[2][3][0]}}};
                    uint8_t l_277 = 0xEDL;
                    int i, j, k;
                    p_68 ^= ((safe_sub_func_uint8_t_u_u(p_70, (p_67 , g_183.f1))) , (((((g_271[6] = ((*l_267) = &g_154)) != &p_69) & (safe_mul_func_int16_t_s_s(0x7145L, (l_274 <= (((safe_mul_func_uint8_t_u_u(1UL, l_274)) >= g_207.f1) , l_203[7][6][0]))))) , l_277) && 0x4028L));
                    if (l_203[7][6][0])
                        continue;
                    return p_67.f0;
                }
lbl_327:
                l_264 = &l_177;
                for (g_154 = 1; (g_154 >= 0); g_154 -= 1)
                { /* block id: 95 */
                    union U1 ***l_281[5][3] = {{&l_261[1],&l_261[1],&l_261[1]},{&l_261[2],&l_261[1],&l_261[2]},{&l_261[1],&l_261[1],&l_261[1]},{&l_261[2],&l_261[1],&l_261[2]},{&l_261[1],&l_261[1],&l_261[1]}};
                    int32_t l_282 = 1L;
                    int32_t l_317 = (-1L);
                    int32_t l_323 = 6L;
                    int i, j;
                    for (l_263 = 0; (l_263 <= 8); l_263 += 1)
                    { /* block id: 98 */
                        if (p_70)
                            break;
                        if (p_67.f0)
                            break;
                    }
                    l_282 = ((*l_264) = (safe_sub_func_uint8_t_u_u(0x3AL, (0xF4L ^ (~((l_281[1][0] != l_281[1][1]) ^ ((void*)0 == &l_177)))))));
                    for (g_132 = 0; (g_132 <= 8); g_132 += 1)
                    { /* block id: 106 */
                        int32_t **l_293 = &l_264;
                        int32_t *l_310 = &l_282;
                        int i;
                        (*l_264) |= (safe_mul_func_int8_t_s_s((+g_104[(g_154 + 1)]), ((g_104[(g_154 + 1)] > ((void*)0 == &g_154)) ^ ((0xAEFF7825D7338BB7LL | ((((1L < ((l_274 ^ (((safe_mul_func_uint16_t_u_u(g_132, (safe_rshift_func_int16_t_s_s((!(g_291 != &g_292[2][0][1])), 15)))) > p_70) && p_70)) && g_154)) < l_282) , g_230.f1) , 0x448E640C1D5FEB8ALL)) | 0xBBF4FE604490758DLL))));
                        (*l_293) = &l_177;
                        (*l_310) &= (safe_mod_func_uint8_t_u_u((safe_div_func_int64_t_s_s(l_274, (p_67.f0 , (-5L)))), (~(1UL == (safe_mod_func_uint64_t_u_u((p_70 <= p_69), ((((((safe_add_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((safe_sub_func_uint8_t_u_u(p_67.f0, (0x0C85L & (safe_mod_func_int8_t_s_s((!p_67.f0), 0x9AL))))), l_274)), 0xB362DC11L)) == l_177) > g_60) , (-1L)) , p_68) & p_68)))))));
                        (*l_264) ^= 0x531CCCDEL;
                    }
                    for (g_60 = 8; (g_60 >= 0); g_60 -= 1)
                    { /* block id: 114 */
                        int32_t *l_311 = &g_156;
                        int32_t *l_312 = &g_52;
                        int32_t *l_313[5] = {&l_282,&l_282,&l_282,&l_282,&l_282};
                        int i;
                        g_324--;
                        if (p_69)
                            continue;
                        if (p_70)
                            goto lbl_327;
                    }
                }
            }
            else
            { /* block id: 120 */
                int64_t *l_334[3];
                int32_t l_341 = 0xD8614077L;
                int32_t *l_343 = &l_318;
                int i;
                for (i = 0; i < 3; i++)
                    l_334[i] = &l_203[8][7][0];
                (*l_343) |= ((safe_rshift_func_int8_t_s_s((0x3D4A7468774B25CBLL != ((p_67.f0 && (((safe_rshift_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(l_177, (((l_321 = p_69) < p_70) | (safe_rshift_func_int8_t_s_s((&g_154 == &g_154), ((l_342 = (safe_add_func_int8_t_s_s((((((safe_mul_func_int16_t_s_s(((l_341 , l_177) < p_69), p_69)) <= g_156) | l_341) == g_60) > 0x0DABL), p_70))) , p_68)))))), p_69)) != g_9) | 6L)) & l_263)), 7)) || p_68);
            }
            if (((safe_add_func_uint32_t_u_u(l_321, 1UL)) != l_346))
            { /* block id: 125 */
                int64_t l_372 = 0xBDDA58D9422DCE98LL;
                int32_t l_406[10][10][2] = {{{0x23DF65D3L,0xFE2B9667L},{(-6L),(-1L)},{1L,0x16215E4DL},{(-1L),0xC116A2CAL},{0L,0xBE56A4DAL},{(-1L),0L},{(-8L),0L},{4L,1L},{0x6BCCEDB5L,0xAE1C6840L},{0x770FD190L,0x7E3683ACL}},{{7L,(-2L)},{0L,(-1L)},{0x1015EE2AL,0xE60C62E7L},{0xAD62A1C1L,1L},{0x0BF9AA45L,(-1L)},{4L,0x770FD190L},{0xB66DB365L,5L},{0xE60C62E7L,7L},{1L,0x56C43B32L},{0x16215E4DL,(-1L)}},{{0x5C62689EL,0xAF16F8C1L},{0x7E3683ACL,0x0BF9AA45L},{0xC873EBF1L,0L},{(-3L),(-1L)},{0x27B2C724L,(-1L)},{(-3L),0L},{0xC873EBF1L,0x0BF9AA45L},{0x7E3683ACL,0xAF16F8C1L},{0x5C62689EL,(-1L)},{0x16215E4DL,0x56C43B32L}},{{1L,7L},{0xE60C62E7L,5L},{0xB66DB365L,0x770FD190L},{4L,(-1L)},{0x0BF9AA45L,1L},{0xAD62A1C1L,0xE60C62E7L},{0x1015EE2AL,(-1L)},{0L,(-2L)},{7L,0x7E3683ACL},{0x770FD190L,0xAE1C6840L}},{{0x6BCCEDB5L,1L},{4L,0L},{(-8L),0L},{(-1L),0xBE56A4DAL},{0L,0xC116A2CAL},{(-1L),0x16215E4DL},{1L,(-1L)},{(-6L),0xFE2B9667L},{0x23DF65D3L,0x23DF65D3L},{(-1L),1L}},{{1L,(-8L)},{0xF34E97EDL,0x34BD164CL},{0x7CF6A49EL,0xF34E97EDL},{5L,0x6BCCEDB5L},{5L,0xF34E97EDL},{0x7CF6A49EL,0x34BD164CL},{0xF34E97EDL,(-8L)},{1L,0xF5CD88ABL},{0L,0xAF16F8C1L},{0xAF16F8C1L,1L}},{{0x27B2C724L,1L},{(-1L),1L},{(-10L),0xF66ED171L},{0x770FD190L,0xC873EBF1L},{0x7E3683ACL,0x16215E4DL},{0L,0x770FD190L},{(-1L),(-1L)},{4L,0x0BF9AA45L},{0xACF184F6L,0x6CF536BAL},{0xF34E97EDL,0xC116A2CAL}},{{4L,0x5C62689EL},{(-1L),0L},{0xB66DB365L,(-8L)},{(-3L),0x7E3683ACL},{0x34BD164CL,0xACF184F6L},{(-1L),0x40FAEA75L},{0L,0x6BCCEDB5L},{0xF5CD88ABL,(-3L)},{1L,(-6L)},{7L,0xE60C62E7L}},{{0x6CF536BAL,(-3L)},{0x56C43B32L,0xAE1C6840L},{0xAD62A1C1L,0L},{0xBE56A4DAL,0L},{0xAD62A1C1L,0xAE1C6840L},{0x56C43B32L,(-3L)},{0x6CF536BAL,0xE60C62E7L},{7L,(-6L)},{1L,(-3L)},{0xF5CD88ABL,0x6BCCEDB5L}},{{0L,0x40FAEA75L},{(-1L),0xACF184F6L},{0x34BD164CL,0x7E3683ACL},{(-3L),(-8L)},{0xB66DB365L,0L},{(-1L),0x5C62689EL},{4L,0xC116A2CAL},{0xF34E97EDL,0x6CF536BAL},{0xACF184F6L,0x0BF9AA45L},{4L,(-1L)}}};
                int16_t l_462 = 1L;
                int32_t l_469[9] = {8L,8L,8L,8L,8L,8L,8L,8L,8L};
                int i, j, k;
lbl_487:
                for (g_52 = 0; (g_52 >= 0); g_52 -= 1)
                { /* block id: 128 */
                    uint16_t *l_367 = &g_81.f2;
                    uint16_t *l_368 = &g_81.f2;
                    int32_t l_369 = 5L;
                    int16_t *l_370[10] = {&g_60,&g_106,&g_60,&g_106,&g_60,&g_106,&g_60,&g_106,&g_60,&g_106};
                    int32_t l_371[10] = {0x806E921FL,0x8AFD4656L,0x8AFD4656L,0x806E921FL,0x8AFD4656L,0x8AFD4656L,0x806E921FL,0x8AFD4656L,0x8AFD4656L,0x806E921FL};
                    int32_t *l_373 = (void*)0;
                    int32_t *l_374 = &l_316;
                    uint16_t **l_400 = &l_368;
                    int8_t l_422 = 0x8BL;
                    int i;
                    (*l_374) ^= (((((p_67.f0 = ((((((((safe_lshift_func_int16_t_s_u((safe_sub_func_int8_t_s_s((func_71(l_351) , (((4294967291UL && (safe_div_func_int8_t_s_s(p_67.f0, (((safe_rshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s(l_358[0], 0x83L)), 11)) ^ (safe_div_func_int64_t_s_s((safe_mod_func_uint16_t_u_u(0x2B4CL, (safe_mul_func_int16_t_s_s((l_177 = ((l_369 ^= ((safe_rshift_func_int16_t_s_s(l_256, 12)) ^ 0x09E22738L)) <= 0xEE10L)), g_218)))), 0x9A1EE3F2ED9BBE03LL))) ^ l_371[9])))) && 3UL) && l_346)), g_104[1])), l_372)) ^ g_4) , &g_202[0]) != (void*)0) & p_68) ^ l_371[4]) == (-1L)) | 0xB14A2062L)) || p_70) ^ (*g_53)) == 0x2210L) > g_61);
                    if (((((g_60 , (((((*g_53) = l_203[7][6][0]) && ((safe_div_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((((safe_mod_func_int8_t_s_s(((((safe_rshift_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_s((((safe_div_func_uint64_t_u_u(l_203[1][7][0], (safe_sub_func_uint32_t_u_u(((*g_53)++), l_391[0])))) , (safe_rshift_func_uint16_t_u_s(5UL, (safe_rshift_func_uint8_t_u_s(((((safe_mod_func_uint32_t_u_u((*g_53), (g_81.f0 = 0x3094E3F1L))) & (safe_mod_func_uint8_t_u_u((((*l_400) = &g_61) == &g_61), (-10L)))) & l_351) || 1UL), g_322))))) , g_218), 1)) ^ (-1L)), p_70)) && 0L) < g_401) | 7UL), g_218)) < 0x6477L) == (*l_374)), 0x3A11697D797E4126LL)), l_391[0])) > l_372)) && p_70) == l_263)) & g_319) , 0xBED272BF7BF8C57BLL) & (*g_125)))
                    { /* block id: 137 */
                        int32_t *l_402 = &l_321;
                        int32_t *l_403[10] = {&l_318,&l_318,&g_52,&l_321,&g_52,&l_318,&l_318,&g_52,&l_321,&g_52};
                        int16_t l_413 = 0x49EEL;
                        int32_t **l_417 = &l_403[8];
                        int i;
                        ++g_410[3];
                        ++g_414;
                        (*l_417) = &g_401;
                        if (p_68)
                            continue;
                    }
                    else
                    { /* block id: 142 */
                        int32_t *l_418 = &l_320[6][3][1];
                        int32_t *l_419 = &g_156;
                        int32_t *l_420 = &g_156;
                        int32_t *l_421 = &l_316;
                        int32_t *l_423[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        uint16_t ***l_467 = (void*)0;
                        uint16_t ***l_468 = &g_465;
                        uint64_t *l_470 = &g_202[0];
                        int i;
                        g_425++;
                        (*l_418) = ((-10L) & (((((safe_div_func_uint64_t_u_u(((*l_470) |= (((safe_rshift_func_uint16_t_u_u((((+((safe_div_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u((((p_70 < (safe_mul_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((((*g_53) = (safe_sub_func_uint32_t_u_u((((safe_mod_func_uint32_t_u_u((((p_68 <= ((l_342 = ((((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_s((l_406[0][8][1] != ((((safe_lshift_func_int8_t_s_u((3L > ((safe_div_func_int64_t_s_s(l_407[1][0], (((safe_mul_func_uint16_t_u_u((!(l_462 == (safe_mod_func_int16_t_s_s((l_469[0] = (((*l_468) = g_465) == (void*)0)), 65528UL)))), (*l_374))) || (-1L)) | p_69))) >= g_409)), 6)) | (*g_53)) < (*l_374)) & 7UL)), 2)), p_68)), 6)) > (*g_125)) ^ 250UL) && 0UL)) > g_230.f1)) == p_69) <= g_104[1]), (*g_53))) , p_69) | l_404), (-1L)))) ^ (*l_374)) >= 0x4BL), p_69)), p_69)), 0x8505L))) < 0L) > p_67.f0), p_68)) | 0x035DL), p_69)) | (*g_125))) >= p_67.f0) != (*g_466)), 8)) , 0x8844L) && p_70)), g_471)) != l_406[4][6][1]) || l_391[0]) >= g_154) != g_218));
                        l_406[6][0][0] |= (g_81.f0 = g_104[1]);
                    }
                    return (*g_125);
                }
                for (l_405 = 0; (l_405 <= 26); l_405 = safe_add_func_uint16_t_u_u(l_405, 4))
                { /* block id: 157 */
                    int32_t *l_474[3];
                    int32_t **l_478 = &l_474[1];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_474[i] = &l_406[6][9][0];
                    --l_475;
                    (*l_478) = &p_68;
                }
                for (l_342 = 8; (l_342 > 24); l_342++)
                { /* block id: 163 */
                    int32_t *l_488 = &l_469[0];
                    int32_t *l_489 = &g_52;
                    int32_t *l_490 = &l_405;
                    int32_t *l_491 = &l_407[1][0];
                    int32_t *l_492 = (void*)0;
                    int32_t *l_493 = &l_320[1][1][1];
                    int32_t *l_494 = &l_469[0];
                    int32_t *l_495 = &l_314;
                    int32_t *l_496 = (void*)0;
                    int32_t *l_497[3][9] = {{&l_320[1][1][0],&l_406[6][9][0],&l_406[9][0][0],&l_406[6][9][0],&l_320[1][1][0],&l_407[1][0],&l_469[1],&l_314,(void*)0},{&l_469[1],&l_407[1][0],&l_320[1][1][0],&l_406[6][9][0],&l_406[9][0][0],&l_406[6][9][0],&l_320[1][1][0],&l_407[1][0],&l_469[1]},{&g_401,(void*)0,&g_401,&l_320[1][1][0],&l_314,&l_407[1][0],(void*)0,&l_407[1][0],&l_314}};
                    int i, j;
                    for (l_372 = 0; (l_372 != 11); l_372++)
                    { /* block id: 166 */
                        union U2 *l_483 = &g_484;
                        union U2 **l_485 = (void*)0;
                        union U2 **l_486 = &l_483;
                        (*l_486) = l_483;
                        if (g_9)
                            goto lbl_487;
                    }
                    l_499--;
                }
            }
            else
            { /* block id: 172 */
                uint8_t **l_529 = &l_170;
                int32_t l_533[2][1];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_533[i][j] = 1L;
                }
                for (g_409 = (-11); (g_409 != 12); g_409 = safe_add_func_uint64_t_u_u(g_409, 7))
                { /* block id: 175 */
                    int32_t l_517 = (-6L);
                    int8_t *l_530 = &g_319;
                    int16_t *l_531 = &l_498;
                    int16_t *l_532 = &g_424[1][8];
                    int32_t *l_534 = &l_320[4][1][1];
                    (*l_534) |= (((safe_sub_func_uint32_t_u_u(((*g_53) = (safe_sub_func_int16_t_s_s(p_69, (safe_mul_func_int16_t_s_s(((*l_532) = ((*l_531) = (g_202[0] , (~(safe_mod_func_int32_t_s_s((safe_mod_func_uint16_t_u_u((p_69 < ((((safe_div_func_int32_t_s_s(l_517, (((*l_530) |= (0x40F435EA2B00364CLL < (((safe_mul_func_uint8_t_u_u(p_68, g_520)) , (safe_lshift_func_int16_t_s_u((safe_unary_minus_func_int64_t_s((!(safe_rshift_func_int16_t_s_s(((g_409 , g_527) == l_529), g_126))))), 6))) <= 0xB88012F8L))) , (*g_53)))) , (*g_53)) >= (-2L)) & p_68)), 0x8871L)), (*g_53))))))), 0x1526L))))), 9L)) & l_533[0][0]) ^ p_69);
                }
            }
            if ((l_321 = l_407[0][0]))
            { /* block id: 184 */
                int32_t l_545[3];
                int32_t l_546 = 0x04E420CFL;
                int32_t l_549 = 0L;
                int i;
                for (i = 0; i < 3; i++)
                    l_545[i] = (-5L);
                for (l_314 = 0; (l_314 >= (-14)); l_314 = safe_sub_func_uint32_t_u_u(l_314, 1))
                { /* block id: 187 */
                    int32_t l_547 = 0x61E74573L;
                    int32_t l_548 = 0xAABB352DL;
                    for (l_498 = 0; (l_498 == (-8)); l_498 = safe_sub_func_int8_t_s_s(l_498, 4))
                    { /* block id: 190 */
                        if (l_321)
                            break;
                        return p_68;
                    }
                    for (g_183.f1 = 6; (g_183.f1 >= 12); g_183.f1 = safe_add_func_int8_t_s_s(g_183.f1, 5))
                    { /* block id: 196 */
                        int32_t *l_541 = &l_177;
                        int32_t *l_542 = &l_407[0][0];
                        int32_t *l_543 = (void*)0;
                        int32_t *l_544[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_544[i] = &l_405;
                        g_550--;
                        p_68 &= p_70;
                        l_555 = g_553;
                    }
                }
                if ((safe_sub_func_uint32_t_u_u(((*g_53) = l_346), (safe_mul_func_uint16_t_u_u(9UL, 0x3E20L)))))
                { /* block id: 203 */
                    int32_t *l_561[8][7] = {{&l_314,&g_156,&l_314,&l_314,&g_156,&l_314,&l_314},{&g_156,&g_156,&g_52,&g_156,&g_156,&g_52,&g_156},{&g_156,&l_314,&l_314,&g_156,&l_314,&l_314,&g_156},{&l_314,&g_156,&l_314,&l_314,&g_156,&l_314,&l_314},{&g_156,&g_156,&g_52,&g_156,&g_156,&g_52,&g_156},{&l_314,&g_52,&g_52,&l_314,&g_52,&g_52,&l_314},{&g_52,&l_314,&g_52,&g_52,&l_314,&g_52,&g_52},{&l_314,&l_314,&g_156,&l_314,&l_314,&g_156,&l_314}};
                    union U0 *l_563 = &g_81;
                    union U0 **l_562 = &l_563;
                    int i, j;
                    l_561[3][4] = &p_68;
                    (*l_562) = (void*)0;
                    return (*g_125);
                }
                else
                { /* block id: 207 */
                    int32_t l_570 = (-5L);
                    int32_t l_576 = 6L;
                    for (g_324 = 0; (g_324 <= 1); g_324 += 1)
                    { /* block id: 210 */
                        if (p_69)
                            break;
                        if (p_70)
                            continue;
                        if (g_104[0])
                            continue;
                        return (*g_125);
                    }
                    for (l_316 = 6; (l_316 >= 4); --l_316)
                    { /* block id: 218 */
                        int8_t *l_575[1][6][1];
                        int32_t *l_581 = &l_405;
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 6; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_575[i][j][k] = &g_218;
                            }
                        }
                        g_401 = (((**g_465) ^= (safe_lshift_func_uint8_t_u_u((safe_div_func_int16_t_s_s((((l_570 , p_68) && ((void*)0 != &g_292[0][0][0])) | (safe_mod_func_int64_t_s_s(0x0442BE3EC5E41D81LL, (((p_70 = ((((p_69 && (safe_rshift_func_uint16_t_u_u(l_263, 1))) && (l_177 = p_69)) , (l_576 = l_263)) < p_68)) != p_67.f0) , p_69)))), g_425)), l_570))) == 65532UL);
                        (*l_581) |= (safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(p_70, 0)), (p_69 ^ 0xB75CDF3E457F0CCCLL)));
                        if (g_54)
                            break;
                        (*l_581) = p_70;
                    }
                }
                g_401 |= (l_203[7][6][0] < g_410[3]);
            }
            else
            { /* block id: 230 */
                union U2 **l_605 = (void*)0;
                union U1 **l_617 = &l_229;
                union U1 **l_618 = &l_229;
                uint16_t l_621 = 3UL;
                int16_t *l_622 = &g_424[0][1];
                uint8_t *l_623[7][10][3] = {{{(void*)0,(void*)0,&g_207.f1},{&g_207.f1,&g_183.f1,&l_351},{&g_104[0],(void*)0,&g_414},{&g_230.f1,&g_230.f1,&g_182.f1},{&l_263,&g_230.f1,(void*)0},{&g_104[1],&g_182.f1,&g_414},{&g_104[0],&g_104[3],(void*)0},{&g_230.f1,&g_104[1],&g_414},{(void*)0,&l_263,(void*)0},{&g_230.f1,&g_183.f1,&g_182.f1}},{{&l_351,&g_414,&g_414},{&g_230.f1,&g_104[1],&l_351},{&l_263,&g_414,&g_207.f1},{&g_230.f1,&g_182.f1,&g_182.f1},{&l_351,&g_207.f1,(void*)0},{&g_230.f1,&g_230.f1,(void*)0},{(void*)0,(void*)0,&g_207.f1},{&g_230.f1,&g_183.f1,&g_232.f1},{&g_104[0],(void*)0,&g_414},{&g_104[1],&g_230.f1,&l_263}},{{&l_263,&g_207.f1,(void*)0},{&g_230.f1,&g_182.f1,&g_183.f1},{&g_104[0],&g_414,(void*)0},{&g_207.f1,&g_104[1],&g_183.f1},{(void*)0,&g_414,(void*)0},{&g_104[1],&g_183.f1,&l_263},{&l_351,&l_263,&g_414},{(void*)0,&g_104[1],&g_232.f1},{&l_263,&g_104[3],&g_207.f1},{(void*)0,&g_182.f1,(void*)0}},{{&l_351,&g_230.f1,(void*)0},{&g_104[1],&g_230.f1,&g_182.f1},{(void*)0,(void*)0,&g_207.f1},{&g_207.f1,&g_183.f1,&l_351},{&g_104[0],(void*)0,&g_414},{&g_230.f1,&g_230.f1,&g_182.f1},{&l_263,&g_230.f1,(void*)0},{&g_104[1],&g_182.f1,&g_414},{&g_104[0],&g_104[3],(void*)0},{&g_230.f1,&g_104[1],&g_414}},{{(void*)0,&l_263,(void*)0},{&g_230.f1,&g_183.f1,&g_182.f1},{&l_351,&g_414,&g_414},{&g_230.f1,&g_104[1],&l_351},{&l_263,&g_414,&g_207.f1},{&g_230.f1,&g_182.f1,&g_182.f1},{&l_351,&g_207.f1,(void*)0},{&g_230.f1,&g_230.f1,(void*)0},{(void*)0,(void*)0,&g_207.f1},{&g_230.f1,&g_183.f1,&g_232.f1}},{{&g_104[0],(void*)0,&g_414},{&g_104[1],&g_230.f1,&l_263},{&l_263,&g_207.f1,(void*)0},{&g_230.f1,&g_182.f1,&g_183.f1},{&g_104[0],&g_414,(void*)0},{&g_207.f1,&g_104[1],&g_183.f1},{(void*)0,&g_414,(void*)0},{&g_104[1],&g_183.f1,&l_263},{&l_351,&l_263,&g_414},{(void*)0,&g_104[1],&g_232.f1}},{{&l_263,&g_104[3],&g_207.f1},{(void*)0,&g_182.f1,(void*)0},{&l_351,&g_230.f1,(void*)0},{&g_104[1],&g_230.f1,&g_182.f1},{(void*)0,(void*)0,&g_207.f1},{&g_207.f1,&g_183.f1,&l_351},{&g_104[0],(void*)0,&g_414},{&g_230.f1,&g_230.f1,&g_182.f1},{&l_263,&g_230.f1,(void*)0},{&g_104[1],&g_182.f1,&g_414}}};
                int32_t *l_625 = &g_520;
                int i, j, k;
                (*l_625) &= ((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s((((((*g_53) = (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((g_207.f1 &= ((((*l_622) = (safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_u(p_69, (+((safe_lshift_func_uint16_t_u_s((safe_div_func_int32_t_s_s((((((safe_mod_func_uint16_t_u_u((**g_465), (safe_lshift_func_uint8_t_u_u(g_104[1], (safe_sub_func_int8_t_s_s((l_605 != ((((safe_add_func_uint64_t_u_u((((((safe_sub_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s(l_614[1][5][3], (safe_mul_func_uint16_t_u_u((l_617 == ((*g_291) = l_618)), ((1UL && (&l_229 != l_618)) != p_68))))), 5)), 246UL)) || 255UL) < l_621) >= 7UL) <= (*g_125)), l_498)) == 0x6D1DEDEB45A668D2LL) , p_67) , &g_553)), 0L)))))) , (*g_53)) >= (*g_53)) == p_69) || 0xFC340FF7BCDF78F3LL), g_4)), p_68)) ^ p_70)))), 1))) != 0x54E5L) & l_621)), 3)), g_230.f1))) , (void*)0) == l_624) && l_499), g_104[1])), 0x14CCL)) , (-1L));
                for (g_425 = (-5); (g_425 <= 41); g_425 = safe_add_func_int8_t_s_s(g_425, 3))
                { /* block id: 238 */
                    int32_t ***l_630[6][8][5] = {{{(void*)0,&l_628,&l_628,(void*)0,&l_628},{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,(void*)0,&l_628,&l_628,&l_628},{(void*)0,&l_628,(void*)0,(void*)0,&l_628},{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,&l_628,(void*)0,&l_628}},{{(void*)0,(void*)0,(void*)0,&l_628,&l_628},{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,(void*)0,&l_628,(void*)0},{&l_628,&l_628,&l_628,&l_628,&l_628},{(void*)0,(void*)0,&l_628,&l_628,&l_628},{&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,(void*)0,&l_628,(void*)0},{&l_628,&l_628,(void*)0,&l_628,&l_628}},{{(void*)0,&l_628,(void*)0,(void*)0,(void*)0},{&l_628,(void*)0,(void*)0,&l_628,&l_628},{&l_628,&l_628,(void*)0,&l_628,(void*)0},{(void*)0,&l_628,&l_628,(void*)0,&l_628},{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,(void*)0,&l_628,&l_628,&l_628},{(void*)0,&l_628,(void*)0,(void*)0,&l_628}},{{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,&l_628,(void*)0,&l_628},{(void*)0,(void*)0,(void*)0,&l_628,&l_628},{(void*)0,&l_628,&l_628,&l_628,(void*)0},{&l_628,&l_628,(void*)0,&l_628,(void*)0},{(void*)0,&l_628,(void*)0,(void*)0,&l_628},{&l_628,&l_628,(void*)0,(void*)0,&l_628}},{{&l_628,&l_628,&l_628,(void*)0,(void*)0},{&l_628,&l_628,&l_628,(void*)0,(void*)0},{&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,(void*)0,&l_628,&l_628},{(void*)0,(void*)0,&l_628,(void*)0,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628},{(void*)0,(void*)0,(void*)0,(void*)0,&l_628},{&l_628,(void*)0,(void*)0,&l_628,(void*)0}},{{&l_628,&l_628,&l_628,&l_628,(void*)0},{(void*)0,(void*)0,&l_628,&l_628,&l_628},{(void*)0,&l_628,(void*)0,(void*)0,&l_628},{(void*)0,&l_628,&l_628,&l_628,&l_628},{(void*)0,&l_628,&l_628,(void*)0,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628},{&l_628,&l_628,(void*)0,&l_628,&l_628},{(void*)0,&l_628,&l_628,(void*)0,&l_628}}};
                    int i, j, k;
                    g_631 = l_628;
                }
            }
            for (g_425 = (-9); (g_425 != 17); g_425 = safe_add_func_int8_t_s_s(g_425, 2))
            { /* block id: 244 */
                uint16_t *l_657 = &g_81.f2;
                uint64_t **l_664 = (void*)0;
                int32_t l_670 = (-1L);
                int64_t *l_671 = &l_203[7][6][0];
                union U1 *l_677 = &g_678;
                int8_t *l_679 = &g_322;
                int16_t *l_680[9] = {&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106};
                int32_t l_681 = 0xA6FE55BAL;
                int8_t l_697 = 0xF1L;
                uint32_t l_721 = 0UL;
                int i;
                l_682 |= (safe_sub_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(p_69, (~(safe_lshift_func_int16_t_s_s((l_670 = (l_177 ^= (safe_sub_func_int16_t_s_s((safe_sub_func_int64_t_s_s((((*l_679) = (safe_lshift_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(((**g_465)--), (((l_321 != (((safe_div_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(p_70, p_67.f0)), (((l_675 = (l_229 = ((((*l_657) = l_656) && (safe_div_func_uint8_t_u_u(g_520, (safe_rshift_func_int16_t_s_s((((*l_170) = ((safe_mul_func_uint16_t_u_u((((g_665 = &g_202[0]) == (l_667 = l_666)) | (((*l_671) = ((((safe_mod_func_uint32_t_u_u(p_67.f0, (-6L))) != 0L) , 0xE6AB972FL) > l_670)) ^ (**l_628))), 0xC79BL)) || 65535UL)) | l_670), 8))))) , l_672[0]))) != l_677) , (-1L)))) & 8L) >= 0UL)) >= l_670) & 3UL))), 15))) > g_673.f1), (-1L))), l_670)))), g_424[3][6]))))), l_681));
                (**l_628) ^= p_69;
                for (g_106 = 0; (g_106 < (-18)); g_106--)
                { /* block id: 260 */
                    for (l_177 = 0; (l_177 >= 24); l_177 = safe_add_func_uint8_t_u_u(l_177, 5))
                    { /* block id: 263 */
                        uint64_t l_687 = 18446744073709551615UL;
                        return l_687;
                    }
                }
                if (((((safe_lshift_func_uint8_t_u_s((g_690 != (void*)0), 2)) || (((**l_628) && 0x34FFL) || (*g_125))) ^ (((((0L | (0xBBL & (safe_mul_func_int16_t_s_s((((g_61 < (((safe_rshift_func_uint16_t_u_s(((0x73109FECL & p_68) < p_69), (**l_628))) | p_68) , p_67.f0)) ^ (*l_629)) <= l_697), (**g_465))))) , 1L) & (*g_466)) , g_553) != l_555)) == p_70))
                { /* block id: 267 */
                    int32_t l_704 = (-1L);
                    uint64_t l_705 = 0x599385A8516C6685LL;
                    if (p_70)
                        break;
                    (*g_631) = &l_320[6][2][1];
                    for (g_132 = 0; (g_132 < (-4)); g_132 = safe_sub_func_uint8_t_u_u(g_132, 4))
                    { /* block id: 272 */
                        int32_t *l_700 = &l_407[2][0];
                        int32_t *l_701 = &l_682;
                        int32_t *l_702 = &l_342;
                        int32_t *l_703[9] = {&g_156,&g_156,&g_156,&g_156,&g_156,&g_156,&g_156,&g_156,&g_156};
                        int i;
                        ++l_705;
                    }
                }
                else
                { /* block id: 275 */
                    union U1 **l_712 = &l_672[0];
                    int32_t *l_716[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    (*l_629) = ((safe_add_func_int64_t_s_s(1L, p_70)) ^ (&l_675 == l_712));
                    for (g_61 = 16; (g_61 <= 51); ++g_61)
                    { /* block id: 279 */
                        if (l_391[0])
                            break;
                        return l_715;
                    }
                    ++l_721;
                    for (g_183.f1 = (-8); (g_183.f1 != 39); g_183.f1 = safe_add_func_int64_t_s_s(g_183.f1, 8))
                    { /* block id: 286 */
                        return g_726;
                    }
                }
            }
        }
        else
        { /* block id: 291 */
            int32_t l_727 = 0x8FA34A78L;
            int16_t *l_743 = (void*)0;
            uint64_t **l_760 = &l_667;
            union U1 **l_768 = &g_262;
            int32_t l_786[3];
            uint8_t *l_796[5][9];
            const uint16_t *l_803 = &g_550;
            const uint16_t **l_802[1][8] = {{&l_803,&l_803,&l_803,&l_803,&l_803,&l_803,&l_803,&l_803}};
            union U0 *l_858 = (void*)0;
            union U0 **l_857[4][10] = {{(void*)0,&l_858,&l_858,&l_858,&l_858,&l_858,&l_858,(void*)0,&l_858,&l_858},{&l_858,(void*)0,&l_858,(void*)0,&l_858,&l_858,&l_858,&l_858,(void*)0,&l_858},{(void*)0,(void*)0,&l_858,&l_858,(void*)0,&l_858,&l_858,(void*)0,(void*)0,&l_858},{(void*)0,&l_858,&l_858,&l_858,&l_858,(void*)0,&l_858,(void*)0,&l_858,&l_858}};
            uint16_t l_868 = 0xA8DAL;
            int32_t l_981 = 0x3BD9DA3AL;
            uint8_t l_1016 = 0x41L;
            int i, j;
            for (i = 0; i < 3; i++)
                l_786[i] = 0x232C9572L;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 9; j++)
                    l_796[i][j] = (void*)0;
            }
        }
        return l_391[0];
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_104 g_119 g_52 g_154 g_156
 * writes: g_154 g_156
 */
static union U0  func_71(int16_t  p_72)
{ /* block id: 33 */
    int8_t *l_139[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int8_t **l_140 = (void*)0;
    int8_t **l_141 = &l_139[5];
    uint16_t *l_144 = &g_81.f2;
    uint16_t *l_145 = &g_81.f2;
    uint16_t *l_146 = (void*)0;
    uint16_t *l_147[8] = {&g_81.f2,&g_81.f2,&g_81.f2,&g_81.f2,&g_81.f2,&g_81.f2,&g_81.f2,&g_81.f2};
    uint16_t l_148 = 0xB8C2L;
    int64_t *l_153 = &g_154;
    int32_t *l_155 = &g_156;
    union U0 l_157[7] = {{0x07BE1BD8L},{0x07BE1BD8L},{0x07BE1BD8L},{0x07BE1BD8L},{0x07BE1BD8L},{0x07BE1BD8L},{0x07BE1BD8L}};
    int i;
    (*l_155) |= ((safe_div_func_int16_t_s_s((((*l_141) = l_139[5]) == &g_9), g_54)) | ((*l_153) &= (safe_lshift_func_uint8_t_u_s(((0x6627L > (g_104[1] || ((++l_148) == ((((safe_lshift_func_int8_t_s_s(g_54, p_72)) < ((g_119 != (void*)0) < p_72)) ^ 0x3C544D90L) , g_104[1])))) , l_148), g_52))));
    (*l_155) = (*l_155);
    return l_157[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_106 g_60 g_104 g_53 g_119 g_125 g_9 g_61
 * writes: g_104 g_132 g_81.f0
 */
static uint16_t  func_74(uint64_t  p_75, union U0  p_76, uint32_t  p_77, union U0  p_78)
{ /* block id: 16 */
    uint64_t l_93 = 0xFA353696E02F5F5CLL;
    int16_t l_94[7][4][4] = {{{(-1L),0L,0xB4CDL,0xD8B1L},{0x8FA6L,0xFF5FL,1L,(-1L)},{1L,(-1L),0L,0L},{(-1L),0x0441L,0x0441L,(-1L)}},{{0x31D7L,1L,0x744AL,0xD8B1L},{0xA777L,0L,(-1L),0xFF5FL},{(-9L),0xBC36L,(-1L),0xFF5FL},{0xB4CDL,0L,0x9C5DL,0xD8B1L}},{{0x0441L,1L,0xB4CDL,(-1L)},{1L,0x0441L,0x0C12L,0L},{0x8FA6L,(-1L),0x9D29L,(-1L)},{4L,0xFF5FL,0xBC36L,7L}},{{0xA879L,(-10L),7L,0x0441L},{0L,0x8FA6L,0xFF5FL,0xB153L},{0L,(-9L),7L,0xA879L},{0xA879L,0xB153L,0xBC36L,1L}},{{4L,0x3742L,0x9D29L,0x744AL},{0x8FA6L,0x9D29L,0x0C12L,0x0C12L},{1L,1L,0xB4CDL,(-10L)},{0x0441L,1L,0x9C5DL,1L}},{{0xB4CDL,0xA777L,(-1L),0x9C5DL},{(-9L),0xA777L,(-1L),1L},{0xA777L,1L,0x744AL,(-10L)},{0x31D7L,1L,0x0441L,0x0C12L}},{{(-1L),0x9D29L,0L,0x744AL},{1L,0x3742L,1L,1L},{0x744AL,0xB153L,0x8FA6L,0xA879L},{(-1L),(-9L),0xC8DDL,0xB153L}}};
    uint8_t *l_103 = &g_104[1];
    int32_t l_105 = 0xDFB53829L;
    uint16_t *l_107[8] = {&g_61,&g_81.f2,&g_61,&g_61,&g_81.f2,&g_61,&g_61,&g_81.f2};
    int32_t l_108 = 0x25832669L;
    int32_t l_109[10][9] = {{0xA983ECD6L,0xE665D24BL,(-1L),(-1L),0xE665D24BL,0xA983ECD6L,0xC661B5B5L,0xA983ECD6L,0xE665D24BL},{0x8406A83BL,3L,3L,0x8406A83BL,1L,(-5L),1L,0x8406A83BL,3L},{0L,0L,0xC661B5B5L,0xE665D24BL,0x9C51A53AL,0xE665D24BL,0xC661B5B5L,0L,0L},{3L,0x8406A83BL,1L,(-5L),1L,0x8406A83BL,3L,3L,0x8406A83BL},{0xE665D24BL,0xA983ECD6L,0xC661B5B5L,0xA983ECD6L,0xE665D24BL,(-1L),(-1L),0xE665D24BL,0xA983ECD6L},{3L,1L,3L,0xC24141E3L,(-1L),(-1L),0xC24141E3L,3L,1L},{0L,(-8L),(-1L),0xC661B5B5L,0xC661B5B5L,(-1L),(-8L),0L,(-8L)},{0x8406A83BL,(-5L),0xC24141E3L,0xC24141E3L,(-5L),0x8406A83BL,(-1L),0x8406A83BL,(-5L)},{0xA983ECD6L,(-8L),(-8L),(-8L),0x9C51A53AL,(-1L),0x9C51A53AL,(-8L),0xE665D24BL},{0x62296547L,0x62296547L,1L,0xC24141E3L,0x8406A83BL,0xC24141E3L,1L,0x62296547L,0x62296547L}};
    uint64_t *l_110 = (void*)0;
    int32_t l_111 = 0x4E2A8042L;
    const volatile int8_t * volatile *l_120 = &g_121;
    uint32_t *l_130 = &g_54;
    int8_t *l_131 = &g_132;
    int32_t *l_133 = (void*)0;
    int32_t *l_134[5];
    int32_t **l_136 = &l_134[1];
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_134[i] = &l_108;
    if ((+(p_78.f0 , (l_111 = ((safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u((!p_76.f0), ((((0xD8DAL && ((((safe_mul_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u(l_93, 1)) , ((l_94[1][1][2] > (safe_mod_func_uint16_t_u_u((l_108 &= (safe_add_func_int8_t_s_s(((!((!(g_54 & (6UL && p_78.f0))) || ((((safe_mul_func_uint8_t_u_u(((*l_103) = p_78.f0), l_94[0][0][2])) & p_76.f0) >= l_94[1][1][2]) <= l_105))) == p_77), g_106))), p_76.f0))) >= g_54)), g_54)) > g_60) , g_104[1]) | l_93)) > l_94[1][3][3]) ^ l_105) , (-8L)))), l_105)) | l_109[5][0])))))
    { /* block id: 20 */
        uint16_t *l_118 = (void*)0;
        p_76.f0 = 6L;
        p_78.f0 = (safe_div_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(p_75, (safe_sub_func_uint8_t_u_u((4294967295UL || (((void*)0 == &g_104[2]) >= (*g_53))), (((&g_54 == ((l_118 != l_107[5]) , &g_54)) && g_60) >= p_75))))), (*g_53)));
    }
    else
    { /* block id: 23 */
        l_120 = g_119;
    }
    if (p_77)
        goto lbl_135;
lbl_135:
    g_81.f0 = (p_78.f0 = (((((safe_add_func_int8_t_s_s((&p_75 != g_125), (((+(safe_mul_func_int8_t_s_s(((*l_131) = ((void*)0 == l_130)), ((p_76.f0 > (g_9 | p_75)) & p_78.f0)))) , l_103) == (void*)0))) < p_78.f0) >= (-1L)) , p_75) ^ (-6L)));
    l_133 = ((*l_136) = &l_108);
    return g_61;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_81.f0, "g_81.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_182.f0, "g_182.f0", print_hash_value);
    transparent_crc(g_182.f1, "g_182.f1", print_hash_value);
    transparent_crc(g_183.f0, "g_183.f0", print_hash_value);
    transparent_crc(g_183.f1, "g_183.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_202[i], "g_202[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_207.f0, "g_207.f0", print_hash_value);
    transparent_crc(g_207.f1, "g_207.f1", print_hash_value);
    transparent_crc(g_218, "g_218", print_hash_value);
    transparent_crc(g_230.f0, "g_230.f0", print_hash_value);
    transparent_crc(g_230.f1, "g_230.f1", print_hash_value);
    transparent_crc(g_232.f0, "g_232.f0", print_hash_value);
    transparent_crc(g_232.f1, "g_232.f1", print_hash_value);
    transparent_crc(g_254, "g_254", print_hash_value);
    transparent_crc(g_319, "g_319", print_hash_value);
    transparent_crc(g_322, "g_322", print_hash_value);
    transparent_crc(g_324, "g_324", print_hash_value);
    transparent_crc(g_401, "g_401", print_hash_value);
    transparent_crc(g_408, "g_408", print_hash_value);
    transparent_crc(g_409, "g_409", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_410[i], "g_410[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_414, "g_414", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_424[i][j], "g_424[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_425, "g_425", print_hash_value);
    transparent_crc(g_471, "g_471", print_hash_value);
    transparent_crc(g_484.f0, "g_484.f0", print_hash_value);
    transparent_crc(g_520, "g_520", print_hash_value);
    transparent_crc(g_550, "g_550", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_554[i][j].f0, "g_554[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_556.f0, "g_556.f0", print_hash_value);
    transparent_crc(g_673.f1, "g_673.f1", print_hash_value);
    transparent_crc(g_674.f0, "g_674.f0", print_hash_value);
    transparent_crc(g_674.f1, "g_674.f1", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_676[i].f0, "g_676[i].f0", print_hash_value);
        transparent_crc(g_676[i].f1, "g_676[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_678.f0, "g_678.f0", print_hash_value);
    transparent_crc(g_678.f1, "g_678.f1", print_hash_value);
    transparent_crc(g_692.f0, "g_692.f0", print_hash_value);
    transparent_crc(g_726, "g_726", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_830[i].f0, "g_830[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_894.f0, "g_894.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_1021[i][j][k], "g_1021[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1026.f0, "g_1026.f0", print_hash_value);
    transparent_crc(g_1026.f1, "g_1026.f1", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1077[i], "g_1077[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1200.f0, "g_1200.f0", print_hash_value);
    transparent_crc(g_1200.f1, "g_1200.f1", print_hash_value);
    transparent_crc(g_1239, "g_1239", print_hash_value);
    transparent_crc(g_1332, "g_1332", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1342[i], "g_1342[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1348.f0, "g_1348.f0", print_hash_value);
    transparent_crc(g_1349.f0, "g_1349.f0", print_hash_value);
    transparent_crc(g_1436, "g_1436", print_hash_value);
    transparent_crc(g_1451, "g_1451", print_hash_value);
    transparent_crc(g_1469.f0, "g_1469.f0", print_hash_value);
    transparent_crc(g_1470.f0, "g_1470.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1472[i].f0, "g_1472[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1584[i], "g_1584[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1614, "g_1614", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1615[i][j], "g_1615[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1900.f0, "g_1900.f0", print_hash_value);
    transparent_crc(g_1900.f1, "g_1900.f1", print_hash_value);
    transparent_crc(g_1917.f0, "g_1917.f0", print_hash_value);
    transparent_crc(g_1919.f0, "g_1919.f0", print_hash_value);
    transparent_crc(g_1921.f0, "g_1921.f0", print_hash_value);
    transparent_crc(g_1924.f0, "g_1924.f0", print_hash_value);
    transparent_crc(g_1924.f1, "g_1924.f1", print_hash_value);
    transparent_crc(g_1939, "g_1939", print_hash_value);
    transparent_crc(g_1965, "g_1965", print_hash_value);
    transparent_crc(g_1983.f0, "g_1983.f0", print_hash_value);
    transparent_crc(g_2101.f0, "g_2101.f0", print_hash_value);
    transparent_crc(g_2126.f0, "g_2126.f0", print_hash_value);
    transparent_crc(g_2129.f0, "g_2129.f0", print_hash_value);
    transparent_crc(g_2202.f0, "g_2202.f0", print_hash_value);
    transparent_crc(g_2202.f1, "g_2202.f1", print_hash_value);
    transparent_crc(g_2398.f0, "g_2398.f0", print_hash_value);
    transparent_crc(g_2398.f1, "g_2398.f1", print_hash_value);
    transparent_crc(g_2455.f0, "g_2455.f0", print_hash_value);
    transparent_crc(g_2455.f1, "g_2455.f1", print_hash_value);
    transparent_crc(g_2456.f0, "g_2456.f0", print_hash_value);
    transparent_crc(g_2456.f1, "g_2456.f1", print_hash_value);
    transparent_crc(g_2551, "g_2551", print_hash_value);
    transparent_crc(g_2745, "g_2745", print_hash_value);
    transparent_crc(g_2765, "g_2765", print_hash_value);
    transparent_crc(g_2767, "g_2767", print_hash_value);
    transparent_crc(g_2977, "g_2977", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_3083[i], "g_3083[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3129, "g_3129", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3172[i], "g_3172[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3217[i].f0, "g_3217[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3224.f0, "g_3224.f0", print_hash_value);
    transparent_crc(g_3224.f1, "g_3224.f1", print_hash_value);
    transparent_crc(g_3226.f0, "g_3226.f0", print_hash_value);
    transparent_crc(g_3245.f0, "g_3245.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_3270[i][j][k].f0, "g_3270[i][j][k].f0", print_hash_value);
                transparent_crc(g_3270[i][j][k].f1, "g_3270[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3310[i], "g_3310[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3360[i].f0, "g_3360[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 781
XXX total union variables: 21

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 68
breakdown:
   indirect level: 0, occurrence: 19
   indirect level: 1, occurrence: 25
   indirect level: 2, occurrence: 19
   indirect level: 3, occurrence: 3
   indirect level: 4, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 30
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 43
XXX times a single bitfield on LHS: 26
XXX times a single bitfield on RHS: 136

XXX max expression depth: 57
breakdown:
   depth: 1, occurrence: 335
   depth: 2, occurrence: 95
   depth: 3, occurrence: 7
   depth: 4, occurrence: 6
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 3
   depth: 15, occurrence: 4
   depth: 16, occurrence: 3
   depth: 17, occurrence: 3
   depth: 18, occurrence: 6
   depth: 20, occurrence: 5
   depth: 21, occurrence: 5
   depth: 22, occurrence: 1
   depth: 23, occurrence: 3
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 4
   depth: 31, occurrence: 3
   depth: 32, occurrence: 2
   depth: 33, occurrence: 4
   depth: 34, occurrence: 1
   depth: 36, occurrence: 4
   depth: 37, occurrence: 1
   depth: 38, occurrence: 2
   depth: 39, occurrence: 1
   depth: 41, occurrence: 1
   depth: 43, occurrence: 1
   depth: 44, occurrence: 1
   depth: 48, occurrence: 1
   depth: 57, occurrence: 1

XXX total number of pointers: 745

XXX times a variable address is taken: 1386
XXX times a pointer is dereferenced on RHS: 439
breakdown:
   depth: 1, occurrence: 374
   depth: 2, occurrence: 64
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 405
breakdown:
   depth: 1, occurrence: 359
   depth: 2, occurrence: 39
   depth: 3, occurrence: 6
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 75
XXX times a pointer is compared with address of another variable: 17
XXX times a pointer is compared with another pointer: 23
XXX times a pointer is qualified to be dereferenced: 8509

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1865
   level: 2, occurrence: 726
   level: 3, occurrence: 82
   level: 4, occurrence: 9
   level: 5, occurrence: 6
XXX number of pointers point to pointers: 262
XXX number of pointers point to scalars: 427
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.7
XXX average alias set size: 1.45

XXX times a non-volatile is read: 2819
XXX times a non-volatile is write: 1335
XXX times a volatile is read: 17
XXX    times read thru a pointer: 9
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 471
XXX percentage of non-volatile access: 99.6

XXX forward jumps: 1
XXX backward jumps: 10

XXX stmts: 352
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 37
   depth: 1, occurrence: 38
   depth: 2, occurrence: 38
   depth: 3, occurrence: 66
   depth: 4, occurrence: 81
   depth: 5, occurrence: 92

XXX percentage a fresh-made variable is used: 17.1
XXX percentage an existing variable is used: 82.9
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

