/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      634647449
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0xE0648261L;
static int32_t g_6 = 0x64DC9ED9L;
static uint32_t g_64 = 3UL;
static int8_t g_79 = 0xBEL;
static uint16_t g_81 = 0UL;
static uint16_t g_101 = 5UL;
static uint16_t *g_100 = &g_101;
static uint64_t g_113 = 4UL;
static int16_t g_115 = 0x1E56L;
static int32_t g_118 = 0x8752EB69L;
static int32_t * volatile g_117[1][7][6] = {{{&g_118,&g_118,&g_2,&g_118,&g_118,&g_2},{&g_118,&g_118,&g_2,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_2},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_2,&g_118,&g_118,&g_2},{&g_118,&g_118,&g_2,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_2}}};
static int8_t g_149 = (-6L);
static int8_t g_151 = 0x63L;
static volatile uint16_t g_154 = 0xBF42L;/* VOLATILE GLOBAL g_154 */
static volatile uint16_t *g_153[10][2][8] = {{{(void*)0,&g_154,&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154}},{{(void*)0,&g_154,&g_154,(void*)0,&g_154,&g_154,(void*)0,(void*)0},{&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154},{(void*)0,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_154,&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154,(void*)0},{(void*)0,&g_154,&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154}},{{(void*)0,&g_154,&g_154,&g_154,(void*)0,&g_154,&g_154,&g_154},{(void*)0,&g_154,&g_154,&g_154,(void*)0,(void*)0,&g_154,&g_154}},{{&g_154,&g_154,&g_154,(void*)0,&g_154,&g_154,&g_154,(void*)0},{(void*)0,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154},{&g_154,(void*)0,(void*)0,&g_154,&g_154,&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154},{(void*)0,&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0}},{{&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154,(void*)0,&g_154}},{{&g_154,&g_154,&g_154,&g_154,&g_154,&g_154,(void*)0,&g_154},{(void*)0,&g_154,(void*)0,&g_154,&g_154,(void*)0,&g_154,&g_154}}};
static volatile uint16_t * volatile *g_152 = &g_153[8][0][4];
static int32_t *g_159[10][2] = {{&g_6,&g_6},{&g_2,&g_6},{&g_6,&g_2},{&g_6,&g_6},{&g_2,&g_6},{&g_6,&g_2},{&g_6,&g_6},{&g_2,&g_6},{&g_6,&g_2},{&g_6,&g_6}};
static int32_t ** volatile g_158[3] = {&g_159[8][0],&g_159[8][0],&g_159[8][0]};
static int32_t *g_174 = &g_6;
static uint8_t g_185 = 0xA1L;
static uint8_t g_211[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static int32_t * volatile g_240 = (void*)0;/* VOLATILE GLOBAL g_240 */
static int32_t *g_249 = &g_6;
static int16_t g_283 = 0x3B6DL;
static int64_t g_315[4][4] = {{3L,1L,1L,3L},{0xEC10CD837A4677E4LL,3L,0x28F6E9EABD20069FLL,3L},{3L,0xEC10CD837A4677E4LL,0x28F6E9EABD20069FLL,0x28F6E9EABD20069FLL},{1L,1L,3L,0x28F6E9EABD20069FLL}};
static uint64_t g_327 = 18446744073709551615UL;
static volatile uint32_t g_479 = 0xB41165BBL;/* VOLATILE GLOBAL g_479 */
static volatile uint32_t * volatile g_478 = &g_479;/* VOLATILE GLOBAL g_478 */
static volatile uint32_t * volatile * const g_477 = &g_478;
static volatile int32_t ***g_520 = (void*)0;
static uint32_t g_528[10] = {6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL};
static const volatile uint32_t g_544 = 4294967295UL;/* VOLATILE GLOBAL g_544 */
static const int32_t *g_575 = (void*)0;
static int64_t *g_589 = (void*)0;
static volatile uint8_t *g_603 = (void*)0;
static volatile uint8_t **g_602 = &g_603;
static uint64_t g_702 = 18446744073709551615UL;
static volatile int16_t g_715 = 0x1E19L;/* VOLATILE GLOBAL g_715 */
static int32_t g_734 = 0L;
static uint16_t g_809 = 0x0CC5L;
static volatile uint32_t g_882 = 5UL;/* VOLATILE GLOBAL g_882 */
static int8_t g_884 = 5L;
static const int32_t ** volatile g_922 = &g_575;/* VOLATILE GLOBAL g_922 */
static const volatile int16_t *g_928 = (void*)0;
static const volatile int16_t * volatile * const g_927 = &g_928;
static uint32_t * volatile *g_975 = (void*)0;
static uint32_t * volatile **g_974[2][8][7] = {{{&g_975,&g_975,&g_975,&g_975,&g_975,&g_975,(void*)0},{&g_975,(void*)0,&g_975,&g_975,&g_975,&g_975,(void*)0},{&g_975,&g_975,&g_975,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,&g_975,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,&g_975,&g_975,&g_975,(void*)0,&g_975},{&g_975,&g_975,&g_975,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,(void*)0,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,&g_975,&g_975,&g_975,&g_975,(void*)0}},{{&g_975,(void*)0,&g_975,&g_975,(void*)0,&g_975,&g_975},{&g_975,(void*)0,&g_975,&g_975,&g_975,(void*)0,&g_975},{&g_975,&g_975,&g_975,&g_975,&g_975,(void*)0,&g_975},{&g_975,(void*)0,(void*)0,&g_975,&g_975,&g_975,&g_975},{&g_975,(void*)0,&g_975,&g_975,&g_975,&g_975,&g_975},{(void*)0,&g_975,&g_975,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,(void*)0,&g_975,&g_975,&g_975,&g_975},{&g_975,&g_975,&g_975,(void*)0,(void*)0,&g_975,&g_975}}};
static uint8_t *g_1013 = (void*)0;
static const uint32_t *g_1027 = (void*)0;
static uint16_t **g_1041 = &g_100;
static uint16_t ***g_1040 = &g_1041;
static int32_t * const  volatile g_1086 = &g_118;/* VOLATILE GLOBAL g_1086 */
static int32_t * volatile g_1118[4][5][10] = {{{&g_118,&g_2,(void*)0,&g_6,&g_2,&g_6,&g_6,&g_2,&g_6,(void*)0},{&g_6,&g_6,&g_2,&g_2,&g_118,(void*)0,&g_118,(void*)0,&g_6,(void*)0},{&g_118,&g_6,&g_2,&g_118,(void*)0,&g_6,&g_118,&g_2,&g_2,&g_6},{&g_6,&g_6,(void*)0,&g_2,(void*)0,&g_6,&g_6,&g_118,&g_6,&g_6},{&g_2,&g_2,(void*)0,(void*)0,&g_118,(void*)0,(void*)0,&g_2,&g_2,&g_2}},{{&g_2,&g_118,(void*)0,(void*)0,&g_118,&g_6,&g_118,(void*)0,&g_6,&g_118},{&g_118,&g_6,&g_6,(void*)0,&g_2,&g_118,&g_2,(void*)0,&g_6,&g_2},{&g_118,(void*)0,&g_6,&g_2,&g_118,&g_6,&g_6,&g_6,&g_6,&g_6},{&g_118,&g_6,&g_6,&g_6,&g_6,&g_118,&g_2,(void*)0,&g_6,(void*)0},{&g_2,&g_6,&g_2,&g_6,&g_6,&g_6,&g_6,&g_118,(void*)0,&g_6}},{{&g_2,(void*)0,&g_118,&g_2,&g_2,&g_118,&g_6,&g_6,&g_6,(void*)0},{&g_118,&g_6,&g_6,&g_6,(void*)0,&g_6,(void*)0,&g_6,(void*)0,&g_6},{&g_118,(void*)0,&g_118,&g_6,&g_2,&g_118,&g_6,&g_2,&g_6,(void*)0},{&g_118,&g_2,&g_6,&g_118,&g_118,&g_6,(void*)0,&g_2,(void*)0,&g_6},{(void*)0,&g_6,&g_118,(void*)0,&g_6,&g_2,&g_118,&g_6,&g_6,&g_6}},{{&g_6,&g_2,&g_6,&g_2,&g_2,&g_2,&g_2,&g_6,&g_2,&g_6},{&g_6,(void*)0,&g_118,(void*)0,&g_2,&g_6,&g_6,&g_118,&g_118,&g_6},{(void*)0,&g_2,&g_2,(void*)0,&g_2,(void*)0,(void*)0,(void*)0,&g_6,&g_6},{&g_2,&g_6,&g_6,&g_118,&g_2,(void*)0,(void*)0,&g_6,&g_6,&g_6},{&g_2,(void*)0,&g_6,&g_2,&g_6,(void*)0,&g_2,(void*)0,&g_2,&g_6}}};
static int32_t * volatile g_1119 = &g_118;/* VOLATILE GLOBAL g_1119 */
static uint32_t *** volatile g_1205 = (void*)0;/* VOLATILE GLOBAL g_1205 */
static uint32_t g_1208 = 0UL;
static uint32_t *g_1207[6][5] = {{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208},{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208},{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208},{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208},{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208},{&g_1208,&g_1208,&g_1208,&g_1208,&g_1208}};
static uint32_t **g_1206 = &g_1207[0][3];
static uint16_t *** volatile g_1211[5][2] = {{&g_1041,&g_1041},{&g_1041,&g_1041},{&g_1041,&g_1041},{&g_1041,&g_1041},{&g_1041,&g_1041}};
static uint16_t *** volatile g_1212 = &g_1041;/* VOLATILE GLOBAL g_1212 */
static uint8_t **g_1238 = (void*)0;
static int64_t * const g_1290 = (void*)0;
static int64_t * volatile * volatile g_1329 = &g_589;/* VOLATILE GLOBAL g_1329 */
static int64_t * volatile * volatile * volatile g_1328 = &g_1329;/* VOLATILE GLOBAL g_1328 */
static int64_t * volatile * volatile * volatile * volatile g_1327 = &g_1328;/* VOLATILE GLOBAL g_1327 */
static int32_t * volatile g_1341 = (void*)0;/* VOLATILE GLOBAL g_1341 */
static volatile uint16_t g_1358 = 0x6040L;/* VOLATILE GLOBAL g_1358 */
static uint32_t *g_1387 = &g_528[9];
static int64_t g_1404 = 0xE8E2637112BE6DBFLL;
static volatile int64_t g_1449 = 0L;/* VOLATILE GLOBAL g_1449 */
static int16_t *g_1469 = (void*)0;
static int16_t **g_1468 = &g_1469;
static int32_t g_1486[3][3][6] = {{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}}};
static int64_t g_1499 = 0L;
static int32_t ** volatile g_1501 = &g_249;/* VOLATILE GLOBAL g_1501 */
static int8_t *g_1513 = &g_149;
static const int64_t g_1531 = 0x779A72CB77924AFELL;
static uint16_t ****g_1542 = &g_1040;
static int16_t g_1543 = (-9L);
static const uint64_t *g_1586 = &g_702;
static int32_t ** volatile g_1610 = &g_159[6][1];/* VOLATILE GLOBAL g_1610 */
static const uint8_t ***g_1625 = (void*)0;
static volatile uint64_t g_1743[6] = {9UL,9UL,0x8018F08F7F4E5B70LL,9UL,9UL,0x8018F08F7F4E5B70LL};
static int32_t ** volatile g_1767 = (void*)0;/* VOLATILE GLOBAL g_1767 */
static int32_t ** volatile g_1768 = &g_159[1][1];/* VOLATILE GLOBAL g_1768 */
static int32_t * volatile * volatile g_1772 = &g_159[8][0];/* VOLATILE GLOBAL g_1772 */
static int32_t g_1831[3][4][4] = {{{0L,(-1L),0x060E51A1L,0x060E51A1L},{0xDEAAED2FL,0xDEAAED2FL,(-7L),(-1L)},{(-1L),0L,(-7L),0L},{0xDEAAED2FL,1L,0x060E51A1L,(-7L)}},{{0L,1L,1L,0L},{1L,0L,0xDEAAED2FL,(-1L)},{1L,0xDEAAED2FL,1L,0x060E51A1L},{0L,(-1L),0x060E51A1L,0x060E51A1L}},{{0xDEAAED2FL,0xDEAAED2FL,(-7L),(-1L)},{(-1L),0L,(-7L),0L},{0xDEAAED2FL,1L,0x060E51A1L,(-7L)},{0L,1L,1L,0L}}};
static int64_t ***g_1840 = (void*)0;
static volatile int8_t * volatile * volatile *g_1864 = (void*)0;
static volatile int16_t * volatile g_1918 = &g_715;/* VOLATILE GLOBAL g_1918 */
static volatile int16_t * volatile * volatile g_1917 = &g_1918;/* VOLATILE GLOBAL g_1917 */
static volatile int16_t * volatile * volatile *g_1916 = &g_1917;
static volatile int16_t * volatile * volatile * volatile *g_1915 = &g_1916;
static const int16_t **g_1931[4][1][2] = {{{(void*)0,(void*)0}},{{(void*)0,(void*)0}},{{(void*)0,(void*)0}},{{(void*)0,(void*)0}}};
static const int16_t ***g_1930 = &g_1931[2][0][0];
static uint8_t g_2025 = 0x8DL;
static int32_t ** volatile g_2031[9] = {&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174};
static int32_t **g_2091 = (void*)0;
static int32_t ***g_2090 = &g_2091;
static int32_t ** volatile g_2108 = &g_174;/* VOLATILE GLOBAL g_2108 */
static uint8_t g_2113[10] = {0x4CL,0x4CL,0x4CL,0x4CL,0x4CL,0x4CL,0x4CL,0x4CL,0x4CL,0x4CL};
static volatile int32_t g_2199 = 0x472171B2L;/* VOLATILE GLOBAL g_2199 */
static volatile int64_t g_2285 = 0xEFC7C226F778ECBELL;/* VOLATILE GLOBAL g_2285 */
static int32_t ** const  volatile g_2317 = (void*)0;/* VOLATILE GLOBAL g_2317 */
static uint32_t g_2319 = 0x9A70BA94L;
static int32_t g_2320 = 0x6B83023DL;
static const uint16_t ***g_2395 = (void*)0;
static const uint16_t ****g_2394 = &g_2395;
static int16_t g_2445 = (-1L);
static int64_t g_2462 = (-3L);
static uint16_t g_2529 = 0xCE62L;
static uint64_t *g_2543[5][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113,&g_113},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int32_t g_2713 = (-8L);
static int32_t g_2815 = 7L;
static int32_t ** volatile g_2843[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** volatile g_2844 = &g_159[8][0];/* VOLATILE GLOBAL g_2844 */
static volatile int16_t g_2942 = (-1L);/* VOLATILE GLOBAL g_2942 */
static volatile int8_t g_3006[6][2][1] = {{{(-10L)},{(-1L)}},{{0xABL},{0xABL}},{{(-1L)},{(-10L)}},{{(-1L)},{0xABL}},{{0xABL},{(-10L)}},{{0xABL},{(-10L)}}};
static volatile int32_t g_3015 = 0x43179FD6L;/* VOLATILE GLOBAL g_3015 */
static int32_t ** volatile g_3075 = &g_159[8][0];/* VOLATILE GLOBAL g_3075 */
static int32_t ** volatile g_3095[9] = {&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174};
static int32_t ** volatile g_3096 = &g_159[4][0];/* VOLATILE GLOBAL g_3096 */
static volatile int64_t g_3167 = 0x21F6396F9807676DLL;/* VOLATILE GLOBAL g_3167 */
static int32_t ** volatile g_3182[2] = {&g_159[5][0],&g_159[5][0]};
static uint64_t **g_3195[2][3] = {{&g_2543[0][8],&g_2543[0][8],&g_2543[0][8]},{&g_2543[0][8],&g_2543[0][8],&g_2543[0][8]}};
static int8_t **g_3262 = (void*)0;
static int8_t ***g_3261 = &g_3262;
static const int8_t *g_3290 = &g_884;
static const int8_t **g_3289[1][9][2] = {{{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290},{&g_3290,&g_3290}}};
static volatile uint32_t g_3296 = 0x348FEA2AL;/* VOLATILE GLOBAL g_3296 */
static volatile uint32_t *g_3295 = &g_3296;
static volatile uint32_t ** const  volatile g_3294 = &g_3295;/* VOLATILE GLOBAL g_3294 */
static volatile uint32_t ** const  volatile *g_3293 = &g_3294;
static volatile uint32_t ** const  volatile * volatile *g_3292 = &g_3293;
static int32_t ** volatile g_3316[3][9][7] = {{{&g_159[8][0],&g_249,(void*)0,&g_159[4][0],&g_174,&g_174,&g_174},{&g_174,&g_159[5][0],&g_159[6][1],(void*)0,(void*)0,&g_159[8][0],&g_159[8][0]},{&g_159[5][0],&g_249,&g_249,(void*)0,&g_249,&g_174,&g_159[8][0]},{&g_174,&g_159[8][0],&g_159[2][0],&g_159[4][0],&g_249,(void*)0,&g_249},{&g_159[8][0],&g_249,&g_174,&g_174,&g_159[8][0],&g_159[2][0],&g_174},{(void*)0,&g_159[8][0],(void*)0,&g_159[2][0],&g_174,&g_174,&g_159[8][0]},{(void*)0,&g_159[4][0],&g_159[8][0],&g_159[8][0],&g_159[8][0],&g_159[4][0],(void*)0},{(void*)0,&g_159[1][1],&g_174,&g_159[8][0],&g_159[8][0],&g_174,(void*)0},{&g_174,&g_159[4][1],&g_174,&g_174,&g_159[6][0],&g_159[8][0],&g_174}},{{&g_174,(void*)0,&g_174,&g_174,&g_159[8][1],&g_249,&g_159[8][0]},{&g_249,&g_174,&g_159[8][0],&g_174,&g_159[1][1],&g_174,&g_159[8][0]},{&g_249,(void*)0,(void*)0,(void*)0,&g_159[2][0],(void*)0,&g_249},{(void*)0,&g_159[2][0],&g_174,&g_174,&g_174,&g_159[8][0],&g_159[2][0]},{&g_249,&g_174,&g_159[2][0],&g_159[8][0],&g_159[8][1],&g_174,&g_174},{&g_159[8][0],&g_159[6][0],&g_249,&g_249,(void*)0,&g_159[8][0],&g_249},{&g_249,&g_159[6][0],&g_159[6][1],&g_249,&g_174,&g_174,&g_249},{&g_159[4][0],&g_174,(void*)0,&g_174,(void*)0,&g_174,&g_159[8][0]},{&g_174,&g_159[2][0],&g_159[8][0],&g_159[8][0],&g_249,&g_159[8][0],&g_174}},{{&g_159[1][1],(void*)0,&g_249,&g_249,&g_159[5][0],&g_174,&g_174},{&g_159[8][0],&g_174,&g_159[8][0],&g_174,&g_159[8][0],&g_249,&g_159[6][1]},{&g_249,(void*)0,&g_249,&g_159[1][1],&g_159[8][0],(void*)0,&g_159[4][0]},{&g_159[8][0],&g_159[4][1],&g_249,(void*)0,&g_159[2][0],&g_249,&g_174},{&g_174,(void*)0,(void*)0,&g_159[8][0],&g_174,&g_174,&g_174},{&g_159[8][0],&g_159[2][0],&g_249,&g_174,(void*)0,&g_159[1][1],&g_249},{(void*)0,(void*)0,&g_174,&g_249,(void*)0,&g_174,&g_159[8][0]},{&g_174,&g_159[8][0],&g_174,&g_159[8][0],&g_159[2][1],&g_174,&g_249},{&g_159[2][0],(void*)0,(void*)0,&g_174,(void*)0,(void*)0,&g_174}}};
static int32_t ** volatile g_3317 = &g_159[6][1];/* VOLATILE GLOBAL g_3317 */
static int16_t g_3333[5][5][5] = {{{0xC6A7L,8L,5L,0x9726L,(-1L)},{0x992FL,0x5849L,(-1L),(-1L),0x5849L},{0x56DBL,0L,5L,(-1L),5L},{0xAC67L,0x8173L,(-1L),0xEAD8L,0x7B6AL},{0L,0x56DBL,0x56DBL,0L,0L}},{{0xAC67L,(-1L),0x7431L,0x6A9FL,0xEAD8L},{0x56DBL,(-9L),0x064DL,5L,0x064DL},{0x992FL,0x992FL,0xEAD8L,0x6A9FL,0x7431L},{0xC6A7L,0x9726L,0L,0L,0x56DBL},{(-1L),0xEAD8L,0x7B6AL,0xEAD8L,(-1L)}},{{0x05CAL,0x9726L,5L,(-1L),5L},{0x6A9FL,0x992FL,0x5849L,(-1L),(-1L)},{(-1L),(-9L),(-1L),0x9726L,5L},{1L,(-1L),0x992FL,0x2F53L,(-1L)},{5L,0x56DBL,8L,8L,0x56DBL}},{{0x5849L,0x8173L,0x992FL,(-1L),0x7431L},{(-9L),0L,(-1L),0L,0x064DL},{0x77E3L,0x5849L,0x5849L,0x77E3L,0xEAD8L},{(-9L),8L,5L,0x05CAL,0L},{0x5849L,0xAC67L,0x7B6AL,0x992FL,0x7B6AL}},{{5L,5L,0L,0x05CAL,5L},{1L,0x2F53L,0xEAD8L,0x77E3L,0x5849L},{(-1L),0L,0x064DL,0L,(-1L)},{0x6A9FL,0x2F53L,0x7431L,(-1L),0x992FL},{0x05CAL,5L,0x56DBL,8L,8L}}};
static volatile uint32_t g_3348[5][5][9] = {{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}}};
static uint32_t g_3363 = 4294967286UL;
static int32_t g_3375 = (-1L);
static uint32_t g_3383[6] = {0x3C3ECF92L,0x3C3ECF92L,0x3C3ECF92L,0x3C3ECF92L,0x3C3ECF92L,0x3C3ECF92L};
static int32_t ** volatile g_3402 = &g_249;/* VOLATILE GLOBAL g_3402 */
static int32_t ** volatile g_3410 = &g_174;/* VOLATILE GLOBAL g_3410 */
static int32_t ** volatile g_3418 = &g_159[8][0];/* VOLATILE GLOBAL g_3418 */
static uint64_t g_3458 = 18446744073709551614UL;
static uint32_t ***g_3470[5][5][1] = {{{&g_1206},{&g_1206},{&g_1206},{&g_1206},{&g_1206}},{{&g_1206},{&g_1206},{&g_1206},{&g_1206},{&g_1206}},{{&g_1206},{&g_1206},{&g_1206},{&g_1206},{&g_1206}},{{&g_1206},{&g_1206},{&g_1206},{&g_1206},{&g_1206}},{{&g_1206},{&g_1206},{&g_1206},{&g_1206},{&g_1206}}};
static uint32_t ****g_3469 = &g_3470[3][4][0];
static uint16_t g_3479 = 0x884AL;
static int8_t g_3484 = (-10L);
static int32_t * volatile g_3485[9][2] = {{&g_2815,&g_6},{&g_2713,&g_2713},{&g_2713,&g_6},{&g_2815,&g_2},{&g_6,&g_2},{&g_2815,&g_6},{&g_2713,&g_2713},{&g_2713,&g_6},{&g_2815,&g_2}};
static int8_t g_3531 = 0x77L;
static uint8_t g_3540 = 0xA2L;
static int8_t ****g_3583 = &g_3261;
static int32_t g_3587 = 0x3E651C06L;
static int16_t **g_3596 = &g_1469;
static const uint32_t **g_3611[1] = {&g_1027};
static const uint32_t *** const  volatile g_3610 = &g_3611[0];/* VOLATILE GLOBAL g_3610 */
static int8_t g_3624 = 0x0AL;
static uint64_t g_3626 = 0xF8771FF2D0E0B3FALL;
static int32_t ** volatile g_3645 = &g_174;/* VOLATILE GLOBAL g_3645 */
static int32_t ** volatile g_3652 = &g_174;/* VOLATILE GLOBAL g_3652 */
static int32_t ** volatile g_3654[4] = {&g_249,&g_249,&g_249,&g_249};
static int32_t ** volatile g_3655[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** volatile g_3704 = &g_159[3][0];/* VOLATILE GLOBAL g_3704 */
static int8_t ** const *g_3765 = (void*)0;
static int8_t ** const **g_3764 = &g_3765;
static int16_t g_3872 = 0x342CL;
static int16_t g_3916[4][10][4] = {{{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L}},{{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L}},{{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L}},{{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L},{0L,0L,0L,0L}}};
static uint16_t g_3987 = 0x931AL;
static int32_t ** volatile g_3994 = &g_159[8][0];/* VOLATILE GLOBAL g_3994 */
static uint32_t g_4139 = 0xF2A6EF53L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_9(int16_t  p_10);
static int16_t  func_13(const uint8_t  p_14);
static uint8_t  func_15(int16_t  p_16, uint64_t  p_17, int32_t  p_18, const uint64_t  p_19, uint32_t  p_20);
static const int8_t  func_23(const int32_t  p_24, int64_t  p_25);
static int8_t  func_28(int8_t  p_29, uint16_t  p_30, int32_t  p_31);
static int8_t  func_39(uint32_t  p_40, uint32_t  p_41);
static uint32_t  func_45(const int32_t  p_46, int64_t  p_47);
static const uint16_t  func_56(int32_t * p_57, const uint8_t  p_58, int32_t * p_59);
static int32_t * func_60(int32_t  p_61, uint64_t  p_62);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_174 g_1040 g_1041 g_100 g_2942 g_1543 g_101 g_1917 g_1918 g_715 g_1586 g_702 g_249 g_1513 g_149 g_6 g_3261 g_3262 g_185 g_1206 g_1207 g_3289 g_3292 g_3290 g_884 g_922 g_575 g_3317 g_2113 g_3333 g_3348 g_3363 g_1501 g_478 g_479 g_477 g_3375 g_3383 g_1542 g_3402 g_118 g_1916 g_3458 g_1387 g_528 g_3469 g_211 g_3296 g_2108 g_1486 g_3645 g_113 g_2320 g_79 g_1212 g_3096 g_3872 g_2025 g_3916 g_1531 g_3583 g_3610 g_3611 g_4139 g_2815 g_1208
 * writes: g_2 g_6 g_249 g_3195 g_101 g_1543 g_2113 g_2025 g_2815 g_149 g_3261 g_3262 g_1208 g_3289 g_1486 g_185 g_575 g_1404 g_159 g_327 g_3363 g_151 g_2445 g_3469 g_3479 g_3484 g_113 g_79 g_528 g_3611
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_5[3][7] = {{0UL,5UL,0UL,5UL,0UL,5UL,0UL},{8UL,0x0EL,0x0EL,8UL,8UL,0x0EL,0x0EL},{0xCFL,5UL,0xCFL,5UL,0xCFL,5UL,0xCFL}};
    uint64_t l_11[6];
    const int8_t l_1951[9][9] = {{0x4FL,(-1L),0xA3L,(-1L),0x4FL,0x4FL,(-1L),0xA3L,(-1L)},{0L,(-1L),2L,2L,(-1L),0L,(-1L),2L,2L},{0x4FL,0x4FL,(-1L),0xA3L,(-1L),0x4FL,0x4FL,(-1L),0xA3L},{0L,(-1L),0L,0L,0L,0L,(-1L),0L,0L},{0x47L,(-1L),(-1L),0x47L,0L,0x47L,(-1L),(-1L),0x47L},{0xC9L,0L,2L,0L,0xC9L,0xC9L,0L,2L,0L},{(-1L),0L,0xA3L,0xA3L,0L,(-1L),0L,0xA3L,0xA3L},{0xC9L,0xC9L,0L,2L,0L,0xC9L,0xC9L,0L,2L},{0x47L,0L,0x47L,(-1L),(-1L),0x47L,0L,0x47L,(-1L)}};
    int32_t l_2928[2];
    uint32_t l_2962[3];
    uint32_t l_2980 = 0x03E1E1D8L;
    int32_t l_2985 = (-5L);
    int32_t l_2988 = 9L;
    int64_t l_3014 = 5L;
    uint8_t l_3048 = 0x44L;
    uint16_t * const *l_3093 = &g_100;
    uint16_t * const **l_3092[5] = {&l_3093,&l_3093,&l_3093,&l_3093,&l_3093};
    uint16_t * const ***l_3091 = &l_3092[3];
    uint16_t * const ****l_3090[9] = {&l_3091,&l_3091,&l_3091,&l_3091,&l_3091,&l_3091,&l_3091,&l_3091,&l_3091};
    uint8_t l_3157 = 0x98L;
    const uint32_t l_3181[3] = {4294967295UL,4294967295UL,4294967295UL};
    uint64_t **l_3194 = &g_2543[0][2];
    uint64_t ***l_3193 = &l_3194;
    int64_t *l_3207 = &l_3014;
    uint64_t *l_3215[2][3] = {{&g_113,&g_113,&g_113},{&g_702,&g_702,&g_702}};
    int32_t l_3216 = 0x6321AE02L;
    int16_t *l_3217 = &g_1543;
    int16_t l_3218 = 0L;
    uint8_t *l_3223 = &g_2113[2];
    uint8_t *l_3234 = &g_2025;
    int8_t **l_3250[6];
    int16_t l_3255 = 1L;
    uint64_t l_3256 = 0xE14311D3215DC33ALL;
    const uint64_t l_3274[4][4][5] = {{{18446744073709551608UL,0x7C07EF2A0E177B68LL,6UL,1UL,0xF30E0A3A9C57F45FLL},{0xDD851F012A9DFC6ELL,0x77572588D0D8755CLL,0x77572588D0D8755CLL,0xDD851F012A9DFC6ELL,18446744073709551612UL},{0UL,5UL,0xEB516E4C1E721370LL,9UL,9UL},{5UL,6UL,18446744073709551611UL,0x06FD0FF8A4B1CED8LL,0x77572588D0D8755CLL}},{{0x7C07EF2A0E177B68LL,0UL,9UL,9UL,0UL},{0x287667A6B9FD5EFALL,0xF9D395A16FC0F6A4LL,0xFE0C392ABFD60D40LL,0xDD851F012A9DFC6ELL,0UL},{0xDE1347C541DB2BDCLL,0xF30E0A3A9C57F45FLL,18446744073709551608UL,0x7C07EF2A0E177B68LL,6UL},{0xDD851F012A9DFC6ELL,1UL,0UL,5UL,5UL}},{{18446744073709551612UL,1UL,18446744073709551612UL,0UL,0x03DEBA3D8496234FLL},{18446744073709551613UL,0xA019F0E0620DD66BLL,0xF9D395A16FC0F6A4LL,0xDD851F012A9DFC6ELL,0x3A7F9082CC7648F0LL},{0xF30E0A3A9C57F45FLL,0x7C07EF2A0E177B68LL,9UL,18446744073709551608UL,0xAE47B5F426E45319LL},{6UL,0x3A7F9082CC7648F0LL,0xF9D395A16FC0F6A4LL,0x3A7F9082CC7648F0LL,6UL}},{{0xEB516E4C1E721370LL,18446744073709551615UL,18446744073709551612UL,5UL,18446744073709551608UL},{0x287667A6B9FD5EFALL,0x77572588D0D8755CLL,0UL,0x06FD0FF8A4B1CED8LL,0UL},{18446744073709551611UL,18446744073709551612UL,18446744073709551608UL,18446744073709551615UL,18446744073709551608UL},{0x06FD0FF8A4B1CED8LL,0x06FD0FF8A4B1CED8LL,0xA019F0E0620DD66BLL,0UL,6UL}}};
    uint8_t l_3277 = 3UL;
    uint64_t l_3315 = 0x6AC2590141FCBEAELL;
    uint32_t l_3334[5][2][1] = {{{0x4C3AC9FFL},{18446744073709551615UL}},{{0x6E96A368L},{0x6E96A368L}},{{18446744073709551615UL},{0x4C3AC9FFL}},{{18446744073709551615UL},{0x6E96A368L}},{{0x6E96A368L},{18446744073709551615UL}}};
    const uint32_t **l_3347 = &g_1027;
    int64_t l_3360[10] = {6L,(-1L),2L,2L,(-1L),6L,(-1L),2L,2L,(-1L)};
    const int8_t *l_3397 = &l_1951[3][6];
    int32_t l_3406 = 0xD8FA1E67L;
    uint32_t l_3431 = 0UL;
    int32_t l_3473 = 0x371EC2CBL;
    int32_t l_3474 = 0x2099146BL;
    int32_t l_3475 = 1L;
    uint8_t l_3476 = 0x66L;
    int64_t **l_3496 = (void*)0;
    int64_t ***l_3495 = &l_3496;
    uint32_t l_3499 = 8UL;
    uint64_t l_3551 = 18446744073709551610UL;
    int64_t l_3576 = (-1L);
    int32_t l_3635 = 3L;
    int32_t l_3643 = 7L;
    int32_t *l_3651[5] = {&g_6,&g_6,&g_6,&g_6,&g_6};
    int16_t ***l_3670 = &g_1468;
    int16_t **** const l_3669 = &l_3670;
    int64_t l_3702 = 7L;
    int8_t ****l_3761[10][7][3] = {{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,(void*)0,(void*)0},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{(void*)0,(void*)0,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}},{{&g_3261,&g_3261,&g_3261},{&g_3261,(void*)0,(void*)0},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261},{&g_3261,&g_3261,&g_3261}}};
    int8_t ** const *l_3763 = &l_3250[0];
    int8_t ** const **l_3762 = &l_3763;
    uint8_t l_3768 = 0x9FL;
    int64_t l_3785 = 0x24FC5B75D8B608C1LL;
    uint64_t l_3788 = 0xD72519CCC40957B0LL;
    const int64_t l_3789 = (-3L);
    uint8_t l_3794 = 0UL;
    int32_t l_3795 = 1L;
    int64_t l_3796 = 8L;
    uint8_t l_3797[2][9][5] = {{{255UL,1UL,255UL,1UL,255UL},{1UL,1UL,251UL,251UL,1UL},{0xFEL,1UL,0xFEL,1UL,0xFEL},{1UL,251UL,251UL,1UL,1UL},{255UL,1UL,255UL,1UL,255UL},{1UL,1UL,251UL,251UL,1UL},{0xFEL,1UL,0xFEL,1UL,0xFEL},{1UL,251UL,251UL,1UL,1UL},{255UL,1UL,255UL,1UL,255UL}},{{1UL,1UL,251UL,251UL,1UL},{0xFEL,1UL,0xFEL,1UL,0xFEL},{1UL,251UL,251UL,1UL,1UL},{255UL,1UL,255UL,1UL,255UL},{1UL,1UL,251UL,251UL,1UL},{0xFEL,1UL,0xFEL,1UL,0xFEL},{1UL,251UL,251UL,1UL,1UL},{255UL,1UL,255UL,1UL,255UL},{1UL,1UL,251UL,251UL,1UL}}};
    uint8_t l_3798[5] = {5UL,5UL,5UL,5UL,5UL};
    uint32_t l_3813[5] = {18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL,18446744073709551607UL};
    int8_t l_3894 = 0L;
    uint8_t l_3915 = 0xE0L;
    int32_t l_3917[2];
    uint8_t l_3976 = 0x59L;
    uint64_t l_3988 = 0xF43AD1E85BFB7483LL;
    int8_t l_4006 = 0xBDL;
    int32_t l_4009 = 1L;
    uint16_t ***l_4043[2][6] = {{&g_1041,&g_1041,&g_1041,&g_1041,&g_1041,&g_1041},{&g_1041,&g_1041,&g_1041,&g_1041,&g_1041,&g_1041}};
    int16_t ***l_4049 = (void*)0;
    uint32_t *l_4055 = (void*)0;
    uint32_t l_4071 = 0xE58713B4L;
    int8_t l_4116 = 0x2CL;
    int64_t l_4130 = 0x603220A8692E85F6LL;
    uint32_t ***l_4135 = &g_1206;
    int32_t l_4141 = 0xDDFF4DAEL;
    int8_t l_4159 = 0x9AL;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_11[i] = 1UL;
    for (i = 0; i < 2; i++)
        l_2928[i] = 9L;
    for (i = 0; i < 3; i++)
        l_2962[i] = 1UL;
    for (i = 0; i < 6; i++)
        l_3250[i] = &g_1513;
    for (i = 0; i < 2; i++)
        l_3917[i] = 0x38D7BCDEL;
    for (g_2 = (-29); (g_2 > (-18)); g_2 = safe_add_func_uint16_t_u_u(g_2, 1))
    { /* block id: 3 */
        int16_t l_49 = 6L;
        int32_t l_999 = 0x0948B379L;
        int32_t l_2321 = 1L;
        uint16_t l_3025 = 0xD316L;
        int16_t l_3049 = 7L;
        const uint64_t l_3114[5][2] = {{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL}};
        int32_t l_3165 = 1L;
        int32_t l_3166[10][5] = {{0x3C9944B2L,(-1L),2L,(-1L),(-1L)},{(-2L),1L,(-2L),(-1L),0L},{0xF3E25044L,0x6DBD3C0DL,0x90CA3E33L,2L,0x3C9944B2L},{1L,0L,0x488B717AL,(-1L),(-1L)},{(-1L),0L,0x90CA3E33L,0x3C9944B2L,0xAB8899F2L},{0x730A2076L,1L,(-2L),(-2L),1L},{(-1L),1L,2L,0xF3E25044L,0x44DC442CL},{0x54C11246L,0L,0xAB8899F2L,1L,(-1L)},{0x90CA3E33L,0L,0x54C11246L,(-1L),(-6L)},{0x54C11246L,0x6DBD3C0DL,(-1L),0x730A2076L,2L}};
        uint8_t l_3168 = 255UL;
        int32_t **l_3183 = &g_249;
        int i, j;
        for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
        { /* block id: 6 */
            uint32_t l_34[9][3] = {{0xCB6D64BDL,6UL,0xCB6D64BDL},{1UL,1UL,1UL},{0xCB6D64BDL,6UL,0xCB6D64BDL},{1UL,1UL,1UL},{0xCB6D64BDL,6UL,0xCB6D64BDL},{1UL,1UL,1UL},{0xCB6D64BDL,6UL,0xCB6D64BDL},{1UL,1UL,1UL},{0xCB6D64BDL,6UL,0xCB6D64BDL}};
            int32_t *l_48 = (void*)0;
            uint8_t l_1002 = 0x6EL;
            int64_t *l_1403 = &g_1404;
            int16_t l_2935[8];
            int32_t l_3013[3][10] = {{3L,2L,0xCE685B41L,1L,0xCE685B41L,2L,3L,3L,2L,0xCE685B41L},{2L,3L,3L,2L,0xCE685B41L,1L,0xCE685B41L,2L,3L,3L},{0xCE685B41L,3L,0x36BBB234L,1L,1L,0x36BBB234L,3L,0xCE685B41L,3L,0x36BBB234L}};
            const int8_t l_3051[7][4] = {{0x7BL,0x7BL,0x43L,(-1L)},{0L,0x0EL,0L,0x43L},{0L,0x43L,0x43L,0L},{0x7BL,0x43L,(-1L),0x43L},{0x43L,0x0EL,(-1L),(-1L)},{0x7BL,0x7BL,0x43L,(-1L)},{0L,0x0EL,0L,0x43L}};
            int32_t ***l_3057 = &g_2091;
            uint8_t l_3062 = 255UL;
            uint32_t *l_3101 = &g_2319;
            int32_t l_3163[9][9] = {{3L,3L,3L,3L,3L,3L,3L,3L,3L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{3L,3L,3L,3L,3L,3L,3L,3L,3L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{3L,3L,3L,3L,3L,3L,3L,3L,3L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{3L,3L,3L,3L,3L,3L,3L,3L,3L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{3L,3L,3L,3L,3L,3L,3L,3L,3L}};
            int i, j;
            for (i = 0; i < 8; i++)
                l_2935[i] = 0L;
        }
        (*l_3183) = &l_2985;
        (*g_174) = 0x699EF3B8L;
        for (l_999 = 0; (l_999 <= 6); ++l_999)
        { /* block id: 1474 */
            l_2928[1] |= 0L;
        }
    }
    (*g_174) = (+(safe_lshift_func_uint16_t_u_s((0L >= ((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s((((*l_3193) = &g_2543[3][0]) != (g_3195[1][1] = (void*)0)), (((~(safe_sub_func_uint64_t_u_u((((safe_add_func_int32_t_s_s((((safe_mul_func_int16_t_s_s((l_2988 < ((l_3181[0] > ((safe_mod_func_uint16_t_u_u((((***g_1040) = (((*l_3207) = l_11[5]) != l_5[2][2])) == ((*l_3217) |= (safe_rshift_func_uint16_t_u_u((((~((safe_mod_func_uint32_t_u_u(l_3157, (safe_add_func_uint64_t_u_u((l_2985 = (g_2942 , 0x25A8826BA2BAB33ELL)), 0UL)))) == l_2928[1])) & (-1L)) && l_3216), l_2980)))), 65535UL)) , (-4L))) <= l_2928[1])), 5L)) , l_5[0][2]) < 5L), l_11[5])) ^ 0x02L) && l_11[5]), l_3181[1]))) , l_3218) , l_2962[1]))), 0L)) , l_11[4])), l_3157)));
lbl_3816:
    if (((*g_249) = (safe_lshift_func_uint16_t_u_s(l_3216, ((safe_div_func_int8_t_s_s(2L, ((*l_3223) = l_3216))) <= ((((safe_mod_func_uint8_t_u_u(((*l_3234) = (safe_add_func_int64_t_s_s((((7L || (-2L)) == (((**g_1041)++) && (safe_lshift_func_int16_t_s_u((**g_1917), (safe_rshift_func_int16_t_s_s(0x683DL, 15)))))) < (*g_1586)), (*g_1586)))), 0x32L)) < l_3014) == l_11[5]) , 0x0644L))))))
    { /* block id: 1489 */
        uint64_t l_3237 = 0xDB6A5336C1D8C6FELL;
        int32_t ****l_3242 = &g_2090;
        uint16_t ***** const l_3254 = (void*)0;
        int16_t l_3260 = 1L;
        int8_t ***l_3264 = (void*)0;
        uint32_t l_3280 = 4294967288UL;
        int8_t l_3306 = 0x35L;
        int32_t l_3311 = 8L;
        uint8_t l_3332[6];
        int32_t l_3357 = (-2L);
        int32_t l_3358 = 0x4A7AACDEL;
        int32_t l_3359 = (-6L);
        int32_t l_3361[5][1] = {{0xA6D2C74AL},{(-10L)},{0xA6D2C74AL},{(-10L)},{0xA6D2C74AL}};
        int64_t l_3389[3];
        int i, j;
        for (i = 0; i < 6; i++)
            l_3332[i] = 0UL;
        for (i = 0; i < 3; i++)
            l_3389[i] = 0xB027F9E61E85CE5CLL;
        for (g_2815 = 0; (g_2815 >= 15); ++g_2815)
        { /* block id: 1492 */
            int8_t ***l_3247 = (void*)0;
            int8_t **l_3249 = &g_1513;
            int8_t ***l_3248 = &l_3249;
            int8_t ***l_3251 = (void*)0;
            int8_t ***l_3252 = (void*)0;
            int8_t ***l_3253[3];
            int32_t l_3257[3];
            int i;
            for (i = 0; i < 3; i++)
                l_3253[i] = &l_3250[0];
            for (i = 0; i < 3; i++)
                l_3257[i] = 1L;
            l_3216 |= l_3237;
            (*g_174) = (safe_add_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u(((*g_1513) & 8UL), (l_3242 == &g_520))), ((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((&g_1542 != ((((*l_3248) = &g_1513) == (l_3250[2] = l_3250[0])) , l_3254)) == l_3255), l_3256)), l_3257[1])) , l_3257[1])));
        }
lbl_3401:
        for (g_149 = 0; (g_149 == 10); g_149++)
        { /* block id: 1500 */
            int8_t ****l_3263 = &g_3261;
            int32_t l_3273 = 5L;
            (*g_174) |= l_2985;
            (*g_249) = (((l_3260 , l_2988) > (((((*l_3263) = g_3261) != l_3264) > (safe_rshift_func_int8_t_s_s(l_3181[1], 2))) & (safe_mul_func_int16_t_s_s((safe_div_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((0xCA6AL > 0x701BL), 0L)), (l_3273 , 0xC875BD73L))), 0xCD2BL)))) && l_3274[3][3][2]);
            (**l_3263) = (**l_3263);
        }
        if ((safe_sub_func_uint64_t_u_u((g_185 | 0x001D8774B3B8D579LL), ((((0UL > (*g_1513)) <= ((((((l_11[5] | (((**g_1206) = l_3277) , (&l_3264 != (void*)0))) < ((((*l_3217) = (safe_rshift_func_uint8_t_u_u(4UL, l_3280))) <= l_2962[0]) , 0L)) , (void*)0) != (***l_3091)) & 0x1BDCL) & l_3280)) , 0x328F3BF4L) > 0xDA26E771L))))
        { /* block id: 1508 */
            const int8_t ***l_3291 = &g_3289[0][1][0];
            uint32_t ***l_3298 = &g_1206;
            uint32_t ****l_3297 = &l_3298;
            int32_t l_3305 = (-1L);
            int32_t *l_3307[9] = {&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734};
            uint16_t l_3308 = 0x566FL;
            int i;
            (*g_249) |= (safe_mul_func_int16_t_s_s((**g_1917), ((safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u((((g_1486[2][0][4] = (((*g_1513) = (&g_3262 == ((((**g_1041) = (safe_sub_func_uint32_t_u_u(((((((((*l_3291) = g_3289[0][6][0]) != (void*)0) != 0x06L) , g_3292) == l_3297) ^ (safe_div_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((!(+l_3181[2])), 2)), (((*g_3290) & l_3305) , 0xEAE08F87E96C7CA7LL)))) <= l_5[1][6]), l_3306))) | 0UL) , (void*)0))) && 0x46L)) , 0x843DB8ACCACB5620LL) < l_3305), 0xA16D9387L)), l_3308)) | (*g_3290))));
            for (g_185 = 0; (g_185 <= 30); g_185 = safe_add_func_uint32_t_u_u(g_185, 9))
            { /* block id: 1516 */
                const int32_t **l_3312 = &g_575;
                l_3311 = ((*g_249) = l_3305);
                (*l_3312) = (*g_922);
            }
            for (g_1404 = (-2); (g_1404 != 0); g_1404++)
            { /* block id: 1523 */
                return l_3315;
            }
            (*g_3317) = &l_3311;
        }
        else
        { /* block id: 1527 */
            int16_t l_3320 = (-1L);
            int64_t **l_3329 = &g_589;
            int64_t *** const l_3328 = &l_3329;
            int32_t l_3331 = 2L;
            const uint32_t **l_3346 = &g_1027;
            int32_t l_3362 = 0x0FF0ECC3L;
            int32_t l_3368 = (-10L);
            int16_t l_3388 = (-4L);
            uint16_t l_3394 = 0x8C60L;
            int8_t *l_3398 = &l_3306;
            if (((((((*l_3223)++) , (*g_100)) <= l_3320) | (!((((safe_sub_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(l_2985, 3)), ((safe_add_func_uint8_t_u_u((l_3328 == ((l_3331 |= (!0xCA8FL)) , &l_3329)), (l_3157 <= 246UL))) , (l_3332[1] , g_3333[3][3][0])))) || l_3334[2][0][0]) != 7L) , l_3320))) <= l_3332[5]))
            { /* block id: 1530 */
                int16_t ** const *l_3335 = (void*)0;
                int32_t l_3339[8] = {0x447ED113L,0L,0x447ED113L,0x447ED113L,0L,0x447ED113L,0x447ED113L,0L};
                int i;
                (*g_174) &= (((0xB438L & ((void*)0 != l_3335)) <= ((*l_3223) &= (+((((*g_1513) = (l_2928[0] = (safe_lshift_func_uint8_t_u_s((253UL != (l_3339[2] == (safe_mod_func_int8_t_s_s(9L, (safe_div_func_int32_t_s_s((safe_mod_func_uint8_t_u_u((((l_3346 != l_3347) < (&l_3320 == &l_3320)) || 4UL), g_3348[3][3][3])), 7L)))))), 4)))) > 255UL) > 2UL)))) || 0x825C0C37L);
                for (g_327 = 19; (g_327 > 48); g_327 = safe_add_func_int8_t_s_s(g_327, 3))
                { /* block id: 1537 */
                    int32_t l_3351 = (-1L);
                    int32_t *l_3352 = (void*)0;
                    int32_t *l_3353 = &g_2713;
                    int32_t *l_3354 = &l_3331;
                    int32_t *l_3355 = &l_2928[0];
                    int32_t *l_3356[1][8][3];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 8; j++)
                        {
                            for (k = 0; k < 3; k++)
                                l_3356[i][j][k] = &l_3339[2];
                        }
                    }
                    g_3363++;
                    for (g_149 = (-3); (g_149 >= (-24)); --g_149)
                    { /* block id: 1541 */
                        if ((**g_1501))
                            break;
                        return (*g_478);
                    }
                }
            }
            else
            { /* block id: 1546 */
                uint32_t l_3380[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_3380[i] = 0xEEBACDFFL;
                (*g_174) = ((l_3368 ^ ((safe_sub_func_int32_t_s_s((safe_mod_func_uint32_t_u_u((**g_477), g_3375)), (safe_mul_func_int8_t_s_s((*g_3290), l_3331)))) != ((safe_sub_func_uint8_t_u_u((l_3380[3] < ((((safe_rshift_func_uint16_t_u_s(g_3383[5], (safe_add_func_uint32_t_u_u((safe_div_func_int64_t_s_s((((((void*)0 == &g_1040) , l_3388) | l_3380[3]) | (****g_1542)), 0x993271FFE0F2C3EALL)), (*g_249))))) , 0x9853DDE5L) == l_3368) <= l_3389[0])), g_702)) > 0x4A26L))) <= l_3255);
                (*g_249) = (safe_add_func_int16_t_s_s((l_3014 > 0xA5647110L), (safe_div_func_uint16_t_u_u((l_3394 > (safe_lshift_func_int16_t_s_u((l_3397 == (l_3398 = &g_149)), (safe_mod_func_uint64_t_u_u(l_3380[3], l_5[0][0]))))), l_3331))));
                if (g_2)
                    goto lbl_3401;
            }
        }
    }
    else
    { /* block id: 1553 */
        const uint64_t l_3403 = 1UL;
        uint32_t **l_3416[9][2][6] = {{{&g_1387,&g_1387,&g_1387,(void*)0,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,(void*)0,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,(void*)0,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,(void*)0,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,(void*)0,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,(void*)0,&g_1387,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,(void*)0,&g_1387}},{{&g_1387,&g_1387,&g_1387,&g_1387,(void*)0,&g_1387},{&g_1387,&g_1387,&g_1387,&g_1387,&g_1387,&g_1387}}};
        uint32_t ***l_3415 = &l_3416[1][1][2];
        int32_t *l_3417 = &g_118;
        int32_t l_3429 = (-6L);
        int8_t l_3448 = (-1L);
        uint8_t l_3449[10][3] = {{0UL,0x48L,0UL},{1UL,0x5FL,0xA0L},{0xF8L,0x5FL,0x37L},{248UL,0x48L,0x52L},{0x3EL,254UL,254UL},{254UL,0xA0L,0x37L},{0UL,248UL,0x37L},{0x5FL,0x37L,254UL},{0x35L,0x48L,0xF8L},{0x37L,0x37L,0x48L}};
        int8_t l_3497 = (-2L);
        int64_t l_3498 = 0x4EFABD15A07C2925LL;
        int32_t l_3512 = 0x7F020541L;
        const int8_t *** const *l_3517 = (void*)0;
        uint64_t l_3530 = 0xCB3FA820A963559ELL;
        int32_t l_3534[6];
        uint16_t l_3586 = 7UL;
        int16_t l_3620 = (-1L);
        int32_t **l_3715 = &l_3417;
        uint16_t l_3727[8] = {0x7FC6L,0x3659L,0x7FC6L,0x3659L,0x7FC6L,0x3659L,0x7FC6L,0x3659L};
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_3534[i] = (-5L);
        (*g_3402) = &l_2928[0];
        if (l_3403)
        { /* block id: 1555 */
            int8_t l_3409[4];
            int16_t *l_3411 = &g_2445;
            uint32_t ** const *l_3414 = (void*)0;
            int32_t l_3427 = 4L;
            int32_t l_3430 = 0xAD23D9C9L;
            int i;
            for (i = 0; i < 4; i++)
                l_3409[i] = 0xF8L;
            for (g_151 = (-13); (g_151 > 0); g_151++)
            { /* block id: 1558 */
                uint16_t *l_3407 = (void*)0;
                (*g_174) |= (l_3403 != l_3406);
                (*g_174) ^= ((void*)0 == l_3407);
            }
            for (g_2445 = 2; (g_2445 >= 0); g_2445 -= 1)
            { /* block id: 1564 */
                uint8_t l_3408 = 0x5DL;
                int32_t l_3419 = 0xF4CDCD32L;
                int32_t *l_3420 = (void*)0;
                int32_t *l_3421 = &g_2713;
                int32_t *l_3422 = &l_2928[1];
                int32_t *l_3423 = &l_2928[1];
                int32_t *l_3424 = &g_118;
                int32_t *l_3425 = &g_2;
                int32_t *l_3426[5][6][3] = {{{&g_2815,&l_2985,(void*)0},{&g_2815,&g_2713,&g_6},{&g_2815,(void*)0,&g_2815},{&g_2815,&g_118,(void*)0},{&g_2815,&g_2815,&l_2928[0]},{&l_3216,(void*)0,(void*)0}},{{&l_2985,&l_2985,(void*)0},{(void*)0,&g_3375,&l_2928[1]},{&g_2713,&l_2985,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_2713,&g_2815,&l_2928[0]},{&g_2815,&g_118,(void*)0}},{{&g_2815,&l_3216,&g_2815},{(void*)0,&l_2928[0],&g_6},{(void*)0,&l_2928[0],(void*)0},{(void*)0,&l_3216,(void*)0},{(void*)0,&g_118,(void*)0},{&l_2928[1],&g_2815,(void*)0}},{{&l_3216,(void*)0,(void*)0},{(void*)0,&l_2985,(void*)0},{&l_2985,&g_3375,&g_2815},{(void*)0,&l_2985,&l_3216},{&l_3216,(void*)0,(void*)0},{&l_2928[1],&g_2815,&l_2928[1]}},{{(void*)0,&g_118,(void*)0},{(void*)0,(void*)0,&l_2985},{(void*)0,&g_2713,&l_2985},{(void*)0,&l_2985,(void*)0},{&g_2815,&l_2928[1],&l_2928[1]},{&g_2815,(void*)0,(void*)0}}};
                int16_t l_3428[7][3] = {{0xDAA8L,3L,(-1L)},{3L,0xDAA8L,(-1L)},{0x60EEL,0x60EEL,(-1L)},{0xDAA8L,3L,(-1L)},{3L,0xDAA8L,(-1L)},{0x60EEL,0x60EEL,(-1L)},{0xDAA8L,3L,(-1L)}};
                int i, j, k;
            }
            return l_3014;
        }
        else
        { /* block id: 1575 */
            int32_t l_3442 = 2L;
            int32_t l_3445 = (-1L);
            int32_t l_3446 = 0x23B2840FL;
            int32_t l_3447[10][5] = {{0x2399228BL,0x5E0A2A4BL,(-1L),0x7B1CB987L,0x400436DEL},{0x5E55B566L,(-1L),0xCEF4287EL,(-1L),0x5E55B566L},{1L,0x5E0A2A4BL,8L,0x5E55B566L,(-2L)},{1L,(-2L),0x400436DEL,3L,3L},{0x5E55B566L,1L,0x5E55B566L,0x5E0A2A4BL,(-2L)},{0x2399228BL,3L,(-2L),0x5E0A2A4BL,0x5E55B566L},{(-2L),0x400436DEL,3L,3L,0x400436DEL},{0x400436DEL,(-10L),(-2L),0x5E55B566L,8L},{1L,(-10L),0x5E55B566L,(-1L),0xCEF4287EL},{0x7B1CB987L,0x400436DEL,0x400436DEL,0x7B1CB987L,(-1L)}};
            int32_t l_3459 = 2L;
            int64_t ****l_3468 = (void*)0;
            uint32_t *****l_3471[10];
            int32_t *l_3486 = (void*)0;
            int i, j;
            for (i = 0; i < 10; i++)
                l_3471[i] = (void*)0;
            l_3459 &= ((l_3274[2][1][1] | (safe_mod_func_uint32_t_u_u(((safe_rshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u((*l_3417), 6)), 7)) > ((**l_3093) = ((*l_3193) == (((safe_div_func_int64_t_s_s(l_3442, (*l_3417))) > (safe_sub_func_uint64_t_u_u((++l_3449[8][1]), (((*l_3417) >= l_3442) > (((safe_mul_func_int16_t_s_s(((*l_3217) = (((*l_3207) = ((safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((**g_1917), ((((*g_174) = 0xD8487A52L) >= l_3445) || 0xF4L))), l_3446)) && (*g_174))) , (***g_1916))), (****g_1542))) && g_3458) <= (*l_3417)))))) , (void*)0)))), (*g_1387)))) > l_3447[7][3]);
            l_3442 ^= (safe_lshift_func_uint16_t_u_u(((((l_2928[1] ^ (g_3484 = ((safe_rshift_func_uint8_t_u_u((((*l_3234) = (safe_div_func_int8_t_s_s((((safe_mul_func_int8_t_s_s((252UL >= ((((void*)0 == l_3468) , (&g_3293 != (g_3469 = g_3469))) & ((((((~(*g_1387)) != (g_3479 = (++l_3476))) >= (((safe_mod_func_uint64_t_u_u((*l_3417), (safe_add_func_uint16_t_u_u((****g_1542), 0x6396L)))) || 5UL) != l_3218)) , l_3445) || l_3446) && 5L))), 0x12L)) <= l_3181[1]) < 4294967295UL), 0x5AL))) != 0L), (*l_3417))) , (*g_174)))) > (*l_3417)) , (*l_3417)) || l_3181[2]), 4));
        }
    }
    if ((((l_3768 <= (safe_sub_func_int32_t_s_s(((*g_174) = (((((((*g_100) = (safe_mul_func_uint8_t_u_u(((safe_rshift_func_int8_t_s_s((*g_3290), 6)) <= (safe_lshift_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((((safe_add_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(g_211[1], (((safe_div_func_int8_t_s_s((*g_3290), l_3785)) < ((*l_3207) &= 0x66BA2D316ABFF2AELL)) != (safe_mul_func_uint8_t_u_u((l_3788 ^ ((l_3789 , (safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(65535UL, (*g_100))), g_101))) | l_3794)), g_3296))))), (*g_3290))) && (**g_2108)) == g_528[1]), l_3795)) && (*g_1918)), 5))), (*g_3290)))) | 0xDF2AL) && l_3796) & (*g_1586)) == l_3797[0][5][1]) | l_3798[1])), (*g_1387)))) >= (*g_3290)) == (*g_1513)))
    { /* block id: 1767 */
        int16_t l_3805 = 0x52CDL;
        uint32_t l_3811 = 18446744073709551606UL;
        int32_t l_3812 = 0xEFE4A0ABL;
        int8_t l_3825 = 1L;
        uint32_t ****l_3841[3][8] = {{(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0,(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0},{(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0,(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0},{(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0,(void*)0,&g_3470[3][4][0],&g_3470[3][4][0],(void*)0}};
        uint64_t l_3918 = 18446744073709551615UL;
        uint32_t l_3923[3];
        int64_t l_3928 = 1L;
        int32_t l_3968 = 0xD149AE66L;
        int32_t l_3969[1][9][2] = {{{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}}};
        const int16_t l_3983 = 0L;
        int32_t *l_4003 = (void*)0;
        int64_t l_4014 = 0x33E8C30411483077LL;
        uint32_t l_4021 = 0x5980D7D6L;
        uint16_t l_4038[1][8][2] = {{{0xFB6BL,6UL},{6UL,0xFB6BL},{6UL,6UL},{0xFB6BL,6UL},{6UL,0xFB6BL},{6UL,6UL},{0xFB6BL,6UL},{6UL,0xFB6BL}}};
        const int8_t l_4087 = 0L;
        int32_t l_4088 = 0xF1E67672L;
        int8_t l_4138 = 0x5AL;
        uint8_t l_4140 = 0x9BL;
        uint32_t l_4142[2];
        uint32_t l_4143 = 0xEE46C5EEL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_3923[i] = 4294967294UL;
        for (i = 0; i < 2; i++)
            l_4142[i] = 0x11B73388L;
        (*g_174) = ((safe_mod_func_int64_t_s_s(((((l_3812 = ((((g_1486[2][1][4] , ((((safe_div_func_int32_t_s_s(((l_3805 >= l_3805) < (l_3805 > (safe_div_func_int32_t_s_s(((!(((+0x78EBL) , ((*l_3207) = ((+l_3805) == ((*l_3223) &= l_3811)))) && (((void*)0 == &g_1840) == (*g_1586)))) >= (**g_3645)), l_3811)))), 0xAEF36B39L)) && l_3805) , l_3811) && l_3811)) & l_3811) , l_3811) , l_3805)) || l_3813[3]) , (void*)0) == &g_2395), 8L)) , l_3811);
        for (g_113 = 0; (g_113 == 27); g_113++)
        { /* block id: 1774 */
            uint16_t l_3821[6];
            int32_t l_3826[1];
            uint8_t l_3846 = 255UL;
            int16_t l_3919[10] = {7L,7L,0xCF79L,7L,7L,0xCF79L,7L,7L,0xCF79L,7L};
            int32_t l_3955 = (-2L);
            int32_t * const l_3993 = &l_3643;
            int8_t * const l_4005[5][3][1] = {{{&g_151},{&g_3531},{&l_3825}},{{&l_3825},{&g_3531},{&g_151}},{{&g_3531},{&l_3825},{&l_3825}},{{&g_3531},{&g_151},{&g_3531}},{{&l_3825},{&l_3825},{&g_3531}}};
            int32_t l_4039 = 5L;
            uint32_t l_4048 = 1UL;
            int32_t l_4053 = 0x586A4EB1L;
            int8_t l_4065 = 0x35L;
            const int8_t l_4066 = 0L;
            uint32_t l_4102 = 0x7877D216L;
            int32_t l_4114 = 0xD917EF0BL;
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_3821[i] = 65535UL;
            for (i = 0; i < 1; i++)
                l_3826[i] = 0xFEC85660L;
            if (l_3014)
                goto lbl_3816;
            for (l_3431 = 0; (l_3431 > 48); l_3431 = safe_add_func_uint16_t_u_u(l_3431, 1))
            { /* block id: 1778 */
                int32_t l_3824 = 0xEDE3E426L;
                int32_t l_3832 = 0x5FF52E74L;
                int32_t l_3852[3][1][2];
                uint64_t l_3863 = 0xCCB063928DC5086FLL;
                uint32_t **l_3951[2];
                int i, j, k;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 2; k++)
                            l_3852[i][j][k] = 0x1D882C70L;
                    }
                }
                for (i = 0; i < 2; i++)
                    l_3951[i] = &g_1387;
                if ((l_3812 == g_2320))
                { /* block id: 1779 */
                    int64_t l_3827 = 0xEA379063CF17CC20LL;
                    int32_t l_3831[10] = {4L,1L,(-1L),(-1L),1L,4L,1L,(-1L),(-1L),1L};
                    uint32_t l_3833 = 0x9C2091D2L;
                    int i;
                    for (g_2815 = 0; (g_2815 == (-2)); g_2815 = safe_sub_func_int8_t_s_s(g_2815, 7))
                    { /* block id: 1782 */
                        int32_t l_3828 = 0x63E28282L;
                        int32_t l_3829 = 0L;
                        int32_t l_3830 = 5L;
                        l_3821[4]--;
                        ++l_3833;
                    }
                }
                else
                { /* block id: 1786 */
                    uint32_t l_3840[4][2] = {{0UL,0xC1A003EBL},{0UL,0xC1A003EBL},{0UL,0xC1A003EBL},{0UL,0xC1A003EBL}};
                    int32_t l_3847 = 2L;
                    int i, j;
                    if ((l_3846 = ((safe_div_func_int32_t_s_s(((*g_174) = ((*g_1513) , ((l_3812 = (safe_lshift_func_uint8_t_u_u((l_3840[0][0] > (((*g_1513) = l_3840[1][1]) > (((l_3841[2][0] == (void*)0) & (g_79 &= (safe_sub_func_int8_t_s_s(l_3840[2][0], 248UL)))) <= (safe_div_func_uint8_t_u_u((((0x40260DC1L && l_3826[0]) || 248UL) & l_3805), l_3824))))), l_3811))) < l_3824))), l_3840[0][0])) == 0xB7L)))
                    { /* block id: 1792 */
                        uint32_t l_3848 = 4294967291UL;
                        int32_t l_3851 = 0x953A8299L;
                        uint32_t l_3853 = 18446744073709551611UL;
                        int16_t ***l_3860 = &g_1468;
                        int64_t l_3892 = 0xB6EA387C1C672FF6LL;
                        uint32_t *l_3893 = &l_3848;
                        l_3848--;
                        (*g_3096) = ((((l_3832 > ((*l_3207) ^= ((((((++l_3853) | (l_3848 ^ (((l_3847 = ((*l_3217) = l_3811)) > (safe_rshift_func_int8_t_s_s(((****l_3762) = (l_3852[2][0][0] || l_3812)), (l_3848 == ((l_3860 != (*l_3669)) == ((l_3851 ^= 0xBC6E8DFB27CB126ELL) || l_3826[0])))))) && (***g_1212)))) != l_3811) <= (**g_1041)) & l_3811) != 0x62E6056BF431AE44LL))) < 0UL) >= l_3826[0]) , &l_3812);
                        (*g_174) ^= ((safe_div_func_uint8_t_u_u(l_3863, (l_3863 ^ ((((***l_3763) = (safe_lshift_func_uint16_t_u_s((((l_3848 == (safe_sub_func_uint16_t_u_u(((*g_100)++), l_3811))) , (safe_lshift_func_uint8_t_u_u((((*l_3207) = g_3872) > (l_3852[2][0][0] = ((l_3826[0] = (safe_add_func_int64_t_s_s((l_3811 <= (safe_mul_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(((*l_3893) |= ((*g_1387) = (safe_rshift_func_int8_t_s_u(((safe_lshift_func_int16_t_s_s(((safe_rshift_func_int16_t_s_u(((*l_3217) = (safe_sub_func_uint32_t_u_u(l_3840[1][1], (safe_lshift_func_int8_t_s_s(((-1L) >= (+((*l_3234) |= (((safe_rshift_func_uint8_t_u_u(255UL, 6)) | l_3805) && 4294967294UL)))), 2))))), l_3892)) || l_3847), 10)) > 0xD7L), l_3852[1][0][0])))), (**g_477))), (****g_1542)))), (*g_1586)))) > l_3894))), l_3840[1][0]))) || l_3853), l_3853))) , (**g_1041)) || 1UL)))) , (-6L));
                    }
                    else
                    { /* block id: 1811 */
                        uint16_t l_3895 = 65535UL;
                        const int32_t **l_3920 = &g_575;
                        (*l_3920) = ((l_3895 , ((~((((****g_1542) |= (safe_unary_minus_func_int64_t_s(l_3825))) , (l_3917[1] = (l_3812 = (((((*l_3217) = (safe_mod_func_int8_t_s_s(0xC0L, (-5L)))) | ((((safe_sub_func_int32_t_s_s(((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(l_3832, ((safe_unary_minus_func_int8_t_s(1L)) != (((safe_mul_func_int16_t_s_s((safe_add_func_int16_t_s_s(((safe_mul_func_int16_t_s_s(((l_3826[0] = l_3821[5]) ^ (safe_rshift_func_int8_t_s_u((l_3895 || l_3811), l_3840[1][0]))), 0xFD85L)) && l_3863), 0xAB0CL)), (**g_1917))) || (*g_1513)) && l_3915)))), l_3840[0][0])) & g_3916[2][3][2]), 0x07B5B172L)) || 1UL) & (*g_100)) == g_1531)) , (**g_1041)) & l_3895)))) | l_3918)) , l_3919[4])) , (*g_922));
                    }
                    for (l_3918 = 0; (l_3918 == 46); l_3918++)
                    { /* block id: 1821 */
                        uint32_t l_3934[8][6][2] = {{{0xE6C98FCAL,0x1EC109F2L},{0xD3425845L,0UL},{4294967295UL,0UL},{0xD3425845L,0x1EC109F2L},{0xE6C98FCAL,3UL},{0xFA33694AL,0UL}},{{0xE6C98FCAL,5UL},{0xD3425845L,3UL},{4294967295UL,3UL},{0xD3425845L,5UL},{0xE6C98FCAL,0UL},{0xFA33694AL,3UL}},{{0xE6C98FCAL,0x1EC109F2L},{0xD3425845L,0UL},{4294967295UL,0UL},{0xD3425845L,0x1EC109F2L},{0xE6C98FCAL,3UL},{0xFA33694AL,0UL}},{{0xE6C98FCAL,5UL},{0xD3425845L,3UL},{4294967295UL,3UL},{0xD3425845L,5UL},{0xE6C98FCAL,0UL},{0xFA33694AL,3UL}},{{0xE6C98FCAL,0x1EC109F2L},{0xD3425845L,0UL},{4294967295UL,0UL},{0xD3425845L,0x1EC109F2L},{0xE6C98FCAL,3UL},{0xFA33694AL,0UL}},{{0xE6C98FCAL,5UL},{0xD3425845L,3UL},{4294967295UL,3UL},{0xD3425845L,5UL},{0xE6C98FCAL,0UL},{0xFA33694AL,3UL}},{{0xE6C98FCAL,0x1EC109F2L},{0xD3425845L,0UL},{4294967295UL,0UL},{0xD3425845L,0x1EC109F2L},{0xE6C98FCAL,3UL},{0xFA33694AL,0UL}},{{0xE6C98FCAL,5UL},{0xD3425845L,3UL},{4294967295UL,3UL},{0xD3425845L,5UL},{0xE6C98FCAL,0UL},{4294967294UL,0x1EC109F2L}}};
                        const uint32_t ***l_3954 = &g_3611[0];
                        int i, j, k;
                        l_3923[2]--;
                        (*g_249) = (safe_add_func_int32_t_s_s((l_3928 == (((~l_3840[0][0]) <= (((void*)0 == &l_2988) > (safe_div_func_int64_t_s_s((safe_rshift_func_int16_t_s_s(0L, l_3919[9])), l_3934[5][1][1])))) >= l_3919[6])), (safe_lshift_func_int16_t_s_s((safe_sub_func_int64_t_s_s(l_3847, l_3934[5][1][1])), 14))));
                        (*g_249) = 0L;
                        (*g_174) ^= ((safe_mod_func_int16_t_s_s(((l_3847 = (safe_mul_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((l_3955 = (l_3826[0] ^= (safe_div_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((3L == ((safe_lshift_func_uint16_t_u_u((l_3832 = (((**g_1041) ^ ((l_3951[0] == ((safe_lshift_func_uint8_t_u_u(((**g_3583) != (void*)0), (0x91D9C624L & l_3934[5][1][1]))) , ((*l_3954) = (*g_3610)))) & (255UL <= l_3840[2][1]))) >= l_3934[2][5][0])), l_3821[4])) < l_3928)), l_3934[2][0][1])), (-1L))))) < l_3811), 0x83L)), 0xF1L))) , l_3923[2]), l_3934[6][4][1])) == l_3934[5][1][1]);
                    }
                }
            }
        }
        l_4143 ^= (safe_lshift_func_int8_t_s_u(((****l_3762) = ((*g_1586) | ((safe_add_func_int8_t_s_s(((safe_add_func_int32_t_s_s((l_4130 >= (safe_div_func_uint8_t_u_u(((safe_sub_func_int16_t_s_s(((((((void*)0 == l_4135) & (((void*)0 != (*g_1542)) , (safe_rshift_func_int8_t_s_s((l_4140 ^= ((0x9BL > l_4138) && g_4139)), 3)))) <= (*g_249)) != l_4141) == l_3969[0][5][1]), (**g_1917))) != 0x34CD66A1D18C0046LL), g_2815))), l_3812)) > (*g_1586)), l_4088)) ^ l_3923[2]))), l_4142[1]));
    }
    else
    { /* block id: 1932 */
        int64_t l_4148 = 0xC8305FF77A557BAELL;
        int32_t l_4157 = 0x1E95D095L;
        int32_t l_4158 = 0xF7B30E63L;
        l_4158 &= ((safe_mod_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u(1UL, 4)) < l_4148), (safe_add_func_int32_t_s_s(0L, ((safe_rshift_func_uint16_t_u_u((l_4148 && (l_4148 <= (l_4148 > (safe_rshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s(l_4148, (((*g_1387) = (l_4157 || (((*g_249) = ((l_4148 ^ 4UL) && l_4157)) != (-1L)))) || 3UL))), 7))))), 12)) ^ (*g_478)))))) >= g_1208);
    }
    return l_4159;
}


/* ------------------------------------------ */
/* 
 * reads : g_100 g_81
 * writes: g_101 g_81 g_327
 */
static uint16_t  func_9(int16_t  p_10)
{ /* block id: 1129 */
    int32_t *l_2322 = (void*)0;
    int32_t *l_2323 = &g_118;
    uint16_t *l_2330 = &g_81;
    uint64_t *l_2335[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    const int8_t l_2336 = (-7L);
    int32_t l_2337 = 0x012D2C87L;
    int32_t l_2343 = (-1L);
    int32_t l_2344 = 9L;
    int32_t l_2345 = (-2L);
    int32_t l_2346 = 0x3BDF78B1L;
    int32_t l_2347 = (-10L);
    int64_t l_2348 = 1L;
    int32_t l_2349 = 0x8E00457AL;
    int32_t l_2350[1];
    uint32_t l_2352[4];
    int16_t ** const l_2371 = &g_1469;
    uint8_t l_2379 = 246UL;
    uint32_t l_2484 = 4294967295UL;
    uint8_t l_2486 = 8UL;
    uint32_t l_2488 = 0x71E22622L;
    const uint32_t ** const *l_2535 = (void*)0;
    const uint32_t ** const **l_2534[7] = {&l_2535,&l_2535,&l_2535,&l_2535,&l_2535,&l_2535,&l_2535};
    int32_t ***l_2614 = &g_2091;
    const uint32_t *l_2653[10] = {&g_528[9],&g_64,&g_64,&g_64,&g_528[9],&g_528[9],&g_64,&g_64,&g_64,&g_528[9]};
    int8_t **l_2669[8][2][5] = {{{&g_1513,&g_1513,&g_1513,(void*)0,&g_1513},{&g_1513,(void*)0,&g_1513,(void*)0,&g_1513}},{{(void*)0,(void*)0,&g_1513,&g_1513,&g_1513},{(void*)0,&g_1513,(void*)0,&g_1513,&g_1513}},{{(void*)0,(void*)0,&g_1513,(void*)0,&g_1513},{&g_1513,&g_1513,&g_1513,(void*)0,&g_1513}},{{&g_1513,(void*)0,&g_1513,(void*)0,&g_1513},{(void*)0,(void*)0,&g_1513,&g_1513,&g_1513}},{{(void*)0,&g_1513,(void*)0,&g_1513,&g_1513},{(void*)0,(void*)0,&g_1513,(void*)0,&g_1513}},{{&g_1513,&g_1513,&g_1513,(void*)0,&g_1513},{&g_1513,(void*)0,&g_1513,(void*)0,&g_1513}},{{(void*)0,(void*)0,&g_1513,&g_1513,&g_1513},{(void*)0,&g_1513,(void*)0,&g_1513,&g_1513}},{{(void*)0,(void*)0,&g_1513,(void*)0,&g_1513},{&g_1513,&g_1513,&g_1513,(void*)0,&g_1513}}};
    int8_t **l_2691 = &g_1513;
    int32_t * const l_2710 = &l_2337;
    int32_t l_2738 = 0x1EAE63E0L;
    int32_t l_2776 = 0xBA3AD03CL;
    uint64_t l_2817 = 0x3C0347D94C017557LL;
    uint8_t l_2828 = 0x6CL;
    uint32_t l_2892[7] = {18446744073709551606UL,18446744073709551611UL,18446744073709551611UL,18446744073709551606UL,18446744073709551611UL,18446744073709551611UL,18446744073709551606UL};
    uint8_t l_2908 = 0xFDL;
    int32_t l_2916[2][2] = {{(-1L),(-1L)},{(-1L),(-1L)}};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2350[i] = 0xCF3E4C99L;
    for (i = 0; i < 4; i++)
        l_2352[i] = 0xA9FC5C2DL;
    l_2323 = (l_2322 = l_2322);
    if ((l_2337 = (((((g_327 = ((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(65535UL, ((*g_100) = ((p_10 , &l_2322) == (void*)0)))), (p_10 > p_10))) != ((safe_mod_func_int8_t_s_s(p_10, 0xD7L)) & (((*l_2330)--) & ((safe_lshift_func_uint16_t_u_s(p_10, p_10)) , p_10))))) || p_10) && p_10) , 1L) >= l_2336)))
    { /* block id: 1136 */
        int8_t l_2338[6] = {6L,6L,0x3EL,6L,6L,0x3EL};
        int32_t l_2339 = 0L;
        int32_t *l_2340 = &g_118;
        int32_t *l_2341 = &l_2337;
        int32_t *l_2342[7];
        int32_t l_2351 = 0xA59E478DL;
        uint32_t l_2370 = 1UL;
        uint8_t *l_2372[6] = {&g_2113[0],&g_2113[0],&g_2025,&g_2113[0],&g_2113[0],&g_2025};
        int16_t ***l_2386 = &g_1468;
        int64_t l_2440 = 0L;
        int8_t l_2456 = 1L;
        uint8_t ***l_2466 = &g_1238;
        uint8_t ****l_2465 = &l_2466;
        uint8_t **l_2518 = &l_2372[3];
        int32_t l_2574 = (-1L);
        int32_t l_2615 = 1L;
        int8_t **l_2670 = &g_1513;
        int16_t l_2757[3][6] = {{0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L},{0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L},{0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L,0x23E8L}};
        uint32_t ** const *l_2795 = &g_1206;
        uint32_t ** const **l_2796 = &l_2795;
        uint16_t l_2814 = 4UL;
        int64_t *l_2816 = &l_2348;
        const uint32_t * const *l_2900 = (void*)0;
        int32_t *l_2910 = &l_2351;
        int i, j;
        for (i = 0; i < 7; i++)
            l_2342[i] = &l_2339;
        l_2352[2]--;
    }
    else
    { /* block id: 1376 */
        uint8_t l_2925 = 0x78L;
        int32_t *l_2926[3];
        int i;
        for (i = 0; i < 3; i++)
            l_2926[i] = (void*)0;
        l_2925 = ((*l_2710) = (-6L));
        l_2926[1] = l_2926[1];
    }
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_884 g_2108 g_2113 g_100 g_101 g_115 g_1513 g_149 g_118 g_702 g_1918 g_715 g_1586 g_1864 g_6 g_81 g_1930 g_1931 g_1387 g_528 g_113 g_478 g_479 g_2319
 * writes: g_884 g_174 g_2113 g_115 g_101 g_702 g_1499 g_149 g_118 g_81 g_113 g_159
 */
static int16_t  func_13(const uint8_t  p_14)
{ /* block id: 1058 */
    int32_t l_2128[10][10] = {{1L,3L,3L,1L,0xFD90220DL,0xCF9CBCCBL,3L,0xD8446FFBL,1L,0xA0DF3BBFL},{1L,0xD8446FFBL,3L,0xCF9CBCCBL,0xFD90220DL,1L,3L,3L,1L,0xFD90220DL},{1L,3L,3L,1L,0xFD90220DL,0xCF9CBCCBL,3L,0xD8446FFBL,1L,0xA0DF3BBFL},{1L,0xD8446FFBL,3L,0xCF9CBCCBL,0xFD90220DL,1L,3L,3L,1L,0xFD90220DL},{1L,3L,3L,1L,0xFD90220DL,0x2CBF1555L,0xCF9CBCCBL,1L,0x649896C7L,1L},{0x649896C7L,1L,0xCF9CBCCBL,0x2CBF1555L,7L,0x649896C7L,0xCF9CBCCBL,0xCF9CBCCBL,0x649896C7L,7L},{0x649896C7L,0xCF9CBCCBL,0xCF9CBCCBL,0x649896C7L,7L,0x2CBF1555L,0xCF9CBCCBL,1L,0x649896C7L,1L},{0x649896C7L,1L,0xCF9CBCCBL,0x2CBF1555L,7L,0x649896C7L,0xCF9CBCCBL,0xCF9CBCCBL,0x649896C7L,7L},{0x649896C7L,0xCF9CBCCBL,0xCF9CBCCBL,0x649896C7L,7L,0x2CBF1555L,0xCF9CBCCBL,1L,0x649896C7L,1L},{0x649896C7L,1L,0xCF9CBCCBL,0x2CBF1555L,7L,0x649896C7L,0xCF9CBCCBL,0xCF9CBCCBL,0x649896C7L,7L}};
    int32_t l_2130 = (-1L);
    int32_t l_2133 = 1L;
    uint16_t ****l_2138 = (void*)0;
    int16_t ** const *l_2259 = (void*)0;
    int32_t *l_2284[10][8][1] = {{{&l_2130},{&l_2128[9][5]},{&l_2130},{&l_2128[2][3]},{(void*)0},{&l_2133},{&l_2128[2][3]},{&l_2128[9][5]}},{{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[9][5]},{&l_2128[2][3]},{&l_2133}},{{(void*)0},{&l_2128[2][3]},{&l_2130},{&l_2128[9][5]},{&l_2130},{&l_2128[2][3]},{(void*)0},{&l_2133}},{{&l_2128[2][3]},{&l_2128[9][5]},{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[9][5]}},{{&l_2128[2][3]},{&l_2133},{(void*)0},{&l_2128[2][3]},{&l_2130},{&l_2128[9][5]},{&l_2130},{&l_2128[2][3]}},{{(void*)0},{&l_2133},{&l_2128[2][3]},{&l_2128[9][5]},{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[2][3]}},{{(void*)0},{&l_2128[9][5]},{&l_2128[2][3]},{&l_2133},{(void*)0},{&l_2128[2][3]},{&l_2130},{&l_2128[9][5]}},{{&l_2130},{&l_2128[2][3]},{(void*)0},{&l_2133},{&l_2128[2][3]},{&l_2128[9][5]},{(void*)0},{&l_2128[2][3]}},{{(void*)0},{&l_2128[2][3]},{(void*)0},{&l_2128[9][5]},{&l_2128[2][3]},{&l_2133},{(void*)0},{&l_2128[2][3]}},{{&l_2130},{&l_2128[9][5]},{&l_2130},{&l_2128[2][3]},{(void*)0},{&l_2133},{&l_2128[2][3]},{&l_2128[9][5]}}};
    int8_t l_2286 = 0x97L;
    int32_t l_2287 = (-2L);
    int8_t l_2288 = 1L;
    uint16_t l_2289 = 0xE6E3L;
    uint64_t *l_2294 = (void*)0;
    uint64_t *l_2295[1];
    uint64_t l_2314[6] = {0xED10E5D3A8BF97CFLL,0xED10E5D3A8BF97CFLL,0x8DB17AB7AD7304D6LL,0xED10E5D3A8BF97CFLL,0xED10E5D3A8BF97CFLL,0x8DB17AB7AD7304D6LL};
    uint8_t l_2315 = 1UL;
    int32_t **l_2316 = (void*)0;
    int32_t **l_2318 = &g_159[8][1];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2295[i] = &g_113;
    for (g_884 = 20; (g_884 > 17); g_884--)
    { /* block id: 1061 */
        int64_t l_2106[6] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
        int32_t l_2129[6][8] = {{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L}};
        uint64_t l_2144 = 18446744073709551615UL;
        int32_t ****l_2154 = &g_2090;
        uint8_t **l_2165 = &g_1013;
        int32_t l_2200 = 0x25F1B211L;
        int16_t ** const *l_2257 = &g_1468;
        int i, j;
        if (l_2106[5])
        { /* block id: 1062 */
            int32_t *l_2107 = &g_6;
            int32_t *l_2109 = &g_118;
            int32_t *l_2110 = &g_118;
            int32_t *l_2111 = &g_118;
            int32_t *l_2112 = (void*)0;
            int16_t *l_2134 = &g_115;
            int16_t l_2137 = (-10L);
            uint16_t * const *l_2141 = &g_100;
            uint16_t * const **l_2140 = &l_2141;
            uint16_t * const ***l_2139[8][2][8] = {{{&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140},{&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140}},{{&l_2140,(void*)0,(void*)0,&l_2140,(void*)0,&l_2140,&l_2140,(void*)0},{&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,(void*)0}},{{(void*)0,(void*)0,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140},{(void*)0,(void*)0,(void*)0,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140}},{{&l_2140,&l_2140,(void*)0,(void*)0,(void*)0,&l_2140,(void*)0,&l_2140},{&l_2140,(void*)0,&l_2140,&l_2140,(void*)0,&l_2140,(void*)0,&l_2140}},{{&l_2140,&l_2140,(void*)0,(void*)0,(void*)0,&l_2140,(void*)0,(void*)0},{&l_2140,&l_2140,&l_2140,(void*)0,&l_2140,&l_2140,&l_2140,&l_2140}},{{&l_2140,(void*)0,&l_2140,(void*)0,&l_2140,&l_2140,&l_2140,&l_2140},{&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140,&l_2140}},{{&l_2140,&l_2140,&l_2140,&l_2140,(void*)0,&l_2140,&l_2140,&l_2140},{&l_2140,(void*)0,&l_2140,&l_2140,(void*)0,(void*)0,&l_2140,(void*)0}},{{&l_2140,&l_2140,&l_2140,&l_2140,(void*)0,(void*)0,&l_2140,&l_2140},{&l_2140,&l_2140,&l_2140,(void*)0,&l_2140,&l_2140,&l_2140,&l_2140}}};
            uint8_t **l_2166 = &g_1013;
            int32_t l_2192 = 0xEE2B98B7L;
            int32_t l_2193 = 1L;
            int32_t l_2197[2][9] = {{0xB4A4B096L,0x78CC7D9EL,0x78CC7D9EL,0xB4A4B096L,0xB4A4B096L,0x78CC7D9EL,0x78CC7D9EL,0xB4A4B096L,0xB4A4B096L},{1L,(-3L),1L,(-3L),1L,(-3L),1L,(-3L),1L}};
            int16_t *l_2262 = (void*)0;
            int16_t ** const l_2261 = &l_2262;
            int16_t ** const *l_2260[3][2][3] = {{{&l_2261,&l_2261,&l_2261},{(void*)0,&l_2261,&l_2261}},{{(void*)0,(void*)0,&l_2261},{&l_2261,&l_2261,&l_2261}},{{&l_2261,&l_2261,&l_2261},{&l_2261,&l_2261,&l_2261}}};
            int32_t ****l_2263 = &g_2090;
            int i, j, k;
            (*g_2108) = l_2107;
            --g_2113[2];
            if (p_14)
                continue;
            if ((safe_add_func_uint16_t_u_u(((**l_2141) = ((safe_lshift_func_uint16_t_u_s((*g_100), 14)) == (((safe_mul_func_uint16_t_u_u(((((((safe_sub_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((l_2129[4][2] |= (safe_sub_func_int64_t_s_s(0x43FA8198CB93B8A1LL, (l_2128[2][3] = 0x42125668188506F0LL)))), ((l_2130 = (p_14 != 253UL)) ^ (((*l_2134) ^= (safe_mod_func_int32_t_s_s(p_14, l_2133))) <= ((safe_mod_func_int8_t_s_s((((*g_1513) > (l_2137 <= l_2106[1])) & p_14), (*l_2111))) > 255UL))))), p_14)) , p_14) & (*l_2109)) , l_2138) == l_2139[7][1][6]) | p_14), l_2106[5])) != 0UL) != l_2133))), 0xAA71L)))
            { /* block id: 1071 */
                return p_14;
            }
            else
            { /* block id: 1073 */
                uint64_t *l_2145 = &g_702;
                int32_t l_2155 = 1L;
                int8_t ** const l_2184 = &g_1513;
                int8_t ** const * const l_2183 = &l_2184;
                int32_t l_2191 = 0x3079ABA3L;
                int32_t l_2195 = 0x58BE723CL;
                int32_t l_2196[1][7][2] = {{{(-1L),0L},{0L,(-1L)},{0L,0L},{(-1L),0L},{0L,(-1L)},{0L,0L},{(-1L),0L}}};
                uint32_t l_2201 = 4294967295UL;
                uint32_t * const *l_2274 = &g_1387;
                uint32_t * const **l_2273 = &l_2274;
                int32_t l_2276[5][1];
                int i, j, k;
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_2276[i][j] = (-1L);
                }
                if ((safe_rshift_func_int8_t_s_u((l_2144 == ((l_2133 = (((*l_2145) &= p_14) | (l_2144 & (safe_mod_func_uint16_t_u_u(p_14, (safe_mod_func_int16_t_s_s((safe_add_func_int16_t_s_s(((safe_mod_func_int8_t_s_s(((((((((void*)0 == l_2145) , ((l_2129[4][2] &= 0xBEB29909L) & (0x321A823FL && (((l_2154 != (void*)0) != 253UL) ^ l_2155)))) <= p_14) == l_2130) ^ 0xB6L) == l_2130) && p_14), p_14)) < 8UL), p_14)), p_14))))))) , (*g_1918))), 1)))
                { /* block id: 1077 */
                    int64_t *l_2158 = &g_1499;
                    int32_t l_2181 = (-2L);
                    int32_t l_2182 = 0x8876895CL;
                    int32_t l_2194 = 0x61A5A73FL;
                    int32_t l_2198 = 0x95016F76L;
                    uint16_t **l_2208 = &g_100;
                    uint32_t * const *l_2252 = (void*)0;
                    int32_t *l_2264 = &l_2197[0][8];
                    (*l_2109) = ((((safe_mod_func_int8_t_s_s((((*l_2158) = p_14) , ((((safe_add_func_int16_t_s_s(((safe_div_func_int8_t_s_s(((safe_unary_minus_func_uint8_t_u((~0x80L))) < ((l_2166 = l_2165) != (void*)0)), (safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(((0x11C880BAL == 0xF41A95D6L) & ((65530UL >= (safe_sub_func_int64_t_s_s((safe_sub_func_uint16_t_u_u(((*g_1586) > (safe_mul_func_uint16_t_u_u((((((*g_1513) |= (safe_add_func_int8_t_s_s((l_2181 = (*l_2109)), l_2182))) , l_2183) == g_1864) <= (*g_100)), p_14))), p_14)), 8UL))) >= p_14)), p_14)), (-2L))))) ^ p_14), (*l_2107))) , p_14) > l_2128[2][3]) > l_2130)), l_2182)) == p_14) , 0x2BL) >= p_14);
                    for (l_2155 = 4; (l_2155 >= 0); l_2155 -= 1)
                    { /* block id: 1085 */
                        int32_t l_2185 = 0x48F72FEEL;
                        int32_t *l_2186 = &g_118;
                        int32_t *l_2187 = &l_2129[4][2];
                        int32_t *l_2188 = &l_2128[2][3];
                        int32_t *l_2189 = &g_118;
                        int32_t *l_2190[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2190[i] = &l_2128[2][3];
                        l_2201++;
                    }
                    for (l_2133 = (-30); (l_2133 < (-25)); l_2133 = safe_add_func_uint64_t_u_u(l_2133, 9))
                    { /* block id: 1090 */
                        uint32_t l_2215 = 0xE7B9C902L;
                        int32_t *l_2228 = (void*)0;
                        int16_t ** const **l_2258[8] = {&l_2257,&l_2257,&l_2257,&l_2257,&l_2257,&l_2257,&l_2257,&l_2257};
                        int i;
                        l_2228 = &l_2129[4][2];
                        (*l_2111) |= (safe_unary_minus_func_uint32_t_u(p_14));
                        l_2264 = &l_2196[0][6][0];
                    }
                }
                else
                { /* block id: 1103 */
                    return p_14;
                }
                if ((p_14 > (-4L)))
                { /* block id: 1106 */
                    for (g_81 = 0; (g_81 > 3); g_81++)
                    { /* block id: 1109 */
                        l_2128[7][1] = 0xC55035F9L;
                    }
                }
                else
                { /* block id: 1112 */
                    int16_t **l_2275 = &l_2262;
                    const int32_t l_2281 = 0xC7454E95L;
                    int32_t l_2282 = 0xD19F441AL;
                    l_2282 = ((safe_sub_func_uint32_t_u_u((safe_add_func_uint64_t_u_u(((safe_add_func_int32_t_s_s(l_2128[0][6], 0x7D4329E6L)) , (l_2273 == (void*)0)), ((*g_1930) == l_2275))), ((p_14 <= ((((l_2276[4][0] = p_14) != (safe_add_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_s(((((((1UL >= p_14) ^ l_2281) > p_14) , p_14) , (*g_1586)) , l_2281), (*g_1918))) > l_2281), (*g_1387)))) >= (*l_2111)) , 65535UL)) & 0xA7C4L))) , p_14);
                }
            }
        }
        else
        { /* block id: 1117 */
            int32_t **l_2283[3][7][2] = {{{(void*)0,&g_249},{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]},{&g_249,&g_249},{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]},{&g_249,&g_249}},{{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]},{&g_249,&g_249},{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]},{&g_249,&g_249},{&g_159[6][1],&g_249}},{{&g_249,&g_159[6][1]},{&g_249,&g_249},{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]},{&g_249,&g_249},{&g_159[6][1],&g_249},{&g_249,&g_159[6][1]}}};
            int i, j, k;
            (*g_2108) = &l_2128[2][3];
        }
    }
    l_2289++;
    l_2315 = (((safe_add_func_uint64_t_u_u((g_702 = (++g_113)), (safe_add_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_s(((((*g_100) = (&g_1206 == &g_1206)) <= ((safe_lshift_func_int8_t_s_u(0L, ((((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(0xDBL, (*g_1513))), ((safe_sub_func_uint8_t_u_u(0xADL, ((((safe_sub_func_uint64_t_u_u((l_2284[5][3][0] != l_2284[4][4][0]), (p_14 , p_14))) , p_14) & 0x2FA12684L) , 253UL))) == p_14))) , p_14) > (-1L)) ^ l_2314[1]))) <= p_14)) && (*g_478)), 2)) < p_14) >= p_14), 0L)))) , (*g_1387)) < 0x8AD8E31FL);
    (*l_2318) = &l_2128[2][3];
    return g_2319;
}


/* ------------------------------------------ */
/* 
 * reads : g_315 g_1387 g_528 g_2025 g_185 g_1831 g_477 g_478 g_479 g_702 g_575 g_1586 g_100 g_101 g_1768
 * writes: g_159 g_115 g_315 g_528 g_64 g_2025 g_575 g_185 g_702 g_113 g_1499
 */
static uint8_t  func_15(int16_t  p_16, uint64_t  p_17, int32_t  p_18, const uint64_t  p_19, uint32_t  p_20)
{ /* block id: 991 */
    const int16_t * const ** const *l_1952 = (void*)0;
    int32_t l_1962 = 0x2F9AE383L;
    int32_t *l_1963 = &l_1962;
    int32_t l_1991 = 0xCB9C2602L;
    int8_t l_2000 = 0x4FL;
    int32_t l_2006 = 1L;
    int32_t l_2009 = 0L;
    int32_t l_2013 = 0xACB93AF2L;
    int32_t l_2017 = 0x57B13211L;
    int32_t l_2018 = 1L;
    int32_t l_2019 = (-10L);
    int32_t l_2020 = 0x5A5787A3L;
    int32_t l_2021 = 0xD3D50BF4L;
    int32_t l_2022 = 0x6AA5B852L;
    int32_t l_2024[5] = {0x90DB8FEAL,0x90DB8FEAL,0x90DB8FEAL,0x90DB8FEAL,0x90DB8FEAL};
    int32_t **l_2050[5][7] = {{(void*)0,&g_249,&g_159[8][0],&g_159[8][0],&g_249,(void*)0,&g_249},{&l_1963,&g_159[8][0],&g_159[8][0],&l_1963,&g_174,&l_1963,&g_159[8][0]},{&g_159[8][0],&g_159[8][0],(void*)0,&g_159[8][0],(void*)0,&g_159[8][0],&g_159[8][0]},{&g_174,&g_159[8][0],&g_159[8][0],&g_159[8][0],&g_174,&g_174,&g_159[8][0]},{&g_174,&g_249,&g_174,(void*)0,(void*)0,&g_174,&g_249}};
    int32_t ***l_2049 = &l_2050[3][5];
    int64_t *l_2063 = &g_1499;
    uint8_t l_2084 = 249UL;
    int32_t ****l_2092 = (void*)0;
    int32_t ****l_2093 = &g_2090;
    int8_t **l_2098 = (void*)0;
    uint16_t *l_2101 = (void*)0;
    uint16_t *l_2102 = &g_809;
    int32_t *l_2103 = (void*)0;
    int i, j;
    if ((l_1952 != (p_16 , l_1952)))
    { /* block id: 992 */
        uint32_t l_1959 = 4UL;
        int32_t **l_1964 = &g_159[5][1];
        int16_t *l_1967 = (void*)0;
        int16_t *l_1968 = &g_115;
        int64_t *l_1983 = &g_315[1][2];
        uint16_t *****l_1986 = (void*)0;
        uint16_t *****l_1987 = (void*)0;
        uint16_t ****l_1988 = &g_1040;
        uint32_t *l_1989 = &g_64;
        uint32_t l_1990 = 4294967295UL;
        (*l_1964) = l_1963;
        l_1991 = (((*l_1963) = ((((*l_1968) = (safe_div_func_int16_t_s_s(0L, 0xAE29L))) >= ((((*l_1989) = ((*g_1387) ^= (((safe_rshift_func_uint8_t_u_u((p_17 < (safe_mul_func_int8_t_s_s(p_17, (safe_mul_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_mod_func_int16_t_s_s((safe_add_func_int32_t_s_s((((*l_1983) ^= 0x56F1169F9380C3E9LL) > (((((safe_lshift_func_int16_t_s_s(0x6EEBL, 3)) || (((l_1988 = (void*)0) != (void*)0) , ((0x60L < (*l_1963)) , (*l_1963)))) , (*l_1963)) , (*l_1963)) <= p_18)), (*l_1963))), (*l_1963))) , p_16), 3)) >= (*l_1963)), p_16))))), 1)) && p_18) , (*l_1963)))) && l_1990) ^ 0L)) != p_16)) , p_20);
    }
    else
    { /* block id: 1001 */
        int16_t l_1992 = (-1L);
        int32_t l_1999 = 0x52F6E67AL;
        int32_t l_2001 = (-1L);
        int32_t l_2002 = 1L;
        int32_t l_2003 = 1L;
        int32_t l_2004 = (-1L);
        int32_t l_2005 = 0xE8E3F5E5L;
        int32_t l_2007 = (-7L);
        int32_t l_2008 = 0xD191AC10L;
        int32_t l_2010 = 0x625F0007L;
        int32_t l_2012 = 8L;
        int32_t l_2014 = (-3L);
        int32_t l_2015 = 0x14B11193L;
        int32_t l_2016 = 0x277E02C7L;
        int32_t l_2023[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
        int32_t **l_2032[4] = {&g_174,&g_174,&g_174,&g_174};
        uint8_t l_2033 = 0xD1L;
        int32_t l_2077[2];
        int i;
        for (i = 0; i < 2; i++)
            l_2077[i] = 0xDEB93656L;
        if ((l_1992 = ((*l_1963) = (-1L))))
        { /* block id: 1004 */
            int64_t l_1993 = 0x085AD8635EAA0ACBLL;
            return l_1993;
        }
        else
        { /* block id: 1006 */
            int32_t *l_1994 = (void*)0;
            int32_t *l_1995 = &l_1962;
            int32_t *l_1996 = (void*)0;
            int32_t *l_1997 = &g_118;
            int32_t *l_1998[10] = {&g_118,(void*)0,(void*)0,&g_118,(void*)0,(void*)0,&g_118,(void*)0,(void*)0,&g_118};
            int32_t l_2011 = (-1L);
            const int32_t **l_2028 = &g_575;
            const int32_t *l_2030 = &l_2023[7];
            const int32_t **l_2029 = &l_2030;
            int i;
            g_2025++;
            (*l_2029) = ((*l_2028) = l_1995);
        }
        l_1963 = &p_18;
        if (p_18)
        { /* block id: 1012 */
            return l_2033;
        }
        else
        { /* block id: 1014 */
            int16_t l_2073[9][9] = {{0x26A4L,0xE76DL,6L,0xD224L,0L,0x26A4L,6L,6L,0x26A4L},{(-6L),0xBD61L,0x22FAL,0xBD61L,(-6L),0x0B19L,3L,(-7L),3L},{0xE76DL,(-4L),0L,0x8452L,0L,6L,(-4L),0x8452L,0x8452L},{0x4D36L,0x0B19L,1L,(-7L),1L,0x0B19L,0x4D36L,0xBD61L,0x73B6L},{0x26A4L,0L,0xD224L,6L,0xE76DL,0x26A4L,(-4L),0xD224L,0xE76DL},{0L,0xBD61L,3L,0xA6C5L,2L,0xA6C5L,3L,0xBD61L,0L},{0x0133L,6L,0L,0xE76DL,0x0133L,0x15ADL,6L,0x8452L,0xE76DL},{1L,(-8L),0x73B6L,(-7L),(-7L),0xBD61L,(-7L),(-7L),0x73B6L},{0x0133L,0x0133L,6L,0L,0xE76DL,0x0133L,0x15ADL,6L,0x8452L}};
            int32_t l_2082 = (-5L);
            int32_t l_2083[9] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
            int i, j;
            for (p_16 = 2; (p_16 >= 0); p_16 -= 1)
            { /* block id: 1017 */
                const uint32_t * const l_2054 = &g_1208;
                const uint32_t * const *l_2053 = &l_2054;
                const uint32_t * const **l_2052 = &l_2053;
                int32_t l_2072 = 0x684B1773L;
                for (g_185 = 0; (g_185 <= 2); g_185 += 1)
                { /* block id: 1020 */
                    int8_t l_2056 = (-1L);
                    int32_t *l_2078 = &l_2014;
                    if ((*l_1963))
                        break;
                    (*l_1963) = 0x499FDDAEL;
                    for (l_2013 = 0; (l_2013 >= 0); l_2013 -= 1)
                    { /* block id: 1025 */
                        uint64_t *l_2046 = &g_702;
                        uint64_t *l_2055 = &g_113;
                        int64_t *l_2074[10][7] = {{&g_1404,(void*)0,&g_315[1][2],&g_315[1][2],(void*)0,&g_1404,&g_315[3][2]},{&g_1404,&g_1404,&g_1404,&g_315[1][2],&g_1404,&g_1404,&g_1404},{&g_315[3][2],&g_1404,(void*)0,&g_315[1][2],&g_315[1][2],(void*)0,&g_1404},{&g_315[1][2],&g_1404,&g_315[1][2],&g_315[1][2],&g_1404,&g_315[1][2],&g_315[3][2]},{&g_1404,&g_315[1][2],(void*)0,&g_315[3][2],&g_1404,&g_315[1][2],&g_315[1][2]},{&g_315[1][2],&g_1404,&g_1404,&g_1404,&g_315[1][2],(void*)0,&g_1404},{&g_1404,&g_315[1][2],&g_315[1][2],&g_1404,&g_315[1][2],&g_1404,&g_315[1][2]},{&g_315[0][0],&g_1404,&g_1404,&g_315[0][0],&g_1404,&g_1404,&g_1404},{&g_1404,&g_1404,&g_1404,&g_315[0][0],&g_1404,&g_1404,&g_315[0][0]},{&g_315[1][2],&g_1404,&g_315[1][2],&g_1404,&g_315[1][2],&g_315[1][2],&g_1404}};
                        const uint16_t l_2075[8][4][6] = {{{0x363DL,0x0B1BL,0xB855L,0x0B1BL,0x363DL,0xC82FL},{0xCFAEL,0x3E53L,0xB855L,0x5CC4L,9UL,0xB855L},{9UL,0x751CL,0xC82FL,0x3E53L,5UL,0xB855L},{0x3E53L,5UL,0xB855L,0xCFAEL,0x71D8L,0xC82FL}},{{5UL,0x363DL,0xB855L,0x751CL,0x751CL,0xB855L},{0x5CC4L,0x5CC4L,0xC82FL,0x71D8L,0xCFAEL,0xB855L},{0x71D8L,0xCFAEL,0xB855L,5UL,0x3E53L,0xC82FL},{0x0B1BL,0x71D8L,0xB855L,9UL,0x5CC4L,0xB855L}},{{0x751CL,9UL,0xC82FL,0x363DL,0x0B1BL,0xB855L},{0x363DL,0x0B1BL,0xB855L,0x0B1BL,0x363DL,0xC82FL},{0xCFAEL,0x3E53L,0xB855L,0x5CC4L,9UL,0xB855L},{9UL,0x751CL,0xC82FL,0x3E53L,5UL,0xB855L}},{{0x3E53L,5UL,0xB855L,0xCFAEL,0x71D8L,0xC82FL},{5UL,0x363DL,0xB855L,0x751CL,0x751CL,0xB855L},{0x5CC4L,0x5CC4L,0xC82FL,0x71D8L,0xCFAEL,0xB855L},{0x71D8L,0xCFAEL,0xB855L,5UL,0x3E53L,0xC82FL}},{{0x0B1BL,0x71D8L,0xB855L,9UL,0x5CC4L,0xB855L},{0x751CL,9UL,0xC82FL,0x363DL,0x0B1BL,0xB855L},{0x363DL,0x0B1BL,0xB855L,0x0B1BL,0x363DL,0xC82FL},{0xCFAEL,0x3E53L,0xB855L,0x5CC4L,8UL,9UL}},{{8UL,65528UL,0x751CL,0xA286L,65535UL,9UL},{0xA286L,65535UL,9UL,0x0B13L,0x53A5L,0x751CL},{65535UL,9UL,9UL,65528UL,65528UL,9UL},{65533UL,65533UL,0x751CL,0x53A5L,0x0B13L,9UL}},{{0x53A5L,0x0B13L,9UL,65535UL,0xA286L,0x751CL},{65535UL,0x53A5L,9UL,8UL,65533UL,9UL},{65528UL,8UL,0x751CL,9UL,65535UL,9UL},{9UL,65535UL,9UL,65535UL,9UL,0x751CL}},{{0x0B13L,0xA286L,9UL,65533UL,8UL,9UL},{8UL,65528UL,0x751CL,0xA286L,65535UL,9UL},{0xA286L,65535UL,9UL,0x0B13L,0x53A5L,0x751CL},{65535UL,9UL,9UL,65528UL,65528UL,9UL}}};
                        uint32_t *l_2076 = &g_64;
                        int i, j, k;
                        (*l_1963) = (g_1831[(l_2013 + 2)][(p_16 + 1)][g_185] & ((((safe_unary_minus_func_uint32_t_u((**g_477))) == (safe_mod_func_uint8_t_u_u((!((safe_lshift_func_uint16_t_u_s(0x4B83L, 7)) == 0xDF7E889BB8F0A150LL)), (safe_div_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((((*l_2046)++) != (((3L | ((*l_2055) = (l_2049 == ((~((void*)0 == l_2052)) , (void*)0)))) , (*g_575)) ^ (-1L))), p_20)), p_20)) , p_20), l_2056))))) > l_2056) & p_16));
                        l_2077[1] &= (safe_mod_func_uint16_t_u_u((((*l_2076) = (((l_1963 != ((((*l_2046) = (*g_1586)) == (safe_div_func_uint8_t_u_u((0xD062L || 0x9EF3L), ((safe_rshift_func_int8_t_s_s((l_2063 != (void*)0), ((safe_div_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u(18446744073709551615UL, (l_2072 = ((*l_2063) = (safe_div_func_int64_t_s_s(((safe_mul_func_uint16_t_u_u(((((*g_1387) ^= (&p_18 != (l_2072 , &p_18))) == p_16) && l_2073[4][0]), p_19)) && (-7L)), 0xADF048B8FEA0578BLL)))))) | p_16), 0x5343L)) || p_18))) & l_2075[4][3][1])))) , (void*)0)) , 0x086498C6L) > p_20)) != 0UL), (*g_100)));
                        if (p_18)
                            continue;
                    }
                    for (l_2072 = 0; (l_2072 <= 2); l_2072 += 1)
                    { /* block id: 1039 */
                        int64_t l_2079 = 0L;
                        (*g_1768) = &p_18;
                        l_2078 = &p_18;
                        if (l_2079)
                            break;
                    }
                }
                l_2082 &= (+(~l_2073[7][2]));
                return l_2082;
            }
            l_2084++;
            return l_2083[7];
        }
    }
    l_2103 = &p_18;
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int8_t  func_23(const int32_t  p_24, int64_t  p_25)
{ /* block id: 685 */
    int64_t **l_1410 = &g_589;
    int64_t ***l_1409 = &l_1410;
    int64_t ****l_1408 = &l_1409;
    const int64_t *l_1414 = (void*)0;
    const int64_t **l_1413[6][1][6] = {{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}},{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}},{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}},{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}},{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}},{{(void*)0,(void*)0,&l_1414,(void*)0,(void*)0,&l_1414}}};
    const int64_t ***l_1412[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    const int64_t ****l_1411[3][4][9] = {{{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]}},{{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]},{&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1],&l_1412[1]}},{{&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1]},{&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1]},{&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1]},{&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1],&l_1412[7],&l_1412[7],&l_1412[1]}}};
    int32_t l_1417 = 0x3D01462DL;
    int32_t l_1431 = 3L;
    int32_t l_1436[1];
    uint64_t l_1441 = 18446744073709551613UL;
    uint64_t l_1450[8];
    uint64_t l_1470 = 0xB71D7092BF6D2689LL;
    uint8_t l_1483 = 0x23L;
    uint32_t l_1484[5] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
    uint32_t **l_1488 = &g_1207[0][3];
    uint32_t **l_1489 = &g_1207[5][4];
    int16_t * const l_1508 = (void*)0;
    int16_t * const *l_1507 = &l_1508;
    uint16_t ***l_1522 = (void*)0;
    int32_t *l_1529 = &l_1436[0];
    uint16_t *****l_1555 = (void*)0;
    int8_t **l_1562 = &g_1513;
    uint8_t l_1565 = 255UL;
    int8_t l_1630[4] = {7L,7L,7L,7L};
    uint32_t l_1637 = 0x5AFDA2A9L;
    int32_t *l_1682[1];
    uint8_t ***l_1713 = &g_1238;
    uint8_t **** const l_1712 = &l_1713;
    uint32_t l_1715 = 18446744073709551615UL;
    int8_t l_1881 = (-6L);
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1436[i] = 0L;
    for (i = 0; i < 8; i++)
        l_1450[i] = 0xF7AF1FC8D7FB71C8LL;
    for (i = 0; i < 1; i++)
        l_1682[i] = &g_1486[1][0][2];
    return p_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_602 g_603 g_528 g_118 g_1040 g_149 g_715 g_64 g_151 g_1013 g_211 g_922 g_575 g_327 g_1086 g_1041 g_100 g_174 g_6 g_1119 g_884 g_115 g_101 g_882 g_315 g_809 g_1212 g_154 g_478 g_479 g_2 g_81 g_1290 g_477 g_283 g_249 g_1327 g_79 g_1328 g_1329 g_113 g_1358 g_1387
 * writes: g_327 g_1013 g_101 g_1027 g_118 g_64 g_1040 g_151 g_149 g_159 g_575 g_117 g_81 g_702 g_185 g_809 g_115 g_283 g_315 g_884 g_1206 g_1041 g_1238 g_79 g_1358 g_1387
 */
static int8_t  func_28(int8_t  p_29, uint16_t  p_30, int32_t  p_31)
{ /* block id: 453 */
    const int64_t *l_1010 = &g_315[1][2];
    const int64_t **l_1009 = &l_1010;
    const int64_t *** const l_1008 = &l_1009;
    int32_t l_1026 = 1L;
    int32_t l_1054 = 0xC59E939FL;
    uint16_t **l_1089 = &g_100;
    uint16_t *l_1200 = &g_809;
    uint16_t ** const l_1199 = &l_1200;
    uint16_t ** const *l_1198 = &l_1199;
    uint32_t **l_1271 = &g_1207[0][3];
    const int16_t l_1306 = (-4L);
    int16_t *l_1366 = &g_283;
    int16_t **l_1365 = &l_1366;
    for (p_30 = 0; (p_30 == 26); p_30 = safe_add_func_int8_t_s_s(p_30, 1))
    { /* block id: 456 */
        uint8_t *l_1021 = &g_185;
        uint8_t ** const l_1020 = &l_1021;
        uint8_t **l_1023[5][9][1] = {{{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021}},{{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021}},{{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021}},{{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021}},{{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021},{&l_1021}}};
        uint8_t ***l_1022[6][1][10] = {{{&l_1023[0][7][0],(void*)0,&l_1023[1][8][0],(void*)0,&l_1023[0][7][0],&l_1023[1][8][0],(void*)0,&l_1023[3][0][0],&l_1023[1][8][0],&l_1023[0][7][0]}},{{&l_1023[0][7][0],&l_1023[0][5][0],&l_1023[1][8][0],(void*)0,&l_1023[2][0][0],&l_1023[2][0][0],(void*)0,&l_1023[1][8][0],&l_1023[0][5][0],&l_1023[0][7][0]}},{{&l_1023[2][0][0],(void*)0,&l_1023[1][8][0],&l_1023[0][5][0],&l_1023[0][7][0],&l_1023[2][0][0],&l_1023[0][5][0],&l_1023[3][0][0],&l_1023[0][5][0],&l_1023[2][0][0]}},{{&l_1023[0][7][0],(void*)0,&l_1023[1][8][0],(void*)0,&l_1023[0][7][0],&l_1023[1][8][0],(void*)0,&l_1023[3][0][0],&l_1023[1][8][0],&l_1023[0][7][0]}},{{&l_1023[0][7][0],&l_1023[0][5][0],&l_1023[1][8][0],(void*)0,&l_1023[2][0][0],&l_1023[2][0][0],(void*)0,&l_1023[1][8][0],&l_1023[0][5][0],&l_1023[0][7][0]}},{{&l_1023[2][0][0],(void*)0,&l_1023[1][8][0],&l_1023[0][5][0],&l_1023[0][7][0],&l_1023[2][0][0],&l_1023[0][5][0],&l_1023[3][0][0],&l_1023[0][5][0],&l_1023[2][0][0]}}};
        uint16_t ***l_1044[4][1] = {{&g_1041},{&g_1041},{&g_1041},{&g_1041}};
        int32_t l_1055 = 0L;
        int32_t l_1056 = 5L;
        int64_t **l_1057 = &g_589;
        uint32_t *l_1102 = &g_64;
        int32_t l_1114[1][7][3] = {{{0L,(-10L),(-10L)},{0L,(-10L),(-10L)},{0L,(-10L),(-10L)},{0L,(-10L),(-10L)},{0L,(-10L),(-10L)},{0L,(-10L),(-10L)},{0L,(-10L),(-10L)}}};
        int32_t *l_1125 = &l_1056;
        int32_t l_1126[9] = {0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L,0x1588EF51L};
        int64_t *l_1172 = (void*)0;
        int64_t l_1233[5][6] = {{(-1L),0x7F80A9C092AF1C66LL,0x7F80A9C092AF1C66LL,(-1L),0x7F80A9C092AF1C66LL,0x7F80A9C092AF1C66LL},{0x7F80A9C092AF1C66LL,(-7L),(-7L),0x7F80A9C092AF1C66LL,(-7L),(-7L)},{0x7F80A9C092AF1C66LL,(-7L),(-7L),0x7F80A9C092AF1C66LL,(-7L),(-7L)},{0x7F80A9C092AF1C66LL,(-7L),(-7L),0x7F80A9C092AF1C66LL,(-7L),(-7L)},{0x7F80A9C092AF1C66LL,(-7L),(-7L),0x7F80A9C092AF1C66LL,(-7L),(-7L)}};
        uint32_t l_1278 = 0x327F3AF0L;
        uint16_t l_1279[3];
        int32_t l_1319[1];
        const uint32_t * const *l_1334 = (void*)0;
        uint32_t *l_1364 = &g_1208;
        int32_t *l_1386 = &l_1126[7];
        uint32_t **l_1388 = (void*)0;
        uint32_t **l_1389 = &g_1387;
        int32_t l_1399 = (-1L);
        int32_t *l_1400 = &l_1319[0];
        int32_t *l_1401 = (void*)0;
        int32_t *l_1402[2];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1279[i] = 0x6D30L;
        for (i = 0; i < 1; i++)
            l_1319[i] = 0L;
        for (i = 0; i < 2; i++)
            l_1402[i] = &l_1114[0][2][2];
        for (g_327 = 0; (g_327 <= 1); g_327 += 1)
        { /* block id: 459 */
            int64_t ***l_1007[1];
            uint8_t *l_1011 = &g_211[2];
            uint8_t **l_1012[8][4][3] = {{{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011},{&l_1011,(void*)0,&l_1011}},{{&l_1011,&l_1011,(void*)0},{(void*)0,&l_1011,&l_1011},{(void*)0,&l_1011,&l_1011},{(void*)0,&l_1011,&l_1011}},{{&l_1011,(void*)0,(void*)0},{(void*)0,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,(void*)0}},{{&l_1011,&l_1011,&l_1011},{(void*)0,(void*)0,(void*)0},{&l_1011,&l_1011,(void*)0},{&l_1011,&l_1011,&l_1011}},{{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011},{&l_1011,(void*)0,&l_1011},{&l_1011,&l_1011,(void*)0}},{{(void*)0,&l_1011,&l_1011},{(void*)0,&l_1011,&l_1011},{(void*)0,&l_1011,&l_1011},{&l_1011,(void*)0,(void*)0}},{{(void*)0,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,(void*)0},{&l_1011,&l_1011,&l_1011}},{{(void*)0,(void*)0,(void*)0},{&l_1011,&l_1011,(void*)0},{&l_1011,&l_1011,&l_1011},{&l_1011,&l_1011,&l_1011}}};
            uint8_t ****l_1024 = &l_1022[1][0][2];
            int32_t l_1025 = 0x2D510396L;
            uint16_t l_1030 = 0x3CAFL;
            uint16_t ****l_1042 = (void*)0;
            uint16_t ****l_1043[9] = {&g_1040,&g_1040,&g_1040,&g_1040,&g_1040,&g_1040,&g_1040,&g_1040,&g_1040};
            uint64_t l_1053 = 18446744073709551615UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1007[i] = (void*)0;
            p_31 = ((safe_rshift_func_uint8_t_u_s(((-5L) && (l_1007[0] != l_1008)), (((p_30 , (((*g_602) == (g_1013 = l_1011)) == ((safe_mod_func_int64_t_s_s((safe_add_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(((l_1020 != ((&g_602 == ((*l_1024) = l_1022[1][0][2])) , (void*)0)) , p_29), 1)), l_1025)), g_528[9])) & 0UL))) , l_1026) ^ (-1L)))) , p_29);
            for (g_101 = 0; (g_101 <= 1); g_101 += 1)
            { /* block id: 465 */
                uint32_t *l_1028[1];
                int32_t *l_1029 = &g_118;
                int i;
                for (i = 0; i < 1; i++)
                    l_1028[i] = (void*)0;
                l_1030 = ((*l_1029) = ((g_1027 = &g_528[0]) == l_1028[0]));
                for (l_1025 = 0; (l_1025 <= 1); l_1025 += 1)
                { /* block id: 471 */
                    for (g_64 = 0; (g_64 <= 1); g_64 += 1)
                    { /* block id: 474 */
                        if ((*l_1029))
                            break;
                        if (p_29)
                            continue;
                    }
                }
            }
            l_1054 |= (safe_lshift_func_uint16_t_u_u(((((safe_add_func_int64_t_s_s(p_30, (~(safe_div_func_uint16_t_u_u(((0x7982775576445BE4LL >= ((safe_lshift_func_uint8_t_u_s(((g_1040 = g_1040) != l_1044[1][0]), 2)) & (((((safe_unary_minus_func_uint8_t_u((safe_lshift_func_uint16_t_u_s(((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(p_30, 0xFAA4L)), p_30)) ^ p_29), 12)))) != (safe_unary_minus_func_uint8_t_u((p_30 <= 6UL)))) > 18446744073709551612UL) | p_29) <= l_1053))) < 0L), (-7L)))))) ^ 0xE61F74DFE50C6665LL) > l_1026) , l_1026), p_31));
            for (g_151 = 1; (g_151 >= 0); g_151 -= 1)
            { /* block id: 484 */
                uint32_t *l_1064 = &g_64;
                int32_t l_1071 = 0L;
                uint8_t l_1077 = 251UL;
                l_1056 |= l_1055;
                for (l_1030 = 0; (l_1030 <= 1); l_1030 += 1)
                { /* block id: 488 */
                    return g_149;
                }
                if ((l_1025 = (((((g_715 >= (l_1057 == (((~(safe_mod_func_int32_t_s_s((((safe_rshift_func_int16_t_s_u(p_31, 6)) , (void*)0) != (void*)0), ((0UL <= (+(&g_975 != (void*)0))) , (--(*l_1064)))))) || (safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s((0xFEDAFF8FL == p_29), 2UL)), g_151))) , (void*)0))) <= 1UL) < p_29) | l_1071) == (*g_1013))))
                { /* block id: 493 */
                    int32_t *l_1072 = &g_118;
                    (*l_1072) ^= l_1054;
                    for (g_149 = 0; (g_149 <= 1); g_149 += 1)
                    { /* block id: 497 */
                        int32_t **l_1073 = (void*)0;
                        int32_t **l_1074 = &g_159[0][0];
                        const int32_t **l_1075 = &g_575;
                        int i, j;
                        l_1026 ^= 0x8F2FF26AL;
                        (*l_1074) = l_1072;
                        (*l_1075) = (*g_922);
                        (*l_1074) = &p_31;
                    }
                }
                else
                { /* block id: 503 */
                    g_159[(g_327 + 4)][g_327] = &l_1071;
                    for (l_1026 = 0; l_1026 < 1; l_1026 += 1)
                    {
                        for (g_118 = 0; g_118 < 7; g_118 += 1)
                        {
                            for (l_1054 = 0; l_1054 < 6; l_1054 += 1)
                            {
                                g_117[l_1026][g_118][l_1054] = (void*)0;
                            }
                        }
                    }
                    for (g_81 = 0; (g_81 <= 1); g_81 += 1)
                    { /* block id: 508 */
                        int32_t *l_1076[4][6] = {{&g_2,(void*)0,(void*)0,&g_2,(void*)0,(void*)0},{&g_2,(void*)0,(void*)0,&g_2,(void*)0,(void*)0},{&g_2,(void*)0,(void*)0,&g_2,(void*)0,(void*)0},{&g_2,(void*)0,(void*)0,&g_2,(void*)0,(void*)0}};
                        int i, j;
                        --l_1077;
                    }
                }
            }
        }
        if (p_31)
        { /* block id: 514 */
            int8_t l_1113 = (-10L);
            int64_t l_1115 = 0xDEDE743568C713D6LL;
            int32_t l_1116 = 0x17D29162L;
            int32_t **l_1124[2];
            int16_t *l_1138 = &g_115;
            int16_t *l_1139 = &g_283;
            uint16_t l_1140 = 0x1109L;
            int i;
            for (i = 0; i < 2; i++)
                l_1124[i] = &g_159[8][0];
            for (g_702 = 0; (g_702 > 30); g_702 = safe_add_func_uint64_t_u_u(g_702, 1))
            { /* block id: 517 */
                uint16_t ***l_1112 = &l_1089;
                for (l_1026 = 0; l_1026 < 4; l_1026 += 1)
                {
                    for (g_81 = 0; g_81 < 1; g_81 += 1)
                    {
                        l_1044[l_1026][g_81] = &g_1041;
                    }
                }
                for (g_185 = 15; (g_185 > 60); ++g_185)
                { /* block id: 521 */
                    int32_t *l_1084 = (void*)0;
                    int32_t *l_1085 = (void*)0;
                    uint32_t *l_1101 = &g_528[4];
                    uint32_t **l_1100 = &l_1101;
                    (*g_922) = &p_31;
                    (*g_1086) &= l_1055;
                    if (((((void*)0 == l_1089) < ((safe_add_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u(((p_31 < (safe_mod_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_u(p_30, 10)) >= ((((*l_1100) = &g_528[9]) == l_1102) == (safe_unary_minus_func_uint8_t_u((l_1116 ^= (((((((**g_1041) = ((safe_rshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((l_1026 , (safe_div_func_int64_t_s_s((safe_sub_func_uint8_t_u_u((l_1112 != (void*)0), p_29)), p_31))), p_29)), 13)) | l_1113)) ^ 0x4F9CL) ^ p_31) , l_1114[0][2][2]) > l_1115) , p_29)))))), l_1026))) || 0x3D51L), 1L)) & p_29), g_715)) < (*g_174))) != l_1113))
                    { /* block id: 527 */
                        int32_t l_1117[7][2] = {{0x036919F7L,4L},{0x036919F7L,0x036919F7L},{4L,0x036919F7L},{0x036919F7L,4L},{0x036919F7L,0x036919F7L},{4L,0x036919F7L},{0x036919F7L,4L}};
                        int i, j;
                        return l_1117[0][1];
                    }
                    else
                    { /* block id: 529 */
                        int8_t l_1120 = 0x02L;
                        (*g_1119) = (l_1055 &= p_29);
                        p_31 |= (l_1114[0][5][1] , l_1120);
                        return l_1056;
                    }
                }
            }
            l_1140 = (((((safe_div_func_uint16_t_u_u(l_1054, 0xE297L)) , (+(((((l_1125 = &l_1116) == (l_1126[4] , (void*)0)) >= p_29) , ((safe_div_func_uint16_t_u_u(((!((*l_1139) = (safe_mod_func_int16_t_s_s(((*l_1138) |= ((p_30 , (l_1054 = g_6)) , (safe_mul_func_int8_t_s_s((safe_sub_func_int16_t_s_s((safe_div_func_int32_t_s_s((l_1054 ^ g_884), p_30)), p_31)), l_1026)))), (*g_100))))) & 0UL), 0x85E8L)) >= p_30)) ^ 0xFAD319D691A59408LL))) >= 0x85CC5E8AA817A385LL) == l_1114[0][4][1]) && p_30);
        }
        else
        { /* block id: 542 */
            uint8_t ***l_1141 = &l_1023[0][6][0];
            int32_t l_1150[8][9] = {{0L,1L,0x7D3F7853L,1L,0L,0x7D3F7853L,(-9L),(-9L),0x7D3F7853L},{0x76D2FD5DL,0x7BE0C5A1L,(-1L),0x7BE0C5A1L,0x76D2FD5DL,0x5A757D3AL,0L,0x1815CBB7L,(-1L)},{0L,1L,0x7D3F7853L,1L,0L,0x7D3F7853L,7L,7L,(-9L)},{2L,0xCB82680AL,0L,0xCB82680AL,2L,0x1815CBB7L,8L,0x624B59A4L,0L},{1L,7L,(-9L),7L,1L,(-9L),7L,7L,(-9L)},{2L,0xCB82680AL,0L,0xCB82680AL,2L,0x1815CBB7L,8L,0x624B59A4L,0L},{1L,7L,(-9L),7L,1L,(-9L),7L,7L,(-9L)},{2L,0xCB82680AL,0L,0xCB82680AL,2L,0x1815CBB7L,8L,0x624B59A4L,0L}};
            int8_t *l_1152 = &g_884;
            int32_t *l_1153[1];
            uint32_t l_1154 = 0x0094CD79L;
            int i, j;
            for (i = 0; i < 1; i++)
                l_1153[i] = &l_1055;
            l_1126[0] ^= (&l_1044[1][0] == (((l_1141 == &g_602) || (safe_add_func_int64_t_s_s((g_315[1][2] = (*l_1125)), ((((safe_sub_func_uint64_t_u_u((safe_add_func_int16_t_s_s((p_31 >= (((safe_rshift_func_int8_t_s_u(((l_1150[7][6] &= 4L) || p_29), 7)) , (~(((*l_1152) |= (g_149 , 0x3FL)) , l_1026))) | l_1026)), (*l_1125))), g_882)) != 0x6FD2L) || p_31) , (*l_1125))))) , &g_1040));
            l_1154++;
        }
        for (g_115 = 0; (g_115 != 25); g_115 = safe_add_func_int64_t_s_s(g_115, 8))
        { /* block id: 551 */
            int32_t l_1164 = 1L;
            int32_t l_1167[10][7][3] = {{{2L,1L,(-2L)},{0x97D3177AL,(-1L),0xFA1832D6L},{0xB615FC37L,2L,(-2L)},{(-1L),(-1L),0xB195D598L},{0x0699DC80L,2L,1L},{0xDBBD9B0BL,(-1L),5L},{0x0699DC80L,1L,0x9912FDBBL}},{{(-1L),0xDBBD9B0BL,5L},{0xB615FC37L,0xB615FC37L,1L},{0x97D3177AL,0xDBBD9B0BL,0xB195D598L},{2L,1L,(-2L)},{0x97D3177AL,(-1L),0xFA1832D6L},{0xB615FC37L,2L,(-2L)},{(-1L),(-1L),0xB195D598L}},{{0x0699DC80L,2L,1L},{0xDBBD9B0BL,(-1L),5L},{0x0699DC80L,1L,0x9912FDBBL},{(-1L),0xDBBD9B0BL,5L},{0xB615FC37L,0xB615FC37L,1L},{0x97D3177AL,0xDBBD9B0BL,0xB195D598L},{2L,1L,(-2L)}},{{0x97D3177AL,(-1L),0xFA1832D6L},{0xB615FC37L,2L,(-2L)},{(-1L),(-1L),0xB195D598L},{0x0699DC80L,2L,1L},{0xDBBD9B0BL,(-1L),5L},{0x0699DC80L,1L,0x9912FDBBL},{(-1L),0xDBBD9B0BL,5L}},{{0xB615FC37L,0xB615FC37L,1L},{0x97D3177AL,0xDBBD9B0BL,0xB195D598L},{2L,1L,(-2L)},{0x97D3177AL,(-1L),0xFA1832D6L},{0xB615FC37L,2L,(-2L)},{(-1L),(-1L),0xB195D598L},{0x0699DC80L,2L,1L}},{{0xDBBD9B0BL,(-1L),5L},{0x0699DC80L,1L,0x9912FDBBL},{(-1L),0xDBBD9B0BL,5L},{0xB615FC37L,0xB615FC37L,1L},{0x97D3177AL,0xDBBD9B0BL,0xB195D598L},{2L,1L,(-2L)},{0x97D3177AL,(-1L),0xFA1832D6L}},{{0xB615FC37L,2L,(-2L)},{(-1L),(-1L),0xB195D598L},{0x0699DC80L,2L,1L},{0xDBBD9B0BL,(-1L),5L},{0x0699DC80L,1L,0x9912FDBBL},{(-1L),0xDBBD9B0BL,(-1L)},{0x7099DE7EL,0x7099DE7EL,0x0699DC80L}},{{8L,0x7ACDBAE8L,0x97D3177AL},{(-1L),8L,1L},{8L,0x9E6C5F11L,1L},{0x7099DE7EL,(-1L),1L},{0x05FAA95BL,0x05FAA95BL,0x97D3177AL},{0x188B3249L,(-1L),0x0699DC80L},{0x7ACDBAE8L,0x9E6C5F11L,(-1L)}},{{0x188B3249L,8L,0x1C626E6DL},{0x05FAA95BL,0x7ACDBAE8L,(-1L)},{0x7099DE7EL,0x7099DE7EL,0x0699DC80L},{8L,0x7ACDBAE8L,0x97D3177AL},{(-1L),8L,1L},{8L,0x9E6C5F11L,1L},{0x7099DE7EL,(-1L),1L}},{{0x05FAA95BL,0x05FAA95BL,0x97D3177AL},{0x188B3249L,(-1L),0x0699DC80L},{0x7ACDBAE8L,0x9E6C5F11L,(-1L)},{0x188B3249L,8L,0x1C626E6DL},{0x05FAA95BL,0x7ACDBAE8L,(-1L)},{0x7099DE7EL,0x7099DE7EL,0x0699DC80L},{8L,0x7ACDBAE8L,0x97D3177AL}}};
            int32_t l_1181 = 0x96EAF315L;
            uint16_t ***l_1188 = &l_1089;
            uint16_t ** const *l_1201 = (void*)0;
            uint32_t **l_1203 = (void*)0;
            uint8_t **l_1237 = &g_1013;
            int64_t ***l_1277 = (void*)0;
            int64_t ****l_1276 = &l_1277;
            const uint32_t l_1293[5] = {0UL,0UL,0UL,0UL,0UL};
            const int32_t *l_1302 = &l_1054;
            int8_t *l_1336 = &g_79;
            int64_t l_1339 = 4L;
            int i, j, k;
            for (p_29 = 0; (p_29 >= 0); p_29 -= 1)
            { /* block id: 554 */
                uint64_t l_1159 = 0x1B78C2AC9361BBCCLL;
                int8_t *l_1165 = &g_884;
                uint32_t *l_1166 = (void*)0;
                int32_t *l_1182 = &l_1055;
                int32_t *l_1183[4][8] = {{&l_1126[4],&l_1026,&l_1056,&l_1056,&l_1026,&l_1126[4],&l_1126[4],&l_1026},{&l_1126[4],&l_1126[4],&l_1056,&l_1126[4],&l_1056,&l_1126[4],&l_1126[4],&l_1126[4]},{&l_1026,(void*)0,&g_2,&l_1126[4],&l_1126[4],&g_2,(void*)0,&l_1026},{&l_1126[4],&l_1126[4],&l_1126[4],&l_1056,&l_1126[4],&l_1056,&l_1126[4],&l_1126[4]}};
                uint16_t ***l_1187[8];
                uint16_t ***l_1210[7][4];
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_1187[i] = &l_1089;
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 4; j++)
                        l_1210[i][j] = &l_1089;
                }
                ++l_1159;
                if ((l_1181 = ((*l_1182) = ((l_1167[8][4][1] = (l_1159 | (safe_div_func_int8_t_s_s(((*l_1165) = l_1164), l_1026)))) , (safe_sub_func_int8_t_s_s(((*l_1165) = (safe_rshift_func_int16_t_s_s(((l_1172 != (*l_1009)) , p_30), 0))), (((l_1054 = ((**l_1089)--)) | (safe_div_func_uint32_t_u_u((safe_mod_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_s((((*g_1119) ^ 0xD84ADBF2L) < ((g_315[0][0] |= ((l_1181 , p_31) > p_30)) != g_115)), 13)) && l_1159), l_1026)), p_30))) ^ p_31)))))))
                { /* block id: 564 */
                    uint16_t l_1184 = 5UL;
                    int32_t **l_1191 = &g_249;
                    if (l_1184)
                    { /* block id: 565 */
                        int8_t l_1185 = 0x23L;
                        uint16_t ****l_1186[7] = {&l_1044[0][0],&l_1044[0][0],&l_1044[0][0],&l_1044[0][0],&l_1044[0][0],&l_1044[0][0],&l_1044[0][0]};
                        uint16_t ** const *l_1197 = (void*)0;
                        uint16_t ** const **l_1196[10] = {&l_1197,&l_1197,&l_1197,&l_1197,&l_1197,&l_1197,&l_1197,&l_1197,&l_1197,&l_1197};
                        int32_t l_1202 = 0x19E1DFC0L;
                        uint32_t ***l_1204 = &l_1203;
                        int i;
                        (*l_1182) |= l_1185;
                        l_1202 &= ((g_315[1][0] = (((l_1187[7] = &g_1041) != (void*)0) <= 1L)) || ((l_1188 != (((-1L) != ((void*)0 != l_1191)) , (l_1201 = (l_1198 = (((safe_mul_func_uint16_t_u_u(((((safe_sub_func_uint8_t_u_u((0xFD36EF1EC34BB7F1LL | p_31), 0x49L)) , 8UL) , 0xF962FA0EL) | p_30), p_30)) || 0xAFL) , &g_1041))))) ^ g_528[9]));
                        g_1206 = ((*l_1204) = l_1203);
                    }
                    else
                    { /* block id: 574 */
                        uint32_t l_1209 = 0x5E0BD160L;
                        if (p_30)
                            break;
                        (*l_1182) &= ((l_1209 , (***g_1040)) , p_30);
                    }
                    if (l_1167[8][4][1])
                        continue;
                }
                else
                { /* block id: 579 */
                    l_1026 |= ((*l_1182) ^= (p_29 , (*g_1086)));
                }
                for (g_118 = 0; (g_118 >= 0); g_118 -= 1)
                { /* block id: 585 */
                    return p_30;
                }
                (*g_1212) = (*l_1198);
            }
            if ((((safe_mod_func_uint16_t_u_u((l_1233[1][2] = (safe_add_func_uint8_t_u_u((l_1026 < ((safe_mod_func_uint32_t_u_u(0x952661A0L, ((*l_1102) = p_29))) != ((l_1164 , ((safe_div_func_int8_t_s_s((((safe_mod_func_int64_t_s_s((safe_lshift_func_int16_t_s_s((l_1181 , (safe_mul_func_uint16_t_u_u((safe_add_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u((&p_30 == (**g_1212)), 4)), p_29)), ((safe_sub_func_uint16_t_u_u(1UL, 0x8EAEL)) & g_315[1][2])))), 9)), p_29)) >= 0xF4L) || p_29), 0x8EL)) ^ p_30)) <= 0xFFL))), (-1L)))), 0xB100L)) | p_30) == 0x94L))
            { /* block id: 592 */
                uint8_t **l_1239 = &g_1013;
                int8_t *l_1246 = &g_79;
                int32_t l_1250 = (-1L);
                uint32_t **l_1262[5][4][5] = {{{&l_1102,&l_1102,(void*)0,&l_1102,(void*)0},{&l_1102,&l_1102,(void*)0,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{(void*)0,&l_1102,&l_1102,&l_1102,&l_1102}},{{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,(void*)0,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,(void*)0,&l_1102}},{{(void*)0,&l_1102,&l_1102,&l_1102,&l_1102},{&l_1102,(void*)0,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102}},{{&l_1102,&l_1102,&l_1102,(void*)0,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{(void*)0,&l_1102,&l_1102,&l_1102,&l_1102}},{{&l_1102,&l_1102,&l_1102,(void*)0,&l_1102},{&l_1102,(void*)0,&l_1102,&l_1102,&l_1102},{&l_1102,&l_1102,&l_1102,&l_1102,&l_1102},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1102}}};
                uint32_t ***l_1261[3][9] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1262[1][2][2],(void*)0,&l_1262[1][2][2],(void*)0,&l_1262[1][2][2],(void*)0,&l_1262[1][2][2],(void*)0,&l_1262[1][2][2]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                uint16_t **l_1263 = &g_100;
                int32_t l_1357 = 0x710F46ADL;
                int i, j, k;
                if ((p_31 = ((~(safe_mul_func_int8_t_s_s((((*l_1246) = (p_30 && ((**l_1020) = ((((((g_1238 = l_1237) != (l_1239 = &g_1013)) == g_154) , ((safe_lshift_func_uint16_t_u_u((*g_100), (((p_29 == (0x77BA9EE3CF89A686LL | (((0x8A021C8671AAF265LL >= (safe_div_func_int32_t_s_s((&p_31 != (void*)0), (*g_478)))) & 0L) != p_29))) <= 65532UL) != p_31))) < p_31)) & 0UL) , p_30)))) != 0xC8L), p_30))) , 6L)))
                { /* block id: 598 */
                    uint16_t **l_1264 = &l_1200;
                    if ((247UL ^ (((+l_1250) != (((void*)0 == &l_1102) != (safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((safe_add_func_int64_t_s_s(1L, (g_2 >= (safe_sub_func_int64_t_s_s(((safe_lshift_func_int8_t_s_s(((((void*)0 == l_1261[0][4]) , ((g_101 , l_1263) == l_1264)) <= l_1026), p_31)) && (**g_1041)), (-1L)))))) < l_1026), p_30)), 0x01L)))) <= 0xE7L)))
                    { /* block id: 599 */
                        return g_315[0][0];
                    }
                    else
                    { /* block id: 601 */
                        return p_30;
                    }
                }
                else
                { /* block id: 604 */
                    const int32_t **l_1294 = &g_575;
                    for (l_1181 = 0; (l_1181 <= (-24)); l_1181 = safe_sub_func_uint16_t_u_u(l_1181, 4))
                    { /* block id: 607 */
                        if (p_30)
                            break;
                    }
                    for (g_884 = (-25); (g_884 != 7); ++g_884)
                    { /* block id: 612 */
                        l_1026 &= ((l_1054 , (&g_1208 != (((safe_rshift_func_uint8_t_u_s(((void*)0 != l_1271), (g_81 , ((safe_lshift_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u(0xBD26L, p_29)) , g_118), 1)) != (((*l_1246) = (l_1276 == (void*)0)) ^ l_1278))))) ^ l_1279[1]) , (void*)0))) || p_31);
                    }
                    l_1167[8][4][1] = (safe_rshift_func_int8_t_s_u(g_315[1][2], (safe_rshift_func_int16_t_s_s((((safe_mod_func_int8_t_s_s(0x91L, (safe_mul_func_int8_t_s_s(p_29, (l_1181 = (p_31 >= ((((&g_315[1][2] != g_1290) & ((((g_327 = ((safe_mod_func_int64_t_s_s(l_1164, (p_30 && 1UL))) & 0x374C85C3L)) , 1UL) > p_29) , p_30)) && 0xAFL) < (**g_477)))))))) <= 0x31A86049CF37DD24LL) , 0xF67EL), l_1293[4]))));
                    (*l_1294) = (*g_922);
                }
                if ((0UL == (safe_div_func_int8_t_s_s(0L, p_31))))
                { /* block id: 621 */
                    uint8_t l_1301 = 2UL;
                    int16_t *l_1333 = &g_283;
                    const uint32_t * const **l_1335 = &l_1334;
                    for (g_283 = 0; (g_283 == (-8)); --g_283)
                    { /* block id: 624 */
                        p_31 = l_1301;
                        l_1302 = l_1302;
                        if ((*l_1302))
                            break;
                    }
                    for (l_1164 = (-14); (l_1164 < (-1)); l_1164++)
                    { /* block id: 631 */
                        uint64_t l_1305[6];
                        int i;
                        for (i = 0; i < 6; i++)
                            l_1305[i] = 0xEB83F0B8A7BCB463LL;
                        return l_1305[0];
                    }
                    for (l_1056 = 3; (l_1056 >= 1); l_1056 -= 1)
                    { /* block id: 636 */
                        uint64_t l_1307 = 0x4D115BF66723BAC2LL;
                        int32_t *l_1308 = &l_1167[3][5][0];
                        int16_t *l_1330[8] = {&g_115,&g_283,&g_115,&g_283,&g_115,&g_283,&g_115,&g_283};
                        int i;
                        p_31 ^= l_1306;
                        (*l_1308) = (p_31 &= ((l_1237 != l_1237) <= (0x52851FD52713F7D6LL < l_1307)));
                        l_1126[4] = (safe_lshift_func_uint16_t_u_u(((**l_1199) = (l_1167[9][3][1] = (++(*g_100)))), (safe_mod_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(l_1319[0], l_1301)) , 0xCADDC24C9AD93938LL), (((((safe_add_func_uint16_t_u_u(((void*)0 == (*l_1237)), ((+((((g_283 ^= (safe_mul_func_int8_t_s_s(((*g_249) && (p_31 | ((((safe_rshift_func_int8_t_s_u((((void*)0 != g_1327) >= g_327), 2)) && 255UL) , 18446744073709551615UL) && 0x6AD4D1FC1095A374LL))), l_1250))) < l_1301) < 4294967288UL) , 1L)) == 0x131C533AL))) , 7UL) ^ l_1250) == l_1250) && 0x282DL))), 0x5C4A45C4AAB29916LL))));
                        if ((*l_1308))
                            break;
                    }
                    l_1026 = (safe_div_func_uint16_t_u_u((((*l_1333) = p_29) > ((&g_1207[4][3] != ((*l_1335) = (((void*)0 == &g_734) , l_1334))) != (p_29 || (l_1336 == &p_29)))), (safe_rshift_func_int8_t_s_s((p_30 , l_1054), 2))));
                }
                else
                { /* block id: 650 */
                    int64_t **l_1340 = &l_1172;
                    int32_t l_1356 = 0x4A8B71C9L;
                    for (g_79 = 0; (g_79 <= 0); g_79 += 1)
                    { /* block id: 653 */
                        int32_t *l_1342 = &l_1181;
                        uint8_t ****l_1353 = &l_1022[1][0][2];
                        uint8_t ***l_1355[6] = {&l_1239,&l_1239,&l_1023[4][5][0],&l_1239,&l_1239,&l_1023[4][5][0]};
                        uint8_t ****l_1354 = &l_1355[0];
                        int i, j, k;
                        (*l_1342) = ((l_1339 , (**g_1327)) == l_1340);
                        if (p_29)
                            break;
                        l_1167[0][6][2] = ((safe_mod_func_int8_t_s_s((l_1357 = (l_1250 &= ((safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s(((((**l_1263) = (((void*)0 != &g_928) , 0x7D76L)) , (((***l_1198) = ((0x89L <= ((g_151 |= ((safe_add_func_int32_t_s_s(0x6B9EF51AL, (safe_mod_func_uint8_t_u_u((p_29 || ((l_1306 < ((((*l_1353) = &g_1238) != ((*l_1354) = &g_1238)) != l_1026)) != p_31)), p_30)))) <= 0x09B3F9C1L)) & 0UL)) , 1UL)) >= (*l_1302))) ^ 65535UL), l_1356)), 0x0779302BB6D5878BLL)) , g_113))), (*l_1302))) && g_81);
                    }
                    g_1358--;
                    return l_1250;
                }
            }
            else
            { /* block id: 668 */
                const int32_t l_1361 = (-1L);
                p_31 = 0xDA89C587L;
                p_31 ^= (l_1026 = ((***g_1040) || l_1361));
            }
            p_31 = (0x4BA3L <= (safe_mul_func_int16_t_s_s(((void*)0 == l_1364), ((l_1365 != (void*)0) <= (safe_add_func_uint16_t_u_u(((**g_1041) = ((safe_sub_func_int32_t_s_s((-7L), 1L)) && (~(safe_div_func_int8_t_s_s((((0x31EEL && (~(!(p_30 , l_1026)))) , p_31) ^ p_30), 7UL))))), (*l_1302)))))));
        }
        p_31 = (((p_31 , ((safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((((l_1026 ^= ((*l_1400) ^= (safe_mod_func_int64_t_s_s(((((*g_1086) ^ (safe_add_func_int16_t_s_s((safe_div_func_uint64_t_u_u(((((-6L) <= ((*l_1386) = p_30)) , &g_528[7]) != ((*l_1389) = g_1387)), ((safe_rshift_func_uint16_t_u_s((***g_1040), ((*l_1366) = (0UL & (+(safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(((safe_div_func_int16_t_s_s(1L, l_1306)) | p_29), 0xC6C9L)), p_29))))))) , g_211[6]))), p_29))) == l_1399) < 0x9693L), p_30)))) , (void*)0) != &g_64), 15)), p_30)) , 0xDBE2L)) != l_1306) , (-5L));
    }
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_39(uint32_t  p_40, uint32_t  p_41)
{ /* block id: 449 */
    int32_t * const l_1000[1][8] = {{(void*)0,(void*)0,&g_118,(void*)0,(void*)0,&g_118,(void*)0,(void*)0}};
    int32_t *l_1001[3][8][5] = {{{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0}},{{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0}},{{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,&g_6,&g_6,(void*)0,(void*)0},{&g_6,(void*)0,&g_118,&g_6,&g_6},{&g_118,(void*)0,&g_118,&g_6,&g_6}}};
    int i, j, k;
    l_1001[1][0][1] = l_1000[0][7];
    return p_40;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_45(const int32_t  p_46, int64_t  p_47)
{ /* block id: 9 */
    uint32_t *l_63[4];
    int32_t l_65 = 0xC6A3F0BDL;
    int32_t l_66 = (-1L);
    int32_t l_67 = (-2L);
    int8_t *l_78 = &g_79;
    uint16_t *l_80 = &g_81;
    int32_t *l_701[4][9] = {{&l_66,&g_6,&g_2,&g_6,&g_2,&l_66,&l_66,&g_2,&g_6},{&g_2,&l_66,&g_2,&l_67,&l_66,&g_6,(void*)0,&g_6,&g_6},{&g_6,&l_66,&g_6,&l_66,&g_6,&l_66,&g_6,(void*)0,&g_2},{(void*)0,&g_6,&l_66,&l_67,&g_2,&l_66,&g_2,&l_67,&l_66}};
    int64_t **l_717 = &g_589;
    int64_t ***l_716 = &l_717;
    int32_t l_780 = 0x7005C5C1L;
    uint32_t l_864 = 3UL;
    uint32_t l_917 = 0xC9A38ECEL;
    int8_t l_918 = (-9L);
    uint16_t l_987 = 0x8362L;
    int i, j;
    for (i = 0; i < 4; i++)
        l_63[i] = &g_64;
    return p_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_79 g_185 g_118 g_115 g_154 g_211 g_151 g_2 g_149 g_249 g_6 g_113 g_64 g_100 g_81
 * writes: g_79 g_185 g_118 g_149 g_283 g_113 g_115 g_315
 */
static const uint16_t  func_56(int32_t * p_57, const uint8_t  p_58, int32_t * p_59)
{ /* block id: 71 */
    int32_t **l_250[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_280 = 0x8495D763L;
    uint32_t *l_289 = &g_64;
    uint16_t **l_421 = &g_100;
    int64_t **l_452 = (void*)0;
    const int32_t *l_573 = &g_6;
    const int8_t * const l_586[10][6] = {{&g_149,(void*)0,&g_149,&g_79,&g_79,&g_149},{&g_151,&g_151,&g_79,&g_149,&g_79,&g_151},{&g_79,(void*)0,&g_149,&g_149,(void*)0,&g_79},{&g_151,&g_79,&g_149,&g_79,&g_151,&g_151},{&g_149,&g_79,&g_79,&g_149,(void*)0,&g_149},{&g_149,(void*)0,&g_149,&g_79,&g_79,&g_149},{&g_151,&g_151,&g_79,&g_149,&g_79,&g_151},{&g_79,(void*)0,&g_149,&g_149,(void*)0,&g_79},{&g_151,&g_79,&g_149,&g_79,&g_151,&g_151},{&g_149,&g_79,&g_79,&g_149,(void*)0,&g_149}};
    int16_t *l_632 = &g_115;
    uint32_t l_697[5];
    int64_t l_700 = 1L;
    int i, j;
    for (i = 0; i < 5; i++)
        l_697[i] = 9UL;
    p_57 = (void*)0;
    for (g_79 = 6; (g_79 != 24); g_79 = safe_add_func_int32_t_s_s(g_79, 1))
    { /* block id: 75 */
        int32_t l_274[10][1][10] = {{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}},{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}}};
        const uint32_t *l_277 = &g_64;
        int32_t **l_325[6] = {&g_249,&g_249,&g_249,&g_249,&g_249,&g_249};
        int32_t ***l_324 = &l_325[0];
        int32_t l_330 = 0xD348A8D5L;
        uint32_t l_406 = 18446744073709551614UL;
        int64_t *l_456 = (void*)0;
        int64_t **l_455[6] = {&l_456,&l_456,&l_456,&l_456,&l_456,&l_456};
        uint64_t l_525 = 0x4600CD059F32DF7ELL;
        uint16_t *l_541 = &g_101;
        const uint16_t l_597 = 0x8B2FL;
        int32_t l_606 = 0x9A4ABD71L;
        uint16_t l_607 = 0x4A0DL;
        int i, j, k;
        for (g_185 = 0; (g_185 < 14); ++g_185)
        { /* block id: 78 */
            int32_t l_267 = 0L;
            int32_t l_284 = 5L;
            int32_t **l_299 = &g_159[8][0];
            for (g_118 = 0; (g_118 > (-6)); g_118 = safe_sub_func_uint64_t_u_u(g_118, 5))
            { /* block id: 81 */
                int32_t l_278[3][8] = {{(-8L),0x021FB113L,(-7L),0L,0L,(-7L),0x021FB113L,(-8L)},{0x021FB113L,1L,(-8L),(-6L),(-8L),1L,0x021FB113L,0x021FB113L},{1L,(-6L),(-7L),(-7L),(-6L),1L,0L,1L}};
                int8_t *l_279 = &g_149;
                int16_t *l_281 = &g_115;
                int16_t *l_282 = &g_283;
                int i, j;
                if ((safe_mod_func_uint64_t_u_u(((g_115 | (+((*l_282) = (((-8L) < (((((safe_rshift_func_int8_t_s_u((~((safe_div_func_uint64_t_u_u(((l_267 , ((safe_div_func_uint8_t_u_u((((((*l_279) = ((((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(p_58, l_274[9][0][4])), ((((safe_div_func_uint64_t_u_u(g_154, p_58)) , (0xB02C8CAAABBA61EALL > ((void*)0 != l_277))) == p_58) & l_278[2][1]))) >= (-1L)) && p_58) | l_267)) < g_79) < 65533UL) & p_58), l_274[8][0][0])) != l_278[2][1])) , 0UL), g_118)) == l_280)), 2)) <= g_211[6]) != 0L) , l_281) != (void*)0)) <= 0xA214L)))) , g_151), l_267)))
                { /* block id: 84 */
                    if ((*p_59))
                        break;
                    if ((*p_59))
                        continue;
                }
                else
                { /* block id: 87 */
                    for (g_149 = 1; (g_149 >= 0); g_149 -= 1)
                    { /* block id: 90 */
                        l_284 = (*g_249);
                        if ((*g_249))
                            continue;
                        if ((*p_59))
                            break;
                    }
                }
                for (g_113 = (-21); (g_113 != 24); ++g_113)
                { /* block id: 98 */
                    const uint32_t l_294 = 0x163A2F53L;
                    int64_t *l_314 = &g_315[1][2];
                    if (l_267)
                    { /* block id: 99 */
                        uint64_t l_295 = 0x013EEB7EE9CA3780LL;
                        l_295 = ((p_58 | 9UL) , ((((*l_282) = (safe_lshift_func_int16_t_s_u(((void*)0 == l_289), 5))) , (0L < (((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((0x93L == l_284), ((void*)0 != &g_283))), l_294)) != l_278[2][1]) , 0x0389L))) , (-1L)));
                    }
                    else
                    { /* block id: 102 */
                        const uint32_t l_296 = 0xC7ACA809L;
                        l_278[2][1] &= l_274[2][0][5];
                        return l_296;
                    }
                    for (l_267 = 0; (l_267 >= 26); ++l_267)
                    { /* block id: 108 */
                        return p_58;
                    }
                    l_284 ^= (((void*)0 == l_299) == (((p_58 < (((((safe_div_func_uint16_t_u_u(((p_58 || (safe_mod_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(p_58, (safe_mul_func_int16_t_s_s((safe_lshift_func_int8_t_s_s((safe_sub_func_int16_t_s_s((l_274[0][0][1] && (((g_64 <= (safe_sub_func_int64_t_s_s(((*l_314) = (((*l_281) = (p_58 | (5UL && l_278[0][7]))) && 0x06E1L)), g_211[1]))) , 0xDABB3FEC30DD82E2LL) , l_274[9][0][4])), 0L)), 3)), 0x99F0L)))), p_58))) >= p_58), (*g_100))) == p_58) != 0x007060064F0C366BLL) ^ 0xFCL) , p_58)) && g_115) ^ 0L));
                }
            }
        }
        for (g_113 = 0; (g_113 == 7); ++g_113)
        { /* block id: 119 */
            uint64_t l_320 = 0x4374FFD2AC4DE56ELL;
            int32_t ***l_321 = (void*)0;
            int32_t ***l_322 = &l_250[1];
            uint64_t *l_326 = &g_327;
            uint16_t l_354[2];
            int32_t l_358 = 1L;
            int32_t l_359 = 0x2C13680DL;
            uint8_t *l_532 = &g_211[0];
            uint8_t ** const l_531 = &l_532;
            int16_t *l_569 = &g_283;
            const int8_t *l_585 = &g_151;
            int64_t *l_588 = &g_315[1][2];
            int32_t *l_590 = &l_359;
            uint8_t **l_600 = &l_532;
            int32_t l_661 = 0x12E56710L;
            int32_t l_663[1];
            uint32_t l_675 = 0xE5F264CAL;
            int i;
            for (i = 0; i < 2; i++)
                l_354[i] = 0x2E63L;
            for (i = 0; i < 1; i++)
                l_663[i] = (-8L);
        }
        return p_58;
    }
    return p_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_81 g_100 g_2 g_101 g_64 g_115 g_79 g_149 g_152 g_174 g_118 g_153 g_154 g_151 g_211 g_159 g_113 g_249
 * writes: g_79 g_81 g_100 g_101 g_113 g_115 g_118 g_149 g_151 g_159 g_185 g_211
 */
static int32_t * func_60(int32_t  p_61, uint64_t  p_62)
{ /* block id: 15 */
    uint16_t * const l_103 = &g_101;
    int64_t l_109 = 0x1E3B40BBFB6FEB77LL;
    int64_t l_110 = 1L;
    int32_t l_120 = (-1L);
    int32_t *l_127 = &g_118;
    uint16_t *l_135 = &g_81;
    uint16_t **l_136 = &g_100;
    const uint16_t *l_138 = &g_101;
    const uint16_t **l_137[6][9] = {{&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138,&l_138},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    uint16_t *l_147 = &g_101;
    uint16_t **l_146 = &l_147;
    int8_t *l_148 = &g_149;
    int8_t *l_150 = &g_151;
    int32_t l_155 = 0xF3906C13L;
    int32_t l_167 = 1L;
    int8_t l_168 = (-2L);
    int32_t l_183 = 0x2268D07AL;
    uint8_t l_212[4][3][6] = {{{0xEBL,0xEAL,8UL,250UL,0xDCL,0x65L},{0xB9L,0xA1L,0xB6L,0xCFL,0xB6L,0xA1L},{0xEFL,4UL,0x65L,0x57L,0xC0L,0xEFL}},{{248UL,250UL,0x85L,0xDCL,0xA1L,0xC4L},{0x94L,250UL,0x31L,8UL,0xC0L,0x59L},{0x65L,4UL,8UL,0xB6L,0xB6L,8UL}},{{0xA1L,0xA1L,0xEFL,0x65L,0xDCL,0xD4L},{0xEFL,0xEAL,253UL,0x85L,0x0BL,0xEFL},{0xC4L,0xEFL,253UL,0x31L,0xA1L,0xD4L}},{{0x59L,0x31L,0xEFL,8UL,0xECL,8UL},{8UL,0xECL,8UL,0xEFL,0x31L,0x59L},{0xD4L,0xA1L,0x31L,253UL,0xEFL,0xC4L}}};
    int16_t *l_221 = (void*)0;
    uint8_t l_223 = 0x32L;
    int32_t *l_243 = &l_155;
    int32_t *l_244 = &l_183;
    int32_t *l_245 = &l_155;
    int32_t *l_246[5];
    int32_t *l_247 = &l_183;
    int32_t *l_248 = &l_183;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_246[i] = &l_167;
lbl_172:
    for (p_62 = 4; (p_62 > 25); ++p_62)
    { /* block id: 18 */
        int8_t *l_90 = &g_79;
        uint16_t *l_95 = (void*)0;
        uint16_t **l_102[1][5][7] = {{{&l_95,&l_95,&l_95,&l_95,&l_95,&l_95,&l_95},{&l_95,&g_100,&l_95,&l_95,&l_95,&l_95,&l_95},{&l_95,&l_95,&l_95,&l_95,&l_95,&l_95,&l_95},{&l_95,&l_95,&l_95,&l_95,&l_95,&l_95,&l_95},{(void*)0,&l_95,(void*)0,&l_95,&l_95,&l_95,(void*)0}}};
        int32_t l_104[2];
        uint64_t *l_111 = (void*)0;
        uint64_t *l_112 = &g_113;
        int16_t *l_114 = &g_115;
        int32_t *l_116 = (void*)0;
        int32_t *l_119 = (void*)0;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_104[i] = (-2L);
        l_120 ^= ((((safe_rshift_func_int16_t_s_u(((*l_114) |= (((*l_112) = (g_6 > (((0x720603003393D3B2LL <= ((&g_79 != &g_79) , ((safe_sub_func_int16_t_s_s(((safe_div_func_int16_t_s_s((((*l_90) = p_62) >= (((safe_div_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((g_81++), (((*l_103) |= (((safe_add_func_int32_t_s_s((l_104[0] = ((g_100 = g_100) == l_103)), (safe_mul_func_uint16_t_u_u((((safe_div_func_uint64_t_u_u(p_62, (p_61 , 18446744073709551615UL))) , l_109) && l_110), p_61)))) | g_6) | g_2)) ^ g_6))), p_62)) == g_6) , l_109)), l_109)) < p_62), 65535UL)) || l_104[0]))) , (void*)0) != (void*)0))) < g_64)), 5)) , g_64) , &g_6) == (void*)0);
    }
    if ((safe_mul_func_uint8_t_u_u(((safe_add_func_uint8_t_u_u(g_2, ((safe_mod_func_int32_t_s_s(((*l_127) = l_110), g_79)) > ((~(l_155 |= (safe_mod_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s((((safe_mod_func_uint8_t_u_u((((*l_136) = l_135) == (((l_137[4][1] = l_137[5][2]) != (((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s((p_62 , ((+(((*l_103) = ((safe_lshift_func_int8_t_s_u(((*l_150) = ((*l_148) = (l_103 != ((*l_146) = l_135)))), 1)) && ((((p_61 ^ 7UL) | g_149) ^ p_62) < p_61))) , 65535UL)) | l_109)), 4)), l_120)) ^ 4UL) , g_152)) , (void*)0)), g_2)) , l_150) == (void*)0), 6)), g_81)))) > p_62)))) != 5UL), p_61)))
    { /* block id: 36 */
        int32_t *l_156 = &l_155;
        int32_t **l_157 = (void*)0;
        int32_t **l_160 = &g_159[8][0];
        int32_t l_163[10];
        uint32_t l_169 = 0x1D2E7F17L;
        int i;
        for (i = 0; i < 10; i++)
            l_163[i] = 0x7B641BACL;
        (*l_160) = l_156;
        if (((*l_127) = (*l_156)))
        { /* block id: 39 */
            int32_t *l_161 = &g_118;
            int32_t *l_162 = &g_118;
            int32_t *l_164 = (void*)0;
            int32_t *l_165 = &l_163[8];
            int32_t *l_166[9] = {&l_163[8],&l_163[8],&l_163[8],&l_163[8],&l_163[8],&l_163[8],&l_163[8],&l_163[8],&l_163[8]};
            int i;
            --l_169;
        }
        else
        { /* block id: 41 */
            if (g_2)
                goto lbl_172;
        }
    }
    else
    { /* block id: 44 */
        int32_t *l_173 = &l_155;
        return g_174;
    }
    if ((safe_mod_func_uint8_t_u_u((*l_127), ((((l_135 != l_103) != (((*l_127) , (p_62 ^ ((safe_lshift_func_int8_t_s_s(((*l_150) = ((5UL && (safe_mod_func_uint8_t_u_u((safe_div_func_int64_t_s_s((((*l_148) = (((void*)0 != (*g_152)) ^ (((((((g_113 = (p_62 , (*l_127))) < 0x076EB19FD917EEAFLL) , 1UL) , g_149) <= g_149) & p_61) & p_61))) < p_62), 18446744073709551608UL)), (*l_127)))) | l_183)), (*l_127))) || g_154))) > (*l_127))) , g_64) | 0x0AA4C988L))))
    { /* block id: 50 */
        int16_t l_184 = (-1L);
        int32_t **l_193 = &g_159[8][0];
        uint64_t *l_210 = &g_113;
        int16_t *l_220 = &g_115;
        int16_t **l_219[1];
        uint8_t *l_224[5];
        int64_t l_239 = (-3L);
        int i;
        for (i = 0; i < 1; i++)
            l_219[i] = &l_220;
        for (i = 0; i < 5; i++)
            l_224[i] = &l_212[3][1][2];
        (*l_127) = ((g_185 = (l_184 | 1UL)) != (!(safe_lshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s(((g_79 >= ((safe_mod_func_int64_t_s_s(((l_193 = l_193) == &g_117[0][0][3]), ((safe_mod_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s(((g_211[6] &= (((safe_div_func_int16_t_s_s((0x19BEL >= (((*l_148) = ((*l_150) &= ((safe_lshift_func_uint16_t_u_u(((*l_127) , (safe_rshift_func_uint16_t_u_u((((safe_mod_func_int64_t_s_s((safe_add_func_int8_t_s_s(g_154, (safe_add_func_int16_t_s_s(g_2, (*g_100))))), 18446744073709551612UL)) , (void*)0) != l_210), p_62))), (*g_100))) ^ g_149))) != (*l_127))), g_118)) && p_61) >= p_62)) ^ 0x3CL), l_184)) >= p_61), 0x0F17L)) , l_212[3][1][2]))) != 2L)) , (-3L)), p_62)), 7))));
        (*l_127) = ((((((((*l_193) != ((((((((*l_103) = ((*g_100) = (safe_lshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_u((((((((void*)0 != (*g_152)) == ((0x3EL == ((*l_127) != (*l_127))) < (-1L))) & (g_185 = (((((safe_mul_func_uint8_t_u_u(((l_221 = &l_184) == ((((((!p_61) , (*l_127)) , 0xFCEAL) == g_115) , p_62) , l_135)), p_62)) & 0xB3L) & l_223) , g_149) || p_62))) , (*l_127)) > (*l_127)) & 0x2199L), 6)), (*l_127))))) || 0L) || (*l_127)) ^ 0xECBAL) >= p_61) , p_62) , (void*)0)) , 0xED0F4632L) != g_113) && (-9L)) < (*l_127)) > p_61) , p_61);
        (*l_127) = (*l_127);
        l_155 ^= ((+((*l_127) == ((g_81 , &g_117[0][3][5]) != (void*)0))) >= ((((safe_add_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(p_62, (~(((((g_151 >= (safe_mul_func_uint16_t_u_u(65526UL, ((l_183 = ((safe_sub_func_int32_t_s_s((((0L && (safe_add_func_int8_t_s_s(((*l_148) = (safe_mul_func_int8_t_s_s(p_62, 0xD3L))), 1UL))) > l_239) , 0L), (*l_127))) ^ p_62)) < 0x25L)))) | 9UL) != 0x32586A36L) , &g_211[6]) == (void*)0)))), p_62)) & 0x5654A653397D4F8ALL) , 2UL) != (*l_127)));
    }
    else
    { /* block id: 66 */
        int8_t l_241 = 0xF3L;
        int32_t *l_242[9];
        int i;
        for (i = 0; i < 9; i++)
            l_242[i] = &g_6;
        l_241 = 0xF6E79546L;
        return l_242[8];
    }
    return g_249;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_185, "g_185", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_211[i], "g_211[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_283, "g_283", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_315[i][j], "g_315[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_327, "g_327", print_hash_value);
    transparent_crc(g_479, "g_479", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_528[i], "g_528[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_544, "g_544", print_hash_value);
    transparent_crc(g_702, "g_702", print_hash_value);
    transparent_crc(g_715, "g_715", print_hash_value);
    transparent_crc(g_734, "g_734", print_hash_value);
    transparent_crc(g_809, "g_809", print_hash_value);
    transparent_crc(g_882, "g_882", print_hash_value);
    transparent_crc(g_884, "g_884", print_hash_value);
    transparent_crc(g_1208, "g_1208", print_hash_value);
    transparent_crc(g_1358, "g_1358", print_hash_value);
    transparent_crc(g_1404, "g_1404", print_hash_value);
    transparent_crc(g_1449, "g_1449", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1486[i][j][k], "g_1486[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1499, "g_1499", print_hash_value);
    transparent_crc(g_1531, "g_1531", print_hash_value);
    transparent_crc(g_1543, "g_1543", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1743[i], "g_1743[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1831[i][j][k], "g_1831[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2025, "g_2025", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2113[i], "g_2113[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2199, "g_2199", print_hash_value);
    transparent_crc(g_2285, "g_2285", print_hash_value);
    transparent_crc(g_2319, "g_2319", print_hash_value);
    transparent_crc(g_2320, "g_2320", print_hash_value);
    transparent_crc(g_2445, "g_2445", print_hash_value);
    transparent_crc(g_2462, "g_2462", print_hash_value);
    transparent_crc(g_2529, "g_2529", print_hash_value);
    transparent_crc(g_2713, "g_2713", print_hash_value);
    transparent_crc(g_2815, "g_2815", print_hash_value);
    transparent_crc(g_2942, "g_2942", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3006[i][j][k], "g_3006[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3015, "g_3015", print_hash_value);
    transparent_crc(g_3167, "g_3167", print_hash_value);
    transparent_crc(g_3296, "g_3296", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_3333[i][j][k], "g_3333[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_3348[i][j][k], "g_3348[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3363, "g_3363", print_hash_value);
    transparent_crc(g_3375, "g_3375", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3383[i], "g_3383[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3458, "g_3458", print_hash_value);
    transparent_crc(g_3479, "g_3479", print_hash_value);
    transparent_crc(g_3484, "g_3484", print_hash_value);
    transparent_crc(g_3531, "g_3531", print_hash_value);
    transparent_crc(g_3540, "g_3540", print_hash_value);
    transparent_crc(g_3587, "g_3587", print_hash_value);
    transparent_crc(g_3624, "g_3624", print_hash_value);
    transparent_crc(g_3626, "g_3626", print_hash_value);
    transparent_crc(g_3872, "g_3872", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_3916[i][j][k], "g_3916[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3987, "g_3987", print_hash_value);
    transparent_crc(g_4139, "g_4139", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1086
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 40
breakdown:
   depth: 1, occurrence: 244
   depth: 2, occurrence: 63
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 7
   depth: 21, occurrence: 5
   depth: 22, occurrence: 1
   depth: 23, occurrence: 2
   depth: 25, occurrence: 3
   depth: 26, occurrence: 5
   depth: 27, occurrence: 2
   depth: 28, occurrence: 3
   depth: 29, occurrence: 5
   depth: 30, occurrence: 2
   depth: 32, occurrence: 4
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 2
   depth: 40, occurrence: 1

XXX total number of pointers: 765

XXX times a variable address is taken: 1732
XXX times a pointer is dereferenced on RHS: 515
breakdown:
   depth: 1, occurrence: 441
   depth: 2, occurrence: 48
   depth: 3, occurrence: 13
   depth: 4, occurrence: 13
XXX times a pointer is dereferenced on LHS: 523
breakdown:
   depth: 1, occurrence: 478
   depth: 2, occurrence: 34
   depth: 3, occurrence: 6
   depth: 4, occurrence: 5
XXX times a pointer is compared with null: 94
XXX times a pointer is compared with address of another variable: 23
XXX times a pointer is compared with another pointer: 30
XXX times a pointer is qualified to be dereferenced: 15255

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2945
   level: 2, occurrence: 577
   level: 3, occurrence: 321
   level: 4, occurrence: 174
XXX number of pointers point to pointers: 414
XXX number of pointers point to scalars: 351
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 32.3
XXX average alias set size: 1.45

XXX times a non-volatile is read: 3218
XXX times a non-volatile is write: 1655
XXX times a volatile is read: 225
XXX    times read thru a pointer: 124
XXX times a volatile is write: 42
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 4.32e+03
XXX percentage of non-volatile access: 94.8

XXX forward jumps: 0
XXX backward jumps: 17

XXX stmts: 254
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 39
   depth: 2, occurrence: 44
   depth: 3, occurrence: 34
   depth: 4, occurrence: 47
   depth: 5, occurrence: 61

XXX percentage a fresh-made variable is used: 14.7
XXX percentage an existing variable is used: 85.3
********************* end of statistics **********************/

