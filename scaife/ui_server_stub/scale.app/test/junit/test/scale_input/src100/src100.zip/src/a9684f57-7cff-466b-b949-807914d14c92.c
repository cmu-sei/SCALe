/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2878147148
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint32_t  f0;
   volatile int32_t  f1;
};

union U1 {
   volatile int32_t  f0;
   uint32_t  f1;
   uint16_t  f2;
   volatile int64_t  f3;
   volatile uint64_t  f4;
};

union U2 {
   volatile int32_t  f0;
   uint32_t  f1;
   const int32_t  f2;
   const uint32_t  f3;
   uint32_t  f4;
};

union U3 {
   volatile unsigned f0 : 28;
   int8_t  f1;
   int8_t * f2;
};

union U4 {
   volatile unsigned f0 : 19;
};

/* --- GLOBAL VARIABLES --- */
static union U3 g_3 = {0x50F82BAEL};/* VOLATILE GLOBAL g_3 */
static int32_t g_6 = (-10L);
static int32_t g_23 = 1L;
static volatile uint64_t g_33 = 0x8EB7BFBC35CF455DLL;/* VOLATILE GLOBAL g_33 */
static int32_t * volatile g_41 = (void*)0;/* VOLATILE GLOBAL g_41 */
static int32_t * volatile g_42 = (void*)0;/* VOLATILE GLOBAL g_42 */
static union U4 g_73 = {0x4AF0E761L};/* VOLATILE GLOBAL g_73 */
static union U2 g_77[7] = {{0x3C28C649L},{0xFD598C55L},{0x3C28C649L},{0x3C28C649L},{0xFD598C55L},{0x3C28C649L},{0x3C28C649L}};
static const int8_t *g_80 = (void*)0;
static int32_t g_85 = 0L;
static int16_t g_98 = 1L;
static volatile union U1 g_103 = {0xFBAD4E8CL};/* VOLATILE GLOBAL g_103 */
static int64_t g_107 = 0x82763D230C2C5401LL;
static int64_t g_110 = 4L;
static const volatile union U3 g_138 = {4294967291UL};/* VOLATILE GLOBAL g_138 */
static int8_t *g_150 = &g_3.f1;
static int8_t g_156 = 0x45L;
static uint8_t g_180 = 0x84L;
static uint32_t g_209 = 4294967289UL;
static volatile uint32_t g_219 = 0x2B265B67L;/* VOLATILE GLOBAL g_219 */
static union U0 g_222 = {0x479E7278L};/* VOLATILE GLOBAL g_222 */
static int16_t g_237 = 0x087BL;
static uint32_t g_243[6] = {0x596F503DL,0x596F503DL,0x596F503DL,0x596F503DL,0x596F503DL,0x596F503DL};
static union U0 g_246 = {3UL};/* VOLATILE GLOBAL g_246 */
static union U0 g_267 = {4294967295UL};/* VOLATILE GLOBAL g_267 */
static uint8_t *** volatile g_270 = (void*)0;/* VOLATILE GLOBAL g_270 */
static union U0 g_272[8][10] = {{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}},{{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L},{0xE92DA704L}}};
static union U2 g_275[8] = {{0xE3678092L},{0xE3678092L},{0xE3678092L},{0xE3678092L},{0xE3678092L},{0xE3678092L},{0xE3678092L},{0xE3678092L}};
static volatile int8_t g_284 = (-1L);/* VOLATILE GLOBAL g_284 */
static int64_t g_300 = 1L;
static volatile int32_t g_301 = 0x165D7144L;/* VOLATILE GLOBAL g_301 */
static uint16_t g_319[2] = {0x34A9L,0x34A9L};
static int32_t *g_322 = &g_6;
static int32_t ** volatile g_321 = &g_322;/* VOLATILE GLOBAL g_321 */
static union U1 g_328 = {-1L};/* VOLATILE GLOBAL g_328 */
static int16_t * volatile g_334 = (void*)0;/* VOLATILE GLOBAL g_334 */
static union U1 g_341 = {-7L};/* VOLATILE GLOBAL g_341 */
static union U1 * const g_340 = &g_341;
static union U3 g_343 = {4294967295UL};/* VOLATILE GLOBAL g_343 */
static uint8_t *g_349 = (void*)0;
static volatile union U4 g_377 = {0xC9E4394CL};/* VOLATILE GLOBAL g_377 */
static int8_t g_401 = 0xEAL;
static uint64_t g_403[1] = {18446744073709551610UL};
static union U2 g_406 = {0L};/* VOLATILE GLOBAL g_406 */
static union U1 g_407 = {0L};/* VOLATILE GLOBAL g_407 */
static int16_t *g_413 = &g_237;
static union U2 g_431[8] = {{0L},{0x0E664F17L},{0x0E664F17L},{0L},{0x0E664F17L},{0x0E664F17L},{0L},{0x0E664F17L}};
static union U1 * volatile g_453 = (void*)0;/* VOLATILE GLOBAL g_453 */
static union U1 g_482 = {1L};/* VOLATILE GLOBAL g_482 */
static int32_t **g_514 = &g_322;
static const volatile union U0 g_571 = {0x48FB3A45L};/* VOLATILE GLOBAL g_571 */
static union U2 g_584 = {1L};/* VOLATILE GLOBAL g_584 */
static union U2 g_605 = {0x7AD80FB5L};/* VOLATILE GLOBAL g_605 */
static int16_t **g_641 = (void*)0;
static const int32_t ***g_670 = (void*)0;
static uint8_t g_728 = 0xDAL;
static uint16_t g_749 = 65535UL;
static volatile union U2 g_763 = {0x92BE9CF6L};/* VOLATILE GLOBAL g_763 */
static const int64_t g_768 = 1L;
static union U1 g_785 = {2L};/* VOLATILE GLOBAL g_785 */
static union U1 g_788[6][1][8] = {{{{0x1E6480EFL},{0xC0AAFDAFL},{0xC0AAFDAFL},{0x1E6480EFL},{0x6939E7FDL},{0x1E6480EFL},{0xC0AAFDAFL},{0xC0AAFDAFL}}},{{{0xC0AAFDAFL},{0x6939E7FDL},{0x5AFE6545L},{0x5AFE6545L},{0x6939E7FDL},{0xC0AAFDAFL},{0x6939E7FDL},{0x5AFE6545L}}},{{{0x1E6480EFL},{0x6939E7FDL},{0x1E6480EFL},{0xC0AAFDAFL},{0xC0AAFDAFL},{0x1E6480EFL},{0x6939E7FDL},{0x1E6480EFL}}},{{{0x6AB176EEL},{0xC0AAFDAFL},{0x5AFE6545L},{0xC0AAFDAFL},{0x6AB176EEL},{0x6AB176EEL},{0xC0AAFDAFL},{0x5AFE6545L}}},{{{0x6AB176EEL},{0x6AB176EEL},{0xC0AAFDAFL},{0x5AFE6545L},{0xC0AAFDAFL},{0x6AB176EEL},{0x6AB176EEL},{0xC0AAFDAFL}}},{{{0x1E6480EFL},{0xC0AAFDAFL},{0xC0AAFDAFL},{0x1E6480EFL},{0x6939E7FDL},{0x1E6480EFL},{0xC0AAFDAFL},{0xC0AAFDAFL}}}};
static volatile union U4 g_792 = {0x078D3A61L};/* VOLATILE GLOBAL g_792 */
static volatile union U1 g_820 = {3L};/* VOLATILE GLOBAL g_820 */
static volatile union U2 g_846 = {-1L};/* VOLATILE GLOBAL g_846 */
static union U2 g_848 = {0x7D2ED4E9L};/* VOLATILE GLOBAL g_848 */
static union U0 g_855 = {0x1B68A4D7L};/* VOLATILE GLOBAL g_855 */
static union U2 g_857 = {0xE38AF897L};/* VOLATILE GLOBAL g_857 */
static volatile union U0 g_886 = {0UL};/* VOLATILE GLOBAL g_886 */
static volatile union U0 * const g_885 = &g_886;
static volatile union U0 * const *g_884 = &g_885;
static volatile union U3 g_900 = {0x831CF050L};/* VOLATILE GLOBAL g_900 */
static union U1 g_927 = {0xD9A0CF40L};/* VOLATILE GLOBAL g_927 */
static volatile union U0 *g_1006 = &g_886;
static volatile union U0 ** volatile g_1005 = &g_1006;/* VOLATILE GLOBAL g_1005 */
static union U2 g_1036 = {1L};/* VOLATILE GLOBAL g_1036 */
static union U1 *g_1059 = &g_341;
static union U1 ** volatile g_1058 = &g_1059;/* VOLATILE GLOBAL g_1058 */
static volatile union U3 g_1073 = {4294967289UL};/* VOLATILE GLOBAL g_1073 */
static union U1 g_1079[9][2][10] = {{{{0x2164896CL},{0x675556B7L},{0L},{1L},{0x54919228L},{0xA339C775L},{0x7AFD7081L},{0x54919228L},{0x4EF93613L},{0xCFD569E5L}},{{0x54919228L},{7L},{-5L},{0x2164896CL},{1L},{0x4881B9F4L},{0x2734C0D7L},{0x4881B9F4L},{1L},{0x2164896CL}}},{{{-1L},{4L},{-1L},{0x4881B9F4L},{0xB6023067L},{0L},{0xE50C58C0L},{0x2734C0D7L},{0L},{0x8E2858F4L}},{{0L},{0x54919228L},{7L},{0L},{0x2164896CL},{0x4ED8497DL},{0x7AFD7081L},{0x2734C0D7L},{0xA339C775L},{1L}}},{{{0xCFD569E5L},{-5L},{-1L},{0x675556B7L},{0L},{0x1A458A85L},{0x54919228L},{0x4881B9F4L},{0x4881B9F4L},{0x54919228L}},{{0xE50C58C0L},{1L},{-5L},{-5L},{1L},{0xE50C58C0L},{0x8E2858F4L},{0x54919228L},{0L},{7L}}},{{{0x675556B7L},{0L},{0L},{0x7AFD7081L},{0xCFD569E5L},{1L},{0x675556B7L},{0xB6023067L},{0x4ED8497DL},{1L}},{{0x675556B7L},{1L},{0xE50C58C0L},{0x2164896CL},{-1L},{0xE50C58C0L},{1L},{0xA1E1B879L},{1L},{1L}}},{{{0x4BC16BE5L},{0L},{0xA1E1B879L},{1L},{1L},{1L},{0xA1E1B879L},{0L},{0x4BC16BE5L},{0x4EF93613L}},{{0xE50C58C0L},{7L},{4L},{1L},{0L},{0xCFD569E5L},{1L},{0xC8643B4CL},{0x54919228L},{0xE50C58C0L}}},{{{7L},{1L},{0x4BC16BE5L},{1L},{0xA339C775L},{2L},{0x4881B9F4L},{0x4ED8497DL},{0x4BC16BE5L},{-5L}},{{0x4EF93613L},{0xC8643B4CL},{2L},{1L},{0x4881B9F4L},{1L},{1L},{0x4881B9F4L},{1L},{2L}}},{{{0x4881B9F4L},{0x4881B9F4L},{0x54919228L},{0x1A458A85L},{0L},{0x675556B7L},{-1L},{-5L},{0xCFD569E5L},{0x1A458A85L}},{{0x1A458A85L},{0xF1E241B9L},{0x4EF93613L},{-5L},{0x4ED8497DL},{2L},{-1L},{0x4BC16BE5L},{2L},{1L}}},{{{7L},{0x4881B9F4L},{0xA339C775L},{7L},{0x1A458A85L},{0L},{1L},{-1L},{1L},{0L}},{{0xE50C58C0L},{0xC8643B4CL},{1L},{0xC8643B4CL},{0xE50C58C0L},{0L},{0x4881B9F4L},{-5L},{0x675556B7L},{0x4881B9F4L}}},{{{-1L},{1L},{7L},{7L},{1L},{0x4BC16BE5L},{1L},{0xA339C775L},{2L},{0x4881B9F4L}},{{0xA1E1B879L},{7L},{2L},{1L},{0xE50C58C0L},{7L},{0xA1E1B879L},{1L},{0L},{0L}}}};
static volatile union U2 *g_1090 = (void*)0;
static const volatile union U1 g_1112[8][6] = {{{0x2B93F4BAL},{-9L},{0L},{0x4D7146F9L},{0L},{-9L}},{{0L},{0x2B93F4BAL},{1L},{0xDF32EE3EL},{0xDF32EE3EL},{1L}},{{0L},{0L},{0xDF32EE3EL},{0x4D7146F9L},{0x1577BECCL},{0x4D7146F9L}},{{0x2B93F4BAL},{0L},{0x2B93F4BAL},{1L},{0xDF32EE3EL},{0xDF32EE3EL}},{{-9L},{0x2B93F4BAL},{0x2B93F4BAL},{-9L},{0L},{0x4D7146F9L}},{{0x4D7146F9L},{-9L},{0xDF32EE3EL},{-9L},{0x4D7146F9L},{1L}},{{-9L},{0x4D7146F9L},{1L},{1L},{0x4D7146F9L},{-9L}},{{0x2B93F4BAL},{-9L},{0L},{0x4D7146F9L},{0L},{-9L}}};
static int32_t *g_1148 = &g_85;
static int32_t ** volatile g_1147 = &g_1148;/* VOLATILE GLOBAL g_1147 */
static volatile union U3 g_1206[9][3][4] = {{{{4294967295UL},{0x67C3C641L},{0UL},{3UL}},{{0xD0914C32L},{4294967295UL},{0x5F3CE874L},{0xC57E0738L}},{{4294967286UL},{0x1FAE3BEFL},{4294967295UL},{0xC57E0738L}}},{{{1UL},{4294967295UL},{0UL},{3UL}},{{0xA72B672EL},{0x67C3C641L},{1UL},{0x5F3CE874L}},{{4294967288UL},{0xA72B672EL},{4294967295UL},{0x484F8B82L}}},{{{1UL},{4294967295UL},{0x9D54447AL},{4294967295UL}},{{1UL},{0xC57E0738L},{0x1FAE3BEFL},{0x2D07CF0BL}},{{4294967287UL},{0xA05A6A5FL},{0x2D07CF0BL},{0xA72B672EL}}},{{{0x484F8B82L},{1UL},{0xC57E0738L},{0xD0914C32L}},{{0xA05A6A5FL},{0x9D54447AL},{0xC57E0738L},{0xA72B672EL}},{{0xA72B672EL},{0xD0914C32L},{4294967288UL},{3UL}}},{{{0x66FC0C42L},{4294967295UL},{0x67C3C641L},{0xC001BE04L}},{{0UL},{0x67C3C641L},{4294967295UL},{4294967295UL}},{{3UL},{3UL},{1UL},{4294967286UL}}},{{{0x484F8B82L},{0xB1820BF3L},{0x5F3CE874L},{0UL}},{{1UL},{1UL},{0x9E47D628L},{0x5F3CE874L}},{{0x9D54447AL},{1UL},{4294967295UL},{0UL}}},{{{1UL},{0xB1820BF3L},{0xC001BE04L},{4294967286UL}},{{4294967287UL},{3UL},{0x484F8B82L},{4294967295UL}},{{4294967295UL},{0x67C3C641L},{0x1FAE3BEFL},{0xC001BE04L}}},{{{0xB1820BF3L},{4294967295UL},{0xB1820BF3L},{3UL}},{{0xC001BE04L},{0xD0914C32L},{0UL},{0xA72B672EL}},{{0x9E47D628L},{0x9D54447AL},{0x56435505L},{0xD0914C32L}}},{{{1UL},{0UL},{0x56435505L},{0x484F8B82L}},{{0x9E47D628L},{4294967286UL},{0UL},{0xC57E0738L}},{{0xC001BE04L},{0x1CE3E5BDL},{0xB1820BF3L},{0x9E47D628L}}}};
static union U0 g_1210 = {4294967286UL};/* VOLATILE GLOBAL g_1210 */
static union U0 *g_1209 = &g_1210;
static union U0 **g_1208 = &g_1209;
static union U0 ***g_1207 = &g_1208;
static union U1 g_1228[5] = {{-5L},{-5L},{-5L},{-5L},{-5L}};
static int32_t *g_1229 = &g_85;
static volatile union U1 g_1236[6][2][5] = {{{{-3L},{-5L},{1L},{-2L},{3L}},{{3L},{-2L},{1L},{-5L},{-3L}}},{{{3L},{-5L},{0x41E72A80L},{-5L},{3L}},{{-3L},{-5L},{1L},{-2L},{3L}}},{{{3L},{-2L},{1L},{-5L},{-3L}},{{3L},{-5L},{0x41E72A80L},{-5L},{3L}}},{{{-3L},{-5L},{1L},{-2L},{3L}},{{3L},{-2L},{1L},{-5L},{-3L}}},{{{3L},{-5L},{0x41E72A80L},{-5L},{3L}},{{-3L},{-5L},{1L},{-2L},{3L}}},{{{3L},{-2L},{1L},{-5L},{-3L}},{{3L},{-5L},{0x41E72A80L},{-5L},{3L}}}};
static const union U2 g_1258 = {0L};/* VOLATILE GLOBAL g_1258 */
static uint8_t g_1266[1] = {0UL};
static union U4 g_1274 = {0x2E704A89L};/* VOLATILE GLOBAL g_1274 */
static volatile union U3 g_1277 = {0xA1682999L};/* VOLATILE GLOBAL g_1277 */
static int64_t *g_1287 = (void*)0;
static volatile uint64_t g_1318 = 0UL;/* VOLATILE GLOBAL g_1318 */
static volatile uint32_t g_1364 = 0x774C1B42L;/* VOLATILE GLOBAL g_1364 */
static union U3 g_1369[6][1] = {{{0UL}},{{0UL}},{{0UL}},{{0UL}},{{0UL}},{{0UL}}};
static volatile uint64_t g_1390 = 0x98051A7B2DDA6519LL;/* VOLATILE GLOBAL g_1390 */
static volatile union U2 g_1434 = {4L};/* VOLATILE GLOBAL g_1434 */
static uint32_t g_1450 = 7UL;
static volatile union U2 g_1468 = {0x7BCC34ABL};/* VOLATILE GLOBAL g_1468 */
static volatile union U4 g_1472 = {9UL};/* VOLATILE GLOBAL g_1472 */
static union U1 g_1484 = {0xDB537491L};/* VOLATILE GLOBAL g_1484 */
static union U3 g_1526 = {0xFD619E73L};/* VOLATILE GLOBAL g_1526 */
static union U4 *g_1540 = &g_73;
static union U4 ** volatile g_1539[7] = {&g_1540,&g_1540,&g_1540,&g_1540,&g_1540,&g_1540,&g_1540};
static union U4 ** const  volatile g_1541 = (void*)0;/* VOLATILE GLOBAL g_1541 */
static union U4 ** volatile g_1542 = (void*)0;/* VOLATILE GLOBAL g_1542 */
static union U4 ** volatile g_1544 = &g_1540;/* VOLATILE GLOBAL g_1544 */
static union U1 g_1639[5][8] = {{{-1L},{-7L},{0xFF8093D6L},{0x0BA4C776L},{0x03B527EEL},{9L},{0x03B527EEL},{0x0BA4C776L}},{{0x1BA52617L},{0xDBA3F97DL},{0x1BA52617L},{0x70745429L},{9L},{0xC3C18EE8L},{-7L},{0x3007C830L}},{{0x0BA4C776L},{0x1BA52617L},{0x03B527EEL},{0x67C4FADEL},{-1L},{1L},{9L},{9L}},{{0x0BA4C776L},{9L},{0x1071850CL},{0x1071850CL},{9L},{0x0BA4C776L},{0xDBA3F97DL},{-9L}},{{0x1BA52617L},{3L},{1L},{0xDBA3F97DL},{0x03B527EEL},{1L},{0x3007C830L},{0x7DF27945L}}};
static int8_t g_1699[7] = {1L,1L,1L,1L,1L,1L,1L};
static volatile union U4 g_1712 = {4294967295UL};/* VOLATILE GLOBAL g_1712 */
static uint32_t g_1713 = 4294967289UL;
static volatile uint64_t g_1736 = 0x07DD6ADCD0D23E44LL;/* VOLATILE GLOBAL g_1736 */
static union U4 **g_1743 = (void*)0;
static volatile union U1 g_1765 = {1L};/* VOLATILE GLOBAL g_1765 */
static int64_t g_1799 = 0L;
static int32_t g_1800 = (-6L);
static volatile int32_t g_1801 = 1L;/* VOLATILE GLOBAL g_1801 */
static union U4 g_1818 = {3UL};/* VOLATILE GLOBAL g_1818 */
static union U2 g_1826 = {0xEAC35167L};/* VOLATILE GLOBAL g_1826 */
static const union U2 g_1829 = {-1L};/* VOLATILE GLOBAL g_1829 */
static uint8_t **g_1831 = (void*)0;
static uint8_t ** volatile *g_1830 = &g_1831;
static union U3 **g_1871 = (void*)0;
static int32_t ** volatile g_1877 = &g_1229;/* VOLATILE GLOBAL g_1877 */
static const uint8_t g_1902 = 0UL;
static const uint8_t *g_1901 = &g_1902;
static const uint8_t **g_1900[10] = {&g_1901,&g_1901,&g_1901,&g_1901,&g_1901,&g_1901,&g_1901,&g_1901,&g_1901,&g_1901};
static const uint8_t ***g_1899[10][6] = {{&g_1900[9],&g_1900[9],&g_1900[2],&g_1900[9],&g_1900[9],&g_1900[9]},{&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],(void*)0,&g_1900[2]},{&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9]},{&g_1900[6],&g_1900[9],&g_1900[2],&g_1900[9],&g_1900[2],&g_1900[9]},{&g_1900[9],&g_1900[2],&g_1900[9],&g_1900[6],&g_1900[9],(void*)0},{&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[8]},{&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[7]},{&g_1900[9],&g_1900[2],&g_1900[9],&g_1900[9],&g_1900[2],&g_1900[9]},{(void*)0,&g_1900[9],&g_1900[9],&g_1900[7],&g_1900[9],&g_1900[6]},{&g_1900[9],&g_1900[9],&g_1900[9],&g_1900[9],(void*)0,&g_1900[9]}};
static int32_t * volatile g_1910 = &g_6;/* VOLATILE GLOBAL g_1910 */
static union U2 g_1917 = {0xB39F7452L};/* VOLATILE GLOBAL g_1917 */
static union U2 g_1960 = {0x06223162L};/* VOLATILE GLOBAL g_1960 */
static volatile int8_t g_1988 = 1L;/* VOLATILE GLOBAL g_1988 */
static volatile union U4 g_2005[7][9] = {{{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL}},{{1UL},{0UL},{0xD064A5F1L},{0UL},{0xD064A5F1L},{0UL},{1UL},{0UL},{0xD064A5F1L}},{{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL}},{{1UL},{0UL},{0xD064A5F1L},{0UL},{0xD064A5F1L},{0UL},{1UL},{0UL},{0xD064A5F1L}},{{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL}},{{1UL},{0UL},{0xD064A5F1L},{0UL},{0xD064A5F1L},{0UL},{1UL},{0UL},{0xD064A5F1L}},{{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL},{4294967291UL},{4294967294UL},{4294967294UL}}};
static union U0 g_2018[3][3] = {{{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL}}};
static union U2 g_2039 = {0L};/* VOLATILE GLOBAL g_2039 */
static union U2 g_2069 = {9L};/* VOLATILE GLOBAL g_2069 */
static volatile uint64_t g_2098 = 0x02BFC0995C3BE002LL;/* VOLATILE GLOBAL g_2098 */
static union U1 ** const  volatile g_2110 = (void*)0;/* VOLATILE GLOBAL g_2110 */
static uint64_t g_2122 = 18446744073709551615UL;
static union U3 g_2131 = {0x8629F094L};/* VOLATILE GLOBAL g_2131 */
static union U3 g_2133 = {0xB0C7D37EL};/* VOLATILE GLOBAL g_2133 */
static union U3 g_2134 = {0x6DCA8C0CL};/* VOLATILE GLOBAL g_2134 */
static volatile uint32_t *g_2139 = &g_219;
static volatile uint32_t * volatile *g_2138 = &g_2139;
static volatile union U4 g_2142 = {0xD99F9FDEL};/* VOLATILE GLOBAL g_2142 */
static union U4 g_2169 = {4294967295UL};/* VOLATILE GLOBAL g_2169 */
static volatile union U0 g_2185 = {4294967295UL};/* VOLATILE GLOBAL g_2185 */
static volatile uint32_t g_2190 = 4294967286UL;/* VOLATILE GLOBAL g_2190 */
static union U2 g_2211 = {0x82DA40B6L};/* VOLATILE GLOBAL g_2211 */
static volatile union U0 g_2229[7] = {{0x72C9087FL},{0x72C9087FL},{0x72C9087FL},{0x72C9087FL},{0x72C9087FL},{0x72C9087FL},{0x72C9087FL}};
static union U3 g_2264[2][6] = {{{0UL},{0xAD787337L},{0UL},{0UL},{0xAD787337L},{0UL}},{{0UL},{0xAD787337L},{0UL},{0UL},{0xAD787337L},{0UL}}};
static union U1 g_2277 = {0L};/* VOLATILE GLOBAL g_2277 */
static union U1 ** volatile g_2383 = &g_1059;/* VOLATILE GLOBAL g_2383 */
static union U1 ** volatile *g_2382[3] = {&g_2383,&g_2383,&g_2383};
static union U0 g_2411 = {5UL};/* VOLATILE GLOBAL g_2411 */
static volatile union U2 g_2429 = {0x10DA4105L};/* VOLATILE GLOBAL g_2429 */
static const union U4 g_2451 = {0UL};/* VOLATILE GLOBAL g_2451 */
static volatile uint64_t *g_2468 = &g_1318;
static volatile uint64_t ** volatile g_2467[8] = {&g_2468,&g_2468,&g_2468,&g_2468,&g_2468,&g_2468,&g_2468,&g_2468};
static volatile uint64_t ** volatile * volatile g_2470 = &g_2467[1];/* VOLATILE GLOBAL g_2470 */
static union U2 g_2471[8][5][4] = {{{{-7L},{-1L},{-1L},{0x0FEB4770L}},{{-10L},{3L},{6L},{0x34DB30C3L}},{{0x2D33BA1AL},{1L},{0x6F8AB14AL},{5L}},{{0x2D33BA1AL},{0x89671A6AL},{6L},{-10L}},{{0L},{-1L},{9L},{0x9A6155D2L}}},{{{-1L},{0L},{0xDC3A142EL},{-1L}},{{0xF538E6FAL},{9L},{0xEA3C5184L},{-3L}},{{0x26089A97L},{0xF2839BF7L},{0x82C291AEL},{-1L}},{{-1L},{0x34DB30C3L},{6L},{0L}},{{-1L},{6L},{1L},{-3L}}},{{{4L},{0L},{0x6F8AB14AL},{0x172BADB0L}},{{0xD3FE8836L},{0L},{0L},{0xF538E6FAL}},{{0xEEDDB4CCL},{0xEA3C5184L},{-1L},{-10L}},{{9L},{-4L},{0x26089A97L},{0xEA3C5184L}},{{0x73399AE0L},{-1L},{-1L},{-1L}}},{{{0L},{1L},{-1L},{6L}},{{-1L},{0x7C11D11DL},{0x6E820C05L},{0x6E820C05L}},{{0xD3FE8836L},{0xD3FE8836L},{0x66EC964AL},{0xEEDDB4CCL}},{{6L},{-1L},{1L},{0L}},{{0x95AE2A08L},{-10L},{-9L},{1L}}},{{{-1L},{-10L},{0xFC6AC27CL},{0L}},{{-10L},{-1L},{0xEA3C5184L},{0xEEDDB4CCL}},{{0x9A6155D2L},{0xD3FE8836L},{-1L},{0x6E820C05L}},{{-1L},{0x7C11D11DL},{0x2D33BA1AL},{6L}},{{-3L},{1L},{6L},{-1L}}},{{{-1L},{-1L},{0L},{0xEA3C5184L}},{{0L},{-4L},{0x14FEE032L},{-10L}},{{-3L},{0xEA3C5184L},{9L},{0xF538E6FAL}},{{0x172BADB0L},{0L},{-1L},{0x172BADB0L}},{{0xF538E6FAL},{0L},{0x0A172249L},{-3L}}},{{{-10L},{6L},{0x82C291AEL},{0L}},{{0xEA3C5184L},{0x34DB30C3L},{-9L},{-1L}},{{-1L},{0xF2839BF7L},{0x6EFCF615L},{-3L}},{{6L},{9L},{0x6F8AB14AL},{-1L}},{{0x6E820C05L},{0L},{0x6E820C05L},{0x9A6155D2L}}},{{{0xEEDDB4CCL},{-1L},{1L},{-10L}},{{0L},{0x82C291AEL},{0x26089A97L},{-1L}},{{1L},{-1L},{0x26089A97L},{0x95AE2A08L}},{{0L},{0x73399AE0L},{1L},{6L}},{{0xEEDDB4CCL},{0x6F8AB14AL},{0x6E820C05L},{0xD3FE8836L}}}};
static uint32_t g_2481[10][4] = {{0x98A9BD20L,0x477C1ABFL,0x98A9BD20L,0x6C5FA049L},{0x7C180BFCL,0x477C1ABFL,0xDCC97AE6L,0xCFB37165L},{0x477C1ABFL,1UL,1UL,0x477C1ABFL},{0x98A9BD20L,0xCFB37165L,1UL,0x6C5FA049L},{0x477C1ABFL,0x7C180BFCL,0xDCC97AE6L,0x7C180BFCL},{0x7C180BFCL,1UL,0x98A9BD20L,0x7C180BFCL},{0x98A9BD20L,0x7C180BFCL,0x6C5FA049L,0x6C5FA049L},{0xCFB37165L,0xCFB37165L,0xDCC97AE6L,0x477C1ABFL},{0xCFB37165L,1UL,0x6C5FA049L,0xCFB37165L},{0x98A9BD20L,0x477C1ABFL,0x98A9BD20L,0x6C5FA049L}};
static uint64_t **g_2491 = (void*)0;
static uint64_t *g_2493 = &g_403[0];
static uint64_t **g_2492 = &g_2493;
static const union U4 g_2499 = {4294967294UL};/* VOLATILE GLOBAL g_2499 */
static volatile union U3 g_2500 = {0x17D5B0DAL};/* VOLATILE GLOBAL g_2500 */
static union U4 g_2533 = {1UL};/* VOLATILE GLOBAL g_2533 */
static uint8_t g_2542 = 0x5BL;
static union U2 g_2566[9] = {{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}};
static volatile union U0 g_2569 = {4294967287UL};/* VOLATILE GLOBAL g_2569 */
static union U2 g_2576[3] = {{0x3F4B1415L},{0x3F4B1415L},{0x3F4B1415L}};
static union U4 ***g_2577 = &g_1743;
static union U2 g_2638 = {1L};/* VOLATILE GLOBAL g_2638 */
static uint64_t * const *g_2656 = (void*)0;
static uint64_t * const **g_2655[7] = {&g_2656,&g_2656,&g_2656,&g_2656,&g_2656,&g_2656,&g_2656};
static int8_t g_2678 = 5L;
static volatile uint32_t g_2696 = 0xD56FFF88L;/* VOLATILE GLOBAL g_2696 */
static union U2 g_2705[10][7][3] = {{{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}},{{9L},{0x94B5413AL},{0xB2AC475FL}},{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}},{{0x8F03CA48L},{-3L},{-5L}},{{0xCB713674L},{0xA1D81846L},{0xCB713674L}},{{0x5E828295L},{0L},{-5L}}},{{{9L},{9L},{0x94B5413AL}},{{0xEE96B9A7L},{0L},{0x8F03CA48L}},{{0x94B5413AL},{0xA1D81846L},{0xB2AC475FL}},{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}},{{9L},{0x94B5413AL},{0xB2AC475FL}},{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}}},{{{0x8F03CA48L},{-3L},{-5L}},{{0xCB713674L},{0xA1D81846L},{0xCB713674L}},{{0x5E828295L},{0L},{-5L}},{{9L},{9L},{0x94B5413AL}},{{0xEE96B9A7L},{0L},{0x8F03CA48L}},{{0x94B5413AL},{0xA1D81846L},{0xB2AC475FL}},{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}}},{{{9L},{0x94B5413AL},{0xB2AC475FL}},{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}},{{0x8F03CA48L},{-3L},{-5L}},{{0xCB713674L},{0xA1D81846L},{0xCB713674L}},{{0x5E828295L},{0L},{-5L}},{{9L},{9L},{0x94B5413AL}}},{{{0xEE96B9A7L},{0L},{0x8F03CA48L}},{{0x94B5413AL},{0xA1D81846L},{0xB2AC475FL}},{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}},{{9L},{0x94B5413AL},{0xB2AC475FL}},{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}},{{0x8F03CA48L},{-3L},{-5L}}},{{{0xCB713674L},{0xA1D81846L},{0xCB713674L}},{{0x5E828295L},{0L},{-5L}},{{9L},{9L},{0x94B5413AL}},{{0xEE96B9A7L},{0L},{0x8F03CA48L}},{{0x94B5413AL},{0xA1D81846L},{0xB2AC475FL}},{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}},{{9L},{0x94B5413AL},{0xB2AC475FL}}},{{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}},{{0x8F03CA48L},{-3L},{-5L}},{{0xCB713674L},{0xA1D81846L},{0xCB713674L}},{{0x5E828295L},{0L},{-5L}},{{9L},{9L},{0x94B5413AL}},{{0xEE96B9A7L},{0L},{0x8F03CA48L}}},{{{0x94B5413AL},{0xA1D81846L},{0xB2AC475FL}},{{0xEE96B9A7L},{-3L},{0xEE96B9A7L}},{{9L},{0x94B5413AL},{0xB2AC475FL}},{{0x5E828295L},{1L},{0x8F03CA48L}},{{0xCB713674L},{0x94B5413AL},{0x94B5413AL}},{{0x8F03CA48L},{-3L},{-5L}},{{0xCB713674L},{0xA1D81846L},{0xCB713674L}}},{{{0x5E828295L},{0L},{-5L}},{{9L},{9L},{0x94B5413AL}},{{0xEE96B9A7L},{0L},{0x8F03CA48L}},{{0xCB713674L},{9L},{0xA1D81846L}},{{-5L},{1L},{-5L}},{{0x94B5413AL},{0xCB713674L},{0xA1D81846L}},{{0x8F03CA48L},{0L},{0xEE96B9A7L}}},{{{0xB2AC475FL},{0xCB713674L},{0xCB713674L}},{{0xEE96B9A7L},{1L},{0xF875AC5EL}},{{0xB2AC475FL},{9L},{0xB2AC475FL}},{{0x8F03CA48L},{0x9A508459L},{0xF875AC5EL}},{{0x94B5413AL},{0x94B5413AL},{0xCB713674L}},{{-5L},{0x9A508459L},{0xEE96B9A7L}},{{0xCB713674L},{9L},{0xA1D81846L}}}};
static const union U0 g_2720 = {0xBD8380ACL};/* VOLATILE GLOBAL g_2720 */
static const union U0 *****g_2721 = (void*)0;
static union U3 g_2752 = {0xF3CBF744L};/* VOLATILE GLOBAL g_2752 */
static union U2 g_2773 = {0xB85A483AL};/* VOLATILE GLOBAL g_2773 */
static union U2 g_2774 = {0L};/* VOLATILE GLOBAL g_2774 */


/* --- FORWARD DECLARATIONS --- */
static union U2  func_1(void);
static int32_t  func_7(uint8_t  p_8, uint32_t  p_9, uint32_t  p_10, int8_t * p_11, uint32_t  p_12);
static uint8_t  func_13(int32_t * p_14, int8_t * p_15, int8_t * p_16);
static int8_t * func_18(uint8_t  p_19, const int8_t  p_20);
static int16_t  func_36(int32_t * p_37);
static union U2  func_45(uint8_t  p_46);
static union U0  func_47(int32_t * p_48, const uint32_t  p_49);
static int32_t * func_54(int32_t  p_55, int8_t * p_56);
static int8_t  func_61(uint64_t  p_62, int32_t * p_63);
static uint64_t  func_64(int16_t  p_65, const int32_t * p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_3.f1 g_6 g_33 g_403 g_272.f0 g_23 g_138.f0 g_605.f2 g_514 g_322 g_670 g_406.f4 g_319 g_413 g_237 g_85 g_209 g_1544 g_1148 g_605.f4 g_1229 g_1147 g_1112.f2 g_407.f1 g_243 g_150 g_98 g_788.f2 g_1236.f0 g_1258.f2 g_1207 g_1639 g_401 g_275.f1 g_848.f3 g_1228.f1 g_267.f0 g_406.f2 g_73 g_77 g_80 g_77.f4 g_77.f0 g_77.f2 g_103 g_73.f0 g_138 g_103.f0 g_110 g_77.f3 g_77.f1 g_180 g_107 g_219 g_222 g_222.f0 g_246 g_267 g_272 g_1699 g_584.f1 g_1712 g_1079.f2 g_1736 g_1209 g_884 g_885 g_1484.f2 g_275.f4 g_886 g_1765 g_482.f2 g_407.f2 g_1712.f0 g_605.f1 g_1058 g_1059 g_1210.f0 g_1917.f4 g_2005 g_855.f0 g_1208 g_820.f1 g_2039.f1 g_1910 g_2492 g_2493 g_2533 g_2542 g_1484.f0 g_2566 g_2569 g_2576 g_1206 g_846.f3 g_275.f2 g_1540 g_246.f0 g_2720 g_2721 g_1266 g_1829.f4 g_1901 g_1902 g_2470 g_2467 g_1468.f1 g_2773 g_2752 g_2774
 * writes: g_3.f1 g_6 g_33 g_403 g_641 g_156 g_246.f0 g_670 g_107 g_180 g_85 g_209 g_328.f2 g_1540 g_1148 g_605.f4 g_243 g_1266 g_98 g_401 g_788.f2 g_343.f1 g_1208 g_267.f0 g_322 g_237 g_23 g_110 g_150 g_77.f1 g_219 g_1699 g_1713 g_1736 g_1036.f4 g_1743 g_1209 g_482.f2 g_407.f2 g_1059 g_1210.f0 g_1917.f4 g_855.f0 g_2039.f1 g_2542 g_2577
 */
static union U2  func_1(void)
{ /* block id: 0 */
    const uint8_t l_2[2] = {255UL,255UL};
    int8_t *l_4 = &g_3.f1;
    int32_t *l_5 = &g_6;
    int32_t l_2541[6][9] = {{1L,0L,1L,1L,4L,0L,0x2B02BD37L,0x2B02BD37L,0L},{0x9CDFE447L,0xA741D36CL,0x82595C5FL,0xA741D36CL,0x9CDFE447L,0x731F4F81L,(-7L),1L,1L},{7L,0L,0L,1L,0L,0L,7L,4L,0x9D4B95A2L},{(-1L),0L,0xA741D36CL,0x731F4F81L,0x91D5DCE1L,0x731F4F81L,0xA741D36CL,0L,(-1L)},{0L,0x285797C1L,0x2B02BD37L,4L,1L,0L,1L,4L,0x2B02BD37L},{(-7L),(-7L),0xDA4511E2L,0x82595C5FL,0L,1L,(-1L),1L,0L}};
    int32_t l_2551 = 7L;
    int32_t l_2563 = 1L;
    uint64_t l_2564 = 1UL;
    uint32_t l_2579 = 0xBB1300CAL;
    int32_t l_2582 = 1L;
    int8_t l_2594[4][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}};
    uint32_t l_2595 = 0x4D355714L;
    uint32_t *l_2735 = &g_267.f0;
    uint32_t **l_2734 = &l_2735;
    union U3 *l_2751 = &g_2752;
    int i, j;
    if (((*l_5) = ((l_2[1] & (g_3 , ((*l_4) = l_2[0]))) ^ ((void*)0 != l_4))))
    { /* block id: 3 */
        int32_t *l_17[7][8][4] = {{{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6}},{{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6}},{{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6}},{{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6}},{{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6}},{{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6}},{{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,(void*)0,&g_6},{(void*)0,&g_6,(void*)0,&g_6}}};
        union U0 **l_1745 = &g_1209;
        int8_t *l_1746 = &g_3.f1;
        uint8_t l_2560 = 252UL;
        uint16_t *l_2593 = &g_328.f2;
        int i, j, k;
        if (func_7(g_3.f1, (func_13(l_17[1][2][3], func_18((*l_5), (*l_5)), (g_23 , (l_4 = &g_401))) < (((*l_1745) = g_1209) == (*g_884))), g_1484.f2, l_1746, g_275[1].f4))
        { /* block id: 1112 */
            union U3 *l_2521 = &g_1369[0][0];
            union U3 **l_2522 = &l_2521;
            union U3 *l_2534 = &g_1369[2][0];
            int32_t l_2539[9][10][2] = {{{0x135DA953L,(-1L)},{0x7C06D107L,(-1L)},{0xA69AFAF4L,0xC593D492L},{(-9L),0L},{0x1DFB7188L,(-4L)},{(-1L),0xF4C32BA3L},{0x8608E17EL,1L},{5L,0xCC175484L},{1L,(-4L)},{0xF73F8CE2L,0L}},{{0xE6A799F2L,0x2E2CB927L},{(-1L),(-1L)},{0x126B779AL,0xA49B8B61L},{(-4L),0xF906890EL},{0xAEB32656L,0x320B02AFL},{0x173CAAA2L,0xE4DB9784L},{0x17C48673L,0xF15BAB5EL},{0xD71C7E5FL,0x41E7B7F1L},{0xE4DB9784L,0L},{(-1L),(-6L)}},{{0x9184764DL,0xF73F8CE2L},{0x070F1F24L,(-1L)},{0xA9602D0FL,0xD71C7E5FL},{0x80DCD9BEL,0x6A7F9BF0L},{(-8L),0x6A7F9BF0L},{0x80DCD9BEL,0xD71C7E5FL},{0xA9602D0FL,0xA49B8B61L},{0L,(-1L)},{0xF73F8CE2L,5L},{0x1DFB7188L,(-1L)}},{{0L,0xD71C7E5FL},{0x070F1F24L,0x2E2CB927L},{0x70136321L,0L},{0xCAB27E63L,0x04AC850AL},{1L,(-6L)},{0x173CAAA2L,0xD1C27F07L},{1L,0xE609EB06L},{1L,0x4C3AD11CL},{(-2L),0L},{(-1L),0x173CAAA2L}},{{(-1L),0xE6A799F2L},{(-8L),0x17C48673L},{0x89BF7EEBL,0xAEB32656L},{(-8L),(-1L)},{(-10L),(-4L)},{0xA69AFAF4L,0x320B02AFL},{(-1L),0xC48B3309L},{0xF906890EL,0x126B779AL},{(-4L),(-9L)},{0xA9602D0FL,0xEAD63A47L}},{{(-1L),0xFF5AF1EDL},{(-1L),0x9184764DL},{0xE609EB06L,(-8L)},{0x320B02AFL,0x6A7F9BF0L},{0xE6A799F2L,0x70136321L},{0L,(-1L)},{0x1706E8D5L,(-6L)},{(-1L),(-1L)},{(-1L),0x89BF7EEBL},{0x4C3AD11CL,0xD41ED171L}},{{0xC593D492L,0xC593D492L},{0x80DCD9BEL,(-1L)},{0xEAD63A47L,0x135DA953L},{0xCC175484L,(-2L)},{9L,0xCC175484L},{0x17C48673L,0xA69AFAF4L},{0x17C48673L,0xCC175484L},{9L,(-2L)},{0xCC175484L,0x135DA953L},{0xEAD63A47L,(-1L)}},{{0x80DCD9BEL,0xC593D492L},{0xC593D492L,0xD41ED171L},{0x4C3AD11CL,0x89BF7EEBL},{(-1L),(-1L)},{(-1L),(-6L)},{0x1706E8D5L,(-1L)},{0L,0x70136321L},{0xE6A799F2L,0x6A7F9BF0L},{0x320B02AFL,(-8L)},{0xE609EB06L,0x9184764DL}},{{(-1L),0xFF5AF1EDL},{(-1L),0xEAD63A47L},{0xA9602D0FL,(-9L)},{(-4L),0x126B779AL},{0xF906890EL,0xC48B3309L},{(-1L),0x320B02AFL},{0xA69AFAF4L,(-4L)},{(-10L),(-1L)},{(-8L),0xAEB32656L},{0x89BF7EEBL,0x17C48673L}}};
            int32_t l_2540[9];
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_2540[i] = (-1L);
            (*l_2522) = l_2521;
            l_2540[2] |= (safe_lshift_func_uint8_t_u_u(((+(&g_1988 == (void*)0)) > (safe_mod_func_uint32_t_u_u(((safe_sub_func_int32_t_s_s(0x3BA837DFL, (-1L))) , (safe_add_func_uint8_t_u_u(((**g_2492) < (+((*l_4) = ((*l_1746) = (g_2533 , ((*l_2522) == (l_2534 = l_2534))))))), (safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s(248UL, 6)) || 4294967295UL), l_2539[7][0][0]))))), (*l_5)))), l_2539[7][0][0]));
            ++g_2542;
            (*g_1229) = (safe_rshift_func_int8_t_s_s(((*l_5) = ((safe_add_func_int8_t_s_s((*l_5), ((*g_150) &= ((*l_4) = (l_2551 | (l_2540[2] > ((*l_5) || (safe_mul_func_uint16_t_u_u(((*l_5) ^ (safe_mul_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(g_1484.f0, l_2560)), (((safe_mul_func_int16_t_s_s(6L, ((((*l_5) , (*g_1207)) == (*g_1207)) , g_1210.f0))) > (*g_413)) & (*l_5)))), l_2563))), 4L))))))))) >= l_2564)), 1));
        }
        else
        { /* block id: 1123 */
            union U4 ***l_2578 = &g_1743;
            int32_t l_2580 = 0x967684ABL;
            uint8_t *l_2581[1];
            int i;
            for (i = 0; i < 1; i++)
                l_2581[i] = &g_1266[0];
            (*g_1229) = ((~((*l_5) &= (&g_2139 == (void*)0))) >= (g_2566[4] , ((safe_rshift_func_uint8_t_u_s((g_1266[0] = ((*g_150) == ((((l_2[1] , g_2569) , ((safe_mod_func_int64_t_s_s((safe_add_func_int64_t_s_s((safe_rshift_func_int8_t_s_u((((g_2576[1] , (g_2577 = &g_1743)) != l_2578) | 2L), 6)), l_2579)), l_2580)) & (-6L))) & l_2580) == (*g_413)))), 0)) < l_2582)));
        }
        (*g_1229) |= (l_2595 = (g_1206[0][2][2] , (0x9462L & ((*l_5) <= (((safe_lshift_func_int8_t_s_u((*g_150), 5)) >= g_846.f3) > (g_243[1] & (safe_rshift_func_int8_t_s_u((safe_mul_func_uint8_t_u_u((((*l_4) |= (*l_5)) < (l_2582 = ((safe_add_func_int16_t_s_s((safe_mod_func_int64_t_s_s((((*l_2593) = ((4UL >= (*l_5)) >= 0x0CL)) > 4UL), (*l_5))), g_275[1].f2)) || 0xBD72F548F9F0AC77LL))), l_2594[2][1])), 4))))))));
    }
    else
    { /* block id: 1134 */
        int16_t l_2603 = 0xCFE8L;
        union U3 *l_2635 = &g_2264[1][3];
        uint64_t * const **l_2657[2][10][5] = {{{&g_2656,&g_2656,&g_2656,(void*)0,&g_2656},{&g_2656,&g_2656,(void*)0,&g_2656,&g_2656},{&g_2656,&g_2656,(void*)0,(void*)0,(void*)0},{&g_2656,&g_2656,(void*)0,&g_2656,&g_2656},{&g_2656,&g_2656,(void*)0,(void*)0,&g_2656},{&g_2656,&g_2656,(void*)0,&g_2656,(void*)0},{&g_2656,&g_2656,&g_2656,(void*)0,&g_2656},{&g_2656,&g_2656,(void*)0,&g_2656,&g_2656},{&g_2656,&g_2656,(void*)0,(void*)0,(void*)0},{&g_2656,&g_2656,(void*)0,&g_2656,&g_2656}},{{&g_2656,&g_2656,(void*)0,(void*)0,&g_2656},{&g_2656,&g_2656,(void*)0,&g_2656,(void*)0},{&g_2656,&g_2656,&g_2656,&g_2656,&g_2656},{(void*)0,(void*)0,&g_2656,&g_2656,&g_2656},{(void*)0,&g_2656,(void*)0,&g_2656,(void*)0},{(void*)0,(void*)0,&g_2656,&g_2656,&g_2656},{&g_2656,(void*)0,(void*)0,&g_2656,&g_2656},{(void*)0,(void*)0,&g_2656,&g_2656,&g_2656},{(void*)0,(void*)0,&g_2656,&g_2656,&g_2656},{(void*)0,(void*)0,&g_2656,&g_2656,&g_2656}}};
        uint8_t l_2668 = 248UL;
        int32_t l_2677 = 0x80D849ABL;
        int32_t l_2695 = 5L;
        int32_t l_2699 = 0x57901DC2L;
        int32_t l_2700[6] = {0x29E16560L,0L,0L,0x29E16560L,0L,0L};
        union U0 *****l_2722 = (void*)0;
        uint8_t ***l_2767[6] = {&g_1831,&g_1831,&g_1831,&g_1831,&g_1831,&g_1831};
        uint8_t ****l_2766 = &l_2767[0];
        int8_t l_2772 = 0xF8L;
        int i, j, k;
        for (g_110 = (-26); (g_110 >= (-21)); ++g_110)
        { /* block id: 1137 */
            union U4 *l_2598 = &g_1818;
            uint16_t l_2599 = 65535UL;
            const union U0 *l_2619 = &g_272[3][6];
            uint32_t *l_2620 = (void*)0;
            uint32_t *l_2621 = (void*)0;
            uint32_t *l_2622 = &g_209;
            uint64_t *l_2623 = &g_2122;
            int8_t *l_2632 = &g_1699[3];
            int32_t l_2641 = 1L;
            uint32_t l_2642 = 0UL;
            int32_t l_2684 = 0L;
            int32_t l_2694 = 0x71761045L;
            int32_t l_2701 = 1L;
            uint64_t l_2702 = 0xFD2D81461A9E1033LL;
            uint16_t l_2710 = 0xD85EL;
            l_2598 = (*g_1544);
            (*l_5) &= l_2599;
        }
        for (g_246.f0 = 0; (g_246.f0 < 17); ++g_246.f0)
        { /* block id: 1171 */
            uint32_t l_2731 = 4294967295UL;
            int32_t l_2736 = 0xE9FAB292L;
            uint8_t *l_2737 = (void*)0;
            uint8_t *l_2738[2];
            uint64_t **l_2750[1][3][2] = {{{&g_2493,&g_2493},{&g_2493,&g_2493},{&g_2493,&g_2493}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_2738[i] = &g_1266[0];
            (*g_1148) &= ((safe_lshift_func_uint8_t_u_s((safe_add_func_uint16_t_u_u(((((g_2720 , g_2721) != l_2722) & (((*l_5) <= ((l_2700[0] >= (((l_2695 == (((((**g_2492) = (**g_2492)) < (safe_mul_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((((l_2731 |= 251UL) > (g_1266[0] = (l_2736 ^= (safe_rshift_func_int16_t_s_u((l_2734 != (void*)0), g_1266[0]))))) , g_1829.f4), 65535UL)), (*g_150))), 0x5DL))) || l_2731) == l_2677)) == (-1L)) >= 255UL)) <= 0x6DE9L)) || (*g_322))) , 0x8821L), (*g_413))), 4)) , 0x53B5C747L);
            for (g_98 = 0; (g_98 <= 6); g_98 += 1)
            { /* block id: 1179 */
                union U3 **l_2753 = &l_2751;
                uint8_t l_2768 = 0x05L;
                uint16_t *l_2769 = (void*)0;
                uint16_t *l_2770[1][2];
                int32_t l_2771 = 0x04C18D01L;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_2770[i][j] = &g_749;
                }
                (*g_1229) = (safe_mul_func_int8_t_s_s(((+(safe_div_func_int32_t_s_s(((safe_mod_func_int32_t_s_s(((*l_5) = l_2731), (safe_rshift_func_int8_t_s_s((((((safe_mul_func_uint8_t_u_u((*g_1901), l_2731)) || (((*g_2470) != l_2750[0][2][1]) != (l_2635 == (l_2736 , ((*l_2753) = l_2751))))) >= (safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((((safe_rshift_func_uint16_t_u_s((((safe_rshift_func_uint8_t_u_s((l_2700[0] ^= ((safe_lshift_func_uint16_t_u_u((l_2771 = (safe_mul_func_uint8_t_u_u((l_2766 == &g_1899[6][5]), l_2768))), 15)) , 0xB8L)), 2)) <= l_2772) || (*g_413)), 10)) || 0x5032B20FDAC42A58LL) , l_2699) , l_2731) & 4294967295UL), 1L)), l_2768))) != 4294967287UL) && g_1468.f1), 5)))) >= l_2768), (*g_1229)))) == 0UL), l_2677));
                if ((*l_5))
                    continue;
                for (l_2736 = 0; (l_2736 >= 0); l_2736 -= 1)
                { /* block id: 1188 */
                    return g_2773;
                }
            }
            (*l_5) = (*l_5);
            l_2635 = ((*l_2751) , l_2751);
        }
    }
    return g_2774;
}


/* ------------------------------------------ */
/* 
 * reads : g_1147 g_1148 g_514 g_885 g_886 g_413 g_237 g_1765 g_482.f2 g_407.f2 g_3.f1 g_1712.f0 g_605.f1 g_401 g_267.f0 g_1058 g_1059 g_1210.f0 g_1917.f4 g_2005 g_855.f0 g_1207 g_1208 g_820.f1 g_1229 g_85 g_2039.f1 g_1910 g_6
 * writes: g_322 g_482.f2 g_407.f2 g_3.f1 g_1059 g_1210.f0 g_1917.f4 g_855.f0 g_85 g_2039.f1
 */
static int32_t  func_7(uint8_t  p_8, uint32_t  p_9, uint32_t  p_10, int8_t * p_11, uint32_t  p_12)
{ /* block id: 735 */
    int32_t l_1753 = (-8L);
    uint64_t *l_1754 = (void*)0;
    uint64_t *l_1756[8] = {&g_403[0],(void*)0,&g_403[0],(void*)0,&g_403[0],(void*)0,&g_403[0],(void*)0};
    uint64_t **l_1755 = &l_1756[6];
    const union U0 * const **l_1764 = (void*)0;
    const union U0 * const ***l_1763 = &l_1764;
    int32_t l_1774 = (-4L);
    uint16_t *l_1775 = (void*)0;
    uint16_t *l_1776 = (void*)0;
    uint16_t *l_1777 = (void*)0;
    int32_t l_1778 = 0L;
    uint16_t *l_1779 = &g_482.f2;
    uint16_t *l_1791 = &g_407.f2;
    int16_t l_1792 = (-1L);
    int32_t l_1796 = 0xA9170FF5L;
    int32_t l_1797 = 0xE08EF5DEL;
    int32_t l_1798[5];
    int8_t * const l_1819 = &g_401;
    uint8_t ***l_1892 = &g_1831;
    int32_t l_1983 = 0xEAB6E893L;
    union U0 *l_1985 = &g_272[0][8];
    int32_t l_2070 = 3L;
    union U3 *l_2105[1];
    int16_t l_2120 = 0x9E01L;
    union U1 **l_2147 = &g_1059;
    uint32_t l_2263 = 4294967295UL;
    uint8_t l_2300 = 3UL;
    int16_t **l_2328 = &g_413;
    int16_t **l_2329 = &g_413;
    uint32_t l_2427 = 0x0AA2DA35L;
    int i;
    for (i = 0; i < 5; i++)
        l_1798[i] = 1L;
    for (i = 0; i < 1; i++)
        l_2105[i] = &g_1369[4][0];
lbl_1805:
    (*g_514) = (*g_1147);
    if (((*g_885) , (((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((*g_413), (l_1753 != (l_1754 != ((*l_1755) = l_1754))))), (safe_sub_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((l_1763 == (g_1765 , (((safe_mod_func_uint32_t_u_u(4294967295UL, (safe_rshift_func_int8_t_s_s((safe_div_func_uint64_t_u_u((((safe_lshift_func_int16_t_s_u((((*l_1779)--) == ((safe_div_func_uint32_t_u_u((+((safe_add_func_int8_t_s_s(((*p_11) |= ((safe_rshift_func_int8_t_s_u((((safe_div_func_uint16_t_u_u(((*l_1791) ^= p_10), p_9)) >= l_1774) != 0x29322B02L), p_12)) != l_1753)), l_1792)) >= g_1712.f0)), 0xAAFA7FD4L)) | 65532UL)), g_605.f1)) | 0L) & 65535UL), p_10)), p_9)))) < g_401) , &l_1764))), (*g_413))), g_267.f0)), l_1753)))) > 0x04BD2974L) == l_1778)))
    { /* block id: 741 */
        union U1 **l_1793 = &g_1059;
        int32_t l_1794 = 2L;
        int32_t *l_1795[6][10][4] = {{{&l_1778,&g_23,&l_1778,&g_6},{&l_1753,(void*)0,&l_1774,&l_1753},{&l_1753,&l_1753,(void*)0,(void*)0},{&l_1753,(void*)0,(void*)0,&g_85},{&l_1753,&l_1774,&l_1774,&l_1753},{&l_1753,&l_1774,&l_1778,&g_23},{&l_1778,&g_23,&l_1794,&g_6},{&g_85,&g_85,&l_1778,(void*)0},{&l_1774,&l_1794,(void*)0,&l_1753},{(void*)0,(void*)0,&l_1778,&g_23}},{{(void*)0,&l_1753,&l_1753,&l_1778},{&l_1774,(void*)0,&g_85,&g_23},{&g_23,(void*)0,&g_23,(void*)0},{&l_1778,&l_1774,&l_1774,&l_1753},{(void*)0,&l_1753,&l_1753,&l_1753},{&g_6,&g_6,&l_1778,&g_85},{&l_1794,&g_23,(void*)0,&l_1778},{&g_6,(void*)0,(void*)0,(void*)0},{&g_6,(void*)0,(void*)0,&l_1778},{(void*)0,&g_23,&g_85,&g_85}},{{(void*)0,&g_6,&l_1794,&l_1753},{&l_1753,&l_1753,(void*)0,&l_1753},{(void*)0,&l_1774,&l_1753,(void*)0},{&l_1774,(void*)0,&l_1753,&g_23},{&l_1753,(void*)0,&g_23,&l_1778},{&g_85,&l_1753,&l_1774,&g_23},{&l_1778,(void*)0,&l_1753,&l_1753},{&l_1778,&l_1794,&g_23,(void*)0},{&l_1778,&g_85,&l_1753,&g_6},{&g_85,&g_23,(void*)0,&g_23}},{{&l_1778,&l_1774,&l_1794,&l_1753},{&l_1753,&l_1774,&g_6,&g_85},{&l_1778,&l_1753,(void*)0,&g_85},{&l_1778,&l_1774,&g_6,&l_1774},{&l_1753,&g_85,&g_23,&l_1753},{&l_1794,&g_6,&g_85,(void*)0},{&l_1778,&g_23,&g_23,&l_1778},{&g_6,&l_1753,&l_1753,&l_1774},{&g_85,&l_1778,&l_1774,(void*)0},{&l_1753,&l_1774,(void*)0,(void*)0}},{{&l_1778,&l_1774,&l_1778,(void*)0},{&l_1774,&g_85,&l_1774,&l_1753},{&l_1753,&l_1753,&l_1753,&l_1794},{&l_1774,&l_1794,&l_1778,&g_6},{&l_1753,&g_23,&g_23,&l_1753},{&l_1753,&g_85,&l_1753,(void*)0},{(void*)0,(void*)0,&l_1774,(void*)0},{&g_6,&l_1778,(void*)0,(void*)0},{(void*)0,(void*)0,&g_23,(void*)0},{&g_23,&g_85,&g_85,&l_1753}},{{(void*)0,&g_23,&l_1753,&g_6},{(void*)0,&l_1794,&l_1774,&l_1794},{&g_85,&l_1753,&l_1774,&l_1753},{&g_23,&g_85,&l_1774,(void*)0},{&l_1778,&l_1774,&l_1753,(void*)0},{(void*)0,&l_1774,&g_85,(void*)0},{(void*)0,&l_1778,&l_1753,&l_1774},{(void*)0,&l_1753,(void*)0,&l_1778},{&l_1774,&g_23,&l_1778,(void*)0},{&g_85,&g_6,&g_85,&l_1753}}};
        uint32_t l_1802 = 0x640CF69DL;
        int i, j, k;
        (*l_1793) = (*g_1058);
        ++l_1802;
        (*g_514) = &l_1778;
        if (l_1774)
            goto lbl_1805;
    }
    else
    { /* block id: 746 */
        uint64_t **l_1815 = &l_1756[6];
        const int8_t l_1832 = (-4L);
        union U3 * const l_1876 = (void*)0;
        union U3 * const *l_1875 = &l_1876;
        const union U4 * const l_1911 = &g_1818;
        union U2 *l_1959 = &g_1960;
        uint32_t l_1989 = 4294967291UL;
        for (g_1210.f0 = 0; (g_1210.f0 <= 1); g_1210.f0 += 1)
        { /* block id: 749 */
            uint64_t ***l_1814 = &l_1755;
            int32_t l_1816 = 0x1BD8933CL;
            union U2 *l_1825 = &g_1826;
            union U2 **l_1824 = &l_1825;
            const int8_t **l_1861 = &g_80;
            union U3 ***l_1872[8][6][5] = {{{&g_1871,&g_1871,(void*)0,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,(void*)0,&g_1871,(void*)0},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,(void*)0}},{{&g_1871,&g_1871,(void*)0,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,(void*)0,&g_1871,(void*)0}},{{&g_1871,&g_1871,(void*)0,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,(void*)0,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,(void*)0,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871}},{{(void*)0,(void*)0,(void*)0,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{(void*)0,&g_1871,(void*)0,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,(void*)0,&g_1871,(void*)0},{&g_1871,&g_1871,&g_1871,&g_1871,(void*)0}},{{&g_1871,&g_1871,(void*)0,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,(void*)0,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,(void*)0}},{{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,(void*)0,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,(void*)0},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,(void*)0,(void*)0,&g_1871},{&g_1871,(void*)0,(void*)0,&g_1871,(void*)0}},{{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{(void*)0,(void*)0,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,(void*)0,&g_1871},{&g_1871,&g_1871,(void*)0,&g_1871,(void*)0}},{{&g_1871,&g_1871,&g_1871,&g_1871,(void*)0},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{(void*)0,&g_1871,&g_1871,&g_1871,&g_1871},{&g_1871,&g_1871,&g_1871,(void*)0,&g_1871},{(void*)0,&g_1871,(void*)0,(void*)0,&g_1871},{&g_1871,&g_1871,&g_1871,&g_1871,&g_1871}}};
            union U3 *l_1874 = &g_1369[1][0];
            union U3 **l_1873[1][5][7] = {{{&l_1874,&l_1874,&l_1874,&l_1874,(void*)0,&l_1874,&l_1874},{&l_1874,&l_1874,&l_1874,&l_1874,&l_1874,&l_1874,(void*)0},{&l_1874,&l_1874,&l_1874,&l_1874,(void*)0,&l_1874,&l_1874},{(void*)0,(void*)0,&l_1874,&l_1874,&l_1874,&l_1874,&l_1874},{&l_1874,&l_1874,(void*)0,(void*)0,&l_1874,&l_1874,&l_1874}}};
            int i, j, k;
        }
    }
    for (g_1917.f4 = 19; (g_1917.f4 != 57); g_1917.f4++)
    { /* block id: 846 */
        uint32_t l_2000 = 18446744073709551612UL;
        uint32_t *l_2012 = &g_855.f0;
        union U0 * const l_2017 = &g_2018[1][0];
        union U0 * const *l_2016[8] = {&l_2017,&l_2017,&l_2017,&l_2017,&l_2017,&l_2017,&l_2017,&l_2017};
        union U0 * const **l_2015 = &l_2016[5];
        int32_t l_2019 = 0L;
        union U1 *l_2020 = &g_788[4][0][4];
        union U1 *l_2022 = &g_1639[3][4];
        int8_t l_2030 = (-1L);
        uint16_t l_2040 = 1UL;
        int32_t l_2097[8] = {0x28B17BC7L,0x28B17BC7L,0x28B17BC7L,0x28B17BC7L,0x28B17BC7L,0x28B17BC7L,0x28B17BC7L,0x28B17BC7L};
        int64_t l_2108 = 8L;
        int32_t l_2121 = (-9L);
        union U3 *l_2132[10] = {&g_2133,&g_2133,&g_2133,&g_2133,&g_2133,&g_2133,&g_2133,&g_2133,&g_2133,&g_2133};
        int8_t l_2135 = 0L;
        int8_t l_2148 = 0x45L;
        int16_t l_2196[8][10] = {{0L,0L,0xD48DL,1L,(-3L),(-3L),1L,0xD48DL,0L,0L},{(-3L),1L,0xD48DL,0L,0L,0xD48DL,1L,(-3L),(-3L),1L},{(-3L),0L,1L,1L,0L,(-3L),0xD48DL,0xD48DL,(-3L),0L},{0L,1L,1L,0L,(-3L),0xD48DL,0xD48DL,(-3L),0L,1L},{0L,0L,0xD48DL,1L,(-3L),(-3L),1L,0xD48DL,0L,0L},{(-3L),1L,0xD48DL,0L,0L,0xD48DL,1L,(-3L),(-3L),1L},{(-3L),0L,1L,1L,0L,(-3L),0xD48DL,0xD48DL,(-3L),0L},{0L,1L,1L,0L,(-3L),0xD48DL,0xD48DL,(-3L),0L,1L}};
        const int64_t l_2241[7] = {0x370D0DC4318A12B6LL,0x370D0DC4318A12B6LL,(-1L),0x370D0DC4318A12B6LL,0x370D0DC4318A12B6LL,(-1L),0x370D0DC4318A12B6LL};
        int32_t l_2322 = 0xAFF490BCL;
        int16_t ***l_2326 = &g_641;
        int16_t ***l_2327 = &g_641;
        union U4 ***l_2334 = &g_1743;
        uint16_t l_2340 = 0x651BL;
        int32_t *l_2368[10][5][5] = {{{&l_1798[3],&l_1796,&l_1753,(void*)0,(void*)0},{&g_23,&l_2097[7],&l_1983,&l_1983,&l_2097[7]},{&g_23,&l_2097[7],&l_1753,&l_1796,&g_85},{&l_2019,(void*)0,&l_1753,&l_1778,(void*)0},{(void*)0,(void*)0,&g_23,&l_2070,&l_1778}},{{&l_2019,&l_1983,&l_1753,&l_2019,&l_1778},{&g_23,(void*)0,(void*)0,&l_2097[7],(void*)0},{&g_23,&g_23,&l_1778,&l_2019,&l_1753},{&l_1798[3],(void*)0,&l_1778,&l_2070,&g_23},{&l_1753,&l_1778,(void*)0,&l_1778,&l_1753}},{{&l_1753,(void*)0,&g_85,&l_1796,&l_1753},{&l_2019,&g_23,&l_2097[7],&l_1983,&l_1983},{(void*)0,(void*)0,(void*)0,(void*)0,&l_1753},{&l_1798[3],&l_1983,&g_23,&g_23,&l_1753},{&l_1753,(void*)0,&g_23,(void*)0,(void*)0}},{{&l_1796,&l_1753,&l_1778,&l_1983,(void*)0},{&l_1753,&l_1796,&l_1778,(void*)0,&l_1798[3]},{&g_23,&l_1796,&l_1796,&g_23,&l_2019},{&l_1753,(void*)0,(void*)0,(void*)0,&l_1797},{&l_1796,&l_2019,&l_1798[3],&l_1778,&l_1798[3]}},{{&l_1778,&l_1774,&l_1797,(void*)0,(void*)0},{&l_1753,(void*)0,&l_2019,&g_23,&l_1796},{&l_1778,(void*)0,&l_1798[3],(void*)0,&l_1778},{&g_23,(void*)0,(void*)0,&l_1983,&l_1778},{&l_1774,&l_1774,(void*)0,(void*)0,&g_23}},{{&l_1983,&l_2019,&l_1983,(void*)0,&l_1778},{(void*)0,(void*)0,&l_1778,&l_2097[7],&l_1778},{&l_1778,&l_1796,&l_2097[7],&l_2097[7],&l_1796},{(void*)0,&l_1796,&l_1778,&l_1796,(void*)0},{&l_2019,&l_1753,&l_1983,&l_2019,&l_1798[3]}},{{&l_1753,&l_2070,(void*)0,&l_2097[7],&l_1797},{&l_2019,&l_2097[7],(void*)0,&g_23,&l_2019},{(void*)0,&l_2019,&l_1798[3],&l_1774,&l_1798[3]},{&l_1778,&l_1778,&l_2019,&g_23,(void*)0},{(void*)0,&l_2097[7],&l_1797,&l_2097[7],(void*)0}},{{&l_1983,&l_2019,&l_1798[3],&l_2019,&l_1983},{&l_1774,&l_2097[7],(void*)0,&l_1796,&l_1778},{&g_23,&l_1778,&l_1796,&l_2097[7],&l_2097[7]},{&l_1778,&l_2019,&l_1778,&l_2097[7],&l_1778},{&l_1753,&l_2097[7],&l_1778,(void*)0,&l_1983}},{{&l_1778,&l_2070,&g_23,(void*)0,(void*)0},{&l_1796,&l_1753,&l_1778,&l_1983,(void*)0},{&l_1753,&l_1796,&l_1778,(void*)0,&l_1798[3]},{&g_23,&l_1796,&l_1796,&g_23,&l_2019},{&l_1753,(void*)0,(void*)0,(void*)0,&l_1797}},{{&l_1796,&l_2019,&l_1798[3],&l_1778,&l_1798[3]},{&l_1778,&l_1774,&l_1797,(void*)0,(void*)0},{&l_1753,(void*)0,&l_2019,&g_23,&l_1796},{&l_1778,(void*)0,&l_1798[3],(void*)0,&l_1778},{&g_23,(void*)0,(void*)0,&l_1983,&l_1778}}};
        uint8_t l_2400 = 0xDCL;
        uint32_t l_2402 = 4294967292UL;
        int8_t * const *l_2452 = &g_150;
        uint64_t **l_2494[4][4][3] = {{{&l_1754,&l_1756[6],&l_1754},{&l_1754,&l_1756[6],&l_1756[6]},{&l_1756[6],&l_1754,&l_1754},{&l_1756[6],&l_1754,&l_1756[6]}},{{&l_1754,&l_1754,&l_1756[6]},{(void*)0,(void*)0,&l_1756[6]},{&l_1754,&l_1756[6],&g_2493},{&l_1754,(void*)0,&l_1754}},{{&l_1754,&l_1754,(void*)0},{&l_1754,&l_1754,&l_1754},{(void*)0,&l_1754,&g_2493},{&l_1756[6],&l_1754,&l_1756[6]}},{{(void*)0,(void*)0,&l_1756[6]},{&l_1754,&l_1756[6],&g_2493},{&l_1754,(void*)0,&l_1754},{&l_1754,&l_1754,(void*)0}}};
        const union U2 *l_2503 = (void*)0;
        uint32_t l_2504 = 1UL;
        int i, j, k;
        if ((safe_mod_func_int16_t_s_s(((safe_rshift_func_int8_t_s_u((safe_mul_func_uint8_t_u_u(l_2000, ((l_2000 || (safe_rshift_func_uint8_t_u_s(0x1CL, ((*p_11) = (safe_add_func_uint64_t_u_u((g_2005[1][0] , (safe_mul_func_uint16_t_u_u(((0x8E9BCC42A8BA4993LL || ((safe_sub_func_int32_t_s_s((safe_sub_func_int16_t_s_s(p_12, ((++(*l_2012)) != (((*l_1791) &= ((((*g_1207) == ((*l_2015) = &l_1985)) & (l_2019 = 0x774345200C1AC0EDLL)) != l_2000)) , l_2019)))), l_2000)) <= p_9)) | p_10), g_820.f1))), 1UL)))))) && p_10))), 6)) > l_1792), l_1792)))
        { /* block id: 852 */
            (*g_1229) ^= l_2019;
        }
        else
        { /* block id: 854 */
            union U1 **l_2021[7];
            int i;
            for (i = 0; i < 7; i++)
                l_2021[i] = &l_2020;
            (*g_1058) = (l_2022 = l_2020);
        }
    }
    for (g_2039.f1 = 2; (g_2039.f1 <= 6); g_2039.f1 += 1)
    { /* block id: 1108 */
        return p_10;
    }
    return (*g_1910);
}


/* ------------------------------------------ */
/* 
 * reads : g_670 g_406.f4 g_319 g_413 g_237 g_322 g_6 g_85 g_209 g_1544 g_514 g_1148 g_605.f4 g_1229 g_403 g_1147 g_1112.f2 g_407.f1 g_243 g_150 g_3.f1 g_98 g_788.f2 g_1236.f0 g_1258.f2 g_1207 g_1639 g_401 g_275.f1 g_848.f3 g_1228.f1 g_267.f0 g_3 g_406.f2 g_33 g_73 g_77 g_80 g_77.f4 g_23 g_77.f0 g_77.f2 g_103 g_73.f0 g_138 g_103.f0 g_110 g_77.f3 g_77.f1 g_180 g_107 g_219 g_222 g_222.f0 g_246 g_267 g_272 g_1699 g_584.f1 g_1712 g_1079.f2 g_1736
 * writes: g_670 g_107 g_180 g_6 g_85 g_209 g_328.f2 g_1540 g_1148 g_605.f4 g_243 g_1266 g_98 g_401 g_788.f2 g_403 g_343.f1 g_641 g_1208 g_267.f0 g_322 g_237 g_23 g_110 g_150 g_156 g_77.f1 g_219 g_1699 g_1713 g_1736 g_1036.f4 g_1743
 */
static uint8_t  func_13(int32_t * p_14, int8_t * p_15, int8_t * p_16)
{ /* block id: 291 */
    uint8_t l_665 = 1UL;
    int32_t l_710 = 1L;
    int32_t l_719 = 0x1B9C8C15L;
    int32_t l_721 = 0xB5993B89L;
    int32_t l_722 = 0x889BA0D2L;
    int32_t l_723 = (-7L);
    int32_t l_727[2][4][3];
    int64_t *l_769[5];
    uint8_t **l_776 = &g_349;
    int32_t l_874 = 0L;
    int8_t l_895 = 0x06L;
    int16_t *l_931 = &g_98;
    union U2 *l_976[8];
    union U1 *l_1077 = &g_788[1][0][5];
    union U1 *l_1078 = &g_1079[4][0][5];
    uint16_t l_1144[3][5][1] = {{{0x8363L},{65535UL},{65535UL},{0x8363L},{65535UL}},{{65535UL},{0x8363L},{65535UL},{65535UL},{0x8363L}},{{65535UL},{65535UL},{0x8363L},{65535UL},{65535UL}}};
    int32_t **l_1205 = &g_1148;
    int32_t ***l_1271 = &l_1205;
    int32_t ****l_1270 = &l_1271;
    uint32_t l_1437 = 7UL;
    int64_t l_1610[3][1];
    union U0 **l_1632 = (void*)0;
    uint8_t l_1643 = 4UL;
    int16_t l_1644 = 0x86CDL;
    uint32_t l_1702[3][9] = {{0x32865F10L,0x32865F10L,0x839406EAL,0x37D99B83L,0xC53E5847L,7UL,0UL,7UL,0xC53E5847L},{0x839406EAL,0x32865F10L,0x32865F10L,0x839406EAL,0x37D99B83L,0xC53E5847L,7UL,0UL,7UL},{0UL,0xCAF72D9CL,0x839406EAL,0x839406EAL,0xCAF72D9CL,0UL,0xC9579761L,0x32865F10L,9UL}};
    union U4 * const l_1720 = &g_1274;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 3; k++)
                l_727[i][j][k] = (-1L);
        }
    }
    for (i = 0; i < 5; i++)
        l_769[i] = &g_107;
    for (i = 0; i < 8; i++)
        l_976[i] = &g_431[4];
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_1610[i][j] = 0xE39B228CC0D5A8E1LL;
    }
    if (l_665)
    { /* block id: 292 */
        const int32_t ****l_671 = &g_670;
        int64_t *l_672 = &g_107;
        int16_t *l_677 = &g_237;
        int32_t l_678[7][1] = {{0L},{0L},{0L},{0L},{0L},{0L},{0L}};
        uint8_t *l_679 = &g_180;
        uint64_t l_771 = 18446744073709551615UL;
        uint8_t **l_777 = &g_349;
        union U1 *l_787 = &g_788[4][0][4];
        int16_t l_802 = 0L;
        union U0 *l_805 = &g_272[7][5];
        union U0 ** const l_804 = &l_805;
        uint32_t l_877 = 4294967292UL;
        int16_t *l_930[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int i, j;
        (*g_322) |= (safe_sub_func_uint8_t_u_u(((0x00L == ((*l_679) = (safe_mul_func_uint8_t_u_u(((l_678[2][0] = ((((*l_671) = g_670) != (((*l_672) = g_406.f4) , &g_514)) == (0x65566278L && (safe_rshift_func_int16_t_s_s(l_665, (((((safe_sub_func_int16_t_s_s((((&g_237 == l_677) ^ 0x6FBD15E6A153E324LL) , 0xAF55L), 0xAF36L)) <= 0x79L) == 0x1BEF2121D8DA0FDFLL) >= g_319[1]) , (*g_413))))))) != (-10L)), l_665)))) >= l_665), l_665));
        for (g_85 = 0; (g_85 <= 1); g_85 += 1)
        { /* block id: 300 */
            int16_t l_694 = 0xB1CDL;
            uint64_t *l_695 = &g_403[0];
            int32_t l_696[2][1];
            int32_t ***l_815 = &g_514;
            uint8_t ** const *l_854 = &l_777;
            uint32_t l_894 = 0x1EBE3A41L;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_696[i][j] = 0xA6D80936L;
            }
        }
    }
    else
    { /* block id: 409 */
        uint64_t *l_963 = (void*)0;
        union U2 *l_974 = &g_431[6];
        int32_t l_982 = (-8L);
        int32_t l_1049[2][10] = {{0L,7L,0x77632AB0L,0x77632AB0L,7L,0L,7L,0x77632AB0L,0x77632AB0L,7L},{0L,7L,0x77632AB0L,0x77632AB0L,7L,0L,7L,0x77632AB0L,0x77632AB0L,7L}};
        uint16_t l_1050 = 5UL;
        union U1 *l_1057 = (void*)0;
        uint32_t l_1062 = 0x75C44726L;
        int32_t ****l_1272[7];
        uint16_t l_1344[10][9][2] = {{{0xC254L,0UL},{65531UL,65535UL},{0x565BL,0UL},{0xFCD7L,65535UL},{65535UL,0UL},{0x449FL,0UL},{65535UL,65535UL},{0xFCD7L,0UL},{0x565BL,65535UL}},{{65531UL,0UL},{0xC254L,0UL},{65531UL,65535UL},{0x565BL,0UL},{0xFCD7L,65535UL},{65535UL,0UL},{0x449FL,0UL},{65535UL,65535UL},{0xFCD7L,0UL}},{{0x565BL,65535UL},{65531UL,0UL},{0xC254L,0UL},{65531UL,65535UL},{0x565BL,0UL},{0xFCD7L,65535UL},{65535UL,0UL},{0x449FL,0UL},{65535UL,65535UL}},{{0xFCD7L,0UL},{0x565BL,65535UL},{65531UL,0UL},{0xC254L,0UL},{65531UL,65535UL},{0x565BL,0UL},{0xFCD7L,65535UL},{65535UL,0UL},{0x449FL,0UL}},{{65535UL,65535UL},{0xFCD7L,0UL},{0x565BL,65535UL},{65531UL,0UL},{0xC254L,0UL},{0x0647L,0xD51DL},{0xC254L,65535UL},{0x449FL,0xD51DL},{0x6FD2L,0UL}},{{65531UL,0UL},{0x6FD2L,0xD51DL},{0x449FL,65535UL},{0xC254L,0xD51DL},{0x0647L,0UL},{65535UL,0UL},{0x0647L,0xD51DL},{0xC254L,65535UL},{0x449FL,0xD51DL}},{{0x6FD2L,0UL},{65531UL,0UL},{0x6FD2L,0xD51DL},{0x449FL,65535UL},{0xC254L,0xD51DL},{0x0647L,0UL},{65535UL,0UL},{0x0647L,0xD51DL},{0xC254L,65535UL}},{{0x449FL,0xD51DL},{0x6FD2L,0UL},{65531UL,0UL},{0x6FD2L,0xD51DL},{0x449FL,65535UL},{0xC254L,0xD51DL},{0x0647L,0UL},{65535UL,0UL},{0x0647L,0xD51DL}},{{0xC254L,65535UL},{0x449FL,0xD51DL},{0x6FD2L,0UL},{65531UL,0UL},{0x6FD2L,0xD51DL},{0x449FL,65535UL},{0xC254L,0xD51DL},{0x0647L,0UL},{65535UL,0UL}},{{0x0647L,0xD51DL},{0xC254L,65535UL},{0x449FL,0xD51DL},{0x6FD2L,0UL},{65531UL,0UL},{0x6FD2L,0xD51DL},{0x449FL,65535UL},{0xC254L,0xD51DL},{0x0647L,0UL}}};
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_1272[i] = (void*)0;
        for (l_710 = 21; (l_710 > 13); --l_710)
        { /* block id: 412 */
            uint8_t l_981[8];
            const uint32_t l_1003[8] = {0x083058CCL,1UL,0x083058CCL,1UL,0x083058CCL,1UL,0x083058CCL,1UL};
            int32_t l_1028 = 0x08258C86L;
            union U1 **l_1076[4][8][3] = {{{&l_1057,&g_1059,&l_1057},{(void*)0,&l_1057,&g_1059},{&l_1057,&g_1059,&g_1059},{(void*)0,(void*)0,&l_1057},{&l_1057,&l_1057,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&g_1059,&g_1059},{(void*)0,(void*)0,&l_1057}},{{&l_1057,&l_1057,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&l_1057,&g_1059},{(void*)0,(void*)0,&g_1059},{&l_1057,&g_1059,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&l_1057,&g_1059},{(void*)0,(void*)0,&l_1057}},{{&l_1057,&g_1059,&l_1057},{(void*)0,&l_1057,&g_1059},{&l_1057,&g_1059,&g_1059},{(void*)0,(void*)0,&l_1057},{&l_1057,&l_1057,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&g_1059,&g_1059},{(void*)0,(void*)0,&l_1057}},{{&l_1057,&l_1057,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&l_1057,&g_1059},{(void*)0,(void*)0,&g_1059},{&l_1057,&g_1059,&l_1057},{(void*)0,&l_1057,&l_1057},{&l_1057,&l_1057,&g_1059},{(void*)0,(void*)0,&l_1057}}};
            uint32_t *l_1091 = (void*)0;
            int32_t l_1094 = (-1L);
            int32_t l_1095 = 0L;
            int32_t l_1096[9];
            int16_t l_1143 = 0x4A24L;
            int16_t ***l_1167[2];
            union U2 ** const l_1190 = &l_974;
            int16_t l_1204 = 1L;
            int32_t * const *l_1213 = &g_322;
            uint8_t l_1235 = 0xB2L;
            int32_t ****l_1243 = (void*)0;
            int32_t l_1294 = 0xFE1E1C44L;
            int32_t l_1362 = 1L;
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_981[i] = 248UL;
            for (i = 0; i < 9; i++)
                l_1096[i] = (-1L);
            for (i = 0; i < 2; i++)
                l_1167[i] = &g_641;
        }
    }
    for (g_209 = (-14); (g_209 > 15); ++g_209)
    { /* block id: 564 */
        uint32_t l_1397 = 0x23C17A35L;
        uint32_t l_1435 = 0x33C54CCBL;
        int32_t l_1445[3];
        const uint8_t **l_1501 = (void*)0;
        int32_t l_1527 = 0L;
        uint64_t l_1531 = 18446744073709551615UL;
        union U4 * const l_1535 = &g_1274;
        union U4 *l_1537[6][5][4] = {{{(void*)0,&g_73,&g_73,&g_1274},{&g_73,&g_73,(void*)0,&g_73},{&g_1274,&g_73,&g_1274,&g_73},{&g_73,&g_73,&g_73,&g_1274},{&g_73,&g_1274,&g_73,&g_73}},{{&g_73,&g_73,&g_73,&g_73},{&g_1274,&g_73,&g_73,(void*)0},{(void*)0,&g_1274,&g_1274,&g_73},{(void*)0,&g_1274,&g_1274,(void*)0},{&g_1274,&g_73,&g_1274,&g_73}},{{(void*)0,&g_73,&g_1274,&g_73},{&g_1274,&g_1274,&g_1274,&g_1274},{&g_73,&g_73,&g_1274,&g_73},{(void*)0,&g_73,&g_73,&g_73},{&g_1274,&g_73,&g_73,&g_1274}},{{&g_1274,&g_73,&g_73,&g_73},{(void*)0,&g_73,&g_1274,&g_1274},{&g_1274,&g_1274,&g_1274,&g_73},{&g_73,&g_1274,&g_73,&g_1274},{&g_1274,&g_73,&g_1274,&g_1274}},{{&g_1274,&g_73,&g_73,&g_73},{&g_1274,&g_73,(void*)0,&g_73},{&g_1274,(void*)0,&g_73,(void*)0},{&g_1274,&g_73,&g_1274,&g_73},{&g_1274,&g_73,&g_73,&g_73}},{{&g_73,(void*)0,&g_1274,&g_1274},{&g_1274,&g_1274,&g_1274,&g_73},{(void*)0,&g_1274,&g_73,&g_1274},{&g_1274,&g_1274,&g_73,(void*)0},{&g_1274,&g_73,&g_73,&g_73}}};
        union U4 **l_1536[3][8][3] = {{{(void*)0,&l_1537[0][3][3],&l_1537[0][3][3]},{(void*)0,&l_1537[0][3][3],&l_1537[5][4][0]},{(void*)0,(void*)0,&l_1537[0][3][3]},{(void*)0,&l_1537[0][3][3],(void*)0},{&l_1537[0][3][3],(void*)0,&l_1537[4][3][2]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[2][2][1],(void*)0,&l_1537[0][3][3]}},{{&l_1537[3][0][0],(void*)0,&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][4][2],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][1][3],&l_1537[0][3][3],&l_1537[4][3][2]},{&l_1537[1][4][2],&l_1537[0][3][3],(void*)0},{&l_1537[0][3][3],&l_1537[3][0][0],&l_1537[0][3][3]},{&l_1537[1][4][2],(void*)0,&l_1537[5][4][0]},{&l_1537[0][1][3],(void*)0,&l_1537[0][3][3]}},{{&l_1537[0][3][3],&l_1537[2][2][1],(void*)0},{&l_1537[0][3][3],(void*)0,(void*)0},{&l_1537[3][0][0],(void*)0,(void*)0},{&l_1537[2][2][1],&l_1537[2][2][1],&l_1537[3][0][0]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[1][4][2],&l_1537[0][3][3],(void*)0},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{(void*)0,&l_1537[1][4][2],(void*)0}}};
        union U4 **l_1538[4][8][4] = {{{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]}},{{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]}},{{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]}},{{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]},{&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3],&l_1537[0][3][3]}}};
        union U4 **l_1543[8] = {&l_1537[0][3][3],(void*)0,&l_1537[0][3][3],(void*)0,&l_1537[0][3][3],(void*)0,&l_1537[0][3][3],(void*)0};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1445[i] = (-1L);
        for (g_328.f2 = 2; (g_328.f2 <= 7); g_328.f2 += 1)
        { /* block id: 567 */
            uint8_t l_1395 = 0xC5L;
            uint64_t l_1396 = 0xC1BB2A5BE8696ED6LL;
            int32_t l_1408[2];
            uint8_t **l_1417 = &g_349;
            int32_t l_1436 = (-2L);
            uint32_t l_1467 = 0x4EE6F922L;
            int32_t l_1528[5];
            int i;
            for (i = 0; i < 2; i++)
                l_1408[i] = (-1L);
            for (i = 0; i < 5; i++)
                l_1528[i] = 0L;
        }
        (*g_1544) = l_1535;
        (**l_1271) = (*g_514);
    }
    if ((****l_1270))
    { /* block id: 620 */
        union U3 *l_1548 = &g_1369[2][0];
        int32_t l_1575 = (-3L);
        uint32_t l_1580 = 4294967295UL;
        int32_t * const l_1592 = (void*)0;
        int32_t l_1598[5][6][5] = {{{0L,(-4L),(-4L),0L,(-4L)},{0L,0L,0x6B79DD29L,0L,0L},{(-4L),0L,(-4L),(-4L),0L},{0L,(-4L),(-4L),0L,(-4L)},{0L,0L,0x6B79DD29L,0L,0L},{(-4L),0L,(-4L),(-4L),0L}},{{0L,(-4L),(-4L),0L,(-4L)},{0L,0L,0x6B79DD29L,0L,0L},{(-4L),0L,0x6B79DD29L,0x6B79DD29L,(-4L)},{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)}},{{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)},{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)}},{{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)},{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)}},{{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)},{(-4L),0x6B79DD29L,0x6B79DD29L,(-4L),0x6B79DD29L},{(-4L),(-4L),0L,(-4L),(-4L)},{0x6B79DD29L,(-4L),0x6B79DD29L,0x6B79DD29L,(-4L)}}};
        int i, j, k;
        (*g_1148) &= (safe_unary_minus_func_int32_t_s(0L));
        for (g_605.f4 = 0; (g_605.f4 != 29); g_605.f4++)
        { /* block id: 624 */
            uint32_t l_1549 = 0x2CB3B291L;
            int32_t l_1590 = 0xA6402DB1L;
            union U1 *l_1591 = &g_927;
            int16_t **l_1597[10][10] = {{&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931},{&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413},{&l_931,&l_931,&g_413,&l_931,&l_931,&g_413,&l_931,&l_931,&g_413,&l_931},{&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931},{&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413},{&l_931,&l_931,&g_413,&l_931,&l_931,&g_413,&l_931,&l_931,&g_413,&l_931},{&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931},{&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413},{&l_931,&l_931,&l_931,&g_413,&g_413,&l_931,&g_413,&g_413,&l_931,&g_413},{&g_413,&g_413,&g_413,&g_413,&g_413,&g_413,&g_413,&g_413,&g_413,&g_413}};
            int64_t l_1604 = (-8L);
            int32_t l_1608 = 0x940186D0L;
            int32_t l_1609 = 0x16B91327L;
            int32_t l_1611 = 0x5CA1C21EL;
            int32_t l_1612 = 6L;
            int32_t l_1614 = 0xFC38B86DL;
            int i, j;
            if ((*g_1229))
                break;
            if (((l_1548 = &g_1369[3][0]) != (void*)0))
            { /* block id: 627 */
                uint64_t l_1574 = 0x2810ED79AFD8FF9BLL;
                int32_t *l_1589 = &l_722;
                for (l_721 = 0; (l_721 <= 0); l_721 += 1)
                { /* block id: 630 */
                    uint32_t *l_1560 = &g_1210.f0;
                    int32_t l_1576 = 0x6CBBEDA0L;
                    int8_t *l_1588 = &g_343.f1;
                    int i;
                    if (g_403[l_721])
                    { /* block id: 631 */
                        return l_1549;
                    }
                    else
                    { /* block id: 633 */
                        int32_t *l_1550 = (void*)0;
                        int32_t *l_1551 = &l_719;
                        uint32_t *l_1562 = (void*)0;
                        uint32_t **l_1561 = &l_1562;
                        int i;
                        (*l_1551) |= (**g_1147);
                        l_1576 = ((**g_514) = (+((~((safe_div_func_uint64_t_u_u(g_605.f4, g_1112[0][5].f2)) >= ((*p_16) = (g_407.f1 <= (((l_1560 == ((*l_1561) = &g_243[1])) , ((**l_1561) &= 0x48E5BD4BL)) >= ((safe_rshift_func_int16_t_s_u((((*l_931) &= (((safe_mul_func_int8_t_s_s(((~((((((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((*g_150), 3)), l_1549)), ((g_1266[l_721] = (251UL ^ 0x1FL)) , l_1574))) & 0x0CBFD4C513BC32ABLL) < (**g_514)) & (*g_150)) && 3L) && g_403[l_721])) > l_1575), (****l_1270))) , l_1575) , l_1549)) & (*l_1551)), l_1575)) || 18446744073709551615UL)))))) | l_1549)));
                        if (g_403[l_721])
                            break;
                    }
                    l_1590 ^= ((0x1253L && ((g_788[4][0][4].f2 |= 0xAFC6L) <= (l_1574 != ((l_1574 | (!((safe_rshift_func_uint16_t_u_u(((g_1236[5][0][4].f0 == (((((**l_1205) = (l_1580 , ((safe_div_func_uint16_t_u_u(l_1575, ((safe_lshift_func_int8_t_s_s(((((*l_1588) = ((*p_16) = (((!(g_403[l_721] = (safe_add_func_int8_t_s_s((l_1576 ^ l_1580), l_1574)))) <= l_1580) & (***l_1271)))) | (-1L)) | 0UL), 2)) , (****l_1270)))) <= (**l_1205)))) , l_1576) , (*g_514)) == l_1589)) == l_1549), 14)) > (*l_1589)))) , 18446744073709551615UL)))) ^ g_1258.f2);
                    if ((**l_1205))
                        break;
                }
                (***l_1271) |= l_1575;
                l_1591 = (void*)0;
            }
            else
            { /* block id: 654 */
                int32_t *l_1596[10][9] = {{&l_874,&l_727[0][3][2],&g_6,&l_727[0][1][1],&l_874,&l_727[0][1][1],&g_6,&l_727[0][3][2],&l_874},{(void*)0,&l_727[0][2][1],&g_23,(void*)0,(void*)0,&g_23,&l_727[0][2][1],(void*)0,&l_727[0][3][2]},{&l_722,&l_727[0][3][2],&l_722,(void*)0,&l_722,&l_727[0][3][2],&l_722,(void*)0,&l_722},{(void*)0,&g_85,&l_727[0][2][1],&l_727[0][2][1],&g_85,(void*)0,&g_23,(void*)0,&l_727[0][3][2]},{&l_874,(void*)0,&l_727[0][3][2],(void*)0,&l_874,(void*)0,&l_727[0][3][2],(void*)0,&l_874},{(void*)0,&l_727[1][2][0],&l_727[1][2][0],(void*)0,&l_727[0][3][2],(void*)0,&g_23,(void*)0,&g_85},{&l_722,(void*)0,&l_722,&l_727[0][3][2],&l_722,(void*)0,&l_722,&l_727[0][3][2],&l_722},{&g_85,&g_85,(void*)0,&l_727[1][2][0],&l_727[0][3][2],(void*)0,&l_727[0][2][1],&g_23,(void*)0},{&l_874,&l_727[0][1][1],&g_6,&l_727[0][3][2],&l_874,&l_727[0][3][2],&g_6,&l_727[0][1][1],&l_874},{&l_727[0][3][2],&l_727[0][2][1],(void*)0,(void*)0,&g_85,&g_23,&l_727[1][2][0],(void*)0,(void*)0}};
                int i, j;
                for (l_1437 = 1; (l_1437 <= 4); l_1437 += 1)
                { /* block id: 657 */
                    uint16_t l_1593 = 0x7517L;
                    int32_t l_1599 = 0xA10C726AL;
                    int32_t l_1601[10] = {0x3B5B5289L,(-8L),0x3B5B5289L,(-8L),0x3B5B5289L,(-8L),0x3B5B5289L,(-8L),0x3B5B5289L,(-8L)};
                    uint32_t l_1615 = 0x778BE501L;
                    int i;
                    p_14 = l_1592;
                    --l_1593;
                    l_1596[9][0] = (*g_1147);
                    g_641 = l_1597[3][3];
                    for (l_1593 = 0; (l_1593 <= 0); l_1593 += 1)
                    { /* block id: 664 */
                        int32_t l_1600 = 0L;
                        int32_t l_1602 = 0x51704B09L;
                        int32_t l_1603 = 3L;
                        int32_t l_1605 = 0xC2A2FAA4L;
                        int32_t l_1606 = (-9L);
                        int32_t l_1607 = 8L;
                        int32_t l_1613 = 0x457E3C07L;
                        int i, j, k;
                        ++l_1615;
                        return l_1144[(l_1593 + 1)][l_1437][l_1593];
                    }
                }
            }
        }
        (**g_514) = 0x519B7101L;
    }
    else
    { /* block id: 672 */
        int32_t l_1642 = 0xF878B5CCL;
        int32_t l_1645[8][8][4] = {{{0x76FF7A37L,4L,1L,1L},{(-7L),0xA0DA1E03L,0xF8DE347BL,0L},{0x5CF94F0DL,0xEB8AEE94L,0xDF5BB829L,1L},{0x734E815BL,0x76FF7A37L,4L,0x8E587DF2L},{0x8E587DF2L,0x43372044L,0x5CF94F0DL,0xEA771C68L},{6L,(-3L),0xE1ED0305L,0x16C5D1B2L},{(-3L),0x76FF7A37L,0x31685D6EL,0x76FF7A37L},{(-1L),0x5CF94F0DL,(-3L),0L}},{{0L,0xEC8B7773L,(-3L),0L},{0L,4L,0x0A3F7A59L,6L},{0L,0xDF5BB829L,(-3L),0x362AD372L},{0L,6L,(-3L),0L},{(-1L),0x8E587DF2L,0x31685D6EL,0x461AF21AL},{(-3L),(-1L),0xE1ED0305L,(-7L)},{6L,1L,0x5CF94F0DL,9L},{0x8E587DF2L,0x362AD372L,4L,0x461AF21AL}},{{0x734E815BL,0x16C5D1B2L,0xDF5BB829L,0x283FAE12L},{0x5CF94F0DL,6L,0xF8DE347BL,(-1L)},{(-7L),0x4115976FL,0L,0x5CF94F0DL},{(-3L),0x701EBABCL,0x10D148F8L,0xE1ED0305L},{1L,0L,0x31685D6EL,0x31685D6EL},{6L,6L,(-1L),(-3L)},{0x4115976FL,(-9L),0x0A3F7A59L,(-3L)},{0xC283BAEDL,1L,(-1L),0x0A3F7A59L}},{{0xB904B7ADL,1L,0x8E587DF2L,(-3L)},{1L,(-9L),(-1L),(-3L)},{0x20D77505L,6L,0x27818545L,0x31685D6EL},{0xDF5BB829L,0L,(-7L),0xE1ED0305L},{0L,0x701EBABCL,0L,0x5CF94F0DL},{0x31685D6EL,0x4115976FL,0x701EBABCL,4L},{0xDF5BB829L,0x5CF94F0DL,0xEB8AEE94L,0xDF5BB829L},{(-1L),0xC283BAEDL,(-1L),0xF8DE347BL}},{{0L,(-4L),0x0626B074L,1L},{0xB904B7ADL,0xE1ED0305L,0x86EDF3A9L,0L},{(-3L),4L,0x0A3F7A59L,0xF8DE347BL},{0L,(-3L),0L,(-1L)},{6L,0x5CF94F0DL,0x283FAE12L,(-4L)},{0L,0L,0x10D148F8L,0x5CF94F0DL},{(-9L),9L,0x10D148F8L,0x96007DF7L},{0L,0L,0x283FAE12L,0L}},{{6L,(-1L),0L,(-3L)},{0L,(-3L),0x0A3F7A59L,0xC283BAEDL},{(-3L),1L,0x86EDF3A9L,0x43372044L},{0xB904B7ADL,0L,0x0626B074L,(-3L)},{0L,(-3L),(-1L),(-9L)},{(-1L),6L,0xEB8AEE94L,0L},{0xDF5BB829L,(-1L),0x701EBABCL,0xE1ED0305L},{0x31685D6EL,9L,0L,0x27818545L}},{{0L,0x4115976FL,(-7L),(-4L)},{0xDF5BB829L,0x27818545L,0x27818545L,0xDF5BB829L},{0x20D77505L,(-3L),(-1L),0x10D148F8L},{1L,(-4L),0x8E587DF2L,0L},{0xB904B7ADL,0x96007DF7L,(-1L),0L},{0xC283BAEDL,(-4L),0x0A3F7A59L,0x10D148F8L},{0x4115976FL,(-3L),(-1L),0xDF5BB829L},{6L,0x27818545L,0x31685D6EL,(-4L)}},{{1L,0x4115976FL,0x10D148F8L,0x27818545L},{(-3L),9L,0L,0xE1ED0305L},{0L,(-1L),0x31685D6EL,0L},{(-1L),6L,0L,(-9L)},{0x4115976FL,(-3L),(-3L),(-3L)},{(-3L),0L,(-1L),0x43372044L},{0x70F8D6AAL,1L,0x0626B074L,0xC283BAEDL},{1L,(-3L),0x734E815BL,(-3L)}}};
        uint32_t *l_1646 = (void*)0;
        uint32_t *l_1647 = (void*)0;
        uint32_t *l_1648 = &g_209;
        union U3 **l_1653 = (void*)0;
        int64_t l_1670 = 7L;
        int i, j, k;
        (*g_1229) = ((**g_514) = ((((*l_1648) |= (safe_sub_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((safe_mod_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((((((safe_rshift_func_uint8_t_u_s((((*g_1207) = l_1632) == (void*)0), (***l_1271))) & (!((&g_80 == &g_80) , (((safe_add_func_int64_t_s_s((0xBCBEA308454F28A4LL & ((safe_rshift_func_int8_t_s_u(((~(l_1642 = ((***l_1271) , ((g_1639[3][4] , (((((safe_add_func_uint32_t_u_u(((*p_16) && l_1642), 1UL)) <= l_1642) != 7UL) , 0x5B49L) && 65535UL)) == g_275[1].f1)))) , (-5L)), 7)) < (**l_1205))), 3UL)) == 0x4C64525EL) > 0x4B9DBE2CE1090B4ELL)))) | 0x309D734AL) & (*g_322)) == (**l_1205)), g_848.f3)), l_1643)), l_1644)) ^ 0x3E342EBEL), (-4L))), l_1645[5][3][2]))) ^ g_1228[1].f1) == 0x64E5A67FL));
        for (g_267.f0 = 0; (g_267.f0 == 36); g_267.f0 = safe_add_func_uint64_t_u_u(g_267.f0, 1))
        { /* block id: 680 */
            uint32_t l_1656 = 0x578F457CL;
            int32_t l_1663 = 0xCC23346FL;
            int32_t l_1664 = (-1L);
            union U0 *l_1681[5] = {&g_1210,&g_1210,&g_1210,&g_1210,&g_1210};
            int i;
            for (l_895 = (-27); (l_895 > (-7)); l_895 = safe_add_func_uint64_t_u_u(l_895, 2))
            { /* block id: 683 */
                union U3 *l_1655 = &g_1369[3][0];
                union U3 **l_1654 = &l_1655;
                int32_t l_1661 = (-1L);
                int32_t l_1662 = (-7L);
                uint32_t l_1678 = 0xFB8730C2L;
                int32_t l_1679 = 1L;
                union U0 *l_1680[7];
                uint64_t *l_1709 = &g_403[0];
                int32_t *l_1721 = &g_85;
                int32_t *l_1722 = &l_1662;
                int32_t *l_1723 = &l_727[0][3][2];
                int32_t *l_1724 = &l_1662;
                int32_t *l_1725 = &l_1645[5][3][2];
                int32_t *l_1726 = &l_1679;
                int32_t *l_1727 = &l_710;
                int32_t *l_1728 = &l_874;
                int32_t *l_1729 = &l_1679;
                int32_t *l_1730 = &l_1642;
                int32_t *l_1731 = &l_1679;
                int32_t *l_1732 = &l_727[0][3][2];
                int32_t *l_1733 = &l_1645[5][3][2];
                int32_t *l_1734 = &l_710;
                int32_t *l_1735[6];
                union U4 **l_1742 = &g_1540;
                int i;
                for (i = 0; i < 7; i++)
                    l_1680[i] = &g_1210;
                for (i = 0; i < 6; i++)
                    l_1735[i] = &l_1661;
                for (l_1643 = 0; (l_1643 <= 1); l_1643 += 1)
                { /* block id: 686 */
                    uint8_t l_1665 = 0xF3L;
                    uint8_t *l_1677 = &l_1665;
                    if (((*g_1229) = (l_1653 == l_1654)))
                    { /* block id: 688 */
                        (*g_514) = ((*l_1205) = (*g_514));
                        (**l_1271) = (void*)0;
                        (*g_1229) &= l_1656;
                        return l_1656;
                    }
                    else
                    { /* block id: 694 */
                        int32_t *l_1657 = &l_874;
                        int32_t *l_1658 = &l_874;
                        int32_t *l_1659 = &l_710;
                        int32_t *l_1660[8][10] = {{&g_23,&l_1645[0][2][2],(void*)0,&g_23,(void*)0,&l_1645[5][3][2],&l_1645[0][2][2],(void*)0,&l_1645[0][2][2],&l_1645[5][3][2]},{(void*)0,&l_727[0][3][2],&g_6,&l_727[0][3][2],(void*)0,&g_23,&l_1645[5][3][2],&l_727[0][0][1],&l_723,&l_723},{&g_23,&l_1645[5][3][2],&l_727[0][0][1],&l_723,&l_723,&g_23,(void*)0,(void*)0,&g_23,&l_723},{&g_6,&l_723,&l_723,&g_6,(void*)0,(void*)0,&l_727[1][1][0],&g_23,(void*)0,&l_1645[5][3][2]},{&l_727[0][1][2],(void*)0,&g_85,&g_23,(void*)0,&l_727[1][1][0],&l_723,&l_727[1][1][0],(void*)0,&g_23},{&l_1645[5][3][2],&l_727[0][1][2],&l_1645[5][3][2],&g_6,(void*)0,(void*)0,(void*)0,&l_1645[0][2][2],&g_23,&l_719},{&l_719,(void*)0,(void*)0,&l_723,&l_1645[0][2][2],&l_723,&l_723,&l_1645[0][2][2],&l_723,(void*)0},{&g_85,&g_85,&l_1645[5][3][2],&l_727[0][3][2],&g_23,&l_727[0][1][2],&l_727[0][0][1],&l_727[1][1][0],&l_1645[0][2][2],(void*)0}};
                        int i, j;
                        l_1665++;
                    }
                    (*g_322) = (safe_rshift_func_uint16_t_u_s(((l_1670 = l_1661) == ((l_1679 &= (safe_rshift_func_int8_t_s_s((0xAD64L != (((((safe_sub_func_uint8_t_u_u((&g_1450 == p_14), ((*l_1677) = (safe_lshift_func_int16_t_s_s((6UL | ((l_1664 |= (*g_322)) , l_1664)), 9))))) , ((*g_413) = l_1645[5][3][2])) & l_1662) <= l_1678) >= 1UL)), 5))) & (*p_16))), 14));
                    l_1681[3] = l_1680[3];
                    for (l_719 = 0; (l_719 <= 1); l_719 += 1)
                    { /* block id: 706 */
                        int32_t l_1688 = 0L;
                        uint64_t *l_1693 = &g_403[0];
                        int32_t *l_1698 = &l_1661;
                        uint32_t l_1700[5];
                        int32_t *l_1701[10][3] = {{&l_1664,&g_23,&g_23},{&g_85,&l_1679,&g_85},{&l_1664,&l_1664,&g_23},{&l_1663,&l_1679,&l_1663},{&l_1664,&g_23,&g_23},{&g_85,&l_1679,&g_85},{&l_1664,&l_1664,&g_23},{&l_1663,&l_1679,&l_1663},{&l_1664,&g_23,&g_23},{&g_85,&l_1679,&g_85}};
                        int i, j;
                        for (i = 0; i < 5; i++)
                            l_1700[i] = 4294967295UL;
                        (***l_1271) = (safe_lshift_func_uint8_t_u_u((((*g_413) = (safe_sub_func_uint32_t_u_u((((*l_931) = ((((g_1699[3] |= (safe_mod_func_uint16_t_u_u((func_47(((l_1688 < (safe_sub_func_int16_t_s_s(((0x2A40B5CF25AAA551LL & l_1663) < ((g_3 , (((safe_sub_func_uint64_t_u_u(((*l_1693) = (***l_1271)), ((safe_mod_func_int32_t_s_s(0xC77E2036L, 0x1B288035L)) | (1UL && (((((*l_1698) = ((((*p_16) > (***l_1271)) >= (**l_1205)) , l_1661)) && 1UL) < 0UL) <= l_1679))))) & (*g_413)) , 0xD016B5299C215734LL)) & (-2L))), l_1656))) , (*g_514)), g_406.f2) , 0UL), l_1665))) > g_584.f1) >= l_1656) && l_1700[3])) >= l_1665), l_1665))) & 0xA277L), 6));
                        (****l_1270) = l_1679;
                        if ((*g_1148))
                            continue;
                        l_1702[2][7]++;
                    }
                }
                (*g_514) = func_54((safe_mod_func_int32_t_s_s((safe_rshift_func_int8_t_s_s((((**g_514) > (((*l_1709) ^= ((void*)0 != p_15)) == (g_1713 = (safe_rshift_func_int8_t_s_u((&l_1632 == (g_1712 , &g_1208)), 5))))) || (((((safe_mod_func_int64_t_s_s(g_1079[4][0][5].f2, (safe_div_func_int8_t_s_s((*p_16), (safe_sub_func_int8_t_s_s(((void*)0 == l_1720), (*p_16))))))) >= l_1661) != l_1663) , (*p_16)) != (-8L))), (***l_1271))), (**l_1205))), &l_895);
                g_1736++;
                for (g_1036.f4 = 0; (g_1036.f4 <= 1); g_1036.f4 += 1)
                { /* block id: 724 */
                    int16_t l_1739 = (-1L);
                    union U4 **l_1744 = &g_1540;
                    if ((**g_1147))
                        break;
                    (*l_1726) = (l_1739 && ((((((l_1664 & (((*g_1148) | (p_16 == (void*)0)) > (0UL && ((****l_1270) && ((g_1743 = l_1742) == l_1744))))) != l_1642) || (*l_1729)) ^ 4294967295UL) || l_1739) , l_1664));
                }
            }
            l_976[5] = &g_857;
        }
    }
    return (***l_1271);
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_33 g_403 g_272.f0 g_23 g_138.f0 g_605.f2 g_514 g_322
 * writes: g_6 g_33 g_403 g_641 g_156 g_246.f0
 */
static int8_t * func_18(uint8_t  p_19, const int8_t  p_20)
{ /* block id: 4 */
    uint8_t l_21[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    int32_t l_31 = 0xE2CD8491L;
    int32_t l_32 = 0x7F5D1CC0L;
    int8_t l_631[1];
    int8_t l_633[3];
    int16_t **l_640 = &g_413;
    uint64_t l_651 = 1UL;
    uint8_t l_652 = 248UL;
    int32_t l_653 = 0x24EE6B65L;
    uint32_t *l_654[4] = {&g_246.f0,&g_246.f0,&g_246.f0,&g_246.f0};
    const uint8_t * const l_658 = &g_180;
    const uint8_t * const *l_657 = &l_658;
    uint16_t *l_659[4][1][10] = {{{&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0,&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0}},{{&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0,&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0}},{{&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0,&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0}},{{&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0,&g_328.f2,(void*)0,(void*)0,&g_328.f2,(void*)0}}};
    int8_t *l_664 = (void*)0;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_631[i] = 0x44L;
    for (i = 0; i < 3; i++)
        l_633[i] = 1L;
    for (g_6 = 8; (g_6 >= 0); g_6 -= 1)
    { /* block id: 7 */
        int32_t *l_22 = &g_23;
        int32_t *l_24 = &g_23;
        int32_t *l_25 = &g_23;
        int32_t *l_26 = (void*)0;
        int32_t *l_27 = &g_23;
        int32_t *l_28 = &g_23;
        int32_t *l_29 = &g_23;
        int32_t *l_30[5][6];
        int8_t *l_608 = &g_156;
        uint64_t *l_632[3][9][9] = {{{&g_403[0],&g_403[0],(void*)0,(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0]},{(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],(void*)0,(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],(void*)0,&g_403[0],(void*)0},{(void*)0,&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],(void*)0,(void*)0,&g_403[0],(void*)0,&g_403[0]},{&g_403[0],(void*)0,(void*)0,&g_403[0],(void*)0,(void*)0,&g_403[0],&g_403[0],(void*)0},{&g_403[0],(void*)0,(void*)0,(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,(void*)0}},{{&g_403[0],&g_403[0],&g_403[0],(void*)0,(void*)0,&g_403[0],&g_403[0],(void*)0,&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],(void*)0,(void*)0,(void*)0},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],(void*)0,(void*)0},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0}},{{&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0]},{(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0},{&g_403[0],(void*)0,&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0},{(void*)0,&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0]},{&g_403[0],&g_403[0],(void*)0,&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],(void*)0},{&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0]},{&g_403[0],&g_403[0],&g_403[0],(void*)0,&g_403[0],&g_403[0],&g_403[0],&g_403[0],(void*)0}}};
        int i, j, k;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 6; j++)
                l_30[i][j] = (void*)0;
        }
        --g_33;
        for (p_19 = 0; (p_19 <= 9); p_19 += 1)
        { /* block id: 11 */
            int64_t *l_280 = &g_110;
            int8_t *l_281 = &g_3.f1;
            int8_t **l_282 = &l_281;
            int i;
        }
        l_653 |= (((g_403[0]++) != ((safe_div_func_uint64_t_u_u(p_20, p_19)) != (safe_rshift_func_int8_t_s_s(((((((((l_640 == (g_641 = &g_413)) , (&p_19 != &l_21[4])) != g_272[3][9].f0) ^ ((*l_608) = p_19)) != ((l_32 = (!((l_31 = (safe_div_func_int8_t_s_s((safe_sub_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u((safe_div_func_int16_t_s_s(1L, 0x173EL)), 3)) & (*l_27)), l_32)), l_651))) > l_32))) , p_19)) == l_652) && (*l_28)) | l_633[2]), 4)))) != p_20);
        if (l_653)
            break;
    }
    (**g_514) = (((g_138.f0 , (l_651 & (g_246.f0 = (0x8AFC741650AAF149LL && 0xF866C8C4264FBD5BLL)))) || (safe_mod_func_uint32_t_u_u(l_653, (((l_31 ^= ((l_657 != &l_658) , 3UL)) <= (safe_lshift_func_uint8_t_u_s((safe_lshift_func_uint16_t_u_s((((((g_605.f2 | (**g_514)) , l_633[2]) || 0x923D0007L) == l_631[0]) == l_651), 2)), 1))) || (-1L))))) , p_19);
    return l_664;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_36(int32_t * p_37)
{ /* block id: 12 */
    const uint8_t l_40 = 0x3AL;
    uint64_t l_43 = 1UL;
    l_43 = (safe_mod_func_uint32_t_u_u(4294967288UL, l_40));
    return l_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_107 g_23 g_33 g_85 g_321 g_180 g_138 g_150 g_3.f1 g_334 g_340 g_243 g_267.f0 g_246.f0 g_343 g_77 g_222.f0 g_209 g_319 g_341 g_110 g_275.f2 g_42 g_377 g_328.f1 g_403 g_406 g_407 g_349 g_431 g_401 g_413 g_98 g_237 g_73 g_80 g_77.f4 g_453 g_482 g_77.f1 g_482.f2 g_328.f2 g_73.f0 g_6 g_407.f1 g_377.f0 g_275.f3 g_275.f4 g_571 g_267 g_406.f2 g_584 g_407.f2 g_300 g_605
 * writes: g_107 g_267.f0 g_222.f0 g_246.f0 g_180 g_319 g_85 g_322 g_23 g_209 g_349 g_156 g_403 g_343.f1 g_413 g_237 g_98 g_110 g_482.f2 g_514 g_407.f2 g_300
 */
static union U2  func_45(uint8_t  p_46)
{ /* block id: 114 */
    int8_t l_291 = 0x4DL;
    int32_t l_296[9] = {0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L,0xE1A63A71L};
    int32_t *l_329 = &g_85;
    uint32_t *l_342 = &g_246.f0;
    const uint32_t l_433 = 0xBD91A236L;
    int16_t **l_443 = (void*)0;
    uint8_t *l_557 = &g_180;
    const union U0 *l_585 = &g_267;
    const uint32_t l_604 = 0x405364EDL;
    int i;
    for (g_107 = 5; (g_107 >= 0); g_107 -= 1)
    { /* block id: 117 */
        int32_t *l_283 = &g_23;
        int32_t *l_285 = (void*)0;
        int32_t *l_286 = &g_85;
        int32_t *l_287[3][8][9] = {{{(void*)0,&g_85,(void*)0,(void*)0,&g_23,(void*)0,(void*)0,&g_85,(void*)0},{(void*)0,(void*)0,&g_23,&g_6,(void*)0,&g_6,(void*)0,&g_6,&g_23},{&g_23,&g_23,(void*)0,&g_85,&g_85,&g_6,(void*)0,&g_6,&g_85},{(void*)0,(void*)0,(void*)0,(void*)0,&g_85,(void*)0,&g_85,&g_23,&g_85},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_23,&g_23,&g_6},{&g_23,(void*)0,&g_23,&g_85,&g_85,&g_23,(void*)0,&g_23,(void*)0},{&g_6,(void*)0,(void*)0,&g_23,&g_85,&g_85,&g_23,(void*)0,(void*)0},{&g_85,&g_23,&g_6,(void*)0,(void*)0,&g_85,&g_85,(void*)0,(void*)0}},{{&g_85,&g_6,&g_85,&g_6,&g_23,&g_6,(void*)0,(void*)0,&g_6},{&g_6,&g_23,&g_85,&g_23,&g_6,(void*)0,(void*)0,&g_85,&g_85},{(void*)0,(void*)0,&g_6,&g_6,&g_6,(void*)0,(void*)0,&g_23,&g_85},{&g_23,(void*)0,&g_23,(void*)0,&g_6,(void*)0,&g_23,(void*)0,&g_23},{(void*)0,(void*)0,(void*)0,&g_23,&g_23,&g_6,&g_23,&g_23,(void*)0},{(void*)0,(void*)0,(void*)0,&g_85,(void*)0,&g_85,&g_23,&g_85,(void*)0},{(void*)0,&g_23,&g_23,(void*)0,&g_85,&g_85,&g_6,(void*)0,&g_6},{&g_23,(void*)0,(void*)0,(void*)0,(void*)0,&g_23,&g_6,(void*)0,&g_6}},{{(void*)0,&g_85,(void*)0,&g_85,&g_85,(void*)0,&g_85,(void*)0,(void*)0},{&g_6,(void*)0,&g_23,&g_6,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_6,(void*)0,(void*)0,&g_6,(void*)0,(void*)0,&g_6,(void*)0},{(void*)0,&g_6,(void*)0,&g_23,(void*)0,&g_23,&g_85,&g_85,&g_23},{(void*)0,&g_6,(void*)0,&g_6,(void*)0,(void*)0,&g_6,(void*)0,(void*)0},{(void*)0,(void*)0,&g_23,&g_23,&g_23,(void*)0,(void*)0,(void*)0,&g_6},{&g_85,&g_6,&g_6,(void*)0,&g_85,(void*)0,&g_6,&g_6,&g_85},{(void*)0,(void*)0,&g_85,(void*)0,&g_85,&g_23,&g_85,(void*)0,&g_85}}};
        uint8_t l_288[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
        int32_t l_299 = 0xA62E1F7FL;
        uint32_t l_302 = 1UL;
        int i, j, k;
        --l_288[2];
        if (p_46)
            break;
        if (p_46)
            continue;
        for (g_267.f0 = 0; (g_267.f0 <= 5); g_267.f0 += 1)
        { /* block id: 123 */
            uint64_t l_292 = 0x4F099C83E0C94391LL;
            int32_t l_295 = 0xF6EF4EA0L;
            int32_t l_297[5] = {0xFE1F7ADBL,0xFE1F7ADBL,0xFE1F7ADBL,0xFE1F7ADBL,0xFE1F7ADBL};
            int32_t l_298 = 0xDFDA9B5FL;
            int16_t * const l_311 = (void*)0;
            int i;
            if ((*l_283))
                break;
            ++l_292;
            ++l_302;
            for (g_222.f0 = 0; (g_222.f0 <= 5); g_222.f0 += 1)
            { /* block id: 129 */
                uint8_t l_324 = 0x4BL;
                union U1 *l_327 = &g_328;
                for (g_246.f0 = 0; (g_246.f0 <= 5); g_246.f0 += 1)
                { /* block id: 132 */
                    uint8_t *l_315 = &g_180;
                    uint16_t *l_318 = &g_319[1];
                    int32_t l_320 = (-2L);
                    (*l_286) |= (safe_mod_func_int32_t_s_s(p_46, (safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((8UL || (0L ^ ((void*)0 == l_311))) ^ (safe_div_func_uint16_t_u_u(((*l_318) = (safe_unary_minus_func_uint8_t_u(((((*l_315) = p_46) > (safe_rshift_func_uint16_t_u_u(0x3B4EL, 13))) >= p_46)))), g_33))), l_295)), l_320))));
                }
                (*g_321) = &l_297[2];
                for (g_180 = 0; (g_180 <= 5); g_180 += 1)
                { /* block id: 140 */
                    uint32_t l_323[10][4][6] = {{{18446744073709551607UL,0x1323F175L,0x5137F1E0L,0x5F934C04L,0x9E34AF9EL,0xA3F01E32L},{1UL,18446744073709551611UL,0x5137F1E0L,0UL,18446744073709551615UL,1UL},{1UL,8UL,0xA3F01E32L,18446744073709551610UL,1UL,1UL},{18446744073709551610UL,1UL,1UL,18446744073709551610UL,0xA3F01E32L,8UL}},{{1UL,1UL,18446744073709551615UL,0UL,0x5137F1E0L,18446744073709551611UL},{1UL,0xA3F01E32L,0x9E34AF9EL,0x5F934C04L,0x5137F1E0L,0x1323F175L},{18446744073709551607UL,1UL,0x60BC7536L,1UL,0xA3F01E32L,18446744073709551615UL},{0xC6E6C73EL,1UL,1UL,0xD2F77C82L,1UL,18446744073709551615UL}},{{1UL,8UL,0x60BC7536L,1UL,18446744073709551615UL,0x1323F175L},{0xA482D9A3L,18446744073709551611UL,0x9E34AF9EL,0xC6E6C73EL,0x9E34AF9EL,18446744073709551611UL},{0xA482D9A3L,0x1323F175L,18446744073709551615UL,1UL,0x60BC7536L,8UL},{1UL,18446744073709551615UL,1UL,0xD2F77C82L,1UL,1UL}},{{0xC6E6C73EL,18446744073709551615UL,0xA3F01E32L,1UL,0x60BC7536L,1UL},{18446744073709551607UL,0x1323F175L,0x5137F1E0L,0x5F934C04L,0x9E34AF9EL,0xA3F01E32L},{1UL,18446744073709551611UL,0x5137F1E0L,0UL,18446744073709551615UL,1UL},{1UL,8UL,0xA3F01E32L,18446744073709551610UL,1UL,1UL}},{{18446744073709551610UL,1UL,1UL,18446744073709551610UL,0xA3F01E32L,8UL},{1UL,1UL,18446744073709551615UL,0UL,0x5137F1E0L,18446744073709551611UL},{1UL,0xA3F01E32L,0x9E34AF9EL,0x5F934C04L,0x5137F1E0L,0x1323F175L},{18446744073709551607UL,1UL,0x60BC7536L,1UL,0xA3F01E32L,18446744073709551615UL}},{{0xC6E6C73EL,1UL,18446744073709551611UL,1UL,0UL,18446744073709551615UL},{8UL,0xBA6C3AF9L,18446744073709551608UL,1UL,18446744073709551615UL,18446744073709551615UL},{0x3C97DC50L,4UL,0x6A8BDDCCL,0xA3F01E32L,0x6A8BDDCCL,4UL},{0x3C97DC50L,18446744073709551615UL,18446744073709551615UL,1UL,18446744073709551608UL,0xBA6C3AF9L}},{{8UL,18446744073709551615UL,0UL,1UL,18446744073709551611UL,0UL},{0xA3F01E32L,18446744073709551615UL,3UL,8UL,18446744073709551608UL,18446744073709551611UL},{0UL,18446744073709551615UL,0x60387FDDL,18446744073709551611UL,0x6A8BDDCCL,3UL},{1UL,4UL,0x60387FDDL,0x1323F175L,18446744073709551615UL,18446744073709551611UL}},{{0x5137F1E0L,0xBA6C3AF9L,3UL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,0UL,0UL,18446744073709551615UL,3UL,0xBA6C3AF9L},{0x5137F1E0L,18446744073709551611UL,18446744073709551615UL,0x1323F175L,0x60387FDDL,4UL},{1UL,3UL,0x6A8BDDCCL,18446744073709551611UL,0x60387FDDL,18446744073709551615UL}},{{0UL,18446744073709551611UL,18446744073709551608UL,8UL,3UL,18446744073709551615UL},{0xA3F01E32L,0UL,18446744073709551611UL,1UL,0UL,18446744073709551615UL},{8UL,0xBA6C3AF9L,18446744073709551608UL,1UL,18446744073709551615UL,18446744073709551615UL},{0x3C97DC50L,4UL,0x6A8BDDCCL,0xA3F01E32L,0x6A8BDDCCL,4UL}},{{0x3C97DC50L,18446744073709551615UL,18446744073709551615UL,1UL,18446744073709551608UL,0xBA6C3AF9L},{8UL,18446744073709551615UL,0UL,1UL,18446744073709551611UL,0UL},{0xA3F01E32L,18446744073709551615UL,3UL,8UL,18446744073709551608UL,18446744073709551611UL},{0UL,18446744073709551615UL,0x60387FDDL,18446744073709551611UL,0x6A8BDDCCL,3UL}}};
                    int i, j, k;
                    if (l_323[2][2][0])
                        break;
                    --l_324;
                    l_327 = l_327;
                    (*l_283) &= p_46;
                }
            }
        }
    }
    (*l_329) ^= l_296[7];
    if ((p_46 != (((*l_342) ^= (g_138 , (safe_mul_func_int8_t_s_s((*g_150), (safe_sub_func_uint64_t_u_u(((void*)0 != g_334), (((~((l_329 == (void*)0) >= (safe_mod_func_int8_t_s_s((safe_lshift_func_int8_t_s_u(((((&g_243[5] != (void*)0) & 255UL) , g_340) == g_340), g_243[3])), 0xCAL)))) | p_46) == g_267.f0))))))) >= p_46)))
    { /* block id: 151 */
        (*l_329) &= (g_343 , (-9L));
        return g_77[3];
    }
    else
    { /* block id: 154 */
        uint8_t *l_350 = &g_180;
        uint8_t **l_382 = &l_350;
        int32_t l_385 = 0xC75B8925L;
        int32_t l_395 = 0xC9A296DCL;
        int32_t l_397 = 0xDF11D21EL;
        int32_t l_447 = 0x8EA05A77L;
        int8_t l_492 = (-3L);
        int32_t l_527 = (-1L);
        int32_t l_541 = (-8L);
        int8_t ** const l_580 = &g_150;
        uint16_t *l_588[9][7] = {{&g_319[1],&g_319[1],&g_328.f2,(void*)0,(void*)0,&g_328.f2,&g_319[1]},{&g_328.f2,(void*)0,&g_482.f2,&g_341.f2,&g_341.f2,&g_482.f2,(void*)0},{&g_319[1],&g_319[1],&g_328.f2,(void*)0,(void*)0,&g_328.f2,&g_319[1]},{&g_328.f2,(void*)0,&g_482.f2,&g_341.f2,&g_341.f2,&g_482.f2,(void*)0},{&g_319[1],&g_319[1],&g_328.f2,(void*)0,(void*)0,&g_328.f2,&g_319[1]},{&g_328.f2,(void*)0,&g_482.f2,&g_341.f2,&g_341.f2,&g_482.f2,(void*)0},{&g_319[1],&g_319[1],&g_328.f2,(void*)0,(void*)0,&g_328.f2,&g_319[1]},{&g_328.f2,(void*)0,&g_482.f2,&g_341.f2,&g_341.f2,&g_482.f2,(void*)0},{&g_319[1],&g_319[1],&g_328.f2,(void*)0,(void*)0,&g_328.f2,&g_319[1]}};
        int32_t l_589 = (-5L);
        int64_t *l_594 = &g_300;
        uint8_t ***l_597 = &l_382;
        uint8_t **l_599 = &g_349;
        uint8_t ***l_598 = &l_599;
        int i, j;
        for (g_222.f0 = 0; (g_222.f0 >= 26); g_222.f0++)
        { /* block id: 157 */
            if (p_46)
                break;
        }
        for (g_209 = 0; (g_209 <= 1); g_209 += 1)
        { /* block id: 162 */
            uint32_t l_346 = 0xDF0E0FF5L;
            uint8_t *l_348 = &g_180;
            uint8_t **l_347[3][3][5] = {{{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348}},{{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348}},{{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348},{&l_348,&l_348,&l_348,&l_348,&l_348}}};
            int32_t l_369 = 0x1C4F02E3L;
            int32_t l_396 = 4L;
            int16_t *l_414 = &g_237;
            uint32_t l_432 = 0x5B71E515L;
            uint16_t l_477 = 65535UL;
            uint8_t l_493 = 0x94L;
            int32_t **l_512 = &l_329;
            int8_t *l_529 = &g_343.f1;
            int i, j, k;
            if (((g_319[g_209] < (l_346 > 1UL)) > ((g_349 = &p_46) == (l_350 = &p_46))))
            { /* block id: 165 */
                int8_t l_353 = 0xAFL;
                int8_t *l_354 = &g_156;
                int32_t **l_361 = &g_322;
                int32_t ***l_362 = &l_361;
                int32_t *l_367 = &l_296[5];
                int8_t l_368 = 0x0BL;
                l_369 = (safe_lshift_func_int8_t_s_u(l_353, (((0x0BL < ((((*l_354) = (*l_329)) <= ((safe_sub_func_uint8_t_u_u(p_46, ((*g_340) , ((*l_348)--)))) != (((*l_367) = (safe_sub_func_int16_t_s_s(((((*l_362) = l_361) == &g_322) , (((((safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(p_46, p_46)), (*l_329))) > 0x58DEL) & 65532UL) , 65535UL) ^ 0xFF6AL)), 65530UL))) <= 0x2FBD0153L))) < (*l_329))) | l_368) <= g_110)));
                return g_77[4];
            }
            else
            { /* block id: 172 */
                int32_t l_380 = 5L;
                int8_t l_446 = (-1L);
                int8_t l_465 = 0x55L;
                int32_t l_475 = 0xDFC19357L;
                int32_t l_476 = (-1L);
                int16_t *l_530 = &g_98;
                int32_t *l_564 = &l_476;
                if ((~g_275[1].f2))
                { /* block id: 173 */
                    uint8_t * const *l_381 = &l_350;
                    int32_t l_383 = 5L;
                    int32_t l_398 = 0x02CED354L;
                    int32_t l_400 = (-1L);
                    int32_t l_402 = (-5L);
                    (*l_329) = (((((safe_lshift_func_int16_t_s_u(((void*)0 != g_42), 12)) || ((safe_lshift_func_uint16_t_u_s(0x691DL, ((((safe_div_func_uint8_t_u_u((g_377 , (&g_110 == ((((safe_lshift_func_int8_t_s_u((g_328.f1 || l_380), 7)) , l_381) != l_382) , (void*)0))), l_383)) > l_383) ^ 4294967295UL) >= g_110))) >= 0x16DEL)) >= g_319[g_209]) <= 0x9DL) != p_46);
                    if ((*l_329))
                        continue;
                    for (g_246.f0 = 0; (g_246.f0 <= 1); g_246.f0 += 1)
                    { /* block id: 178 */
                        int32_t *l_384 = &l_383;
                        int32_t *l_386 = &l_385;
                        int32_t *l_387 = &g_85;
                        int32_t *l_388 = &g_85;
                        int32_t *l_389 = (void*)0;
                        int32_t *l_390 = &g_85;
                        int32_t *l_391 = &g_23;
                        int32_t *l_392 = &g_85;
                        int32_t *l_393 = &l_296[1];
                        int32_t *l_394[2][10] = {{(void*)0,&l_296[1],(void*)0,&l_296[1],(void*)0,&l_296[1],(void*)0,&l_296[1],(void*)0,&l_296[1]},{&l_296[2],&l_296[1],&l_296[2],&l_296[1],&l_296[2],&l_296[1],&l_296[2],&l_296[1],&l_296[2],&l_296[1]}};
                        int32_t l_399 = 0xA057602EL;
                        int i, j;
                        ++g_403[0];
                        return g_406;
                    }
                }
                else
                { /* block id: 182 */
                    uint32_t l_408 = 0xCD7F034AL;
                    int16_t *l_412 = &g_237;
                    int16_t **l_411[3][4][9] = {{{&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412},{(void*)0,(void*)0,&l_412,&l_412,(void*)0,&l_412,&l_412,(void*)0,&l_412},{&l_412,&l_412,&l_412,(void*)0,(void*)0,&l_412,(void*)0,(void*)0,&l_412},{&l_412,(void*)0,&l_412,(void*)0,(void*)0,(void*)0,(void*)0,&l_412,(void*)0}},{{&l_412,(void*)0,&l_412,(void*)0,&l_412,(void*)0,&l_412,(void*)0,&l_412},{(void*)0,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,(void*)0,(void*)0},{(void*)0,(void*)0,&l_412,&l_412,&l_412,(void*)0,(void*)0,&l_412,(void*)0},{(void*)0,(void*)0,&l_412,&l_412,(void*)0,(void*)0,&l_412,&l_412,(void*)0}},{{&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412,&l_412},{&l_412,(void*)0,(void*)0,&l_412,(void*)0,&l_412,&l_412,(void*)0,(void*)0},{&l_412,&l_412,&l_412,(void*)0,(void*)0,&l_412,(void*)0,(void*)0,&l_412},{(void*)0,(void*)0,&l_412,(void*)0,(void*)0,(void*)0,&l_412,&l_412,&l_412}}};
                    uint8_t *l_422[3];
                    int16_t *l_464[6][10][4] = {{{&g_237,&g_98,&g_237,&g_98},{&g_98,&g_98,&g_237,&g_237},{&g_98,&g_98,&g_98,&g_98},{&g_98,&g_98,(void*)0,&g_98},{&g_98,&g_237,(void*)0,&g_237},{(void*)0,(void*)0,&g_98,&g_98},{&g_237,&g_98,&g_98,&g_237},{(void*)0,&g_98,&g_237,&g_237},{&g_237,&g_237,&g_237,&g_237},{(void*)0,&g_98,&g_237,&g_237}},{{&g_98,&g_237,&g_98,&g_98},{&g_237,&g_98,&g_98,&g_98},{&g_98,&g_237,&g_98,&g_237},{&g_98,&g_98,&g_98,&g_237},{&g_98,&g_237,(void*)0,&g_237},{&g_98,&g_98,&g_237,&g_237},{(void*)0,&g_237,&g_237,&g_98},{&g_98,&g_98,(void*)0,(void*)0},{&g_98,&g_98,&g_98,(void*)0},{&g_98,(void*)0,&g_98,&g_98}},{{&g_98,&g_98,&g_98,&g_98},{&g_237,&g_98,&g_98,&g_98},{&g_98,(void*)0,&g_237,(void*)0},{(void*)0,&g_98,&g_237,(void*)0},{&g_237,&g_98,&g_237,&g_98},{(void*)0,&g_237,&g_98,&g_237},{(void*)0,&g_98,&g_237,&g_237},{&g_237,&g_237,&g_237,&g_237},{(void*)0,&g_98,&g_237,&g_237},{&g_98,&g_237,&g_98,&g_98}},{{&g_237,&g_98,&g_98,&g_98},{&g_98,&g_237,&g_98,&g_237},{&g_98,&g_98,&g_98,&g_237},{&g_98,&g_237,(void*)0,&g_237},{&g_98,&g_98,&g_237,&g_237},{(void*)0,&g_237,&g_237,&g_98},{&g_98,&g_98,(void*)0,(void*)0},{&g_98,&g_98,&g_98,(void*)0},{&g_98,(void*)0,&g_98,&g_98},{&g_98,&g_98,&g_98,&g_98}},{{&g_237,&g_98,&g_98,&g_98},{&g_98,(void*)0,&g_237,(void*)0},{(void*)0,&g_98,&g_237,(void*)0},{&g_237,&g_98,&g_237,&g_98},{(void*)0,&g_237,&g_98,&g_237},{(void*)0,&g_98,&g_237,&g_237},{&g_237,&g_237,&g_237,&g_237},{(void*)0,&g_98,&g_237,&g_237},{&g_98,&g_237,&g_98,&g_98},{&g_237,&g_98,&g_98,&g_98}},{{&g_98,&g_237,&g_98,&g_237},{&g_98,&g_98,&g_98,&g_237},{&g_98,&g_237,(void*)0,&g_237},{&g_98,&g_98,&g_237,&g_237},{(void*)0,&g_237,(void*)0,&g_98},{&g_237,&g_98,&g_237,&g_237},{&g_237,&g_237,(void*)0,&g_237},{(void*)0,&g_237,&g_98,&g_237},{&g_237,(void*)0,&g_237,&g_98},{(void*)0,(void*)0,&g_98,&g_237}}};
                    int32_t l_474 = 0x2DC694FDL;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_422[i] = &g_180;
                    if (((*l_329) = (((*l_329) | (p_46 != (g_407 , (l_408 ^ 0x6FL)))) != ((((((g_343.f1 = l_346) , (safe_lshift_func_uint16_t_u_u((((g_413 = &g_98) != l_414) < ((((safe_mul_func_uint8_t_u_u(l_380, (*g_349))) & (-9L)) , (*l_329)) ^ 7UL)), 6))) != 0xC0A8L) | 5L) <= l_385) <= g_275[1].f2))))
                    { /* block id: 186 */
                        int32_t *l_434[5][1][9] = {{{&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23}},{{&l_396,&l_395,&l_395,&l_396,&l_396,&l_395,&l_395,&l_396,&l_396}},{{&l_395,&g_23,&l_395,&g_23,&l_395,&g_23,&l_395,&g_23,&l_395}},{{&l_396,&l_396,&l_395,&l_395,&l_396,&l_396,&l_395,&l_395,&l_396}},{{&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23,&g_23}}};
                        int16_t ***l_442[7][2][5] = {{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{(void*)0,&l_411[2][0][2],(void*)0,(void*)0,&l_411[2][0][2]}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][2][4],&l_411[2][0][2],&l_411[2][0][2]}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{&l_411[2][0][2],(void*)0,(void*)0,&l_411[2][0][2],(void*)0}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{(void*)0,&l_411[2][0][2],(void*)0,(void*)0,&l_411[2][0][2]}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][2][4],&l_411[2][0][2],&l_411[2][0][2]}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{&l_411[2][0][2],(void*)0,(void*)0,&l_411[2][0][2],(void*)0}},{{&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2],&l_411[2][0][2]},{(void*)0,&l_411[2][0][2],(void*)0,(void*)0,&l_411[2][0][2]}}};
                        int32_t **l_448 = &l_434[4][0][1];
                        int i, j, k;
                        l_296[8] = ((safe_mul_func_uint16_t_u_u(l_397, (safe_sub_func_uint16_t_u_u(((l_348 != &l_291) <= p_46), ((!l_380) > ((l_422[0] = &g_180) != (void*)0)))))) ^ (safe_mul_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u(((((*l_329) = (safe_mod_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((g_431[6] , (g_319[g_209] = (g_401 == 18446744073709551612UL))) , (*l_329)), l_432)) | 0UL), 0x90A3L))) == p_46) , 0x98L), 0)) <= 0xC626A049L), l_433)));
                        (*l_448) = func_54((safe_sub_func_int8_t_s_s((4294967286UL ^ (((((*l_329) = p_46) , (((*g_413) = ((~(((*l_412) &= (safe_mod_func_int64_t_s_s(((p_46 & (0L || p_46)) & ((l_411[2][0][2] = &g_413) == l_443)), ((safe_lshift_func_int16_t_s_s(((-1L) >= (((l_446 != 65534UL) , (-7L)) != 65534UL)), (*g_413))) , (*l_329))))) != (*l_329))) | l_396)) && l_447)) > p_46) < l_446)), (*g_150))), l_350);
                        l_296[2] = (safe_add_func_uint64_t_u_u(((safe_mod_func_int16_t_s_s((g_453 != g_340), p_46)) , (safe_mul_func_int16_t_s_s(((safe_div_func_int64_t_s_s((safe_sub_func_int64_t_s_s((((((safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_u((l_408 < ((*l_329) = (&g_98 == (l_464[0][0][1] = l_414)))), l_446)), p_46)) < (p_46 >= p_46)) != g_319[g_209]) <= l_380) & (*g_150)), l_465)), l_408)) & 4294967286UL), p_46))), g_246.f0));
                    }
                    else
                    { /* block id: 199 */
                        int32_t *l_466 = (void*)0;
                        int32_t *l_467 = &l_296[1];
                        int32_t *l_468 = &g_23;
                        int32_t *l_469 = &l_369;
                        int32_t *l_470 = &l_296[0];
                        int32_t *l_471 = &l_296[2];
                        int32_t *l_472 = &l_369;
                        int32_t *l_473[4];
                        const uint32_t l_483 = 0xC3A53F22L;
                        uint16_t *l_486[6][10][4] = {{{&g_407.f2,&g_319[g_209],&g_407.f2,&g_407.f2},{(void*)0,&g_407.f2,&g_341.f2,&g_341.f2},{(void*)0,&g_328.f2,&g_341.f2,&g_407.f2},{&g_328.f2,(void*)0,&g_341.f2,(void*)0},{(void*)0,&g_482.f2,&g_341.f2,&l_477},{(void*)0,(void*)0,&g_407.f2,&g_341.f2},{&g_407.f2,&g_341.f2,&g_319[1],&g_319[1]},{&g_319[0],&g_319[g_209],&g_319[1],&g_407.f2},{&g_328.f2,&g_319[1],&g_319[0],&g_341.f2},{(void*)0,&g_319[1],&g_319[1],(void*)0}},{{&l_477,&g_341.f2,&g_319[1],&g_319[g_209]},{&g_407.f2,&g_328.f2,(void*)0,&g_482.f2},{&g_341.f2,(void*)0,(void*)0,&g_482.f2},{&g_482.f2,&g_328.f2,&g_407.f2,&g_482.f2},{&g_341.f2,(void*)0,&l_477,&g_319[g_209]},{&g_328.f2,&g_319[0],(void*)0,&g_482.f2},{&g_407.f2,&g_341.f2,&g_328.f2,(void*)0},{(void*)0,&l_477,&g_319[0],(void*)0},{(void*)0,&g_319[1],&g_407.f2,&g_319[1]},{&g_319[1],(void*)0,(void*)0,&g_328.f2}},{{&g_482.f2,&g_407.f2,(void*)0,&g_319[0]},{&g_319[0],(void*)0,&g_328.f2,&g_341.f2},{&g_319[0],&g_407.f2,(void*)0,&g_482.f2},{&g_482.f2,&g_341.f2,(void*)0,(void*)0},{&g_319[1],&g_482.f2,&g_407.f2,&g_482.f2},{(void*)0,&g_319[1],&g_319[0],&g_319[1]},{(void*)0,&g_341.f2,&g_328.f2,(void*)0},{&g_407.f2,&g_407.f2,(void*)0,(void*)0},{&g_328.f2,&g_328.f2,&l_477,(void*)0},{&g_341.f2,&g_482.f2,&g_407.f2,(void*)0}},{{&g_407.f2,&g_319[1],&g_341.f2,&g_407.f2},{&g_319[g_209],&g_319[1],&g_482.f2,(void*)0},{&g_319[1],&g_482.f2,&g_319[g_209],(void*)0},{&g_328.f2,&g_328.f2,&g_319[0],(void*)0},{&g_319[g_209],&g_407.f2,&g_328.f2,(void*)0},{&g_407.f2,&g_341.f2,(void*)0,&g_319[1]},{(void*)0,&g_319[1],&g_341.f2,&g_482.f2},{&g_341.f2,&g_482.f2,&g_341.f2,(void*)0},{&g_341.f2,&g_341.f2,&g_482.f2,&g_482.f2},{&g_482.f2,&g_407.f2,(void*)0,&g_341.f2}},{{&g_328.f2,(void*)0,(void*)0,&g_319[0]},{&g_482.f2,&g_407.f2,&g_482.f2,&g_328.f2},{&g_341.f2,(void*)0,&g_341.f2,&g_319[1]},{&g_341.f2,&g_319[1],&g_341.f2,(void*)0},{(void*)0,&l_477,(void*)0,(void*)0},{&g_407.f2,&g_341.f2,&g_328.f2,&g_482.f2},{&g_319[g_209],&g_319[0],&g_319[0],&g_319[g_209]},{&g_328.f2,(void*)0,&g_319[g_209],&g_482.f2},{&g_319[1],&g_328.f2,&g_482.f2,&g_482.f2},{&g_319[g_209],&g_319[g_209],&g_341.f2,&g_482.f2}},{{&g_407.f2,&g_328.f2,&g_407.f2,&g_482.f2},{&g_341.f2,(void*)0,&l_477,&g_319[g_209]},{&g_328.f2,&g_319[0],(void*)0,&g_482.f2},{&g_407.f2,&g_341.f2,&g_328.f2,(void*)0},{(void*)0,&l_477,&g_319[0],(void*)0},{(void*)0,&g_319[1],&g_407.f2,&g_319[1]},{&g_319[1],(void*)0,(void*)0,&g_328.f2},{&g_482.f2,&g_407.f2,(void*)0,&g_319[0]},{&g_319[0],(void*)0,&g_328.f2,&g_341.f2},{&g_319[0],&g_407.f2,(void*)0,&g_482.f2}}};
                        int64_t *l_489 = (void*)0;
                        int64_t *l_490 = &g_110;
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_473[i] = &l_395;
                        ++l_477;
                        l_492 ^= (((*l_490) = (safe_mul_func_uint16_t_u_u(((g_482 , l_483) , (safe_add_func_uint16_t_u_u(p_46, (g_319[1]++)))), g_77[4].f1))) , (+p_46));
                    }
                    for (l_476 = 5; (l_476 >= 0); l_476 -= 1)
                    { /* block id: 207 */
                        --l_493;
                    }
                }
                for (g_482.f2 = 0; (g_482.f2 >= 14); g_482.f2 = safe_add_func_int8_t_s_s(g_482.f2, 3))
                { /* block id: 213 */
                    int8_t *l_504 = &l_492;
                    int32_t **l_513 = (void*)0;
                    int32_t l_583 = 7L;
                    if (((*l_329) = (safe_mul_func_int16_t_s_s((p_46 ^ 0x4BL), ((safe_lshift_func_uint8_t_u_u((*g_349), ((*l_348) = l_465))) > 8L)))))
                    { /* block id: 216 */
                        uint64_t l_524 = 18446744073709551615UL;
                        uint64_t *l_525 = (void*)0;
                        uint64_t *l_526[1][8][1] = {{{&g_403[0]},{&l_524},{&g_403[0]},{&g_403[0]},{&l_524},{&l_524},{&l_524},{&l_524}}};
                        int8_t **l_528[4][7][9] = {{{(void*)0,&l_504,&g_150,&l_504,&l_504,&l_504,(void*)0,(void*)0,&g_150},{&l_504,&l_504,(void*)0,&l_504,&l_504,&l_504,&g_150,(void*)0,&g_150},{&l_504,(void*)0,(void*)0,&g_150,(void*)0,&g_150,&l_504,&g_150,&l_504},{&g_150,&g_150,&g_150,&g_150,(void*)0,&g_150,&g_150,&l_504,(void*)0},{&g_150,(void*)0,&l_504,&l_504,&l_504,&l_504,&g_150,&g_150,(void*)0},{&g_150,&l_504,(void*)0,&g_150,&g_150,&g_150,(void*)0,&l_504,&g_150},{&g_150,&g_150,&g_150,(void*)0,&l_504,&l_504,(void*)0,&l_504,&l_504}},{{&g_150,&l_504,&l_504,&g_150,&g_150,&g_150,&l_504,(void*)0,&g_150},{&l_504,&g_150,&g_150,&g_150,(void*)0,&g_150,&l_504,&l_504,&g_150},{&g_150,&l_504,&g_150,&l_504,&g_150,(void*)0,&g_150,(void*)0,&g_150},{&g_150,&g_150,&g_150,(void*)0,&l_504,&l_504,&l_504,&g_150,&g_150},{&g_150,&l_504,(void*)0,&l_504,&g_150,&l_504,&g_150,&g_150,(void*)0},{&g_150,&l_504,&g_150,&l_504,&l_504,&l_504,&g_150,&l_504,&l_504},{(void*)0,(void*)0,&l_504,&g_150,(void*)0,&l_504,&g_150,&g_150,&l_504}},{{&l_504,&g_150,&l_504,(void*)0,(void*)0,&g_150,&g_150,&l_504,&g_150},{&g_150,(void*)0,(void*)0,&l_504,&l_504,&l_504,&g_150,&g_150,&g_150},{&g_150,&l_504,(void*)0,(void*)0,&l_504,&l_504,&g_150,&g_150,&g_150},{&g_150,(void*)0,&g_150,&g_150,&l_504,&g_150,&g_150,&l_504,&g_150},{&l_504,&g_150,&l_504,&g_150,(void*)0,&l_504,&g_150,&g_150,&l_504},{&g_150,&l_504,&l_504,&g_150,(void*)0,&g_150,&l_504,&g_150,(void*)0},{&g_150,&g_150,&g_150,(void*)0,(void*)0,&g_150,&g_150,&l_504,&g_150}},{{&g_150,&g_150,&l_504,&g_150,&l_504,&g_150,&l_504,(void*)0,&l_504},{&l_504,&g_150,&g_150,&g_150,&l_504,&g_150,&g_150,&g_150,&g_150},{&l_504,(void*)0,&g_150,&g_150,(void*)0,(void*)0,&g_150,&g_150,&g_150},{&l_504,&g_150,&l_504,(void*)0,&g_150,&l_504,&g_150,&l_504,&g_150},{&g_150,&l_504,(void*)0,(void*)0,&g_150,&g_150,(void*)0,&g_150,&l_504},{&l_504,&g_150,&g_150,&l_504,&g_150,&l_504,(void*)0,&l_504,&l_504},{&g_150,&g_150,&g_150,(void*)0,&g_150,&g_150,&g_150,&g_150,&g_150}}};
                        uint32_t l_558 = 18446744073709551615UL;
                        uint16_t *l_559 = (void*)0;
                        uint16_t *l_560 = (void*)0;
                        uint16_t *l_561[7][4][5] = {{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]},{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&g_407.f2,&g_319[1]}},{{&g_341.f2,(void*)0,(void*)0,&g_341.f2,&g_319[g_209]},{&g_407.f2,&g_407.f2,&g_407.f2,&l_477,&l_477},{&g_482.f2,&g_341.f2,&g_341.f2,&g_482.f2,(void*)0},{&l_477,&g_407.f2,&g_407.f2,&l_477,&l_477}}};
                        int32_t *l_562[6];
                        int i, j, k;
                        for (i = 0; i < 6; i++)
                            l_562[i] = &l_397;
                        (*l_329) = (((l_504 != (l_529 = ((((((safe_div_func_int64_t_s_s((safe_add_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s((((((*g_349) , (g_403[0] |= ((p_46 > (((safe_unary_minus_func_int16_t_s(((*g_413) &= ((0x859CBEDFL || (l_512 != (g_514 = l_513))) <= (((safe_div_func_int8_t_s_s(((safe_lshift_func_int8_t_s_s((g_328.f2 ^ g_73.f0), (!(safe_mod_func_uint8_t_u_u(((*l_348) = (safe_lshift_func_int8_t_s_s((((&l_414 == &g_413) , g_77[4].f4) || 18446744073709551612UL), p_46))), (*g_150)))))) , l_524), p_46)) || 1UL) , 0xDBL))))) || 4294967295UL) > g_77[4].f4)) > p_46))) <= g_6) , l_524) > l_527), p_46)), p_46)), g_407.f1)) == (-1L)) & 9L) > l_524) < g_246.f0) , (void*)0))) != 0L) == p_46);
                        (*l_512) = func_54((*l_329), &g_156);
                        l_475 |= ((p_46 , ((void*)0 == l_530)) , (safe_add_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((safe_mod_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u(l_541, ((safe_add_func_uint64_t_u_u(g_377.f0, (safe_mul_func_uint16_t_u_u(((((safe_mul_func_int16_t_s_s(((l_476 ^ (safe_unary_minus_func_uint64_t_u((p_46 ^ ((safe_mod_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((safe_div_func_int16_t_s_s(p_46, ((*l_329) |= ((((((safe_sub_func_int16_t_s_s(((*l_414) ^= ((&p_46 == l_557) >= g_107)), 8L)) < 0x67L) , l_558) != g_275[1].f3) < l_385) || p_46)))), g_403[0])), g_403[0])) == l_558))))) == l_446), p_46)) == p_46) > p_46) || 0x92A838BA98DE215ALL), g_275[1].f4)))) , p_46))) ^ l_385), (*g_349))), l_446)), 5)), p_46)));
                    }
                    else
                    { /* block id: 227 */
                        int16_t l_563 = 0xBB61L;
                        l_563 &= p_46;
                        if (p_46)
                            continue;
                        l_564 = (*l_512);
                        l_296[1] &= ((-1L) & (0xDEL || ((safe_sub_func_int32_t_s_s(((safe_div_func_int64_t_s_s((safe_add_func_uint64_t_u_u((g_571 , (safe_rshift_func_int8_t_s_s(((((safe_sub_func_uint32_t_u_u((((*l_350) = ((*l_348)++)) <= (g_267 , ((safe_sub_func_int8_t_s_s((l_583 = (l_580 != ((safe_lshift_func_uint8_t_u_u((((-1L) == (**l_512)) && ((((l_492 & (**l_512)) , 0x2522DAC0L) && 0x1C68E808L) != l_563)), l_385)) , (void*)0))), (*l_329))) , 1UL))), l_563)) != 0x0BL) < (-4L)) | g_23), l_395))), g_406.f2)), 0x26C68A52474208F3LL)) || 0xB54624D93F11F2B1LL), l_563)) < 0x4AL)));
                    }
                }
            }
            return g_584;
        }
        l_585 = l_585;
        (*l_329) = ((safe_rshift_func_int8_t_s_u(((++g_407.f2) > ((p_46 = ((safe_div_func_int64_t_s_s(((*l_594) &= (*l_329)), (p_46 , 9L))) , (safe_mul_func_uint16_t_u_u((((*l_597) = &l_350) != ((*l_598) = &l_350)), p_46)))) & ((safe_add_func_uint8_t_u_u(((*l_329) , (((((*l_329) != ((safe_add_func_int8_t_s_s((((((void*)0 == l_557) <= 5UL) < (*l_329)) != 0xC8L), (*g_150))) < 0UL)) , (*l_329)) && (*l_329)) , l_385)), 5L)) , l_604))), l_589)) > 0xB2E4L);
    }
    return g_605;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_33 g_3.f1 g_73 g_77 g_80 g_77.f4 g_23 g_85 g_77.f0 g_77.f2 g_3 g_103 g_107 g_98 g_73.f0 g_138 g_150 g_103.f0 g_110 g_77.f3 g_77.f1 g_180 g_209 g_219 g_222 g_222.f0 g_243 g_246 g_267 g_272
 * writes: g_23 g_85 g_98 g_107 g_110 g_150 g_156 g_77.f1 g_180 g_209 g_219 g_237 g_243
 */
static union U0  func_47(int32_t * p_48, const uint32_t  p_49)
{ /* block id: 15 */
    int32_t *l_50[6][5][8] = {{{&g_6,&g_23,&g_23,(void*)0,(void*)0,(void*)0,&g_23,&g_23},{&g_23,&g_6,(void*)0,&g_6,&g_23,(void*)0,&g_6,&g_6},{&g_6,&g_23,&g_6,&g_6,&g_23,&g_6,&g_6,&g_6},{&g_23,&g_6,(void*)0,(void*)0,&g_6,&g_23,&g_23,&g_23},{&g_6,&g_23,&g_23,&g_23,(void*)0,(void*)0,&g_6,(void*)0}},{{&g_23,&g_6,&g_6,&g_23,&g_23,(void*)0,&g_23,&g_23},{&g_6,&g_23,&g_6,(void*)0,&g_6,&g_23,(void*)0,&g_6},{&g_23,&g_6,&g_23,&g_6,&g_6,(void*)0,&g_6,&g_6},{&g_23,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6,&g_23},{&g_6,&g_23,&g_6,(void*)0,&g_23,&g_23,&g_6,&g_6}},{{&g_23,(void*)0,(void*)0,&g_6,(void*)0,&g_23,&g_6,&g_23},{&g_6,&g_23,&g_6,&g_23,&g_6,&g_6,&g_6,&g_6},{&g_23,&g_6,&g_6,&g_23,&g_23,(void*)0,&g_6,&g_23},{&g_6,&g_6,&g_6,&g_6,&g_23,&g_23,&g_6,&g_6},{&g_23,&g_23,&g_6,&g_6,(void*)0,(void*)0,&g_6,&g_23}},{{&g_6,&g_6,(void*)0,&g_23,&g_6,(void*)0,&g_6,&g_23},{&g_6,&g_23,&g_6,&g_6,&g_6,&g_23,&g_6,&g_6},{&g_23,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6,&g_23},{(void*)0,&g_23,&g_23,&g_23,&g_6,(void*)0,(void*)0,&g_6},{&g_23,&g_6,&g_6,&g_23,&g_6,(void*)0,&g_23,&g_23}},{{&g_6,&g_23,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_23,&g_23,(void*)0,(void*)0,(void*)0,&g_23,&g_23},{&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,(void*)0,&g_23},{(void*)0,&g_6,(void*)0,(void*)0,&g_6,&g_6,(void*)0,(void*)0},{&g_6,(void*)0,&g_6,&g_6,(void*)0,&g_6,&g_6,&g_6}},{{(void*)0,&g_6,&g_6,&g_6,&g_6,&g_6,&g_23,&g_6},{&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6},{(void*)0,&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,(void*)0},{&g_6,&g_23,&g_6,(void*)0,&g_6,&g_6,&g_6,&g_23},{&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,(void*)0,&g_6}}};
    uint16_t l_181 = 0x9C82L;
    int16_t l_253 = 1L;
    int8_t **l_258 = &g_150;
    uint8_t *l_269 = &g_180;
    uint8_t **l_268 = &l_269;
    uint8_t ***l_271 = &l_268;
    int i, j, k;
    if (func_36(l_50[0][0][7]))
    { /* block id: 16 */
        uint32_t l_51 = 0x45490A9DL;
        int32_t l_69 = (-1L);
        int8_t *l_70[9][7][4] = {{{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1}},{{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,(void*)0,&g_3.f1,&g_3.f1}},{{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1}},{{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1}},{{(void*)0,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{(void*)0,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1}},{{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1}},{{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1}},{{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1}},{{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,&g_3.f1,&g_3.f1,&g_3.f1},{&g_3.f1,(void*)0,&g_3.f1,&g_3.f1}}};
        int8_t *l_90[3][1];
        int16_t l_91 = (-7L);
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_90[i][j] = (void*)0;
        }
        l_51--;
        if ((0x34C8L || ((g_6 ^ p_49) | (l_51 >= func_36(func_54((g_33 && (l_51 ^ (safe_div_func_uint16_t_u_u((safe_add_func_int8_t_s_s((l_69 = func_61(func_64(p_49, &g_23), l_50[0][0][7])), g_3.f1)), g_3.f1)))), l_70[6][5][0]))))))
        { /* block id: 30 */
            int8_t **l_89 = &l_70[3][6][3];
            int32_t *l_96 = &g_6;
            int16_t *l_97 = &g_98;
            l_69 = ((safe_mul_func_uint16_t_u_u((((*l_89) = l_70[6][5][0]) != l_90[1][0]), ((*l_97) = ((l_91 &= p_49) & (safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_u(p_49, 4)), (((&g_23 == l_96) && g_77[4].f0) | ((void*)0 == &l_90[2][0])))))))) ^ g_77[4].f2);
        }
        else
        { /* block id: 35 */
            l_69 ^= 0x85881B6AL;
        }
    }
    else
    { /* block id: 38 */
        int64_t *l_106 = &g_107;
        int64_t *l_108 = (void*)0;
        int64_t *l_109 = &g_110;
        int32_t l_124 = 0x585002FAL;
        int32_t l_130 = (-1L);
        uint8_t l_131 = 254UL;
        int32_t l_212 = 9L;
        int32_t l_215 = 0L;
        int32_t l_216[8][9] = {{0L,(-1L),0x73866EE0L,0xE50CD27CL,0L,0xE50CD27CL,0x73866EE0L,(-1L),0L},{0x996AD940L,1L,(-1L),0x73866EE0L,2L,(-1L),1L,(-1L),2L},{(-9L),1L,1L,(-9L),0xE50CD27CL,1L,0xABF4834DL,2L,(-1L)},{0x996AD940L,2L,1L,(-4L),(-4L),1L,2L,0x996AD940L,0L},{0L,(-4L),(-1L),0x996AD940L,0xE50CD27CL,2L,2L,0xE50CD27CL,0x996AD940L},{0x73866EE0L,0L,0x73866EE0L,1L,2L,(-4L),0xABF4834DL,0L,0L},{1L,0L,0L,2L,0L,0L,1L,0xABF4834DL,(-1L)},{0xABF4834DL,(-4L),0xE50CD27CL,(-1L),(-4L),0x996AD940L,(-4L),(-1L),0xE50CD27CL}};
        uint32_t *l_247 = &g_243[4];
        int32_t l_252 = (-1L);
        int8_t **l_259[9][9] = {{&g_150,&g_150,(void*)0,&g_150,&g_150,(void*)0,&g_150,(void*)0,&g_150},{&g_150,(void*)0,(void*)0,&g_150,(void*)0,&g_150,&g_150,&g_150,&g_150},{&g_150,(void*)0,(void*)0,(void*)0,(void*)0,&g_150,(void*)0,&g_150,(void*)0},{&g_150,&g_150,&g_150,(void*)0,(void*)0,&g_150,&g_150,&g_150,&g_150},{(void*)0,(void*)0,&g_150,(void*)0,&g_150,&g_150,(void*)0,&g_150,(void*)0},{(void*)0,&g_150,&g_150,&g_150,(void*)0,&g_150,&g_150,(void*)0,&g_150},{&g_150,&g_150,&g_150,(void*)0,(void*)0,(void*)0,&g_150,&g_150,(void*)0},{&g_150,&g_150,(void*)0,&g_150,&g_150,&g_150,(void*)0,&g_150,&g_150},{&g_150,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_150,(void*)0,&g_150}};
        int i, j;
        if ((safe_add_func_uint64_t_u_u(p_49, (p_49 && ((safe_sub_func_uint8_t_u_u((g_3 , (p_48 != (g_103 , (void*)0))), (((*l_109) = ((*l_106) = 0xBA28DA27851ED01BLL)) <= (g_23 > p_49)))) <= 0x8389L)))))
        { /* block id: 41 */
            const uint64_t l_119 = 0xB7DE0C385723E820LL;
            int8_t *l_153 = (void*)0;
            int32_t l_157 = (-1L);
            int32_t l_214 = 0L;
            int32_t l_217 = 0xBDDEB08EL;
            uint32_t *l_240 = (void*)0;
            uint32_t *l_241 = &g_209;
            uint32_t *l_242 = &g_243[1];
            for (g_107 = 0; (g_107 <= 4); g_107 += 1)
            { /* block id: 44 */
                uint8_t l_111 = 250UL;
                int32_t l_125 = 0x249FF590L;
                int8_t *l_152 = (void*)0;
                --l_111;
                l_124 = ((((0x54FFL > ((((g_85 |= (safe_lshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((!p_49), l_119)), ((l_130 &= (safe_lshift_func_int8_t_s_s((((l_125 = (safe_sub_func_int32_t_s_s(l_124, g_98))) && (g_73.f0 <= (p_49 == l_124))) , (((safe_mod_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s((p_49 , 0x7C446C13L), 7L)) != 0x01CFL), p_49)) , p_49) == p_49)), 3))) > p_49)))) & l_119) && g_77[4].f4) & 18446744073709551610UL)) < l_131) && 0x1EL) > p_49);
                for (l_131 = 0; (l_131 <= 4); l_131 += 1)
                { /* block id: 52 */
                    int8_t **l_151 = &g_150;
                    int32_t l_154 = (-3L);
                    int8_t *l_155 = &g_156;
                    uint32_t *l_158[4];
                    int32_t l_159 = (-9L);
                    int32_t l_213 = 0x75F73016L;
                    int i;
                    for (i = 0; i < 4; i++)
                        l_158[i] = &g_77[4].f1;
                    if ((l_159 &= (safe_lshift_func_uint16_t_u_u((((g_77[4].f1 = (l_157 = (safe_div_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s(l_125, ((*l_155) = (g_138 , ((g_103 , g_77[1]) , (((safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((((safe_div_func_int8_t_s_s((((safe_div_func_int16_t_s_s(((~(l_154 = (safe_mul_func_int8_t_s_s(0xB8L, (((l_152 = ((*l_151) = g_150)) == l_153) && ((18446744073709551607UL && l_154) > g_6)))))) >= 0x31L), l_130)) && 0xA37329A5L) || 0x42E7455E0D3EF503LL), (-7L))) < 0x5FEB66E7L) >= 0x54L), g_98)), g_103.f0)) >= g_110) >= g_23)))))), g_77[4].f3)))) , p_49) != p_49), 14))))
                    { /* block id: 60 */
                        int16_t l_174 = 0x9FEAL;
                        uint8_t *l_178 = &l_111;
                        uint8_t *l_179 = &g_180;
                        l_157 = (safe_div_func_int16_t_s_s((((g_73 , (safe_div_func_int32_t_s_s(0x5FCC9BDCL, (l_124 |= ((~9L) < g_103.f0))))) | (!((-1L) && (((safe_lshift_func_uint16_t_u_u(0x7E23L, 0)) > (!(safe_add_func_uint64_t_u_u(0x02CAF5ADCE77D404LL, (safe_unary_minus_func_int8_t_s((safe_sub_func_uint32_t_u_u(((((((*l_109) = (g_6 < (6L < g_6))) < 5UL) <= g_77[4].f1) | 0x95L) >= p_49), l_174)))))))) ^ 0UL)))) , g_77[4].f1), l_131));
                        l_125 &= ((safe_unary_minus_func_uint64_t_u(((g_3.f1 , l_159) | (((*l_178) = g_103.f0) == ((*l_179) ^= p_49))))) ^ (((((l_131 , l_119) | g_77[4].f3) || (((((l_174 , &g_98) != &g_98) | g_6) , p_49) > g_3.f1)) , l_181) <= 253UL));
                    }
                    else
                    { /* block id: 67 */
                        int16_t l_186 = 0x5290L;
                        int32_t l_205 = 1L;
                        uint32_t *l_208 = &g_209;
                        int32_t l_218 = 1L;
                        l_213 ^= (g_73.f0 , (safe_lshift_func_int16_t_s_s((safe_add_func_int32_t_s_s((l_186 |= p_49), (-4L))), ((((safe_sub_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s((safe_div_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(0xEA086712L, ((0xE69FL > ((safe_rshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u((safe_sub_func_int8_t_s_s(l_205, ((safe_mod_func_uint8_t_u_u((((*l_208) &= (0UL || p_49)) < (l_159 = (safe_sub_func_uint8_t_u_u(l_212, (*g_150))))), (*g_150))) <= l_212))), g_103.f0)), 5)) > p_49)) <= 2UL))), 0xCD35L)), 6)), l_130)), g_107)) && p_49) ^ l_125) <= 0xF2L))));
                        --g_219;
                    }
                    for (l_154 = 0; (l_154 <= 4); l_154 += 1)
                    { /* block id: 76 */
                        return g_222;
                    }
                }
            }
            for (l_181 = (-21); (l_181 != 37); l_181++)
            { /* block id: 83 */
                uint8_t l_225 = 0xC1L;
                l_225++;
            }
            l_124 &= ((safe_div_func_uint32_t_u_u(((*l_241) |= ((safe_lshift_func_int16_t_s_u(((safe_lshift_func_uint16_t_u_u(g_222.f0, (+(g_237 = ((safe_mul_func_uint16_t_u_u(p_49, ((-10L) || l_157))) > 1L))))) & 0x5648L), 1)) == (safe_lshift_func_int8_t_s_s(p_49, 4)))), (((((*l_242) |= 4294967295UL) <= ((safe_sub_func_int64_t_s_s(((p_49 != p_49) == g_180), g_77[4].f0)) == p_49)) >= p_49) , p_49))) && l_217);
        }
        else
        { /* block id: 90 */
            return g_246;
        }
        l_253 ^= ((p_49 || (((&g_180 != (void*)0) , (void*)0) == l_247)) ^ (safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_u((l_216[0][6] && 2UL), 5)), l_252)));
        for (g_110 = 0; (g_110 > 28); g_110 = safe_add_func_uint8_t_u_u(g_110, 1))
        { /* block id: 96 */
            for (l_181 = (-12); (l_181 >= 28); l_181 = safe_add_func_int32_t_s_s(l_181, 7))
            { /* block id: 99 */
                int16_t l_260 = 3L;
                int16_t *l_263 = (void*)0;
                int16_t *l_264 = (void*)0;
                int16_t *l_265 = &g_237;
                int32_t l_266 = 0x68C300E8L;
                l_259[4][8] = l_258;
                l_260 = 1L;
                l_266 = ((safe_add_func_int16_t_s_s(l_260, g_243[1])) < ((*l_265) = 0x2C54L));
                if (l_215)
                    break;
            }
        }
        return g_267;
    }
    (*l_271) = l_268;
    return g_272[3][9];
}


/* ------------------------------------------ */
/* 
 * reads : g_3.f1 g_73 g_77 g_80 g_77.f4 g_23 g_85
 * writes: g_23 g_85
 */
static int32_t * func_54(int32_t  p_55, int8_t * p_56)
{ /* block id: 24 */
    int32_t *l_72 = &g_23;
    int8_t *l_74 = &g_3.f1;
    int8_t *l_76 = &g_3.f1;
    int8_t **l_75 = &l_76;
    int32_t *l_83 = (void*)0;
    int32_t *l_84 = &g_85;
lbl_86:
    (*l_72) = (safe_unary_minus_func_uint64_t_u(g_3.f1));
    (*l_84) &= (((((0x93AA688ECCDF3378LL && ((g_73 , l_74) == ((*l_75) = p_56))) && ((g_77[4] , (safe_sub_func_uint16_t_u_u(((void*)0 == g_80), ((0xF6617FA1L < (safe_lshift_func_int16_t_s_u((((1UL | 0x5DF2L) == 1L) , p_55), 11))) & 65529UL)))) >= p_55)) != g_77[4].f4) , (*l_72)) == p_55);
    if (p_55)
        goto lbl_86;
    return &g_85;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_61(uint64_t  p_62, int32_t * p_63)
{ /* block id: 21 */
    return p_62;
}


/* ------------------------------------------ */
/* 
 * reads : g_33
 * writes: g_23
 */
static uint64_t  func_64(int16_t  p_65, const int32_t * p_66)
{ /* block id: 18 */
    uint16_t l_67 = 65529UL;
    int32_t *l_68 = &g_23;
    (*l_68) = l_67;
    return g_33;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3.f1, "g_3.f1", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_73.f0, "g_73.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_77[i].f0, "g_77[i].f0", print_hash_value);
        transparent_crc(g_77[i].f1, "g_77[i].f1", print_hash_value);
        transparent_crc(g_77[i].f2, "g_77[i].f2", print_hash_value);
        transparent_crc(g_77[i].f3, "g_77[i].f3", print_hash_value);
        transparent_crc(g_77[i].f4, "g_77[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_103.f0, "g_103.f0", print_hash_value);
    transparent_crc(g_103.f1, "g_103.f1", print_hash_value);
    transparent_crc(g_103.f2, "g_103.f2", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_138.f0, "g_138.f0", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_180, "g_180", print_hash_value);
    transparent_crc(g_209, "g_209", print_hash_value);
    transparent_crc(g_219, "g_219", print_hash_value);
    transparent_crc(g_222.f0, "g_222.f0", print_hash_value);
    transparent_crc(g_222.f1, "g_222.f1", print_hash_value);
    transparent_crc(g_237, "g_237", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_243[i], "g_243[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_246.f0, "g_246.f0", print_hash_value);
    transparent_crc(g_246.f1, "g_246.f1", print_hash_value);
    transparent_crc(g_267.f0, "g_267.f0", print_hash_value);
    transparent_crc(g_267.f1, "g_267.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_272[i][j].f0, "g_272[i][j].f0", print_hash_value);
            transparent_crc(g_272[i][j].f1, "g_272[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_275[i].f0, "g_275[i].f0", print_hash_value);
        transparent_crc(g_275[i].f1, "g_275[i].f1", print_hash_value);
        transparent_crc(g_275[i].f2, "g_275[i].f2", print_hash_value);
        transparent_crc(g_275[i].f3, "g_275[i].f3", print_hash_value);
        transparent_crc(g_275[i].f4, "g_275[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_300, "g_300", print_hash_value);
    transparent_crc(g_301, "g_301", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_319[i], "g_319[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_328.f2, "g_328.f2", print_hash_value);
    transparent_crc(g_341.f0, "g_341.f0", print_hash_value);
    transparent_crc(g_341.f1, "g_341.f1", print_hash_value);
    transparent_crc(g_341.f2, "g_341.f2", print_hash_value);
    transparent_crc(g_377.f0, "g_377.f0", print_hash_value);
    transparent_crc(g_401, "g_401", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_403[i], "g_403[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_406.f0, "g_406.f0", print_hash_value);
    transparent_crc(g_406.f1, "g_406.f1", print_hash_value);
    transparent_crc(g_406.f2, "g_406.f2", print_hash_value);
    transparent_crc(g_406.f3, "g_406.f3", print_hash_value);
    transparent_crc(g_406.f4, "g_406.f4", print_hash_value);
    transparent_crc(g_407.f2, "g_407.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_431[i].f0, "g_431[i].f0", print_hash_value);
        transparent_crc(g_431[i].f1, "g_431[i].f1", print_hash_value);
        transparent_crc(g_431[i].f2, "g_431[i].f2", print_hash_value);
        transparent_crc(g_431[i].f3, "g_431[i].f3", print_hash_value);
        transparent_crc(g_431[i].f4, "g_431[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_482.f2, "g_482.f2", print_hash_value);
    transparent_crc(g_571.f0, "g_571.f0", print_hash_value);
    transparent_crc(g_571.f1, "g_571.f1", print_hash_value);
    transparent_crc(g_584.f0, "g_584.f0", print_hash_value);
    transparent_crc(g_584.f1, "g_584.f1", print_hash_value);
    transparent_crc(g_584.f2, "g_584.f2", print_hash_value);
    transparent_crc(g_584.f3, "g_584.f3", print_hash_value);
    transparent_crc(g_584.f4, "g_584.f4", print_hash_value);
    transparent_crc(g_605.f0, "g_605.f0", print_hash_value);
    transparent_crc(g_605.f1, "g_605.f1", print_hash_value);
    transparent_crc(g_605.f2, "g_605.f2", print_hash_value);
    transparent_crc(g_605.f3, "g_605.f3", print_hash_value);
    transparent_crc(g_605.f4, "g_605.f4", print_hash_value);
    transparent_crc(g_728, "g_728", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    transparent_crc(g_763.f0, "g_763.f0", print_hash_value);
    transparent_crc(g_763.f1, "g_763.f1", print_hash_value);
    transparent_crc(g_763.f2, "g_763.f2", print_hash_value);
    transparent_crc(g_763.f3, "g_763.f3", print_hash_value);
    transparent_crc(g_763.f4, "g_763.f4", print_hash_value);
    transparent_crc(g_768, "g_768", print_hash_value);
    transparent_crc(g_785.f0, "g_785.f0", print_hash_value);
    transparent_crc(g_785.f1, "g_785.f1", print_hash_value);
    transparent_crc(g_785.f2, "g_785.f2", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_788[i][j][k].f2, "g_788[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_792.f0, "g_792.f0", print_hash_value);
    transparent_crc(g_820.f0, "g_820.f0", print_hash_value);
    transparent_crc(g_820.f1, "g_820.f1", print_hash_value);
    transparent_crc(g_820.f2, "g_820.f2", print_hash_value);
    transparent_crc(g_846.f0, "g_846.f0", print_hash_value);
    transparent_crc(g_846.f1, "g_846.f1", print_hash_value);
    transparent_crc(g_846.f2, "g_846.f2", print_hash_value);
    transparent_crc(g_846.f3, "g_846.f3", print_hash_value);
    transparent_crc(g_846.f4, "g_846.f4", print_hash_value);
    transparent_crc(g_848.f0, "g_848.f0", print_hash_value);
    transparent_crc(g_848.f1, "g_848.f1", print_hash_value);
    transparent_crc(g_848.f2, "g_848.f2", print_hash_value);
    transparent_crc(g_848.f3, "g_848.f3", print_hash_value);
    transparent_crc(g_848.f4, "g_848.f4", print_hash_value);
    transparent_crc(g_855.f0, "g_855.f0", print_hash_value);
    transparent_crc(g_855.f1, "g_855.f1", print_hash_value);
    transparent_crc(g_857.f0, "g_857.f0", print_hash_value);
    transparent_crc(g_857.f1, "g_857.f1", print_hash_value);
    transparent_crc(g_857.f2, "g_857.f2", print_hash_value);
    transparent_crc(g_857.f3, "g_857.f3", print_hash_value);
    transparent_crc(g_857.f4, "g_857.f4", print_hash_value);
    transparent_crc(g_886.f0, "g_886.f0", print_hash_value);
    transparent_crc(g_886.f1, "g_886.f1", print_hash_value);
    transparent_crc(g_900.f0, "g_900.f0", print_hash_value);
    transparent_crc(g_927.f0, "g_927.f0", print_hash_value);
    transparent_crc(g_927.f1, "g_927.f1", print_hash_value);
    transparent_crc(g_927.f2, "g_927.f2", print_hash_value);
    transparent_crc(g_1036.f0, "g_1036.f0", print_hash_value);
    transparent_crc(g_1036.f1, "g_1036.f1", print_hash_value);
    transparent_crc(g_1036.f2, "g_1036.f2", print_hash_value);
    transparent_crc(g_1036.f3, "g_1036.f3", print_hash_value);
    transparent_crc(g_1036.f4, "g_1036.f4", print_hash_value);
    transparent_crc(g_1073.f0, "g_1073.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_1079[i][j][k].f0, "g_1079[i][j][k].f0", print_hash_value);
                transparent_crc(g_1079[i][j][k].f1, "g_1079[i][j][k].f1", print_hash_value);
                transparent_crc(g_1079[i][j][k].f2, "g_1079[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_1112[i][j].f0, "g_1112[i][j].f0", print_hash_value);
            transparent_crc(g_1112[i][j].f1, "g_1112[i][j].f1", print_hash_value);
            transparent_crc(g_1112[i][j].f2, "g_1112[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1206[i][j][k].f0, "g_1206[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1210.f0, "g_1210.f0", print_hash_value);
    transparent_crc(g_1210.f1, "g_1210.f1", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1228[i].f0, "g_1228[i].f0", print_hash_value);
        transparent_crc(g_1228[i].f1, "g_1228[i].f1", print_hash_value);
        transparent_crc(g_1228[i].f2, "g_1228[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1236[i][j][k].f0, "g_1236[i][j][k].f0", print_hash_value);
                transparent_crc(g_1236[i][j][k].f1, "g_1236[i][j][k].f1", print_hash_value);
                transparent_crc(g_1236[i][j][k].f2, "g_1236[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1258.f0, "g_1258.f0", print_hash_value);
    transparent_crc(g_1258.f1, "g_1258.f1", print_hash_value);
    transparent_crc(g_1258.f2, "g_1258.f2", print_hash_value);
    transparent_crc(g_1258.f3, "g_1258.f3", print_hash_value);
    transparent_crc(g_1258.f4, "g_1258.f4", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1266[i], "g_1266[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1274.f0, "g_1274.f0", print_hash_value);
    transparent_crc(g_1277.f0, "g_1277.f0", print_hash_value);
    transparent_crc(g_1318, "g_1318", print_hash_value);
    transparent_crc(g_1364, "g_1364", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1369[i][j].f0, "g_1369[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1390, "g_1390", print_hash_value);
    transparent_crc(g_1434.f0, "g_1434.f0", print_hash_value);
    transparent_crc(g_1434.f1, "g_1434.f1", print_hash_value);
    transparent_crc(g_1434.f2, "g_1434.f2", print_hash_value);
    transparent_crc(g_1434.f3, "g_1434.f3", print_hash_value);
    transparent_crc(g_1434.f4, "g_1434.f4", print_hash_value);
    transparent_crc(g_1450, "g_1450", print_hash_value);
    transparent_crc(g_1468.f0, "g_1468.f0", print_hash_value);
    transparent_crc(g_1468.f1, "g_1468.f1", print_hash_value);
    transparent_crc(g_1468.f2, "g_1468.f2", print_hash_value);
    transparent_crc(g_1468.f3, "g_1468.f3", print_hash_value);
    transparent_crc(g_1468.f4, "g_1468.f4", print_hash_value);
    transparent_crc(g_1472.f0, "g_1472.f0", print_hash_value);
    transparent_crc(g_1484.f0, "g_1484.f0", print_hash_value);
    transparent_crc(g_1484.f1, "g_1484.f1", print_hash_value);
    transparent_crc(g_1484.f2, "g_1484.f2", print_hash_value);
    transparent_crc(g_1526.f0, "g_1526.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1639[i][j].f0, "g_1639[i][j].f0", print_hash_value);
            transparent_crc(g_1639[i][j].f1, "g_1639[i][j].f1", print_hash_value);
            transparent_crc(g_1639[i][j].f2, "g_1639[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1699[i], "g_1699[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1712.f0, "g_1712.f0", print_hash_value);
    transparent_crc(g_1713, "g_1713", print_hash_value);
    transparent_crc(g_1736, "g_1736", print_hash_value);
    transparent_crc(g_1765.f0, "g_1765.f0", print_hash_value);
    transparent_crc(g_1765.f1, "g_1765.f1", print_hash_value);
    transparent_crc(g_1765.f2, "g_1765.f2", print_hash_value);
    transparent_crc(g_1799, "g_1799", print_hash_value);
    transparent_crc(g_1800, "g_1800", print_hash_value);
    transparent_crc(g_1801, "g_1801", print_hash_value);
    transparent_crc(g_1818.f0, "g_1818.f0", print_hash_value);
    transparent_crc(g_1826.f0, "g_1826.f0", print_hash_value);
    transparent_crc(g_1826.f1, "g_1826.f1", print_hash_value);
    transparent_crc(g_1826.f2, "g_1826.f2", print_hash_value);
    transparent_crc(g_1826.f3, "g_1826.f3", print_hash_value);
    transparent_crc(g_1826.f4, "g_1826.f4", print_hash_value);
    transparent_crc(g_1829.f0, "g_1829.f0", print_hash_value);
    transparent_crc(g_1829.f1, "g_1829.f1", print_hash_value);
    transparent_crc(g_1829.f2, "g_1829.f2", print_hash_value);
    transparent_crc(g_1829.f3, "g_1829.f3", print_hash_value);
    transparent_crc(g_1829.f4, "g_1829.f4", print_hash_value);
    transparent_crc(g_1902, "g_1902", print_hash_value);
    transparent_crc(g_1917.f0, "g_1917.f0", print_hash_value);
    transparent_crc(g_1917.f1, "g_1917.f1", print_hash_value);
    transparent_crc(g_1917.f2, "g_1917.f2", print_hash_value);
    transparent_crc(g_1917.f3, "g_1917.f3", print_hash_value);
    transparent_crc(g_1917.f4, "g_1917.f4", print_hash_value);
    transparent_crc(g_1960.f0, "g_1960.f0", print_hash_value);
    transparent_crc(g_1960.f1, "g_1960.f1", print_hash_value);
    transparent_crc(g_1960.f2, "g_1960.f2", print_hash_value);
    transparent_crc(g_1960.f3, "g_1960.f3", print_hash_value);
    transparent_crc(g_1960.f4, "g_1960.f4", print_hash_value);
    transparent_crc(g_1988, "g_1988", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_2005[i][j].f0, "g_2005[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2018[i][j].f0, "g_2018[i][j].f0", print_hash_value);
            transparent_crc(g_2018[i][j].f1, "g_2018[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2039.f0, "g_2039.f0", print_hash_value);
    transparent_crc(g_2039.f1, "g_2039.f1", print_hash_value);
    transparent_crc(g_2039.f2, "g_2039.f2", print_hash_value);
    transparent_crc(g_2039.f3, "g_2039.f3", print_hash_value);
    transparent_crc(g_2039.f4, "g_2039.f4", print_hash_value);
    transparent_crc(g_2069.f0, "g_2069.f0", print_hash_value);
    transparent_crc(g_2069.f1, "g_2069.f1", print_hash_value);
    transparent_crc(g_2069.f2, "g_2069.f2", print_hash_value);
    transparent_crc(g_2069.f3, "g_2069.f3", print_hash_value);
    transparent_crc(g_2069.f4, "g_2069.f4", print_hash_value);
    transparent_crc(g_2098, "g_2098", print_hash_value);
    transparent_crc(g_2122, "g_2122", print_hash_value);
    transparent_crc(g_2131.f0, "g_2131.f0", print_hash_value);
    transparent_crc(g_2133.f0, "g_2133.f0", print_hash_value);
    transparent_crc(g_2134.f0, "g_2134.f0", print_hash_value);
    transparent_crc(g_2142.f0, "g_2142.f0", print_hash_value);
    transparent_crc(g_2169.f0, "g_2169.f0", print_hash_value);
    transparent_crc(g_2185.f0, "g_2185.f0", print_hash_value);
    transparent_crc(g_2185.f1, "g_2185.f1", print_hash_value);
    transparent_crc(g_2190, "g_2190", print_hash_value);
    transparent_crc(g_2211.f0, "g_2211.f0", print_hash_value);
    transparent_crc(g_2211.f1, "g_2211.f1", print_hash_value);
    transparent_crc(g_2211.f2, "g_2211.f2", print_hash_value);
    transparent_crc(g_2211.f3, "g_2211.f3", print_hash_value);
    transparent_crc(g_2211.f4, "g_2211.f4", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2229[i].f0, "g_2229[i].f0", print_hash_value);
        transparent_crc(g_2229[i].f1, "g_2229[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_2264[i][j].f0, "g_2264[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2277.f0, "g_2277.f0", print_hash_value);
    transparent_crc(g_2277.f1, "g_2277.f1", print_hash_value);
    transparent_crc(g_2277.f2, "g_2277.f2", print_hash_value);
    transparent_crc(g_2411.f0, "g_2411.f0", print_hash_value);
    transparent_crc(g_2411.f1, "g_2411.f1", print_hash_value);
    transparent_crc(g_2429.f0, "g_2429.f0", print_hash_value);
    transparent_crc(g_2429.f1, "g_2429.f1", print_hash_value);
    transparent_crc(g_2429.f2, "g_2429.f2", print_hash_value);
    transparent_crc(g_2429.f3, "g_2429.f3", print_hash_value);
    transparent_crc(g_2429.f4, "g_2429.f4", print_hash_value);
    transparent_crc(g_2451.f0, "g_2451.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2471[i][j][k].f0, "g_2471[i][j][k].f0", print_hash_value);
                transparent_crc(g_2471[i][j][k].f1, "g_2471[i][j][k].f1", print_hash_value);
                transparent_crc(g_2471[i][j][k].f2, "g_2471[i][j][k].f2", print_hash_value);
                transparent_crc(g_2471[i][j][k].f3, "g_2471[i][j][k].f3", print_hash_value);
                transparent_crc(g_2471[i][j][k].f4, "g_2471[i][j][k].f4", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_2481[i][j], "g_2481[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2499.f0, "g_2499.f0", print_hash_value);
    transparent_crc(g_2500.f0, "g_2500.f0", print_hash_value);
    transparent_crc(g_2533.f0, "g_2533.f0", print_hash_value);
    transparent_crc(g_2542, "g_2542", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2566[i].f0, "g_2566[i].f0", print_hash_value);
        transparent_crc(g_2566[i].f1, "g_2566[i].f1", print_hash_value);
        transparent_crc(g_2566[i].f2, "g_2566[i].f2", print_hash_value);
        transparent_crc(g_2566[i].f3, "g_2566[i].f3", print_hash_value);
        transparent_crc(g_2566[i].f4, "g_2566[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2569.f0, "g_2569.f0", print_hash_value);
    transparent_crc(g_2569.f1, "g_2569.f1", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2576[i].f0, "g_2576[i].f0", print_hash_value);
        transparent_crc(g_2576[i].f1, "g_2576[i].f1", print_hash_value);
        transparent_crc(g_2576[i].f2, "g_2576[i].f2", print_hash_value);
        transparent_crc(g_2576[i].f3, "g_2576[i].f3", print_hash_value);
        transparent_crc(g_2576[i].f4, "g_2576[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2638.f0, "g_2638.f0", print_hash_value);
    transparent_crc(g_2638.f1, "g_2638.f1", print_hash_value);
    transparent_crc(g_2638.f2, "g_2638.f2", print_hash_value);
    transparent_crc(g_2638.f3, "g_2638.f3", print_hash_value);
    transparent_crc(g_2638.f4, "g_2638.f4", print_hash_value);
    transparent_crc(g_2678, "g_2678", print_hash_value);
    transparent_crc(g_2696, "g_2696", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2705[i][j][k].f0, "g_2705[i][j][k].f0", print_hash_value);
                transparent_crc(g_2705[i][j][k].f1, "g_2705[i][j][k].f1", print_hash_value);
                transparent_crc(g_2705[i][j][k].f2, "g_2705[i][j][k].f2", print_hash_value);
                transparent_crc(g_2705[i][j][k].f3, "g_2705[i][j][k].f3", print_hash_value);
                transparent_crc(g_2705[i][j][k].f4, "g_2705[i][j][k].f4", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2720.f0, "g_2720.f0", print_hash_value);
    transparent_crc(g_2720.f1, "g_2720.f1", print_hash_value);
    transparent_crc(g_2752.f0, "g_2752.f0", print_hash_value);
    transparent_crc(g_2773.f0, "g_2773.f0", print_hash_value);
    transparent_crc(g_2773.f1, "g_2773.f1", print_hash_value);
    transparent_crc(g_2773.f2, "g_2773.f2", print_hash_value);
    transparent_crc(g_2773.f3, "g_2773.f3", print_hash_value);
    transparent_crc(g_2773.f4, "g_2773.f4", print_hash_value);
    transparent_crc(g_2774.f0, "g_2774.f0", print_hash_value);
    transparent_crc(g_2774.f1, "g_2774.f1", print_hash_value);
    transparent_crc(g_2774.f2, "g_2774.f2", print_hash_value);
    transparent_crc(g_2774.f3, "g_2774.f3", print_hash_value);
    transparent_crc(g_2774.f4, "g_2774.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 673
XXX total union variables: 70

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 53
breakdown:
   indirect level: 0, occurrence: 24
   indirect level: 1, occurrence: 15
   indirect level: 2, occurrence: 10
   indirect level: 3, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 69
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 39
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 9

XXX max expression depth: 39
breakdown:
   depth: 1, occurrence: 195
   depth: 2, occurrence: 44
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 3
   depth: 18, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 4
   depth: 21, occurrence: 6
   depth: 22, occurrence: 2
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 26, occurrence: 4
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 39, occurrence: 1

XXX total number of pointers: 619

XXX times a variable address is taken: 1667
XXX times a pointer is dereferenced on RHS: 359
breakdown:
   depth: 1, occurrence: 270
   depth: 2, occurrence: 60
   depth: 3, occurrence: 18
   depth: 4, occurrence: 11
XXX times a pointer is dereferenced on LHS: 358
breakdown:
   depth: 1, occurrence: 321
   depth: 2, occurrence: 29
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 53
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 18
XXX times a pointer is qualified to be dereferenced: 6832

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1783
   level: 2, occurrence: 252
   level: 3, occurrence: 83
   level: 4, occurrence: 56
XXX number of pointers point to pointers: 198
XXX number of pointers point to scalars: 363
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.4
XXX average alias set size: 1.51

XXX times a non-volatile is read: 2224
XXX times a non-volatile is write: 1063
XXX times a volatile is read: 135
XXX    times read thru a pointer: 19
XXX times a volatile is write: 22
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 5.56e+03
XXX percentage of non-volatile access: 95.4

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 192
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 42
   depth: 2, occurrence: 31
   depth: 3, occurrence: 26
   depth: 4, occurrence: 28
   depth: 5, occurrence: 35

XXX percentage a fresh-made variable is used: 18.6
XXX percentage an existing variable is used: 81.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

