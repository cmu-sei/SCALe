/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1602826796
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint8_t  f0;
   volatile uint64_t  f1;
   const int8_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = (-1L);
static int64_t g_76 = 0x412097756EB3E198LL;
static uint16_t g_80 = 0xB5CFL;
static int32_t g_83 = 0L;
static volatile uint8_t g_87 = 0UL;/* VOLATILE GLOBAL g_87 */
static uint16_t g_90 = 65535UL;
static uint16_t g_126 = 0UL;
static int32_t * const  volatile g_153[7][5][1] = {{{&g_3},{&g_3},{&g_83},{(void*)0},{(void*)0}},{{&g_83},{&g_83},{&g_83},{(void*)0},{(void*)0}},{{&g_83},{&g_3},{&g_3},{&g_3},{&g_3}},{{&g_3},{&g_83},{(void*)0},{(void*)0},{&g_83}},{{&g_83},{&g_83},{(void*)0},{(void*)0},{&g_83}},{{&g_3},{&g_3},{&g_3},{&g_3},{&g_3}},{{&g_83},{(void*)0},{(void*)0},{&g_83},{&g_83}}};
static uint8_t g_169 = 0x86L;
static int32_t *g_185 = &g_3;
static int32_t **g_184 = &g_185;
static int8_t g_210 = (-1L);
static int8_t g_212 = 0xE6L;
static uint64_t g_221[1][5][2] = {{{0xDD5D329C145D4FDDLL,0UL},{0xDD5D329C145D4FDDLL,0UL},{0xDD5D329C145D4FDDLL,0UL},{0xDD5D329C145D4FDDLL,0UL},{0xDD5D329C145D4FDDLL,0UL}}};
static const int8_t g_229 = 0xC8L;
static volatile union U0 g_316 = {4UL};/* VOLATILE GLOBAL g_316 */
static int32_t *g_323 = (void*)0;
static uint8_t g_341[10][10][2] = {{{0x5EL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL}},{{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL}},{{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL}},{{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL}},{{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL}},{{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL}},{{9UL,0UL},{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL}},{{0x5EL,253UL},{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL}},{{255UL,0UL},{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{9UL,0UL},{0x5EL,253UL},{255UL,0UL}},{{9UL,0UL},{0x71L,253UL},{0x71L,0UL},{9UL,0UL},{255UL,253UL},{0x5EL,0UL},{0UL,0xD9L},{9UL,0xF0L},{0x02L,255UL},{0UL,253UL}}};
static uint64_t g_353 = 0x8C004BFBC94AE0E3LL;
static const uint32_t g_362 = 0x04760FD3L;
static int32_t *** volatile g_367 = &g_184;/* VOLATILE GLOBAL g_367 */
static volatile union U0 g_396 = {0UL};/* VOLATILE GLOBAL g_396 */
static volatile int16_t g_406 = 0x5392L;/* VOLATILE GLOBAL g_406 */
static volatile int8_t g_487 = 0L;/* VOLATILE GLOBAL g_487 */
static volatile int8_t *g_486 = &g_487;
static volatile int8_t ** volatile g_485 = &g_486;/* VOLATILE GLOBAL g_485 */
static volatile int16_t *g_500 = (void*)0;
static union U0 g_517 = {255UL};/* VOLATILE GLOBAL g_517 */
static int32_t g_551[7] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
static int16_t g_553 = 0xA90CL;
static uint64_t g_584 = 0x1147DD618E0B50C6LL;
static union U0 g_615 = {0x5FL};/* VOLATILE GLOBAL g_615 */
static int32_t * volatile g_618[6][10] = {{&g_83,&g_83,&g_551[4],(void*)0,&g_3,&g_551[6],&g_83,(void*)0,&g_83,&g_551[6]},{&g_3,&g_551[4],(void*)0,&g_551[4],&g_3,&g_551[2],&g_83,&g_83,&g_551[2],&g_551[2]},{(void*)0,&g_83,&g_83,&g_551[6],&g_551[6],&g_83,&g_83,(void*)0,(void*)0,&g_551[2]},{(void*)0,&g_551[6],&g_83,&g_551[2],&g_3,&g_83,&g_3,&g_551[2],&g_83,&g_551[6]},{&g_83,&g_551[2],&g_83,&g_3,&g_3,&g_551[2],(void*)0,(void*)0,&g_551[2],&g_3},{&g_551[2],&g_83,&g_83,&g_551[2],&g_551[4],&g_551[2],(void*)0,&g_83,&g_3,&g_83}};
static int32_t * volatile g_619 = (void*)0;/* VOLATILE GLOBAL g_619 */
static int32_t g_626 = 1L;
static int16_t g_639 = 0x762FL;
static int32_t * volatile g_640 = &g_551[2];/* VOLATILE GLOBAL g_640 */
static int32_t **** const g_673 = (void*)0;
static int32_t g_691[6][4][8] = {{{0x068EE025L,0xD878E9D8L,3L,0x022F84A9L,(-1L),(-1L),0x46B129EFL,0xD0976B42L},{0x068EE025L,0x2AC9B3DAL,(-4L),0xF9E30CB8L,0x46B129EFL,0x199A1D45L,0x3F5BD358L,0x55E2CF7BL},{0xFC2177D7L,(-8L),0L,5L,0L,(-1L),0xF9E07210L,(-1L)},{5L,0xFC2177D7L,0xE882AF70L,0x87964C4EL,0L,0x8747F9E7L,0x8063E04CL,0x022F84A9L}},{{0xA187CF64L,1L,(-1L),0x8839C7F7L,0L,3L,0L,0L},{0x2AF407B7L,0xF9E30CB8L,0L,0x35C063DCL,0x35C063DCL,0L,0xF9E30CB8L,0x2AF407B7L},{0L,0x0562A3BCL,0L,0xAC8C6B54L,0x87964C4EL,0x1FE73E1CL,0x15E88212L,0L},{0x46B129EFL,0x2B10CB1CL,0x55E2CF7BL,(-1L),0xAC8C6B54L,0x1FE73E1CL,0xE65C42B6L,0x5A3A4CF1L}},{{1L,0x0562A3BCL,0xAB394525L,0xD45A7F7EL,0xE95DB4E0L,0L,0L,1L},{0x5A3A4CF1L,0xF9E30CB8L,0x87964C4EL,0xE65C42B6L,1L,3L,1L,0x8063E04CL},{0xAC8C6B54L,1L,1L,0xF9E07210L,0xD878E9D8L,0x8747F9E7L,(-1L),5L},{0L,0xFC2177D7L,(-1L),0x15E88212L,1L,(-1L),(-1L),(-1L)}},{{0x8063E04CL,(-8L),5L,(-8L),0x8063E04CL,0x199A1D45L,0x8747F9E7L,0L},{0L,0x2AC9B3DAL,0L,0x9B890603L,0x199A1D45L,(-1L),0x7461726BL,(-8L)},{0L,0xD878E9D8L,0L,0xAC8C6B54L,0x8063E04CL,0L,0xAB394525L,0x068EE025L},{0xE95DB4E0L,0x199A1D45L,0L,0x8063E04CL,0xFC2177D7L,(-1L),0xAC8C6B54L,0xF9E30CB8L}},{{0x022F84A9L,0xE65C42B6L,(-8L),0x3F5BD358L,0x8747F9E7L,5L,0x46B129EFL,0xD878E9D8L},{0xE882AF70L,0xAB394525L,0x3F5BD358L,(-1L),0x35C063DCL,0x8063E04CL,0x9B890603L,0x022F84A9L},{0x46B129EFL,0xFC2177D7L,0L,8L,1L,1L,8L,0L},{0L,0L,0xD878E9D8L,0xFC2177D7L,0x7461726BL,0x5A3A4CF1L,1L,0L}},{{(-1L),0L,0xF9E07210L,(-4L),0x11484A97L,0L,0x022F84A9L,0L},{0L,0x87964C4EL,0xE882AF70L,0xFC2177D7L,5L,0x2AF407B7L,0x8839C7F7L,0L},{0x2B10CB1CL,0x068EE025L,0x87964C4EL,8L,0x9B890603L,0L,0xE882AF70L,0x022F84A9L},{0L,0xD0976B42L,0x46B129EFL,(-1L),(-1L),0x022F84A9L,3L,0xD878E9D8L}}};
static volatile union U0 g_696 = {0x07L};/* VOLATILE GLOBAL g_696 */
static uint32_t g_724 = 0UL;
static int32_t * volatile g_752[6][4] = {{&g_83,(void*)0,&g_3,&g_83},{&g_551[2],&g_3,&g_551[6],&g_3},{&g_551[6],&g_3,&g_551[2],&g_83},{&g_3,(void*)0,&g_83,&g_551[6]},{(void*)0,&g_551[2],&g_551[2],(void*)0},{(void*)0,&g_83,&g_83,(void*)0}};
static int32_t * volatile g_753 = &g_83;/* VOLATILE GLOBAL g_753 */
static uint32_t * const g_806 = &g_724;
static uint32_t * const *g_805 = &g_806;
static uint32_t * const * volatile *g_804 = &g_805;
static uint32_t *g_845 = &g_724;
static uint32_t **g_844 = &g_845;
static int16_t g_847 = 0x9B72L;
static uint8_t * volatile g_851 = &g_169;/* VOLATILE GLOBAL g_851 */
static uint8_t * volatile *g_850 = &g_851;
static uint64_t * volatile g_919[10][7] = {{&g_353,&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0],&g_353,&g_353},{&g_221[0][2][1],&g_221[0][2][0],&g_353,&g_221[0][2][0],&g_221[0][2][1],&g_353,&g_221[0][2][1]},{&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0]},{&g_353,&g_221[0][2][0],&g_353,&g_584,&g_221[0][2][1],&g_584,&g_353},{&g_221[0][2][0],&g_221[0][2][0],&g_353,&g_221[0][2][0],&g_221[0][2][0],&g_353,&g_221[0][2][0]},{&g_221[0][2][1],&g_584,&g_353,&g_221[0][2][0],&g_353,&g_584,&g_221[0][2][1]},{&g_353,&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0],&g_353,&g_353},{&g_221[0][2][1],&g_221[0][2][0],&g_353,&g_221[0][2][0],&g_221[0][2][1],&g_353,&g_221[0][2][1]},{&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0],&g_353,&g_353,&g_221[0][2][0]},{&g_353,&g_221[0][2][0],&g_353,&g_584,&g_221[0][2][1],&g_584,&g_353}};
static uint64_t * volatile * volatile g_918 = &g_919[1][1];/* VOLATILE GLOBAL g_918 */
static volatile uint32_t g_952 = 18446744073709551609UL;/* VOLATILE GLOBAL g_952 */
static uint32_t g_969 = 0xC60130D9L;
static int8_t *g_1051[8][9] = {{&g_210,&g_210,&g_212,&g_210,&g_210,&g_212,&g_210,&g_210,&g_212},{&g_210,&g_212,&g_212,&g_212,&g_210,&g_212,&g_210,&g_212,&g_212},{&g_210,&g_210,&g_210,&g_212,&g_212,&g_210,&g_210,&g_212,&g_210},{(void*)0,&g_210,&g_210,&g_210,(void*)0,&g_212,(void*)0,&g_210,&g_210},{&g_212,&g_212,&g_210,&g_210,&g_212,&g_210,&g_210,&g_210,&g_210},{(void*)0,&g_210,&g_210,&g_210,(void*)0,&g_212,(void*)0,&g_210,&g_210},{&g_212,&g_210,&g_210,&g_212,&g_212,&g_210,&g_210,&g_212,&g_210},{(void*)0,&g_210,&g_210,&g_210,(void*)0,&g_212,(void*)0,&g_210,&g_210}};
static int8_t **g_1050 = &g_1051[2][2];
static int16_t *g_1091 = (void*)0;
static volatile union U0 g_1114 = {254UL};/* VOLATILE GLOBAL g_1114 */
static uint64_t g_1138 = 0x54322289374A2323LL;
static volatile union U0 g_1199 = {255UL};/* VOLATILE GLOBAL g_1199 */
static int16_t **g_1283[6] = {&g_1091,&g_1091,&g_1091,&g_1091,&g_1091,&g_1091};
static int64_t g_1354[9][6] = {{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL},{0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL,0xF2291F6925340F06LL,0xF2291F6925340F06LL,0x8BF8DF545543F911LL}};
static int32_t ** volatile g_1356 = &g_323;/* VOLATILE GLOBAL g_1356 */
static union U0 g_1394 = {0x75L};/* VOLATILE GLOBAL g_1394 */
static int32_t ** volatile g_1418 = &g_185;/* VOLATILE GLOBAL g_1418 */
static volatile union U0 g_1436 = {0xD0L};/* VOLATILE GLOBAL g_1436 */
static volatile uint64_t g_1440 = 1UL;/* VOLATILE GLOBAL g_1440 */
static volatile uint64_t * volatile g_1439 = &g_1440;/* VOLATILE GLOBAL g_1439 */
static volatile uint64_t * volatile *g_1438 = &g_1439;
static volatile uint64_t * volatile * volatile * const g_1437 = &g_1438;
static int32_t *g_1443 = &g_691[3][1][2];
static uint8_t g_1517 = 255UL;
static uint16_t *g_1560[2] = {(void*)0,(void*)0};
static uint16_t **g_1559 = &g_1560[1];
static union U0 g_1626 = {0x33L};/* VOLATILE GLOBAL g_1626 */
static int32_t ** volatile g_1655 = (void*)0;/* VOLATILE GLOBAL g_1655 */
static int32_t *g_1662 = (void*)0;
static int8_t g_1709 = 7L;
static union U0 g_1749 = {6UL};/* VOLATILE GLOBAL g_1749 */
static volatile union U0 g_1760 = {246UL};/* VOLATILE GLOBAL g_1760 */
static volatile union U0 g_1792 = {0xC3L};/* VOLATILE GLOBAL g_1792 */
static volatile int32_t g_1833 = (-1L);/* VOLATILE GLOBAL g_1833 */
static volatile uint8_t g_1843 = 0xDDL;/* VOLATILE GLOBAL g_1843 */
static int32_t ** const  volatile g_1879 = &g_185;/* VOLATILE GLOBAL g_1879 */
static int8_t *** volatile g_1915[1] = {&g_1050};
static uint64_t g_1940 = 0xCC865D17E2D5F90CLL;
static union U0 *g_1986 = &g_1394;
static union U0 ** const  volatile g_1985 = &g_1986;/* VOLATILE GLOBAL g_1985 */
static int32_t ** volatile g_1987[5][7] = {{(void*)0,&g_1662,&g_323,&g_323,&g_1662,(void*)0,&g_323},{&g_1662,&g_1662,&g_1662,&g_1662,&g_1662,&g_1662,(void*)0},{(void*)0,&g_1662,&g_323,&g_323,&g_1662,(void*)0,&g_323},{&g_1662,&g_1662,&g_1662,&g_1662,&g_1662,&g_1662,(void*)0},{(void*)0,&g_1662,&g_323,&g_323,&g_1662,(void*)0,&g_323}};
static const int64_t g_1990 = 1L;
static union U0 g_2011 = {2UL};/* VOLATILE GLOBAL g_2011 */
static int32_t * volatile g_2033 = &g_83;/* VOLATILE GLOBAL g_2033 */
static union U0 g_2034 = {1UL};/* VOLATILE GLOBAL g_2034 */


/* --- FORWARD DECLARATIONS --- */
static union U0  func_1(void);
static int32_t  func_6(int64_t  p_7, int32_t * p_8);
static int64_t  func_9(int32_t * p_10, int32_t  p_11);
static int32_t * func_12(int32_t * p_13, uint16_t  p_14, int8_t  p_15, int32_t * p_16, const int32_t * p_17);
static int32_t * func_18(int32_t * p_19, int32_t * p_20);
static int32_t * func_21(int32_t  p_22, int32_t  p_23, int16_t  p_24, uint32_t  p_25, uint32_t  p_26);
static int32_t * func_27(uint32_t  p_28, uint8_t  p_29, const int32_t * p_30);
static int64_t  func_33(int32_t * p_34, int32_t * p_35);
static int32_t * func_36(int32_t * p_37, int32_t * p_38, int32_t * const  p_39, int32_t * p_40);
static int32_t * func_41(int32_t  p_42, int64_t  p_43, int16_t  p_44, const int32_t * p_45);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_1356 g_323 g_212 g_626 g_185 g_184 g_396.f2 g_517.f2 g_1437 g_1438 g_1439 g_1440 g_844 g_845 g_724 g_1626.f2 g_362 g_1985 g_1879 g_1990 g_691 g_850 g_851 g_87 g_80 g_673 g_90 g_126 g_76 g_2011 g_486 g_487 g_169 g_2033 g_2034
 * writes: g_3 g_212 g_626 g_553 g_724 g_639 g_1986 g_185 g_615.f0 g_169 g_584 g_80 g_76 g_1354 g_83
 */
static union U0  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3;
    uint64_t l_74[2][8] = {{0xF455DBFE6B87C265LL,0xB1067DCC3592E7BALL,0xF455DBFE6B87C265LL,0xF455DBFE6B87C265LL,0xB1067DCC3592E7BALL,0xF455DBFE6B87C265LL,0xF455DBFE6B87C265LL,0xB1067DCC3592E7BALL},{0xB1067DCC3592E7BALL,0xF455DBFE6B87C265LL,0xF455DBFE6B87C265LL,0xB1067DCC3592E7BALL,0xF455DBFE6B87C265LL,0xF455DBFE6B87C265LL,0xB1067DCC3592E7BALL,0xF455DBFE6B87C265LL}};
    int32_t *l_746 = &g_3;
    const int32_t *l_973[2][10][10] = {{{&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0},{&g_3,(void*)0,&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3,(void*)0,(void*)0,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,(void*)0},{(void*)0,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0},{&g_3,(void*)0,&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3,(void*)0,(void*)0,&g_3}}};
    int32_t l_1317[7][6] = {{(-7L),(-7L),0x8A70C14FL,(-1L),0x8A70C14FL,(-7L)},{0x8A70C14FL,0x538F46EEL,(-1L),(-1L),0x538F46EEL,0x8A70C14FL},{(-7L),0x8A70C14FL,(-1L),0x8A70C14FL,0x8A70C14FL,0x8A70C14FL},{(-1L),0xC5BE5AFCL,0xC5BE5AFCL,(-1L),(-7L),(-1L)},{(-1L),(-7L),(-1L),0xC5BE5AFCL,0xC5BE5AFCL,(-1L)},{0x8A70C14FL,0x8A70C14FL,0xC5BE5AFCL,0x538F46EEL,0xC5BE5AFCL,0x8A70C14FL},{0xC5BE5AFCL,(-7L),0x538F46EEL,0x538F46EEL,(-7L),0xC5BE5AFCL}};
    uint16_t l_1967 = 0x7BADL;
    uint32_t **l_2016 = &g_845;
    int i, j, k;
    (*l_2) = 1L;
    for (g_3 = 0; (g_3 == 22); ++g_3)
    { /* block id: 4 */
        int32_t *l_63 = (void*)0;
        int32_t **l_62 = &l_63;
        int64_t *l_75 = &g_76;
        uint16_t *l_77 = (void*)0;
        uint16_t *l_78 = (void*)0;
        uint16_t *l_79 = &g_80;
        const int32_t *l_642 = (void*)0;
        int32_t *l_690[10][8] = {{(void*)0,&g_691[4][2][7],(void*)0,&g_691[2][3][2],(void*)0,&g_626,&g_691[5][3][5],&g_691[4][2][7]},{(void*)0,&g_626,&g_691[5][3][5],&g_691[4][2][7],(void*)0,(void*)0,&g_691[4][2][7],&g_691[4][2][7]},{(void*)0,&g_691[3][3][6],&g_691[3][3][4],&g_691[3][3][4],&g_691[3][3][6],(void*)0,&g_626,&g_626},{&g_691[2][3][6],&g_626,&g_691[3][3][6],(void*)0,&g_626,&g_691[4][2][7],&g_691[4][2][5],&g_691[5][3][5]},{&g_691[4][2][7],&g_691[4][2][7],&g_626,(void*)0,&g_691[4][2][7],(void*)0,&g_626,&g_626},{&g_626,&g_691[4][2][7],&g_626,&g_691[3][3][4],&g_626,&g_691[4][2][7],(void*)0,&g_691[4][2][7]},{&g_691[4][2][7],&g_691[2][3][6],&g_691[4][0][2],&g_691[4][2][7],&g_626,&g_626,&g_626,&g_691[4][2][7]},{&g_691[4][2][7],&g_626,&g_691[4][2][7],&g_691[2][3][2],&g_691[2][3][6],&g_691[2][3][7],&g_626,&g_691[4][2][7]},{&g_626,&g_691[4][2][7],(void*)0,&g_691[4][2][7],&g_691[4][0][0],&g_626,&g_691[2][3][6],(void*)0},{&g_626,&g_691[4][2][5],&g_626,&g_626,&g_691[2][3][6],(void*)0,(void*)0,&g_691[5][0][1]}};
        int32_t l_692 = 0xD26C430CL;
        int32_t *l_972 = &g_3;
        int i, j;
    }
    l_973[1][9][8] = (*g_1356);
    if ((*l_746))
    { /* block id: 855 */
        int64_t l_1964[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        int32_t l_1965 = (-1L);
        int8_t ***l_1972 = &g_1050;
        int32_t *l_1989 = &l_1317[4][1];
        int i;
        for (g_212 = 0; (g_212 >= (-30)); --g_212)
        { /* block id: 858 */
            int32_t ***l_1945 = &g_184;
            uint32_t l_1966 = 1UL;
            int32_t l_1980 = 0xA0D21199L;
            int8_t ***l_1999 = &g_1050;
            for (g_626 = 0; (g_626 <= 0); g_626 += 1)
            { /* block id: 861 */
                int32_t * const *l_1947 = &g_185;
                int32_t * const **l_1946 = &l_1947;
                int i;
                (*g_185) = ((safe_add_func_int64_t_s_s(((l_1945 == l_1946) >= (safe_lshift_func_int16_t_s_s((***l_1946), ((safe_mul_func_uint16_t_u_u((safe_div_func_int8_t_s_s(0xB4L, (***l_1946))), (safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_mod_func_uint64_t_u_u((((**g_184) ^ (safe_mod_func_uint8_t_u_u(0x57L, (safe_mod_func_int8_t_s_s((**l_1947), 0x28L))))) && l_1964[7]), g_396.f2)) >= l_1965), 0)), (**l_1947))))) >= l_1966)))), g_517.f2)) > l_1965);
                l_1967 = 0x11E19E2DL;
            }
            for (g_3 = (-28); (g_3 <= (-28)); g_3 = safe_add_func_uint64_t_u_u(g_3, 3))
            { /* block id: 867 */
                int32_t l_1976 = 0x9517A8F4L;
                uint8_t l_1979 = 0x55L;
                int32_t *l_1991 = &l_1317[3][5];
                for (g_553 = 0; (g_553 < 6); g_553 = safe_add_func_uint8_t_u_u(g_553, 2))
                { /* block id: 870 */
                    int8_t l_1975 = 0xFAL;
                    int16_t *l_1981 = &g_639;
                    int32_t l_1982 = 0L;
                    union U0 * const l_1983 = &g_1626;
                    l_1317[4][1] = (l_1972 != &g_485);
                    if ((((((***g_1437) || (((**g_844)++) != 0L)) ^ l_1975) < ((l_1975 , 0xDE42L) < l_1976)) ^ ((*l_1981) = ((((((((***l_1945) || l_1975) < (g_1626.f2 != g_362)) < l_1979) > l_1975) == (***l_1945)) & l_1980) > 0UL))))
                    { /* block id: 874 */
                        union U0 **l_1984 = (void*)0;
                        int32_t **l_1988[6] = {&l_2,&l_2,&l_2,&l_2,&l_2,&l_2};
                        int i;
                        l_1982 = 0xCE2A50A0L;
                        if ((***l_1945))
                            continue;
                        (*g_1985) = l_1983;
                        l_1989 = ((*g_184) = (*g_1879));
                    }
                    else
                    { /* block id: 880 */
                        if (g_1990)
                            break;
                    }
                }
                (*l_1991) |= 1L;
                for (g_615.f0 = 0; (g_615.f0 != 30); g_615.f0 = safe_add_func_int8_t_s_s(g_615.f0, 1))
                { /* block id: 887 */
                    uint16_t l_1996 = 0x7AA7L;
                    for (l_1980 = (-22); (l_1980 >= (-30)); --l_1980)
                    { /* block id: 890 */
                        const uint8_t l_2008 = 0UL;
                        int16_t *l_2009[1][6][6] = {{{(void*)0,&g_639,(void*)0,&g_639,(void*)0,(void*)0},{&g_847,&g_639,&g_847,&g_553,&g_553,&g_553},{&g_553,&g_553,&g_553,&g_553,&g_847,&g_639},{&g_847,(void*)0,(void*)0,&g_639,(void*)0,&g_639},{(void*)0,&g_847,&g_553,&g_847,(void*)0,&g_847},{&g_639,(void*)0,(void*)0,&g_553,&g_847,(void*)0}}};
                        int32_t l_2010 = (-2L);
                        int i, j, k;
                        l_1996--;
                        l_1989 = func_27(((((((((65531UL > (l_1989 != (void*)0)) & g_691[4][2][7]) ^ ((void*)0 == l_1999)) ^ ((**g_850) = 0xB9L)) == (safe_lshift_func_uint8_t_u_s((safe_div_func_uint16_t_u_u((*l_1989), (safe_div_func_uint32_t_u_u((((l_2010 = (safe_mul_func_int16_t_s_s(l_2008, (*l_2)))) & 0x758CL) & 0x97L), (*l_1989))))), (*l_1991)))) < (*g_185)) >= (*l_2)) > g_1990), (***l_1945), &l_1976);
                    }
                }
                (*g_184) = &l_1317[6][2];
            }
            return g_2011;
        }
    }
    else
    { /* block id: 901 */
        uint32_t ***l_2013 = &g_844;
        uint32_t ****l_2012 = &l_2013;
        const uint32_t *l_2015 = (void*)0;
        const uint32_t **l_2014 = &l_2015;
        uint32_t l_2027 = 0xC8E72946L;
        int64_t *l_2030 = &g_1354[0][1];
        uint64_t l_2031 = 18446744073709551606UL;
        int64_t l_2032 = (-3L);
        (*g_2033) = ((&g_844 != ((*l_2012) = &g_844)) == (((l_2014 == l_2016) >= (safe_rshift_func_int8_t_s_s(((*l_2) = (0xCF870A4F909488E8LL && ((safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_s(((*g_486) , (((*l_2) , (safe_rshift_func_int8_t_s_s(((((safe_rshift_func_int16_t_s_s((l_2027 <= ((*l_2030) = (((safe_lshift_func_uint8_t_u_u(l_2027, 4)) , l_2027) || 0xE2193C2CL))), 1)) , 2UL) >= (**g_850)) | l_2027), 1))) != l_2031)), l_2027)), (*g_185))) | 4UL))), 5))) < l_2032));
    }
    return g_2034;
}


/* ------------------------------------------ */
/* 
 * reads : g_724 g_3 g_126 g_90 g_1418 g_185
 * writes: g_724 g_126 g_90
 */
static int32_t  func_6(int64_t  p_7, int32_t * p_8)
{ /* block id: 826 */
    int8_t **l_1914[9][3];
    int8_t ***l_1916 = &l_1914[6][0];
    int32_t l_1919 = 0x993CF049L;
    int32_t **l_1928 = &g_323;
    int32_t *l_1935 = &g_551[0];
    int32_t *l_1936[9] = {&g_83,&g_551[4],&g_83,&g_83,&g_551[4],&g_83,&g_83,&g_551[4],&g_83};
    uint32_t l_1937 = 0UL;
    int i, j;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
            l_1914[i][j] = &g_1051[2][2];
    }
    (*l_1916) = l_1914[1][0];
    for (g_724 = (-23); (g_724 >= 4); g_724++)
    { /* block id: 830 */
        uint32_t l_1920 = 0UL;
        uint16_t *l_1921 = &g_126;
        int32_t l_1931 = 1L;
        if ((*p_8))
            break;
        l_1919 = (0xAE38L && ((l_1919 != ((*l_1921) &= (l_1919 > ((l_1920 , l_1919) && p_7)))) == ((((((safe_mul_func_int8_t_s_s(0x45L, 0x2CL)) , (safe_div_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((l_1928 == l_1928), l_1920)), p_7))) && 0x27F2C2F2L) && p_7) == 4294967295UL) >= (*p_8))));
        for (g_90 = 0; (g_90 == 32); g_90++)
        { /* block id: 836 */
            int32_t l_1934 = 0x54780B64L;
            l_1931 = (*p_8);
            for (l_1919 = 0; (l_1919 < 27); l_1919++)
            { /* block id: 840 */
                if ((*p_8))
                { /* block id: 841 */
                    return (*p_8);
                }
                else
                { /* block id: 843 */
                    if (l_1934)
                        break;
                }
            }
        }
    }
    l_1937++;
    p_8 = (*g_1418);
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_806 g_724 g_847 g_362 g_80 g_1356 g_551 g_850 g_851 g_169 g_805 g_640 g_1394 g_83 g_323 g_3 g_1418 g_918 g_919 g_584 g_353 g_221 g_969 g_691 g_1436 g_1437 g_618 g_1438 g_1439 g_1440 g_1517 g_1091 g_485 g_486 g_487 g_615.f0 g_1138 g_1559 g_639 g_126 g_952 g_753 g_804 g_185 g_1560 g_1051 g_1354 g_1626 g_210 g_1114.f0 g_1749 g_626 g_1760 g_341 g_212 g_76 g_1792 g_517.f0 g_87
 * writes: g_724 g_76 g_1354 g_323 g_80 g_551 g_517.f0 g_1138 g_221 g_185 g_1443 g_639 g_847 g_618 g_126 g_1091 g_1050 g_169 g_844 g_83 g_1662 g_210 g_212 g_353
 */
static int64_t  func_9(int32_t * p_10, int32_t  p_11)
{ /* block id: 580 */
    int32_t l_1332 = 0x9D7E43E6L;
    const uint8_t l_1349[6][10][2] = {{{1UL,253UL},{1UL,1UL},{0x3BL,0x8AL},{1UL,0x5CL},{0x69L,0x96L},{0xB8L,255UL},{255UL,0UL},{253UL,0x9CL},{8UL,249UL},{1UL,0x69L}},{{1UL,0x51L},{0x12L,0UL},{0x26L,5UL},{4UL,1UL},{0xC2L,253UL},{0x5CL,4UL},{0UL,0x2CL},{0x3BL,0x97L},{0x12L,7UL},{1UL,7UL}},{{0x12L,0x97L},{0x3BL,0x2CL},{0UL,4UL},{0x5CL,253UL},{0xC2L,1UL},{4UL,5UL},{0x26L,0UL},{1UL,0xB8L},{253UL,0xF2L},{0x97L,0x96L}},{{0xC2L,1UL},{0x51L,255UL},{8UL,8UL},{0x8AL,0x26L},{0xF2L,0xCBL},{249UL,1UL},{0x2CL,249UL},{1UL,0x51L},{1UL,249UL},{0x2CL,1UL}},{{249UL,0xCBL},{0xF2L,0x26L},{0x8AL,8UL},{8UL,255UL},{0x51L,1UL},{0xC2L,0x96L},{0x97L,0xF2L},{253UL,0xB8L},{1UL,0UL},{0x26L,5UL}},{{4UL,1UL},{0xC2L,253UL},{0x5CL,4UL},{0UL,0x2CL},{0x3BL,0x97L},{0x12L,7UL},{1UL,7UL},{0x12L,0x97L},{0x3BL,0x2CL},{0UL,4UL}}};
    int32_t l_1350[7][3][5] = {{{(-4L),3L,0xC16E2848L,0x9B00DEE3L,(-1L)},{0L,0x9B00DEE3L,0x5AAF153EL,(-6L),1L},{0x657410E8L,0x9AFD8FF9L,0xC207BB8BL,(-7L),(-1L)}},{{0x61FB5B77L,0xAC68BFD8L,0xC16E2848L,0x5AAF153EL,0x5BD4BE5DL},{(-6L),(-10L),1L,0x5BD4BE5DL,0x9B00DEE3L},{(-6L),0L,0L,1L,1L}},{{0x61FB5B77L,3L,0x61FB5B77L,(-10L),0L},{0x657410E8L,(-4L),0x9B00DEE3L,0x9AFD8FF9L,0x61FB5B77L},{0L,(-1L),0xC89EE1E4L,1L,(-1L)}},{{(-4L),0xC056D4A9L,0x9B00DEE3L,0x61FB5B77L,0x11D5A3B6L},{3L,(-2L),0x61FB5B77L,0xAC68BFD8L,0xC16E2848L},{(-7L),(-1L),0L,(-7L),0xAC68BFD8L}},{{0x5E2810EDL,1L,1L,0xB678157CL,0xAC68BFD8L},{(-1L),0x5E2810EDL,0xC16E2848L,0L,0xC16E2848L},{0L,0L,0xC207BB8BL,(-6L),0x11D5A3B6L}},{{0x5C0CBFD4L,0x9AFD8FF9L,0x5AAF153EL,(-4L),(-1L)},{0x5BD4BE5DL,0x5AAF153EL,0xC16E2848L,0xAC68BFD8L,0x61FB5B77L},{(-6L),0x9AFD8FF9L,1L,0x5BD4BE5DL,0L}},{{0xB678157CL,0L,(-4L),(-4L),(-4L)},{(-4L),0x5155DC41L,0xC89EE1E4L,(-2L),0xC207BB8BL},{0x61FB5B77L,(-4L),0xAC68BFD8L,(-2L),(-4L)}}};
    int32_t l_1351 = 6L;
    int64_t *l_1352 = &g_76;
    int64_t *l_1353 = &g_1354[5][3];
    int32_t *l_1355 = &g_551[2];
    uint64_t *l_1384[8] = {&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1],&g_221[0][3][1]};
    uint64_t **l_1383 = &l_1384[3];
    uint64_t ***l_1382 = &l_1383;
    uint8_t * volatile *l_1428 = &g_851;
    uint16_t l_1480 = 5UL;
    int32_t **l_1483 = &g_1443;
    uint32_t l_1647 = 4294967295UL;
    uint64_t l_1691 = 1UL;
    int16_t *l_1727 = &g_847;
    uint8_t l_1733 = 0UL;
    uint32_t l_1821 = 0xAAF8474EL;
    uint32_t l_1886 = 4UL;
    uint64_t l_1887 = 18446744073709551606UL;
    int32_t ***l_1913 = (void*)0;
    int i, j, k;
    l_1351 ^= (((safe_lshift_func_int16_t_s_u((~p_11), 2)) , (safe_div_func_uint32_t_u_u(((*g_806)++), ((l_1350[3][2][3] = (+(0xCB9CL <= ((((safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((l_1332 && p_11) != (safe_sub_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s((!p_11), p_11)) ^ ((safe_unary_minus_func_uint64_t_u(((safe_sub_func_uint32_t_u_u(1UL, (safe_rshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(0UL, (((safe_lshift_func_uint8_t_u_s((((safe_sub_func_uint16_t_u_u((l_1332 <= l_1349[3][5][0]), (-6L))) ^ l_1349[3][5][0]) ^ g_847), l_1349[3][5][0])) <= 0x15F9BF8BL) && p_11))), 1)))) , 6UL))) != 0UL)), l_1332))), 0)), 0x77L)) != p_11) && l_1349[3][5][0]) != g_362)))) | g_80)))) & l_1332);
    if ((((*l_1353) = ((*l_1352) = ((0x90BA512B4E7E20F0LL == p_11) != l_1351))) < 18446744073709551615UL))
    { /* block id: 586 */
        uint16_t l_1365 = 65535UL;
        int32_t l_1395 = 0xC370A285L;
        int32_t l_1478 = 0x4C3C18EEL;
        int32_t l_1479 = 0x71BA5261L;
        int32_t **l_1485 = &g_1443;
        int64_t *l_1487 = &g_1354[5][3];
        int32_t *l_1521 = &l_1478;
        int16_t *l_1534 = &g_847;
        uint16_t l_1541[8][2] = {{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L},{0xA414L,0xA414L}};
        uint16_t **l_1562 = (void*)0;
        uint16_t **l_1563 = &g_1560[0];
        int8_t **l_1605 = &g_1051[2][2];
        uint8_t *l_1628 = &g_517.f0;
        uint8_t * const *l_1627 = &l_1628;
        union U0 *l_1660[7] = {&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626,&g_1626};
        int32_t *l_1661 = &g_83;
        const int32_t *l_1692 = &l_1350[3][0][4];
        const uint8_t *l_1700 = &g_341[2][5][0];
        const uint8_t **l_1699 = &l_1700;
        uint8_t l_1705 = 0xE6L;
        uint64_t l_1711 = 0UL;
        int i, j;
lbl_1652:
        (*g_1356) = p_10;
        for (g_80 = 0; (g_80 < 50); ++g_80)
        { /* block id: 590 */
            uint8_t l_1389 = 0UL;
            int32_t l_1399 = 1L;
            uint8_t l_1427 = 0xAFL;
            const int32_t ****l_1431 = (void*)0;
            int32_t l_1458 = 0xB25A4C8CL;
            uint32_t l_1459 = 0xA691F775L;
            const uint16_t *l_1463 = &g_90;
            const uint16_t **l_1462 = &l_1463;
            int64_t * const l_1488 = &g_1354[1][0];
            uint16_t l_1508 = 0xEBCBL;
            uint16_t l_1556 = 0x3EE8L;
            uint8_t l_1574 = 1UL;
            int8_t l_1586 = 0x01L;
            (*l_1355) |= (-1L);
            for (g_517.f0 = 21; (g_517.f0 == 55); g_517.f0++)
            { /* block id: 594 */
                uint64_t ***l_1385[8] = {(void*)0,(void*)0,&l_1383,(void*)0,(void*)0,&l_1383,(void*)0,(void*)0};
                uint64_t * const *l_1387[6] = {&l_1384[0],&l_1384[0],&l_1384[0],&l_1384[0],&l_1384[0],&l_1384[0]};
                uint64_t * const **l_1386 = &l_1387[3];
                uint64_t * const ***l_1388 = &l_1386;
                uint32_t l_1390 = 0xBF44DEDBL;
                int32_t *l_1406 = (void*)0;
                int32_t l_1447[6][8] = {{6L,0x04BA42F2L,0xF7C343FAL,0xF7C343FAL,0x04BA42F2L,6L,0x18DD3D1CL,0x04BA42F2L},{0xC1BFAD24L,0x18DD3D1CL,0xF7C343FAL,0xC1BFAD24L,0xF7C343FAL,0x18DD3D1CL,0xC1BFAD24L,6L},{0x04BA42F2L,8L,0x8FC77822L,0xC1BFAD24L,0xC1BFAD24L,0x8FC77822L,8L,0x04BA42F2L},{6L,0xC1BFAD24L,0x18DD3D1CL,0xF7C343FAL,0xC1BFAD24L,0xF7C343FAL,0x18DD3D1CL,0xC1BFAD24L},{0x04BA42F2L,0x18DD3D1CL,6L,0x04BA42F2L,0xF7C343FAL,0xF7C343FAL,0x04BA42F2L,6L},{0xC1BFAD24L,0xC1BFAD24L,0x8FC77822L,8L,0x04BA42F2L,0x8FC77822L,0x04BA42F2L,8L}};
                int32_t ***l_1484 = &l_1483;
                uint16_t *l_1486 = &g_126;
                int16_t **l_1518 = &g_1091;
                int32_t *l_1573[3];
                int i, j;
                for (i = 0; i < 3; i++)
                    l_1573[i] = (void*)0;
                if ((((safe_rshift_func_uint16_t_u_s(p_11, p_11)) | p_11) || ((((*l_1353) = l_1365) , (safe_rshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(((**g_850) ^ (((safe_lshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_s(0x2BL, 1)) ^ (((safe_mod_func_int16_t_s_s(((safe_mod_func_uint16_t_u_u((safe_div_func_int8_t_s_s((((((l_1385[1] = l_1382) == ((*l_1388) = l_1386)) , (**g_805)) , l_1365) , 0xEEL), (*l_1355))), p_11)) , l_1389), p_11)) > l_1365) == 0x46896C32L)), 2)) <= l_1390) == g_80)), (*l_1355))), 6))) == (*l_1355))))
                { /* block id: 598 */
                    int16_t l_1398 = 0xC182L;
                    int32_t *l_1407 = (void*)0;
                    int32_t *l_1417 = &g_551[2];
                    if ((*g_640))
                        break;
                    (*l_1355) = ((!((safe_rshift_func_int16_t_s_u((((l_1399 &= (((g_1394 , l_1389) , ((****l_1388) = (*l_1355))) | ((l_1395 = (*l_1355)) ^ (safe_mod_func_uint32_t_u_u(l_1398, (l_1350[2][2][0] |= 0x96D8ECB0L)))))) | ((safe_div_func_int32_t_s_s((0xB650L | g_83), (safe_mul_func_uint8_t_u_u((*l_1355), 254UL)))) , l_1389)) < 0x76ED6DF9F8EBAE4FLL), (*l_1355))) && l_1398)) , p_11);
                    for (g_724 = 0; (g_724 <= 19); g_724++)
                    { /* block id: 607 */
                        int32_t *l_1416 = &l_1395;
                        (*g_1418) = func_36(l_1407, l_1406, func_36((*g_1356), p_10, func_36(func_36(&l_1399, ((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((safe_lshift_func_uint8_t_u_u((l_1389 && (safe_add_func_uint16_t_u_u(p_11, (-1L)))), (*l_1355))) && l_1398), 0x4AEA0B7D5CDB0D3CLL)), (*l_1355))) , l_1416), l_1416, p_10), &l_1350[1][1][0], &l_1395, l_1417), &g_551[2]), p_10);
                    }
                }
                else
                { /* block id: 611 */
                    int8_t l_1456 = (-2L);
                    int32_t l_1457 = (-10L);
                    const uint16_t ***l_1464 = &l_1462;
                    int32_t *l_1465 = (void*)0;
                    int32_t *l_1466 = &l_1395;
                    int32_t *l_1467 = (void*)0;
                    int32_t *l_1468 = &l_1457;
                    int32_t *l_1469 = &g_83;
                    int32_t *l_1470 = &l_1458;
                    int32_t *l_1471 = &g_551[2];
                    int32_t *l_1472 = &l_1395;
                    int32_t *l_1473 = &l_1458;
                    int32_t *l_1474 = &l_1447[4][5];
                    int32_t *l_1475 = &g_551[2];
                    int32_t *l_1476 = &l_1457;
                    int32_t *l_1477[3][8] = {{(void*)0,&l_1458,(void*)0,(void*)0,&l_1458,&l_1350[4][0][0],&l_1350[4][0][0],&l_1458},{&l_1458,&l_1350[4][0][0],&l_1350[4][0][0],&l_1458,(void*)0,(void*)0,&l_1458,(void*)0},{&l_1458,&g_551[2],&l_1351,&g_551[2],&l_1458,&l_1351,(void*)0,(void*)0}};
                    int i, j;
                    if ((safe_mul_func_uint16_t_u_u(0xBF24L, ((safe_unary_minus_func_int64_t_s(0xB0974D451663C5EBLL)) , ((((((0UL > p_11) , ((p_11 && (((safe_unary_minus_func_uint32_t_u((safe_lshift_func_int16_t_s_s((&g_691[2][3][2] == &l_1332), (((**g_850) || ((safe_sub_func_uint64_t_u_u(((**g_918) & p_11), g_969)) >= l_1427)) , (-9L)))))) | g_691[4][2][7]) && l_1365)) , (-2L))) || (*g_851)) ^ 2UL) == g_584) , p_11)))))
                    { /* block id: 612 */
                        uint64_t ***l_1441 = (void*)0;
                        int32_t **l_1442 = (void*)0;
                        int16_t *l_1446 = &g_639;
                        l_1428 = &g_851;
                        l_1350[3][2][3] = ((*l_1355) = (safe_sub_func_int32_t_s_s(((l_1431 == l_1431) , (safe_mod_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(((*l_1446) = (((g_1436 , (**g_918)) < (((g_1437 == l_1441) && (&p_11 == (g_1443 = &g_691[3][3][7]))) != (safe_sub_func_int8_t_s_s(((*l_1355) | l_1395), l_1365)))) != p_11)), p_11)), 251UL))), 0x4B4BFED1L)));
                    }
                    else
                    { /* block id: 618 */
                        return g_969;
                    }
                    for (g_847 = 0; (g_847 <= 5); g_847 += 1)
                    { /* block id: 623 */
                        int32_t l_1448[6];
                        int32_t *l_1449 = &l_1350[3][2][3];
                        int32_t *l_1450 = &g_83;
                        int32_t *l_1451 = &l_1350[3][2][3];
                        int32_t *l_1452 = &l_1350[1][2][1];
                        int32_t *l_1453 = &l_1350[3][2][3];
                        int32_t *l_1454 = &g_551[4];
                        int32_t *l_1455[4];
                        int i, j;
                        for (i = 0; i < 6; i++)
                            l_1448[i] = 0x1673686CL;
                        for (i = 0; i < 4; i++)
                            l_1455[i] = &l_1395;
                        g_618[g_847][(g_847 + 2)] = g_618[g_847][(g_847 + 4)];
                        l_1459++;
                    }
                    (*l_1464) = l_1462;
                    l_1480++;
                }
                if (((((*l_1486) = (((*l_1484) = l_1483) != l_1485)) , l_1487) != l_1488))
                { /* block id: 632 */
                    uint32_t l_1497 = 0x60CF6AA9L;
                    int32_t l_1519 = (-7L);
                    int16_t *l_1533 = (void*)0;
                    union U0 *l_1543 = &g_517;
                    union U0 **l_1542 = &l_1543;
                    int32_t *l_1544 = &g_83;
                    int32_t *l_1545 = &l_1519;
                    int32_t *l_1546 = (void*)0;
                    int32_t *l_1547 = &l_1395;
                    int32_t *l_1548 = &l_1395;
                    int32_t *l_1549 = &l_1399;
                    int32_t *l_1550 = &l_1478;
                    int32_t *l_1551 = &l_1351;
                    int32_t *l_1552 = &l_1519;
                    int32_t *l_1553 = &l_1351;
                    int32_t *l_1554[2][9][9] = {{{(void*)0,&l_1478,&g_83,&l_1447[4][5],&l_1447[4][5],(void*)0,&g_551[2],&g_551[2],(void*)0},{(void*)0,&l_1479,&l_1395,&l_1479,(void*)0,&l_1399,&l_1399,&l_1447[4][5],&g_551[5]},{&l_1447[1][5],&l_1519,&l_1519,&l_1351,(void*)0,&l_1351,(void*)0,&g_83,(void*)0},{&l_1350[1][2][4],&g_551[3],&g_551[2],&l_1479,(void*)0,&l_1399,&l_1519,(void*)0,&l_1479},{&g_3,&g_551[2],(void*)0,&l_1395,(void*)0,(void*)0,&l_1447[4][5],&l_1519,(void*)0},{&g_551[3],&l_1395,&l_1447[4][5],&l_1519,&l_1395,&l_1458,&l_1478,(void*)0,&l_1479},{&l_1351,&g_3,&g_3,(void*)0,&g_551[2],&l_1399,&l_1395,(void*)0,&l_1519},{&l_1350[1][2][3],&l_1478,(void*)0,&l_1458,&l_1479,&l_1399,(void*)0,&g_83,(void*)0},{&l_1395,&g_551[2],&l_1479,&l_1478,&g_551[3],&l_1350[1][2][4],&g_551[0],(void*)0,&g_551[0]}},{{&g_83,&l_1395,&l_1350[1][2][3],&l_1350[1][2][3],&l_1395,&g_83,(void*)0,&l_1478,&g_551[3]},{&l_1399,(void*)0,&l_1458,&g_551[3],&l_1519,&l_1350[3][2][3],&l_1458,&l_1351,(void*)0},{(void*)0,&l_1519,&l_1519,&l_1351,&l_1478,(void*)0,(void*)0,&g_3,&l_1350[3][2][3]},{&l_1395,&l_1351,(void*)0,&l_1458,&l_1458,&l_1519,&g_551[0],&g_551[2],(void*)0},{&l_1479,&l_1350[1][2][3],&g_83,&l_1479,&l_1350[3][2][3],&l_1395,(void*)0,&l_1395,(void*)0},{&l_1395,&l_1399,(void*)0,&l_1447[4][5],&l_1351,&l_1399,&l_1395,&l_1519,&g_83},{&l_1479,(void*)0,(void*)0,&l_1395,&g_551[5],&l_1479,&l_1350[3][2][3],&g_551[0],&l_1395},{(void*)0,&l_1351,&g_83,&g_551[0],&l_1478,&l_1350[3][2][3],&g_83,&l_1458,&l_1458},{&l_1519,&l_1519,(void*)0,&l_1399,(void*)0,&l_1519,&l_1519,&l_1447[4][5],&l_1519}}};
                    int16_t l_1555 = 0x50D1L;
                    int i, j, k;
                    for (l_1399 = 0; (l_1399 == (-1)); l_1399 = safe_sub_func_int16_t_s_s(l_1399, 6))
                    { /* block id: 635 */
                        uint32_t l_1507 = 0x4115976FL;
                        (*l_1355) &= (((safe_mul_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_u(((safe_rshift_func_int16_t_s_u((l_1458 = p_11), 8)) <= l_1497), (safe_add_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s((safe_unary_minus_func_uint16_t_u(g_691[4][2][7])), 6)) & (safe_lshift_func_int16_t_s_s((((safe_rshift_func_int16_t_s_u((l_1507 < (((***g_1437) , 255UL) <= 0x68L)), 12)) <= (*g_806)) < (1UL && p_11)), p_11))), l_1508)))) == p_11) <= l_1365), 0x43L)) , p_11) ^ 0x89170F8D6AAF2F18LL);
                        l_1519 = ((0xE03BL & 0x19C2L) ^ (safe_mod_func_int64_t_s_s((((safe_add_func_int8_t_s_s((safe_sub_func_int64_t_s_s(0xEF2086EB66FFA472LL, (&p_11 == (void*)0))), (((*l_1486) = (safe_lshift_func_uint16_t_u_u(p_11, 0))) || (((*l_1355) , (((g_1517 > l_1390) , l_1518) != (void*)0)) , 1L)))) & p_11) > (*g_806)), 0x47D1C4DFFFD116B4LL)));
                        (*l_1355) = (l_1351 |= ((l_1507 & (~(*l_1355))) > (((*l_1352) = ((void*)0 != (*l_1518))) > (0xFCL < l_1459))));
                        l_1521 = &l_1478;
                    }
                    (*l_1542) = ((~(safe_mul_func_int8_t_s_s((**g_485), (((safe_div_func_int8_t_s_s(((safe_unary_minus_func_int64_t_s(p_11)) != ((safe_mod_func_int64_t_s_s((safe_lshift_func_int16_t_s_s((~(((*l_1518) = (l_1533 = (void*)0)) == l_1534)), 0)), (((safe_div_func_int8_t_s_s(l_1519, ((9UL ^ (((((safe_mul_func_uint16_t_u_u(((safe_add_func_int8_t_s_s((*l_1355), 0x28L)) | (l_1541[4][1] = (((0L || 0x0CL) && 0xA9BFL) , p_11))), (*l_1521))) , (-1L)) , p_11) != 7UL) ^ (*l_1521))) ^ g_584))) == p_11) , (-1L)))) , g_615.f0)), (*l_1355))) | p_11) && p_11)))) , (void*)0);
                    l_1556++;
                }
                else
                { /* block id: 650 */
                    uint16_t ***l_1561[9][3][5] = {{{&g_1559,&g_1559,&g_1559,(void*)0,&g_1559},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{(void*)0,&g_1559,(void*)0,&g_1559,&g_1559}},{{(void*)0,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,&g_1559,(void*)0,(void*)0,&g_1559},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559}},{{&g_1559,&g_1559,(void*)0,&g_1559,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,(void*)0,&g_1559,&g_1559,&g_1559}},{{&g_1559,&g_1559,(void*)0,&g_1559,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{(void*)0,&g_1559,&g_1559,&g_1559,&g_1559}},{{(void*)0,&g_1559,(void*)0,&g_1559,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,&g_1559,&g_1559,(void*)0,(void*)0}},{{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,(void*)0,&g_1559,&g_1559,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559}},{{&g_1559,&g_1559,&g_1559,(void*)0,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,(void*)0},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559}},{{&g_1559,&g_1559,(void*)0,&g_1559,&g_1559},{&g_1559,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,&g_1559,&g_1559,&g_1559,(void*)0}},{{(void*)0,&g_1559,&g_1559,&g_1559,&g_1559},{&g_1559,&g_1559,(void*)0,&g_1559,&g_1559},{&g_1559,&g_1559,(void*)0,(void*)0,&g_1559}}};
                    int i, j, k;
                    (*l_1521) ^= p_11;
                    (*l_1355) = ((((l_1562 = ((l_1458 = ((***l_1382) &= (**g_1438))) , g_1559)) != l_1563) ^ ((-1L) < (safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((*l_1355), (*g_806))), g_639)), (safe_sub_func_int64_t_s_s((g_1354[5][3] = p_11), 0x0B465164EE6F672ALL)))))) >= g_126);
                    return g_952;
                }
                (*l_1355) |= (p_11 & (~(*g_753)));
                --l_1574;
            }
            for (l_1478 = 0; (l_1478 != (-3)); l_1478--)
            { /* block id: 664 */
                int32_t *l_1581 = &l_1395;
                int32_t *l_1585 = (void*)0;
                int8_t **l_1603 = &g_1051[2][2];
                int32_t l_1648 = (-1L);
                for (l_1427 = 0; (l_1427 <= 7); l_1427 += 1)
                { /* block id: 667 */
                    uint16_t l_1595 = 0x6554L;
                    int8_t **l_1606 = &g_1051[2][2];
                    for (g_517.f0 = 0; (g_517.f0 <= 7); g_517.f0 += 1)
                    { /* block id: 670 */
                        int32_t **l_1582 = &g_323;
                        int i, j;
                        (*l_1581) = ((***g_804) , ((((((safe_sub_func_uint64_t_u_u(8UL, 1L)) == (((*l_1582) = (*g_1418)) == p_10)) , p_11) , (*l_1355)) , 65535UL) <= p_11));
                    }
                    (*l_1355) &= 0x01AEE609L;
                    if (l_1586)
                        break;
                    if (((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u(p_11, 0)) == (safe_mod_func_int32_t_s_s(((void*)0 == (*l_1563)), ((***g_804)++)))), 1)) , l_1595))
                    { /* block id: 679 */
                        int8_t ***l_1604[2];
                        int32_t l_1607 = 0L;
                        int32_t *l_1609[5][4][10] = {{{&g_83,&l_1479,&l_1607,&l_1478,&g_83,&l_1350[6][0][0],&l_1350[3][2][3],&l_1350[3][2][3],&l_1479,(void*)0},{&l_1351,&g_3,&l_1478,(void*)0,&l_1350[6][0][0],&l_1399,&g_83,(void*)0,&g_83,&l_1350[3][2][3]},{&l_1479,(void*)0,&g_3,&l_1350[3][2][3],&g_83,(void*)0,&l_1478,&g_83,(void*)0,(void*)0},{&l_1479,(void*)0,&l_1399,&l_1399,&l_1399,&l_1399,(void*)0,&l_1479,&l_1350[6][0][0],&g_83}},{{&l_1351,(void*)0,&l_1478,&g_3,&l_1478,&l_1350[6][0][0],&l_1478,(void*)0,&l_1351,&l_1399},{&g_83,&l_1478,&l_1478,&l_1478,(void*)0,(void*)0,&g_83,&l_1479,(void*)0,&g_3},{(void*)0,&l_1350[6][0][0],&l_1399,&g_83,(void*)0,&g_83,&l_1350[3][2][3],&g_83,&l_1351,&l_1350[6][0][0]},{&l_1399,&l_1478,&g_3,&l_1350[6][0][0],(void*)0,&l_1350[3][2][3],&l_1350[3][2][3],(void*)0,&l_1350[6][0][0],&g_3}},{{(void*)0,(void*)0,&l_1478,&l_1607,(void*)0,&l_1479,&l_1399,&l_1350[3][2][3],(void*)0,&l_1399},{&l_1399,&l_1458,&l_1607,&l_1479,&l_1478,&g_3,&l_1399,&l_1351,&g_83,&g_83},{(void*)0,(void*)0,&l_1350[3][2][3],&l_1478,&l_1399,(void*)0,&l_1350[3][2][3],&l_1399,&l_1479,(void*)0},{&g_83,&l_1478,&l_1607,&l_1479,&g_83,&g_3,&l_1350[3][2][3],&l_1479,&l_1479,&l_1350[3][2][3]}},{{&l_1351,&l_1350[6][0][0],&l_1478,&l_1478,&l_1350[6][0][0],&l_1351,&g_83,&l_1350[3][2][3],&g_83,(void*)0},{&l_1479,&l_1478,&g_3,&l_1479,&g_83,&l_1478,&l_1478,&l_1478,(void*)0,(void*)0},{&l_1479,(void*)0,&l_1399,&l_1607,&l_1399,&l_1351,(void*)0,&l_1458,(void*)0,(void*)0},{&l_1399,&g_3,&l_1458,(void*)0,(void*)0,&l_1478,&l_1458,&g_83,&l_1399,&g_3}},{{&l_1351,(void*)0,&l_1458,(void*)0,&g_83,&g_83,(void*)0,&l_1458,(void*)0,&l_1351},{(void*)0,&l_1478,&l_1607,(void*)0,&l_1479,&l_1399,&l_1350[3][2][3],(void*)0,&l_1399,&l_1478},{&l_1350[6][0][0],&l_1351,&l_1399,&l_1478,&l_1479,&l_1479,&l_1478,&l_1350[3][2][3],(void*)0,&l_1351},{&l_1479,&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[6][0][0],&g_83,&l_1478,&l_1607,&l_1479,&g_83,&g_3}}};
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_1604[i] = &l_1603;
                        l_1479 ^= ((*l_1355) = (safe_rshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_u((~(safe_lshift_func_uint16_t_u_s(1UL, 4))), ((g_1050 = l_1603) != (l_1606 = l_1605)))) >= (*l_1521)), (((((0L & ((*l_1581) |= l_1607)) , (**g_805)) >= (~(g_1051[l_1427][l_1427] != (*g_485)))) == l_1607) != g_551[2]))));
                        l_1399 = (safe_mod_func_uint8_t_u_u((&g_486 != (((*l_1534) |= (((safe_add_func_uint16_t_u_u(1UL, 0x2A66L)) <= ((*l_1488) ^= p_11)) != ((**g_850) = (((0xE7D9L || (((safe_sub_func_uint8_t_u_u((p_11 >= (safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(0x17L, (safe_rshift_func_uint16_t_u_u(((*l_1355) = p_11), p_11)))), (**g_918)))), p_11)) != 0xEDB4FD9B028BCDAELL) , p_11)) || (*l_1355)) , (**g_850))))) , (void*)0)), 248UL));
                        if (p_11)
                            break;
                    }
                    else
                    { /* block id: 691 */
                        int8_t l_1629 = 0xA0L;
                        uint8_t **l_1630[4][4][4] = {{{&l_1628,(void*)0,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{(void*)0,(void*)0,&l_1628,&l_1628}},{{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628}},{{&l_1628,(void*)0,(void*)0,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,(void*)0,&l_1628,&l_1628}},{{&l_1628,&l_1628,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628},{(void*)0,(void*)0,&l_1628,&l_1628},{&l_1628,&l_1628,&l_1628,&l_1628}}};
                        uint32_t ***l_1643 = &g_844;
                        int8_t *l_1644 = (void*)0;
                        int8_t *l_1645 = &l_1586;
                        int8_t l_1646 = (-10L);
                        int32_t *l_1649 = (void*)0;
                        int32_t *l_1650 = (void*)0;
                        int32_t *l_1651[7];
                        int i, j, k;
                        for (i = 0; i < 7; i++)
                            l_1651[i] = &l_1351;
                        g_83 |= (safe_mul_func_int16_t_s_s(((safe_add_func_uint16_t_u_u((*l_1521), ((((((g_1626 , l_1627) != (((*l_1355) = l_1629) , l_1630[1][3][3])) , ((safe_mod_func_int32_t_s_s((l_1648 &= ((*g_640) = (l_1399 = ((*l_1581) = (safe_add_func_int32_t_s_s((safe_add_func_uint8_t_u_u((safe_mod_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(((((*l_1645) = (safe_mul_func_int8_t_s_s((((l_1562 != (void*)0) , (*g_804)) == ((*l_1643) = &g_845)), 0xB8L))) ^ (**g_850)) <= p_11), 2)) , l_1646), p_11)), l_1647)), 7L)))))), 7L)) , 0x7B7AL)) <= 0x1BC9L) < l_1629) ^ 0x33D5AAB5A2DBBCA3LL))) < p_11), 1UL));
                        if (l_1586)
                            goto lbl_1652;
                        (*l_1581) &= (*l_1355);
                    }
                }
                for (g_126 = 3; (g_126 >= 7); g_126++)
                { /* block id: 706 */
                    int32_t l_1663 = 0xEEABCFACL;
                    p_10 = (*g_1356);
                    for (g_83 = 9; (g_83 < 1); g_83--)
                    { /* block id: 710 */
                        g_1662 = (((safe_rshift_func_int8_t_s_u(p_11, 6)) >= (&g_396 != (p_11 , l_1660[5]))) , ((*l_1521) , l_1661));
                        l_1521 = &l_1350[3][1][4];
                    }
                    if (l_1663)
                        continue;
                    for (l_1663 = (-23); (l_1663 < 8); l_1663 = safe_add_func_uint8_t_u_u(l_1663, 6))
                    { /* block id: 717 */
                        int32_t l_1666 = 0x0B43E3A7L;
                        int32_t *l_1667 = &l_1350[4][2][4];
                        int32_t *l_1668 = &l_1399;
                        int32_t *l_1669[9][9][3] = {{{&l_1395,(void*)0,&l_1458},{&l_1395,&g_551[1],(void*)0},{&l_1479,&l_1395,&l_1458},{&g_83,&l_1663,&l_1479},{&l_1478,&l_1479,&l_1395},{&l_1395,&l_1478,(void*)0},{(void*)0,&l_1478,(void*)0},{&l_1351,&l_1479,&l_1458},{&l_1648,&l_1663,&l_1479}},{{&l_1350[3][2][3],&l_1395,&l_1395},{&l_1395,&g_551[1],&l_1395},{&l_1350[3][2][3],(void*)0,(void*)0},{&l_1648,&l_1395,&g_83},{&l_1351,&l_1663,&l_1350[1][0][0]},{(void*)0,&l_1350[1][0][0],&l_1350[1][0][0]},{&l_1395,&l_1350[3][0][2],&g_83},{&l_1478,&l_1350[4][0][4],(void*)0},{&g_83,&l_1479,&l_1395}},{{&l_1479,&l_1663,&l_1395},{&l_1395,&l_1479,&l_1479},{&l_1395,&l_1350[4][0][4],&l_1458},{&g_551[2],&l_1350[3][0][2],(void*)0},{&l_1663,&l_1350[1][0][0],(void*)0},{&l_1663,&l_1663,&l_1395},{&g_551[2],&l_1395,&l_1350[3][2][3]},{&l_1395,&g_83,&l_1350[4][0][4]},{&g_83,&l_1479,&l_1395}},{{&l_1479,&l_1395,&l_1350[4][0][4]},{&l_1395,&l_1395,&l_1350[3][2][3]},{&l_1458,&g_551[2],&l_1395},{&l_1395,&l_1663,&l_1478},{&l_1395,&l_1663,&l_1395},{&l_1479,&g_551[2],&g_551[1]},{&l_1350[1][0][0],&l_1395,&g_551[2]},{(void*)0,&l_1395,&l_1478},{&l_1395,&l_1479,&l_1350[3][0][2]}},{{(void*)0,&g_83,&l_1395},{&l_1350[1][0][0],&l_1478,(void*)0},{&l_1479,&l_1395,(void*)0},{&l_1395,(void*)0,(void*)0},{&l_1395,&l_1351,(void*)0},{&l_1458,&l_1648,&l_1395},{&l_1395,&l_1350[3][2][3],&l_1350[3][0][2]},{&l_1479,&l_1395,&l_1478},{&g_83,&l_1350[3][2][3],&g_551[2]}},{{&l_1395,&l_1648,&g_551[1]},{&l_1458,&l_1351,&l_1395},{&l_1395,(void*)0,&l_1478},{&l_1395,&l_1395,&l_1395},{&l_1458,&l_1478,&l_1350[3][2][3]},{&l_1395,&g_83,&l_1350[4][0][4]},{&g_83,&l_1479,&l_1395},{&l_1479,&l_1395,&l_1350[4][0][4]},{&l_1395,&l_1395,&l_1350[3][2][3]}},{{&l_1458,&g_551[2],&l_1395},{&l_1395,&l_1663,&l_1478},{&l_1395,&l_1663,&l_1395},{&l_1479,&g_551[2],&g_551[1]},{&l_1350[1][0][0],&l_1395,&g_551[2]},{(void*)0,&l_1395,&l_1478},{&l_1395,&l_1479,&l_1350[3][0][2]},{(void*)0,&g_83,&l_1395},{&l_1350[1][0][0],&l_1478,(void*)0}},{{&l_1479,&l_1395,(void*)0},{&l_1395,(void*)0,(void*)0},{&l_1395,&l_1351,(void*)0},{&l_1458,&l_1648,&l_1395},{&l_1395,&l_1350[3][2][3],&l_1350[3][0][2]},{&l_1479,&l_1395,&l_1478},{&g_83,&l_1350[3][2][3],&g_551[2]},{&l_1395,&l_1648,&g_551[1]},{&l_1458,&l_1351,&l_1395}},{{&l_1395,(void*)0,&l_1478},{&l_1395,&l_1395,&l_1395},{&l_1458,&l_1478,&l_1350[3][2][3]},{&l_1395,&g_83,&l_1350[4][0][4]},{&g_83,&l_1479,&l_1395},{&l_1479,&l_1395,&l_1350[4][0][4]},{&l_1395,&l_1395,&l_1350[3][2][3]},{&l_1458,&g_551[2],&l_1395},{&l_1395,&l_1663,&l_1478}}};
                        uint32_t l_1670 = 0x81CB734FL;
                        int i, j, k;
                        if (l_1663)
                            goto lbl_1652;
                        if (l_1666)
                            break;
                        ++l_1670;
                    }
                }
            }
        }
        for (g_210 = 0; (g_210 == 18); g_210++)
        { /* block id: 727 */
            uint32_t l_1689 = 0xB9D5AFD2L;
            int32_t l_1690 = (-6L);
            int32_t *l_1693[7] = {&l_1350[6][1][1],(void*)0,&l_1350[6][1][1],&l_1350[6][1][1],(void*)0,&l_1350[6][1][1],&l_1350[6][1][1]};
            uint8_t **l_1696[2][2] = {{&l_1628,&l_1628},{&l_1628,&l_1628}};
            const uint8_t ***l_1701 = &l_1699;
            int8_t *l_1706 = &g_212;
            int8_t *l_1707 = (void*)0;
            int8_t *l_1708 = &g_1709;
            int32_t l_1710 = (-1L);
            int32_t **l_1712[5] = {&g_1662,&g_1662,&g_1662,&g_1662,&g_1662};
            int i, j;
            l_1355 = &l_1350[3][2][3];
            l_1693[6] = p_10;
            p_10 = p_10;
        }
    }
    else
    { /* block id: 737 */
        int64_t *l_1715 = (void*)0;
        int16_t *l_1725 = &g_847;
        int32_t l_1728[3][6];
        int32_t l_1730 = 0xB8B46222L;
        int16_t ***l_1761 = &g_1283[1];
        uint64_t **l_1806 = &l_1384[4];
        int8_t ***l_1810[4][5][3] = {{{&g_1050,&g_1050,(void*)0},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050}},{{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050}},{{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050}},{{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050},{&g_1050,&g_1050,&g_1050}}};
        int32_t ***l_1894 = &g_184;
        const int32_t *l_1896[8] = {&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3],&l_1350[3][2][3]};
        int32_t *l_1897[9] = {(void*)0,&l_1350[3][2][3],(void*)0,(void*)0,&l_1350[3][2][3],(void*)0,(void*)0,&l_1350[3][2][3],(void*)0};
        uint32_t l_1898 = 4294967295UL;
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 6; j++)
                l_1728[i][j] = (-6L);
        }
        if ((*l_1355))
        { /* block id: 738 */
            int16_t **l_1726 = &g_1091;
            uint16_t l_1729[10] = {6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL,6UL};
            int i;
            (*l_1355) = (*g_640);
            (*l_1355) = (safe_add_func_int64_t_s_s((l_1715 != l_1352), (safe_sub_func_int8_t_s_s((safe_div_func_uint16_t_u_u((((!(safe_lshift_func_uint16_t_u_s((l_1728[0][4] = (g_1114.f0 < (safe_div_func_uint64_t_u_u(0UL, ((((*l_1726) = l_1725) != l_1727) , g_724))))), ((*l_1727) = (((l_1730 = (l_1729[4] |= (-6L))) && ((((safe_div_func_uint64_t_u_u(p_11, 0x3971359481925F34LL)) , l_1730) , 0x38E0L) || l_1733)) & p_11))))) , 3UL) || 0x8C755664L), 0x61C2L)), 2L))));
            return p_11;
        }
        else
        { /* block id: 747 */
            uint32_t l_1773 = 0x34D568D6L;
            int32_t l_1774 = (-1L);
            int32_t l_1795 = 0x9909C6FAL;
            int32_t l_1832 = 0x8EDFBC36L;
            int32_t l_1835 = 0xDBCD79CBL;
            int32_t l_1837 = (-5L);
            int32_t l_1840 = 6L;
            int32_t l_1841[7] = {0x23F2D40BL,0x23F2D40BL,0x23F2D40BL,0x23F2D40BL,0x23F2D40BL,0x23F2D40BL,0x23F2D40BL};
            uint32_t l_1876 = 18446744073709551615UL;
            int64_t * const l_1893 = (void*)0;
            int i;
            for (g_724 = 0; (g_724 != 28); g_724++)
            { /* block id: 750 */
                uint32_t l_1770[1];
                int32_t l_1771 = 0x736D3C82L;
                int8_t *l_1772 = &g_212;
                int32_t l_1775 = 2L;
                uint8_t l_1794 = 0x52L;
                int i;
                for (i = 0; i < 1; i++)
                    l_1770[i] = 9UL;
                (*l_1355) = p_11;
                l_1775 ^= (((safe_lshift_func_int16_t_s_u((safe_add_func_int8_t_s_s((safe_add_func_int64_t_s_s((((safe_add_func_int32_t_s_s(((safe_unary_minus_func_int32_t_s(((p_11 || (((+(((l_1773 ^= ((~(safe_sub_func_int16_t_s_s(((g_1749 , ((((g_626 ^ (safe_lshift_func_int16_t_s_s(l_1730, (((*l_1772) ^= (safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((((safe_mod_func_int16_t_s_s((safe_add_func_int16_t_s_s(((g_1760 , ((l_1761 = (void*)0) != ((safe_mod_func_int32_t_s_s(((safe_lshift_func_int8_t_s_s((p_11 | ((safe_mod_func_int32_t_s_s(((-1L) >= (((safe_div_func_int32_t_s_s(((*l_1355) = (l_1770[0] = (p_10 != (*g_1418)))), p_11)) ^ g_341[2][6][1]) >= l_1771)), l_1771)) <= p_11)), l_1730)) & g_584), 0x49AF83BEL)) , &g_1283[1]))) == g_639), l_1771)), p_11)) & 0x213DL) >= (*g_806)), l_1730)), p_11))) >= g_221[0][3][1])))) & 4L) & 0UL) != 0xE8L)) && p_11), p_11))) , (*g_806))) <= p_11) >= 4294967288UL)) == (***g_804)) | p_11)) , 0xD7FDDDE1L))) < p_11), 2UL)) == l_1771) && (*g_851)), p_11)), l_1774)), 13)) , (void*)0) == (void*)0);
                for (g_76 = 0; (g_76 < (-17)); g_76--)
                { /* block id: 760 */
                    int64_t l_1796 = 0x33BE332D8260768BLL;
                    (*l_1355) = ((safe_sub_func_uint16_t_u_u(65535UL, (safe_lshift_func_int16_t_s_u(3L, 14)))) , ((safe_unary_minus_func_uint8_t_u(((**l_1428) ^= (+0x32L)))) ^ (*l_1355)));
                    for (g_353 = 1; (g_353 <= 6); g_353 += 1)
                    { /* block id: 765 */
                        uint16_t *** const l_1790 = &g_1559;
                        int32_t l_1793 = (-1L);
                        uint16_t l_1797 = 0xE2E0L;
                        l_1771 = (((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((65535UL | p_11), p_11)) == (((safe_mod_func_uint64_t_u_u((l_1796 = (((l_1790 == &g_1559) ^ (l_1728[0][1] = ((!(l_1728[2][4] | (((((**l_1383) = (g_1792 , ((p_11 >= (((*l_1355) ^= ((l_1793 |= (**g_485)) && p_11)) == l_1794)) , 18446744073709551607UL))) >= g_210) < l_1795) || 1UL))) != p_11))) == p_11)), 18446744073709551611UL)) | p_11) && l_1797)), p_11)) == l_1795) >= l_1773);
                    }
                }
            }
            for (g_517.f0 = 7; (g_517.f0 >= 48); g_517.f0 = safe_add_func_int64_t_s_s(g_517.f0, 4))
            { /* block id: 777 */
                const int16_t l_1825 = 0xA64EL;
                int32_t l_1838 = 0x6B8C6F9AL;
                int32_t l_1849 = 0x23E6DC6BL;
                int32_t l_1850 = 0x84D598A9L;
                int32_t l_1851 = 0x11F81860L;
                int32_t l_1852 = 0x0AEA3640L;
                int32_t l_1853 = 0L;
                int32_t l_1854 = 0xBE8365D4L;
                int32_t **l_1881 = &l_1355;
            }
        }
        ++l_1898;
        l_1351 |= ((safe_sub_func_uint32_t_u_u(((*l_1355) || ((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(((safe_add_func_int32_t_s_s(((*l_1355) = ((safe_mul_func_int16_t_s_s((((*l_1727) ^= (((((*l_1355) ^ (((((*l_1355) , l_1761) == l_1761) >= (safe_sub_func_int32_t_s_s((&g_1879 != ((*l_1355) , (l_1913 = l_1913))), (g_87 == 18446744073709551615UL)))) < (*l_1355))) < (*l_1355)) || 0x98L) == p_11)) | p_11), 1L)) == (*l_1355))), p_11)) > p_11), 8)), 0)) != 0xBE4D68A2L)), 4294967288UL)) && p_11);
    }
    return g_341[2][6][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_353 g_850 g_851 g_169 g_553 g_3 g_969 g_551 g_87 g_80 g_673 g_90 g_126 g_76 g_626 g_184 g_185 g_83 g_918 g_919 g_584 g_221 g_844 g_1050 g_806 g_724 g_316 g_753 g_805 g_804 g_1114 g_696 g_847 g_362 g_396.f0 g_1138 g_367 g_615.f0 g_212 g_640 g_229 g_639 g_210 g_485 g_486 g_487 g_323
 * writes: g_847 g_553 g_969 g_551 g_169 g_584 g_80 g_76 g_185 g_83 g_845 g_1050 g_221 g_724 g_1091 g_184 g_353 g_87 g_90 g_126 g_323 g_615.f0 g_212 g_626
 */
static int32_t * func_12(int32_t * p_13, uint16_t  p_14, int8_t  p_15, int32_t * p_16, const int32_t * p_17)
{ /* block id: 402 */
    int32_t **l_976 = &g_185;
    int16_t *l_977 = &g_847;
    uint64_t *l_979[2];
    uint64_t * const *l_978 = &l_979[0];
    uint64_t **l_980 = &l_979[0];
    uint64_t ***l_981 = &l_980;
    int32_t l_983 = 0xD5AF97C7L;
    int32_t l_984 = 0L;
    int32_t l_985 = 0xA73A7306L;
    int32_t l_986 = (-10L);
    int32_t l_987 = 0x44646694L;
    int32_t l_988 = 0L;
    int32_t l_989 = (-7L);
    int32_t l_990 = 2L;
    int32_t l_991 = 0x1630CF39L;
    int32_t l_992 = 0L;
    uint16_t l_1022 = 65535UL;
    uint32_t *l_1042 = (void*)0;
    int64_t l_1063 = 0x8A17F0FA4A1C75D2LL;
    int32_t l_1064 = 0xF38299E4L;
    uint32_t **l_1097 = &g_845;
    int32_t ** const *l_1123 = &g_184;
    int32_t ** const **l_1122 = &l_1123;
    const uint16_t l_1136 = 0UL;
    uint8_t l_1142[8][3] = {{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL},{0x2CL,0xECL,0xECL}};
    uint32_t l_1149 = 5UL;
    uint8_t *l_1289 = &g_615.f0;
    uint8_t **l_1288 = &l_1289;
    uint8_t ***l_1287 = &l_1288;
    int8_t * const *l_1310 = &g_1051[2][4];
    int8_t * const **l_1309 = &l_1310;
    int i, j;
    for (i = 0; i < 2; i++)
        l_979[i] = &g_353;
    if ((safe_div_func_int8_t_s_s((((*l_977) = (((((l_976 == l_976) , p_15) , (65535UL && g_353)) || (**g_850)) ^ g_553)) < ((l_978 != ((*l_981) = l_980)) >= p_15)), p_14)))
    { /* block id: 405 */
        int32_t *l_982[1][3];
        uint64_t l_993 = 1UL;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_982[i][j] = &g_551[1];
        }
        --l_993;
        for (g_553 = 10; (g_553 == 21); g_553 = safe_add_func_uint8_t_u_u(g_553, 1))
        { /* block id: 409 */
            if ((*p_16))
                break;
        }
        return l_982[0][2];
    }
    else
    { /* block id: 413 */
        const int32_t *l_1002 = &g_3;
        int32_t l_1018 = 0x3666636DL;
        int8_t l_1020[8][3][2] = {{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}},{{0xECL,0xDBL},{0xECL,0xECL},{0xDBL,0xECL}}};
        int32_t l_1021 = 0xAFE08E82L;
        int32_t l_1047[4];
        uint16_t *l_1058 = &l_1022;
        uint16_t **l_1057[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int64_t *l_1070[10][3] = {{&l_1063,&g_76,&l_1063},{&l_1063,&l_1063,&l_1063},{&l_1063,&g_76,&l_1063},{&l_1063,&l_1063,&l_1063},{&l_1063,&g_76,&l_1063},{&l_1063,&l_1063,&l_1063},{&l_1063,&g_76,&l_1063},{&l_1063,&l_1063,&l_1063},{&l_1063,&g_76,&l_1063},{&l_1063,&l_1063,&l_1063}};
        uint32_t **l_1186 = &g_845;
        int32_t *** const l_1203[9][3][8] = {{{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184}},{{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184}},{{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184}},{{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184}},{{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184}},{{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184}},{{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184}},{{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184}},{{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184},{&l_976,&l_976,&l_976,&g_184,(void*)0,&l_976,(void*)0,&g_184},{&l_976,&g_184,&l_976,&g_184,(void*)0,&g_184,(void*)0,&g_184}}};
        int32_t *** const *l_1202 = &l_1203[6][0][6];
        uint32_t l_1248 = 2UL;
        int16_t ** const l_1284 = &g_1091;
        int8_t *l_1315 = &l_1020[1][2][0];
        int64_t l_1316 = 0x7AA217AA011947C7LL;
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_1047[i] = 0x158B9240L;
        l_988 |= (*p_16);
        for (g_969 = 0; (g_969 > 14); ++g_969)
        { /* block id: 417 */
            uint64_t ***l_1001 = &l_980;
            int32_t l_1019[2][4];
            int32_t l_1054 = (-10L);
            const uint16_t *l_1056[10];
            const uint16_t * const *l_1055[8];
            int64_t * const l_1071 = &l_1063;
            uint32_t **l_1096 = &l_1042;
            int32_t ** const l_1133 = &g_323;
            int32_t ** const **l_1196 = &l_1123;
            int64_t l_1229 = (-7L);
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                    l_1019[i][j] = 0x32D44B6AL;
            }
            for (i = 0; i < 10; i++)
                l_1056[i] = &g_90;
            for (i = 0; i < 8; i++)
                l_1055[i] = &l_1056[5];
            for (p_15 = 0; (p_15 <= 0); p_15 += 1)
            { /* block id: 420 */
                int8_t l_1012 = 0L;
                int32_t *l_1060 = &l_987;
                int32_t *l_1061[10][8][3] = {{{&l_1047[3],&l_1021,&l_991},{&l_989,&g_83,&l_985},{&l_1047[0],&l_984,&l_989},{&l_987,&g_551[2],(void*)0},{&l_987,&l_986,&g_3},{(void*)0,(void*)0,&l_986},{(void*)0,&l_983,(void*)0},{&l_990,&g_3,(void*)0}},{{&l_1019[1][3],&l_1019[1][3],&l_983},{(void*)0,&l_986,&l_1047[3]},{&l_984,&l_988,&l_991},{&g_83,&l_991,&l_987},{&g_551[(p_15 + 4)],&l_1021,(void*)0},{&l_1021,&g_551[(p_15 + 4)],(void*)0},{&l_1047[3],&l_988,&l_1047[3]},{(void*)0,&l_1047[3],(void*)0}},{{&l_1054,&l_984,&g_83},{&l_1047[3],(void*)0,&l_992},{(void*)0,&l_986,&l_1021},{&l_1047[3],&l_1047[3],&l_983},{&l_1054,(void*)0,&l_987},{(void*)0,&g_551[0],&l_1018},{&l_1047[3],&l_990,&g_551[5]},{&l_1021,&l_987,(void*)0}},{{&g_551[(p_15 + 4)],&l_1047[3],(void*)0},{&g_83,&g_83,(void*)0},{&l_984,&l_1047[2],(void*)0},{(void*)0,&l_1018,(void*)0},{&l_1019[1][3],&l_990,&l_1018},{&l_990,(void*)0,&l_991},{(void*)0,(void*)0,&l_986},{(void*)0,(void*)0,&g_83}},{{&l_987,&l_986,(void*)0},{&l_987,&l_1047[3],&l_1019[1][3]},{&l_1047[0],&l_991,&l_990},{&l_989,(void*)0,(void*)0},{&l_1047[3],(void*)0,&g_83},{&g_3,&l_991,&l_988},{&l_983,&l_1047[3],&l_1054},{&l_991,&l_986,&l_1021}},{{&l_1018,(void*)0,&l_987},{&l_984,(void*)0,&l_1018},{&l_1021,(void*)0,&l_987},{&l_1047[3],&l_990,&l_985},{&l_991,&l_1018,&l_1054},{&g_551[1],&l_1047[2],&l_1047[3]},{&l_988,&g_83,&l_1047[0]},{&l_983,&l_1047[3],&l_985}},{{&l_990,&l_987,&l_986},{&l_989,&l_990,(void*)0},{&g_551[0],&g_551[0],&g_551[2]},{&g_551[2],(void*)0,&g_551[(p_15 + 4)]},{(void*)0,&l_1047[3],&l_1054},{&g_3,&l_991,&l_988},{&l_983,&l_1021,&l_1054},{&l_989,&l_985,&l_986}},{{&l_989,&l_1018,&l_1021},{(void*)0,&l_1019[1][3],&l_987},{&l_989,(void*)0,&g_551[5]},{&g_83,&l_987,&g_551[2]},{&l_1021,(void*)0,&g_3},{&l_1047[3],(void*)0,&l_1018},{&l_1047[3],&g_551[5],(void*)0},{&l_1019[1][3],&l_987,&l_1054}},{{&l_1018,&l_984,&g_551[1]},{&l_1047[0],(void*)0,&l_1047[3]},{&l_1018,&l_992,(void*)0},{&l_991,&l_991,&l_987},{&l_987,&l_990,&l_1047[3]},{(void*)0,&l_1047[3],&l_1021},{&g_551[2],&g_551[2],&l_1021},{(void*)0,&l_990,(void*)0}},{{(void*)0,(void*)0,(void*)0},{&g_551[2],&l_1047[2],&l_987},{(void*)0,&l_985,(void*)0},{&l_987,&l_1019[1][3],&l_985},{&l_991,&l_988,&l_991},{&l_1018,&l_1047[2],&l_987},{&l_1047[0],&l_1021,&l_1018},{&l_1018,&l_1054,(void*)0}}};
                int32_t l_1062 = (-7L);
                uint64_t l_1065 = 18446744073709551615UL;
                uint32_t ***l_1083[8][5][1];
                int8_t *l_1084[2][8][1] = {{{&g_212},{(void*)0},{(void*)0},{(void*)0},{&g_212},{(void*)0},{(void*)0},{(void*)0}},{{&g_212},{(void*)0},{(void*)0},{(void*)0},{&g_212},{(void*)0},{(void*)0},{(void*)0}}};
                uint64_t l_1085 = 18446744073709551613UL;
                int8_t l_1086 = 0x8BL;
                int64_t *l_1101 = &l_1063;
                uint32_t l_1117 = 0xACD1E968L;
                uint16_t **l_1134 = &l_1058;
                int16_t l_1137[10][1] = {{0x1963L},{0xBAB0L},{0x1963L},{0xBAB0L},{0x1963L},{0xBAB0L},{0x1963L},{0xBAB0L},{0x1963L},{0xBAB0L}};
                uint32_t l_1174 = 0xE103544DL;
                uint32_t l_1201 = 9UL;
                int i, j, k;
                for (i = 0; i < 8; i++)
                {
                    for (j = 0; j < 5; j++)
                    {
                        for (k = 0; k < 1; k++)
                            l_1083[i][j][k] = &g_844;
                    }
                }
                for (l_985 = 0; (l_985 <= 1); l_985 += 1)
                { /* block id: 423 */
                    int64_t *l_1000[10][1] = {{&g_76},{&g_76},{&g_76},{&g_76},{&g_76},{&g_76},{&g_76},{&g_76},{&g_76},{&g_76}};
                    const int32_t **l_1003 = &l_1002;
                    int32_t *l_1004 = &l_984;
                    int32_t *l_1005 = &l_990;
                    int32_t *l_1006 = &l_986;
                    int32_t *l_1007 = &l_992;
                    int32_t *l_1008 = &l_989;
                    int32_t *l_1009 = (void*)0;
                    int32_t *l_1010 = (void*)0;
                    int32_t *l_1011 = &l_991;
                    int32_t *l_1013 = &g_83;
                    int32_t *l_1014 = &l_987;
                    int32_t *l_1015 = &l_987;
                    int32_t *l_1016 = &g_551[6];
                    int32_t *l_1017[4] = {&g_551[(l_985 + 2)],&g_551[(l_985 + 2)],&g_551[(l_985 + 2)],&g_551[(l_985 + 2)]};
                    int8_t *l_1049 = &g_212;
                    int8_t **l_1048 = &l_1049;
                    int i, j;
                    (*g_184) = func_27(((g_551[(p_15 + 1)] = g_551[(p_15 + 1)]) > (&g_918 == l_1001)), ((**g_850) = 246UL), ((*l_1003) = l_1002));
                    ++l_1022;
                    if ((*l_1002))
                    { /* block id: 429 */
                        int8_t *l_1027[3][2][7];
                        int8_t **l_1026 = &l_1027[1][1][5];
                        int8_t ***l_1025 = &l_1026;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 2; j++)
                            {
                                for (k = 0; k < 7; k++)
                                    l_1027[i][j][k] = &g_212;
                            }
                        }
                        (*l_1013) |= (l_1025 != (void*)0);
                    }
                    else
                    { /* block id: 431 */
                        int8_t ***l_1052 = &g_1050;
                        const int32_t l_1053 = 0xB6620191L;
                        uint32_t l_1059 = 0xC7CCD567L;
                        int i, j, k;
                        (*l_1008) = ((((((l_1054 &= (g_221[p_15][(l_985 + 1)][p_15] = (((safe_sub_func_uint8_t_u_u((((((safe_div_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((l_1019[1][3] = ((safe_sub_func_int32_t_s_s(((((safe_mul_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(((p_14 & ((l_1042 = ((*g_844) = ((**g_918) , (void*)0))) != (void*)0)) && (safe_mul_func_uint8_t_u_u(p_15, (safe_sub_func_int64_t_s_s(l_1047[3], (g_76 = (l_1048 != ((*l_1052) = g_1050)))))))), 14)), (((*g_806) >= (*l_1014)) < 7L))) < p_14) , g_316) , l_1053), p_15)) && l_1053)), (*l_1008))), (*l_1013))), (*p_16))) & 0x3DF4L) , p_15) > (*l_1002)) >= 0xBF601BF87144A9A7LL), 249UL)) && l_1012) == p_15))) > 18446744073709551611UL) != 0xC9B7B752L) , (**g_918)) , l_1055[1]) == l_1057[3]);
                        if (l_1059)
                            continue;
                    }
                }
                l_1065--;
                (*g_753) &= (safe_lshift_func_uint8_t_u_u((g_551[p_15] , (l_1070[5][0] == l_1071)), ((!(0UL != g_551[(p_15 + 2)])) || (((safe_lshift_func_int8_t_s_s((l_1085 = (((*l_1060) = (safe_lshift_func_uint16_t_u_s((safe_mod_func_int8_t_s_s((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((void*)0 != l_1083[0][2][0]), 1UL)), 0xD19A3F09L)), p_15)), 10))) , p_14)), p_15)) , l_1086) || (-2L)))));
                if ((*p_16))
                { /* block id: 447 */
                    (*l_1060) |= 0x69CFA7CBL;
                    (*l_976) = (void*)0;
                    if ((*l_1060))
                        continue;
                }
                else
                { /* block id: 451 */
                    int32_t l_1087[10] = {0xCF06CE86L,0xF3A71062L,0xCF06CE86L,0xF3A71062L,0xCF06CE86L,0xF3A71062L,0xCF06CE86L,0xF3A71062L,0xCF06CE86L,0xF3A71062L};
                    int16_t *l_1089 = &g_847;
                    int32_t l_1139 = 0xCC03EB34L;
                    int32_t l_1140 = 0x689EAAE7L;
                    int32_t l_1141[4] = {0x5EF1D666L,0x5EF1D666L,0x5EF1D666L,0x5EF1D666L};
                    uint16_t l_1145 = 0x8CB1L;
                    int i;
                    if (((*l_1060) = l_1087[5]))
                    { /* block id: 453 */
                        int16_t **l_1090 = &l_1089;
                        int64_t * const l_1100[5][7][2] = {{{(void*)0,&g_76},{(void*)0,&g_76},{&g_76,&g_76},{&g_76,(void*)0},{&g_76,(void*)0},{&g_76,&g_76},{&g_76,&g_76}},{{(void*)0,&g_76},{(void*)0,&g_76},{&g_76,&g_76},{&g_76,(void*)0},{&g_76,(void*)0},{&g_76,&g_76},{&g_76,&g_76}},{{(void*)0,&g_76},{(void*)0,&g_76},{&g_76,&g_76},{&g_76,(void*)0},{&g_76,(void*)0},{&g_76,&g_76},{&g_76,&g_76}},{{(void*)0,&g_76},{(void*)0,&g_76},{&g_76,&g_76},{&g_76,(void*)0},{&g_76,(void*)0},{&g_76,&g_76},{(void*)0,&g_76}},{{&g_76,(void*)0},{&g_76,&g_76},{(void*)0,(void*)0},{&g_76,&g_76},{(void*)0,&g_76},{&g_76,(void*)0},{(void*)0,&g_76}}};
                        int16_t *l_1118[10] = {&g_639,(void*)0,&g_639,&g_639,&g_639,&g_639,(void*)0,&g_639,&g_639,&g_639};
                        int i, j, k;
                        (*l_1060) &= (((((*l_1071) = (((**g_805) = (~(-1L))) , ((*g_851) < (l_1056[4] != (g_1091 = ((*l_1090) = l_1089)))))) & ((0xD465DD8AL & (6L | (l_1083[0][2][0] != (void*)0))) > 0x92L)) , (*l_1002)) >= 0x83FBE0B2L);
                        l_1021 = (18446744073709551615UL > (safe_mul_func_int8_t_s_s((((safe_mul_func_uint8_t_u_u(((*g_804) == (l_1097 = (l_1096 = (void*)0))), 0x4CL)) > (((safe_mul_func_int8_t_s_s((l_1100[2][5][1] != l_1101), (safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(((safe_rshift_func_int16_t_s_u((l_1019[0][1] = ((*l_1089) |= (((safe_div_func_int16_t_s_s((g_87 , (safe_div_func_uint32_t_u_u((((safe_mul_func_int8_t_s_s((g_1114 , (l_1047[3] = (safe_div_func_uint32_t_u_u(((g_696 , (*g_851)) && l_1117), l_1019[1][3])))), (*l_1002))) == p_14) ^ p_15), (*l_1002)))), 0xE1AEL)) | l_1054) & (**g_805)))), 5)) <= g_3), 7)), (*l_1002))))) && (-2L)) != 0x82L)) != 9L), 0x87L)));
                    }
                    else
                    { /* block id: 465 */
                        int32_t ***l_1132 = &g_184;
                        uint16_t *l_1135 = &g_80;
                        l_1061[1][5][0] = func_41((~((((safe_lshift_func_int16_t_s_s((p_15 , ((((**l_978) = (((**l_1134) = ((&g_367 != l_1122) | (((safe_lshift_func_uint16_t_u_u((safe_sub_func_int64_t_s_s((0x33L && ((p_14 & (((*l_1071) = ((((safe_div_func_uint64_t_u_u(l_1019[1][3], (p_15 ^ ((((((safe_rshift_func_int8_t_s_s((9UL >= (((*l_1132) = &p_13) == l_1133)), (*l_1060))) , (void*)0) != l_1134) , &p_14) != l_1135) > (-5L))))) , l_1087[2]) < l_1136) | p_15)) || 18446744073709551611UL)) == g_362)), l_1137[9][0])), g_847)) == p_15) == p_15))) & l_1087[8])) <= p_15) || p_14)), 5)) < g_396.f0) , p_14) > 18446744073709551615UL)), g_1138, l_1087[5], &g_551[(p_15 + 4)]);
                    }
                    l_1142[1][0]--;
                    if (l_1145)
                        continue;
                    (*l_1133) = (**g_367);
                }
                for (g_615.f0 = 0; (g_615.f0 <= 0); g_615.f0 += 1)
                { /* block id: 478 */
                    int32_t l_1146 = 0L;
                    int32_t l_1200[4][8] = {{0x4904BA47L,(-1L),0x4904BA47L,(-8L),(-1L),0x402037EDL,0x402037EDL,(-1L)},{(-1L),0x402037EDL,0x402037EDL,(-1L),(-8L),0x4904BA47L,(-1L),0x4904BA47L},{(-1L),0L,0xFC4AF1AEL,0L,(-1L),0xFC4AF1AEL,2L,2L},{0x4904BA47L,0L,(-8L),(-8L),0L,0x4904BA47L,0x402037EDL,0L}};
                    int i, j;
                    for (g_212 = 0; (g_212 >= 0); g_212 -= 1)
                    { /* block id: 481 */
                        int16_t l_1147 = (-2L);
                        if (l_1146)
                            break;
                        if (l_1147)
                            continue;
                        if ((*p_16))
                            break;
                    }
                    for (l_990 = 0; (l_990 <= 0); l_990 += 1)
                    { /* block id: 488 */
                        uint64_t ***l_1148 = &l_980;
                        l_1047[3] = (((l_1148 == &g_918) , (l_1054 = (l_1149 || ((**g_805) == (*g_806))))) < ((((*g_640) &= (safe_add_func_int16_t_s_s(p_15, (~((safe_mul_func_uint16_t_u_u(p_15, ((safe_mod_func_int32_t_s_s((safe_sub_func_int32_t_s_s((-1L), (((safe_add_func_int64_t_s_s(0x7B957C0A2A17BB69LL, l_1146)) | 0L) ^ 0x77L))), 0xB76AB731L)) , 0x26BBL))) | p_15))))) ^ l_1146) == p_15));
                    }
                    for (g_80 = 0; (g_80 <= 6); g_80 += 1)
                    { /* block id: 495 */
                        int64_t l_1179 = (-4L);
                        int i, j, k;
                        g_551[(p_15 + 6)] = ((((safe_div_func_uint8_t_u_u(g_551[g_80], (((*g_851) | (((-1L) <= (((safe_mul_func_int8_t_s_s(((l_1021 &= (~(((((g_221[p_15][(p_15 + 3)][(g_615.f0 + 1)] |= (safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(l_1146, ((((g_551[g_80] , (((safe_sub_func_int64_t_s_s(p_15, ((((l_979[(g_615.f0 + 1)] = (**l_981)) == ((safe_add_func_int16_t_s_s((0x3AL && (l_1047[3] ^= g_551[g_80])), 65530UL)) , (void*)0)) , (*l_1002)) <= g_229))) <= p_14) != (*l_1002))) , g_551[g_80]) & 65530UL) | p_15))), (*l_1002)))) <= g_639) == 0UL) > p_15) && p_15))) >= p_15), (*l_1002))) && (**g_805)) < 1UL)) > l_1174)) ^ g_210))) || (-1L)) | 0x79L) != p_14);
                        (*g_184) = (*g_184);
                    }
                    for (g_553 = 0; (g_553 <= 0); g_553 += 1)
                    { /* block id: 510 */
                        int64_t l_1204[1];
                        int32_t * const l_1224 = &l_987;
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_1204[i] = 0L;
                        if (l_1204[0])
                            break;
                        (*g_640) = (safe_mod_func_int64_t_s_s(((*l_1071) = ((0x4EA274A877F272E3LL >= (safe_sub_func_int16_t_s_s((p_15 | (**g_485)), (~((safe_mul_func_uint8_t_u_u(g_229, (((((**l_980) = (g_221[g_553][(p_15 + 2)][(p_15 + 1)] |= ((g_850 == (void*)0) ^ (safe_div_func_int32_t_s_s(l_1204[0], (safe_rshift_func_int8_t_s_u((safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(0xC5L, ((safe_div_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((((-1L) && 251UL) | p_14), p_15)), 0x64L)) , p_14))), p_14)), p_15))))))) == 0x7FBF2AA9CB499E20LL) <= 0x674DL) > p_14))) < p_15))))) , 0x8ED3C58A6B0C1255LL)), 0xA452315875669C04LL));
                        (*l_1060) = (9UL <= p_14);
                        (***l_1196) = func_36(&l_1200[1][0], (p_13 = p_16), l_1224, (*l_1133));
                    }
                }
            }
            for (g_626 = 7; (g_626 >= 2); g_626 -= 1)
            { /* block id: 524 */
                uint16_t l_1231 = 65534UL;
                int8_t ***l_1251 = &g_1050;
                int32_t l_1273 = 1L;
                int16_t **l_1282 = &g_1091;
                int16_t ***l_1281 = &l_1282;
            }
        }
        l_1316 |= ((safe_rshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((safe_add_func_int32_t_s_s(((safe_add_func_uint32_t_u_u((safe_unary_minus_func_int8_t_s((safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u(1UL, (safe_mul_func_int16_t_s_s(0L, (safe_lshift_func_int16_t_s_s((0x18D465AB0A0919C5LL == ((6UL || (safe_lshift_func_uint16_t_u_u(((((l_1309 = l_1309) != ((safe_rshift_func_int16_t_s_s(p_15, p_14)) , &g_485)) < (safe_lshift_func_int8_t_s_s(((*l_1315) &= (p_14 || (**g_485))), (*l_1002)))) < p_15), g_551[2]))) && 0UL)), 13)))))), 1UL)))), p_15)) != 0x590DL), (**g_805))), 0xA9L)), p_15)) == 0UL);
    }
    return (*l_976);
}


/* ------------------------------------------ */
/* 
 * reads : g_639 g_753 g_83 g_353 g_184 g_221 g_640 g_551 g_3 g_367 g_185
 * writes: g_639 g_83 g_353 g_185
 */
static int32_t * func_18(int32_t * p_19, int32_t * p_20)
{ /* block id: 290 */
    int64_t l_747 = 6L;
    int32_t l_748 = 0xD0F4EA13L;
    int8_t *l_758 = &g_210;
    uint16_t l_765[1][7] = {{0UL,1UL,1UL,0UL,1UL,1UL,0UL}};
    const uint8_t l_768 = 0x71L;
    uint32_t *l_841 = (void*)0;
    uint32_t **l_840[2][6] = {{&l_841,&l_841,&l_841,&l_841,&l_841,&l_841},{&l_841,&l_841,&l_841,&l_841,&l_841,&l_841}};
    uint8_t *l_927 = &g_169;
    uint8_t **l_926 = &l_927;
    uint16_t *l_933[8];
    uint16_t **l_932[6][5][8] = {{{&l_933[2],(void*)0,&l_933[7],&l_933[7],&l_933[5],&l_933[5],&l_933[7],&l_933[3]},{&l_933[6],&l_933[4],&l_933[7],&l_933[0],&l_933[3],&l_933[3],&l_933[0],&l_933[7]},{&l_933[3],&l_933[3],&l_933[3],&l_933[7],&l_933[7],(void*)0,&l_933[0],&l_933[6]},{&l_933[3],&l_933[0],&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[3],&l_933[6]},{&l_933[0],&l_933[4],(void*)0,&l_933[7],&l_933[7],&l_933[7],&l_933[3],&l_933[7]}},{{&l_933[0],&l_933[6],&l_933[7],&l_933[0],(void*)0,&l_933[1],&l_933[6],&l_933[3]},{&l_933[7],&l_933[5],&l_933[2],&l_933[7],&l_933[7],&l_933[7],&l_933[2],&l_933[5]},{&l_933[6],&l_933[5],&l_933[7],&l_933[5],(void*)0,&l_933[4],&l_933[7],&l_933[7]},{&l_933[3],&l_933[6],(void*)0,&l_933[7],&l_933[6],&l_933[7],&l_933[7],&l_933[7]},{&l_933[0],&l_933[7],&l_933[7],&l_933[4],&l_933[5],&l_933[7],&l_933[2],(void*)0}},{{&l_933[5],&l_933[7],&l_933[2],(void*)0,&l_933[7],&l_933[4],&l_933[6],&l_933[7]},{&l_933[7],&l_933[3],&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[3],&l_933[7]},{&l_933[7],(void*)0,(void*)0,&l_933[2],&l_933[3],&l_933[5],&l_933[3],&l_933[5]},{&l_933[5],&l_933[7],&l_933[7],(void*)0,&l_933[2],&l_933[5],&l_933[0],&l_933[7]},{&l_933[6],(void*)0,&l_933[0],&l_933[7],&l_933[7],&l_933[0],&l_933[7],&l_933[7]}},{{&l_933[3],&l_933[7],&l_933[7],&l_933[1],&l_933[7],&l_933[7],&l_933[5],&l_933[2]},{&l_933[7],&l_933[5],&l_933[7],&l_933[7],&l_933[7],&l_933[5],&l_933[7],&l_933[7]},{&l_933[7],&l_933[3],&l_933[7],&l_933[4],&l_933[7],(void*)0,&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7],(void*)0,&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],(void*)0,&l_933[7],&l_933[7],&l_933[7],&l_933[4],&l_933[7]}},{{&l_933[7],(void*)0,(void*)0,&l_933[4],&l_933[7],&l_933[5],&l_933[4],&l_933[4]},{&l_933[3],&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[3],&l_933[1],&l_933[0]},{&l_933[2],&l_933[7],&l_933[3],&l_933[5],(void*)0,&l_933[5],&l_933[4],(void*)0},{&l_933[4],&l_933[7],&l_933[7],&l_933[5],&l_933[7],&l_933[6],&l_933[2],&l_933[0]},{&l_933[1],&l_933[7],&l_933[7],&l_933[7],&l_933[3],&l_933[7],&l_933[3],&l_933[4]}},{{&l_933[4],(void*)0,(void*)0,&l_933[4],&l_933[3],&l_933[7],&l_933[7],&l_933[7]},{&l_933[4],&l_933[7],&l_933[6],&l_933[7],&l_933[4],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[5],&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[3],&l_933[7],&l_933[4],(void*)0,&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[6],&l_933[7],&l_933[0],&l_933[7],&l_933[7],&l_933[2]}}};
    uint16_t **l_936 = &l_933[7];
    int32_t *l_971 = &g_83;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_933[i] = &g_90;
    l_748 = l_747;
    for (g_639 = 9; (g_639 >= (-15)); g_639 = safe_sub_func_int64_t_s_s(g_639, 9))
    { /* block id: 294 */
        int32_t l_751[7] = {(-1L),0x24CEFDD3L,(-1L),(-1L),0x24CEFDD3L,(-1L),(-1L)};
        int32_t *l_754[7];
        uint16_t l_811 = 0xADC1L;
        int16_t l_874 = 0xCD81L;
        int32_t ***l_875 = &g_184;
        uint16_t **l_934[5] = {&l_933[6],&l_933[6],&l_933[6],&l_933[6],&l_933[6]};
        int i;
        for (i = 0; i < 7; i++)
            l_754[i] = (void*)0;
        if ((l_751[5] &= 0x9A315014L))
        { /* block id: 296 */
            (*g_753) |= l_751[5];
            return l_754[1];
        }
        else
        { /* block id: 299 */
            int8_t *l_762 = &g_212;
            int32_t l_769 = 0x43EE38AFL;
            int32_t l_799 = 0xC622FD4BL;
            uint16_t l_907 = 0UL;
            uint8_t *l_915 = (void*)0;
            uint8_t **l_914 = &l_915;
            uint64_t * volatile * volatile l_920[10][10][2] = {{{&g_919[2][4],(void*)0},{&g_919[6][4],&g_919[1][1]},{&g_919[7][5],(void*)0},{&g_919[7][1],&g_919[3][4]},{&g_919[1][1],&g_919[1][1]},{(void*)0,&g_919[2][4]},{&g_919[5][0],&g_919[1][1]},{&g_919[1][1],(void*)0},{&g_919[5][2],&g_919[1][1]},{&g_919[1][1],(void*)0}},{{(void*)0,&g_919[7][1]},{&g_919[2][0],(void*)0},{(void*)0,&g_919[4][4]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],&g_919[0][5]},{&g_919[1][1],(void*)0},{&g_919[1][1],&g_919[4][4]},{&g_919[1][1],&g_919[1][1]},{&g_919[2][2],(void*)0}},{{&g_919[7][4],(void*)0},{(void*)0,&g_919[2][2]},{&g_919[6][6],&g_919[2][0]},{(void*)0,(void*)0},{&g_919[1][1],(void*)0},{&g_919[2][2],&g_919[1][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[0][4],(void*)0},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],&g_919[4][4]}},{{&g_919[1][1],&g_919[1][1]},{(void*)0,&g_919[1][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[7][5],&g_919[1][1]},{&g_919[2][4],&g_919[7][5]},{&g_919[5][4],(void*)0},{&g_919[5][4],&g_919[7][5]},{&g_919[2][4],&g_919[1][1]},{&g_919[7][5],&g_919[1][1]},{&g_919[1][1],&g_919[1][1]}},{{(void*)0,&g_919[1][1]},{&g_919[1][1],&g_919[4][4]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],(void*)0},{&g_919[0][4],&g_919[1][1]},{(void*)0,(void*)0},{&g_919[1][1],&g_919[3][4]},{&g_919[1][3],&g_919[1][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],&g_919[2][2]}},{{(void*)0,(void*)0},{(void*)0,&g_919[1][1]},{&g_919[2][2],&g_919[1][1]},{&g_919[8][1],&g_919[1][1]},{&g_919[1][1],&g_919[7][1]},{&g_919[9][1],&g_919[1][1]},{&g_919[4][4],(void*)0},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],(void*)0},{&g_919[3][4],(void*)0}},{{&g_919[1][1],(void*)0},{&g_919[7][1],&g_919[1][1]},{&g_919[1][1],&g_919[7][2]},{&g_919[1][1],&g_919[2][2]},{(void*)0,&g_919[4][4]},{&g_919[1][1],&g_919[8][4]},{&g_919[1][1],(void*)0},{(void*)0,&g_919[1][1]},{(void*)0,&g_919[1][1]},{&g_919[4][4],&g_919[9][1]}},{{&g_919[1][1],&g_919[5][6]},{&g_919[8][4],&g_919[5][6]},{&g_919[1][1],&g_919[9][1]},{&g_919[4][4],&g_919[1][1]},{(void*)0,&g_919[1][1]},{(void*)0,(void*)0},{&g_919[1][1],&g_919[8][4]},{&g_919[1][1],&g_919[4][4]},{(void*)0,&g_919[2][2]},{&g_919[1][1],&g_919[7][2]}},{{&g_919[1][1],&g_919[1][1]},{&g_919[7][1],(void*)0},{&g_919[1][1],(void*)0},{&g_919[3][4],(void*)0},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],(void*)0},{&g_919[4][4],&g_919[1][1]},{&g_919[9][1],&g_919[7][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[8][1],&g_919[1][1]}},{{&g_919[2][2],&g_919[1][1]},{(void*)0,(void*)0},{(void*)0,&g_919[2][2]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][1],&g_919[1][1]},{&g_919[1][3],&g_919[3][4]},{&g_919[1][1],(void*)0},{(void*)0,&g_919[1][1]},{&g_919[0][4],(void*)0},{&g_919[1][1],&g_919[1][1]}}};
            int32_t l_970[1][5][5] = {{{5L,(-10L),(-10L),5L,0x74766E9AL},{5L,6L,0x7FF71052L,0x7FF71052L,6L},{0x74766E9AL,(-10L),0x7FF71052L,0x5A2BCECCL,0x5A2BCECCL},{(-10L),0x74766E9AL,(-10L),0x7FF71052L,0x5A2BCECCL},{6L,5L,0x5A2BCECCL,5L,6L}}};
            int i, j, k;
            for (g_353 = (-13); (g_353 == 56); g_353 = safe_add_func_uint64_t_u_u(g_353, 3))
            { /* block id: 302 */
                int32_t l_757 = 1L;
                int8_t **l_759 = (void*)0;
                int8_t *l_761[9] = {&g_212,&g_212,&g_212,&g_212,&g_212,&g_212,&g_212,&g_212,&g_212};
                int8_t **l_760 = &l_761[8];
                uint8_t *l_853[5][9] = {{&g_341[2][6][1],&g_517.f0,&g_615.f0,&g_615.f0,&g_169,&g_169,&g_615.f0,&g_615.f0,&g_517.f0},{&g_341[2][6][1],&g_169,&g_341[2][6][1],&g_517.f0,&g_615.f0,&g_615.f0,&g_615.f0,&g_615.f0,&g_517.f0},{&g_341[2][6][1],&g_615.f0,&g_341[2][6][1],&g_615.f0,&g_169,&g_341[2][6][1],&g_169,&g_169,&g_341[2][6][1]},{&g_341[2][6][1],&g_169,&g_341[2][6][1],&g_169,&g_341[2][6][1],&g_517.f0,&g_615.f0,&g_615.f0,&g_615.f0},{&g_169,&g_615.f0,&g_341[2][6][1],&g_615.f0,&g_341[2][6][1],&g_615.f0,&g_169,&g_169,&g_341[2][6][1]}};
                uint8_t * const *l_852 = &l_853[2][2];
                uint8_t l_877 = 1UL;
                const int32_t l_885 = 0x6665CFC5L;
                uint16_t ** const l_943[10][5] = {{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]},{&l_933[7],&l_933[7],&l_933[7],&l_933[7],&l_933[7]}};
                int32_t l_946[10] = {1L,0x0FDB6535L,0x0FDB6535L,1L,0x0FDB6535L,0x0FDB6535L,1L,0x0FDB6535L,0x0FDB6535L,1L};
                int64_t *l_968[8] = {&l_747,&l_747,&l_747,&l_747,&l_747,&l_747,&l_747,&l_747};
                int i, j;
            }
            (**l_875) = (void*)0;
            (*g_753) = (l_748 & g_221[0][3][1]);
            if ((*g_640))
                break;
        }
        (**l_875) = p_20;
    }
    (*l_971) = (*p_19);
    return (**g_367);
}


/* ------------------------------------------ */
/* 
 * reads : g_696 g_639 g_210 g_396.f2 g_126 g_615.f2 g_212 g_76 g_517.f2 g_184 g_185 g_3 g_229 g_724 g_551 g_486 g_487 g_83 g_626
 * writes: g_551 g_639 g_126 g_724 g_341 g_83 g_626 g_618
 */
static int32_t * func_21(int32_t  p_22, int32_t  p_23, int16_t  p_24, uint32_t  p_25, uint32_t  p_26)
{ /* block id: 261 */
    int8_t l_705 = 3L;
    uint8_t l_706 = 0xE0L;
    int32_t *l_707 = &g_551[6];
    int16_t *l_712 = &g_639;
    uint16_t *l_719 = &g_126;
    uint8_t l_720[4][1] = {{0x56L},{1UL},{0x56L},{1UL}};
    int32_t l_721 = 0xA0DDD608L;
    uint32_t *l_722 = (void*)0;
    uint32_t *l_723 = &g_724;
    int32_t l_725 = 0x512CDEFEL;
    int i, j;
lbl_728:
    l_725 |= (((*l_723) |= (((~(safe_mod_func_int64_t_s_s(p_26, ((l_721 = (((g_696 , ((safe_rshift_func_uint8_t_u_u((safe_div_func_int64_t_s_s(((safe_sub_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(l_705, ((*l_707) = (l_706 = 0x3E369923L)))), (safe_rshift_func_int16_t_s_u((((safe_div_func_int32_t_s_s(((((((((*l_712) |= p_26) && g_210) , (safe_rshift_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((p_22 > (((*l_719) &= g_396.f2) < g_615.f2)), g_212)), p_23)), g_76))) & 0x4880L) && p_23) , g_212) > l_720[3][0]), p_25)) && (-10L)) == p_22), 3)))) ^ 0xFE09B9A575153FCFLL), 0xF80AA209FE7799D5LL)), g_517.f2)) == (**g_184))) == 0x2FL) <= g_229)) , p_23)))) ^ 1UL) == 255UL)) < 9L);
    for (l_705 = 0; (l_705 > (-10)); --l_705)
    { /* block id: 271 */
        if (g_212)
            goto lbl_728;
    }
    for (l_725 = 5; (l_725 >= 0); l_725 -= 1)
    { /* block id: 276 */
        int32_t ***l_732 = &g_184;
        int32_t ****l_731 = &l_732;
        uint8_t *l_742 = (void*)0;
        uint8_t *l_743[5];
        int32_t *l_744[6][3][10] = {{{&g_551[3],&g_551[2],&g_3,&g_551[3],(void*)0,&g_551[3],&g_3,&g_551[2],&g_551[3],(void*)0},{&g_3,&g_551[2],&g_551[(l_725 + 1)],&g_3,(void*)0,&l_721,&g_551[2],&g_551[2],&l_721,(void*)0},{&g_3,&g_3,&g_3,&g_3,(void*)0,&g_551[3],&g_551[2],&g_3,&g_551[3],(void*)0}},{{&g_551[3],&g_551[2],&g_3,&g_551[3],(void*)0,&g_551[3],&g_3,&g_551[2],&g_551[3],(void*)0},{&g_3,&g_551[2],&g_551[(l_725 + 1)],&g_3,(void*)0,&l_721,&g_551[2],&g_551[2],&l_721,(void*)0},{&g_3,&g_3,&g_3,&g_3,(void*)0,&g_551[3],&g_551[2],&g_3,&g_551[3],(void*)0}},{{&g_551[3],&g_551[2],&g_3,&g_551[3],(void*)0,&g_551[3],&g_3,&g_551[2],&g_551[3],(void*)0},{&g_3,&g_551[2],&g_551[(l_725 + 1)],&g_3,(void*)0,&l_721,&g_551[2],&g_551[2],&l_721,(void*)0},{&g_3,&g_3,&g_3,&l_725,&g_551[2],(void*)0,&g_551[3],&l_721,(void*)0,&g_3}},{{(void*)0,&g_551[3],&l_721,(void*)0,&g_3,(void*)0,&l_721,&g_551[3],(void*)0,&g_551[2]},{&l_725,&g_551[3],&g_3,&l_725,&g_3,&g_3,&g_551[3],&g_551[3],&g_3,&g_3},{&l_725,&l_721,&l_721,&l_725,&g_551[2],(void*)0,&g_551[3],&l_721,(void*)0,&g_3}},{{(void*)0,&g_551[3],&l_721,(void*)0,&g_3,(void*)0,&l_721,&g_551[3],(void*)0,&g_551[2]},{&l_725,&g_551[3],&g_3,&l_725,&g_3,&g_3,&g_551[3],&g_551[3],&g_3,&g_3},{&l_725,&l_721,&l_721,&l_725,&g_551[2],(void*)0,&g_551[3],&l_721,(void*)0,&g_3}},{{(void*)0,&g_551[3],&l_721,(void*)0,&g_3,(void*)0,&l_721,&g_551[3],(void*)0,&g_551[2]},{&l_725,&g_551[3],&g_3,&l_725,&g_3,&g_3,&g_551[3],&g_551[3],&g_3,&g_3},{&l_725,&l_721,&l_721,&l_725,&g_551[2],(void*)0,&g_551[3],&l_721,(void*)0,&g_3}}};
        int32_t *l_745 = (void*)0;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_743[i] = (void*)0;
        g_551[l_725] = g_551[(l_725 + 1)];
        if (g_551[(l_725 + 1)])
            continue;
        g_83 &= (safe_rshift_func_int16_t_s_s(((g_341[0][5][0] = ((((l_731 == (void*)0) , (*g_486)) != (((safe_div_func_uint16_t_u_u(((-2L) <= (safe_lshift_func_uint8_t_u_u((+(*l_707)), (safe_add_func_uint16_t_u_u(((g_639 = (((void*)0 == &l_732) || ((*l_719) = (safe_rshift_func_int16_t_s_u((-1L), (*l_707)))))) || g_724), p_26))))), (*l_707))) == 0xE8574CFFB0C2AEA4LL) || 4UL)) | 0UL)) , (*l_707)), p_23));
        for (g_626 = 0; (g_626 <= 5); g_626 += 1)
        { /* block id: 285 */
            int i, j;
            g_618[l_725][l_725] = l_745;
        }
    }
    return (*g_184);
}


/* ------------------------------------------ */
/* 
 * reads : g_584 g_87 g_80 g_673 g_90 g_126 g_76 g_626 g_184 g_185
 * writes: g_584 g_80 g_76
 */
static int32_t * func_27(uint32_t  p_28, uint8_t  p_29, const int32_t * p_30)
{ /* block id: 246 */
    int32_t l_643 = 0x688744FBL;
    const uint16_t *l_645 = &g_80;
    int32_t l_646 = (-5L);
    uint32_t l_674 = 0xF9687A06L;
    int32_t l_676 = 0x54DBD5B0L;
    int32_t *l_677 = &g_83;
    int32_t *l_678 = &g_551[3];
    int32_t *l_679 = &g_551[2];
    int32_t *l_680 = &g_83;
    int32_t l_681[1][7];
    int32_t *l_682 = &l_681[0][4];
    int32_t *l_683[9][8][3] = {{{&g_3,&l_646,&g_3},{&g_3,&g_551[2],&g_3},{&g_83,&l_646,&g_551[2]},{&g_3,&l_646,&l_646},{&g_3,&g_83,&g_83},{&g_83,&l_681[0][6],&g_551[3]},{&g_3,&g_3,&g_551[6]},{&g_3,&g_551[2],&g_83}},{{&g_83,&l_646,&g_551[5]},{&g_3,&l_646,&g_3},{&g_3,&g_551[2],&g_3},{&g_83,&l_646,&g_551[2]},{&g_3,&l_646,&l_646},{&g_3,&g_83,&g_83},{&g_83,&l_681[0][6],&g_551[3]},{&g_3,&g_3,&g_551[6]}},{{&g_3,&g_551[2],&g_83},{&g_83,&l_646,&g_551[5]},{&g_3,&l_646,&g_3},{&g_3,&g_551[2],&g_3},{&g_83,&l_646,&g_551[2]},{&g_3,&l_646,&l_646},{&g_3,&g_83,&g_83},{&g_83,&l_681[0][6],&g_551[3]}},{{&g_3,&g_3,&g_551[6]},{&g_3,&g_551[2],&g_83},{&g_83,&l_646,&g_551[5]},{&g_3,&l_646,&g_3},{&g_3,&g_551[2],&g_3},{&g_83,&l_646,&g_551[2]},{&g_3,&l_646,&l_646},{&g_3,&g_551[5],&g_83}},{{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&g_551[6],&l_681[0][3]},{&l_681[0][3],&g_551[3],&l_681[0][3]},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&l_646,(void*)0},{&l_681[0][3],&g_551[2],&l_681[0][3]},{&l_681[0][3],&g_3,&l_681[0][3]},{&l_681[0][3],&g_3,(void*)0}},{{&l_681[0][3],&g_551[5],&g_83},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&g_551[6],&l_681[0][3]},{&l_681[0][3],&g_551[3],&l_681[0][3]},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&l_646,(void*)0},{&l_681[0][3],&g_551[2],&l_681[0][3]},{&l_681[0][3],&g_3,&l_681[0][3]}},{{&l_681[0][3],&g_3,(void*)0},{&l_681[0][3],&g_551[5],&g_83},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&g_551[6],&l_681[0][3]},{&l_681[0][3],&g_551[3],&l_681[0][3]},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&l_646,(void*)0},{&l_681[0][3],&g_551[2],&l_681[0][3]}},{{&l_681[0][3],&g_3,&l_681[0][3]},{&l_681[0][3],&g_3,(void*)0},{&l_681[0][3],&g_551[5],&g_83},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&g_551[6],&l_681[0][3]},{&l_681[0][3],&g_551[3],&l_681[0][3]},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&l_646,(void*)0}},{{&l_681[0][3],&g_551[2],&l_681[0][3]},{&l_681[0][3],&g_3,&l_681[0][3]},{&l_681[0][3],&g_3,(void*)0},{&l_681[0][3],&g_551[5],&g_83},{&l_681[0][3],&g_83,&g_551[4]},{&l_681[0][3],&g_551[6],&l_681[0][3]},{&l_681[0][3],&g_551[3],&l_681[0][3]},{&l_681[0][3],&g_83,&g_551[4]}}};
    int16_t l_684 = (-1L);
    int32_t l_685 = 0x27536C39L;
    int32_t l_686 = (-1L);
    uint32_t l_687 = 18446744073709551615UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
            l_681[i][j] = 0x8D4158D2L;
    }
    l_646 |= ((l_643 , (&g_80 == ((safe_unary_minus_func_int64_t_s(0L)) , l_645))) != p_28);
    for (g_584 = 0; (g_584 > 58); g_584 = safe_add_func_int8_t_s_s(g_584, 1))
    { /* block id: 250 */
        uint16_t l_649 = 0x50D0L;
        int32_t l_650 = 0xA3148886L;
        uint16_t *l_663[1];
        int32_t l_664 = 0xBC08E6ECL;
        int64_t *l_675 = &g_76;
        int i;
        for (i = 0; i < 1; i++)
            l_663[i] = &g_126;
        l_646 = (l_649 && (l_650 > ((safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((safe_div_func_int16_t_s_s(((((g_87 <= ((*l_675) ^= (((safe_mul_func_uint16_t_u_u(((void*)0 != &l_645), (safe_div_func_int8_t_s_s((((safe_div_func_uint64_t_u_u(((((g_80++) > ((l_664 = (safe_rshift_func_uint16_t_u_s((((safe_lshift_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u((g_673 == (void*)0), g_90)) > p_29), 3)) != p_29) <= 65535UL), 11))) != 0x51L)) <= l_646) , l_674), 0x666B44E91C914DEBLL)) & l_649) && 0x7F6DAF9F91D28E64LL), g_126)))) < l_643) , 0x281FAA47D2EC24EELL))) , 0x54L) || l_646) < l_643), l_643)) || l_676), p_28)), 0x41L)) ^ g_626)));
        return (*g_184);
    }
    ++l_687;
    return (*g_184);
}


/* ------------------------------------------ */
/* 
 * reads : g_553 g_3 g_367 g_184 g_185 g_551 g_615 g_221 g_83 g_126 g_639 g_229 g_210 g_485 g_486 g_487 g_640
 * writes: g_553 g_210 g_639 g_551
 */
static int64_t  func_33(int32_t * p_34, int32_t * p_35)
{ /* block id: 228 */
    uint8_t *l_602[6][3][4] = {{{&g_341[0][8][0],(void*)0,&g_341[0][8][0],&g_341[2][6][1]},{(void*)0,&g_341[2][6][1],&g_341[2][6][1],&g_341[2][6][1]},{(void*)0,&g_341[4][9][0],&g_341[2][6][1],&g_341[2][6][1]}},{{&g_169,(void*)0,&g_341[2][6][1],&g_341[2][6][1]},{(void*)0,&g_341[2][6][1],&g_341[2][6][1],(void*)0},{(void*)0,&g_341[0][8][0],&g_341[0][8][0],(void*)0}},{{&g_341[0][8][0],(void*)0,&g_341[4][9][0],&g_169},{&g_341[2][6][1],(void*)0,&g_169,&g_341[2][6][1]},{(void*)0,&g_169,&g_341[2][6][1],&g_341[2][6][1]}},{{&g_341[4][9][0],(void*)0,&g_341[2][6][1],&g_169},{&g_341[2][6][1],(void*)0,&g_517.f0,(void*)0},{(void*)0,&g_341[0][8][0],&g_341[2][6][1],(void*)0}},{{&g_341[2][6][1],&g_341[2][6][1],&g_341[0][8][0],&g_341[2][6][1]},{&g_341[2][6][1],(void*)0,&g_169,&g_341[2][6][1]},{&g_341[2][6][1],&g_341[4][9][0],&g_341[0][8][0],&g_341[2][6][1]}},{{&g_341[2][6][1],&g_341[2][6][1],&g_341[2][6][1],&g_341[2][6][1]},{(void*)0,(void*)0,&g_517.f0,&g_341[2][6][1]},{&g_341[2][6][1],&g_169,&g_169,&g_341[0][8][0]}}};
    uint8_t * const l_603 = &g_341[2][6][1];
    int8_t *l_604 = (void*)0;
    int8_t *l_605[2][10][4] = {{{(void*)0,&g_212,&g_212,&g_210},{&g_212,&g_210,&g_210,&g_210},{&g_212,(void*)0,&g_210,&g_210},{&g_212,&g_210,&g_210,&g_210},{&g_212,&g_212,&g_212,&g_210},{&g_210,&g_212,&g_210,&g_212},{&g_210,&g_210,&g_210,&g_210},{&g_210,&g_210,(void*)0,&g_212},{(void*)0,(void*)0,&g_212,&g_212},{&g_212,&g_210,&g_210,&g_210}},{{&g_212,&g_212,&g_212,(void*)0},{(void*)0,&g_210,(void*)0,&g_210},{&g_210,&g_212,&g_210,&g_212},{&g_210,&g_210,&g_210,&g_210},{&g_210,&g_210,&g_212,(void*)0},{&g_212,&g_210,&g_210,&g_212},{&g_212,&g_212,&g_210,&g_210},{&g_212,&g_212,&g_210,&g_212},{&g_212,&g_210,&g_212,(void*)0},{(void*)0,&g_210,&g_212,&g_210}}};
    int32_t l_606[4][3] = {{0x6937AFC0L,(-5L),(-5L)},{0xD89C8873L,(-1L),(-1L)},{0x6937AFC0L,(-5L),(-5L)},{0xD89C8873L,(-1L),(-1L)}};
    int32_t l_616 = 0xA6A01E2BL;
    int32_t l_617 = (-1L);
    int16_t *l_622 = (void*)0;
    int32_t *l_625[9][9][1] = {{{(void*)0},{(void*)0},{&g_626},{&g_626},{&g_626},{(void*)0},{&g_626},{&g_626},{(void*)0}},{{&g_626},{(void*)0},{&g_626},{&g_626},{(void*)0},{&g_626},{&g_626},{&g_626},{(void*)0}},{{(void*)0},{&g_626},{&g_626},{&g_626},{&g_626},{(void*)0},{(void*)0},{&g_626},{&g_626}},{{&g_626},{(void*)0},{&g_626},{&g_626},{(void*)0},{&g_626},{(void*)0},{&g_626},{&g_626}},{{(void*)0},{&g_626},{&g_626},{&g_626},{(void*)0},{(void*)0},{&g_626},{&g_626},{&g_626}},{{&g_626},{(void*)0},{(void*)0},{&g_626},{&g_626},{&g_626},{(void*)0},{&g_626},{&g_626}},{{(void*)0},{&g_626},{(void*)0},{&g_626},{&g_626},{(void*)0},{&g_626},{&g_626},{&g_626}},{{(void*)0},{(void*)0},{&g_626},{&g_626},{&g_626},{&g_626},{(void*)0},{(void*)0},{&g_626}},{{&g_626},{&g_626},{(void*)0},{&g_626},{&g_626},{(void*)0},{&g_626},{(void*)0},{&g_626}}};
    int32_t **l_629 = &g_323;
    int16_t *l_638 = &g_639;
    int16_t l_641[9][4] = {{2L,(-2L),(-2L),2L},{(-2L),2L,(-2L),(-2L)},{2L,2L,0x4F25L,2L},{2L,(-2L),0x4F25L,(-2L)},{0x4F25L,(-2L),0x4F25L,0x4F25L},{(-2L),(-2L),2L,(-2L)},{(-2L),0x4F25L,0x4F25L,(-2L)},{0x4F25L,(-2L),0x4F25L,0x4F25L},{(-2L),(-2L),2L,(-2L)}};
    int i, j, k;
    for (g_553 = (-25); (g_553 <= 21); g_553++)
    { /* block id: 231 */
        int32_t *l_600[9][10] = {{&g_551[2],&g_551[2],&g_551[2],&g_551[6],&g_551[2],&g_551[6],&g_551[2],&g_551[2],&g_551[2],&g_551[2]},{&g_551[4],&g_551[6],&g_83,&g_83,&g_551[6],&g_551[4],&g_551[2],&g_551[4],&g_551[6],&g_83},{&g_551[6],&g_551[2],&g_551[6],&g_83,&g_551[2],&g_551[2],&g_83,&g_551[6],&g_551[2],&g_551[6]},{&g_551[6],&g_551[4],&g_551[2],&g_551[6],&g_551[2],&g_551[4],&g_551[6],&g_551[6],&g_551[4],&g_551[2]},{&g_551[4],&g_551[6],&g_551[6],&g_551[4],&g_551[2],&g_551[6],&g_551[2],&g_551[4],&g_551[6],&g_551[6]},{&g_551[2],&g_551[6],&g_83,&g_551[2],&g_551[2],&g_83,&g_551[6],&g_551[2],&g_551[6],&g_83},{&g_551[6],&g_551[4],&g_551[2],&g_551[4],&g_551[6],&g_83,&g_83,&g_551[6],&g_551[4],&g_551[2]},{&g_551[2],&g_551[2],&g_551[2],&g_551[6],&g_551[2],&g_551[6],&g_551[2],&g_551[2],&g_551[2],&g_551[2]},{&g_551[4],&g_551[6],&g_83,&g_83,&g_551[6],&g_551[4],&g_551[2],&g_551[4],&g_551[6],&g_83}};
        uint16_t l_601[1];
        int i, j;
        for (i = 0; i < 1; i++)
            l_601[i] = 1UL;
        l_601[0] &= 0xA6100C7DL;
        if ((*p_35))
            break;
        if ((***g_367))
            continue;
    }
    l_616 = (l_617 ^= ((l_602[2][2][0] == l_603) <= ((((0xA6L == (g_210 = (l_606[0][1] = 5L))) , (safe_rshift_func_int8_t_s_s((((safe_div_func_uint16_t_u_u(((((safe_mul_func_int8_t_s_s(((l_606[0][1] = (safe_mul_func_uint16_t_u_u(0x6857L, ((((g_551[4] ^ l_606[2][1]) <= (g_615 , (l_606[0][1] , l_606[0][1]))) < 0xB6L) | (*p_34))))) == l_616), l_616)) || l_606[0][1]) || 18446744073709551615UL) ^ l_616), g_221[0][3][1])) , 6L) , l_606[2][1]), g_553))) < 0x985BAA7DL) != g_83)));
    (*g_640) = (safe_mul_func_uint16_t_u_u(((void*)0 != l_622), (safe_sub_func_uint8_t_u_u(((l_617 = 0x4FE66801L) , (safe_rshift_func_int16_t_s_s((g_553 = l_617), ((void*)0 == l_629)))), (((safe_mul_func_int8_t_s_s(((*p_35) & (safe_lshift_func_uint16_t_u_s((g_126 & ((*l_638) |= (safe_sub_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s(l_616, 0)) , g_551[2]), 65533UL)))), g_229))), g_210)) >= g_229) >= (**g_485))))));
    return l_641[6][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_551 g_3
 * writes:
 */
static int32_t * func_36(int32_t * p_37, int32_t * p_38, int32_t * const  p_39, int32_t * p_40)
{ /* block id: 225 */
    int16_t l_596 = 0x36B1L;
    int32_t *l_597 = &g_3;
    l_596 ^= (*p_39);
    return l_597;
}


/* ------------------------------------------ */
/* 
 * reads : g_87 g_90 g_80 g_83 g_126 g_3 g_184 g_185 g_551
 * writes: g_87 g_83 g_90 g_76 g_80 g_126 g_185
 */
static int32_t * func_41(int32_t  p_42, int64_t  p_43, int16_t  p_44, const int32_t * p_45)
{ /* block id: 8 */
    uint32_t l_81[9][10] = {{1UL,0x0E5E2E4BL,0x0E5E2E4BL,1UL,0x5A975881L,4294967295UL,1UL,4294967295UL,0x5A975881L,1UL},{4294967295UL,1UL,4294967295UL,0x5A975881L,1UL,0x0E5E2E4BL,0x0E5E2E4BL,1UL,0x5A975881L,4294967295UL},{0x0F96394AL,0x0F96394AL,0xB61EA52FL,1UL,0x2075D7B1L,0xB61EA52FL,0x2075D7B1L,1UL,0xB61EA52FL,0x0F96394AL},{0x2075D7B1L,0x0E5E2E4BL,4294967295UL,0x2075D7B1L,0x5A975881L,0x5A975881L,0x2075D7B1L,4294967295UL,0x0E5E2E4BL,0x2075D7B1L},{4294967295UL,0x0F96394AL,0x0E5E2E4BL,0x5A975881L,0x0F96394AL,0x5A975881L,0x0E5E2E4BL,0x0F96394AL,4294967295UL,4294967295UL},{0x2075D7B1L,1UL,0xB61EA52FL,0x0F96394AL,0x0F96394AL,0xB61EA52FL,1UL,0x2075D7B1L,0xB61EA52FL,0x2075D7B1L},{0x0F96394AL,0x0E5E2E4BL,0x5A975881L,0x0F96394AL,0x5A975881L,0x0E5E2E4BL,0x0F96394AL,4294967295UL,4294967295UL,0x0F96394AL},{4294967295UL,0x2075D7B1L,0x5A975881L,0x5A975881L,0x2075D7B1L,4294967295UL,0x0E5E2E4BL,0x2075D7B1L,0x0E5E2E4BL,0xEBF624E1L},{0x0E5E2E4BL,0x5A975881L,0x0F96394AL,0x5A975881L,0x0E5E2E4BL,0x0F96394AL,4294967295UL,4294967295UL,0x0F96394AL,0x0E5E2E4BL}};
    int32_t l_120 = (-9L);
    int32_t l_121 = 1L;
    int32_t l_122 = (-1L);
    int32_t l_125[5];
    int16_t l_180 = 1L;
    const int8_t *l_228 = &g_229;
    uint64_t *l_232 = &g_221[0][3][1];
    int16_t l_244 = 2L;
    int32_t l_294 = 0x96784529L;
    const int16_t l_305[8] = {0x71F1L,0x71F1L,0x71F1L,0x71F1L,0x71F1L,0x71F1L,0x71F1L,0x71F1L};
    int32_t *l_329 = &l_125[2];
    const int32_t *l_387[6][10] = {{(void*)0,&l_122,&l_122,&l_122,&l_122,(void*)0,&l_120,&l_120,(void*)0,&l_122},{&l_122,&l_122,&l_122,&l_122,(void*)0,&l_120,&l_120,(void*)0,&l_122,&l_122},{&l_122,&l_122,&l_120,&l_122,(void*)0,(void*)0,&l_122,&l_120,&l_122,&l_122},{(void*)0,&l_122,&l_120,&l_122,&l_122,&l_120,&l_122,(void*)0,(void*)0,&l_122},{(void*)0,&l_122,&l_122,&l_122,&l_122,(void*)0,&l_120,&l_120,(void*)0,&l_122},{&l_122,&l_122,&l_122,&l_122,(void*)0,&l_120,&l_120,(void*)0,&l_122,&l_122}};
    const int32_t **l_386[10] = {&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2],&l_387[1][2]};
    const int32_t ** const *l_385 = &l_386[7];
    int32_t l_407 = (-8L);
    uint8_t *l_446 = &g_341[2][6][1];
    uint64_t l_497 = 0xDE6BDD7E7F9EF6B5LL;
    uint8_t l_499 = 4UL;
    uint8_t l_502 = 0xD9L;
    int32_t *l_521 = &l_120;
    int32_t *l_522[2];
    int8_t l_581 = 0xF0L;
    int32_t *l_595 = &g_551[2];
    int i, j;
    for (i = 0; i < 5; i++)
        l_125[i] = 2L;
    for (i = 0; i < 2; i++)
        l_522[i] = &g_3;
    for (p_44 = 1; (p_44 <= 8); p_44 += 1)
    { /* block id: 11 */
        int16_t l_110 = 4L;
        uint16_t *l_111[1];
        int32_t l_119 = 9L;
        int32_t l_124 = 0xE8C80964L;
        int32_t ** const l_188 = &g_185;
        int32_t l_213[2];
        const int8_t *l_227 = &g_212;
        uint64_t *l_233 = &g_221[0][3][1];
        int32_t l_246 = 0xB5969875L;
        int32_t *l_326 = &l_124;
        int32_t *l_331 = (void*)0;
        int16_t l_368 = 0x1232L;
        uint64_t l_373 = 18446744073709551615UL;
        uint32_t l_408 = 0x94CAB002L;
        int16_t l_537 = 0L;
        const uint32_t *l_589 = &g_362;
        const uint32_t **l_588 = &l_589;
        int i;
        for (i = 0; i < 1; i++)
            l_111[i] = &g_90;
        for (i = 0; i < 2; i++)
            l_213[i] = 0L;
        for (p_43 = 8; (p_43 >= 0); p_43 -= 1)
        { /* block id: 14 */
            int32_t *l_82 = &g_83;
            int32_t *l_84 = (void*)0;
            int32_t *l_85 = &g_83;
            int32_t *l_86[10][9][2] = {{{(void*)0,&g_83},{&g_83,&g_3},{&g_3,&g_83},{&g_83,&g_83},{&g_83,(void*)0},{(void*)0,&g_83},{&g_3,&g_83},{&g_83,&g_3},{&g_3,&g_83}},{{(void*)0,&g_83},{&g_3,&g_83},{(void*)0,&g_83},{&g_3,&g_3},{&g_83,&g_83},{&g_3,&g_83},{(void*)0,(void*)0},{&g_83,&g_83},{&g_83,&g_83}},{{&g_3,&g_3},{&g_83,&g_83},{(void*)0,&g_3},{&g_83,&g_3},{(void*)0,&g_3},{(void*)0,&g_83},{&g_83,(void*)0},{&g_3,(void*)0},{&g_83,(void*)0}},{{&g_83,&g_3},{&g_83,&g_83},{&g_3,(void*)0},{&g_3,(void*)0},{&g_3,&g_3},{(void*)0,&g_83},{&g_83,&g_3},{(void*)0,&g_3},{&g_83,&g_3}},{{&g_83,&g_83},{&g_83,&g_3},{&g_83,(void*)0},{&g_83,&g_83},{&g_83,(void*)0},{&g_3,&g_83},{&g_3,&g_83},{&g_3,&g_83},{(void*)0,&g_83}},{{&g_3,&g_3},{&g_83,&g_3},{&g_83,&g_83},{&g_3,&g_83},{(void*)0,(void*)0},{(void*)0,&g_83},{(void*)0,&g_83},{&g_83,(void*)0},{(void*)0,&g_83}},{{&g_83,&g_83},{&g_83,&g_83},{(void*)0,(void*)0},{&g_83,&g_83},{(void*)0,&g_83},{&g_83,&g_83},{&g_83,&g_83},{(void*)0,(void*)0},{&g_3,&g_83}},{{(void*)0,(void*)0},{&g_3,&g_3},{&g_83,&g_3},{&g_83,&g_83},{&g_3,(void*)0},{(void*)0,&g_83},{&g_3,&g_3},{&g_83,&g_83},{&g_83,&g_3}},{{&g_3,&g_83},{&g_3,(void*)0},{&g_83,&g_83},{&g_83,&g_3},{&g_3,&g_3},{&g_83,&g_83},{&g_3,&g_83},{(void*)0,&g_3},{&g_3,&g_3}},{{&g_3,(void*)0},{&g_3,&g_3},{&g_3,&g_83},{&g_83,&g_3},{&g_3,(void*)0},{&g_83,(void*)0},{&g_3,&g_83},{(void*)0,(void*)0},{&g_83,&g_83}}};
            int64_t *l_131 = &g_76;
            uint16_t *l_132 = &g_90;
            int i, j, k;
            g_87++;
            if (((*l_82) = 0x1AE2D2C9L))
            { /* block id: 17 */
                uint64_t l_98 = 0x13F5ED5A8D4E4AF0LL;
                int64_t *l_99[10] = {&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76};
                uint16_t *l_112 = &g_80;
                int32_t l_115 = 4L;
                int i, j;
                --g_90;
                l_115 ^= (safe_rshift_func_uint16_t_u_s(((safe_mul_func_int8_t_s_s((!(l_81[p_44][(p_43 + 1)] = ((g_76 = l_98) > (0x10F8796DL & l_98)))), (safe_div_func_int8_t_s_s((safe_add_func_uint16_t_u_u((((l_98 || (safe_lshift_func_int16_t_s_s(((safe_add_func_int64_t_s_s((l_110 && (l_111[0] != l_112)), (((safe_rshift_func_int16_t_s_s(((void*)0 != &l_86[8][5][1]), 11)) , l_110) | 0x6BC5A18187EA63F3LL))) <= 0x4CL), g_80))) && (*l_85)) && g_80), l_110)), l_110)))) , l_110), 12));
                (*l_82) = (-1L);
            }
            else
            { /* block id: 23 */
                int64_t l_123[1][4][4] = {{{0x926F2DC12F6744EDLL,(-2L),0x926F2DC12F6744EDLL,0x926F2DC12F6744EDLL},{(-2L),(-2L),0xBDF17F541A3ACD9BLL,(-2L)},{(-2L),0x926F2DC12F6744EDLL,0x926F2DC12F6744EDLL,(-2L)},{0x926F2DC12F6744EDLL,(-2L),0x926F2DC12F6744EDLL,0x926F2DC12F6744EDLL}}};
                uint16_t *l_133 = (void*)0;
                int32_t l_146 = 7L;
                int i, j, k;
                for (g_80 = (-1); (g_80 <= 5); g_80++)
                { /* block id: 26 */
                    int32_t l_118 = 1L;
                    g_126++;
                    if ((l_146 = (0x249AA0F805AAA48DLL == ((((safe_rshift_func_int8_t_s_s((&p_43 != l_131), 0)) & ((((l_132 = (void*)0) != l_133) == ((0xFB5D179AL | (*p_45)) , (safe_rshift_func_uint16_t_u_u(g_126, 1)))) && (safe_sub_func_int16_t_s_s((((safe_div_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s(((safe_mod_func_uint32_t_u_u((g_80 >= 0x5199CEA1L), p_42)) | p_42), 6)), l_122)), g_126)) , (-8L)) < p_43), g_83)))) || p_44) ^ (*p_45)))))
                    { /* block id: 30 */
                        return l_85;
                    }
                    else
                    { /* block id: 32 */
                        (*l_85) = l_124;
                        return l_85;
                    }
                }
            }
        }
        for (g_90 = 3; (g_90 != 49); ++g_90)
        { /* block id: 41 */
            int32_t *l_174[3][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
            int32_t **l_186 = (void*)0;
            int8_t *l_243 = (void*)0;
            int32_t *l_327[6][8][3] = {{{&l_119,&l_125[1],&l_125[1]},{&l_125[1],&g_3,(void*)0},{&l_120,&l_124,(void*)0},{(void*)0,(void*)0,&l_125[1]},{&l_122,&g_83,&l_246},{(void*)0,(void*)0,&g_83},{&l_122,&l_124,&l_124},{&l_122,&g_3,&l_122}},{{(void*)0,&l_125[1],&l_124},{&l_122,&l_122,&l_122},{(void*)0,&l_122,&l_124},{&l_120,&l_122,&g_83},{&l_125[1],&l_122,&l_246},{&l_119,&l_125[1],&l_125[1]},{&l_125[1],&g_3,(void*)0},{&l_120,&l_124,(void*)0}},{{(void*)0,(void*)0,&l_125[1]},{&l_122,&g_83,&l_246},{(void*)0,(void*)0,&g_83},{&l_122,&l_124,&l_124},{&l_122,&g_3,&l_122},{(void*)0,&l_125[1],&l_124},{&l_122,&l_122,&l_122},{(void*)0,&l_122,&l_124}},{{&l_120,&l_122,&l_122},{&l_119,(void*)0,&l_120},{(void*)0,&l_119,&l_119},{&l_119,&l_124,&g_83},{&l_122,&l_125[1],&g_83},{&l_122,&g_83,&l_119},{&l_124,&l_122,&l_120},{&g_83,&g_83,&l_122}},{{(void*)0,&l_125[1],&l_246},{(void*)0,&l_124,&l_124},{&g_83,&l_119,&l_125[1]},{&l_124,(void*)0,&l_124},{&l_122,&g_3,&l_246},{&l_122,&g_3,&l_122},{&l_119,(void*)0,&l_120},{(void*)0,&l_119,&l_119}},{{&l_119,&l_124,&g_83},{&l_122,&l_125[1],&g_83},{&l_122,&g_83,&l_119},{&l_124,&l_122,&l_120},{&g_83,&g_83,&l_122},{(void*)0,&l_125[1],&l_246},{(void*)0,&l_124,&l_124},{&g_83,&l_119,&l_125[1]}}};
            int32_t *l_328 = &l_125[2];
            int32_t *l_330[4];
            uint16_t *l_334 = &g_80;
            int8_t l_523[10];
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_330[i] = &l_125[3];
            for (i = 0; i < 10; i++)
                l_523[i] = 0xE7L;
            for (p_43 = 0; (p_43 >= 20); p_43++)
            { /* block id: 44 */
                int32_t *l_151 = (void*)0;
                int32_t *l_152 = &l_121;
                int32_t *l_154 = &l_122;
                (*l_154) &= ((*l_152) &= 0L);
            }
        }
    }
    (*g_184) = (*g_184);
    return l_595;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_221[i][j][k], "g_221[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_229, "g_229", print_hash_value);
    transparent_crc(g_316.f0, "g_316.f0", print_hash_value);
    transparent_crc(g_316.f2, "g_316.f2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_341[i][j][k], "g_341[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_362, "g_362", print_hash_value);
    transparent_crc(g_396.f0, "g_396.f0", print_hash_value);
    transparent_crc(g_396.f2, "g_396.f2", print_hash_value);
    transparent_crc(g_406, "g_406", print_hash_value);
    transparent_crc(g_487, "g_487", print_hash_value);
    transparent_crc(g_517.f0, "g_517.f0", print_hash_value);
    transparent_crc(g_517.f2, "g_517.f2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_551[i], "g_551[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_553, "g_553", print_hash_value);
    transparent_crc(g_584, "g_584", print_hash_value);
    transparent_crc(g_615.f0, "g_615.f0", print_hash_value);
    transparent_crc(g_615.f2, "g_615.f2", print_hash_value);
    transparent_crc(g_626, "g_626", print_hash_value);
    transparent_crc(g_639, "g_639", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_691[i][j][k], "g_691[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_696.f0, "g_696.f0", print_hash_value);
    transparent_crc(g_696.f2, "g_696.f2", print_hash_value);
    transparent_crc(g_724, "g_724", print_hash_value);
    transparent_crc(g_847, "g_847", print_hash_value);
    transparent_crc(g_952, "g_952", print_hash_value);
    transparent_crc(g_969, "g_969", print_hash_value);
    transparent_crc(g_1114.f0, "g_1114.f0", print_hash_value);
    transparent_crc(g_1114.f2, "g_1114.f2", print_hash_value);
    transparent_crc(g_1138, "g_1138", print_hash_value);
    transparent_crc(g_1199.f0, "g_1199.f0", print_hash_value);
    transparent_crc(g_1199.f2, "g_1199.f2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_1354[i][j], "g_1354[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1394.f0, "g_1394.f0", print_hash_value);
    transparent_crc(g_1394.f2, "g_1394.f2", print_hash_value);
    transparent_crc(g_1436.f0, "g_1436.f0", print_hash_value);
    transparent_crc(g_1436.f2, "g_1436.f2", print_hash_value);
    transparent_crc(g_1440, "g_1440", print_hash_value);
    transparent_crc(g_1517, "g_1517", print_hash_value);
    transparent_crc(g_1626.f0, "g_1626.f0", print_hash_value);
    transparent_crc(g_1626.f2, "g_1626.f2", print_hash_value);
    transparent_crc(g_1709, "g_1709", print_hash_value);
    transparent_crc(g_1749.f0, "g_1749.f0", print_hash_value);
    transparent_crc(g_1749.f2, "g_1749.f2", print_hash_value);
    transparent_crc(g_1760.f0, "g_1760.f0", print_hash_value);
    transparent_crc(g_1760.f2, "g_1760.f2", print_hash_value);
    transparent_crc(g_1792.f0, "g_1792.f0", print_hash_value);
    transparent_crc(g_1792.f2, "g_1792.f2", print_hash_value);
    transparent_crc(g_1833, "g_1833", print_hash_value);
    transparent_crc(g_1843, "g_1843", print_hash_value);
    transparent_crc(g_1940, "g_1940", print_hash_value);
    transparent_crc(g_1990, "g_1990", print_hash_value);
    transparent_crc(g_2011.f0, "g_2011.f0", print_hash_value);
    transparent_crc(g_2011.f2, "g_2011.f2", print_hash_value);
    transparent_crc(g_2034.f0, "g_2034.f0", print_hash_value);
    transparent_crc(g_2034.f2, "g_2034.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 485
XXX total union variables: 15

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 52
breakdown:
   depth: 1, occurrence: 215
   depth: 2, occurrence: 58
   depth: 5, occurrence: 1
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 4
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 2
   depth: 21, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 3
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 36, occurrence: 2
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 52, occurrence: 1

XXX total number of pointers: 462

XXX times a variable address is taken: 1417
XXX times a pointer is dereferenced on RHS: 285
breakdown:
   depth: 1, occurrence: 218
   depth: 2, occurrence: 50
   depth: 3, occurrence: 17
XXX times a pointer is dereferenced on LHS: 242
breakdown:
   depth: 1, occurrence: 217
   depth: 2, occurrence: 19
   depth: 3, occurrence: 5
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 40
XXX times a pointer is compared with address of another variable: 16
XXX times a pointer is compared with another pointer: 15
XXX times a pointer is qualified to be dereferenced: 5907

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1056
   level: 2, occurrence: 354
   level: 3, occurrence: 98
   level: 4, occurrence: 28
XXX number of pointers point to pointers: 161
XXX number of pointers point to scalars: 297
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.3
XXX average alias set size: 1.53

XXX times a non-volatile is read: 1667
XXX times a non-volatile is write: 775
XXX times a volatile is read: 137
XXX    times read thru a pointer: 52
XXX times a volatile is write: 29
XXX    times written thru a pointer: 7
XXX times a volatile is available for access: 3.69e+03
XXX percentage of non-volatile access: 93.6

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 215
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 36
   depth: 1, occurrence: 31
   depth: 2, occurrence: 29
   depth: 3, occurrence: 26
   depth: 4, occurrence: 44
   depth: 5, occurrence: 49

XXX percentage a fresh-made variable is used: 15.5
XXX percentage an existing variable is used: 84.5
********************* end of statistics **********************/

