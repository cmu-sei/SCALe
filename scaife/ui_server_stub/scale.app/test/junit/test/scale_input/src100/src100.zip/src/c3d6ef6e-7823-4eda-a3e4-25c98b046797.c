/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2761995853
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 0x4F833FCBL;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0xF34FDA0EL;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0x951FE77DL;/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = (-3L);
static int32_t g_7 = (-2L);
static int32_t g_37 = 1L;
static int32_t g_61 = 0xD4C46983L;
static int32_t *g_60 = &g_61;
static uint16_t g_68[7] = {0x373CL,0x373CL,0x373CL,0x373CL,0x373CL,0x373CL,0x373CL};
static uint32_t g_71 = 0x4AD44630L;
static uint64_t g_102 = 0x5EF58E71DF66360CLL;
static uint64_t g_104[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static uint8_t g_151 = 1UL;
static uint16_t g_155 = 8UL;
static int32_t g_174 = 3L;
static int32_t * volatile g_173 = &g_174;/* VOLATILE GLOBAL g_173 */
static int32_t ** volatile g_183 = (void*)0;/* VOLATILE GLOBAL g_183 */
static int32_t ** volatile g_188 = &g_60;/* VOLATILE GLOBAL g_188 */
static volatile uint8_t g_195 = 0x56L;/* VOLATILE GLOBAL g_195 */
static volatile int32_t g_211 = 1L;/* VOLATILE GLOBAL g_211 */
static uint16_t g_212 = 1UL;
static int8_t g_252 = 0L;
static int32_t g_271 = (-9L);
static uint64_t *g_279 = &g_102;
static uint64_t **g_278 = &g_279;
static int32_t * volatile g_288 = &g_61;/* VOLATILE GLOBAL g_288 */
static int32_t ** volatile g_310 = &g_60;/* VOLATILE GLOBAL g_310 */
static int16_t g_314 = (-1L);
static volatile int64_t g_320[5][8][6] = {{{0x83748E38710527B9LL,0xEAF47D8385099B4ELL,0xB0D356719CF51B75LL,8L,0L,0x91E52429227F7AEDLL},{(-6L),0xF4F6CBA468E9773BLL,0L,3L,3L,0L},{(-1L),(-1L),0x014A2D4A61B79BA9LL,(-3L),5L,8L},{0x0702EA304488DE92LL,0x82EBA1052F1D853ELL,(-1L),0x91E52429227F7AEDLL,0x49E8291654FE5E0ALL,0x014A2D4A61B79BA9LL},{0x363F34B4380D1C07LL,0x0702EA304488DE92LL,(-1L),(-8L),(-1L),8L},{(-6L),0x7838914F165C230CLL,0xAA1B837C6D80C1CFLL,1L,0L,(-3L)},{1L,0L,(-3L),0x363F34B4380D1C07LL,0xC9FE8F8B71822003LL,0x014A2D4A61B79BA9LL},{0x82EBA1052F1D853ELL,0x49E8291654FE5E0ALL,8L,(-1L),1L,0x363F34B4380D1C07LL}},{{1L,1L,0x91E52429227F7AEDLL,0x83748E38710527B9LL,0x8A2A8A86BFDA8D52LL,0x7838914F165C230CLL},{0x91E52429227F7AEDLL,0L,(-3L),0xEF87003E3035331CLL,(-3L),0L},{3L,0xF075EF67230A18AALL,1L,1L,0x7838914F165C230CLL,0xC9FE8F8B71822003LL},{0xB28CE6065E58DAA2LL,0xEAF47D8385099B4ELL,(-1L),0x1C2AC4045477F4ADLL,(-6L),0x82EBA1052F1D853ELL},{0x1D82569CB5C4F618LL,0xEAF47D8385099B4ELL,(-7L),0L,0x7838914F165C230CLL,(-8L)},{(-10L),0xF075EF67230A18AALL,0xEF87003E3035331CLL,(-6L),(-3L),0xB41CDEEC54CD7775LL},{0xF075EF67230A18AALL,0L,0xEA328A6977314DBCLL,0L,0x8A2A8A86BFDA8D52LL,0xB28CE6065E58DAA2LL},{1L,1L,0L,(-3L),1L,0x49E8291654FE5E0ALL}},{{0xEA328A6977314DBCLL,0x49E8291654FE5E0ALL,0L,(-10L),0xC9FE8F8B71822003LL,(-3L)},{0xF4F6CBA468E9773BLL,0L,3L,3L,0L,0xF4F6CBA468E9773BLL},{(-3L),0x7838914F165C230CLL,5L,0L,0x80CEB50AAFC2DB64LL,0L},{0xC9FE8F8B71822003LL,3L,0x49E8291654FE5E0ALL,(-1L),0xEF87003E3035331CLL,0x5CBCEE99220F0BB0LL},{0xC9FE8F8B71822003LL,0xF4F6CBA468E9773BLL,(-1L),0L,0x1D82569CB5C4F618LL,(-1L)},{(-3L),0x80CEB50AAFC2DB64LL,1L,3L,0xEAF47D8385099B4ELL,1L},{0xF4F6CBA468E9773BLL,(-7L),0x1D82569CB5C4F618LL,(-10L),(-3L),0xF075EF67230A18AALL},{0xEA328A6977314DBCLL,0x5CBCEE99220F0BB0LL,0xC9FE8F8B71822003LL,(-3L),0xB28CE6065E58DAA2LL,(-6L)}},{{1L,3L,1L,0L,0x1C2AC4045477F4ADLL,0x91E52429227F7AEDLL},{0xF075EF67230A18AALL,(-6L),0L,(-6L),0xF075EF67230A18AALL,0xEA328A6977314DBCLL},{(-10L),0x1C2AC4045477F4ADLL,(-8L),0L,0xEA328A6977314DBCLL,4L},{0x1D82569CB5C4F618LL,(-1L),0x8A2A8A86BFDA8D52LL,0x1C2AC4045477F4ADLL,3L,4L},{0xB28CE6065E58DAA2LL,5L,(-8L),1L,0L,0xEA328A6977314DBCLL},{3L,(-1L),0L,0xEF87003E3035331CLL,0xB0D356719CF51B75LL,0x91E52429227F7AEDLL},{0x91E52429227F7AEDLL,1L,1L,0x83748E38710527B9LL,0x014A2D4A61B79BA9LL,(-6L)},{1L,(-8L),0xC9FE8F8B71822003LL,(-1L),0x0702EA304488DE92LL,0xF075EF67230A18AALL}},{{0x82EBA1052F1D853ELL,0xB28CE6065E58DAA2LL,0x1D82569CB5C4F618LL,0x363F34B4380D1C07LL,1L,1L},{1L,1L,1L,1L,(-1L),(-1L)},{(-6L),0xB0D356719CF51B75LL,(-1L),0x7838914F165C230CLL,0L,0x5CBCEE99220F0BB0LL},{(-1L),0x91E52429227F7AEDLL,0x49E8291654FE5E0ALL,0x014A2D4A61B79BA9LL,0L,0L},{3L,0xB0D356719CF51B75LL,5L,1L,(-1L),(-7L)},{0x82EBA1052F1D853ELL,0L,0xEAF47D8385099B4ELL,0x5CBCEE99220F0BB0LL,0x8A2A8A86BFDA8D52LL,0xB0D356719CF51B75LL},{0xB41CDEEC54CD7775LL,0x91E52429227F7AEDLL,(-3L),0x1D82569CB5C4F618LL,3L,0xEF87003E3035331CLL},{(-10L),0x7838914F165C230CLL,0xB28CE6065E58DAA2LL,0x49E8291654FE5E0ALL,0xAA1B837C6D80C1CFLL,0x91E52429227F7AEDLL}}};
static int16_t g_324 = 0xA1D4L;
static int32_t g_325 = 0x9F678E49L;
static int64_t g_350 = 0xCA9D412B1CDF8BA9LL;
static int8_t g_352 = 0x49L;
static int32_t ** volatile g_421[1][10] = {{&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60,&g_60}};
static int32_t ** volatile g_422 = (void*)0;/* VOLATILE GLOBAL g_422 */
static int32_t ** volatile g_425 = &g_60;/* VOLATILE GLOBAL g_425 */
static int32_t ** volatile g_427 = &g_60;/* VOLATILE GLOBAL g_427 */
static volatile uint16_t *g_432 = (void*)0;
static volatile uint16_t **g_431 = &g_432;
static int32_t ** volatile g_478 = &g_60;/* VOLATILE GLOBAL g_478 */
static uint32_t *g_507 = &g_71;
static uint32_t * volatile *g_506 = &g_507;
static int32_t ** volatile g_508 = &g_60;/* VOLATILE GLOBAL g_508 */
static int32_t ** const  volatile g_510 = (void*)0;/* VOLATILE GLOBAL g_510 */
static const int32_t *g_601 = (void*)0;
static const int32_t ** volatile g_600[8] = {&g_601,&g_601,&g_601,&g_601,&g_601,&g_601,&g_601,&g_601};
static const int32_t ** volatile g_602 = &g_601;/* VOLATILE GLOBAL g_602 */
static uint32_t *g_672 = &g_71;
static int64_t g_676 = 2L;
static int16_t *g_693[10] = {&g_314,&g_314,&g_314,&g_314,&g_314,&g_314,&g_314,&g_314,&g_314,&g_314};
static int32_t * volatile *g_721 = &g_60;
static int32_t * volatile **g_720 = &g_721;
static int8_t *g_805 = (void*)0;
static int8_t * const *g_804 = &g_805;
static int8_t * const **g_803 = &g_804;
static uint32_t g_826 = 0x2D130F7BL;
static int8_t **g_846 = &g_805;
static int8_t ***g_845 = &g_846;
static volatile uint64_t g_1037 = 18446744073709551613UL;/* VOLATILE GLOBAL g_1037 */
static volatile uint64_t *g_1036 = &g_1037;
static volatile uint64_t **g_1035 = &g_1036;
static volatile uint64_t ***g_1034 = &g_1035;
static volatile uint64_t ****g_1033[6][7][3] = {{{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0},{(void*)0,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034}},{{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{(void*)0,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0},{(void*)0,&g_1034,&g_1034}},{{&g_1034,&g_1034,(void*)0},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0}},{{(void*)0,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{(void*)0,&g_1034,&g_1034}},{{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0},{(void*)0,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034}},{{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,(void*)0},{(void*)0,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034},{&g_1034,&g_1034,&g_1034}}};
static int32_t *g_1066 = &g_6;
static int32_t ** volatile g_1065 = &g_1066;/* VOLATILE GLOBAL g_1065 */
static int32_t ** volatile *g_1083 = &g_1065;
static int32_t ** volatile * volatile *g_1082 = &g_1083;
static int32_t ** volatile * volatile ** volatile g_1081 = &g_1082;/* VOLATILE GLOBAL g_1081 */
static uint32_t g_1086 = 0xA223DDBFL;
static int32_t ** volatile g_1145 = &g_60;/* VOLATILE GLOBAL g_1145 */
static int32_t ** volatile g_1172 = (void*)0;/* VOLATILE GLOBAL g_1172 */
static int32_t ** volatile g_1173 = &g_1066;/* VOLATILE GLOBAL g_1173 */
static uint32_t **g_1188 = &g_507;
static uint32_t ***g_1187 = &g_1188;
static int32_t g_1282 = 0x4A21D715L;
static uint64_t g_1332 = 0UL;
static uint8_t *g_1440 = &g_151;
static uint8_t ** volatile g_1439 = &g_1440;/* VOLATILE GLOBAL g_1439 */
static uint64_t **g_1465 = &g_279;
static uint8_t g_1518 = 2UL;
static int32_t * const * const g_1588 = &g_60;
static int32_t * const * const *g_1587 = &g_1588;
static int32_t * const * const **g_1586 = &g_1587;
static int64_t *g_1637 = &g_350;
static int32_t g_1705 = (-1L);
static int64_t g_1709 = 0xD8EB2B96A021BB3DLL;
static const int8_t *g_1781 = &g_352;
static const int8_t **g_1780 = &g_1781;
static const int8_t ***g_1779[7][1] = {{&g_1780},{&g_1780},{&g_1780},{&g_1780},{&g_1780},{&g_1780},{&g_1780}};
static const int8_t ****g_1778 = &g_1779[0][0];
static int8_t * const * const *g_1819[8][1] = {{(void*)0},{&g_804},{(void*)0},{&g_804},{(void*)0},{&g_804},{(void*)0},{&g_804}};
static volatile uint16_t g_1859[3] = {65535UL,65535UL,65535UL};
static volatile int64_t g_1906 = 9L;/* VOLATILE GLOBAL g_1906 */
static uint32_t * const *g_1910 = &g_507;
static uint32_t * const * const *g_1909 = &g_1910;
static const uint16_t *g_1945 = &g_68[4];
static const uint16_t **g_1944 = &g_1945;
static volatile uint32_t g_2009 = 0UL;/* VOLATILE GLOBAL g_2009 */
static uint8_t **g_2020 = &g_1440;
static uint8_t ***g_2019 = &g_2020;
static int16_t g_2051 = (-1L);
static const int32_t ** volatile g_2100 = &g_601;/* VOLATILE GLOBAL g_2100 */
static const uint8_t g_2127 = 1UL;
static const uint8_t *g_2126 = &g_2127;
static const uint8_t **g_2125[10] = {&g_2126,&g_2126,&g_2126,&g_2126,&g_2126,&g_2126,&g_2126,&g_2126,&g_2126,&g_2126};
static const uint8_t ***g_2124 = &g_2125[3];
static uint16_t g_2160 = 3UL;
static const uint32_t *g_2257[3][5] = {{&g_1086,&g_1086,&g_1086,&g_1086,&g_1086},{&g_826,&g_826,&g_826,&g_826,&g_826},{&g_1086,&g_1086,&g_1086,&g_1086,&g_1086}};
static const uint32_t **g_2256 = &g_2257[0][3];
static const uint32_t ** const *g_2255 = &g_2256;
static const uint32_t ** const **g_2254 = &g_2255;
static volatile uint8_t g_2309 = 0x11L;/* VOLATILE GLOBAL g_2309 */
static uint16_t *g_2316 = &g_155;
static uint16_t **g_2315 = &g_2316;
static uint16_t ***g_2314[10] = {&g_2315,&g_2315,&g_2315,&g_2315,&g_2315,&g_2315,&g_2315,&g_2315,&g_2315,&g_2315};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_8(int32_t  p_9, int64_t  p_10, uint32_t  p_11, uint32_t  p_12);
static int64_t  func_13(uint8_t  p_14, int16_t  p_15, int32_t  p_16, int32_t  p_17);
static uint16_t  func_19(int32_t  p_20, int8_t  p_21, int16_t  p_22, uint64_t  p_23, uint16_t  p_24);
static int8_t  func_27(uint16_t  p_28, int8_t  p_29, const uint32_t  p_30, uint64_t  p_31, int8_t  p_32);
static uint32_t  func_33(int32_t  p_34, int32_t  p_35);
static int8_t  func_40(uint32_t  p_41, const uint16_t  p_42, int8_t  p_43, const int16_t  p_44, uint8_t  p_45);
static uint32_t  func_46(uint32_t  p_47);
static int8_t  func_50(uint32_t  p_51, int8_t  p_52, uint32_t  p_53);
static int16_t  func_56(int32_t * p_57, int32_t * p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_37 g_5 g_61 g_71 g_4 g_68 g_151 g_3 g_155 g_195 g_174 g_60 g_212 g_102 g_507 g_278 g_279 g_324 g_104 g_271 g_352 g_506 g_314 g_320 g_602 g_288 g_325 g_672 g_676 g_211 g_350 g_720 g_721 g_601 g_252 g_803 g_845 g_431 g_432 g_173 g_804 g_1086 g_1465 g_1705 g_1637 g_1709 g_1034 g_1035 g_1036 g_1037 g_1439 g_1440 g_826 g_1083 g_1065 g_1778 g_1780 g_1781 g_1779 g_1819 g_1187 g_1188 g_1859 g_1282 g_1906 g_1909 g_1944 g_1945 g_2009 g_1145 g_2019 g_2020 g_2100 g_1082 g_2160 g_1081 g_1587 g_1588 g_2126 g_2127 g_2254 g_2309 g_2314 g_2315 g_2316 g_1066
 * writes: g_6 g_7 g_37 g_60 g_68 g_71 g_61 g_102 g_104 g_151 g_155 g_195 g_212 g_324 g_601 g_325 g_314 g_350 g_672 g_676 g_693 g_271 g_803 g_826 g_845 g_1705 g_1709 g_1066 g_1778 g_1332 g_1909 g_1086 g_1944 g_1282 g_2009 g_1440 g_352 g_2124 g_2019 g_2309
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_2[1];
    int32_t *l_59[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_2348[1][2][2];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2[i] = 252UL;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 2; k++)
                l_2348[i][j][k] = (-1L);
        }
    }
    for (g_6 = 0; (g_6 <= 0); g_6 += 1)
    { /* block id: 3 */
        const int32_t l_578[1][9] = {{0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL,0x5720F30AL}};
        int16_t l_2015 = (-1L);
        uint32_t l_2143 = 4294967294UL;
        uint8_t l_2163 = 1UL;
        int i, j;
        for (g_7 = 0; (g_7 <= 0); g_7 += 1)
        { /* block id: 6 */
            int32_t *l_36 = &g_37;
            int8_t l_72[7][4] = {{0L,0x0CL,0x0CL,0L},{(-7L),0x0CL,0x4BL,0x0CL},{0x0CL,(-1L),0x4BL,0x4BL},{(-7L),(-7L),0x0CL,0x4BL},{0L,(-1L),0L,0x0CL},{0L,0x0CL,0x0CL,0L},{(-7L),0x0CL,0x4BL,0x0CL}};
            int8_t l_579 = 0x15L;
            int i, j;
            (*l_36) = func_8(l_2[g_7], func_13((+((func_19(l_2[0], (((l_2[0] > (((safe_add_func_int8_t_s_s(func_27(l_2[g_7], ((func_33(((*l_36) &= 0xC43CC9F1L), (safe_mod_func_int8_t_s_s(func_40((func_46((safe_mul_func_int8_t_s_s(g_7, func_50(g_6, (((l_72[3][1] = (safe_mul_func_int16_t_s_s(func_56(&g_6, (g_60 = l_59[2])), g_7))) , 0L) && 65527UL), g_6)))) , 0xCFAE0491L), l_578[0][6], g_352, l_578[0][3], l_579), g_252))) > 0x8111D62DL) >= l_578[0][2]), g_1086, l_578[0][6], l_578[0][6]), 0x3BL)) != 7L) >= 18446744073709551615UL)) , 18446744073709551608UL) | g_352), g_352, l_2015, g_7) != g_252) || 7UL)), l_2143, l_578[0][6], l_579), l_2015, l_2163);
            (**g_720) = ((***g_1082) = (*g_1065));
            return l_578[0][6];
        }
    }
    (**g_1083) = (***g_1082);
    return l_2348[0][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_720 g_721 g_37 g_1587 g_1588 g_60 g_7 g_1944 g_1945 g_68 g_507 g_71 g_1637 g_320 g_278 g_279 g_2126 g_2127 g_1781 g_352 g_2254 g_1465 g_2309 g_2314 g_2315 g_2316 g_155 g_288 g_1282 g_2020 g_1440 g_151
 * writes: g_60 g_37 g_71 g_350 g_102 g_1086 g_352 g_2309 g_61 g_151
 */
static int32_t  func_8(int32_t  p_9, int64_t  p_10, uint32_t  p_11, uint32_t  p_12)
{ /* block id: 1025 */
    int32_t *l_2164 = &g_7;
    int32_t **l_2169 = &g_60;
    int32_t ***l_2168 = &l_2169;
    int32_t ****l_2167 = &l_2168;
    int32_t *****l_2166 = &l_2167;
    int32_t ****** const l_2165 = &l_2166;
    int32_t ******l_2171 = &l_2166;
    int32_t *******l_2170 = &l_2171;
    uint32_t ****l_2199 = &g_1187;
    int32_t l_2237 = 0L;
    int32_t l_2240 = (-1L);
    int32_t l_2241 = 4L;
    int32_t l_2249 = (-6L);
    int32_t l_2250 = 0xD1158603L;
    int8_t *l_2281 = &g_252;
    int8_t *l_2282 = &g_352;
    uint16_t ***l_2318 = (void*)0;
    uint16_t ***l_2319 = &g_2315;
    uint64_t **l_2323 = &g_279;
    int8_t *****l_2339 = (void*)0;
    int16_t l_2345[4][4] = {{0x0AF9L,0x0AF9L,1L,0x0AF9L},{0x0AF9L,0xDE53L,0xDE53L,0x0AF9L},{0xDE53L,0x0AF9L,0xDE53L,0xDE53L},{0x0AF9L,0x0AF9L,1L,0x0AF9L}};
    int i, j;
lbl_2172:
    (**g_720) = l_2164;
    p_9 |= (l_2165 != ((*l_2170) = &l_2166));
    if (p_9)
        goto lbl_2172;
    for (g_37 = 0; (g_37 <= (-16)); g_37 = safe_sub_func_uint8_t_u_u(g_37, 5))
    { /* block id: 1032 */
        uint16_t *l_2201 = &g_68[5];
        uint16_t **l_2200 = &l_2201;
        int32_t l_2202 = (-4L);
        int16_t l_2230 = 1L;
        int32_t l_2239 = 1L;
        int32_t l_2242 = 0L;
        int32_t l_2244 = 0x81F51DAEL;
        int32_t l_2246 = 0x4AD88483L;
        int32_t l_2247 = 4L;
        int32_t l_2248[10][6][4] = {{{(-1L),(-6L),0L,0L},{0L,0L,(-1L),(-1L)},{2L,0x0384DCBFL,0x0384DCBFL,2L},{0x3045976CL,(-2L),(-1L),0x7458D748L},{0L,(-1L),2L,(-6L)},{1L,0x9BA55158L,0L,(-6L)}},{{0x675A0162L,(-1L),(-7L),0x7458D748L},{0x0384DCBFL,(-2L),0x675A0162L,2L},{(-1L),0x0384DCBFL,1L,(-1L)},{(-2L),0L,0xB9D72A83L,0L},{(-1L),(-6L),0x9BA55158L,0L},{0x6224FF56L,0xEAC40FABL,0L,0x0384DCBFL}},{{(-1L),(-2L),(-6L),1L},{(-1L),1L,0L,0x6224FF56L},{0x6224FF56L,1L,0x9BA55158L,(-1L)},{(-1L),0x43D7BC00L,0xB9D72A83L,(-1L)},{(-2L),0xB9D72A83L,1L,1L},{(-1L),(-1L),0x675A0162L,0xEAC40FABL}},{{0x0384DCBFL,0L,(-7L),(-2L)},{0x675A0162L,0L,0L,(-7L)},{1L,0L,2L,(-2L)},{0L,0L,(-1L),0xEAC40FABL},{0x3045976CL,(-1L),0x0384DCBFL,1L},{2L,0xB9D72A83L,(-1L),(-1L)}},{{0L,1L,1L,0x7458D748L},{1L,0L,(-1L),0x0384DCBFL},{8L,0xB9D72A83L,(-5L),0L},{(-1L),(-1L),(-5L),(-1L)},{8L,1L,(-1L),(-6L)},{1L,0L,1L,8L}},{{1L,8L,0x9BA55158L,0xEAC40FABL},{(-1L),(-1L),(-1L),(-1L)},{0x6224FF56L,(-7L),1L,0L},{0x675A0162L,0x9BA55158L,(-1L),0L},{0xB9D72A83L,(-1L),8L,0L},{(-2L),0x9BA55158L,2L,0L}},{{(-1L),(-7L),(-2L),(-1L)},{0x7458D748L,(-1L),0x3045976CL,0xEAC40FABL},{(-1L),8L,(-2L),8L},{0x43D7BC00L,0L,(-1L),(-6L)},{0x0384DCBFL,1L,(-6L),(-1L)},{0xEAC40FABL,(-1L),0L,0L}},{{0xEAC40FABL,0xB9D72A83L,(-6L),0x0384DCBFL},{0x0384DCBFL,0L,(-1L),0x7458D748L},{0x43D7BC00L,1L,(-2L),1L},{(-1L),(-2L),0x3045976CL,0x3045976CL},{0x7458D748L,0x7458D748L,(-2L),1L},{(-1L),1L,2L,(-7L)}},{{(-2L),0x675A0162L,8L,2L},{0xB9D72A83L,0x675A0162L,(-1L),(-7L)},{0x675A0162L,1L,1L,1L},{0x6224FF56L,0x7458D748L,(-1L),0x3045976CL},{(-1L),(-2L),0x9BA55158L,1L},{1L,1L,1L,0x7458D748L}},{{1L,0L,(-1L),0x0384DCBFL},{8L,0xB9D72A83L,(-5L),0L},{(-1L),(-1L),(-5L),(-1L)},{8L,1L,(-1L),(-6L)},{1L,0L,1L,8L},{1L,8L,0x9BA55158L,0xEAC40FABL}}};
        int8_t *l_2280 = &g_352;
        uint16_t l_2284 = 65528UL;
        int64_t l_2287[1];
        int8_t * const ***l_2300[6][2] = {{&g_803,(void*)0},{&g_803,&g_803},{(void*)0,&g_803},{&g_803,(void*)0},{&g_803,&g_803},{&g_803,(void*)0}};
        int8_t * const ****l_2299 = &l_2300[5][1];
        int32_t *l_2313 = &g_1282;
        int8_t l_2322 = 0L;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2287[i] = (-8L);
        if ((***g_1587))
        { /* block id: 1033 */
            const uint32_t *l_2198 = &g_826;
            const uint32_t **l_2197[4][2][10] = {{{(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198},{&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198}},{{(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198},{&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198}},{{(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198},{&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198}},{{(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198,(void*)0,&l_2198},{&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198,&l_2198}}};
            const uint32_t ***l_2196 = &l_2197[1][1][4];
            const uint32_t *** const *l_2195[7];
            int32_t l_2203[5][8][6] = {{{7L,0xB7C98866L,0x442A6A96L,0x13C2C1F5L,2L,0x75A10F1FL},{0x442A6A96L,0x74950AEDL,0xBEF76B2DL,0xB7C98866L,0x1DA292AEL,0x75A10F1FL},{1L,0L,0x442A6A96L,0x442A6A96L,0L,1L},{0x1DA292AEL,0x73C4B365L,2L,0x9B3C4E9FL,7L,0L},{0x73C4B365L,0xBEF76B2DL,7L,0xC85E2BC5L,(-1L),0x7C8EB9C2L},{0x73C4B365L,0x13C2C1F5L,0xC85E2BC5L,0x9B3C4E9FL,0xC85E2BC5L,0x13C2C1F5L},{0x1DA292AEL,7L,0xB7C98866L,0x442A6A96L,0x13C2C1F5L,2L},{1L,(-7L),0x9B3C4E9FL,0xB7C98866L,0x75A10F1FL,0xC85E2BC5L}},{{0x442A6A96L,(-7L),0x74950AEDL,0x13C2C1F5L,0x13C2C1F5L,0x74950AEDL},{7L,7L,(-7L),5L,0xC85E2BC5L,0x73C4B365L},{0xBEF76B2DL,0x13C2C1F5L,0x7C8EB9C2L,1L,(-1L),(-7L)},{0x75A10F1FL,0xBEF76B2DL,0x7C8EB9C2L,0x73C4B365L,7L,0x73C4B365L},{(-7L),0x73C4B365L,(-7L),2L,0L,0x74950AEDL},{2L,0L,0x74950AEDL,(-1L),0x1DA292AEL,0xC85E2BC5L},{5L,0x74950AEDL,0x9B3C4E9FL,(-1L),2L,2L},{2L,0xB7C98866L,0xB7C98866L,2L,0xBEF76B2DL,0x13C2C1F5L}},{{(-7L),5L,0xC85E2BC5L,0x73C4B365L,0x9B3C4E9FL,0x7C8EB9C2L},{0x75A10F1FL,(-1L),7L,1L,0x9B3C4E9FL,0L},{0xBEF76B2DL,5L,2L,5L,0xBEF76B2DL,1L},{7L,0xB7C98866L,0x442A6A96L,0x13C2C1F5L,2L,0x75A10F1FL},{0x442A6A96L,0x74950AEDL,0xBEF76B2DL,0xB7C98866L,0x1DA292AEL,0x75A10F1FL},{1L,0L,0x442A6A96L,0x442A6A96L,0L,1L},{0x1DA292AEL,0x73C4B365L,2L,0x9B3C4E9FL,7L,0L},{0x73C4B365L,0xBEF76B2DL,7L,0xC85E2BC5L,(-1L),0x7C8EB9C2L}},{{0x73C4B365L,0x13C2C1F5L,0xC85E2BC5L,0x442A6A96L,0xBEF76B2DL,0xC85E2BC5L},{0x13C2C1F5L,0x75A10F1FL,7L,2L,0xC85E2BC5L,(-7L)},{0x9B3C4E9FL,0x1DA292AEL,0x442A6A96L,7L,0xC23F92ABL,0xBEF76B2DL},{2L,0x1DA292AEL,1L,0xC85E2BC5L,0xC85E2BC5L,1L},{0x75A10F1FL,0x75A10F1FL,0x1DA292AEL,0xB7C98866L,0xBEF76B2DL,0x74950AEDL},{5L,0xC85E2BC5L,0x73C4B365L,0x9B3C4E9FL,0x7C8EB9C2L,0x1DA292AEL},{0xC23F92ABL,5L,0x73C4B365L,0x74950AEDL,0x75A10F1FL,0x74950AEDL},{0x1DA292AEL,0x74950AEDL,0x1DA292AEL,(-7L),(-1L),1L}},{{(-7L),(-1L),1L,0x7C8EB9C2L,0x13C2C1F5L,0xBEF76B2DL},{0xB7C98866L,1L,0x442A6A96L,0x7C8EB9C2L,(-7L),(-7L)},{(-7L),7L,7L,(-7L),5L,0xC85E2BC5L},{0x1DA292AEL,0xB7C98866L,0xBEF76B2DL,0x74950AEDL,0x442A6A96L,0x73C4B365L},{0xC23F92ABL,0x7C8EB9C2L,0x75A10F1FL,0x9B3C4E9FL,0x442A6A96L,(-1L)},{5L,0xB7C98866L,(-7L),0xB7C98866L,5L,0x9B3C4E9FL},{0x75A10F1FL,7L,2L,0xC85E2BC5L,(-7L),0xC23F92ABL},{2L,1L,5L,7L,0x13C2C1F5L,0xC23F92ABL}}};
            uint16_t l_2251[2][9] = {{0UL,1UL,0UL,1UL,0UL,1UL,0UL,1UL,0UL},{0xC543L,0xC543L,0x3BDCL,0x3BDCL,0xC543L,0xC543L,0x3BDCL,0x3BDCL,0xC543L}};
            int32_t l_2283 = 0xD1AA2951L;
            int32_t **l_2302 = &g_1066;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_2195[i] = &l_2196;
            for (g_71 = 0; (g_71 != 57); g_71 = safe_add_func_uint64_t_u_u(g_71, 7))
            { /* block id: 1036 */
                const uint16_t l_2177 = 0x9595L;
                uint8_t * const *l_2192 = &g_1440;
                int32_t l_2224 = 0x7D866BE3L;
                int32_t l_2226 = 0xF2E25357L;
                int32_t l_2228[8];
                const uint32_t ** const **l_2259[5] = {&g_2255,&g_2255,&g_2255,&g_2255,&g_2255};
                uint32_t *l_2263 = &g_1086;
                int i;
                for (i = 0; i < 8; i++)
                    l_2228[i] = 8L;
                if ((l_2177 != (safe_mod_func_int8_t_s_s((safe_mod_func_int32_t_s_s((3L & (safe_mul_func_uint16_t_u_u(p_9, (safe_mul_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((p_12 , (safe_add_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((((void*)0 == l_2192) ^ ((((p_11 | (l_2195[0] != l_2199)) , 0x60CEC170C2C2C0AELL) , l_2200) == (void*)0)), p_11)), p_9))), p_12)), p_10))))), p_11)), p_11))))
                { /* block id: 1037 */
                    return l_2202;
                }
                else
                { /* block id: 1039 */
                    int64_t *l_2223[9][9] = {{&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676},{&g_676,&g_1709,&g_676,&g_676,&g_1709,&g_676,&g_1709,&g_676,&g_676},{&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676},{&g_676,&g_1709,&g_676,&g_676,&g_676,&g_676,&g_1709,&g_676,&g_676},{&g_676,&g_676,&g_676,&g_676,&g_1709,&g_676,&g_676,&g_676,&g_676},{&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676},{&g_676,&g_1709,&g_676,&g_676,&g_1709,&g_676,&g_1709,&g_676,&g_676},{&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676},{&g_676,&g_1709,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676,&g_676}};
                    uint64_t *l_2225 = (void*)0;
                    int8_t *l_2227[3][9][3] = {{{&g_252,&g_252,&g_352},{(void*)0,&g_352,&g_352},{&g_252,&g_352,&g_252},{&g_252,&g_352,&g_352},{&g_252,&g_252,&g_352},{(void*)0,&g_352,(void*)0},{&g_352,&g_352,&g_352},{(void*)0,&g_352,(void*)0},{&g_252,&g_252,&g_352}},{{&g_252,&g_352,(void*)0},{&g_252,&g_252,&g_352},{(void*)0,&g_352,&g_352},{&g_252,&g_352,&g_252},{&g_252,&g_352,&g_352},{&g_252,&g_252,&g_352},{(void*)0,&g_352,(void*)0},{&g_352,&g_352,&g_352},{(void*)0,&g_352,(void*)0}},{{&g_252,&g_252,&g_352},{&g_252,&g_352,(void*)0},{&g_252,&g_252,&g_352},{(void*)0,&g_352,&g_352},{&g_252,&g_352,&g_252},{&g_252,&g_352,&g_352},{&g_252,&g_252,&g_352},{(void*)0,&g_352,(void*)0},{&g_352,&g_352,&g_352}}};
                    int32_t l_2229 = 0L;
                    int32_t l_2236 = 0x980A009BL;
                    int32_t l_2238 = 5L;
                    int32_t l_2243[3][3][8] = {{{0x51ED61BDL,(-1L),0xB04F07EDL,0x4947F4C9L,0xB04F07EDL,(-1L),0x51ED61BDL,0x51ED61BDL},{(-1L),0x4947F4C9L,9L,9L,0x4947F4C9L,(-1L),5L,(-1L)},{0x4947F4C9L,(-1L),5L,(-1L),0x4947F4C9L,9L,9L,0x4947F4C9L}},{{(-1L),0x51ED61BDL,0x51ED61BDL,(-1L),0xB04F07EDL,0x4947F4C9L,0xB04F07EDL,(-1L)},{0x51ED61BDL,0xB04F07EDL,0x51ED61BDL,9L,5L,5L,9L,0x51ED61BDL},{0xB04F07EDL,0xB04F07EDL,5L,0x4947F4C9L,0xBA9A1502L,0x4947F4C9L,5L,0xB04F07EDL}},{{0xB04F07EDL,0x51ED61BDL,9L,5L,5L,9L,0x51ED61BDL,0xB04F07EDL},{0x51ED61BDL,(-1L),0xB04F07EDL,0x4947F4C9L,0xB04F07EDL,(-1L),0x51ED61BDL,0x51ED61BDL},{(-1L),0x4947F4C9L,9L,9L,0x4947F4C9L,(-1L),5L,(-1L)}}};
                    uint32_t ****l_2260 = &g_1187;
                    int32_t **l_2290 = &g_1066;
                    int8_t * const ** const *l_2298 = &g_803;
                    int8_t * const ** const **l_2297 = &l_2298;
                    int8_t * const *****l_2301 = &l_2299;
                    int i, j, k;
                    if (((l_2203[1][4][4] , ((l_2228[6] = ((p_10 >= ((l_2226 = (l_2224 = ((l_2202 = (((**g_1944) , p_10) , ((safe_mod_func_uint8_t_u_u(l_2177, (safe_mod_func_int64_t_s_s(l_2202, (safe_mul_func_int8_t_s_s(((safe_add_func_int32_t_s_s((p_9 |= (safe_rshift_func_uint16_t_u_s((p_10 || (0x53L != (safe_rshift_func_uint16_t_u_s(((((safe_div_func_uint16_t_u_u((((((**g_278) = (safe_sub_func_uint8_t_u_u((!(safe_add_func_int64_t_s_s(((*g_1637) = ((*g_507) && (*l_2164))), g_320[0][6][3]))), p_12))) | l_2203[1][4][4]) > (-1L)) >= l_2177), l_2177)) , 0x31L) >= (*g_2126)) , 0xEFD3L), 11)))), 15))), l_2177)) >= 0xCD7E8AF4L), 9UL)))))) != 1L))) , p_12))) , 0x6D9AL)) <= l_2177)) <= (*g_1781))) <= l_2203[3][2][4]))
                    { /* block id: 1047 */
                        return p_11;
                    }
                    else
                    { /* block id: 1049 */
                        int32_t *l_2231 = &l_2202;
                        int32_t l_2232[9] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
                        int32_t *l_2233 = &l_2232[6];
                        int32_t *l_2234 = &l_2203[0][7][2];
                        int32_t *l_2235[4] = {&l_2228[7],&l_2228[7],&l_2228[7],&l_2228[7]};
                        int8_t l_2245 = 8L;
                        const uint32_t ** const ***l_2258[8] = {&g_2254,&g_2254,(void*)0,&g_2254,&g_2254,(void*)0,&g_2254,&g_2254};
                        int i;
                        (*****l_2165) = (void*)0;
                        --l_2251[0][0];
                        (*l_2169) = &p_9;
                        (*l_2231) = (((l_2259[3] = g_2254) != (l_2260 = &g_1187)) == (safe_div_func_uint8_t_u_u((l_2263 == &p_11), (safe_rshift_func_uint16_t_u_s((((safe_mul_func_int8_t_s_s((((safe_mod_func_uint32_t_u_u((l_2243[2][2][0] = ((*l_2263) = 4294967295UL)), (l_2283 = ((******l_2171) = (safe_unary_minus_func_int16_t_s(((!0x67063A38L) != (0x5D9EL < (safe_sub_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u((safe_div_func_uint8_t_u_u(((l_2281 = l_2280) != l_2282), p_11)), p_9)), 0)), p_12)))))))))) | l_2284) >= p_10), p_12)) ^ p_10) && 0xF08B4341B7BB0A47LL), p_12)))));
                    }
                    (*******l_2170) = ((l_2228[6] &= l_2251[0][0]) >= (l_2287[0] > ((((*l_2280) = p_11) <= (((safe_add_func_int32_t_s_s(p_11, (l_2290 == (((((safe_div_func_int8_t_s_s((safe_add_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((**g_1465) = 0xAE73271B7A98AC2ALL), ((l_2297 == ((*l_2301) = l_2299)) , p_12))), 0x7EACL)), 0x91L)) <= 0x65C71CB4DA31F3C0LL) >= 0x9AF88CA0L) , l_2283) , l_2302)))) ^ p_11) , 0L)) && 0xCCF8792DCC35E3A8LL)));
                    if ((!(*g_60)))
                    { /* block id: 1067 */
                        return p_9;
                    }
                    else
                    { /* block id: 1069 */
                        int16_t l_2304 = 0x500EL;
                        return l_2304;
                    }
                }
            }
            for (l_2241 = 0; (l_2241 != (-8)); l_2241 = safe_sub_func_uint32_t_u_u(l_2241, 4))
            { /* block id: 1076 */
                int32_t *l_2307 = &l_2203[4][6][1];
                int32_t *l_2308[6] = {&l_2203[1][4][4],&l_2203[1][4][4],&l_2203[1][4][4],&l_2203[1][4][4],&l_2203[1][4][4],&l_2203[1][4][4]};
                int i;
                ++g_2309;
                for (l_2237 = 0; l_2237 < 7; l_2237 += 1)
                {
                    l_2195[l_2237] = &l_2196;
                }
            }
        }
        else
        { /* block id: 1080 */
            int32_t **l_2312[10] = {&g_1066,&l_2164,&g_1066,&g_1066,&g_1066,&g_1066,&g_1066,&g_1066,&g_1066,&g_1066};
            uint16_t ****l_2317[9] = {&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3],&g_2314[3]};
            int i;
            l_2313 = (p_10 , (*g_1588));
            (*g_288) = (l_2248[6][1][2] = ((((l_2318 = g_2314[3]) == l_2319) != ((safe_mod_func_int64_t_s_s(0xF5F659AAA169EB8DLL, ((p_9 &= ((-1L) ^ (l_2322 > (**g_2315)))) || ((void*)0 != l_2323)))) & (*l_2313))) && 0xEECBL));
        }
        for (l_2247 = 0; (l_2247 == 6); l_2247++)
        { /* block id: 1089 */
            uint64_t l_2342 = 0x2AB584C4E0845B2DLL;
            uint16_t l_2343 = 0xF77BL;
            uint64_t ****l_2344 = (void*)0;
            int8_t l_2346 = 0x70L;
            int32_t l_2347 = 0xE6849EDDL;
            l_2347 ^= ((safe_mod_func_uint16_t_u_u(((!((safe_mul_func_uint16_t_u_u((&p_10 == &p_10), ((((**g_2020) |= ((((safe_rshift_func_int16_t_s_u((*l_2313), (safe_mod_func_int16_t_s_s(p_12, 0xA490L)))) , ((((safe_lshift_func_int16_t_s_u(((safe_sub_func_int8_t_s_s((((l_2339 == (void*)0) , ((*l_2280) = ((******l_2165) > ((((safe_mod_func_uint64_t_u_u(((((((p_11 & (*g_1945)) , (void*)0) != (void*)0) <= l_2342) > l_2343) > p_11), 0x8CAA16ED19C2124ALL)) , l_2344) != (void*)0) && p_11)))) < 0xCFL), p_10)) <= p_9), p_11)) < (*l_2313)) || (-9L)) ^ p_11)) && p_12) <= 0xC060L)) , l_2345[1][1]) >= (*l_2313)))) || p_9)) & l_2346), l_2346)) && 6L);
            return (*******l_2170);
        }
        if ((******l_2171))
            break;
    }
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_1082 g_1083 g_1065 g_721 g_507 g_71 g_2160 g_1282 g_1081 g_278 g_279 g_102 g_271
 * writes: g_1066 g_60 g_102 g_271
 */
static int64_t  func_13(uint8_t  p_14, int16_t  p_15, int32_t  p_16, int32_t  p_17)
{ /* block id: 1018 */
    int32_t *l_2144 = (void*)0;
    int32_t *l_2145 = &g_1282;
    int32_t *l_2146 = &g_271;
    int32_t *l_2147 = &g_61;
    int32_t *l_2148 = &g_61;
    int32_t *l_2149[7];
    uint32_t l_2150 = 0x5D6BF465L;
    uint8_t l_2157 = 0x2DL;
    uint8_t ** const *l_2162[6][2][3] = {{{(void*)0,&g_2020,&g_2020},{&g_2020,&g_2020,&g_2020}},{{&g_2020,(void*)0,&g_2020},{&g_2020,(void*)0,&g_2020}},{{&g_2020,&g_2020,&g_2020},{&g_2020,(void*)0,&g_2020}},{{(void*)0,(void*)0,&g_2020},{&g_2020,&g_2020,&g_2020}},{{(void*)0,&g_2020,&g_2020},{&g_2020,&g_2020,&g_2020}},{{&g_2020,(void*)0,&g_2020},{&g_2020,(void*)0,&g_2020}}};
    uint8_t ** const **l_2161 = &l_2162[0][1][1];
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_2149[i] = &g_271;
    (***g_1082) = l_2144;
    (*g_721) = &p_16;
    --l_2150;
    (*l_2146) |= ((6L > ((**g_278) ^= ((*g_507) , (((p_15 | (safe_add_func_int8_t_s_s((safe_mul_func_int8_t_s_s(l_2157, p_16)), (((safe_add_func_int64_t_s_s((g_2160 != p_16), (*l_2145))) , &g_2124) != l_2161)))) , (*g_1081)) != (void*)0)))) == p_14);
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_324 g_2019 g_2020 g_1440 g_1637 g_350 g_279 g_102 g_320 g_1945 g_68 g_1859 g_37 g_431 g_432 g_1944 g_507 g_71 g_212 g_1439 g_151 g_2100 g_1188
 * writes: g_324 g_1705 g_1709 g_1440 g_151 g_325 g_212 g_68 g_352 g_601 g_2124 g_2019
 */
static uint16_t  func_19(int32_t  p_20, int8_t  p_21, int16_t  p_22, uint64_t  p_23, uint16_t  p_24)
{ /* block id: 961 */
    int64_t l_2035 = (-1L);
    int16_t l_2039 = 0x307BL;
    int32_t l_2050 = 9L;
    int32_t l_2052[6][3] = {{0xDEF14368L,0xDEF14368L,0xDEF14368L},{0xD62281E8L,0xD62281E8L,0xD62281E8L},{0xDEF14368L,0xDEF14368L,0xDEF14368L},{0xD62281E8L,0xD62281E8L,0xD62281E8L},{0xDEF14368L,0xDEF14368L,0xDEF14368L},{0xD62281E8L,0xD62281E8L,0xD62281E8L}};
    int32_t ***l_2063 = (void*)0;
    int32_t ****l_2062 = &l_2063;
    int32_t *****l_2061[2];
    int32_t ******l_2060[7];
    int32_t *******l_2059 = &l_2060[6];
    const uint8_t ***l_2122 = (void*)0;
    int64_t l_2137[6];
    int i, j;
    for (i = 0; i < 2; i++)
        l_2061[i] = &l_2062;
    for (i = 0; i < 7; i++)
        l_2060[i] = &l_2061[0];
    for (i = 0; i < 6; i++)
        l_2137[i] = 0xE7B77A131854FDE9LL;
    for (g_324 = 0; (g_324 <= 0); g_324 += 1)
    { /* block id: 964 */
        int64_t l_2017[3][3][10] = {{{0L,0xC0B63D1FF0C2165ELL,0xEEA71B5250E89DEBLL,0xEEA71B5250E89DEBLL,0xC0B63D1FF0C2165ELL,0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL},{0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL,0x5DDE496CEFA7194FLL,4L,0x354CA0F1EDCD3233LL,0x354CA0F1EDCD3233LL,4L},{0L,0xC0B63D1FF0C2165ELL,0xEEA71B5250E89DEBLL,0xEEA71B5250E89DEBLL,0xC0B63D1FF0C2165ELL,0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL}},{{0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL,0x5DDE496CEFA7194FLL,4L,0x354CA0F1EDCD3233LL,0x354CA0F1EDCD3233LL,4L},{0L,0xC0B63D1FF0C2165ELL,0xEEA71B5250E89DEBLL,0xEEA71B5250E89DEBLL,0xC0B63D1FF0C2165ELL,0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL},{0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL,0x5DDE496CEFA7194FLL,4L,0x354CA0F1EDCD3233LL,0x354CA0F1EDCD3233LL,4L}},{{0L,0xC0B63D1FF0C2165ELL,0xEEA71B5250E89DEBLL,0xEEA71B5250E89DEBLL,0xC0B63D1FF0C2165ELL,0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL},{0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL,0x5DDE496CEFA7194FLL,4L,0x354CA0F1EDCD3233LL,0x354CA0F1EDCD3233LL,4L},{0L,0xC0B63D1FF0C2165ELL,0xEEA71B5250E89DEBLL,0xEEA71B5250E89DEBLL,0xC0B63D1FF0C2165ELL,0L,4L,0xEEA71B5250E89DEBLL,0x354CA0F1EDCD3233LL,0xC0B63D1FF0C2165ELL}}};
        int32_t l_2018[9][3] = {{(-10L),1L,1L},{0L,1L,0x7E1F0F92L},{0xB08833C9L,(-10L),1L},{0L,0L,1L},{(-10L),0xB08833C9L,0x7E1F0F92L},{1L,0L,1L},{1L,(-10L),0L},{(-10L),1L,1L},{0L,1L,0x7E1F0F92L}};
        uint8_t *l_2033 = &g_151;
        int8_t l_2047 = 0L;
        int64_t l_2138 = 0xCF6D2AACFDC4DFC6LL;
        uint8_t l_2140 = 5UL;
        int i, j, k;
        l_2018[3][1] = (!l_2017[1][2][2]);
        for (g_1705 = 0; (g_1705 >= 0); g_1705 -= 1)
        { /* block id: 968 */
            uint8_t ***l_2021 = &g_2020;
            int32_t *l_2022 = (void*)0;
            int32_t *l_2023 = (void*)0;
            int32_t *l_2024 = &l_2018[4][0];
            int32_t l_2036 = 0x63CC0394L;
            int32_t l_2037 = 0xD1C01B08L;
            int32_t l_2046 = (-1L);
            int32_t l_2048 = 0x01BB5231L;
            int32_t l_2049[2];
            int32_t l_2053 = 0xC4A24890L;
            uint64_t l_2054[9];
            int32_t *******l_2064[6] = {&l_2060[2],&l_2060[2],&l_2060[2],&l_2060[2],&l_2060[2],&l_2060[2]};
            uint64_t ***l_2073 = &g_1465;
            int16_t l_2139 = 0L;
            int i;
            for (i = 0; i < 2; i++)
                l_2049[i] = 0L;
            for (i = 0; i < 9; i++)
                l_2054[i] = 18446744073709551615UL;
            (*l_2024) = (&g_1439 != (l_2021 = g_2019));
            for (g_1709 = 0; (g_1709 <= 0); g_1709 += 1)
            { /* block id: 973 */
                uint32_t l_2025 = 6UL;
                uint16_t **l_2030[1];
                uint8_t *l_2034 = &g_151;
                int32_t l_2038[7] = {0xA34BF5E8L,0xA34BF5E8L,7L,0xA34BF5E8L,0xA34BF5E8L,7L,0xA34BF5E8L};
                int32_t *l_2040 = &g_174;
                int32_t *l_2041 = &l_2038[4];
                int32_t *l_2042 = &g_1282;
                int32_t *l_2043 = &l_2037;
                int32_t *l_2044 = &g_1282;
                int32_t *l_2045[3];
                uint64_t ***l_2074 = &g_278;
                int i;
                for (i = 0; i < 1; i++)
                    l_2030[i] = (void*)0;
                for (i = 0; i < 3; i++)
                    l_2045[i] = (void*)0;
                l_2025 = 0x636F2CD9L;
                l_2035 = (((safe_mod_func_int16_t_s_s(4L, p_21)) & ((*l_2024) = (l_2025 & (p_22 = 0x5A4EL)))) >= ((*l_2034) = ((safe_sub_func_int64_t_s_s((((l_2030[0] == (void*)0) == 1UL) , (((l_2025 , (safe_lshift_func_uint16_t_u_s((((**g_2019) = (l_2033 = (**l_2021))) == l_2034), p_20))) && p_20) , (*g_1637))), p_20)) && (*g_279))));
                ++l_2054[4];
                l_2018[3][1] = (safe_sub_func_uint8_t_u_u(((l_2064[4] = l_2059) == (void*)0), ((p_24 == (safe_sub_func_int16_t_s_s(4L, 0xC6FBL))) == (((safe_add_func_uint16_t_u_u((((safe_mul_func_int16_t_s_s(((l_2073 = &g_278) != (p_24 , (g_320[4][7][5] , l_2074))), 3UL)) <= 0x1BB658AC78009890LL) == 1UL), (*g_1945))) != 0UL) , p_24))));
            }
            for (l_2037 = 0; (l_2037 <= 0); l_2037 += 1)
            { /* block id: 988 */
                int64_t **l_2084 = (void*)0;
                const int32_t l_2086 = 7L;
                const uint64_t l_2089 = 0xCBDDB81CA17BB012LL;
                int32_t l_2092[6][10] = {{0x58556B40L,0x7D73A7F1L,0x3F5041C4L,0x43C7A9F9L,0x7D73A7F1L,1L,0L,1L,0x7D73A7F1L,0x43C7A9F9L},{0xB511BC83L,1L,0xB511BC83L,0x3F5041C4L,0L,1L,0x3F5041C4L,9L,0xC0C48B26L,0xB511BC83L},{9L,0x58556B40L,0x193D4272L,0xDB0695B3L,1L,1L,9L,9L,1L,1L},{0x58556B40L,0xB511BC83L,0xB511BC83L,0x58556B40L,0xC0C48B26L,0x7D73A7F1L,1L,1L,0xB511BC83L,9L},{0xC0C48B26L,9L,0x3F5041C4L,1L,0L,0x3F5041C4L,0xB511BC83L,1L,0xB511BC83L,0x3F5041C4L},{0xDB0695B3L,0x58556B40L,0xAE06DD6BL,0x58556B40L,0xDB0695B3L,0x8A698F4EL,0x43C7A9F9L,0xDB0695B3L,1L,0L}};
                int8_t l_2131 = 0x97L;
                int i, j;
                for (g_325 = 0; (g_325 <= 0); g_325 += 1)
                { /* block id: 991 */
                    uint32_t l_2091 = 1UL;
                    int16_t l_2114 = 0x61E6L;
                    int8_t *l_2115 = &l_2047;
                    const uint8_t ****l_2123[10] = {&l_2122,&l_2122,&l_2122,&l_2122,&l_2122,&l_2122,&l_2122,&l_2122,&l_2122,&l_2122};
                    uint8_t ****l_2128 = &g_2019;
                    int i;
                    for (p_20 = 0; (p_20 <= 0); p_20 += 1)
                    { /* block id: 994 */
                        int64_t **l_2083 = &g_1637;
                        uint16_t *l_2090 = &g_68[2];
                        int i, j;
                        l_2092[1][6] = (safe_mul_func_uint8_t_u_u((safe_mod_func_int64_t_s_s((((safe_mod_func_int32_t_s_s(g_1859[(l_2037 + 1)], (safe_mul_func_uint16_t_u_u(((*l_2090) = (g_212 |= ((l_2083 != l_2084) != ((safe_unary_minus_func_uint8_t_u((&p_24 == (g_37 , (*g_431))))) && (((((*g_1637) > ((l_2086 , (((((safe_rshift_func_uint8_t_u_s((((((((l_2018[3][1] &= p_21) ^ (*g_279)) & p_21) == 4L) == (-1L)) | p_24) ^ p_20), 6)) & p_21) & (**g_1944)) | l_2089) < 0x8EL)) | p_21)) > 0UL) & (*g_1637)) , (*g_507)))))), p_24)))) , p_21) , l_2091), (*g_279))), 0xC3L));
                        return p_23;
                    }
                    for (g_352 = 0; (g_352 >= 0); g_352 -= 1)
                    { /* block id: 1003 */
                        int64_t ***l_2099 = &l_2084;
                        const int32_t **l_2101 = &g_601;
                        (*g_2100) = ((safe_unary_minus_func_uint16_t_u(((g_324 , ((((p_22 && (p_21 > (safe_lshift_func_uint8_t_u_u((((!(~l_2091)) , l_2091) != ((l_2091 >= ((~l_2089) , (&g_1637 == ((*l_2099) = &g_1637)))) & p_22)), 1)))) , (**g_1439)) < 248UL) | p_23)) , l_2017[1][2][2]))) , &l_2086);
                        (*l_2101) = &l_2086;
                    }
                    l_2092[1][6] |= (safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_s((safe_div_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(((((safe_div_func_uint8_t_u_u((*g_1440), (((**g_1188) > ((((((safe_sub_func_uint64_t_u_u(p_23, ((((*l_2115) = l_2114) | (safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((((safe_add_func_uint16_t_u_u((((g_2124 = l_2122) == ((*l_2128) = l_2021)) || ((((safe_mod_func_int8_t_s_s(l_2131, (safe_sub_func_uint8_t_u_u((p_23 ^ (!(**g_1188))), (***g_2019))))) || p_22) && 0xE2L) & 0x126761961853CB60LL)), 3UL)) , 3L) & 0x83L), p_20)), p_20))) ^ 1UL))) , (void*)0) != l_2084) , 0x97BD1BB296629975LL) == 0UL) | 0xB9L)) , p_21))) , (void*)0) != &g_1909) | 0L), 6)), p_22)), l_2018[1][0])), p_22));
                }
            }
            ++l_2140;
        }
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_1465 g_279 g_102 g_1705 g_1637 g_350 g_676 g_1709 g_1034 g_1035 g_1036 g_1037 g_672 g_71 g_1439 g_1440 g_507 g_826 g_151 g_278 g_1083 g_1065 g_1778 g_212 g_68 g_1780 g_1781 g_1779 g_352 g_602 g_601 g_1819 g_506 g_1187 g_1188 g_1859 g_1282 g_1906 g_1909 g_1944 g_1945 g_2009 g_1145 g_271
 * writes: g_102 g_1705 g_676 g_1709 g_71 g_271 g_1066 g_1778 g_212 g_68 g_350 g_151 g_1332 g_1909 g_1086 g_1944 g_1282 g_2009 g_60
 */
static int8_t  func_27(uint16_t  p_28, int8_t  p_29, const uint32_t  p_30, uint64_t  p_31, int8_t  p_32)
{ /* block id: 828 */
    int64_t l_1687 = 0x04BC71A7F1BC7A84LL;
    int32_t *l_1704 = &g_1705;
    int16_t l_1706 = 0x7605L;
    int64_t *l_1707 = &g_676;
    int64_t *l_1708 = &g_1709;
    int32_t l_1714 = 1L;
    int32_t *** const *l_1720 = (void*)0;
    int32_t *** const **l_1719[5];
    int32_t *** const ***l_1718 = &l_1719[0];
    int64_t **l_1723 = &l_1707;
    int64_t ***l_1722 = &l_1723;
    uint8_t *l_1735 = (void*)0;
    int64_t l_1760[10][10] = {{(-1L),0x46D61A33C063D5A9LL,(-1L),0x8A06F463E15F6144LL,0x8A06F463E15F6144LL,(-1L),0x46D61A33C063D5A9LL,(-1L),0x73E51F30090B942ELL,0x9C8B643586E58186LL},{0L,0x8A06F463E15F6144LL,0x46D61A33C063D5A9LL,0x0DDCD9E08B6465ACLL,0x2B3066189FEE1EABLL,0x724B9DEC8A841F2ALL,0x2B3066189FEE1EABLL,0x0DDCD9E08B6465ACLL,0x46D61A33C063D5A9LL,0x8A06F463E15F6144LL},{(-1L),0x14F2AF5981B80639LL,0x46D61A33C063D5A9LL,0x2B3066189FEE1EABLL,4L,0x0DDCD9E08B6465ACLL,(-1L),(-1L),0x0DDCD9E08B6465ACLL,4L},{0x9C8B643586E58186LL,(-1L),(-1L),0x9C8B643586E58186LL,0x1F46355F7C423BF4LL,0x0DDCD9E08B6465ACLL,0L,0x46D61A33C063D5A9LL,4L,0x46D61A33C063D5A9LL},{(-1L),0x724B9DEC8A841F2ALL,0x73E51F30090B942ELL,0x46D61A33C063D5A9LL,0x73E51F30090B942ELL,0x724B9DEC8A841F2ALL,(-1L),0L,4L,0x14F2AF5981B80639LL},{0L,0x0DDCD9E08B6465ACLL,0x1F46355F7C423BF4LL,0x9C8B643586E58186LL,(-1L),(-1L),0x9C8B643586E58186LL,0x1F46355F7C423BF4LL,0x0DDCD9E08B6465ACLL,0L},{(-1L),0x0DDCD9E08B6465ACLL,4L,0x2B3066189FEE1EABLL,0x46D61A33C063D5A9LL,0x14F2AF5981B80639LL,(-1L),0x14F2AF5981B80639LL,0x46D61A33C063D5A9LL,0x2B3066189FEE1EABLL},{0x2B3066189FEE1EABLL,0x724B9DEC8A841F2ALL,0x2B3066189FEE1EABLL,0x0DDCD9E08B6465ACLL,0x46D61A33C063D5A9LL,0x8A06F463E15F6144LL,0L,0x73E51F30090B942ELL,0x73E51F30090B942ELL,0L},{0x46D61A33C063D5A9LL,(-1L),0x8A06F463E15F6144LL,0x8A06F463E15F6144LL,(-1L),0x46D61A33C063D5A9LL,(-1L),0x73E51F30090B942ELL,0x9C8B643586E58186LL,0x14F2AF5981B80639LL},{0x724B9DEC8A841F2ALL,0x14F2AF5981B80639LL,0x2B3066189FEE1EABLL,0x1F46355F7C423BF4LL,0x73E51F30090B942ELL,0x1F46355F7C423BF4LL,0x2B3066189FEE1EABLL,0x14F2AF5981B80639LL,0x724B9DEC8A841F2ALL,0x46D61A33C063D5A9LL}};
    uint16_t l_1761 = 1UL;
    int8_t *** const *l_1777 = (void*)0;
    const int8_t ****l_1782 = (void*)0;
    uint32_t **l_1799 = (void*)0;
    const int64_t l_1809 = 0x54664D87B55FA7E8LL;
    int8_t ***l_1817[5];
    uint64_t l_1875 = 0x1C4E0DD7765E3C22LL;
    uint32_t l_1903 = 0xEF2FA782L;
    uint16_t *l_1943 = &g_68[2];
    uint16_t **l_1942 = &l_1943;
    int64_t ** const l_1971[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int i, j;
    for (i = 0; i < 5; i++)
        l_1719[i] = &l_1720;
    for (i = 0; i < 5; i++)
        l_1817[i] = &g_846;
    if ((safe_sub_func_int64_t_s_s(0xDE661017B8C953EFLL, ((*l_1708) |= ((*l_1707) &= (safe_lshift_func_int8_t_s_s((safe_sub_func_int16_t_s_s((~((((safe_add_func_uint32_t_u_u((((((*l_1704) &= (safe_lshift_func_int16_t_s_s(((~1UL) , l_1687), (safe_sub_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((**g_1465) ^= (safe_sub_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(65534UL, p_29)), (safe_div_func_uint16_t_u_u(l_1687, 0x8874L)))) != ((((l_1687 , ((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(p_30, l_1687)), 9UL)) < l_1687)) <= p_29) == l_1687) , l_1687)), 0xE25BL))), p_31)), l_1687))))) , 6UL) , l_1687) , l_1687), l_1706)) != 0x58L) ^ (*g_1637)) | (*g_1637))), 0x3A06L)), 2)))))))
    { /* block id: 833 */
        uint16_t l_1712 = 0UL;
        int16_t *l_1713[7];
        int32_t l_1715 = 0xA4AD0F53L;
        int32_t l_1721 = 0x56BD53B7L;
        int64_t ***l_1724 = (void*)0;
        uint64_t ***l_1752 = &g_278;
        int32_t l_1756 = 0x069D8F7FL;
        int8_t ****l_1785[1][9][5] = {{{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,(void*)0,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845},{&g_845,&g_845,&g_845,&g_845,&g_845}}};
        int8_t *****l_1784 = &l_1785[0][6][4];
        int32_t l_1808 = 0x201C55CEL;
        int32_t l_1860 = 0x28D29116L;
        uint16_t **l_1941 = (void*)0;
        int32_t l_1954 = 6L;
        int32_t l_1959 = 0x22D4EB15L;
        int32_t l_1960 = (-10L);
        int32_t l_1962 = 0x24FD3515L;
        int32_t l_1964 = 0xAE86F460L;
        int32_t l_1965 = 0xCD379C18L;
        int32_t * const ****l_2002 = (void*)0;
        int32_t * const *****l_2001 = &l_2002;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_1713[i] = &l_1706;
lbl_2013:
        if ((((250UL <= (safe_rshift_func_uint16_t_u_s((((p_28 < (p_32 = (((***g_1034) , ((((l_1715 |= (l_1714 = ((l_1712 < p_28) >= 1L))) <= (((safe_mul_func_uint16_t_u_u((((*g_672) ^= ((((l_1721 = ((void*)0 == l_1718)) == (p_30 == l_1712)) == 0x899B1528F865E70FLL) && l_1721)) , p_29), p_28)) , l_1722) == l_1724)) , (void*)0) != &g_845)) , 6L))) == 1UL) , l_1715), 2))) >= p_31) & l_1712))
        { /* block id: 839 */
            uint64_t * const *l_1754[10];
            uint64_t * const **l_1753[8][5][2] = {{{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]}},{{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]}},{{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]}},{{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]}},{{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]}},{{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]}},{{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]}},{{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]},{&l_1754[1],&l_1754[4]},{&l_1754[6],&l_1754[4]}}};
            int32_t l_1755 = 9L;
            uint16_t *l_1757[5];
            int16_t l_1758[6];
            int32_t l_1759[2];
            int32_t l_1762 = 0L;
            int32_t l_1763 = 0L;
            int i, j, k;
            for (i = 0; i < 10; i++)
                l_1754[i] = &g_279;
            for (i = 0; i < 5; i++)
                l_1757[i] = &g_212;
            for (i = 0; i < 6; i++)
                l_1758[i] = (-1L);
            for (i = 0; i < 2; i++)
                l_1759[i] = 1L;
            l_1721 = ((safe_mul_func_uint8_t_u_u((((safe_div_func_uint64_t_u_u(((**g_278) = (safe_sub_func_int32_t_s_s((l_1763 = (l_1715 = (((l_1762 &= (((((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_u(((l_1735 == (*g_1439)) ^ ((safe_div_func_int8_t_s_s(((+p_32) == l_1715), p_28)) ^ (l_1759[1] &= (safe_mul_func_uint8_t_u_u(l_1715, (safe_mod_func_int64_t_s_s((safe_lshift_func_int8_t_s_s(((l_1755 = ((safe_unary_minus_func_uint16_t_u(((safe_mod_func_int16_t_s_s(((((*g_507) ^= (((safe_unary_minus_func_uint8_t_u(((safe_add_func_uint32_t_u_u((+(l_1752 != l_1753[1][2][0])), l_1715)) == (*g_1637)))) ^ l_1755) > 0x3CCA00D2D3EA11F8LL)) < l_1756) & p_28), l_1755)) || g_826))) && l_1721)) != l_1712), l_1758[2])), l_1758[4]))))))), 13)), l_1760[3][9])) , (*g_1440)) ^ p_28) != 0UL) , l_1761)) == 4294967295UL) != 0x206DL))), 0x51FC7417L))), l_1756)) ^ 0x29C8L) , p_30), l_1758[1])) , l_1756);
            for (g_271 = 1; (g_271 <= (-13)); g_271 = safe_sub_func_uint64_t_u_u(g_271, 4))
            { /* block id: 850 */
                return l_1763;
            }
        }
        else
        { /* block id: 853 */
            uint64_t l_1766[8];
            int i;
            for (i = 0; i < 8; i++)
                l_1766[i] = 18446744073709551612UL;
            l_1766[7]++;
            return p_32;
        }
        for (p_31 = 0; (p_31 <= 2); p_31 += 1)
        { /* block id: 859 */
            const int8_t *****l_1783 = &g_1778;
            int32_t l_1791 = 1L;
            int32_t l_1861[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
            int32_t l_1862 = 0x578B37E3L;
            int32_t **l_1873 = &g_1066;
            int32_t ***l_1872 = &l_1873;
            int32_t ****l_1871 = &l_1872;
            int32_t *****l_1870 = &l_1871;
            int8_t l_1874 = 0x4AL;
            uint64_t **l_1893 = (void*)0;
            uint64_t **** const l_1894[4] = {&l_1752,&l_1752,&l_1752,&l_1752};
            int32_t l_1957 = 0L;
            int64_t *l_1996 = &l_1687;
            int i;
            (**g_1083) = (void*)0;
            l_1715 ^= ((1UL & ((safe_lshift_func_int16_t_s_s((((!(safe_sub_func_int64_t_s_s(((~(safe_unary_minus_func_uint16_t_u(65535UL))) >= (!(9UL | (l_1777 != ((*l_1783) = (l_1782 = g_1778)))))), p_31))) , ((l_1784 == &l_1777) , (void*)0)) == (void*)0), 12)) <= 4294967290UL)) & p_31);
            for (g_212 = 0; (g_212 <= 2); g_212 += 1)
            { /* block id: 866 */
                uint32_t ***l_1786 = (void*)0;
                uint64_t *** const l_1787[9] = {&g_278,(void*)0,&g_278,&g_278,(void*)0,&g_278,&g_278,(void*)0,&g_278};
                uint64_t ****l_1788 = (void*)0;
                uint64_t ****l_1789 = &l_1752;
                int32_t l_1790[10][8] = {{1L,0xEC190231L,(-8L),(-8L),0xEC190231L,1L,0xBF0C7008L,(-2L)},{0xEC190231L,1L,0xBF0C7008L,(-2L),0x149B882DL,(-8L),0xAABA031EL,0x149B882DL},{(-2L),0x531F7ED3L,0L,(-2L),0x84D18E3CL,0x6A8EF0B2L,0x84D18E3CL,(-2L)},{0xA8F93E11L,0x84D18E3CL,0xA8F93E11L,(-8L),0x91AA9741L,0xBF0C7008L,(-8L),0x531F7ED3L},{0x84D18E3CL,9L,0xBF0C7008L,0xEC190231L,0xDD6E1354L,0x149B882DL,0x91AA9741L,9L},{0x84D18E3CL,0x531F7ED3L,(-1L),0x91AA9741L,0x91AA9741L,(-1L),0x531F7ED3L,0x84D18E3CL},{0xA8F93E11L,(-2L),9L,(-1L),0xDD6E1354L,0L,0x6A8EF0B2L,0x149B882DL},{0xA8F93E11L,(-1L),0x79FF600DL,0xBF0C7008L,(-1L),0L,9L,0L},{(-8L),0xA8F93E11L,0x84D18E3CL,0xA8F93E11L,(-8L),0x91AA9741L,0xBF0C7008L,(-8L)},{0L,0x149B882DL,0x6A8EF0B2L,0L,0xDD6E1354L,(-1L),6L,0xA8F93E11L}};
                int16_t l_1792 = 0L;
                int8_t * const **l_1816 = &g_804;
                int32_t l_1869 = 0L;
                uint8_t l_1895 = 0x8CL;
                int32_t l_1913 = (-9L);
                uint64_t l_1917 = 0x759CDF5C5152D6AELL;
                int32_t *l_1920 = &g_1282;
                uint32_t l_1930 = 1UL;
                int64_t l_1956 = 6L;
                int32_t l_1958 = 0x0D6CBF34L;
                int32_t l_1961 = 0xC8161A6FL;
                int32_t l_1966 = 0xB898C26CL;
                uint32_t l_1967 = 2UL;
                uint16_t **l_1997 = &l_1943;
                int i, j;
                l_1791 = ((l_1715 = (((((p_29 , (((l_1786 == ((g_68[(g_212 + 3)] ^= l_1715) , l_1786)) , (l_1787[0] == ((*l_1789) = l_1752))) | (l_1790[3][2] < ((*g_1780) != (void*)0)))) != 255UL) < l_1790[3][2]) > 0x8A29L) & l_1791)) ^ l_1712);
                if (l_1792)
                { /* block id: 871 */
                    uint32_t l_1793 = 0UL;
                    const int32_t *l_1807 = &g_271;
                    if ((l_1793 = p_31))
                    { /* block id: 873 */
                        uint16_t l_1794 = 65535UL;
                        if (l_1794)
                            break;
                        if (l_1794)
                            continue;
                    }
                    else
                    { /* block id: 876 */
                        uint16_t l_1805 = 0x5067L;
                        int32_t l_1806 = 9L;
                        l_1806 &= (((0x09B6L <= (safe_add_func_int32_t_s_s((0L > (safe_mul_func_uint8_t_u_u(p_30, (*g_1440)))), (l_1721 , ((void*)0 != l_1799))))) <= ((((((*l_1708) &= (((**l_1723) = ((*g_1637) = ((~(p_32 & ((safe_add_func_int16_t_s_s(((safe_rshift_func_int8_t_s_u((l_1715 <= 0x64DEF2D849B8AAE9LL), 5)) ^ 0x4F23C819L), p_28)) , 0x032EL))) != p_32))) || 0x7097CE482B79A694LL)) != p_28) , (void*)0) == (void*)0) | l_1805)) ^ 0UL);
                        return (****g_1778);
                    }
                    l_1807 = (*g_602);
                    for (l_1714 = 2; (l_1714 >= 0); l_1714 -= 1)
                    { /* block id: 886 */
                        int8_t ***l_1818 = &g_846;
                        int32_t l_1820 = 0L;
                        int i, j, k;
                        if (l_1808)
                            break;
                        if (l_1809)
                            continue;
                        l_1820 |= (safe_sub_func_uint32_t_u_u(l_1790[3][2], (((safe_add_func_int32_t_s_s(g_68[(g_212 + 3)], ((safe_sub_func_uint32_t_u_u(((g_68[(g_212 + 3)] & p_29) , (*g_672)), ((l_1816 != (l_1818 = l_1817[4])) && l_1791))) < (((((*g_1778) != g_1819[0][0]) ^ 0x39L) || p_31) && l_1808)))) == 0L) , 1L)));
                        return l_1808;
                    }
                }
                else
                { /* block id: 893 */
                    int8_t l_1850 = 0xABL;
                    l_1862 &= ((((*g_1440) |= (safe_add_func_uint16_t_u_u((safe_div_func_int32_t_s_s((safe_div_func_int16_t_s_s(((((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s((((safe_sub_func_uint16_t_u_u(((l_1790[3][3] != (safe_lshift_func_uint8_t_u_s((safe_mul_func_uint8_t_u_u(p_30, (!((safe_lshift_func_uint8_t_u_s(p_30, 7)) < p_30)))), l_1715))) >= l_1790[1][6]), ((safe_add_func_uint16_t_u_u((safe_mod_func_int16_t_s_s((safe_add_func_int32_t_s_s((l_1791 = l_1850), ((safe_sub_func_int8_t_s_s(l_1715, ((safe_add_func_int64_t_s_s((((l_1721 = ((safe_sub_func_uint64_t_u_u((safe_add_func_uint8_t_u_u(0x55L, 0x9CL)), l_1721)) || (**g_506))) == (***g_1187)) , (*g_1637)), (*g_1637))) ^ l_1792))) >= 0xDF0B2708E8845520LL))), g_1859[0])), l_1850)) , l_1860))) || l_1791) || l_1791), p_28)), 15)), p_31)), 13)) > 0xAB93B7DE3F24970BLL) && (*g_1036)) >= 0xC66C7679L), l_1861[6])), (**g_506))), g_1282))) == 0xD0L) & 0x0CL);
                    l_1874 = ((((safe_mod_func_int16_t_s_s(p_31, (safe_div_func_int8_t_s_s((p_31 & (0x85L ^ (&g_506 != ((((&p_32 != &p_32) != (l_1860 != l_1869)) < (((*g_1637) && p_30) , 1L)) , (void*)0)))), p_30)))) , l_1870) == &g_1586) & 0L);
                    ++l_1875;
                    for (l_1687 = 0; (l_1687 <= 2); l_1687 += 1)
                    { /* block id: 902 */
                        int i;
                        return g_1859[p_31];
                    }
                }
                if ((((**g_1465)++) < (g_1332 = (safe_mul_func_int16_t_s_s(((((safe_mul_func_uint16_t_u_u(((5L > (safe_unary_minus_func_int16_t_s((l_1808 != (safe_sub_func_int32_t_s_s((safe_mul_func_int16_t_s_s(((((((safe_sub_func_uint32_t_u_u(p_32, (l_1869 |= (((safe_rshift_func_int8_t_s_s((((*l_1752) != l_1893) >= (*g_1637)), (**g_1780))) , ((((0x3106L || 0xDA67L) , (void*)0) != l_1894[2]) | p_28)) , l_1790[3][2])))) , g_68[(g_212 + 3)]) , 0x51L) || l_1860) && (*g_1637)) || l_1895), p_28)), g_68[(g_212 + 3)])))))) == 0x82L), 3L)) & p_30) < 0x596C6F94L) && (**g_1439)), p_31)))))
                { /* block id: 909 */
                    int32_t l_1898 = 0xFF924001L;
                    const uint16_t ***l_1946[6][1] = {{&g_1944},{(void*)0},{&g_1944},{&g_1944},{(void*)0},{&g_1944}};
                    const int32_t l_1947 = 0xBB4293F9L;
                    int32_t l_1948 = (-1L);
                    int32_t l_1949 = 0L;
                    int32_t l_1955 = 0xD210C8EBL;
                    int32_t l_1963 = 0xC20C3B38L;
                    int i, j;
                    for (l_1706 = 0; (l_1706 < (-28)); l_1706 = safe_sub_func_uint16_t_u_u(l_1706, 5))
                    { /* block id: 912 */
                        uint32_t * const * const **l_1911 = (void*)0;
                        uint32_t * const * const **l_1912 = &g_1909;
                        int32_t l_1914 = 0xF64AFDF3L;
                        int32_t l_1915 = (-5L);
                        int32_t l_1916[6][2] = {{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}};
                        int i, j;
                        if (l_1898)
                            break;
                        l_1913 |= (l_1869 = (((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((18446744073709551614UL && l_1903), 3)), p_30)) | (0x31BB8ABA8DF7D6CDLL | 0x240312AC8D98CDACLL)) , (safe_mul_func_int16_t_s_s(g_1906, (l_1860 , ((((safe_lshift_func_int16_t_s_s(((p_32 != (((*l_1912) = g_1909) != &g_1910)) , p_29), p_31)) | p_31) , 0UL) || 0xAD38L))))));
                        l_1917++;
                        if (l_1808)
                            break;
                    }
                    l_1920 = &l_1898;
                    for (g_1086 = (-9); (g_1086 <= 44); g_1086 = safe_add_func_uint64_t_u_u(g_1086, 1))
                    { /* block id: 923 */
                        return (*g_1781);
                    }
                    if ((safe_add_func_uint64_t_u_u((p_28 >= ((((((safe_unary_minus_func_uint32_t_u((((5L <= (safe_mod_func_int8_t_s_s(p_28, (-8L)))) && ((safe_sub_func_int16_t_s_s((((l_1930 == (safe_rshift_func_int8_t_s_s((((((l_1898 = (safe_mul_func_int16_t_s_s(0x11FAL, (g_1906 , (safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((l_1942 = l_1941) != (g_1944 = g_1944)), 0x83L)), p_29)))))) ^ 0UL) < 0UL) , l_1721) > 255UL), p_31))) , p_31) > p_28), l_1947)) , (*g_507))) ^ (*g_1945)))) , p_28) , (*g_507)) != p_31) > p_31) != 0xF0C8L)), (*g_1637))))
                    { /* block id: 929 */
                        uint16_t l_1950 = 0x579DL;
                        int32_t l_1953[10][1][5] = {{{(-1L),0L,0L,(-1L),0L}},{{0x0EFC3826L,0x21ECD1C7L,0x0EFE1CACL,0x21ECD1C7L,0x0EFC3826L}},{{0L,(-1L),0L,0L,(-1L)}},{{5L,0x13006726L,8L,0x21ECD1C7L,8L}},{{(-1L),0xA93D2CF2L,(-1L),(-1L),(-1L)}},{{(-1L),0x21ECD1C7L,(-1L),0x13006726L,0x0EFC3826L}},{{(-1L),0L,0L,0xA93D2CF2L,0L}},{{5L,0x21ECD1C7L,9L,0x21ECD1C7L,5L}},{{0L,0xA93D2CF2L,0L,0L,(-1L)}},{{0x0EFC3826L,0x13006726L,(-1L),0x21ECD1C7L,(-1L)}}};
                        int32_t *l_1970 = &l_1862;
                        int i, j, k;
                        --l_1950;
                        ++l_1967;
                        l_1970 = &l_1860;
                    }
                    else
                    { /* block id: 933 */
                        (***l_1871) = &l_1966;
                        return p_29;
                    }
                }
                else
                { /* block id: 937 */
                    uint32_t l_1981 = 4294967295UL;
                    uint16_t **l_1993 = &l_1943;
                    int32_t ******l_1999 = &l_1870;
                    int32_t l_2004 = 8L;
                    int32_t l_2005 = 0x2C1B741CL;
                    int32_t l_2006 = 0xD8553BF6L;
                    int32_t l_2008[9] = {0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L,0x60FA6F21L};
                    int i;
                    if ((*l_1920))
                    { /* block id: 938 */
                        uint16_t l_1982 = 0UL;
                        uint16_t **l_1991 = &l_1943;
                        uint16_t ***l_1992[8] = {&l_1942,(void*)0,&l_1942,(void*)0,&l_1942,(void*)0,&l_1942,(void*)0};
                        int32_t *******l_2000 = &l_1999;
                        int32_t l_2003 = 0x68C4122EL;
                        int32_t l_2007 = 0xBAA2C28FL;
                        int i;
                        l_1913 |= ((*l_1920) = (((p_29 , (&g_1637 == l_1971[4])) == ((safe_lshift_func_int8_t_s_u(((((+((safe_sub_func_uint64_t_u_u((p_31 == (-1L)), (((safe_lshift_func_int8_t_s_u(((safe_sub_func_uint64_t_u_u((**g_278), 0x12DD67370FC6D74CLL)) , 0x9CL), (*l_1920))) >= 0x2E143C9F9543BC0ALL) , p_28))) <= p_28)) != 18446744073709551609UL) || p_29) > l_1981), 5)) , l_1982)) <= p_31));
                        (*l_1920) = ((safe_sub_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u(((l_1993 = l_1991) != ((0xC68A7CA9L ^ (safe_div_func_uint64_t_u_u((&g_1906 != ((**l_1722) = l_1996)), p_29))) , l_1997)), (0x19A2L & ((((~(((*l_2000) = l_1999) == l_2001)) , p_30) , (void*)0) == &g_1187)))), p_32)), p_30)), 0UL)) | (**g_1188));
                        --g_2009;
                    }
                    else
                    { /* block id: 946 */
                        uint8_t l_2012 = 8UL;
                        (*g_1145) = (void*)0;
                        l_2012 &= 0xCB5F99F4L;
                        if (p_32)
                            break;
                        if (g_826)
                            goto lbl_2013;
                    }
                    (*l_1920) = p_29;
                }
            }
        }
        return p_28;
    }
    else
    { /* block id: 957 */
        uint32_t l_2014 = 0x11199E05L;
        l_2014 |= p_30;
    }
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_61
 * writes: g_61
 */
static uint32_t  func_33(int32_t  p_34, int32_t  p_35)
{ /* block id: 574 */
    uint64_t l_1196[3];
    int32_t **l_1229[9][7][4] = {{{(void*)0,(void*)0,(void*)0,&g_60},{&g_60,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_60,&g_1066,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_60},{(void*)0,(void*)0,(void*)0,&g_60},{&g_60,&g_60,(void*)0,&g_60}},{{(void*)0,(void*)0,(void*)0,&g_60},{&g_60,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_60,&g_1066,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_60},{(void*)0,(void*)0,(void*)0,&g_60},{&g_60,&g_60,(void*)0,&g_60}},{{(void*)0,(void*)0,(void*)0,&g_60},{&g_60,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_60,&g_1066,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_60},{(void*)0,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}},{{&g_1066,&g_1066,(void*)0,&g_60},{(void*)0,&g_1066,(void*)0,&g_1066},{&g_1066,&g_60,(void*)0,(void*)0},{(void*)0,&g_60,&g_60,&g_1066},{&g_60,&g_1066,&g_1066,&g_60},{&g_60,&g_1066,&g_60,&g_1066},{(void*)0,&g_60,(void*)0,&g_1066}}};
    int32_t ***l_1228 = &l_1229[0][5][0];
    int32_t ****l_1227[9] = {&l_1228,&l_1228,&l_1228,&l_1228,&l_1228,&l_1228,&l_1228,&l_1228,&l_1228};
    int16_t *l_1249[10][1][9] = {{{&g_324,&g_314,&g_314,&g_314,&g_314,&g_324,(void*)0,&g_314,&g_314}},{{&g_324,(void*)0,&g_324,&g_314,&g_314,&g_324,&g_324,&g_324,&g_324}},{{&g_324,&g_324,&g_314,&g_324,&g_324,&g_324,(void*)0,(void*)0,&g_324}},{{&g_324,&g_324,&g_324,&g_324,(void*)0,(void*)0,&g_324,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_324,&g_324,&g_314,&g_324,(void*)0}},{{(void*)0,&g_324,&g_314,&g_324,(void*)0,&g_324,&g_324,(void*)0,&g_324}},{{&g_324,(void*)0,&g_324,&g_314,&g_324,&g_324,&g_324,&g_314,&g_324}},{{&g_324,&g_324,(void*)0,&g_314,(void*)0,&g_314,(void*)0,&g_314,(void*)0}},{{&g_324,&g_324,(void*)0,&g_314,&g_324,&g_324,(void*)0,&g_314,(void*)0}},{{&g_324,&g_324,&g_314,&g_324,&g_314,&g_314,&g_324,&g_314,&g_324}}};
    int32_t *l_1333 = &g_271;
    int64_t *l_1340 = (void*)0;
    uint16_t l_1444 = 1UL;
    int64_t l_1606[6] = {0x50FFD0ECB3BDE8ADLL,7L,0x50FFD0ECB3BDE8ADLL,0x50FFD0ECB3BDE8ADLL,7L,0x50FFD0ECB3BDE8ADLL};
    int8_t l_1671 = 0x1AL;
    uint32_t l_1672 = 4294967293UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1196[i] = 6UL;
    for (g_61 = 0; (g_61 > (-30)); g_61 = safe_sub_func_uint32_t_u_u(g_61, 1))
    { /* block id: 577 */
        uint32_t ***l_1204 = &g_1188;
        int32_t l_1206[9];
        int32_t l_1208 = 0x54DCA5DDL;
        const int32_t l_1210 = 0xDE85CA5AL;
        uint8_t *l_1212 = &g_151;
        uint8_t ** const l_1211 = &l_1212;
        int32_t l_1213 = 0x3B71BDE8L;
        int64_t l_1221 = (-1L);
        int16_t * const l_1248[4][9][4] = {{{&g_324,&g_324,&g_314,&g_314},{&g_324,&g_314,&g_314,&g_314},{&g_324,&g_314,&g_314,&g_324},{&g_324,&g_314,&g_314,&g_314},{&g_314,&g_314,(void*)0,&g_324},{&g_324,&g_324,&g_314,&g_324},{&g_324,&g_314,&g_324,&g_314},{&g_324,&g_314,&g_314,&g_324},{&g_324,&g_314,&g_314,&g_314}},{{&g_314,&g_314,&g_314,&g_314},{&g_324,&g_324,&g_314,&g_324},{&g_324,&g_324,&g_324,&g_314},{&g_324,&g_314,&g_314,&g_324},{&g_324,&g_314,(void*)0,&g_314},{&g_314,&g_324,&g_314,&g_324},{&g_324,&g_324,&g_314,&g_314},{&g_324,&g_314,&g_314,&g_314},{&g_324,&g_314,&g_314,&g_324}},{{&g_324,&g_314,&g_314,&g_314},{&g_314,&g_314,(void*)0,&g_324},{&g_324,&g_324,&g_314,&g_324},{&g_324,&g_314,&g_324,&g_314},{&g_324,&g_314,&g_314,&g_324},{&g_324,&g_314,&g_314,&g_314},{&g_314,&g_314,&g_314,&g_314},{&g_324,&g_314,&g_324,&g_324},{&g_314,&g_324,(void*)0,&g_324}},{{(void*)0,&g_324,&g_314,(void*)0},{&g_314,&g_324,&g_314,&g_324},{&g_324,&g_324,&g_324,&g_324},{&g_314,&g_314,&g_314,&g_324},{&g_314,&g_324,&g_324,&g_324},{&g_314,&g_314,&g_314,&g_314},{&g_314,&g_324,&g_324,&g_314},{&g_324,&g_324,&g_314,&g_324},{&g_314,&g_314,&g_314,&g_324}}};
        uint32_t l_1280 = 0x39595B7EL;
        int32_t *l_1293 = (void*)0;
        uint16_t *l_1310 = (void*)0;
        uint16_t **l_1309 = &l_1310;
        int8_t ***l_1312 = &g_846;
        uint8_t l_1348 = 255UL;
        int16_t l_1408 = 4L;
        int32_t *****l_1469 = &l_1227[1];
        int32_t ******l_1468 = &l_1469;
        uint64_t ***l_1495 = &g_1465;
        uint64_t *** const *l_1494 = &l_1495;
        const uint8_t l_1534 = 0xA0L;
        int32_t l_1611[8][2][10] = {{{(-8L),0L,0xD61D0EDCL,0xB1F872DEL,0x722C49D2L,(-6L),0L,1L,0x5880E361L,0xB28ACBAAL},{8L,0x8CF5C175L,0xD61D0EDCL,0x722C49D2L,0xB0FE52E3L,1L,0x8CF5C175L,1L,0xB0FE52E3L,0x722C49D2L}},{{0xD61D0EDCL,0L,0xD61D0EDCL,0x5880E361L,0xB1F872DEL,(-8L),0L,1L,0xB28ACBAAL,0xB0FE52E3L},{(-6L),(-1L),0xD61D0EDCL,0xB0FE52E3L,0x5880E361L,8L,(-1L),1L,0xB1F872DEL,0xB1F872DEL}},{{1L,(-1L),0xD61D0EDCL,0xB28ACBAAL,0xB28ACBAAL,0xD61D0EDCL,(-1L),1L,0x722C49D2L,0x5880E361L},{(-8L),0L,0xD61D0EDCL,0xB1F872DEL,0x722C49D2L,(-6L),0L,1L,0x5880E361L,0xB28ACBAAL}},{{8L,0x8CF5C175L,0xD61D0EDCL,0x722C49D2L,0xB0FE52E3L,1L,0x8CF5C175L,1L,0xB0FE52E3L,0x722C49D2L},{0xD61D0EDCL,0L,0xD61D0EDCL,0x5880E361L,0xB1F872DEL,(-8L),0L,1L,0xB28ACBAAL,0xB0FE52E3L}},{{(-6L),(-1L),0xD61D0EDCL,0xB0FE52E3L,0x5880E361L,8L,(-1L),1L,0xB1F872DEL,0xB1F872DEL},{1L,(-1L),0xD61D0EDCL,0xB28ACBAAL,0xB28ACBAAL,0xD61D0EDCL,(-1L),1L,0x722C49D2L,0x5880E361L}},{{(-8L),0L,0xD61D0EDCL,0xB1F872DEL,0x722C49D2L,(-6L),0L,1L,0x5880E361L,0xB28ACBAAL},{8L,0x8CF5C175L,0xD61D0EDCL,0x722C49D2L,0xB0FE52E3L,1L,0x8CF5C175L,1L,0xB0FE52E3L,0x722C49D2L}},{{0xD61D0EDCL,0L,0xD61D0EDCL,0x5880E361L,0xB1F872DEL,(-8L),0L,1L,0xB28ACBAAL,0xB0FE52E3L},{(-6L),(-1L),0xD61D0EDCL,0xB0FE52E3L,0x5880E361L,8L,(-1L),1L,0xB1F872DEL,0xB1F872DEL}},{{1L,(-1L),0xD61D0EDCL,0xB28ACBAAL,0xB28ACBAAL,0xD61D0EDCL,(-1L),1L,8L,(-6L)},{0xEBABFF26L,1L,0x5913D25FL,1L,8L,0x995109A2L,1L,(-1L),(-6L),0xD61D0EDCL}}};
        uint32_t l_1622 = 0xFC35AFA7L;
        int64_t **l_1642 = &l_1340;
        int32_t l_1648 = 0x03AD3045L;
        uint32_t *l_1660 = &g_1086;
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_1206[i] = 0x42FE20E7L;
    }
    ++l_1672;
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_155 g_104 g_506 g_507 g_61 g_314 g_320 g_602 g_288 g_71 g_352 g_279 g_102 g_151 g_325 g_68 g_3 g_278 g_271 g_672 g_676 g_211 g_4 g_350 g_6 g_720 g_721 g_601 g_324 g_195 g_7 g_252 g_212 g_803 g_845 g_431 g_432 g_173 g_174 g_804 g_5
 * writes: g_155 g_61 g_601 g_325 g_314 g_324 g_104 g_350 g_672 g_676 g_693 g_60 g_71 g_212 g_151 g_271 g_102 g_803 g_826 g_845
 */
static int8_t  func_40(uint32_t  p_41, const uint16_t  p_42, int8_t  p_43, const int16_t  p_44, uint8_t  p_45)
{ /* block id: 282 */
    int8_t l_584 = 1L;
    uint64_t * const *l_597 = &g_279;
    uint64_t * const **l_596 = &l_597;
    uint64_t * const ***l_595 = &l_596;
    int32_t l_615 = 0x0C540F07L;
    int32_t l_633 = 2L;
    uint16_t *l_651[3];
    uint16_t **l_650 = &l_651[0];
    uint16_t *** const l_649 = &l_650;
    int16_t *l_695 = &g_324;
    uint64_t l_698 = 18446744073709551615UL;
    int16_t *l_722 = &g_324;
    int32_t *l_731 = &g_325;
    int32_t *l_744[9][8] = {{&l_615,&g_174,&g_6,&g_325,&g_325,&g_325,&g_6,&g_174},{&l_633,&g_174,&g_7,&g_325,(void*)0,&l_615,&g_7,&g_271},{&g_325,&g_7,&g_174,(void*)0,&l_633,&g_61,&g_7,&l_633},{&g_271,(void*)0,&g_7,&l_615,&g_7,&g_174,&g_6,&g_6},{&g_7,&g_174,&g_6,&g_6,&g_174,&g_7,&l_615,&g_7},{&g_174,(void*)0,&l_633,&g_7,&g_61,&l_633,(void*)0,&g_174},{&g_61,(void*)0,&g_271,&g_7,&l_615,(void*)0,&g_325,&g_7},{&g_7,&l_615,&g_174,&g_6,&g_325,&g_325,&g_325,&g_6},{(void*)0,(void*)0,(void*)0,&l_615,&g_174,&g_61,&g_61,&l_633}};
    int32_t l_773 = 0xDF543CE0L;
    int8_t **l_807 = &g_805;
    int8_t ***l_806 = &l_807;
    uint32_t **l_857 = (void*)0;
    int8_t l_913 = 1L;
    int32_t l_943 = 0x1B13C22BL;
    uint8_t *l_1012 = (void*)0;
    uint16_t l_1050 = 65535UL;
    uint32_t l_1098 = 0xC153547DL;
    uint16_t l_1133 = 65533UL;
    uint64_t l_1165 = 0UL;
    int i, j;
    for (i = 0; i < 3; i++)
        l_651[i] = &g_212;
lbl_842:
    for (g_155 = 0; (g_155 <= 8); g_155 += 1)
    { /* block id: 285 */
        int32_t *l_580 = (void*)0;
        int32_t *l_581 = &g_61;
        int8_t *l_583 = &g_252;
        int8_t **l_582[3];
        int64_t *l_587 = &g_350;
        uint64_t l_634 = 18446744073709551606UL;
        int32_t l_655 = 0xF8A0F297L;
        int32_t l_657 = 1L;
        int32_t l_658 = 0x33320A65L;
        int32_t l_660 = (-9L);
        int16_t *l_694 = (void*)0;
        const int32_t *l_728 = (void*)0;
        int i;
        for (i = 0; i < 3; i++)
            l_582[i] = &l_583;
        l_584 &= (((((*l_581) = 0L) , l_582[0]) == (void*)0) , 0xC26A6C18L);
        (*l_581) = 0xCF16D354L;
        if ((safe_add_func_uint64_t_u_u((l_587 == (void*)0), (safe_add_func_uint8_t_u_u(((((((safe_mul_func_int16_t_s_s(0x9AA9L, ((safe_lshift_func_int8_t_s_s((g_104[g_155] | ((&l_582[0] != (void*)0) , ((void*)0 == (*g_506)))), 5)) & (safe_unary_minus_func_uint16_t_u(l_584))))) | 1UL) & (*l_581)) | g_314) <= l_584) && p_43), g_320[4][7][5])))))
        { /* block id: 289 */
            uint64_t * const ***l_598[10] = {&l_596,&l_596,&l_596,&l_596,&l_596,&l_596,&l_596,&l_596,&l_596,&l_596};
            const int32_t *l_599 = (void*)0;
            int32_t l_609 = 0L;
            uint16_t l_616 = 1UL;
            uint16_t * const **l_652 = (void*)0;
            int16_t l_671 = 1L;
            int8_t ***l_699 = &l_582[0];
            int i;
            if (((l_598[1] = l_595) != (void*)0))
            { /* block id: 291 */
                int32_t *l_603 = &g_325;
                int32_t *l_604 = &g_61;
                int32_t *l_605 = &g_174;
                int32_t *l_606 = (void*)0;
                int32_t *l_607 = &g_325;
                int32_t *l_608 = (void*)0;
                int32_t *l_610 = &g_271;
                int32_t *l_611 = &g_271;
                int32_t *l_612 = &g_174;
                int32_t *l_613 = &g_325;
                int32_t *l_614 = &g_325;
                (*g_602) = l_599;
                l_616--;
            }
            else
            { /* block id: 294 */
                uint64_t l_622[10] = {0xCBBB91D3C02A93CELL,0x81E2DC8B5D006637LL,0x8908148308D4F6ADLL,0x8908148308D4F6ADLL,0x81E2DC8B5D006637LL,0xCBBB91D3C02A93CELL,0x81E2DC8B5D006637LL,0x8908148308D4F6ADLL,0x8908148308D4F6ADLL,0x81E2DC8B5D006637LL};
                int i;
                for (g_325 = 0; (g_325 >= 0); g_325 -= 1)
                { /* block id: 297 */
                    int32_t *l_619 = &g_61;
                    int32_t *l_620 = &l_615;
                    int32_t *l_621[9] = {&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271,&g_271};
                    int i, j;
                    (*g_288) ^= 0x2945AE90L;
                    if (p_42)
                        continue;
                    ++l_622[4];
                }
                if (l_615)
                    break;
            }
            for (g_314 = 8; (g_314 >= 3); g_314 -= 1)
            { /* block id: 306 */
                int32_t *l_625 = &g_325;
                int32_t *l_626 = &g_174;
                int32_t l_627[3][4];
                int32_t *l_628 = &g_325;
                int32_t *l_629 = &l_627[1][3];
                int32_t *l_630 = (void*)0;
                int32_t *l_631 = &l_627[1][3];
                int32_t *l_632[2][10][3] = {{{&g_271,(void*)0,&g_271},{&l_615,(void*)0,&l_627[1][3]},{&g_325,(void*)0,&g_325},{&l_615,&l_609,&l_627[1][3]},{&g_271,(void*)0,&g_271},{&l_615,(void*)0,&l_627[1][3]},{&g_325,(void*)0,&g_325},{&l_615,&l_609,&l_627[1][3]},{&g_271,(void*)0,&g_271},{&l_615,(void*)0,&l_627[1][3]}},{{&g_325,(void*)0,&g_325},{&l_615,&l_609,&l_627[1][3]},{&g_271,(void*)0,&g_271},{&l_615,(void*)0,&l_627[1][3]},{&g_325,(void*)0,&g_325},{&l_615,&l_609,&l_627[1][3]},{&g_271,(void*)0,&g_271},{&l_615,(void*)0,&l_627[1][3]},{&g_325,(void*)0,&g_325},{&l_615,&l_609,&l_627[1][3]}}};
                int16_t *l_691[4][1];
                int i, j, k;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 4; j++)
                        l_627[i][j] = (-5L);
                }
                for (i = 0; i < 4; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_691[i][j] = (void*)0;
                }
                --l_634;
                for (l_615 = 5; (l_615 >= 3); l_615 -= 1)
                { /* block id: 310 */
                    int16_t *l_653 = &g_324;
                    int32_t l_654 = 0x6B5046B7L;
                    int32_t l_656 = 0L;
                    uint16_t l_661 = 0x845AL;
                    int8_t * const *l_701 = &l_583;
                    int8_t * const **l_700 = &l_701;
                    if (((safe_unary_minus_func_int8_t_s((safe_add_func_uint64_t_u_u(0xEE2F9BF05AA96F9ALL, (4UL <= (*g_507)))))) > (g_352 & ((*l_653) = (safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((0x26L > (+(*l_581))), (safe_div_func_uint32_t_u_u(((safe_mod_func_uint8_t_u_u(((*g_279) & (((g_151 , l_649) != l_652) < 1L)), (*l_625))) , 0xD119C65EL), p_42)))), l_615))))))
                    { /* block id: 312 */
                        int32_t l_659 = 0x02D5BF48L;
                        l_661++;
                    }
                    else
                    { /* block id: 314 */
                        if (l_661)
                            break;
                    }
                    if ((*l_581))
                    { /* block id: 317 */
                        uint32_t **l_673 = (void*)0;
                        uint32_t **l_674 = &g_672;
                        int64_t *l_675 = &g_676;
                        int i;
                        if ((*g_288))
                            break;
                        (*l_631) = (((((3UL < g_68[0]) , (g_104[g_155] = l_584)) <= ((*l_675) &= (safe_add_func_uint64_t_u_u((safe_sub_func_int16_t_s_s(g_3, (safe_mul_func_uint8_t_u_u(((~(**g_278)) <= (((((*l_587) = 0x7DD806E890986840LL) || ((g_271 , l_671) <= (((*l_674) = g_672) != (void*)0))) , p_41) & 0xAC17L)), 0x25L)))), l_656)))) < p_43) == 0x381FL);
                    }
                    else
                    { /* block id: 324 */
                        int16_t **l_692[6][1];
                        int32_t **l_702 = &g_60;
                        int32_t **l_703[6] = {&l_632[0][4][1],&l_632[0][4][1],&l_632[0][4][1],&l_632[0][4][1],&l_632[0][4][1],&l_632[0][4][1]};
                        int i, j;
                        for (i = 0; i < 6; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_692[i][j] = &l_653;
                        }
                        (*g_602) = (l_626 = ((*l_702) = ((p_44 != (safe_add_func_int64_t_s_s((safe_add_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_s((l_656 ^ (safe_rshift_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u(((((g_693[0] = l_691[1][0]) == (l_695 = l_694)) && 0L) | p_41), (p_41 , (safe_add_func_uint16_t_u_u((l_609 = l_698), (l_699 != l_700)))))) | 0x75L), 5))), 0)) & 1UL), 0x2B8AL)), g_271)), 65535UL)), 0x6B7F66F17ABE5FAFLL))) , (void*)0)));
                    }
                    if (((safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_u(((((***l_649) = (((*g_672) ^= (((((safe_rshift_func_int8_t_s_s((safe_div_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(((*l_631) = ((safe_add_func_uint32_t_u_u((&p_44 != &g_324), 0xFE108705L)) >= ((-6L) == l_654))), (l_633 ^= ((((*l_587) |= ((p_43 &= ((p_42 ^ (&p_44 == &g_324)) ^ (((safe_rshift_func_int8_t_s_s((-2L), g_211)) , g_4) >= g_271))) != 0xA5L)) != p_45) ^ g_102)))), p_42)), g_6)) <= p_45) , &g_510) != g_720) >= p_44)) > p_44)) , l_633) == 0xC568ED44L), g_68[2])), 0UL)) > 0xE28EAB3DL))
                    { /* block id: 338 */
                        (*l_628) = ((void*)0 == &g_314);
                    }
                    else
                    { /* block id: 340 */
                        if (p_43)
                            break;
                    }
                }
                if ((p_42 > ((*l_581) & (*l_631))))
                { /* block id: 344 */
                    int16_t **l_723 = &l_722;
                    int16_t **l_724 = &l_691[1][0];
                    (*l_631) ^= (((*l_723) = l_722) == ((*l_724) = (p_41 , (void*)0)));
                }
                else
                { /* block id: 348 */
                    l_599 = &l_627[1][3];
                    (*g_721) = &l_615;
                }
                for (l_634 = 0; (l_634 != 52); l_634 = safe_add_func_int32_t_s_s(l_634, 5))
                { /* block id: 354 */
                    const int32_t **l_727 = &g_601;
                    (*l_727) = (*g_602);
                    l_728 = (*l_727);
                }
            }
        }
        else
        { /* block id: 359 */
            int32_t *l_729 = &g_271;
            for (l_615 = 0; (l_615 <= 0); l_615 += 1)
            { /* block id: 362 */
                int32_t **l_730[7][2][2] = {{{&l_581,&l_581},{&g_60,&l_581}},{{&g_60,&g_60},{&g_60,&l_581}},{{&g_60,&l_581},{&l_581,&l_581}},{{&l_581,&g_60},{&l_581,&l_581}},{{&l_581,&g_60},{&l_581,&g_60}},{{&g_60,&g_60},{&l_581,&g_60}},{{&l_581,&l_581},{&l_581,&g_60}}};
                int i, j, k;
                (**g_720) = (l_580 = l_729);
                return g_324;
            }
        }
        l_731 = (p_42 , &l_615);
    }
lbl_747:
    g_271 &= (safe_add_func_uint32_t_u_u(0x124EC93AL, ((((g_195 ^ (((-4L) > (safe_rshift_func_int16_t_s_s(0L, (safe_lshift_func_uint16_t_u_u(((((safe_div_func_uint64_t_u_u((0x0EL ^ ((((p_42 != (safe_mod_func_int16_t_s_s(((g_151 = (0xF3EFBD92L & 4294967292UL)) , (((safe_mod_func_int32_t_s_s((*l_731), 9UL)) , 4294967292UL) && p_41)), (*l_731)))) & (*g_279)) == 4L) | (*l_731))), (*l_731))) != 1L) < 1L) < 1UL), g_155))))) <= g_104[7])) , (void*)0) == &g_432) < 0x78F5L)));
    for (l_584 = (-21); (l_584 < 3); l_584++)
    { /* block id: 374 */
        int16_t l_751[1][4][2] = {{{0xD1ACL,0xD1ACL},{0xD1ACL,0xD1ACL},{0xD1ACL,0xD1ACL},{0xD1ACL,0xD1ACL}}};
        int8_t *l_772[3][8] = {{&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0},{&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0},{&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0,&g_252,(void*)0}};
        int32_t l_774 = 0xBF3ADEBBL;
        uint64_t **l_801[8][10][3] = {{{&g_279,(void*)0,&g_279},{(void*)0,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,&g_279,(void*)0},{(void*)0,(void*)0,&g_279},{&g_279,&g_279,&g_279},{(void*)0,(void*)0,&g_279}},{{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,(void*)0,&g_279},{(void*)0,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,&g_279,(void*)0}},{{(void*)0,(void*)0,&g_279},{&g_279,&g_279,&g_279},{(void*)0,(void*)0,&g_279},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,(void*)0,&g_279},{(void*)0,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,(void*)0,&g_279}},{{&g_279,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,&g_279,(void*)0},{(void*)0,(void*)0,&g_279},{&g_279,&g_279,&g_279},{(void*)0,(void*)0,&g_279},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,(void*)0,&g_279}},{{(void*)0,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,&g_279,(void*)0},{(void*)0,(void*)0,&g_279},{&g_279,(void*)0,&g_279},{&g_279,&g_279,(void*)0},{(void*)0,&g_279,&g_279}},{{(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279},{(void*)0,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,(void*)0,&g_279},{(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279},{(void*)0,&g_279,&g_279}},{{&g_279,(void*)0,&g_279},{&g_279,&g_279,(void*)0},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279},{(void*)0,&g_279,&g_279},{&g_279,&g_279,(void*)0},{&g_279,(void*)0,&g_279},{(void*)0,&g_279,&g_279}},{{&g_279,&g_279,&g_279},{&g_279,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,(void*)0,&g_279},{&g_279,&g_279,(void*)0},{(void*)0,&g_279,&g_279},{(void*)0,&g_279,&g_279},{&g_279,&g_279,&g_279},{&g_279,(void*)0,&g_279},{(void*)0,&g_279,&g_279}}};
        uint16_t ***l_811[6][6][7] = {{{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,(void*)0,(void*)0,&l_650},{&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650,&l_650}},{{&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,(void*)0},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650}},{{&l_650,&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650},{&l_650,(void*)0,(void*)0,&l_650,&l_650,&l_650,(void*)0},{&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650}},{{&l_650,&l_650,&l_650,(void*)0,(void*)0,&l_650,&l_650},{&l_650,&l_650,&l_650,(void*)0,(void*)0,(void*)0,&l_650},{&l_650,(void*)0,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,(void*)0},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,(void*)0}},{{(void*)0,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650},{(void*)0,(void*)0,&l_650,&l_650,&l_650,(void*)0,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650}},{{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{(void*)0,&l_650,(void*)0,(void*)0,&l_650,&l_650,&l_650},{(void*)0,(void*)0,&l_650,&l_650,&l_650,&l_650,(void*)0},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,(void*)0},{&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650,&l_650},{(void*)0,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650}}};
        int32_t l_815 = (-1L);
        int64_t *l_944 = &g_350;
        int64_t l_973 = (-3L);
        int32_t l_1007 = 1L;
        int32_t * const *l_1030 = &l_744[8][1];
        int32_t * const **l_1029 = &l_1030;
        int32_t * const **l_1032 = &l_1030;
        int16_t l_1099[9] = {0xCF8EL,0xEF7FL,0xCF8EL,0xEF7FL,0xCF8EL,0xEF7FL,0xCF8EL,0xEF7FL,0xCF8EL};
        int16_t l_1136 = 1L;
        int32_t l_1161 = (-4L);
        int32_t l_1164 = 8L;
        int i, j, k;
        if (g_325)
            goto lbl_747;
        if ((safe_sub_func_int8_t_s_s((((!(0x1EL && l_751[0][0][0])) != 0UL) > ((((safe_lshift_func_int8_t_s_u(((*l_731) != (p_42 & ((safe_div_func_uint8_t_u_u((((**g_506) = (safe_lshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_u(0x52B9L, 8)) & (safe_mod_func_uint64_t_u_u((((safe_sub_func_uint16_t_u_u(((safe_mod_func_int8_t_s_s((-1L), ((l_773 = ((0x613471908157C565LL & ((safe_mod_func_int32_t_s_s((0x28L ^ g_68[2]), 1UL)) == 0xED253B48L)) == g_7)) , g_252))) ^ 0UL), p_41)) < l_751[0][3][1]) , (**g_278)), p_43))), 5)) , g_61), 0UL)), g_212))) && (*g_672)), 1L)) >= 0x3FL))), 3)) != p_43) ^ g_102) || l_774)), p_42)))
        { /* block id: 378 */
            int32_t l_779 = 0xD8F4CE28L;
            uint64_t l_799 = 0xA6D2DF6705810FE9LL;
            const uint16_t * const l_814 = &g_68[6];
            const uint16_t * const *l_813 = &l_814;
            const uint16_t * const ** const l_812 = &l_813;
            int32_t l_875 = 0xFB8E971AL;
            const int32_t **l_882 = (void*)0;
            uint16_t l_883[10][4][1] = {{{0xDF6EL},{0xDF6EL},{0x6516L},{0xA09CL}},{{2UL},{0xAD50L},{65535UL},{0x07C3L}},{{0xDE37L},{1UL},{0xDE37L},{0x07C3L}},{{65535UL},{0xAD50L},{2UL},{0xA09CL}},{{0x6516L},{0xDF6EL},{0xDF6EL},{0x6516L}},{{0xA09CL},{2UL},{0xAD50L},{2UL}},{{0x6DA1L},{1UL},{0xAD50L},{1UL}},{{0x6DA1L},{2UL},{0x6516L},{0x5947L}},{{0xDE37L},{65530UL},{0x5B75L},{0x5B75L}},{{65530UL},{0xDE37L},{0x5947L},{0x6516L}}};
            int i, j, k;
            if (l_751[0][0][0])
                break;
            for (g_325 = 12; (g_325 <= 9); g_325 = safe_sub_func_int8_t_s_s(g_325, 8))
            { /* block id: 382 */
                uint8_t l_781 = 255UL;
                int32_t l_800 = (-6L);
                uint64_t **l_802 = &g_279;
                uint16_t l_841 = 6UL;
                int8_t ***l_851 = &g_846;
                for (l_774 = (-26); (l_774 <= 22); l_774 = safe_add_func_uint64_t_u_u(l_774, 2))
                { /* block id: 385 */
                    int16_t l_780[4][8] = {{1L,1L,0x10F2L,0x9160L,0x8BB5L,0x9160L,0x10F2L,1L},{0x6C18L,0x10F2L,(-6L),0x9160L,(-9L),3L,3L,(-9L)},{(-10L),(-9L),(-9L),(-10L),0x6C18L,1L,3L,1L},{0x10F2L,(-10L),(-6L),3L,(-6L),(-10L),0x10F2L,0x8BB5L}};
                    const int32_t *l_798 = &l_615;
                    int32_t l_818[1];
                    uint32_t *l_825 = &g_826;
                    int32_t l_874 = 2L;
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_818[i] = (-9L);
                    ++l_781;
                    l_800 &= (safe_mul_func_int8_t_s_s(((safe_lshift_func_int8_t_s_u(g_320[1][2][1], (((((safe_rshift_func_int8_t_s_u((safe_add_func_int16_t_s_s((1L != ((((l_751[0][0][0] == (((**g_278) = ((+(!p_43)) & (safe_add_func_int32_t_s_s((((safe_mul_func_uint16_t_u_u(65528UL, p_41)) , (p_44 == p_42)) , (0UL & p_42)), l_751[0][2][0])))) != g_324)) & p_45) , &l_633) == l_798)), (-1L))), 6)) == l_779) && p_43) , l_799) || (*l_798)))) , p_41), g_271));
                    l_818[0] ^= (((***l_649) = (l_801[1][4][1] != l_802)) <= (((g_803 = g_803) == l_806) & ((l_815 = ((safe_lshift_func_int8_t_s_s((((!l_781) , l_811[0][3][6]) != l_812), 6)) < l_751[0][0][1])) , (safe_lshift_func_uint16_t_u_s(p_44, l_774)))));
                    if ((0x843389651049066CLL <= ((*g_672) ^ (((l_781 , l_800) & ((*l_722) = (safe_rshift_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(((p_43 = (((*l_825) = l_779) & (safe_mod_func_uint16_t_u_u(((~(((safe_sub_func_uint64_t_u_u((~p_41), g_320[4][3][0])) | (safe_rshift_func_int8_t_s_s(l_800, 5))) != (((((safe_rshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u((g_212 = (safe_div_func_uint16_t_u_u(((((0x2D0546B5E65F8825LL == 18446744073709551613UL) == l_751[0][0][0]) && 65527UL) | (*l_798)), 0x27F2L))), l_800)), l_779)) , l_774) | p_45) && p_41) == 249UL))) , l_781), p_42)))) && g_104[0]), p_41)) && l_841), p_44)))) < l_774))))
                    { /* block id: 397 */
                        int8_t ****l_847 = (void*)0;
                        int8_t ****l_848 = (void*)0;
                        int8_t ****l_849 = &g_845;
                        int8_t ****l_850 = &l_806;
                        int8_t ****l_852 = &l_851;
                        uint32_t ***l_858 = &l_857;
                        const int32_t l_871 = 0x6FE11A3CL;
                        uint8_t l_872 = 255UL;
                        int64_t *l_873[9][5] = {{&g_350,&g_350,&g_350,&g_350,&g_676},{&g_350,(void*)0,&g_350,(void*)0,&g_676},{&g_350,&g_350,&g_350,&g_350,&g_350},{&g_350,(void*)0,&g_676,&g_350,&g_350},{&g_350,&g_350,&g_676,(void*)0,(void*)0},{&g_350,&g_350,&g_350,(void*)0,&g_350},{&g_350,(void*)0,&g_350,(void*)0,&g_350},{&g_350,&g_676,(void*)0,(void*)0,&g_676},{&g_676,&g_350,&g_350,&g_350,&g_676}};
                        int i, j;
                        if (l_698)
                            goto lbl_747;
                        if (g_676)
                            goto lbl_842;
                        l_875 &= (((l_874 ^= ((safe_mul_func_int16_t_s_s((((*l_850) = ((*l_849) = g_845)) != ((*l_852) = l_851)), ((safe_lshift_func_int8_t_s_s((l_818[0] = (safe_mul_func_uint8_t_u_u((p_41 != (&g_672 != ((*l_858) = l_857))), ((safe_mod_func_int32_t_s_s((0xDFED1ABAF480FDA3LL < (l_815 |= ((safe_add_func_int16_t_s_s((((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(65530UL, (safe_div_func_uint64_t_u_u((safe_div_func_int16_t_s_s(((*l_722) = (((void*)0 == (*l_649)) == 0x99549FB0FF084504LL)), p_44)), 18446744073709551615UL)))), 1)) ^ 251UL) , l_871), l_872)) <= g_68[4]))), l_774)) >= (*g_507))))), 7)) ^ l_779))) == l_872)) | l_751[0][0][0]) ^ 1UL);
                    }
                    else
                    { /* block id: 409 */
                        if (l_781)
                            break;
                        (**g_720) = &l_615;
                    }
                }
            }
            (*l_731) = ((((*l_722) = (safe_mod_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(((void*)0 != &l_731), 2)), (((***l_649) = 6UL) && 0x0224L)))) && (((**l_650) &= l_779) | (((l_779 , (0x8734L & (safe_add_func_uint64_t_u_u((l_799 , (((&l_799 != (*g_278)) , l_882) == &l_744[8][7])), p_41)))) & g_3) == l_883[9][2][0]))) , l_751[0][0][0]);
            l_744[5][5] = &l_615;
        }
        else
        { /* block id: 420 */
            int64_t l_900[5][8] = {{1L,0x7ABFB717B8534C3BLL,0x8583FC6F87B0919DLL,(-9L),(-9L),0x8583FC6F87B0919DLL,0x7ABFB717B8534C3BLL,1L},{0x7ABFB717B8534C3BLL,(-4L),1L,0xBBBE6B68F270C1EBLL,1L,(-4L),0x7ABFB717B8534C3BLL,0x7ABFB717B8534C3BLL},{(-4L),0xBBBE6B68F270C1EBLL,0x8583FC6F87B0919DLL,0x8583FC6F87B0919DLL,0xBBBE6B68F270C1EBLL,(-4L),(-9L),(-4L)},{0xBBBE6B68F270C1EBLL,(-4L),(-9L),(-4L),0xBBBE6B68F270C1EBLL,0x8583FC6F87B0919DLL,0x8583FC6F87B0919DLL,0xBBBE6B68F270C1EBLL},{(-4L),0x7ABFB717B8534C3BLL,0x7ABFB717B8534C3BLL,(-4L),1L,0xBBBE6B68F270C1EBLL,1L,(-4L)}};
            uint8_t *l_901 = &g_151;
            int32_t l_902 = 0L;
            uint32_t **l_917[6][8] = {{(void*)0,&g_672,&g_672,&g_672,(void*)0,&g_672,(void*)0,&g_672},{&g_507,&g_672,&g_507,(void*)0,(void*)0,(void*)0,&g_507,&g_672},{(void*)0,(void*)0,&g_507,&g_672,&g_507,(void*)0,(void*)0,(void*)0},{(void*)0,&g_672,&g_672,&g_672,(void*)0,&g_672,(void*)0,&g_672},{&g_507,&g_672,&g_507,(void*)0,(void*)0,(void*)0,&g_507,&g_672},{(void*)0,(void*)0,&g_507,&g_672,&g_507,(void*)0,(void*)0,(void*)0}};
            int8_t **l_930[5];
            int i, j;
            for (i = 0; i < 5; i++)
                l_930[i] = &l_772[0][4];
            l_902 &= ((*l_731) = (safe_sub_func_uint32_t_u_u(4UL, (((((safe_mul_func_int8_t_s_s(p_42, (safe_mul_func_int16_t_s_s((0x3D8F12A7L & (safe_lshift_func_int16_t_s_u((+(safe_sub_func_int32_t_s_s(0x9465A181L, (p_42 < p_42)))), 2))), ((((safe_mod_func_uint8_t_u_u(((*l_901) = ((p_43 = 0x87L) , ((safe_mul_func_uint8_t_u_u((((safe_unary_minus_func_int64_t_s((4294967293UL | (-1L)))) != l_900[4][1]) ^ 4294967290UL), 0xA3L)) > l_900[0][2]))), l_815)) || l_900[0][4]) , g_320[4][3][5]) ^ p_41))))) & p_42) , (*g_431)) == &p_42) != l_751[0][0][0]))));
            for (p_43 = 0; (p_43 == (-14)); --p_43)
            { /* block id: 427 */
                (**g_720) = &l_902;
                for (g_325 = 0; (g_325 >= 22); ++g_325)
                { /* block id: 431 */
                    (**l_595) = &g_279;
                    if (p_41)
                        continue;
                    if ((*g_173))
                        continue;
                }
            }
            (*g_721) = &l_902;
            (*l_731) ^= (safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_u(l_902, (((**g_278) = (p_43 != l_913)) , (safe_div_func_uint32_t_u_u((~((l_917[0][5] != l_857) == ((safe_rshift_func_uint16_t_u_u(((((safe_mod_func_int8_t_s_s(((((safe_sub_func_int8_t_s_s(((p_41 , ((safe_rshift_func_uint16_t_u_u(((safe_unary_minus_func_uint32_t_u((~p_45))) & (safe_add_func_uint16_t_u_u(65529UL, (((((l_801[6][9][1] != &g_279) , l_815) || (**g_278)) , (*g_803)) == l_930[3])))), 5)) | (**g_278))) , l_900[4][1]), g_68[2])) && 65528UL) & p_45) > p_42), 252UL)) != 0UL) && g_5) & p_42), 0)) , l_902))), (**g_506)))))) && (-1L)), g_271)) <= 0x009EA5E05D8903F8LL), g_324));
        }
    }
    for (g_151 = 0; (g_151 <= 0); g_151 += 1)
    { /* block id: 565 */
        int i;
        for (g_350 = 7; (g_350 >= 1); g_350 -= 1)
        { /* block id: 568 */
            if (g_271)
                goto lbl_747;
        }
        return g_104[(g_151 + 1)];
    }
    return p_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_324 g_104 g_279 g_102 g_271 g_5 g_212 g_68 g_507
 * writes: g_324 g_71
 */
static uint32_t  func_46(uint32_t  p_47)
{ /* block id: 273 */
    int64_t l_557 = 0L;
    uint64_t **l_575 = &g_279;
    int32_t l_577 = 9L;
    for (g_324 = 8; (g_324 >= 0); g_324 -= 1)
    { /* block id: 276 */
        uint64_t ***l_576 = (void*)0;
        int i;
        l_577 &= ((((*g_507) = (g_104[g_324] <= ((*g_279) >= ((safe_div_func_uint16_t_u_u((l_557 && (!(safe_mod_func_int32_t_s_s((safe_mul_func_uint8_t_u_u((0x452EL <= ((p_47 , p_47) < (safe_unary_minus_func_int8_t_s(((safe_lshift_func_int16_t_s_u((safe_unary_minus_func_uint32_t_u(((safe_div_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_sub_func_int64_t_s_s((p_47 && (&g_279 == (l_575 = l_575))), g_271)), p_47)), g_5)) ^ g_212))), p_47)) > g_104[g_324]))))), p_47)), g_104[g_324])))), g_68[6])) , g_104[g_324])))) | 0x24ED2F05L) , p_47);
    }
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_4 g_7 g_6 g_68 g_61 g_151 g_3 g_155 g_195 g_174 g_60 g_212 g_102 g_507 g_278 g_279
 * writes: g_102 g_104 g_71 g_68 g_151 g_155 g_61 g_195 g_60 g_212
 */
static int8_t  func_50(uint32_t  p_51, int8_t  p_52, uint32_t  p_53)
{ /* block id: 16 */
    uint16_t * const l_91 = &g_68[2];
    int32_t l_100 = (-1L);
    int32_t l_124 = 0x9A49A9C0L;
    int64_t l_138 = 0xE654CDFF1806A296LL;
    uint64_t *l_149 = &g_102;
    uint16_t *l_165 = (void*)0;
    int32_t *l_178 = &l_124;
    int32_t l_194 = 0x41DADCECL;
    int32_t l_204 = 0x5BF07671L;
    int32_t l_207 = (-2L);
    int32_t l_208 = 0L;
    int32_t l_209 = 0x8DDEBA2DL;
    int32_t l_210[4][5][7] = {{{0L,0x95C9495EL,2L,1L,(-7L),0L,(-7L)},{1L,0x0C672968L,0xBE829238L,2L,3L,0x03F8E5C4L,0x203F3C9CL},{0x2024EE24L,0xF7EB3699L,1L,0L,(-1L),0x001B5967L,0xDD36E1F2L},{0x001B5967L,0xC7054000L,0x2024EE24L,0xD52DE870L,0xC5E5C33BL,(-1L),0x8D4B36AFL},{0xB048B095L,0L,0xC5E5C33BL,1L,0x95C9495EL,0x0C6C6CD6L,1L}},{{0xDD36E1F2L,0xBE829238L,1L,1L,0xC7054000L,0x891246E7L,0L},{(-1L),0xF8EE6FD2L,(-9L),0xD52DE870L,0xD27D01E9L,0L,0x891246E7L},{0L,0xAAB65A99L,0x9407D1EAL,0L,0x9407D1EAL,0xAAB65A99L,0L},{0xF7EB3699L,1L,0x5C39C69AL,2L,(-1L),1L,0x190030C7L},{(-10L),0L,2L,0x68D1301EL,0x2024EE24L,0L,2L}},{{0x4DAEAD15L,0x9407D1EAL,0x5C39C69AL,0xD75997CBL,0L,0xD52DE870L,0xB5D410D0L},{0L,7L,0x9407D1EAL,2L,1L,(-1L),(-1L)},{0L,0L,(-9L),(-10L),0L,0xD27D01E9L,0xC5E5C33BL},{1L,0x891246E7L,1L,0L,0xF7EB3699L,0xC5E5C33BL,0xAED5F3CCL},{0x4AC731D9L,0x891246E7L,0xC5E5C33BL,3L,(-4L),2L,0xD27D01E9L}},{{0x8D4B36AFL,0L,0x2024EE24L,0xB048B095L,1L,0L,0L},{0xFBB2B88AL,7L,1L,7L,0xFBB2B88AL,3L,0x0C672968L},{0xC5E5C33BL,0x9407D1EAL,0xBE829238L,1L,2L,7L,1L},{0L,0L,(-1L),0xF8EE6FD2L,0x0C6C6CD6L,0x4DD74674L,0x68D1301EL},{0xC5E5C33BL,1L,0xA1803D16L,1L,(-7L),0x4DAEAD15L,0xF7EB3699L}}};
    uint8_t * const l_243 = &g_151;
    uint32_t l_305 = 0UL;
    int64_t l_418 = 0xF4ED036454BA2A83LL;
    volatile uint16_t **l_434 = (void*)0;
    uint8_t l_475[9][2][5] = {{{247UL,4UL,1UL,0x37L,4UL},{0UL,255UL,255UL,0UL,249UL}},{{1UL,0UL,246UL,4UL,4UL},{255UL,0UL,255UL,249UL,0UL}},{{4UL,1UL,0x37L,4UL,0x37L},{248UL,248UL,0xEEL,0UL,254UL}},{{247UL,1UL,0x37L,0x37L,1UL},{254UL,255UL,255UL,254UL,249UL}},{{0UL,1UL,246UL,1UL,0UL},{255UL,248UL,255UL,249UL,248UL}},{{0UL,1UL,1UL,0UL,0x37L},{254UL,0UL,0xEEL,248UL,255UL}},{{0x78L,1UL,0x78L,1UL,1UL},{255UL,0xEEL,3UL,255UL,3UL}},{{247UL,247UL,4UL,1UL,0x37L},{0x9AL,249UL,3UL,3UL,249UL}},{{0x37L,246UL,0x78L,0x37L,1UL},{255UL,249UL,248UL,249UL,255UL}}};
    uint32_t **l_518 = &g_507;
    int8_t *l_539 = &g_252;
    int8_t **l_538 = &l_539;
    const uint16_t l_544 = 0xB38DL;
    uint16_t l_549 = 0UL;
    int32_t **l_550 = &g_60;
    uint8_t *l_551 = (void*)0;
    uint8_t *l_552 = &l_475[1][1][1];
    int32_t *l_553 = (void*)0;
    int32_t l_554 = 0x5953CF1CL;
    int i, j, k;
    if (((safe_add_func_int32_t_s_s((g_71 ^ ((safe_div_func_uint16_t_u_u((((((safe_div_func_int64_t_s_s(((((void*)0 == &g_6) & ((safe_sub_func_uint16_t_u_u(0UL, (safe_rshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((((safe_lshift_func_int16_t_s_s((g_4 & (((safe_mul_func_int16_t_s_s((safe_add_func_int64_t_s_s((((void*)0 == l_91) >= (g_7 , (((((safe_sub_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u((p_53 >= p_52), p_53)) , 0x36032EE7L), 0L)), p_51)), p_53)) , &g_68[2]) != &g_68[5]) == p_52) ^ l_100))), g_6)), g_68[2])) , g_71) > g_6)), 8)) == p_53) <= l_100), g_68[2])), p_51)))) , l_100)) > p_51), g_7)) > g_68[2]) , l_100) < 0xEAFEL) > l_100), g_6)) != l_100)), g_71)) , 0L))
    { /* block id: 17 */
        uint64_t *l_101 = &g_102;
        uint64_t *l_103 = &g_104[8];
        uint32_t *l_107 = (void*)0;
        uint32_t *l_108 = &g_71;
        int32_t l_123 = 0x1004047EL;
        uint64_t **l_148[4][5][8] = {{{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0,&l_103,&l_103},{&l_103,&l_101,&l_103,&l_103,&l_101,&l_103,&l_101,&l_103},{(void*)0,&l_101,(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0}},{{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0,&l_103,&l_103},{&l_103,&l_101,&l_103,&l_103,&l_101,&l_103,&l_101,&l_103},{(void*)0,&l_101,(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0}},{{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0,&l_103,&l_103},{&l_103,&l_101,&l_103,&l_103,&l_101,&l_103,&l_101,&l_103},{(void*)0,&l_101,(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0}},{{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103,&l_103},{(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0,&l_103,&l_103},{&l_103,&l_101,&l_103,&l_103,&l_101,&l_103,&l_101,&l_103},{(void*)0,&l_101,(void*)0,&l_103,&l_103,(void*)0,&l_101,(void*)0}}};
        uint8_t *l_150 = &g_151;
        int32_t l_152 = 8L;
        uint16_t *l_153 = (void*)0;
        uint16_t *l_154 = &g_155;
        int16_t l_166[4] = {(-1L),(-1L),(-1L),(-1L)};
        int i, j, k;
        l_124 &= ((((*l_103) = ((*l_101) = g_68[2])) < (safe_mod_func_int16_t_s_s(((((++(*l_108)) > (p_52 ^ 65533UL)) || (safe_lshift_func_int16_t_s_s((6UL >= (safe_unary_minus_func_int32_t_s(((~(safe_add_func_uint16_t_u_u(((safe_div_func_int16_t_s_s(g_4, g_68[2])) <= (safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((p_53 & (l_100 >= 65535UL)), 0x80F2L)), p_53))), l_123))) == 65535UL)))), 10))) , (-1L)), 0x4979L))) != l_123);
        if ((safe_mul_func_uint8_t_u_u(((!((safe_lshift_func_int16_t_s_u(p_52, ((*l_154) = (((safe_div_func_uint32_t_u_u((((0xA538DB7DL >= (safe_rshift_func_uint8_t_u_u((5L ^ (safe_add_func_int16_t_s_s((((safe_rshift_func_int16_t_s_u(l_138, 12)) || (p_51 != (~(((*l_150) ^= ((safe_mul_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((l_123 = ((((*l_91) = l_123) , ((l_149 = ((safe_rshift_func_int16_t_s_s(0x44D6L, (((*l_91)--) != 0L))) , l_103)) == (void*)0)) && l_123)) , g_61), 7UL)), 1L)) >= l_138)) <= 255UL)))) | 0x5C008FFCL), l_152))), 0))) <= g_3) , p_51), l_152)) ^ l_152) | (-1L))))) || p_53)) , 7UL), g_71)))
        { /* block id: 28 */
            int32_t *l_156 = &l_152;
            (*l_156) &= (g_61 = g_155);
            (*l_156) = (((safe_div_func_uint8_t_u_u(p_51, (safe_mul_func_int16_t_s_s(p_52, (((safe_sub_func_uint8_t_u_u(l_124, ((*l_156) || ((0xF280801E7C2DC33BLL < ((&l_152 == &g_5) != (5L ^ ((safe_div_func_int32_t_s_s(((p_51 , (*l_156)) > g_68[2]), 4294967291UL)) , 0xDDAE05CFL)))) , (*l_156))))) < 0x69A0L) <= 0UL))))) | p_51) | 5L);
            l_123 = ((((void*)0 != l_165) && p_51) != ((*l_156) = ((l_166[2] , p_53) != ((p_52 , (safe_rshift_func_uint16_t_u_u((((safe_mod_func_uint8_t_u_u(((p_52 & (p_51 <= (p_51 && 4294967295UL))) , l_166[3]), p_53)) < p_53) , p_51), 1))) == l_100))));
        }
        else
        { /* block id: 34 */
            int32_t l_190 = 1L;
            int32_t *l_191 = &l_123;
            int32_t *l_192 = &l_123;
            int32_t *l_193[4][2][4] = {{{&g_7,&g_7,&l_152,&l_124},{&l_124,&l_124,&l_152,&l_124}},{{&g_7,&g_61,&l_100,&l_152},{&l_124,&g_61,&g_61,&l_124}},{{&g_61,&l_124,&g_7,&l_124},{&g_61,&g_7,&g_61,&l_100}},{{&l_124,&l_124,&l_100,&l_100},{&g_7,&g_7,&l_152,&l_124}}};
            int32_t **l_202 = &l_193[0][0][1];
            int i, j, k;
            for (g_61 = 0; (g_61 != 20); g_61++)
            { /* block id: 37 */
                int32_t **l_189 = &l_178;
            }
            ++g_195;
            (*l_178) = (safe_lshift_func_int8_t_s_u(g_174, (safe_mod_func_uint64_t_u_u(p_53, g_174))));
            (*l_202) = l_191;
        }
    }
    else
    { /* block id: 64 */
        int32_t **l_203 = &g_60;
        int32_t *l_205 = &l_194;
        int32_t *l_206[9];
        int i;
        for (i = 0; i < 9; i++)
            l_206[i] = &g_61;
        (*l_203) = &l_124;
        (**l_203) = l_204;
        g_212--;
        (*l_205) ^= ((**l_203) = 0x3DF18954L);
    }
    if (g_61)
        goto lbl_533;
lbl_533:
    for (l_209 = (-1); (l_209 <= 11); l_209++)
    { /* block id: 73 */
        int32_t * const * const l_223 = &g_60;
        int32_t l_226 = 3L;
        uint16_t *l_238 = &g_68[2];
        uint16_t l_253 = 65531UL;
        uint32_t l_254 = 1UL;
        uint8_t l_272 = 1UL;
        uint64_t ***l_306 = &g_278;
        uint32_t l_308 = 0x47F54339L;
        int32_t *l_315 = &l_100;
        int16_t *l_321 = (void*)0;
        int16_t *l_322 = (void*)0;
        int16_t *l_323 = &g_324;
        uint32_t l_371 = 0x87140BE0L;
        int64_t * const l_385 = &g_350;
        int32_t l_488 = 0xCE3A1D83L;
        int32_t l_489 = 0x03EADAD5L;
        int32_t l_490 = 0L;
        int32_t l_491[2];
        int i;
        for (i = 0; i < 2; i++)
            l_491[i] = 0L;
    }
    if ((!g_3))
    { /* block id: 260 */
        (*l_178) |= (safe_lshift_func_uint8_t_u_s(0UL, 3));
        l_178 = (void*)0;
    }
    else
    { /* block id: 263 */
        int8_t ***l_537 = (void*)0;
        (*l_178) = p_52;
        l_538 = (void*)0;
    }
    l_207 |= (safe_mod_func_uint8_t_u_u(((((((((((safe_rshift_func_uint8_t_u_u((((((l_544 >= (&g_352 != &p_52)) | p_52) >= ((*l_552) = ((*l_243) &= (safe_rshift_func_uint8_t_u_s((((*g_507) = (((((safe_add_func_uint16_t_u_u(l_549, g_102)) , (((*l_550) = &l_210[0][3][2]) != (void*)0)) , (*l_550)) != (void*)0) & 0xD2C4DF94L)) & 0xB5CDEC1CL), 1))))) || (**l_550)) == 0x0F205E0FL), 7)) ^ p_51) <= p_52) | (**g_278)) | p_52) && 0x293BL) == p_51) , 0UL) | g_212) && (*g_279)), 255UL));
    return l_554;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_61 g_71 g_6
 * writes: g_68 g_71 g_61
 */
static int16_t  func_56(int32_t * p_57, int32_t * p_58)
{ /* block id: 9 */
    int16_t l_64 = 0L;
    uint16_t *l_67 = &g_68[2];
    int32_t **l_70[6] = {&g_60,&g_60,&g_60,&g_60,&g_60,&g_60};
    int i;
    g_61 = ((safe_mod_func_int8_t_s_s((((void*)0 == p_57) || l_64), (safe_add_func_uint8_t_u_u((g_5 < (((*l_67) = g_7) < (g_71 &= ((g_61 | (((+g_7) , ((p_58 = &g_61) == (void*)0)) == 65528UL)) ^ 0L)))), g_6)))) && g_71);
    return g_7;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_68[i], "g_68[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_174, "g_174", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    transparent_crc(g_211, "g_211", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    transparent_crc(g_252, "g_252", print_hash_value);
    transparent_crc(g_271, "g_271", print_hash_value);
    transparent_crc(g_314, "g_314", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_320[i][j][k], "g_320[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_324, "g_324", print_hash_value);
    transparent_crc(g_325, "g_325", print_hash_value);
    transparent_crc(g_350, "g_350", print_hash_value);
    transparent_crc(g_352, "g_352", print_hash_value);
    transparent_crc(g_676, "g_676", print_hash_value);
    transparent_crc(g_826, "g_826", print_hash_value);
    transparent_crc(g_1037, "g_1037", print_hash_value);
    transparent_crc(g_1086, "g_1086", print_hash_value);
    transparent_crc(g_1282, "g_1282", print_hash_value);
    transparent_crc(g_1332, "g_1332", print_hash_value);
    transparent_crc(g_1518, "g_1518", print_hash_value);
    transparent_crc(g_1705, "g_1705", print_hash_value);
    transparent_crc(g_1709, "g_1709", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1859[i], "g_1859[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1906, "g_1906", print_hash_value);
    transparent_crc(g_2009, "g_2009", print_hash_value);
    transparent_crc(g_2051, "g_2051", print_hash_value);
    transparent_crc(g_2127, "g_2127", print_hash_value);
    transparent_crc(g_2160, "g_2160", print_hash_value);
    transparent_crc(g_2309, "g_2309", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 579
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 217
   depth: 2, occurrence: 46
   depth: 3, occurrence: 5
   depth: 5, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 5
   depth: 17, occurrence: 4
   depth: 18, occurrence: 3
   depth: 19, occurrence: 2
   depth: 20, occurrence: 3
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 1
   depth: 26, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 31, occurrence: 1
   depth: 32, occurrence: 3
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 2
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 41, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 508

XXX times a variable address is taken: 1270
XXX times a pointer is dereferenced on RHS: 227
breakdown:
   depth: 1, occurrence: 164
   depth: 2, occurrence: 45
   depth: 3, occurrence: 10
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
XXX times a pointer is dereferenced on LHS: 279
breakdown:
   depth: 1, occurrence: 218
   depth: 2, occurrence: 37
   depth: 3, occurrence: 19
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
XXX times a pointer is compared with null: 38
XXX times a pointer is compared with address of another variable: 16
XXX times a pointer is compared with another pointer: 24
XXX times a pointer is qualified to be dereferenced: 5924

XXX max dereference level: 7
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 958
   level: 2, occurrence: 419
   level: 3, occurrence: 248
   level: 4, occurrence: 95
   level: 5, occurrence: 37
   level: 6, occurrence: 35
   level: 7, occurrence: 11
XXX number of pointers point to pointers: 289
XXX number of pointers point to scalars: 219
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27
XXX average alias set size: 1.39

XXX times a non-volatile is read: 1810
XXX times a non-volatile is write: 905
XXX times a volatile is read: 95
XXX    times read thru a pointer: 27
XXX times a volatile is write: 61
XXX    times written thru a pointer: 35
XXX times a volatile is available for access: 1.13e+03
XXX percentage of non-volatile access: 94.6

XXX forward jumps: 1
XXX backward jumps: 14

XXX stmts: 215
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 29
   depth: 2, occurrence: 39
   depth: 3, occurrence: 25
   depth: 4, occurrence: 38
   depth: 5, occurrence: 49

XXX percentage a fresh-made variable is used: 18.2
XXX percentage an existing variable is used: 81.8
********************* end of statistics **********************/

