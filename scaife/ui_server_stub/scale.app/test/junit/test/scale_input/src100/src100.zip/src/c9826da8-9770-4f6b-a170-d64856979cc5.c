/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2064813954
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint8_t  f0;
   const signed f1 : 8;
   signed f2 : 10;
   int32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x58D32FFAL;
static uint16_t g_5[9] = {0xBD69L,0xBD69L,0xBD69L,0xBD69L,0xBD69L,0xBD69L,0xBD69L,0xBD69L,0xBD69L};
static int32_t *g_16[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint8_t g_30 = 0x51L;
static int64_t g_42 = 0x0F1A0197CBB40284LL;
static uint32_t g_45 = 0xF2DDFDAFL;
static uint8_t g_81 = 0xADL;
static uint8_t *g_82 = &g_81;
static uint16_t g_173 = 0x2155L;
static int16_t g_174 = 0xEC1FL;
static union U0 g_192[10] = {{254UL},{254UL},{254UL},{254UL},{254UL},{254UL},{254UL},{254UL},{254UL},{254UL}};
static uint64_t g_200 = 2UL;
static int8_t g_212 = (-1L);
static volatile int64_t g_213 = 0L;/* VOLATILE GLOBAL g_213 */
static const int32_t g_259[9][6] = {{1L,(-1L),1L,1L,(-1L),1L},{1L,(-1L),1L,1L,(-1L),1L},{1L,(-1L),1L,1L,(-1L),1L},{1L,(-1L),1L,1L,1L,0x112C0037L},{0x112C0037L,1L,0x112C0037L,0x112C0037L,1L,0x112C0037L},{0x112C0037L,1L,0x112C0037L,0x112C0037L,1L,0x112C0037L},{0x112C0037L,1L,0x112C0037L,0x112C0037L,1L,0x112C0037L},{0x112C0037L,1L,0x112C0037L,0x112C0037L,1L,0x112C0037L},{0x112C0037L,1L,0x112C0037L,0x112C0037L,1L,0x112C0037L}};
static volatile int16_t g_298 = (-10L);/* VOLATILE GLOBAL g_298 */
static int64_t g_350 = 0x030F7A7959F4360DLL;
static uint32_t *g_379 = (void*)0;
static uint32_t **g_378 = &g_379;
static uint64_t g_407 = 18446744073709551608UL;
static int8_t *g_409 = &g_212;
static uint32_t g_427[2][2] = {{18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL}};
static uint32_t * const g_426 = &g_427[1][1];
static uint32_t * const *g_425[4][6][2] = {{{&g_426,&g_426},{&g_426,&g_426},{&g_426,&g_426},{&g_426,(void*)0},{&g_426,&g_426},{(void*)0,&g_426}},{{(void*)0,&g_426},{&g_426,(void*)0},{&g_426,&g_426},{&g_426,&g_426},{&g_426,&g_426},{&g_426,&g_426}},{{&g_426,(void*)0},{&g_426,&g_426},{(void*)0,&g_426},{(void*)0,&g_426},{&g_426,(void*)0},{&g_426,&g_426}},{{&g_426,&g_426},{&g_426,&g_426},{&g_426,&g_426},{&g_426,(void*)0},{&g_426,&g_426},{(void*)0,&g_426}}};
static int32_t g_448 = 0xB4F65FEEL;
static int32_t * volatile g_447 = &g_448;/* VOLATILE GLOBAL g_447 */
static uint16_t **g_475 = (void*)0;
static uint8_t g_482 = 8UL;
static uint8_t **g_485 = &g_82;
static uint8_t **g_486 = &g_82;
static int32_t ** const  volatile g_487 = &g_16[1];/* VOLATILE GLOBAL g_487 */
static uint16_t g_502 = 65528UL;
static uint16_t g_516 = 0x1A17L;
static int32_t * volatile g_517 = &g_448;/* VOLATILE GLOBAL g_517 */
static const int8_t g_526 = 0x44L;
static volatile int32_t g_544 = 5L;/* VOLATILE GLOBAL g_544 */
static int32_t ** volatile g_571 = &g_16[1];/* VOLATILE GLOBAL g_571 */
static int32_t ** volatile g_597[10] = {&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[1]};
static int32_t ** volatile g_598 = &g_16[1];/* VOLATILE GLOBAL g_598 */
static volatile int16_t *g_724 = &g_298;
static volatile int16_t ** const g_723 = &g_724;
static volatile int16_t *** volatile g_725 = (void*)0;/* VOLATILE GLOBAL g_725 */
static volatile int16_t **g_727 = &g_724;
static volatile int16_t *** volatile g_726 = &g_727;/* VOLATILE GLOBAL g_726 */
static union U0 *g_733[3][5] = {{&g_192[3],&g_192[3],&g_192[3],&g_192[3],&g_192[3]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_192[3],&g_192[3],&g_192[3],&g_192[3],&g_192[3]}};
static union U0 ** const  volatile g_732 = &g_733[1][3];/* VOLATILE GLOBAL g_732 */
static union U0 ** volatile g_755 = &g_733[1][3];/* VOLATILE GLOBAL g_755 */
static uint16_t *** volatile g_776[5] = {&g_475,&g_475,&g_475,&g_475,&g_475};
static uint16_t *** volatile g_777 = (void*)0;/* VOLATILE GLOBAL g_777 */
static volatile int64_t g_841 = 2L;/* VOLATILE GLOBAL g_841 */
static volatile int64_t * volatile g_840 = &g_841;/* VOLATILE GLOBAL g_840 */
static volatile int64_t * volatile *g_839 = &g_840;
static volatile int64_t * volatile * volatile *g_838 = &g_839;
static uint32_t g_896 = 0x9FEC3333L;
static volatile int16_t *** volatile g_930 = &g_727;/* VOLATILE GLOBAL g_930 */
static uint64_t g_967[5] = {0x468868712EC1DB94LL,0x468868712EC1DB94LL,0x468868712EC1DB94LL,0x468868712EC1DB94LL,0x468868712EC1DB94LL};
static uint32_t g_978 = 18446744073709551607UL;
static int32_t ** volatile g_1036[10][8][3] = {{{&g_16[4],&g_16[1],&g_16[2]},{&g_16[4],(void*)0,(void*)0},{&g_16[2],&g_16[3],&g_16[4]},{&g_16[1],&g_16[4],&g_16[1]},{&g_16[2],&g_16[1],&g_16[1]},{&g_16[4],&g_16[1],(void*)0},{&g_16[4],&g_16[1],&g_16[4]},{(void*)0,&g_16[4],&g_16[1]}},{{(void*)0,&g_16[3],&g_16[4]},{&g_16[1],(void*)0,(void*)0},{(void*)0,&g_16[1],&g_16[1]},{&g_16[1],&g_16[1],&g_16[1]},{(void*)0,&g_16[1],&g_16[4]},{(void*)0,&g_16[1],(void*)0},{&g_16[4],&g_16[1],&g_16[2]},{&g_16[4],(void*)0,(void*)0}},{{&g_16[2],&g_16[3],&g_16[4]},{&g_16[1],&g_16[4],&g_16[1]},{&g_16[2],&g_16[1],&g_16[1]},{&g_16[4],&g_16[1],(void*)0},{&g_16[4],&g_16[1],&g_16[4]},{(void*)0,&g_16[4],&g_16[1]},{(void*)0,&g_16[3],&g_16[4]},{&g_16[1],(void*)0,(void*)0}},{{&g_16[4],&g_16[3],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{&g_16[4],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1]},{(void*)0,&g_16[3],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,(void*)0,&g_16[1]}},{{(void*)0,&g_16[1],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],(void*)0},{&g_16[1],(void*)0,(void*)0},{&g_16[4],&g_16[1],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{&g_16[4],&g_16[3],&g_16[2]},{(void*)0,(void*)0,&g_16[1]}},{{&g_16[4],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1]},{(void*)0,&g_16[3],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],&g_16[2]},{(void*)0,(void*)0,&g_16[1]}},{{(void*)0,&g_16[1],(void*)0},{&g_16[1],(void*)0,(void*)0},{&g_16[4],&g_16[1],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{&g_16[4],&g_16[3],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{&g_16[4],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1]}},{{(void*)0,&g_16[3],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,&g_16[1],&g_16[1]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],(void*)0},{&g_16[1],(void*)0,(void*)0}},{{&g_16[4],&g_16[1],(void*)0},{(void*)0,&g_16[1],&g_16[1]},{&g_16[4],&g_16[3],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{&g_16[4],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1]},{(void*)0,&g_16[3],(void*)0},{(void*)0,&g_16[1],&g_16[1]}},{{(void*)0,&g_16[1],&g_16[1]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],&g_16[2]},{(void*)0,(void*)0,&g_16[1]},{(void*)0,&g_16[1],(void*)0},{&g_16[1],(void*)0,(void*)0},{&g_16[4],&g_16[1],(void*)0},{(void*)0,&g_16[1],&g_16[1]}}};
static int32_t ** volatile g_1037 = &g_16[1];/* VOLATILE GLOBAL g_1037 */
static int32_t g_1060[7] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
static uint32_t g_1092 = 4294967288UL;
static uint32_t g_1094 = 1UL;
static int8_t g_1095 = 0x1CL;
static int32_t * const  volatile g_1121 = &g_448;/* VOLATILE GLOBAL g_1121 */
static uint32_t *g_1159[6][5][6] = {{{&g_1092,(void*)0,&g_1094,&g_1094,&g_1092,&g_1094},{&g_1094,&g_1092,&g_1094,(void*)0,&g_1092,(void*)0},{&g_1094,&g_1094,(void*)0,(void*)0,&g_1092,&g_1094},{&g_1092,(void*)0,&g_1094,&g_1094,&g_1094,&g_1094},{&g_1094,(void*)0,(void*)0,&g_1094,&g_1092,(void*)0}},{{(void*)0,&g_1094,&g_1094,&g_1092,&g_1092,&g_1094},{&g_1094,&g_1094,&g_1092,&g_1092,&g_1092,&g_1092},{&g_1094,&g_1092,&g_1092,(void*)0,&g_1094,&g_1094},{&g_1092,&g_1094,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1094,(void*)0,&g_1094,&g_1094,(void*)0,(void*)0}},{{&g_1092,&g_1094,(void*)0,&g_1094,&g_1094,&g_1094},{(void*)0,&g_1092,(void*)0,&g_1092,&g_1092,&g_1094},{(void*)0,&g_1092,&g_1092,&g_1092,&g_1094,&g_1094},{&g_1094,&g_1094,&g_1092,&g_1092,&g_1092,&g_1092},{(void*)0,(void*)0,&g_1092,&g_1092,&g_1094,&g_1092}},{{(void*)0,&g_1094,(void*)0,&g_1094,&g_1094,(void*)0},{&g_1092,&g_1092,&g_1094,&g_1094,(void*)0,(void*)0},{&g_1094,&g_1092,(void*)0,(void*)0,&g_1092,&g_1094},{&g_1092,&g_1092,&g_1092,(void*)0,&g_1092,&g_1092},{&g_1094,&g_1092,(void*)0,&g_1092,&g_1092,&g_1094}},{{&g_1094,&g_1094,(void*)0,&g_1092,&g_1094,&g_1094},{(void*)0,&g_1092,&g_1094,&g_1094,&g_1094,(void*)0},{&g_1094,(void*)0,&g_1094,&g_1094,&g_1092,(void*)0},{&g_1092,&g_1094,(void*)0,(void*)0,&g_1092,&g_1094},{&g_1094,&g_1094,&g_1092,(void*)0,&g_1094,&g_1094}},{{(void*)0,&g_1094,&g_1094,(void*)0,(void*)0,&g_1094},{&g_1092,&g_1092,&g_1092,&g_1094,&g_1094,(void*)0},{(void*)0,&g_1094,(void*)0,(void*)0,&g_1094,&g_1092},{(void*)0,&g_1092,&g_1094,&g_1092,(void*)0,&g_1094},{(void*)0,&g_1094,(void*)0,&g_1092,&g_1094,&g_1094}}};
static int32_t ** volatile g_1202 = (void*)0;/* VOLATILE GLOBAL g_1202 */
static int32_t ** volatile g_1203[9][3][1] = {{{&g_16[1]},{&g_16[1]},{&g_16[3]}},{{&g_16[1]},{&g_16[1]},{&g_16[2]}},{{&g_16[1]},{&g_16[1]},{&g_16[3]}},{{&g_16[1]},{&g_16[1]},{&g_16[2]}},{{&g_16[1]},{&g_16[1]},{&g_16[3]}},{{&g_16[1]},{&g_16[1]},{&g_16[2]}},{{&g_16[1]},{&g_16[1]},{&g_16[3]}},{{&g_16[1]},{&g_16[1]},{&g_16[2]}},{{&g_16[1]},{&g_16[1]},{&g_16[1]}}};
static volatile uint8_t *g_1212 = (void*)0;
static volatile uint8_t **g_1211[3][9] = {{&g_1212,&g_1212,&g_1212,(void*)0,&g_1212,&g_1212,&g_1212,&g_1212,(void*)0},{&g_1212,(void*)0,&g_1212,&g_1212,&g_1212,&g_1212,(void*)0,&g_1212,&g_1212},{&g_1212,&g_1212,&g_1212,&g_1212,(void*)0,&g_1212,&g_1212,&g_1212,&g_1212}};
static volatile uint8_t *** volatile g_1210 = &g_1211[2][6];/* VOLATILE GLOBAL g_1210 */
static volatile uint8_t *** volatile *g_1209 = &g_1210;
static const int64_t g_1228 = 0x38A01F0BF5BFA823LL;
static int64_t *g_1261[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int64_t * const *g_1260 = &g_1261[8];
static int64_t * const **g_1259 = &g_1260;
static int64_t * const ***g_1258[4] = {&g_1259,&g_1259,&g_1259,&g_1259};
static int64_t g_1279 = 0x0F21BB93C1B7051FLL;
static volatile int16_t g_1291 = 0x6577L;/* VOLATILE GLOBAL g_1291 */
static int16_t *** volatile g_1302 = (void*)0;/* VOLATILE GLOBAL g_1302 */
static int16_t *g_1305[1][7][7] = {{{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,(void*)0,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,(void*)0,&g_174,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,(void*)0,&g_174},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,(void*)0},{&g_174,&g_174,&g_174,&g_174,&g_174,&g_174,&g_174}}};
static int16_t **g_1304 = &g_1305[0][3][3];
static int16_t *** volatile g_1303 = &g_1304;/* VOLATILE GLOBAL g_1303 */
static int32_t ** volatile g_1307 = &g_16[2];/* VOLATILE GLOBAL g_1307 */
static volatile uint32_t g_1321 = 4UL;/* VOLATILE GLOBAL g_1321 */
static volatile uint32_t *g_1320 = &g_1321;
static volatile uint32_t * volatile *g_1319 = &g_1320;
static volatile uint32_t * volatile * volatile *g_1318 = &g_1319;
static volatile uint32_t * volatile * volatile ** volatile g_1317 = &g_1318;/* VOLATILE GLOBAL g_1317 */
static const int32_t g_1326 = 8L;
static int32_t ** volatile g_1354 = &g_16[1];/* VOLATILE GLOBAL g_1354 */
static int32_t ** volatile g_1360 = (void*)0;/* VOLATILE GLOBAL g_1360 */
static int32_t ** volatile g_1361 = &g_16[1];/* VOLATILE GLOBAL g_1361 */
static volatile int32_t g_1384 = 0L;/* VOLATILE GLOBAL g_1384 */
static union U0 ** volatile g_1391 = &g_733[1][3];/* VOLATILE GLOBAL g_1391 */
static uint32_t *g_1420 = &g_978;
static volatile int16_t g_1454 = (-9L);/* VOLATILE GLOBAL g_1454 */
static int32_t ** volatile g_1555 = &g_16[1];/* VOLATILE GLOBAL g_1555 */
static int32_t **g_1557 = (void*)0;
static int32_t **g_1571 = (void*)0;
static int32_t ***g_1570 = &g_1571;
static int32_t ****g_1569 = &g_1570;
static const uint8_t g_1572[3] = {0x3DL,0x3DL,0x3DL};
static int16_t g_1620 = 0x966EL;
static volatile union U0 g_1634 = {0x1DL};/* VOLATILE GLOBAL g_1634 */
static volatile union U0 *g_1633[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static volatile union U0 ** volatile g_1632 = &g_1633[3];/* VOLATILE GLOBAL g_1632 */
static const int32_t *g_1640 = &g_3;
static const int32_t **g_1639 = &g_1640;
static const int32_t ***g_1638 = &g_1639;
static int32_t g_1672 = 0xD999D623L;
static union U0 ** volatile g_1778 = &g_733[2][3];/* VOLATILE GLOBAL g_1778 */
static const int16_t *g_1817 = (void*)0;
static const int16_t **g_1816 = &g_1817;
static const int16_t ***g_1815 = &g_1816;
static union U0 g_1965 = {8UL};
static uint32_t g_2036 = 18446744073709551614UL;
static uint32_t ***g_2046 = &g_378;
static uint32_t **** const g_2045 = &g_2046;
static uint32_t **** const *g_2044 = &g_2045;
static uint16_t g_2086 = 1UL;
static int32_t *g_2095 = &g_192[5].f3;
static int32_t **g_2123[10][2][8] = {{{&g_16[2],(void*)0,&g_16[1],&g_16[2],&g_16[0],&g_16[1],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[4],&g_16[1]}},{{&g_16[1],&g_16[3],&g_16[4],&g_16[1],&g_16[4],&g_16[3],&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[0],(void*)0,&g_16[2],(void*)0,&g_16[4],&g_16[1]}},{{(void*)0,&g_16[1],&g_16[3],&g_16[1],&g_16[2],(void*)0,&g_16[1],&g_16[1]},{&g_16[1],(void*)0,&g_16[1],&g_16[1],&g_16[4],&g_16[1],&g_16[1],&g_16[1]}},{{&g_16[1],&g_16[0],(void*)0,&g_16[1],&g_16[1],&g_16[4],(void*)0,&g_16[1]},{&g_16[1],&g_16[1],(void*)0,(void*)0,&g_16[0],&g_16[1],&g_16[1],&g_16[1]}},{{&g_16[2],&g_16[1],&g_16[1],&g_16[1],&g_16[4],&g_16[4],(void*)0,(void*)0},{(void*)0,&g_16[1],(void*)0,(void*)0,(void*)0,(void*)0,&g_16[1],(void*)0}},{{&g_16[4],&g_16[1],(void*)0,&g_16[3],&g_16[1],&g_16[1],(void*)0,&g_16[1]},{&g_16[1],&g_16[1],(void*)0,&g_16[1],&g_16[3],&g_16[1],&g_16[1],&g_16[3]}},{{&g_16[4],&g_16[1],(void*)0,&g_16[1],&g_16[1],&g_16[1],&g_16[1],&g_16[3]},{&g_16[3],&g_16[4],&g_16[0],(void*)0,&g_16[2],&g_16[2],&g_16[2],&g_16[1]}},{{&g_16[3],&g_16[2],&g_16[2],(void*)0,&g_16[2],&g_16[3],&g_16[1],&g_16[1]},{&g_16[4],(void*)0,&g_16[0],&g_16[1],&g_16[1],&g_16[1],&g_16[3],&g_16[4]}},{{&g_16[1],(void*)0,&g_16[2],(void*)0,&g_16[1],(void*)0,&g_16[2],(void*)0},{&g_16[3],(void*)0,(void*)0,(void*)0,(void*)0,&g_16[1],&g_16[2],&g_16[2]}},{{(void*)0,&g_16[1],&g_16[1],(void*)0,&g_16[3],(void*)0,&g_16[2],&g_16[3]},{&g_16[1],(void*)0,(void*)0,&g_16[1],(void*)0,(void*)0,&g_16[2],&g_16[3]}}};
static const int32_t *g_2191 = &g_259[5][4];
static volatile int64_t * volatile * volatile g_2253 = (void*)0;/* VOLATILE GLOBAL g_2253 */
static volatile uint64_t g_2389 = 0xAA6F71C472B2C057LL;/* VOLATILE GLOBAL g_2389 */
static int32_t g_2466 = 0x73CA9471L;
static uint32_t g_2491 = 4294967290UL;


/* --- FORWARD DECLARATIONS --- */
static union U0  func_1(void);
static int8_t  func_12(uint32_t  p_13, int32_t * p_14);
static uint32_t  func_17(uint32_t  p_18, int32_t * const  p_19, int32_t * p_20, uint32_t  p_21);
static int16_t  func_33(uint32_t  p_34, uint64_t  p_35, union U0  p_36);
static int32_t ** func_46(int8_t  p_47, union U0  p_48, uint8_t * p_49, int64_t * p_50, uint8_t * p_51);
static int8_t  func_52(uint32_t * p_53, int16_t  p_54, union U0  p_55, uint32_t  p_56, uint32_t * p_57);
static int8_t  func_58(uint32_t * p_59, uint32_t  p_60);
static uint32_t  func_61(int32_t  p_62, int32_t  p_63, uint64_t  p_64, const int32_t ** p_65);
static int32_t  func_67(uint8_t  p_68, int32_t * p_69, int64_t * p_70, const uint32_t  p_71, int64_t * p_72);
static int64_t * func_75(int32_t ** p_76, const int16_t  p_77, uint32_t * p_78);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_30 g_42 g_3 g_45 g_81 g_16 g_192 g_200 g_213 g_173 g_174 g_192.f0 g_212 g_259 g_298 g_407 g_409 g_447 g_448 g_427 g_475 g_487 g_571 g_502 g_598 g_350 g_426 g_516 g_1060 g_482 g_930 g_727 g_723 g_724 g_839 g_840 g_841 g_1092 g_1094 g_1095 g_1420 g_1454 g_1555 g_967 g_1572 g_978 g_1569 g_1570 g_1121 g_1279 g_1639 g_1640 g_2086 g_1037 g_2036 g_1965.f0 g_1638 g_838 g_2253 g_726 g_2389 g_1209 g_1210 g_1672 g_896 g_2466 g_2491
 * writes: g_5 g_16 g_30 g_42 g_45 g_3 g_82 g_81 g_173 g_174 g_200 g_212 g_192.f0 g_350 g_378 g_407 g_409 g_425 g_448 g_475 g_482 g_485 g_486 g_502 g_427 g_516 g_1060 g_1092 g_1094 g_1095 g_1557 g_1569 g_1571 g_1640 g_2086 g_1279 g_2095 g_2123 g_2036 g_967 g_733 g_1672
 */
static union U0  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3;
    int32_t *l_4[10][8] = {{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3}};
    int32_t **l_15[3];
    union U0 l_2492 = {8UL};
    int i, j;
    for (i = 0; i < 3; i++)
        l_15[i] = &l_2;
    ++g_5[0];
    (*g_1639) = ((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(g_5[0], (func_12(g_5[0], (g_16[1] = &g_3)) || g_2491))), 13)) , (**g_1638));
    return l_2492;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_30 g_42 g_3 g_45 g_81 g_16 g_192 g_200 g_213 g_173 g_174 g_192.f0 g_212 g_259 g_298 g_407 g_409 g_447 g_448 g_427 g_475 g_487 g_571 g_502 g_598 g_350 g_426 g_516 g_1060 g_482 g_930 g_727 g_723 g_724 g_839 g_840 g_841 g_1092 g_1094 g_1095 g_1420 g_1454 g_1555 g_967 g_1572 g_978 g_1569 g_1570 g_1121 g_1279 g_1639 g_1640 g_2086 g_1037 g_2036 g_1965.f0 g_1638 g_838 g_2253 g_726 g_2389 g_1209 g_1210 g_1672 g_896 g_2466
 * writes: g_30 g_42 g_45 g_16 g_3 g_82 g_81 g_173 g_174 g_200 g_212 g_192.f0 g_350 g_378 g_407 g_409 g_425 g_448 g_475 g_482 g_485 g_486 g_502 g_427 g_516 g_1060 g_1092 g_1094 g_1095 g_1557 g_1569 g_1571 g_1640 g_2086 g_1279 g_2095 g_2123 g_2036 g_967 g_733 g_1672
 */
static int8_t  func_12(uint32_t  p_13, int32_t * p_14)
{ /* block id: 3 */
    uint16_t l_24 = 0x4653L;
    uint8_t *l_29 = &g_30;
    int64_t *l_41 = &g_42;
    uint32_t *l_43 = (void*)0;
    uint32_t *l_44 = &g_45;
    const int32_t **l_66 = (void*)0;
    union U0 l_1419 = {0x1EL};
    int32_t ***l_2119 = &g_1571;
    int32_t ***l_2120 = &g_1557;
    int32_t ***l_2121 = &g_1557;
    int32_t ***l_2122[2];
    int8_t *l_2124 = (void*)0;
    int8_t *l_2125 = &g_1095;
    uint32_t *l_2126 = &g_2036;
    int32_t *l_2465[1][9][6] = {{{&g_2466,&g_2466,&g_2466,(void*)0,&g_2466,(void*)0},{(void*)0,&g_2466,(void*)0,&g_2466,(void*)0,&g_2466},{&g_2466,&g_2466,(void*)0,&g_2466,&g_2466,(void*)0},{&g_2466,&g_2466,&g_2466,&g_2466,&g_2466,(void*)0},{&g_2466,&g_2466,(void*)0,&g_2466,&g_2466,&g_2466},{&g_2466,(void*)0,(void*)0,&g_2466,&g_2466,(void*)0},{&g_2466,&g_2466,&g_2466,&g_2466,&g_2466,(void*)0},{&g_2466,&g_2466,(void*)0,&g_2466,(void*)0,&g_2466},{(void*)0,&g_2466,&g_2466,&g_2466,&g_2466,&g_2466}}};
    uint32_t l_2490 = 18446744073709551615UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2122[i] = (void*)0;
    if ((func_17((g_5[0] == ((safe_mul_func_int16_t_s_s(l_24, (safe_lshift_func_int16_t_s_s((((*l_2125) = ((safe_mul_func_int16_t_s_s((((*l_29) |= p_13) <= l_24), (((safe_add_func_uint64_t_u_u((func_33(((*l_2126) &= ((safe_add_func_int8_t_s_s((((*l_44) = (safe_mod_func_int64_t_s_s(((*l_41) &= (l_24 && l_24)), g_5[3]))) , ((*l_2125) = ((g_2123[6][0][7] = func_46(func_52((func_58(&g_45, func_61(g_3, (*p_14), l_24, l_66)) , (void*)0), p_13, l_1419, p_13, g_1420), l_1419, l_29, &g_1279, l_29)) == &p_14))), 0x36L)) != p_13)), g_1965.f0, l_1419) < (-1L)), p_13)) , p_13) | 1L))) == g_896)) , p_13), 4)))) & p_13)), p_14, l_2465[0][2][5], p_13) , (*p_14)))
    { /* block id: 1153 */
        int64_t **l_2476 = &g_1261[8];
        int64_t **l_2477 = (void*)0;
        int64_t ***l_2478 = &l_2477;
        int32_t l_2485 = 0xB9A9CB85L;
        uint8_t ***l_2486 = &g_485;
        uint8_t **l_2487 = &l_29;
        (*p_14) ^= (safe_lshift_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((((safe_sub_func_int64_t_s_s((((((*g_840) , (l_2476 = &l_41)) == ((*l_2478) = l_2477)) , 0xA2FBD8CAL) < 1UL), ((!(safe_mul_func_uint8_t_u_u((p_13 && (((!(safe_mod_func_uint16_t_u_u(((((l_2485 , ((*l_2486) = &g_82)) == l_2487) || 0x3F592D988608D2D9LL) , p_13), 0xD826L))) == 9L) > p_13)), l_2485))) == p_13))) >= p_13) <= l_2485), l_2485)), l_2485)), p_13));
        for (p_13 = 0; p_13 < 5; p_13 += 1)
        {
            g_967[p_13] = 18446744073709551615UL;
        }
        (*g_1639) = p_14;
    }
    else
    { /* block id: 1160 */
        uint16_t l_2488 = 0UL;
        int32_t *l_2489[6] = {&g_3,&g_3,&g_3,&g_3,&g_3,&g_3};
        int i;
        p_14 = (l_2488 , l_2489[4]);
    }
    return l_2490;
}


/* ------------------------------------------ */
/* 
 * reads : g_1638 g_1639 g_2466
 * writes: g_1640
 */
static uint32_t  func_17(uint32_t  p_18, int32_t * const  p_19, int32_t * p_20, uint32_t  p_21)
{ /* block id: 1150 */
    const int32_t *l_2467 = &g_2466;
    (**g_1638) = l_2467;
    return (*l_2467);
}


/* ------------------------------------------ */
/* 
 * reads : g_1638 g_1639 g_838 g_839 g_840 g_841 g_3 g_448 g_1640 g_173 g_45 g_174 g_967 g_2253 g_407 g_1572 g_212 g_409 g_447 g_350 g_1095 g_5 g_724 g_298 g_726 g_727 g_200 g_1060 g_2389 g_1209 g_1210 g_1672
 * writes: g_1640 g_448 g_3 g_173 g_45 g_174 g_967 g_407 g_409 g_350 g_200 g_733 g_1060 g_1672
 */
static int16_t  func_33(uint32_t  p_34, uint64_t  p_35, union U0  p_36)
{ /* block id: 986 */
    int32_t *l_2127 = &g_3;
    union U0 l_2130 = {0x65L};
    int16_t l_2132 = (-9L);
    uint32_t * const **l_2150 = &g_425[0][3][0];
    uint32_t * const ***l_2149 = &l_2150;
    uint32_t l_2219 = 4294967292UL;
    const uint32_t *l_2231 = &g_427[1][1];
    const uint32_t **l_2230 = &l_2231;
    uint16_t *l_2294[2];
    uint8_t ***l_2437 = &g_485;
    int32_t l_2458[6] = {(-5L),(-5L),0xA9390DFCL,(-5L),(-5L),0xA9390DFCL};
    int32_t *l_2459 = (void*)0;
    int32_t *l_2460[6][3];
    int16_t l_2461 = 0x5A27L;
    uint8_t l_2462 = 0xDEL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_2294[i] = &g_5[0];
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
            l_2460[i][j] = &g_1060[6];
    }
    if (((void*)0 == &p_36))
    { /* block id: 987 */
        int32_t *l_2131 = &g_448;
        int32_t l_2136 = (-1L);
        const uint32_t *l_2183 = (void*)0;
        const uint32_t **l_2182[3][7][7] = {{{(void*)0,&l_2183,&l_2183,&l_2183,(void*)0,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,&l_2183,&l_2183,&l_2183,(void*)0,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,(void*)0,(void*)0,(void*)0,&l_2183,(void*)0},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183}},{{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,(void*)0,(void*)0,&l_2183,(void*)0,(void*)0},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,(void*)0,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,(void*)0,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183}},{{&l_2183,(void*)0,(void*)0,&l_2183,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,(void*)0,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,(void*)0,&l_2183,(void*)0,(void*)0,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{(void*)0,&l_2183,&l_2183,(void*)0,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183,&l_2183},{&l_2183,&l_2183,&l_2183,(void*)0,(void*)0,&l_2183,(void*)0}}};
        int32_t l_2228[10][10] = {{0x49176A85L,0x8225376DL,0x05676C0BL,(-10L),(-10L),0x05676C0BL,0x8225376DL,0x49176A85L,(-1L),0x8225376DL},{0x49176A85L,(-1L),0L,0x8225376DL,(-1L),(-10L),0xADAA0E38L,(-5L),(-10L),(-10L)},{(-1L),0x8225376DL,5L,1L,(-10L),0x05676C0BL,0x05676C0BL,(-10L),1L,5L},{(-1L),(-1L),0xADAA0E38L,0L,(-10L),0x49176A85L,0L,(-5L),(-10L),(-1L)},{(-10L),5L,0x05676C0BL,(-1L),1L,0x05676C0BL,0L,(-1L),(-1L),0L},{(-1L),(-1L),5L,5L,(-1L),(-1L),0x05676C0BL,(-5L),(-1L),1L},{(-1L),0L,0x8225376DL,(-1L),(-10L),0xADAA0E38L,(-5L),(-10L),(-10L),0L},{(-1L),1L,0x05676C0BL,0L,(-1L),(-1L),0L,0x05676C0BL,1L,(-1L)},{(-1L),0L,0x05676C0BL,1L,(-1L),0x05676C0BL,5L,(-10L),(-1L),5L},{(-10L),(-1L),0x8225376DL,0L,(-1L),0x49176A85L,(-5L),(-5L),0x49176A85L,(-1L)}};
        int64_t ****l_2313 = (void*)0;
        int64_t l_2325 = 1L;
        uint16_t *l_2328[9][10][2] = {{{(void*)0,&g_5[0]},{&g_502,&g_2086},{&g_5[4],&g_502},{&g_5[6],&g_2086},{&g_5[6],&g_502},{&g_5[4],&g_2086},{&g_502,&g_5[0]},{(void*)0,&g_502},{&g_2086,&g_5[6]},{&g_5[6],&g_173}},{{(void*)0,&g_2086},{&g_173,&g_2086},{(void*)0,&g_173},{&g_5[6],&g_5[6]},{&g_2086,&g_502},{(void*)0,&g_5[0]},{&g_502,&g_2086},{&g_5[4],&g_502},{&g_5[6],&g_2086},{&g_5[6],&g_502}},{{&g_5[4],&g_2086},{&g_502,&g_5[0]},{(void*)0,&g_502},{&g_2086,&g_5[6]},{&g_5[6],&g_173},{(void*)0,&g_2086},{&g_173,&g_2086},{(void*)0,&g_173},{&g_5[6],&g_5[6]},{&g_2086,&g_502}},{{(void*)0,&g_5[0]},{&g_502,&g_2086},{&g_5[4],&g_502},{&g_5[6],&g_2086},{&g_5[6],&g_502},{&g_5[4],&g_2086},{&g_502,&g_5[0]},{(void*)0,&g_502},{&g_2086,&g_5[6]},{&g_5[6],&g_173}},{{(void*)0,&g_2086},{&g_173,&g_2086},{(void*)0,&g_173},{&g_5[6],&g_5[6]},{&g_2086,&g_502},{(void*)0,&g_5[0]},{&g_502,&g_2086},{&g_5[4],&g_502},{&g_5[6],&g_2086},{&g_5[6],&g_502}},{{&g_5[4],&g_2086},{&g_502,&g_5[0]},{(void*)0,&g_502},{&g_2086,&g_5[6]},{&g_5[6],&g_173},{(void*)0,&g_2086},{&g_173,&g_2086},{&g_516,(void*)0},{&g_173,&g_173},{&g_5[0],&g_5[4]}},{{&g_516,&g_5[0]},{&g_5[4],&g_2086},{(void*)0,&g_5[4]},{&g_173,&g_5[0]},{&g_173,&g_5[4]},{(void*)0,&g_2086},{&g_5[4],&g_5[0]},{&g_516,&g_5[4]},{&g_5[0],&g_173},{&g_173,(void*)0}},{{&g_516,&g_2086},{(void*)0,&g_2086},{&g_516,(void*)0},{&g_173,&g_173},{&g_5[0],&g_5[4]},{&g_516,&g_5[0]},{&g_5[4],&g_2086},{(void*)0,&g_5[4]},{&g_173,&g_5[0]},{&g_173,&g_5[4]}},{{(void*)0,&g_2086},{&g_5[4],&g_5[0]},{&g_516,&g_5[4]},{&g_5[0],&g_173},{&g_173,(void*)0},{&g_516,&g_2086},{(void*)0,&g_2086},{&g_516,(void*)0},{&g_173,&g_173},{&g_5[0],&g_5[4]}}};
        uint32_t l_2386 = 0UL;
        int32_t **l_2414 = &g_2095;
        int32_t ***l_2413 = &l_2414;
        int64_t *****l_2418[3];
        int64_t ****** const l_2417 = &l_2418[0];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2418[i] = &l_2313;
lbl_2138:
        (**g_1638) = l_2127;
        if (((***g_838) && (safe_lshift_func_uint16_t_u_u((*l_2127), 9))))
        { /* block id: 989 */
            uint32_t l_2133 = 4294967295UL;
            int64_t ***l_2137 = (void*)0;
            uint32_t * const **l_2147 = (void*)0;
            uint32_t * const ***l_2146 = &l_2147;
            int32_t l_2151 = (-1L);
            int64_t ***l_2158 = (void*)0;
            int16_t *l_2214 = &g_174;
            uint32_t *l_2220 = (void*)0;
            uint32_t *l_2221[1];
            int i;
            for (i = 0; i < 1; i++)
                l_2221[i] = (void*)0;
            (*g_1639) = (l_2130 , l_2131);
            if (l_2132)
            { /* block id: 991 */
                uint32_t *l_2134 = (void*)0;
                uint32_t *l_2135[7][3] = {{&l_2133,&g_1094,&g_1094},{(void*)0,&g_1094,(void*)0},{&l_2133,&l_2133,&g_1094},{&l_2133,&g_1094,&l_2133},{&l_2133,&g_1094,&g_1094},{(void*)0,&g_1094,(void*)0},{&l_2133,&l_2133,&g_1094}};
                int i, j;
                (*l_2127) = (((*l_2131) ^= l_2133) > 4294967295UL);
                l_2136 &= ((*l_2127) = (***g_1638));
                (*l_2131) |= ((void*)0 != l_2137);
            }
            else
            { /* block id: 997 */
                for (g_173 = 3; (g_173 <= 9); g_173 += 1)
                { /* block id: 1000 */
                    if (l_2136)
                        goto lbl_2138;
                }
            }
            for (g_45 = 0; (g_45 <= 7); ++g_45)
            { /* block id: 1006 */
                uint64_t *l_2141 = &g_407;
                uint32_t * const ****l_2148 = (void*)0;
                int8_t *l_2156[7][7][5] = {{{&g_212,&g_212,&g_212,&g_212,&g_1095},{&g_1095,&g_1095,&g_212,&g_212,&g_212},{&g_212,&g_212,&g_212,&g_212,&g_212},{&g_1095,&g_1095,&g_212,&g_1095,&g_212},{&g_212,&g_212,&g_212,(void*)0,&g_212},{&g_212,(void*)0,&g_1095,(void*)0,&g_212},{&g_1095,(void*)0,&g_212,&g_1095,&g_212}},{{&g_212,&g_1095,&g_212,&g_212,&g_212},{&g_212,&g_212,&g_212,&g_1095,&g_212},{(void*)0,&g_1095,&g_212,&g_212,&g_212},{&g_212,&g_1095,&g_212,&g_212,&g_212},{&g_1095,&g_212,&g_212,&g_212,&g_1095},{&g_212,&g_1095,&g_212,(void*)0,&g_1095},{&g_1095,(void*)0,&g_212,&g_212,&g_1095}},{{&g_212,&g_1095,&g_212,&g_212,&g_212},{&g_212,&g_212,&g_1095,&g_212,&g_1095},{&g_1095,&g_212,&g_212,&g_1095,&g_1095},{&g_212,&g_212,&g_212,(void*)0,(void*)0},{&g_1095,&g_1095,&g_212,&g_212,&g_212},{&g_212,(void*)0,&g_212,(void*)0,&g_1095},{(void*)0,&g_212,&g_212,&g_1095,&g_1095}},{{&g_1095,(void*)0,&g_212,(void*)0,&g_212},{&g_212,&g_212,&g_212,&g_1095,(void*)0},{&g_212,&g_212,&g_1095,&g_212,&g_212},{&g_1095,(void*)0,&g_212,(void*)0,&g_1095},{&g_212,&g_212,&g_212,&g_1095,&g_212},{&g_1095,&g_212,(void*)0,&g_1095,&g_212},{&g_1095,&g_212,&g_1095,&g_212,&g_212}},{{&g_212,&g_1095,(void*)0,&g_1095,&g_1095},{&g_212,&g_1095,(void*)0,&g_212,&g_212},{(void*)0,&g_1095,&g_212,&g_212,(void*)0},{&g_1095,&g_1095,&g_212,&g_212,&g_212},{&g_212,&g_1095,(void*)0,(void*)0,&g_1095},{&g_1095,&g_212,(void*)0,&g_212,&g_1095},{&g_212,(void*)0,&g_1095,&g_1095,&g_212}},{{&g_212,(void*)0,(void*)0,(void*)0,&g_212},{&g_212,&g_1095,&g_212,(void*)0,&g_1095},{&g_1095,&g_212,&g_212,&g_212,&g_1095},{&g_212,&g_1095,&g_1095,&g_212,&g_212},{&g_1095,&g_212,&g_212,&g_212,&g_1095},{(void*)0,&g_212,&g_212,&g_212,&g_212},{&g_212,&g_212,&g_212,(void*)0,(void*)0}},{{&g_212,&g_1095,&g_212,(void*)0,&g_1095},{&g_1095,&g_1095,(void*)0,&g_1095,&g_1095},{&g_1095,&g_1095,&g_212,&g_212,(void*)0},{&g_212,&g_212,&g_1095,(void*)0,&g_212},{&g_1095,&g_212,&g_1095,&g_212,(void*)0},{&g_212,&g_212,&g_212,&g_212,(void*)0},{&g_212,&g_1095,&g_1095,&g_212,&g_212}}};
                int32_t l_2157 = 0L;
                int i, j, k;
            }
            l_2228[5][0] ^= (+(((*l_2214) ^= (p_35 && (*l_2127))) || (l_2136 |= (safe_div_func_uint16_t_u_u(((((safe_sub_func_uint64_t_u_u((((l_2219 && (l_2151 = (*l_2131))) <= (p_36.f2 = (safe_sub_func_int64_t_s_s(((*l_2131) <= (((*l_2127) = p_34) != ((*l_2214) = ((((0x1DAC50A2L != ((safe_div_func_int32_t_s_s((0UL | l_2133), (*l_2131))) & 4294967295UL)) || 0xF2C0L) ^ p_35) < 2L)))), p_36.f0)))) & p_35), (*l_2131))) & (*l_2131)) != 0x46F9L) > 0x1E5167E980F08482LL), 0x4571L)))));
        }
        else
        { /* block id: 1060 */
            const uint32_t ***l_2232 = &l_2230;
            uint64_t *l_2237 = &g_967[4];
            int16_t l_2254 = (-10L);
            uint32_t *l_2255 = (void*)0;
            uint32_t *l_2256[3][10] = {{&l_2219,&g_1094,&g_1094,&g_1094,&g_1094,&g_1094,&g_1094,&g_1094,&l_2219,&l_2219},{&l_2219,&l_2219,&l_2219,(void*)0,&g_1094,&l_2219,&l_2219,&g_1094,(void*)0,&l_2219},{&l_2219,&l_2219,&g_1094,(void*)0,&l_2219,&l_2219,&l_2219,&g_1094,&l_2219,&l_2219}};
            int32_t **l_2267 = &g_2095;
            uint32_t l_2274 = 0UL;
            int32_t l_2290 = 0x23EC3D48L;
            int i, j;
            if (((((((((!(((*l_2232) = l_2230) == (void*)0)) != (safe_sub_func_int16_t_s_s((((*l_2131) = (((*l_2131) <= ((((*l_2127) = (-1L)) || (*l_2131)) == ((safe_rshift_func_int8_t_s_u(((++(*l_2237)) , (((safe_mod_func_int64_t_s_s((-6L), ((safe_unary_minus_func_int32_t_s((safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(((safe_lshift_func_int8_t_s_u((((safe_mod_func_int16_t_s_s(((safe_lshift_func_int16_t_s_s(p_36.f0, ((void*)0 != g_2253))) | p_34), (*l_2131))) , g_407) ^ p_35), 0)) | l_2254), g_1572[0])), l_2254)))) | 0UL))) , l_2254) >= p_34)), p_35)) > p_36.f0))) & (*l_2131))) <= 0x3B45A0A0L), l_2254))) , p_34) > p_34) | l_2254) < g_212) != l_2254) | 0x088DF839L))
            { /* block id: 1065 */
                uint16_t l_2257 = 0x9BC6L;
                l_2257 |= l_2254;
                return p_34;
            }
            else
            { /* block id: 1068 */
                int32_t **l_2269[1];
                int32_t ***l_2268 = &l_2269[0];
                int32_t l_2275 = 0xD9B1D1E5L;
                int32_t **l_2281 = &l_2127;
                uint16_t *l_2283[4];
                int i;
                for (i = 0; i < 1; i++)
                    l_2269[i] = &g_2095;
                for (i = 0; i < 4; i++)
                    l_2283[i] = (void*)0;
                if ((safe_sub_func_int16_t_s_s((safe_add_func_int16_t_s_s(0L, 0x0599L)), (safe_sub_func_int64_t_s_s((safe_add_func_int32_t_s_s((((!(l_2267 == ((*l_2268) = (void*)0))) == 0x4073C546L) , ((safe_mod_func_uint8_t_u_u(l_2254, ((0xBF8CL <= ((safe_lshift_func_uint8_t_u_s(l_2254, 3)) ^ 0x70CD75E0L)) & l_2254))) == p_34)), 0L)), l_2274)))))
                { /* block id: 1070 */
                    l_2290 = (((((l_2275 , (safe_lshift_func_int8_t_s_u((*g_409), 5))) , (-1L)) ^ (g_407 = (!((((**l_2281) = (safe_add_func_uint64_t_u_u(((void*)0 == l_2281), 0xD990610E99C4E8ACLL))) ^ (~(l_2283[1] == ((safe_add_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s((*g_409), 3)), ((*l_2237) = ((((safe_add_func_int64_t_s_s(((255UL <= p_35) != p_36.f0), (-1L))) > 0UL) > 0xA8L) ^ p_34)))) , (void*)0)))) , (-1L))))) > (-1L)) , 1L);
                    (*l_2127) &= 0x54B8AA0FL;
                }
                else
                { /* block id: 1076 */
                    int32_t *l_2291[7][1] = {{&g_1060[6]},{(void*)0},{&g_1060[6]},{(void*)0},{&g_1060[6]},{(void*)0},{&g_1060[6]}};
                    int i, j;
                    (*g_1639) = l_2291[1][0];
                }
            }
        }
        if ((*g_447))
        { /* block id: 1081 */
            int8_t **l_2301[6] = {&g_409,&g_409,&g_409,&g_409,&g_409,&g_409};
            int64_t *l_2314 = &g_350;
            int32_t l_2323 = 9L;
            int32_t l_2324 = 3L;
            uint32_t l_2326 = 0xB1241615L;
            int64_t l_2327 = 0L;
            int32_t *****l_2367 = (void*)0;
            uint8_t l_2424 = 255UL;
            int i;
            (**g_1638) = (((*l_2127) == ((l_2294[0] != ((safe_rshift_func_uint16_t_u_u((((safe_mod_func_uint64_t_u_u(((safe_div_func_uint32_t_u_u(((g_409 = &g_212) == &g_526), (((safe_div_func_int16_t_s_s(((p_34 != ((safe_div_func_int32_t_s_s(((safe_div_func_int8_t_s_s((+(l_2324 = (safe_rshift_func_uint8_t_u_s(((safe_div_func_int64_t_s_s(((*l_2127) , ((*l_2314) ^= ((*l_2131) = ((void*)0 != l_2313)))), ((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((l_2323 |= ((safe_add_func_int16_t_s_s((safe_mod_func_int64_t_s_s((-6L), g_1095)), 0x93DDL)) < 0UL)) || 65534UL) >= 1L), 0x048211E6L)), l_2324)) , 0xF996630DBB51EC20LL))) | (*l_2127)), g_5[0])))), p_34)) && (*l_2127)), l_2325)) == l_2326)) , (*g_724)), 0x6E23L)) & p_35) | l_2327))) | 0x43E25D2C1075FA41LL), p_35)) || 0x8A030510EDB2DB10LL) ^ p_35), 12)) , l_2328[4][9][0])) != l_2325)) , &l_2228[2][8]);
            (*l_2127) |= (l_2324 = (l_2323 = (*l_2131)));
            if (l_2323)
            { /* block id: 1091 */
                int32_t l_2342 = 0x4DFC6063L;
                uint32_t *l_2361 = &l_2326;
                int32_t **l_2412[1][10];
                int32_t ***l_2411 = &l_2412[0][3];
                int32_t l_2416 = 0x9CF069ECL;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 10; j++)
                        l_2412[i][j] = &g_2095;
                }
lbl_2362:
                (*l_2127) |= (safe_div_func_uint32_t_u_u(p_34, (safe_mul_func_int8_t_s_s((-7L), p_34))));
                if ((safe_sub_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u((***g_726), (safe_unary_minus_func_int16_t_s((l_2342 && ((*l_2131) &= 1UL)))))) <= ((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s((safe_div_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((p_34 , 0x8FC13A98L) | l_2342), (0L < (safe_div_func_uint64_t_u_u(0xD5603E3B814BAB44LL, (safe_sub_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((*l_2361) = (((safe_rshift_func_uint16_t_u_u(g_1572[0], 13)) | p_35) ^ p_34)), p_35)), 0xF9165F7AL))))))), p_34)), p_35)), l_2342)) && l_2324), p_34)) == (*g_409))), (*l_2127))), p_34)) == 0x9D89L), (***g_1638))))
                { /* block id: 1095 */
                    if (l_2327)
                        goto lbl_2362;
                }
                else
                { /* block id: 1097 */
                    for (g_200 = 8; (g_200 > 25); g_200 = safe_add_func_uint32_t_u_u(g_200, 5))
                    { /* block id: 1100 */
                        union U0 **l_2365 = &g_733[1][4];
                        int32_t l_2366 = (-1L);
                        (*l_2127) = 0L;
                        (*l_2365) = (void*)0;
                        if (l_2366)
                            break;
                    }
                }
                (**g_1638) = &l_2228[5][0];
                for (p_36.f3 = 0; (p_36.f3 <= 1); p_36.f3 += 1)
                { /* block id: 1109 */
                    int16_t *l_2387 = &l_2132;
                    int8_t l_2388 = 0x2EL;
                    int i;
                    g_1060[(p_36.f3 + 2)] = ((((&g_1569 == l_2367) , ((((safe_mul_func_int16_t_s_s(((*l_2127) = ((safe_sub_func_uint32_t_u_u((((safe_div_func_int8_t_s_s((safe_sub_func_int64_t_s_s(((safe_mod_func_int64_t_s_s((((*l_2314) = (safe_unary_minus_func_int64_t_s(((0xA5C4L ^ 1L) >= ((*l_2361) &= (((0xEB391B57L && g_1060[(p_36.f3 + 5)]) | (*l_2131)) > (safe_mod_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(((*l_2387) = ((((+(safe_lshift_func_uint8_t_u_s(0x1DL, 4))) && l_2386) ^ p_36.f0) || 0x000EL)), p_35)), (*l_2131))))))))) , (-1L)), 5L)) != l_2388), 1UL)), 0xA0L)) && g_1060[(p_36.f3 + 5)]) <= (*l_2127)), g_2389)) | (*l_2131))), (*l_2131))) ^ 1L) ^ p_36.f2) , (*l_2127))) > (*g_409)) && p_36.f3);
                    for (l_2130.f0 = 0; (l_2130.f0 <= 1); l_2130.f0 += 1)
                    { /* block id: 1117 */
                        uint32_t l_2404[3][10][7] = {{{7UL,0xB1EB1028L,0UL,7UL,0x48C40421L,0xABFF4193L,0x0B6881D0L},{0xB5A8638BL,0xB1EB1028L,1UL,0xAC03A739L,4294967295UL,0x1C0AFF0FL,0x1C0AFF0FL},{0xB1EB1028L,0x0B6881D0L,0x40025619L,0x0B6881D0L,0xB1EB1028L,4294967293UL,1UL},{4294967291UL,0x78A2098AL,0xABFF4193L,1UL,0x48B543E0L,0x164B0693L,1UL},{1UL,1UL,0xA1617DEFL,0xAC03A739L,1UL,0x48B543E0L,0x78A2098AL},{4294967291UL,1UL,0xA0A20514L,4294967287UL,4294967286UL,0xF44891E4L,0x0B6881D0L},{0xB1EB1028L,0x1C0AFF0FL,4294967295UL,0xE1E85224L,0x48B543E0L,0xB5A8638BL,0xB1EB1028L},{0xB5A8638BL,0x0B6881D0L,0xAC03A739L,0x48B543E0L,0x16A45C84L,0xB5A8638BL,4294967295UL},{0x908830E3L,0x0A1BA934L,0xF44891E4L,1UL,1UL,0xF44891E4L,0x0A1BA934L},{0x0B6881D0L,0x78A2098AL,0UL,0x48C40421L,0x32CA270DL,0x48B543E0L,4294967286UL}},{{4294967294UL,4294967295UL,1UL,0xABFF4193L,0x0A1BA934L,0x164B0693L,4294967295UL},{0xB1EB1028L,0x16A45C84L,0xA0A20514L,0x48C40421L,4294967295UL,4294967293UL,0UL},{0UL,4294967295UL,0xAC03A739L,1UL,4UL,0x1C0AFF0FL,1UL},{4294967294UL,1UL,0x164B0693L,0x48B543E0L,1UL,0xABFF4193L,0x78A2098AL},{1UL,1UL,0x40025619L,0xE1E85224L,4294967286UL,0xA0A20514L,4294967286UL},{4294967287UL,4294967295UL,4294967295UL,4294967287UL,0x32CA270DL,4294967294UL,4294967295UL},{0xB5A8638BL,0x16A45C84L,0x48B543E0L,0xAC03A739L,0x0B6881D0L,0xB5A8638BL,0x1C0AFF0FL},{0x16A45C84L,4294967295UL,0x40025619L,1UL,0UL,4294967293UL,4294967295UL},{0x908830E3L,0x78A2098AL,4294967294UL,0x0B6881D0L,0x48B543E0L,0xABFF4193L,4294967286UL},{1UL,0x0A1BA934L,0UL,0xAC03A739L,0x0A1BA934L,4294967295UL,0x78A2098AL}},{{4294967287UL,0x0B6881D0L,0xA0A20514L,0x908830E3L,0x0A1BA934L,0xF44891E4L,1UL},{0UL,0x1C0AFF0FL,0x48B543E0L,0x4C009B09L,0x48B543E0L,0x1C0AFF0FL,0UL},{0xB5A8638BL,1UL,0xA1617DEFL,0x48B543E0L,0UL,4UL,4294967295UL},{4294967291UL,1UL,0xF44891E4L,4294967295UL,0x0B6881D0L,0xF44891E4L,4294967286UL},{4294967295UL,0x78A2098AL,0xA1617DEFL,0xE1E85224L,0x32CA270DL,1UL,0x0A1BA934L},{4294967294UL,0x0B6881D0L,0x48B543E0L,0xABFF4193L,4294967286UL,4294967294UL,4294967295UL},{0x16A45C84L,0xB1EB1028L,0xA0A20514L,0x4C009B09L,1UL,4294967293UL,0xB1EB1028L},{0x16A45C84L,4294967295UL,0UL,0x0B6881D0L,4UL,4UL,0x0B6881D0L},{4294967295UL,0x1C0AFF0FL,4294967295UL,0xA914BF0CL,0x164B0693L,0x40025619L,4294967293UL},{0x164B0693L,4UL,1UL,0x32CA270DL,0x1C0AFF0FL,4294967291UL,0xB5A8638BL}}};
                        uint16_t l_2409 = 65534UL;
                        uint64_t *l_2410 = &g_407;
                        int32_t *l_2415[1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_2415[i] = &g_1060[6];
                        l_2416 |= (safe_add_func_int16_t_s_s(((((((*l_2314) = p_35) < ((safe_mul_func_uint8_t_u_u((((*l_2410) = ((p_36.f0 && (((*l_2387) |= (3L && (safe_add_func_int32_t_s_s((l_2409 = (safe_div_func_int16_t_s_s((safe_add_func_int64_t_s_s(1L, (((*l_2127) , (safe_div_func_uint32_t_u_u(((l_2404[2][1][0] | ((*l_2127) = (safe_add_func_int64_t_s_s(((*l_2127) , ((safe_lshift_func_uint16_t_u_u((((p_36.f3 ^ p_36.f3) , l_2342) | p_36.f3), 7)) == 0x7022L)), 1L)))) <= (*g_840)), p_36.f3))) >= (*g_409)))), 1UL))), p_36.f1)))) < 0L)) , p_36.f3)) >= p_35), 0x79L)) >= p_34)) , l_2411) == l_2413) != l_2388), (*l_2131)));
                        return (**g_727);
                    }
                }
            }
            else
            { /* block id: 1127 */
                const int64_t **l_2423 = (void*)0;
                const int64_t ***l_2422 = &l_2423;
                const int64_t ****l_2421 = &l_2422;
                const int64_t *****l_2420 = &l_2421;
                const int64_t ******l_2419 = &l_2420;
                (*l_2127) |= (l_2417 == l_2419);
            }
            --l_2424;
        }
        else
        { /* block id: 1131 */
            int16_t *l_2438 = &l_2132;
            int32_t *l_2439 = &l_2228[5][0];
            (*l_2131) ^= (safe_lshift_func_uint16_t_u_u((0x5FA0312CL < p_34), (safe_div_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((*l_2127), ((*l_2438) = (((!(((!(*l_2127)) , (p_35 , l_2328[4][9][0])) != (void*)0)) , (*g_1209)) != ((safe_mod_func_int64_t_s_s((((void*)0 != g_1209) > p_34), (*l_2127))) , l_2437))))), 0x8AAF18300EE99622LL))));
            for (g_1672 = 4; (g_1672 >= 1); g_1672 -= 1)
            { /* block id: 1136 */
                int32_t l_2440[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_2440[i] = (-1L);
                (**g_1638) = l_2439;
                return l_2440[0];
            }
        }
    }
    else
    { /* block id: 1141 */
        uint16_t l_2452 = 0x78F1L;
        uint8_t *l_2455 = &l_2130.f0;
        int32_t l_2456 = 1L;
        int32_t l_2457 = 0x88DCFD8FL;
        (*l_2127) = (p_36.f0 | (safe_sub_func_uint64_t_u_u(p_34, (safe_rshift_func_int16_t_s_u(((((*l_2127) & (+(0xA961L && (((l_2457 = ((l_2456 = ((safe_mul_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(65535UL, 0x32B9L)), (safe_mod_func_int64_t_s_s(l_2452, (safe_add_func_uint8_t_u_u(((*l_2455) ^= l_2452), 1UL)))))) < 0xF748DC16L)) == l_2452)) & 0x22B6L) & l_2458[1])))) , l_2452) & (*l_2127)), (*l_2127))))));
    }
    l_2462--;
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_350 g_1279 g_448 g_1639 g_1640 g_409 g_727 g_724 g_298 g_45 g_212 g_2086 g_1037
 * writes: g_350 g_448 g_174 g_1640 g_212 g_2086 g_1279 g_2095 g_16
 */
static int32_t ** func_46(int8_t  p_47, union U0  p_48, uint8_t * p_49, int64_t * p_50, uint8_t * p_51)
{ /* block id: 720 */
    int32_t *l_1583 = &g_448;
    union U0 l_1675 = {255UL};
    int8_t l_1719 = 0x17L;
    int16_t *l_1767 = &g_1620;
    union U0 *l_1777[3];
    int32_t *l_1781 = (void*)0;
    int32_t l_1888 = (-3L);
    int32_t l_1894[3];
    uint32_t * const **l_1924 = &g_425[0][3][0];
    uint32_t * const ***l_1923 = &l_1924;
    uint16_t l_1976 = 0UL;
    uint16_t l_1982 = 6UL;
    int8_t l_1991 = (-7L);
    int32_t l_2085[7];
    int32_t l_2114 = (-3L);
    int32_t **l_2118 = (void*)0;
    int i;
    for (i = 0; i < 3; i++)
        l_1777[i] = &g_192[6];
    for (i = 0; i < 3; i++)
        l_1894[i] = 0xB3B2E6EAL;
    for (i = 0; i < 7; i++)
        l_2085[i] = 9L;
    l_1583 = l_1583;
    for (g_350 = 0; (g_350 < 2); g_350 = safe_add_func_uint64_t_u_u(g_350, 6))
    { /* block id: 724 */
        int64_t l_1586 = 8L;
        int16_t ***l_1587 = (void*)0;
        (*l_1583) |= (&g_727 != ((p_47 == (((*p_50) < l_1586) & 0xD9L)) , l_1587));
        return &g_16[1];
    }
    for (g_350 = 15; (g_350 >= 29); ++g_350)
    { /* block id: 730 */
        const uint16_t **l_1594 = (void*)0;
        int32_t **l_1598[6] = {&l_1583,&l_1583,&l_1583,&l_1583,&l_1583,&l_1583};
        const int32_t l_1613 = 0xB58EF28AL;
        int16_t l_1674 = 1L;
        int32_t l_1805 = 0xD4558C61L;
        const uint16_t l_1837 = 0x7E38L;
        int16_t *** const l_1839 = &g_1304;
        uint8_t l_1930 = 0x06L;
        union U0 **l_1943[6] = {&g_733[2][0],&g_733[0][3],&g_733[0][3],&g_733[2][0],&g_733[0][3],&g_733[0][3]};
        uint8_t l_1951 = 253UL;
        volatile union U0 **l_1956 = &g_1633[2];
        int8_t *l_1972 = &l_1719;
        int8_t l_1973 = 0x40L;
        uint32_t l_1974 = 0xF6758350L;
        uint16_t *l_1975[4][9][5] = {{{&g_502,&g_173,(void*)0,&g_173,(void*)0},{&g_5[5],(void*)0,(void*)0,&g_5[1],&g_5[0]},{&g_516,&g_173,&g_516,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_173,(void*)0},{&g_516,&g_173,&g_516,&g_516,(void*)0},{&g_516,&g_502,(void*)0,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_516,(void*)0},{&g_516,(void*)0,&g_502,&g_173,(void*)0},{&g_5[5],&g_502,&g_5[0],(void*)0,(void*)0}},{{&g_502,&g_173,&g_5[0],&g_5[1],&g_5[0]},{(void*)0,(void*)0,&g_502,&g_173,(void*)0},{&g_502,&g_173,(void*)0,&g_173,(void*)0},{&g_5[5],(void*)0,(void*)0,&g_5[1],&g_5[0]},{&g_516,&g_173,&g_516,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_173,(void*)0},{&g_516,&g_173,&g_516,&g_516,(void*)0},{&g_516,&g_502,(void*)0,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_516,(void*)0}},{{&g_516,(void*)0,&g_502,&g_173,(void*)0},{&g_5[5],&g_502,&g_5[0],(void*)0,(void*)0},{&g_502,&g_173,&g_5[0],&g_5[1],&g_5[0]},{(void*)0,(void*)0,&g_502,&g_173,(void*)0},{&g_502,&g_173,(void*)0,&g_173,(void*)0},{&g_5[5],(void*)0,(void*)0,&g_5[1],&g_5[0]},{&g_516,&g_173,&g_516,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_173,(void*)0},{&g_516,&g_173,&g_516,&g_516,(void*)0}},{{&g_516,&g_502,(void*)0,(void*)0,&g_5[0]},{&g_173,(void*)0,(void*)0,&g_516,(void*)0},{&g_516,(void*)0,&g_502,&g_173,(void*)0},{&g_5[5],&g_502,&g_5[0],(void*)0,(void*)0},{&g_502,&g_173,&g_5[0],&g_5[1],&g_5[0]},{(void*)0,(void*)0,&g_502,&g_173,(void*)0},{(void*)0,&g_5[0],&g_173,&g_5[0],&g_5[1]},{(void*)0,&g_5[0],&g_5[1],&g_5[7],&g_502},{(void*)0,&g_5[0],(void*)0,&g_173,&g_502}}};
        const uint16_t *l_1990[6][3][7] = {{{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,(void*)0,&l_1837,&l_1837,(void*)0},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,(void*)0,&l_1837}},{{&l_1837,(void*)0,(void*)0,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837}},{{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,(void*)0},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837}},{{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,(void*)0,&l_1837}},{{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,(void*)0,(void*)0,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837}},{{&l_1837,(void*)0,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837,&l_1837},{&l_1837,&l_1837,(void*)0,&l_1837,&l_1837,&l_1837,&l_1837}}};
        const uint16_t **l_1989 = &l_1990[0][0][5];
        uint8_t * const l_1992 = (void*)0;
        uint8_t **l_2071[10][9][2] = {{{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,&g_82},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,(void*)0},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{(void*)0,&g_82},{(void*)0,&g_82},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,&g_82}},{{&g_82,&g_82},{(void*)0,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0}},{{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,&g_82},{&g_82,&g_82},{(void*)0,&g_82},{&g_82,(void*)0},{&g_82,&g_82}},{{&g_82,&g_82},{&g_82,&g_82},{&g_82,(void*)0},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{(void*)0,&g_82},{(void*)0,&g_82},{&g_82,&g_82}}};
        int i, j, k;
        for (g_174 = 4; (g_174 < (-20)); --g_174)
        { /* block id: 733 */
            uint16_t *l_1593 = &g_5[0];
            uint16_t **l_1592 = &l_1593;
            int32_t **l_1595 = &g_16[0];
            int32_t ***l_1596 = &g_1557;
            int32_t ***l_1597[6] = {&g_1571,&g_1571,&g_1571,&g_1571,&g_1571,&g_1571};
            int32_t l_1627 = 0x99EC15EFL;
            uint8_t l_1648 = 247UL;
            uint32_t *l_1664 = &g_45;
            const int32_t * const l_1676 = &l_1613;
            int32_t * const l_1680 = &g_1672;
            int32_t * const * const l_1679 = &l_1680;
            int8_t l_1775[10][6][4] = {{{0xFFL,(-8L),0x6BL,(-1L)},{0xFFL,(-1L),0xB6L,0x41L},{0x5FL,(-1L),0xFFL,1L},{(-1L),8L,(-1L),(-1L)},{0L,8L,0L,1L},{(-1L),(-1L),0xF2L,0x41L}},{{0x0FL,(-1L),(-1L),(-1L)},{1L,(-8L),(-1L),0x1DL},{0x0FL,1L,0xF2L,3L},{(-1L),(-2L),0L,0xE8L},{0L,0xE8L,(-1L),0xE8L},{(-1L),(-2L),0xFFL,3L}},{{0x5FL,1L,0xB6L,0x1DL},{0xFFL,(-8L),(-1L),(-8L)},{0xB6L,0xE8L,(-1L),1L},{0L,(-8L),0xB6L,(-2L)},{1L,0x41L,0x5FL,0xE8L},{0x6BL,0x41L,0x6BL,(-2L)}},{{0x0FL,(-8L),(-1L),1L},{0x91L,0xE8L,1L,(-8L)},{0xFFL,0x1DL,1L,(-1L)},{0x91L,(-2L),(-1L),(-1L)},{0x0FL,0L,0x6BL,8L},{0x6BL,8L,0x5FL,8L}},{{1L,0L,0xB6L,(-1L)},{0L,(-2L),(-1L),(-1L)},{0xB6L,0x1DL,(-1L),(-8L)},{0xB6L,0xE8L,(-1L),1L},{0L,(-8L),0xB6L,(-2L)},{1L,0x41L,0x5FL,0xE8L}},{{0x6BL,0x41L,0x6BL,(-2L)},{0x0FL,(-8L),(-1L),1L},{0x91L,0xE8L,1L,(-8L)},{0xFFL,0x1DL,1L,(-1L)},{0x91L,(-2L),(-1L),(-1L)},{0x0FL,0L,0x6BL,8L}},{{0x6BL,8L,0x5FL,8L},{1L,0L,0xB6L,(-1L)},{0L,(-2L),(-1L),(-1L)},{0xB6L,0x1DL,(-1L),(-8L)},{0xB6L,0xE8L,(-1L),1L},{0L,(-8L),0xB6L,(-2L)}},{{1L,0x41L,0x5FL,0xE8L},{0x6BL,0x41L,0x6BL,(-2L)},{0x0FL,(-8L),(-1L),1L},{0x91L,0xE8L,1L,(-8L)},{0xFFL,0x1DL,1L,(-1L)},{0x91L,(-2L),(-1L),(-1L)}},{{0x0FL,0L,0x6BL,8L},{0x6BL,8L,0x5FL,8L},{1L,0L,0xB6L,(-1L)},{0L,(-2L),(-1L),(-1L)},{0xB6L,0x1DL,(-1L),(-8L)},{0xB6L,0xE8L,(-1L),1L}},{{0L,(-8L),0xB6L,(-2L)},{1L,0x41L,0x5FL,0xE8L},{0x6BL,0x41L,0x6BL,(-2L)},{0x0FL,(-8L),(-1L),1L},{0x91L,0xE8L,1L,(-8L)},{0xFFL,0x1DL,1L,(-1L)}}};
            uint16_t **l_1784 = &l_1593;
            uint16_t l_1794 = 0xCE6FL;
            uint64_t l_1885 = 0UL;
            int8_t **l_1886 = &g_409;
            union U0 *l_1964 = &g_1965;
            int i, j, k;
        }
        (*g_1639) = (*g_1639);
        l_1894[2] ^= (((*g_409) = (p_48.f0 == ((void*)0 == p_50))) ^ (safe_mul_func_uint8_t_u_u(((8L == ((p_47 > (**g_727)) && (l_1976 = (((safe_rshift_func_uint16_t_u_u((p_48.f0 , (safe_div_func_uint8_t_u_u(((((*l_1972) = (0x394CL <= p_47)) == p_47) & 3L), l_1973))), l_1974)) || 0x7C38L) != (*p_50))))) , p_48.f0), (*l_1583))));
        if (((((0x4BL | p_48.f0) != (!((safe_add_func_int16_t_s_s((safe_mod_func_int64_t_s_s((l_1982 == (0x0CL && 0UL)), (safe_rshift_func_uint8_t_u_s((((safe_add_func_uint64_t_u_u(g_45, (safe_sub_func_uint16_t_u_u((((((*l_1989) = ((*g_409) , &l_1976)) != &l_1982) , l_1991) || (*l_1583)), p_48.f0)))) >= 0x85L) && 1UL), 2)))), p_47)) != p_48.f0))) , p_51) == l_1992))
        { /* block id: 905 */
            int32_t *l_1993 = &g_448;
            uint16_t *l_2006[3][2] = {{&g_502,&g_502},{&g_502,&g_502},{&g_502,&g_502}};
            uint16_t ***l_2013 = &g_475;
            union U0 l_2053 = {0x65L};
            uint8_t **l_2073 = (void*)0;
            uint8_t l_2079 = 255UL;
            int32_t l_2084[10] = {0x3F77C5DEL,5L,5L,0x3F77C5DEL,0xC9D9319CL,0x3F77C5DEL,5L,5L,0x3F77C5DEL,0xC9D9319CL};
            int32_t *l_2094 = (void*)0;
            int32_t **l_2093[4][10][6] = {{{(void*)0,&l_2094,(void*)0,(void*)0,&l_2094,(void*)0},{(void*)0,(void*)0,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,(void*)0,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,(void*)0,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,(void*)0,&l_2094,&l_2094,(void*)0},{&l_2094,&l_2094,&l_2094,(void*)0,&l_2094,(void*)0},{&l_2094,&l_2094,&l_2094,(void*)0,(void*)0,&l_2094},{&l_2094,&l_2094,&l_2094,(void*)0,&l_2094,(void*)0}},{{&l_2094,(void*)0,&l_2094,&l_2094,&l_2094,(void*)0},{&l_2094,&l_2094,(void*)0,(void*)0,(void*)0,&l_2094},{(void*)0,(void*)0,&l_2094,(void*)0,&l_2094,&l_2094},{&l_2094,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{&l_2094,(void*)0,&l_2094,(void*)0,&l_2094,&l_2094},{&l_2094,(void*)0,&l_2094,(void*)0,&l_2094,&l_2094},{&l_2094,(void*)0,&l_2094,(void*)0,&l_2094,(void*)0},{&l_2094,&l_2094,(void*)0,&l_2094,&l_2094,&l_2094},{(void*)0,(void*)0,&l_2094,&l_2094,(void*)0,&l_2094},{(void*)0,&l_2094,(void*)0,(void*)0,&l_2094,(void*)0}},{{(void*)0,(void*)0,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,(void*)0,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,(void*)0,&l_2094,&l_2094},{(void*)0,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{(void*)0,&l_2094,(void*)0,&l_2094,&l_2094,(void*)0},{&l_2094,&l_2094,&l_2094,(void*)0,&l_2094,(void*)0},{&l_2094,&l_2094,&l_2094,(void*)0,(void*)0,&l_2094},{&l_2094,&l_2094,&l_2094,(void*)0,&l_2094,(void*)0},{&l_2094,(void*)0,&l_2094,&l_2094,&l_2094,(void*)0}},{{&l_2094,(void*)0,(void*)0,&l_2094,&l_2094,&l_2094},{&l_2094,(void*)0,(void*)0,&l_2094,&l_2094,&l_2094},{&l_2094,&l_2094,&l_2094,&l_2094,(void*)0,&l_2094},{(void*)0,&l_2094,&l_2094,(void*)0,(void*)0,(void*)0},{&l_2094,&l_2094,&l_2094,&l_2094,(void*)0,(void*)0},{(void*)0,&l_2094,&l_2094,&l_2094,(void*)0,&l_2094},{&l_2094,&l_2094,&l_2094,&l_2094,&l_2094,&l_2094},{&l_2094,(void*)0,(void*)0,&l_2094,&l_2094,&l_2094},{&l_2094,(void*)0,&l_2094,&l_2094,(void*)0,&l_2094},{&l_2094,(void*)0,&l_2094,(void*)0,&l_2094,(void*)0}}};
            int i, j, k;
            (*g_1639) = l_1993;
            for (l_1982 = (-25); (l_1982 != 59); l_1982 = safe_add_func_uint8_t_u_u(l_1982, 3))
            { /* block id: 909 */
                int8_t *l_1997 = &g_1095;
                int32_t l_2003 = 0x6960BD33L;
                int32_t l_2007 = 0xB5FA25C0L;
                const int32_t l_2008 = 0x83347876L;
                int32_t * const *l_2024 = (void*)0;
                union U0 l_2051[3][5][3] = {{{{0x30L},{0x93L},{0x93L}},{{0x93L},{0x95L},{255UL}},{{248UL},{255UL},{255UL}},{{0x0DL},{255UL},{0x93L}},{{253UL},{1UL},{1UL}}},{{{255UL},{255UL},{1UL}},{{0xC2L},{255UL},{0x0CL}},{{0xC2L},{0x95L},{253UL}},{{255UL},{0x93L},{255UL}},{{253UL},{0xC2L},{253UL}}},{{{0x0DL},{253UL},{0x0CL}},{{248UL},{253UL},{1UL}},{{0x93L},{0xC2L},{1UL}},{{0x30L},{0x93L},{0x93L}},{{0x93L},{0x95L},{255UL}}}};
                int32_t l_2063 = 8L;
                uint8_t **l_2077[1][4][2] = {{{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82},{&g_82,&g_82}}};
                int i, j, k;
            }
            (*l_1993) ^= (((p_48.f0 = p_47) > ((g_2086--) < (safe_lshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s((p_47 != ((*p_50) = 4L)), ((g_2095 = l_1993) == (void*)0))), 8)))) > ((p_47 <= p_47) >= (safe_mul_func_uint8_t_u_u(((void*)0 == l_2006[2][0]), 251UL))));
        }
        else
        { /* block id: 963 */
            int64_t ****l_2103 = (void*)0;
            int64_t *****l_2102[5] = {&l_2103,&l_2103,&l_2103,&l_2103,&l_2103};
            int32_t *l_2104 = (void*)0;
            int32_t l_2109 = 1L;
            uint32_t l_2115[9] = {0xF7011381L,0xF7011381L,4294967292UL,0xF7011381L,0xF7011381L,4294967292UL,0xF7011381L,0xF7011381L,4294967292UL};
            int i;
            if (p_47)
            { /* block id: 964 */
                uint8_t l_2110 = 0UL;
                for (g_212 = 0; (g_212 > 25); g_212 = safe_add_func_uint16_t_u_u(g_212, 7))
                { /* block id: 967 */
                    int64_t *****l_2106 = &l_2103;
                    int64_t ******l_2105 = &l_2106;
                    int32_t l_2107 = (-1L);
                    int32_t l_2108 = 0L;
                    l_2108 |= ((*l_1583) , ((safe_lshift_func_int16_t_s_s((l_2102[4] == ((*l_2105) = (((p_48.f0 == (l_2104 == (void*)0)) < ((*l_1972) = p_47)) , &l_2103))), 12)) , l_2107));
                }
                ++l_2110;
            }
            else
            { /* block id: 973 */
                int32_t *l_2113[4][9][7] = {{{&l_1894[2],(void*)0,&g_1060[0],&l_1894[2],(void*)0,&g_1060[1],(void*)0},{&l_1894[1],&l_1805,(void*)0,&l_1894[1],(void*)0,&l_1805,&l_1894[1]},{&l_1888,(void*)0,&g_1060[3],(void*)0,&l_1894[2],&l_1805,(void*)0},{&g_448,&g_1060[6],&l_2109,&g_448,&l_1805,(void*)0,(void*)0},{&g_1060[3],&l_1888,&g_1060[3],&l_2109,&g_1060[1],(void*)0,&l_1805},{&g_448,&l_1888,(void*)0,&g_1060[6],&l_1888,&g_1060[2],&g_448},{(void*)0,&l_1888,&g_1060[0],&g_1060[0],&l_1888,(void*)0,(void*)0},{&l_1888,&g_448,&l_1888,&l_1894[2],&l_2109,(void*)0,&l_1894[2]},{&l_1805,(void*)0,&g_1060[6],&l_1805,(void*)0,&l_1805,&g_1060[6]}},{{&l_1894[1],&l_1888,(void*)0,&g_448,&g_448,&l_1888,&l_2109},{(void*)0,(void*)0,&l_1888,&l_1805,&l_1894[2],&l_1888,&l_1888},{&g_448,&g_448,&l_1888,&g_448,&g_448,&l_1888,&l_1805},{&l_2109,&l_1805,(void*)0,(void*)0,&l_1894[2],&g_1060[0],(void*)0},{&g_1060[6],&g_448,&l_1888,&l_1894[2],&g_1060[2],&g_448,&g_448},{&l_2109,(void*)0,&l_1805,(void*)0,(void*)0,&l_1888,&l_1805},{&g_448,&l_1888,&l_2109,&l_1894[1],(void*)0,&l_1894[2],(void*)0},{(void*)0,&g_1060[6],&g_1060[6],(void*)0,&l_1888,&l_1805,(void*)0},{&l_1894[1],&g_448,&g_448,&l_1894[2],&l_1805,&g_1060[2],(void*)0}},{{(void*)0,&g_1060[1],&l_1805,(void*)0,&l_1805,&g_1060[1],(void*)0},{&l_1888,&g_1060[1],&l_1894[2],&g_448,&l_1894[1],&g_448,(void*)0},{(void*)0,(void*)0,&g_1060[0],&l_1805,&l_2109,&l_2109,&l_1805},{&l_1894[2],&g_1060[6],&l_1894[2],&g_448,&l_2109,&l_1888,&g_448},{&g_1060[1],&l_1894[2],&l_1805,(void*)0,&g_1060[6],&l_1805,(void*)0},{&g_448,&g_1060[6],&g_448,&l_1805,&l_1888,&l_1888,&l_1805},{(void*)0,&l_1805,&g_1060[6],&g_1060[3],&g_1060[0],&l_2109,&l_1888},{&l_1888,&l_1888,&l_2109,&g_448,(void*)0,&g_448,&l_2109},{&l_1805,&l_1805,&l_1805,&l_1888,&g_1060[3],&g_1060[1],&l_1894[2]}},{{&l_1805,&g_1060[6],&l_1888,&l_1888,&l_2109,&g_1060[2],&l_2109},{&g_1060[3],&l_1894[2],(void*)0,&l_1894[2],&g_1060[3],&l_1805,(void*)0},{&l_1805,&g_1060[6],&l_1888,&g_1060[1],(void*)0,&l_1894[2],&g_448},{(void*)0,(void*)0,&l_1888,&g_1060[0],&g_1060[0],&l_1888,(void*)0},{&l_1805,&g_1060[1],(void*)0,(void*)0,&l_1888,&g_448,&l_1894[1]},{&g_1060[3],&g_1060[1],&l_1894[2],(void*)0,&g_1060[6],&g_1060[0],&g_1060[6]},{&l_1805,&g_448,(void*)0,(void*)0,&l_2109,&l_1888,&l_1888},{&l_1805,&g_1060[6],&g_1060[3],&g_1060[0],&l_2109,&l_1888,&l_1894[2]},{&l_1888,&l_1888,&l_1894[1],&g_1060[1],&l_1894[1],&l_1888,&l_1888}}};
                int i, j, k;
                l_2113[0][3][3] = ((*g_1037) = &l_2109);
            }
            if (l_2109)
                continue;
            l_1894[2] ^= (*l_1583);
            --l_2115[2];
        }
    }
    return l_2118;
}


/* ------------------------------------------ */
/* 
 * reads : g_448 g_81 g_409 g_212 g_200 g_1454 g_502 g_1555 g_723 g_724 g_298 g_967 g_1572 g_978 g_1569 g_1570 g_1121 g_482
 * writes: g_81 g_212 g_1095 g_502 g_200 g_16 g_1557 g_1569 g_1092 g_1571 g_448
 */
static int8_t  func_52(uint32_t * p_53, int16_t  p_54, union U0  p_55, uint32_t  p_56, uint32_t * p_57)
{ /* block id: 659 */
    int32_t l_1421 = 5L;
    int32_t **l_1422 = (void*)0;
    int32_t *l_1423 = &g_1060[6];
    uint8_t *l_1431 = &g_81;
    int32_t l_1442[7] = {0xCF55335CL,0xCF55335CL,0xCF55335CL,7L,7L,0xCF55335CL,7L};
    union U0 l_1443 = {0xB0L};
    const int16_t l_1444[9] = {0x6181L,0x9DF1L,0x6181L,0x9DF1L,0x6181L,0x9DF1L,0x6181L,0x9DF1L,0x6181L};
    int8_t *l_1445 = &g_1095;
    int32_t l_1463 = 0x8C7FF015L;
    int32_t l_1480 = 0xA7391413L;
    int32_t l_1484 = 0xCB792D3CL;
    int32_t l_1489 = (-1L);
    int32_t l_1493 = (-10L);
    int32_t l_1495 = (-7L);
    int32_t l_1499 = 4L;
    int32_t l_1503 = 0x054FDCC8L;
    int32_t l_1510 = 1L;
    int8_t l_1511 = 0x2BL;
    int32_t ** const *l_1565 = &l_1422;
    int32_t ** const **l_1564 = &l_1565;
    int32_t ***l_1567 = &l_1422;
    int32_t ****l_1566 = &l_1567;
    const int32_t *l_1580 = &g_259[5][4];
    const int32_t **l_1579 = &l_1580;
    int i;
lbl_1574:
    l_1423 = ((g_448 | l_1421) , (void*)0);
    if ((((*l_1445) = ((safe_mul_func_uint16_t_u_u((0x7E51872326B9DB40LL > (safe_unary_minus_func_uint32_t_u((safe_rshift_func_int16_t_s_s((((safe_mod_func_int16_t_s_s((((*l_1431) ^= p_54) < p_56), (((0x7181L && ((0xF4FABFB1D71C7943LL < ((safe_lshift_func_int8_t_s_s(((*g_409) = ((safe_lshift_func_uint8_t_u_u((((l_1421 | 4294967292UL) , (safe_rshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((((p_54 , l_1421) < p_55.f0) , l_1442[1]), l_1442[2])), 7))) && p_56), 2)) < 0L)), 5)) >= p_55.f0)) != p_56)) , l_1443) , p_56))) || p_55.f0) >= p_55.f0), l_1444[6]))))), 65535UL)) > (-6L))) || p_54))
    { /* block id: 664 */
        uint32_t l_1448 = 18446744073709551615UL;
        uint16_t *l_1455 = &g_502;
        int32_t l_1456 = (-1L);
        int32_t l_1488 = 0x654DA28CL;
        int32_t l_1502 = 1L;
        int32_t l_1506 = (-1L);
        int32_t l_1509 = 0x608E3262L;
        int32_t *l_1517 = (void*)0;
        uint16_t l_1545 = 0x1F72L;
        int32_t *l_1554[4][5] = {{(void*)0,&l_1503,&l_1503,(void*)0,&l_1503},{&l_1506,&l_1506,(void*)0,&l_1506,&l_1506},{&l_1503,(void*)0,&l_1503,&l_1503,(void*)0},{&l_1506,&l_1509,&l_1509,&l_1506,&l_1509}};
        const int32_t *l_1577 = &l_1510;
        const int32_t **l_1576 = &l_1577;
        int i, j;
        if ((((safe_lshift_func_uint8_t_u_u((((((l_1448 = 0x74L) || p_56) == (0xF1L >= (*g_409))) , p_57) == (void*)0), 7)) < ((g_200 != p_56) > (safe_div_func_int64_t_s_s(((((*l_1455) &= ((safe_rshift_func_int8_t_s_s(((!p_55.f0) ^ g_1454), 4)) & p_55.f0)) ^ 0xE1FBL) | p_56), l_1456)))) , p_55.f0))
        { /* block id: 667 */
            uint64_t l_1470 = 18446744073709551615UL;
            int32_t l_1482 = 0xC4B3EBAFL;
            int32_t l_1490 = 0x4D09227EL;
            int32_t l_1491 = (-1L);
            int64_t l_1492 = 0xA559345017E6D536LL;
            int64_t l_1494 = 0xD7C623E53D279136LL;
            int32_t l_1500 = 1L;
            int32_t l_1501 = 6L;
            int32_t l_1504 = 5L;
            int8_t l_1505 = 0xE5L;
            int32_t l_1507 = 0x46F583AAL;
            int64_t *****l_1550 = (void*)0;
            int32_t **l_1553 = &l_1423;
            int32_t ***l_1556[6][9] = {{&l_1422,&l_1422,&l_1553,(void*)0,&l_1422,&l_1553,&l_1422,(void*)0,&l_1553},{(void*)0,(void*)0,&l_1553,&l_1422,&l_1422,&l_1553,&l_1422,&l_1422,&l_1553},{&l_1422,&l_1422,&l_1553,(void*)0,&l_1422,&l_1553,&l_1422,(void*)0,&l_1553},{(void*)0,(void*)0,&l_1553,&l_1422,&l_1422,&l_1553,&l_1422,&l_1422,&l_1553},{&l_1422,&l_1422,&l_1553,(void*)0,&l_1422,&l_1553,&l_1422,(void*)0,&l_1553},{(void*)0,(void*)0,&l_1553,&l_1422,&l_1422,&l_1553,&l_1422,&l_1422,&l_1553}};
            int32_t *****l_1568[1][6];
            uint32_t *l_1573 = &g_1092;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 6; j++)
                    l_1568[i][j] = &l_1566;
            }
            for (g_200 = 0; (g_200 != 39); g_200 = safe_add_func_uint32_t_u_u(g_200, 5))
            { /* block id: 670 */
                int16_t l_1462 = 0x6425L;
                int32_t *l_1464 = (void*)0;
                int32_t *l_1465 = &l_1456;
                int32_t *l_1466 = &l_1463;
                int16_t *l_1469 = &g_174;
                int32_t *l_1473 = &g_1060[1];
                int32_t l_1478 = 0L;
                int32_t l_1481 = 0xD10F38E3L;
                int32_t l_1487[2];
                uint8_t l_1512 = 255UL;
                int32_t l_1541 = 0x67522B16L;
                int32_t ***l_1543[3][8][9] = {{{&l_1422,&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,(void*)0,(void*)0},{&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,(void*)0,&l_1422},{&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{&l_1422,(void*)0,(void*)0,&l_1422,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422},{&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0,&l_1422},{&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0,&l_1422,&l_1422},{&l_1422,&l_1422,(void*)0,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422}},{{&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,(void*)0},{&l_1422,(void*)0,(void*)0,&l_1422,&l_1422,&l_1422,(void*)0,(void*)0,&l_1422},{&l_1422,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,(void*)0,&l_1422,&l_1422},{(void*)0,&l_1422,(void*)0,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0},{(void*)0,&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,(void*)0,(void*)0,&l_1422},{&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{(void*)0,&l_1422,&l_1422,&l_1422,(void*)0,(void*)0,&l_1422,&l_1422,&l_1422}},{{&l_1422,&l_1422,(void*)0,(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,&l_1422},{&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{&l_1422,&l_1422,&l_1422,(void*)0,(void*)0,(void*)0,&l_1422,&l_1422,(void*)0},{(void*)0,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422,&l_1422},{&l_1422,&l_1422,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0,&l_1422,(void*)0},{&l_1422,&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0},{&l_1422,&l_1422,(void*)0,&l_1422,&l_1422,(void*)0,&l_1422,(void*)0,&l_1422}}};
                int32_t ****l_1542 = &l_1543[0][2][3];
                int16_t l_1544 = 0x29D0L;
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_1487[i] = 1L;
            }
            (*g_1555) = ((2L | (safe_sub_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((l_1550 != l_1550), p_54)), (safe_rshift_func_int8_t_s_s((*g_409), 5))))) , (l_1554[2][0] = ((*l_1553) = p_57)));
            l_1484 &= ((((((((&g_1384 != p_57) || (l_1553 != (g_1557 = l_1553))) < ((p_56 |= ((*l_1573) = (safe_mod_func_int8_t_s_s(((safe_rshift_func_int8_t_s_s((*g_409), (safe_lshift_func_int16_t_s_s((**g_723), 3)))) && (l_1564 != (g_1569 = l_1566))), (g_967[4] & g_1572[0]))))) & (*l_1423))) <= p_55.f0) < p_54) & (**l_1553)) , 0UL) > 1L);
            if (l_1421)
                goto lbl_1574;
        }
        else
        { /* block id: 707 */
            int32_t **l_1575 = &l_1554[2][0];
            const int32_t ***l_1578[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1578[i] = (void*)0;
            (*g_1121) = ((((**g_1569) = l_1575) == (l_1579 = l_1576)) , (-7L));
            return p_54;
        }
        (*l_1576) = (l_1517 = &l_1488);
    }
    else
    { /* block id: 715 */
        int32_t *l_1581 = (void*)0;
        int32_t *l_1582 = &l_1510;
        p_55.f2 = ((*l_1582) = (g_482 , ((void*)0 == &p_57)));
    }
    return (*g_409);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_45 g_81 g_5 g_16 g_42 g_192 g_200 g_213 g_173 g_174 g_192.f0 g_212 g_259 g_298 g_407 g_409 g_447 g_448 g_427 g_475 g_487 g_571 g_502 g_598 g_350 g_426 g_516 g_1060 g_482 g_930 g_727 g_723 g_724 g_839 g_840 g_841 g_1092 g_1094 g_1095
 * writes: g_45 g_16 g_3 g_42 g_82 g_81 g_173 g_174 g_200 g_212 g_192.f0 g_350 g_378 g_407 g_409 g_425 g_448 g_475 g_482 g_485 g_486 g_502 g_427 g_516 g_1060 g_1092 g_1094 g_1095
 */
static int8_t  func_58(uint32_t * p_59, uint32_t  p_60)
{ /* block id: 9 */
    int64_t l_73 = 0xA73B020B2DE47E5FLL;
    int32_t *l_74 = &g_3;
    uint16_t *l_474 = &g_5[5];
    uint16_t **l_473 = &l_474;
    uint16_t ***l_476 = (void*)0;
    uint16_t ***l_477 = &g_475;
    uint16_t **l_479 = (void*)0;
    uint16_t ***l_478 = &l_479;
    uint8_t *l_480 = (void*)0;
    uint8_t *l_481 = &g_482;
    int32_t *l_1059 = &g_1060[6];
    int32_t l_1103 = 1L;
    uint32_t l_1120 = 4UL;
    union U0 *l_1142 = &g_192[5];
    uint32_t ***l_1143 = &g_378;
    int32_t l_1151 = 0xA66B2394L;
    const uint64_t l_1189 = 0UL;
    int32_t l_1233[5][9] = {{1L,(-2L),1L,1L,0x690602ECL,0x690602ECL,1L,1L,(-2L)},{(-2L),1L,1L,0x690602ECL,0x690602ECL,1L,1L,(-2L),1L},{(-8L),5L,1L,1L,5L,(-8L),0x690602ECL,(-8L),5L},{(-8L),1L,1L,(-8L),(-2L),5L,(-2L),(-8L),1L},{(-2L),(-2L),0x690602ECL,5L,0xAE789587L,5L,0x690602ECL,(-2L),(-2L)}};
    int64_t l_1299 = 0x8054BC6C493CBD7FLL;
    int16_t *l_1301 = (void*)0;
    int16_t **l_1300 = &l_1301;
    const int32_t l_1350 = (-5L);
    int8_t l_1413 = (-5L);
    int i, j;
    if (((*l_1059) |= func_67(l_73, l_74, func_75(&g_16[2], (*l_74), p_59), (((safe_sub_func_uint8_t_u_u(((*l_481) = ((safe_rshift_func_uint16_t_u_s(g_427[1][0], (safe_rshift_func_uint16_t_u_s(((((safe_mul_func_int8_t_s_s(((((l_473 == ((*l_478) = ((*l_477) = g_475))) > 3UL) & p_60) ^ p_60), p_60)) <= 0x77CA87C93DA484EELL) || p_60) & g_5[0]), 1)))) ^ g_5[0])), (-10L))) && l_73) && p_60), &l_73)))
    { /* block id: 466 */
        const uint8_t l_1081 = 254UL;
        uint64_t *l_1084 = &g_967[4];
        const int16_t l_1090 = (-1L);
        uint32_t *l_1091 = &g_1092;
        uint32_t *l_1093[3][2][6] = {{{&g_1094,(void*)0,&g_1094,&g_1094,&g_1094,(void*)0},{&g_1094,(void*)0,&g_1094,(void*)0,&g_1094,(void*)0}},{{&g_1094,&g_1094,&g_1094,(void*)0,&g_1094,&g_1094},{&g_1094,&g_1094,&g_1094,&g_1094,&g_1094,&g_1094}},{{&g_1094,(void*)0,&g_1094,&g_1094,&g_1094,(void*)0},{&g_1094,(void*)0,&g_1094,(void*)0,&g_1094,(void*)0}}};
        int i, j, k;
        for (g_81 = (-18); (g_81 >= 46); g_81 = safe_add_func_uint8_t_u_u(g_81, 5))
        { /* block id: 469 */
            int16_t *l_1069 = &g_174;
            int16_t **l_1068 = &l_1069;
            int16_t ***l_1067 = &l_1068;
            const int32_t l_1071 = 0x915186E7L;
            uint32_t **l_1078 = &g_379;
            if (((void*)0 == &g_839))
            { /* block id: 470 */
                int32_t l_1070 = (-8L);
                (*l_1059) = (((safe_mod_func_int64_t_s_s(0L, ((safe_lshift_func_uint16_t_u_u(((((*l_481) |= (g_173 >= p_60)) || ((*g_409) = 0x5CL)) || (l_1067 != (void*)0)), 0)) , ((((*g_930) == (void*)0) >= ((l_1070 , g_1060[6]) , l_1071)) || (**g_723))))) && p_60) == g_192[5].f0);
            }
            else
            { /* block id: 474 */
                uint16_t l_1082 = 0x7B9DL;
                (*l_74) |= ((safe_lshift_func_int16_t_s_u((9L | (safe_add_func_int64_t_s_s((safe_mod_func_int64_t_s_s(0x892139B878F18D14LL, (**g_839))), ((*l_1059) != (l_1082 = ((0x17L < ((&p_59 == l_1078) != p_60)) , (safe_sub_func_uint16_t_u_u(l_1081, 0x4E63L)))))))), 15)) , p_60);
            }
        }
        (*l_1059) = ((+((**g_839) & (l_1084 != ((*l_1059) , (void*)0)))) > (safe_sub_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u(l_1081, (((((((g_1095 ^= (g_1094 ^= ((*l_1091) &= (((g_516 , (*l_1059)) & (!(g_482 && (((l_1090 != 5L) || 1UL) | g_212)))) != l_1081)))) <= (*l_1059)) >= l_1090) < g_3) , (*l_1059)) || p_60) | g_5[6]))) & (*l_74)) ^ p_60), l_1081)));
    }
    else
    { /* block id: 483 */
        uint8_t *l_1102[6] = {&g_81,&g_81,&g_81,&g_81,&g_81,&g_81};
        int16_t *l_1117 = &g_174;
        int32_t l_1118 = 1L;
        union U0 **l_1119 = (void*)0;
        uint32_t l_1141 = 0x03BA5341L;
        uint32_t l_1152 = 4294967295UL;
        int32_t l_1200 = 0x2FECFDA1L;
        int32_t *l_1201[4][5][3] = {{{(void*)0,(void*)0,&l_1200},{&g_3,&g_1060[6],&l_1200},{&g_1060[6],&g_3,&g_1060[6]},{&g_3,&g_3,&g_1060[6]},{(void*)0,&g_1060[6],&g_1060[6]}},{{(void*)0,(void*)0,&l_1200},{&g_3,&g_1060[6],&l_1200},{&g_1060[6],&g_3,&g_1060[6]},{&g_3,&g_3,&g_1060[6]},{(void*)0,&g_1060[6],&g_1060[6]}},{{(void*)0,(void*)0,&l_1200},{&g_3,&g_1060[6],&l_1200},{&g_1060[6],&g_3,&g_1060[6]},{&g_3,&g_3,&g_1060[6]},{(void*)0,&g_1060[6],&g_1060[6]}},{{(void*)0,(void*)0,&l_1200},{&g_3,&g_1060[6],&l_1200},{&g_1060[6],&g_3,&g_1060[6]},{&g_3,&g_3,&g_1060[6]},{(void*)0,&g_1060[6],&g_1060[6]}}};
        uint32_t l_1240 = 0UL;
        int64_t l_1331[9] = {5L,5L,5L,5L,5L,5L,5L,5L,5L};
        int i, j, k;
        for (g_502 = 5; (g_502 != 59); g_502 = safe_add_func_uint8_t_u_u(g_502, 9))
        { /* block id: 486 */
            for (g_448 = (-20); (g_448 <= (-23)); g_448 = safe_sub_func_uint32_t_u_u(g_448, 2))
            { /* block id: 489 */
                for (g_1092 = 0; (g_1092 <= 2); g_1092 += 1)
                { /* block id: 492 */
                    if (p_60)
                        break;
                }
            }
            for (g_3 = 0; g_3 < 5; g_3 += 1)
            {
                g_16[g_3] = &g_1060[3];
            }
            for (p_60 = 0; (p_60 <= 31); p_60 = safe_add_func_uint32_t_u_u(p_60, 1))
            { /* block id: 499 */
                return (*g_409);
            }
        }
    }
    return (*l_74);
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static uint32_t  func_61(int32_t  p_62, int32_t  p_63, uint64_t  p_64, const int32_t ** p_65)
{ /* block id: 7 */
    return g_5[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_173 g_3 g_487 g_16 g_571 g_447 g_448 g_409 g_212 g_45 g_502 g_598 g_42 g_350 g_426 g_174 g_516 g_213 g_259 g_427
 * writes: g_173 g_3 g_485 g_486 g_16 g_502 g_448 g_427 g_174 g_516 g_81
 */
static int32_t  func_67(uint8_t  p_68, int32_t * p_69, int64_t * p_70, const uint32_t  p_71, int64_t * p_72)
{ /* block id: 172 */
    uint32_t l_489 = 0xAB1FD68FL;
    uint8_t *l_496 = (void*)0;
    int32_t l_529 = 7L;
    uint16_t *l_531 = &g_502;
    uint16_t **l_530 = &l_531;
    int32_t l_538 = 0L;
    int32_t l_546 = 0x109EB598L;
    int32_t l_547 = 0x85E8E794L;
    int32_t l_550 = 0x5DAAD4D6L;
    int32_t l_551[8][5] = {{0xBBABEF61L,0L,0xD1EAC8CFL,1L,1L},{0x84617000L,0L,0x84617000L,0xCF3B11F8L,1L},{0xBBABEF61L,8L,0x84617000L,1L,0xCF3B11F8L},{0xBBABEF61L,0L,0xD1EAC8CFL,1L,1L},{0x84617000L,0L,0x84617000L,0xCF3B11F8L,1L},{0xBBABEF61L,8L,0x84617000L,1L,0xCF3B11F8L},{0xBBABEF61L,0L,0xD1EAC8CFL,1L,1L},{0x84617000L,0L,0x84617000L,0xCF3B11F8L,1L}};
    int8_t l_567 = 0xC6L;
    uint32_t l_586 = 0UL;
    int32_t *l_593 = &l_547;
    const int32_t l_610 = 3L;
    int64_t *l_715 = &g_350;
    union U0 l_717 = {0xBDL};
    uint32_t l_720 = 1UL;
    int64_t **l_774[5][1] = {{&l_715},{&l_715},{&l_715},{&l_715},{&l_715}};
    uint32_t l_808 = 0xB896A439L;
    uint8_t ***l_814 = &g_486;
    uint8_t l_820 = 3UL;
    uint16_t l_821[4][8] = {{6UL,6UL,65535UL,6UL,6UL,65535UL,6UL,6UL},{65528UL,6UL,65528UL,65528UL,6UL,65528UL,65528UL,6UL},{6UL,65528UL,65528UL,6UL,65528UL,65528UL,6UL,65528UL},{6UL,6UL,65535UL,6UL,6UL,65535UL,6UL,6UL}};
    int32_t l_906 = 0x354E31B6L;
    uint32_t * const l_997 = &l_489;
    int8_t l_1015[1];
    int16_t *l_1032 = &g_174;
    int16_t **l_1031 = &l_1032;
    uint16_t l_1044 = 65532UL;
    uint16_t l_1056 = 0x0303L;
    int i, j;
    for (i = 0; i < 1; i++)
        l_1015[i] = (-10L);
    for (g_173 = 0; (g_173 <= 1); g_173 += 1)
    { /* block id: 175 */
        uint8_t **l_483 = &g_82;
        uint8_t ***l_484[9][2][6] = {{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483,&l_483,&l_483}}};
        int32_t l_492 = 0L;
        uint8_t *l_524 = &g_482;
        uint8_t ** const l_523 = &l_524;
        uint8_t ** const *l_522 = &l_523;
        const int8_t *l_525 = &g_526;
        int32_t l_543 = (-1L);
        int32_t l_545 = (-9L);
        int32_t l_548 = 0xC59D77D8L;
        int32_t l_549[6][3][10] = {{{0xBEE703BBL,1L,(-1L),(-8L),(-7L),1L,0x1DD32060L,0x5A9B6240L,1L,2L},{(-6L),0x178E5E52L,0xD9611BD1L,(-1L),0xE796479AL,1L,(-8L),4L,0x89DE8618L,0L},{0xBEE703BBL,7L,2L,4L,(-8L),0x44E4862DL,0x2575DABEL,(-1L),(-4L),(-4L)}},{{(-4L),0xA5AA0784L,0xE6D67F4CL,1L,1L,0xE6D67F4CL,0xA5AA0784L,(-4L),0L,0x89DE8618L},{(-1L),0xDC5297C5L,0xFF8A1314L,0xD9611BD1L,7L,0xA5AA0784L,0L,(-1L),2L,1L},{0L,(-6L),0xFF8A1314L,7L,(-1L),(-1L),0x9EF49825L,(-4L),(-1L),0xCD8EA76DL}},{{(-7L),0xFF8A1314L,0xE6D67F4CL,0x89DE8618L,0x9EF49825L,0x2575DABEL,0L,(-1L),0L,0x2575DABEL},{0xD9611BD1L,0x2575DABEL,2L,0x2575DABEL,0xD9611BD1L,(-7L),0xCD8EA76DL,4L,0xE796479AL,(-1L)},{4L,(-4L),0xD9611BD1L,(-8L),0x178E5E52L,0x9EF49825L,(-1L),0x5A9B6240L,0xA5AA0784L,(-1L)}},{{0L,(-8L),(-1L),1L,0xD9611BD1L,0x1DD32060L,(-1L),(-3L),0x5A9B6240L,0x2575DABEL},{(-1L),0x93646EBBL,0xCD8EA76DL,0x8B4FEE1EL,0x9EF49825L,0xD9611BD1L,0xD9611BD1L,0x9EF49825L,0x8B4FEE1EL,0xCD8EA76DL},{0xE6D67F4CL,0xE6D67F4CL,0x93646EBBL,0x178E5E52L,(-1L),0x5A9B6240L,(-8L),0xDC5297C5L,(-1L),0L}},{{7L,0x93646EBBL,0xE796479AL,0x89DE8618L,0x1DD32060L,0x8B4FEE1EL,0xBEE703BBL,(-8L),(-8L),0x178E5E52L},{(-6L),2L,0xE6D67F4CL,(-7L),0L,0xA5AA0784L,(-1L),7L,(-3L),0x8B4FEE1EL},{(-7L),(-8L),(-1L),1L,0xBEE703BBL,1L,(-1L),(-8L),(-7L),1L}},{{0xDC5297C5L,0xBEE703BBL,0L,0x5A9B6240L,7L,4L,0x2575DABEL,0xCD8EA76DL,0xFF8A1314L,(-8L)},{(-1L),0x8B4FEE1EL,4L,0x5A9B6240L,0x93646EBBL,4L,1L,(-1L),(-7L),0x2575DABEL},{0xBEE703BBL,0xCD8EA76DL,0xD9611BD1L,1L,(-1L),(-6L),0x89DE8618L,(-3L),(-3L),0x89DE8618L}}};
        uint64_t l_555 = 18446744073709551615UL;
        int i, j, k;
        (*p_69) &= 0x2B030C26L;
        g_486 = (g_485 = l_483);
        (*p_69) &= 5L;
        (*g_487) = &g_448;
    }
    if ((*p_69))
    { /* block id: 229 */
        (*g_571) = (*g_487);
        return (*g_447);
    }
    else
    { /* block id: 232 */
        int16_t l_572 = (-8L);
        uint64_t l_583 = 18446744073709551611UL;
        int32_t l_587 = 8L;
        uint16_t *l_590 = &g_502;
        int32_t *l_591 = &l_546;
        int32_t **l_592 = &l_591;
        l_587 = ((*p_69) = ((l_572 & (((safe_rshift_func_uint8_t_u_u(l_529, 0)) ^ l_572) == (safe_add_func_int16_t_s_s(((((void*)0 != &p_69) , ((safe_sub_func_uint16_t_u_u((p_71 ^ (*g_409)), ((safe_lshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_u(((l_583 || ((safe_mod_func_int64_t_s_s((l_531 != l_531), g_173)) < l_586)) , l_529), l_567)) , 0x98L), 1)) != l_551[7][1]))) , p_68)) & p_71), l_583)))) >= 3UL));
        (*p_69) = (((p_71 | (l_590 == ((1L ^ 6L) , (*l_530)))) || (((*l_592) = l_591) == (*g_571))) , (((*l_591) ^ (g_45 <= 0xD2939B17L)) & p_71));
        (*l_592) = l_593;
    }
    for (g_502 = 0; (g_502 > 18); g_502 = safe_add_func_uint16_t_u_u(g_502, 3))
    { /* block id: 241 */
        int32_t *l_596 = &l_529;
        int32_t l_631 = 1L;
        int32_t l_643 = (-1L);
        int32_t l_644 = (-1L);
        int32_t l_645 = (-6L);
        int32_t l_649[8][2][1] = {{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}},{{3L},{0x7B4FD4EBL}}};
        int16_t l_696 = 0L;
        int i, j, k;
        (*g_598) = l_596;
        if ((*l_593))
            break;
        for (l_546 = (-3); (l_546 < 16); l_546 = safe_add_func_int32_t_s_s(l_546, 2))
        { /* block id: 246 */
            int32_t *l_601 = (void*)0;
            int32_t **l_602 = &g_16[1];
            int32_t l_638 = 0xC6BA9E48L;
            int32_t l_639 = 0L;
            int32_t l_647 = 0x170D95E9L;
            int32_t l_650 = (-6L);
            int32_t l_654 = (-7L);
            int32_t l_656 = 4L;
            int32_t l_657 = 0xC965EC95L;
            int32_t l_658 = 1L;
            int32_t l_659 = 0xE3C61104L;
            uint8_t **l_686 = &g_82;
            (*l_602) = l_601;
            for (g_448 = 1; (g_448 <= 4); g_448 += 1)
            { /* block id: 250 */
                uint16_t l_603 = 0x9F56L;
                uint16_t ***l_606 = (void*)0;
                int32_t l_620 = 0L;
                int32_t l_624 = 0x579546B7L;
                int32_t l_640[1][4][6] = {{{0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L},{0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L},{0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L},{0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L,0xE7E52ED8L}}};
                int32_t l_641[5];
                uint64_t l_660 = 0xE58341893C334C97LL;
                uint8_t **l_685[9] = {&g_82,&g_82,(void*)0,&g_82,&g_82,(void*)0,&g_82,&g_82,(void*)0};
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_641[i] = (-3L);
                for (l_489 = 1; (l_489 <= 4); l_489 += 1)
                { /* block id: 253 */
                    int16_t *l_618 = &g_174;
                    uint16_t *l_619 = &g_516;
                    int32_t l_621 = (-1L);
                    int32_t l_646 = (-2L);
                    int32_t l_648 = 0xFC295E9FL;
                    int32_t l_651 = (-8L);
                    int32_t l_652 = 0x025EBD53L;
                    int32_t l_653 = 0xEF4F97EAL;
                    int32_t l_655[5] = {(-10L),(-10L),(-10L),(-10L),(-10L)};
                    union U0 l_671 = {0xFCL};
                    int32_t l_673 = 0xBDEA5257L;
                    int i, j;
                    l_621 |= (((l_603 = l_551[l_489][l_489]) | ((safe_mul_func_int8_t_s_s(((((void*)0 != l_606) & (safe_sub_func_uint32_t_u_u((safe_unary_minus_func_uint8_t_u(p_71)), l_610))) || (safe_mod_func_int8_t_s_s((((((*g_409) || (safe_add_func_int64_t_s_s(((*p_72) |= ((((*l_619) ^= (((*l_618) ^= (safe_unary_minus_func_uint16_t_u(((*p_70) > ((safe_rshift_func_uint16_t_u_s(((((*g_426) = (&g_16[l_489] != (void*)0)) , (*l_596)) || (*p_69)), g_42)) & (*l_593)))))) && p_68)) < g_213) != p_71)), p_71))) != 0UL) , p_71) >= l_620), p_68))), 0xB2L)) , (*g_409))) & g_502);
                    if ((safe_rshift_func_uint16_t_u_u(p_68, 3)))
                    { /* block id: 260 */
                        int16_t l_625 = 0x68FFL;
                        int32_t *l_626 = (void*)0;
                        int32_t *l_627 = &l_547;
                        int32_t l_628[9][8] = {{(-8L),0L,2L,0x9ED0791FL,(-8L),0x9ED0791FL,2L,0L},{(-8L),0x9ED0791FL,2L,0L,(-8L),0L,2L,0x9ED0791FL},{(-8L),0L,2L,0x9ED0791FL,(-8L),0x9ED0791FL,2L,0L},{(-8L),0x9ED0791FL,2L,0L,(-8L),0L,2L,0x9ED0791FL},{(-8L),0L,2L,0x9ED0791FL,(-8L),0x9ED0791FL,2L,0L},{(-8L),0x9ED0791FL,2L,0L,(-8L),0L,2L,0x9ED0791FL},{(-8L),0L,2L,0x9ED0791FL,(-8L),0x9ED0791FL,2L,0L},{(-8L),0x9ED0791FL,2L,0L,(-8L),0L,2L,0x9ED0791FL},{(-8L),0L,2L,0x9ED0791FL,(-8L),0x9ED0791FL,2L,0L}};
                        int32_t *l_629 = &l_620;
                        int32_t *l_630 = &l_551[7][1];
                        int32_t *l_632 = &l_551[7][1];
                        int32_t *l_633 = &l_628[0][5];
                        int32_t *l_634 = &l_628[0][5];
                        int32_t *l_635 = &l_631;
                        int32_t *l_636 = &l_538;
                        int32_t *l_637[1];
                        int32_t l_642[9];
                        uint64_t *l_667 = &l_660;
                        uint8_t *l_672 = &g_81;
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_637[i] = &l_538;
                        for (i = 0; i < 9; i++)
                            l_642[i] = 0xAA9F080FL;
                        ++l_660;
                        (*l_629) ^= (((((g_213 , 0x4A433C18CECE3369LL) == ((safe_rshift_func_uint16_t_u_u(0x7E4EL, 0)) , ((*l_667) = l_641[0]))) , ((*l_672) = (safe_mod_func_int32_t_s_s((((*l_634) = (*p_69)) <= ((*l_593) = (~p_68))), (l_671 , p_71))))) < ((((*l_619)++) <= 0L) == (*g_409))) , 6L);
                        if ((*p_69))
                            continue;
                        (*l_634) = ((*l_636) |= (*p_69));
                    }
                    else
                    { /* block id: 271 */
                        uint64_t *l_676 = &l_660;
                        uint64_t *l_679 = (void*)0;
                        uint64_t *l_680[7] = {&g_200,&g_200,&g_200,&g_200,&g_200,&g_200,&g_200};
                        int i;
                        l_644 ^= ((((*l_596) = (--(*l_676))) || (safe_rshift_func_uint8_t_u_s((safe_div_func_uint64_t_u_u((((((*p_72) = ((l_624 > g_350) || ((((l_685[3] != l_686) >= ((*l_596) = (*g_409))) || (((*l_618) |= (safe_div_func_uint64_t_u_u((+4294967293UL), (*p_70)))) || (safe_add_func_int16_t_s_s((safe_mod_func_int16_t_s_s(l_624, (safe_div_func_uint64_t_u_u(((*l_676) = p_71), g_259[5][4])))), p_71)))) ^ (*p_70)))) , g_259[6][5]) >= g_427[1][1]) != (*g_409)), 7L)), (*l_593)))) != p_71);
                        if ((*p_69))
                            continue;
                    }
                }
            }
            return l_696;
        }
    }
    for (l_489 = 0; (l_489 <= 9); l_489 += 1)
    { /* block id: 288 */
        int16_t l_697 = (-1L);
        uint64_t l_718 = 0xF645141DF3330F3ALL;
        uint32_t ***l_721 = &g_378;
        union U0 *l_731 = &g_192[5];
        int8_t *l_749 = &g_212;
        union U0 *l_771[8][7] = {{&g_192[5],&g_192[5],&g_192[0],&g_192[5],&g_192[5],&g_192[0],&g_192[5]},{&g_192[5],&l_717,&l_717,&g_192[5],&l_717,&l_717,&g_192[5]},{&l_717,&g_192[5],&l_717,&l_717,&g_192[5],&l_717,&l_717},{&g_192[5],&g_192[5],&g_192[0],&g_192[5],&g_192[5],&g_192[0],&g_192[5]},{&g_192[5],&l_717,&l_717,&g_192[5],&l_717,&l_717,&g_192[5]},{&l_717,&g_192[5],&l_717,&l_717,&g_192[5],&l_717,&l_717},{&g_192[5],&g_192[5],&g_192[0],&g_192[5],&g_192[5],&g_192[0],&g_192[5]},{&g_192[5],&l_717,&l_717,&g_192[5],&l_717,&l_717,&g_192[5]}};
        int64_t **l_773 = &l_715;
        int32_t l_795 = 0xB419C839L;
        int32_t l_807 = (-1L);
        int32_t l_872 = 0L;
        int32_t l_873 = 0x33D5CBD9L;
        uint8_t **l_902 = &g_82;
        int32_t *l_986 = &g_448;
        uint8_t *l_1012 = &l_820;
        int32_t l_1047 = 0x11567ADDL;
        int32_t l_1055[2][10][3] = {{{(-1L),(-1L),(-2L)},{0xD73EBC02L,0L,0L},{(-2L),(-1L),0x05F931F9L},{0x8657E120L,0xD73EBC02L,(-6L)},{(-2L),(-2L),(-7L)},{0xD73EBC02L,0x8657E120L,7L},{(-1L),(-2L),(-1L)},{0L,0xD73EBC02L,0xAC4F6832L},{(-1L),(-1L),(-1L)},{0xAC4F6832L,0L,7L}},{{0L,(-1L),(-7L)},{0xAC4F6832L,0xAC4F6832L,(-6L)},{(-1L),0L,0x05F931F9L},{0L,0xAC4F6832L,0L},{(-1L),(-1L),(-2L)},{0xD73EBC02L,0L,0L},{(-2L),(-1L),0x05F931F9L},{0x8657E120L,0xD73EBC02L,(-6L)},{(-2L),(-2L),(-7L)},{0xD73EBC02L,0x8657E120L,7L}}};
        int i, j, k;
    }
    return (*p_69);
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_3 g_81 g_5 g_16 g_42 g_192 g_200 g_213 g_173 g_174 g_192.f0 g_212 g_259 g_298 g_407 g_409 g_447 g_448
 * writes: g_45 g_16 g_3 g_42 g_82 g_81 g_173 g_174 g_200 g_212 g_192.f0 g_350 g_378 g_407 g_409 g_425 g_448
 */
static int64_t * func_75(int32_t ** p_76, const int16_t  p_77, uint32_t * p_78)
{ /* block id: 10 */
    uint32_t l_88[10][6][4] = {{{18446744073709551611UL,0xD081FB71L,0x6F7EBA05L,18446744073709551615UL},{0UL,0x0B167AC4L,0xFF731867L,0x320CD53BL},{0xB5E35254L,0xDF38E6A2L,0UL,0x320CD53BL},{0xE9DC621CL,0x0B167AC4L,0x103C2894L,18446744073709551615UL},{0x9AC803B8L,0xD081FB71L,0x2EB2EFFCL,0x85D54DBCL},{0x12ABB1EFL,0xE9DC621CL,0x25C8E5C6L,18446744073709551615UL}},{{0x103C2894L,0x12ABB1EFL,0xDF38E6A2L,18446744073709551611UL},{0x9AC803B8L,18446744073709551615UL,0x024B1735L,0xD081FB71L},{0xF0833481L,0x51EF177DL,0UL,0x12ABB1EFL},{18446744073709551615UL,0UL,18446744073709551615UL,0x19F073E4L},{0UL,18446744073709551615UL,5UL,0x582D056BL},{0x582D056BL,0x103C2894L,0xE9DC621CL,18446744073709551615UL}},{{0x1B313CF3L,0xF0833481L,0xE9DC621CL,0x1B313CF3L},{0x582D056BL,0xD081FB71L,5UL,0xB5E35254L},{0UL,0x36AA1284L,18446744073709551615UL,0x320CD53BL},{18446744073709551615UL,0x320CD53BL,0UL,0xDF38E6A2L},{0xF0833481L,0x0B167AC4L,0x024B1735L,0xB5E35254L},{0x9AC803B8L,0x19F073E4L,7UL,0x103C2894L}},{{0x2EB2EFFCL,0x1B313CF3L,0x422E233AL,0x422E233AL},{0xDF38E6A2L,0xDF38E6A2L,0UL,0x19F073E4L},{18446744073709551615UL,0x422E233AL,0x2EB2EFFCL,0x36AA1284L},{0x9D30CD94L,18446744073709551611UL,18446744073709551615UL,0x2EB2EFFCL},{0x25C8E5C6L,18446744073709551611UL,18446744073709551615UL,0x36AA1284L},{18446744073709551611UL,0x422E233AL,7UL,0x19F073E4L}},{{0xE4505C26L,0xDF38E6A2L,0x9D30CD94L,0x422E233AL},{0x103C2894L,0x1B313CF3L,0x85D54DBCL,0x103C2894L},{0x19F073E4L,0x8EE8584DL,7UL,0x25C8E5C6L},{0x27B92311L,0x6F7EBA05L,9UL,7UL},{0x25C8E5C6L,0x51EF177DL,0x9AC803B8L,0x51EF177DL},{0x1B313CF3L,5UL,0x2EB2EFFCL,0x25C8E5C6L}},{{0xFF731867L,0x36AA1284L,7UL,0x024B1735L},{0xDF38E6A2L,0x1B313CF3L,0xF0833481L,0xE9DC621CL},{0xDF38E6A2L,0x2EB2EFFCL,7UL,0x19F073E4L},{0xFF731867L,0xE9DC621CL,0x2EB2EFFCL,0x8EE8584DL},{0x1B313CF3L,18446744073709551611UL,0x9AC803B8L,0xDF38E6A2L},{0x25C8E5C6L,0x27B92311L,9UL,0x36AA1284L}},{{0x27B92311L,0xE9DC621CL,7UL,0xE4505C26L},{0x19F073E4L,0xDF38E6A2L,0x85D54DBCL,0xE9DC621CL},{0x103C2894L,0x9D30CD94L,0x9D30CD94L,0x103C2894L},{0xE4505C26L,0x36AA1284L,7UL,9UL},{18446744073709551611UL,0x6F7EBA05L,18446744073709551615UL,0x51EF177DL},{0x25C8E5C6L,7UL,18446744073709551615UL,0x51EF177DL}},{{0x9D30CD94L,0x6F7EBA05L,0x2EB2EFFCL,9UL},{18446744073709551615UL,0x36AA1284L,0UL,0x103C2894L},{0xDF38E6A2L,0x9D30CD94L,0x422E233AL,0xE9DC621CL},{0x2EB2EFFCL,0xDF38E6A2L,7UL,0xE4505C26L},{18446744073709551615UL,0xE9DC621CL,0x320CD53BL,0x36AA1284L},{0x1B313CF3L,0x27B92311L,18446744073709551615UL,0xDF38E6A2L}},{{9UL,18446744073709551611UL,9UL,0x8EE8584DL},{18446744073709551611UL,0xE9DC621CL,1UL,0x19F073E4L},{0x19F073E4L,0x2EB2EFFCL,0x9D30CD94L,0xE9DC621CL},{0x024B1735L,0x1B313CF3L,0x9D30CD94L,0x024B1735L},{0x19F073E4L,0x36AA1284L,1UL,0x25C8E5C6L},{18446744073709551611UL,5UL,9UL,0x51EF177DL}},{{9UL,0x51EF177DL,18446744073709551615UL,7UL},{0x1B313CF3L,0x6F7EBA05L,0x320CD53BL,0x25C8E5C6L},{18446744073709551615UL,0x8EE8584DL,7UL,0x103C2894L},{0x2EB2EFFCL,0x1B313CF3L,0x422E233AL,0x422E233AL},{0xDF38E6A2L,0xDF38E6A2L,0UL,0x19F073E4L},{18446744073709551615UL,0x422E233AL,0x2EB2EFFCL,0x36AA1284L}}};
    int32_t l_92 = 0x1FF5BAEDL;
    union U0 l_105 = {0x5DL};
    int32_t l_141 = 0x6ABCE841L;
    int32_t l_143 = 0x6218FE46L;
    int32_t l_145 = (-1L);
    int32_t l_151 = (-2L);
    int32_t l_153 = 0x997E5F22L;
    const int32_t *l_260[5][3][1] = {{{(void*)0},{&g_3},{(void*)0}},{{&g_3},{(void*)0},{&g_3}},{{(void*)0},{&g_3},{(void*)0}},{{&g_3},{(void*)0},{&g_3}},{{(void*)0},{&g_3},{(void*)0}}};
    int16_t *l_321 = &g_174;
    uint32_t l_361 = 0xF941106FL;
    int64_t *l_377[4][8];
    int64_t l_394 = 0x2C6116AD5E1A435CLL;
    int32_t l_446 = 1L;
    uint16_t *l_460 = &g_5[6];
    uint16_t **l_459 = &l_460;
    uint32_t l_461[10][2] = {{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL},{0x5DA0AD6BL,18446744073709551611UL}};
    int32_t *l_462 = (void*)0;
    int32_t *l_463[2][10][6] = {{{&l_151,(void*)0,(void*)0,&g_448,&l_92,(void*)0},{&l_151,&l_145,&l_92,(void*)0,&l_145,&l_92},{&l_145,&l_145,(void*)0,&l_153,&l_92,&l_92},{&l_153,(void*)0,(void*)0,&l_153,&l_145,&l_92},{(void*)0,&g_3,&l_92,&l_153,&l_92,(void*)0},{&l_153,&l_92,(void*)0,&l_153,&l_92,&g_3},{&l_145,&g_3,&l_145,(void*)0,&l_145,&g_3},{&l_151,(void*)0,(void*)0,&g_448,&l_92,(void*)0},{&l_151,&l_145,&l_92,(void*)0,&l_145,&l_92},{&l_145,&l_145,(void*)0,&l_153,&l_92,&l_92}},{{&l_153,(void*)0,(void*)0,&l_153,&l_145,&l_92},{(void*)0,&g_3,&l_92,&l_153,&l_92,(void*)0},{&l_153,&l_92,(void*)0,&l_153,&l_92,&g_3},{&l_145,&g_3,&l_145,(void*)0,&l_145,&g_3},{&l_151,(void*)0,(void*)0,&g_448,&l_92,(void*)0},{&l_151,&l_145,&l_92,(void*)0,&l_145,&l_92},{&l_145,&l_145,(void*)0,&l_153,&l_92,&l_92},{&l_153,(void*)0,(void*)0,&l_153,&l_145,&l_92},{(void*)0,&g_3,&l_92,&l_153,&l_92,(void*)0},{&l_153,&l_92,(void*)0,&l_153,&l_92,&g_3}}};
    uint32_t l_464[9] = {9UL,1UL,1UL,9UL,1UL,1UL,9UL,1UL,1UL};
    int i, j, k;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
            l_377[i][j] = &g_350;
    }
lbl_366:
    for (g_45 = 0; (g_45 <= 4); g_45 += 1)
    { /* block id: 13 */
        int i;
        g_16[g_45] = (void*)0;
        for (g_3 = 4; (g_3 >= 0); g_3 -= 1)
        { /* block id: 17 */
            union U0 l_86 = {0x78L};
            int32_t l_87 = (-1L);
            int i;
            for (g_42 = 0; (g_42 <= 4); g_42 += 1)
            { /* block id: 20 */
                uint8_t *l_80 = &g_81;
                uint8_t **l_79 = &l_80;
                int32_t l_83 = 0xECDE8719L;
                l_87 &= (((((((((*l_79) = (void*)0) == (g_82 = (void*)0)) <= (g_3 == 0xB81468F3L)) >= 0x40642FC3L) | (l_83 | ((safe_div_func_int64_t_s_s(((((g_81 , l_86) , p_77) >= (-1L)) > g_45), (-1L))) | p_77))) && p_77) | p_77) && g_45);
            }
            l_88[6][2][1] = 0L;
            for (g_81 = 0; (g_81 <= 4); g_81 += 1)
            { /* block id: 28 */
                uint32_t *l_91 = &l_88[7][4][1];
                int i;
                l_92 = ((safe_mod_func_uint64_t_u_u(g_5[0], ((g_16[g_81] != (p_77 , l_91)) | p_77))) != g_3);
            }
        }
    }
    for (g_3 = 0; (g_3 <= 4); g_3 += 1)
    { /* block id: 35 */
        int16_t l_93 = 0xE36FL;
        int32_t l_135 = (-5L);
        int32_t l_136 = (-2L);
        int32_t l_137 = 0x3F4C8ED2L;
        int32_t l_142 = 2L;
        int32_t l_144 = (-1L);
        int32_t l_146 = (-10L);
        int32_t l_147 = 2L;
        int32_t l_149 = 0xCC334F83L;
        int32_t l_150 = (-1L);
        int32_t l_152[6][8][5] = {{{1L,0xED9211E9L,0L,(-2L),0x0529A07FL},{0x3D3CFB5FL,(-3L),0xBD609039L,0x22E916BBL,0x38CC87C9L},{(-4L),0x2183A9A7L,0xF3AE84E3L,0xED9211E9L,0xCDDDF838L},{0xACEDF7BAL,1L,1L,0xACEDF7BAL,2L},{0xCDDDF838L,0x22E916BBL,9L,0xF77B4A3BL,0xACEDF7BAL},{0xED9211E9L,0x2183A9A7L,0x0529A07FL,0x71645DA5L,0x5A9511BFL},{0x681B76BFL,0x477A9A3AL,(-8L),0xF77B4A3BL,1L},{(-3L),0x472E0867L,0x65E96A0BL,0xACEDF7BAL,0x98853BCEL}},{{0x477A9A3AL,7L,0x71645DA5L,0xED9211E9L,(-2L)},{0x681B76BFL,(-8L),0xE2246E6AL,0x0529A07FL,(-2L)},{(-8L),0x71645DA5L,0x2183A9A7L,0xBEE15430L,2L},{0xDAF28E72L,(-4L),0x32BA1A25L,0xB8501E2EL,2L},{0x477A9A3AL,(-1L),1L,0xF3AE84E3L,(-2L)},{2L,0xF3AE84E3L,0x38CC87C9L,0x2959A087L,0xBEE15430L},{0xBD609039L,(-1L),(-1L),(-1L),(-1L)},{1L,0xDAF28E72L,(-1L),0L,0L}},{{(-5L),0x71645DA5L,0x472E0867L,0x2959A087L,0xF3AE84E3L},{0xB8501E2EL,0xD147D6BFL,9L,0xAC6FD517L,0x477A9A3AL},{(-5L),0xB8501E2EL,0x65E96A0BL,1L,0xE2246E6AL},{1L,(-8L),(-3L),0xBEE15430L,(-4L)},{0xBD609039L,0xC3D5CCC3L,9L,(-1L),2L},{2L,0xE2246E6AL,0x8F057B95L,(-8L),0xDAF28E72L},{0x477A9A3AL,0x0529A07FL,0xCDDDF838L,0x477A9A3AL,(-5L)},{0xDAF28E72L,0x0529A07FL,(-1L),0L,0x477A9A3AL}},{{(-8L),0xE2246E6AL,0xDAF28E72L,2L,0xAC6FD517L},{0L,0xC3D5CCC3L,0x3D3CFB5FL,0x71645DA5L,0x71645DA5L},{0x32BA1A25L,(-8L),0x32BA1A25L,0x65E96A0BL,(-1L)},{0xC3D5CCC3L,0xB8501E2EL,(-6L),(-8L),9L},{0L,0xD147D6BFL,7L,0x0529A07FL,1L},{1L,0x71645DA5L,(-6L),9L,2L},{(-4L),0xDAF28E72L,0x32BA1A25L,1L,(-6L)},{0x477A9A3AL,(-1L),0x3D3CFB5FL,0xF3AE84E3L,1L}},{{9L,0xF3AE84E3L,0xDAF28E72L,0xBD609039L,0xBEE15430L},{0x2959A087L,(-1L),(-1L),0L,(-1L)},{1L,(-4L),0xCDDDF838L,0L,0x71645DA5L},{0xE2246E6AL,0x71645DA5L,0x8F057B95L,0xBD609039L,0xF3AE84E3L},{1L,1L,9L,0xF3AE84E3L,0x65E96A0BL},{(-5L),1L,(-3L),1L,(-5L)},{(-2L),(-8L),0x65E96A0BL,9L,(-4L)},{0x2959A087L,0x32BA1A25L,9L,0x0529A07FL,9L}},{{2L,(-5L),0x472E0867L,(-8L),(-4L)},{0x65E96A0BL,0x0529A07FL,(-1L),0x65E96A0BL,(-5L)},{(-4L),(-1L),(-1L),0x71645DA5L,0x65E96A0BL},{(-8L),(-5L),0x38CC87C9L,2L,0xF3AE84E3L},{(-1L),0xC3D5CCC3L,1L,0L,0x71645DA5L},{0xC3D5CCC3L,1L,0x32BA1A25L,0x477A9A3AL,(-1L)},{0xC3D5CCC3L,1L,0x2183A9A7L,(-8L),0xBEE15430L},{(-1L),0xD147D6BFL,0xE2246E6AL,0x38CC87C9L,0L}}};
        int8_t l_182 = 0xA1L;
        int32_t l_228 = 0xA9BD93B3L;
        const int64_t l_332[1][3] = {{0xF6F8027C97B53E73LL,0xF6F8027C97B53E73LL,0xF6F8027C97B53E73LL}};
        uint32_t l_408 = 0xB64EEE70L;
        const int32_t l_433 = 0x68611746L;
        uint8_t *l_444 = &g_81;
        int i, j, k;
        if ((l_93 , l_93))
        { /* block id: 36 */
            uint8_t l_104 = 0x86L;
            int32_t l_121 = 0x6F24FD69L;
            int16_t *l_122 = (void*)0;
            int16_t *l_123 = &l_93;
            int32_t l_124 = 1L;
            int32_t l_138 = (-1L);
            int32_t l_139[5];
            int16_t l_148 = (-6L);
            uint32_t l_154 = 1UL;
            uint16_t *l_172 = &g_173;
            int32_t *l_175[10][3] = {{&l_150,&l_139[4],(void*)0},{&l_92,(void*)0,(void*)0},{&l_136,&l_138,(void*)0},{&l_92,&l_138,&l_150},{&l_150,(void*)0,(void*)0},{&l_150,&l_139[4],(void*)0},{&l_92,(void*)0,(void*)0},{&l_136,&l_138,(void*)0},{&l_92,&l_138,&l_150},{&l_150,(void*)0,(void*)0}};
            uint32_t *l_176 = &l_154;
            int32_t l_229 = 1L;
            union U0 l_230 = {0UL};
            int32_t l_290 = (-4L);
            const int32_t *l_300 = &l_149;
            int64_t *l_380 = &g_42;
            int i, j;
            for (i = 0; i < 5; i++)
                l_139[i] = 3L;
            l_124 = (safe_div_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_rshift_func_int16_t_s_u(((*l_123) = (safe_mul_func_uint16_t_u_u(((g_3 , (((((safe_rshift_func_uint8_t_u_u(l_104, ((l_105 , (safe_lshift_func_uint16_t_u_s(((+(safe_add_func_uint32_t_u_u((p_77 < (safe_add_func_int16_t_s_s(((g_5[2] , p_77) == (+((l_92 , g_5[2]) == (safe_sub_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((~(safe_sub_func_uint8_t_u_u(p_77, l_121))), l_104)), p_77))))), 0xA155L))), l_93))) <= p_77), 11))) , l_93))) , g_81) | 250UL) != (-1L)) , l_92)) == 8L), g_5[3]))), g_42)), 10)), p_77));
            for (l_121 = 0; (l_121 <= 4); l_121 += 1)
            { /* block id: 41 */
                int32_t l_125 = 0x1B86B2CCL;
                int32_t *l_126 = &l_124;
                int32_t *l_127 = &l_92;
                int32_t *l_128 = &l_124;
                int32_t *l_129 = &l_92;
                int32_t *l_130 = (void*)0;
                int32_t *l_131 = &l_125;
                int32_t *l_132 = &l_124;
                int32_t *l_133 = (void*)0;
                int32_t *l_134[4];
                int64_t l_140 = 0xEA2622DB6E2B7B1BLL;
                int i;
                for (i = 0; i < 4; i++)
                    l_134[i] = &l_92;
                l_154--;
            }
            l_153 |= (((safe_sub_func_uint16_t_u_u((g_174 = ((*l_172) = (l_141 = ((safe_rshift_func_int16_t_s_s(((safe_unary_minus_func_uint16_t_u((safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(g_42, (p_77 , (safe_rshift_func_uint8_t_u_u(((g_45 || (g_3 <= ((safe_add_func_int32_t_s_s((g_42 != ((&l_93 == (void*)0) ^ ((p_77 ^ g_42) < l_138))), p_77)) && 8UL))) <= l_88[6][2][1]), p_77))))), 2L)))) && g_5[7]), 4)) , g_42)))), g_5[6])) , 0L) == p_77);
            if (((8UL != ((*l_176) &= 0xC5B995B8L)) , ((void*)0 == p_76)))
            { /* block id: 49 */
                uint32_t l_177 = 0x86254796L;
                union U0 l_185 = {0x90L};
                uint64_t *l_199 = &g_200;
                int8_t *l_211 = &g_212;
                int64_t *l_214 = &g_42;
                int32_t *l_248 = (void*)0;
                int16_t *l_322 = &g_174;
                --l_177;
                if (((((safe_sub_func_uint64_t_u_u(l_182, (l_141 ^ (safe_mod_func_uint8_t_u_u((l_185 , (safe_mod_func_int8_t_s_s(((safe_div_func_uint64_t_u_u((65533UL <= (((((*l_214) = (safe_mod_func_int16_t_s_s((g_192[5] , ((safe_lshift_func_int16_t_s_s(((*l_123) |= (p_77 & (l_136 > (((safe_sub_func_uint64_t_u_u(((++(*l_199)) != (safe_sub_func_int32_t_s_s(l_177, ((++(*l_176)) ^ (safe_rshift_func_int8_t_s_s(((*l_211) = ((safe_mod_func_int32_t_s_s(l_185.f0, p_77)) , p_77)), p_77)))))), p_77)) | 0x810BL) , p_77)))), l_88[1][4][3])) < g_213)), l_145))) && 0x568A418543001A50LL) , g_173) < (-9L))), p_77)) <= 0xCB57L), p_77))), p_77))))) <= l_150) > 0L) >= g_5[0]))
                { /* block id: 56 */
                    uint64_t l_215 = 3UL;
                    int32_t *l_220 = (void*)0;
                    uint8_t *l_247 = &l_104;
                    l_215--;
                    l_151 = (l_92 |= ((((l_177 | (((safe_rshift_func_int8_t_s_s(((void*)0 == l_220), 0)) > p_77) <= ((safe_mod_func_uint8_t_u_u((g_173 || (p_77 > ((safe_sub_func_uint32_t_u_u((((l_177 != (((*l_123) = ((+(g_174 == ((l_228 , p_77) || p_77))) > l_228)) < p_77)) == g_173) & l_146), 1UL)) == g_174))), l_229)) , 0x7C4E0F4D10C2F2DALL))) , l_230) , g_5[0]) & 4UL));
                    if ((safe_add_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((((*p_76) = ((safe_lshift_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(((!g_81) == ((safe_lshift_func_uint8_t_u_s((safe_div_func_uint8_t_u_u((((safe_lshift_func_int16_t_s_s(g_192[5].f0, ((*l_123) = g_81))) > ((*l_214) = 0x78FCAF225372B5BDLL)) >= l_88[2][2][2]), (g_3 | ((*l_247) |= p_77)))), g_5[0])) > ((4294967289UL ^ g_45) && 0xED8CL))))), p_77)) , &g_3)) != &l_139[3]) && g_3), l_151)), g_81)))
                    { /* block id: 65 */
                        l_248 = ((*p_76) = (*p_76));
                    }
                    else
                    { /* block id: 68 */
                        const int32_t *l_258 = &g_259[5][4];
                        const int32_t **l_257 = &l_258;
                        l_260[1][2][0] = ((*l_257) = (((safe_mul_func_uint8_t_u_u(1UL, (safe_add_func_uint64_t_u_u(((*l_199)++), (safe_rshift_func_uint8_t_u_u(0x67L, 5)))))) ^ l_93) , &g_3));
                        (*p_76) = (void*)0;
                    }
                }
                else
                { /* block id: 74 */
                    int32_t l_283 = (-1L);
                    int32_t l_299 = 0xBF68E014L;
                    uint8_t *l_312 = (void*)0;
                    uint8_t *l_313 = &g_192[5].f0;
                    uint8_t *l_331 = &l_230.f0;
                    int16_t l_334 = 9L;
                    for (g_45 = 0; (g_45 < 26); g_45 = safe_add_func_int8_t_s_s(g_45, 2))
                    { /* block id: 77 */
                        int32_t l_278[9][10][2] = {{{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL}},{{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L}},{{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L}},{{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL}},{{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L}},{{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL}},{{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L}},{{0x88C86E7DL,0x0B9EC8A6L},{0xA71976BEL,0x6B8C3321L},{0x6B8C3321L,0xA71976BEL},{0x0B9EC8A6L,0x88C86E7DL},{0x0B9EC8A6L,0xA71976BEL},{0x6B8C3321L,0x6B8C3321L},{0xA71976BEL,0x0B9EC8A6L},{0x88C86E7DL,0xA71976BEL},{0x88C86E7DL,(-5L)},{(-5L),0x88C86E7DL}},{{0xA71976BEL,0L},{0xA71976BEL,0x88C86E7DL},{(-5L),(-5L)},{0x88C86E7DL,0xA71976BEL},{0L,0xA71976BEL},{0x88C86E7DL,(-5L)},{(-5L),0x88C86E7DL},{0xA71976BEL,0L},{0xA71976BEL,0x88C86E7DL},{(-5L),(-5L)}}};
                        uint8_t *l_281 = (void*)0;
                        uint8_t *l_282 = &l_105.f0;
                        int i, j, k;
                        l_283 = (((safe_add_func_uint8_t_u_u(((((*l_282) = (safe_rshift_func_uint16_t_u_s((safe_div_func_uint8_t_u_u(p_77, ((safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((0x65524AE8L || (safe_add_func_uint8_t_u_u((((*l_172) ^= g_212) > 0x0B73L), (((safe_sub_func_int32_t_s_s((~p_77), l_278[5][7][0])) || 0x33L) , (p_77 , (((safe_sub_func_int16_t_s_s((((*p_76) = &g_3) != &g_259[1][0]), g_3)) || 0xFD497B51L) && g_42)))))), g_259[0][1])), g_5[5])) , p_77))), g_192[5].f0))) , g_192[5].f0) , 255UL), g_3)) , p_76) != (void*)0);
                        (*p_76) = (*p_76);
                        l_299 = (safe_lshift_func_int8_t_s_u(((g_45 & g_174) >= ((safe_mul_func_uint8_t_u_u((--(*l_282)), (((*l_172) = l_290) <= ((((&g_45 == (void*)0) >= ((l_185.f2 = (safe_lshift_func_uint16_t_u_u(0xA7E0L, ((safe_mul_func_int8_t_s_s(((!p_77) , g_42), (safe_lshift_func_uint16_t_u_s((0L || (-1L)), 14)))) || p_77)))) ^ l_283)) && 2UL) , g_5[5])))) == g_298)), 4));
                    }
                    l_300 = &g_259[5][4];
                    if ((safe_add_func_int16_t_s_s((safe_mod_func_int32_t_s_s((safe_add_func_uint64_t_u_u(((!((((safe_lshift_func_int8_t_s_s((((((*l_211) |= ((safe_div_func_uint8_t_u_u((--(*l_313)), 0x63L)) >= (safe_mul_func_int16_t_s_s(((((!((((l_321 != l_322) != (safe_unary_minus_func_uint16_t_u(((*l_172) = 0x0F5EL)))) & ((8UL || ((l_141 = ((*l_214) |= (safe_div_func_uint8_t_u_u(p_77, p_77)))) , 0x2662L)) >= ((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((+(l_299 ^= (((*l_331) = p_77) | l_228))), 14)), g_213)) != g_81))) , p_77)) > 0x2FD0L) == 0x3DL) >= (-1L)), (*l_300))))) && p_77) == 1UL) > p_77), 7)) > (-1L)) , g_213) , 7UL)) > p_77), 0L)), l_332[0][0])), g_174)))
                    { /* block id: 96 */
                        uint16_t l_333 = 0xF90DL;
                        uint8_t *l_339 = &l_230.f0;
                        int8_t *l_348 = &l_182;
                        int64_t *l_349 = &g_350;
                        int32_t l_351 = (-1L);
                        l_333 ^= 0xE60F88E6L;
                        l_334 |= (g_45 | l_333);
                        l_351 = (safe_sub_func_uint64_t_u_u(18446744073709551608UL, ((*l_349) = ((*l_214) |= (l_211 == ((safe_mul_func_int16_t_s_s(((l_211 != l_339) <= (safe_add_func_uint64_t_u_u((safe_mod_func_int16_t_s_s((safe_rshift_func_int8_t_s_u(((*l_348) = ((*l_211) = (safe_rshift_func_uint16_t_u_s(0x99DAL, 15)))), p_77)), ((*l_172) = l_150))), 0xD0B17583D3E0E9D6LL))), g_298)) , l_211))))));
                        l_145 = 0xCAED8014L;
                    }
                    else
                    { /* block id: 106 */
                        uint64_t l_358 = 18446744073709551615UL;
                        int32_t l_365 = 3L;
                        l_105.f2 = ((safe_sub_func_uint32_t_u_u((((safe_div_func_int32_t_s_s((l_361 = ((((*l_176) = ((((safe_mod_func_uint64_t_u_u(0x03E406031C6C41B1LL, (((*l_211) = p_77) || ((((l_358 < ((void*)0 != &l_182)) & ((l_144 = ((safe_mul_func_uint8_t_u_u(0x5AL, g_298)) != (p_77 > (*l_300)))) , g_200)) == l_299) , p_77)))) ^ g_3) , (*p_76)) != &g_259[5][4])) & 1L) || p_77)), p_77)) >= l_137) && l_332[0][0]), g_259[5][4])) ^ 0x2CL);
                        l_365 |= ((safe_lshift_func_int8_t_s_u((~l_142), g_212)) < l_142);
                        l_105.f2 |= l_152[4][4][4];
                        if (l_229)
                            goto lbl_366;
                    }
                }
            }
            else
            { /* block id: 117 */
                int32_t **l_370 = &g_16[4];
                uint8_t **l_391 = &g_82;
                int16_t *l_410 = &g_174;
                l_146 ^= ((safe_rshift_func_uint8_t_u_u(((l_151 = g_3) , ((!((void*)0 == l_370)) , (((safe_mod_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_u(((((safe_rshift_func_uint16_t_u_s((*l_300), (&g_213 != (((*p_78) = 0x22C2ECCDL) , l_377[0][0])))) | p_77) != 0UL) > p_77), p_77)) <= 1L), p_77)) & 0xE044CEBC7E217CBELL) == 6L))), 7)) ^ p_77);
                g_378 = &p_78;
                for (l_361 = 0; (l_361 <= 4); l_361 += 1)
                { /* block id: 124 */
                    int32_t l_395 = 0x363E014BL;
                    int32_t l_396 = 0xE153D726L;
                    for (l_229 = 2; (l_229 >= 0); l_229 -= 1)
                    { /* block id: 127 */
                        int i, j;
                        return l_377[l_229][(l_361 + 2)];
                    }
                    l_153 ^= (*l_300);
                    l_396 &= ((((void*)0 != l_380) != (safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((((safe_rshift_func_int8_t_s_u(((l_152[4][7][2] |= (p_77 & ((l_142 , ((l_391 = &g_82) != &g_82)) <= (safe_mod_func_uint32_t_u_u(g_174, p_77))))) ^ (((((p_77 <= g_298) & l_394) , 0x494BL) | p_77) == l_395)), p_77)) >= 0x04E5D9F7L) , p_77), l_395)), p_77)), 0xC2L))) , l_395);
                    for (l_135 = 1; (l_135 <= 4); l_135 += 1)
                    { /* block id: 136 */
                        uint64_t *l_399 = &g_200;
                        uint64_t *l_406 = &g_407;
                        int i, j, k;
                        l_92 |= ((safe_add_func_uint8_t_u_u((((*l_399) = 0xB1F5828B9E66737BLL) < (((*l_172) &= l_152[(l_361 + 1)][g_3][l_361]) >= (+(l_152[(l_361 + 1)][(l_135 + 2)][l_361] <= ((*l_406) |= (+(((l_152[(l_361 + 1)][g_3][l_361] >= (0x6022L ^ (((safe_mul_func_uint8_t_u_u((l_396 = (*l_300)), (((((safe_div_func_int16_t_s_s(0x71F3L, p_77)) | (g_298 , 9L)) && 0UL) | 65526UL) ^ p_77))) < g_3) < g_5[8]))) ^ g_259[0][0]) , p_77))))))), p_77)) < g_42);
                    }
                }
                if ((l_408 | (&g_212 == (g_409 = &g_212))))
                { /* block id: 145 */
                    l_145 |= (l_260[3][2][0] != (p_77 , &l_408));
                }
                else
                { /* block id: 147 */
                    l_144 |= ((l_321 != l_410) != 0xF46DL);
                }
            }
        }
        else
        { /* block id: 151 */
            uint32_t * const *l_422 = &g_379;
            uint32_t * const **l_423 = (void*)0;
            uint32_t * const **l_424[7] = {&l_422,&l_422,&l_422,&l_422,&l_422,&l_422,&l_422};
            int32_t l_432 = 0x44EE5FFFL;
            int i;
            l_135 = (safe_sub_func_int32_t_s_s((~p_77), ((((((((safe_rshift_func_int8_t_s_u((((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_s((0x6EL && ((*g_409) = (safe_add_func_int64_t_s_s(((g_425[0][3][0] = l_422) != &g_426), ((safe_rshift_func_int16_t_s_s((g_259[2][1] , (g_192[5] , 0x7F47L)), p_77)) > ((safe_lshift_func_int8_t_s_u(((&p_77 == &g_174) != l_432), p_77)) & (*g_409))))))), l_433)) , l_432), 12)) && p_77) < 0x7AL), p_77)) != p_77) ^ 0x8621L) != p_77) , p_77) <= g_298) & p_77) <= l_332[0][1])));
            return &g_350;
        }
        (*g_447) |= (safe_rshift_func_int8_t_s_u(((((((g_174 != 0x4E17L) || (safe_unary_minus_func_uint16_t_u(((!(safe_add_func_int8_t_s_s(0x71L, 0x4DL))) & ((safe_mod_func_int8_t_s_s(p_77, 0x77L)) | (((safe_lshift_func_int8_t_s_u(((*g_409) = (l_444 == (((p_77 , (+g_259[5][4])) ^ g_3) , l_444))), 5)) != (-4L)) | 7UL)))))) && 4294967295UL) | l_152[4][7][2]) <= l_446) && l_135), 7));
        for (l_408 = 8; (l_408 == 30); l_408 = safe_add_func_uint64_t_u_u(l_408, 7))
        { /* block id: 161 */
            return &g_42;
        }
        if (p_77)
            goto lbl_366;
    }
    l_464[8] |= ((g_298 != (safe_lshift_func_uint8_t_u_s((18446744073709551614UL || (((safe_mul_func_uint16_t_u_u((((p_77 >= (safe_lshift_func_uint16_t_u_s(g_42, (p_77 ^ (safe_add_func_int64_t_s_s(g_173, ((65526UL != ((((((*l_459) = &g_173) != &g_173) > p_77) | g_45) , p_77)) , 0x57D41B5A750DB596LL))))))) < 1UL) , p_77), 0L)) | l_461[9][0]) != 0x9FA3L)), 0))) && g_212);
    return &g_350;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_174, "g_174", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_192[i].f0, "g_192[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_259[i][j], "g_259[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_298, "g_298", print_hash_value);
    transparent_crc(g_350, "g_350", print_hash_value);
    transparent_crc(g_407, "g_407", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_427[i][j], "g_427[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_448, "g_448", print_hash_value);
    transparent_crc(g_482, "g_482", print_hash_value);
    transparent_crc(g_502, "g_502", print_hash_value);
    transparent_crc(g_516, "g_516", print_hash_value);
    transparent_crc(g_526, "g_526", print_hash_value);
    transparent_crc(g_544, "g_544", print_hash_value);
    transparent_crc(g_841, "g_841", print_hash_value);
    transparent_crc(g_896, "g_896", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_967[i], "g_967[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_978, "g_978", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1060[i], "g_1060[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1092, "g_1092", print_hash_value);
    transparent_crc(g_1094, "g_1094", print_hash_value);
    transparent_crc(g_1095, "g_1095", print_hash_value);
    transparent_crc(g_1228, "g_1228", print_hash_value);
    transparent_crc(g_1279, "g_1279", print_hash_value);
    transparent_crc(g_1291, "g_1291", print_hash_value);
    transparent_crc(g_1321, "g_1321", print_hash_value);
    transparent_crc(g_1326, "g_1326", print_hash_value);
    transparent_crc(g_1384, "g_1384", print_hash_value);
    transparent_crc(g_1454, "g_1454", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1572[i], "g_1572[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1620, "g_1620", print_hash_value);
    transparent_crc(g_1634.f0, "g_1634.f0", print_hash_value);
    transparent_crc(g_1672, "g_1672", print_hash_value);
    transparent_crc(g_1965.f0, "g_1965.f0", print_hash_value);
    transparent_crc(g_2036, "g_2036", print_hash_value);
    transparent_crc(g_2086, "g_2086", print_hash_value);
    transparent_crc(g_2389, "g_2389", print_hash_value);
    transparent_crc(g_2466, "g_2466", print_hash_value);
    transparent_crc(g_2491, "g_2491", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 617
XXX total union variables: 24

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 36
breakdown:
   indirect level: 0, occurrence: 24
   indirect level: 1, occurrence: 8
   indirect level: 2, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 18
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 42
XXX times a single bitfield on LHS: 14
XXX times a single bitfield on RHS: 14

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 178
   depth: 2, occurrence: 49
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 3
   depth: 21, occurrence: 4
   depth: 23, occurrence: 3
   depth: 24, occurrence: 3
   depth: 25, occurrence: 4
   depth: 26, occurrence: 2
   depth: 27, occurrence: 3
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 33, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 40, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 560

XXX times a variable address is taken: 1321
XXX times a pointer is dereferenced on RHS: 321
breakdown:
   depth: 1, occurrence: 278
   depth: 2, occurrence: 25
   depth: 3, occurrence: 15
   depth: 4, occurrence: 3
XXX times a pointer is dereferenced on LHS: 360
breakdown:
   depth: 1, occurrence: 347
   depth: 2, occurrence: 12
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 59
XXX times a pointer is compared with address of another variable: 8
XXX times a pointer is compared with another pointer: 11
XXX times a pointer is qualified to be dereferenced: 8159

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1219
   level: 2, occurrence: 330
   level: 3, occurrence: 147
   level: 4, occurrence: 22
   level: 5, occurrence: 13
XXX number of pointers point to pointers: 246
XXX number of pointers point to scalars: 304
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.4
XXX average alias set size: 1.38

XXX times a non-volatile is read: 2033
XXX times a non-volatile is write: 1009
XXX times a volatile is read: 114
XXX    times read thru a pointer: 52
XXX times a volatile is write: 31
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.45e+03
XXX percentage of non-volatile access: 95.5

XXX forward jumps: 0
XXX backward jumps: 13

XXX stmts: 190
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 38
   depth: 2, occurrence: 41
   depth: 3, occurrence: 31
   depth: 4, occurrence: 24
   depth: 5, occurrence: 27

XXX percentage a fresh-made variable is used: 15.3
XXX percentage an existing variable is used: 84.7
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

