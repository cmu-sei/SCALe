/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1179670702
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   signed f1 : 2;
   volatile uint32_t  f2;
   int8_t  f3;
   volatile uint64_t  f4;
   volatile uint32_t  f5;
   const volatile uint32_t  f6;
   uint64_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static const int32_t g_6 = 1L;
static int32_t g_14 = 9L;
static uint16_t g_19 = 65535UL;
static uint64_t g_20[5] = {0x2C39D5B611FB8EB5LL,0x2C39D5B611FB8EB5LL,0x2C39D5B611FB8EB5LL,0x2C39D5B611FB8EB5LL,0x2C39D5B611FB8EB5LL};
static const struct S0 g_21 = {4294967289UL,-0,0xB88CDF8AL,0xFFL,18446744073709551614UL,9UL,0xA12A2EF7L,18446744073709551611UL};/* VOLATILE GLOBAL g_21 */
static volatile uint32_t g_28 = 0x89BB643CL;/* VOLATILE GLOBAL g_28 */
static uint32_t g_44 = 0xF497C316L;
static uint32_t g_50 = 0x7DCAF6DDL;
static int32_t *g_53 = &g_14;
static int32_t **g_52 = &g_53;
static const int32_t *g_90 = &g_14;
static const int32_t **g_89 = &g_90;
static int64_t g_133 = 1L;
static int8_t g_135 = 0x6AL;
static int32_t g_137[9] = {6L,0x3F1C1567L,0x3F1C1567L,6L,0x3F1C1567L,0x3F1C1567L,6L,0x3F1C1567L,0x3F1C1567L};
static int16_t g_145[9][9] = {{0L,0x39F9L,0L,0xEAE7L,0xCDB4L,(-9L),(-1L),0xB59CL,(-1L)},{(-5L),8L,0x8A75L,0x6A15L,0xC247L,(-8L),(-1L),(-5L),0xCDB4L},{0x264BL,0xB59CL,0xCDB4L,(-8L),8L,0xF466L,0L,0L,0xF466L},{(-9L),0xB59CL,0L,0xB59CL,(-9L),0L,0x8A75L,1L,0x264BL},{(-8L),6L,0L,(-1L),(-1L),(-5L),0x99B5L,0L,0x2485L},{0xC247L,0x6A15L,0x8A75L,8L,(-5L),0L,0x6A15L,(-3L),0L},{(-1L),9L,0L,0x8A75L,0x2420L,(-1L),(-1L),(-1L),0x2420L},{(-1L),(-8L),(-8L),(-1L),6L,(-9L),(-3L),0x264BL,8L},{0xC247L,(-3L),8L,0x2420L,0xB59CL,1L,(-5L),0x2485L,(-3L)}};
static const int64_t g_148 = 0xAFD11974AA1647F7LL;
static int32_t g_160 = 1L;
static int32_t g_178 = (-8L);
static uint8_t g_210 = 0UL;
static uint8_t g_212 = 0x91L;
static int16_t g_256 = 0x432BL;
static uint32_t g_260 = 0UL;
static struct S0 g_277 = {0x0CCF4FE8L,0,0x4B74A621L,0x0DL,18446744073709551615UL,0x8E02149DL,4294967292UL,0xADC728AAC3256DE8LL};/* VOLATILE GLOBAL g_277 */
static int64_t g_282 = (-1L);
static const int8_t g_325 = 0L;
static int16_t *g_464 = &g_145[5][0];
static int16_t **g_463 = &g_464;
static int16_t *** volatile g_462 = &g_463;/* VOLATILE GLOBAL g_462 */
static volatile struct S0 g_481[1][5] = {{{4294967295UL,-1,0x73A1B7DAL,0x29L,0x54BD8BC8AD2DD164LL,3UL,0x4B5A26D3L,0x025D52D19F02E2CDLL},{4294967295UL,-1,0x73A1B7DAL,0x29L,0x54BD8BC8AD2DD164LL,3UL,0x4B5A26D3L,0x025D52D19F02E2CDLL},{4294967295UL,-1,0x73A1B7DAL,0x29L,0x54BD8BC8AD2DD164LL,3UL,0x4B5A26D3L,0x025D52D19F02E2CDLL},{4294967295UL,-1,0x73A1B7DAL,0x29L,0x54BD8BC8AD2DD164LL,3UL,0x4B5A26D3L,0x025D52D19F02E2CDLL},{4294967295UL,-1,0x73A1B7DAL,0x29L,0x54BD8BC8AD2DD164LL,3UL,0x4B5A26D3L,0x025D52D19F02E2CDLL}}};
static int8_t *g_491 = &g_135;
static uint64_t g_500 = 5UL;
static struct S0 g_511 = {0x5A17CD30L,-0,0x86E46DA1L,0x28L,0x4B35270933C2CC47LL,18446744073709551614UL,4294967295UL,0x2B87971FD9DE76C6LL};/* VOLATILE GLOBAL g_511 */
static volatile int32_t g_530[1] = {1L};
static struct S0 g_531 = {0x50BFF2D5L,0,18446744073709551609UL,0x87L,0x32F3E8637718B7A5LL,0x5539CD97L,5UL,0x69CC3C140D3B7B00LL};/* VOLATILE GLOBAL g_531 */
static int8_t * volatile *g_591[9][1] = {{&g_491},{&g_491},{&g_491},{&g_491},{&g_491},{&g_491},{&g_491},{&g_491},{&g_491}};
static int8_t * volatile **g_590 = &g_591[8][0];
static const volatile int8_t * volatile *g_593 = (void*)0;
static const volatile int8_t * volatile **g_592 = &g_593;
static volatile struct S0 g_594 = {0xDBB3CD7EL,1,0UL,1L,0x6FE245E5F3EE395BLL,7UL,0x13E0CE4FL,1UL};/* VOLATILE GLOBAL g_594 */
static const int32_t g_650 = 6L;
static uint8_t *g_670 = &g_210;
static int32_t g_711 = (-1L);
static uint32_t *g_717 = &g_50;
static uint32_t **g_716 = &g_717;
static int32_t *g_752 = &g_178;
static int32_t **g_751 = &g_752;
static int32_t g_763 = 1L;
static int8_t g_800[5] = {0x69L,0x69L,0x69L,0x69L,0x69L};
static int8_t g_801 = 0x52L;
static int8_t g_802 = (-5L);
static int8_t g_803 = 0x78L;
static int8_t g_804 = 0x10L;
static int8_t g_805 = (-2L);
static int8_t g_806 = 1L;
static int8_t g_807[2] = {1L,1L};
static int8_t g_808[1] = {3L};
static int8_t g_809 = 0xCAL;
static int8_t g_810 = 9L;
static int8_t g_811 = 2L;
static int8_t g_812[1][10][10] = {{{(-1L),(-2L),(-6L),0x0DL,(-1L),0L,(-1L),0x0BL,0x03L,0x70L},{(-1L),0x98L,0x5AL,(-2L),(-1L),(-8L),0x49L,(-3L),0L,0x64L},{(-1L),(-1L),0x71L,0x5FL,1L,0x5AL,(-1L),1L,(-6L),3L},{(-1L),4L,(-1L),0L,0x76L,0xA3L,0x76L,0L,(-1L),4L},{0L,0x03L,0x45L,(-6L),0x5CL,0xD7L,0x71L,1L,0x0DL,0x15L},{0x49L,0xA3L,(-3L),0x7FL,0L,0xD7L,0x47L,0x64L,(-1L),(-2L)},{0L,0x5FL,0x76L,0x64L,3L,0xA3L,0xF3L,0xD7L,0x70L,(-3L)},{(-1L),(-6L),(-6L),0x76L,0x15L,0x5AL,0x5AL,0x15L,0x76L,(-6L)},{(-1L),(-1L),0xF3L,(-1L),0xA3L,(-8L),1L,0x49L,0x47L,0x5FL},{(-1L),1L,4L,0x47L,0x0DL,0L,1L,0x03L,0xD7L,(-8L)}}};
static int8_t g_813 = 0x57L;
static int8_t * const g_799[9][5] = {{&g_810,(void*)0,&g_800[0],&g_800[0],(void*)0},{&g_813,&g_801,&g_806,&g_801,&g_813},{(void*)0,&g_800[0],&g_800[0],(void*)0,&g_810},{&g_809,&g_801,&g_809,&g_807[1],&g_809},{(void*)0,(void*)0,(void*)0,&g_800[0],&g_810},{&g_813,&g_807[1],&g_806,&g_807[1],&g_813},{&g_810,&g_800[0],(void*)0,(void*)0,(void*)0},{&g_809,&g_807[1],&g_809,&g_801,&g_809},{&g_810,(void*)0,&g_800[0],&g_800[0],(void*)0}};
static int8_t * const *g_798 = &g_799[8][4];
static int8_t g_816 = 0xF2L;
static int8_t * const g_815 = &g_816;
static int8_t * const *g_814 = &g_815;
static uint8_t g_851 = 8UL;
static volatile struct S0 g_853 = {6UL,0,2UL,0x58L,0xAF21D297130CAF79LL,0xE9D6218CL,0xC61B9603L,18446744073709551606UL};/* VOLATILE GLOBAL g_853 */
static volatile int16_t g_873 = 6L;/* VOLATILE GLOBAL g_873 */
static uint32_t g_976 = 0x3EA1EBA4L;
static uint32_t g_1016 = 0xD7987C16L;
static const struct S0 g_1083 = {0xF8D0961BL,0,0x445E7548L,-2L,7UL,0x43CECBCAL,0xE9D0569BL,0xD8C8D16C274A0B2BLL};/* VOLATILE GLOBAL g_1083 */
static const struct S0 g_1084[9][3] = {{{1UL,1,0x85AD01E2L,0x94L,18446744073709551615UL,0xBCB4251AL,4294967295UL,0x312A0A8AC817A2FDLL},{0UL,-1,1UL,0x8FL,0UL,18446744073709551609UL,0UL,0x3244B238862432D2LL},{1UL,-1,0x6C8F0D7FL,1L,0x7F2ACC8C7BCC4CB9LL,18446744073709551608UL,0xE8C417D2L,18446744073709551611UL}},{{0xAEC335EFL,-1,0x3B371E79L,9L,0x66CB04D3CE248E39LL,1UL,0x838CB7B0L,0x1D6B317C07C88EEDLL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL}},{{1UL,1,0x85AD01E2L,0x94L,18446744073709551615UL,0xBCB4251AL,4294967295UL,0x312A0A8AC817A2FDLL},{0UL,-1,1UL,0x8FL,0UL,18446744073709551609UL,0UL,0x3244B238862432D2LL},{1UL,-1,0x6C8F0D7FL,1L,0x7F2ACC8C7BCC4CB9LL,18446744073709551608UL,0xE8C417D2L,18446744073709551611UL}},{{0xAEC335EFL,-1,0x3B371E79L,9L,0x66CB04D3CE248E39LL,1UL,0x838CB7B0L,0x1D6B317C07C88EEDLL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL}},{{1UL,1,0x85AD01E2L,0x94L,18446744073709551615UL,0xBCB4251AL,4294967295UL,0x312A0A8AC817A2FDLL},{0UL,-1,1UL,0x8FL,0UL,18446744073709551609UL,0UL,0x3244B238862432D2LL},{1UL,-1,0x6C8F0D7FL,1L,0x7F2ACC8C7BCC4CB9LL,18446744073709551608UL,0xE8C417D2L,18446744073709551611UL}},{{0xAEC335EFL,-1,0x3B371E79L,9L,0x66CB04D3CE248E39LL,1UL,0x838CB7B0L,0x1D6B317C07C88EEDLL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL}},{{1UL,1,0x85AD01E2L,0x94L,18446744073709551615UL,0xBCB4251AL,4294967295UL,0x312A0A8AC817A2FDLL},{0UL,-1,1UL,0x8FL,0UL,18446744073709551609UL,0UL,0x3244B238862432D2LL},{1UL,-1,0x6C8F0D7FL,1L,0x7F2ACC8C7BCC4CB9LL,18446744073709551608UL,0xE8C417D2L,18446744073709551611UL}},{{0xAEC335EFL,-1,0x3B371E79L,9L,0x66CB04D3CE248E39LL,1UL,0x838CB7B0L,0x1D6B317C07C88EEDLL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL},{8UL,1,0UL,6L,0xC2511D50C94C204ELL,0UL,8UL,0x8BA0D1249A19B194LL}},{{1UL,1,0x85AD01E2L,0x94L,18446744073709551615UL,0xBCB4251AL,4294967295UL,0x312A0A8AC817A2FDLL},{0UL,-1,1UL,0x8FL,0UL,18446744073709551609UL,0UL,0x3244B238862432D2LL},{1UL,-1,0x6C8F0D7FL,1L,0x7F2ACC8C7BCC4CB9LL,18446744073709551608UL,0xE8C417D2L,18446744073709551611UL}}};
static int32_t * volatile g_1090 = (void*)0;/* VOLATILE GLOBAL g_1090 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_4(const uint32_t  p_5);
static const struct S0  func_10(uint8_t  p_11, uint32_t  p_12);
static int32_t ** func_24(uint32_t  p_25, int16_t  p_26);
static struct S0  func_54(int8_t  p_55, int16_t  p_56, int8_t  p_57, uint32_t  p_58);
static const uint32_t  func_68(int32_t ** p_69, int32_t ** p_70, int8_t  p_71);
static int32_t ** func_72(int32_t * p_73, uint32_t * p_74, int32_t ** p_75, uint8_t  p_76, int8_t  p_77);
static int32_t * func_78(int8_t  p_79, uint32_t  p_80, int32_t  p_81, int8_t  p_82);
static int64_t  func_85(const int32_t ** p_86, uint8_t  p_87, int32_t  p_88);
static uint8_t  func_92(int32_t  p_93, int16_t  p_94, int32_t  p_95, uint64_t  p_96);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_14 g_19 g_21 g_28 g_20 g_52 g_44 g_89 g_90 g_53 g_50 g_137 g_148 g_133 g_145 g_178 g_135 g_212 g_277 g_325 g_210 g_462 g_282 g_481 g_463 g_464 g_160 g_500 g_256 g_511 g_530 g_531 g_260 g_594.f1 g_650 g_716 g_717 g_594.f7 g_751 g_763 g_670 g_853 g_873 g_815 g_816 g_800 g_802 g_810 g_976 g_801 g_1016 g_711 g_851 g_594.f0 g_1083 g_1084
 * writes: g_14 g_19 g_28 g_44 g_133 g_135 g_137 g_50 g_145 g_160 g_20 g_178 g_210 g_212 g_90 g_53 g_282 g_277.f0 g_463 g_491 g_500 g_511.f0 g_531.f3 g_531.f1 g_256 g_511.f1 g_531.f7 g_670 g_277.f1 g_531.f0 g_716 g_751 g_511.f3 g_798 g_814 g_260 g_976 g_801 g_763 g_853.f1 g_711
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_1085 = (-4L);
    int32_t *l_1091[2];
    int i;
    for (i = 0; i < 2; i++)
        l_1091[i] = &g_137[0];
    g_711 = ((((((safe_lshift_func_int8_t_s_s(func_4(g_6), (safe_mod_func_int16_t_s_s((func_10(g_6, (g_6 <= 0xFEL)) , (l_1085 , (safe_mod_func_uint64_t_u_u((8L < (safe_add_func_int32_t_s_s(((void*)0 == &g_282), l_1085))), l_1085)))), g_802)))) | l_1085) ^ (-10L)) | l_1085) && 0x45FAL) == g_21.f3);
    return (**g_716);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_4(const uint32_t  p_5)
{ /* block id: 1 */
    uint32_t l_7 = 1UL;
    return l_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_19 g_21 g_28 g_20 g_6 g_52 g_44 g_89 g_90 g_53 g_50 g_137 g_148 g_133 g_178 g_145 g_135 g_212 g_277 g_325 g_210 g_462 g_282 g_481 g_463 g_464 g_160 g_500 g_256 g_511 g_530 g_531 g_260 g_594.f1 g_650 g_716 g_717 g_594.f7 g_751 g_763 g_670 g_853 g_873 g_815 g_816 g_800 g_802 g_810 g_976 g_801 g_1016 g_711 g_851 g_594.f0 g_1083 g_1084
 * writes: g_14 g_19 g_28 g_44 g_133 g_135 g_137 g_50 g_145 g_160 g_20 g_178 g_210 g_212 g_90 g_53 g_282 g_277.f0 g_463 g_491 g_500 g_511.f0 g_531.f3 g_531.f1 g_256 g_511.f1 g_531.f7 g_670 g_277.f1 g_531.f0 g_716 g_751 g_511.f3 g_798 g_814 g_260 g_976 g_801 g_763 g_853.f1
 */
static const struct S0  func_10(uint8_t  p_11, uint32_t  p_12)
{ /* block id: 3 */
    int32_t *l_13 = &g_14;
    int32_t **l_1081 = &l_13;
    (*l_13) = (-1L);
    for (p_11 = 29; (p_11 > 15); p_11--)
    { /* block id: 7 */
        int32_t **l_17 = (void*)0;
        int32_t **l_18 = &l_13;
        (*l_18) = (void*)0;
        g_19 &= g_14;
        for (g_14 = 4; (g_14 >= 0); g_14 -= 1)
        { /* block id: 12 */
            return g_21;
        }
    }
    for (p_12 = 6; (p_12 <= 19); p_12 = safe_add_func_int32_t_s_s(p_12, 4))
    { /* block id: 18 */
        volatile int32_t l_1082[10][8] = {{1L,0L,(-6L),0x8A58E1A1L,0L,0L,0x8A58E1A1L,(-6L)},{1L,1L,(-1L),0x8A58E1A1L,1L,(-2L),0x8A58E1A1L,0x8A58E1A1L},{0L,1L,(-6L),(-6L),1L,0L,(-6L),0x8A58E1A1L},{1L,0L,(-6L),0x8A58E1A1L,0L,0L,0x8A58E1A1L,(-6L)},{1L,1L,(-1L),0x8A58E1A1L,1L,(-2L),0x8A58E1A1L,0x8A58E1A1L},{0L,1L,(-6L),(-6L),1L,0L,(-6L),0x8A58E1A1L},{1L,0L,(-6L),0x8A58E1A1L,0L,0L,0x8A58E1A1L,(-6L)},{1L,1L,(-1L),0x8A58E1A1L,1L,(-2L),0x8A58E1A1L,0x8A58E1A1L},{0L,1L,(-6L),(-6L),1L,0L,(-6L),0x8A58E1A1L},{1L,0L,(-6L),0x8A58E1A1L,0L,0L,0x8A58E1A1L,(-6L)}};
        int i, j;
        l_1081 = func_24(g_21.f6, p_11);
        l_1082[0][1] = g_530[0];
        return g_1083;
    }
    return g_1084[3][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_14 g_21.f7 g_21.f4 g_20 g_6 g_52 g_44 g_21.f1 g_89 g_90 g_53 g_50 g_21.f0 g_21.f5 g_19 g_137 g_148 g_21.f3 g_133 g_178 g_145 g_135 g_212 g_277 g_325 g_210 g_462 g_282 g_481 g_463 g_464 g_160 g_500 g_256 g_511 g_530 g_531 g_260 g_21.f2 g_594.f1 g_650 g_716 g_717 g_594.f7 g_751 g_763 g_670 g_853 g_873 g_815 g_816 g_800 g_802 g_810 g_976 g_801 g_1016 g_711 g_851 g_594.f0
 * writes: g_28 g_44 g_14 g_133 g_135 g_137 g_50 g_145 g_160 g_20 g_178 g_210 g_212 g_90 g_53 g_19 g_282 g_277.f0 g_463 g_491 g_500 g_511.f0 g_531.f3 g_531.f1 g_256 g_511.f1 g_531.f7 g_670 g_277.f1 g_531.f0 g_716 g_751 g_511.f3 g_798 g_814 g_260 g_976 g_801 g_763 g_853.f1
 */
static int32_t ** func_24(uint32_t  p_25, int16_t  p_26)
{ /* block id: 19 */
    int32_t *l_27[7] = {&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14};
    uint32_t *l_43 = &g_44;
    uint32_t *l_49[8][6] = {{&g_50,&g_50,&g_50,&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50,&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50,&g_50,&g_50,(void*)0},{&g_50,&g_50,&g_50,&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50,&g_50,(void*)0,(void*)0},{&g_50,&g_50,&g_50,&g_50,&g_50,&g_50},{&g_50,&g_50,&g_50,&g_50,&g_50,&g_50},{&g_50,(void*)0,&g_50,&g_50,&g_50,(void*)0}};
    uint32_t *l_241 = &g_44;
    uint8_t *l_613 = &g_212;
    const uint16_t *l_619 = (void*)0;
    int8_t l_706 = 0x26L;
    int64_t l_734 = 0x7C4A543C1C8FEF53LL;
    uint64_t l_745 = 0xC477801B36EE8FBELL;
    int8_t * const *l_796 = &g_491;
    int32_t l_834 = 0x069037FBL;
    int16_t l_900 = 0x1BDAL;
    uint32_t * const *l_919 = &l_49[6][2];
    uint32_t * const **l_918 = &l_919;
    int32_t ** const *l_929 = (void*)0;
    int64_t l_954[9] = {(-1L),0x729C32692198C3A6LL,0x39324BAAEE52EDAFLL,0x729C32692198C3A6LL,0x39324BAAEE52EDAFLL,0x39324BAAEE52EDAFLL,0x729C32692198C3A6LL,0x39324BAAEE52EDAFLL,0x39324BAAEE52EDAFLL};
    uint8_t l_956 = 254UL;
    int16_t l_967 = (-10L);
    int64_t l_971 = (-1L);
    int32_t ***l_1015 = (void*)0;
    uint32_t l_1076 = 1UL;
    int32_t **l_1080 = (void*)0;
    int i, j;
    g_28--;
    if (((((safe_sub_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u(((*l_43) = (safe_add_func_uint8_t_u_u((7L ^ (safe_sub_func_int8_t_s_s(g_14, (safe_lshift_func_int8_t_s_s(g_21.f7, 0))))), (safe_rshift_func_int8_t_s_s(func_4(g_21.f4), 3))))), (safe_rshift_func_uint8_t_u_u(((-7L) <= (safe_sub_func_int32_t_s_s(p_25, ((l_27[4] == (l_49[7][1] = l_43)) <= 252UL)))), 4)))) & p_26), g_20[1])) >= g_6) != g_20[1]) | 0xA0L))
    { /* block id: 23 */
        int32_t **l_51 = &l_27[5];
        return g_52;
    }
    else
    { /* block id: 25 */
        int16_t l_63[8][8] = {{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)}};
        int64_t l_91 = (-10L);
        int32_t l_267[6][3][8] = {{{(-6L),(-1L),(-6L),0x48EA2435L,1L,1L,0xF14A6420L,(-6L)},{0xE908A047L,(-5L),0x054FCF9FL,1L,(-1L),0x0A228F55L,1L,0x075D6D8AL},{0xE908A047L,0x5C362547L,0x48EA2435L,0x054FCF9FL,1L,0L,0x5C362547L,(-5L)}},{{(-6L),1L,(-5L),0x7C293D81L,(-1L),0x0628882CL,0x56730D74L,0x56730D74L},{1L,0xD0A5A646L,6L,6L,0xD0A5A646L,1L,1L,0x905F6503L},{0x7C293D81L,(-1L),1L,1L,1L,0x95644861L,0xF14A6420L,0x7C293D81L}},{{0L,0x56730D74L,0xB8E159C8L,1L,0xE908A047L,0x0A228F55L,(-5L),0x905F6503L},{0x5C362547L,0xE908A047L,0x56730D74L,6L,1L,0x4315AF73L,0L,0x56730D74L},{1L,(-5L),1L,0x7C293D81L,0x71C5D8BFL,0x7C293D81L,1L,(-5L)}},{{(-5L),(-10L),6L,0x054FCF9FL,1L,0x48EA2435L,(-10L),0x075D6D8AL},{(-6L),(-1L),1L,1L,(-5L),0x0628882CL,(-10L),(-6L)},{0L,1L,6L,0x48EA2435L,0x0A228F55L,0L,1L,0x905F6503L}},{{0x0A228F55L,0L,1L,0x905F6503L,1L,0L,0L,1L},{0x0628882CL,0x56730D74L,0x56730D74L,0x0628882CL,(-1L),0x7C293D81L,(-5L),1L},{0x56730D74L,(-1L),0xB8E159C8L,6L,1L,1L,0xF14A6420L,0xB8E159C8L}},{{0x94A6969CL,(-1L),0x075D6D8AL,0x95644861L,0x0628882CL,6L,0xE908A047L,0x94A6969CL},{0L,0x7C293D81L,1L,1L,(-5L),1L,0x7C293D81L,0x71C5D8BFL},{1L,0x56730D74L,(-1L),0xF14A6420L,(-1L),0x56730D74L,1L,0x7C293D81L}}};
        int8_t *l_497 = (void*)0;
        int32_t l_498 = 0xDE794EC2L;
        int32_t l_499 = 0xF9C7286FL;
        int8_t *l_501 = &g_135;
        int32_t l_549 = 0x481E56AAL;
        int16_t l_558 = 0xD00EL;
        uint32_t *l_608 = &g_260;
        int32_t ***l_651 = &g_52;
        int32_t l_693 = 0xBF2BD1D3L;
        int32_t l_697 = 0x60575F4BL;
        int32_t l_698 = 0x10DE509EL;
        int32_t l_699 = 1L;
        int32_t l_700 = 0L;
        int32_t l_701 = 2L;
        int32_t l_703 = 0xB401F782L;
        int32_t l_704 = 1L;
        int32_t l_705 = (-10L);
        int32_t l_707 = (-1L);
        int32_t l_708 = 1L;
        int32_t l_709 = (-1L);
        int32_t l_710 = 0xA4A7804BL;
        uint32_t l_713 = 4294967286UL;
        int32_t **l_756 = &g_752;
        int8_t l_789 = (-1L);
        uint16_t l_879 = 65528UL;
        const uint8_t l_893 = 0x61L;
        uint8_t l_909 = 0xABL;
        int8_t l_923[1][2];
        int8_t **l_960 = &l_497;
        int8_t ***l_959 = &l_960;
        int16_t l_966[4][1];
        int32_t l_972[3][9] = {{0xC309945AL,0x58741E55L,0xC309945AL,0xC309945AL,0x58741E55L,0xC309945AL,0xC309945AL,0x58741E55L,0xC309945AL},{0xBAC832E9L,0x018A55F3L,0xBAC832E9L,(-2L),1L,(-2L),0xBAC832E9L,0x018A55F3L,0xBAC832E9L},{0xC309945AL,0x58741E55L,0xC309945AL,0xC309945AL,0x58741E55L,0xC309945AL,0xC309945AL,0x58741E55L,0xC309945AL}};
        uint8_t l_1038[4];
        uint32_t l_1060 = 2UL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_923[i][j] = 0xCCL;
        }
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 1; j++)
                l_966[i][j] = (-1L);
        }
        for (i = 0; i < 4; i++)
            l_1038[i] = 0UL;
        if ((65535UL || func_4((func_54(((*l_501) = (safe_rshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((p_26 = ((((g_44 ^ (l_63[0][4] != (safe_mod_func_int64_t_s_s((g_500 ^= (p_25 > (((l_499 ^= ((l_498 = (((safe_sub_func_uint32_t_u_u(func_68(func_72(func_78(g_21.f1, g_6, (safe_add_func_int32_t_s_s(((func_85(g_89, ((l_63[4][3] & g_6) && l_91), l_63[0][4]) == g_21.f1) > g_21.f7), p_25)), g_44), l_241, &g_53, l_63[0][4], p_26), &l_27[1], l_267[2][1][3]), 0xAA344341L)) ^ 6L) ^ 1UL)) & 0UL)) , &g_28) != (void*)0))), p_25)))) && p_25) > l_267[2][1][3]) || g_19)), g_256)), 5))), l_63[2][5], p_25, l_63[0][4]) , l_267[2][2][6]))))
        { /* block id: 232 */
            int64_t *l_538 = &l_91;
            int32_t l_551 = 8L;
            int32_t l_629 = (-7L);
            int32_t l_702 = 0xFCD21B4EL;
            int32_t l_712 = 0L;
            int16_t l_744 = 0x1223L;
            int32_t **l_757[2];
            int i;
            for (i = 0; i < 2; i++)
                l_757[i] = &g_752;
            for (g_511.f0 = 0; (g_511.f0 <= 2); g_511.f0 += 1)
            { /* block id: 235 */
                int64_t *l_550 = &g_282;
                uint16_t *l_552 = &g_19;
                int32_t l_553[4][2][9] = {{{0x182915D7L,0xA74A5838L,0x56B046CAL,1L,8L,0x43F6C005L,0xAFC92011L,0x18FCA682L,0x18FCA682L},{0x45240BB2L,0x91EB1F55L,1L,0x33A94483L,1L,0x91EB1F55L,0x45240BB2L,0x1594CD33L,0x27F6A156L}},{{0x43F6C005L,2L,1L,0L,0x18FCA682L,8L,0xA2C0EF01L,0xA74A5838L,0xA2C0EF01L},{1L,0xCDC1C22AL,0L,0L,0xCDC1C22AL,1L,0x27F6A156L,0x1594CD33L,0x45240BB2L}},{{0xA74A5838L,0x56B046CAL,1L,8L,0x43F6C005L,0xAFC92011L,0x18FCA682L,0x18FCA682L,0xAFC92011L},{0L,0x9A63BBF4L,0x45240BB2L,0x9A63BBF4L,0L,1L,0x27F6A156L,0x33A94483L,0xEB60026FL}},{{0xE16657ABL,0x18FCA682L,0xA74A5838L,0x438C36FFL,0x56B046CAL,2L,0xA2C0EF01L,2L,0x56B046CAL},{0x27F6A156L,0L,0L,0x27F6A156L,0x40DEBF5BL,1L,0x45240BB2L,1L,0x35D3EB12L}}};
                uint16_t *l_570[9] = {&g_19,(void*)0,&g_19,(void*)0,&g_19,(void*)0,&g_19,(void*)0,&g_19};
                int32_t **l_582 = &g_53;
                uint16_t l_643[6] = {0x39D0L,0x39D0L,0x39D0L,0x39D0L,0x39D0L,0x39D0L};
                uint8_t *l_649[2];
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_649[i] = &g_212;
                l_553[1][1][3] = (safe_rshift_func_int8_t_s_s((safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_s((l_538 != l_538), (safe_div_func_uint16_t_u_u(((*l_552) |= ((safe_mul_func_int16_t_s_s((p_26 = (g_20[(g_511.f0 + 1)] > p_25)), (safe_mod_func_int16_t_s_s(((((safe_sub_func_uint8_t_u_u((safe_sub_func_int64_t_s_s(((65535UL < l_549) > ((*l_550) |= (g_160 || ((void*)0 == l_550)))), 0x077D0EF83D0C7E44LL)), g_260)) || (*g_464)) && (-1L)) , (*g_464)), p_25)))) != l_551)), 0x30C9L)))), g_137[4])), 7));
                for (g_277.f0 = 0; (g_277.f0 <= 2); g_277.f0 += 1)
                { /* block id: 242 */
                    int16_t *l_557[5][1][9] = {{{&g_145[3][2],&g_145[1][6],&l_63[0][4],(void*)0,(void*)0,(void*)0,(void*)0,&l_63[0][4],&g_145[1][6]}},{{&l_63[6][6],&l_63[0][4],&g_145[3][2],&l_63[0][4],&g_145[4][5],(void*)0,(void*)0,&g_145[4][5],&l_63[0][4]}},{{&l_63[6][6],&g_145[4][5],&l_63[6][6],(void*)0,(void*)0,&g_145[3][2],(void*)0,(void*)0,&g_145[3][2]}},{{&g_145[3][2],&l_63[0][4],&l_63[6][6],&l_63[0][4],&g_145[3][2],&l_63[0][4],&g_145[4][5],(void*)0,(void*)0}},{{&l_63[0][4],&g_145[1][6],&g_145[3][2],(void*)0,&g_145[3][2],&g_145[1][6],&l_63[0][4],(void*)0,(void*)0}}};
                    int32_t l_571[10];
                    int32_t ** const l_581 = &g_53;
                    int i, j, k;
                    for (i = 0; i < 10; i++)
                        l_571[i] = 0xDC86955EL;
                    l_551 = p_25;
                    for (g_531.f3 = 0; (g_531.f3 >= 0); g_531.f3 -= 1)
                    { /* block id: 246 */
                        int i;
                        if (g_530[g_531.f3])
                            break;
                    }
                    g_531.f1 = (((l_558 ^= (+(safe_mul_func_uint16_t_u_u(1UL, (*g_464))))) != (safe_add_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((0x2A35AB89483BFCE7LL >= ((((safe_div_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s((+((g_21.f2 & p_26) >= (l_571[3] = (safe_mod_func_uint64_t_u_u((((*l_538) = l_499) <= 5UL), (((void*)0 == l_570[4]) & 0x46D125DBL)))))), 14)), g_137[4])) ^ p_26) <= p_26) != p_26)), 9)), p_25))) < (-1L));
                    for (g_256 = 2; (g_256 >= 0); g_256 -= 1)
                    { /* block id: 255 */
                        int i, j, k;
                        l_553[1][1][7] |= l_267[(g_256 + 2)][g_511.f0][(g_511.f0 + 1)];
                        (*g_89) = &l_551;
                    }
                    for (g_44 = 0; (g_44 <= 0); g_44 += 1)
                    { /* block id: 261 */
                        int32_t ***l_583 = &l_582;
                        int32_t **l_585 = &g_53;
                        int32_t ***l_584 = &l_585;
                        int i, j, k;
                        g_14 = (safe_unary_minus_func_int32_t_s(((safe_sub_func_uint8_t_u_u((9L <= (l_553[1][1][3] = (1UL <= (l_551 = ((safe_mod_func_int8_t_s_s(((g_530[g_44] | (safe_add_func_uint8_t_u_u((l_581 != ((*l_583) = l_582)), 0x02L))) != 0L), p_26)) >= 18446744073709551615UL))))), p_26)) <= p_26)));
                        l_553[1][1][3] &= p_25;
                    }
                }
                for (g_210 = 0; (g_210 <= 0); g_210 += 1)
                { /* block id: 273 */
                    uint8_t *l_597[9] = {&g_210,&g_212,&g_210,&g_210,&g_212,&g_210,&g_210,&g_212,(void*)0};
                    int32_t l_607 = (-1L);
                    int32_t l_609[10] = {(-1L),1L,0x467C0A7CL,0x467C0A7CL,1L,(-1L),1L,0x467C0A7CL,0x467C0A7CL,1L};
                    int i;
                    (*g_89) = (*l_582);
                    for (l_549 = 0; (l_549 >= 0); l_549 -= 1)
                    { /* block id: 279 */
                        const uint8_t *l_612 = (void*)0;
                        uint8_t **l_614[7][7][5] = {{{(void*)0,&l_613,(void*)0,&l_613,&l_613},{(void*)0,&l_613,&l_613,(void*)0,(void*)0},{&l_597[5],&l_597[3],&l_597[8],&l_613,&l_613},{&l_597[8],&l_597[8],&l_597[8],&l_597[8],&l_613},{&l_597[8],(void*)0,&l_613,&l_613,&l_597[8]},{&l_613,&l_597[8],&l_613,(void*)0,&l_613},{(void*)0,&l_597[8],&l_597[8],(void*)0,&l_613}},{{&l_613,&l_597[8],&l_613,&l_597[8],&l_597[8]},{&l_597[8],&l_597[8],&l_613,&l_613,&l_597[0]},{&l_597[8],(void*)0,&l_613,&l_597[8],&l_597[7]},{&l_613,&l_597[8],(void*)0,&l_613,&l_613},{&l_613,&l_597[3],&l_597[8],&l_597[7],&l_613},{(void*)0,&l_613,&l_597[8],(void*)0,&l_597[8]},{&l_597[8],&l_613,&l_613,&l_597[8],&l_597[8]}},{{&l_613,&l_597[0],&l_597[3],&l_597[8],&l_597[8]},{&l_597[8],(void*)0,&l_597[8],(void*)0,&l_597[8]},{(void*)0,&l_597[8],&l_613,&l_597[8],&l_597[4]},{(void*)0,&l_613,&l_597[4],&l_597[8],&l_613},{&l_613,&l_597[5],&l_597[2],&l_597[8],&l_597[4]},{&l_613,&l_597[8],&l_613,&l_597[0],&l_597[8]},{&l_597[4],&l_597[4],&l_613,&l_597[8],&l_597[8]}},{{&l_613,&l_613,(void*)0,(void*)0,&l_597[8]},{&l_613,&l_597[4],&l_597[8],&l_597[8],&l_597[8]},{&l_597[4],&l_613,&l_597[1],&l_597[8],&l_613},{&l_613,&l_613,&l_597[6],&l_597[8],&l_613},{&l_613,(void*)0,&l_597[8],&l_613,&l_597[7]},{(void*)0,&l_613,&l_597[8],&l_613,&l_597[0]},{&l_613,&l_597[4],&l_613,&l_613,&l_597[8]}},{{&l_597[4],&l_597[4],&l_613,&l_597[8],&l_613},{&l_613,&l_597[1],&l_613,(void*)0,&l_613},{(void*)0,&l_597[8],&l_613,(void*)0,&l_597[8]},{&l_597[8],&l_597[8],&l_597[8],&l_597[8],&l_613},{&l_613,&l_597[8],&l_597[8],&l_613,&l_613},{&l_597[8],&l_613,&l_597[6],(void*)0,(void*)0},{&l_597[0],&l_597[8],&l_597[1],&l_597[8],&l_613}},{{&l_597[8],&l_597[3],&l_597[8],(void*)0,&l_613},{&l_613,&l_597[3],&l_613,&l_597[8],&l_597[0]},{&l_597[8],&l_597[8],(void*)0,(void*)0,&l_597[8]},{&l_613,(void*)0,&l_597[3],&l_597[3],&l_597[8]},{&l_597[8],&l_613,&l_613,&l_597[8],&l_597[8]},{&l_597[6],&l_613,&l_597[8],&l_613,&l_597[8]},{&l_597[8],&l_597[0],&l_597[0],&l_613,&l_597[8]}},{{&l_613,&l_613,&l_597[8],&l_613,(void*)0},{&l_597[8],&l_597[4],&l_597[6],&l_597[2],&l_597[8]},{&l_613,&l_597[8],&l_597[8],&l_613,(void*)0},{(void*)0,&l_613,&l_613,&l_597[8],&l_597[3]},{&l_613,&l_613,&l_597[1],&l_597[8],&l_613},{&l_613,&l_597[7],&l_597[8],(void*)0,&l_597[8]},{&l_597[0],&l_613,&l_597[5],&l_613,&l_597[8]}}};
                        int i, j, k;
                        g_511.f1 ^= (((safe_mod_func_int16_t_s_s((g_511.f0 & l_63[0][1]), g_531.f4)) <= ((*l_552) &= (((l_612 = &g_212) != (l_613 = l_613)) || l_499))) & g_21.f3);
                    }
                    return l_582;
                }
                for (g_531.f7 = 0; (g_531.f7 <= 2); g_531.f7 += 1)
                { /* block id: 289 */
                    uint16_t **l_617 = (void*)0;
                    uint16_t **l_618[3];
                    int32_t ***l_642 = (void*)0;
                    int32_t l_652 = 0x449C7963L;
                    uint64_t l_691 = 18446744073709551609UL;
                    int32_t l_694 = 0x5BCF1028L;
                    int32_t l_695 = 0xD2030CB0L;
                    int32_t l_696[1];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_618[i] = &l_570[4];
                    for (i = 0; i < 1; i++)
                        l_696[i] = 0xEA82374DL;
                    l_629 = (((7UL || 0x380ADA9EB47D17CELL) >= ((safe_lshift_func_uint16_t_u_s(((l_570[4] = &g_19) != l_619), (safe_sub_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(((*l_538) = ((*l_550) = (safe_unary_minus_func_uint64_t_u(g_50)))), ((8L ^ (((((safe_add_func_uint8_t_u_u(((l_498 = p_25) <= p_26), p_25)) , l_629) && p_26) == 0x63L) != g_594.f1)) && (-1L)))), 5UL)))) != 0x50177AA2L)) , l_629);
                    for (l_499 = 0; (l_499 <= 0); l_499 += 1)
                    { /* block id: 297 */
                        uint32_t l_634 = 0xAEEA107BL;
                        int32_t l_639[8] = {0xB6D43730L,0xB6D43730L,0xB6D43730L,0xB6D43730L,0xB6D43730L,0xB6D43730L,0xB6D43730L,0xB6D43730L};
                        uint8_t **l_668 = &l_613;
                        uint8_t **l_669[6][5][8] = {{{&l_649[0],(void*)0,(void*)0,&l_649[0],&l_649[0],&l_649[1],&l_649[1],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0]},{(void*)0,(void*)0,&l_649[0],(void*)0,&l_649[0],&l_649[1],(void*)0,&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0]},{&l_649[0],&l_649[1],(void*)0,&l_649[1],&l_649[0],&l_649[0],&l_649[0],&l_649[0]}},{{&l_649[0],(void*)0,(void*)0,&l_649[0],&l_649[0],&l_649[1],(void*)0,&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],&l_649[0],(void*)0,(void*)0,&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],&l_649[1],&l_649[0],(void*)0,(void*)0,&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],(void*)0,&l_649[1],&l_649[0],&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],(void*)0,&l_649[0],(void*)0,&l_649[0],(void*)0,&l_649[0]}},{{&l_649[0],&l_649[0],&l_649[1],&l_649[0],&l_649[0],&l_649[0],&l_649[1],&l_649[0]},{(void*)0,(void*)0,&l_649[0],&l_649[0],&l_649[0],(void*)0,&l_649[0],&l_649[0]},{(void*)0,(void*)0,&l_649[0],&l_649[1],&l_649[0],(void*)0,&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[1],&l_649[1],&l_649[0],&l_649[0]},{&l_649[0],&l_649[1],&l_649[0],(void*)0,&l_649[1],&l_649[1],&l_649[1],&l_649[0]}},{{&l_649[0],(void*)0,(void*)0,&l_649[0],&l_649[0],(void*)0,(void*)0,&l_649[0]},{&l_649[0],(void*)0,&l_649[1],&l_649[0],&l_649[0],&l_649[0],&l_649[1],&l_649[0]},{&l_649[0],&l_649[0],&l_649[1],(void*)0,&l_649[0],&l_649[0],&l_649[0],(void*)0},{&l_649[0],(void*)0,&l_649[0],&l_649[0],&l_649[0],(void*)0,(void*)0,&l_649[1]},{(void*)0,(void*)0,&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0]}},{{&l_649[1],&l_649[0],&l_649[1],&l_649[1],&l_649[0],&l_649[0],(void*)0,(void*)0},{&l_649[0],&l_649[0],&l_649[1],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],(void*)0,&l_649[0],&l_649[0],&l_649[0],&l_649[0]},{&l_649[1],(void*)0,&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[1]},{(void*)0,&l_649[0],(void*)0,(void*)0,&l_649[0],(void*)0,&l_649[0],&l_649[1]}},{{&l_649[0],(void*)0,&l_649[0],(void*)0,&l_649[0],&l_649[1],(void*)0,&l_649[0]},{&l_649[0],&l_649[1],&l_649[0],(void*)0,&l_649[0],&l_649[0],&l_649[0],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],(void*)0,&l_649[0],&l_649[0],&l_649[1],&l_649[0]},{&l_649[0],&l_649[0],&l_649[0],&l_649[0],&l_649[1],&l_649[1],&l_649[0],&l_649[0]},{&l_649[0],(void*)0,(void*)0,&l_649[1],&l_649[0],&l_649[1],(void*)0,&l_649[0]}}};
                        int32_t l_692 = 0x8EBD9336L;
                        int i, j, k;
                        l_652 |= (safe_mul_func_uint16_t_u_u(p_25, ((safe_lshift_func_int8_t_s_u((l_634 , ((safe_mod_func_int8_t_s_s(l_498, (safe_add_func_int32_t_s_s(((l_639[2] = g_531.f5) > ((((++g_44) ^ ((l_642 == ((l_643[0] > (((((safe_div_func_int16_t_s_s((safe_rshift_func_int16_t_s_u((((+p_26) && (l_649[0] != l_649[0])) <= p_26), 12)), p_25)) || 1UL) != p_25) > g_650) && 0L)) , l_651)) > l_551)) && p_26) != g_145[4][5])), 0x90D4B8B4L)))) || l_267[2][1][3])), 7)) , l_551)));
                        l_692 = (~((safe_mod_func_uint8_t_u_u((l_629 = ((((safe_mod_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((p_26 < (safe_lshift_func_int8_t_s_s(((((safe_rshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(2UL, ((((safe_sub_func_uint8_t_u_u((((*l_668) = &g_212) != (g_670 = &g_210)), ((*l_501) = (safe_add_func_int16_t_s_s((~(safe_add_func_int32_t_s_s(((safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((safe_sub_func_int16_t_s_s(((*g_464) = ((((safe_lshift_func_uint16_t_u_u(((l_498 >= p_26) , (safe_add_func_int16_t_s_s(((0xD0L >= (safe_mod_func_int16_t_s_s(0x43AFL, ((l_639[6] = (safe_mod_func_uint8_t_u_u(((g_277.f1 |= (safe_unary_minus_func_int16_t_s((*g_464)))) || p_26), g_21.f2))) || g_160)))) , l_652), p_26))), p_25)) | p_26) && 1L) != l_691)), g_210)) >= g_20[(g_511.f0 + 1)]), 18446744073709551615UL)), 1UL)) ^ p_25), p_25))), (-4L)))))) | 0xA201D7AAL) || p_26) && 0x9777FDB1L))), 2)) <= g_19) >= 0xCB1FL) , (-1L)), p_26))), p_25)) > p_25), 0x04L)) != 4294967287UL) | 0x1F27F0CEL) | g_511.f0)), 255UL)) | 0x11EEA035837C3626LL));
                        l_713--;
                    }
                }
                for (g_531.f0 = 0; (g_531.f0 <= 0); g_531.f0 += 1)
                { /* block id: 314 */
                    uint32_t ***l_718 = &g_716;
                    const int32_t l_719 = (-1L);
                    int32_t **l_720 = &l_27[4];
                    if ((((g_210 != (((*g_464) = (((g_210 , ((g_28 != p_25) || ((l_538 = l_550) != (void*)0))) && (((*l_718) = g_716) == &g_717)) ^ p_25)) <= l_719)) > l_719) <= p_25))
                    { /* block id: 318 */
                        return (*l_651);
                    }
                    else
                    { /* block id: 320 */
                        return (*l_651);
                    }
                }
            }
            for (g_282 = 2; (g_282 >= 0); g_282 -= 1)
            { /* block id: 327 */
                int32_t *l_736 = &l_701;
                int32_t l_743[10][1][4] = {{{0x9584F2E6L,0L,0L,0x9584F2E6L}},{{0x9A96EF66L,0x8036B2C3L,0L,0x8D55A0DDL}},{{0x9584F2E6L,(-1L),0x90012958L,(-1L)}},{{(-1L),0L,0x9A96EF66L,(-1L)}},{{0x9A96EF66L,(-1L),0x8D55A0DDL,0x8D55A0DDL}},{{0x8036B2C3L,0x8036B2C3L,0x90012958L,0x9584F2E6L}},{{0x8036B2C3L,0L,0x8D55A0DDL,0x8036B2C3L}},{{0x9A96EF66L,0x9584F2E6L,0x9A96EF66L,0x8D55A0DDL}},{{(-1L),0x9584F2E6L,0x90012958L,0x8036B2C3L}},{{0x9584F2E6L,0L,0L,0x9584F2E6L}}};
                uint8_t l_790 = 1UL;
                int i, j, k;
                if ((safe_sub_func_int64_t_s_s((((0L != (l_551 & (0x34B3A4E9L | (+(safe_sub_func_int8_t_s_s(((safe_lshift_func_int8_t_s_s(p_25, (((safe_mod_func_uint16_t_u_u(p_25, 9L)) && 0xAD45A0BC2DFF35C2LL) > (((*l_538) = (safe_lshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u(0x3671022EE39EE3CDLL, ((0xC0CDA3FCL <= l_551) != 0x4541L))), l_734))) > p_26)))) || l_699), p_26)))))) , p_25) >= (**g_716)), g_594.f7)))
                { /* block id: 329 */
                    (*g_89) = (*g_52);
                }
                else
                { /* block id: 331 */
                    for (l_91 = 0; (l_91 <= 2); l_91 += 1)
                    { /* block id: 334 */
                        int32_t **l_735 = &l_27[1];
                        return &g_53;
                    }
                }
                (*g_89) = ((*g_52) = l_736);
                if (((safe_div_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(g_14, (safe_lshift_func_int8_t_s_u((((***l_651) , (**g_52)) && (l_743[3][0][0] |= (**g_52))), 7)))), p_26)) & p_25))
                { /* block id: 341 */
                    ++l_745;
                }
                else
                { /* block id: 343 */
                    uint8_t l_748 = 0xABL;
                    int32_t ***l_753 = &g_751;
                    int32_t **l_755[3];
                    int32_t ***l_754[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_755[i] = &g_752;
                    for (i = 0; i < 3; i++)
                        l_754[i] = &l_755[1];
                    ++l_748;
                    (*g_53) = ((l_756 = ((*l_753) = g_751)) == (l_757[0] = &g_752));
                    for (g_511.f3 = 0; (g_511.f3 <= 0); g_511.f3 += 1)
                    { /* block id: 351 */
                        uint64_t l_758[9][10] = {{1UL,18446744073709551615UL,18446744073709551610UL,18446744073709551610UL,18446744073709551615UL,1UL,9UL,18446744073709551615UL,1UL,18446744073709551608UL},{0xA38140524EAD01DALL,6UL,18446744073709551607UL,0x3C754676433C65B5LL,18446744073709551615UL,18446744073709551615UL,1UL,6UL,0xA48297135E6FB53ALL,18446744073709551615UL},{0xA38140524EAD01DALL,18446744073709551610UL,0xA4A3F2A4B1467B08LL,18446744073709551615UL,0xD367BB3F872D4192LL,1UL,18446744073709551615UL,0xD367BB3F872D4192LL,0xB9F84E77A6BD1FD2LL,1UL},{18446744073709551615UL,0xD367BB3F872D4192LL,0xA48297135E6FB53ALL,0xB9F84E77A6BD1FD2LL,1UL,0x9CCF4FD21913ADDDLL,18446744073709551606UL,0x991B84D786A16897LL,18446744073709551606UL,0x9CCF4FD21913ADDDLL},{18446744073709551610UL,0x377EA4F913C151B6LL,18446744073709551615UL,0x377EA4F913C151B6LL,18446744073709551610UL,2UL,9UL,0xD367BB3F872D4192LL,18446744073709551615UL,1UL},{18446744073709551615UL,18446744073709551615UL,0x65828B5C3E3672C9LL,1UL,0x9CCF4FD21913ADDDLL,0x65828B5C3E3672C9LL,0xD367BB3F872D4192LL,0xB9F84E77A6BD1FD2LL,18446744073709551609UL,1UL},{18446744073709551607UL,1UL,18446744073709551615UL,0x3E466683F989BC9FLL,18446744073709551610UL,18446744073709551606UL,18446744073709551615UL,18446744073709551608UL,18446744073709551615UL,0x9CCF4FD21913ADDDLL},{1UL,0xA4A3F2A4B1467B08LL,0x3C754676433C65B5LL,18446744073709551610UL,1UL,6UL,18446744073709551615UL,18446744073709551615UL,6UL,1UL},{1UL,0x65828B5C3E3672C9LL,0x65828B5C3E3672C9LL,1UL,0xA48297135E6FB53ALL,0x3E466683F989BC9FLL,0x991B84D786A16897LL,18446744073709551615UL,0UL,0xD367BB3F872D4192LL}};
                        int i, j;
                        ++l_758[6][4];
                    }
                    (**l_651) = &l_712;
                }
                for (g_511.f0 = 0; (g_511.f0 <= 8); g_511.f0 += 1)
                { /* block id: 358 */
                    int32_t l_768 = 0x53D278A8L;
                    int i, j;
                    if ((safe_rshift_func_uint16_t_u_s(((g_145[g_511.f0][g_511.f0] < (g_763 == 1UL)) <= (((safe_mod_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u(((l_768 , ((l_712 = (((((safe_mod_func_int8_t_s_s((safe_sub_func_int32_t_s_s(((safe_add_func_int32_t_s_s(((safe_sub_func_int32_t_s_s(((safe_add_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((void*)0 != &g_90), (safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(p_26, (0xC0L & (safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((*g_670), 0UL)), p_26))))), l_789)))), p_26)) , p_25), p_26)) ^ p_26), 0x3C5FAEA3L)) & (*l_736)), 1L)), 0xE3L)) <= 0x41F0D8AAL) | 3L) | 0UL) >= g_277.f5)) > 0xD705C5ACL)) > 8L), g_137[8])), 0xDECC74A2L)) || 0UL) <= p_26)), (*g_464))))
                    { /* block id: 360 */
                        return &g_53;
                    }
                    else
                    { /* block id: 362 */
                        (*g_53) |= (p_25 || g_145[g_511.f0][g_511.f0]);
                        ++l_790;
                    }
                    for (l_789 = 0; (l_789 <= 0); l_789 += 1)
                    { /* block id: 368 */
                        (***l_651) ^= 0x83C7B896L;
                        if (p_25)
                            break;
                        (*g_53) &= (p_26 , (safe_rshift_func_int8_t_s_s(((*l_501) = (-1L)), 4)));
                    }
                }
            }
        }
        else
        { /* block id: 376 */
            uint16_t l_795 = 0x6139L;
            int8_t * const **l_797[10] = {&l_796,&l_796,&l_796,&l_796,&l_796,&l_796,&l_796,&l_796,&l_796,&l_796};
            int32_t l_817 = 0x0E46CA77L;
            int32_t l_820 = 0x048B4A63L;
            int32_t l_821 = 0x3688884AL;
            int32_t l_822 = 0xF7712EB4L;
            int32_t l_824 = 0xEACB47B3L;
            int32_t l_825 = 0xBA4D426EL;
            uint8_t l_826 = 0x34L;
            int8_t l_835 = 0L;
            int32_t l_908 = 0x69B0AEF9L;
            int32_t * const **l_930[9];
            uint32_t l_942 = 0x5A99F789L;
            int32_t l_965 = 1L;
            int16_t l_969[10][10] = {{8L,0x014CL,(-1L),0x1503L,(-1L),0x014CL,8L,8L,0x014CL,(-1L)},{0x014CL,8L,8L,0x014CL,(-1L),0x1503L,(-1L),0x014CL,8L,8L},{(-1L),8L,1L,0xBA88L,0xBA88L,1L,8L,(-1L),8L,1L},{0x1503L,0x014CL,0xBA88L,0x014CL,0x1503L,1L,1L,0x1503L,0x014CL,0xBA88L},{(-1L),(-1L),0xBA88L,0x1503L,0x3D91L,0x1503L,0xBA88L,(-1L),(-1L),0xBA88L},{0x014CL,0x1503L,1L,1L,0x1503L,0x014CL,0xBA88L,0x014CL,0x1503L,1L},{8L,(-1L),8L,1L,0xBA88L,0xBA88L,1L,8L,(-1L),8L},{8L,0x014CL,(-1L),0x1503L,(-1L),0x014CL,8L,8L,0x014CL,(-1L)},{0x014CL,8L,8L,0x014CL,(-1L),0x1503L,(-1L),0x014CL,8L,8L},{(-1L),8L,1L,0xBA88L,0xBA88L,1L,8L,(-1L),8L,1L}};
            int32_t l_975 = 0L;
            int i, j;
            for (i = 0; i < 9; i++)
                l_930[i] = (void*)0;
            if ((p_25 , (254UL || (l_795 & ((g_814 = (g_798 = l_796)) == l_796)))))
            { /* block id: 379 */
                int8_t l_823[5][8] = {{0x8EL,(-1L),0x92L,0x8EL,0x92L,(-1L),0x8EL,1L},{(-1L),0x8AL,1L,0x8EL,0x8EL,1L,0x8AL,(-1L)},{1L,0x8EL,(-1L),0x2EL,1L,0x2EL,1L,1L},{0x92L,1L,0L,0x92L,0x2EL,0x2EL,0x92L,0L},{1L,1L,0x8EL,(-1L),0x92L,0x8EL,0x92L,(-1L)}};
                int32_t l_829 = 0x19154096L;
                int32_t l_830 = 0xEF86D004L;
                int32_t l_831 = 0xD26E0501L;
                int32_t l_832[3];
                int32_t l_833 = (-4L);
                int8_t l_836 = 0x90L;
                uint8_t l_852 = 255UL;
                uint32_t * const **l_920[7][4][9] = {{{&l_919,(void*)0,(void*)0,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,(void*)0,&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919},{&l_919,(void*)0,&l_919,&l_919,(void*)0,(void*)0,&l_919,&l_919,(void*)0},{&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919,(void*)0,&l_919,&l_919}},{{&l_919,(void*)0,&l_919,(void*)0,&l_919,(void*)0,&l_919,&l_919,&l_919},{&l_919,&l_919,(void*)0,(void*)0,&l_919,&l_919,&l_919,&l_919,(void*)0},{&l_919,(void*)0,&l_919,(void*)0,&l_919,&l_919,(void*)0,&l_919,&l_919},{&l_919,(void*)0,&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919,&l_919}},{{(void*)0,&l_919,&l_919,(void*)0,&l_919,&l_919,(void*)0,&l_919,(void*)0},{&l_919,&l_919,(void*)0,(void*)0,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,(void*)0,(void*)0,(void*)0,&l_919,&l_919,&l_919,&l_919,&l_919},{(void*)0,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919}},{{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919,&l_919,&l_919,&l_919}},{{&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919,&l_919,&l_919,&l_919},{&l_919,(void*)0,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,(void*)0,(void*)0,&l_919,(void*)0,(void*)0,(void*)0,&l_919},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,(void*)0}},{{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919,&l_919},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,(void*)0},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919},{&l_919,&l_919,&l_919,(void*)0,(void*)0,&l_919,&l_919,&l_919,&l_919}},{{(void*)0,&l_919,(void*)0,(void*)0,(void*)0,(void*)0,&l_919,&l_919,&l_919},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,(void*)0},{&l_919,(void*)0,&l_919,&l_919,(void*)0,(void*)0,&l_919,(void*)0,(void*)0},{&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,&l_919,(void*)0,&l_919}}};
                int8_t ** const l_936 = &l_501;
                int8_t ** const *l_935 = &l_936;
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_832[i] = 0x72023C3CL;
lbl_945:
                if (l_795)
                { /* block id: 380 */
                    int32_t l_818 = 1L;
                    int32_t l_819[3][5] = {{9L,0xB6D695BEL,9L,9L,0xB6D695BEL},{0xB6D695BEL,9L,9L,0xB6D695BEL,9L},{0xB6D695BEL,0xB6D695BEL,2L,0xB6D695BEL,0xB6D695BEL}};
                    int i, j;
                    --l_826;
                }
                else
                { /* block id: 382 */
                    uint8_t l_837[8][10] = {{0x90L,0x3DL,255UL,255UL,0x3DL,0x90L,1UL,0x11L,255UL,7UL},{0x90L,1UL,0x11L,255UL,7UL,0x90L,0UL,246UL,0x89L,255UL},{0x90L,0UL,246UL,0x89L,255UL,0x90L,255UL,0x89L,246UL,0UL},{0x90L,255UL,0x89L,246UL,0UL,0x90L,7UL,255UL,0x11L,1UL},{0x90L,7UL,255UL,0x11L,1UL,0x90L,0x3DL,255UL,255UL,0x3DL},{0x90L,0x3DL,255UL,255UL,0x3DL,0x90L,1UL,0x11L,255UL,7UL},{0x90L,1UL,0x11L,255UL,7UL,0x90L,0UL,246UL,0x89L,255UL},{0x90L,0UL,246UL,0x89L,255UL,0x90L,255UL,0x89L,246UL,0UL}};
                    int16_t ***l_845[8][3][4] = {{{&g_463,(void*)0,(void*)0,&g_463},{&g_463,&g_463,&g_463,&g_463},{&g_463,&g_463,&g_463,&g_463}},{{(void*)0,&g_463,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463},{&g_463,(void*)0,(void*)0,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{(void*)0,(void*)0,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463},{&g_463,(void*)0,(void*)0,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{(void*)0,(void*)0,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463},{&g_463,(void*)0,(void*)0,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{(void*)0,(void*)0,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463}},{{&g_463,&g_463,&g_463,&g_463},{&g_463,(void*)0,&g_463,&g_463},{&g_463,(void*)0,(void*)0,&g_463}}};
                    int16_t ****l_844 = &l_845[7][1][2];
                    uint64_t *l_850 = &g_511.f7;
                    int32_t l_876 = (-9L);
                    int32_t l_877 = 0L;
                    int32_t l_898 = 0xEDBB5E16L;
                    int32_t l_899 = 0xC62FE3EEL;
                    int32_t l_901 = 0L;
                    int32_t l_903[8] = {0x137A24D1L,0x137A24D1L,0x137A24D1L,0x137A24D1L,0x137A24D1L,0x137A24D1L,0x137A24D1L,0x137A24D1L};
                    int i, j, k;
                    l_837[2][5]--;
                    if (((l_837[7][1] <= (safe_sub_func_int16_t_s_s((g_853 , 1L), g_6))) < (**g_716)))
                    { /* block id: 387 */
                        uint16_t l_874 = 0x601AL;
                        int32_t l_875 = 0x484EC732L;
                        int32_t l_878 = 0x3F909D5FL;
                        l_829 ^= ((255UL & (((safe_div_func_int64_t_s_s((safe_unary_minus_func_uint64_t_u((safe_lshift_func_uint8_t_u_s((*g_670), (safe_div_func_int16_t_s_s((p_26 <= (safe_lshift_func_int8_t_s_s(((void*)0 != &g_670), (l_825 < (safe_mod_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((p_26 && ((safe_add_func_uint16_t_u_u((((safe_sub_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(p_26, ((*l_613) = p_26))) <= g_873), (*g_815))) ^ l_874) , 0x1693L), l_874)) || g_800[4])), l_837[2][5])), p_26)))))), l_795)))))), l_875)) < 0x6DL) , l_874)) >= p_25);
                        ++l_879;
                    }
                    else
                    { /* block id: 391 */
                        uint64_t l_894 = 0x852D66EC8E9F7540LL;
                        int32_t l_895 = 1L;
                        int32_t l_896 = 0xE07D4C5DL;
                        int32_t l_897 = 9L;
                        int32_t l_902 = 0L;
                        int32_t l_904 = 0L;
                        int16_t l_905 = 0xA026L;
                        int32_t l_906 = 0xD31C46D6L;
                        int32_t l_907 = 1L;
                        l_894 |= (((g_530[0] < (safe_div_func_uint32_t_u_u((**g_716), (safe_mul_func_uint16_t_u_u((((*g_464) != ((safe_mul_func_uint8_t_u_u((p_25 & (!2UL)), p_26)) ^ (((*l_608) = ((l_833 = l_837[1][3]) || p_26)) , ((*l_613) = (safe_sub_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u((p_25 ^ p_26), 0xDBC8A96DBAC4A644LL)) <= l_893) <= 0x58CEF3B5E0AF666CLL), p_25)))))) > (*g_717)), g_802))))) && 0xB4B9L) != 0xBD8BD37BL);
                        ++l_909;
                    }
                }
                for (p_26 = 2; (p_26 <= 8); p_26 += 1)
                { /* block id: 401 */
                    uint16_t *l_924 = &l_879;
                    int32_t **l_925[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_925[i] = &l_27[4];
                    for (l_817 = 4; (l_817 >= 1); l_817 -= 1)
                    { /* block id: 404 */
                        int i;
                        l_821 = g_20[l_817];
                        l_825 = p_25;
                    }
                    if ((l_829 = (((((((safe_sub_func_uint32_t_u_u((0L | (*g_464)), (*g_717))) , ((safe_mul_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(((*l_924) = ((l_923[0][1] = (p_26 >= (((((l_918 = l_918) != (p_25 , l_920[0][1][0])) , ((safe_sub_func_int16_t_s_s(p_26, 0xCE64L)) > (**g_716))) ^ 7UL) != p_25))) & p_26)), 10)) != l_908), g_800[0])) , p_26)) | 7L) <= p_26) ^ l_831) , (*g_815)) ^ p_26)))
                    { /* block id: 412 */
                        l_908 = l_820;
                        return &g_53;
                    }
                    else
                    { /* block id: 415 */
                        uint32_t l_926 = 0UL;
                        int32_t l_937 = 0x33CA04CFL;
                        int32_t l_938 = 0L;
                        int32_t l_939 = (-1L);
                        int32_t l_940 = 2L;
                        int32_t l_941 = 0L;
                        --l_926;
                        g_511.f1 = ((l_929 == l_930[0]) < (&g_593 != (((p_25 & p_25) > (((&p_25 == (void*)0) & g_810) , ((safe_mod_func_uint32_t_u_u(((*l_241) = (((safe_mod_func_uint64_t_u_u(((p_25 , g_277.f7) , l_830), 18446744073709551615UL)) < 5L) , p_25)), 0xFD77654BL)) >= p_25))) , l_935)));
                        ++l_942;
                    }
                    for (g_210 = 0; (g_210 <= 8); g_210 += 1)
                    { /* block id: 423 */
                        int32_t **l_946 = (void*)0;
                        if (p_25)
                            break;
                        if (g_500)
                            goto lbl_945;
                        return l_946;
                    }
                }
            }
            else
            { /* block id: 429 */
                int32_t l_949 = 1L;
                int32_t l_950 = 0L;
                int32_t l_952[9][10][2] = {{{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L},{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L}},{{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L},{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L}},{{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L},{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L}},{{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L},{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L}},{{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L},{(-5L),(-5L)},{(-5L),0x01811B35L},{0x5A10B39CL,0x73FDF3F1L},{0x01811B35L,0x73FDF3F1L},{0x5A10B39CL,0x01811B35L}},{{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL},{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL}},{{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL},{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL}},{{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL},{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL}},{{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL},{0x01811B35L,0x01811B35L},{0x01811B35L,0x5A10B39CL},{0L,(-5L)},{0x5A10B39CL,(-5L)},{0L,0x5A10B39CL}}};
                int32_t l_968 = (-2L);
                int32_t l_974 = 0x947A05CDL;
                uint8_t * const l_999 = &l_826;
                uint32_t l_1003 = 0x62481344L;
                int i, j, k;
                for (l_699 = 0; (l_699 >= 4); l_699 = safe_add_func_uint8_t_u_u(l_699, 8))
                { /* block id: 432 */
                    int32_t l_951 = 1L;
                    int32_t l_953[6] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
                    int32_t l_955[8][6] = {{0x4111AD3DL,(-1L),(-7L),2L,(-1L),0xA2773781L},{0xA05C2D38L,6L,0x08FD4216L,0xA2773781L,0xA2773781L,0x08FD4216L},{1L,1L,4L,0xFC084620L,9L,0x4111AD3DL},{(-7L),0x96485F00L,9L,(-7L),(-1L),4L},{6L,(-7L),9L,0x08FD4216L,1L,0x4111AD3DL},{0xC527D89CL,0x08FD4216L,4L,0x1E5AC342L,4L,0x08FD4216L},{0x1E5AC342L,4L,0x08FD4216L,0xC527D89CL,0x7C818CFBL,0xA2773781L},{0x08FD4216L,9L,(-7L),6L,(-7L),0L}};
                    int i, j;
                    l_956++;
                    if ((l_959 == (void*)0))
                    { /* block id: 434 */
                        int64_t l_961 = 0L;
                        int32_t l_962 = 7L;
                        int32_t l_963 = 0xD8868738L;
                        int32_t l_964[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
                        int32_t l_970 = (-9L);
                        int64_t l_973 = 0L;
                        int i;
                        --g_976;
                    }
                    else
                    { /* block id: 436 */
                        uint64_t l_993 = 8UL;
                        uint8_t **l_998 = &l_613;
                        int32_t *l_1002[10][7][3] = {{{&l_820,&l_701,&l_817},{&g_137[4],&l_705,(void*)0},{&l_701,&l_693,&l_710},{&l_972[1][8],(void*)0,&l_707},{&l_701,&l_710,&l_820},{&g_137[4],&l_952[5][2][0],&l_974},{&l_820,&l_950,&l_698}},{{&l_952[1][0][1],&l_700,(void*)0},{&l_698,&l_950,&l_708},{&l_952[1][0][1],(void*)0,&l_952[1][0][1]},{&l_820,&l_701,&l_972[1][8]},{&g_137[4],&l_952[1][0][1],&l_953[5]},{&l_701,&l_701,&l_698},{&l_972[1][8],&g_137[3],&l_697}},{{&l_701,&l_950,&l_700},{&g_137[4],&l_693,&l_707},{&l_822,&l_698,&l_955[3][4]},{&l_949,&l_953[2],&l_700},{(void*)0,&g_160,&l_708},{&l_949,&g_137[4],&l_974},{&l_822,&l_700,&l_950}},{{&l_972[1][8],(void*)0,(void*)0},{&l_498,&l_701,&l_955[3][4]},{(void*)0,&l_972[0][8],&l_949},{&l_498,&g_160,&l_498},{&l_972[1][8],&l_952[1][0][1],&l_822},{&l_822,&l_710,&l_698},{&l_949,&l_697,(void*)0}},{{(void*)0,&l_820,&l_950},{&l_949,&l_972[0][8],&l_498},{&l_822,&l_820,&l_708},{&l_972[1][8],&l_972[1][8],&l_972[1][8]},{&l_498,&l_700,&l_698},{(void*)0,&l_825,&l_708},{&l_498,&l_820,&l_908}},{{&l_972[1][8],&l_953[2],&l_949},{&l_822,&l_949,(void*)0},{&l_949,&l_952[1][0][1],&l_972[1][8]},{(void*)0,&l_955[5][5],&l_950},{&l_949,&l_825,&l_949},{&l_822,&l_701,&l_950},{&l_972[1][8],&l_953[5],&l_700}},{{&l_498,&l_820,(void*)0},{(void*)0,&g_137[4],&l_822},{&l_498,&l_955[5][5],(void*)0},{&l_972[1][8],&l_697,&l_708},{&l_822,&l_698,&l_955[3][4]},{&l_949,&l_953[2],&l_700},{(void*)0,&g_160,&l_708}},{{&l_949,&g_137[4],&l_974},{&l_822,&l_700,&l_950},{&l_972[1][8],(void*)0,(void*)0},{&l_498,&l_701,&l_955[3][4]},{(void*)0,&l_972[0][8],&l_949},{&l_498,&g_160,&l_498},{&l_972[1][8],&l_952[1][0][1],&l_822}},{{&l_822,&l_710,&l_698},{&l_949,&l_697,(void*)0},{(void*)0,&l_820,&l_950},{&l_949,&l_972[0][8],&l_498},{&l_822,&l_820,&l_708},{&l_972[1][8],&l_972[1][8],&l_972[1][8]},{&l_498,&l_700,&l_698}},{{(void*)0,&l_825,&l_708},{&l_498,&l_820,&l_908},{&l_972[1][8],&l_953[2],&l_949},{&l_822,&l_949,(void*)0},{&l_949,&l_952[1][0][1],&l_972[1][8]},{(void*)0,&l_955[5][5],&l_950},{&l_949,&l_825,&l_949}}};
                        int i, j, k;
                        (*g_52) = l_1002[3][0][2];
                        if (l_955[3][4])
                            continue;
                        return &g_53;
                    }
                    for (g_801 = 8; (g_801 >= 0); g_801 -= 1)
                    { /* block id: 451 */
                        int i, j;
                        --l_1003;
                        if (l_969[(g_801 + 1)][(g_801 + 1)])
                            continue;
                    }
                    return &g_53;
                }
            }
        }
        for (g_212 = 0; (g_212 <= 8); g_212 += 1)
        { /* block id: 461 */
            uint32_t ***l_1042 = &g_716;
            int32_t * const l_1044 = &l_972[1][2];
            uint8_t * const *l_1061 = &g_670;
            int i;
            if (((l_954[g_212] == (safe_lshift_func_uint16_t_u_s((safe_mod_func_int64_t_s_s((safe_sub_func_uint8_t_u_u((((safe_lshift_func_int8_t_s_u(((l_954[g_212] == p_26) || (safe_unary_minus_func_int8_t_s((p_25 , (l_954[g_212] , ((void*)0 != l_1015)))))), (5UL && ((p_26 > (*g_670)) >= g_1016)))) | (-2L)) || p_25), (*g_670))), l_954[g_212])), 11))) < g_711))
            { /* block id: 462 */
                int16_t l_1037 = 0x1B36L;
                for (g_763 = 0; (g_763 <= 25); g_763 = safe_add_func_int8_t_s_s(g_763, 8))
                { /* block id: 465 */
                    int32_t *l_1036[7];
                    int64_t *l_1039 = &l_734;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1036[i] = &l_705;
                    g_853.f1 |= (safe_mod_func_uint32_t_u_u((~(7UL >= (((*l_1039) = (safe_div_func_int64_t_s_s((!(0x6D7EL <= (((safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(((0UL < ((safe_unary_minus_func_uint32_t_u(((((safe_sub_func_int32_t_s_s(p_26, (p_26 == (l_1036[3] == l_1036[0])))) >= p_26) > p_26) , 4294967295UL))) == l_1037)) & p_25), 15)), (*g_670))) == 0x1255DBCB8F37EA26LL), l_954[g_212])), p_25)) || l_1038[2]) | p_26))), g_711))) == p_26))), (-1L)));
                }
            }
            else
            { /* block id: 469 */
                int64_t l_1062 = (-4L);
                for (l_900 = 0; (l_900 >= 0); l_900 -= 1)
                { /* block id: 472 */
                    int64_t l_1043 = 1L;
                    for (l_693 = 0; (l_693 >= 0); l_693 -= 1)
                    { /* block id: 475 */
                        uint32_t ** const *l_1041[10];
                        uint32_t ** const **l_1040 = &l_1041[3];
                        int32_t **l_1045 = &g_53;
                        int i;
                        for (i = 0; i < 10; i++)
                            l_1041[i] = (void*)0;
                        l_1043 ^= (((*l_1040) = (void*)0) != l_1042);
                        (*l_1045) = l_1044;
                        if (g_800[(l_900 + 1)])
                            continue;
                        (*l_1044) = ((safe_rshift_func_int16_t_s_s(0xF412L, (((((**l_1061) &= (safe_add_func_uint8_t_u_u((((func_54(p_25, ((safe_sub_func_uint16_t_u_u(g_851, (safe_unary_minus_func_int8_t_s(p_26)))) ^ ((safe_lshift_func_int16_t_s_u((~(((**g_716) = ((safe_sub_func_uint16_t_u_u(l_1060, (l_1061 != (void*)0))) , ((*l_43) = (((&l_706 == (void*)0) == 1UL) || (*l_1044))))) & p_25)), (**l_1045))) > (**l_1045))), (**l_1045), g_594.f0) , l_1062) <= (*g_815)) , p_25), p_25))) <= 0L) == p_26) && 0x8D56B39EL))) >= g_20[2]);
                    }
                    (*g_89) = ((*g_52) = &g_711);
                }
            }
        }
        for (g_500 = 22; (g_500 != 34); g_500++)
        { /* block id: 492 */
            if (p_26)
                break;
            for (l_697 = 21; (l_697 < 2); l_697 = safe_sub_func_int8_t_s_s(l_697, 5))
            { /* block id: 496 */
                uint32_t l_1074 = 4294967290UL;
                for (g_277.f0 = 0; (g_277.f0 != 43); g_277.f0 = safe_add_func_int16_t_s_s(g_277.f0, 4))
                { /* block id: 499 */
                    int64_t l_1071 = 4L;
                    int64_t l_1079 = (-1L);
                    for (g_801 = 25; (g_801 <= (-24)); g_801--)
                    { /* block id: 502 */
                        l_1071 = p_26;
                        return &g_53;
                    }
                    l_1079 |= (safe_rshift_func_int16_t_s_u(((*g_464) ^= (l_1074 ^ (+l_1076))), (safe_div_func_uint8_t_u_u(255UL, (*g_670)))));
                }
            }
        }
    }
    return l_1080;
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_53 g_14 g_135 g_511 g_530 g_531
 * writes: g_14 g_44 g_137 g_53
 */
static struct S0  func_54(int8_t  p_55, int16_t  p_56, int8_t  p_57, uint32_t  p_58)
{ /* block id: 213 */
    uint16_t l_506 = 0x9FA7L;
    int8_t **l_521[2];
    uint64_t l_526 = 18446744073709551615UL;
    int i;
    for (i = 0; i < 2; i++)
        l_521[i] = &g_491;
    if ((((safe_lshift_func_int16_t_s_u(5L, 5)) > ((**g_52) &= p_58)) | (((l_506 , p_56) < ((safe_rshift_func_int16_t_s_u(l_506, 15)) ^ ((void*)0 != (*g_52)))) >= g_135)))
    { /* block id: 215 */
        for (g_44 = 0; g_44 < 9; g_44 += 1)
        {
            g_137[g_44] = (-1L);
        }
        (*g_52) = (void*)0;
        for (p_58 = 27; (p_58 < 57); p_58++)
        { /* block id: 220 */
            return g_511;
        }
    }
    else
    { /* block id: 223 */
        int32_t l_516[5];
        int8_t ***l_522 = &l_521[1];
        const int32_t ***l_523 = &g_89;
        int32_t l_524 = 0L;
        uint8_t *l_525[9][1][6] = {{{&g_212,(void*)0,&g_210,&g_210,&g_210,(void*)0}},{{&g_210,&g_212,&g_210,&g_212,&g_212,&g_210}},{{&g_210,&g_210,&g_212,&g_210,&g_210,&g_210}},{{&g_212,&g_210,&g_212,&g_210,&g_212,&g_212}},{{(void*)0,&g_212,&g_212,(void*)0,&g_210,&g_210}},{{&g_210,&g_212,&g_210,&g_212,&g_210,&g_212}},{{&g_212,&g_210,&g_212,&g_212,&g_210,&g_212}},{{&g_210,&g_212,&g_210,&g_210,&g_210,&g_212}},{{&g_210,&g_210,&g_212,&g_210,&g_210,&g_212}}};
        int8_t *l_527 = &g_511.f3;
        const int32_t *l_529 = (void*)0;
        const int32_t **l_528 = &l_529;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_516[i] = 8L;
        (**g_52) = (((((safe_rshift_func_int8_t_s_u((l_516[1] & (((*l_528) = &l_524) == (void*)0)), 2)) , g_530[0]) & p_57) & l_526) >= 0x4483L);
    }
    return g_531;
}


/* ------------------------------------------ */
/* 
 * reads : g_53 g_19 g_178 g_14 g_277 g_145 g_133 g_212 g_21.f1 g_52 g_325 g_137 g_210 g_21.f5 g_462 g_148 g_282 g_481 g_463 g_464 g_160
 * writes: g_53 g_19 g_178 g_133 g_282 g_14 g_212 g_277.f0 g_20 g_463 g_145 g_491
 */
static const uint32_t  func_68(int32_t ** p_69, int32_t ** p_70, int8_t  p_71)
{ /* block id: 116 */
    int32_t l_272 = 0xF46E7083L;
    int32_t l_283[6] = {(-4L),6L,(-4L),(-4L),6L,(-4L)};
    uint16_t l_295[3];
    int64_t *l_324 = &g_133;
    const int32_t **l_383 = &g_90;
    uint32_t l_475 = 4294967295UL;
    int8_t *l_486[8][1];
    int i, j;
    for (i = 0; i < 3; i++)
        l_295[i] = 65534UL;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
            l_486[i][j] = &g_135;
    }
    (*p_69) = (*p_69);
    for (g_19 = (-1); (g_19 <= 44); g_19 = safe_add_func_uint8_t_u_u(g_19, 8))
    { /* block id: 120 */
        uint64_t l_291[9][3][8] = {{{18446744073709551611UL,18446744073709551612UL,18446744073709551610UL,1UL,0UL,0x3E4FF47D78C674DELL,18446744073709551606UL,0x09037D4182CB10E3LL},{18446744073709551610UL,0x3DCA199E2A63C7ABLL,18446744073709551613UL,6UL,18446744073709551611UL,0x684CF5DC0CEF86DELL,0xBB811BF82B213745LL,0UL},{0xCEB0BC73D204DF4BLL,0x6308C6F954EC6FA8LL,0xA997E5A0778CE083LL,1UL,0x1310D9C446DE6448LL,18446744073709551615UL,0x664D865936964168LL,0x0AAD98337A895C0ALL}},{{0x795DC2F38453F7F7LL,18446744073709551612UL,0x7B09AB5F580B7B11LL,1UL,0x7B09AB5F580B7B11LL,18446744073709551612UL,0x795DC2F38453F7F7LL,0x3DCA199E2A63C7ABLL},{18446744073709551610UL,0xAD468E1691999558LL,0x874F58ABC9BC23BCLL,0xC9B6341C7137C132LL,1UL,18446744073709551610UL,18446744073709551613UL,0x81D80BF712A38A6ALL},{0xD285BDA2F7A7A2C9LL,3UL,1UL,0x795DC2F38453F7F7LL,1UL,0xB1C68B05920B80E0LL,1UL,1UL}},{{18446744073709551610UL,0UL,0x2A63C90750858C52LL,0x81D80BF712A38A6ALL,0x7B09AB5F580B7B11LL,18446744073709551615UL,0UL,0UL},{0x795DC2F38453F7F7LL,0x1B2535BE3E966DBCLL,0x81D80BF712A38A6ALL,18446744073709551615UL,0x1310D9C446DE6448LL,0x09037D4182CB10E3LL,0xBC05B62413DD2467LL,0x31FFB44109209464LL},{0xCEB0BC73D204DF4BLL,1UL,0xA4F54504EA7FF4E4LL,9UL,18446744073709551611UL,0UL,0x24EA310EAAE944D6LL,18446744073709551610UL}},{{18446744073709551610UL,0xCEB0BC73D204DF4BLL,0x1B2535BE3E966DBCLL,1UL,0UL,0xAD468E1691999558LL,18446744073709551611UL,18446744073709551612UL},{18446744073709551611UL,0x802A8A70B46EA5D3LL,0x2DD2EF5246273A6DLL,18446744073709551615UL,18446744073709551615UL,1UL,7UL,1UL},{18446744073709551611UL,18446744073709551612UL,0xF36BC50D1068E37ELL,0xD285BDA2F7A7A2C9LL,18446744073709551615UL,9UL,0xDFFD78A4FEAA90E3LL,0xBB7F8BF7227BF970LL}},{{0xC95829EE725D3417LL,18446744073709551606UL,0xA405F35307B5E04BLL,18446744073709551611UL,7UL,18446744073709551612UL,1UL,18446744073709551610UL},{0xBFF306726C21DDFALL,0xF5139CD15266E77DLL,0xFD62860D3FAABD57LL,18446744073709551612UL,0x3DCA199E2A63C7ABLL,0x874F58ABC9BC23BCLL,18446744073709551610UL,18446744073709551612UL},{3UL,0xBB7F8BF7227BF970LL,0xBFF306726C21DDFALL,18446744073709551611UL,18446744073709551611UL,0xBFF306726C21DDFALL,0xBB7F8BF7227BF970LL,3UL}},{{0xBD3B3BA48C5682B5LL,0UL,0x486C57CDE4736B51LL,0x6308C6F954EC6FA8LL,0x09037D4182CB10E3LL,0xF36BC50D1068E37ELL,0UL,0x3E4FF47D78C674DELL},{18446744073709551615UL,0xC95829EE725D3417LL,18446744073709551610UL,0UL,0x6308C6F954EC6FA8LL,0xF36BC50D1068E37ELL,0x3DCA199E2A63C7ABLL,7UL},{18446744073709551615UL,0UL,1UL,0x874F58ABC9BC23BCLL,0xFD62860D3FAABD57LL,0xBFF306726C21DDFALL,0UL,18446744073709551612UL}},{{7UL,0xBB7F8BF7227BF970LL,18446744073709551606UL,1UL,0x81D80BF712A38A6ALL,0x874F58ABC9BC23BCLL,0xF5139CD15266E77DLL,0xD50EA08A2A92A369LL},{1UL,0xF5139CD15266E77DLL,0xDFFD78A4FEAA90E3LL,0x0AAD98337A895C0ALL,0UL,18446744073709551612UL,0x8584F748EBBB2773LL,0xC95829EE725D3417LL},{0xA405F35307B5E04BLL,0xC95829EE725D3417LL,6UL,1UL,7UL,18446744073709551615UL,18446744073709551615UL,0xD807AB2B7545660DLL}},{{0xF36BC50D1068E37ELL,0xF5139CD15266E77DLL,0x795DC2F38453F7F7LL,0xA4F54504EA7FF4E4LL,0xBB811BF82B213745LL,0UL,0xD285BDA2F7A7A2C9LL,0x664D865936964168LL},{0x2DD2EF5246273A6DLL,0x2A63C90750858C52LL,9UL,0x09037D4182CB10E3LL,18446744073709551613UL,0x30916B115BD37BD4LL,18446744073709551610UL,0UL},{0x1B2535BE3E966DBCLL,9UL,18446744073709551615UL,0x31FFB44109209464LL,0xB1C68B05920B80E0LL,0xBB811BF82B213745LL,0xC9B6341C7137C132LL,18446744073709551610UL}},{{0xA4F54504EA7FF4E4LL,0x1C4D4A3C98711725LL,18446744073709551615UL,18446744073709551612UL,18446744073709551615UL,0UL,18446744073709551606UL,1UL},{0x81D80BF712A38A6ALL,18446744073709551611UL,0x24EA310EAAE944D6LL,18446744073709551613UL,18446744073709551615UL,18446744073709551613UL,0x24EA310EAAE944D6LL,18446744073709551611UL},{0x2A63C90750858C52LL,0UL,0xF5139CD15266E77DLL,0UL,18446744073709551611UL,0x6308C6F954EC6FA8LL,18446744073709551615UL,18446744073709551610UL}}};
        int8_t *l_308[7][1][4] = {{{&g_277.f3,&g_135,&g_277.f3,&g_277.f3}},{{&g_135,&g_135,(void*)0,&g_135}},{{&g_135,&g_277.f3,&g_277.f3,&g_135}},{{&g_277.f3,&g_135,&g_277.f3,&g_277.f3}},{{&g_135,&g_135,(void*)0,&g_135}},{{&g_135,&g_277.f3,&g_277.f3,&g_135}},{{&g_277.f3,&g_135,&g_277.f3,&g_277.f3}}};
        int32_t l_335 = 3L;
        int32_t l_336[2][3] = {{0x5AE9B3B8L,0x5AE9B3B8L,1L},{0x5AE9B3B8L,0x5AE9B3B8L,1L}};
        uint64_t l_339 = 0xB5ED032FCD2DCC75LL;
        uint32_t *l_407[10][1][4] = {{{&g_44,&g_277.f0,&g_277.f0,&g_277.f0}},{{&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0}},{{&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0}},{{(void*)0,(void*)0,&g_277.f0,&g_44}},{{(void*)0,&g_277.f0,&g_277.f0,(void*)0}},{{&g_277.f0,&g_44,&g_277.f0,&g_277.f0}},{{&g_277.f0,&g_44,&g_277.f0,(void*)0}},{{&g_44,&g_277.f0,&g_277.f0,&g_44}},{{&g_277.f0,(void*)0,&g_277.f0,&g_277.f0}},{{&g_44,&g_277.f0,&g_277.f0,&g_277.f0}}};
        int16_t **l_461 = (void*)0;
        int i, j, k;
        for (g_178 = 27; (g_178 >= (-21)); g_178--)
        { /* block id: 123 */
            int64_t *l_280 = &g_133;
            int64_t *l_281 = &g_282;
            uint8_t *l_294[4] = {&g_212,&g_212,&g_212,&g_212};
            int32_t l_298[2];
            int32_t l_323 = (-4L);
            int16_t *l_326 = (void*)0;
            int32_t l_327 = 1L;
            uint32_t *l_401 = &g_277.f0;
            int32_t l_403 = 0x85A242E4L;
            uint64_t l_445 = 0x120338512767AB7FLL;
            int i;
            for (i = 0; i < 2; i++)
                l_298[i] = 0x7E63882DL;
            l_272 = (**p_69);
            if ((safe_mod_func_int16_t_s_s(0xEBC7L, (safe_add_func_uint64_t_u_u((((*g_53) = ((g_277 , p_69) == ((((safe_lshift_func_uint8_t_u_s((((((l_283[2] = ((*l_281) = ((*l_280) = g_145[4][5]))) >= 7L) , (((p_71 >= ((safe_rshift_func_uint8_t_u_u((((safe_add_func_int64_t_s_s(((*l_280) &= (safe_mod_func_int64_t_s_s((~0xCFL), l_291[6][2][3]))), (safe_mul_func_uint8_t_u_u((l_295[2]--), ((l_298[0] <= g_212) >= p_71))))) | 0L) & g_21.f1), 1)) > l_291[2][2][2])) ^ p_71) >= l_291[6][2][3])) & l_298[0]) && l_291[6][2][3]), 5)) == l_272) < p_71) , p_70))) & 1L), l_291[6][2][3])))))
            { /* block id: 131 */
                uint8_t l_319[6] = {0x9DL,0x9DL,0x9DL,0x9DL,0x9DL,0x9DL};
                int32_t l_337[8][10][3] = {{{(-1L),0L,0L},{0L,(-9L),0x78E88200L},{(-4L),0xEDAA46B1L,0xEA4F6FBCL},{0xF4F7B480L,1L,0x05259986L},{0xEB2A888EL,(-8L),0x31ABD8A1L},{(-7L),0x0935C681L,0xE45B5A84L},{0L,6L,1L},{0xE45B5A84L,0xBE97FAF3L,9L},{6L,0x3281BDC8L,1L},{(-1L),0L,(-6L)}},{{0xA7A934EFL,0xAA56B7D8L,0xAA56B7D8L},{0xFCD97547L,1L,0xBE97FAF3L},{0x3CEBE816L,0x0B8C5502L,(-1L)},{0L,1L,1L},{(-7L),(-10L),0xCA488AD1L},{(-6L),1L,0x74CE7931L},{(-9L),0x0B8C5502L,0x76D62D0AL},{0x78E88200L,(-5L),0x3F769CEDL},{0x34029A7AL,0x35CE9EFBL,0xD0861988L},{(-8L),0xC8FDA1C9L,0x78E88200L}},{{(-1L),1L,0x31ABD8A1L},{(-1L),0xF0E65E22L,0xFFF755FFL},{1L,0L,1L},{0xF4F7B480L,0x7408FA73L,0L},{(-1L),0xD0861988L,(-1L)},{0x10DA4FAAL,(-1L),0L},{0xD9A3F886L,(-4L),0xC8334F02L},{0x75ED174BL,0L,1L},{1L,(-1L),0x309E014EL},{(-1L),1L,(-1L)}},{{0x76D62D0AL,0L,0x76D62D0AL},{1L,0x3F769CEDL,0x0935C681L},{0xD0861988L,0L,0x634AED8EL},{(-7L),8L,0x6C6504D1L},{1L,0xEA4F6FBCL,(-1L)},{(-7L),1L,0xC8FDA1C9L},{0xD0861988L,0xEDAA46B1L,0x0B8C5502L},{1L,0x5E713FECL,(-7L)},{0x76D62D0AL,(-10L),(-4L)},{(-1L),0xBE97FAF3L,0L}},{{1L,(-8L),0x98808A8CL},{0x75ED174BL,0xFCD97547L,0x7408FA73L},{0xD9A3F886L,0xC8334F02L,(-1L)},{0x10DA4FAAL,0L,(-9L)},{(-1L),1L,0L},{0xF4F7B480L,0xFFF755FFL,6L},{1L,(-1L),(-10L)},{(-1L),0x75ED174BL,(-8L)},{(-1L),0x3CEBE816L,(-1L)},{(-8L),0xA39CCFACL,0L}},{{0x34029A7AL,0x34029A7AL,0L},{0x78E88200L,0L,0x10DA4FAAL},{(-1L),0xCA488AD1L,(-1L)},{0xE45B5A84L,1L,(-1L)},{0x634AED8EL,(-1L),(-1L)},{0x0F3FFA15L,(-1L),0x10DA4FAAL},{0x0B8C5502L,0x76D62D0AL,0L},{0xBE97FAF3L,0x6CA54E26L,0L},{0x31ABD8A1L,(-1L),(-1L)},{0L,0x384A0247L,(-8L)}},{{0L,0x1394130DL,(-10L)},{(-1L),(-8L),6L},{(-1L),(-1L),0L},{0x4D84C3E9L,(-1L),(-9L)},{(-9L),0x3281BDC8L,(-1L)},{1L,0x74D077DBL,0x7408FA73L},{(-1L),0x0B8C5502L,0x98808A8CL},{0x74D077DBL,(-7L),0L},{1L,0x76C7FB34L,(-4L)},{1L,(-7L),(-7L)}},{{0x3CEBE816L,0xA7A934EFL,0x0B8C5502L},{0xF0E65E22L,0x05259986L,0xC8FDA1C9L},{0x32267AD0L,1L,(-1L)},{2L,0x10DA4FAAL,0x6C6504D1L},{(-4L),1L,0x634AED8EL},{8L,0x05259986L,0x0935C681L},{0x309E014EL,0xA7A934EFL,0x76D62D0AL},{0x5E713FECL,(-7L),(-1L)},{(-4L),0x76C7FB34L,0x309E014EL},{(-4L),(-7L),1L}}};
                int32_t l_380 = 0xEFC4623EL;
                int32_t *l_404 = &g_137[4];
                uint64_t *l_408 = &g_20[4];
                uint64_t l_444 = 18446744073709551611UL;
                const uint32_t *l_453 = &g_21.f0;
                const uint32_t **l_452 = &l_453;
                int32_t *l_460 = (void*)0;
                int i, j, k;
                for (g_212 = 1; (g_212 <= 5); g_212 += 1)
                { /* block id: 134 */
                    int8_t **l_309 = &l_308[1][0][3];
                    int8_t *l_318[3][7] = {{&g_135,&g_135,&g_135,&g_135,&g_135,&g_135,&g_135},{&g_277.f3,&g_277.f3,&g_277.f3,&g_277.f3,&g_277.f3,&g_277.f3,&g_277.f3},{&g_135,&g_135,&g_135,&g_135,&g_135,&g_135,&g_135}};
                    int32_t *l_330 = &l_283[2];
                    int32_t *l_331 = &l_327;
                    int32_t *l_332 = &l_283[g_212];
                    int32_t *l_333 = &g_160;
                    int32_t *l_334[1];
                    int16_t l_338[2][4] = {{0x87D9L,0x87D9L,0x87D9L,0x87D9L},{0x87D9L,0x87D9L,0x87D9L,0x87D9L}};
                    int32_t ***l_377 = &g_52;
                    uint64_t *l_378 = (void*)0;
                    uint64_t *l_379 = (void*)0;
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_334[i] = (void*)0;
                    l_327 |= ((safe_unary_minus_func_uint64_t_u(((((safe_div_func_uint32_t_u_u((safe_div_func_uint8_t_u_u((safe_add_func_int32_t_s_s((((safe_mul_func_uint16_t_u_u((((4UL ^ ((l_298[0] &= 0xE5L) || (((*l_309) = l_308[1][0][3]) != (l_283[g_212] , &g_135)))) | (((((*p_69) = (((safe_sub_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u(((((p_71 >= (safe_sub_func_uint8_t_u_u((((l_319[0] = l_283[2]) <= (safe_rshift_func_uint16_t_u_s(((!(&p_71 == &g_135)) || g_212), 1))) <= 0x1313D4E5EF283404LL), 0UL))) || l_283[g_212]) || p_71) , l_323), 0x196BL)), (-6L))), 1L)) <= 0xE6BF6D669E67C957LL) , (*g_52))) == (void*)0) , &g_282) == l_324)) , l_283[1]), l_295[0])) , g_145[5][2]) , (*g_53)), (-9L))), g_325)), l_283[g_212])) & l_291[2][2][6]) , &g_145[6][8]) != l_326))) , (**g_52));
                    for (g_277.f0 = 0; (g_277.f0 < 38); g_277.f0++)
                    { /* block id: 142 */
                        (**g_52) ^= l_323;
                    }
                    --l_339;
                    (*p_69) = (*g_52);
                }
                for (l_327 = 0; (l_327 < 9); l_327 = safe_add_func_int16_t_s_s(l_327, 1))
                { /* block id: 156 */
                    uint32_t *l_398[9][10][2] = {{{&g_277.f0,&g_44},{&g_44,&g_44},{&g_277.f0,(void*)0},{(void*)0,&g_277.f0},{&g_277.f0,&g_277.f0},{&g_50,&g_44},{&g_277.f0,&g_44},{&g_277.f0,&g_277.f0},{&g_44,&g_44},{&g_277.f0,&g_277.f0}},{{(void*)0,&g_50},{&g_44,&g_44},{&g_277.f0,&g_50},{&g_50,&g_50},{&g_277.f0,&g_277.f0},{&g_50,&g_277.f0},{&g_44,&g_50},{&g_50,(void*)0},{&g_50,(void*)0},{&g_50,&g_50}},{{&g_44,&g_277.f0},{&g_50,&g_277.f0},{&g_277.f0,&g_50},{&g_50,&g_50},{&g_277.f0,&g_44},{&g_44,&g_50},{(void*)0,&g_277.f0},{&g_277.f0,&g_44},{&g_44,&g_277.f0},{&g_277.f0,&g_44}},{{&g_277.f0,&g_44},{&g_50,&g_277.f0},{&g_277.f0,&g_277.f0},{(void*)0,(void*)0},{&g_277.f0,&g_44},{&g_44,&g_44},{&g_277.f0,&g_277.f0},{&g_44,&g_277.f0},{&g_277.f0,&g_277.f0},{&g_277.f0,&g_277.f0}},{{&g_44,&g_277.f0},{&g_277.f0,&g_44},{&g_44,&g_44},{&g_277.f0,(void*)0},{(void*)0,&g_277.f0},{&g_277.f0,&g_277.f0},{&g_50,&g_44},{&g_277.f0,&g_44},{&g_277.f0,&g_277.f0},{&g_44,&g_44}},{{&g_277.f0,&g_277.f0},{(void*)0,&g_50},{&g_44,&g_44},{&g_277.f0,&g_50},{&g_50,&g_50},{&g_277.f0,&g_277.f0},{&g_50,&g_277.f0},{&g_44,&g_50},{&g_50,(void*)0},{&g_50,(void*)0}},{{&g_50,&g_50},{&g_44,&g_277.f0},{&g_50,&g_277.f0},{&g_277.f0,&g_50},{&g_50,&g_50},{&g_277.f0,&g_44},{&g_44,&g_50},{(void*)0,&g_277.f0},{&g_277.f0,&g_44},{&g_44,&g_277.f0}},{{&g_277.f0,&g_44},{&g_277.f0,&g_44},{&g_50,&g_277.f0},{&g_277.f0,&g_277.f0},{(void*)0,(void*)0},{&g_277.f0,&g_44},{&g_44,&g_44},{&g_277.f0,&g_277.f0},{&g_44,&g_277.f0},{&g_277.f0,&g_277.f0}},{{&g_277.f0,&g_277.f0},{&g_44,&g_50},{&g_277.f0,&g_50},{&g_277.f0,&g_277.f0},{&g_44,&g_277.f0},{&g_277.f0,&g_277.f0},{&g_44,&g_44},{(void*)0,&g_44},{&g_277.f0,&g_277.f0},{&g_277.f0,&g_44}}};
                    uint32_t *l_399 = &g_260;
                    uint32_t **l_400 = &l_398[6][3][1];
                    int32_t l_402[1][1][4] = {{{0xECBCB07EL,0xECBCB07EL,0xECBCB07EL,0xECBCB07EL}}};
                    int32_t l_446 = 0x01F14E60L;
                    int i, j, k;
                    l_383 = &g_90;
                }
                (*g_53) = (p_71 ^ (safe_lshift_func_int16_t_s_s(((**p_69) == (safe_sub_func_int64_t_s_s((((p_71 >= ((((*l_452) = (void*)0) == (void*)0) & ((safe_add_func_int64_t_s_s(((l_336[1][0] ^= ((((g_20[0] = (*l_404)) | (safe_mul_func_uint16_t_u_u((p_71 & (((((safe_rshift_func_int16_t_s_s(0xB5CCL, ((&g_53 != l_383) || p_71))) & l_335) | 0x1472A1047E791777LL) , g_210) , 0UL)), 0L))) & p_71) | g_277.f6)) , g_21.f5), 0x83A7A2216A7398B1LL)) , p_71))) >= 3L) , 0xC9E63EE617969053LL), p_71))), p_71)));
            }
            else
            { /* block id: 182 */
                (*g_462) = l_461;
            }
        }
        return g_148;
    }
    for (g_19 = 15; (g_19 == 17); g_19 = safe_add_func_uint32_t_u_u(g_19, 6))
    { /* block id: 190 */
        int32_t *l_467 = &g_137[4];
        int32_t *l_468 = &l_283[2];
        int32_t *l_469 = &g_160;
        int32_t *l_470 = &l_283[2];
        int32_t *l_471 = &g_137[4];
        int32_t *l_472 = &g_137[4];
        int32_t *l_473 = (void*)0;
        int32_t *l_474 = &l_283[1];
        int8_t **l_487 = (void*)0;
        int8_t **l_488 = (void*)0;
        int8_t **l_489 = (void*)0;
        int8_t **l_490 = &l_486[0][0];
        int8_t *l_492[3];
        uint8_t *l_496 = &g_210;
        uint8_t **l_495 = &l_496;
        int i;
        for (i = 0; i < 3; i++)
            l_492[i] = &g_277.f3;
        l_475++;
        for (g_282 = 3; (g_282 <= 8); g_282 += 1)
        { /* block id: 194 */
            int i;
            (*p_70) = ((safe_unary_minus_func_uint64_t_u(g_137[g_282])) , (void*)0);
            (*p_70) = &g_137[g_282];
        }
        if (l_295[2])
            break;
        (*g_53) &= ((safe_lshift_func_int16_t_s_u(((((g_481[0][2] , ((**g_463) = (g_481[0][2].f6 >= (*l_468)))) & (safe_mul_func_uint16_t_u_u((0UL > (((safe_add_func_int8_t_s_s((((*l_324) |= (((*l_490) = l_486[0][0]) != (l_492[2] = (g_491 = &p_71)))) && (((safe_lshift_func_int16_t_s_s((((*l_495) = l_486[6][0]) == &g_212), 11)) , g_160) && 1UL)), g_160)) ^ p_71) && (*l_470))), (*l_471)))) >= 1L) || p_71), 3)) > (*l_474));
    }
    return p_71;
}


/* ------------------------------------------ */
/* 
 * reads : g_145 g_44 g_53 g_137
 * writes: g_14 g_137
 */
static int32_t ** func_72(int32_t * p_73, uint32_t * p_74, int32_t ** p_75, uint8_t  p_76, int8_t  p_77)
{ /* block id: 108 */
    int32_t l_244[5][7][2];
    int32_t l_254 = 0x2C4B8081L;
    int16_t *l_255 = &g_256;
    int64_t *l_257[6][5] = {{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,(void*)0,&g_133,(void*)0}};
    int32_t l_258 = (-2L);
    uint32_t *l_259 = &g_260;
    int32_t *l_261 = &g_137[4];
    int64_t l_262 = 0x44F79F7B5380B0ABLL;
    int32_t *l_263[9] = {&g_137[2],&g_160,&g_137[2],&g_160,&g_137[2],&g_160,&g_137[2],&g_160,&g_137[2]};
    uint32_t l_264 = 0xC011F5A4L;
    int i, j, k;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 2; k++)
                l_244[i][j][k] = 6L;
        }
    }
    l_262 = ((*l_261) ^= ((**p_75) = (p_77 > ((g_145[4][5] && p_76) & (((safe_add_func_uint8_t_u_u(((((p_76 || (-9L)) , l_259) == (void*)0) ^ l_244[2][0][1]), p_76)) == 0x75E04641L) ^ (*p_74))))));
    l_264--;
    return &g_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_135 g_53 g_14 g_21.f3 g_212 g_89 g_21.f4 g_137 g_52 g_90
 * writes: g_14 g_20 g_90 g_135
 */
static int32_t * func_78(int8_t  p_79, uint32_t  p_80, int32_t  p_81, int8_t  p_82)
{ /* block id: 94 */
    uint32_t l_225 = 4294967295UL;
    int32_t l_226 = 7L;
    if ((0x1A1ADF4364D310EFLL <= (g_20[0] = (((*g_53) = (safe_sub_func_uint16_t_u_u(g_135, 0x791AL))) >= l_225))))
    { /* block id: 97 */
        int8_t *l_239 = &g_135;
        int32_t l_240 = (-8L);
        l_226 = ((*g_53) |= p_81);
        (**g_52) &= (((((0xC602L ^ (safe_add_func_int32_t_s_s((-1L), (safe_div_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((safe_unary_minus_func_int16_t_s(g_21.f3)), p_82)), g_212))))) == (safe_lshift_func_int16_t_s_u((((*g_89) = &p_81) == (void*)0), (p_79 > (safe_add_func_int8_t_s_s((!((*l_239) |= g_21.f4)), 1UL)))))) , l_225) <= l_240) >= g_137[4]);
        return (*g_52);
    }
    else
    { /* block id: 104 */
        (*g_89) = (*g_89);
    }
    return (*g_52);
}


/* ------------------------------------------ */
/* 
 * reads : g_21.f7 g_90 g_14 g_52 g_53 g_44 g_50 g_21.f0 g_21.f5 g_6 g_19 g_137 g_20 g_148 g_21.f1 g_21.f4 g_21.f3 g_133 g_178 g_145
 * writes: g_14 g_133 g_135 g_137 g_50 g_145 g_160 g_20 g_178 g_210 g_212
 */
static int64_t  func_85(const int32_t ** p_86, uint8_t  p_87, int32_t  p_88)
{ /* block id: 26 */
    const int32_t l_117 = 0x3C44AE9DL;
    int64_t *l_132[6][8][5] = {{{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,(void*)0,&g_133,&g_133,(void*)0},{&g_133,&g_133,(void*)0,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,(void*)0,&g_133,(void*)0}},{{&g_133,&g_133,(void*)0,&g_133,&g_133},{&g_133,(void*)0,(void*)0,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{(void*)0,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133}},{{&g_133,(void*)0,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{(void*)0,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,(void*)0,&g_133,(void*)0},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,(void*)0,(void*)0,&g_133,&g_133}},{{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,(void*)0,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133},{&g_133,(void*)0,&g_133,&g_133,&g_133},{&g_133,(void*)0,&g_133,&g_133,(void*)0},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133}},{{&g_133,&g_133,&g_133,&g_133,&g_133},{(void*)0,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,(void*)0},{&g_133,(void*)0,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{(void*)0,(void*)0,&g_133,(void*)0,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,(void*)0,&g_133}},{{&g_133,(void*)0,&g_133,&g_133,&g_133},{(void*)0,(void*)0,&g_133,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,(void*)0,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{&g_133,&g_133,(void*)0,&g_133,&g_133},{&g_133,&g_133,&g_133,&g_133,&g_133},{(void*)0,(void*)0,&g_133,&g_133,(void*)0}}};
    int8_t *l_134 = &g_135;
    int32_t *l_136 = &g_137[4];
    int32_t l_138 = 0x13D8BF85L;
    uint32_t *l_139 = (void*)0;
    uint32_t *l_140 = (void*)0;
    uint32_t *l_141 = &g_50;
    uint32_t l_142 = 0x579C62F1L;
    int16_t *l_143 = (void*)0;
    int16_t *l_144 = &g_145[4][5];
    const int32_t l_149 = (-3L);
    uint64_t l_179 = 18446744073709551611UL;
    uint8_t l_191[8];
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_191[i] = 0xA3L;
    if ((((((g_21.f7 && func_92((safe_add_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((((safe_sub_func_int16_t_s_s(((*l_144) = ((safe_div_func_int64_t_s_s((safe_div_func_int8_t_s_s(((safe_sub_func_uint64_t_u_u(g_21.f7, (((*l_141) = (((((**g_52) = (*g_90)) & (0x114349BA410498C5LL & (l_138 = (safe_rshift_func_uint8_t_u_u((!(safe_rshift_func_int16_t_s_u(((!(safe_sub_func_int32_t_s_s(l_117, (((*l_136) = (safe_div_func_uint16_t_u_u(p_88, (safe_mul_func_int8_t_s_s(((*l_134) = ((safe_unary_minus_func_uint64_t_u((safe_mul_func_uint8_t_u_u(((((g_133 = (~(safe_rshift_func_uint8_t_u_s((safe_add_func_uint8_t_u_u((p_88 && (safe_div_func_int32_t_s_s((l_117 >= (((((l_117 >= 0xBEL) , 0x59L) <= g_44) <= g_50) <= g_21.f0)), 0x9BDABD65L))), g_21.f5)), 1)))) || p_88) , (void*)0) != (void*)0), g_6)))) & l_117)), g_19))))) && (*l_136))))) , 0x1502L), p_88))), p_87))))) == g_6) , (*l_136))) != l_142))) && 4294967291UL), g_19)), 2L)) < 0x83BE9465D988D013LL)), p_87)) , g_21.f7) >= p_88), 15)), p_88)), g_20[0], p_87, g_6)) | p_87) > g_148) || (*l_136)) , l_149))
    { /* block id: 42 */
        uint16_t l_152 = 0xDA09L;
        int32_t l_183 = 5L;
        int32_t l_184 = 0L;
        int32_t l_187 = 0x311D11F0L;
        for (g_14 = 1; (g_14 <= 4); g_14 += 1)
        { /* block id: 45 */
            int32_t *l_159[6] = {&g_14,&g_14,&g_14,&g_14,&g_14,&g_14};
            int64_t *l_182 = &g_133;
            uint32_t l_207 = 4294967290UL;
            uint32_t l_208 = 0xCFCA4276L;
            uint8_t l_216[6];
            int i;
            for (i = 0; i < 6; i++)
                l_216[i] = 0x4CL;
            if ((g_160 = ((((safe_mul_func_int8_t_s_s((g_20[g_14] | 0xB48CL), (g_137[(g_14 + 4)] = g_137[(g_14 + 4)]))) , l_152) ^ ((void*)0 == l_144)) != (safe_lshift_func_int8_t_s_u(3L, (safe_lshift_func_uint8_t_u_s(((safe_mod_func_int32_t_s_s(((65535UL && (p_87 != 0xE7L)) , (-10L)), (*g_53))) , p_87), 4)))))))
            { /* block id: 48 */
                return g_20[1];
            }
            else
            { /* block id: 50 */
                const uint64_t l_163 = 18446744073709551615UL;
                int32_t l_166 = (-1L);
                uint32_t *l_169 = &l_142;
                int i;
                if ((safe_div_func_int8_t_s_s(((l_163 >= (safe_mul_func_int16_t_s_s((l_166 = g_21.f1), ((+((safe_unary_minus_func_int8_t_s((((((*l_169) ^= g_21.f4) , ((p_88 == ((*l_141) = (((safe_rshift_func_uint8_t_u_u((((p_87 , (*l_136)) , (l_152 <= ((*l_136) > (safe_sub_func_uint16_t_u_u(((safe_add_func_int16_t_s_s(((g_178 = (g_20[g_14] = 18446744073709551615UL)) >= g_21.f0), 0xD791L)) ^ g_21.f3), 0xFF29L))))) < 0x5184A0F193884B00LL), g_133)) || 0xB3L) >= l_179))) <= 0x2BL)) , 0UL) || (**p_86)))) ^ 0x39CDCE665EB517B2LL)) >= g_44)))) | p_87), g_44)))
                { /* block id: 56 */
                    int32_t l_185 = 0L;
                    int32_t l_186[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                    int i;
                    if ((0x9A28L || (safe_mod_func_int16_t_s_s((((&g_28 != (void*)0) & p_88) ^ (((*l_182) = (((&g_148 != l_182) ^ (-1L)) ^ 0xCF8FE107L)) > 18446744073709551614UL)), p_88))))
                    { /* block id: 58 */
                        (*l_136) ^= (**p_86);
                    }
                    else
                    { /* block id: 60 */
                        uint16_t l_188 = 65528UL;
                        --l_188;
                        --l_191[5];
                        if (l_188)
                            continue;
                        l_187 = (*g_90);
                    }
                }
                else
                { /* block id: 66 */
                    uint8_t l_213 = 0xADL;
                    for (g_178 = 7; (g_178 >= 0); g_178 -= 1)
                    { /* block id: 69 */
                        uint8_t *l_209 = &g_210;
                        uint8_t *l_211 = &g_212;
                        int i, j;
                        (*l_136) = ((g_145[(g_14 + 3)][(g_14 + 3)] , (((safe_div_func_int64_t_s_s(((safe_mod_func_int32_t_s_s((p_88 = ((+l_191[g_178]) , (1L > ((p_88 , g_20[g_14]) >= 0x52E2E74A5ACE6E74LL)))), l_166)) | (safe_lshift_func_int8_t_s_u((safe_rshift_func_uint8_t_u_u(((*l_211) = ((*l_209) = (safe_mod_func_uint64_t_u_u(((((((safe_lshift_func_uint8_t_u_s(g_21.f5, p_87)) ^ l_207) == l_191[g_178]) <= g_133) > l_208) | g_145[4][5]), (-10L))))), 2)), g_44))), p_87)) ^ 1L) , l_213)) <= l_191[g_178]);
                        return g_20[1];
                    }
                    return (*l_136);
                }
            }
            for (l_187 = (-23); (l_187 < (-11)); l_187 = safe_add_func_uint16_t_u_u(l_187, 2))
            { /* block id: 81 */
                l_216[3]--;
            }
            (*l_136) = (p_88 != g_137[4]);
        }
    }
    else
    { /* block id: 86 */
        int32_t l_221 = 0x59BAA4C8L;
        (*l_136) = ((safe_add_func_uint16_t_u_u(l_221, ((((*l_144) = p_88) <= (safe_unary_minus_func_uint32_t_u(g_133))) | ((void*)0 != &g_210)))) != p_88);
    }
    (*l_136) &= (**p_86);
    (*g_53) = (*g_90);
    (*l_136) |= (**p_86);
    return (*l_136);
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_53 g_14
 * writes: g_14
 */
static uint8_t  func_92(int32_t  p_93, int16_t  p_94, int32_t  p_95, uint64_t  p_96)
{ /* block id: 34 */
    (**g_52) ^= 0xA8B53E2DL;
    for (g_14 = 0; (g_14 != (-16)); g_14 = safe_sub_func_int8_t_s_s(g_14, 3))
    { /* block id: 38 */
        return p_96;
    }
    return p_94;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_20[i], "g_20[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21.f0, "g_21.f0", print_hash_value);
    transparent_crc(g_21.f1, "g_21.f1", print_hash_value);
    transparent_crc(g_21.f2, "g_21.f2", print_hash_value);
    transparent_crc(g_21.f3, "g_21.f3", print_hash_value);
    transparent_crc(g_21.f4, "g_21.f4", print_hash_value);
    transparent_crc(g_21.f5, "g_21.f5", print_hash_value);
    transparent_crc(g_21.f6, "g_21.f6", print_hash_value);
    transparent_crc(g_21.f7, "g_21.f7", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_137[i], "g_137[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_145[i][j], "g_145[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    transparent_crc(g_256, "g_256", print_hash_value);
    transparent_crc(g_260, "g_260", print_hash_value);
    transparent_crc(g_277.f0, "g_277.f0", print_hash_value);
    transparent_crc(g_277.f1, "g_277.f1", print_hash_value);
    transparent_crc(g_277.f2, "g_277.f2", print_hash_value);
    transparent_crc(g_277.f3, "g_277.f3", print_hash_value);
    transparent_crc(g_277.f4, "g_277.f4", print_hash_value);
    transparent_crc(g_277.f5, "g_277.f5", print_hash_value);
    transparent_crc(g_277.f6, "g_277.f6", print_hash_value);
    transparent_crc(g_277.f7, "g_277.f7", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    transparent_crc(g_325, "g_325", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_481[i][j].f0, "g_481[i][j].f0", print_hash_value);
            transparent_crc(g_481[i][j].f1, "g_481[i][j].f1", print_hash_value);
            transparent_crc(g_481[i][j].f2, "g_481[i][j].f2", print_hash_value);
            transparent_crc(g_481[i][j].f3, "g_481[i][j].f3", print_hash_value);
            transparent_crc(g_481[i][j].f4, "g_481[i][j].f4", print_hash_value);
            transparent_crc(g_481[i][j].f5, "g_481[i][j].f5", print_hash_value);
            transparent_crc(g_481[i][j].f6, "g_481[i][j].f6", print_hash_value);
            transparent_crc(g_481[i][j].f7, "g_481[i][j].f7", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_511.f0, "g_511.f0", print_hash_value);
    transparent_crc(g_511.f1, "g_511.f1", print_hash_value);
    transparent_crc(g_511.f2, "g_511.f2", print_hash_value);
    transparent_crc(g_511.f3, "g_511.f3", print_hash_value);
    transparent_crc(g_511.f4, "g_511.f4", print_hash_value);
    transparent_crc(g_511.f5, "g_511.f5", print_hash_value);
    transparent_crc(g_511.f6, "g_511.f6", print_hash_value);
    transparent_crc(g_511.f7, "g_511.f7", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_530[i], "g_530[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_531.f0, "g_531.f0", print_hash_value);
    transparent_crc(g_531.f1, "g_531.f1", print_hash_value);
    transparent_crc(g_531.f2, "g_531.f2", print_hash_value);
    transparent_crc(g_531.f3, "g_531.f3", print_hash_value);
    transparent_crc(g_531.f4, "g_531.f4", print_hash_value);
    transparent_crc(g_531.f5, "g_531.f5", print_hash_value);
    transparent_crc(g_531.f6, "g_531.f6", print_hash_value);
    transparent_crc(g_531.f7, "g_531.f7", print_hash_value);
    transparent_crc(g_594.f0, "g_594.f0", print_hash_value);
    transparent_crc(g_594.f1, "g_594.f1", print_hash_value);
    transparent_crc(g_594.f2, "g_594.f2", print_hash_value);
    transparent_crc(g_594.f3, "g_594.f3", print_hash_value);
    transparent_crc(g_594.f4, "g_594.f4", print_hash_value);
    transparent_crc(g_594.f5, "g_594.f5", print_hash_value);
    transparent_crc(g_594.f6, "g_594.f6", print_hash_value);
    transparent_crc(g_594.f7, "g_594.f7", print_hash_value);
    transparent_crc(g_650, "g_650", print_hash_value);
    transparent_crc(g_711, "g_711", print_hash_value);
    transparent_crc(g_763, "g_763", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_800[i], "g_800[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_801, "g_801", print_hash_value);
    transparent_crc(g_802, "g_802", print_hash_value);
    transparent_crc(g_803, "g_803", print_hash_value);
    transparent_crc(g_804, "g_804", print_hash_value);
    transparent_crc(g_805, "g_805", print_hash_value);
    transparent_crc(g_806, "g_806", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_807[i], "g_807[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_808[i], "g_808[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_809, "g_809", print_hash_value);
    transparent_crc(g_810, "g_810", print_hash_value);
    transparent_crc(g_811, "g_811", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_812[i][j][k], "g_812[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_813, "g_813", print_hash_value);
    transparent_crc(g_816, "g_816", print_hash_value);
    transparent_crc(g_851, "g_851", print_hash_value);
    transparent_crc(g_853.f0, "g_853.f0", print_hash_value);
    transparent_crc(g_853.f1, "g_853.f1", print_hash_value);
    transparent_crc(g_853.f2, "g_853.f2", print_hash_value);
    transparent_crc(g_853.f3, "g_853.f3", print_hash_value);
    transparent_crc(g_853.f4, "g_853.f4", print_hash_value);
    transparent_crc(g_853.f5, "g_853.f5", print_hash_value);
    transparent_crc(g_853.f6, "g_853.f6", print_hash_value);
    transparent_crc(g_853.f7, "g_853.f7", print_hash_value);
    transparent_crc(g_873, "g_873", print_hash_value);
    transparent_crc(g_976, "g_976", print_hash_value);
    transparent_crc(g_1016, "g_1016", print_hash_value);
    transparent_crc(g_1083.f0, "g_1083.f0", print_hash_value);
    transparent_crc(g_1083.f1, "g_1083.f1", print_hash_value);
    transparent_crc(g_1083.f2, "g_1083.f2", print_hash_value);
    transparent_crc(g_1083.f3, "g_1083.f3", print_hash_value);
    transparent_crc(g_1083.f4, "g_1083.f4", print_hash_value);
    transparent_crc(g_1083.f5, "g_1083.f5", print_hash_value);
    transparent_crc(g_1083.f6, "g_1083.f6", print_hash_value);
    transparent_crc(g_1083.f7, "g_1083.f7", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_1084[i][j].f0, "g_1084[i][j].f0", print_hash_value);
            transparent_crc(g_1084[i][j].f1, "g_1084[i][j].f1", print_hash_value);
            transparent_crc(g_1084[i][j].f2, "g_1084[i][j].f2", print_hash_value);
            transparent_crc(g_1084[i][j].f3, "g_1084[i][j].f3", print_hash_value);
            transparent_crc(g_1084[i][j].f4, "g_1084[i][j].f4", print_hash_value);
            transparent_crc(g_1084[i][j].f5, "g_1084[i][j].f5", print_hash_value);
            transparent_crc(g_1084[i][j].f6, "g_1084[i][j].f6", print_hash_value);
            transparent_crc(g_1084[i][j].f7, "g_1084[i][j].f7", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 270
   depth: 1, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 9
breakdown:
   indirect level: 0, occurrence: 9
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 10
XXX times a single bitfield on LHS: 6
XXX times a single bitfield on RHS: 8

XXX max expression depth: 54
breakdown:
   depth: 1, occurrence: 182
   depth: 2, occurrence: 50
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 1
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 32, occurrence: 2
   depth: 39, occurrence: 1
   depth: 48, occurrence: 2
   depth: 54, occurrence: 1

XXX total number of pointers: 172

XXX times a variable address is taken: 703
XXX times a pointer is dereferenced on RHS: 88
breakdown:
   depth: 1, occurrence: 64
   depth: 2, occurrence: 23
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 117
breakdown:
   depth: 1, occurrence: 103
   depth: 2, occurrence: 13
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 16
XXX times a pointer is compared with address of another variable: 2
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 4891

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 546
   level: 2, occurrence: 218
   level: 3, occurrence: 53
   level: 4, occurrence: 1
XXX number of pointers point to pointers: 77
XXX number of pointers point to scalars: 95
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.2
XXX average alias set size: 1.8

XXX times a non-volatile is read: 841
XXX times a non-volatile is write: 408
XXX times a volatile is read: 31
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3.8e+03
XXX percentage of non-volatile access: 97.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 189
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 27
   depth: 2, occurrence: 15
   depth: 3, occurrence: 22
   depth: 4, occurrence: 43
   depth: 5, occurrence: 53

XXX percentage a fresh-made variable is used: 14.7
XXX percentage an existing variable is used: 85.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

