/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4042370303
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const unsigned f0 : 30;
};

#pragma pack(push)
#pragma pack(1)
struct S1 {
   const struct S0  f0;
   uint32_t  f1;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static const volatile uint32_t g_18 = 18446744073709551606UL;/* VOLATILE GLOBAL g_18 */
static int64_t g_29 = 6L;
static int16_t g_31 = 0x12E7L;
static uint32_t g_33 = 0x415051ACL;
static int32_t g_53 = 0x05008D6DL;
static int32_t g_55 = 0x9BB5C1EDL;
static uint32_t g_59[6][5] = {{0UL,0UL,0UL,0UL,0UL},{0x38F87434L,0x227FD5D1L,0x38F87434L,0x227FD5D1L,0x38F87434L},{0UL,0UL,0UL,0UL,0UL},{0x38F87434L,0x227FD5D1L,0x38F87434L,0x227FD5D1L,0x38F87434L},{0UL,0UL,0UL,0UL,0UL},{0x38F87434L,0x227FD5D1L,0x38F87434L,0x227FD5D1L,0x38F87434L}};
static uint32_t g_64 = 0x016D172EL;
static int32_t ** const g_89 = (void*)0;
static int8_t g_101 = 0xB4L;
static uint64_t g_105 = 0xBFABE471A24E3021LL;
static int16_t **g_108 = (void*)0;
static uint8_t g_120 = 0x40L;
static int32_t g_173 = 8L;
static uint16_t g_178 = 0x1D82L;
static int32_t **g_181[2] = {(void*)0,(void*)0};
static int32_t ***g_229 = &g_181[1];
static int32_t g_265 = 0x190EA319L;
static struct S1 g_271[6] = {{{21196},0x31644C7AL},{{21196},0x31644C7AL},{{21196},0x31644C7AL},{{21196},0x31644C7AL},{{21196},0x31644C7AL},{{21196},0x31644C7AL}};
static volatile uint8_t g_284 = 251UL;/* VOLATILE GLOBAL g_284 */
static volatile uint8_t g_285 = 253UL;/* VOLATILE GLOBAL g_285 */
static volatile uint8_t g_286[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static volatile uint8_t g_287 = 0UL;/* VOLATILE GLOBAL g_287 */
static volatile uint8_t g_288 = 0UL;/* VOLATILE GLOBAL g_288 */
static volatile uint8_t g_289 = 0xC3L;/* VOLATILE GLOBAL g_289 */
static volatile uint8_t g_290[2][9] = {{0x5EL,8UL,8UL,0x5EL,0x5EL,8UL,8UL,0x5EL,0x5EL},{0xA6L,0x92L,0xA6L,0x92L,0xA6L,0x92L,0xA6L,0x92L,0xA6L}};
static volatile uint8_t g_291[10][2] = {{0xE0L,251UL},{0x6AL,252UL},{251UL,252UL},{0x6AL,251UL},{0xE0L,0xE0L},{0xE0L,251UL},{0x6AL,252UL},{251UL,252UL},{0x6AL,251UL},{0xE0L,0xE0L}};
static volatile uint8_t g_292 = 0x6FL;/* VOLATILE GLOBAL g_292 */
static volatile uint8_t g_293[3] = {255UL,255UL,255UL};
static volatile uint8_t g_294[2][8][2] = {{{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL}},{{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL},{6UL,6UL}}};
static volatile uint8_t g_295 = 0x99L;/* VOLATILE GLOBAL g_295 */
static volatile uint8_t g_296 = 0xB2L;/* VOLATILE GLOBAL g_296 */
static volatile uint8_t g_297 = 0x7AL;/* VOLATILE GLOBAL g_297 */
static volatile uint8_t g_298 = 0UL;/* VOLATILE GLOBAL g_298 */
static volatile uint8_t g_299 = 0x8FL;/* VOLATILE GLOBAL g_299 */
static volatile uint8_t g_300 = 4UL;/* VOLATILE GLOBAL g_300 */
static volatile uint8_t g_301 = 255UL;/* VOLATILE GLOBAL g_301 */
static volatile uint8_t g_302 = 0x09L;/* VOLATILE GLOBAL g_302 */
static volatile uint8_t g_303 = 255UL;/* VOLATILE GLOBAL g_303 */
static volatile uint8_t g_304[7] = {249UL,249UL,246UL,249UL,249UL,246UL,249UL};
static volatile uint8_t g_305 = 255UL;/* VOLATILE GLOBAL g_305 */
static volatile uint8_t g_306 = 1UL;/* VOLATILE GLOBAL g_306 */
static volatile uint8_t g_307 = 255UL;/* VOLATILE GLOBAL g_307 */
static volatile uint8_t g_308 = 0x0CL;/* VOLATILE GLOBAL g_308 */
static volatile uint8_t g_309 = 3UL;/* VOLATILE GLOBAL g_309 */
static volatile uint8_t g_310 = 0x87L;/* VOLATILE GLOBAL g_310 */
static volatile uint8_t g_311 = 0x3AL;/* VOLATILE GLOBAL g_311 */
static volatile uint8_t g_312 = 0xA4L;/* VOLATILE GLOBAL g_312 */
static volatile uint8_t g_313 = 0xEAL;/* VOLATILE GLOBAL g_313 */
static volatile uint8_t g_314 = 0x6BL;/* VOLATILE GLOBAL g_314 */
static volatile uint8_t g_315[10] = {0x1DL,0x1DL,0x1DL,0x1DL,0x1DL,0x1DL,0x1DL,0x1DL,0x1DL,0x1DL};
static volatile uint8_t g_316[4] = {1UL,1UL,1UL,1UL};
static volatile uint8_t g_317 = 0x0BL;/* VOLATILE GLOBAL g_317 */
static volatile uint8_t g_318 = 0x9FL;/* VOLATILE GLOBAL g_318 */
static volatile uint8_t g_319[1][8][8] = {{{1UL,255UL,1UL,1UL,1UL,1UL,255UL,1UL},{1UL,0xF2L,2UL,0UL,255UL,0x84L,1UL,0x84L},{0UL,0x71L,0x21L,0x71L,0UL,0x84L,0xFEL,255UL},{0x36L,0xF2L,0x71L,0x16L,1UL,1UL,0x16L,0x71L},{255UL,255UL,0x71L,1UL,2UL,1UL,0xFEL,0x36L},{1UL,0xFEL,0x21L,255UL,0x21L,0xFEL,1UL,0x36L},{0xFEL,1UL,2UL,1UL,0x71L,255UL,255UL,0x71L},{0x16L,1UL,1UL,0x16L,0x71L,0xF2L,0x36L,255UL}}};
static volatile uint8_t g_320[6] = {0UL,0xA3L,0xA3L,0UL,0xA3L,0xA3L};
static volatile uint8_t g_321 = 253UL;/* VOLATILE GLOBAL g_321 */
static volatile uint8_t g_322 = 0UL;/* VOLATILE GLOBAL g_322 */
static volatile uint8_t g_323 = 0xFCL;/* VOLATILE GLOBAL g_323 */
static volatile uint8_t g_324[5] = {3UL,3UL,3UL,3UL,3UL};
static volatile uint8_t g_325 = 250UL;/* VOLATILE GLOBAL g_325 */
static volatile uint8_t g_326 = 0x1BL;/* VOLATILE GLOBAL g_326 */
static volatile uint8_t g_327[1][10][9] = {{{0xDAL,0x95L,0x16L,0x95L,0xDAL,0xBCL,0xDAL,0x95L,0x16L},{0xC6L,0xC6L,246UL,0xBCL,0xC6L,1UL,0xBCL,0xBCL,1UL},{0x3CL,0x95L,0x3CL,2UL,0x33L,0x95L,0x33L,2UL,0x3CL},{0x71L,0UL,0xBCL,0x71L,0x71L,0xBCL,0UL,0x71L,0xC6L},{0UL,2UL,0xDAL,2UL,0UL,0x95L,0UL,2UL,0xDAL},{0x71L,0x71L,0xBCL,0UL,0x71L,0xC6L,0UL,0UL,0xC6L},{0x33L,2UL,0x3CL,2UL,0x33L,0x95L,0x33L,2UL,0x3CL},{0x71L,0UL,0xBCL,0x71L,0x71L,0xBCL,0UL,0x71L,0xC6L},{0UL,2UL,0xDAL,2UL,0UL,0x95L,0UL,2UL,0xDAL},{0x71L,0x71L,0xBCL,0UL,0x71L,0xC6L,0UL,0UL,0xC6L}}};
static volatile uint8_t g_328 = 0x9CL;/* VOLATILE GLOBAL g_328 */
static volatile uint8_t g_329 = 0UL;/* VOLATILE GLOBAL g_329 */
static volatile uint8_t g_330 = 0xC2L;/* VOLATILE GLOBAL g_330 */
static volatile uint8_t g_331 = 0x75L;/* VOLATILE GLOBAL g_331 */
static volatile uint8_t g_332 = 0xA6L;/* VOLATILE GLOBAL g_332 */
static volatile uint8_t g_333 = 0x8CL;/* VOLATILE GLOBAL g_333 */
static volatile uint8_t g_334 = 0x17L;/* VOLATILE GLOBAL g_334 */
static volatile uint8_t g_335[8] = {0x5CL,0x5CL,0x61L,0x5CL,0x5CL,0x61L,0x5CL,0x5CL};
static volatile uint8_t g_336 = 0x83L;/* VOLATILE GLOBAL g_336 */
static volatile uint8_t g_337 = 0x2BL;/* VOLATILE GLOBAL g_337 */
static volatile uint8_t g_338 = 0x98L;/* VOLATILE GLOBAL g_338 */
static volatile uint8_t g_339 = 246UL;/* VOLATILE GLOBAL g_339 */
static volatile uint8_t g_340 = 0UL;/* VOLATILE GLOBAL g_340 */
static volatile uint8_t g_341 = 0xE0L;/* VOLATILE GLOBAL g_341 */
static volatile uint8_t * volatile g_283[8][6][5] = {{{&g_298,&g_338,&g_291[6][0],&g_332,&g_288},{&g_327[0][2][3],&g_325,&g_295,&g_295,&g_325},{&g_323,&g_338,&g_324[3],&g_341,&g_329},{&g_285,&g_316[1],&g_320[0],&g_295,(void*)0},{&g_330,&g_321,&g_341,&g_332,&g_296},{&g_285,(void*)0,(void*)0,&g_337,&g_316[1]}},{{&g_323,&g_288,&g_341,&g_307,&g_304[0]},{&g_327[0][2][3],&g_308,&g_320[0],(void*)0,&g_316[1]},{&g_298,&g_296,&g_324[3],&g_324[3],&g_296},{&g_293[2],&g_308,&g_295,&g_312,(void*)0},{&g_314,&g_288,&g_291[6][0],&g_324[3],&g_329},{&g_302,(void*)0,&g_312,(void*)0,&g_325}},{{&g_314,&g_321,&g_300,&g_307,&g_288},{&g_293[2],&g_316[1],&g_312,&g_337,&g_333},{&g_298,&g_338,&g_291[6][0],&g_332,&g_288},{&g_327[0][2][3],&g_325,&g_295,&g_295,&g_325},{&g_323,&g_338,&g_324[3],&g_341,&g_329},{&g_285,&g_316[1],&g_320[0],&g_295,(void*)0}},{{&g_330,&g_321,&g_341,&g_332,&g_296},{&g_285,(void*)0,(void*)0,&g_337,&g_316[1]},{&g_323,&g_288,&g_341,&g_307,&g_304[0]},{&g_327[0][2][3],&g_308,&g_320[0],(void*)0,&g_316[1]},{&g_298,&g_296,&g_329,&g_329,&g_301},{&g_299,(void*)0,(void*)0,&g_316[1],(void*)0}},{{&g_319[0][4][5],&g_292,&g_296,&g_329,&g_334},{&g_306,&g_297,&g_316[1],&g_308,(void*)0},{&g_319[0][4][5],&g_326,&g_304[0],&g_313,&g_292},{&g_299,&g_322,&g_316[1],&g_284,(void*)0},{&g_303,(void*)0,&g_296,&g_338,&g_292},{&g_331,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_328,(void*)0,&g_329,&g_288,&g_334},{(void*)0,&g_322,&g_325,(void*)0,(void*)0},{&g_336,&g_326,&g_288,&g_338,&g_301},{(void*)0,&g_297,&g_333,&g_284,&g_322},{&g_328,&g_292,&g_288,&g_313,&g_309},{&g_331,(void*)0,&g_325,&g_308,&g_322}},{{&g_303,&g_301,&g_329,&g_329,&g_301},{&g_299,(void*)0,(void*)0,&g_316[1],(void*)0},{&g_319[0][4][5],&g_292,&g_296,&g_329,&g_334},{&g_306,&g_297,&g_316[1],&g_308,(void*)0},{&g_319[0][4][5],&g_326,&g_304[0],&g_313,&g_292},{&g_299,&g_322,&g_316[1],&g_284,(void*)0}},{{&g_303,(void*)0,&g_296,&g_338,&g_292},{&g_331,(void*)0,(void*)0,(void*)0,(void*)0},{&g_328,(void*)0,&g_329,&g_288,&g_334},{(void*)0,&g_322,&g_325,(void*)0,(void*)0},{&g_336,&g_326,&g_288,&g_338,&g_301},{(void*)0,&g_297,&g_333,&g_284,&g_322}}};
static volatile uint8_t g_343 = 6UL;/* VOLATILE GLOBAL g_343 */
static volatile uint8_t *g_342 = &g_343;
static volatile uint8_t * volatile *g_282[8] = {&g_342,&g_283[4][5][4],&g_342,&g_342,&g_283[4][5][4],&g_342,&g_342,&g_283[4][5][4]};
static struct S0 g_351[10] = {{31981},{31981},{31981},{31981},{31981},{31981},{31981},{31981},{31981},{31981}};
static struct S0 *g_350[4] = {&g_351[9],&g_351[9],&g_351[9],&g_351[9]};
static uint8_t g_380 = 248UL;
static uint8_t g_389 = 254UL;
static int8_t g_478 = (-2L);
static int16_t g_515 = 8L;
static int64_t *g_533 = &g_29;
static uint64_t *g_594 = &g_105;
static uint32_t g_656 = 0x342F822FL;
static uint32_t g_732 = 0xB7FCF065L;
static uint32_t g_785 = 0xEA836CD9L;
static int16_t g_837 = 1L;
static uint16_t g_853 = 1UL;
static struct S0 g_919 = {19922};
static volatile int32_t **g_932 = (void*)0;
static uint16_t g_947 = 0xBDD6L;
static volatile struct S0 g_1001 = {27246};/* VOLATILE GLOBAL g_1001 */
static volatile struct S0 * volatile g_1000 = &g_1001;/* VOLATILE GLOBAL g_1000 */
static volatile struct S0 * volatile * volatile g_999 = &g_1000;/* VOLATILE GLOBAL g_999 */
static volatile struct S0 g_1004 = {12768};/* VOLATILE GLOBAL g_1004 */
static volatile struct S0 g_1005 = {1398};/* VOLATILE GLOBAL g_1005 */
static volatile struct S0 * volatile g_1003[6] = {&g_1005,&g_1005,&g_1005,&g_1005,&g_1005,&g_1005};
static volatile struct S0 * volatile * volatile g_1002 = &g_1003[0];/* VOLATILE GLOBAL g_1002 */
static volatile struct S0 * volatile * volatile * const g_998[4] = {&g_1002,&g_1002,&g_1002,&g_1002};
static int32_t *g_1072[8][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int32_t **g_1071 = &g_1072[0][4];
static int32_t g_1178[2][6] = {{1L,0xFA1E403FL,1L,1L,0xFA1E403FL,1L},{1L,0xFA1E403FL,1L,1L,0xFA1E403FL,1L}};
static uint32_t g_1323 = 0xC5D0D805L;
static int64_t g_1485[9][4][2] = {{{3L,(-8L)},{(-1L),0x8FE01B72F7BC348CLL},{2L,0x8FE01B72F7BC348CLL},{(-1L),(-8L)}},{{3L,2L},{(-9L),0L},{(-10L),(-1L)},{0L,(-1L)}},{{0x1820CDD070184DA5LL,0x1820CDD070184DA5LL},{0xCD2DB9C41D0384B0LL,3L},{0xEDF7DB3A4A102F57LL,0x12937AD2AEF501F9LL},{0xB24F4C6627E20429LL,1L}},{{1L,0xB24F4C6627E20429LL},{0L,0L},{0L,0xB24F4C6627E20429LL},{1L,1L}},{{0xB24F4C6627E20429LL,0x12937AD2AEF501F9LL},{0xEDF7DB3A4A102F57LL,3L},{0xCD2DB9C41D0384B0LL,0x1820CDD070184DA5LL},{0x1820CDD070184DA5LL,(-1L)}},{{0L,(-1L)},{(-10L),0L},{(-9L),2L},{3L,(-8L)}},{{(-1L),0x8FE01B72F7BC348CLL},{2L,0x8FE01B72F7BC348CLL},{(-1L),(-8L)},{3L,2L}},{{(-9L),0L},{(-10L),(-1L)},{0L,(-1L)},{0x1820CDD070184DA5LL,0x1820CDD070184DA5LL}},{{0xCD2DB9C41D0384B0LL,3L},{0xEDF7DB3A4A102F57LL,0x12937AD2AEF501F9LL},{0xB24F4C6627E20429LL,1L},{1L,0xB24F4C6627E20429LL}}};
static uint64_t g_1595 = 18446744073709551610UL;
static int32_t g_1606[10][5] = {{(-4L),0x11BF0E06L,9L,(-8L),1L},{1L,(-8L),9L,0x11BF0E06L,(-4L)},{1L,0x11BF0E06L,0x3C2F67D6L,0x11BF0E06L,1L},{(-4L),0x11BF0E06L,9L,(-8L),1L},{1L,(-8L),9L,0x11BF0E06L,(-4L)},{1L,0x11BF0E06L,0x3C2F67D6L,0x11BF0E06L,1L},{(-4L),0x11BF0E06L,9L,(-8L),1L},{1L,(-8L),9L,0x11BF0E06L,(-4L)},{1L,0x11BF0E06L,0x3C2F67D6L,0x11BF0E06L,1L},{(-4L),0x11BF0E06L,9L,(-8L),1L}};
static uint64_t g_1643 = 0xBA23476407E92D8DLL;
static uint8_t * const *g_1647 = (void*)0;
static uint8_t g_1650 = 0xD9L;
static int64_t g_1689 = 0xE5BFAB2AFCFF7F53LL;
static volatile int8_t g_1725 = (-1L);/* VOLATILE GLOBAL g_1725 */
static volatile int8_t *g_1724 = &g_1725;
static volatile int8_t **g_1723 = &g_1724;
static struct S0 **g_1795 = &g_350[1];
static struct S0 ***g_1794 = &g_1795;
static struct S0 ****g_1793[4][4] = {{&g_1794,&g_1794,&g_1794,&g_1794},{&g_1794,&g_1794,&g_1794,&g_1794},{&g_1794,&g_1794,&g_1794,&g_1794},{&g_1794,&g_1794,&g_1794,&g_1794}};
static int64_t g_1846[1][6][6] = {{{0L,(-4L),(-4L),0L,(-2L),1L},{1L,0L,0x601CEBD6FDAD73B4LL,0L,1L,0x5D06B87F541B96E6LL},{0L,1L,0x5D06B87F541B96E6LL,0x5D06B87F541B96E6LL,1L,0L},{(-4L),0L,(-2L),1L,(-2L),0L},{(-2L),(-4L),0x5D06B87F541B96E6LL,0x601CEBD6FDAD73B4LL,0x601CEBD6FDAD73B4LL,0x5D06B87F541B96E6LL},{(-2L),(-2L),(-2L),0x5D06B87F541B96E6LL,0L,0x5D06B87F541B96E6LL}}};
static int64_t *g_1845[8] = {&g_1846[0][0][5],&g_1846[0][0][1],&g_1846[0][0][5],&g_1846[0][0][1],&g_1846[0][0][5],&g_1846[0][0][1],&g_1846[0][0][5],&g_1846[0][0][1]};
static int16_t **g_1907[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static struct S1 g_1973 = {{8992},0x586738C2L};
static int64_t ***g_2036 = (void*)0;
static uint32_t g_2066 = 0x96E8E232L;
static uint32_t g_2138 = 0UL;
static int32_t *g_2156 = &g_53;
static int32_t * const *g_2155[7][6][6] = {{{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,(void*)0,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,(void*)0,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156}},{{&g_2156,&g_2156,&g_2156,(void*)0,(void*)0,(void*)0},{&g_2156,(void*)0,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,(void*)0},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,(void*)0,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,(void*)0,&g_2156}},{{(void*)0,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{(void*)0,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,(void*)0,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,(void*)0,(void*)0,(void*)0,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156}},{{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,(void*)0,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,(void*)0,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,(void*)0,&g_2156},{&g_2156,(void*)0,(void*)0,(void*)0,&g_2156,&g_2156}},{{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,(void*)0},{&g_2156,(void*)0,&g_2156,&g_2156,&g_2156,&g_2156},{(void*)0,&g_2156,&g_2156,&g_2156,(void*)0,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{(void*)0,&g_2156,&g_2156,&g_2156,&g_2156,(void*)0},{(void*)0,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156}},{{&g_2156,(void*)0,(void*)0,&g_2156,(void*)0,&g_2156},{(void*)0,&g_2156,(void*)0,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,(void*)0,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,(void*)0,&g_2156},{&g_2156,(void*)0,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,(void*)0,&g_2156,&g_2156}},{{(void*)0,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{(void*)0,&g_2156,&g_2156,(void*)0,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156},{(void*)0,&g_2156,&g_2156,(void*)0,(void*)0,&g_2156},{&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156}}};
static int32_t * const **g_2154 = &g_2155[3][3][1];
static volatile uint32_t g_2204[1][3] = {{8UL,8UL,8UL}};
static volatile uint32_t g_2205 = 18446744073709551608UL;/* VOLATILE GLOBAL g_2205 */
static volatile uint32_t g_2206 = 18446744073709551609UL;/* VOLATILE GLOBAL g_2206 */
static volatile uint32_t g_2207 = 0UL;/* VOLATILE GLOBAL g_2207 */
static volatile uint32_t g_2208 = 0x660BAAB7L;/* VOLATILE GLOBAL g_2208 */
static volatile uint32_t g_2209 = 0x8A94202EL;/* VOLATILE GLOBAL g_2209 */
static volatile uint32_t g_2210 = 0x22A09F96L;/* VOLATILE GLOBAL g_2210 */
static volatile uint32_t g_2211 = 0xDE6DFE51L;/* VOLATILE GLOBAL g_2211 */
static volatile uint32_t g_2212 = 0x134FAD74L;/* VOLATILE GLOBAL g_2212 */
static volatile uint32_t *g_2203[5][8] = {{&g_2210,&g_2212,&g_2210,&g_2204[0][1],&g_2204[0][1],&g_2210,&g_2212,&g_2210},{&g_2208,&g_2204[0][1],&g_2206,&g_2204[0][1],&g_2208,&g_2208,&g_2204[0][1],&g_2206},{&g_2208,&g_2208,&g_2204[0][1],&g_2206,&g_2204[0][1],&g_2208,&g_2208,&g_2204[0][1]},{&g_2210,&g_2204[0][1],&g_2204[0][1],&g_2210,&g_2212,&g_2210,&g_2204[0][1],&g_2204[0][1]},{&g_2204[0][1],&g_2212,&g_2206,&g_2206,&g_2212,&g_2204[0][1],&g_2212,&g_2206}};
static volatile uint32_t * volatile *g_2202[9][3][8] = {{{(void*)0,(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0]},{&g_2203[0][0],&g_2203[0][4],&g_2203[0][4],&g_2203[0][4],&g_2203[0][0],&g_2203[0][0],(void*)0,(void*)0},{&g_2203[0][0],&g_2203[0][0],(void*)0,(void*)0,(void*)0,&g_2203[0][0],&g_2203[1][4],&g_2203[0][4]}},{{(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0],&g_2203[4][1],&g_2203[0][0],(void*)0,&g_2203[0][4]},{(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[4][1],&g_2203[0][4],&g_2203[0][0],(void*)0},{(void*)0,(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0]}},{{&g_2203[0][0],&g_2203[0][4],&g_2203[0][4],&g_2203[0][4],&g_2203[0][0],&g_2203[0][0],(void*)0,(void*)0},{&g_2203[0][0],&g_2203[0][0],(void*)0,(void*)0,(void*)0,&g_2203[0][0],&g_2203[1][4],&g_2203[0][4]},{(void*)0,&g_2203[0][4],(void*)0,(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0]}},{{(void*)0,&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][4],&g_2203[0][0],(void*)0,(void*)0,&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][4],(void*)0,(void*)0}},{{(void*)0,&g_2203[0][4],(void*)0,(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0]},{(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0]},{(void*)0,&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[1][4],(void*)0}},{{(void*)0,&g_2203[0][0],&g_2203[0][4],&g_2203[0][0],(void*)0,(void*)0,&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][4],(void*)0,(void*)0},{(void*)0,&g_2203[0][4],(void*)0,(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0]}},{{(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0]},{(void*)0,&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][4],&g_2203[0][0],(void*)0,(void*)0,&g_2203[1][4],(void*)0}},{{(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][4],(void*)0,(void*)0},{(void*)0,&g_2203[0][4],(void*)0,(void*)0,(void*)0,&g_2203[0][4],(void*)0,&g_2203[0][0]},{(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0],(void*)0,(void*)0,&g_2203[0][0]}},{{(void*)0,&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][4],&g_2203[0][0],(void*)0,(void*)0,&g_2203[1][4],(void*)0},{(void*)0,&g_2203[0][0],&g_2203[0][0],&g_2203[0][0],(void*)0,&g_2203[0][4],(void*)0,(void*)0}}};
static struct S0 g_2323 = {11849};
static const int32_t g_2364 = 0x3637A6DBL;
static const int32_t g_2366[10] = {0x7DB21E22L,0x7DB21E22L,0xC6D2D0D2L,0x036001AAL,0xC6D2D0D2L,0x7DB21E22L,0x7DB21E22L,0xC6D2D0D2L,0x036001AAL,0xC6D2D0D2L};
static const int32_t *g_2365[2][9][7] = {{{&g_2366[6],&g_2366[1],&g_2366[1],&g_2364,&g_2366[1],&g_2366[1],&g_2366[6]},{&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7]},{&g_2366[6],&g_2364,&g_2366[1],&g_2364,&g_2366[6],(void*)0,&g_2366[6]},{&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6]},{&g_2366[1],&g_2364,&g_2366[1],&g_2366[1],&g_2366[1],(void*)0,&g_2366[1]},{&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7]},{&g_2366[1],(void*)0,&g_2366[1],&g_2366[1],&g_2366[1],(void*)0,&g_2366[1]},{&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1]},{&g_2366[1],&g_2366[1],&g_2366[6],&g_2366[1],&g_2366[1],&g_2364,&g_2366[1]}},{{&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7]},{&g_2366[1],&g_2366[1],&g_2366[1],(void*)0,&g_2366[1],(void*)0,&g_2366[1]},{&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7]},{&g_2366[1],(void*)0,&g_2366[1],&g_2366[1],&g_2366[1],(void*)0,&g_2366[1]},{&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1]},{&g_2366[1],&g_2366[1],&g_2366[6],&g_2366[1],&g_2366[1],&g_2364,&g_2366[1]},{&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7],&g_2366[1],&g_2366[1],&g_2366[7]},{&g_2366[1],&g_2366[1],&g_2366[1],(void*)0,&g_2366[1],(void*)0,&g_2366[1]},{&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7],&g_2366[7],&g_2366[6],&g_2366[7]}}};
static int32_t g_2369[3][2][10] = {{{0x6093D5BDL,0xD8081138L,0x2E545B06L,0x2E545B06L,0xD8081138L,0x6093D5BDL,(-1L),0x6093D5BDL,0xD8081138L,0x2E545B06L},{0L,0x84530420L,0L,0x2E545B06L,(-1L),(-1L),0x2E545B06L,0L,0x84530420L,0L}},{{0L,0x6093D5BDL,0x84530420L,0xD8081138L,0x84530420L,0x6093D5BDL,0L,0L,0x6093D5BDL,0x84530420L},{0x6093D5BDL,0L,0L,0x6093D5BDL,0x84530420L,0xD8081138L,0x84530420L,0x6093D5BDL,0L,0L}},{{0x84530420L,0L,0x2E545B06L,(-1L),(-1L),0x2E545B06L,0L,0x84530420L,0L,0x2E545B06L},{0xD8081138L,0x6093D5BDL,(-1L),0x6093D5BDL,0xD8081138L,0x2E545B06L,0x2E545B06L,0xD8081138L,0x6093D5BDL,(-1L)}}};
static uint8_t g_2400 = 1UL;
static uint32_t *g_2507 = &g_59[2][2];
static int32_t g_2531 = 1L;
static const struct S0 *g_2557 = &g_271[5].f0;
static const struct S0 **g_2556 = &g_2557;
static const struct S0 *** const g_2555 = &g_2556;
static const struct S0 *** const *g_2554 = &g_2555;
static uint32_t *g_2683 = &g_2138;
static int32_t g_2689[4] = {0xC5DC2C40L,0xC5DC2C40L,0xC5DC2C40L,0xC5DC2C40L};
static int32_t * const g_2688 = &g_2689[1];
static int32_t * const *g_2687 = &g_2688;
static uint8_t g_2693 = 0xA9L;
static struct S1 *g_2778[6][4] = {{&g_271[5],&g_1973,&g_271[5],&g_1973},{&g_271[5],&g_1973,&g_271[5],&g_1973},{&g_271[5],&g_1973,&g_271[5],&g_1973},{&g_271[5],&g_1973,&g_271[5],&g_1973},{&g_271[5],&g_1973,&g_271[5],&g_1973},{&g_271[5],&g_1973,&g_271[5],&g_1973}};
static struct S1 ** const g_2777 = &g_2778[2][0];
static const uint8_t g_2792 = 247UL;
static struct S0 * const *g_2820 = (void*)0;
static struct S0 * const **g_2819[10] = {&g_2820,(void*)0,&g_2820,(void*)0,&g_2820,(void*)0,&g_2820,(void*)0,&g_2820,(void*)0};
static uint8_t *g_2900 = &g_120;
static uint8_t **g_2899 = &g_2900;
static struct S0 g_2926 = {23275};
static const uint16_t g_3019 = 2UL;
static uint16_t *g_3021 = (void*)0;
static int32_t g_3039 = 0L;
static int16_t g_3102[2] = {(-2L),(-2L)};
static struct S1 g_3113 = {{14679},0x16420FF1L};
static uint8_t ***g_3149 = &g_2899;
static int32_t ** volatile g_3226 = &g_2156;/* VOLATILE GLOBAL g_3226 */
static uint64_t ** volatile g_3297 = &g_594;/* VOLATILE GLOBAL g_3297 */
static uint64_t ** volatile *g_3296[7][2] = {{&g_3297,&g_3297},{(void*)0,&g_3297},{&g_3297,&g_3297},{&g_3297,&g_3297},{(void*)0,&g_3297},{&g_3297,&g_3297},{(void*)0,&g_3297}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint64_t  func_8(struct S0  p_9, int8_t  p_10, int32_t  p_11, int32_t  p_12, uint16_t  p_13);
static uint64_t  func_23(int64_t  p_24, int8_t  p_25, uint16_t  p_26, uint32_t  p_27, int16_t  p_28);
static uint16_t  func_39(int8_t  p_40, struct S0  p_41, int64_t * p_42);
static int16_t * func_43(int64_t * p_44, uint16_t  p_45, uint32_t  p_46, int16_t * p_47, int8_t  p_48);
static uint16_t  func_50(int16_t * p_51);
static int32_t  func_67(int32_t * p_68);
static int32_t * func_69(int32_t * p_70);
static int32_t  func_74(int16_t * p_75);
static int32_t ** func_77(int16_t * p_78);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18 g_29 g_31 g_33 g_2899 g_2900 g_2687 g_2688 g_594 g_105 g_2777 g_2689 g_3039 g_1723 g_1724 g_1725 g_2156 g_53 g_2507 g_59 g_389 g_533 g_342 g_343 g_2369 g_2366 g_287 g_1650 g_2555 g_2556 g_173 g_101 g_1485 g_178 g_947 g_2554 g_2557 g_271.f0 g_3226 g_1794 g_108 g_64 g_120 g_55 g_181 g_3296
 * writes: g_31 g_33 g_2689 g_2778 g_3039 g_53 g_229 g_101 g_59 g_389 g_3149 g_29 g_178 g_2557 g_173 g_947 g_853 g_2156 g_1795 g_2369 g_1643 g_108 g_120 g_64 g_181 g_2693 g_265
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    struct S0 l_14 = {27391};
    int16_t *l_30 = &g_31;
    int64_t *l_32[6] = {&g_29,&g_29,&g_29,&g_29,&g_29,&g_29};
    int64_t l_3105 = (-2L);
    uint32_t l_3106 = 1UL;
    int32_t l_3316 = 6L;
    int i;
    l_3316 = (safe_add_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u(((safe_div_func_int64_t_s_s(0x37A3A11C15747814LL, 5UL)) , (func_8(l_14, (safe_rshift_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u(((g_18 >= l_14.f0) && l_14.f0))), (safe_mod_func_int64_t_s_s((((safe_mod_func_int64_t_s_s((l_14.f0 | (-1L)), func_23((g_33 |= (((*l_30) |= g_29) | l_14.f0)), g_29, l_14.f0, g_29, l_14.f0))) != 0x64451E21L) || (-3L)), (*g_594))))), l_3105, l_3105, l_3106) && 0x56D9C15525AD1A4ALL)), l_3106)), l_3105));
    return l_3106;
}


/* ------------------------------------------ */
/* 
 * reads : g_2777 g_2688 g_2689 g_3039 g_1723 g_1724 g_1725 g_2156 g_53 g_2507 g_59 g_2687 g_389 g_533 g_29 g_342 g_343 g_2369 g_2366 g_287 g_1650 g_594 g_105 g_2555 g_2556 g_173 g_101 g_1485 g_178 g_947 g_2554 g_2557 g_271.f0 g_3226 g_1794 g_108 g_64 g_120 g_31 g_55 g_33 g_181 g_2900 g_3296
 * writes: g_2778 g_2689 g_3039 g_53 g_229 g_101 g_59 g_389 g_3149 g_29 g_178 g_2557 g_173 g_947 g_853 g_2156 g_1795 g_2369 g_1643 g_108 g_120 g_64 g_181 g_2693 g_265
 */
static uint64_t  func_8(struct S0  p_9, int8_t  p_10, int32_t  p_11, int32_t  p_12, uint16_t  p_13)
{ /* block id: 1328 */
    struct S1 *l_3111 = &g_271[5];
    struct S1 *l_3112 = &g_3113;
    uint32_t **l_3116 = (void*)0;
    uint32_t ***l_3117 = (void*)0;
    uint32_t **l_3118 = &g_2683;
    int32_t ***l_3119 = &g_181[0];
    int32_t ****l_3120 = &g_229;
    const uint32_t *l_3143 = (void*)0;
    uint8_t ***l_3150 = &g_2899;
    int32_t *l_3152 = &g_2689[1];
    int8_t *l_3181 = &g_101;
    int8_t **l_3180 = &l_3181;
    int32_t l_3184[8] = {(-3L),(-8L),(-8L),(-3L),(-8L),(-8L),(-3L),(-8L)};
    int16_t l_3189 = 2L;
    int8_t l_3191 = 1L;
    int32_t l_3193[2];
    int32_t * const l_3224 = &g_2369[0][0][7];
    uint64_t **l_3262 = &g_594;
    uint16_t **l_3311[5][10] = {{(void*)0,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0},{(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0},{&g_3021,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021},{(void*)0,&g_3021,&g_3021,(void*)0,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,(void*)0},{(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0,&g_3021,&g_3021,(void*)0}};
    int32_t **l_3314 = (void*)0;
    int32_t **l_3315 = &g_2156;
    int i, j;
    for (i = 0; i < 2; i++)
        l_3193[i] = 0x7B8E76FCL;
    (*g_2688) ^= (safe_lshift_func_int16_t_s_u((safe_add_func_uint8_t_u_u((((*g_2777) = l_3111) == (l_3112 = l_3111)), p_12)), 1));
    for (g_3039 = (-19); (g_3039 == (-6)); g_3039 = safe_add_func_uint16_t_u_u(g_3039, 3))
    { /* block id: 1334 */
        (*g_2156) ^= ((**g_1723) , p_9.f0);
    }
    if (((((l_3116 = l_3116) == (l_3118 = &g_2683)) , l_3119) == ((*l_3120) = (void*)0)))
    { /* block id: 1340 */
        uint32_t **l_3131 = &g_2683;
        uint32_t ***l_3132 = &l_3118;
        int8_t *l_3133[3];
        int32_t l_3136 = 1L;
        int16_t l_3144 = 0L;
        int32_t *l_3153 = &g_2689[3];
        uint8_t l_3156 = 0x71L;
        int32_t l_3157 = 0L;
        int32_t l_3171 = 0xE1F75F74L;
        int64_t l_3187[2][7];
        int32_t l_3192[4];
        uint32_t l_3232 = 0UL;
        int32_t l_3303 = 1L;
        int i, j;
        for (i = 0; i < 3; i++)
            l_3133[i] = &g_478;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 7; j++)
                l_3187[i][j] = 3L;
        }
        for (i = 0; i < 4; i++)
            l_3192[i] = 0L;
        (*g_2156) = ((**g_2687) = (safe_rshift_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((safe_mod_func_int32_t_s_s(0x95428825L, ((p_9.f0 >= (g_101 = (safe_mod_func_int16_t_s_s(((*g_2507) < (l_3131 != ((*l_3132) = l_3116))), 65528UL)))) , (safe_add_func_uint16_t_u_u((((*g_2507) |= l_3136) & (safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_s((l_3144 = (safe_div_func_uint32_t_u_u((((**g_1723) , l_3143) == &g_732), (-2L)))), l_3136)), l_3136))), p_12))))), 0)), p_9.f0)), 3)));
        for (g_389 = 0; (g_389 <= 8); g_389 = safe_add_func_int8_t_s_s(g_389, 7))
        { /* block id: 1349 */
            uint16_t l_3147 = 0xA666L;
            uint8_t ****l_3148[1][1][1];
            int32_t **l_3151[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t *l_3154 = &g_2369[0][1][7];
            uint16_t *l_3155 = &g_178;
            uint32_t l_3172 = 0UL;
            int32_t *** const *l_3178 = (void*)0;
            int8_t l_3195 = 0L;
            uint16_t l_3196 = 65535UL;
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_3148[i][j][k] = (void*)0;
                }
            }
            l_3157 |= (l_3147 | ((((g_3149 = (void*)0) != (l_3136 , l_3150)) ^ ((((0x51DD43E8304A1884LL <= (p_13 >= (((*g_533) = (*g_533)) | (((*l_3155) = ((((((l_3153 = (l_3152 = &p_11)) == (p_9.f0 , l_3154)) > (*g_342)) <= (*l_3154)) | g_2366[1]) , g_287)) != p_10)))) || (*g_342)) | g_1650) < l_3144)) , l_3156));
            if ((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(65527UL, ((*g_594) & (safe_add_func_uint16_t_u_u((p_11 || (((safe_mul_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(p_13, p_13)), ((0x0DL & (*l_3153)) , 0x21L))) != (*l_3153)) <= p_12)), p_10))))), p_10)))
            { /* block id: 1356 */
                int16_t l_3168 = 0xECB8L;
                int32_t l_3169 = (-1L);
                int32_t l_3170 = (-6L);
                int32_t *l_3175 = &g_2689[0];
                int32_t **l_3176 = &l_3154;
                int8_t **l_3179 = (void*)0;
                int32_t l_3194[10][3][1] = {{{0xA5528012L},{(-1L)},{0x1DA441E2L}},{{(-1L)},{0xA5528012L},{0xCBFE7F72L}},{{0xB2339015L},{7L},{1L}},{{(-8L)},{1L},{7L}},{{0xB2339015L},{0xCBFE7F72L},{0xA5528012L}},{{(-1L)},{0x1DA441E2L},{(-1L)}},{{0xA5528012L},{0xCBFE7F72L},{0xB2339015L}},{{7L},{1L},{(-8L)}},{{1L},{7L},{0xB2339015L}},{{0xCBFE7F72L},{0xA5528012L},{(-1L)}}};
                int64_t l_3219 = (-1L);
                uint32_t l_3222 = 1UL;
                int i, j, k;
                ++l_3172;
                l_3175 = &p_11;
                (*l_3176) = (*g_2687);
                for (g_101 = 0; (g_101 <= 1); g_101 += 1)
                { /* block id: 1362 */
                    int32_t l_3185 = 1L;
                    int32_t l_3186 = (-2L);
                    int32_t l_3188 = 0L;
                    int32_t l_3190[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_3190[i] = 0xE507901EL;
                    (*l_3152) = ((((**g_2687) = ((~p_12) != (0x39FDACCAL == (((void*)0 == l_3178) | 0x95L)))) && ((*l_3153) && ((l_3179 = &l_3133[2]) == l_3180))) , ((safe_add_func_uint8_t_u_u(255UL, 0UL)) , 0x5FE627ACL));
                    for (g_3039 = 0; (g_3039 <= 1); g_3039 += 1)
                    { /* block id: 1368 */
                        (**g_2555) = &p_9;
                    }
                    ++l_3196;
                    for (g_173 = 0; (g_173 <= 7); g_173 += 1)
                    { /* block id: 1374 */
                        uint16_t *l_3214[1][5] = {{&l_3147,&l_3147,&l_3147,&l_3147,&l_3147}};
                        int32_t l_3223 = (-8L);
                        int32_t **l_3225[9][2] = {{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152},{&l_3152,&l_3152}};
                        int i, j, k;
                        (*l_3154) = ((g_1485[g_173][(g_101 + 2)][g_101] <= (((safe_mul_func_uint16_t_u_u((((safe_lshift_func_int16_t_s_u((((safe_add_func_int16_t_s_s(((safe_unary_minus_func_int16_t_s(((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((--(*l_3155)), (g_853 = (++g_947)))), l_3186)) , p_9.f0))) || p_13), (safe_lshift_func_int16_t_s_s((l_3223 &= (safe_rshift_func_uint16_t_u_s(l_3219, ((safe_rshift_func_int8_t_s_s((p_9.f0 < (((*l_3153) ^= ((****g_2554) , (*g_594))) == p_10)), l_3222)) & (*g_2156))))), l_3157)))) == p_13) == 4294967295UL), 6)) == 0x3FL) <= g_1485[g_173][(g_101 + 2)][g_101]), 0x40EAL)) & 0L) && 0x5BL)) <= 0x61997122L);
                        (*g_3226) = l_3224;
                    }
                }
            }
            else
            { /* block id: 1384 */
                struct S0 **l_3229 = &g_350[0];
                int32_t l_3230[1][10] = {{0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL,0xE966114DL}};
                int32_t l_3231 = 6L;
                const int8_t l_3248 = 0x42L;
                int32_t **l_3249 = (void*)0;
                const struct S1 l_3252[2][7][8] = {{{{{13205},0x94A89228L},{{30253},0xE5769D1EL},{{4566},1UL},{{32109},0x805DDBB9L},{{7931},0x97810F6DL},{{5561},18446744073709551610UL},{{32109},0x805DDBB9L},{{8859},0xACD56777L}},{{{7968},18446744073709551615UL},{{3151},0xF76D4104L},{{6852},18446744073709551611UL},{{13873},18446744073709551607UL},{{17057},18446744073709551615UL},{{19685},0x8EA331BDL},{{10438},1UL},{{13205},0x94A89228L}},{{{7931},0x97810F6DL},{{10438},1UL},{{22372},0xF3F0B929L},{{3151},0xF76D4104L},{{22372},0xF3F0B929L},{{10438},1UL},{{7931},0x97810F6DL},{{2703},18446744073709551615UL}},{{{8070},18446744073709551615UL},{{14654},0x53B2C59FL},{{27344},18446744073709551613UL},{{31951},5UL},{{8859},0xACD56777L},{{12466},18446744073709551615UL},{{3151},0xF76D4104L},{{8859},0xACD56777L}},{{{27336},18446744073709551614UL},{{7931},0x97810F6DL},{{17609},0UL},{{27336},18446744073709551614UL},{{10438},1UL},{{28077},0xC620E8F9L},{{19777},0xBFE896D6L},{{6852},18446744073709551611UL}},{{{13873},18446744073709551607UL},{{27344},18446744073709551613UL},{{11544},0x7DABA835L},{{10438},1UL},{{23701},18446744073709551608UL},{{29571},9UL},{{19685},0x8EA331BDL},{{27344},18446744073709551613UL}},{{{27336},18446744073709551614UL},{{26370},7UL},{{8859},0xACD56777L},{{19685},0x8EA331BDL},{{22372},0xF3F0B929L},{{19310},0x00303EDFL},{{5425},0xB5602FC3L},{{5425},0xB5602FC3L}}},{{{{4566},1UL},{{27336},18446744073709551614UL},{{5561},18446744073709551610UL},{{5561},18446744073709551610UL},{{27336},18446744073709551614UL},{{4566},1UL},{{19142},0x4E9556B8L},{{2703},18446744073709551615UL}},{{{23866},0x67939BEBL},{{5561},18446744073709551610UL},{{4566},1UL},{{29167},0x0768B6D5L},{{11544},0x7DABA835L},{{19386},18446744073709551615UL},{{19685},0x8EA331BDL},{{28077},0xC620E8F9L}},{{{19685},0x8EA331BDL},{{13873},18446744073709551607UL},{{14654},0x53B2C59FL},{{29167},0x0768B6D5L},{{6852},18446744073709551611UL},{{7931},0x97810F6DL},{{23866},0x67939BEBL},{{2703},18446744073709551615UL}},{{{19142},0x4E9556B8L},{{6852},18446744073709551611UL},{{30022},0x8CAAA95FL},{{5561},18446744073709551610UL},{{17609},0UL},{{30022},0x8CAAA95FL},{{4566},1UL},{{5425},0xB5602FC3L}},{{{5425},0xB5602FC3L},{{28077},0xC620E8F9L},{{22365},0x1C3A1BD0L},{{19685},0x8EA331BDL},{{4566},1UL},{{27344},18446744073709551613UL},{{27336},18446744073709551614UL},{{27344},18446744073709551613UL}},{{{19685},0x8EA331BDL},{{10438},1UL},{{13205},0x94A89228L},{{10438},1UL},{{19685},0x8EA331BDL},{{17057},18446744073709551615UL},{{13873},18446744073709551607UL},{{6852},18446744073709551611UL}},{{{19777},0xBFE896D6L},{{29167},0x0768B6D5L},{{29571},9UL},{{12466},18446744073709551615UL},{{27336},18446744073709551614UL},{{30022},0x8CAAA95FL},{{12466},18446744073709551615UL},{{10438},1UL}}}};
                int i, j, k;
                for (p_11 = 0; (p_11 != 15); p_11 = safe_add_func_uint32_t_u_u(p_11, 6))
                { /* block id: 1387 */
                    (*g_1794) = l_3229;
                }
                l_3232--;
                if ((p_13 || ((safe_mul_func_uint16_t_u_u(l_3231, ((*g_2507) , (+(l_3231 & (safe_lshift_func_uint8_t_u_u((*l_3152), (((safe_add_func_uint32_t_u_u((((((p_13 , ((safe_div_func_uint8_t_u_u((((safe_mul_func_int8_t_s_s(((void*)0 != &g_2819[3]), p_10)) <= p_10) || l_3248), (*g_342))) != p_13)) && 0x3339L) ^ (*l_3154)) != (*g_2507)) , 4294967295UL), (*l_3224))) , l_3249) == l_3249)))))))) == p_10)))
                { /* block id: 1391 */
                    int32_t **l_3253[7] = {&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156,&g_2156};
                    int16_t *l_3254 = &g_31;
                    uint64_t **l_3260[7];
                    uint64_t l_3276 = 0xFA962B7F10ED4458LL;
                    int i;
                    for (i = 0; i < 7; i++)
                        l_3260[i] = &g_594;
                    (*g_2156) = (*l_3153);
                    for (g_1643 = 0; (g_1643 <= 5); g_1643 = safe_add_func_uint64_t_u_u(g_1643, 5))
                    { /* block id: 1395 */
                        int32_t ***l_3255 = &l_3151[9];
                        uint64_t ***l_3261[4] = {&l_3260[3],&l_3260[3],&l_3260[3],&l_3260[3]};
                        struct S1 l_3263[8][3][3] = {{{{{14440},0x596373B1L},{{15855},0UL},{{31698},0UL}},{{{508},7UL},{{13782},0x024A2B37L},{{14227},0x33E51B87L}},{{{14227},0x33E51B87L},{{23371},0UL},{{13782},0x024A2B37L}}},{{{{19818},8UL},{{1201},0x7E7030BFL},{{8633},0xEE63E898L}},{{{23362},18446744073709551615UL},{{31490},18446744073709551607UL},{{8633},0xEE63E898L}},{{{13782},0x024A2B37L},{{18027},0UL},{{13782},0x024A2B37L}}},{{{{25942},0xF20512D4L},{{2607},0xE2931374L},{{14227},0x33E51B87L}},{{{10548},0UL},{{15352},0x63968E6DL},{{31698},0UL}},{{{760},0xD2825274L},{{508},7UL},{{30977},0xD4E1BCFAL}}},{{{{14777},0xFD550EEDL},{{23362},18446744073709551615UL},{{26395},0x49357667L}},{{{760},0xD2825274L},{{15138},0x9B99492FL},{{6492},0x8D5B876FL}},{{{10548},0UL},{{23202},18446744073709551615UL},{{14930},0xD8DD86BFL}}},{{{{25942},0xF20512D4L},{{19818},8UL},{{1201},0x7E7030BFL}},{{{13782},0x024A2B37L},{{30977},0xD4E1BCFAL},{{15138},0x9B99492FL}},{{{23362},18446744073709551615UL},{{30977},0xD4E1BCFAL},{{31490},18446744073709551607UL}}},{{{{19818},8UL},{{19818},8UL},{{760},0xD2825274L}},{{{14227},0x33E51B87L},{{23202},18446744073709551615UL},{{23362},18446744073709551615UL}},{{{508},7UL},{{15138},0x9B99492FL},{{26623},0x9BAAEDA5L}}},{{{{14440},0x596373B1L},{{23362},18446744073709551615UL},{{23371},0UL}},{{{15855},0UL},{{508},7UL},{{26623},0x9BAAEDA5L}},{{{30977},0xD4E1BCFAL},{{15352},0x63968E6DL},{{23362},18446744073709551615UL}}},{{{{1201},0x7E7030BFL},{{2607},0xE2931374L},{{760},0xD2825274L}},{{{15533},18446744073709551607UL},{{18027},0UL},{{31490},18446744073709551607UL}},{{{26623},0x9BAAEDA5L},{{31490},18446744073709551607UL},{{15138},0x9B99492FL}}}};
                        int i, j, k;
                        p_12 = p_12;
                        p_12 = ((l_3252[1][1][7] , (l_3249 = l_3253[3])) == ((*l_3255) = ((*l_3119) = func_77(l_3254))));
                        p_12 |= (((safe_mul_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(((((((l_3260[5] == (l_3262 = &g_594)) , l_3263[1][1][2]) , ((safe_div_func_int8_t_s_s(((void*)0 == &g_229), p_11)) == ((*l_3155) = (safe_sub_func_int32_t_s_s(((!(safe_mul_func_int16_t_s_s(((*l_3224) > (safe_lshift_func_uint16_t_u_s((((**l_3249) , (((safe_unary_minus_func_uint32_t_u(((*g_2507) = (safe_div_func_uint8_t_u_u(0x92L, (**g_1723)))))) , (**g_3226)) < (**l_3249))) || 8UL), 12))), p_9.f0))) , (**l_3249)), l_3276))))) ^ (*l_3153)) || (*g_594)) , 0x68L), 1L)), p_9.f0)) <= 0L) , p_13);
                        (*l_3224) = p_13;
                    }
                    (**g_3226) = (*g_2156);
                }
                else
                { /* block id: 1408 */
                    uint16_t l_3277 = 0xF422L;
                    for (p_13 = 0; (p_13 <= 5); p_13 += 1)
                    { /* block id: 1411 */
                        return (*g_594);
                    }
                    if (l_3277)
                        continue;
                    (*g_3226) = &l_3192[1];
                }
                for (l_3136 = 0; (l_3136 > 27); l_3136 = safe_add_func_uint32_t_u_u(l_3136, 1))
                { /* block id: 1419 */
                    int32_t l_3302[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_3302[i] = 0x2D56E7B4L;
                    (*g_2156) = ((safe_mod_func_uint8_t_u_u(((~(safe_rshift_func_int16_t_s_u((safe_unary_minus_func_uint8_t_u(((*l_3152) && (((*l_3152) |= (++(*g_2900))) , ((safe_lshift_func_int8_t_s_u((0xE8E34B07L == (safe_rshift_func_uint16_t_u_u((*l_3154), 6))), (g_2693 = ((*g_2900) ^= (((p_11 , (((*g_594) && (((((**l_3180) ^= ((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s(((((*g_533) = (*g_533)) > ((g_3296[4][1] != ((0xCF84C67B7528EB9ELL == (safe_mul_func_int8_t_s_s((((safe_rshift_func_uint16_t_u_s((0xDE682616L | p_10), p_10)) != l_3302[0]) & p_12), (-9L)))) , &g_3297)) >= p_9.f0)) != (*l_3153)), p_9.f0)), 10)) , 0xDAL)) ^ (*g_1724)) > p_12) <= 4294967286UL)) == p_11)) && l_3302[0]) != (-10L)))))) >= l_3302[0]))))), p_13))) , p_9.f0), l_3303)) , p_13);
                    (*l_3224) = 0x2FC08B49L;
                }
            }
        }
    }
    else
    { /* block id: 1431 */
        int32_t *l_3310 = &g_265;
        int32_t l_3313[10];
        int i;
        for (i = 0; i < 10; i++)
            l_3313[i] = (-1L);
        (*l_3224) = ((**g_2687) = ((p_11 != (g_947 = (safe_sub_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((((*l_3181) = (safe_add_func_uint8_t_u_u(255UL, ((*g_1723) == &p_10)))) == 0x18L), ((**g_2556) , (((((*l_3310) = (-1L)) , l_3311[0][9]) != (((~((((p_10 = (0x533AL && (-7L))) < p_11) , (void*)0) == &g_1072[0][4])) && l_3313[2]) , (void*)0)) && (*g_2507))))), (*g_342))))) ^ 18446744073709551612UL));
        return p_11;
    }
    (*l_3315) = (void*)0;
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_2899 g_2900 g_2687 g_2688
 * writes: g_2689
 */
static uint64_t  func_23(int64_t  p_24, int8_t  p_25, uint16_t  p_26, uint32_t  p_27, int16_t  p_28)
{ /* block id: 3 */
    int16_t l_34[4][7] = {{0xF551L,0x289CL,0xCA92L,2L,2L,0xCA92L,0x289CL},{0x6E5DL,(-2L),0L,0x6ED4L,0x6ED4L,0L,(-2L)},{0xF551L,0x289CL,0xCA92L,2L,2L,0xCA92L,0x289CL},{0x6E5DL,(-2L),0L,0x6ED4L,0x6ED4L,0L,(-2L)}};
    const struct S1 l_1836 = {{8519},18446744073709551615UL};
    int8_t *l_3055 = &g_478;
    int64_t l_3057 = 0xE3F57EACDEB8F7A2LL;
    int32_t l_3066[2];
    uint32_t l_3104[1][6] = {{18446744073709551612UL,0xCC6270C2L,0xCC6270C2L,18446744073709551612UL,0x7D865338L,0x7D865338L}};
    int i, j;
    for (i = 0; i < 2; i++)
        l_3066[i] = 1L;
lbl_3103:
    for (p_28 = 3; (p_28 >= 0); p_28 -= 1)
    { /* block id: 6 */
        int64_t *l_49 = &g_29;
        int32_t l_1847 = 2L;
        int16_t *l_2013[4];
        int8_t l_3036 = 0xDCL;
        uint32_t l_3037 = 0xEF332581L;
        int32_t *l_3038 = &g_3039;
        struct S1 l_3046 = {{27166},0x9E703182L};
        uint32_t *l_3056 = &g_59[2][2];
        int32_t l_3067 = 0xEA872D6CL;
        int32_t l_3068 = 0x9DEA8204L;
        int32_t l_3069[2];
        uint32_t l_3070 = 0x18E7FE8FL;
        int i;
        for (i = 0; i < 4; i++)
            l_2013[i] = &g_837;
        for (i = 0; i < 2; i++)
            l_3069[i] = (-1L);
    }
    (**g_2687) = ((*g_2899) == l_3055);
    if (p_28)
        goto lbl_3103;
    return l_3104[0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_29 g_389 g_533 g_1973.f0.f0 g_53 g_173 g_2036 g_380 g_33 g_2066 g_732 g_120 g_1595 g_853 g_101 g_1643 g_2138 g_919.f0 g_2154 g_1485 g_2156 g_178 g_1689 g_837 g_947 g_271.f0.f0 g_1323 g_2202 g_105 g_59 g_1650 g_1178 g_64 g_265 g_1723 g_1724 g_1846 g_1071 g_271.f1 g_2323 g_2507 g_31 g_515 g_2364 g_2366 g_2369 g_2557 g_271.f0 g_2693 g_1072 g_2689 g_656 g_785 g_2777 g_2792 g_2688 g_2687 g_2819 g_2531 g_2899 g_2900 g_3019 g_351.f0
 * writes: g_55 g_101 g_853 g_380 g_2066 g_732 g_1650 g_120 g_178 g_1689 g_29 g_1643 g_478 g_53 g_837 g_947 g_59 g_2138 g_515 g_2507 g_1072 g_105 g_1846 g_2554 g_108 g_33 g_1323 g_2683 g_2155 g_2687 g_1595 g_785 g_2689 g_2693 g_2899 g_3021
 */
static uint16_t  func_39(int8_t  p_40, struct S0  p_41, int64_t * p_42)
{ /* block id: 791 */
    int32_t *l_2014 = &g_55;
    int8_t *l_2017 = &g_101;
    int32_t l_2024 = 3L;
    uint16_t *l_2025 = &g_853;
    int32_t l_2026[1];
    uint32_t l_2080 = 1UL;
    uint16_t l_2130 = 0x6B47L;
    int32_t l_2131 = 0x3C538899L;
    struct S1 l_2185 = {{24868},1UL};
    uint64_t l_2252 = 8UL;
    int32_t *l_2284 = &g_53;
    int32_t *l_2285[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    struct S0 * const l_2322 = &g_2323;
    struct S0 * const *l_2321 = &l_2322;
    struct S0 * const **l_2320 = &l_2321;
    struct S0 * const ***l_2319 = &l_2320;
    int32_t l_2326 = 0x5923CDA1L;
    int32_t **l_2335 = &g_1072[0][4];
    uint32_t l_2370 = 0UL;
    int16_t ***l_2374 = &g_1907[1];
    struct S0 **l_2392[1];
    int16_t *l_2443 = &g_515;
    int16_t **l_2442 = &l_2443;
    uint16_t l_2445 = 0xDADAL;
    int16_t **l_2594 = &l_2443;
    int32_t ****l_2628 = &g_229;
    const uint8_t l_2685 = 0x58L;
    uint32_t l_2730[9][3] = {{1UL,0x86E1E6A5L,0x161F6DF7L},{0x3894AB44L,0x161F6DF7L,5UL},{0x4C5E4DCBL,0x9CB34429L,0x5F938C1AL},{0x161F6DF7L,0x161F6DF7L,0x9CB34429L},{4294967288UL,0x86E1E6A5L,0x31C6678CL},{4294967288UL,0xEEB04213L,0x4C5E4DCBL},{0x161F6DF7L,5UL,0x86E1E6A5L},{0x4C5E4DCBL,4294967288UL,0x4C5E4DCBL},{0x3894AB44L,0UL,0x31C6678CL}};
    uint32_t **l_2749 = &g_2683;
    uint32_t l_2846 = 1UL;
    uint64_t **l_2904 = &g_594;
    uint64_t **l_2905 = &g_594;
    uint64_t l_2917[5][2][5] = {{{18446744073709551607UL,0xDA84BA11D4C09248LL,18446744073709551615UL,0xDA84BA11D4C09248LL,18446744073709551607UL},{18446744073709551606UL,1UL,4UL,1UL,18446744073709551606UL}},{{18446744073709551607UL,0xDA84BA11D4C09248LL,18446744073709551615UL,0xDA84BA11D4C09248LL,18446744073709551607UL},{18446744073709551606UL,1UL,4UL,1UL,18446744073709551606UL}},{{18446744073709551607UL,0xDA84BA11D4C09248LL,18446744073709551615UL,0xDA84BA11D4C09248LL,18446744073709551607UL},{18446744073709551606UL,1UL,4UL,1UL,18446744073709551606UL}},{{18446744073709551607UL,0xDA84BA11D4C09248LL,18446744073709551615UL,0xDA84BA11D4C09248LL,18446744073709551607UL},{18446744073709551606UL,1UL,4UL,1UL,18446744073709551606UL}},{{18446744073709551607UL,0xDA84BA11D4C09248LL,18446744073709551615UL,0xDA84BA11D4C09248LL,18446744073709551607UL},{18446744073709551606UL,1UL,4UL,1UL,18446744073709551606UL}}};
    int64_t l_2950 = 1L;
    const uint32_t ***l_2977 = (void*)0;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2026[i] = 0x0E4B39D8L;
    for (i = 0; i < 1; i++)
        l_2392[i] = &g_350[1];
    l_2014 = l_2014;
lbl_2060:
    (*l_2014) &= 0x6B5B4064L;
    if (((safe_lshift_func_uint16_t_u_u((0x8545L ^ (((0x7FL && ((*l_2014) ^= 0x47L)) || (*p_42)) > ((*l_2017) = g_389))), (18446744073709551615UL < ((safe_add_func_int16_t_s_s(((safe_add_func_uint16_t_u_u(((safe_div_func_int64_t_s_s((-6L), (*g_533))) , ((*l_2025) = ((l_2024 ^= 0x125703AC1E481820LL) >= 0x2EC0728EE8199313LL))), g_1973.f0.f0)) , 0x0984L), p_41.f0)) & l_2026[0])))) & g_53))
    { /* block id: 798 */
        uint64_t l_2027 = 0xBAA59859598449BBLL;
        int32_t *** const *l_2046 = &g_229;
        const struct S0 *l_2055 = &g_351[9];
        const struct S0 * const *l_2054 = &l_2055;
        const struct S0 * const * const *l_2053 = &l_2054;
        int32_t l_2061 = 0xC3BE4D2EL;
        uint8_t *l_2125 = &g_1650;
        int32_t * const **l_2157 = &g_2155[3][3][1];
        int64_t *l_2187 = &g_1846[0][3][3];
        int16_t *l_2197[1][3];
        int64_t *l_2220 = &g_1846[0][0][1];
        int64_t *l_2221 = &g_29;
        int32_t **l_2232[8][4][1] = {{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}},{{&g_1072[7][1]},{&g_1072[0][4]},{&g_1072[7][1]},{&g_1072[4][0]}}};
        int32_t l_2239 = 1L;
        int32_t l_2240 = 7L;
        int32_t l_2241 = 1L;
        int32_t l_2242 = 0L;
        int64_t l_2243[1][7][10] = {{{0x9CBA2A40C2F9D388LL,0x6BF2981780260902LL,(-6L),(-6L),0x6BF2981780260902LL,0x9CBA2A40C2F9D388LL,0x1F125C079328FC13LL,6L,0x90AA1D00EA30B939LL,0xF45FEC5EDADCAE67LL},{1L,0xF45FEC5EDADCAE67LL,0xC4B0AB40E1F4C7ECLL,0x265CE875F06EAE6FLL,6L,0x265CE875F06EAE6FLL,0xC4B0AB40E1F4C7ECLL,0xF45FEC5EDADCAE67LL,1L,0x9CBA2A40C2F9D388LL},{1L,(-6L),0x211C9CE7916CAB44LL,0x1F125C079328FC13LL,0x265CE875F06EAE6FLL,0x9CBA2A40C2F9D388LL,0x9CBA2A40C2F9D388LL,0x265CE875F06EAE6FLL,0x1F125C079328FC13LL,0x211C9CE7916CAB44LL},{0x9CBA2A40C2F9D388LL,0x9CBA2A40C2F9D388LL,0x265CE875F06EAE6FLL,0x1F125C079328FC13LL,0x211C9CE7916CAB44LL,(-6L),1L,1L,1L,(-6L)},{0xC4B0AB40E1F4C7ECLL,0x265CE875F06EAE6FLL,6L,0x265CE875F06EAE6FLL,0xC4B0AB40E1F4C7ECLL,0xF45FEC5EDADCAE67LL,1L,0x9CBA2A40C2F9D388LL,0x90AA1D00EA30B939LL,0x90AA1D00EA30B939LL},{0x1F125C079328FC13LL,0x9CBA2A40C2F9D388LL,0x6BF2981780260902LL,(-6L),(-6L),0x6BF2981780260902LL,0x9CBA2A40C2F9D388LL,0x1F125C079328FC13LL,6L,0x90AA1D00EA30B939LL},{1L,(-6L),0x9CBA2A40C2F9D388LL,0xE22444F73E317183LL,0xC4B0AB40E1F4C7ECLL,1L,0xC4B0AB40E1F4C7ECLL,0xE22444F73E317183LL,0x9CBA2A40C2F9D388LL,(-6L)}}};
        uint16_t l_2246 = 65527UL;
        int32_t **l_2267 = &l_2014;
        uint8_t **l_2276 = &l_2125;
        uint8_t ***l_2275[4][5][9] = {{{&l_2276,(void*)0,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276},{(void*)0,&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276,&l_2276},{&l_2276,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276},{&l_2276,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276,&l_2276},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0}},{{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,(void*)0,(void*)0},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276}},{{&l_2276,(void*)0,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276},{(void*)0,(void*)0,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0,&l_2276},{&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276},{&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276},{(void*)0,(void*)0,(void*)0,(void*)0,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276}},{{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276},{&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0,(void*)0},{&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,&l_2276,(void*)0},{&l_2276,&l_2276,&l_2276,(void*)0,&l_2276,(void*)0,(void*)0,&l_2276,(void*)0}}};
        int64_t l_2278[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
        uint64_t l_2316 = 0x9905F422769E1A92LL;
        uint64_t l_2344 = 0x37ADA24BC7D6E88ELL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_2197[i][j] = &g_837;
        }
        if (l_2027)
        { /* block id: 799 */
            int64_t * const *l_2035 = &g_1845[2];
            int64_t * const ** const l_2034[4][4][8] = {{{&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0,&l_2035},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035},{&l_2035,&l_2035,(void*)0,&l_2035,&l_2035,&l_2035,(void*)0,(void*)0}},{{&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0,&l_2035},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035},{&l_2035,&l_2035,(void*)0,&l_2035,&l_2035,&l_2035,(void*)0,(void*)0}},{{&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0,&l_2035},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035},{&l_2035,&l_2035,(void*)0,&l_2035,&l_2035,&l_2035,(void*)0,(void*)0}},{{&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0,&l_2035},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,(void*)0},{(void*)0,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035,&l_2035},{&l_2035,&l_2035,(void*)0,&l_2035,&l_2035,&l_2035,(void*)0,(void*)0}}};
            uint16_t l_2037 = 0UL;
            int32_t l_2062 = 1L;
            int32_t l_2063 = 0x49D68080L;
            int32_t l_2064 = (-6L);
            int16_t l_2096 = 0xFFB1L;
            uint16_t l_2099 = 7UL;
            uint64_t *l_2135 = &g_1643;
            const int32_t **l_2153 = (void*)0;
            const int32_t *** const l_2152[6][3] = {{&l_2153,(void*)0,(void*)0},{(void*)0,&l_2153,&l_2153},{&l_2153,(void*)0,(void*)0},{(void*)0,&l_2153,&l_2153},{&l_2153,(void*)0,(void*)0},{(void*)0,&l_2153,&l_2153}};
            int8_t *l_2158 = &g_478;
            int i, j, k;
lbl_2059:
            (*l_2014) = (safe_mod_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((0xE8D8F5CFDF70CD6ALL > ((void*)0 != l_2017)), ((0x4A91CBEEL & (8L != g_173)) <= (p_40 != ((l_2027 , l_2034[0][2][0]) != g_2036))))) <= l_2027), l_2037));
            if (g_55)
                goto lbl_2132;
            if (p_40)
            { /* block id: 801 */
                int32_t *l_2056[7] = {&l_2024,&l_2024,&l_2024,&l_2024,&l_2024,&l_2024,&l_2024};
                int16_t l_2065 = (-6L);
                int i;
                for (l_2024 = 0; (l_2024 != 14); l_2024 = safe_add_func_uint8_t_u_u(l_2024, 2))
                { /* block id: 804 */
                    int8_t **l_2040 = &l_2017;
                    int32_t l_2041 = 0x66DA40D0L;
                    int32_t l_2047 = 7L;
                    uint8_t *l_2051 = &g_380;
                    struct S0 ***l_2052[1][10][2] = {{{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795},{&g_1795,&g_1795}}};
                    int i, j, k;
                    if (p_41.f0)
                        break;
                    if (l_2037)
                        goto lbl_2069;
                    if ((((((*l_2025) = (&g_1724 == l_2040)) || (l_2041 ^ (l_2041 , (p_40 ^ ((+((*l_2051) &= (((safe_sub_func_uint16_t_u_u(0x32D4L, ((l_2047 |= (+((void*)0 != l_2046))) ^ ((safe_rshift_func_int16_t_s_s((safe_unary_minus_func_uint32_t_u(4294967290UL)), 6)) , p_40)))) , p_40) && 0xB7L))) && p_41.f0))))) < l_2027) >= p_41.f0))
                    { /* block id: 809 */
                        int32_t **l_2057 = (void*)0;
                        int32_t **l_2058 = &l_2056[6];
                        (*l_2014) = p_41.f0;
                        (*l_2058) = l_2056[6];
                        if (p_41.f0)
                            goto lbl_2059;
                        return g_33;
                    }
                    else
                    { /* block id: 814 */
                        (*l_2014) = l_2047;
                        if (l_2024)
                            goto lbl_2060;
                        return p_41.f0;
                    }
                }
                --g_2066;
lbl_2069:
                l_2062 = p_40;
                for (g_732 = 0; (g_732 <= 7); g_732 += 1)
                { /* block id: 825 */
                    int32_t *l_2072 = &l_2026[0];
                    int32_t l_2095[9] = {0x5982345AL,0xE5957408L,0x5982345AL,0xE5957408L,0x5982345AL,0xE5957408L,0x5982345AL,0xE5957408L,0x5982345AL};
                    int64_t l_2097[6] = {0xA2A6BF8017D094D5LL,0xA2A6BF8017D094D5LL,0xA2A6BF8017D094D5LL,0xA2A6BF8017D094D5LL,0xA2A6BF8017D094D5LL,0xA2A6BF8017D094D5LL};
                    int i;
                    if ((safe_mod_func_uint16_t_u_u(((void*)0 == &g_932), g_55)))
                    { /* block id: 826 */
                        int32_t *l_2073 = &l_2026[0];
                        l_2073 = &l_2062;
                    }
                    else
                    { /* block id: 828 */
                        uint8_t *l_2081[2];
                        int32_t l_2088 = 0xA690B031L;
                        uint16_t *l_2089 = (void*)0;
                        uint16_t *l_2090 = (void*)0;
                        uint16_t *l_2091 = &g_178;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2081[i] = &g_120;
                        (*l_2072) |= ((safe_rshift_func_int16_t_s_s((((((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(((g_1650 = l_2080) != (--g_120)), p_40)), (((*l_2091) = ((safe_mul_func_uint16_t_u_u((((*l_2014) = (g_389 > p_41.f0)) == 0xEBL), 0xDB72L)) == ((safe_mul_func_int16_t_s_s(p_41.f0, (l_2088 , ((*l_2025) |= g_1595)))) | (-5L)))) , p_40))) || p_41.f0) >= 7UL) == (*p_42)) | g_101), 11)) , p_40);
                        return (*l_2014);
                    }
                    for (g_1689 = 6; (g_1689 >= 0); g_1689 -= 1)
                    { /* block id: 839 */
                        int32_t *l_2092 = (void*)0;
                        int32_t **l_2093 = (void*)0;
                        int32_t **l_2094 = &l_2056[1];
                        int32_t l_2098[9] = {0x8EC76D0BL,(-3L),(-3L),0x8EC76D0BL,(-3L),(-3L),0x8EC76D0BL,(-3L),(-3L)};
                        int i;
                        l_2092 = l_2092;
                        (*l_2094) = (l_2072 = l_2072);
                        ++l_2099;
                    }
                }
            }
            else
            { /* block id: 846 */
                uint8_t l_2104[3][7] = {{251UL,255UL,255UL,251UL,255UL,255UL,251UL},{255UL,251UL,255UL,255UL,251UL,255UL,255UL},{251UL,251UL,247UL,251UL,251UL,247UL,251UL}};
                int32_t l_2105 = (-8L);
                uint8_t **l_2126 = &l_2125;
                struct S0 l_2127 = {3794};
                uint8_t *l_2128 = &g_380;
                int i, j;
                l_2105 ^= (safe_sub_func_uint64_t_u_u(l_2099, l_2104[1][3]));
                for (g_853 = 0; (g_853 <= 3); g_853 += 1)
                { /* block id: 850 */
                    return p_41.f0;
                }
                (*l_2014) = (safe_lshift_func_uint16_t_u_s((g_178 = (safe_div_func_uint16_t_u_u(((p_40 >= (safe_sub_func_int64_t_s_s((safe_lshift_func_int8_t_s_u((safe_sub_func_uint8_t_u_u((((*g_533) = (!(((safe_rshift_func_uint16_t_u_s(((*l_2025) = (safe_rshift_func_uint16_t_u_s((safe_add_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u(((((((p_40 | p_40) || 0x60L) || ((*l_2128) = (((*l_2126) = l_2125) != (l_2127 , &g_120)))) , 0x85L) < (safe_unary_minus_func_uint64_t_u(0x361D10DBA7127844LL))) & (*l_2014)), l_2104[0][6])) , l_2130), l_2061)), 10))), 14)) <= p_41.f0) , p_41.f0))) <= p_40), 1UL)), 2)), l_2131))) != p_41.f0), p_41.f0))), p_40));
            }
lbl_2132:
            if (g_29)
                goto lbl_2060;
            (*g_2156) = (l_2099 == (safe_sub_func_uint64_t_u_u((++(*l_2135)), (g_2138 != (~((*l_2158) = (safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((*l_2014), 2)), (((safe_lshift_func_uint8_t_u_s(246UL, (safe_mod_func_uint8_t_u_u(((*l_2125) = ((p_41.f0 >= g_919.f0) > (safe_sub_func_uint16_t_u_u(p_40, ((safe_mod_func_int8_t_s_s(((*l_2017) = ((l_2152[3][2] == (l_2157 = g_2154)) | (-9L))), p_41.f0)) || p_40))))), p_41.f0)))) > 0x606D81BECDC2CE07LL) , g_1485[4][2][1])))))))));
        }
        else
        { /* block id: 868 */
            int64_t *l_2186[6];
            int32_t l_2188 = 0x8540711CL;
            int32_t l_2191 = 0x20BC6453L;
            int i;
            for (i = 0; i < 6; i++)
                l_2186[i] = &g_29;
            for (g_178 = 0; (g_178 == 50); g_178 = safe_add_func_int16_t_s_s(g_178, 9))
            { /* block id: 871 */
                uint32_t l_2192[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_2192[i] = 0x2BB2ECFCL;
                for (g_1689 = 24; (g_1689 >= 3); g_1689 = safe_sub_func_uint64_t_u_u(g_1689, 1))
                { /* block id: 874 */
                    int32_t l_2189 = 0x5396B1E7L;
                    for (g_837 = 5; (g_837 == 28); g_837 = safe_add_func_uint8_t_u_u(g_837, 9))
                    { /* block id: 877 */
                        uint16_t *l_2173 = &g_947;
                        uint16_t l_2178[10] = {0x60ECL,6UL,0x32ECL,6UL,0x60ECL,0x60ECL,6UL,0x32ECL,6UL,0x60ECL};
                        int16_t *l_2190[10] = {&g_515,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515};
                        int i;
                        (*g_2156) ^= (p_40 != (((safe_mod_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((((*l_2017) = (safe_lshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((((*l_2025) ^= 0x120FL) > ((*l_2173)--)), (safe_sub_func_uint64_t_u_u((l_2178[1] || (-7L)), p_41.f0)))), (((1L >= (((l_2178[3] > (l_2191 &= (safe_mod_func_int8_t_s_s(((safe_mul_func_int16_t_s_s(((((*l_2125) = (((*l_2014) = (safe_lshift_func_int16_t_s_u(((l_2185 , l_2186[2]) == l_2187), p_40))) & 252UL)) > l_2188) || p_40), g_271[5].f0.f0)) && p_41.f0), l_2189)))) , 0x71FC80B9ED7E2A8ELL) > 0x17C257CFEDAB74C8LL)) | p_40) != p_40)))) == p_41.f0), p_41.f0)), p_41.f0)) <= g_1689) == 5UL));
                        if (p_40)
                            continue;
                    }
                    l_2192[0] ^= p_40;
                    if (p_41.f0)
                        continue;
                }
                return p_41.f0;
            }
            return p_41.f0;
        }
        (*l_2014) &= ((*g_2156) = (+p_41.f0));
        if (((*l_2014) = ((*g_2156) = (safe_add_func_uint16_t_u_u(((g_1323 ^ 4294967292UL) ^ 1L), (+((18446744073709551614UL == (((((*l_2014) >= 0x57L) & (*p_42)) >= (l_2061 = p_40)) <= ((((((((safe_div_func_int64_t_s_s((safe_mod_func_int64_t_s_s((*p_42), (*p_42))), (-2L))) <= 0xA2L) > p_40) < 18446744073709551615UL) , (void*)0) == g_2202[2][0][4]) != (*p_42)) , g_178))) != g_2066)))))))
        { /* block id: 899 */
            uint32_t *l_2233 = &g_59[2][2];
            int32_t l_2234 = (-1L);
            int32_t l_2244 = (-1L);
            int32_t l_2245 = 0x00FDFE24L;
            uint64_t *l_2268 = &l_2252;
            uint8_t **l_2274 = &l_2125;
            uint8_t ***l_2273[9];
            uint8_t ****l_2277 = &l_2275[2][4][4];
            int i;
            for (i = 0; i < 9; i++)
                l_2273[i] = &l_2274;
            if ((g_105 == (((*g_2156) = (safe_rshift_func_uint16_t_u_u(((((0x23B16889L >= (g_59[5][2] || ((safe_lshift_func_uint8_t_u_u((+(safe_mul_func_int16_t_s_s((p_42 != (l_2221 = l_2220)), ((safe_mul_func_int8_t_s_s(p_41.f0, ((safe_add_func_uint32_t_u_u((*l_2014), ((safe_mod_func_uint32_t_u_u(((*l_2233) ^= ((p_41.f0 , ((safe_mul_func_uint8_t_u_u((g_120 = ((*l_2125) &= (safe_rshift_func_int16_t_s_u((((p_40 ^ p_41.f0) , (void*)0) == l_2232[1][0][0]), (*l_2014))))), (*l_2014))) != (*p_42))) >= p_41.f0)), g_1178[1][1])) , p_40))) | p_41.f0))) > g_271[5].f0.f0)))), l_2234)) == g_178))) == 0x6EL) , 0x2136E032L) & 0x63FD6A91L), p_41.f0))) >= p_41.f0)))
            { /* block id: 905 */
                int32_t l_2235 = 8L;
                int32_t l_2236 = 0x9551D2B7L;
                int32_t *l_2237 = &l_2024;
                int32_t *l_2238[5];
                int i;
                for (i = 0; i < 5; i++)
                    l_2238[i] = (void*)0;
                ++l_2246;
            }
            else
            { /* block id: 907 */
                uint64_t l_2251 = 0UL;
                (*g_2156) &= ((0x0E2C3B95L == g_29) > (safe_rshift_func_int8_t_s_s(((*l_2017) = 0L), (((l_2251 == 0x3E14L) >= (l_2252 ^= (*l_2014))) < (p_41.f0 <= (safe_rshift_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u((((safe_mod_func_uint8_t_u_u(1UL, l_2251)) >= g_64) & 0L), 15)) | (-10L)), 1)))))));
            }
            (**l_2267) = (((*l_2233) = (safe_rshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((((**l_2276) &= ((l_2234 || (255UL >= ((((safe_mod_func_int32_t_s_s(((safe_mod_func_uint64_t_u_u((((*l_2017) = (&l_2014 != l_2267)) && (g_265 > (((*l_2268)--) && ((*l_2268) = ((safe_add_func_int16_t_s_s(((((*g_1723) == ((l_2273[5] == ((*l_2277) = l_2275[1][2][3])) , &p_40)) <= (*l_2014)) && p_40), g_947)) , 0x5D77279CE2A7E80ELL))))), g_853)) == l_2278[3]), p_41.f0)) < p_41.f0) , (void*)0) == &l_2244))) || (*l_2014))) | 1L) , (**l_2267)), (*l_2014))), p_40))) & 0x7FBBEC57L);
            (*l_2267) = (void*)0;
            l_2234 &= (-1L);
        }
        else
        { /* block id: 921 */
            int32_t *l_2283 = &g_173;
            int64_t *l_2302[5][8][6] = {{{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0]},{&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0],&g_29,&g_1485[8][2][1],&g_1485[5][3][1]},{&g_1846[0][0][1],&l_2243[0][4][2],&g_1485[5][2][0],&l_2278[3],&l_2278[3],&g_1485[5][2][0]},{&l_2243[0][5][8],&l_2243[0][5][8],&g_1485[5][3][1],&g_1485[8][2][1],&g_29,&g_1485[5][2][0]},{&g_1485[8][2][1],&g_29,&g_1485[5][2][0],&g_1846[0][0][1],&g_1846[0][3][4],&g_1485[5][3][1]},{&l_2243[0][4][2],&g_1485[8][2][1],&g_1485[5][2][0],&l_2278[3],&l_2243[0][5][8],&g_1485[5][2][0]},{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][2][0]},{&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][2][0],&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][3][1]}},{{&g_29,&g_1846[0][3][4],&g_1485[5][2][0],&l_2243[0][5][8],&l_2278[3],&g_1485[5][2][0]},{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0]},{&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0],&g_29,&g_1485[8][2][1],&g_1485[5][3][1]},{&g_1846[0][0][1],&l_2243[0][4][2],&g_1485[5][2][0],&l_2278[3],&l_2278[3],&g_1485[5][2][0]},{&l_2243[0][5][8],&l_2243[0][5][8],&g_1485[5][3][1],&g_1485[8][2][1],&g_29,&g_1485[5][2][0]},{&g_1485[8][2][1],&g_29,&g_1485[5][2][0],&g_1846[0][0][1],&g_1846[0][3][4],&g_1485[5][3][1]},{&l_2243[0][4][2],&g_1485[8][2][1],&g_1485[5][2][0],&l_2278[3],&l_2243[0][5][8],&g_1485[5][2][0]},{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][2][0]}},{{&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][2][0],&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][3][1]},{&g_29,&g_1846[0][3][4],&g_1485[5][2][0],&l_2243[0][5][8],&l_2278[3],&g_1485[5][2][0]},{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0]},{&g_1846[0][3][4],&g_1846[0][0][1],&g_1485[5][2][0],&g_29,&g_1485[8][2][1],&g_1485[5][3][1]},{&g_1846[0][0][1],&l_2243[0][4][2],&g_1485[5][2][0],&l_2278[3],&l_2278[3],&g_1485[5][2][0]},{&l_2243[0][5][8],&l_2243[0][5][8],&g_1485[5][3][1],&g_1485[8][2][1],&g_29,&g_1485[5][2][0]},{&g_1485[8][2][1],&g_29,&g_1485[5][2][0],&g_1846[0][0][1],&g_1846[0][3][4],&g_1485[5][3][1]},{&l_2243[0][4][2],&g_1485[8][2][1],&g_1485[5][2][0],&l_2278[3],&l_2243[0][5][8],&g_1485[5][2][0]}},{{&l_2278[3],&l_2278[3],&g_1485[5][3][1],&l_2243[0][4][2],&l_2243[0][4][2],&g_1485[5][2][0]},{&g_1846[0][0][1],&l_2278[3],&l_2278[3],&l_2278[3],&g_1846[0][0][1],&l_2278[3]},{&g_1485[3][3][1],&l_2243[0][4][2],&l_2278[3],&g_1846[0][0][5],(void*)0,&l_2278[3]},{(void*)0,&l_2278[8],&l_2278[3],&l_2243[0][4][2],(void*)0,&l_2278[3]},{&l_2243[0][4][2],(void*)0,&l_2278[3],&g_1485[3][3][1],&g_1846[0][0][1],&l_2278[3]},{(void*)0,&g_1846[0][0][1],&l_2278[3],&l_2278[8],&l_2278[8],&l_2278[3]},{&g_1846[0][0][5],&g_1846[0][0][5],&l_2278[3],&g_1846[0][0][1],&g_1485[3][3][1],&l_2278[3]},{&g_1846[0][0][1],&g_1485[3][3][1],&l_2278[3],(void*)0,&l_2243[0][4][2],&l_2278[3]}},{{&l_2278[3],&g_1846[0][0][1],&l_2278[3],(void*)0,&g_1846[0][0][5],&l_2278[3]},{&l_2278[8],(void*)0,&l_2278[3],&g_1846[0][0][1],&l_2278[3],&l_2278[3]},{&g_1846[0][0][1],&l_2278[3],&l_2278[3],&l_2278[3],&g_1846[0][0][1],&l_2278[3]},{&g_1485[3][3][1],&l_2243[0][4][2],&l_2278[3],&g_1846[0][0][5],(void*)0,&l_2278[3]},{(void*)0,&l_2278[8],&l_2278[3],&l_2243[0][4][2],(void*)0,&l_2278[3]},{&l_2243[0][4][2],(void*)0,&l_2278[3],&g_1485[3][3][1],&g_1846[0][0][1],&l_2278[3]},{(void*)0,&g_1846[0][0][1],&l_2278[3],&l_2278[8],&l_2278[8],&l_2278[3]},{&g_1846[0][0][5],&g_1846[0][0][5],&l_2278[3],&g_1846[0][0][1],&g_1485[3][3][1],&l_2278[3]}}};
            int16_t ** const *l_2375 = (void*)0;
            int32_t *l_2384 = (void*)0;
            struct S0 l_2385[6][6][3] = {{{{14957},{19644},{23138}},{{8170},{9516},{2321}},{{30533},{14957},{23138}},{{14720},{11921},{23138}},{{9516},{8170},{2321}},{{11921},{22342},{23138}}},{{{22342},{30533},{23138}},{{16365},{16365},{2321}},{{19644},{14720},{23138}},{{14957},{19644},{23138}},{{8170},{9516},{2321}},{{30533},{14957},{23138}}},{{{14720},{11921},{23138}},{{9516},{8170},{2321}},{{11921},{22342},{23138}},{{22342},{30533},{23138}},{{16365},{16365},{2321}},{{19644},{14720},{23138}}},{{{14957},{19644},{23138}},{{8170},{9516},{2321}},{{30533},{14957},{23138}},{{14720},{11921},{23138}},{{9516},{8170},{2321}},{{11921},{22342},{23138}}},{{{22342},{30533},{23138}},{{16365},{16365},{2321}},{{19644},{14720},{23138}},{{14957},{19644},{23138}},{{8170},{9516},{2321}},{{30533},{14957},{23138}}},{{{14720},{11921},{23138}},{{9516},{8170},{2321}},{{11921},{22342},{23138}},{{22342},{30533},{8170}},{{17626},{17626},{9516}},{{23019},{31749},{8170}}}};
            int32_t *l_2387 = &l_2326;
            struct S0 **l_2391 = &g_350[3];
            struct S1 *l_2405[8][2] = {{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]},{&g_271[5],&g_271[5]}};
            int i, j, k;
            for (l_2024 = 0; (l_2024 == (-7)); l_2024 = safe_sub_func_int8_t_s_s(l_2024, 9))
            { /* block id: 924 */
                int8_t l_2288 = 5L;
                int32_t *l_2338[10][7][1] = {{{&g_1606[8][1]},{(void*)0},{(void*)0},{(void*)0},{&g_1606[8][1]},{(void*)0},{&l_2026[0]}},{{&l_2024},{(void*)0},{&l_2239},{(void*)0},{&l_2024},{&l_2026[0]},{(void*)0}},{{&g_1606[8][1]},{(void*)0},{(void*)0},{(void*)0},{&g_1606[8][1]},{(void*)0},{&l_2026[0]}},{{&l_2024},{(void*)0},{&l_2239},{(void*)0},{&l_2024},{&l_2026[0]},{(void*)0}},{{&g_1606[8][1]},{(void*)0},{(void*)0},{(void*)0},{&g_1606[8][1]},{(void*)0},{&l_2026[0]}},{{&l_2024},{(void*)0},{&l_2239},{(void*)0},{&l_2024},{&l_2026[0]},{(void*)0}},{{&g_1606[8][1]},{(void*)0},{(void*)0},{(void*)0},{&g_1606[8][1]},{(void*)0},{&l_2026[0]}},{{&l_2024},{(void*)0},{&l_2239},{(void*)0},{&l_2024},{&l_2026[0]},{(void*)0}},{{&g_1606[8][1]},{(void*)0},{(void*)0},{(void*)0},{&g_1606[8][1]},{(void*)0},{&l_2026[0]}},{{&l_2024},{(void*)0},{&l_2239},{(void*)0},{&l_2024},{&l_2026[0]},{(void*)0}}};
                uint64_t l_2380 = 0xE5ECAD325959E639LL;
                uint8_t *l_2397 = &g_389;
                int i, j, k;
            }
        }
    }
    else
    { /* block id: 1005 */
        int32_t l_2418 = 0xCFE4809BL;
        uint8_t *l_2437 = &g_1650;
        int16_t *l_2439 = &g_515;
        int16_t **l_2438[9][7] = {{&l_2439,&l_2439,&l_2439,(void*)0,&l_2439,&l_2439,(void*)0},{&l_2439,&l_2439,&l_2439,&l_2439,(void*)0,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,(void*)0,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439,&l_2439},{&l_2439,&l_2439,&l_2439,&l_2439,(void*)0,&l_2439,&l_2439}};
        int16_t ***l_2440 = &g_108;
        int16_t ***l_2441[3][9][6] = {{{&g_1907[6],&l_2438[0][0],&l_2438[0][0],&g_1907[6],&g_1907[1],&g_1907[1]},{&l_2438[0][0],&l_2438[6][0],&l_2438[8][5],(void*)0,&l_2438[0][1],&g_108},{(void*)0,&g_1907[0],&g_1907[1],&l_2438[0][0],&l_2438[0][1],&g_1907[3]},{&g_108,&l_2438[6][0],&l_2438[0][0],&g_1907[1],&g_1907[1],&g_1907[1]},{&l_2438[5][5],&l_2438[0][0],&l_2438[0][0],&g_108,(void*)0,&l_2438[1][3]},{&g_1907[0],&g_1907[0],&g_1907[6],(void*)0,&l_2438[0][0],&l_2438[1][3]},{(void*)0,&g_1907[1],&g_108,&g_1907[1],&g_1907[3],&g_1907[1]},{&g_1907[3],&g_1907[1],&l_2438[8][5],&g_1907[0],&g_1907[1],&g_1907[0]},{&g_1907[0],&l_2438[1][3],(void*)0,&l_2438[0][1],&g_1907[1],&g_1907[1]}},{{&g_1907[1],&g_1907[3],&g_1907[1],&g_1907[3],(void*)0,&g_1907[3]},{&l_2438[0][0],&g_1907[1],&l_2438[0][0],&g_1907[2],&g_1907[0],(void*)0},{&g_1907[1],&l_2438[0][0],&g_1907[3],&l_2438[1][3],&l_2438[0][0],&l_2438[3][5]},{&l_2438[0][0],&l_2438[5][5],(void*)0,&l_2438[1][3],&g_1907[1],&g_1907[2]},{&g_1907[1],&g_108,&l_2438[6][0],&g_1907[2],&l_2438[1][3],&g_108},{&l_2438[0][0],&g_1907[0],&g_1907[1],&g_1907[3],(void*)0,&g_1907[3]},{&g_1907[1],&l_2438[0][0],&g_1907[0],&l_2438[0][1],&l_2438[6][0],&g_1907[1]},{&g_1907[0],(void*)0,&g_1907[2],&g_1907[0],&l_2438[5][5],&l_2438[5][5]},{&g_1907[3],&l_2438[0][1],&l_2438[0][0],&g_1907[1],&g_1907[0],(void*)0}},{{(void*)0,&l_2438[0][0],&g_1907[0],(void*)0,&l_2438[0][0],&g_1907[1]},{&g_1907[1],&l_2438[0][0],&l_2438[0][0],&g_1907[1],&g_1907[1],&l_2438[0][0]},{&g_108,&g_108,&g_1907[1],&g_1907[3],&g_108,&g_1907[6]},{(void*)0,&g_1907[1],&g_1907[1],&g_1907[1],&l_2438[0][1],&g_1907[1]},{&g_1907[3],(void*)0,&g_1907[1],&l_2438[0][0],&g_108,&g_1907[6]},{&l_2438[6][0],&l_2438[0][0],&g_1907[1],&g_1907[1],&g_1907[1],&l_2438[0][0]},{&g_1907[1],&g_1907[1],&l_2438[0][0],(void*)0,&g_1907[0],&g_1907[1]},{&g_1907[1],&l_2438[3][5],&g_1907[0],&l_2438[5][5],&g_1907[1],(void*)0},{&g_1907[1],(void*)0,&l_2438[0][0],&g_108,(void*)0,&l_2438[5][5]}}};
        int32_t l_2444 = 0xF1B3086DL;
        uint32_t *l_2446 = &g_2138;
        int32_t l_2453 = (-1L);
        int32_t l_2454 = (-2L);
        int32_t l_2520[8];
        int8_t l_2532 = 0x36L;
        uint32_t l_2533[3][8] = {{0xB80EAEAAL,0x79E06D3CL,0xCA5B7F44L,0x79E06D3CL,0xB80EAEAAL,4UL,4294967295UL,4294967287UL},{0x79E06D3CL,4294967295UL,0xC69BB0CEL,0xCA5B7F44L,0xCA5B7F44L,0xC69BB0CEL,4294967295UL,0x79E06D3CL},{0x6E5D1C1BL,4UL,0xC69BB0CEL,0xAFAA9353L,4294967295UL,0xB80EAEAAL,4294967295UL,0xAFAA9353L}};
        struct S1 l_2564 = {{7602},0xAA74C462L};
        int32_t *l_2590 = &l_2026[0];
        int64_t *l_2605 = &g_1689;
        uint64_t *l_2610[7][6][6] = {{{&g_1643,&g_1643,&g_1643,&g_1643,(void*)0,&g_1595},{&g_1595,&g_1643,&g_1595,&l_2252,(void*)0,&g_1595},{&l_2252,&g_1643,&g_1595,&l_2252,&g_105,&g_1643},{&g_1595,&g_1595,&l_2252,&g_1643,&l_2252,&g_1643},{&g_1643,&g_1595,&g_105,&g_1643,&g_105,&l_2252},{&g_1643,&g_1643,&g_1643,&g_1595,&g_105,&g_105}},{{&g_1643,(void*)0,&g_1595,&g_105,&l_2252,&g_105},{&g_1595,&g_105,&g_1643,&g_105,&g_1643,&g_1643},{&g_1595,&l_2252,&g_105,&g_1643,&g_105,&l_2252},{&g_1595,&g_1595,&g_105,(void*)0,&g_105,&g_1595},{&g_1643,&l_2252,&g_105,&g_1595,&g_105,&g_105},{&g_1643,&l_2252,&g_1595,&l_2252,&g_1643,&g_1595}},{{&g_105,&l_2252,&l_2252,(void*)0,(void*)0,&l_2252},{&g_1643,&g_1643,&g_105,&g_105,&l_2252,&l_2252},{&g_105,(void*)0,&g_1595,&g_1595,&g_1643,&g_105},{&g_1643,&g_105,&g_1595,&g_105,&g_1643,&l_2252},{&g_1595,&g_105,&g_105,(void*)0,&g_1643,&l_2252},{(void*)0,&g_1643,&l_2252,(void*)0,&g_1643,&g_1595}},{{&g_1595,&l_2252,&g_1595,&g_1643,&g_105,&g_105},{&g_105,&l_2252,&g_105,&l_2252,&g_105,&g_1595},{(void*)0,&g_1643,&g_105,&g_1595,&g_1643,&l_2252},{(void*)0,&g_105,&g_105,&g_1595,&l_2252,&g_1643},{&g_1643,&g_105,&g_1643,&g_1643,&g_1643,&g_105},{&g_1643,&g_105,(void*)0,&g_1643,&g_105,&l_2252}},{{&g_1595,&g_1643,&l_2252,&g_105,&l_2252,&g_1643},{&g_105,(void*)0,&g_105,&l_2252,&g_105,(void*)0},{&g_1595,&g_105,&g_1595,&g_1643,&g_105,&g_1595},{&g_1643,&g_1595,&g_105,&g_1595,&g_1643,&g_1595},{&l_2252,&g_1595,(void*)0,(void*)0,&g_105,&g_1643},{&g_1595,&g_105,&g_1643,&l_2252,&g_105,&g_1643}},{{&g_105,(void*)0,&g_1643,&g_1643,&l_2252,&g_1595},{(void*)0,&g_1643,&g_1595,&l_2252,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_1643,&g_1643,&g_105},{&g_1595,&g_105,&g_105,&l_2252,&l_2252,&g_1595},{&g_105,&g_105,(void*)0,&g_105,&g_1643,&g_1595},{&g_1643,&g_1643,&l_2252,&g_105,&g_105,&l_2252}},{{&l_2252,&l_2252,&g_1595,&g_1643,&g_105,&g_1595},{&g_105,&l_2252,&g_1643,&g_105,&g_1643,&g_1595},{&g_1643,&g_1643,&g_105,&g_105,&l_2252,&g_1643},{&g_1643,&l_2252,&g_1643,&g_1595,&g_1595,(void*)0},{&l_2252,(void*)0,&g_1643,&g_1595,&g_1643,&g_105},{&l_2252,&l_2252,&g_1595,&g_1595,&g_1595,&g_1595}}};
        int64_t **l_2621[1][7][2] = {{{&l_2605,&l_2605},{&l_2605,&l_2605},{&g_533,(void*)0},{&g_533,&l_2605},{&l_2605,&l_2605},{&l_2605,&g_533},{(void*)0,&g_533}}};
        int64_t ***l_2620 = &l_2621[0][3][0];
        uint32_t l_2680 = 0x41AF60F2L;
        const struct S0 **l_2729 = &g_2557;
        const int32_t l_2731[6][8][5] = {{{0xF1FB9C76L,0x9CEF7823L,0x0C977F8BL,(-7L),0xE8C6923BL},{(-3L),0xFBD02E40L,0x6BEF0A75L,0x01626821L,(-1L)},{0xE8C6923BL,(-1L),3L,(-9L),0xBA40BAC5L},{0xFBD02E40L,0xC9947E1CL,3L,0L,0xC9947E1CL},{0L,1L,0x6BEF0A75L,1L,0xFBD02E40L},{0x9CEF7823L,0x9319D2E8L,0x0C977F8BL,3L,(-9L)},{0x4E383DFEL,0x0C977F8BL,(-9L),0x9BE4DEC8L,0L},{1L,0x01626821L,2L,1L,(-1L)}},{{0x76E25318L,0L,0x03595D04L,0x3E9DA6D7L,1L},{0xFBD02E40L,0x03F4EF0FL,0xC21EBF77L,0xADA18132L,0xC21EBF77L},{0x2E30379EL,0x2E30379EL,(-1L),1L,0xADA18132L},{(-4L),0xD8348DC1L,0x03F4EF0FL,0x5EB3F9A5L,0L},{0xF1FB9C76L,0x3E9DA6D7L,(-4L),0xBA40BAC5L,(-5L)},{0x9BE4DEC8L,0xD8348DC1L,3L,1L,(-3L)},{0L,0x2E30379EL,0xF752B4E3L,3L,6L},{(-1L),0x03F4EF0FL,0x3E9DA6D7L,6L,(-9L)}},{{0L,0L,(-1L),0x01626821L,(-3L)},{(-4L),0x01626821L,0x76E25318L,0xC21EBF77L,0x74C6D236L},{(-9L),0x0C977F8BL,0x0813B3EBL,0xFBD02E40L,0x76E25318L},{1L,0x9319D2E8L,0xA35753EDL,0x74C6D236L,0xADA18132L},{0x03595D04L,1L,0L,0xECB3B761L,(-7L)},{1L,0xC9947E1CL,0x3E9DA6D7L,0xD8348DC1L,0x0813B3EBL},{1L,(-1L),0x1C98CFF1L,1L,(-1L)},{0x03595D04L,0xFBD02E40L,(-4L),(-6L),0x5D9890B1L}},{{1L,0x9CEF7823L,(-4L),0L,0xECB3B761L},{(-9L),0xB5DB3819L,0x63943025L,0xF1FB9C76L,0xFBD02E40L},{(-4L),(-7L),(-6L),(-4L),0x4E383DFEL},{0L,0xECB3B761L,0xC21EBF77L,0xD8348DC1L,3L},{(-1L),(-9L),1L,(-9L),(-1L)},{0L,(-7L),0xC9947E1CL,(-5L),0x2E30379EL},{0x9BE4DEC8L,0L,(-9L),0xFBD02E40L,0x6348B1DDL},{0xE8C6923BL,0x3E9DA6D7L,0L,0L,0x50E86C6BL}},{{(-1L),0xECB3B761L,5L,0xAE36DBBDL,0L},{0x50E86C6BL,0x8E152159L,0x2DE9098EL,0x0813B3EBL,0xA35753EDL},{0xECB3B761L,3L,(-7L),0xC21EBF77L,3L},{1L,(-4L),5L,0xABE1C99CL,0xECB3B761L},{0x3E9DA6D7L,1L,3L,0x76E25318L,2L},{3L,(-4L),1L,(-5L),0xA26B157EL},{0xABE1C99CL,0x0C977F8BL,0L,0x657F1D9FL,(-4L)},{0L,(-9L),0x63943025L,(-9L),0x7AD52E69L}},{{0xECB3B761L,0x9CEF7823L,0x5D9890B1L,(-9L),0L},{0x4EB96B6AL,0x50E86C6BL,(-1L),0x657F1D9FL,(-9L)},{(-6L),5L,0x5B24F8A2L,(-5L),1L},{0xE8C6923BL,(-9L),(-1L),0x76E25318L,0xF8B01E69L},{0x9FA897B0L,3L,(-9L),0xABE1C99CL,(-6L)},{0xA26B157EL,0x4EB96B6AL,0x8E152159L,0xC21EBF77L,8L},{0L,0x9CEF7823L,6L,0x0813B3EBL,0x0813B3EBL},{(-1L),(-4L),(-1L),0xAE36DBBDL,(-6L)}}};
        uint8_t l_2748 = 255UL;
        uint16_t l_2780[9] = {0UL,0x7625L,0x7625L,0UL,0x7625L,0x7625L,0UL,0x7625L,0x7625L};
        uint64_t l_2807[9];
        const struct S0 ** const *l_2903 = &l_2729;
        const struct S0 ** const **l_2902[8] = {&l_2903,&l_2903,&l_2903,&l_2903,&l_2903,&l_2903,&l_2903,&l_2903};
        uint8_t l_2931[10] = {0x60L,0x10L,0x10L,0x60L,252UL,0x60L,0x10L,0x10L,0x60L,252UL};
        int8_t l_2949 = 0x23L;
        uint32_t l_2952 = 0x37F816B1L;
        const uint16_t *l_3018 = &g_3019;
        uint32_t l_3034 = 1UL;
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2520[i] = 1L;
        for (i = 0; i < 9; i++)
            l_2807[i] = 0x4664D1F4282519BDLL;
        if (((safe_mul_func_int16_t_s_s(((((*l_2017) = l_2418) , (((*l_2446) |= (safe_add_func_uint16_t_u_u((1UL && ((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_u((~l_2418), (safe_sub_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u(0x9FL, (safe_lshift_func_int16_t_s_u(((safe_rshift_func_uint8_t_u_s(((*l_2437) = (safe_lshift_func_int8_t_s_u(((+0xFE4BDD4DL) , l_2418), 7))), ((g_178 , (l_2442 = l_2438[0][0])) == (void*)0))) , p_41.f0), p_41.f0)))) & (*l_2014)), l_2418)))), l_2444)) != l_2418)), l_2445))) , l_2444)) <= 0x15491437L), 0UL)) ^ g_1973.f0.f0))
        { /* block id: 1010 */
            int32_t l_2455 = 1L;
            uint32_t *l_2493[5][7][1] = {{{&l_2370},{&l_2370},{&l_2370},{&g_785},{&l_2370},{&g_59[2][2]},{&g_59[2][2]}},{{&l_2370},{&g_785},{&l_2370},{&l_2370},{&l_2370},{&g_785},{&l_2370}},{{&g_59[2][2]},{&g_59[2][2]},{&l_2370},{&g_785},{&l_2370},{&l_2370},{&l_2370}},{{&g_785},{&l_2370},{&g_59[2][2]},{&g_59[2][2]},{&l_2370},{&g_785},{&l_2370}},{{&l_2370},{&l_2370},{&g_785},{&l_2370},{&g_59[2][2]},{&g_59[2][2]},{&l_2370}}};
            int32_t l_2499[3];
            uint32_t *l_2506 = &l_2080;
            int32_t **l_2509 = (void*)0;
            int32_t *l_2511 = &g_1178[1][3];
            int32_t **l_2510 = &l_2511;
            int32_t l_2518 = 0x7B205155L;
            int32_t *l_2537[10][1][3] = {{{(void*)0,&g_173,&g_1606[4][2]}},{{&g_2369[2][1][7],&g_2369[2][1][7],(void*)0}},{{(void*)0,&g_173,&g_1606[4][2]}},{{&g_2369[2][1][7],&g_2369[2][1][7],(void*)0}},{{(void*)0,&g_173,&g_1606[4][2]}},{{&g_2369[2][1][7],&g_2369[2][1][7],(void*)0}},{{(void*)0,&g_173,&g_1606[4][2]}},{{&g_2369[2][1][7],&g_2369[2][1][7],(void*)0}},{{(void*)0,&g_173,&g_1606[4][2]}},{{&g_2369[2][1][7],&g_2369[2][1][7],(void*)0}}};
            struct S0 *** const *l_2550 = &g_1794;
            uint32_t l_2565[1];
            int32_t **l_2589[10] = {&l_2014,(void*)0,&l_2014,(void*)0,&l_2014,(void*)0,&l_2014,(void*)0,&l_2014,(void*)0};
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_2499[i] = 0L;
            for (i = 0; i < 1; i++)
                l_2565[i] = 0x2739EBEBL;
            if ((((safe_mod_func_int8_t_s_s(((*l_2017) &= (l_2185 , (g_478 = (safe_sub_func_int16_t_s_s((p_41 , (p_41.f0 > p_41.f0)), 0xFE43L))))), p_41.f0)) & 4294967295UL) < (*l_2284)))
            { /* block id: 1013 */
                uint64_t l_2456 = 8UL;
                for (g_947 = 0; (g_947 == 1); ++g_947)
                { /* block id: 1016 */
                    uint16_t l_2475 = 7UL;
                    uint32_t *l_2478 = &g_2066;
                    uint32_t *l_2479 = &g_59[2][2];
                    l_2456--;
                    if (l_2455)
                        break;
                    (*l_2284) ^= (safe_add_func_uint32_t_u_u(((*l_2479) = (safe_mul_func_int16_t_s_s(((((*l_2443) = ((((*l_2478) &= (safe_mul_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(0xC24AL, 2)), (safe_lshift_func_int8_t_s_u(g_837, ((safe_div_func_int32_t_s_s((*l_2014), l_2475)) ^ (l_2475 ^ ((safe_rshift_func_uint8_t_u_u((l_2418 <= p_40), 6)) > l_2475))))))) ^ (l_2475 > l_2456)) <= (*g_533)), 255UL)), 0L))) | 1L) & l_2418)) , l_2456) & (-1L)), (-1L)))), (-8L)));
                }
                for (l_2456 = (-11); (l_2456 > 26); l_2456 = safe_add_func_uint16_t_u_u(l_2456, 1))
                { /* block id: 1026 */
                    (*g_2156) ^= p_40;
                    for (g_29 = 0; (g_29 != 25); ++g_29)
                    { /* block id: 1030 */
                        struct S1 *l_2485 = &g_271[5];
                        struct S1 **l_2484 = &l_2485;
                        (*l_2484) = &g_271[3];
                    }
                }
                return p_41.f0;
            }
            else
            { /* block id: 1035 */
                int32_t l_2498 = 0x41CBA114L;
                l_2499[0] ^= (safe_div_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((~((0UL | ((void*)0 == l_2493[3][4][0])) | p_41.f0)), 0L)), ((*g_2156) = ((*l_2014) = (safe_add_func_int64_t_s_s(((((*l_2014) , ((safe_mul_func_uint8_t_u_u(p_40, (9UL ^ (((l_2437 == l_2017) ^ l_2498) , p_40)))) <= l_2498)) || l_2418) <= g_178), p_40))))));
                (*l_2284) ^= p_40;
            }
            if ((((&l_2418 == ((*l_2510) = ((*g_1071) = (((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s(((*l_2025) ^= (0x14F2L <= (safe_add_func_int16_t_s_s(l_2453, l_2444)))), ((((l_2506 == (g_2507 = (g_1846[0][1][0] , &l_2370))) < 0x903AL) >= (safe_unary_minus_func_int8_t_s(((p_41.f0 ^ p_41.f0) != 0x32B2L)))) & g_389))), g_1973.f0.f0)) && 1L) , (void*)0)))) || 0x22A4L) && 0UL))
            { /* block id: 1045 */
                return g_1485[3][3][1];
            }
            else
            { /* block id: 1047 */
                uint8_t l_2512 = 255UL;
                int32_t l_2521 = 0x90DA5B05L;
                int32_t l_2522 = (-1L);
                int32_t l_2525[9];
                struct S1 l_2541 = {{24820},0x7CCDDECAL};
                uint8_t **l_2558 = &l_2437;
                int i;
                for (i = 0; i < 9; i++)
                    l_2525[i] = 0L;
                l_2512++;
                if (p_41.f0)
                { /* block id: 1049 */
                    int64_t l_2519 = 0x37B0E4FAEBA35101LL;
                    int32_t l_2524 = 0x658F71EFL;
                    int32_t l_2526[4][8][8] = {{{6L,(-3L),(-2L),(-1L),6L,0x249AB3A4L,(-3L),0xCC6B5301L},{4L,(-5L),(-2L),0L,0L,0x914CF1C8L,0x914CF1C8L,0L},{0x83F4DB2BL,1L,1L,0x83F4DB2BL,0xCC6B5301L,(-3L),0x249AB3A4L,6L},{0x18667FC9L,9L,0xCC6B5301L,2L,(-4L),(-1L),(-2L),4L},{0x914CF1C8L,9L,4L,0xA4E86A40L,0L,(-3L),0x4DCD13CBL,1L},{(-1L),1L,(-1L),0L,2L,0x914CF1C8L,2L,0L},{0x4DCD13CBL,(-5L),0x4DCD13CBL,(-1L),(-9L),0x249AB3A4L,9L,(-1L)},{0x89F88CF6L,(-5L),0L,6L,(-3L),(-2L),(-9L),0xA4E86A40L}},{{0x89F88CF6L,8L,(-5L),0x18667FC9L,(-9L),0x4DCD13CBL,6L,0L},{0x4DCD13CBL,(-4L),9L,8L,2L,2L,8L,9L},{(-1L),(-1L),(-1L),0x914CF1C8L,0L,9L,(-1L),0x249AB3A4L},{0x914CF1C8L,0x18667FC9L,0x83F4DB2BL,4L,(-4L),(-9L),1L,0x249AB3A4L},{0x18667FC9L,(-1L),0L,0x914CF1C8L,0xCC6B5301L,6L,(-1L),9L},{0x83F4DB2BL,0L,0L,8L,0L,8L,0L,0L},{4L,0x914CF1C8L,8L,0x18667FC9L,6L,(-1L),0L,0xA4E86A40L},{(-4L),0xCC6B5301L,0L,6L,4L,1L,0L,(-1L)}},{{(-9L),6L,8L,(-1L),1L,(-1L),0L,0L},{1L,(-1L),0L,0L,0L,0L,(-1L),1L},{0x249AB3A4L,9L,0L,0xA4E86A40L,(-1L),0L,1L,4L},{(-1L),0L,0x83F4DB2BL,2L,0xA4E86A40L,0L,(-1L),6L},{(-5L),9L,(-1L),0x83F4DB2BL,0L,0L,8L,0L},{6L,(-1L),9L,0L,9L,(-1L),6L,0xCC6B5301L},{(-2L),6L,(-5L),(-1L),0x249AB3A4L,1L,(-9L),(-4L)},{0L,0xCC6B5301L,0L,0x89F88CF6L,0x249AB3A4L,(-1L),9L,0L}},{{(-2L),0x914CF1C8L,0x89F88CF6L,0L,0x249AB3A4L,2L,4L,4L},{(-4L),(-1L),9L,9L,(-1L),(-4L),0x89F88CF6L,(-1L)},{0x83F4DB2BL,0xCC6B5301L,(-3L),0x249AB3A4L,6L,(-1L),(-1L),(-5L)},{(-1L),0L,(-5L),0x249AB3A4L,4L,(-2L),8L,(-1L)},{8L,4L,9L,9L,0L,4L,(-9L),4L},{9L,0L,(-1L),0L,9L,0x89F88CF6L,(-5L),0L},{(-1L),2L,0x18667FC9L,0xA4E86A40L,(-3L),(-1L),(-1L),0L},{0L,(-1L),0x18667FC9L,(-1L),(-4L),8L,(-5L),(-5L)}}};
                    int i, j, k;
                    for (g_105 = 0; (g_105 != 44); ++g_105)
                    { /* block id: 1052 */
                        int8_t l_2517 = 1L;
                        int32_t l_2523 = 4L;
                        int32_t l_2527 = 0x0B559D61L;
                        int32_t l_2528 = 0x2C2932ACL;
                        int32_t l_2529[2];
                        int64_t l_2530 = 0xB58331C587C7AB89LL;
                        int32_t **l_2536 = &l_2284;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2529[i] = 0x97868298L;
                        l_2533[2][3]++;
                        l_2537[2][0][2] = ((*l_2536) = &l_2521);
                    }
                }
                else
                { /* block id: 1057 */
                    uint8_t **l_2542[3][7][4] = {{{&l_2437,&l_2437,&l_2437,&l_2437},{&l_2437,&l_2437,&l_2437,(void*)0},{&l_2437,&l_2437,&l_2437,&l_2437},{&l_2437,&l_2437,(void*)0,&l_2437},{(void*)0,&l_2437,(void*)0,&l_2437},{&l_2437,&l_2437,&l_2437,&l_2437},{(void*)0,&l_2437,&l_2437,&l_2437}},{{(void*)0,&l_2437,&l_2437,&l_2437},{&l_2437,&l_2437,(void*)0,&l_2437},{(void*)0,(void*)0,(void*)0,(void*)0},{&l_2437,(void*)0,&l_2437,&l_2437},{&l_2437,&l_2437,&l_2437,(void*)0},{&l_2437,&l_2437,&l_2437,(void*)0},{&l_2437,&l_2437,&l_2437,&l_2437}},{{&l_2437,(void*)0,&l_2437,(void*)0},{&l_2437,(void*)0,&l_2437,&l_2437},{&l_2437,&l_2437,&l_2437,&l_2437},{(void*)0,&l_2437,&l_2437,&l_2437},{&l_2437,&l_2437,&l_2437,&l_2437},{(void*)0,&l_2437,&l_2437,&l_2437},{&l_2437,&l_2437,&l_2437,&l_2437}}};
                    uint8_t ***l_2543 = &l_2542[2][0][3];
                    int64_t *l_2544 = &g_1846[0][5][4];
                    int32_t l_2570 = 0xE211E8D5L;
                    int i, j, k;
                    l_2520[3] &= (p_40 >= (safe_unary_minus_func_uint8_t_u(((*l_2437) = l_2512))));
                    if ((l_2525[6] > (((safe_add_func_int64_t_s_s(l_2453, ((*l_2544) = ((*g_533) &= (((*l_2284) , (l_2541 , 7L)) & (&l_2437 != ((*l_2543) = l_2542[2][0][3]))))))) ^ 0x6116ABE3F132C5A1LL) != (18446744073709551612UL != (-1L)))))
                    { /* block id: 1063 */
                        int32_t **l_2547 = &l_2285[1];
                        const struct S0 ***l_2552 = (void*)0;
                        const struct S0 *** const *l_2551 = &l_2552;
                        const struct S0 *** const **l_2553[8] = {&l_2551,&l_2551,&l_2551,&l_2551,&l_2551,&l_2551,&l_2551,&l_2551};
                        uint64_t *l_2559 = (void*)0;
                        int i;
                        (*l_2284) = (safe_lshift_func_uint8_t_u_s(0x57L, ((*l_2017) = g_271[5].f1)));
                        (*l_2547) = &l_2026[0];
                        l_2522 &= (l_2521 == (4L == (((safe_lshift_func_int16_t_s_s((((*l_2025) ^= ((****l_2319) , (l_2550 != (g_2554 = l_2551)))) , p_40), (l_2558 == ((g_105 = ((((void*)0 != &l_2509) , p_41) , 3UL)) , (void*)0)))) , (*l_2284)) == (*g_2507))));
                        (*g_2156) |= (safe_add_func_uint16_t_u_u((((safe_div_func_uint64_t_u_u((((**l_2558) = (0xA35296D32418DFC5LL == 0UL)) > ((((l_2564 , (l_2520[5] = p_41.f0)) || l_2565[0]) != (safe_mod_func_uint32_t_u_u(((safe_add_func_int64_t_s_s(0xD379EBF7ADE520EDLL, ((*g_2507) <= ((-1L) != ((l_2453 = (*p_42)) == p_40))))) == l_2521), l_2570))) , p_40)), 0xF9C58AC2CC2217A8LL)) != p_40) || p_41.f0), l_2532));
                    }
                    else
                    { /* block id: 1075 */
                        int32_t **l_2571 = &l_2014;
                        (*l_2571) = &l_2499[2];
                        return g_33;
                    }
                }
                (*l_2014) |= ((safe_rshift_func_uint16_t_u_u(0x32ECL, ((*l_2025) &= g_31))) ^ (safe_div_func_uint32_t_u_u((~(safe_mul_func_uint8_t_u_u(((*l_2437) = p_41.f0), (safe_mod_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_u((l_2512 | p_40), 3)) != (l_2521 |= (((p_41.f0 & 4294967288UL) > (safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u((((*l_2017) = p_41.f0) , (safe_add_func_uint16_t_u_u(p_40, p_40))), 3)), (*p_42)))) == (-1L)))) , p_40), l_2512))))), p_40)));
            }
            l_2590 = &l_2026[0];
        }
        else
        { /* block id: 1087 */
            uint16_t l_2591 = 65535UL;
            ++l_2591;
            (*l_2440) = l_2594;
        }
        if ((safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((safe_div_func_int8_t_s_s(0x89L, ((l_2185 , l_2564.f0) , (safe_mul_func_uint16_t_u_u(0x48C2L, p_41.f0))))) || ((*l_2590) = ((safe_sub_func_int64_t_s_s((*p_42), ((*l_2605) = (*p_42)))) && (safe_add_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s((0UL | ((((*l_2014) = (0x29C1L != 1UL)) && 4294967289UL) <= 8L)), 5)), (*p_42)))))), g_1846[0][2][4])), g_947)))
        { /* block id: 1094 */
            return p_41.f0;
        }
        else
        { /* block id: 1096 */
            int16_t l_2611 = 0x3EB6L;
            struct S0 ****l_2646 = &g_1794;
            int32_t l_2710[10][6][2] = {{{0xA1B903DAL,0L},{0L,0xA1B903DAL},{0x306404F5L,0x306404F5L},{0x306404F5L,0xA1B903DAL},{0L,0L},{0xA1B903DAL,0L}},{{0L,0xA1B903DAL},{0x306404F5L,0x306404F5L},{0x306404F5L,0xA1B903DAL},{0L,0L},{0xA1B903DAL,0L},{0L,0xA1B903DAL}},{{0x306404F5L,0x306404F5L},{0x306404F5L,0xA1B903DAL},{0L,0L},{0xA1B903DAL,0L},{0L,0xA1B903DAL},{0x306404F5L,0x306404F5L}},{{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L}},{{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L}},{{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L}},{{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L}},{{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL}},{{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L}},{{0xDD1E5A38L,0x306404F5L},{0L,0x306404F5L},{0xDD1E5A38L,0L},{0xA1B903DAL,0xA1B903DAL},{0xA1B903DAL,0L},{0xDD1E5A38L,0x306404F5L}}};
            int16_t **l_2757 = (void*)0;
            int64_t l_2779 = (-1L);
            int32_t ****l_2782 = &g_229;
            uint8_t ***l_2901 = &g_2899;
            int64_t *l_2910 = &g_29;
            int32_t *l_2960[1][1][10] = {{{&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0],&l_2710[1][1][0]}}};
            struct S1 l_2983[8][10][3] = {{{{{6157},0xFC810B0FL},{{9042},18446744073709551608UL},{{5513},18446744073709551615UL}},{{{5148},0x09A928C2L},{{29115},18446744073709551615UL},{{26877},0x5AEA2547L}},{{{21362},0UL},{{9257},0x64416E39L},{{21263},8UL}},{{{1823},0xA3F03639L},{{30430},0x52A30EF6L},{{32235},0x3853B71CL}},{{{23015},18446744073709551615UL},{{23895},1UL},{{32235},0x3853B71CL}},{{{6931},0UL},{{8270},18446744073709551615UL},{{21263},8UL}},{{{2506},1UL},{{10032},1UL},{{26877},0x5AEA2547L}},{{{28795},0xE3C3D422L},{{21614},0x960AF9E2L},{{5513},18446744073709551615UL}},{{{15804},0x7D8770A7L},{{22064},1UL},{{9694},1UL}},{{{14192},0UL},{{1823},0xA3F03639L},{{28286},18446744073709551615UL}}},{{{{16045},0x070319FEL},{{20138},18446744073709551615UL},{{402},0x91CCB318L}},{{{23117},0xB2F84B74L},{{3642},0UL},{{32085},0xA41C67D5L}},{{{22313},0UL},{{5320},0UL},{{2506},1UL}},{{{1334},18446744073709551615UL},{{2506},1UL},{{10700},18446744073709551608UL}},{{{5320},0UL},{{1334},18446744073709551615UL},{{5320},0UL}},{{{9694},1UL},{{21263},8UL},{{28795},0xE3C3D422L}},{{{5303},18446744073709551615UL},{{30321},18446744073709551615UL},{{28655},0xCCF32BF1L}},{{{5513},18446744073709551615UL},{{32193},0x01897BB5L},{{16784},0x13DA4405L}},{{{26184},0x45222AF4L},{{4918},0xD02096C1L},{{30430},0x52A30EF6L}},{{{5513},18446744073709551615UL},{{22188},18446744073709551610UL},{{32114},9UL}}},{{{{5303},18446744073709551615UL},{{15804},0x7D8770A7L},{{32193},0x01897BB5L}},{{{9694},1UL},{{26877},0x5AEA2547L},{{27076},0x3844ACF8L}},{{{5320},0UL},{{14298},0xFEDD1D08L},{{28331},0UL}},{{{1334},18446744073709551615UL},{{5148},0x09A928C2L},{{10032},1UL}},{{{22313},0UL},{{22818},1UL},{{5489},0x02715E0BL}},{{{23117},0xB2F84B74L},{{19365},0xFD662FCBL},{{22313},0UL}},{{{16045},0x070319FEL},{{14192},0UL},{{420},5UL}},{{{14192},0UL},{{17813},0xB17D30F8L},{{31534},18446744073709551615UL}},{{{15804},0x7D8770A7L},{{32114},9UL},{{9257},0x64416E39L}},{{{28795},0xE3C3D422L},{{1046},18446744073709551615UL},{{14298},0xFEDD1D08L}}},{{{{2506},1UL},{{14881},0xE0AD6DD9L},{{15008},0xDC43A81BL}},{{{6931},0UL},{{25885},2UL},{{14192},0UL}},{{{23015},18446744073709551615UL},{{22818},1UL},{{15008},0xDC43A81BL}},{{{13981},0x6E4EA9B5L},{{24553},18446744073709551606UL},{{30350},0xFE5A8057L}},{{{32114},9UL},{{23015},18446744073709551615UL},{{28655},0xCCF32BF1L}},{{{29106},0xF7CFBFDBL},{{22313},0UL},{{22188},18446744073709551610UL}},{{{4514},0xD62352BCL},{{16104},0x574B7864L},{{22064},1UL}},{{{30350},0xFE5A8057L},{{32069},0UL},{{16784},0x13DA4405L}},{{{22188},18446744073709551610UL},{{16575},0x1017FAE1L},{{8733},0xF3530299L}},{{{28331},0UL},{{420},5UL},{{23895},1UL}}},{{{{30321},18446744073709551615UL},{{29106},0xF7CFBFDBL},{{23117},0xB2F84B74L}},{{{5303},18446744073709551615UL},{{402},0x91CCB318L},{{5148},0x09A928C2L}},{{{25885},2UL},{{25885},2UL},{{30430},0x52A30EF6L}},{{{15804},0x7D8770A7L},{{8733},0xF3530299L},{{11148},18446744073709551615UL}},{{{29115},18446744073709551615UL},{{21993},18446744073709551611UL},{{1334},18446744073709551615UL}},{{{28795},0xE3C3D422L},{{5148},0x09A928C2L},{{22818},1UL}},{{{19365},0xFD662FCBL},{{29115},18446744073709551615UL},{{1334},18446744073709551615UL}},{{{4918},0xD02096C1L},{{20138},18446744073709551615UL},{{11148},18446744073709551615UL}},{{{31534},18446744073709551615UL},{{9042},18446744073709551608UL},{{30430},0x52A30EF6L}},{{{558},0x6D961DEDL},{{14192},0UL},{{5148},0x09A928C2L}}},{{{{5513},18446744073709551615UL},{{526},1UL},{{23117},0xB2F84B74L}},{{{16575},0x1017FAE1L},{{32235},0x3853B71CL},{{23895},1UL}},{{{16567},0xF0FC6BADL},{{6190},18446744073709551609UL},{{8733},0xF3530299L}},{{{22313},0UL},{{17813},0xB17D30F8L},{{16784},0x13DA4405L}},{{{22818},1UL},{{13981},0x6E4EA9B5L},{{22064},1UL}},{{{21993},18446744073709551611UL},{{26877},0x5AEA2547L},{{22188},18446744073709551610UL}},{{{8270},18446744073709551615UL},{{31534},18446744073709551615UL},{{28655},0xCCF32BF1L}},{{{26184},0x45222AF4L},{{19365},0xFD662FCBL},{{30350},0xFE5A8057L}},{{{10700},18446744073709551608UL},{{28655},0xCCF32BF1L},{{15008},0xDC43A81BL}},{{{5489},0x02715E0BL},{{30430},0x52A30EF6L},{{32069},0UL}}},{{{{5489},0x02715E0BL},{{8270},18446744073709551615UL},{{26184},0x45222AF4L}},{{{10700},18446744073709551608UL},{{16045},0x070319FEL},{{402},0x91CCB318L}},{{{26184},0x45222AF4L},{{22188},18446744073709551610UL},{{16045},0x070319FEL}},{{{8270},18446744073709551615UL},{{28611},0x85880D4CL},{{5320},0UL}},{{{21993},18446744073709551611UL},{{5513},18446744073709551615UL},{{14881},0xE0AD6DD9L}},{{{22818},1UL},{{4918},0xD02096C1L},{{9694},1UL}},{{{22313},0UL},{{4612},0x5A646DACL},{{16567},0xF0FC6BADL}},{{{16567},0xF0FC6BADL},{{29140},0x81EF61D4L},{{19365},0xFD662FCBL}},{{{16575},0x1017FAE1L},{{11148},18446744073709551615UL},{{14080},0x61209BC6L}},{{{5513},18446744073709551615UL},{{28286},18446744073709551615UL},{{28286},18446744073709551615UL}}},{{{{558},0x6D961DEDL},{{32193},0x01897BB5L},{{29115},18446744073709551615UL}},{{{31534},18446744073709551615UL},{{21362},0UL},{{22313},0UL}},{{{4918},0xD02096C1L},{{5303},18446744073709551615UL},{{8270},18446744073709551615UL}},{{{19365},0xFD662FCBL},{{6931},0UL},{{2506},1UL}},{{{28795},0xE3C3D422L},{{5303},18446744073709551615UL},{{29553},5UL}},{{{29115},18446744073709551615UL},{{21362},0UL},{{3755},9UL}},{{{15804},0x7D8770A7L},{{32193},0x01897BB5L},{{32235},0x3853B71CL}},{{{25885},2UL},{{28286},18446744073709551615UL},{{4612},0x5A646DACL}},{{{5303},18446744073709551615UL},{{11148},18446744073709551615UL},{{526},1UL}},{{{30321},18446744073709551615UL},{{29140},0x81EF61D4L},{{28079},1UL}}}};
            uint32_t ***l_2996 = (void*)0;
            int i, j, k;
            if (l_2611)
            { /* block id: 1097 */
                int16_t l_2649[10] = {0x3449L,0x3776L,0x3449L,0x3449L,0x3776L,0x3449L,0x3449L,0x3776L,0x3449L,0x3449L};
                int32_t l_2679 = 0x8EE95946L;
                int32_t * const *l_2686 = (void*)0;
                int32_t *l_2793 = &l_2710[9][3][0];
                struct S0 **l_2837[9][9][3] = {{{&g_350[0],&g_350[3],&g_350[3]},{&g_350[3],&g_350[3],&g_350[3]},{&g_350[3],(void*)0,(void*)0},{&g_350[1],&g_350[3],&g_350[3]},{&g_350[3],(void*)0,&g_350[3]},{&g_350[0],&g_350[2],&g_350[3]},{(void*)0,(void*)0,&g_350[3]},{&g_350[0],&g_350[1],&g_350[3]},{&g_350[0],&g_350[0],(void*)0}},{{&g_350[3],(void*)0,&g_350[3]},{&g_350[3],&g_350[0],&g_350[3]},{&g_350[2],&g_350[0],&g_350[3]},{&g_350[3],&g_350[3],&g_350[3]},{(void*)0,&g_350[3],&g_350[2]},{&g_350[3],&g_350[1],(void*)0},{&g_350[3],(void*)0,&g_350[2]},{&g_350[2],&g_350[1],&g_350[3]},{&g_350[3],&g_350[3],&g_350[0]}},{{&g_350[3],&g_350[3],&g_350[3]},{(void*)0,(void*)0,&g_350[2]},{&g_350[1],&g_350[3],(void*)0},{&g_350[2],(void*)0,&g_350[2]},{&g_350[3],(void*)0,&g_350[3]},{&g_350[0],&g_350[3],&g_350[0]},{(void*)0,&g_350[2],&g_350[3]},{(void*)0,&g_350[2],&g_350[2]},{&g_350[3],&g_350[3],(void*)0}},{{(void*)0,(void*)0,&g_350[2]},{&g_350[0],&g_350[3],&g_350[3]},{&g_350[3],&g_350[0],&g_350[0]},{&g_350[1],&g_350[0],&g_350[3]},{(void*)0,&g_350[3],&g_350[2]},{&g_350[3],&g_350[1],(void*)0},{&g_350[3],(void*)0,&g_350[2]},{&g_350[2],&g_350[1],&g_350[3]},{&g_350[3],&g_350[3],&g_350[0]}},{{&g_350[3],&g_350[3],&g_350[3]},{(void*)0,(void*)0,&g_350[2]},{&g_350[1],&g_350[3],(void*)0},{&g_350[2],(void*)0,&g_350[2]},{&g_350[3],(void*)0,&g_350[3]},{&g_350[0],&g_350[3],&g_350[0]},{(void*)0,&g_350[2],&g_350[3]},{(void*)0,&g_350[2],&g_350[2]},{&g_350[3],&g_350[3],(void*)0}},{{(void*)0,(void*)0,&g_350[2]},{&g_350[0],&g_350[3],&g_350[3]},{&g_350[3],&g_350[0],&g_350[0]},{&g_350[1],&g_350[0],&g_350[3]},{(void*)0,&g_350[3],&g_350[2]},{&g_350[3],&g_350[1],(void*)0},{&g_350[3],(void*)0,&g_350[2]},{&g_350[2],&g_350[1],&g_350[3]},{&g_350[3],&g_350[3],&g_350[0]}},{{&g_350[3],&g_350[3],&g_350[3]},{(void*)0,(void*)0,&g_350[2]},{&g_350[1],&g_350[3],(void*)0},{&g_350[2],(void*)0,&g_350[2]},{&g_350[3],(void*)0,&g_350[3]},{&g_350[0],&g_350[3],&g_350[0]},{(void*)0,&g_350[2],&g_350[3]},{(void*)0,&g_350[2],&g_350[2]},{&g_350[3],&g_350[3],(void*)0}},{{(void*)0,(void*)0,&g_350[2]},{&g_350[0],&g_350[3],&g_350[3]},{&g_350[3],&g_350[0],&g_350[0]},{&g_350[1],&g_350[0],&g_350[3]},{(void*)0,&g_350[3],&g_350[2]},{&g_350[3],&g_350[1],(void*)0},{&g_350[3],(void*)0,&g_350[2]},{&g_350[2],&g_350[1],&g_350[3]},{&g_350[3],&g_350[3],&g_350[0]}},{{&g_350[3],&g_350[3],&g_350[3]},{(void*)0,(void*)0,&g_350[2]},{&g_350[1],&g_350[3],(void*)0},{&g_350[2],(void*)0,&g_350[2]},{&g_350[3],(void*)0,&g_350[1]},{&g_350[3],&g_350[3],&g_350[0]},{(void*)0,(void*)0,&g_350[1]},{&g_350[3],&g_350[1],&g_350[3]},{&g_350[3],&g_350[3],&g_350[3]}}};
                int i, j, k;
                for (l_2564.f1 = 0; (l_2564.f1 != 20); l_2564.f1 = safe_add_func_int64_t_s_s(l_2564.f1, 2))
                { /* block id: 1100 */
                    int32_t ****l_2629 = &g_229;
                    (*l_2014) = (safe_mod_func_uint64_t_u_u(((safe_div_func_uint8_t_u_u((((safe_mul_func_int16_t_s_s(p_40, (g_2036 == (g_31 , l_2620)))) != (safe_rshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(((*l_2437) = (0xA60D7D18L >= (((p_40 , l_2628) != l_2629) & p_41.f0))), 6)), 0x3CL)), 8))) | (*l_2590)), p_40)) & 0x08A47727L), 9UL));
                    for (g_33 = 0; (g_33 != 13); ++g_33)
                    { /* block id: 1105 */
                        (*g_2156) = (-1L);
                    }
                    if (p_40)
                        break;
                }
                for (l_2611 = 6; (l_2611 >= 5); l_2611 = safe_sub_func_uint16_t_u_u(l_2611, 5))
                { /* block id: 1112 */
                    uint32_t l_2650[4][10];
                    uint64_t l_2651 = 18446744073709551611UL;
                    int32_t l_2652 = 0L;
                    int32_t l_2653 = (-7L);
                    int16_t l_2654 = (-5L);
                    uint32_t *l_2670 = &g_1323;
                    int16_t l_2681 = (-7L);
                    int i, j;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 10; j++)
                            l_2650[i][j] = 0xAF9FBB45L;
                    }
                    for (g_2066 = (-22); (g_2066 == 55); g_2066++)
                    { /* block id: 1115 */
                        uint16_t l_2655 = 0x4C44L;
                        struct S1 **l_2658 = (void*)0;
                        struct S1 *l_2660 = &g_271[5];
                        struct S1 **l_2659 = &l_2660;
                        struct S1 *l_2662 = &g_271[5];
                        struct S1 **l_2661 = &l_2662;
                        if (p_41.f0)
                            break;
                        (*g_2156) = (g_515 >= ((safe_rshift_func_uint16_t_u_u(g_2364, (safe_rshift_func_uint16_t_u_s(((safe_add_func_uint8_t_u_u(((*l_2437) = (safe_mul_func_uint16_t_u_u((1L <= (g_837 , ((safe_add_func_uint16_t_u_u(((void*)0 == l_2646), p_40)) & (((safe_mul_func_uint16_t_u_u(1UL, (g_2366[5] > l_2649[7]))) > p_40) < 0x7C41F251F002BF45LL)))), 0xAE9BL))), l_2650[1][1])) , l_2650[1][1]), 14)))) < l_2651));
                        --l_2655;
                        (*l_2661) = ((*l_2659) = &g_271[5]);
                    }
                    (*l_2590) = ((safe_lshift_func_int16_t_s_s((~(-2L)), ((p_41.f0 != p_40) || ((safe_div_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((l_2670 == &g_2066) ^ (((safe_add_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u((((*l_2017) = 0x3FL) | ((safe_mul_func_uint8_t_u_u(((--(*l_2670)) , (3L < (l_2679 ^= ((*l_2437) = g_2369[0][1][7])))), ((*g_2557) , g_53))) < (*l_2590))), 1UL)) < (*l_2590)), l_2680)) , 0xAEE2L) > p_40)), 0xF4L)), 3UL)) , 249UL)))) <= p_41.f0);
                    if (p_40)
                    { /* block id: 1128 */
                        uint64_t l_2682 = 9UL;
                        uint32_t **l_2684 = &l_2446;
                        l_2682 ^= l_2681;
                        if (p_41.f0)
                            continue;
                        (*g_2156) = ((((*l_2684) = (g_2683 = l_2014)) != (void*)0) <= (l_2564 , l_2685));
                    }
                    else
                    { /* block id: 1134 */
                        int64_t l_2692 = (-1L);
                        (*g_2156) &= (((g_2687 = ((*g_2154) = ((****l_2319) , l_2686))) == ((l_2651 ^ (((safe_mod_func_int32_t_s_s(((l_2692 == ((((*l_2017) = p_41.f0) && g_2693) > (g_1643 ^= (0xB60EL & ((*l_2025) = p_41.f0))))) , (((*l_2335) = (*l_2335)) == &l_2418)), (*g_2507))) <= 4294967291UL) >= 0UL)) , (void*)0)) & 1L);
                        l_2652 ^= (((safe_rshift_func_uint8_t_u_s((safe_div_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s(((safe_rshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s((safe_add_func_int64_t_s_s(0x7AC5F61C7C29BA30LL, (safe_sub_func_int64_t_s_s((*g_533), (l_2710[3][2][0] |= (*l_2590)))))), (((*g_2156) &= (0x7B2EL || ((((*l_2670) = ((*l_2014) ^= 0x311F9259L)) , ((*l_2437) = g_101)) , ((safe_mul_func_uint16_t_u_u((++(*l_2025)), ((**l_2594) |= ((-1L) != ((safe_add_func_int64_t_s_s(((*l_2605) = (~((((safe_lshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u(((!(safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(((((safe_rshift_func_uint8_t_u_s((l_2729 != (void*)0), 0)) , p_41.f0) != 0x2DL) , g_101), l_2692)), p_41.f0))) | p_40), (*g_2507))), (*l_2590))) & 0xAFL) , (*l_2590)) , l_2730[7][0]))), (*p_42))) && l_2650[1][6]))))) != 1L)))) , (*l_2014)))), (*l_2590))) != 1L), g_31)) != (*l_2590)), p_40)), 0x45E1L)), g_2689[1])) < 0x984349FD6D78E63DLL) <= l_2731[3][2][1]);
                        return p_41.f0;
                    }
                }
                if (((safe_lshift_func_int8_t_s_s(((*l_2017) = 0xAEL), ((((g_389 && ((&g_2203[0][2] != (((((*l_2590) & (safe_lshift_func_uint16_t_u_s((((safe_div_func_uint16_t_u_u((((*l_2025) = (safe_div_func_int8_t_s_s((((safe_div_func_uint64_t_u_u(((safe_sub_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(l_2710[3][2][0], (g_1595 ^= (safe_sub_func_uint16_t_u_u(1UL, l_2748))))), p_40)) , ((*g_2507) != 0x6A1B3597L)), 0xAF387689AE391288LL)) ^ p_41.f0) , 0x03L), g_2323.f0))) | 0xE620L), 1L)) , 0x2DL) , 0xAC32L), 7))) || g_173) >= 0xDD2BL) , l_2749)) & 0x7A41L)) <= (*p_42)) & (*l_2590)) | g_2323.f0))) != 0UL))
                { /* block id: 1157 */
                    int16_t **l_2756[5][6][6] = {{{&l_2443,&l_2443,&l_2443,&l_2439,&l_2439,&l_2443},{(void*)0,(void*)0,&l_2439,&l_2443,&l_2439,(void*)0},{&l_2439,&l_2443,&l_2443,&l_2443,(void*)0,&l_2439},{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,(void*)0},{&l_2443,&l_2439,&l_2439,&l_2443,(void*)0,&l_2443},{&l_2443,(void*)0,&l_2443,&l_2439,&l_2439,&l_2443}},{{(void*)0,&l_2439,&l_2439,&l_2443,&l_2439,&l_2439},{&l_2439,(void*)0,&l_2443,&l_2443,(void*)0,&l_2439},{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,&l_2439},{&l_2443,&l_2439,&l_2439,&l_2443,(void*)0,&l_2443},{&l_2443,&l_2443,&l_2443,&l_2439,&l_2439,&l_2443},{(void*)0,(void*)0,&l_2439,&l_2443,&l_2439,(void*)0}},{{&l_2439,&l_2443,&l_2443,&l_2443,(void*)0,&l_2439},{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,(void*)0},{&l_2443,&l_2439,&l_2439,&l_2443,(void*)0,&l_2443},{&l_2443,(void*)0,&l_2443,&l_2439,&l_2439,&l_2443},{(void*)0,&l_2439,&l_2439,&l_2443,&l_2439,&l_2439},{&l_2439,(void*)0,&l_2443,&l_2443,(void*)0,&l_2439}},{{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,&l_2439},{&l_2443,&l_2439,&l_2439,&l_2443,(void*)0,&l_2443},{&l_2443,&l_2443,&l_2443,&l_2439,&l_2439,&l_2443},{(void*)0,(void*)0,&l_2439,&l_2443,&l_2439,(void*)0},{&l_2439,&l_2443,&l_2443,&l_2443,(void*)0,&l_2439},{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,(void*)0}},{{&l_2443,&l_2439,&l_2439,&l_2443,(void*)0,&l_2443},{&l_2443,(void*)0,&l_2443,&l_2439,&l_2439,&l_2443},{(void*)0,&l_2439,&l_2439,&l_2443,&l_2439,&l_2439},{&l_2439,(void*)0,&l_2443,&l_2443,(void*)0,&l_2439},{(void*)0,&l_2439,&l_2443,&l_2439,(void*)0,&l_2439},{&l_2443,&l_2439,&l_2443,&l_2443,(void*)0,&l_2443}}};
                    uint32_t *l_2770 = (void*)0;
                    uint32_t *l_2771 = (void*)0;
                    uint32_t *l_2772 = (void*)0;
                    uint32_t *l_2773 = &g_785;
                    int32_t l_2774 = (-1L);
                    int i, j, k;
                    if ((p_41.f0 < (safe_mod_func_uint8_t_u_u(((((((((((safe_add_func_uint16_t_u_u((((p_41.f0 , (0x75ECL || (safe_add_func_uint32_t_u_u((l_2756[3][3][3] == l_2757), (p_41.f0 | (safe_rshift_func_uint8_t_u_u(((safe_add_func_int8_t_s_s(p_41.f0, (((*l_2773) &= (((safe_div_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u(((((*l_2025) &= g_656) != ((*l_2590) = (safe_sub_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(((-1L) != l_2710[3][2][0]), 1)), (*g_2507))))) ^ p_40), 15)), p_40)) , 0xC5AEF02EL) , 4294967286UL)) ^ 0x181E8E28L))) && (-1L)), 7))))))) || p_41.f0) < (*g_2507)), g_1323)) , (-4L)) >= l_2774) , 18446744073709551615UL) | l_2774) & p_41.f0) != 0x3C5C33FC1196AC04LL) == l_2774) | l_2774) , 0x34L), 0x4EL))))
                    { /* block id: 1161 */
                        int16_t l_2781 = (-1L);
                        (*g_2156) = (safe_mul_func_int8_t_s_s((g_2777 == (void*)0), (((l_2779 ^= p_40) , ((((((l_2781 = ((*l_2014) = l_2780[6])) ^ (l_2782 == &g_2154)) <= (((*l_2590) > ((4294967291UL && (p_41.f0 <= 0x4CL)) > 0xAAL)) ^ l_2774)) , 1L) <= 3UL) | 1UL)) ^ (*l_2590))));
                    }
                    else
                    { /* block id: 1166 */
                        uint32_t l_2789 = 4294967295UL;
                        (*g_2688) = (safe_mul_func_uint8_t_u_u(((((*g_2507) == ((*l_2590) &= ((*l_2773) |= 1UL))) & ((*l_2025) = (safe_sub_func_int8_t_s_s(((safe_div_func_int64_t_s_s(((g_1689 <= l_2789) != l_2774), (safe_rshift_func_int16_t_s_s(((**l_2594) &= p_41.f0), (0x76L || p_40))))) , 0L), 1L)))) , (*l_2590)), g_2792));
                    }
                }
                else
                { /* block id: 1173 */
                    int32_t **l_2794 = &l_2590;
                    (*l_2794) = (l_2793 = &l_2453);
                    for (g_105 = 0; (g_105 < 37); g_105 = safe_add_func_int8_t_s_s(g_105, 5))
                    { /* block id: 1178 */
                        (*l_2794) = &l_2326;
                    }
                    for (l_2679 = 0; (l_2679 > 4); l_2679++)
                    { /* block id: 1183 */
                        (*l_2793) = (*l_2590);
                    }
                }
                for (g_947 = 0; (g_947 <= 0); g_947 += 1)
                { /* block id: 1189 */
                    int32_t *l_2799 = &g_2369[0][0][9];
                    int32_t **l_2825 = &l_2285[2];
                    for (g_1689 = 1; (g_1689 >= 0); g_1689 -= 1)
                    { /* block id: 1192 */
                        uint8_t *l_2808[3];
                        struct S0 ***l_2821[4][2];
                        int8_t * const *l_2824 = &l_2017;
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_2808[i] = &g_380;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_2821[i][j] = &g_1795;
                        }
                        l_2799 = g_1072[(g_947 + 1)][(g_947 + 4)];
                        (**g_2687) |= (l_2520[(g_1689 + 4)] || (((*l_2017) |= (safe_mul_func_uint16_t_u_u(((*l_2014) < 0x739512A2L), (safe_div_func_uint64_t_u_u(((p_41.f0 && (g_2693 = ((*l_2437) &= ((p_41.f0 ^ ((p_40 >= ((((+(*l_2590)) & (safe_mul_func_uint16_t_u_u(((*l_2014) < ((((*p_42) = 3L) , &g_2066) != l_2799)), g_1689))) & 1L) || (-1L))) , g_837)) > l_2807[5])))) & 0x566D08C7653ECA8ALL), 0x81AF41BFAFFB6A51LL))))) , l_2520[(g_1689 + 4)]));
                        (**g_2687) = p_41.f0;
                        (*g_2156) = (((*p_42) ^ (safe_sub_func_uint64_t_u_u(0xAFC6B86DBEE4DA2CLL, (*p_42)))) , ((safe_mul_func_uint16_t_u_u(p_40, ((*g_2507) & ((!(safe_sub_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((+(((*l_2319) = g_2819[3]) == l_2821[3][1])), (safe_lshift_func_int8_t_s_s(((&g_1724 != l_2824) == 1L), 3)))), 0x9FFF4F0F04271E6DLL))) , p_41.f0)))) < (-1L)));
                    }
                    (*l_2825) = (*g_2687);
                    for (g_2693 = 0; (g_2693 <= 4); g_2693 += 1)
                    { /* block id: 1206 */
                        uint32_t l_2828 = 1UL;
                        uint16_t *l_2857 = &l_2780[5];
                        int32_t l_2858 = 7L;
                        int i, j;
                        (*g_2688) = (((0xFC1B61811629752ALL > ((*g_533) = (safe_lshift_func_int16_t_s_u(((**l_2594) = l_2828), (safe_rshift_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(((*l_2793) | ((safe_lshift_func_uint8_t_u_s(((l_2837[0][1][1] == (void*)0) && (((*l_2793) != (safe_add_func_uint8_t_u_u(((*l_2437) = (*l_2793)), (((g_105 ^ (safe_sub_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(l_2846, g_837)), p_41.f0)), 0x73L))) , (*p_42)) < (*l_2590))))) <= g_2531)), 2)) < p_40)), p_41.f0)), 2)))))) & g_271[5].f1) | (*l_2590));
                        (*l_2014) = ((p_41.f0 , (l_2858 = (safe_lshift_func_uint16_t_u_u((((!(*l_2590)) , p_40) | p_40), (!((safe_div_func_int32_t_s_s((!(l_2828 < ((((((safe_rshift_func_uint16_t_u_u(((*l_2857) = ((g_853 = ((safe_unary_minus_func_uint8_t_u(((void*)0 == g_1072[(g_947 + 1)][(g_947 + 1)]))) & (*g_533))) < 0x82BCL)), 11)) >= p_41.f0) < p_40) <= (*g_2507)) & 0xB5L) , (*l_2793)))), 0x54368FA0L)) && p_40)))))) >= p_41.f0);
                        if (p_41.f0)
                            break;
                    }
                }
            }
            else
            { /* block id: 1218 */
                int16_t l_2875 = (-1L);
                int32_t *l_2876[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_2876[i] = &l_2024;
                for (g_380 = (-23); (g_380 != 44); ++g_380)
                { /* block id: 1221 */
                    uint32_t ***l_2867 = &l_2749;
                    int32_t l_2874[6] = {0x545C8E80L,0x545C8E80L,0x545C8E80L,0x545C8E80L,0x545C8E80L,0x545C8E80L};
                    int i;
                    (*l_2014) |= (0x4A3151D1L < (((safe_mod_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((safe_add_func_int16_t_s_s(((*l_2439) = (((*l_2867) = (void*)0) == &g_2683)), p_40)), g_1689)), (safe_mul_func_int8_t_s_s(((void*)0 == &g_594), ((*g_533) && (safe_lshift_func_int16_t_s_u((safe_rshift_func_uint8_t_u_s((p_41.f0 != l_2874[3]), l_2875)), 9))))))) ^ (*p_42)) == p_40));
                }
                l_2876[1] = ((**l_2729) , &l_2520[3]);
                if (l_2370)
                    goto lbl_2877;
lbl_2877:
                for (l_2748 = 0; l_2748 < 3; l_2748 += 1)
                {
                    for (g_178 = 0; g_178 < 8; g_178 += 1)
                    {
                        l_2533[l_2748][g_178] = 0xEBACD056L;
                    }
                }
                for (g_1650 = 0; (g_1650 > 6); g_1650++)
                { /* block id: 1231 */
                    int32_t l_2883 = (-9L);
                    int16_t ** const l_2892[1] = {(void*)0};
                    int8_t l_2893[3][10] = {{0xEAL,0x1EL,0xF6L,1L,(-1L),(-1L),1L,0xF6L,0x1EL,0xEAL},{(-1L),0x1EL,0x3AL,(-10L),0x1BL,0x1EL,(-1L),0x1EL,0x1BL,(-10L)},{(-10L),0x60L,(-10L),0x1EL,0x1BL,0x99L,0xEAL,7L,7L,0xEAL}};
                    int32_t l_2894 = 0x4E46A7C7L;
                    int i, j;
                    (*l_2590) = (safe_lshift_func_int16_t_s_s((-2L), 13));
                    l_2894 |= (((7UL <= (!((((l_2883 || (safe_div_func_uint64_t_u_u((p_41.f0 > ((-6L) >= (((safe_sub_func_uint8_t_u_u(g_55, (safe_div_func_int32_t_s_s((((*p_42) ^ ((safe_div_func_int64_t_s_s(((*l_2605) = ((void*)0 != l_2892[0])), 0xFEBDD09BC50419C6LL)) && 0xF014C9FEDD757BACLL)) ^ 0xDB9AL), p_41.f0)))) ^ 0x7F951FFDL) && l_2893[2][8]))), p_40))) > (*l_2590)) || p_40) <= g_2689[0]))) , p_41.f0) , 0xBF6E8A73L);
                }
            }
            if (((*l_2590) && ((safe_mul_func_uint16_t_u_u(((*l_2025) = ((safe_lshift_func_int16_t_s_u((&g_342 != ((*l_2901) = g_2899)), (((l_2902[5] == &g_998[2]) || ((l_2904 = &g_594) == l_2905)) , (*l_2590)))) > ((((p_41.f0 & 0xFB842AC2L) <= 1L) >= 0UL) | 0xE12E4BF430DAA9E5LL))), 8L)) & 0x1A78L)))
            { /* block id: 1240 */
                int8_t l_2918 = 0xAFL;
                if (((safe_sub_func_int16_t_s_s(p_40, (safe_sub_func_int64_t_s_s(((l_2910 = p_42) != (void*)0), ((safe_rshift_func_int16_t_s_s((safe_add_func_int16_t_s_s(p_40, (p_41.f0 > ((*g_2900) ^ (((*p_42) , ((safe_mul_func_uint8_t_u_u((p_41.f0 & (((l_2564 , g_2323.f0) , (void*)0) != p_42)), (*g_2900))) < l_2917[1][0][4])) <= (*l_2590)))))), (*l_2590))) < 0xDEL))))) , l_2918))
                { /* block id: 1242 */
                    return p_41.f0;
                }
                else
                { /* block id: 1244 */
                    int32_t l_2919 = 0x1AA99E74L;
                    return l_2919;
                }
            }
            else
            { /* block id: 1247 */
                int16_t ***l_2922 = &g_1907[1];
                struct S0 *l_2925 = &g_2926;
                int32_t l_2934 = 3L;
                int32_t l_2951 = 0x757C9443L;
                int32_t *l_2961[7][3] = {{&g_1606[7][1],(void*)0,&g_1606[4][1]},{&g_2369[2][1][4],&g_2689[1],&g_2369[2][1][4]},{&l_2026[0],&g_1606[7][1],&g_1606[4][1]},{&l_2454,&l_2454,&l_2024},{(void*)0,&g_1606[7][1],&g_1606[7][1]},{&l_2024,&g_2689[1],&g_2369[0][0][1]},{(void*)0,(void*)0,(void*)0}};
                int i, j;
                for (l_2846 = 0; (l_2846 <= 59); ++l_2846)
                { /* block id: 1250 */
                    (*l_2014) |= (&l_2594 != l_2922);
                }
                (*l_2014) = (safe_add_func_int8_t_s_s(g_53, ((*l_2590) != p_41.f0)));
                l_2925 = &p_41;
                if (((((safe_mod_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(l_2931[1], 0x845BFBE83BFA716BLL)), (safe_rshift_func_int8_t_s_u(l_2934, (safe_mul_func_uint16_t_u_u((++(*l_2025)), (p_40 & (p_40 , ((*g_2507) < (l_2951 = (safe_mul_func_uint16_t_u_u(0UL, (((safe_add_func_uint64_t_u_u((l_2950 = ((((safe_rshift_func_int16_t_s_s(0L, (safe_add_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u(0xF166L, l_2949)) | 249UL), (*g_2507))))) <= (**g_2899)) & 0x7CL) ^ (*l_2590))), 1UL)) <= (*g_2688)) & 4294967294UL))))))))))))) | l_2952) | (*l_2590)) , p_41.f0))
                { /* block id: 1258 */
                    int16_t l_2953[8][1][4] = {{{4L,1L,0x07FAL,0x00DEL}},{{1L,0xBDF2L,1L,4L}},{{0L,0x8014L,0x8014L,0L}},{{0L,0x00DEL,1L,0xF39CL}},{{1L,0L,0x07FAL,0x0DD1L}},{{4L,0L,4L,0x0DD1L}},{{0x07FAL,0L,1L,0xF39CL}},{{1L,0x00DEL,0L,0L}}};
                    uint16_t l_2954[4];
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_2954[i] = 0x78A9L;
                    l_2951 = l_2953[3][0][2];
                    return l_2954[1];
                }
                else
                { /* block id: 1261 */
                    uint64_t l_2957 = 18446744073709551606UL;
                    const uint32_t ****l_2978 = &l_2977;
                    const int64_t l_2994 = 1L;
                    uint32_t l_2995 = 1UL;
                    const uint64_t l_2997 = 0xE4AA95250DB643D5LL;
                    uint32_t l_3017 = 4294967295UL;
                    struct S1 l_3030[7] = {{{22818},0xF2367A98L},{{22818},0xF2367A98L},{{26665},8UL},{{22818},0xF2367A98L},{{22818},0xF2367A98L},{{26665},8UL},{{22818},0xF2367A98L}};
                    int16_t l_3035 = 0xB0AAL;
                    int i;
                    for (l_2130 = 0; (l_2130 > 24); l_2130 = safe_add_func_uint32_t_u_u(l_2130, 1))
                    { /* block id: 1264 */
                        l_2957++;
                        l_2961[4][0] = l_2960[0][0][5];
                        (*l_2590) |= ((*g_2156) = l_2957);
                        (**g_2687) = p_40;
                    }
                    if ((safe_mod_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(((+((safe_sub_func_int64_t_s_s((safe_mul_func_uint8_t_u_u(((g_105 ^= (safe_mul_func_uint8_t_u_u((((((*l_2978) = l_2977) == ((((safe_add_func_uint8_t_u_u((p_40 < (safe_mul_func_int8_t_s_s(p_40, (l_2983[2][7][0] , ((***l_2901) &= ((l_2995 = (((safe_sub_func_uint32_t_u_u((p_40 || (((safe_add_func_int64_t_s_s((*p_42), (safe_div_func_int64_t_s_s((l_2957 == (safe_mod_func_uint8_t_u_u(((p_41 , ((safe_mul_func_int8_t_s_s(((*l_2017) = g_1485[3][3][1]), 0x18L)) != 0x3BL)) | l_2957), p_40))), (*g_533))))) == p_41.f0) >= l_2994)), 0x863BA7BFL)) , p_40) <= p_41.f0)) != 255UL)))))), 0UL)) >= g_2369[0][1][7]) && (*g_533)) , l_2996)) , (void*)0) != (void*)0), g_59[2][2]))) == 0x8CE44BD025288064LL), g_837)), l_2997)) < 0L)) != p_41.f0), 3)), p_41.f0)) ^ 3L), p_40)) != (*l_2590)), g_1643)))
                    { /* block id: 1276 */
                        int8_t l_3004 = 0x6BL;
                        uint16_t **l_3020[5][10][3] = {{{&l_2025,(void*)0,(void*)0},{&l_2025,&l_2025,(void*)0},{(void*)0,&l_2025,(void*)0},{&l_2025,&l_2025,(void*)0},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025}},{{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,(void*)0},{&l_2025,&l_2025,(void*)0},{&l_2025,&l_2025,(void*)0},{(void*)0,&l_2025,(void*)0},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,(void*)0},{(void*)0,&l_2025,&l_2025}},{{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,(void*)0},{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,(void*)0,(void*)0},{&l_2025,&l_2025,&l_2025}},{{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,(void*)0},{&l_2025,&l_2025,&l_2025},{&l_2025,(void*)0,&l_2025},{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025}},{{&l_2025,&l_2025,(void*)0},{&l_2025,&l_2025,&l_2025},{(void*)0,&l_2025,(void*)0},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,(void*)0},{(void*)0,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025},{&l_2025,&l_2025,&l_2025}}};
                        uint32_t l_3033[3];
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_3033[i] = 1UL;
                        (**g_2687) = (safe_lshift_func_int16_t_s_u(((1L || 0x510DB3CAL) , (l_2995 & (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(l_3004, (safe_sub_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u(((**g_2899) = 0xC3L), ((*l_2437)--))) & (safe_mod_func_uint64_t_u_u(g_947, (safe_add_func_int32_t_s_s((p_41.f0 != (safe_mul_func_uint8_t_u_u(l_3017, 0xEBL))), 0UL))))), l_2957)))), 0UL)))), 12));
                        (*g_2688) = (((p_41.f0 , ((((p_40 && (((l_3018 = &l_2130) == (g_3021 = (void*)0)) < (safe_div_func_uint32_t_u_u(p_40, (((safe_rshift_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((((-9L) ^ (((safe_add_func_int16_t_s_s((l_3030[0] , (safe_add_func_uint8_t_u_u((**g_2899), p_41.f0))), (*l_2014))) == g_1178[0][0]) <= p_40)) , 5UL) || p_41.f0), 6)), g_3019)) & l_3033[2]) | l_3004))))) >= g_389) >= l_3034) >= (*g_2507))) , l_3030[0].f0.f0) == g_351[9].f0);
                        return p_41.f0;
                    }
                    else
                    { /* block id: 1284 */
                        (*l_2014) = p_40;
                        return l_3035;
                    }
                }
            }
        }
    }
    return p_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_380 g_55 g_31 g_785 g_271.f1 g_173 g_29 g_1689 g_1323 g_1606 g_732 g_1795 g_1794 g_350 g_108 g_837 g_533 g_919.f0 g_1178 g_1643 g_89 g_105 g_64 g_120 g_59 g_53 g_33 g_101 g_178 g_181 g_265 g_271 g_282 g_389 g_229 g_351.f0 g_478 g_515
 * writes: g_380 g_1650 g_1606 g_101 g_108 g_1907 g_350 g_265 g_785 g_837 g_1643 g_33 g_59 g_55 g_105 g_53 g_120 g_64 g_173 g_178 g_181 g_29 g_229 g_389 g_478 g_533 g_515 g_594
 */
static int16_t * func_43(int64_t * p_44, uint16_t  p_45, uint32_t  p_46, int16_t * p_47, int8_t  p_48)
{ /* block id: 725 */
    uint32_t l_1856 = 0x338FF5B6L;
    uint8_t *l_1857[5];
    int32_t l_1858 = 0xE5B07CA2L;
    struct S0 l_1865[2] = {{29739},{29739}};
    uint16_t *l_1876[7][9][3] = {{{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853}},{{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947}},{{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853}},{{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947}},{{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853}},{{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947}},{{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853},{&g_947,&g_947,&g_947},{&g_853,&g_853,&g_853}}};
    int32_t l_1877 = (-1L);
    int32_t *l_1878 = &g_1606[2][1];
    const int32_t **** const l_1897 = (void*)0;
    uint8_t **l_1911 = &l_1857[3];
    uint8_t *** const l_1910 = &l_1911;
    int32_t l_1945 = 0x442D29BEL;
    int32_t l_1947 = 0x326C6650L;
    int32_t l_1948 = 0x93BF3993L;
    int32_t l_1949 = 0xB4C06FF5L;
    int32_t *l_2001 = &l_1945;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_1857[i] = &g_120;
lbl_1914:
    (*l_1878) = (((safe_mul_func_uint8_t_u_u(255UL, (l_1877 &= (safe_mod_func_int64_t_s_s((safe_sub_func_int32_t_s_s((0x890807594A06245DLL & (((g_1650 = (safe_sub_func_int64_t_s_s(l_1856, (((((--g_380) < ((safe_rshift_func_uint8_t_u_u((g_55 ^ ((*p_47) ^ (((safe_rshift_func_int8_t_s_u(0x9DL, 3)) <= (((l_1865[0] , (p_45 = (safe_sub_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u(p_48, (safe_div_func_int64_t_s_s((safe_sub_func_uint8_t_u_u(l_1858, g_785)), 0x54EC073518307703LL)))) <= p_46), l_1865[0].f0)), l_1865[0].f0)))) >= 1L) || p_46)) < p_46))), 1)) || g_271[5].f1)) >= l_1865[0].f0) <= p_48) < l_1856)))) && g_173) != (-8L))), l_1856)), (*p_44)))))) ^ l_1856) < 1UL);
    for (p_46 = (-1); (p_46 == 56); p_46 = safe_add_func_uint8_t_u_u(p_46, 9))
    { /* block id: 733 */
        struct S1 l_1891 = {{9100},0x12F34F13L};
        int8_t *l_1898[8][3][4] = {{{&g_101,&g_478,&g_101,&g_478},{&g_478,(void*)0,&g_101,&g_101},{&g_101,&g_101,&g_478,&g_101}},{{&g_478,(void*)0,&g_478,&g_478},{&g_478,&g_478,&g_478,&g_478},{&g_101,&g_478,&g_101,&g_478}},{{&g_478,(void*)0,&g_101,&g_101},{&g_101,&g_101,&g_478,&g_101},{&g_478,(void*)0,&g_478,&g_478}},{{&g_478,&g_478,&g_478,&g_478},{&g_101,&g_478,&g_101,&g_478},{&g_478,(void*)0,&g_101,&g_101}},{{&g_101,&g_101,&g_478,&g_101},{&g_478,(void*)0,&g_478,&g_478},{&g_478,&g_478,&g_478,&g_478}},{{&g_101,&g_478,&g_101,&g_478},{&g_478,(void*)0,&g_101,&g_101},{&g_101,&g_101,&g_478,&g_101}},{{&g_478,(void*)0,&g_478,&g_478},{&g_478,&g_478,&g_478,&g_478},{&g_101,&g_478,&g_101,&g_478}},{{&g_478,(void*)0,&g_101,&g_101},{&g_101,&g_101,&g_478,&g_101},{&g_478,(void*)0,&g_478,&g_478}}};
        int32_t *l_1917 = (void*)0;
        int32_t l_1938 = (-10L);
        int32_t l_1953 = 0xDDADC4A1L;
        int64_t l_1993 = 0xA8F2DADF474F706BLL;
        int16_t *l_2012 = (void*)0;
        int i, j, k;
        if (p_46)
            break;
        if ((safe_lshift_func_int16_t_s_u((safe_add_func_uint16_t_u_u(g_1689, (safe_div_func_uint16_t_u_u(g_380, (safe_rshift_func_uint8_t_u_u((g_1323 != (*l_1878)), ((0x3EB82C922FB3F09ALL == (safe_div_func_uint64_t_u_u(((l_1891 , (!(l_1891.f1 , (g_101 = (safe_sub_func_int8_t_s_s(((-3L) & (((safe_rshift_func_uint16_t_u_u((((l_1891.f1 , (*p_44)) | (*l_1878)) && 0x55EB0C98L), g_732)) , (void*)0) == l_1897)), l_1891.f1)))))) | 0xAB40L), (*p_44)))) == l_1891.f1))))))), 15)))
        { /* block id: 736 */
            int16_t ***l_1903 = &g_108;
            int16_t *l_1906 = (void*)0;
            int16_t **l_1905 = &l_1906;
            int16_t ***l_1904[5][7];
            int8_t **l_1912 = &l_1898[0][2][1];
            const uint16_t l_1913 = 0x65C3L;
            int32_t l_1920 = 0L;
            int32_t l_1946 = 0xAF4D7E3AL;
            int32_t l_1952 = 0xE627C1F7L;
            int64_t l_2000 = 1L;
            int i, j;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 7; j++)
                    l_1904[i][j] = &l_1905;
            }
            if ((safe_sub_func_uint64_t_u_u(p_45, (safe_mod_func_int64_t_s_s(((((((((*l_1903) = &p_47) != (g_1907[1] = &p_47)) | (((void*)0 == p_47) < (((*l_1878) = 4294967295UL) <= (safe_mod_func_int16_t_s_s(((p_48 = ((void*)0 != l_1910)) , (((*l_1912) = ((g_732 & p_48) , (void*)0)) == (void*)0)), p_45))))) ^ l_1913) <= 6UL) > p_46) ^ 1UL), (-1L))))))
            { /* block id: 742 */
                int32_t *l_1919 = &g_173;
                int32_t l_1927 = 0xFB539FC7L;
                int32_t l_1939 = (-1L);
                int32_t l_1941 = 0x09FE1A1AL;
                int32_t l_1942 = (-8L);
                int32_t l_1950 = 0x6B14B7E5L;
                int32_t l_1951 = 0x146F7BD4L;
                int32_t l_1954 = 0x867ABD2FL;
                const struct S0 *l_1969 = &g_351[9];
                struct S1 *l_1972 = &g_1973;
                if (g_29)
                    goto lbl_1914;
                (*g_1795) = (void*)0;
                for (l_1856 = (-17); (l_1856 < 6); ++l_1856)
                { /* block id: 747 */
                    int32_t l_1940 = 6L;
                    int32_t l_1943 = 0x3FAFA154L;
                    int32_t l_1944[9][3][7] = {{{0x8A2DFEC5L,0xC6940C80L,8L,(-1L),(-1L),8L,0xC6940C80L},{(-2L),1L,(-1L),0x425A4182L,0xC6940C80L,0x785005D0L,0x68B68357L},{0x49CC9603L,0xD26F9FFEL,0xC6940C80L,0L,0xD998E0ABL,(-2L),1L}},{{0xC6940C80L,0L,0L,0x425A4182L,1L,(-10L),3L},{0x785005D0L,1L,0xD998E0ABL,(-1L),0x425A4182L,(-1L),1L},{1L,1L,0L,(-1L),(-2L),0xE16D5FF9L,1L}},{{0xE16D5FF9L,7L,(-10L),0xD26F9FFEL,0L,1L,0x8A2DFEC5L},{0L,(-1L),3L,0x425A4182L,(-2L),0x8A2DFEC5L,1L},{0x879E0395L,0xD998E0ABL,0x68B68357L,2L,1L,1L,2L}},{{0x6C36EBB0L,0xD998E0ABL,0x6C36EBB0L,1L,0x8A2DFEC5L,(-2L),0x425A4182L},{0x49CC9603L,(-1L),8L,0x8A2DFEC5L,1L,0L,0xD26F9FFEL},{0L,7L,1L,1L,0xE16D5FF9L,(-2L),(-1L)}},{{8L,1L,(-1L),1L,0L,1L,0L},{8L,(-1L),(-1L),8L,0xC6940C80L,0x8A2DFEC5L,1L},{1L,(-1L),1L,(-1L),0x879E0395L,1L,3L}},{{7L,0x49CC9603L,8L,0L,1L,0xE16D5FF9L,1L},{2L,0x8A2DFEC5L,0x6C36EBB0L,0xE16D5FF9L,(-1L),0L,0L},{(-5L),0xE16D5FF9L,0x68B68357L,0xE16D5FF9L,(-5L),0xC6940C80L,(-1L)}},{{(-1L),0x6C36EBB0L,3L,0L,0x425A4182L,0x879E0395L,0xD26F9FFEL},{(-2L),(-5L),(-10L),(-1L),0x49CC9603L,1L,0x425A4182L},{(-1L),0L,0L,8L,0x68B68357L,(-1L),2L}},{{(-5L),0x68B68357L,1L,1L,0x68B68357L,(-5L),1L},{2L,0xD26F9FFEL,(-5L),1L,0x49CC9603L,0x425A4182L,0x8A2DFEC5L},{7L,0x785005D0L,0xE16D5FF9L,0x8A2DFEC5L,0x425A4182L,0x49CC9603L,1L}},{{1L,0xD26F9FFEL,0x785005D0L,1L,(-5L),0x68B68357L,1L},{8L,0x68B68357L,(-1L),2L,(-1L),0x68B68357L,8L},{8L,0L,2L,0x425A4182L,1L,0x49CC9603L,(-1L)}}};
                    struct S1 *l_1971[6][4] = {{&l_1891,&g_271[1],(void*)0,&g_271[1]},{&l_1891,(void*)0,(void*)0,&g_271[1]},{(void*)0,&g_271[1],(void*)0,(void*)0},{&l_1891,&g_271[1],(void*)0,&g_271[1]},{&l_1891,(void*)0,(void*)0,&g_271[1]},{(void*)0,&g_271[1],(void*)0,(void*)0}};
                    struct S1 **l_1970 = &l_1971[4][0];
                    int i, j, k;
                    for (g_265 = 0; (g_265 <= 1); g_265 += 1)
                    { /* block id: 750 */
                        int32_t **l_1918 = &l_1917;
                        int32_t *l_1921 = &l_1920;
                        int32_t *l_1922 = &l_1877;
                        int32_t *l_1923 = &l_1920;
                        int32_t *l_1924 = &g_173;
                        int32_t *l_1925 = (void*)0;
                        int32_t *l_1926 = &g_173;
                        int32_t *l_1928 = (void*)0;
                        int32_t *l_1929 = &g_173;
                        int32_t *l_1930 = &g_53;
                        int32_t *l_1931 = &l_1927;
                        int32_t *l_1932 = &l_1858;
                        int32_t *l_1933 = &g_173;
                        int32_t *l_1934 = &g_173;
                        int32_t *l_1935 = &g_1606[4][1];
                        int32_t *l_1936 = &l_1927;
                        int32_t *l_1937[9][9] = {{&g_173,(void*)0,&g_1606[7][1],(void*)0,&g_173,&g_1606[1][3],&l_1858,&l_1877,&l_1877},{(void*)0,&g_1606[4][4],&g_53,(void*)0,&g_53,&l_1858,&g_1606[7][1],&g_1606[7][1],&g_173},{&g_1606[7][1],&g_173,&g_1606[7][1],&g_1606[4][4],&g_1606[7][1],&g_1606[4][4],&g_1606[7][1],&g_173,&g_1606[7][1]},{&l_1858,&g_1606[4][4],&g_1606[7][1],&g_1606[7][1],&l_1877,&g_53,&l_1877,&g_1606[7][1],&g_1606[7][1]},{&l_1877,&l_1877,&l_1858,&g_1606[1][3],&g_173,(void*)0,&g_1606[7][1],(void*)0,&g_173},{&l_1858,&l_1877,&l_1877,&l_1858,&g_1606[1][3],&g_173,(void*)0,&g_1606[7][1],(void*)0},{&g_1606[7][1],&g_1606[4][4],&l_1858,&l_1858,&g_1606[4][4],&g_1606[7][1],&g_1606[7][1],&l_1877,&g_53},{&g_1606[7][1],&g_173,&g_1606[7][1],&g_1606[1][3],&g_1606[1][3],&g_1606[7][1],&g_173,&g_1606[7][1],&g_1606[4][4]},{&g_53,&l_1858,&g_1606[7][1],&g_1606[7][1],&g_173,&g_173,&g_1606[7][1],&g_1606[7][1],&l_1858}};
                        uint32_t l_1955 = 9UL;
                        int i, j;
                        l_1919 = ((*l_1918) = l_1917);
                        if (g_173)
                            goto lbl_1914;
                        l_1955++;
                        (*l_1878) = ((safe_div_func_int16_t_s_s((*l_1924), (((safe_mul_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_unary_minus_func_int32_t_s((safe_lshift_func_uint16_t_u_u(p_48, 2)))), (safe_add_func_int16_t_s_s((l_1969 != (**g_1794)), 8L)))), ((**g_108) | ((l_1940 = l_1938) , (0UL == 0xAEBCL))))) & p_45) ^ g_1689))) <= 1L);
                    }
                    l_1972 = ((*l_1970) = &g_271[1]);
                    (*l_1878) = (*l_1878);
                }
            }
            else
            { /* block id: 762 */
                int32_t l_1998 = 1L;
                int32_t l_2003 = 0L;
                int32_t l_2004 = 6L;
                int32_t l_2006 = 0xD763776FL;
                for (g_785 = 0; (g_785 < 10); g_785 = safe_add_func_uint32_t_u_u(g_785, 6))
                { /* block id: 765 */
                    return p_47;
                }
                for (g_837 = 2; (g_837 <= 7); g_837 += 1)
                { /* block id: 770 */
                    uint64_t *l_1999 = &g_1643;
                    int32_t l_2005 = 8L;
                    int32_t *l_2011 = &l_1877;
                    int i;
                    if ((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((p_46 > p_48), (safe_sub_func_uint32_t_u_u((1UL != (((!(safe_rshift_func_int8_t_s_s((safe_div_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((((*l_1878) && (safe_sub_func_uint64_t_u_u(((*l_1999) &= ((((*g_533) <= ((((l_1993 &= g_919.f0) == 247UL) , ((safe_div_func_int8_t_s_s((safe_div_func_int8_t_s_s((((**g_1794) == (**g_1794)) , p_45), l_1946)), l_1998)) , l_1920)) == l_1998)) , g_1178[1][5]) != 1L)), l_2000))) > (*p_44)), 255UL)), p_45)), p_48))) != p_46) < l_1998)), l_1998)))), 15)) && p_45), l_1998)))
                    { /* block id: 773 */
                        int32_t *l_2002[6][10][4] = {{{&l_1938,(void*)0,(void*)0,(void*)0},{&l_1938,&l_1938,&l_1947,&l_1946},{&l_1947,&g_53,&l_1947,&l_1948},{&l_1945,&l_1946,(void*)0,&l_1947},{&l_1953,&l_1946,&l_1938,&l_1948},{&l_1946,&g_53,(void*)0,&l_1946},{&l_1952,&l_1938,&l_1947,(void*)0},{&l_1877,(void*)0,(void*)0,&l_1938},{&g_1606[0][0],&l_1953,&l_1946,&l_1947},{(void*)0,&l_1953,&g_53,(void*)0}},{{&l_1949,&l_1945,&l_1948,&l_1947},{&l_1938,&l_1946,(void*)0,&l_1946},{&g_53,(void*)0,&l_1920,&l_1953},{&l_1947,&l_1949,&l_1945,&l_1938},{&l_1946,&l_1920,&l_1953,&g_1606[7][1]},{&l_1946,&l_1946,&l_1945,&g_1606[7][2]},{&l_1947,&g_1606[7][1],&l_1920,&g_1606[4][3]},{&g_53,&l_1948,(void*)0,&l_1949},{&l_1938,&g_1606[0][0],&l_1948,&g_53},{&l_1949,&l_1952,&g_53,&l_1949}},{{(void*)0,&l_1945,&l_1946,&l_1947},{&g_1606[0][0],(void*)0,(void*)0,(void*)0},{&l_1877,&l_1947,&l_1947,&l_1877},{&l_1952,&l_1948,(void*)0,(void*)0},{&l_1946,&l_1949,&l_1938,&l_1946},{&l_1953,&g_1606[4][3],(void*)0,&l_1946},{&l_1945,&l_1949,&l_1947,(void*)0},{&l_1947,&l_1948,&l_1947,&l_1877},{&l_1938,&l_1947,(void*)0,(void*)0},{&l_1938,(void*)0,&l_1953,&l_1947}},{{&l_1945,&l_1946,&l_1947,&g_1606[4][3]},{&l_1877,&l_1920,&g_1606[7][2],(void*)0},{&l_1946,&l_1947,&l_1945,(void*)0},{&l_1948,&l_1877,&l_1948,&l_1946},{&l_1946,(void*)0,&g_1606[4][3],&l_1938},{(void*)0,&g_53,&l_1953,(void*)0},{&g_1606[7][1],&l_1947,&l_1953,(void*)0},{(void*)0,&l_1946,&g_1606[4][3],(void*)0},{&l_1946,(void*)0,&l_1948,(void*)0},{&l_1948,(void*)0,&l_1945,(void*)0}},{{&l_1946,&l_1947,&g_1606[7][2],&g_1606[7][1]},{&l_1877,(void*)0,&l_1947,&l_1949},{&l_1953,(void*)0,(void*)0,&g_1606[7][2]},{&l_1949,&g_53,&l_1946,&l_1946},{(void*)0,(void*)0,&l_1949,&g_1606[0][0]},{&l_1953,(void*)0,&l_1938,&l_1947},{&l_1947,&l_1945,&g_53,&l_1938},{(void*)0,&l_1945,&l_1949,&l_1947},{&l_1945,(void*)0,&l_1945,&g_1606[0][0]},{&l_1920,(void*)0,(void*)0,&l_1946}},{{&l_1938,&g_53,&l_1952,&g_1606[7][2]},{&l_1947,(void*)0,(void*)0,&l_1949},{&l_1952,(void*)0,(void*)0,&g_1606[7][1]},{(void*)0,&l_1947,&l_1947,(void*)0},{&g_1606[7][2],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1947,(void*)0},{(void*)0,&l_1946,&l_1953,(void*)0},{&g_1606[0][0],&l_1947,(void*)0,(void*)0},{&g_1606[0][0],&g_53,&l_1953,&l_1938},{(void*)0,(void*)0,&l_1947,&l_1946}}};
                        uint32_t l_2007 = 0x73580E3BL;
                        int i, j, k;
                        l_2002[2][5][1] = func_69(l_2001);
                        l_2007++;
                        l_2002[2][5][1] = func_69(&l_1920);
                    }
                    else
                    { /* block id: 777 */
                        int32_t **l_2010[5][5][2] = {{{&l_2001,(void*)0},{&l_2001,&l_2001},{(void*)0,(void*)0},{(void*)0,&l_2001},{&l_2001,(void*)0}},{{&l_2001,&l_2001},{(void*)0,(void*)0},{(void*)0,&l_2001},{&l_2001,(void*)0},{&l_2001,&l_2001}},{{(void*)0,(void*)0},{(void*)0,&l_2001},{&l_2001,(void*)0},{&l_2001,&l_2001},{(void*)0,(void*)0}},{{(void*)0,&l_2001},{&l_2001,(void*)0},{&l_2001,&l_2001},{(void*)0,(void*)0},{(void*)0,&l_2001}},{{&l_2001,(void*)0},{&l_2001,&l_2001},{(void*)0,(void*)0},{(void*)0,&l_2001},{&l_2001,(void*)0}}};
                        int i, j, k;
                        (*l_2001) |= l_2005;
                        l_2011 = &l_1946;
                        l_1917 = &l_1946;
                    }
                    return p_47;
                }
            }
        }
        else
        { /* block id: 785 */
            return l_2012;
        }
    }
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_53 g_55 g_59 g_64 g_33 g_89 g_31 g_105 g_108 g_120 g_101 g_173 g_178 g_181 g_29 g_265 g_271 g_282 g_350 g_389 g_229 g_351.f0 g_533 g_478 g_515 g_380 g_732 g_1178 g_656 g_837 g_919.f0 g_947 g_1323 g_853 g_1485 g_594 g_998 g_1606 g_1643 g_1647 g_1689 g_1723 g_1724 g_1595
 * writes: g_53 g_55 g_59 g_64 g_33 g_101 g_105 g_108 g_120 g_173 g_178 g_181 g_29 g_229 g_265 g_380 g_389 g_478 g_533 g_515 g_594 g_732 g_837 g_1071 g_947 g_853 g_1323 g_1485 g_1606 g_656 g_1689
 */
static uint16_t  func_50(int16_t * p_51)
{ /* block id: 7 */
    int32_t *l_52 = &g_53;
    int32_t l_58 = (-1L);
    int32_t l_63 = 0x35443C7FL;
    const int32_t * const l_1488 = (void*)0;
    int64_t **l_1493 = &g_533;
    struct S0 l_1496 = {14095};
    int32_t l_1513 = (-9L);
    int32_t l_1514[9];
    uint8_t * const **l_1551 = (void*)0;
    int8_t *l_1553 = &g_478;
    int64_t l_1704[9] = {0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL,0x959B0F975EA612ACLL};
    struct S1 *l_1755 = (void*)0;
    int64_t l_1832 = 0L;
    int i;
    for (i = 0; i < 9; i++)
        l_1514[i] = 0x9CAC45A1L;
    if (((*l_52) |= 1L))
    { /* block id: 9 */
        int32_t *l_54 = &g_55;
        int32_t *l_56 = (void*)0;
        int32_t *l_57[7] = {&g_55,&g_55,&g_55,&g_55,&g_55,&g_55,&g_55};
        int32_t *l_1447[5][8][6] = {{{&l_63,&l_63,&l_63,&g_53,&g_53,&g_55},{&g_53,&l_58,&g_55,&l_58,(void*)0,&g_53},{&g_53,(void*)0,&l_63,&l_63,(void*)0,&l_63},{&g_55,&l_63,(void*)0,&g_173,&g_173,&l_63},{&g_53,&l_63,&l_58,&g_173,&l_58,&l_63},{&g_173,&l_58,&g_55,(void*)0,&l_58,&g_55},{(void*)0,&g_53,&g_173,&g_173,&l_63,&l_63},{&l_58,&g_53,&l_63,&g_53,&g_173,&l_63}},{{&g_173,&g_53,&l_63,&l_63,&g_53,&g_173},{(void*)0,&g_55,&l_58,&g_53,&g_55,&g_53},{&g_55,&g_55,&l_63,&l_58,&g_173,&g_55},{&g_55,&l_63,&l_58,&g_53,&g_53,(void*)0},{(void*)0,&g_55,&l_58,&l_63,(void*)0,&g_53},{&g_173,&g_173,&g_55,&g_53,&l_58,&l_63},{&l_58,&l_63,&l_58,&g_173,&g_55,&g_55},{(void*)0,&g_173,&g_53,(void*)0,&g_173,&l_58}},{{&g_173,(void*)0,&g_53,&g_173,&l_63,&l_63},{&g_53,&l_58,&l_63,&g_173,&g_53,&g_55},{&g_55,&g_173,&g_173,&l_63,&g_53,&g_173},{&g_53,&g_55,&l_63,&l_58,&l_63,&l_58},{&g_53,&g_173,&g_53,&g_55,(void*)0,&g_55},{&g_55,&l_63,&g_55,&l_58,&g_53,&l_58},{&g_53,(void*)0,&g_55,&g_173,&l_63,&g_53},{(void*)0,(void*)0,(void*)0,&g_55,&g_55,&g_53}},{{&g_55,&g_53,(void*)0,&g_53,(void*)0,&g_53},{&g_173,&g_53,&l_63,&g_173,&g_55,&l_58},{&g_53,&g_53,&g_53,&l_58,(void*)0,&g_173},{(void*)0,&g_53,&l_58,&g_173,&g_55,&l_58},{&l_58,&g_53,&g_53,&l_58,(void*)0,&g_173},{&g_53,&g_53,&g_55,&g_53,&g_55,&g_55},{&g_53,(void*)0,&l_63,&g_53,&l_63,(void*)0},{&g_173,(void*)0,&g_53,&l_63,&g_53,&l_63}},{{&g_53,&l_63,&g_55,&g_53,(void*)0,(void*)0},{&g_55,&g_53,&g_173,&g_53,&g_53,(void*)0},{&l_63,(void*)0,&l_58,&g_53,&l_63,&g_53},{&l_63,(void*)0,&g_173,&g_53,&g_53,&l_63},{&g_173,(void*)0,&l_58,&g_53,&g_53,&g_173},{&g_53,&l_58,&g_173,&l_58,&g_53,&l_63},{&g_53,(void*)0,&g_53,&g_173,&g_173,&l_58},{&g_55,&l_58,&g_55,(void*)0,(void*)0,&g_53}}};
        int32_t l_1483 = 0x9612B23DL;
        int i, j, k;
        (*l_54) ^= (5L < ((*l_52) = g_53));
        if (g_55)
            goto lbl_62;
lbl_62:
        g_59[2][2]++;
        ++g_64;
        if (func_67(func_69(&l_58)))
        { /* block id: 597 */
            int32_t *l_1444 = &g_55;
            int32_t **l_1445 = &l_54;
            int32_t **l_1446 = (void*)0;
            l_1447[2][2][3] = ((*l_1445) = &l_63);
        }
        else
        { /* block id: 600 */
            const uint64_t l_1458 = 0x7348180519AE1099LL;
            uint64_t *l_1475 = &g_105;
            int16_t *l_1482[10][5][5] = {{{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31}},{{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515}},{{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31},{&g_515,&g_515,&g_515,&g_515,&g_515},{&g_31,&g_31,&g_31,&g_31,&g_31}}};
            int64_t *l_1484 = &g_1485[3][3][1];
            int32_t *l_1505 = &l_63;
            int32_t l_1509 = 0xE1D05FABL;
            int32_t l_1510 = (-1L);
            int8_t l_1511 = 1L;
            int32_t l_1512[5] = {0xB923694FL,0xB923694FL,0xB923694FL,0xB923694FL,0xB923694FL};
            int32_t l_1515 = 0x07FB1575L;
            int16_t l_1520 = (-3L);
            uint8_t l_1531 = 252UL;
            int i, j, k;
            (*l_54) = (safe_rshift_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s((((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s((safe_div_func_int64_t_s_s(l_1458, (*l_52))), (*l_52))), 6)) < 0L) || ((~3L) && ((*l_1484) ^= (safe_rshift_func_int8_t_s_s((safe_mod_func_int32_t_s_s(((((~255UL) >= (safe_rshift_func_uint16_t_u_u(((safe_mod_func_int16_t_s_s(((((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((((*l_1475) = 1UL) && ((safe_div_func_uint64_t_u_u((*l_52), ((safe_add_func_int8_t_s_s((((g_515 = ((safe_sub_func_uint16_t_u_u(0xDC33L, (*p_51))) == 1UL)) , (*g_533)) == (*l_52)), g_59[0][0])) || l_1483))) < l_1458)) <= 0x3DL), (-6L))), g_351[9].f0)), l_1458)) || 0xBBL) <= (*l_52)) <= l_1458), g_33)) , g_947), 15))) || l_1458) < g_64), (*l_52))), 0))))), 0)) , (-1L)), 6));
            for (g_55 = 0; (g_55 != 13); g_55 = safe_add_func_int16_t_s_s(g_55, 1))
            { /* block id: 607 */
                const int32_t *l_1490 = &l_58;
                const int32_t **l_1489 = &l_1490;
                int32_t l_1494 = 0x2E451112L;
                int32_t l_1495 = (-8L);
                uint8_t *l_1506 = &g_120;
                int8_t *l_1507 = &g_101;
                int8_t l_1508 = 0x7EL;
                int32_t l_1516 = 0x093ECE18L;
                int32_t l_1517 = 0xD8A6AB32L;
                int32_t l_1518 = 9L;
                int32_t l_1519 = 0xFA55F43BL;
                int32_t l_1521 = 0x51AE52CFL;
                int32_t l_1522 = 0x73B28252L;
                int32_t l_1523 = 0L;
                int32_t l_1524 = (-4L);
                int32_t l_1525 = 0L;
                int32_t l_1526 = 0xEB8245E1L;
                int32_t l_1527 = 7L;
                int32_t l_1528 = 0xA5D21496L;
                int32_t l_1529 = 0L;
                int32_t l_1530[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_1530[i] = 0xA6DD13B8L;
                (*l_1489) = l_1488;
                (*l_52) ^= ((l_1494 ^= (safe_rshift_func_uint8_t_u_u((((&g_282[1] != &g_282[1]) , l_1493) != &l_1484), 1))) >= (l_1495 == (l_1496 , (~(safe_div_func_uint8_t_u_u((((*l_1507) ^= (((*l_1505) = ((safe_lshift_func_uint8_t_u_s(((*l_1506) = (safe_mod_func_uint16_t_u_u((g_351[9].f0 | ((~((void*)0 != l_1505)) & (*l_1505))), (*p_51)))), g_64)) < (*l_1505))) == g_515)) | g_173), (*l_54)))))));
                if ((*l_1505))
                    break;
                ++l_1531;
            }
        }
    }
    else
    { /* block id: 618 */
        int16_t l_1552 = 0x5B49L;
        uint8_t *l_1578 = &g_380;
        int32_t l_1584 = (-1L);
        int32_t **l_1589 = &g_1072[0][4];
        int64_t **l_1610 = &g_533;
        struct S0 l_1660 = {10396};
        int32_t l_1700 = 0L;
        int32_t l_1702 = 9L;
        int32_t l_1705 = 0x6C43198AL;
        int64_t l_1709[2];
        int32_t l_1710 = (-6L);
        int32_t l_1713 = 0L;
        int32_t *l_1719 = &l_1702;
        int8_t **l_1722 = &l_1553;
        struct S0 **l_1733 = (void*)0;
        uint32_t l_1743 = 18446744073709551615UL;
        int32_t l_1773 = 8L;
        int32_t l_1775 = (-5L);
        int32_t l_1808[1];
        int32_t *l_1835 = &g_173;
        int i;
        for (i = 0; i < 2; i++)
            l_1709[i] = 1L;
        for (i = 0; i < 1; i++)
            l_1808[i] = (-1L);
lbl_1557:
        for (g_853 = 9; (g_853 >= 5); g_853--)
        { /* block id: 621 */
            int32_t *l_1536 = (void*)0;
            int32_t *l_1556[9];
            int i;
            for (i = 0; i < 9; i++)
                l_1556[i] = &l_63;
            l_1536 = l_1536;
            l_58 &= (safe_mul_func_int16_t_s_s(0x7B83L, (safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((**l_1493) = (((g_33 >= ((safe_mul_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((((void*)0 != l_1551) , ((*g_533) || ((l_1552 , (void*)0) == l_1553))), (safe_rshift_func_int16_t_s_u(g_853, 4)))), g_478)) | l_1552), g_380)) != 0x06DDAEAFL)) , l_1552) & 0xE99787E2L)), (*g_594))), (*l_52)))));
            if (l_63)
                goto lbl_1557;
        }
        for (g_120 = 0; (g_120 <= 4); g_120 += 1)
        { /* block id: 629 */
            const uint64_t l_1579[9][6][4] = {{{18446744073709551606UL,18446744073709551613UL,18446744073709551606UL,18446744073709551609UL},{9UL,7UL,18446744073709551615UL,0x721067E4E003498FLL},{18446744073709551615UL,0x6E497FEC33DBBA79LL,18446744073709551615UL,7UL},{7UL,0x30EAA17A278B3DE1LL,18446744073709551615UL,0x7956C5820FA813ACLL},{18446744073709551615UL,0x31BBF95C9D346609LL,18446744073709551615UL,0x6E497FEC33DBBA79LL},{9UL,18446744073709551608UL,18446744073709551606UL,18446744073709551608UL}},{{18446744073709551606UL,18446744073709551608UL,9UL,0x6E497FEC33DBBA79LL},{18446744073709551615UL,0x31BBF95C9D346609LL,18446744073709551615UL,0x7956C5820FA813ACLL},{18446744073709551615UL,0x30EAA17A278B3DE1LL,7UL,7UL},{18446744073709551615UL,0x6E497FEC33DBBA79LL,18446744073709551615UL,0x721067E4E003498FLL},{18446744073709551615UL,7UL,9UL,18446744073709551609UL},{18446744073709551606UL,18446744073709551613UL,18446744073709551606UL,18446744073709551609UL}},{{9UL,7UL,18446744073709551615UL,0x721067E4E003498FLL},{18446744073709551615UL,0x6E497FEC33DBBA79LL,18446744073709551615UL,7UL},{7UL,0x30EAA17A278B3DE1LL,18446744073709551615UL,0x7956C5820FA813ACLL},{18446744073709551615UL,0x31BBF95C9D346609LL,18446744073709551615UL,0x6E497FEC33DBBA79LL},{9UL,18446744073709551608UL,18446744073709551606UL,18446744073709551608UL},{18446744073709551606UL,18446744073709551608UL,9UL,0x6E497FEC33DBBA79LL}},{{18446744073709551615UL,0x31BBF95C9D346609LL,18446744073709551615UL,0x7956C5820FA813ACLL},{18446744073709551615UL,0x30EAA17A278B3DE1LL,7UL,7UL},{18446744073709551615UL,0x6E497FEC33DBBA79LL,18446744073709551606UL,0x31BBF95C9D346609LL},{1UL,0x30EAA17A278B3DE1LL,18446744073709551615UL,18446744073709551608UL},{0xE95920C693E124E9LL,0x721067E4E003498FLL,0xE95920C693E124E9LL,18446744073709551608UL},{18446744073709551615UL,0x30EAA17A278B3DE1LL,1UL,0x31BBF95C9D346609LL}},{{18446744073709551606UL,7UL,7UL,0x30EAA17A278B3DE1LL},{18446744073709551615UL,18446744073709551609UL,7UL,0x6E497FEC33DBBA79LL},{18446744073709551606UL,0xEE8402F4E16B1927LL,1UL,7UL},{18446744073709551615UL,18446744073709551613UL,0xE95920C693E124E9LL,18446744073709551613UL},{0xE95920C693E124E9LL,18446744073709551613UL,18446744073709551615UL,7UL},{1UL,0xEE8402F4E16B1927LL,18446744073709551606UL,0x6E497FEC33DBBA79LL}},{{7UL,18446744073709551609UL,18446744073709551615UL,0x30EAA17A278B3DE1LL},{7UL,7UL,18446744073709551606UL,0x31BBF95C9D346609LL},{1UL,0x30EAA17A278B3DE1LL,18446744073709551615UL,18446744073709551608UL},{0xE95920C693E124E9LL,0x721067E4E003498FLL,0xE95920C693E124E9LL,18446744073709551608UL},{18446744073709551615UL,0x30EAA17A278B3DE1LL,1UL,0x31BBF95C9D346609LL},{18446744073709551606UL,7UL,7UL,0x30EAA17A278B3DE1LL}},{{18446744073709551615UL,18446744073709551609UL,7UL,0x6E497FEC33DBBA79LL},{18446744073709551606UL,0xEE8402F4E16B1927LL,1UL,7UL},{18446744073709551615UL,18446744073709551613UL,0xE95920C693E124E9LL,18446744073709551613UL},{0xE95920C693E124E9LL,18446744073709551613UL,18446744073709551615UL,7UL},{1UL,0xEE8402F4E16B1927LL,18446744073709551606UL,0x6E497FEC33DBBA79LL},{7UL,18446744073709551609UL,18446744073709551615UL,0x30EAA17A278B3DE1LL}},{{7UL,7UL,18446744073709551606UL,0x31BBF95C9D346609LL},{1UL,0x30EAA17A278B3DE1LL,18446744073709551615UL,18446744073709551608UL},{0xE95920C693E124E9LL,0x721067E4E003498FLL,0xE95920C693E124E9LL,18446744073709551608UL},{18446744073709551615UL,0x30EAA17A278B3DE1LL,1UL,0x31BBF95C9D346609LL},{18446744073709551606UL,7UL,7UL,0x30EAA17A278B3DE1LL},{18446744073709551615UL,18446744073709551609UL,7UL,0x6E497FEC33DBBA79LL}},{{18446744073709551606UL,0xEE8402F4E16B1927LL,1UL,7UL},{18446744073709551615UL,18446744073709551613UL,0xE95920C693E124E9LL,18446744073709551613UL},{0xE95920C693E124E9LL,18446744073709551613UL,18446744073709551615UL,7UL},{1UL,0xEE8402F4E16B1927LL,18446744073709551606UL,0x6E497FEC33DBBA79LL},{7UL,18446744073709551609UL,18446744073709551615UL,0x30EAA17A278B3DE1LL},{7UL,7UL,18446744073709551606UL,0x31BBF95C9D346609LL}}};
            int32_t l_1580 = 0xCB5D8127L;
            int64_t * const l_1600 = &g_1485[8][3][1];
            int32_t * const *l_1602 = &l_52;
            int32_t * const **l_1601 = &l_1602;
            uint8_t **l_1608 = (void*)0;
            struct S0 l_1637 = {3943};
            uint32_t *l_1646[9][3] = {{(void*)0,(void*)0,(void*)0},{&g_732,&g_732,&g_732},{(void*)0,(void*)0,(void*)0},{&g_732,&g_732,&g_732},{(void*)0,(void*)0,(void*)0},{&g_732,&g_732,&g_732},{(void*)0,(void*)0,(void*)0},{&g_732,&g_732,&g_732},{(void*)0,(void*)0,(void*)0}};
            int32_t l_1712 = 1L;
            int32_t ***l_1728[8][8] = {{&g_1071,&g_1071,&l_1589,&g_1071,&g_1071,&l_1589,&g_1071,&g_1071},{&l_1589,&g_1071,&l_1589,&l_1589,&g_1071,&l_1589,&l_1589,&g_1071},{&g_1071,&l_1589,&l_1589,&g_1071,&l_1589,&l_1589,&g_1071,&l_1589},{&g_1071,&g_1071,&l_1589,&g_1071,&g_1071,&l_1589,&l_1589,&l_1589},{&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589},{&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589},{&l_1589,&l_1589,&g_1071,&l_1589,&l_1589,&g_1071,&l_1589,&l_1589},{&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589,&l_1589}};
            struct S0 ***l_1748 = &l_1733;
            int32_t l_1770 = 1L;
            int32_t l_1771 = (-1L);
            int32_t l_1774 = 0x25DBC38DL;
            int32_t l_1776 = 0x2A304FB8L;
            int32_t l_1777 = 0x876128C1L;
            int32_t l_1778 = (-1L);
            int32_t l_1807[2][4][3] = {{{0x1BAB4CFBL,0x1BAB4CFBL,0xA29DC04DL},{0xD32A2C6DL,5L,5L},{0xA29DC04DL,0x3A02755AL,0x584A6927L},{0xD32A2C6DL,6L,0xD32A2C6DL}},{{0x1BAB4CFBL,0xA29DC04DL,0x584A6927L},{0xCAD699D9L,0xCAD699D9L,5L},{0x485EA86DL,0xA29DC04DL,0xA29DC04DL},{5L,6L,3L}}};
            uint32_t l_1810 = 1UL;
            uint16_t l_1831 = 65535UL;
            int i, j, k;
            if (l_1552)
                break;
            for (g_732 = 0; (g_732 <= 4); g_732 += 1)
            { /* block id: 633 */
                int16_t *l_1581 = (void*)0;
                int16_t *l_1582 = (void*)0;
                int16_t *l_1583 = &g_837;
                int32_t l_1629 = 0xF0081E6AL;
                uint8_t * const l_1649 = &g_1650;
                uint8_t * const *l_1648 = &l_1649;
                int32_t l_1695 = 0xA85AFCAFL;
                int32_t l_1697 = 0x7C6196C5L;
                int32_t l_1706 = 0xF42131B5L;
                int32_t l_1707 = (-1L);
                int32_t l_1711 = 0L;
                uint8_t l_1779 = 0x80L;
                int32_t l_1809 = 0xB27F4D79L;
                int i, j;
                if (((+g_59[g_732][g_732]) > (!(safe_div_func_uint64_t_u_u((l_1584 = (((((((*l_1583) |= (g_59[g_732][g_732] == (g_1323 <= (((~(safe_mul_func_int16_t_s_s((((*l_52) = 0L) == (l_1580 = ((safe_add_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(((safe_sub_func_int64_t_s_s(((**l_1493) = (((((((((*g_533) > (((void*)0 == &g_342) >= (safe_lshift_func_uint8_t_u_u((((~((l_1552 , l_1578) != (void*)0)) ^ 5L) >= l_1579[4][0][3]), 4)))) == 0x3F61E009L) != (*g_594)) & l_1579[4][0][3]) , g_59[g_732][g_732]) > l_1552) >= g_59[g_732][g_732]) < l_1552)), l_1579[6][4][2])) , l_1552), 0xB1L)) != l_1552), (*p_51))) && g_265))), (*p_51)))) , (*g_533)) & g_101)))) >= (-1L)) & 18446744073709551614UL) < 0L) == (*g_594)) && l_1552)), l_1552)))))
                { /* block id: 639 */
                    uint64_t *l_1592 = (void*)0;
                    uint64_t *l_1593 = (void*)0;
                    uint64_t *l_1594[2];
                    int32_t **l_1596[3];
                    struct S0 l_1599 = {19652};
                    uint64_t l_1609 = 3UL;
                    int32_t l_1696 = (-3L);
                    int32_t l_1698 = (-2L);
                    int32_t l_1699 = 1L;
                    int32_t l_1701 = (-5L);
                    int32_t l_1703 = (-5L);
                    int32_t l_1708 = 0x04A2F5CBL;
                    int32_t l_1714[9][5][5] = {{{5L,0x215A640FL,0x215A640FL,5L,0x9B4BA76DL},{0xA22160FBL,0xF9D7C55EL,0x9B4BA76DL,1L,(-1L)},{0x4F8828E4L,1L,1L,0L,0L},{0x9B3FB945L,0xB9BBFD03L,(-1L),1L,0x3BD30668L},{0x73914FD9L,0L,5L,5L,0x577D8B59L}},{{0xCADC8A05L,0L,0xFF66E014L,0xBA5E52AEL,0x39D2D3F8L},{5L,0x50788636L,0xE2729E46L,1L,0xE1174037L},{0xE9AD56ACL,0xE4A39B29L,(-7L),(-1L),0L},{0x52DB716DL,0xB59077BDL,0xE6C3689CL,0xE9AD56ACL,0L},{0x50788636L,0x377BB496L,0xE977A1BCL,1L,1L}},{{0x586AD4F9L,(-9L),0x76406159L,0x7904644AL,0xC0C3FAB6L},{0L,0L,0x686EC9C9L,0x90C4AA87L,0x22C592EEL},{(-5L),1L,0x7904644AL,0xCADC8A05L,0x22C592EEL},{0L,0xE2729E46L,0x52DB716DL,0L,0xC0C3FAB6L},{0x59C7F945L,0L,1L,0x9B4BA76DL,1L}},{{0x39D2D3F8L,0x76406159L,0x3BB7A55CL,0L,0L},{0L,0x7499F762L,0xE1174037L,(-1L),0L},{0x377BB496L,(-1L),0xCB84FE89L,0x215A640FL,0xE1174037L},{0xE6C3689CL,(-1L),0xD8196E6BL,1L,0x39D2D3F8L},{0xC0C3FAB6L,0x577D8B59L,0x07CAE08DL,0x07CAE08DL,0x577D8B59L}},{{0xBA5E52AEL,0x829F7ECEL,0x586AD4F9L,(-6L),0x3BD30668L},{1L,0x59AC8227L,0x495F314CL,0x467DDB05L,0L},{0L,(-1L),0x59C7F945L,0x22C592EEL,(-1L)},{1L,0x90C4AA87L,0L,0xE977A1BCL,0x9B4BA76DL},{0xBA5E52AEL,1L,(-1L),0xA20538D8L,1L}},{{0xC0C3FAB6L,1L,0x99E3F484L,0x829F7ECEL,0L},{0xE6C3689CL,0x72A9483CL,0x377BB496L,0x22C592EEL,0x1EFE195CL},{(-1L),0x9B4BA76DL,0x1E26BCA6L,0x99E3F484L,0xB59077BDL},{(-6L),0x72A9483CL,0x8357EF8BL,(-1L),0x495F314CL},{0L,(-6L),0x7904644AL,0x577D8B59L,0xB9BBFD03L}},{{0x76406159L,0L,0L,0x686EC9C9L,0x90C4AA87L},{0x52DB716DL,0xE4A39B29L,1L,(-9L),0x59AC8227L},{0x686EC9C9L,0xE4A39B29L,1L,0xB9BBFD03L,1L},{0x9B4BA76DL,0L,0x90C4AA87L,0xBA5E52AEL,0x52DB716DL},{0x467DDB05L,(-6L),0xF9D7C55EL,0L,1L}},{{0x07CAE08DL,0x72A9483CL,0xE977A1BCL,0x60C9EE0AL,0L},{(-1L),0x9B4BA76DL,0xE1174037L,5L,(-1L)},{0x39D2D3F8L,(-1L),(-6L),0L,1L},{(-1L),0x59C7F945L,0x686EC9C9L,0xE977A1BCL,0xE977A1BCL},{0xE6C3689CL,(-9L),0xE6C3689CL,0L,5L}},{{0L,(-1L),1L,0x52DB716DL,0xF9D7C55EL},{0x3BB7A55CL,1L,0x4F8828E4L,0x3BD30668L,0xE4A39B29L},{0xEE6A92E6L,0x60C9EE0AL,1L,0xF9D7C55EL,0x76406159L},{0xB59077BDL,1L,0xE6C3689CL,1L,0x586AD4F9L},{0x59AC8227L,0L,0x686EC9C9L,0xE9AD56ACL,0x1E26BCA6L}}};
                    int32_t **l_1718[8] = {(void*)0,&l_52,&l_52,(void*)0,&l_52,&l_52,(void*)0,&l_52};
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_1594[i] = &g_1595;
                    for (i = 0; i < 3; i++)
                        l_1596[i] = (void*)0;
                    if (((*p_51) >= (safe_mod_func_uint64_t_u_u(((void*)0 != g_998[2]), ((*l_52) , (safe_lshift_func_uint16_t_u_u((l_1579[4][0][3] <= (l_1589 == ((((4294967295UL && 1UL) != ((*l_52) ^= ((safe_lshift_func_int16_t_s_s(((*l_1583) = (*p_51)), l_1580)) , (*g_594)))) , 0UL) , l_1596[0]))), 10)))))))
                    { /* block id: 642 */
                        int16_t **l_1603 = &l_1582;
                        int32_t l_1607 = 0xEAF956ACL;
                        uint64_t **l_1614 = &l_1593;
                        int8_t *l_1630 = &g_101;
                        int i, j;
                        (***l_1601) = (safe_add_func_uint64_t_u_u(((*g_594) = ((l_1599 , l_1600) == (((l_1601 == (l_1599.f0 , &g_181[1])) < ((((*l_1603) = p_51) == (((0L & ((((safe_lshift_func_uint8_t_u_s(((**l_1602) > (0x60F57650L && g_1606[7][1])), l_1607)) , 0x657FL) , (void*)0) == l_1608)) | (*p_51)) , &g_837)) ^ (*g_533))) , l_1600))), 0x16C707534FE0D7B3LL));
                        (***l_1601) = ((l_1609 < (&g_533 == l_1610)) < ((((safe_mod_func_int32_t_s_s((!(((*l_1614) = &g_105) != (void*)0)), (safe_lshift_func_int8_t_s_s(((*l_1553) = 4L), ((safe_lshift_func_int8_t_s_u((safe_lshift_func_int8_t_s_s((safe_div_func_int64_t_s_s((safe_sub_func_int32_t_s_s((((safe_sub_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s((((g_59[(g_732 + 1)][g_120] = 0UL) > l_1629) >= ((*l_1630) = (&l_1607 == &l_1584))), g_265)) , l_1552), l_1629)) , l_1552) < (*l_52)), 4294967294UL)), l_1609)), 5)), l_1607)) , 0x7BL))))) >= l_1584) >= l_1607) <= 1UL));
                        if (l_1609)
                            goto lbl_1557;
                        (**l_1602) &= g_59[(g_732 + 1)][g_120];
                    }
                    else
                    { /* block id: 653 */
                        uint16_t *l_1639 = (void*)0;
                        uint16_t *l_1640 = &g_947;
                        uint8_t **l_1657 = &l_1578;
                        const int32_t *l_1658 = &g_1178[1][2];
                        int32_t *l_1659 = &g_1606[7][1];
                        const int32_t * const *l_1668 = &l_1658;
                        const int32_t * const **l_1667 = &l_1668;
                        uint32_t *l_1670 = &g_656;
                        uint32_t *l_1673 = &g_59[2][2];
                        int64_t *l_1688 = &g_1689;
                        (*l_52) = ((safe_rshift_func_uint8_t_u_u(l_1552, 4)) < (safe_add_func_uint32_t_u_u(((safe_sub_func_int16_t_s_s(((l_1637 , (~(++(*l_1640)))) > g_1643), (safe_rshift_func_int16_t_s_u((l_1646[6][1] != &g_64), ((&g_342 != (l_1648 = g_1647)) | (safe_mod_func_int8_t_s_s(((void*)0 == l_52), g_1323))))))) , 1UL), g_1606[4][0])));
                        (*l_1659) |= ((**l_1602) ^= (((((safe_rshift_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(l_1609, g_732)), 0)) & (&g_342 != l_1657)) ^ ((void*)0 != l_1658)) , (*g_229)) == (void*)0));
                        l_1629 = ((***l_1601) && ((l_1660 , (safe_rshift_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u(((((l_1599 , (l_1660 , (-5L))) == ((**l_1602) = (safe_div_func_int64_t_s_s(((l_1667 == &g_932) , (~(((((*l_1673) = ((*l_1670)++)) & 0xAA719719L) == (l_1629 && 0xA4778DDC81F00BC0LL)) >= (*l_52)))), (*l_52))))) , g_59[g_732][g_732]) & 0UL), g_732)), (*l_1659)))) < g_478));
                        (*l_52) = (safe_div_func_uint32_t_u_u(((*l_1659) >= (safe_mul_func_uint8_t_u_u(l_1552, (safe_lshift_func_int16_t_s_u(0xB41FL, (((*l_1688) ^= ((*l_1600) = ((safe_rshift_func_uint8_t_u_s((((*l_1583) = g_59[g_732][g_732]) < (safe_sub_func_int64_t_s_s(0xFCFB227DE67EAB36LL, ((safe_div_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_s(((-1L) > 0UL), 6)) && g_120), (*g_533))) && 0xDF70227DL)))), g_59[g_732][g_732])) <= (**l_1602)))) != 1UL)))))), l_1584));
                    }
                    (***l_1601) = (safe_unary_minus_func_uint16_t_u(65532UL));
                    for (g_478 = 23; (g_478 >= 13); g_478--)
                    { /* block id: 671 */
                        int32_t *l_1693 = &l_1513;
                        int32_t *l_1694[6][9] = {{&g_1606[4][2],&l_1514[1],&l_1629,&l_63,&l_58,(void*)0,&l_63,&l_58,&l_58},{&l_1513,&g_55,(void*)0,&g_173,(void*)0,&g_55,&l_1513,&l_63,&l_1629},{(void*)0,&l_58,(void*)0,&l_1513,&g_173,&l_1580,&l_58,&g_55,&l_58},{&l_63,(void*)0,&l_1629,&g_55,&g_55,&l_1629,(void*)0,&l_63,(void*)0},{&l_63,&g_53,&l_63,&g_55,&g_1606[4][2],(void*)0,&l_1514[1],&l_58,&l_1580},{(void*)0,&g_55,&l_1580,&l_1513,&l_63,&l_1513,&l_1580,&g_55,(void*)0}};
                        uint32_t l_1715 = 18446744073709551615UL;
                        int i, j;
                        l_1715--;
                    }
                    l_1719 = &l_1695;
                }
                else
                { /* block id: 675 */
                    const int8_t l_1734[7][4] = {{(-3L),0L,1L,(-8L)},{(-1L),0L,0L,(-1L)},{0L,(-1L),(-3L),0x93L},{0L,(-3L),0L,1L},{(-1L),0x93L,1L,1L},{(-3L),(-3L),(-8L),0x93L},{0x93L,(-1L),(-8L),(-1L)}};
                    int32_t l_1735 = 0xC83E349BL;
                    int i, j;
                    l_1735 |= ((*p_51) == ((*l_1583) = (safe_div_func_int32_t_s_s(((l_1722 == g_1723) , ((4294967295UL >= (g_29 & ((l_1697 || (l_1728[0][0] != &g_1071)) , ((((((*l_52) = ((*l_1553) = (safe_sub_func_int16_t_s_s((((((safe_add_func_uint32_t_u_u(((l_1733 = &g_350[3]) == (void*)0), l_1706)) == 0xD5L) & (**l_1602)) < (***l_1601)) <= (*g_594)), l_1734[6][0])))) <= 0xE2L) | g_64) && g_53) & l_1734[2][3])))) , (***l_1601))), 0xBD909403L))));
                    if ((**l_1602))
                        continue;
                }
            }
        }
        (*l_1835) ^= ((*g_594) || (((g_1606[7][1] & 1L) && ((*l_52) < (((*g_533) = 0L) , 6L))) < ((safe_mul_func_int16_t_s_s(((*l_52) == ((((void*)0 != (*g_1723)) != g_389) < l_1709[1])), (*p_51))) && g_1595)));
    }
    l_52 = &l_1514[1];
    return g_59[5][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_380 g_271.f0.f0 g_732 g_515 g_389 g_178 g_478 g_55 g_533 g_29 g_105 g_265 g_1178 g_120 g_656 g_271.f1 g_837 g_33 g_919.f0 g_53 g_271 g_947 g_229 g_181 g_1323 g_853 g_173 g_59 g_31
 * writes: g_380 g_515 g_732 g_105 g_178 g_120 g_837 g_53 g_29 g_1071 g_947 g_478 g_853 g_1323 g_265 g_389
 */
static int32_t  func_67(int32_t * p_68)
{ /* block id: 252 */
    uint32_t l_628[1][9][9] = {{{18446744073709551615UL,18446744073709551609UL,0xBED0FBC4L,5UL,18446744073709551615UL,0xBED0FBC4L,0UL,0xBED0FBC4L,0xBB6391FBL},{7UL,0xBB6391FBL,0xBB6391FBL,7UL,0x53B631F8L,0x038308B8L,0xBED0FBC4L,0xBB6391FBL,0x038308B8L},{18446744073709551615UL,0xBB6391FBL,18446744073709551615UL,0xBED0FBC4L,0x6B4C94E2L,0x6B4C94E2L,0xBED0FBC4L,18446744073709551615UL,0xBB6391FBL},{0xBED0FBC4L,0x53B631F8L,18446744073709551615UL,18446744073709551609UL,0x53B631F8L,0xBB6391FBL,1UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,0x6B4C94E2L,0xBB6391FBL,18446744073709551609UL,0xBB6391FBL,0x6B4C94E2L,18446744073709551615UL,0xBB6391FBL,18446744073709551615UL},{7UL,0x53B631F8L,0x038308B8L,0xBED0FBC4L,0xBB6391FBL,0x038308B8L,1UL,0x038308B8L,0xBB6391FBL},{7UL,0xBB6391FBL,0xBB6391FBL,7UL,0x53B631F8L,0x038308B8L,0xBED0FBC4L,0xBB6391FBL,0x038308B8L},{18446744073709551615UL,0xBB6391FBL,18446744073709551615UL,0xBED0FBC4L,0x6B4C94E2L,0x6B4C94E2L,0xBED0FBC4L,18446744073709551615UL,0xBB6391FBL},{0xBED0FBC4L,0x53B631F8L,18446744073709551615UL,18446744073709551609UL,0x53B631F8L,0xBB6391FBL,1UL,18446744073709551615UL,18446744073709551615UL}}};
    int16_t *l_635 = &g_31;
    struct S1 l_636 = {{10521},0UL};
    int32_t l_640 = 0x13A69476L;
    int32_t *l_642 = &g_173;
    int32_t l_647 = (-10L);
    int32_t l_649 = (-1L);
    int32_t l_651[8] = {0L,(-4L),(-4L),0L,(-4L),(-4L),0L,(-4L)};
    int64_t * const *l_786 = &g_533;
    uint8_t l_860 = 1UL;
    int64_t l_906 = 0x2BBDD3F1815728B1LL;
    struct S0 **l_978 = (void*)0;
    struct S0 ***l_977 = &l_978;
    int32_t l_1022[7][6] = {{0x5BCB7E6AL,9L,1L,1L,9L,0x5BCB7E6AL},{0xB11AAFD9L,0x95583A0FL,0xB47B4B1CL,5L,0x5BCB7E6AL,0x45E927B7L},{9L,(-1L),0L,0x5BCB7E6AL,0L,(-1L)},{9L,0x45E927B7L,0x5BCB7E6AL,5L,0xB47B4B1CL,0x95583A0FL},{0xB11AAFD9L,0x5BCB7E6AL,9L,1L,1L,9L},{0x5BCB7E6AL,0x5BCB7E6AL,(-1L),0xB11AAFD9L,0xB47B4B1CL,1L},{(-1L),0x45E927B7L,5L,(-1L),0L,(-1L)}};
    int32_t *l_1073 = (void*)0;
    int8_t *l_1087 = &g_478;
    int32_t l_1138 = (-6L);
    int32_t l_1139 = 0x56FB1C21L;
    uint32_t l_1152 = 0x6564B083L;
    uint8_t *l_1240 = &g_389;
    const int16_t l_1254[8][5][6] = {{{0xAFD6L,0x99DFL,0x4ABCL,0L,1L,(-1L)},{0x5EB2L,0x99DFL,0xD5CDL,(-1L),0xC56AL,0x2018L},{(-1L),0xA89BL,1L,1L,(-10L),(-9L)},{0xA89BL,1L,(-1L),6L,0L,0xAFD6L},{(-4L),(-6L),1L,1L,(-10L),0x2A6EL}},{{(-1L),0x2A6EL,6L,(-1L),0xF6BAL,(-10L)},{0xE912L,6L,0x02BAL,0x02BAL,6L,0xE912L},{1L,0xC56AL,2L,1L,(-1L),(-1L)},{0xF6BAL,0x02BAL,0x2A6EL,0L,1L,0x1925L},{0xF6BAL,0xE912L,0L,1L,0x5EB2L,0x4ABCL}},{{1L,(-1L),(-4L),0x02BAL,0x99DFL,(-6L)},{0xE912L,5L,0xF6BAL,0L,(-6L),0xD5CDL},{0L,0x3DCBL,(-10L),(-6L),0L,8L},{6L,1L,0L,1L,(-10L),0x0586L},{0xD5CDL,8L,(-10L),8L,0xD5CDL,0L}},{{0L,(-10L),0xC56AL,(-10L),0L,0x2A6EL},{0xF6BAL,(-1L),1L,(-10L),1L,0x2A6EL},{0L,0x5EB2L,0xC56AL,6L,(-4L),0L},{1L,(-5L),(-10L),0xA89BL,6L,0x0586L},{0x0586L,0x2018L,0L,(-9L),0x4A79L,8L}},{{0x49C0L,0xC56AL,(-10L),(-1L),0x02BAL,0xD5CDL},{0xE912L,0L,0xF6BAL,0x4ABCL,0L,0L},{0x2018L,6L,6L,0x2018L,(-1L),(-5L)},{8L,6L,(-1L),(-6L),0xAFD6L,0x3DCBL},{(-5L),0x0586L,1L,0x4A79L,0xAFD6L,(-10L)}},{{0x99DFL,6L,0x5EB2L,0L,(-1L),5L},{(-1L),6L,0x99DFL,0x1925L,0L,1L},{(-9L),0L,1L,0x5EB2L,0x02BAL,1L},{(-1L),0xC56AL,0xAFD6L,0x2A6EL,0x4A79L,0L},{(-1L),0x2018L,0L,(-1L),6L,(-1L)}},{{0xA89BL,(-5L),0xA89BL,(-10L),(-4L),0xC56AL},{(-1L),0x5EB2L,(-1L),7L,1L,0xE912L},{(-10L),(-1L),(-5L),7L,0L,(-10L)},{(-1L),(-10L),0x49C0L,(-10L),0xD5CDL,0xAFD6L},{0xA89BL,8L,1L,(-1L),(-10L),(-6L)}},{{(-1L),1L,0x0586L,0x2A6EL,0L,0x4ABCL},{(-1L),0x3DCBL,0x2B00L,0x5EB2L,(-6L),0x4A79L},{(-9L),(-1L),(-6L),0x1925L,0x1925L,(-6L)},{(-1L),(-1L),7L,0L,0xF6BAL,0x02BAL},{0x99DFL,5L,1L,0x4A79L,0xA89BL,7L}}};
    uint32_t l_1258[4][4][10] = {{{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL},{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL}},{{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL},{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL}},{{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL},{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL}},{{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL},{0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L},{0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL,1UL,0x01A6C088L,0x01A6C088L,1UL}}};
    int16_t l_1347 = 0x73D1L;
    uint32_t l_1405 = 4294967293UL;
    int32_t **l_1434 = &g_1072[7][0];
    uint8_t **l_1437[7][8] = {{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,(void*)0,&l_1240,&l_1240},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,(void*)0},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240},{&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240,&l_1240}};
    uint8_t ***l_1436 = &l_1437[3][5];
    uint32_t **l_1438 = (void*)0;
    int i, j, k;
    for (g_380 = 0; (g_380 != 5); ++g_380)
    { /* block id: 255 */
        uint8_t l_620 = 0xCCL;
        int32_t l_621 = 0xDAA408B9L;
        const uint32_t l_639 = 0xDB4109D0L;
        int32_t *l_641 = &g_173;
        int32_t l_653 = 0xE4802063L;
        int32_t l_654 = 0xEBC5C134L;
        int32_t l_655 = 0x70A1D107L;
        int32_t *l_678 = &l_621;
        struct S0 l_777[6][9] = {{{3444},{3444},{6605},{11952},{26966},{2022},{32286},{13507},{32286}},{{3444},{26713},{2022},{2022},{26713},{3444},{11952},{29028},{11719}},{{13507},{14631},{6605},{11719},{26713},{26713},{11719},{6605},{14631}},{{26713},{25715},{3444},{30371},{26966},{14631},{11952},{11952},{14631}},{{30371},{6605},{29028},{6605},{30371},{25715},{32286},{3444},{11719}},{{32286},{25715},{30371},{6605},{29028},{6605},{30371},{25715},{32286}}};
        int64_t * const *l_788 = &g_533;
        int32_t l_900 = 0x05DF2814L;
        int32_t l_902[3];
        int64_t l_905 = 0xBA18A89706D55BC4LL;
        int64_t l_907 = (-1L);
        struct S0 *l_918 = &g_919;
        uint16_t *l_927 = &g_853;
        int16_t l_945 = (-4L);
        int32_t *l_972 = (void*)0;
        int32_t **l_971 = &l_972;
        struct S0 ***l_1006[6] = {&l_978,&l_978,&l_978,&l_978,&l_978,&l_978};
        int16_t l_1019 = 0L;
        uint16_t l_1066 = 0x0CE9L;
        int8_t *l_1088[6][3] = {{&g_478,&g_478,(void*)0},{&g_101,&g_101,&g_478},{&g_478,&g_478,(void*)0},{&g_101,&g_101,&g_478},{&g_478,&g_478,(void*)0},{&g_101,&g_101,&g_478}};
        int32_t l_1140 = 0x89F11B8BL;
        int i, j;
        for (i = 0; i < 3; i++)
            l_902[i] = 0x4C37086BL;
        l_621 |= l_620;
    }
lbl_1179:
    l_1073 = (l_642 = p_68);
    if (((void*)0 != &l_1138))
    { /* block id: 453 */
        int32_t *l_1141 = &g_53;
        int32_t *l_1142 = (void*)0;
        int32_t *l_1143 = &l_649;
        int32_t l_1144 = 0xA36ABF1FL;
        int32_t *l_1145 = &l_640;
        int32_t *l_1146 = &g_53;
        int32_t *l_1147 = &l_647;
        int32_t *l_1148 = &l_651[0];
        int32_t *l_1149 = (void*)0;
        int32_t *l_1150 = &g_173;
        int32_t *l_1151[5][4] = {{&l_1144,&l_1144,&l_1144,&l_1144},{&l_1144,&l_1144,&l_1144,&l_1144},{&l_1144,&l_1144,&l_1144,&l_1144},{&l_1144,&l_1144,&l_1144,&l_1144},{&l_1144,&l_1144,&l_1144,&l_1144}};
        int i, j;
        --l_1152;
    }
    else
    { /* block id: 455 */
        int64_t l_1155 = 6L;
        uint32_t *l_1168[7][2][8] = {{{&l_628[0][8][0],(void*)0,&g_33,(void*)0,&l_628[0][5][7],&g_271[5].f1,(void*)0,&g_732},{&g_271[5].f1,(void*)0,&g_732,&g_271[5].f1,(void*)0,&g_732,&g_33,&g_271[5].f1}},{{&l_628[0][6][1],&l_636.f1,&g_64,&g_271[5].f1,&l_628[0][5][3],&l_636.f1,&l_628[0][5][3],&g_271[5].f1},{&g_732,(void*)0,&g_732,&g_271[5].f1,&l_636.f1,&l_628[0][8][0],&l_628[0][6][8],&g_732}},{{&g_732,(void*)0,&g_271[5].f1,&g_271[5].f1,&g_732,&l_628[0][6][8],&l_636.f1,&g_732},{&g_732,&l_628[0][5][3],&l_628[0][6][8],&g_732,&l_636.f1,&l_636.f1,&g_271[5].f1,&g_64}},{{&g_732,&l_628[0][6][8],(void*)0,&l_628[0][6][8],&l_628[0][5][3],&g_732,&l_628[0][8][0],(void*)0},{&l_628[0][6][1],&g_64,&g_271[5].f1,&l_628[0][6][8],(void*)0,(void*)0,&g_732,&g_271[5].f1}},{{&g_271[5].f1,&l_628[0][5][3],&g_64,&g_732,&l_628[0][5][7],(void*)0,&l_628[0][6][8],&l_628[0][6][8]},{&l_628[0][8][0],(void*)0,(void*)0,(void*)0,(void*)0,&l_628[0][8][0],&l_628[0][4][7],&l_628[0][5][7]}},{{&l_628[0][5][7],&g_732,&g_271[5].f1,(void*)0,&g_64,&g_33,&g_64,&g_732},{&g_271[5].f1,&l_628[0][6][8],&g_271[5].f1,&l_628[0][4][7],&g_271[5].f1,&l_636.f1,&g_271[5].f1,&g_271[5].f1}},{{&l_628[0][6][8],&g_271[5].f1,&g_64,(void*)0,(void*)0,&g_64,&l_636.f1,(void*)0},{&l_628[0][4][7],&g_271[5].f1,&g_33,(void*)0,&g_64,&g_33,&l_628[0][8][0],&l_628[0][0][8]}}};
        int32_t l_1171 = 0L;
        const struct S1 l_1203[8][8][4] = {{{{{4433},5UL},{{25205},0x51451B1AL},{{29343},1UL},{{13181},0UL}},{{{25205},0x51451B1AL},{{19578},0UL},{{14998},0xF0F7C945L},{{4433},5UL}},{{{23805},18446744073709551606UL},{{11579},0xD6CE288EL},{{25514},2UL},{{23805},18446744073709551606UL}},{{{23499},0x2018B982L},{{13181},0UL},{{9376},0UL},{{4308},0x3DB38221L}},{{{25205},0x51451B1AL},{{23805},18446744073709551606UL},{{16342},0xC331B113L},{{18411},0x9EC000B3L}},{{{4001},0UL},{{14032},18446744073709551615UL},{{4001},0UL},{{13879},0x0D6654CAL}},{{{27040},5UL},{{23499},0x2018B982L},{{392},0x2D33ED83L},{{4308},0x3DB38221L}},{{{28820},0UL},{{22309},1UL},{{23805},18446744073709551606UL},{{23499},0x2018B982L}}},{{{{25514},2UL},{{11579},0xD6CE288EL},{{23805},18446744073709551606UL},{{4001},0UL}},{{{28820},0UL},{{18825},0x8730527AL},{{392},0x2D33ED83L},{{13181},0UL}},{{{27040},5UL},{{12898},18446744073709551610UL},{{4001},0UL},{{25205},0x51451B1AL}},{{{4001},0UL},{{25205},0x51451B1AL},{{16342},0xC331B113L},{{22309},1UL}},{{{25205},0x51451B1AL},{{18825},0x8730527AL},{{9376},0UL},{{4433},5UL}},{{{23499},0x2018B982L},{{25514},2UL},{{25514},2UL},{{23499},0x2018B982L}},{{{23805},18446744073709551606UL},{{13181},0UL},{{14998},0xF0F7C945L},{{19031},18446744073709551609UL}},{{{25205},0x51451B1AL},{{23499},0x2018B982L},{{29343},1UL},{{18411},0x9EC000B3L}}},{{{{4433},5UL},{{12314},18446744073709551615UL},{{4001},0UL},{{18411},0x9EC000B3L}},{{{16342},0xC331B113L},{{23499},0x2018B982L},{{12898},18446744073709551610UL},{{19031},18446744073709551609UL}},{{{28820},0UL},{{13181},0UL},{{14663},2UL},{{23499},0x2018B982L}},{{{11579},0xD6CE288EL},{{25514},2UL},{{23805},18446744073709551606UL},{{4433},5UL}},{{{14998},0xF0F7C945L},{{18825},0x8730527AL},{{12898},18446744073709551610UL},{{22309},1UL}},{{{27040},5UL},{{25205},0x51451B1AL},{{21217},18446744073709551615UL},{{25205},0x51451B1AL}},{{{4433},5UL},{{12898},18446744073709551610UL},{{16342},0xC331B113L},{{13181},0UL}},{{{12898},18446744073709551610UL},{{18825},0x8730527AL},{{14998},0xF0F7C945L},{{4001},0UL}}},{{{{23499},0x2018B982L},{{11579},0xD6CE288EL},{{5235},0x022CF8FBL},{{23499},0x2018B982L}},{{{23499},0x2018B982L},{{22309},1UL},{{14998},0xF0F7C945L},{{4308},0x3DB38221L}},{{{12898},18446744073709551610UL},{{23499},0x2018B982L},{{16342},0xC331B113L},{{13879},0x0D6654CAL}},{{{4433},5UL},{{14032},18446744073709551615UL},{{21217},18446744073709551615UL},{{18411},0x9EC000B3L}},{{{27040},5UL},{{23805},18446744073709551606UL},{{12898},18446744073709551610UL},{{4308},0x3DB38221L}},{{{14998},0xF0F7C945L},{{13181},0UL},{{23805},18446744073709551606UL},{{23805},18446744073709551606UL}},{{{11579},0xD6CE288EL},{{11579},0xD6CE288EL},{{14663},2UL},{{4433},5UL}},{{{28820},0UL},{{19578},0UL},{{12898},18446744073709551610UL},{{13181},0UL}}},{{{{16342},0xC331B113L},{{25205},0x51451B1AL},{{4001},0UL},{{12898},18446744073709551610UL}},{{{4433},5UL},{{25205},0x51451B1AL},{{29343},1UL},{{13181},0UL}},{{{25205},0x51451B1AL},{{19578},0UL},{{14998},0xF0F7C945L},{{4433},5UL}},{{{23805},18446744073709551606UL},{{11579},0xD6CE288EL},{{25514},2UL},{{23805},18446744073709551606UL}},{{{23499},0x2018B982L},{{13181},0UL},{{9376},0UL},{{4308},0x3DB38221L}},{{{25205},0x51451B1AL},{{23805},18446744073709551606UL},{{16342},0xC331B113L},{{18411},0x9EC000B3L}},{{{4001},0UL},{{14032},18446744073709551615UL},{{4001},0UL},{{13879},0x0D6654CAL}},{{{27040},5UL},{{23499},0x2018B982L},{{392},0x2D33ED83L},{{4308},0x3DB38221L}}},{{{{28820},0UL},{{22309},1UL},{{23805},18446744073709551606UL},{{23499},0x2018B982L}},{{{31399},18446744073709551615UL},{{13879},0x0D6654CAL},{{5235},0x022CF8FBL},{{4106},1UL}},{{{4001},0UL},{{16342},0xC331B113L},{{14032},18446744073709551615UL},{{23805},18446744073709551606UL}},{{{14998},0xF0F7C945L},{{14827},18446744073709551615UL},{{4106},1UL},{{12314},18446744073709551615UL}},{{{4106},1UL},{{12314},18446744073709551615UL},{{9376},0UL},{{14663},2UL}},{{{12314},18446744073709551615UL},{{16342},0xC331B113L},{{4433},5UL},{{22309},1UL}},{{{25514},2UL},{{31399},18446744073709551615UL},{{31399},18446744073709551615UL},{{25514},2UL}},{{{5235},0x022CF8FBL},{{23805},18446744073709551606UL},{{21217},18446744073709551615UL},{{23777},0x423502DEL}}},{{{{12314},18446744073709551615UL},{{25514},2UL},{{28820},0UL},{{12898},18446744073709551610UL}},{{{22309},1UL},{{714},6UL},{{4106},1UL},{{12898},18446744073709551610UL}},{{{9376},0UL},{{25514},2UL},{{14827},18446744073709551615UL},{{23777},0x423502DEL}},{{{4001},0UL},{{23805},18446744073709551606UL},{{11579},0xD6CE288EL},{{25514},2UL}},{{{13879},0x0D6654CAL},{{31399},18446744073709551615UL},{{5235},0x022CF8FBL},{{22309},1UL}},{{{21217},18446744073709551615UL},{{16342},0xC331B113L},{{14827},18446744073709551615UL},{{14663},2UL}},{{{14998},0xF0F7C945L},{{12314},18446744073709551615UL},{{13181},0UL},{{12314},18446744073709551615UL}},{{{22309},1UL},{{14827},18446744073709551615UL},{{9376},0UL},{{23805},18446744073709551606UL}}},{{{{14827},18446744073709551615UL},{{16342},0xC331B113L},{{21217},18446744073709551615UL},{{4106},1UL}},{{{25514},2UL},{{13879},0x0D6654CAL},{{18411},0x9EC000B3L},{{25514},2UL}},{{{25514},2UL},{{14663},2UL},{{21217},18446744073709551615UL},{{19578},0UL}},{{{14827},18446744073709551615UL},{{25514},2UL},{{9376},0UL},{{392},0x2D33ED83L}},{{{22309},1UL},{{19031},18446744073709551609UL},{{13181},0UL},{{12898},18446744073709551610UL}},{{{14998},0xF0F7C945L},{{5235},0x022CF8FBL},{{14827},18446744073709551615UL},{{19578},0UL}},{{{21217},18446744073709551615UL},{{23805},18446744073709551606UL},{{5235},0x022CF8FBL},{{5235},0x022CF8FBL}},{{{13879},0x0D6654CAL},{{13879},0x0D6654CAL},{{11579},0xD6CE288EL},{{22309},1UL}}}};
        int64_t l_1208 = 0L;
        int32_t l_1230 = 1L;
        int32_t l_1231 = 0x11CBC5E9L;
        int32_t l_1232 = 0xE2B1C078L;
        struct S0 l_1261 = {14086};
        int8_t *l_1346 = &g_478;
        uint64_t l_1349 = 0UL;
        uint64_t *l_1401 = &l_1349;
        const uint8_t *l_1442[8][4][1] = {{{&l_860},{&g_120},{&l_860},{&g_380}},{{&g_120},{&l_860},{&l_860},{&g_120}},{{&g_380},{&l_860},{&g_120},{&l_860}},{{&g_380},{&g_120},{&l_860},{&l_860}},{{&g_120},{&g_380},{&l_860},{&g_120}},{{&l_860},{&g_380},{&g_120},{&l_860}},{{&l_860},{&g_120},{&g_380},{&l_860}},{{&g_120},{&l_860},{&g_380},{&g_120}}};
        const uint8_t **l_1441 = &l_1442[5][0][0];
        const uint8_t ***l_1440[1];
        int32_t *l_1443[4];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1440[i] = &l_1441;
        for (i = 0; i < 4; i++)
            l_1443[i] = &l_1171;
        if (l_1155)
        { /* block id: 456 */
            int16_t *l_1158[9][8] = {{&g_837,&g_837,&g_515,&g_837,&g_837,&g_515,&g_837,&g_837},{&g_515,&g_837,&g_515,&g_515,&g_837,&g_515,&g_515,&g_837},{&g_837,&g_515,&g_515,&g_837,&g_515,&g_515,&g_837,&g_515},{&g_837,&g_837,&g_515,&g_837,&g_837,&g_515,&g_837,&g_837},{&g_515,&g_837,&g_515,&g_515,&g_837,&g_515,&g_515,&g_837},{&g_837,&g_515,&g_515,&g_837,&g_515,&g_515,&g_837,&g_515},{&g_837,&g_837,&g_515,&g_837,&g_837,&g_515,&g_837,&g_837},{&g_515,&g_837,&g_515,&g_515,&g_837,&g_515,&g_515,&g_837},{&g_837,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515,&g_515}};
            int32_t l_1163 = 0x4A1E0D74L;
            int32_t *l_1166 = &l_640;
            int i, j;
            if ((((((safe_add_func_int32_t_s_s(l_1155, g_271[5].f0.f0)) & (g_515 |= g_732)) & ((((safe_sub_func_uint16_t_u_u(((((((safe_div_func_uint32_t_u_u(l_1155, (l_1163 = 0x2913F661L))) , ((safe_mul_func_uint16_t_u_u(l_1163, (((((*l_1166) = l_1163) <= (!g_389)) > g_178) <= g_478))) , (*l_1166))) , p_68) != p_68) , l_1168[1][1][0]) == (void*)0), g_55)) > 9L) <= 0UL) < l_1155)) <= (*g_533)) >= (-1L)))
            { /* block id: 460 */
                for (g_732 = 0; (g_732 <= 7); g_732 += 1)
                { /* block id: 463 */
                    uint64_t *l_1172 = (void*)0;
                    uint64_t *l_1173[7];
                    int32_t l_1174 = (-1L);
                    int32_t l_1175[5] = {(-8L),(-8L),(-8L),(-8L),(-8L)};
                    int i;
                    for (i = 0; i < 7; i++)
                        l_1173[i] = &g_105;
                    l_651[g_732] &= ((((safe_mul_func_uint16_t_u_u((*l_1166), 0x8797L)) , (*g_533)) || (--g_105)) ^ g_265);
                    for (g_178 = 0; (g_178 <= 0); g_178 += 1)
                    { /* block id: 468 */
                        if (g_1178[1][3])
                            break;
                    }
                }
                if (g_178)
                    goto lbl_1179;
            }
            else
            { /* block id: 473 */
                int64_t l_1184 = (-1L);
                int32_t l_1209[10][9] = {{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L},{0xB361C9C9L,(-1L),7L,0xF9E080A5L,(-1L),0xF9E080A5L,7L,(-1L),0xB361C9C9L}};
                uint16_t l_1210[6] = {0xFB14L,0xFB14L,0xFB14L,0xFB14L,0xFB14L,0xFB14L};
                uint8_t *l_1212[9] = {&g_120,(void*)0,&g_120,&g_120,(void*)0,&g_120,&g_120,(void*)0,&g_120};
                uint8_t **l_1211[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint8_t ***l_1213 = &l_1211[3];
                int i, j;
                (*l_1213) = (((safe_mul_func_uint16_t_u_u((((l_1158[6][3] == (void*)0) != (safe_rshift_func_int8_t_s_s(((l_1210[1] = (l_1155 != (((((l_1184 && (safe_mul_func_uint16_t_u_u(0UL, (safe_mod_func_int64_t_s_s(((+((safe_sub_func_uint8_t_u_u((g_120 |= ((*l_1166) <= (-5L))), (safe_mul_func_int8_t_s_s((((l_1209[2][8] = ((((!(safe_lshift_func_int16_t_s_s((g_837 ^= (safe_mul_func_int8_t_s_s(((((((safe_mul_func_uint8_t_u_u((safe_mod_func_int64_t_s_s((l_1203[1][2][1] , (safe_sub_func_int8_t_s_s(((((safe_add_func_uint16_t_u_u(1UL, g_656)) ^ l_1155) > l_1171) > l_1208), g_515))), 7L)), 0xCCL)) <= g_271[5].f1) , (*l_1166)) <= 6L) , (*l_1166)) , 1L), l_1184))), l_1184))) || 0UL) & l_1184) | (-1L))) != 0xECL) | (*l_1166)), g_33)))) == 0UL)) == l_1155), (*l_1166)))))) ^ l_1203[1][2][1].f1) == g_919.f0) == (*l_1166)) <= l_1184))) <= l_1184), l_1184))) > 0x1B71L), g_271[5].f0.f0)) || l_1210[0]) , l_1211[3]);
                for (g_53 = 0; (g_53 >= (-10)); --g_53)
                { /* block id: 481 */
                    p_68 = (g_271[3] , p_68);
                }
            }
        }
        else
        { /* block id: 485 */
            int32_t *l_1216 = &l_651[0];
            int32_t *l_1217 = (void*)0;
            int32_t *l_1218 = &l_651[0];
            int32_t *l_1219 = &l_1138;
            int32_t *l_1220 = (void*)0;
            int32_t *l_1221 = &l_1138;
            int32_t *l_1222 = &l_640;
            int32_t *l_1223 = &l_651[0];
            int32_t *l_1224 = &g_53;
            int32_t *l_1225 = &l_1138;
            int32_t *l_1226 = &l_640;
            int32_t *l_1227 = &l_651[1];
            int32_t *l_1228 = &g_53;
            int32_t *l_1229[7][3];
            uint64_t l_1233 = 0xD1CCD5985F3824EALL;
            uint8_t *l_1238 = &g_120;
            int32_t *l_1249 = &l_1022[3][2];
            struct S0 l_1292 = {19008};
            struct S0 * const * const l_1320 = &g_350[1];
            int32_t **l_1322[10];
            int8_t *l_1345[3];
            int32_t ****l_1367 = &g_229;
            uint32_t l_1407 = 4294967295UL;
            int16_t l_1431 = (-1L);
            int i, j;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 3; j++)
                    l_1229[i][j] = (void*)0;
            }
            for (i = 0; i < 10; i++)
                l_1322[i] = (void*)0;
            for (i = 0; i < 3; i++)
                l_1345[i] = &g_478;
            l_1233--;
lbl_1366:
            for (g_380 = 0; (g_380 >= 59); ++g_380)
            { /* block id: 489 */
                uint8_t **l_1239[9][2][5] = {{{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238},{&l_1238,&l_1238,(void*)0,&l_1238,&l_1238}},{{&l_1238,&l_1238,(void*)0,&l_1238,(void*)0},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}},{{(void*)0,&l_1238,&l_1238,&l_1238,(void*)0},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}},{{(void*)0,(void*)0,&l_1238,(void*)0,&l_1238},{&l_1238,&l_1238,&l_1238,(void*)0,(void*)0}},{{(void*)0,&l_1238,(void*)0,(void*)0,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}},{{&l_1238,(void*)0,(void*)0,&l_1238,(void*)0},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}},{{&l_1238,&l_1238,(void*)0,&l_1238,&l_1238},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}},{{(void*)0,&l_1238,(void*)0,(void*)0,&l_1238},{&l_1238,(void*)0,&l_1238,&l_1238,&l_1238}},{{&l_1238,(void*)0,(void*)0,&l_1238,(void*)0},{&l_1238,&l_1238,&l_1238,&l_1238,&l_1238}}};
                const uint32_t **l_1241 = (void*)0;
                const uint32_t *l_1243 = &l_1203[1][2][1].f1;
                const uint32_t **l_1242 = &l_1243;
                int32_t l_1255 = 2L;
                int32_t l_1283 = 0x781AA542L;
                const struct S0 l_1321 = {13071};
                int i, j, k;
                if ((((((l_1240 = l_1238) != (void*)0) != (*l_1219)) , p_68) == ((*l_1242) = &g_732)))
                { /* block id: 492 */
                    int16_t l_1256 = 3L;
                    int32_t l_1257 = (-1L);
                    int32_t l_1282[4][8] = {{0L,0L,0L,0L,(-9L),1L,(-9L),0L},{0L,(-9L),0L,(-6L),0x05DE6FFAL,0x05DE6FFAL,(-6L),0L},{(-9L),(-9L),0x05DE6FFAL,1L,(-1L),1L,0x05DE6FFAL,(-9L)},{(-9L),0L,(-6L),0x05DE6FFAL,0x05DE6FFAL,(-6L),0L,(-9L)}};
                    int32_t l_1284 = (-4L);
                    int i, j;
                    for (g_29 = 0; (g_29 < 6); g_29 = safe_add_func_int64_t_s_s(g_29, 1))
                    { /* block id: 495 */
                        int32_t ***l_1248 = &g_1071;
                        uint64_t *l_1272 = &l_1233;
                        int16_t *l_1275 = &l_1256;
                        int32_t l_1285 = (-1L);
                        (*l_1227) = (safe_rshift_func_int8_t_s_u((((void*)0 != l_1248) , (l_1249 == (void*)0)), ((safe_mul_func_int8_t_s_s(1L, 8UL)) , ((safe_mod_func_uint8_t_u_u(((((*l_1248) = &g_1072[0][4]) != (void*)0) , l_1254[3][1][5]), g_380)) && l_1255))));
                        ++l_1258[0][1][1];
                        (*l_1226) = (((l_1261 , ((((safe_div_func_uint32_t_u_u(((safe_add_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u((&l_1232 == (void*)0), ((safe_mod_func_uint16_t_u_u((((((*g_533) != (++(*l_1272))) > g_837) & (((*l_1275) = g_178) == ((safe_lshift_func_int16_t_s_u(((*l_1223) = l_1257), 0)) ^ g_29))) > (((safe_div_func_int32_t_s_s((l_1282[1][5] = ((((safe_mul_func_int16_t_s_s(((*g_533) ^ 0xC2FA300CA1595191LL), 0xAEF0L)) != 0x5D17L) != 0UL) & g_178)), l_1203[1][2][1].f0.f0)) ^ l_1257) , 0xDFL)), l_1283)) & l_1261.f0))) <= (*g_533)), l_1284)) < 0L), g_1178[1][3])) < l_1255) || l_1285) || 0xABE8F99736A8993ELL)) , l_1208) >= g_478);
                    }
                    for (g_947 = 0; (g_947 > 55); g_947 = safe_add_func_int8_t_s_s(g_947, 2))
                    { /* block id: 507 */
                        int32_t * const *l_1294 = &l_1226;
                        int32_t * const **l_1293 = &l_1294;
                        int32_t * const ***l_1295 = &l_1293;
                        int32_t * const **l_1297 = &l_1294;
                        int32_t * const ***l_1296 = &l_1297;
                        l_1255 ^= (*l_1225);
                        (*l_1218) = ((*l_1222) = (safe_rshift_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_s((((*l_1296) = (l_1292 , ((*l_1295) = l_1293))) != (void*)0), 1)) == (((safe_lshift_func_uint16_t_u_u(65535UL, g_271[5].f1)) > (safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(65533UL, (safe_mod_func_int8_t_s_s((((~(safe_mul_func_int16_t_s_s(0x00C6L, (*l_1218)))) != l_1255) > l_1282[1][5]), 0x89L)))), 0x59L))) , 0L)), g_120)));
                        (***l_1297) = (safe_rshift_func_uint16_t_u_s((((((**l_1294) , (*g_229)) != ((safe_mod_func_int8_t_s_s(((*l_1087) = (~(9L < (safe_rshift_func_int16_t_s_u(0x9F81L, ((safe_lshift_func_uint8_t_u_s(((((safe_sub_func_int32_t_s_s(l_1283, (((void*)0 != l_1320) == ((((l_1321 , l_1243) != (void*)0) == (***l_1297)) <= (*l_1227))))) != (****l_1295)) | g_478) >= l_1255), 1)) , l_1284)))))), 249UL)) , l_1322[4])) ^ 4294967294UL) != g_1323), 6));
                    }
                    if (l_1284)
                        continue;
                    (*l_1228) |= ((*l_1216) = (g_853 & 8UL));
                }
                else
                { /* block id: 519 */
                    int8_t l_1324 = (-2L);
                    uint32_t *l_1334 = (void*)0;
                    uint32_t *l_1335 = &l_1152;
                    struct S1 l_1344 = {{16744},0x881E678CL};
                    int64_t *l_1348 = &l_1155;
                    (*l_1225) ^= (l_1324 || (((~(*l_1223)) & (((((*l_1348) = ((((((**l_786) = (-1L)) != (l_1324 & 0x8D0DA1C8L)) , (safe_mul_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u((*l_1226), 65528UL)), (((*l_1335)++) , (safe_add_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((((l_1344 , l_1345[2]) != l_1346) >= 0x9DL), 0xE369L)), 0x5AL)) && l_1344.f0.f0), g_173))))), 0xE2L)), 0x3BBAL))) >= (*l_1228)) == l_1347)) == 0x264E8617B8CF53A3LL) >= 0L) & 0x54C1L)) < l_1321.f0));
                }
                (*l_1222) &= (((*l_1240) = 250UL) ^ (-4L));
                l_1349++;
            }
            (*l_1225) |= (safe_unary_minus_func_int64_t_s(((*g_533) = (-1L))));
            for (g_53 = 3; (g_53 >= 1); g_53 -= 1)
            { /* block id: 533 */
                uint32_t l_1353 = 0xCCD058C8L;
                int16_t *l_1382 = (void*)0;
                uint32_t l_1404 = 0x0635CE14L;
                int32_t l_1433[7];
                int i;
                for (i = 0; i < 7; i++)
                    l_1433[i] = (-10L);
                l_1353--;
                for (l_1139 = 1; (l_1139 <= 4); l_1139 += 1)
                { /* block id: 537 */
                    uint32_t l_1363[5];
                    uint64_t *l_1400[6][8] = {{&l_1233,&l_1349,&l_1349,(void*)0,&g_105,(void*)0,&l_1233,&l_1233},{&l_1349,(void*)0,(void*)0,(void*)0,(void*)0,&l_1349,&g_105,&l_1349},{(void*)0,&l_1349,&g_105,&l_1349,(void*)0,(void*)0,&l_1349,(void*)0},{&l_1349,&l_1233,&g_105,&l_1349,&g_105,&l_1233,&g_105,&l_1349},{(void*)0,&g_105,(void*)0,(void*)0,&g_105,&g_105,(void*)0,&l_1233},{&g_105,&g_105,&g_105,(void*)0,&l_1233,(void*)0,&g_105,&g_105}};
                    int32_t l_1406[10] = {(-1L),0xE915E89AL,(-1L),0xE915E89AL,(-1L),0xE915E89AL,(-1L),0xE915E89AL,(-1L),0xE915E89AL};
                    const uint8_t *l_1424 = &g_120;
                    const uint8_t * const *l_1423[10][5][4] = {{{&l_1424,(void*)0,&l_1424,(void*)0},{&l_1424,&l_1424,(void*)0,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,(void*)0},{&l_1424,&l_1424,&l_1424,(void*)0}},{{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,(void*)0},{(void*)0,(void*)0,&l_1424,&l_1424},{&l_1424,(void*)0,(void*)0,&l_1424},{&l_1424,(void*)0,&l_1424,&l_1424}},{{(void*)0,(void*)0,&l_1424,(void*)0},{&l_1424,&l_1424,(void*)0,&l_1424},{&l_1424,&l_1424,&l_1424,(void*)0},{&l_1424,&l_1424,&l_1424,(void*)0},{(void*)0,&l_1424,&l_1424,&l_1424}},{{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,(void*)0,(void*)0},{&l_1424,(void*)0,&l_1424,&l_1424},{&l_1424,&l_1424,(void*)0,&l_1424},{&l_1424,&l_1424,&l_1424,(void*)0}},{{&l_1424,&l_1424,&l_1424,&l_1424},{(void*)0,(void*)0,&l_1424,&l_1424},{&l_1424,(void*)0,&l_1424,&l_1424},{&l_1424,(void*)0,(void*)0,&l_1424},{&l_1424,&l_1424,(void*)0,&l_1424}},{{(void*)0,&l_1424,&l_1424,(void*)0},{(void*)0,(void*)0,&l_1424,(void*)0},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,(void*)0,(void*)0,&l_1424}},{{&l_1424,(void*)0,&l_1424,&l_1424},{&l_1424,(void*)0,&l_1424,&l_1424},{(void*)0,&l_1424,(void*)0,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424}},{{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,(void*)0,(void*)0,&l_1424},{(void*)0,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424}},{{&l_1424,&l_1424,(void*)0,(void*)0},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,(void*)0,&l_1424,&l_1424},{(void*)0,(void*)0,&l_1424,&l_1424}},{{(void*)0,&l_1424,(void*)0,&l_1424},{&l_1424,&l_1424,(void*)0,(void*)0},{&l_1424,&l_1424,&l_1424,&l_1424},{&l_1424,&l_1424,&l_1424,&l_1424},{(void*)0,&l_1424,&l_1424,&l_1424}}};
                    const uint8_t * const **l_1425 = (void*)0;
                    const uint8_t * const **l_1426 = &l_1423[3][4][1];
                    uint8_t **l_1427[5];
                    uint8_t ***l_1428 = &l_1427[4];
                    uint8_t **l_1430[9] = {&l_1238,&l_1238,&l_1238,&l_1238,&l_1238,&l_1238,&l_1238,&l_1238,&l_1238};
                    uint8_t ***l_1429 = &l_1430[8];
                    uint16_t *l_1432[7];
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_1363[i] = 4294967291UL;
                    for (i = 0; i < 5; i++)
                        l_1427[i] = &l_1238;
                    for (i = 0; i < 7; i++)
                        l_1432[i] = &g_947;
                    for (g_853 = 1; (g_853 <= 4); g_853 += 1)
                    { /* block id: 540 */
                        int16_t *l_1362 = &g_837;
                        int i, j;
                        (*l_1219) = ((safe_mod_func_int16_t_s_s(((*l_1362) = ((((g_59[(l_1139 + 1)][g_853] && ((0xA436L <= g_59[(g_853 + 1)][g_853]) <= ((0x4AL == (-1L)) != l_1353))) ^ ((safe_lshift_func_uint8_t_u_u(0UL, 2)) < l_1353)) | (safe_lshift_func_uint8_t_u_s(((l_1231 , g_53) & l_1353), 6))) ^ g_1178[0][0])), (*l_1221))) ^ g_515);
                        l_1363[3]--;
                    }
                    if (l_1155)
                        goto lbl_1366;
                    for (g_947 = 0; (g_947 <= 2); g_947 += 1)
                    { /* block id: 548 */
                        uint32_t *l_1368 = &g_1323;
                        int16_t *l_1375 = &l_1347;
                        int32_t l_1381 = 8L;
                        int32_t l_1383 = 7L;
                        (*l_1219) |= (l_1367 != ((((*l_1368) = g_271[5].f0.f0) && (((safe_rshift_func_uint16_t_u_s(g_173, 11)) != (safe_sub_func_int64_t_s_s((((((safe_lshift_func_int16_t_s_u(((*l_1375) ^= 0x8D44L), 5)) >= (safe_add_func_uint32_t_u_u((0x3FL | (safe_div_func_int64_t_s_s(((((+(((l_1381 = l_1353) & 65529UL) <= (l_1382 == l_1382))) < l_1363[2]) == l_1353) , l_1363[3]), 0x0E2CA7ADC8140A70LL))), l_1383))) > 0L) , 0x0BDB316DD18DFEAFLL) ^ 0x3825DCBB0E07BD90LL), l_1203[1][2][1].f1))) && 1UL)) , l_1367));
                        l_1406[5] = ((safe_mul_func_int16_t_s_s(1L, (safe_add_func_int16_t_s_s((safe_add_func_int16_t_s_s(g_265, (-4L))), ((*l_1375) = ((0UL >= (((safe_div_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u(((((safe_rshift_func_int8_t_s_s((safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((((l_1400[5][0] = &l_1349) == (l_636 , (l_1401 = &l_1349))) , (safe_rshift_func_int16_t_s_s((l_1383 , ((g_271[5].f1 ^ g_389) <= l_1404)), 15))), g_919.f0)), l_1363[4])), l_1353)) ^ l_1405) , l_1381) <= l_1363[4]), g_1178[1][3])) , 0x91F72B32L), l_1383)) >= 0x71L) ^ 0xECE0B20EL)) ^ l_1353)))))) > l_1381);
                        ++l_1407;
                    }
                    l_1433[5] = ((g_853 = ((+((safe_add_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u(((((safe_mod_func_int8_t_s_s((safe_add_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((*l_1224), (((((*l_1426) = l_1423[3][4][2]) != ((*l_1429) = ((*l_1428) = l_1427[2]))) , l_1363[3]) != ((l_1231 = 0x1933L) ^ ((0x6B0ABD3DA8C0C422LL != 0x025687D1402DB684LL) || g_380))))), 0x9FL)), l_1171)), l_1404)) && (*g_533)) || l_1203[1][2][1].f1) | g_53), 2L)) , l_1431), l_1171)) == 0x0523L)) ^ l_1406[4])) <= l_1363[3]);
                }
                if ((l_1353 & l_1433[2]))
                { /* block id: 566 */
                    for (g_265 = 0; (g_265 <= 1); g_265 += 1)
                    { /* block id: 569 */
                        int i;
                        l_651[(g_53 + 1)] = ((void*)0 != l_1434);
                    }
                }
                else
                { /* block id: 572 */
                    uint32_t l_1435 = 0UL;
                    return l_1435;
                }
                if ((*l_1221))
                    continue;
                for (g_389 = 0; (g_389 <= 2); g_389 += 1)
                { /* block id: 578 */
                    if (l_1433[5])
                    { /* block id: 579 */
                        return (*l_1228);
                    }
                    else
                    { /* block id: 581 */
                        if (l_1404)
                            break;
                        if (l_1349)
                            break;
                    }
                    for (g_105 = 0; (g_105 <= 2); g_105 += 1)
                    { /* block id: 587 */
                        if (l_1230)
                            break;
                    }
                }
            }
        }
        l_649 = ((l_1436 != ((((&l_1168[0][1][2] != l_1438) && (~((*g_533) & (((((*l_1240) |= g_947) || (65535UL ^ (l_1261 , ((((g_31 && l_1230) > l_1208) > 0x4549AC93A4D6210FLL) & (*g_533))))) & 18446744073709551615UL) | g_947)))) < l_1231) , l_1440[0])) | l_1203[1][2][1].f1);
    }
    return l_1254[1][3][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_31 g_105 g_64 g_108 g_120 g_55 g_59 g_53 g_33 g_101 g_173 g_178 g_181 g_29 g_265 g_271 g_282 g_350 g_389 g_229 g_351.f0 g_533 g_478 g_515
 * writes: g_33 g_101 g_59 g_55 g_105 g_108 g_53 g_120 g_64 g_173 g_178 g_181 g_29 g_229 g_265 g_380 g_389 g_478 g_533 g_515 g_594
 */
static int32_t * func_69(int32_t * p_70)
{ /* block id: 15 */
    uint32_t l_71 = 4294967290UL;
    const int16_t **l_191 = (void*)0;
    int32_t ***l_228 = (void*)0;
    uint8_t *l_272 = &g_120;
    int32_t l_378 = 2L;
    uint8_t l_434[8] = {1UL,1UL,0xE7L,1UL,1UL,0xE7L,1UL,1UL};
    uint8_t l_443[7] = {255UL,0x5FL,255UL,255UL,0x5FL,255UL,255UL};
    int32_t l_450 = 0xAFF1BAE2L;
    int32_t l_452 = 0x34D590DDL;
    int32_t l_454 = 0x7952EEAFL;
    int32_t l_462 = (-3L);
    int32_t l_464 = 8L;
    uint16_t l_516[7] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
    int32_t *l_580[9] = {&g_173,&g_53,&g_53,&g_173,&g_53,&g_53,&g_173,&g_53,&g_53};
    uint8_t l_607[10][1] = {{1UL},{0UL},{1UL},{1UL},{0UL},{1UL},{1UL},{0UL},{1UL},{1UL}};
    uint8_t l_614 = 1UL;
    int16_t *l_615 = &g_515;
    int i, j;
lbl_398:
    (*p_70) = l_71;
    for (g_33 = 12; (g_33 <= 46); g_33 = safe_add_func_int64_t_s_s(g_33, 1))
    { /* block id: 19 */
        int16_t *l_76[10][10][2] = {{{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{&g_31,(void*)0},{&g_31,(void*)0},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{&g_31,(void*)0},{&g_31,(void*)0},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,&g_31},{(void*)0,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{&g_31,(void*)0},{&g_31,(void*)0},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31}},{{(void*)0,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,(void*)0}},{{&g_31,(void*)0},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31}},{{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{(void*)0,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,&g_31},{&g_31,(void*)0},{&g_31,(void*)0}}};
        int32_t l_195 = 0L;
        int8_t *l_234 = (void*)0;
        struct S1 l_241 = {{16129},0UL};
        int32_t ** const *l_263 = &g_181[1];
        int32_t *l_264 = &g_265;
        uint8_t *l_266 = &g_120;
        int32_t l_267 = (-7L);
        uint64_t *l_281 = &g_105;
        int16_t l_382 = (-5L);
        uint8_t l_437[7];
        int32_t l_451 = 0xD333E659L;
        int32_t l_453 = 0x32640380L;
        int32_t l_455 = 0xE2EB505FL;
        int32_t l_456 = 0x0759AD52L;
        int32_t l_457 = 0x4847A4CAL;
        int32_t l_458 = (-10L);
        int32_t l_459 = 1L;
        int32_t l_460 = 0x6A93AB14L;
        int32_t l_463 = 0L;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_437[i] = 1UL;
        if (func_74(l_76[0][8][0]))
        { /* block id: 61 */
            uint32_t l_200 = 0xE552D92CL;
            for (g_101 = 1; (g_101 >= 0); g_101 -= 1)
            { /* block id: 64 */
                struct S0 *l_193 = (void*)0;
                struct S0 **l_194 = &l_193;
                int32_t l_216 = 0x9E7098F1L;
                if ((*p_70))
                { /* block id: 65 */
                    int32_t *l_190 = (void*)0;
                    return l_190;
                }
                else
                { /* block id: 67 */
                    const int16_t ***l_192 = &l_191;
                    (*l_192) = l_191;
                }
                (*l_194) = l_193;
                if (l_195)
                { /* block id: 71 */
                    int32_t *l_196 = &g_173;
                    int32_t *l_197 = (void*)0;
                    int32_t *l_198 = &l_195;
                    int32_t *l_199[6][1][4] = {{{&g_173,&g_53,&g_173,&g_55}},{{&g_173,&g_55,&g_173,&g_53}},{{&g_173,&g_55,&g_55,&g_55}},{{&g_173,&l_195,&g_55,&g_53}},{{&g_55,&g_53,&g_55,&l_195}},{{&g_173,&g_53,&g_173,&g_53}}};
                    int i, j, k;
                    for (g_178 = 0; (g_178 <= 1); g_178 += 1)
                    { /* block id: 74 */
                        if ((*p_70))
                            break;
                        (*l_194) = (*l_194);
                    }
                    ++l_200;
                    for (g_120 = 0; (g_120 <= 1); g_120 += 1)
                    { /* block id: 81 */
                        return p_70;
                    }
                }
                else
                { /* block id: 84 */
                    int32_t l_213[9][3][2] = {{{0x2998C320L,0x96C7B4C5L},{0x2998C320L,(-3L)},{0x5A76CD9FL,8L}},{{(-3L),0L},{0x145B7FBAL,(-3L)},{0x96C7B4C5L,0x2998C320L}},{{0x2998C320L,0x2FA25C20L},{0x145B7FBAL,8L},{0x2FA25C20L,8L}},{{0x145B7FBAL,0x2FA25C20L},{0x2998C320L,0x2998C320L},{0x96C7B4C5L,(-3L)}},{{0x145B7FBAL,0L},{(-3L),8L},{0x5A76CD9FL,(-3L)}},{{0x2998C320L,0x96C7B4C5L},{0x2998C320L,(-3L)},{0x5A76CD9FL,8L}},{{(-3L),0L},{0x145B7FBAL,(-3L)},{0x96C7B4C5L,0x2998C320L}},{{0x2998C320L,0x2FA25C20L},{0x145B7FBAL,8L},{0x2FA25C20L,8L}},{{0x145B7FBAL,0x2FA25C20L},{0x2998C320L,0x2998C320L},{0x96C7B4C5L,(-3L)}}};
                    int i, j, k;
                    for (g_178 = 0; (g_178 <= 1); g_178 += 1)
                    { /* block id: 87 */
                        int64_t *l_217[3];
                        int32_t l_218 = 0x0667DD3FL;
                        int32_t *l_220 = &l_195;
                        int32_t **l_219 = &l_220;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_217[i] = &g_29;
                        (*l_219) = ((safe_add_func_uint16_t_u_u(65535UL, (safe_mod_func_int16_t_s_s((((safe_div_func_uint64_t_u_u(((safe_mul_func_int8_t_s_s(l_195, ((safe_lshift_func_uint8_t_u_s(((l_213[5][2][1] > l_195) != (((safe_lshift_func_int8_t_s_u((l_216 , (((0x5DL & (g_31 , ((g_29 ^= ((g_53 == ((l_200 | 65528UL) ^ 1UL)) , 0x879FA2D9F9B9082ALL)) > l_218))) >= l_195) < 8UL)), l_71)) > g_120) ^ 18446744073709551615UL)), l_216)) >= 0xDFBF4EFDL))) > 0x733EL), 8UL)) & l_71) , 4L), l_71)))) , (void*)0);
                        if ((*p_70))
                            continue;
                    }
                    for (g_120 = 23; (g_120 >= 32); ++g_120)
                    { /* block id: 94 */
                        uint16_t l_223[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_223[i] = 0UL;
                        if (l_216)
                            break;
                        if (l_223[1])
                            break;
                    }
                }
                return p_70;
            }
            if ((*p_70))
                break;
        }
        else
        { /* block id: 102 */
            (*p_70) = 0xE4F92291L;
            (*p_70) = ((safe_add_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((((g_229 = l_228) == (void*)0) ^ 0xB0E04704L), l_71)), (((safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((void*)0 == l_234), (l_195 = (safe_sub_func_uint32_t_u_u(((~((l_195 < (safe_rshift_func_int8_t_s_u(0L, 5))) , 0UL)) ^ 0L), 1UL))))), 0xFF6BL)) < 1L) ^ g_59[2][2]))) ^ (-1L));
        }
        if ((l_267 &= (safe_unary_minus_func_uint8_t_u(((*l_266) = (((l_241 , (safe_rshift_func_uint8_t_u_u(g_64, ((((*l_264) |= (safe_add_func_uint64_t_u_u((safe_sub_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((((g_33 == (((safe_mod_func_int16_t_s_s(((g_64 ^ (safe_add_func_int16_t_s_s((safe_unary_minus_func_int32_t_s((safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((l_195 ^= ((safe_sub_func_uint32_t_u_u((g_59[3][0] = 0x8D7DD194L), (*p_70))) ^ l_241.f1)), g_29)) == (((g_229 = &g_181[1]) == l_263) >= 1L)), l_71)))), (-9L)))) ^ 0x8D69L), l_241.f1)) & 0x842A2D73B8AE9C4DLL) && 0x37D4FFB9L)) , p_70) != p_70), l_241.f1)), l_71)) <= (*p_70)) > 0x12782790L), 1L)), 0xE5E31DAC9CA45F45LL))) , 0xE0DADD7EL) == (*p_70))))) != 0xD9L) != l_241.f1))))))
        { /* block id: 114 */
            int8_t *l_270 = &g_101;
            uint8_t **l_273 = &l_272;
            int32_t l_352 = (-1L);
            int32_t ***l_363 = &g_181[1];
            uint16_t l_435[7][10] = {{65531UL,0x38A1L,65535UL,0x0B7DL,0x811BL,0x9B95L,5UL,0x9B95L,0x811BL,0x0B7DL},{0x0B7DL,1UL,0x0B7DL,0x38A1L,0x811BL,65534UL,0xB6D7L,0xA12DL,0xA12DL,0xB6D7L},{0x811BL,5UL,65534UL,65534UL,5UL,0x811BL,65531UL,0xA12DL,0xBDE5L,0x9B95L},{1UL,0x9B95L,0x0B7DL,0x8F82L,0xA12DL,0x8F82L,0x0B7DL,0x9B95L,1UL,0x811BL},{1UL,65534UL,65535UL,65531UL,0x8F82L,0x811BL,0x811BL,0x8F82L,65531UL,65535UL},{0x811BL,0x811BL,0x8F82L,65531UL,65535UL,65534UL,1UL,0xB6D7L,1UL,65534UL},{0x0B7DL,0x8F82L,0xA12DL,0x8F82L,0x0B7DL,0x9B95L,1UL,0x811BL,0xBDE5L,0xBDE5L}};
            int32_t *l_438 = (void*)0;
            int32_t *l_446 = &g_53;
            int32_t *l_447 = &l_195;
            int32_t *l_448 = &l_352;
            int32_t *l_449[1][3];
            int64_t l_461[10][7][3] = {{{(-4L),0x96434A620E5CB8B0LL,0x4058C229EA8CDBFELL},{7L,0xD76B79F5D47AEF6BLL,0xF8A40BFA01428A19LL},{0x141DDC807E202EB8LL,0x141DDC807E202EB8LL,0xD76B79F5D47AEF6BLL},{0L,(-2L),(-3L)},{0x10D7CE3149CD46B3LL,0x35A7AD6E3605197ALL,(-1L)},{0x2A4F7C10BBDDBA7CLL,0L,3L},{7L,0x10D7CE3149CD46B3LL,(-1L)}},{{1L,(-1L),(-3L)},{1L,0xB97F588084778C19LL,0xD76B79F5D47AEF6BLL},{(-1L),(-1L),0xF8A40BFA01428A19LL},{0xD9501DDF95CFB2E6LL,0L,0x4058C229EA8CDBFELL},{0x16F7237B87D7233BLL,0xE8E21DAA83EEEFFCLL,0x3957C8F7EC801660LL},{1L,(-8L),6L},{(-4L),6L,(-1L)}},{{1L,0xF3D461231412B05DLL,0xF8A40BFA01428A19LL},{0x2A4F7C10BBDDBA7CLL,0x96434A620E5CB8B0LL,0x6DBAAEF4B3A1EB68LL},{(-1L),(-2L),4L},{(-1L),0xED8EA83097D7708ALL,1L},{0x2A4F7C10BBDDBA7CLL,0xD9501DDF95CFB2E6LL,0x4058C229EA8CDBFELL},{3L,1L,0L},{0x1EB699569A532080LL,0xED8EA83097D7708ALL,0xF8A40BFA01428A19LL}},{{1L,(-1L),(-1L)},{0L,0L,1L},{0x3957C8F7EC801660LL,0xD9501DDF95CFB2E6LL,0xD9501DDF95CFB2E6LL},{0xD9501DDF95CFB2E6LL,(-1L),0xF3D461231412B05DLL},{(-1L),0x16F7237B87D7233BLL,0x243F2C433C4BAA0ELL},{0xB97F588084778C19LL,0x6DBAAEF4B3A1EB68LL,0x28F5E786042C3A19LL},{(-2L),0x10D7CE3149CD46B3LL,1L}},{{0x243F2C433C4BAA0ELL,0x6DBAAEF4B3A1EB68LL,0L},{(-4L),0x16F7237B87D7233BLL,(-3L)},{0x88F486F508354CC9LL,(-1L),0xC73EFF6A7A4DC308LL},{0xD76B79F5D47AEF6BLL,0xD9501DDF95CFB2E6LL,0L},{(-2L),0L,3L},{0x1EB699569A532080LL,(-1L),0L},{0x49D59A091B0A25A8LL,0xED8EA83097D7708ALL,(-1L)}},{{2L,1L,(-1L)},{6L,0xD9501DDF95CFB2E6LL,0x28F5E786042C3A19LL},{0L,(-3L),0x6DBAAEF4B3A1EB68LL},{(-1L),0x4058C229EA8CDBFELL,0x6DBAAEF4B3A1EB68LL},{1L,0x58B460CC3469EF66LL,0x28F5E786042C3A19LL},{0xC73EFF6A7A4DC308LL,(-1L),(-1L)},{0xD76B79F5D47AEF6BLL,0x6DBAAEF4B3A1EB68LL,(-1L)}},{{0L,(-1L),0L},{0x88F486F508354CC9LL,0x6022EAB5B3BED09FLL,3L},{0x6DBAAEF4B3A1EB68LL,0x6E7E1396008A2179LL,0L},{0xC73EFF6A7A4DC308LL,1L,0xC73EFF6A7A4DC308LL},{0xB97F588084778C19LL,(-1L),(-3L)},{1L,0xE8E21DAA83EEEFFCLL,0L},{2L,(-4L),1L}},{{0x2A4F7C10BBDDBA7CLL,0x6E7E1396008A2179LL,0x28F5E786042C3A19LL},{2L,(-1L),0x243F2C433C4BAA0ELL},{1L,0x4058C229EA8CDBFELL,0xF3D461231412B05DLL},{0xB97F588084778C19LL,0xD76B79F5D47AEF6BLL,0xD9501DDF95CFB2E6LL},{0xC73EFF6A7A4DC308LL,0L,1L},{0x6DBAAEF4B3A1EB68LL,0x58B460CC3469EF66LL,(-1L)},{0x88F486F508354CC9LL,0x16F7237B87D7233BLL,0xF8A40BFA01428A19LL}},{{0L,0x6022EAB5B3BED09FLL,0L},{0xD76B79F5D47AEF6BLL,0L,0x4058C229EA8CDBFELL},{0xC73EFF6A7A4DC308LL,(-4L),3L},{1L,0xED8EA83097D7708ALL,(-3L)},{(-1L),0xED8EA83097D7708ALL,(-1L)},{0L,(-4L),0x257A66F0E9A398A8LL},{6L,0L,0xD9501DDF95CFB2E6LL}},{{2L,0x6022EAB5B3BED09FLL,0x6DBAAEF4B3A1EB68LL},{0x49D59A091B0A25A8LL,0x16F7237B87D7233BLL,0xF3D461231412B05DLL},{0x1EB699569A532080LL,0x58B460CC3469EF66LL,2L},{(-2L),0L,0x257A66F0E9A398A8LL},{0xD76B79F5D47AEF6BLL,0xD76B79F5D47AEF6BLL,0L},{0x88F486F508354CC9LL,0x4058C229EA8CDBFELL,0L},{(-4L),(-1L),0L}}};
            uint8_t l_465[4] = {254UL,254UL,254UL,254UL};
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_449[i][j] = &l_267;
            }
            if ((g_173 > (safe_lshift_func_int8_t_s_u(((*l_270) |= g_59[1][3]), ((g_271[5] , l_234) != ((*l_273) = l_272))))))
            { /* block id: 117 */
                uint16_t *l_353 = (void*)0;
                uint16_t *l_354 = (void*)0;
                int32_t l_355 = 4L;
                int32_t l_391 = (-10L);
                int32_t l_393[8] = {0x9C739074L,0x9C739074L,0x0667F4F1L,0x9C739074L,0x9C739074L,0x0667F4F1L,0x9C739074L,0x9C739074L};
                int16_t l_406 = 0xF0F9L;
                int32_t l_410 = 0x2EAA6358L;
                int i;
                p_70 = p_70;
                if ((safe_unary_minus_func_int64_t_s(((safe_mod_func_uint64_t_u_u(0xB4E17504899D85C3LL, ((safe_div_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((l_355 = ((((void*)0 != l_281) & 3L) > ((g_282[1] == &l_272) >= (l_241 , (((safe_mul_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_u(g_120, 1)), 15)) || ((g_350[3] == &g_351[9]) , l_352)) , l_71), (-2L))) >= l_352) || g_33))))), 6L)), l_352)) && 0x1111A74DA8DAF7D2LL))) , l_355))))
                { /* block id: 120 */
                    int8_t l_364 = 0xB5L;
                    (*p_70) = ((g_271[5] , ((((safe_lshift_func_uint8_t_u_s(0xE3L, 3)) , 18446744073709551608UL) && ((0L < (safe_mod_func_int64_t_s_s(((g_55 || (g_105 , (0x8A383003L >= (safe_div_func_uint64_t_u_u(((~(&g_181[1] != l_363)) != g_120), g_178))))) < 247UL), 0x54DD28137182850DLL))) >= l_364)) , l_352)) & l_364);
                }
                else
                { /* block id: 122 */
                    int8_t l_377 = 0xD8L;
                    int32_t *l_415 = &l_355;
                    for (g_29 = (-2); (g_29 < 1); g_29++)
                    { /* block id: 125 */
                        struct S0 l_370 = {3963};
                        uint8_t *l_379 = &g_380;
                        uint8_t *l_381 = (void*)0;
                        uint8_t *l_387 = (void*)0;
                        uint8_t *l_388[2];
                        int32_t l_390 = 1L;
                        int32_t l_392 = 0xADF7E4CAL;
                        int32_t l_396 = 0x9396E87CL;
                        int32_t *l_397 = &g_55;
                        int8_t *l_409[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        for (i = 0; i < 2; i++)
                            l_388[i] = &g_389;
                        (*l_397) |= (((~(((((safe_add_func_uint64_t_u_u(g_59[2][2], (l_370 , (safe_add_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_u((l_378 ^= ((*l_266) = l_377)), (l_382 = ((*p_70) , ((*l_379) = l_352))))) && (safe_div_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(((((g_389--) != g_173) || ((((l_390 , ((l_377 , (*g_229)) == (*g_229))) ^ l_71) & 254UL) & l_391)) < l_396), 1L)), 0xFCC9L))), 0x8238ABA1L))))) || l_377) ^ 0xA9C3L) | l_396) , g_351[9].f0)) > l_377) , 0x4D3B4240L);
                        if (l_241.f0.f0)
                            goto lbl_398;
                        (*l_397) = (+((safe_add_func_int64_t_s_s((*l_397), ((safe_add_func_int64_t_s_s(((safe_rshift_func_int16_t_s_u((l_406 ^ (l_393[7] &= 0x83DCL)), 9)) < (0x3E13L > ((safe_div_func_int8_t_s_s(((*l_270) = (-1L)), (l_410 = (*l_397)))) | (l_377 == 0L)))), (g_351[9].f0 & 0xB4CC9C1CD1AA1144LL))) | g_59[4][2]))) & (*l_397)));
                    }
                    (*p_70) = ((safe_add_func_int64_t_s_s(7L, ((g_64 && ((safe_div_func_uint32_t_u_u((((*l_266) &= ((((*p_70) == ((*l_415) ^= (l_377 || g_178))) <= g_29) & (0xFFA7BA6158B85164LL & ((*l_281)--)))) != 3L), (l_391 ^ g_173))) != g_271[5].f0.f0)) > l_391))) != (-5L));
                }
                (*p_70) |= (safe_rshift_func_uint8_t_u_s(0x7FL, 3));
            }
            else
            { /* block id: 144 */
                int16_t l_429[6][2][5] = {{{(-1L),0x6988L,0L,1L,(-8L)},{(-7L),5L,1L,0x474EL,0xE8F0L}},{{(-8L),0x749BL,0x83EDL,0x41BBL,0x83EDL},{(-8L),3L,0x41BBL,0x749BL,0x474EL}},{{0x0F73L,0x83EDL,(-5L),0x6F6CL,0x83EDL},{(-6L),0L,0xB619L,0x83EDL,0x6F6CL}},{{0x4B7CL,0x83EDL,1L,0x474EL,0x749BL},{0xA6FEL,3L,0x3B7DL,0x6F6CL,1L}},{{1L,0x3B7DL,0x3B7DL,1L,0x1527L},{0x474EL,0x4B7CL,1L,3L,(-7L)}},{{0x0F73L,0x749BL,0xB619L,0x1527L,0x4B7CL},{(-7L),0x3B7DL,(-5L),3L,0x6F6CL}}};
                int i, j, k;
                for (g_265 = (-19); (g_265 == 29); ++g_265)
                { /* block id: 147 */
                    int8_t l_436 = 0x05L;
                    int32_t **l_439 = &l_438;
                    for (g_178 = 0; (g_178 > 16); g_178 = safe_add_func_int8_t_s_s(g_178, 4))
                    { /* block id: 150 */
                        int32_t *l_424 = &l_195;
                        (*l_424) ^= (*p_70);
                        l_437[3] = (safe_mod_func_int32_t_s_s((-3L), ((4294967294UL & (safe_div_func_uint64_t_u_u((l_429[3][0][0] , (safe_mod_func_int32_t_s_s((l_429[3][0][0] | (safe_rshift_func_uint8_t_u_u(((((*l_424) |= (*p_70)) , (l_429[3][0][0] <= 0xAEL)) && 65535UL), (l_434[1] , l_435[3][6])))), 1UL))), l_436))) , (*p_70))));
                    }
                    (*l_439) = l_438;
                    for (g_380 = 0; (g_380 <= 4); g_380 += 1)
                    { /* block id: 158 */
                        int32_t *l_440 = &l_267;
                        int32_t *l_441 = &g_53;
                        int32_t *l_442 = &g_55;
                        l_443[3]++;
                    }
                }
            }
            l_465[1]--;
        }
        else
        { /* block id: 164 */
            uint32_t *l_476 = &l_241.f1;
            int8_t *l_481 = &g_101;
            int32_t l_485[8][1][7] = {{{0xEBB79057L,0xEBB79057L,1L,0xB20DAB1FL,0xDDFCE9A9L,1L,0xDDFCE9A9L}},{{0xB20DAB1FL,1L,1L,0xB20DAB1FL,1L,0L,0xB20DAB1FL}},{{0L,0xDDFCE9A9L,1L,1L,0xDDFCE9A9L,0L,1L}},{{0xDDFCE9A9L,0xB20DAB1FL,1L,0xEBB79057L,0xEBB79057L,1L,0xB20DAB1FL}},{{0xDDFCE9A9L,1L,0L,0xDDFCE9A9L,1L,1L,0xDDFCE9A9L}},{{0L,0xB20DAB1FL,0L,1L,0xB20DAB1FL,1L,1L}},{{0xB20DAB1FL,0xDDFCE9A9L,1L,0xDDFCE9A9L,0xB20DAB1FL,1L,0xEBB79057L}},{{0xEBB79057L,1L,1L,0xEBB79057L,1L,1L,0xEBB79057L}}};
            int32_t *l_508 = &g_173;
            int64_t l_545 = 0x0510C14C1011A950LL;
            int16_t l_548 = 0x0798L;
            int16_t l_549 = 7L;
            uint32_t *l_550 = &g_59[2][2];
            uint64_t *l_552 = &g_105;
            struct S1 l_567 = {{27831},1UL};
            int i, j, k;
            for (g_101 = (-13); (g_101 >= 28); g_101++)
            { /* block id: 167 */
                const uint8_t l_474 = 0x89L;
                struct S0 l_475 = {11540};
                int8_t *l_477 = &g_478;
                int32_t l_491 = 0x3B5EDC1AL;
                int32_t l_500 = (-8L);
                int32_t l_501[3];
                int32_t *l_505 = &l_452;
                int32_t **l_555 = (void*)0;
                int32_t **l_556 = &l_505;
                int i;
                for (i = 0; i < 3; i++)
                    l_501[i] = 0x68E8D610L;
                if ((safe_lshift_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_u(l_474, ((l_475 , l_476) == (((*l_477) = g_389) , l_264)))) , ((void*)0 != &g_105)), 6)))
                { /* block id: 169 */
                    int8_t l_482 = 0x70L;
                    int32_t l_497 = 0x36592907L;
                    int32_t l_498 = 0x0D190778L;
                    int32_t l_499 = 0xFC47F6C5L;
                    uint64_t l_502 = 1UL;
                    int32_t *l_507 = &l_462;
                    if (((safe_mod_func_int64_t_s_s(((void*)0 == l_481), l_482)) || ((l_475.f0 <= ((((safe_mul_func_uint8_t_u_u(((*p_70) || l_474), g_29)) >= (-1L)) <= (&g_59[2][2] == &g_59[2][2])) | g_271[5].f1)) == l_485[5][0][5])))
                    { /* block id: 170 */
                        int32_t *l_486 = (void*)0;
                        int32_t *l_487 = &l_458;
                        (*l_487) ^= (*p_70);
                    }
                    else
                    { /* block id: 172 */
                        int32_t *l_488 = (void*)0;
                        int32_t **l_489 = &l_488;
                        (*l_489) = l_488;
                    }
                    for (l_456 = 7; (l_456 >= 0); l_456 -= 1)
                    { /* block id: 177 */
                        int32_t *l_490[4] = {&l_485[5][0][5],&l_485[5][0][5],&l_485[5][0][5],&l_485[5][0][5]};
                        int i;
                        l_491 &= (*p_70);
                    }
                    if ((safe_div_func_uint64_t_u_u(0UL, l_482)))
                    { /* block id: 180 */
                        int32_t *l_494 = &l_451;
                        int32_t *l_495 = (void*)0;
                        int32_t *l_496[2][1][5] = {{{&l_454,&l_195,&l_195,&l_454,&l_464}},{{&l_454,&l_195,&l_195,&l_454,&l_464}}};
                        int32_t *l_506 = &l_491;
                        int i, j, k;
                        l_502--;
                        return p_70;
                    }
                    else
                    { /* block id: 183 */
                        p_70 = l_507;
                        return l_508;
                    }
                }
                else
                { /* block id: 187 */
                    int32_t l_530[5] = {1L,1L,1L,1L,1L};
                    int i;
                    if (((*l_505) ^= 0x285A3C82L))
                    { /* block id: 189 */
                        int64_t l_509 = 0xB4A9CCAB8F3872A3LL;
                        int32_t *l_510 = &l_450;
                        int32_t *l_511 = &l_460;
                        int32_t *l_512 = &l_500;
                        int32_t *l_513 = &l_501[2];
                        int32_t *l_514[1][1];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_514[i][j] = &l_462;
                        }
                        --l_516[2];
                    }
                    else
                    { /* block id: 191 */
                        uint8_t l_521 = 0UL;
                        int64_t *l_535 = &g_29;
                        int64_t **l_534 = &l_535;
                        int64_t *l_537[4][4][6] = {{{&g_29,&g_29,(void*)0,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,(void*)0,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29}},{{(void*)0,&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29}},{{(void*)0,&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,(void*)0,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29}},{{(void*)0,&g_29,&g_29,&g_29,&g_29,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29},{(void*)0,&g_29,&g_29,&g_29,(void*)0,&g_29},{&g_29,&g_29,&g_29,&g_29,&g_29,&g_29}}};
                        int64_t **l_536 = &l_537[1][3][3];
                        uint16_t *l_538 = &l_516[0];
                        int i, j, k;
                        (*p_70) = (p_70 == ((((void*)0 == g_108) | ((*l_538) ^= (((safe_mod_func_int32_t_s_s(((*l_508) = l_521), (safe_mul_func_int8_t_s_s((safe_sub_func_int32_t_s_s((4294967295UL ^ (*l_505)), (safe_mod_func_int8_t_s_s(((safe_mod_func_uint32_t_u_u((l_530[4] | (g_29 = (safe_sub_func_int64_t_s_s((((*l_536) = ((*l_534) = (g_533 = &g_29))) != &g_29), 0x0F6E0E1A0F9E0533LL)))), g_351[9].f0)) != l_530[4]), g_265)))), g_271[5].f1)))) || 1UL) < l_521))) , &g_265));
                    }
                    (*p_70) = ((((((*l_264) = ((*l_505) , ((*l_508) < (safe_mul_func_int8_t_s_s(((safe_rshift_func_int16_t_s_s(((*l_505) |= l_530[4]), 8)) && (((((*g_533) = l_545) | g_55) , (((g_351[9].f0 != ((*l_272)++)) != g_178) & ((*p_70) >= (0xF10B30EBL > l_548)))) == l_530[4])), (*l_508)))))) , l_475) , &l_437[0]) != &g_389) , l_530[4]);
                    if ((*l_508))
                        continue;
                    l_549 = (*p_70);
                }
                (*l_556) = (((((l_550 = l_505) == (void*)0) < (((*l_508) , (*l_505)) || ((~(*p_70)) && ((*l_272) = (((((&g_105 != l_552) || ((((*l_476) |= (safe_mul_func_int16_t_s_s(((&g_59[5][2] == (void*)0) != (*g_533)), (*l_505)))) , (-5L)) , l_434[7])) > 0x45786106L) && (*l_508)) >= 0x0A175CACA662B90DLL))))) <= 6L) , (void*)0);
            }
            (*l_508) = (0xF8L || (*l_508));
            for (l_455 = 0; (l_455 <= 6); l_455 += 1)
            { /* block id: 216 */
                int16_t **l_562[9] = {&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0],&l_76[0][8][0]};
                int32_t l_578 = 0x852E956BL;
                int i;
                for (g_515 = 4; (g_515 >= 1); g_515 -= 1)
                { /* block id: 219 */
                    const int32_t *l_559 = &g_265;
                    int32_t l_579[9][1] = {{1L},{1L},{3L},{1L},{1L},{3L},{1L},{1L},{3L}};
                    int i, j;
                    for (l_378 = 6; (l_378 >= 0); l_378 -= 1)
                    { /* block id: 222 */
                        int i;
                        (*p_70) = (safe_rshift_func_uint8_t_u_s((&g_265 != (l_516[l_378] , l_559)), ((safe_mod_func_uint16_t_u_u((((void*)0 == l_562[0]) | (safe_div_func_int64_t_s_s(l_516[l_455], (safe_rshift_func_uint16_t_u_s((l_241 , (l_567 , (safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((safe_div_func_uint32_t_u_u(l_516[l_378], l_437[l_378])), (*l_508))), l_516[l_455])), l_578)), 7)))), l_579[5][0]))))), g_59[1][2])) , l_579[5][0])));
                    }
                }
            }
        }
        l_580[1] = p_70;
    }
    for (g_55 = 0; (g_55 < (-9)); g_55 = safe_sub_func_uint8_t_u_u(g_55, 8))
    { /* block id: 232 */
        int8_t *l_583 = &g_101;
        int64_t l_584[5][1][9] = {{{8L,0x5ADEFC407A36B178LL,8L,0x517FE088897F66DELL,0x517FE088897F66DELL,8L,0x5ADEFC407A36B178LL,8L,1L}},{{6L,0xEEDA52DB669FF21DLL,8L,1L,0x5ADEFC407A36B178LL,0x5ADEFC407A36B178LL,1L,8L,0xEEDA52DB669FF21DLL}},{{0x517FE088897F66DELL,8L,6L,1L,6L,0x1DBCB66D57E6AFCALL,0x1DBCB66D57E6AFCALL,6L,1L}},{{0x517FE088897F66DELL,0L,0x517FE088897F66DELL,0x1DBCB66D57E6AFCALL,1L,6L,8L,8L,6L}},{{6L,8L,0x517FE088897F66DELL,8L,6L,1L,6L,0x1DBCB66D57E6AFCALL,0x1DBCB66D57E6AFCALL}}};
        uint16_t l_596[9];
        int32_t *l_602 = &l_464;
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_596[i] = 0x09F0L;
        if ((((*l_583) |= g_478) == l_584[1][0][3]))
        { /* block id: 234 */
            int32_t *l_585 = &g_53;
            return l_585;
        }
        else
        { /* block id: 236 */
            uint16_t *l_590 = &l_516[6];
            int16_t *l_591 = &g_515;
            int32_t l_595[3][9];
            int32_t **l_597[1];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 9; j++)
                    l_595[i][j] = 0x5101F638L;
            }
            for (i = 0; i < 1; i++)
                l_597[i] = &l_580[1];
            l_596[0] = (((safe_mul_func_int8_t_s_s(0xA6L, (4294967288UL && g_105))) == ((safe_mul_func_uint16_t_u_u(((*l_590) ^= (0x0978L == 6UL)), ((*l_591) |= l_584[1][0][7]))) > g_389)) && (safe_mul_func_uint16_t_u_u((((g_594 = (void*)0) == (void*)0) == l_595[0][5]), g_173)));
            p_70 = p_70;
            (*l_602) = ((*p_70) = (safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(((l_596[0] , l_272) != ((((void*)0 == l_602) > (*l_602)) , l_583)), ((*l_591) = (((safe_mul_func_uint8_t_u_u(253UL, g_178)) , (safe_add_func_int32_t_s_s((((*l_590) |= 0x76CCL) ^ g_173), (*p_70)))) , (*l_602))))), (*g_533))));
            if (l_607[1][0])
                break;
        }
    }
    (*p_70) = ((safe_div_func_int8_t_s_s(g_271[5].f0.f0, (safe_rshift_func_int8_t_s_u(g_53, (safe_rshift_func_uint8_t_u_u(((l_614 | (&l_272 == &l_272)) <= ((*l_615) |= 0L)), (safe_rshift_func_uint8_t_u_s(((p_70 == (g_271[4] , l_580[4])) && 18446744073709551608UL), g_178)))))))) & g_59[4][4]);
    return p_70;
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_31 g_105 g_64 g_108 g_53 g_120 g_55 g_59 g_33 g_101 g_173 g_178 g_181
 * writes: g_101 g_59 g_55 g_105 g_108 g_53 g_120 g_64 g_173 g_178 g_181
 */
static int32_t  func_74(int16_t * p_75)
{ /* block id: 20 */
    int32_t l_85 = 0x4C81E2E8L;
    int8_t *l_100 = &g_101;
    uint32_t *l_102 = (void*)0;
    int32_t *l_103 = &g_55;
    uint64_t *l_104 = &g_105;
    struct S1 l_106 = {{16355},0x38B78E61L};
    int32_t l_107 = 0x45565C69L;
    int32_t ***l_184[6][5][1] = {{{&g_181[0]},{&g_181[1]},{&g_181[1]},{&g_181[1]},{&g_181[0]}},{{&g_181[1]},{&g_181[0]},{&g_181[1]},{&g_181[1]},{&g_181[1]}},{{&g_181[0]},{&g_181[1]},{&g_181[0]},{&g_181[1]},{&g_181[1]}},{{&g_181[1]},{&g_181[0]},{&g_181[1]},{&g_181[0]},{&g_181[1]}},{{&g_181[1]},{&g_181[1]},{&g_181[0]},{&g_181[1]},{&g_181[0]}},{{&g_181[1]},{&g_181[1]},{&g_181[1]},{&g_181[0]},{&g_181[1]}}};
    uint64_t l_185 = 0UL;
    int i, j, k;
    g_181[0] = func_77(((safe_add_func_int32_t_s_s((((((safe_sub_func_uint64_t_u_u((255UL || (safe_sub_func_int64_t_s_s(l_85, ((!(safe_add_func_int32_t_s_s(0x23F84E0FL, ((void*)0 == g_89)))) , ((*l_104) &= ((((*l_103) = ((safe_mod_func_int64_t_s_s(((((safe_mul_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((g_59[2][2] = (((((*l_100) = ((l_85 ^ ((l_85 && ((safe_add_func_uint32_t_u_u(0xB05D12CBL, l_85)) >= l_85)) , 0xE4L)) < l_85)) > 0x18L) <= 0x01L) , 0x3326EEDAL)), l_85)), l_85)) == l_85), l_85)) == l_85) != g_31) && (-1L)), l_85)) & 0UL)) , &g_55) == (void*)0)))))), l_85)) != l_85) | l_85) , l_106) , l_107), g_64)) , (void*)0));
    l_185--;
    for (g_120 = 0; (g_120 < 10); g_120 = safe_add_func_int16_t_s_s(g_120, 7))
    { /* block id: 53 */
        for (g_173 = 0; (g_173 <= 4); g_173 += 1)
        { /* block id: 56 */
            return (*l_103);
        }
    }
    return (*l_103);
}


/* ------------------------------------------ */
/* 
 * reads : g_108 g_53 g_64 g_120 g_31 g_55 g_59 g_33 g_101 g_173 g_178 g_181
 * writes: g_108 g_53 g_120 g_64 g_59 g_173 g_178
 */
static int32_t ** func_77(int16_t * p_78)
{ /* block id: 25 */
    int16_t ***l_109 = (void*)0;
    int16_t ***l_110 = &g_108;
    int32_t l_118 = 0xA6BC85F6L;
    uint64_t *l_129 = &g_105;
    int32_t l_176[6] = {0x11F59170L,0x11F59170L,1L,0x11F59170L,0x11F59170L,1L};
    int32_t *l_183 = &g_53;
    int32_t **l_182 = &l_183;
    int i;
    (*l_110) = g_108;
    for (g_53 = 0; (g_53 <= 6); g_53 = safe_add_func_int64_t_s_s(g_53, 5))
    { /* block id: 29 */
        uint8_t *l_119 = &g_120;
        const int32_t l_124 = 1L;
        int8_t l_163 = 0x17L;
        int32_t l_174[6][8][5] = {{{(-1L),0L,0L,0L,0x5BBA9885L},{1L,7L,(-10L),(-9L),0xFBAE6C0BL},{1L,0xC1BF41EBL,1L,0L,0L},{1L,(-1L),0L,(-10L),1L},{7L,1L,0x623B7989L,0x76364005L,0x4B76AC36L},{0x174B960DL,0xFBAE6C0BL,(-1L),0xFBAE6C0BL,0x174B960DL},{0x5BBA9885L,0x623B7989L,1L,0xA0135165L,0L},{(-1L),0x5ED506CEL,2L,5L,1L}},{{0L,0L,0xCA836B06L,0x623B7989L,0L},{0L,5L,0xDF7396B2L,0x3C664DA5L,0x174B960DL},{0L,0x3F5DDD1EL,0xECAB0C5FL,0x5DEB8F54L,0x4B76AC36L},{5L,1L,1L,1L,1L},{0xFF0D073AL,0L,0x76364005L,0L,0L},{7L,0L,1L,(-9L),1L},{0xECAB0C5FL,0L,0xFE436B37L,0xA0135165L,0x76364005L},{0x4BF33FD1L,0x9A2F9BC0L,1L,0L,1L}},{{(-8L),(-4L),1L,0x5DEB8F54L,0L},{0xFBAE6C0BL,7L,7L,2L,7L},{(-1L),(-1L),0L,0x48E4E0DEL,0x5DEB8F54L},{0L,(-7L),7L,0x3628CFD8L,1L},{0L,0x5DEB8F54L,0x3F5DDD1EL,0xFF0D073AL,0L},{0x3628CFD8L,(-7L),(-10L),0x4BF33FD1L,0L},{0x76364005L,(-1L),(-1L),0x623B7989L,0xFE436B37L},{0L,7L,2L,(-6L),(-6L)}},{{0x9CEB3AD1L,(-4L),0x9CEB3AD1L,0xCA836B06L,0L},{(-10L),0x9A2F9BC0L,1L,7L,5L},{1L,0L,0L,1L,(-8L)},{0L,(-1L),1L,5L,2L},{1L,0x48E4E0DEL,0x9CEB3AD1L,1L,0x5BBA9885L},{0x174B960DL,1L,2L,(-7L),1L},{0x3F5DDD1EL,(-1L),(-1L),0x3F5DDD1EL,0L},{0xA97DFE4BL,0xFBAE6C0BL,(-10L),1L,0xDF7396B2L}},{{0x48E4E0DEL,0x99FBBD77L,0x3F5DDD1EL,(-8L),1L},{1L,0x3C664DA5L,7L,1L,0xFBAE6C0BL},{(-4L),0x5BBA9885L,0L,0x3F5DDD1EL,0xECAB0C5FL},{(-1L),1L,7L,(-7L),(-9L)},{(-1L),1L,1L,1L,(-1L)},{0xDF7396B2L,7L,1L,5L,0x37D81659L},{0xA0135165L,0x3A2C9E81L,0xFE436B37L,1L,0xC1BF41EBL},{1L,0x4BF33FD1L,1L,7L,0x37D81659L}},{{0L,1L,0x4B76AC36L,0xCA836B06L,(-1L)},{0x37D81659L,0L,(-1L),(-6L),(-9L)},{1L,0xECAB0C5FL,0x623B7989L,0x623B7989L,0xECAB0C5FL},{1L,0L,(-7L),0x4BF33FD1L,0xFBAE6C0BL},{0x99FBBD77L,(-1L),0L,0xFF0D073AL,1L},{1L,1L,(-6L),0x3628CFD8L,0xDF7396B2L},{0x99FBBD77L,0xCA836B06L,0xECAB0C5FL,0x48E4E0DEL,0L},{1L,(-10L),0xA97DFE4BL,2L,1L}}};
        int32_t l_177 = 0xB8BFCC78L;
        int i, j, k;
        l_118 = (safe_mod_func_int8_t_s_s(g_64, ((safe_add_func_int32_t_s_s(((safe_unary_minus_func_uint64_t_u((((*l_119) &= l_118) & 0x0FL))) < ((!(safe_sub_func_int16_t_s_s(l_124, (g_31 <= (safe_mul_func_int16_t_s_s((((l_129 != (void*)0) == ((safe_div_func_int8_t_s_s((((safe_mod_func_int32_t_s_s(l_118, (safe_lshift_func_uint16_t_u_u(((0xF9L ^ g_55) >= g_59[2][2]), l_124)))) , l_118) > l_124), g_53)) >= 0x4F1ACCADAFA07406LL)) ^ g_53), l_124)))))) != g_64)), 0L)) , 255UL)));
        if ((safe_lshift_func_int16_t_s_u(((safe_lshift_func_int16_t_s_u(0x0A10L, (l_124 ^ (safe_lshift_func_uint8_t_u_u((~((safe_lshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u(((*l_119)++), (+l_118))), 0)) , 6UL)), (g_59[2][2] | l_118)))))) == (l_118 >= (safe_add_func_uint16_t_u_u(((l_118 , (((((l_118 , l_124) , (-9L)) > 65535UL) , 0x76D89E43L) <= g_33)) == l_118), g_31)))), l_118)))
        { /* block id: 33 */
            int32_t l_157 = 5L;
            int32_t *l_162[10] = {&g_53,(void*)0,(void*)0,&g_53,&g_53,&g_53,(void*)0,(void*)0,&g_53,&g_53};
            int32_t **l_161 = &l_162[9];
            uint32_t *l_170[6][7] = {{&g_64,(void*)0,(void*)0,&g_64,&g_64,&g_64,&g_64},{&g_64,&g_64,&g_64,&g_64,&g_64,&g_64,&g_64},{&g_64,(void*)0,(void*)0,&g_64,&g_64,(void*)0,(void*)0},{&g_64,&g_64,&g_64,&g_64,&g_64,&g_64,&g_64},{&g_64,(void*)0,&g_64,&g_64,(void*)0,&g_64,&g_64},{(void*)0,&g_64,(void*)0,&g_64,(void*)0,(void*)0,&g_64}};
            int32_t *l_171 = (void*)0;
            int32_t *l_172 = &g_173;
            int i, j;
            for (g_64 = 28; (g_64 >= 45); g_64 = safe_add_func_int32_t_s_s(g_64, 3))
            { /* block id: 36 */
                uint32_t *l_156 = &g_59[2][0];
                l_157 = (safe_mod_func_int64_t_s_s(((-4L) > ((*l_156) = l_124)), g_53));
            }
            (*l_172) ^= ((safe_unary_minus_func_uint32_t_u((((0xB2L > l_157) >= (safe_lshift_func_int8_t_s_s((((*l_161) = &l_118) != &g_55), ((l_163 && (g_53 && 1UL)) < (safe_rshift_func_uint16_t_u_u((((g_64 |= (safe_add_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(l_157, l_163)), g_55))) , l_170[5][2]) != (void*)0), g_101)))))) , l_118))) == l_118);
        }
        else
        { /* block id: 43 */
            int32_t *l_175[7] = {&l_118,&l_118,&l_118,&l_118,&l_118,&l_118,&l_118};
            int i;
            g_178++;
            return g_181[1];
        }
    }
    return g_181[1];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_59[i][j], "g_59[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_265, "g_265", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_271[i].f0.f0, "g_271[i].f0.f0", print_hash_value);
        transparent_crc(g_271[i].f1, "g_271[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_285, "g_285", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_286[i], "g_286[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_287, "g_287", print_hash_value);
    transparent_crc(g_288, "g_288", print_hash_value);
    transparent_crc(g_289, "g_289", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_290[i][j], "g_290[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_291[i][j], "g_291[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_292, "g_292", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_293[i], "g_293[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_294[i][j][k], "g_294[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_295, "g_295", print_hash_value);
    transparent_crc(g_296, "g_296", print_hash_value);
    transparent_crc(g_297, "g_297", print_hash_value);
    transparent_crc(g_298, "g_298", print_hash_value);
    transparent_crc(g_299, "g_299", print_hash_value);
    transparent_crc(g_300, "g_300", print_hash_value);
    transparent_crc(g_301, "g_301", print_hash_value);
    transparent_crc(g_302, "g_302", print_hash_value);
    transparent_crc(g_303, "g_303", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_304[i], "g_304[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_305, "g_305", print_hash_value);
    transparent_crc(g_306, "g_306", print_hash_value);
    transparent_crc(g_307, "g_307", print_hash_value);
    transparent_crc(g_308, "g_308", print_hash_value);
    transparent_crc(g_309, "g_309", print_hash_value);
    transparent_crc(g_310, "g_310", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    transparent_crc(g_312, "g_312", print_hash_value);
    transparent_crc(g_313, "g_313", print_hash_value);
    transparent_crc(g_314, "g_314", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_315[i], "g_315[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_316[i], "g_316[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_317, "g_317", print_hash_value);
    transparent_crc(g_318, "g_318", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_319[i][j][k], "g_319[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_320[i], "g_320[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_321, "g_321", print_hash_value);
    transparent_crc(g_322, "g_322", print_hash_value);
    transparent_crc(g_323, "g_323", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_324[i], "g_324[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_325, "g_325", print_hash_value);
    transparent_crc(g_326, "g_326", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_327[i][j][k], "g_327[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_328, "g_328", print_hash_value);
    transparent_crc(g_329, "g_329", print_hash_value);
    transparent_crc(g_330, "g_330", print_hash_value);
    transparent_crc(g_331, "g_331", print_hash_value);
    transparent_crc(g_332, "g_332", print_hash_value);
    transparent_crc(g_333, "g_333", print_hash_value);
    transparent_crc(g_334, "g_334", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_335[i], "g_335[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_336, "g_336", print_hash_value);
    transparent_crc(g_337, "g_337", print_hash_value);
    transparent_crc(g_338, "g_338", print_hash_value);
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_340, "g_340", print_hash_value);
    transparent_crc(g_341, "g_341", print_hash_value);
    transparent_crc(g_343, "g_343", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_351[i].f0, "g_351[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_380, "g_380", print_hash_value);
    transparent_crc(g_389, "g_389", print_hash_value);
    transparent_crc(g_478, "g_478", print_hash_value);
    transparent_crc(g_515, "g_515", print_hash_value);
    transparent_crc(g_656, "g_656", print_hash_value);
    transparent_crc(g_732, "g_732", print_hash_value);
    transparent_crc(g_785, "g_785", print_hash_value);
    transparent_crc(g_837, "g_837", print_hash_value);
    transparent_crc(g_853, "g_853", print_hash_value);
    transparent_crc(g_919.f0, "g_919.f0", print_hash_value);
    transparent_crc(g_947, "g_947", print_hash_value);
    transparent_crc(g_1001.f0, "g_1001.f0", print_hash_value);
    transparent_crc(g_1004.f0, "g_1004.f0", print_hash_value);
    transparent_crc(g_1005.f0, "g_1005.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_1178[i][j], "g_1178[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1323, "g_1323", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1485[i][j][k], "g_1485[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1595, "g_1595", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1606[i][j], "g_1606[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1643, "g_1643", print_hash_value);
    transparent_crc(g_1650, "g_1650", print_hash_value);
    transparent_crc(g_1689, "g_1689", print_hash_value);
    transparent_crc(g_1725, "g_1725", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1846[i][j][k], "g_1846[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1973.f0.f0, "g_1973.f0.f0", print_hash_value);
    transparent_crc(g_1973.f1, "g_1973.f1", print_hash_value);
    transparent_crc(g_2066, "g_2066", print_hash_value);
    transparent_crc(g_2138, "g_2138", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2204[i][j], "g_2204[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2205, "g_2205", print_hash_value);
    transparent_crc(g_2206, "g_2206", print_hash_value);
    transparent_crc(g_2207, "g_2207", print_hash_value);
    transparent_crc(g_2208, "g_2208", print_hash_value);
    transparent_crc(g_2209, "g_2209", print_hash_value);
    transparent_crc(g_2210, "g_2210", print_hash_value);
    transparent_crc(g_2211, "g_2211", print_hash_value);
    transparent_crc(g_2212, "g_2212", print_hash_value);
    transparent_crc(g_2323.f0, "g_2323.f0", print_hash_value);
    transparent_crc(g_2364, "g_2364", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2366[i], "g_2366[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_2369[i][j][k], "g_2369[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2400, "g_2400", print_hash_value);
    transparent_crc(g_2531, "g_2531", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2689[i], "g_2689[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2693, "g_2693", print_hash_value);
    transparent_crc(g_2792, "g_2792", print_hash_value);
    transparent_crc(g_2926.f0, "g_2926.f0", print_hash_value);
    transparent_crc(g_3019, "g_3019", print_hash_value);
    transparent_crc(g_3039, "g_3039", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3102[i], "g_3102[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3113.f0.f0, "g_3113.f0.f0", print_hash_value);
    transparent_crc(g_3113.f1, "g_3113.f1", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 779
   depth: 1, occurrence: 18
   depth: 2, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 74
breakdown:
   indirect level: 0, occurrence: 38
   indirect level: 1, occurrence: 10
   indirect level: 2, occurrence: 11
   indirect level: 3, occurrence: 8
   indirect level: 4, occurrence: 7
XXX full-bitfields structs in the program: 18
breakdown:
   indirect level: 0, occurrence: 18
XXX times a bitfields struct's address is taken: 38
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 73
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 202

XXX max expression depth: 46
breakdown:
   depth: 1, occurrence: 408
   depth: 2, occurrence: 108
   depth: 3, occurrence: 9
   depth: 4, occurrence: 1
   depth: 6, occurrence: 3
   depth: 7, occurrence: 4
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 12, occurrence: 4
   depth: 13, occurrence: 3
   depth: 14, occurrence: 4
   depth: 15, occurrence: 1
   depth: 16, occurrence: 8
   depth: 17, occurrence: 7
   depth: 18, occurrence: 7
   depth: 19, occurrence: 6
   depth: 20, occurrence: 2
   depth: 21, occurrence: 11
   depth: 22, occurrence: 6
   depth: 23, occurrence: 6
   depth: 24, occurrence: 4
   depth: 25, occurrence: 6
   depth: 26, occurrence: 1
   depth: 27, occurrence: 5
   depth: 28, occurrence: 2
   depth: 29, occurrence: 3
   depth: 30, occurrence: 1
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 43, occurrence: 2
   depth: 46, occurrence: 1

XXX total number of pointers: 682

XXX times a variable address is taken: 1940
XXX times a pointer is dereferenced on RHS: 435
breakdown:
   depth: 1, occurrence: 376
   depth: 2, occurrence: 50
   depth: 3, occurrence: 5
   depth: 4, occurrence: 4
XXX times a pointer is dereferenced on LHS: 466
breakdown:
   depth: 1, occurrence: 430
   depth: 2, occurrence: 31
   depth: 3, occurrence: 5
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 26
XXX times a pointer is compared with another pointer: 16
XXX times a pointer is qualified to be dereferenced: 9007

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2412
   level: 2, occurrence: 290
   level: 3, occurrence: 246
   level: 4, occurrence: 65
XXX number of pointers point to pointers: 270
XXX number of pointers point to scalars: 392
XXX number of pointers point to structs: 20
XXX percent of pointers has null in alias set: 32.4
XXX average alias set size: 1.61

XXX times a non-volatile is read: 2634
XXX times a non-volatile is write: 1340
XXX times a volatile is read: 11
XXX    times read thru a pointer: 8
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 114
XXX percentage of non-volatile access: 99.6

XXX forward jumps: 5
XXX backward jumps: 12

XXX stmts: 424
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 37
   depth: 1, occurrence: 31
   depth: 2, occurrence: 56
   depth: 3, occurrence: 76
   depth: 4, occurrence: 102
   depth: 5, occurrence: 122

XXX percentage a fresh-made variable is used: 17.8
XXX percentage an existing variable is used: 82.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

