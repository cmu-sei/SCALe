/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2630711299
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 3L;
static uint32_t g_61 = 0xF0BB9A67L;
static int64_t g_65 = 0L;
static int64_t g_74 = (-9L);
static uint64_t g_76 = 0x278A4911CCFE983DLL;
static int32_t g_83 = 0xC6BF2A6BL;
static int16_t g_101 = 0x1095L;
static int64_t g_104 = (-1L);
static int32_t *g_110 = &g_83;
static int16_t *g_128 = &g_101;
static uint32_t *g_141[3][8] = {{&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61,&g_61}};
static uint32_t *g_142[10][4] = {{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61},{&g_61,(void*)0,(void*)0,&g_61}};
static int8_t g_148 = (-1L);
static int32_t g_156[1] = {(-1L)};
static int32_t * volatile g_155 = &g_156[0];/* VOLATILE GLOBAL g_155 */
static int64_t **g_170 = (void*)0;
static int32_t * volatile g_176[5][5][5] = {{{(void*)0,&g_156[0],(void*)0,&g_156[0],&g_156[0]},{(void*)0,&g_156[0],&g_156[0],&g_156[0],(void*)0},{(void*)0,&g_156[0],&g_156[0],&g_156[0],(void*)0},{&g_156[0],&g_83,&g_156[0],&g_156[0],&g_83},{&g_156[0],&g_83,&g_156[0],&g_156[0],(void*)0}},{{(void*)0,&g_156[0],(void*)0,&g_83,(void*)0},{(void*)0,&g_83,&g_156[0],&g_83,&g_156[0]},{(void*)0,(void*)0,&g_2,&g_83,(void*)0},{(void*)0,&g_83,(void*)0,&g_156[0],&g_83},{&g_156[0],&g_156[0],(void*)0,&g_83,&g_156[0]}},{{&g_156[0],&g_83,&g_156[0],(void*)0,&g_83},{(void*)0,(void*)0,&g_83,&g_156[0],&g_83},{(void*)0,&g_83,&g_83,(void*)0,&g_83},{(void*)0,&g_156[0],&g_156[0],(void*)0,&g_156[0]},{(void*)0,&g_83,(void*)0,&g_83,&g_156[0]}},{{&g_156[0],&g_83,(void*)0,(void*)0,&g_156[0]},{&g_83,&g_156[0],&g_2,(void*)0,&g_156[0]},{(void*)0,&g_156[0],&g_156[0],&g_156[0],&g_156[0]},{&g_83,&g_156[0],(void*)0,(void*)0,&g_156[0]},{&g_83,(void*)0,&g_156[0],&g_83,&g_156[0]}},{{(void*)0,&g_83,&g_156[0],&g_156[0],&g_156[0]},{&g_83,&g_83,&g_156[0],&g_83,&g_83},{&g_83,(void*)0,&g_156[0],&g_83,&g_83},{(void*)0,(void*)0,(void*)0,&g_83,&g_83},{&g_83,&g_83,&g_83,&g_156[0],&g_156[0]}}};
static int32_t g_244 = 9L;
static uint8_t g_246[10] = {0UL,0x17L,0x09L,0x09L,0x17L,0UL,0x17L,0x09L,0x09L,0x17L};
static uint32_t **g_272 = &g_142[7][0];
static int8_t g_339 = 0xC2L;
static int64_t g_478 = 1L;
static uint8_t g_480 = 0x17L;
static uint8_t g_482[10][6] = {{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,0x26L,0x26L,0x55L,0x26L,0x26L},{0x55L,250UL,250UL,0x26L,250UL,250UL},{0x26L,250UL,250UL,0x26L,250UL,250UL},{0x26L,250UL,250UL,0x26L,250UL,250UL},{0x26L,250UL,250UL,0x26L,250UL,250UL}};
static uint64_t * volatile *g_496 = (void*)0;
static uint64_t *g_498[4][2] = {{&g_76,&g_76},{&g_76,&g_76},{&g_76,&g_76},{&g_76,&g_76}};
static uint64_t **g_497 = &g_498[3][0];
static int64_t g_514 = (-1L);
static int8_t * const g_521 = &g_148;
static int8_t * const *g_520[6][5][8] = {{{&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{(void*)0,&g_521,&g_521,&g_521,(void*)0,&g_521,(void*)0,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521,&g_521}},{{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,(void*)0,&g_521,&g_521,&g_521,(void*)0,(void*)0},{(void*)0,&g_521,(void*)0,&g_521,(void*)0,&g_521,&g_521,&g_521}},{{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,(void*)0,(void*)0},{&g_521,&g_521,&g_521,(void*)0,(void*)0,(void*)0,&g_521,&g_521}},{{(void*)0,&g_521,&g_521,(void*)0,&g_521,(void*)0,&g_521,(void*)0},{&g_521,(void*)0,(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,(void*)0,&g_521,&g_521,&g_521,&g_521,(void*)0,&g_521}},{{(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0,(void*)0},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,(void*)0,(void*)0,&g_521,&g_521},{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521}},{{&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,(void*)0},{(void*)0,&g_521,&g_521,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_521,&g_521,(void*)0,&g_521,(void*)0,&g_521,&g_521},{&g_521,&g_521,(void*)0,&g_521,&g_521,&g_521,(void*)0,&g_521},{(void*)0,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521,&g_521}}};
static int8_t g_525 = 0x24L;
static volatile int64_t g_547 = 0xFB3FA6A45C7D8679LL;/* VOLATILE GLOBAL g_547 */
static int32_t g_559 = 1L;
static uint16_t g_562 = 1UL;
static uint16_t g_578[8] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static uint32_t g_597 = 4294967295UL;
static int32_t ** volatile g_602[9][4] = {{(void*)0,&g_110,&g_110,&g_110},{(void*)0,&g_110,&g_110,(void*)0},{(void*)0,&g_110,&g_110,&g_110},{(void*)0,(void*)0,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,(void*)0,(void*)0,&g_110},{&g_110,&g_110,(void*)0,(void*)0},{&g_110,&g_110,(void*)0,&g_110},{&g_110,&g_110,(void*)0,&g_110}};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_5(uint32_t  p_6, int64_t  p_7);
static uint8_t  func_12(const int32_t  p_13, uint32_t  p_14, uint64_t  p_15, int32_t  p_16);
static uint32_t  func_17(uint32_t  p_18, uint8_t  p_19);
static uint8_t  func_25(uint64_t  p_26);
static int8_t  func_29(int16_t  p_30, int32_t  p_31);
static int64_t  func_32(uint32_t  p_33, uint8_t  p_34, int32_t  p_35, uint32_t  p_36, int64_t  p_37);
static uint8_t  func_42(int32_t  p_43, uint32_t  p_44, const int8_t  p_45);
static int32_t  func_46(uint16_t  p_47, uint64_t  p_48, int32_t  p_49, int16_t  p_50, uint8_t  p_51);
static const uint32_t  func_54(const int32_t  p_55, int16_t  p_56, uint64_t  p_57, int64_t  p_58, uint32_t  p_59);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_110 g_83 g_562 g_128 g_101 g_521 g_155 g_156 g_61 g_478 g_497 g_498 g_74 g_480 g_104 g_559 g_244 g_76 g_65 g_482 g_246 g_272 g_142 g_148 g_514
 * writes: g_2 g_562 g_148 g_482 g_578 g_83 g_61 g_597 g_101 g_156 g_480 g_141 g_142 g_244 g_74
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_8 = 0xE1E2L;
    int32_t l_587[4][7][8] = {{{0xF0DDD862L,(-1L),0x45EAB1A0L,0L,(-1L),0L,0x45EAB1A0L,(-1L)},{0x46BA9375L,1L,0xF0DDD862L,0xAF3774E8L,0L,0x7866A6B6L,0xAF3774E8L,1L},{0x851FF90CL,(-1L),5L,0xD14A1A83L,0x46BA9375L,2L,0xAF3774E8L,0x73C9113AL},{1L,0xD14A1A83L,0xF0DDD862L,0x7866A6B6L,(-1L),0x45EAB1A0L,0x45EAB1A0L,(-1L)},{(-1L),0x45EAB1A0L,0x45EAB1A0L,(-1L),0x7866A6B6L,0xF0DDD862L,0xD14A1A83L,1L},{0x73C9113AL,0xAF3774E8L,2L,0x46BA9375L,0xD14A1A83L,5L,(-1L),0x851FF90CL},{1L,0xAF3774E8L,0x7866A6B6L,0L,0xAF3774E8L,0xF0DDD862L,1L,0x46BA9375L}},{{(-1L),0x45EAB1A0L,0L,(-1L),0L,0x45EAB1A0L,(-1L),0xF0DDD862L},{0xAF3774E8L,0xD14A1A83L,0x851FF90CL,6L,1L,0x851FF90CL,0x45EAB1A0L,5L},{0x8978A556L,0xF0DDD862L,2L,0x84FA8638L,1L,0xAC86F5D4L,2L,0xF0DDD862L},{0x7866A6B6L,2L,0L,5L,0x84FA8638L,0x84FA8638L,5L,0L},{6L,6L,(-1L),0x45EAB1A0L,0x7866A6B6L,0x851FF90CL,0L,1L},{0L,0x45EAB1A0L,1L,0xAC86F5D4L,1L,2L,2L,1L},{0x45EAB1A0L,2L,5L,0x45EAB1A0L,0xAC86F5D4L,0L,0xF4E146C2L,0L}},{{0xF4E146C2L,5L,0x851FF90CL,5L,0xF4E146C2L,(-1L),1L,0xF0DDD862L},{0L,0L,(-4L),0x84FA8638L,0L,1L,2L,5L},{1L,2L,(-4L),6L,0x84FA8638L,5L,1L,0x8978A556L},{0L,0xF4E146C2L,0x851FF90CL,0xF0DDD862L,0xF0DDD862L,0x851FF90CL,0xF4E146C2L,0L},{0x8978A556L,1L,5L,0x84FA8638L,6L,(-4L),2L,1L},{5L,2L,1L,0L,0x84FA8638L,(-4L),0L,0L},{0xF0DDD862L,1L,(-1L),0xF4E146C2L,5L,0x851FF90CL,5L,0xF4E146C2L}},{{0L,0xF4E146C2L,0L,0xAC86F5D4L,0x45EAB1A0L,5L,2L,0x45EAB1A0L},{1L,2L,2L,1L,0xAC86F5D4L,1L,0x45EAB1A0L,0L},{1L,0L,0x851FF90CL,0x7866A6B6L,0x45EAB1A0L,(-1L),6L,6L},{0L,5L,0x84FA8638L,0x84FA8638L,5L,0L,2L,0x7866A6B6L},{0xF0DDD862L,2L,0xAC86F5D4L,1L,0x84FA8638L,2L,0xF0DDD862L,0x8978A556L},{5L,0x45EAB1A0L,0x851FF90CL,1L,6L,0x851FF90CL,1L,0x7866A6B6L},{0x8978A556L,6L,2L,0x84FA8638L,0xF0DDD862L,0x84FA8638L,2L,6L}}};
    int32_t *l_603[8][2];
    uint16_t l_605 = 0x888BL;
    uint32_t **l_639 = &g_142[1][0];
    int i, j, k;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 2; j++)
            l_603[i][j] = &g_244;
    }
    for (g_2 = 0; (g_2 != 25); g_2 = safe_add_func_uint64_t_u_u(g_2, 4))
    { /* block id: 3 */
        int16_t l_9 = 1L;
        uint32_t l_600 = 0xE5581B71L;
        int32_t l_604 = 0x74ACD6D1L;
        int32_t l_651 = 1L;
        int32_t l_652 = 0xC0F2F5F2L;
        if (func_5(l_8, l_9))
        { /* block id: 229 */
            uint32_t *l_588 = &g_61;
            int32_t l_595 = 0x9D5DE039L;
            uint32_t *l_596 = &g_597;
            (*g_110) = ((safe_mod_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((safe_add_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((((((*l_588) = (l_587[0][3][0] ^= ((void*)0 == (*g_497)))) > ((safe_rshift_func_int16_t_s_u(((*g_128) = (safe_mod_func_uint64_t_u_u(l_8, (safe_div_func_uint32_t_u_u(((*l_596) = l_595), l_595))))), 4)) || (0x15CEL != ((l_9 , (g_2 > ((0xCF32L == (*g_128)) == l_9))) && g_74)))) , l_9) != (-3L)), l_600)), l_595)), l_600)), l_595)) || l_595);
        }
        else
        { /* block id: 235 */
            int32_t *l_601 = &g_156[0];
            uint64_t l_626 = 0UL;
            uint8_t l_653 = 0xFFL;
            (*l_601) &= (*g_110);
            l_603[1][0] = &g_83;
            for (g_480 = 0; (g_480 <= 2); g_480 += 1)
            { /* block id: 240 */
                uint16_t l_615 = 65535UL;
                const int32_t *l_625 = &g_559;
                const int32_t **l_624 = &l_625;
                int32_t l_627 = 0xBE6D2370L;
                int8_t * const l_647 = (void*)0;
                uint32_t *l_649 = &g_597;
                for (g_562 = 0; (g_562 <= 5); g_562 += 1)
                { /* block id: 243 */
                    int32_t **l_623 = &g_110;
                    int32_t ***l_622 = &l_623;
                    uint32_t *l_648 = (void*)0;
                    int i, j;
                    l_605++;
                    l_627 = ((*l_601) | (safe_add_func_int16_t_s_s((((safe_add_func_uint64_t_u_u((safe_unary_minus_func_int8_t_s((g_104 ^ ((l_615 ^= (safe_rshift_func_int8_t_s_s(((void*)0 != &g_498[0][0]), 6))) | (((*g_128) = (-10L)) == (((safe_mod_func_uint64_t_u_u((((((-1L) > (8UL && (g_559 == (((*l_622) = &l_603[1][0]) == l_624)))) <= (*l_625)) != g_2) || (**l_623)), (**g_497))) , l_626) , 0xBC5BL)))))), 0x1A51269A96BF836ALL)) , l_9) == g_65), 0L)));
                    for (l_9 = 1; (l_9 <= 5); l_9 += 1)
                    { /* block id: 251 */
                        int32_t l_628 = 0xB88C7717L;
                        uint32_t **l_638 = &g_141[0][0];
                        uint16_t *l_646 = &l_8;
                        uint16_t *l_650 = &l_615;
                        int i, j, k;
                        (*l_601) = ((l_628 , ((safe_sub_func_int32_t_s_s(((***l_622) &= (((safe_mul_func_uint8_t_u_u(((safe_add_func_int8_t_s_s((-1L), (++g_482[(l_9 + 1)][(g_480 + 1)]))) ^ (~((l_638 == l_639) || ((safe_add_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((*l_650) = ((((*g_128) ^= ((safe_div_func_uint16_t_u_u(((*l_646) = g_246[3]), ((l_604 ^ ((((*l_639) = (g_141[g_480][(g_480 + 2)] = (*g_272))) == (l_649 = (((void*)0 != l_647) , l_648))) && 0x64L)) | (*g_521)))) == l_628)) , &g_272) == (void*)0)), g_514)), (-1L))) == g_156[0])))), 0x02L)) != g_559) , (*g_155))), (*l_601))) , (void*)0)) != &g_272);
                    }
                }
                for (g_148 = 0; (g_148 <= 0); g_148 += 1)
                { /* block id: 265 */
                    int i;
                    if (g_156[g_148])
                        break;
                }
                for (g_74 = 0; (g_74 <= 0); g_74 += 1)
                { /* block id: 270 */
                    int i;
                    if (g_156[g_74])
                        break;
                    if ((*g_155))
                        break;
                }
            }
            ++l_653;
        }
        return l_9;
    }
    return (*g_521);
}


/* ------------------------------------------ */
/* 
 * reads : g_110 g_83 g_562 g_128 g_101 g_521 g_155 g_156 g_61 g_478
 * writes: g_562 g_148 g_482 g_578 g_83
 */
static int32_t  func_5(uint32_t  p_6, int64_t  p_7)
{ /* block id: 4 */
    int64_t *l_73 = &g_74;
    const int32_t l_75 = 0x902820A3L;
    int32_t l_548[7] = {0x75E46869L,(-5L),(-5L),0x75E46869L,(-5L),(-5L),0x75E46869L};
    int16_t l_560 = 0x0AD6L;
    uint16_t *l_561 = &g_562;
    uint8_t *l_575 = &g_482[0][1];
    int64_t l_576 = 0x1F16EC1A34BA687ALL;
    uint16_t *l_577 = &g_578[6];
    int i;
    for (p_6 = 0; (p_6 != 9); ++p_6)
    { /* block id: 7 */
        uint32_t l_20[3];
        uint32_t *l_60 = &g_61;
        int64_t *l_64[10];
        int32_t l_66[10][1] = {{0x01E07AD4L},{0xDAAFD55BL},{0x01E07AD4L},{0xDAAFD55BL},{0x01E07AD4L},{0xDAAFD55BL},{0x01E07AD4L},{0xDAAFD55BL},{0x01E07AD4L},{0xDAAFD55BL}};
        int32_t l_79 = (-1L);
        uint64_t l_107 = 0x4DAAE8D137083F7ALL;
        const uint32_t l_157 = 1UL;
        int32_t *l_161[7];
        int8_t * const l_524 = &g_525;
        int8_t * const *l_523[3];
        int32_t l_530[3];
        int i, j;
        for (i = 0; i < 3; i++)
            l_20[i] = 4294967291UL;
        for (i = 0; i < 10; i++)
            l_64[i] = &g_65;
        for (i = 0; i < 7; i++)
            l_161[i] = &l_66[8][0];
        for (i = 0; i < 3; i++)
            l_523[i] = &l_524;
        for (i = 0; i < 3; i++)
            l_530[i] = 0xB23DEB18L;
    }
    (*g_110) = (safe_mod_func_int32_t_s_s(((((safe_mul_func_uint8_t_u_u((0x94980476L == (*g_110)), ((safe_mod_func_uint32_t_u_u((l_75 == ((((safe_sub_func_uint16_t_u_u(((*l_577) = (((++(*l_561)) && (safe_sub_func_int16_t_s_s((*g_128), (safe_div_func_int16_t_s_s((((p_7 ^ ((p_7 <= (safe_div_func_uint64_t_u_u((((((*g_521) = l_75) > ((*l_575) = ((safe_mod_func_int32_t_s_s((*g_155), p_7)) <= l_560))) && l_75) > (-1L)), p_7))) || p_7)) , l_576) && (*g_110)), p_7))))) ^ (*g_128))), g_61)) < l_548[0]) >= l_560) > 0x1850L)), (-8L))) || g_478))) , l_548[3]) != p_6) >= l_560), (*g_110)));
    return (*g_155);
}


/* ------------------------------------------ */
/* 
 * reads : g_83 g_101 g_156 g_61 g_65 g_76 g_104 g_74 g_128 g_2 g_272 g_141 g_246 g_148 g_142 g_244 g_110 g_155 g_339 g_478 g_480 g_496 g_497 g_482
 * writes: g_83 g_148 g_74 g_76 g_65 g_156 g_244 g_246 g_272 g_110 g_61 g_339 g_101 g_480 g_482 g_514
 */
static uint8_t  func_12(const int32_t  p_13, uint32_t  p_14, uint64_t  p_15, int32_t  p_16)
{ /* block id: 65 */
    int32_t ** const l_189 = &g_110;
    uint16_t l_242 = 0xB04EL;
    int32_t l_251 = 1L;
    int32_t l_252[1];
    uint16_t l_262 = 0UL;
    int16_t l_307[6] = {0xAEA3L,0xAEA3L,0xAEA3L,0xAEA3L,0xAEA3L,0xAEA3L};
    const uint32_t *l_359[5];
    int8_t *l_467 = (void*)0;
    uint64_t **l_513 = &g_498[3][0];
    int i;
    for (i = 0; i < 1; i++)
        l_252[i] = 0x395282E9L;
    for (i = 0; i < 5; i++)
        l_359[i] = &g_61;
    for (g_83 = (-6); (g_83 > 19); ++g_83)
    { /* block id: 68 */
        int64_t l_182 = (-1L);
        int8_t *l_194 = &g_148;
        int64_t *l_205 = &g_74;
        uint64_t *l_206 = &g_76;
        int32_t l_226 = (-2L);
        uint16_t l_239 = 2UL;
        int32_t l_240 = 0x75B8AA76L;
        int32_t l_253 = (-1L);
        int32_t l_254 = (-1L);
        int32_t l_255 = 0xE910D818L;
        int32_t l_256 = 1L;
        int32_t l_257 = 0xA476E1ABL;
        int32_t l_258 = (-9L);
        int32_t l_259 = 0x655E74B0L;
        int32_t l_260 = (-1L);
        int32_t l_261 = 0xF733664AL;
        uint32_t *l_267 = (void*)0;
        int64_t l_334 = 1L;
        uint64_t **l_500 = (void*)0;
        uint8_t *l_508 = &g_482[0][1];
        p_16 |= (((((safe_lshift_func_uint16_t_u_s(((~(l_182 == (safe_div_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(0x00E805A5L, (safe_sub_func_int32_t_s_s(((void*)0 == l_189), l_182)))) , (safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(((*l_194) = g_101), 2)), g_156[0]))), (safe_sub_func_int8_t_s_s(g_61, (safe_mul_func_uint8_t_u_u(0x11L, 0x8CL)))))))) , 5UL), 1)) , g_65) , g_76) && 0xBEL) == 65529UL);
        if ((((*l_206) = (l_182 | ((((+l_182) < g_65) ^ (((p_16 <= (safe_rshift_func_int8_t_s_u(((((void*)0 != &l_182) || (~p_15)) == p_13), (safe_mul_func_uint8_t_u_u(((((*l_205) = p_13) , p_16) < 0xEE2591527C6EF001LL), p_16))))) == 0xC9453CEAL) | g_156[0])) | 0x9FL))) < g_104))
        { /* block id: 73 */
            int64_t *l_209 = &g_65;
            int32_t *l_241 = &g_156[0];
            uint16_t l_243 = 0UL;
            uint8_t *l_245 = &g_246[3];
            int32_t *l_247 = &g_244;
            int32_t *l_248 = &l_226;
            int32_t *l_249 = &l_226;
            int32_t *l_250[5];
            uint32_t l_340 = 4294967287UL;
            int8_t *l_360 = &g_339;
            int i;
            for (i = 0; i < 5; i++)
                l_250[i] = &g_156[0];
            p_16 &= (safe_mul_func_int8_t_s_s((((*l_209) |= ((*l_205) |= 0L)) != 0x469D7E750E090713LL), (safe_mod_func_uint8_t_u_u(((*l_245) = ((safe_rshift_func_int8_t_s_u((0x91L & (safe_add_func_int64_t_s_s(((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((g_244 = (~(+((safe_div_func_uint64_t_u_u(((safe_sub_func_int32_t_s_s(((void*)0 == &g_61), ((l_226 = (*g_128)) >= (safe_rshift_func_int16_t_s_u((((*l_241) = (safe_mod_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(((p_14 , (safe_rshift_func_int8_t_s_s(0xF3L, 3))) & ((((*l_206) = ((safe_mod_func_uint32_t_u_u(((g_156[0] , l_239) , p_15), 0x8636C559L)) > 0xB89AL)) ^ 2UL) ^ l_240)), 0xFBL)), l_182)) == p_15), (-1L)))) != 1L), l_242))))) , 0x1B9CCF313D322444LL), 0x721D8526C4551C73LL)) >= l_243)))), (*g_128))), p_14)) , 0x3F102FCD55C4C9A3LL), g_2))), g_61)) > p_13)), l_240))));
            ++l_262;
            if (l_257)
            { /* block id: 83 */
                uint32_t **l_269 = &g_142[1][0];
                uint32_t ***l_268 = &l_269;
                uint32_t **l_271 = (void*)0;
                uint32_t ***l_270[9] = {&l_271,&l_271,&l_271,&l_271,&l_271,&l_271,&l_271,&l_271,&l_271};
                int32_t l_282 = 0xDCAB98A7L;
                int8_t *l_286[3];
                uint16_t *l_297 = &l_243;
                uint32_t *l_301[4][7][4] = {{{&g_61,&g_61,&g_61,&g_61},{(void*)0,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,&g_61},{(void*)0,&g_61,&g_61,(void*)0}},{{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,(void*)0},{(void*)0,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,(void*)0}},{{&g_61,&g_61,&g_61,&g_61},{(void*)0,&g_61,&g_61,&g_61},{(void*)0,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,&g_61}},{{(void*)0,&g_61,&g_61,(void*)0},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,(void*)0},{(void*)0,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61},{&g_61,&g_61,&g_61,&g_61}}};
                int32_t l_302 = 0x2DAAB47BL;
                int64_t l_303[3][5] = {{0x8E90C7F6F1940B1ALL,0x823759EBEBF65EF6LL,0xA1CF02BA5F2539F9LL,1L,1L},{0x823759EBEBF65EF6LL,0x8E90C7F6F1940B1ALL,0x823759EBEBF65EF6LL,0xA1CF02BA5F2539F9LL,1L},{0xAEEAECE4B6B21CC5LL,(-1L),1L,(-1L),0xAEEAECE4B6B21CC5LL}};
                int32_t l_304 = 0x3D30D6FCL;
                int32_t l_305[9][6] = {{7L,0x9B69DBA9L,0L,0xE0DDB56AL,0L,0x9B69DBA9L},{0x99B6E637L,7L,0L,0x69399026L,0xF99866C2L,0xE0DDB56AL},{0x82543912L,0x69399026L,0x9B69DBA9L,0x9B69DBA9L,0x69399026L,0x82543912L},{0x9B69DBA9L,0x69399026L,0x82543912L,0x35638F95L,0xF99866C2L,0L},{0L,7L,0x99B6E637L,7L,0L,0x69399026L},{0L,0x9B69DBA9L,7L,0x35638F95L,0x8FCE3D55L,0x8FCE3D55L},{0x9B69DBA9L,0xF99866C2L,0xF99866C2L,0x9B69DBA9L,0x99B6E637L,0x8FCE3D55L},{0x82543912L,0x8FCE3D55L,7L,0x69399026L,0x35638F95L,0x69399026L},{0x99B6E637L,0xE5609E3FL,0x99B6E637L,0xE0DDB56AL,0x35638F95L,0L}};
                int64_t l_306 = (-1L);
                int32_t l_308 = 0xEBC04C05L;
                uint8_t l_309 = 1UL;
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_286[i] = &g_148;
                if (((0x2F218E09L <= ((p_15 >= (0x65F4L & p_15)) ^ (safe_mul_func_uint16_t_u_u((((8L >= (((void*)0 != l_267) <= ((g_272 = ((*l_268) = &g_141[1][7])) != (void*)0))) == 0x8BL) && (*g_128)), g_74)))) | p_16))
                { /* block id: 86 */
                    uint16_t *l_283 = &l_239;
                    int8_t **l_287 = &l_194;
                    uint32_t l_288 = 0x3F27653AL;
                    (*l_189) = (void*)0;
                    (*l_249) = (((safe_add_func_int64_t_s_s((safe_sub_func_uint8_t_u_u((((((((0xF2D6737CD069B105LL && ((void*)0 != (*g_272))) | (0x065226A7L && (safe_div_func_uint16_t_u_u(((safe_unary_minus_func_int32_t_s((p_16 ^= 0xD96ED306L))) <= l_282), (0x0DB5L ^ (--(*l_283))))))) >= (&g_148 != ((*l_287) = l_286[2]))) <= g_104) & g_246[9]) , l_288) == p_13), g_2)), 7UL)) , 1UL) < p_13);
                }
                else
                { /* block id: 92 */
                    l_260 &= (-7L);
                    return l_282;
                }
                p_16 = (((*l_205) |= (safe_lshift_func_uint16_t_u_s((safe_sub_func_int16_t_s_s(((l_270[3] = &g_272) != &g_272), (safe_div_func_uint16_t_u_u((((((*g_128) || ((safe_rshift_func_uint16_t_u_u(p_15, 3)) || (g_76 |= ((((*l_297) = (&g_83 == &g_244)) & ((safe_add_func_uint8_t_u_u((((((*l_209) = (((*l_248) = p_13) , ((((!((0x5D410CA4L | (l_309--)) , (safe_sub_func_int16_t_s_s(((*g_128) , (-1L)), (*g_128))))) < l_282) & 4294967295UL) , l_251))) >= l_239) != p_14) & (-1L)), p_13)) | 0xD07C3FB299D949EFLL)) || 0xC5L)))) >= p_13) && 0x2758L) < 0x1377L), g_61)))), 7))) | (*l_241));
            }
            else
            { /* block id: 104 */
                uint32_t *l_329 = &g_61;
                int32_t l_331 = (-1L);
                int16_t *l_335[8][1] = {{&l_307[5]},{(void*)0},{&l_307[5]},{(void*)0},{&l_307[5]},{(void*)0},{&l_307[5]},{(void*)0}};
                int32_t l_336 = 0x1AA78ADAL;
                int8_t *l_337 = (void*)0;
                int8_t *l_338 = &g_339;
                int32_t l_341 = 0xCBEBB16FL;
                int64_t l_350 = 0L;
                int i, j;
                l_254 &= ((+(((safe_mod_func_uint8_t_u_u((safe_add_func_int16_t_s_s((*g_128), (((safe_mul_func_int16_t_s_s(0x4A47L, ((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(0x52L, (safe_mod_func_int8_t_s_s(((*l_338) = (g_246[3] < ((safe_sub_func_uint32_t_u_u(((*l_329) |= 4294967295UL), p_15)) == ((g_148 = ((l_336 = (l_331 = (~(l_331 ^ (((*l_205) = ((((((0x75L < ((safe_add_func_uint16_t_u_u(l_334, p_13)) >= g_2)) | 0UL) , p_13) <= 0x9190592FF4622C58LL) | p_13) <= g_101)) ^ p_16))))) != 0x94C3L)) ^ 0x8BL)))), l_340)))), l_341)) | g_65))) , g_104) != l_341))), 249UL)) == (*g_128)) >= g_156[0])) , p_16);
                for (l_258 = (-18); (l_258 == 6); l_258 = safe_add_func_uint16_t_u_u(l_258, 9))
                { /* block id: 114 */
                    int32_t l_346[3][8][6] = {{{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)}},{{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)}},{{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)},{0L,(-8L),0L,(-8L),0L,(-8L)}}};
                    int i, j, k;
                    for (l_243 = 7; (l_243 >= 52); l_243 = safe_add_func_int16_t_s_s(l_243, 1))
                    { /* block id: 117 */
                        uint64_t l_347[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_347[i] = 0x9F8D9338E6546670LL;
                        l_347[0]--;
                        if (l_350)
                            continue;
                    }
                }
            }
            l_252[0] |= ((*l_248) = (p_14 || ((safe_rshift_func_int16_t_s_u((safe_sub_func_int64_t_s_s(((g_148 == p_16) > ((*l_248) <= ((safe_add_func_int32_t_s_s(p_14, (((*g_272) != l_359[4]) ^ (g_83 <= ((*l_360) = 9L))))) , 0x0010B538A22CC31BLL))), g_156[0])), (*l_247))) , g_65)));
        }
        else
        { /* block id: 126 */
            int32_t l_390 = 4L;
            uint16_t l_406 = 0x5F20L;
            int32_t l_427 = 6L;
            uint32_t **l_459 = &g_142[1][0];
            (*l_189) = &g_2;
            if ((**l_189))
            { /* block id: 128 */
                int32_t l_361 = (-10L);
                int32_t *l_362 = &l_259;
                (*l_362) &= l_361;
            }
            else
            { /* block id: 130 */
                int8_t l_365 = 0x0CL;
                int32_t l_366 = 0xF7E2210CL;
                uint8_t *l_376 = &g_246[3];
                int32_t *l_377 = &l_256;
                uint16_t *l_438 = &l_239;
                int16_t l_450 = (-3L);
                uint64_t *l_456 = &g_76;
                uint64_t l_458 = 0xBED14295BC118406LL;
                int8_t l_476 = 0x51L;
                uint64_t l_501 = 0xE35AFADD1F2138BALL;
                if (((*l_377) = (safe_add_func_int64_t_s_s(((l_366 &= l_365) > (((safe_mul_func_uint8_t_u_u((safe_div_func_uint8_t_u_u(p_13, (((void*)0 == l_194) || (-1L)))), 3UL)) & 0L) , ((*l_376) ^= (+(safe_mod_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u(g_101, 7)), ((&g_76 == &g_76) & p_14))))))), 0x910C8C6545C969D0LL))))
                { /* block id: 134 */
                    return p_15;
                }
                else
                { /* block id: 136 */
                    int32_t *l_378 = &l_252[0];
                    int32_t *l_379 = &l_256;
                    int32_t *l_380 = (void*)0;
                    int32_t *l_381 = &l_252[0];
                    int32_t *l_382 = (void*)0;
                    int32_t *l_383 = &l_252[0];
                    int32_t *l_384 = (void*)0;
                    int32_t *l_385 = &l_260;
                    int32_t *l_386 = &g_156[0];
                    int32_t *l_387 = (void*)0;
                    int32_t *l_388 = &g_244;
                    int32_t *l_389 = &l_252[0];
                    int32_t *l_391 = &l_261;
                    int32_t *l_392 = &g_244;
                    int32_t *l_393[8][5][6] = {{{&l_258,&g_2,&l_258,&g_83,&l_260,&l_258},{&l_240,&l_258,(void*)0,&g_2,&l_240,&l_226},{(void*)0,&g_83,&g_156[0],&g_2,&g_156[0],&g_83},{&l_240,(void*)0,&g_244,&g_83,&g_156[0],&l_240},{&l_258,&l_226,&g_156[0],&l_260,&l_260,&l_257}},{{&g_156[0],&l_226,(void*)0,&l_226,&g_156[0],&g_2},{(void*)0,(void*)0,&l_258,&l_257,&g_156[0],(void*)0},{&g_156[0],&g_83,&g_244,(void*)0,&l_240,(void*)0},{&l_258,&l_258,&l_258,&l_240,&l_260,&g_2},{&l_240,&g_2,(void*)0,&l_258,&l_240,&l_257}},{{(void*)0,&l_240,&g_156[0],&l_258,&g_156[0],&l_240},{&l_240,&l_260,&g_244,&l_240,&g_156[0],&g_83},{&l_258,&l_257,&g_156[0],(void*)0,&l_260,&l_226},{&g_156[0],&l_257,(void*)0,&l_257,&g_156[0],&l_258},{(void*)0,&l_260,&l_258,&l_226,&g_156[0],&l_260}},{{&g_156[0],&l_240,&g_244,&l_260,&l_240,&l_260},{&l_258,&g_2,&l_258,&g_83,&l_260,&l_258},{&l_240,&l_258,(void*)0,&g_2,&l_240,&l_226},{(void*)0,&g_83,&g_156[0],&g_2,&g_156[0],&g_83},{&l_240,(void*)0,&g_244,&g_83,&g_156[0],&l_240}},{{&l_258,&l_226,&g_156[0],&l_260,&l_260,&l_257},{&g_156[0],&l_226,(void*)0,&l_226,&g_156[0],&g_2},{(void*)0,(void*)0,&l_258,&l_257,&g_156[0],(void*)0},{&g_156[0],&g_83,&g_244,(void*)0,&l_240,(void*)0},{&l_258,&l_258,&l_258,&l_240,&l_260,&g_2}},{{&l_240,&g_2,(void*)0,&l_258,&l_240,&l_257},{(void*)0,&l_240,&g_156[0],&l_258,&g_156[0],&l_240},{&l_240,&l_260,&g_244,&l_240,&g_156[0],&g_83},{&l_258,&l_257,&g_156[0],(void*)0,&l_260,&l_226},{&g_156[0],&l_257,(void*)0,&l_257,&g_156[0],&l_258}},{{(void*)0,&l_260,&l_258,&l_226,&g_156[0],&l_260},{&g_156[0],&l_240,&g_244,&l_260,&l_240,&l_260},{&l_258,&g_2,&l_258,&g_83,&l_260,&l_258},{&l_240,&l_258,(void*)0,&g_2,&l_240,&l_226},{(void*)0,&g_83,&g_156[0],&g_2,&g_156[0],&g_83}},{{&l_240,(void*)0,&g_244,&g_83,&g_156[0],&l_240},{&l_258,&l_226,&g_156[0],&l_260,&l_260,&l_257},{&g_156[0],&l_226,(void*)0,&l_226,&g_156[0],&g_2},{(void*)0,(void*)0,&l_258,&l_257,&g_156[0],(void*)0},{&g_156[0],&g_83,&g_244,(void*)0,&l_240,(void*)0}}};
                    uint8_t l_394 = 255UL;
                    int16_t l_401 = 1L;
                    int i, j, k;
                    --l_394;
                    for (l_259 = 0; (l_259 <= 4); l_259 += 1)
                    { /* block id: 140 */
                        uint8_t l_400 = 0xFDL;
                        (*l_388) ^= (((*g_110) == (+0x644BL)) ^ (l_400 &= (safe_rshift_func_int16_t_s_u(0x6A28L, 5))));
                        if (l_401)
                            break;
                        if ((**l_189))
                            break;
                    }
                    p_16 |= (safe_div_func_uint8_t_u_u(g_156[0], (safe_lshift_func_uint8_t_u_s(l_406, (((safe_sub_func_uint8_t_u_u(0x4AL, (safe_sub_func_int64_t_s_s((safe_sub_func_int32_t_s_s((((l_254 || 1L) || g_246[2]) | 0xA9AAE1C5282BA2F7LL), ((*l_385) ^= ((l_406 , (safe_unary_minus_func_int16_t_s((l_259 , p_14)))) >= (*l_392))))), (**l_189))))) >= 0UL) , p_14)))));
                }
                if (((*l_377) = (safe_div_func_uint8_t_u_u(((((safe_div_func_uint64_t_u_u((((*l_205) = g_83) && (*l_377)), ((p_16 ^ 1UL) & p_16))) && (((l_427 = (~((safe_mod_func_uint32_t_u_u((((safe_add_func_uint32_t_u_u((l_240 = ((p_14 ^ (safe_mul_func_int16_t_s_s((l_258 , ((*g_128) = ((**l_189) , (safe_mod_func_int16_t_s_s(2L, 0xAB7EL))))), p_16))) > g_148)), 1UL)) >= 1UL) & (**l_189)), (*g_155))) ^ l_406))) && p_15) && 0L)) , (*g_128)) || 0UL), l_406))))
                { /* block id: 154 */
                    int32_t l_445 = 1L;
                    uint64_t **l_455[1][5];
                    uint64_t l_457[10] = {0xB33F1206192F4315LL,0xB33F1206192F4315LL,0UL,0xB33F1206192F4315LL,0xB33F1206192F4315LL,0UL,0xB33F1206192F4315LL,0xB33F1206192F4315LL,0UL,0xB33F1206192F4315LL};
                    int8_t **l_460 = (void*)0;
                    int64_t *l_477 = &l_334;
                    uint8_t *l_479 = &g_480;
                    uint8_t *l_481 = &g_482[0][1];
                    int16_t *l_483 = &l_307[5];
                    uint8_t l_489 = 255UL;
                    uint64_t ***l_499[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 5; j++)
                            l_455[i][j] = (void*)0;
                    }
                    for (l_256 = 0; (l_256 > (-16)); l_256--)
                    { /* block id: 157 */
                        int8_t *l_443 = &l_365;
                        int32_t l_444 = (-6L);
                        (*l_189) = &g_244;
                        (**l_189) = (safe_mod_func_int64_t_s_s(((safe_div_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(((g_339 ^= (((*l_205) = ((0x6B8EA459L || (((((safe_sub_func_uint32_t_u_u((((&l_406 == (p_15 , l_438)) , (safe_rshift_func_uint16_t_u_u(((*g_128) ^ g_156[0]), (safe_rshift_func_int16_t_s_s(0xBA8BL, (*l_377)))))) , ((void*)0 == l_443)), (*l_377))) || (*g_128)) ^ l_444) || p_16) & 0xB9D1L)) , g_246[3])) == g_148)) || l_406), l_445)), g_61)) , p_13), 1UL));
                    }
                    (*l_377) ^= ((((18446744073709551607UL > (((*l_438) &= (0x1259B346L <= ((((((safe_mod_func_int64_t_s_s(((safe_rshift_func_uint8_t_u_s(((*l_376) ^= (g_148 | ((((l_450 , (safe_add_func_int64_t_s_s((l_255 = p_16), (((l_427 & (**l_189)) <= ((safe_sub_func_int64_t_s_s(p_15, ((l_456 = (g_83 , &g_76)) == (void*)0))) && l_445)) <= l_457[2])))) , p_13) , l_458) & p_16))), 7)) & p_16), l_390)) ^ (**l_189)) | (*g_128)) , 0x2380D268F8804C86LL) , l_459) == &l_267))) < p_15)) > p_13) , &l_194) == l_460);
                    (*l_377) ^= ((l_457[6] > (safe_lshift_func_uint16_t_u_s(((l_427 = ((*l_376)--)) ^ ((((safe_lshift_func_int8_t_s_u(((l_467 == &g_148) > (((*l_483) = (((((p_16 = ((((*l_481) = ((*l_479) = (safe_sub_func_int16_t_s_s((((p_13 != g_104) , (safe_mul_func_uint16_t_u_u(((((*l_477) &= (((((-4L) && (safe_add_func_int16_t_s_s(((*g_128) ^= ((g_74 == (l_406 || 0UL)) , l_476)), p_15))) ^ 65535UL) <= 4294967287UL) >= 65526UL)) && (-8L)) && l_445), p_14))) || l_334), g_478)))) , 0UL) <= 0L)) | 0x7B9FA781L) | p_13) | (**l_189)) , 0xCF51L)) != 1UL)), 6)) > (-5L)) == l_445) > p_15)), 11))) , (*g_110));
                    p_16 = (safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u(((((safe_sub_func_uint8_t_u_u((((l_489 | p_14) , ((safe_mod_func_int8_t_s_s(((((++(*l_479)) < ((0xB740L | (p_16 ^ ((*l_481) = ((g_496 != (l_500 = g_497)) , (255UL <= ((-4L) < 0x41F2L)))))) <= (**l_189))) ^ (-4L)) , (-5L)), l_255)) , g_2)) , p_14), g_2)) || (*l_377)) && (*l_377)) , g_478))), 0xF129L));
                }
                else
                { /* block id: 181 */
                    l_501--;
                    (*l_189) = &p_16;
                }
                if (l_259)
                    continue;
                if (l_406)
                    continue;
            }
        }
        g_514 = ((safe_rshift_func_int8_t_s_u((0x09C1852AL | ((safe_lshift_func_int16_t_s_u(((((l_259 , &l_239) != (void*)0) == ((*l_508)++)) == (safe_sub_func_uint16_t_u_u((4L | (l_260 |= ((l_513 == (void*)0) && ((g_339 && 0xFEF4L) > (*g_128))))), (-10L)))), 3)) > 0x38E9C91CL)), 4)) || 0x3F3AL);
    }
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_170 g_61 g_76 g_155
 * writes: g_156
 */
static uint32_t  func_17(uint32_t  p_18, uint8_t  p_19)
{ /* block id: 60 */
    int64_t *l_168[1];
    int64_t **l_169 = &l_168[0];
    int64_t **l_171 = (void*)0;
    int32_t l_174 = 0xDD9F3165L;
    int8_t l_175 = 8L;
    int i;
    for (i = 0; i < 1; i++)
        l_168[i] = &g_74;
    (*g_155) = (safe_add_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((18446744073709551615UL ^ ((((l_174 = ((safe_div_func_uint32_t_u_u((p_18 > ((((*l_169) = l_168[0]) != (void*)0) > (g_170 != (g_61 , l_171)))), 3UL)) , (((safe_add_func_uint64_t_u_u((l_174 == p_18), p_19)) | l_174) && p_19))) , p_19) | l_175) || 7L)), p_18)), g_76));
    return l_175;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_61 g_142 g_110
 */
static uint8_t  func_25(uint64_t  p_26)
{ /* block id: 55 */
    int32_t **l_158 = (void*)0;
    int32_t **l_159 = &g_110;
    uint8_t l_160 = 0x31L;
    for (g_61 = 0; g_61 < 10; g_61 += 1)
    {
        for (p_26 = 0; p_26 < 4; p_26 += 1)
        {
            g_142[g_61][p_26] = &g_61;
        }
    }
    (*l_159) = (void*)0;
    return l_160;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_148 g_110 g_155
 * writes: g_83 g_156
 */
static int8_t  func_29(int16_t  p_30, int32_t  p_31)
{ /* block id: 51 */
    uint32_t *l_151[10][5];
    int32_t **l_154 = &g_110;
    int i, j;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
            l_151[i][j] = &g_61;
    }
    (*g_155) = ((**l_154) = (safe_lshift_func_uint8_t_u_u((&g_61 == l_151[8][2]), (safe_mul_func_int8_t_s_s((g_2 != g_148), (l_154 == (void*)0))))));
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_65 g_83 g_101 g_110 g_104 g_128 g_148
 * writes: g_83 g_110 g_104 g_128 g_141 g_142 g_76 g_148
 */
static int64_t  func_32(uint32_t  p_33, uint8_t  p_34, int32_t  p_35, uint32_t  p_36, int64_t  p_37)
{ /* block id: 29 */
    int8_t l_108[1][10] = {{0x9BL,0x9BL,0x2FL,0L,0x2FL,0x9BL,0x9BL,0x2FL,0L,0x2FL}};
    int32_t *l_111[9][1] = {{&g_2},{&g_83},{&g_2},{&g_83},{&g_2},{&g_83},{&g_2},{&g_83},{&g_2}};
    int16_t *l_127[10] = {&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101};
    uint32_t *l_140 = &g_61;
    uint32_t **l_139[3][3];
    uint64_t *l_147 = &g_76;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
            l_139[i][j] = &l_140;
    }
    for (p_35 = 0; (p_35 >= 0); p_35 -= 1)
    { /* block id: 32 */
        int32_t l_126 = 0x37570C98L;
        if (l_108[0][9])
            break;
        for (p_34 = 0; (p_34 <= 0); p_34 += 1)
        { /* block id: 36 */
            int32_t *l_109 = &g_83;
            int32_t **l_112 = &l_111[1][0];
            int i, j;
            (*l_109) = 0xDDA348D5L;
            g_110 = l_109;
            (*l_112) = l_111[3][0];
            (*g_110) = ((~(l_108[p_34][(p_35 + 5)] < ((safe_lshift_func_uint16_t_u_s((p_33 | ((g_104 = (safe_lshift_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((safe_rshift_func_int16_t_s_s((g_65 & p_35), ((safe_sub_func_uint8_t_u_u(0x40L, (safe_add_func_uint16_t_u_u((g_65 == p_33), (*l_109))))) , 0x0BD8L))), 0UL)), l_126))) , g_101)), 1)) < g_101))) , 0x41605789L);
        }
    }
    g_148 ^= (((g_128 = l_127[6]) == l_127[9]) || (((((!g_65) == (((*l_147) = ((!((*g_110) = (safe_mul_func_int16_t_s_s(((safe_rshift_func_int8_t_s_u(((1UL ^ (((0x00093999L == (((safe_rshift_func_int8_t_s_s((1L >= ((safe_mul_func_int8_t_s_s(((g_141[1][5] = l_111[0][0]) != (g_142[1][0] = &g_61)), ((safe_mod_func_int32_t_s_s((safe_lshift_func_int16_t_s_u(p_33, 10)), g_104)) & (*g_128)))) != 4294967287UL)), 6)) , p_34) <= 1UL)) | p_34) && 0x65L)) ^ (-7L)), 2)) > 4L), 0x2D4BL)))) || p_33)) || p_34)) , (void*)0) != &g_104) || 0x15E2L));
    return g_65;
}


/* ------------------------------------------ */
/* 
 * reads : g_65 g_83 g_76 g_104
 * writes: g_101 g_83 g_104 g_65
 */
static uint8_t  func_42(int32_t  p_43, uint32_t  p_44, const int8_t  p_45)
{ /* block id: 19 */
    int32_t *l_86 = &g_83;
    int32_t **l_85[4][4] = {{(void*)0,&l_86,(void*)0,(void*)0},{&l_86,&l_86,(void*)0,&l_86},{&l_86,(void*)0,(void*)0,&l_86},{(void*)0,&l_86,(void*)0,(void*)0}};
    int16_t *l_99 = (void*)0;
    int16_t *l_100 = &g_101;
    uint8_t l_103 = 0xDAL;
    int i, j;
    g_104 &= (l_85[2][2] != ((((((safe_rshift_func_int16_t_s_s(p_44, (1L && ((*l_86) ^= (safe_sub_func_int16_t_s_s(p_43, (((safe_div_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u(((*l_100) = (safe_rshift_func_uint8_t_u_u(((safe_add_func_uint8_t_u_u(p_45, p_44)) , 246UL), 3))), (+0x99L))) >= 3UL), g_65)) || p_43) > g_65))))))) && g_76) && p_44) != l_103) , 0x0E64C7C5L) , (void*)0));
    for (g_65 = 0; (g_65 >= (-6)); --g_65)
    { /* block id: 25 */
        return p_43;
    }
    return g_83;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_83
 */
static int32_t  func_46(uint16_t  p_47, uint64_t  p_48, int32_t  p_49, int16_t  p_50, uint8_t  p_51)
{ /* block id: 14 */
    int32_t *l_81 = &g_2;
    int32_t **l_80 = &l_81;
    int32_t *l_82 = &g_83;
    int32_t *l_84 = &g_83;
    l_82 = ((*l_80) = &g_2);
    (*l_84) = (&g_61 != (void*)0);
    return (*l_81);
}


/* ------------------------------------------ */
/* 
 * reads : g_76
 * writes: g_76
 */
static const uint32_t  func_54(const int32_t  p_55, int16_t  p_56, uint64_t  p_57, int64_t  p_58, uint32_t  p_59)
{ /* block id: 11 */
    g_76--;
    return p_58;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_156[i], "g_156[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_244, "g_244", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_246[i], "g_246[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_478, "g_478", print_hash_value);
    transparent_crc(g_480, "g_480", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_482[i][j], "g_482[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_514, "g_514", print_hash_value);
    transparent_crc(g_525, "g_525", print_hash_value);
    transparent_crc(g_547, "g_547", print_hash_value);
    transparent_crc(g_559, "g_559", print_hash_value);
    transparent_crc(g_562, "g_562", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_578[i], "g_578[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_597, "g_597", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 130
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 88
   depth: 2, occurrence: 17
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 2
   depth: 18, occurrence: 3
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 24, occurrence: 4
   depth: 27, occurrence: 1
   depth: 32, occurrence: 2
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 39, occurrence: 1
   depth: 41, occurrence: 1

XXX total number of pointers: 127

XXX times a variable address is taken: 338
XXX times a pointer is dereferenced on RHS: 63
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 11
XXX times a pointer is dereferenced on LHS: 88
breakdown:
   depth: 1, occurrence: 85
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 16
XXX times a pointer is compared with address of another variable: 3
XXX times a pointer is compared with another pointer: 3
XXX times a pointer is qualified to be dereferenced: 1455

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 319
   level: 2, occurrence: 59
   level: 3, occurrence: 7
XXX number of pointers point to pointers: 39
XXX number of pointers point to scalars: 88
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.1
XXX average alias set size: 1.39

XXX times a non-volatile is read: 491
XXX times a non-volatile is write: 251
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 145
XXX percentage of non-volatile access: 98.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 89
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 8
   depth: 2, occurrence: 15
   depth: 3, occurrence: 12
   depth: 4, occurrence: 21
   depth: 5, occurrence: 8

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
********************* end of statistics **********************/

