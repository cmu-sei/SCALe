/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3597409131
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint8_t  f0;
   volatile uint16_t  f1;
   const uint32_t  f2;
   int16_t  f3;
};

union U1 {
   int16_t  f0;
   volatile uint16_t  f1;
   const uint32_t  f2;
   int32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_2 = 1UL;
static int32_t *g_5 = (void*)0;
static int32_t ** volatile g_4 = &g_5;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_8 = 9L;/* VOLATILE GLOBAL g_8 */
static volatile int32_t g_9[3] = {0x81A7ECC2L,0x81A7ECC2L,0x81A7ECC2L};
static int32_t g_10[4][7][8] = {{{(-1L),1L,0x64C7B7F6L,0x8CD3BED1L,(-8L),4L,1L,1L},{0x88D96753L,0x64C7B7F6L,7L,0L,0x8CD3BED1L,0x8CD3BED1L,0L,7L},{(-1L),(-1L),0xE9A07B30L,0x8EA5F34BL,0x88D96753L,(-1L),0xDDCD1665L,9L},{7L,0x8EA5F34BL,0x94E8FE75L,4L,9L,0x64C7B7F6L,1L,9L},{0x8EA5F34BL,1L,1L,0x8EA5F34BL,4L,7L,0x20B50F6BL,7L},{0x20B50F6BL,0L,(-1L),0x4DE6F885L,1L,1L,7L,(-1L)},{0xBDBDF7CDL,0x8CD3BED1L,1L,0x4C266D8FL,0x8CD3BED1L,1L,(-1L),0x4DE6F885L}},{{7L,(-1L),1L,0x94E8FE75L,0x4C266D8FL,0xE9A07B30L,7L,0x3AC9D73DL},{0x8CD3BED1L,1L,(-8L),(-1L),(-1L),(-8L),1L,0x8CD3BED1L},{0x3AC9D73DL,7L,0xE9A07B30L,0x4C266D8FL,0x94E8FE75L,1L,(-1L),7L},{0x4DE6F885L,(-1L),1L,0x8CD3BED1L,0x4C266D8FL,1L,0x8CD3BED1L,0xBDBDF7CDL},{(-1L),7L,1L,1L,0x4DE6F885L,(-8L),0x4DE6F885L,1L},{0xBDBDF7CDL,1L,0xBDBDF7CDL,(-6L),1L,0xE9A07B30L,(-1L),1L},{0x64C7B7F6L,(-1L),(-1L),0x64C7B7F6L,(-6L),1L,1L,0xBDBDF7CDL}},{{0x64C7B7F6L,0x8CD3BED1L,(-8L),4L,1L,1L,0x94E8FE75L,0x94E8FE75L},{0xBDBDF7CDL,0x4DE6F885L,0x4C266D8FL,0x4C266D8FL,0x4DE6F885L,0xBDBDF7CDL,(-1L),4L},{(-1L),(-1L),(-6L),7L,0x4C266D8FL,(-1L),(-1L),0x3AC9D73DL},{0x4DE6F885L,1L,(-8L),7L,0x94E8FE75L,(-8L),0x64C7B7F6L,4L},{0x3AC9D73DL,0x94E8FE75L,(-1L),0x4C266D8FL,(-1L),0x4C266D8FL,(-1L),0x94E8FE75L},{0x8CD3BED1L,(-1L),0x3AC9D73DL,4L,0x4C266D8FL,(-6L),4L,0xBDBDF7CDL},{7L,(-1L),1L,0x64C7B7F6L,0x8CD3BED1L,(-8L),4L,1L}},{{0xBDBDF7CDL,0x64C7B7F6L,0x3AC9D73DL,(-6L),1L,(-1L),(-1L),1L},{1L,(-1L),(-1L),1L,(-6L),0x3AC9D73DL,0x64C7B7F6L,0xBDBDF7CDL},{1L,4L,(-8L),0x8CD3BED1L,0x64C7B7F6L,1L,(-1L),7L},{0xBDBDF7CDL,4L,(-6L),0x4C266D8FL,4L,0x3AC9D73DL,(-1L),0x8CD3BED1L},{0x94E8FE75L,(-1L),0x4C266D8FL,(-1L),0x4C266D8FL,(-1L),0x94E8FE75L,0x3AC9D73DL},{4L,0x64C7B7F6L,(-8L),0x94E8FE75L,7L,(-8L),1L,0x4DE6F885L},{0x3AC9D73DL,(-1L),(-1L),0x4C266D8FL,7L,(-6L),(-1L),(-1L)}}};
static const int32_t *g_20 = &g_10[2][6][4];
static const int32_t **g_19 = &g_20;
static int32_t g_47[7][9][4] = {{{0xD6BCE8D5L,1L,(-1L),(-7L)},{(-1L),(-7L),0L,0L},{0x7C3387DDL,0x7C3387DDL,0L,0x2B8909FFL},{0x2DC71837L,0L,1L,(-1L)},{(-1L),0x2B8909FFL,0xD46C64E7L,1L},{8L,0x2B8909FFL,0L,(-1L)},{0x2B8909FFL,0L,(-1L),0x2B8909FFL},{0x4BD4AC96L,0x7E99E855L,0L,9L},{(-9L),8L,0L,8L}},{{0L,6L,0x4BD4AC96L,0xB2A12551L},{(-1L),0L,8L,9L},{(-1L),0x2DC71837L,0L,1L},{(-1L),0L,8L,0x7E99E855L},{(-1L),1L,0x4BD4AC96L,1L},{0L,(-9L),0L,0x2DC71837L},{(-9L),0L,0L,(-9L)},{0x4BD4AC96L,(-1L),(-1L),9L},{0x2B8909FFL,0xB2A12551L,0L,0L}},{{8L,6L,0xD46C64E7L,0L},{(-1L),0xB2A12551L,1L,9L},{0x2DC71837L,(-1L),0L,(-9L)},{0x7E99E855L,0L,9L,0x2DC71837L},{(-1L),(-9L),(-1L),1L},{0xB2A12551L,1L,0L,0x7E99E855L},{1L,0L,6L,1L},{0x4BD4AC96L,0x2DC71837L,6L,9L},{1L,0L,0L,0xB2A12551L}},{{0xB2A12551L,6L,(-1L),8L},{(-1L),8L,9L,9L},{0x7E99E855L,0x7E99E855L,0L,0x2B8909FFL},{0x2DC71837L,0L,1L,(-1L)},{(-1L),0x2B8909FFL,0xD46C64E7L,1L},{8L,0x2B8909FFL,0L,(-1L)},{0x2B8909FFL,0L,(-1L),0x2B8909FFL},{0x4BD4AC96L,0x7E99E855L,0L,9L},{(-9L),8L,0L,8L}},{{0L,6L,0x4BD4AC96L,0xB2A12551L},{(-1L),0L,8L,9L},{(-1L),0x2DC71837L,0L,1L},{(-1L),0L,8L,0x7E99E855L},{(-1L),1L,0x4BD4AC96L,1L},{0L,(-9L),0L,0x2DC71837L},{(-9L),0L,0L,(-9L)},{0x4BD4AC96L,(-1L),(-1L),9L},{0x2B8909FFL,0xB2A12551L,0L,0L}},{{8L,6L,0xD46C64E7L,0L},{(-1L),0xB2A12551L,1L,9L},{0x2DC71837L,(-1L),0L,(-9L)},{0x7E99E855L,0L,9L,0x2DC71837L},{(-1L),(-9L),(-1L),1L},{1L,6L,(-1L),0xD46C64E7L},{6L,0x7C3387DDL,0L,6L},{0xD6BCE8D5L,0x4BD4AC96L,0L,6L},{6L,9L,(-1L),1L}},{{1L,0L,(-8L),8L},{(-8L),8L,6L,6L},{0xD46C64E7L,0xD46C64E7L,0x2DC71837L,0L},{0x4BD4AC96L,0x7C3387DDL,(-8L),(-1L)},{(-8L),0L,(-7L),(-8L)},{8L,0L,(-1L),(-1L)},{0L,0x7C3387DDL,0L,0L},{0xD6BCE8D5L,0xD46C64E7L,0x7C3387DDL,6L},{(-1L),8L,(-1L),8L}}};
static int32_t g_60 = (-1L);
static int32_t g_70 = 0x202970E7L;
static const uint64_t g_87 = 8UL;
static int32_t g_94 = 0xAD8C3D5FL;
static int32_t g_103 = 0x5C181965L;
static int32_t g_104[10] = {0x5C02B894L,(-8L),(-8L),0x5C02B894L,(-8L),(-8L),0x5C02B894L,(-8L),(-8L),0x5C02B894L};
static union U0 g_110 = {0x13L};/* VOLATILE GLOBAL g_110 */
static union U0 * const g_109 = &g_110;
static uint32_t g_145 = 0x392876FBL;
static uint32_t g_148 = 0xA22506B0L;
static union U0 g_152 = {0xE9L};/* VOLATILE GLOBAL g_152 */
static union U0 g_155[5][2] = {{{0x52L},{0x52L}},{{0x52L},{0x52L}},{{0x52L},{0x52L}},{{0x52L},{0x52L}},{{0x52L},{0x52L}}};
static union U0 g_167 = {0xE0L};/* VOLATILE GLOBAL g_167 */
static union U0 g_168 = {246UL};/* VOLATILE GLOBAL g_168 */
static union U0 g_174 = {0x21L};/* VOLATILE GLOBAL g_174 */
static uint16_t g_176[10] = {0x6355L,0x6355L,0x7BDFL,0x6355L,0x6355L,0x7BDFL,0x6355L,0x6355L,0x7BDFL,0x6355L};
static union U0 *g_185 = (void*)0;
static union U0 **g_184 = &g_185;
static uint64_t *g_201 = (void*)0;
static uint64_t *g_202 = (void*)0;
static int64_t g_233 = (-1L);
static union U0 g_236 = {0x1CL};/* VOLATILE GLOBAL g_236 */
static uint64_t g_253 = 0xA55AB99A0AEC93D4LL;
static int32_t *g_275 = &g_47[5][1][1];
static int64_t g_304 = 5L;
static int8_t g_323 = (-1L);
static int64_t *g_326[2] = {&g_233,&g_233};
static uint32_t g_406[3] = {0x4F939530L,0x4F939530L,0x4F939530L};
static int8_t g_408[10] = {(-1L),(-1L),1L,(-1L),1L,(-1L),(-1L),1L,(-1L),1L};
static uint64_t g_441 = 0xA452AA7277EEC87ALL;
static int64_t g_632 = 5L;
static uint32_t g_636 = 0xFA7F710BL;
static uint8_t g_665[10] = {0x8FL,0xD0L,0xD0L,0x8FL,0xD0L,0xD0L,0x8FL,0xD0L,0xD0L,0x8FL};
static uint16_t g_714 = 5UL;
static int64_t *g_750 = (void*)0;
static volatile int16_t *g_754 = (void*)0;
static volatile int16_t **g_753[4][6] = {{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754},{&g_754,&g_754,&g_754,&g_754,&g_754,&g_754}};
static union U0 g_768 = {0x56L};/* VOLATILE GLOBAL g_768 */
static union U0 *g_767 = &g_768;
static const union U1 g_812 = {0x3035L};/* VOLATILE GLOBAL g_812 */
static const union U1 *g_811 = &g_812;
static const union U1 ** const g_810 = &g_811;
static uint16_t *g_819 = (void*)0;
static uint16_t **g_818[4] = {&g_819,&g_819,&g_819,&g_819};
static uint64_t **g_941 = &g_201;
static uint64_t **g_942[8][9][3] = {{{(void*)0,(void*)0,&g_201},{&g_201,&g_202,&g_201},{&g_201,(void*)0,(void*)0},{&g_201,&g_202,&g_202},{&g_201,&g_201,(void*)0},{&g_201,&g_202,&g_202},{(void*)0,&g_201,&g_201},{&g_201,&g_202,(void*)0},{&g_201,(void*)0,(void*)0}},{{&g_201,&g_201,(void*)0},{&g_201,&g_202,&g_201},{&g_202,(void*)0,&g_202},{&g_201,&g_201,&g_201},{&g_201,&g_202,&g_202},{(void*)0,&g_202,&g_201},{&g_202,&g_201,(void*)0},{&g_201,&g_202,(void*)0},{&g_202,(void*)0,(void*)0}},{{&g_202,&g_201,&g_201},{&g_201,&g_201,&g_201},{&g_201,&g_202,&g_202},{&g_201,(void*)0,&g_202},{(void*)0,&g_201,&g_201},{&g_202,(void*)0,(void*)0},{&g_201,&g_202,&g_201},{&g_202,&g_201,&g_202},{&g_202,&g_201,(void*)0}},{{&g_201,&g_201,&g_201},{&g_202,&g_201,&g_202},{&g_201,&g_202,&g_202},{&g_201,&g_201,&g_201},{&g_202,(void*)0,&g_201},{&g_201,&g_201,&g_201},{&g_202,&g_202,&g_202},{&g_201,(void*)0,&g_201},{&g_201,&g_202,&g_201}},{{&g_202,&g_201,&g_202},{&g_201,&g_201,&g_201},{&g_202,&g_202,&g_201},{&g_202,&g_202,&g_201},{&g_201,&g_202,&g_201},{&g_202,&g_201,&g_201},{(void*)0,&g_201,&g_201},{&g_201,&g_201,&g_201},{&g_201,(void*)0,&g_201}},{{&g_201,&g_202,&g_201},{&g_201,(void*)0,&g_202},{(void*)0,&g_201,&g_201},{&g_202,&g_201,&g_201},{&g_201,&g_202,&g_202},{&g_201,(void*)0,&g_201},{(void*)0,&g_201,&g_201},{&g_202,(void*)0,&g_201},{(void*)0,&g_202,&g_202}},{{&g_201,&g_201,&g_202},{&g_202,&g_201,&g_201},{&g_201,(void*)0,(void*)0},{&g_202,&g_202,&g_202},{&g_201,(void*)0,&g_201},{&g_202,&g_201,(void*)0},{&g_201,&g_201,&g_201},{&g_202,&g_201,&g_202},{&g_201,&g_202,&g_202}},{{&g_202,&g_202,&g_201},{&g_201,&g_202,&g_201},{&g_202,&g_201,&g_202},{&g_201,&g_201,(void*)0},{&g_202,&g_202,&g_202},{&g_201,(void*)0,&g_201},{(void*)0,&g_202,(void*)0},{&g_202,&g_201,&g_201},{(void*)0,(void*)0,(void*)0}}};
static int32_t g_1018 = 0xCF57E12EL;
static int32_t g_1044 = 0xC2E7CF89L;
static int16_t *g_1065 = &g_174.f3;
static int16_t **g_1064 = &g_1065;
static uint8_t g_1128 = 0UL;
static const uint32_t **g_1154 = (void*)0;
static const uint32_t g_1157[6] = {0xD73C66E4L,0xD73C66E4L,0xD73C66E4L,0xD73C66E4L,0xD73C66E4L,0xD73C66E4L};
static const uint32_t *g_1156 = &g_1157[2];
static const uint32_t **g_1155 = &g_1156;
static const int64_t g_1262[1] = {1L};
static union U1 g_1334 = {1L};/* VOLATILE GLOBAL g_1334 */
static volatile int64_t g_1364 = (-1L);/* VOLATILE GLOBAL g_1364 */
static const volatile int64_t *g_1363[3] = {&g_1364,&g_1364,&g_1364};
static const volatile int64_t **g_1362 = &g_1363[0];
static const volatile int64_t ***g_1361 = &g_1362;
static uint32_t g_1369 = 4294967286UL;
static int8_t g_1516[2] = {0xF1L,0xF1L};
static union U1 g_1571[1][9][5] = {{{{-2L},{0L},{0xBBB7L},{0L},{-2L}},{{0x5B19L},{0L},{0x1131L},{-2L},{0x1131L}},{{0x1131L},{0x1131L},{0xBBB7L},{-2L},{0xAF36L}},{{0L},{0x5B19L},{0x5B19L},{0L},{0xAF36L}},{{0x5B19L},{0xD8C6L},{0xBBB7L},{0xBBB7L},{0xD8C6L}},{{0xAF36L},{-2L},{0xBBB7L},{0x1131L},{0x1131L}},{{-2L},{0xAF36L},{-2L},{0xBBB7L},{0x1131L}},{{0xD8C6L},{0x5B19L},{0x1131L},{0x5B19L},{0xD8C6L}},{{-2L},{0x5B19L},{0xAF36L},{0xD8C6L},{0xAF36L}}}};
static uint32_t g_1673[1][2] = {{1UL,1UL}};
static uint8_t *g_1721[8][3] = {{&g_665[5],(void*)0,&g_665[5]},{&g_665[5],&g_665[5],(void*)0},{&g_665[5],&g_1128,&g_1128},{&g_665[5],(void*)0,&g_665[5]},{&g_665[5],&g_665[5],(void*)0},{&g_665[5],&g_1128,&g_1128},{&g_665[5],(void*)0,&g_665[5]},{&g_665[5],&g_665[5],(void*)0}};
static uint8_t **g_1720[1] = {&g_1721[5][2]};
static int16_t ***g_1772[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const union U0 g_1810 = {0x21L};/* VOLATILE GLOBAL g_1810 */
static union U1 *g_1820 = &g_1571[0][4][3];
static union U1 **g_1819 = &g_1820;
static union U1 g_1822 = {1L};/* VOLATILE GLOBAL g_1822 */
static union U1 **g_1836[5][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
static union U0 g_1873 = {0x8CL};/* VOLATILE GLOBAL g_1873 */
static int8_t g_1905 = (-6L);
static volatile int8_t g_1963[9] = {0x0FL,0x0FL,2L,0x0FL,0x0FL,2L,0x0FL,0x0FL,2L};
static volatile int8_t *g_1962 = &g_1963[6];
static volatile int8_t **g_1961 = &g_1962;
static volatile int8_t ***g_1960 = &g_1961;
static uint64_t g_1969 = 0x857F8EF8CA3228A5LL;
static const union U0 g_1981 = {4UL};/* VOLATILE GLOBAL g_1981 */
static union U0 g_1986 = {1UL};/* VOLATILE GLOBAL g_1986 */
static union U1 g_2004 = {0x2558L};/* VOLATILE GLOBAL g_2004 */
static union U1 g_2005[8] = {{0x6A7BL},{0x6A7BL},{0x6A7BL},{0x6A7BL},{0x6A7BL},{0x6A7BL},{0x6A7BL},{0x6A7BL}};
static union U1 g_2006 = {0x61F8L};/* VOLATILE GLOBAL g_2006 */
static union U0 g_2066 = {6UL};/* VOLATILE GLOBAL g_2066 */
static uint32_t g_2081 = 0x387CB90AL;
static volatile int16_t g_2083[3] = {(-1L),(-1L),(-1L)};
static const int32_t g_2093 = 0L;
static const int32_t *g_2092 = &g_2093;
static const int32_t ** const g_2091[2] = {&g_2092,&g_2092};
static const int32_t ** const *g_2090 = &g_2091[0];
static const volatile union U1 g_2141[8][6][4] = {{{{0L},{0xCCE8L},{0xCCE8L},{0L}},{{9L},{0xF6ABL},{0xCCE8L},{0x27BAL}},{{0L},{0xB6E3L},{0x8BB2L},{0xB6E3L}},{{0xB6E3L},{0xCCE8L},{9L},{0xB6E3L}},{{9L},{0xB6E3L},{0x27BAL},{0x27BAL}},{{0xF6ABL},{0xF6ABL},{0x8BB2L},{0L}}},{{{0xF6ABL},{0xCCE8L},{0x27BAL},{0xF6ABL}},{{9L},{0L},{9L},{0x27BAL}},{{0xB6E3L},{0L},{0x8BB2L},{0xF6ABL}},{{0L},{0xCCE8L},{0xCCE8L},{0L}},{{9L},{0xF6ABL},{0xCCE8L},{0x27BAL}},{{0L},{0xB6E3L},{0x8BB2L},{0xB6E3L}}},{{{0xB6E3L},{0xCCE8L},{9L},{0xB6E3L}},{{9L},{0xB6E3L},{0x27BAL},{0x27BAL}},{{0xF6ABL},{0xF6ABL},{0x8BB2L},{0L}},{{0xF6ABL},{0xCCE8L},{0x27BAL},{0xF6ABL}},{{9L},{0L},{9L},{0x27BAL}},{{0xB6E3L},{0L},{0x8BB2L},{0xF6ABL}}},{{{0L},{0xCCE8L},{0xCCE8L},{0L}},{{9L},{0xF6ABL},{0xCCE8L},{0x27BAL}},{{0L},{0xB6E3L},{0x8BB2L},{0xB6E3L}},{{0xB6E3L},{0xCCE8L},{9L},{0xB6E3L}},{{9L},{0xB6E3L},{0x27BAL},{0x27BAL}},{{0xF6ABL},{0xF6ABL},{0x8BB2L},{0L}}},{{{0xF6ABL},{0xCCE8L},{0x27BAL},{0xF6ABL}},{{9L},{0xCCE8L},{5L},{0L}},{{0x27BAL},{0xCCE8L},{0xF6ABL},{9L}},{{0xCCE8L},{0x8BB2L},{0x8BB2L},{0xCCE8L}},{{5L},{9L},{0x8BB2L},{0L}},{{0xCCE8L},{0x27BAL},{0xF6ABL},{0x27BAL}}},{{{0x27BAL},{0x8BB2L},{5L},{0x27BAL}},{{5L},{0x27BAL},{0L},{0L}},{{9L},{9L},{0xF6ABL},{0xCCE8L}},{{9L},{0x8BB2L},{0L},{9L}},{{5L},{0xCCE8L},{5L},{0L}},{{0x27BAL},{0xCCE8L},{0xF6ABL},{9L}}},{{{0xCCE8L},{0x8BB2L},{0x8BB2L},{0xCCE8L}},{{5L},{9L},{0x8BB2L},{0L}},{{0xCCE8L},{0x27BAL},{0xF6ABL},{0x27BAL}},{{0x27BAL},{0x8BB2L},{5L},{0x27BAL}},{{5L},{0x27BAL},{0L},{0L}},{{9L},{9L},{0xF6ABL},{0xCCE8L}}},{{{9L},{0x8BB2L},{0L},{9L}},{{5L},{0xCCE8L},{5L},{0L}},{{0x27BAL},{0xCCE8L},{0xF6ABL},{9L}},{{0xCCE8L},{0x8BB2L},{0x8BB2L},{0xCCE8L}},{{5L},{9L},{0x8BB2L},{0L}},{{0xCCE8L},{0x27BAL},{0xF6ABL},{0x27BAL}}}};
static volatile uint32_t g_2159[7][3] = {{0x2CDD5523L,0x2CDD5523L,0x2CDD5523L},{4294967294UL,4294967294UL,4294967294UL},{0x2CDD5523L,0x2CDD5523L,0x2CDD5523L},{4294967294UL,4294967294UL,4294967294UL},{0x2CDD5523L,0x2CDD5523L,0x2CDD5523L},{4294967294UL,4294967294UL,4294967294UL},{0x2CDD5523L,0x2CDD5523L,0x2CDD5523L}};
static int64_t g_2163 = 0x30205D3DB0259846LL;
static int32_t g_2172 = 7L;
static union U1 g_2234 = {0x6A68L};/* VOLATILE GLOBAL g_2234 */
static int8_t *g_2253 = &g_408[6];
static int8_t **g_2252 = &g_2253;
static int8_t ***g_2251 = &g_2252;
static union U1 g_2300 = {0x43B0L};/* VOLATILE GLOBAL g_2300 */
static volatile int8_t g_2316 = 0x18L;/* VOLATILE GLOBAL g_2316 */
static volatile union U1 g_2360 = {0x40E4L};/* VOLATILE GLOBAL g_2360 */
static uint32_t g_2434 = 0xEE221962L;
static int64_t g_2438 = 0x19AA47E8F79FB6EBLL;
static volatile int16_t g_2445 = 0x3BCEL;/* VOLATILE GLOBAL g_2445 */
static volatile int8_t g_2457 = 0x9BL;/* VOLATILE GLOBAL g_2457 */
static union U1 g_2467[9][7] = {{{-1L},{0x5AE4L},{1L},{1L},{0x5AE4L},{-1L},{0xDB3CL}},{{5L},{-1L},{1L},{-6L},{0x6AC4L},{5L},{0xBD29L}},{{-6L},{-1L},{0L},{0L},{0x2DFAL},{1L},{0x8282L}},{{0xBD29L},{-1L},{-5L},{0x8282L},{5L},{3L},{-1L}},{{0L},{0x5AE4L},{-1L},{-5L},{0x50C2L},{-5L},{-1L}},{{0xB84DL},{0xB84DL},{-6L},{-7L},{-1L},{0xFDFCL},{0x8282L}},{{0xF08EL},{0xD763L},{1L},{-1L},{1L},{5L},{0xBD29L}},{{-7L},{0xFDFCL},{0xE661L},{0x2DFAL},{-1L},{1L},{0xDB3CL}},{{0xE661L},{1L},{5L},{-1L},{0x50C2L},{-7L},{-7L}}};
static union U1 g_2468[6] = {{0xE998L},{0xE998L},{0xE998L},{0xE998L},{0xE998L},{0xE998L}};
static int8_t g_2506[5][2][7] = {{{0x30L,0L,0x30L,1L,1L,0L,1L},{6L,(-1L),(-1L),6L,9L,0xDAL,(-5L)}},{{1L,1L,0xC4L,1L,1L,0L,0xC4L},{0L,(-6L),1L,1L,(-6L),0L,(-5L)}},{{1L,1L,0x30L,0L,0x30L,1L,1L},{0L,1L,(-5L),6L,6L,(-5L),1L}},{{1L,1L,0x07L,9L,1L,9L,0x07L},{6L,(-6L),(-5L),(-1L),0L,0L,(-1L)}},{{0x30L,1L,0x30L,9L,1L,1L,1L},{(-6L),(-1L),1L,6L,0L,0xDAL,0xDAL}}};
static uint32_t g_2511 = 0x0AC802CEL;
static volatile union U0 g_2520 = {1UL};/* VOLATILE GLOBAL g_2520 */
static volatile union U1 g_2590[10][9] = {{{-1L},{-6L},{0x5B06L},{1L},{0x35A8L},{-1L},{1L},{0xAA45L},{1L}},{{0x4A4BL},{-1L},{0x22C4L},{0x22C4L},{-1L},{0x4A4BL},{0x487AL},{0xAF20L},{0x22C4L}},{{-1L},{0x35A8L},{1L},{0x5B06L},{-6L},{-1L},{-1L},{-6L},{0x5B06L}},{{0L},{-1L},{0L},{0x4A4BL},{0L},{0L},{0x487AL},{0xD353L},{0x4A4BL}},{{0xF024L},{-6L},{1L},{0xF024L},{0xDC5DL},{0xF024L},{1L},{-6L},{0xF024L}},{{0xC557L},{0L},{0x22C4L},{0x4A4BL},{0x67F6L},{0xC557L},{0x4A4BL},{0xAF20L},{0x4A4BL}},{{1L},{0xDC5DL},{0x5B06L},{0x5B06L},{0xDC5DL},{1L},{0xA390L},{0xAA45L},{0x5B06L}},{{0xC557L},{0x67F6L},{0x4A4BL},{0x22C4L},{0L},{0xC557L},{0xC557L},{0L},{0x22C4L}},{{0xF024L},{0xDC5DL},{0xF024L},{1L},{-6L},{0xF024L},{0xA390L},{0x34A5L},{1L}},{{0L},{0L},{0x4A4BL},{0L},{-1L},{0L},{0x4A4BL},{0L},{0L}}};
static union U1 g_2631 = {0x01E4L};/* VOLATILE GLOBAL g_2631 */
static int16_t *** volatile g_2657 = (void*)0;/* VOLATILE GLOBAL g_2657 */
static int16_t *** volatile g_2658 = &g_1064;/* VOLATILE GLOBAL g_2658 */
static union U1 g_2698 = {0x8245L};/* VOLATILE GLOBAL g_2698 */
static const uint32_t g_2740 = 18446744073709551615UL;
static int64_t **g_2760 = (void*)0;
static int64_t ***g_2759[2][4][1] = {{{&g_2760},{&g_2760},{&g_2760},{&g_2760}},{{&g_2760},{&g_2760},{&g_2760},{&g_2760}}};
static int64_t **** volatile g_2758 = &g_2759[0][1][0];/* VOLATILE GLOBAL g_2758 */
static int64_t **** volatile * volatile g_2757 = &g_2758;/* VOLATILE GLOBAL g_2757 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static union U1  func_13(int32_t ** p_14, uint64_t  p_15, const int32_t ** p_16, const uint32_t  p_17, uint32_t  p_18);
static const uint32_t  func_21(int32_t ** p_22, int32_t  p_23, int16_t  p_24);
static int32_t ** func_25(int32_t * p_26, int32_t * p_27, int32_t ** p_28, const int8_t  p_29);
static int32_t * func_30(int64_t  p_31, const int32_t * p_32, int8_t  p_33);
static int8_t  func_36(int32_t * p_37, uint32_t  p_38, int32_t ** p_39, uint16_t  p_40);
static int32_t  func_73(uint8_t  p_74, int32_t * p_75);
static int8_t  func_82(const uint64_t * p_83, int32_t * p_84, int32_t  p_85);
static uint32_t  func_88(uint16_t  p_89, uint32_t  p_90);
static int8_t  func_91(int32_t * p_92, int32_t  p_93);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_10
 * writes: g_5 g_2 g_10
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_3 = (void*)0;
    int32_t l_2701[5][7] = {{4L,4L,4L,4L,4L,4L,4L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{4L,4L,4L,4L,4L,4L,4L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{4L,4L,4L,4L,4L,4L,4L}};
    uint16_t l_2752 = 6UL;
    union U0 **l_2780 = &g_185;
    int64_t ***l_2817 = &g_2760;
    int16_t l_2830[10][8][3];
    int64_t l_2831 = 0xF782FED2286EE6FBLL;
    int i, j, k;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
                l_2830[i][j][k] = (-1L);
        }
    }
    (*g_4) = (g_2 , l_3);
    for (g_2 = 0; (g_2 != 28); ++g_2)
    { /* block id: 4 */
        uint64_t l_41 = 0UL;
        int32_t **l_42 = &g_5;
        uint8_t **l_2702 = &g_1721[2][0];
        uint8_t **l_2704 = &g_1721[5][2];
        uint32_t *l_2741 = &g_2511;
        int32_t l_2743 = 0x550ED7B4L;
        int8_t l_2746 = 1L;
        int64_t ** const * const **l_2756 = (void*)0;
        for (g_10[2][6][4] = (-5); (g_10[2][6][4] <= 27); ++g_10[2][6][4])
        { /* block id: 7 */
            uint64_t *l_59[1];
            int32_t l_61 = 0xCF859E22L;
            uint32_t *l_1780 = &g_406[1];
            int32_t l_2748 = 1L;
            uint32_t l_2749[10][1] = {{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}};
            uint16_t l_2814 = 0x4A96L;
            uint8_t l_2829 = 0xABL;
            int i, j;
            for (i = 0; i < 1; i++)
                l_59[i] = &l_41;
        }
    }
    return l_2831;
}


/* ------------------------------------------ */
/* 
 * reads : g_1156 g_1157 g_1155 g_811 g_812 g_145 g_275 g_47 g_632 g_1810 g_810 g_20 g_10 g_1819 g_1822 g_19 g_1065 g_8 g_1018 g_60 g_174.f3 g_1128 g_1516 g_4 g_5 g_941 g_201 g_1361 g_1362 g_812.f0 g_1873 g_1905 g_103 g_176 g_323 g_1960 g_1064 g_1981 g_1986 g_665 g_2004 g_184 g_2005 g_2006 g_1961 g_1962 g_1963 g_2066 g_2081 g_2083 g_767 g_768 g_2090 g_2091 g_2092 g_2093 g_2141 g_1571.f0 g_2159 g_2163 g_104 g_408 g_233 g_2006.f3 g_2234 g_2251 g_2252 g_2253 g_2172 g_2300 g_2234.f0 g_2360 g_2434 g_2438 g_2467 g_2468 g_441 g_2511 g_2520 g_1369 g_70 g_750 g_2590 g_2631 g_1820 g_768.f3 g_2658 g_304 g_2698
 * writes: g_145 g_47 g_665 g_1819 g_174.f3 g_1836 g_1720 g_1018 g_60 g_104 g_1128 g_20 g_1516 g_103 g_941 g_441 g_236.f3 g_1820 g_323 g_1969 g_185 g_408 g_1961 g_2090 g_1905 g_5 g_70 g_94 g_2163 g_233 g_767 g_2066.f3 g_2006.f3 g_2172 g_1873.f3 g_2234.f0 g_1369 g_176 g_2434 g_2438 g_2511 g_326 g_2234.f3 g_2081 g_811 g_768.f3 g_818 g_1064 g_2251 g_304
 */
static union U1  func_13(int32_t ** p_14, uint64_t  p_15, const int32_t ** p_16, const uint32_t  p_17, uint32_t  p_18)
{ /* block id: 756 */
    int8_t *l_1794[2];
    int8_t **l_1793 = &l_1794[0];
    uint16_t *l_1799[6];
    int32_t l_1800[3];
    const int32_t l_1801 = 0x944B229EL;
    uint32_t *l_1802[4][1][4] = {{{&g_145,&g_406[0],&g_406[0],&g_145}},{{&g_406[0],&g_145,&g_406[0],&g_406[0]}},{{&g_145,&g_145,&g_145,&g_145}},{{&g_145,&g_406[0],&g_406[0],&g_145}}};
    int16_t l_1803 = (-1L);
    int32_t l_1818 = 0x4E7D7A36L;
    const int16_t ****l_1825 = (void*)0;
    uint32_t *l_1846 = &g_1369;
    int8_t l_1907 = 0x49L;
    int64_t **l_2012 = &g_750;
    int64_t ***l_2011 = &l_2012;
    int32_t l_2033 = 0xADAA237FL;
    int16_t **l_2077 = &g_1065;
    union U0 **l_2089 = &g_185;
    const uint64_t l_2150 = 4UL;
    uint16_t l_2156 = 0UL;
    uint16_t l_2182[10];
    union U1 *l_2222 = &g_1334;
    int32_t l_2226[1][7];
    uint32_t l_2273 = 0UL;
    int64_t l_2310 = (-7L);
    uint64_t l_2313 = 18446744073709551609UL;
    int64_t l_2447 = (-1L);
    int32_t l_2455 = 3L;
    int64_t l_2458 = 0x837C04A6F3AC74AELL;
    int16_t l_2459[9][2] = {{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}};
    uint8_t l_2471 = 0x26L;
    uint8_t ***l_2537 = &g_1720[0];
    union U1 ***l_2588 = (void*)0;
    int16_t **l_2661[4][7] = {{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{(void*)0,&g_1065,(void*)0,&g_1065,(void*)0,&g_1065,(void*)0},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{(void*)0,&g_1065,(void*)0,&g_1065,(void*)0,&g_1065,(void*)0}};
    uint32_t l_2664 = 4294967290UL;
    uint32_t l_2685[6][2] = {{0xF9CC212FL,0xF9CC212FL},{18446744073709551613UL,0xF9CC212FL},{0xF9CC212FL,18446744073709551613UL},{0xF9CC212FL,0xF9CC212FL},{18446744073709551613UL,0xF9CC212FL},{0xF9CC212FL,18446744073709551613UL}};
    uint16_t ***l_2697 = &g_818[0];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1794[i] = (void*)0;
    for (i = 0; i < 6; i++)
        l_1799[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_1800[i] = 0x1B3DB0F7L;
    for (i = 0; i < 10; i++)
        l_2182[i] = 3UL;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
            l_2226[i][j] = 0xB79FDA06L;
    }
    if ((0x55L ^ (safe_mul_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s((0L || ((safe_sub_func_uint8_t_u_u(((*g_1156) || p_17), (safe_lshift_func_int16_t_s_u((((safe_sub_func_uint32_t_u_u(((l_1793 == (p_17 , &l_1794[1])) || ((g_145 &= (safe_add_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s((((((((**g_1155) & (((l_1800[1] = 0x8342L) & 0x03C4L) > p_18)) , 0x15B19F620F3A7A0DLL) , l_1800[1]) , (*g_811)) , (void*)0) == (void*)0), l_1801)) && l_1800[0]), p_17))) != l_1801)), (*g_275))) > l_1803) != 0x29072F0FL), p_15)))) == l_1803)), 0x647D6725L)) & p_18), l_1801)), g_632))))
    { /* block id: 759 */
        uint16_t l_1815 = 1UL;
        int8_t ***l_1816[9] = {&l_1793,&l_1793,&l_1793,&l_1793,&l_1793,&l_1793,&l_1793,&l_1793,&l_1793};
        uint8_t *l_1817 = &g_665[3];
        int16_t ****l_1826[10] = {&g_1772[0],(void*)0,&g_1772[0],(void*)0,&g_1772[0],(void*)0,&g_1772[0],(void*)0,&g_1772[0],(void*)0};
        union U1 **l_1835 = &g_1820;
        int32_t l_1917 = 0L;
        int32_t l_1918 = 0x70B271B7L;
        int32_t l_1919 = 1L;
        int32_t l_1920 = 2L;
        int32_t l_1926 = 0xE1267E9FL;
        int32_t l_1927 = (-1L);
        int32_t l_1928 = (-9L);
        int32_t l_1929 = 0x02BDBB47L;
        int32_t ***l_1945 = (void*)0;
        int16_t l_2001 = 0xC1E6L;
        int64_t l_2032 = 0x5FEAF86F25DB2B05LL;
        int64_t ***l_2059[8] = {&l_2012,&l_2012,&l_2012,&l_2012,&l_2012,&l_2012,&l_2012,&l_2012};
        uint64_t l_2080 = 0x7325C604081ECF37LL;
        union U0 **l_2088 = &g_767;
        uint64_t l_2128 = 0UL;
        uint64_t l_2155 = 4UL;
        int32_t **l_2158 = (void*)0;
        int32_t ***l_2157 = &l_2158;
        int32_t l_2173 = 5L;
        int32_t l_2174 = 2L;
        int32_t l_2175 = 0x37739F24L;
        int32_t l_2176 = 0x7FFEF469L;
        int32_t l_2177 = (-7L);
        int32_t l_2178 = 1L;
        int16_t l_2196 = 0L;
        int16_t l_2227 = 6L;
        uint32_t l_2228 = 0x3EEAD4B1L;
        int8_t l_2361 = (-1L);
        const uint32_t l_2419 = 0xDBEC6572L;
        uint32_t l_2428 = 0x74D748DBL;
        int32_t l_2429[8];
        int8_t l_2446 = 0x29L;
        int32_t *l_2452 = &g_94;
        int32_t *l_2453 = (void*)0;
        int32_t *l_2454[2];
        int8_t l_2456 = 0x6CL;
        int64_t l_2460 = 0xA981976FB6943B49LL;
        uint32_t l_2461[3][7];
        int i, j;
        for (i = 0; i < 8; i++)
            l_2429[i] = 1L;
        for (i = 0; i < 2; i++)
            l_2454[i] = &g_2004.f3;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 7; j++)
                l_2461[i][j] = 8UL;
        }
        if ((((l_1818 |= ((((*l_1817) = (safe_sub_func_int32_t_s_s((safe_add_func_uint16_t_u_u((((safe_mod_func_uint32_t_u_u(((*g_275) , (((g_1810 , ((safe_div_func_int32_t_s_s(((((safe_add_func_uint16_t_u_u(((4294967286UL ^ (g_145 = (((**g_810) , (0x9AE6E31AL != l_1800[1])) | ((*g_275) |= 0xA82AC5FAL)))) > (**p_16)), l_1815)) <= l_1800[1]) , p_17) > p_15), (**g_1155))) < 255UL)) > l_1801) & 0L)), (**p_16))) , l_1816[8]) != l_1816[6]), l_1815)), (*g_20)))) ^ p_17) && p_17)) < 0x291BL) , 2L))
        { /* block id: 764 */
            union U1 ***l_1821[4][5] = {{&g_1819,&g_1819,&g_1819,(void*)0,&g_1819},{&g_1819,&g_1819,&g_1819,(void*)0,&g_1819},{&g_1819,&g_1819,&g_1819,&g_1819,&g_1819},{&g_1819,(void*)0,&g_1819,&g_1819,(void*)0}};
            int32_t l_1834 = 0xE9803E3EL;
            uint8_t ***l_1844 = &g_1720[0];
            int32_t *l_1845 = &g_1018;
            int32_t *l_1847[5] = {&g_94,&g_94,&g_94,&g_94,&g_94};
            uint64_t * const *l_1914 = (void*)0;
            uint8_t l_1940 = 0xF1L;
            int32_t l_1995 = 6L;
            int i, j;
            (*g_275) |= (((g_1819 = g_1819) == (g_1836[1][0] = (g_1822 , (((safe_add_func_int16_t_s_s(1L, (1UL & (0xBB9F3D995FD983CALL <= (l_1825 == l_1826[7]))))) ^ (safe_rshift_func_int16_t_s_u((safe_rshift_func_int8_t_s_u((l_1800[1] = (l_1800[1] <= ((((((safe_unary_minus_func_uint64_t_u(((safe_add_func_int16_t_s_s(((*g_1065) = (0x55C8142FL | (**g_19))), l_1834)) != 65535UL))) && p_15) <= p_15) & 18446744073709551615UL) , l_1815) , l_1800[1]))), 5)), p_15))) , l_1835)))) && p_17);
            g_104[2] = ((*g_275) = ((l_1834 = (~((**p_16) & (((l_1834 < ((safe_sub_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_s(((safe_div_func_uint8_t_u_u(0xB7L, ((*l_1817) = (p_17 | (p_18 , (((*g_275) , (g_60 &= ((*l_1845) &= ((((*l_1844) = ((((p_17 , (g_8 , &g_1064)) != (void*)0) , p_17) , &g_1721[5][2])) == &g_1721[6][0]) > p_17)))) , 0x03L)))))) ^ (-1L)), 14)) , 3L) >= p_15), p_18)) , l_1800[1])) , (void*)0) != l_1846)))) & (*g_1065)));
            for (g_1128 = 0; (g_1128 <= 1); g_1128 += 1)
            { /* block id: 779 */
                int32_t l_1857 = 0L;
                int16_t l_1911 = 0x060CL;
                int32_t l_1924 = 0x0DAC1447L;
                int32_t l_1925[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
                int32_t l_1930 = 9L;
                uint32_t l_1932 = 0UL;
                int64_t l_1949 = 0x003B2D4FCA65EF9ELL;
                uint64_t l_2003 = 0UL;
                int i;
                (*p_16) = ((*p_14) = ((!(safe_div_func_uint8_t_u_u(((*l_1817) = (g_1516[g_1128] <= 4294967289UL)), (l_1800[1] = l_1800[1])))) , ((safe_rshift_func_int8_t_s_u(l_1818, 3)) , (*g_4))));
                if (((safe_rshift_func_int8_t_s_s(((((+(p_18 && p_15)) || 1UL) && (((safe_unary_minus_func_uint16_t_u((l_1857 = ((*g_941) != (void*)0)))) == (safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_u(p_15, (safe_mul_func_int16_t_s_s((safe_sub_func_int16_t_s_s(((((void*)0 == (*g_1361)) | (!((safe_rshift_func_uint8_t_u_u(l_1818, 5)) != p_15))) > p_15), p_17)), l_1815)))), p_15))) ^ l_1800[1])) | l_1815), g_812.f0)) < 0xFD97L))
                { /* block id: 785 */
                    int32_t l_1902[9][1] = {{0x9BB93F54L},{(-1L)},{0x9BB93F54L},{(-1L)},{0x9BB93F54L},{(-1L)},{0x9BB93F54L},{(-1L)},{0x9BB93F54L}};
                    int32_t l_1906[7][6] = {{0x8B5E6C43L,0x4F093927L,0x164DE5FCL,0x5A6DCA06L,0xF1635973L,0xA0B90B7BL},{0xF1635973L,0x8B5E6C43L,(-5L),(-10L),(-10L),(-5L)},{0xF1635973L,0xF1635973L,0xC9FF8397L,0x5A6DCA06L,0x9D03E2C0L,1L},{0x8B5E6C43L,0xF1635973L,(-1L),0xC8EEA5E5L,(-10L),0xC9FF8397L},{0x4F093927L,0x8B5E6C43L,(-1L),0x4F093927L,0xF1635973L,1L},{0x5A6DCA06L,0x4F093927L,0xC9FF8397L,0x4F093927L,0x5A6DCA06L,(-10L)},{0x7B890530L,0x545EE123L,(-10L),0xD5EF856BL,0x545EE123L,0x8B5E6C43L}};
                    int i, j;
                    g_103 = (safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((**g_810) , (g_1873 , (safe_div_func_uint16_t_u_u(p_15, (safe_div_func_uint64_t_u_u(((safe_sub_func_int16_t_s_s(((safe_sub_func_int64_t_s_s(((((safe_add_func_int32_t_s_s((l_1906[3][1] = ((*g_275) = (safe_add_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u((safe_rshift_func_uint16_t_u_s(p_18, 6)))), (safe_rshift_func_int16_t_s_u((((safe_lshift_func_int16_t_s_u(((l_1801 , ((safe_mul_func_int8_t_s_s((((safe_sub_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(((+((+(~l_1902[4][0])) , (p_17 , (((((safe_mul_func_int8_t_s_s((g_1516[1] ^= g_1905), ((&g_811 != (void*)0) == l_1857))) , p_18) == p_15) <= 0xF9835D6ABFD84B9DLL) < 65530UL)))) < l_1815), p_15)), 18446744073709551607UL)) || p_18) < l_1800[1]), 0x0AL)) , 0x7880F2711E23CCACLL)) , 0xA96EL), p_17)) <= p_18) | (*g_275)), 14)))))), 4294967292UL)) ^ l_1857) == g_103) | p_15), l_1902[1][0])) >= l_1907), l_1803)) , l_1815), l_1815)))))), l_1815)), 65531UL));
                    if (l_1801)
                        continue;
                    if ((safe_div_func_uint8_t_u_u((safe_unary_minus_func_uint64_t_u(0UL)), p_17)))
                    { /* block id: 791 */
                        uint64_t ***l_1912 = &g_941;
                        uint64_t * const **l_1913[5][1];
                        int32_t l_1915 = 0xAB84CB36L;
                        int i, j;
                        for (i = 0; i < 5; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_1913[i][j] = (void*)0;
                        }
                        l_1915 ^= (l_1911 < (((*l_1912) = &g_201) == (l_1914 = &g_202)));
                    }
                    else
                    { /* block id: 795 */
                        int32_t l_1916 = (-1L);
                        int32_t l_1921 = 0xA20407CAL;
                        int32_t l_1922 = 0xA97B69CFL;
                        int32_t l_1923[8] = {0xB366A7BBL,0L,0xB366A7BBL,0L,0xB366A7BBL,0L,0xB366A7BBL,0L};
                        int64_t l_1931 = 0x1B97FDDB5A65D2A6LL;
                        uint32_t l_1939 = 5UL;
                        int i;
                        --l_1932;
                        if (p_17)
                            break;
                        if (l_1921)
                            continue;
                        (*g_275) ^= ((((safe_rshift_func_uint8_t_u_u(p_15, (safe_mod_func_uint8_t_u_u(((((g_145 = (((void*)0 != &g_1720[0]) <= (l_1939 & (*g_1156)))) || p_18) & (((void*)0 == &g_1836[4][1]) ^ (&g_1064 == (void*)0))) ^ l_1940), p_18)))) > 0x0F3976F1L) < l_1931) || p_17);
                    }
                }
                else
                { /* block id: 802 */
                    uint16_t ***l_1944 = &g_818[2];
                    uint16_t ****l_1943 = &l_1944;
                    int32_t l_1948 = (-8L);
                    for (g_441 = 0; (g_441 <= 3); g_441 += 1)
                    { /* block id: 805 */
                        if (l_1800[1])
                            break;
                        return (**g_810);
                    }
                    (*g_275) = ((0xFD06C9A5L ^ ((safe_mul_func_int16_t_s_s((0x4CL != ((((&g_818[2] != (l_1815 , ((*l_1943) = (void*)0))) , l_1945) == (void*)0) || ((safe_lshift_func_int16_t_s_s(0x8CF8L, (l_1948 = l_1948))) != p_17))), l_1932)) == 0x4BC0756D4B1D20A8LL)) , l_1949);
                    for (g_236.f3 = 0; (g_236.f3 <= 3); g_236.f3 += 1)
                    { /* block id: 814 */
                        int i;
                        (*g_275) = ((safe_sub_func_uint8_t_u_u(((void*)0 == &g_819), g_176[(g_1128 + 5)])) && (-4L));
                    }
                    (*l_1835) = (void*)0;
                }
                (*g_275) = 0xFB1B159EL;
                for (g_323 = 3; (g_323 <= 9); g_323 += 1)
                { /* block id: 822 */
                    uint8_t *l_1958 = (void*)0;
                    int8_t *l_1967[10][8] = {{&l_1907,(void*)0,&g_1905,&g_323,&g_408[8],&g_1516[1],&g_1905,&g_1905},{&g_1516[g_1128],(void*)0,&g_1905,&g_1516[1],(void*)0,&g_1516[g_1128],&l_1907,&g_408[4]},{&g_1516[1],&g_408[4],&g_408[8],(void*)0,&g_323,&g_1516[g_1128],&g_323,(void*)0},{&l_1907,(void*)0,&l_1907,&g_323,&g_1516[1],&g_1516[1],(void*)0,&g_1516[1]},{&g_1516[g_1128],&g_408[8],(void*)0,&g_1516[g_1128],&g_1516[g_1128],&g_1905,&g_1516[1],&g_1516[1]},{&g_1516[g_1128],&g_1905,(void*)0,&l_1907,&g_1516[1],&l_1907,&g_1516[g_1128],&g_323},{&l_1907,&g_408[8],&g_1516[g_1128],&g_1905,&g_323,&g_323,&g_1905,&g_1516[g_1128]},{&g_1516[1],&g_1516[1],&g_1516[1],&g_1516[g_1128],(void*)0,(void*)0,&g_323,&g_1516[1]},{&g_1516[g_1128],&l_1907,&l_1907,&g_1905,&g_408[8],&g_1516[1],&g_408[4],&g_1516[1]},{&l_1907,&g_323,&g_323,&g_1516[g_1128],&g_1905,&g_1516[g_1128],&l_1907,&g_1516[g_1128]}};
                    int8_t *l_1968[1][2];
                    int8_t ** const l_1966[5] = {&l_1968[0][0],&l_1968[0][0],&l_1968[0][0],&l_1968[0][0],&l_1968[0][0]};
                    int8_t ** const *l_1965[5][4][1] = {{{&l_1966[3]},{&l_1966[3]},{&l_1966[4]},{&l_1966[3]}},{{&l_1966[3]},{&l_1966[4]},{&l_1966[3]},{&l_1966[3]}},{{&l_1966[4]},{&l_1966[3]},{&l_1966[3]},{&l_1966[4]}},{{&l_1966[3]},{&l_1966[3]},{&l_1966[4]},{&l_1966[3]}},{{&l_1966[3]},{&l_1966[4]},{&l_1966[3]},{&l_1966[3]}}};
                    int8_t ** const **l_1964 = &l_1965[0][1][0];
                    int32_t l_1998 = 0xCAD53255L;
                    int64_t l_2000 = 0x68B9A5E2FA334B65LL;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 2; j++)
                            l_1968[i][j] = &g_1516[g_1128];
                    }
                    if ((safe_add_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u(p_18, 0xF2808289953E6A13LL)) <= (((g_1969 = (((safe_mod_func_uint32_t_u_u((l_1924 &= ((void*)0 != l_1958)), 1L)) > l_1930) && (~(g_1960 == ((*l_1964) = &l_1793))))) | (safe_lshift_func_uint16_t_u_u((((safe_mod_func_uint64_t_u_u(((p_18 , p_17) >= p_17), 1UL)) >= 255UL) , p_15), 3))) ^ 8L)), (**g_1064))))
                    { /* block id: 826 */
                        int64_t l_1999[9][4][7] = {{{1L,0L,1L,1L,(-1L),1L,1L},{(-2L),9L,0L,0x9E76ABD82D1E5B84LL,(-1L),1L,(-2L)},{(-1L),1L,0L,0L,(-1L),(-1L),0L},{0x41D96CAD0C18937ELL,0x5212C13966BC34FELL,0x41D96CAD0C18937ELL,0x8EBFB3AE5832C32CLL,(-1L),0L,1L}},{{0L,(-1L),0x3A940C322D45D05FLL,0xD7F2C50A0073303ELL,(-1L),0x224B1A6431FB547FLL,(-1L)},{0L,0x8EBFB3AE5832C32CLL,1L,0xB963424B5D6F19E2LL,1L,0L,(-1L)},{(-1L),(-1L),1L,0L,0L,(-1L),(-1L)},{(-2L),0x8D2CBE948A20E1C9LL,(-4L),0x8D2CBE948A20E1C9LL,(-2L),1L,(-1L)}},{{0x3AA288544C51167CLL,9L,1L,0L,1L,1L,(-1L)},{1L,0x5212C13966BC34FELL,0xB3E0A8FD799CD1F0LL,0L,0xF1BDEBB8BCCC2BA6LL,0x8EBFB3AE5832C32CLL,1L},{0L,1L,0x3AA288544C51167CLL,0L,(-1L),0xD7F2C50A0073303ELL,1L},{1L,(-1L),(-5L),0x784E2DE911ABB3F2LL,(-5L),(-1L),1L}},{{0x224B1A6431FB547FLL,1L,0x8D53388BEAE1AF71LL,0xC129ADFBB499486ALL,1L,0x224B1A6431FB547FLL,0xC129ADFBB499486ALL},{0xB3E0A8FD799CD1F0LL,0x3ED754EAA595D9D4LL,0x700A72DC399253C7LL,0L,0x41D96CAD0C18937ELL,0x9E76ABD82D1E5B84LL,(-8L)},{1L,0L,0x8D53388BEAE1AF71LL,9L,0L,0xC129ADFBB499486ALL,(-1L)},{(-4L),0L,(-5L),0L,(-8L),0L,(-5L)}},{{1L,1L,0x3AA288544C51167CLL,9L,1L,0L,1L},{1L,(-1L),(-10L),0L,0L,(-1L),0x41D96CAD0C18937ELL},{0x3A940C322D45D05FLL,(-1L),0x3A940C322D45D05FLL,0xC129ADFBB499486ALL,1L,0x3A940C322D45D05FLL,0L},{0x41D96CAD0C18937ELL,0x3ED754EAA595D9D4LL,0xF1BDEBB8BCCC2BA6LL,0x784E2DE911ABB3F2LL,(-8L),0xB963424B5D6F19E2LL,(-8L)}},{{0L,0xC129ADFBB499486ALL,0xC129ADFBB499486ALL,0L,0L,0x3A940C322D45D05FLL,1L},{0L,0x8EBFB3AE5832C32CLL,(-5L),0xE54B3FB997B5E7ABLL,0x41D96CAD0C18937ELL,(-1L),0L},{1L,1L,(-1L),1L,1L,0L,1L},{0xB3E0A8FD799CD1F0LL,1L,(-4L),0L,(-5L),0L,(-8L)}},{{0xC129ADFBB499486ALL,(-1L),0x8D53388BEAE1AF71LL,0x8D53388BEAE1AF71LL,(-1L),0xC129ADFBB499486ALL,0L},{0xB3E0A8FD799CD1F0LL,0L,0L,0L,(-8L),0x9E76ABD82D1E5B84LL,0x41D96CAD0C18937ELL},{1L,0x224B1A6431FB547FLL,0xC129ADFBB499486ALL,9L,0xC129ADFBB499486ALL,0x224B1A6431FB547FLL,1L},{0L,0L,(-10L),(-1L),1L,(-1L),(-5L)}},{{0L,(-1L),0xD7F2C50A0073303ELL,1L,1L,0xD7F2C50A0073303ELL,(-1L)},{0x41D96CAD0C18937ELL,1L,(-10L),0x784E2DE911ABB3F2LL,0x100B28ABE70A2DB3LL,(-1L),(-8L)},{0x3A940C322D45D05FLL,1L,0xC129ADFBB499486ALL,0x3A940C322D45D05FLL,(-1L),0x3A940C322D45D05FLL,0xC129ADFBB499486ALL},{1L,0x8EBFB3AE5832C32CLL,0L,0x784E2DE911ABB3F2LL,0x41D96CAD0C18937ELL,0x8D2CBE948A20E1C9LL,1L}},{{1L,0xC129ADFBB499486ALL,0x8D53388BEAE1AF71LL,1L,0x224B1A6431FB547FLL,0x224B1A6431FB547FLL,1L},{(-4L),0x3ED754EAA595D9D4LL,(-4L),(-1L),0x41D96CAD0C18937ELL,0L,0x100B28ABE70A2DB3LL},{1L,(-1L),(-1L),9L,(-1L),0x3AA288544C51167CLL,(-1L)},{0xB3E0A8FD799CD1F0LL,(-1L),(-5L),0L,0x100B28ABE70A2DB3LL,0L,0x41D96CAD0C18937ELL}}};
                        int64_t l_2002 = 3L;
                        int i, j, k;
                        if (l_1925[5])
                            break;
                        l_1998 = ((*g_275) ^= (~(safe_rshift_func_uint16_t_u_u(((safe_add_func_int64_t_s_s((0x89L || ((((safe_mul_func_uint8_t_u_u(((g_1981 , 1L) && (safe_lshift_func_uint16_t_u_s((((safe_mod_func_uint64_t_u_u(p_17, p_17)) >= ((g_1986 , ((((safe_div_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(((l_1995 = (safe_add_func_uint8_t_u_u(((**g_1155) , l_1800[0]), ((*l_1817)++)))) ^ ((safe_add_func_int64_t_s_s(((p_18 >= p_18) > p_18), l_1998)) || p_18)), l_1999[5][0][5])), 0x50E0DEDFDD19C7DDLL)) >= l_2000) >= l_2001) ^ 0x5C627722L)) && 0xE03DCC2CDC7DE8ACLL)) < p_17), (*g_1065)))), 0x09L)) == 1UL) , 0xDBL) & 0xC5L)), p_15)) == l_1998), 10))));
                        if (l_2002)
                            break;
                    }
                    else
                    { /* block id: 833 */
                        (*g_275) = l_2003;
                        return g_2004;
                    }
                    for (l_1907 = 0; (l_1907 <= 3); l_1907 += 1)
                    { /* block id: 839 */
                        (*g_184) = (void*)0;
                        return g_2005[3];
                    }
                    return g_2006;
                }
            }
            l_1847[3] = (*g_4);
        }
        else
        { /* block id: 847 */
            uint32_t *l_2017 = &g_1369;
            int32_t l_2024 = 0x3F0E6B39L;
            union U0 ** const l_2031 = &g_767;
            int8_t *l_2058 = &g_323;
            int8_t ***l_2064 = &l_1793;
            uint32_t l_2074 = 4294967295UL;
            int32_t *l_2122 = (void*)0;
            int32_t *l_2123 = &g_1822.f3;
            int32_t *l_2124 = &g_1822.f3;
            int32_t *l_2125 = &g_2006.f3;
            int32_t *l_2126 = &g_70;
            int32_t *l_2127[9];
            int i;
            for (i = 0; i < 9; i++)
                l_2127[i] = &g_1334.f3;
            (*g_275) ^= (safe_div_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(((l_2024 = (((((((void*)0 == l_2011) , ((g_1516[1] = (g_323 &= ((l_1818 &= p_18) ^ (((safe_mod_func_int64_t_s_s((l_2017 == l_1846), 1UL)) || ((g_408[8] = (0x2B25L > p_18)) <= (safe_rshift_func_int16_t_s_s((safe_mod_func_int8_t_s_s(((((-10L) & l_2024) && l_1800[0]) & p_18), 1UL)), 6)))) & l_2024)))) | 0x03L)) | 0x1C2FL) <= p_17) || p_18) > p_17)) <= p_18), l_1801)) , 4294967293UL), p_15));
            l_2033 |= ((safe_add_func_uint32_t_u_u(p_18, 0x65653D42L)) != ((((((safe_add_func_int16_t_s_s(p_15, l_2024)) | (((((safe_mul_func_int8_t_s_s(p_18, (l_1818 && (((void*)0 == l_2031) > (l_2024 == 0x350DL))))) != l_1800[2]) && l_2032) , (***g_1960)) , p_15)) < 7L) < l_2024) & 7L) >= l_2024));
            for (p_18 = 0; (p_18 <= 1); p_18 += 1)
            { /* block id: 857 */
                int32_t l_2045[2][2] = {{0xEBDAB6ACL,0xEBDAB6ACL},{0xEBDAB6ACL,0xEBDAB6ACL}};
                int32_t l_2046[8][7] = {{(-1L),(-5L),0x13AABDC9L,1L,1L,1L,1L},{1L,(-5L),0x2EAE2646L,1L,1L,1L,1L},{0xEDF2FFA3L,1L,0xEDF2FFA3L,1L,1L,0x13AABDC9L,0x13AABDC9L},{7L,1L,8L,1L,7L,8L,(-10L)},{(-9L),0x13AABDC9L,1L,(-9L),1L,0x13AABDC9L,(-9L)},{0x2EAE2646L,(-10L),(-5L),1L,(-10L),1L,(-5L)},{(-9L),(-9L),1L,1L,0x6910C334L,1L,0x6910C334L},{7L,(-5L),(-5L),7L,1L,0x2EAE2646L,7L}};
                uint32_t **l_2057 = (void*)0;
                int32_t l_2079[6][10] = {{0x6AF0F771L,0x0A869343L,0xC549E5CEL,0xF67763B3L,0x0A869343L,(-2L),0L,0x31468BD1L,0L,(-2L)},{(-1L),0x4651924CL,0x255DAF8EL,0x4651924CL,(-1L),(-1L),0xB035E89BL,8L,(-1L),6L},{6L,0xC77275A2L,0L,6L,0xC549E5CEL,5L,0x6BAB3D6DL,0x6AF0F771L,0xF67763B3L,6L},{0x6AF0F771L,6L,(-2L),0xC549E5CEL,(-1L),0xC77275A2L,0xC77275A2L,(-1L),0xC549E5CEL,(-2L)},{0x18499145L,0x18499145L,(-1L),0x6BAB3D6DL,0x0A869343L,0x255DAF8EL,0x31468BD1L,6L,(-1L),8L},{0x4651924CL,0L,5L,0x31468BD1L,0xF67763B3L,0x2C01BB24L,0x31468BD1L,0x6AF0F771L,0xC77275A2L,0x4651924CL}};
                int i, j;
                (*g_1960) = (*g_1960);
                (*g_275) = (((((safe_add_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_u(0xD5L, (safe_mul_func_uint16_t_u_u((safe_unary_minus_func_int16_t_s(((((safe_lshift_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((p_17 , ((l_2046[3][0] &= l_2045[1][1]) != p_18)), (safe_add_func_int32_t_s_s((safe_add_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s((l_2045[1][1] <= (safe_mod_func_uint8_t_u_u((safe_div_func_int32_t_s_s((((&g_1156 == l_2057) , ((((void*)0 == l_2058) & (**p_16)) <= (**p_16))) >= (-1L)), p_18)), 1UL))), p_15)), (-1L))), 0UL)))) && 0x08693C25L), 15)) != (***g_1960)) > (-1L)) || p_17))), l_2024)))) || p_17), 0xCA2AL)) , (void*)0) == l_2059[5]) > p_17) < p_17);
                for (g_1128 = 0; (g_1128 <= 1); g_1128 += 1)
                { /* block id: 863 */
                    uint32_t l_2060 = 0UL;
                    union U0 **l_2065 = &g_185;
                    int32_t l_2071 = 0x30A6D461L;
                    int16_t * const *l_2078[10][6] = {{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065}};
                    int i, j;
                    (*g_275) |= ((**p_16) | (-9L));
                    if ((((**g_1064) = (l_2060 & ((safe_rshift_func_int16_t_s_u((-1L), 0)) | ((((((!(l_2024 = 0xB330CFEF66F2FC99LL)) == p_15) && ((((void*)0 == l_2064) , (void*)0) == l_2065)) ^ (0xB9DDA26858079396LL != p_15)) > (*g_275)) < 0xC870D1841160C006LL)))) <= 65532UL))
                    { /* block id: 867 */
                        uint32_t l_2082 = 18446744073709551615UL;
                        (*g_275) &= (g_2066 , (safe_mod_func_uint8_t_u_u((((safe_lshift_func_uint8_t_u_u((l_1800[2] ^= p_17), 6)) , (l_2071 |= (l_2045[0][1] , 0x57A549BDA14E7E31LL))) > (l_2082 = (((*g_20) != (((((l_2046[3][0] | (safe_mod_func_int32_t_s_s((-8L), l_2074))) <= ((safe_div_func_int16_t_s_s((((((l_2079[4][7] &= (l_2024 = (l_2077 != l_2078[9][2]))) || l_1818) >= 65535UL) > 0x72D1AE7AL) <= 0x9A7EL), 0xC65CL)) < l_2033)) <= p_15) , l_2080) , (**g_1155))) > g_2081))), (*g_1962))));
                        (*g_275) = 3L;
                        if ((**p_16))
                            break;
                        if (g_2083[1])
                            continue;
                    }
                    else
                    { /* block id: 877 */
                        if ((*g_20))
                            break;
                        (*g_275) |= (safe_mul_func_uint8_t_u_u(0x34L, ((((safe_add_func_int32_t_s_s(((((*l_2058) = ((**g_1064) | (l_2088 != l_2089))) == (g_408[8] = ((g_2090 = &g_19) != (void*)0))) && (safe_lshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_s(((safe_div_func_int32_t_s_s((0UL < p_18), ((((safe_rshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_u((((**l_2088) , l_2024) != l_1800[0]), 0)) >= 0UL), p_15)) , (*g_19)) == (void*)0) | l_2024))) >= p_18), 11)), 7))), (*g_20))) , l_2033) ^ 1L) != 0x74B4BCE18E90175CLL)));
                    }
                    (*g_19) = func_30((((p_15 , (safe_mod_func_uint16_t_u_u(0xE10EL, (safe_add_func_int64_t_s_s((l_2024 && (((-8L) ^ ((*g_1065) ^= (-4L))) & (((void*)0 == &g_1820) == (safe_lshift_func_uint16_t_u_u(((safe_mod_func_int8_t_s_s(l_2071, l_2046[3][0])) && 0xA40BL), 10))))), p_17))))) ^ p_17) < l_2060), (*p_16), (**g_1961));
                    for (g_1905 = 1; (g_1905 >= 0); g_1905 -= 1)
                    { /* block id: 888 */
                        (*g_275) ^= (((((l_1801 , (safe_rshift_func_uint8_t_u_u((((safe_sub_func_int32_t_s_s((l_2077 == (((*l_2058) |= l_2024) , ((((safe_lshift_func_uint8_t_u_u(p_17, 2)) | 0x3C9AL) , (safe_lshift_func_uint16_t_u_s(2UL, 6))) , l_2078[9][2]))), p_15)) , (safe_div_func_int32_t_s_s((l_2074 | p_18), 4294967295UL))) == p_18), 1))) == 0x7DL) <= 1UL) & l_1801) >= (***g_2090));
                    }
                }
            }
            l_2128--;
        }
        if (((p_15 = (safe_lshift_func_int16_t_s_u(((**l_2077) = 0x00A2L), (((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(18446744073709551615UL, (safe_lshift_func_uint8_t_u_u(((l_1818 && (g_2141[2][2][3] , (((*g_275) = ((safe_lshift_func_uint8_t_u_s((safe_div_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u((l_1800[1] & l_2033), (safe_rshift_func_int8_t_s_u(((((*l_2157) = func_25(((*g_4) = func_30(((l_2150 >= ((l_1818 |= (**g_1961)) <= (((safe_sub_func_int64_t_s_s(((l_1927 = (((safe_mod_func_int64_t_s_s(l_2155, l_1803)) == 0UL) | p_17)) , p_15), p_15)) , l_1800[1]) != (-7L)))) > l_2156), &l_1801, g_665[5])), &g_104[2], p_14, p_15)) != (*g_2090)) != (-1L)), p_15)))) , 0x523DCADDL) > (-1L)), p_18)), p_15)) > g_1571[0][4][3].f0)) | 3UL))) , l_2033), 5)))), p_17)), p_18)) | l_2156) < (-3L))))) , g_2159[2][1]))
        { /* block id: 903 */
            int16_t l_2168[5] = {1L,1L,1L,1L,1L};
            int32_t l_2170[4][10][6] = {{{0xA130ACF1L,0x258FFC12L,0L,0x821C75A4L,5L,0xCFBF7B5BL},{0x63EB4B7AL,1L,0xFEC47B7AL,0xFEC47B7AL,1L,0x63EB4B7AL},{0xCFBF7B5BL,5L,0x821C75A4L,(-2L),0x63EB4B7AL,1L},{0xFEC47B7AL,0xAED3EF12L,0x0DCE50D7L,9L,6L,0L},{0xFEC47B7AL,0xA130ACF1L,9L,(-2L),0x0DCE50D7L,0x821C75A4L},{5L,0x63EB4B7AL,1L,1L,1L,0x63EB4B7AL},{0xAED3EF12L,0xCFBF7B5BL,0xE1C9418EL,0xCB1593AEL,(-1L),0xAED3EF12L},{1L,(-2L),0xA3349E90L,0x0DCE50D7L,0x63EB4B7AL,0L},{0L,(-2L),8L,9L,(-1L),1L},{0x821C75A4L,0xCFBF7B5BL,9L,1L,1L,9L}},{{0x63EB4B7AL,0x63EB4B7AL,0xAED3EF12L,0xE1C9418EL,0x0DCE50D7L,0x85954F18L},{0xAED3EF12L,0xA130ACF1L,0x78C84C85L,0xA3349E90L,6L,0xAED3EF12L},{0L,0xAED3EF12L,0x78C84C85L,8L,0x63EB4B7AL,0x85954F18L},{1L,8L,0xAED3EF12L,9L,0x258FFC12L,9L},{9L,0x258FFC12L,9L,0xAED3EF12L,8L,1L},{0x85954F18L,0x63EB4B7AL,8L,0x78C84C85L,0xAED3EF12L,0L},{0xAED3EF12L,6L,0xA3349E90L,0x78C84C85L,0xA130ACF1L,0xAED3EF12L},{0x85954F18L,0x0DCE50D7L,0xE1C9418EL,0xAED3EF12L,0x63EB4B7AL,0x63EB4B7AL},{9L,1L,1L,9L,0xCFBF7B5BL,0x821C75A4L},{1L,(-1L),9L,8L,(-2L),0L}},{{0L,0x63EB4B7AL,0x0DCE50D7L,0xA3349E90L,(-2L),1L},{0xAED3EF12L,(-1L),0xCB1593AEL,0xE1C9418EL,0xCFBF7B5BL,0xAED3EF12L},{0x63EB4B7AL,1L,1L,1L,0x63EB4B7AL,5L},{0x821C75A4L,0x0DCE50D7L,(-2L),9L,0xA130ACF1L,0xFEC47B7AL},{0L,6L,9L,0x0DCE50D7L,0xAED3EF12L,0xFEC47B7AL},{1L,0x63EB4B7AL,(-2L),0xCB1593AEL,8L,5L},{0xAED3EF12L,0x258FFC12L,1L,1L,0x258FFC12L,0xAED3EF12L},{5L,8L,0xCB1593AEL,(-2L),0x63EB4B7AL,1L},{0xFEC47B7AL,0xAED3EF12L,0x0DCE50D7L,9L,6L,0L},{0xFEC47B7AL,0xA130ACF1L,9L,(-2L),0x0DCE50D7L,0x821C75A4L}},{{5L,0x63EB4B7AL,1L,1L,1L,0x63EB4B7AL},{0xAED3EF12L,0xCFBF7B5BL,0xE1C9418EL,0xCB1593AEL,(-1L),0xAED3EF12L},{1L,(-2L),0xA3349E90L,0x0DCE50D7L,0x63EB4B7AL,0L},{0L,(-2L),8L,9L,(-1L),1L},{0x821C75A4L,5L,0xA3349E90L,9L,9L,0xA3349E90L},{0xAED3EF12L,0xAED3EF12L,0L,0xA130ACF1L,1L,1L},{0L,1L,(-1L),0xCFBF7B5BL,0L,0L},{(-2L),0L,(-1L),0x821C75A4L,0xAED3EF12L,1L},{0x78C84C85L,0x821C75A4L,0L,0xA3349E90L,0x63EB4B7AL,0xA3349E90L},{0xA3349E90L,0x63EB4B7AL,0xA3349E90L,0L,0x821C75A4L,0x78C84C85L}}};
            int8_t l_2171 = 0x1DL;
            union U1 ***l_2184 = &g_1819;
            const uint32_t l_2221 = 18446744073709551615UL;
            int i, j, k;
            for (p_15 = 0; (p_15 <= 3); p_15 += 1)
            { /* block id: 906 */
                int64_t l_2164 = 0x89E635219DD48334LL;
                int32_t l_2167 = 9L;
                int32_t l_2169[9][8][3] = {{{(-1L),(-1L),9L},{1L,0x82150C06L,(-1L)},{0L,0L,0xCB922D4DL},{(-4L),0x35563806L,0x6F9448B1L},{0x35563806L,9L,0x11E251C8L},{0x35563806L,(-1L),0L},{(-4L),(-4L),1L},{0L,0xE05C0E06L,1L}},{{1L,(-1L),0xC0BC5042L},{(-1L),0xC0BC5042L,(-1L)},{1L,1L,0xC0BC5042L},{0xE7E5C911L,1L,1L},{1L,(-9L),1L},{(-1L),1L,0L},{0x93F941D6L,(-1L),0x11E251C8L},{0xE05C0E06L,(-1L),0x6F9448B1L}},{{0xCB922D4DL,1L,0xCB922D4DL},{0x78667223L,(-9L),(-1L)},{(-4L),1L,9L},{0L,1L,0x93F941D6L},{(-1L),0xC0BC5042L,1L},{0L,(-1L),(-1L)},{(-4L),0xE05C0E06L,1L},{0x78667223L,(-4L),0x35563806L}},{{0xCB922D4DL,(-1L),(-9L)},{0xE05C0E06L,9L,(-9L)},{0x93F941D6L,0x35563806L,0x35563806L},{(-1L),0L,1L},{1L,0x82150C06L,(-1L)},{0xE7E5C911L,(-1L),1L},{1L,0x11E251C8L,0x93F941D6L},{(-1L),(-1L),9L}},{{1L,0x82150C06L,(-1L)},{0L,0L,0xCB922D4DL},{(-4L),0x35563806L,0x6F9448B1L},{0x35563806L,9L,0x11E251C8L},{0x35563806L,(-1L),0L},{(-4L),(-4L),1L},{0L,0xE05C0E06L,1L},{1L,(-1L),0xC0BC5042L}},{{(-1L),0xC0BC5042L,(-1L)},{1L,1L,0xC0BC5042L},{0xE7E5C911L,1L,1L},{1L,(-9L),1L},{(-1L),1L,0L},{0x93F941D6L,(-1L),0x11E251C8L},{0xE05C0E06L,(-1L),0x6F9448B1L},{0xCB922D4DL,1L,0xCB922D4DL}},{{0x78667223L,(-9L),(-1L)},{(-4L),1L,9L},{0L,1L,0x93F941D6L},{(-1L),0xC0BC5042L,1L},{(-4L),0L,0L},{1L,(-1L),(-7L)},{1L,0x6D845AF4L,(-1L)},{0xE7E5C911L,(-1L),0x78667223L}},{{(-1L),1L,0x78667223L},{0x35563806L,(-1L),(-1L)},{0L,(-4L),(-7L)},{0x93F941D6L,0xC0BC5042L,0L},{0xFB0EE668L,0x82150C06L,(-1L)},{(-4L),1L,0x35563806L},{(-1L),0x82150C06L,1L},{0x11E251C8L,0xC0BC5042L,0x6F9448B1L}},{{9L,(-4L),0xE7E5C911L},{0x6D845AF4L,(-1L),(-9L)},{(-1L),1L,1L},{(-1L),(-1L),9L},{0x6D845AF4L,0x6D845AF4L,(-4L)},{9L,(-1L),0x93F941D6L},{0x11E251C8L,0L,1L},{(-1L),1L,0L}}};
                uint32_t l_2179[4] = {4294967290UL,4294967290UL,4294967290UL,4294967290UL};
                int32_t *l_2223 = &l_1918;
                int32_t *l_2224 = &l_1800[1];
                int32_t *l_2225[7][5][5] = {{{&l_1929,&l_1926,&l_1929,&g_10[2][6][4],&g_104[4]},{(void*)0,&l_2033,&l_2173,&l_2169[7][1][2],(void*)0},{(void*)0,&l_2174,&g_104[8],(void*)0,&l_1918},{(void*)0,&g_104[2],&l_2173,(void*)0,&l_1917},{(void*)0,&l_1800[1],&l_1929,(void*)0,&l_2169[1][6][1]}},{{&g_104[2],&l_2169[7][1][2],&l_2170[0][5][1],(void*)0,(void*)0},{&g_103,(void*)0,&l_1918,&l_1918,(void*)0},{&g_10[2][6][4],&l_2173,(void*)0,&l_2169[7][1][2],&l_2177},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_2177,(void*)0,&l_1818,&l_2173,&l_1917}},{{(void*)0,&l_1917,&g_103,&l_1918,&l_1929},{&g_10[2][6][4],&g_47[5][1][1],&l_2177,&g_47[2][8][2],(void*)0},{&g_103,&l_2176,&l_1800[1],&l_2177,&g_104[4]},{&g_104[2],&l_2177,&l_2177,&g_104[2],&l_2173},{(void*)0,(void*)0,(void*)0,&g_104[4],&l_2176}},{{(void*)0,&g_104[4],&l_2173,&l_2173,&l_2169[4][7][2]},{(void*)0,&l_2177,&g_103,&g_104[4],&g_104[2]},{(void*)0,&l_2169[7][1][2],(void*)0,&g_104[2],&l_2169[7][1][2]},{&l_1929,(void*)0,&l_2169[1][6][1],&l_2177,&l_2174},{&g_104[4],&l_1818,(void*)0,&g_47[2][8][2],(void*)0}},{{&l_2174,&l_2174,&g_47[5][1][1],&l_1918,&l_2176},{&l_2173,&l_1917,&l_2176,&l_2173,&g_10[2][6][4]},{&l_1918,&l_1917,&l_1929,(void*)0,&l_2167},{(void*)0,&l_1917,&l_1800[1],&l_2169[7][1][2],(void*)0},{&l_1918,&l_2174,&g_104[2],&l_1918,&l_1918}},{{&l_2169[4][7][2],&l_1818,&l_1929,&l_2033,&g_104[2]},{&g_103,&l_1917,(void*)0,&l_1917,&g_103},{&l_1917,&l_1818,&l_2177,&l_1929,&l_1800[0]},{&l_1929,&g_47[5][1][1],&g_104[8],&g_104[2],&g_47[5][1][1]},{&l_1928,&g_2004.f3,(void*)0,&l_1818,&l_1800[0]}},{{&l_2174,&g_104[2],&l_2167,(void*)0,&g_103},{&l_1800[0],(void*)0,&l_1917,&l_1928,&g_104[2]},{&l_1917,&l_2169[1][6][1],&l_1918,&l_2177,&l_2177},{&l_1928,(void*)0,&l_1928,&l_1800[1],&l_2033},{&l_1929,(void*)0,&l_2174,&l_1918,&l_2178}}};
                int i, j, k;
                for (g_94 = 3; (g_94 >= 0); g_94 -= 1)
                { /* block id: 909 */
                    int16_t ***l_2162[4][10] = {{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064}};
                    int32_t *l_2165 = &g_104[3];
                    int32_t *l_2166[4] = {&g_104[2],&g_104[2],&g_104[2],&g_104[2]};
                    union U1 ***l_2194[2][10][5] = {{{&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&l_1835},{&g_1819,&l_1835,&g_1819,&g_1836[1][0],&g_1836[1][0]},{&g_1836[1][0],&l_1835,(void*)0,&g_1836[1][0],(void*)0},{(void*)0,&g_1836[1][0],&g_1819,&g_1836[1][0],(void*)0},{(void*)0,&l_1835,&g_1836[1][0],&g_1836[1][0],(void*)0},{(void*)0,&g_1836[0][1],(void*)0,&g_1836[1][0],&g_1836[1][0]},{(void*)0,&l_1835,(void*)0,&l_1835,&l_1835},{&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&l_1835},{&g_1819,&l_1835,&g_1819,&g_1836[1][0],&g_1836[1][0]},{&g_1836[1][0],&l_1835,(void*)0,&g_1836[1][0],(void*)0}},{{(void*)0,&g_1836[1][0],&g_1819,&g_1836[1][0],(void*)0},{(void*)0,&l_1835,&g_1836[1][0],&g_1836[1][0],(void*)0},{(void*)0,&g_1836[0][1],(void*)0,&g_1836[1][0],&g_1836[1][0]},{(void*)0,&l_1835,(void*)0,&l_1835,&l_1835},{&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&g_1836[1][0],&l_1835},{&g_1819,&l_1835,&g_1819,&g_1836[1][0],&g_1836[1][0]},{&g_1836[1][0],&l_1835,(void*)0,&g_1836[1][0],(void*)0},{(void*)0,&g_1836[1][0],&g_1819,&g_1836[1][0],(void*)0},{(void*)0,&l_1835,&g_1836[1][0],&g_1836[1][0],(void*)0},{(void*)0,&g_1836[0][1],(void*)0,&g_1836[1][0],(void*)0}}};
                    uint16_t l_2216 = 0x7521L;
                    int i, j, k;
                    g_2163 ^= (safe_lshift_func_int8_t_s_s(p_15, (0x82D50EB43A0534DALL & (&g_753[3][4] == l_2162[2][2]))));
                    l_2179[2]++;
                    for (g_233 = 3; (g_233 >= 0); g_233 -= 1)
                    { /* block id: 914 */
                        int32_t *l_2192 = &g_2172;
                        const int32_t l_2193 = 0xDE88E6AFL;
                        int32_t l_2197 = (-9L);
                        int32_t l_2214 = 0L;
                        int32_t l_2215 = 0x1DDC82D9L;
                        int i;
                        (*l_2088) = (*l_2088);
                        l_1800[1] = (((*l_1817) = l_2182[2]) || (safe_unary_minus_func_int16_t_s(((*g_1065) &= ((l_2184 = &l_1835) != (((safe_div_func_uint64_t_u_u(0xAB4AE8343DD389ACLL, (safe_add_func_uint8_t_u_u(p_18, (0xF4955D7BL || ((*g_275) = (safe_mod_func_int8_t_s_s(((*l_2165) , (-3L)), (((((~(l_2192 == (void*)0)) ^ p_15) >= p_15) | l_2179[1]) || p_18))))))))) >= l_2193) , l_2194[0][4][0]))))));
                        if (l_2167)
                            break;
                        (*l_2165) = (safe_unary_minus_func_int16_t_s(((l_2197 = l_2196) , ((safe_mod_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(p_18, (safe_mul_func_int8_t_s_s((((l_2197 = 0L) ^ (safe_mul_func_int8_t_s_s(0xB2L, (safe_lshift_func_int16_t_s_u((safe_rshift_func_int8_t_s_u(((safe_sub_func_uint32_t_u_u(((*g_811) , ((safe_mul_func_int16_t_s_s(((**g_1961) == p_15), (++l_2216))) ^ p_15)), ((safe_rshift_func_int8_t_s_s(l_2170[2][3][2], 7)) ^ l_2171))) , (***g_1960)), l_2193)), 15))))) , (***g_1960)), g_408[8])))) , l_2221), p_15)) | p_15))));
                    }
                    l_2222 = ((**l_2184) = l_2222);
                }
                l_2228++;
            }
            for (l_2175 = 0; l_2175 < 1; l_2175 += 1)
            {
                for (g_2066.f3 = 0; g_2066.f3 < 7; g_2066.f3 += 1)
                {
                    l_2226[l_2175][g_2066.f3] = 0x5279585DL;
                }
            }
        }
        else
        { /* block id: 933 */
            uint32_t l_2231 = 0x416CB1C4L;
            int32_t l_2236 = 0x3415A647L;
            uint64_t l_2248 = 18446744073709551615UL;
            union U0 ** const *l_2284[6][1][3];
            int8_t * const *l_2299 = &g_2253;
            int8_t * const **l_2298 = &l_2299;
            int32_t l_2307 = 4L;
            int32_t l_2311 = 0x5900BA01L;
            uint8_t l_2317 = 0x67L;
            int32_t *l_2330 = &l_1927;
            int8_t l_2353 = 0L;
            int32_t l_2382 = (-4L);
            int64_t l_2402 = (-3L);
            int64_t l_2403 = 0x353488CEE08E4523LL;
            int i, j, k;
            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 3; k++)
                        l_2284[i][j][k] = &l_2089;
                }
            }
            for (g_233 = 0; (g_233 >= 0); g_233 -= 1)
            { /* block id: 936 */
                int32_t l_2237 = (-1L);
                int8_t ***l_2276 = &g_2252;
                int16_t ***l_2296[1][2][7] = {{{&l_2077,(void*)0,&l_2077,&g_1064,&g_1064,&l_2077,(void*)0},{&l_2077,(void*)0,&l_2077,&g_1064,&g_1064,&l_2077,(void*)0}}};
                int32_t l_2312 = 0xCA40525DL;
                uint16_t ***l_2352 = &g_818[0];
                uint16_t ****l_2351 = &l_2352;
                int32_t l_2376[9] = {0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL,0xC1A81D8EL};
                uint32_t **l_2385 = &l_1846;
                uint32_t *** const l_2384[8] = {&l_2385,&l_2385,&l_2385,&l_2385,&l_2385,&l_2385,&l_2385,&l_2385};
                int32_t l_2386 = 0xB1E32E7CL;
                uint32_t l_2392 = 4294967295UL;
                uint32_t l_2404 = 0UL;
                int i, j, k;
                for (g_145 = 0; (g_145 <= 2); g_145 += 1)
                { /* block id: 939 */
                    for (g_2006.f3 = 0; (g_2006.f3 <= 9); g_2006.f3 += 1)
                    { /* block id: 942 */
                        int i;
                        if (g_176[g_2006.f3])
                            break;
                        if (g_2083[g_233])
                            continue;
                        --l_2231;
                    }
                    return g_2234;
                }
                if ((*g_275))
                { /* block id: 949 */
                    int32_t *l_2235[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint16_t l_2238 = 0UL;
                    int i;
                    --l_2238;
                }
                else
                { /* block id: 951 */
                    int64_t l_2245 = 0x876A514F412A1E54LL;
                    int8_t ****l_2254 = (void*)0;
                    int8_t ****l_2255 = &l_1816[8];
                    int32_t l_2301[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_2301[i] = 0x026262A0L;
                    if ((2UL && (l_2226[0][5] <= (((safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s(l_2245, (safe_mul_func_int16_t_s_s(((((*l_2011) = (l_2248 , &g_326[1])) == ((safe_div_func_uint64_t_u_u(((&g_1961 == ((*l_2255) = g_2251)) >= ((!(((safe_div_func_uint64_t_u_u((((+3L) & ((((+((safe_div_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u(((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint64_t_u((safe_unary_minus_func_uint16_t_u((((l_2273 == p_18) , p_18) ^ 0xDFE8L))))), (*g_1065))), l_2237)) & 0UL), (***g_2251))), 4L)) < l_2245)) & (*g_1156)) ^ p_17) == 0xB1D6F6295AF4F48FLL)) , 0x61FC705CBADFCFCDLL), p_18)) != l_1800[0]) != p_18)) >= (*g_2092))), l_2236)) , (void*)0)) || 0xB58A1528L), p_15)))), l_2273)) < p_17) | l_2236))))
                    { /* block id: 954 */
                        int8_t ***l_2277 = &g_2252;
                        union U0 ** const **l_2285 = &l_2284[4][0][0];
                        int32_t *l_2297 = &g_2172;
                        (*g_275) &= ((((l_2236 = (safe_sub_func_int8_t_s_s(((((l_2277 = l_2276) != (((*l_2297) &= (safe_sub_func_int16_t_s_s(((((*g_1155) != (*g_1155)) <= (safe_rshift_func_int8_t_s_u((l_2236 > (((*l_2285) = l_2284[4][0][0]) != (void*)0)), 0))) >= (safe_div_func_int32_t_s_s(((safe_sub_func_int16_t_s_s((((safe_lshift_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((0L <= ((*g_1156) , ((safe_mul_func_uint8_t_u_u((((-9L) & 3UL) & 0UL), l_1818)) , l_2237))), l_2226[0][4])), 2)) , l_2296[0][1][3]) != l_2296[0][1][3]), 1UL)) != p_18), (**g_1155)))), p_18))) , l_2298)) || l_2237) > 1L), 0xCFL))) , p_18) != p_15) & l_2245);
                        return g_2300;
                    }
                    else
                    { /* block id: 961 */
                        int32_t *l_2302 = &l_1928;
                        int32_t *l_2303 = &g_47[5][1][1];
                        int32_t *l_2304 = &l_1818;
                        int32_t *l_2305 = &g_1334.f3;
                        int32_t *l_2306 = (void*)0;
                        int32_t *l_2308 = &l_2236;
                        int32_t *l_2309[9] = {&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94,&g_94};
                        int i;
                        l_2313++;
                        --l_2317;
                    }
                    (*g_275) ^= l_2312;
                    l_2312 = (*g_275);
                    for (g_1873.f3 = 0; (g_1873.f3 >= 0); g_1873.f3 -= 1)
                    { /* block id: 969 */
                        uint64_t *l_2324 = &l_2080;
                        uint64_t *l_2327[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_2327[i] = (void*)0;
                        l_2301[0] |= 0x4468A4D6L;
                        l_2330 = func_30((safe_sub_func_uint8_t_u_u(0xF2L, p_18)), &l_1800[1], (safe_mul_func_int8_t_s_s((***g_1960), ((p_18 | ((--(*l_2324)) >= (l_2033 = l_1800[1]))) , (((safe_mod_func_int64_t_s_s(p_18, l_2301[0])) || p_15) == p_15)))));
                    }
                }
                for (g_2234.f0 = 2; (g_2234.f0 >= 0); g_2234.f0 -= 1)
                { /* block id: 978 */
                    int32_t l_2338 = 0x95DF04A7L;
                    uint64_t *l_2377 = &l_2080;
                    uint32_t ***l_2383 = (void*)0;
                    int32_t l_2387[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                    int i;
                    if (((safe_unary_minus_func_int32_t_s((safe_add_func_int16_t_s_s((safe_mul_func_int8_t_s_s(l_2338, 0L)), l_2312)))) != ((*l_2330) >= (((*l_1846) = (((safe_div_func_int32_t_s_s(((**g_810) , (safe_rshift_func_uint8_t_u_u(((p_18 && (safe_mul_func_int16_t_s_s((safe_mod_func_int64_t_s_s(l_2033, (safe_sub_func_int32_t_s_s(((void*)0 == l_2351), (*l_2330))))), 0L))) && p_15), 0))), 5L)) > l_2237) == 0L)) | p_15))))
                    { /* block id: 980 */
                        int32_t l_2388 = (-1L);
                        int32_t l_2389 = 0x62EEB631L;
                        int32_t *l_2390[8][4] = {{&l_2175,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_10[0][4][7],(void*)0},{(void*)0,&l_2175,&g_10[0][4][7],&l_2175},{(void*)0,&l_1926,(void*)0,&g_10[0][4][7]},{&l_2175,&l_1926,&l_1926,&l_2175},{&l_1926,&l_2175,(void*)0,(void*)0},{&l_1926,(void*)0,&l_1926,(void*)0},{&l_2175,(void*)0,(void*)0,(void*)0}};
                        int32_t l_2391 = 0x6DB3027AL;
                        int i, j;
                        (*g_19) = ((*p_14) = (void*)0);
                        (*g_275) ^= l_2353;
                        l_2387[1] ^= ((safe_mul_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((g_176[(g_233 + 2)] = (g_2360 , (p_15 , ((l_2361 <= ((((((safe_mod_func_int64_t_s_s((safe_add_func_int32_t_s_s(l_2237, (((safe_add_func_int16_t_s_s(((*g_1065) |= (safe_div_func_int64_t_s_s(((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((((((safe_div_func_int32_t_s_s(4L, l_2376[3])) , l_2377) == (((safe_mod_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((***g_2251) = ((l_2382 , (l_2383 != l_2384[4])) != 0L)), 0x21L)), l_2312)) ^ p_15) , (*g_941))) ^ 0xDDD2F254E215AE74LL) & p_18) , l_2338), p_15)), (*g_275))) ^ l_2386), p_18))), l_2273)) > (*l_2330)) & p_18))), p_17)) || (*g_2253)) | 0xD064L) , (void*)0) != (void*)0) > (*l_2330))) != l_2338)))), 3)), p_17)) , (-9L)), p_15)) == l_2312);
                        --l_2392;
                    }
                    else
                    { /* block id: 989 */
                        return (*g_811);
                    }
                    (*g_275) ^= p_18;
                    for (l_2237 = 0; (l_2237 <= 2); l_2237 += 1)
                    { /* block id: 995 */
                        int32_t *l_2395 = &l_2236;
                        int32_t *l_2396 = (void*)0;
                        int32_t *l_2397 = &g_1571[0][4][3].f3;
                        int32_t *l_2398 = &g_103;
                        int32_t *l_2399 = &l_1929;
                        int32_t *l_2400 = &l_2387[1];
                        int32_t *l_2401[7] = {&g_1822.f3,&g_1822.f3,&g_1822.f3,&g_1822.f3,&g_1822.f3,&g_1822.f3,&g_1822.f3};
                        int i;
                        l_2404++;
                        l_2376[0] ^= (0L && p_17);
                        (*p_16) = (*g_19);
                    }
                }
            }
            (*g_275) = p_18;
        }
        if ((((void*)0 == &l_1835) < ((**g_1155) & (safe_mul_func_int8_t_s_s((((((safe_add_func_int8_t_s_s(((safe_unary_minus_func_uint64_t_u((((l_2429[5] &= (+(safe_mul_func_int8_t_s_s((safe_add_func_int64_t_s_s((safe_add_func_uint8_t_u_u(p_18, l_2419)), (safe_mod_func_uint8_t_u_u((safe_div_func_uint8_t_u_u(((safe_unary_minus_func_int8_t_s(p_17)) < p_15), (safe_mod_func_uint16_t_u_u((~(l_2428 ^ p_17)), l_1801)))), p_18)))), 0xC2L)))) >= p_15) , l_2182[2]))) ^ p_18), p_15)) < (**g_1064)) >= (*g_1962)) > l_1800[1]) > 1UL), 5L)))))
        { /* block id: 1005 */
            int32_t *l_2430 = (void*)0;
            int32_t *l_2431 = (void*)0;
            int32_t *l_2432 = &l_1800[1];
            int32_t *l_2433[3];
            int i;
            for (i = 0; i < 3; i++)
                l_2433[i] = &l_1818;
            --g_2434;
        }
        else
        { /* block id: 1007 */
            int32_t *l_2439 = &l_1929;
            int32_t *l_2440 = &g_2004.f3;
            int32_t *l_2441 = &g_2006.f3;
            int32_t *l_2442 = (void*)0;
            int32_t *l_2443[10];
            int32_t l_2444 = 1L;
            int16_t l_2448 = 1L;
            uint64_t l_2449[5][9][1] = {{{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL},{18446744073709551615UL},{0x442A0317B286E0B4LL},{18446744073709551615UL}}};
            int i, j, k;
            for (i = 0; i < 10; i++)
                l_2443[i] = &g_2234.f3;
            (*g_275) = (!(0x8EE9L >= ((g_2438 |= ((l_2182[2] == p_15) , (0xF3L | 0UL))) < p_18)));
            l_2449[3][1][0]--;
        }
        ++l_2461[2][2];
    }
    else
    { /* block id: 1013 */
        uint32_t l_2464 = 0x16F756F4L;
        uint64_t l_2481 = 18446744073709551612UL;
        const int32_t *l_2482 = &g_70;
        int32_t l_2502 = 0L;
        int32_t l_2504 = 1L;
        int32_t l_2505 = 0x1B3732FDL;
        int32_t l_2507[10][6][2] = {{{0x912F5EF6L,7L},{0x6E9E9C3DL,0x434F76F5L},{0L,0x434F76F5L},{0x6E9E9C3DL,7L},{0x912F5EF6L,9L},{2L,0x912F5EF6L}},{{0x14332D79L,0x02C5F1F9L},{9L,0x8D217DDDL},{2L,(-1L)},{0x8D217DDDL,7L},{0xD1558E41L,0xD1558E41L},{0L,0x6E9E9C3DL}},{{0x434F76F5L,7L},{0x732DE20DL,0x14332D79L},{2L,0x732DE20DL},{(-1L),0x02C5F1F9L},{(-1L),0x732DE20DL},{2L,0x14332D79L}},{{0x732DE20DL,7L},{0x434F76F5L,0x6E9E9C3DL},{0L,0xD1558E41L},{0xD1558E41L,7L},{0x8D217DDDL,(-1L)},{2L,0x7457613CL}},{{0x9F1B30EEL,0x97A98793L},{6L,0x02C5F1F9L},{0x17C7AC72L,0x9F1B30EEL},{0x02C5F1F9L,0x5EAD4296L},{2L,0L},{0xA4C7E761L,0L}},{{2L,0x5EAD4296L},{0x02C5F1F9L,0x9F1B30EEL},{0x17C7AC72L,0x02C5F1F9L},{6L,0x97A98793L},{0x9F1B30EEL,0x7457613CL},{0x17C7AC72L,1L}},{{0x7457613CL,0x5EAD4296L},{0L,0L},{0xA4C7E761L,2L},{0L,0x5EAD4296L},{7L,6L},{0x17C7AC72L,7L}},{{1L,0x97A98793L},{1L,7L},{0x17C7AC72L,6L},{7L,0x5EAD4296L},{0L,2L},{0xA4C7E761L,0L}},{{0L,0x5EAD4296L},{0x7457613CL,1L},{0x17C7AC72L,0x7457613CL},{0x9F1B30EEL,0x97A98793L},{6L,0x02C5F1F9L},{0x17C7AC72L,0x9F1B30EEL}},{{0x02C5F1F9L,0x5EAD4296L},{2L,0L},{0xA4C7E761L,0L},{2L,0x5EAD4296L},{0x02C5F1F9L,0x9F1B30EEL},{0x17C7AC72L,0x02C5F1F9L}}};
        uint16_t l_2567 = 0xE478L;
        union U1 ***l_2629 = (void*)0;
        const int16_t **l_2645 = (void*)0;
        uint16_t ***l_2646 = &g_818[0];
        int32_t l_2647[3];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2647[i] = 1L;
        if (l_2464)
        { /* block id: 1014 */
            for (l_2156 = 0; (l_2156 > 49); l_2156 = safe_add_func_uint16_t_u_u(l_2156, 3))
            { /* block id: 1017 */
                return g_2467[7][3];
            }
            return g_2468[4];
        }
        else
        { /* block id: 1021 */
            const int16_t l_2479 = 0x5346L;
            uint64_t *l_2480 = &g_1969;
            (*g_275) = ((-8L) & (((0x3735L || (0x7A613940569971F0LL | ((safe_sub_func_uint32_t_u_u(((l_2471 , (p_15 != ((7L && ((*l_2480) = (!(((p_18 && (l_2458 ^ ((safe_mul_func_uint16_t_u_u(((safe_add_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u(p_18, l_2273)), 0x9931891DL)) == (**g_19)), 0UL)) && l_2479))) > 4UL) & l_2273)))) && l_2313))) , (*g_1156)), 4294967286UL)) > p_15))) > l_2464) == l_2481));
        }
        for (l_2310 = 3; (l_2310 >= 0); l_2310 -= 1)
        { /* block id: 1027 */
            int16_t * const *l_2487 = &g_1065;
            int16_t * const **l_2486[9][1] = {{(void*)0},{&l_2487},{(void*)0},{&l_2487},{(void*)0},{&l_2487},{(void*)0},{&l_2487},{(void*)0}};
            int16_t * const ***l_2485 = &l_2486[4][0];
            int32_t l_2491 = 7L;
            int32_t l_2499[2];
            int32_t l_2510 = 0x6B3EF9D1L;
            int32_t *l_2562 = &g_2234.f3;
            int32_t *l_2563 = &l_2033;
            int32_t *l_2564 = &g_1334.f3;
            int32_t *l_2565 = &g_2467[7][3].f3;
            int32_t *l_2566[6] = {&g_104[5],&g_104[5],&g_104[5],&g_104[5],&g_104[5],&g_104[5]};
            int8_t **l_2583 = &l_1794[1];
            uint8_t l_2589 = 247UL;
            int64_t ****l_2614[8][4][8] = {{{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{(void*)0,&l_2011,&l_2011,(void*)0,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011}},{{&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,(void*)0,(void*)0,(void*)0,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011}},{{&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011}},{{&l_2011,&l_2011,&l_2011,(void*)0,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,(void*)0,(void*)0,&l_2011,&l_2011,&l_2011},{(void*)0,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,&l_2011}},{{(void*)0,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011}},{{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,(void*)0,(void*)0,(void*)0},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,(void*)0,&l_2011,(void*)0,(void*)0,&l_2011}},{{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,(void*)0},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{(void*)0,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011}},{{&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,(void*)0,(void*)0,(void*)0,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,&l_2011,&l_2011},{&l_2011,&l_2011,(void*)0,&l_2011,&l_2011,&l_2011,(void*)0,&l_2011}}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_2499[i] = 0xC5DA8774L;
            for (l_2481 = 0; (l_2481 <= 3); l_2481 += 1)
            { /* block id: 1030 */
                int32_t l_2490 = 0L;
                uint64_t *l_2496 = &g_441;
                int32_t l_2500 = 0xEAE4C70BL;
                int32_t l_2501 = 0xDFB7ED7DL;
                int32_t l_2503 = (-4L);
                int32_t l_2508 = 0xE7B19444L;
                int32_t l_2509[6][10] = {{(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L},{(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L},{(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L},{(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L},{(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L},{(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L,(-3L),0L}};
                uint32_t *l_2515 = &l_2464;
                int i, j;
                (*p_14) = func_30(((p_18 = ((*l_1846) = 1UL)) > l_2182[l_2310]), l_2482, (safe_div_func_uint32_t_u_u((((l_2182[(l_2481 + 5)] > (l_2485 == (void*)0)) <= l_2182[(l_2310 + 6)]) | (safe_mul_func_int16_t_s_s((l_2490 ^= 0x9AB7L), (l_2491 &= (0xAEL != 0L))))), p_17)));
                if ((((safe_rshift_func_uint16_t_u_u(((p_15 | ((*l_2496)--)) , l_1803), (l_2182[(l_2310 + 6)] , (g_2511--)))) ^ (((*l_2515) = (safe_unary_minus_func_int16_t_s(0x4E06L))) , ((((safe_mul_func_uint16_t_u_u(0x794EL, l_2499[0])) >= ((safe_rshift_func_uint16_t_u_s(l_2182[(l_2310 + 6)], (0x6EL != l_2510))) ^ 5L)) , 0x3C79L) == 0xAD88L))) , l_2182[(l_2481 + 5)]))
                { /* block id: 1039 */
                    int32_t *l_2533 = (void*)0;
                    int32_t *l_2534 = &l_2510;
                    l_2033 = ((*g_275) && (g_2520 , ((--(*l_1846)) == (l_2182[(l_2310 + 6)] != ((((safe_add_func_int16_t_s_s(((*g_275) , p_15), (((p_18++) ^ ((*l_2534) = (safe_div_func_int64_t_s_s((((**p_14) > ((safe_mul_func_int16_t_s_s((safe_add_func_uint8_t_u_u((*l_2482), (*g_2253))), l_2509[0][7])) ^ (**p_14))) < (**g_1961)), 0x6861E9E8E485553DLL)))) & (*l_2482)))) && 18446744073709551611UL) == p_15) <= p_15)))));
                }
                else
                { /* block id: 1044 */
                    int8_t l_2546[5][9] = {{0L,8L,0L,0L,5L,5L,0L,0L,8L},{8L,0L,0L,5L,5L,0L,0L,8L,0L},{0x8AL,0L,0L,0L,0L,0x8AL,5L,0x8AL,0L},{0x8AL,0L,0L,0x8AL,8L,0L,8L,0x8AL,0L},{8L,8L,5L,0L,(-8L),0L,5L,8L,8L}};
                    uint8_t *l_2547 = &g_665[5];
                    uint8_t *l_2548 = &g_1128;
                    uint32_t l_2561 = 18446744073709551607UL;
                    int i, j;
                    (*g_275) |= (safe_rshift_func_uint8_t_u_u((l_2537 != ((~(safe_mul_func_uint8_t_u_u(((((void*)0 == &l_1802[3][0][3]) >= ((*l_2548) = (safe_lshift_func_int16_t_s_u(((safe_sub_func_uint32_t_u_u((((~0x3DL) >= ((6L >= (l_2510 = (((*l_2547) = ((0x5007E10BCC332995LL > ((p_15 , ((g_2434 = p_15) == (0x1A695EB7L ^ 5L))) & (*l_2482))) == l_2546[0][7])) >= 255UL))) <= p_15)) ^ p_18), 0xE5A96099L)) | (*g_1156)), p_18)))) , 255UL), 0x06L))) , (void*)0)), 7));
                    if ((***g_2090))
                        continue;
                    (*g_275) = ((p_15 && ((**l_2011) == (g_326[1] = &g_2438))) , (safe_div_func_uint64_t_u_u(((!((p_18 , (((l_2499[0] != (*l_2482)) <= ((((~(((((safe_mod_func_uint64_t_u_u(0x3ED6D21F03F494C6LL, (safe_rshift_func_int16_t_s_u(1L, 0)))) , l_2182[(l_2310 + 6)]) > l_2501) && l_2491) == 0L)) > l_2156) >= 18446744073709551613UL) , l_2561)) ^ l_2561)) , p_17)) != 1L), p_15)));
                }
                (*g_275) = 0xDF7EEBACL;
            }
            l_2567++;
            l_2504 ^= (safe_mod_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_s(((~(p_17 & ((safe_add_func_uint32_t_u_u((((((*l_2562) = (safe_rshift_func_int8_t_s_u((p_17 , (((((p_15 || (safe_lshift_func_uint8_t_u_u(((((***g_2251) &= 1L) >= ((l_2507[8][5][1] = 1UL) != ((void*)0 != l_2583))) , (safe_lshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_u(l_2471, 5)), (((**g_1064) = (((((void*)0 == &g_1720[0]) , l_2588) == (void*)0) ^ p_18)) || (*l_2563))))), 3))) ^ p_17) != p_15) | l_2589) <= (**p_16))), 6))) >= l_2458) , 0x3DL) || (*g_2253)), 0xC10600B5L)) < 5UL))) == (*l_2482)), (*l_2482))), 2)), p_15));
            for (l_2471 = 0; (l_2471 <= 2); l_2471 += 1)
            { /* block id: 1064 */
                int16_t l_2597 = 0x9356L;
                int32_t l_2601 = (-1L);
                int32_t l_2623 = 0x1652F7DEL;
                int32_t l_2624 = 0L;
                uint32_t l_2626 = 18446744073709551608UL;
                for (g_2081 = 0; (g_2081 <= 2); g_2081 += 1)
                { /* block id: 1067 */
                    uint32_t l_2603 = 8UL;
                    int16_t l_2620 = 3L;
                    int32_t l_2621 = 0x18E1838BL;
                    int32_t l_2622 = (-1L);
                    int32_t l_2625 = 0xFD4A3D45L;
                    int32_t l_2630 = 8L;
                    if ((*g_275))
                    { /* block id: 1068 */
                        uint8_t *l_2598[7];
                        int32_t l_2599 = 1L;
                        int32_t l_2600 = (-1L);
                        int32_t l_2602 = (-10L);
                        uint32_t l_2609 = 0x2FF346BDL;
                        int64_t *****l_2615 = &l_2614[5][2][7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_2598[i] = &g_665[5];
                        if ((***g_2090))
                            break;
                        if ((**p_16))
                            break;
                        (*g_275) = ((*l_2562) = ((((*l_2563) |= (g_2590[0][3] , (safe_add_func_uint16_t_u_u((l_2502 = ((safe_mod_func_int16_t_s_s((l_2601 = (safe_div_func_uint8_t_u_u((--l_2603), l_2226[0][4]))), (~p_17))) != (((*l_2482) == (safe_add_func_int16_t_s_s(((l_2609 , (safe_mod_func_int16_t_s_s((safe_add_func_int64_t_s_s((((*l_2615) = l_2614[1][3][0]) != &g_1361), ((safe_lshift_func_uint8_t_u_s((safe_sub_func_int64_t_s_s((((*g_2253) = p_17) ^ (--l_2626)), ((void*)0 != l_2629))), l_2182[2])) & l_2630))), 7L))) >= l_2597), p_18))) & 18446744073709551612UL))), p_15)))) < 6UL) && l_2623));
                        return g_2631;
                    }
                    else
                    { /* block id: 1081 */
                        (*g_810) = (*g_1819);
                    }
                    (*g_275) ^= (0xF1A1L < (*l_2482));
                }
                for (g_768.f3 = 0; (g_768.f3 <= 4); g_768.f3 += 1)
                { /* block id: 1088 */
                    int16_t **l_2632 = &g_1065;
                    for (g_2434 = 0; (g_2434 <= 8); g_2434 += 1)
                    { /* block id: 1091 */
                        int i;
                        l_2077 = l_2632;
                        if (g_1963[(g_768.f3 + 1)])
                            continue;
                    }
                }
            }
        }
        l_1800[1] = ((((*l_2646) = ((((safe_add_func_uint64_t_u_u(l_2182[2], ((safe_add_func_int16_t_s_s(((*g_1961) != (void*)0), l_2458)) & ((safe_rshift_func_int8_t_s_s((+p_15), ((safe_div_func_uint8_t_u_u(1UL, (*l_2482))) < ((*g_1065) = (((~((void*)0 != l_2645)) < (**p_16)) && (-1L)))))) == 2UL)))) || 0x5E520784174A563BLL) | (-8L)) , &g_819)) != &g_819) && l_2647[0]);
    }
    if (l_2226[0][5])
    { /* block id: 1102 */
        (*g_275) &= (&g_1836[1][0] != (void*)0);
    }
    else
    { /* block id: 1104 */
        int32_t l_2675[8][3] = {{1L,9L,1L},{1L,7L,0x2A6C98B1L},{1L,0xCB49D6BEL,(-1L)},{1L,9L,1L},{1L,7L,0x2A6C98B1L},{1L,0xCB49D6BEL,(-1L)},{1L,9L,1L},{1L,7L,0x2A6C98B1L}};
        union U0 **l_2680 = &g_767;
        uint16_t ** const *l_2681 = &g_818[3];
        uint16_t ** const **l_2682 = &l_2681;
        uint64_t *l_2683[10][6][4] = {{{&g_441,&l_2313,&l_2313,&g_1969},{&g_1969,&g_253,&g_441,&l_2313},{&l_2313,&g_441,&g_441,&l_2313},{&g_1969,(void*)0,&l_2313,(void*)0},{&g_441,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_253,(void*)0}},{{&g_441,(void*)0,&g_253,(void*)0},{&g_1969,(void*)0,(void*)0,&l_2313},{&g_253,&g_441,&l_2313,&l_2313},{&g_253,&g_253,(void*)0,&g_1969},{&g_1969,&l_2313,&g_253,(void*)0},{&g_441,&g_441,&g_253,&g_253}},{{(void*)0,&g_441,(void*)0,(void*)0},{&g_441,&l_2313,&l_2313,&g_1969},{&g_1969,&g_253,&g_441,&l_2313},{&l_2313,&g_441,&g_441,&l_2313},{&g_1969,(void*)0,&l_2313,(void*)0},{&g_441,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_253,(void*)0},{&g_441,(void*)0,&g_253,(void*)0},{&g_1969,(void*)0,(void*)0,&l_2313},{&g_253,&g_441,&l_2313,&l_2313},{&g_253,&g_253,(void*)0,&g_1969},{&g_1969,&l_2313,&g_253,(void*)0}},{{&g_441,&g_441,&g_253,(void*)0},{&l_2313,&g_1969,&l_2313,(void*)0},{&g_1969,&g_441,&g_253,(void*)0},{(void*)0,(void*)0,&l_2313,&g_441},{&g_253,&l_2313,&l_2313,&g_253},{(void*)0,(void*)0,&g_253,&l_2313}},{{&g_1969,&l_2313,&l_2313,&g_441},{&l_2313,&g_441,&g_1969,&g_441},{&l_2313,&l_2313,(void*)0,&l_2313},{(void*)0,(void*)0,&g_441,&g_253},{(void*)0,&l_2313,&g_441,&g_441},{(void*)0,(void*)0,&g_441,(void*)0}},{{(void*)0,&g_441,(void*)0,(void*)0},{&l_2313,&g_1969,&g_1969,(void*)0},{&l_2313,&g_1969,&l_2313,(void*)0},{&g_1969,&g_441,&g_253,(void*)0},{(void*)0,(void*)0,&l_2313,&g_441},{&g_253,&l_2313,&l_2313,&g_253}},{{(void*)0,(void*)0,&g_253,&l_2313},{&g_1969,&l_2313,&l_2313,&g_441},{&l_2313,&g_441,&g_1969,&g_441},{&l_2313,&l_2313,(void*)0,&l_2313},{(void*)0,(void*)0,&g_441,&g_253},{(void*)0,&l_2313,&g_441,&g_441}},{{(void*)0,(void*)0,&g_441,(void*)0},{(void*)0,&g_441,(void*)0,(void*)0},{&l_2313,&g_1969,&g_1969,(void*)0},{&l_2313,&g_1969,&l_2313,(void*)0},{&g_1969,&g_441,&g_253,(void*)0},{(void*)0,(void*)0,&l_2313,&g_441}},{{&g_253,&l_2313,&l_2313,&g_253},{(void*)0,(void*)0,&g_253,&l_2313},{&g_1969,&l_2313,&l_2313,&g_441},{&l_2313,&g_441,&g_1969,&g_441},{&l_2313,&l_2313,(void*)0,&l_2313},{(void*)0,(void*)0,&g_441,&g_253}}};
        int32_t l_2684 = (-9L);
        int64_t ****l_2693 = &l_2011;
        int64_t *****l_2694[9][3][1] = {{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}},{{&l_2693},{&l_2693},{&l_2693}}};
        int64_t ****l_2695 = &l_2011;
        uint16_t l_2696 = 1UL;
        int i, j, k;
        for (g_103 = (-2); (g_103 == (-17)); g_103 = safe_sub_func_int64_t_s_s(g_103, 1))
        { /* block id: 1107 */
            uint32_t l_2652 = 0x7B1C1C88L;
            int8_t ***l_2673 = &l_1793;
            l_1818 = 0xF7929CC5L;
            for (p_15 = (-14); (p_15 >= 22); ++p_15)
            { /* block id: 1111 */
                uint32_t l_2653 = 0x100F4CCDL;
                int16_t **l_2656 = &g_1065;
                int16_t **l_2663[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int i;
                l_2653 |= (((*g_2253) = l_2652) && (0L || l_2652));
                for (g_768.f3 = 0; (g_768.f3 != (-7)); --g_768.f3)
                { /* block id: 1116 */
                    int16_t ***l_2662 = &l_2656;
                    int8_t ****l_2674 = &g_2251;
                    int32_t l_2676[9][5][5] = {{{0L,1L,(-4L),0x5B50A913L,1L},{0x5B50A913L,0x68060A55L,0xC110DD41L,(-4L),0x4A55240FL},{0xCDA774B8L,1L,1L,0x3A5B3DEAL,(-1L)},{0xFE063321L,(-2L),1L,0xCE718A31L,0x4A55240FL},{0x4A55240FL,(-1L),0xD9DB06F4L,6L,0x4D3C1C52L}},{{(-10L),0L,1L,(-1L),0x68D506FDL},{6L,(-5L),0x6D3F7641L,0x3E295FCDL,6L},{6L,1L,4L,(-1L),0xEE42853CL},{(-10L),0xD9DB06F4L,8L,0L,0xAD57BA66L},{0x4A55240FL,0x5B50A913L,0x359BAE9FL,9L,0L}},{{0xFE063321L,0xDD01FDE6L,0xDD01FDE6L,0xFE063321L,0x2B7824C9L},{0x3A5B3DEAL,4L,0x4A55240FL,0x68060A55L,0x8EDC135EL},{4L,1L,1L,(-5L),0xD77B7160L},{0xC110DD41L,0xAD57BA66L,0xCDA774B8L,0x68060A55L,0xC46A7C5BL},{4L,0x27F109DFL,0x3A5B3DEAL,0xFE063321L,(-2L)}},{{6L,0xF475E154L,(-1L),9L,0xFE063321L},{1L,(-4L),0x10F19C17L,0L,4L},{(-1L),0xEE42853CL,0xC46A7C5BL,(-1L),(-4L)},{8L,6L,0x4D3C1C52L,0x3E295FCDL,0xCE718A31L},{0L,6L,(-10L),(-1L),9L}},{{0L,0xEE42853CL,(-4L),6L,(-5L)},{0x359BAE9FL,(-4L),5L,0xCE718A31L,(-1L)},{(-1L),0xF475E154L,0x5B50A913L,0xF475E154L,(-1L)},{0xCE718A31L,0x27F109DFL,0x68D506FDL,0xD30B9CADL,0xCDA774B8L},{(-1L),0xAD57BA66L,0L,4L,1L}},{{0xEE42853CL,1L,0xC74C86ADL,0x27F109DFL,0xCDA774B8L},{0xD77B7160L,4L,0xFE063321L,5L,(-1L)},{0xCDA774B8L,0xDD01FDE6L,0xAD57BA66L,(-6L),(-1L)},{6L,0x5B50A913L,0x69168DEFL,0x3A5B3DEAL,(-5L)},{0L,0xD9DB06F4L,0x27F109DFL,1L,9L}},{{0x5B50A913L,1L,1L,0x359BAE9FL,0xCE718A31L},{0xABD1CFADL,(-5L),1L,0x5B50A913L,(-4L)},{1L,0L,0x27F109DFL,0xC110DD41L,4L},{(-2L),(-1L),0x69168DEFL,0xC74C86ADL,0xFE063321L},{0L,(-2L),0xAD57BA66L,0xAD57BA66L,(-2L)}},{{0x10F19C17L,(-10L),0xFE063321L,(-1L),0xC46A7C5BL},{1L,1L,0xC74C86ADL,6L,0xD77B7160L},{0L,6L,0L,0xD9DB06F4L,0x8EDC135EL},{1L,(-1L),0x68D506FDL,0xB17453B9L,0x2B7824C9L},{0x10F19C17L,0xCE718A31L,0x5B50A913L,0x2B7824C9L,0L}},{{0L,0x68060A55L,5L,0L,0xAD57BA66L},{6L,0x10F19C17L,0xD30B9CADL,0xC74C86ADL,0x5B50A913L},{0x4A55240FL,0xAD57BA66L,1L,0x3A5B3DEAL,1L},{9L,0xC46A7C5BL,1L,0x3A5B3DEAL,0xD77B7160L},{4L,(-4L),0L,0xC74C86ADL,1L}}};
                    int64_t *l_2677 = &g_304;
                    int i, j, k;
                    for (g_2434 = 0; (g_2434 <= 2); g_2434 += 1)
                    { /* block id: 1119 */
                        int i;
                        (*g_275) = (l_1800[g_2434] = 0x105F1BFEL);
                        (*g_2658) = l_2656;
                    }
                    (*g_275) = (((*l_2677) |= (safe_sub_func_uint64_t_u_u((((((*l_2662) = l_2661[1][2]) != l_2663[4]) >= l_2664) <= (safe_add_func_int32_t_s_s((((safe_sub_func_int16_t_s_s(l_2182[5], (safe_div_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(((&g_1961 != ((*l_2674) = l_2673)) > (l_2675[6][1] , (l_2676[6][0][1] &= p_17))), 3)), p_18)))) || l_2652) >= (-1L)), 0xC50A8D33L))), p_18))) < l_2310);
                    if (l_2675[4][1])
                        continue;
                }
            }
        }
        (*g_275) |= ((((((l_2680 == (void*)0) && (((*l_2682) = (p_15 , l_2681)) != (((--l_2685[5][0]) , (p_18 &= ((0x13L & (((-1L) | l_2675[6][1]) , (~(safe_add_func_uint32_t_u_u(4294967295UL, (((((safe_add_func_int64_t_s_s(((l_2695 = l_2693) != &g_1361), p_15)) , 0x290BD719DD0C40C0LL) <= l_2675[3][1]) < 0x7D0C6DD4L) | l_2696)))))) | p_15))) , l_2697))) >= l_2684) || 0xE4L) < l_2696) != (*g_1962));
        l_1800[2] &= (l_2697 == &g_818[1]);
    }
    return g_2698;
}


/* ------------------------------------------ */
/* 
 * reads : g_104 g_1044 g_275 g_47 g_1155 g_1156 g_1157
 * writes: g_1772 g_47
 */
static const uint32_t  func_21(int32_t ** p_22, int32_t  p_23, int16_t  p_24)
{ /* block id: 24 */
    const uint64_t *l_86 = &g_87;
    int32_t l_96 = 0x1831556DL;
    int32_t l_597[8] = {(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L};
    int8_t *l_1291 = &g_408[8];
    int8_t **l_1290[8] = {&l_1291,&l_1291,&l_1291,&l_1291,&l_1291,&l_1291,&l_1291,&l_1291};
    uint16_t *l_1315 = &g_714;
    const union U1 *l_1333 = &g_1334;
    uint16_t **l_1419[4];
    int16_t l_1509 = 1L;
    const union U1 **l_1520 = &l_1333;
    const union U1 ***l_1519 = &l_1520;
    uint8_t l_1558 = 0x1AL;
    uint8_t *l_1561 = &l_1558;
    uint8_t **l_1560 = &l_1561;
    uint8_t ***l_1559 = &l_1560;
    int32_t l_1582[5];
    int32_t *l_1587 = &g_104[1];
    int32_t **l_1600[1];
    int32_t ***l_1599 = &l_1600[0];
    int64_t l_1605 = 0x06B27902E9E15535LL;
    int8_t l_1644 = 0x82L;
    uint32_t l_1654 = 0x38E7E0BDL;
    int64_t **l_1733[9] = {&g_326[1],&g_326[1],&g_326[1],&g_326[1],&g_326[1],&g_326[1],&g_326[1],&g_326[1],&g_326[1]};
    int64_t ***l_1732[10][6][4] = {{{&l_1733[7],&l_1733[2],(void*)0,&l_1733[3]},{(void*)0,&l_1733[3],&l_1733[0],&l_1733[1]},{&l_1733[2],&l_1733[1],&l_1733[3],&l_1733[2]},{&l_1733[1],&l_1733[2],&l_1733[7],(void*)0},{&l_1733[2],(void*)0,&l_1733[2],&l_1733[2]},{&l_1733[0],(void*)0,&l_1733[6],&l_1733[4]}},{{(void*)0,&l_1733[2],&l_1733[2],&l_1733[2]},{&l_1733[1],(void*)0,&l_1733[4],&l_1733[1]},{&l_1733[2],&l_1733[2],(void*)0,&l_1733[2]},{&l_1733[2],&l_1733[5],&l_1733[2],&l_1733[7]},{&l_1733[2],(void*)0,(void*)0,&l_1733[6]},{&l_1733[2],&l_1733[7],&l_1733[4],&l_1733[2]}},{{&l_1733[1],&l_1733[7],&l_1733[2],&l_1733[7]},{(void*)0,(void*)0,&l_1733[6],&l_1733[2]},{&l_1733[0],(void*)0,&l_1733[2],&l_1733[0]},{&l_1733[2],&l_1733[3],&l_1733[7],(void*)0},{&l_1733[1],(void*)0,&l_1733[3],&l_1733[5]},{&l_1733[2],&l_1733[7],&l_1733[0],(void*)0}},{{(void*)0,&l_1733[1],(void*)0,(void*)0},{&l_1733[7],&l_1733[2],&l_1733[2],&l_1733[2]},{(void*)0,(void*)0,&l_1733[2],(void*)0},{&l_1733[7],&l_1733[8],&l_1733[2],&l_1733[7]},{&l_1733[7],(void*)0,(void*)0,&l_1733[2]},{(void*)0,&l_1733[7],(void*)0,&l_1733[2]}},{{&l_1733[6],&l_1733[2],&l_1733[0],&l_1733[7]},{(void*)0,&l_1733[3],(void*)0,&l_1733[6]},{&l_1733[2],&l_1733[2],(void*)0,&l_1733[3]},{&l_1733[2],(void*)0,&l_1733[1],&l_1733[2]},{&l_1733[7],&l_1733[3],&l_1733[2],&l_1733[2]},{(void*)0,(void*)0,&l_1733[2],&l_1733[2]}},{{&l_1733[2],&l_1733[2],(void*)0,(void*)0},{&l_1733[7],&l_1733[2],&l_1733[3],&l_1733[3]},{(void*)0,&l_1733[1],&l_1733[0],&l_1733[3]},{&l_1733[6],&l_1733[1],&l_1733[8],&l_1733[3]},{&l_1733[1],&l_1733[2],&l_1733[8],(void*)0},{&l_1733[2],&l_1733[2],&l_1733[2],&l_1733[2]}},{{&l_1733[2],&l_1733[2],&l_1733[2],(void*)0},{(void*)0,&l_1733[7],&l_1733[7],&l_1733[8]},{(void*)0,&l_1733[2],(void*)0,&l_1733[4]},{&l_1733[2],(void*)0,&l_1733[1],&l_1733[1]},{&l_1733[8],&l_1733[2],&l_1733[2],&l_1733[3]},{&l_1733[7],&l_1733[2],&l_1733[2],&l_1733[2]}},{{&l_1733[2],&l_1733[3],&l_1733[5],&l_1733[3]},{&l_1733[2],&l_1733[2],&l_1733[7],(void*)0},{&l_1733[2],&l_1733[3],&l_1733[0],&l_1733[2]},{&l_1733[2],(void*)0,&l_1733[1],&l_1733[2]},{&l_1733[4],&l_1733[0],&l_1733[7],(void*)0},{&l_1733[4],(void*)0,&l_1733[2],(void*)0}},{{(void*)0,(void*)0,(void*)0,&l_1733[3]},{&l_1733[2],&l_1733[2],(void*)0,(void*)0},{&l_1733[2],&l_1733[2],&l_1733[2],&l_1733[0]},{&l_1733[2],(void*)0,&l_1733[3],&l_1733[2]},{&l_1733[3],&l_1733[2],&l_1733[0],(void*)0},{&l_1733[8],&l_1733[0],&l_1733[8],&l_1733[8]}},{{(void*)0,&l_1733[3],&l_1733[2],(void*)0},{&l_1733[1],&l_1733[2],&l_1733[2],&l_1733[3]},{&l_1733[7],(void*)0,&l_1733[2],&l_1733[2]},{&l_1733[1],(void*)0,&l_1733[2],&l_1733[6]},{(void*)0,&l_1733[2],&l_1733[8],&l_1733[8]},{&l_1733[8],&l_1733[8],&l_1733[0],(void*)0}}};
    int16_t ** const *l_1769 = (void*)0;
    int16_t ***l_1771[8] = {&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064};
    int16_t ****l_1770[5] = {&l_1771[7],&l_1771[7],&l_1771[7],&l_1771[7],&l_1771[7]};
    uint32_t l_1773 = 0x844DA0E4L;
    int32_t l_1778 = 0x60D719B1L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1419[i] = &g_819;
    for (i = 0; i < 5; i++)
        l_1582[i] = (-1L);
    for (i = 0; i < 1; i++)
        l_1600[i] = &g_275;
    for (p_24 = 0; (p_24 == 15); p_24 = safe_add_func_int16_t_s_s(p_24, 2))
    { /* block id: 27 */
        uint32_t l_81[4] = {1UL,1UL,1UL,1UL};
        const int32_t *l_95 = &g_47[5][1][1];
        int32_t *l_598 = &l_597[7];
        uint8_t * const l_1301 = &g_665[5];
        uint16_t *l_1313 = &g_2;
        int64_t * const *l_1357 = &g_750;
        int64_t * const **l_1356 = &l_1357;
        int32_t l_1373 = 0x1974DEFBL;
        int32_t l_1383 = (-1L);
        int32_t l_1392 = 0x1BF6E6BBL;
        int32_t l_1394 = 0L;
        uint16_t l_1416 = 65534UL;
        int32_t l_1494 = 0L;
        int32_t l_1497 = 0L;
        uint16_t l_1498[1];
        uint16_t l_1540 = 0xFE0AL;
        int64_t l_1566 = (-2L);
        union U1 *l_1570 = &g_1571[0][4][3];
        union U1 **l_1569 = &l_1570;
        int16_t l_1598[9][8][3] = {{{(-4L),0x0132L,3L},{0x8BB7L,0x8A0AL,0xD185L},{0x5CC5L,0x0132L,0x93E5L},{1L,2L,0x23AAL},{(-1L),0x1268L,1L},{0xD185L,0x06A0L,0xBC6DL},{0x93ADL,(-4L),0xBA75L},{0xBC6DL,7L,1L}},{{(-2L),0x2602L,0xBA75L},{0x02E6L,(-5L),0xBC6DL},{1L,0xED53L,1L},{0L,0xE0DEL,0x23AAL},{0xF44BL,0xEDDAL,0x93E5L},{0xE0DEL,1L,0xD185L},{(-1L),0xB891L,3L},{0xE0DEL,(-6L),(-8L)}},{{0xF44BL,(-3L),0x1D66L},{0L,0xD185L,0x06A0L},{1L,(-2L),1L},{0x02E6L,0L,(-8L)},{(-2L),0x99C0L,(-1L)},{0xBC6DL,0L,7L},{0x93ADL,(-2L),0xF44BL},{0xD185L,0xD185L,0L}},{{(-1L),(-3L),0x5CC5L},{1L,(-6L),0x404DL},{0x5CC5L,0x6626L,(-1L)},{0x7A86L,2L,0xE0DEL},{3L,0x99C0L,0xF44BL},{0L,7L,0L},{(-1L),0xB891L,1L},{0L,0x8A0AL,0x02E6L}},{{0x93E5L,(-2L),(-2L)},{0x06A0L,0x02E6L,0xBC6DL},{0x93E5L,0xFB7FL,0x93ADL},{0L,0xD185L,0xD185L},{(-1L),0x8A4BL,(-1L)},{0L,0x06A0L,1L},{3L,0xB121L,0x5CC5L},{0x7A86L,0x404DL,0x8BB7L}},{{0xF44BL,0xB121L,(-4L)},{2L,0x06A0L,0L},{(-2L),0x8A4BL,6L},{0x8BB7L,0xD185L,0x23AAL},{(-1L),0xFB7FL,0x46C1L},{0x23AAL,0x02E6L,2L},{0x3942L,(-2L),0x46C1L},{(-8L),0x8A0AL,0x23AAL}},{{6L,0xB891L,6L},{(-6L),7L,0L},{1L,0x99C0L,(-4L)},{7L,2L,0x8BB7L},{0x1D66L,0x6626L,0x5CC5L},{7L,(-8L),1L},{1L,0x1268L,(-1L)},{(-6L),0x8BB7L,0xD185L}},{{6L,(-3L),0x93ADL},{(-8L),0L,0xBC6DL},{0x3942L,0x68B5L,(-2L)},{0x23AAL,0L,0x02E6L},{(-1L),(-3L),1L},{0x8BB7L,0x8BB7L,0L},{(-2L),0x1268L,0xF44BL},{2L,(-8L),0xE0DEL}},{{0xF44BL,0x6626L,(-1L)},{0x7A86L,2L,0xE0DEL},{3L,0x99C0L,0xF44BL},{0L,7L,0L},{(-1L),0xB891L,1L},{0L,0x8A0AL,0x02E6L},{0x93E5L,(-2L),(-2L)},{0x06A0L,0x02E6L,0xBC6DL}}};
        int32_t *l_1601[10][8][3] = {{{&l_1394,(void*)0,&g_103},{&l_1373,&l_597[1],&g_47[5][3][1]},{&l_1373,&g_47[5][1][1],&l_96},{&l_1373,&g_103,&g_47[5][1][1]},{&l_1383,(void*)0,(void*)0},{&g_104[4],&l_1494,&l_1394},{&g_70,&g_103,&l_1394},{&l_597[7],&l_96,(void*)0}},{{&g_104[6],&g_47[4][6][1],&g_47[5][1][1]},{&l_1383,&g_10[1][1][1],&l_1373},{&l_1494,&g_10[2][6][4],&l_1392},{(void*)0,&l_1373,&l_597[4]},{(void*)0,&l_1373,&g_70},{&g_94,&g_10[2][6][4],(void*)0},{(void*)0,&g_10[1][1][1],&g_70},{&l_1394,&g_47[4][6][1],&l_1383}},{{&g_10[2][6][4],&l_96,&l_1494},{&g_104[2],&g_103,&g_10[2][6][4]},{&l_597[7],(void*)0,&g_10[2][6][4]},{&g_104[1],&g_103,&g_47[0][3][0]},{&g_10[2][6][4],&g_10[3][3][7],&g_104[4]},{(void*)0,&l_1394,(void*)0},{&l_1394,&l_1392,&l_1394},{&l_1394,&g_94,&l_1392}},{{(void*)0,&g_47[4][6][1],(void*)0},{(void*)0,(void*)0,&g_47[6][8][3]},{&g_10[2][6][4],&g_104[6],&g_70},{&l_1394,(void*)0,&g_47[4][6][1]},{&l_1373,(void*)0,&g_47[5][1][1]},{&l_1394,&l_1373,&l_1497},{&g_10[2][6][4],&g_10[2][6][4],(void*)0},{(void*)0,&l_1494,&g_47[5][1][1]}},{{(void*)0,&g_47[6][8][3],&g_104[6]},{&l_1394,&l_1383,(void*)0},{&l_1394,&g_10[2][6][4],&g_94},{(void*)0,&l_96,&g_10[1][1][1]},{&g_10[2][6][4],&l_597[1],&l_1494},{&g_104[1],(void*)0,&g_70},{&l_597[7],&g_70,&l_1373},{(void*)0,&g_103,&l_1373}},{{&l_96,(void*)0,&l_1394},{(void*)0,&l_1497,&g_10[3][3][5]},{&g_103,&l_597[7],&g_70},{(void*)0,&g_103,(void*)0},{&g_47[5][1][1],&g_104[2],(void*)0},{&l_96,&l_1394,&g_70},{&l_96,&g_47[1][3][1],&g_10[3][3][5]},{&g_47[5][1][1],&g_47[0][3][0],&l_1394}},{{(void*)0,&g_94,&l_1373},{&l_96,&g_104[4],&l_1373},{&g_10[1][1][1],&g_47[5][1][1],&g_70},{&l_1373,&l_1494,&l_1494},{&g_104[4],&g_47[5][3][1],&g_10[1][1][1]},{&l_1497,&l_1392,&g_94},{&g_10[2][6][4],&l_597[1],(void*)0},{&l_1497,&g_10[2][6][4],&g_104[6]}},{{&g_104[2],&g_47[5][1][1],&g_47[5][1][1]},{&g_103,(void*)0,(void*)0},{&l_597[0],&g_104[2],&l_1497},{&g_104[2],&g_70,&g_47[5][1][1]},{&l_1373,&g_47[4][1][0],&g_47[4][6][1]},{&l_1394,&g_70,&g_70},{(void*)0,&g_104[2],&g_47[6][8][3]},{&l_597[1],(void*)0,(void*)0}},{{&l_1494,&g_47[5][1][1],&l_1392},{&l_1497,&g_10[2][6][4],&l_1394},{&l_597[6],&l_597[1],(void*)0},{&g_70,&l_1392,&g_104[4]},{&g_104[2],&g_47[5][3][1],&g_47[0][3][0]},{&g_104[2],&l_1494,&g_10[2][6][4]},{&g_10[3][3][7],&g_47[5][1][1],&l_96},{&l_597[1],&g_104[4],&g_10[2][6][4]}},{{&g_70,&g_94,&l_597[4]},{(void*)0,&g_47[0][3][0],&l_1494},{(void*)0,&g_47[1][3][1],&g_104[1]},{&g_47[6][8][3],&l_1394,&g_70},{&g_10[2][6][4],&g_104[2],&l_96},{&g_10[2][6][4],&g_103,(void*)0},{&g_47[6][8][3],&l_597[7],&l_1497},{(void*)0,&l_1497,&g_103}}};
        uint64_t l_1648 = 0xBF37092642FBF63ALL;
        uint32_t l_1659 = 0x6C351053L;
        uint8_t **l_1722 = &l_1561;
        int32_t l_1750 = (-1L);
        uint32_t l_1760 = 4294967291UL;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1498[i] = 1UL;
    }
    (***l_1599) = (safe_add_func_int32_t_s_s((safe_div_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((l_1769 != (g_1772[1] = &g_1064)), ((**l_1560) = ((*l_1587) || (l_1773 > (safe_mul_func_uint8_t_u_u(((safe_mod_func_int16_t_s_s((&g_754 != &g_1065), ((p_24 , (g_1044 , ((p_24 ^ p_23) , l_1778))) , p_23))) , p_24), (-3L)))))))), g_1044)), 1UL));
    (*g_275) = (!(***l_1599));
    return (**g_1155);
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_20
 * writes: g_60 g_70
 */
static int32_t ** func_25(int32_t * p_26, int32_t * p_27, int32_t ** p_28, const int8_t  p_29)
{ /* block id: 19 */
    const int32_t *l_65[6][10] = {{&g_47[5][1][1],&g_10[2][2][0],&g_47[5][1][1],&g_10[2][5][7],&g_10[2][6][4],&g_47[5][1][1],&g_10[2][6][4],&g_10[2][6][4],&g_10[0][2][2],&g_47[1][0][0]},{&g_10[1][6][3],&g_47[5][6][1],&g_10[3][0][7],&g_10[2][2][0],(void*)0,&g_47[5][1][1],&g_10[2][6][4],&g_47[1][0][0],&g_47[5][1][1],&g_10[0][3][3]},{&g_10[0][2][2],&g_47[6][0][1],&g_10[2][5][7],&g_10[0][3][3],&g_47[2][5][3],&g_47[5][1][1],&g_10[1][6][3],&g_10[1][6][3],&g_47[5][1][1],&g_47[2][5][3]},{&g_10[1][6][3],&g_10[3][2][7],&g_10[3][2][7],&g_10[1][6][3],&g_10[3][0][7],&g_47[5][1][1],&g_47[5][1][1],&g_47[5][1][1],(void*)0,&g_10[2][6][4]},{&g_10[0][3][3],&g_10[2][5][7],&g_47[6][0][1],&g_10[0][2][2],&g_47[5][1][1],&g_47[1][0][0],&g_10[3][2][7],&g_47[5][1][1],(void*)0,&g_47[5][1][1]},{&g_10[2][2][0],&g_10[3][0][7],&g_47[5][6][1],&g_10[1][6][3],&g_47[5][6][1],&g_10[3][0][7],&g_10[2][2][0],(void*)0,&g_47[5][1][1],&g_10[2][6][4]}};
    int32_t *l_66[1][3][2] = {{{&g_47[3][6][0],&g_10[2][6][4]},{&g_10[2][6][4],&g_47[3][6][0]},{&g_10[2][6][4],&g_10[2][6][4]}}};
    uint32_t l_67 = 0xC12866A8L;
    int i, j, k;
    l_65[5][0] = (*g_19);
    l_67--;
    for (l_67 = 0; l_67 < 1; l_67 += 1)
    {
        for (g_60 = 0; g_60 < 3; g_60 += 1)
        {
            for (g_70 = 0; g_70 < 2; g_70 += 1)
            {
                l_66[l_67][g_60][g_70] = &g_47[3][7][0];
            }
        }
    }
    return &g_5;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_60 g_47
 */
static int32_t * func_30(int64_t  p_31, const int32_t * p_32, int8_t  p_33)
{ /* block id: 14 */
    int64_t l_62 = 0x08D8D3B62B766AA6LL;
    int32_t l_63 = 0L;
lbl_64:
    for (p_31 = 0; p_31 < 7; p_31 += 1)
    {
        for (g_60 = 0; g_60 < 9; g_60 += 1)
        {
            for (p_33 = 0; p_33 < 4; p_33 += 1)
            {
                g_47[p_31][g_60][p_33] = 1L;
            }
        }
    }
    l_63 = ((-9L) != l_62);
    if (l_62)
        goto lbl_64;
    return &g_10[2][6][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_47
 * writes:
 */
static int8_t  func_36(int32_t * p_37, uint32_t  p_38, int32_t ** p_39, uint16_t  p_40)
{ /* block id: 8 */
    uint8_t l_43 = 1UL;
    int32_t *l_46 = &g_47[5][1][1];
    int32_t *l_48 = (void*)0;
    int32_t *l_49 = &g_47[3][6][0];
    int32_t l_50 = (-1L);
    int32_t *l_51 = &l_50;
    int32_t *l_52 = &g_47[6][1][3];
    int32_t l_53 = 0x2634D7F4L;
    int32_t *l_54 = &l_53;
    int32_t *l_55[10] = {(void*)0,&g_10[2][1][0],(void*)0,(void*)0,&g_10[2][1][0],(void*)0,(void*)0,&g_10[2][1][0],(void*)0,(void*)0};
    uint8_t l_56 = 248UL;
    int i;
    l_43--;
    l_56++;
    (*l_54) = 9L;
    return (*l_49);
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_253 g_233 g_636 g_275 g_104 g_47 g_406 g_145 g_176 g_87 g_103 g_19 g_408 g_5 g_20 g_2 g_714 g_665 g_148 g_750 g_753 g_184 g_185 g_632 g_60 g_70 g_441 g_810 g_174.f3 g_323 g_1044 g_1065 g_304 g_152.f3 g_326 g_1018 g_1128 g_94
 * writes: g_406 g_233 g_323 g_168.f3 g_70 g_636 g_304 g_632 g_174.f3 g_408 g_104 g_47 g_20 g_5 g_176 g_253 g_665 g_714 g_441 g_60 g_753 g_767 g_326 g_818 g_148 g_941 g_942 g_185 g_155.f3 g_811 g_145 g_1064 g_152.f3 g_1154 g_1155 g_103 g_1128 g_94 g_750
 */
static int32_t  func_73(uint8_t  p_74, int32_t * p_75)
{ /* block id: 248 */
    uint32_t *l_601 = &g_406[0];
    int32_t **l_602 = &g_5;
    int32_t l_628 = (-1L);
    int32_t l_634 = 0x3BBFCE94L;
    union U0 **l_653 = &g_185;
    int64_t ** const l_658 = &g_326[1];
    uint64_t *l_710 = &g_441;
    uint16_t *l_743 = &g_176[8];
    const union U1 * const l_775 = (void*)0;
    uint64_t **l_785 = &l_710;
    int32_t l_890 = 1L;
    int32_t l_904 = 0L;
    int32_t l_906 = 0L;
    int32_t l_907[9][9][3] = {{{0L,5L,(-8L)},{(-9L),(-9L),(-7L)},{0x7B97102EL,0xC3690B27L,4L},{(-2L),(-9L),0x0832EE4CL},{(-1L),5L,(-5L)},{0x3D53E211L,(-2L),0x0832EE4CL},{(-1L),0xF5281BE8L,4L},{0xA17FF37AL,0x3D53E211L,(-7L)},{(-1L),0L,(-8L)}},{{0x3D53E211L,0xA17FF37AL,1L},{(-1L),0L,(-8L)},{(-2L),0x3D53E211L,(-2L)},{0x7B97102EL,0xF5281BE8L,(-8L)},{(-9L),(-2L),1L},{0L,5L,(-8L)},{(-9L),(-9L),(-7L)},{0x7B97102EL,0xC3690B27L,4L},{(-2L),(-9L),0x0832EE4CL}},{{(-1L),5L,(-5L)},{0x3D53E211L,(-2L),0x0832EE4CL},{(-1L),0xF5281BE8L,4L},{0xA17FF37AL,0x3D53E211L,(-7L)},{(-1L),0L,(-8L)},{0x3D53E211L,0xA17FF37AL,1L},{(-1L),0L,(-8L)},{(-2L),0x3D53E211L,(-2L)},{0x7B97102EL,0xF5281BE8L,(-8L)}},{{(-9L),(-2L),1L},{0L,5L,(-8L)},{(-9L),(-9L),(-7L)},{0x7B97102EL,0xC3690B27L,4L},{(-2L),(-9L),0x0832EE4CL},{(-1L),5L,(-5L)},{0x3D53E211L,(-2L),0x0832EE4CL},{(-1L),0xF5281BE8L,4L},{0xA17FF37AL,0x3D53E211L,(-7L)}},{{(-1L),0L,(-8L)},{0x3D53E211L,0xA17FF37AL,1L},{(-1L),0L,(-8L)},{(-2L),0x3D53E211L,0L},{0x5739CE9DL,(-8L),0L},{0xD5954D6BL,0x20482B86L,1L},{0x431E8339L,0x20CB1D87L,(-1L)},{0xD5954D6BL,0xD5954D6BL,(-9L)},{0x5739CE9DL,3L,0L}},{{0x20482B86L,0xD5954D6BL,0xA17FF37AL},{7L,0x20CB1D87L,0x5CA2E2F8L},{0L,0x20482B86L,0xA17FF37AL},{3L,(-8L),0L},{(-9L),0L,(-9L)},{3L,0x06CCFE67L,(-1L)},{0L,(-9L),1L},{7L,0x06CCFE67L,0L},{0x20482B86L,0L,0L}},{{0x5739CE9DL,(-8L),0L},{0xD5954D6BL,0x20482B86L,1L},{0x431E8339L,0x20CB1D87L,(-1L)},{0xD5954D6BL,0xD5954D6BL,(-9L)},{0x5739CE9DL,3L,0L},{0x20482B86L,0xD5954D6BL,0xA17FF37AL},{7L,0x20CB1D87L,0x5CA2E2F8L},{0L,0x20482B86L,0xA17FF37AL},{3L,(-8L),0L}},{{(-9L),0L,(-9L)},{3L,0x06CCFE67L,(-1L)},{0L,(-9L),1L},{7L,0x06CCFE67L,0L},{0x20482B86L,0L,0L},{0x5739CE9DL,(-8L),0L},{0xD5954D6BL,0x20482B86L,1L},{0x431E8339L,0x20CB1D87L,(-1L)},{0xD5954D6BL,0xD5954D6BL,(-9L)}},{{0x5739CE9DL,3L,0L},{0x20482B86L,0xD5954D6BL,0xA17FF37AL},{7L,0x20CB1D87L,0x5CA2E2F8L},{0L,0x20482B86L,0xA17FF37AL},{3L,(-8L),0L},{(-9L),0L,(-9L)},{3L,0x06CCFE67L,(-1L)},{0L,(-9L),1L},{7L,0x06CCFE67L,0L}}};
    uint16_t **l_950[7][5] = {{&g_819,&l_743,(void*)0,&g_819,&g_819},{&l_743,&l_743,&g_819,&g_819,&l_743},{(void*)0,&g_819,&g_819,(void*)0,&g_819},{&l_743,&g_819,&g_819,(void*)0,&g_819},{&g_819,&l_743,&l_743,(void*)0,&l_743},{(void*)0,(void*)0,&g_819,(void*)0,&g_819},{&g_819,(void*)0,&g_819,(void*)0,&g_819}};
    uint8_t l_1021[10][4][2] = {{{0UL,0UL},{0x37L,0x32L},{0x95L,246UL},{249UL,0xE9L}},{{0x32L,249UL},{0x95L,1UL},{0x95L,249UL},{0x32L,0xE9L}},{{249UL,246UL},{0x95L,0x32L},{0x37L,0UL},{0UL,8UL}},{{0xAEL,0x85L},{0x2BL,0x95L},{0x90L,0xC5L},{246UL,0x2BL}},{{0xAEL,0x37L},{8UL,1UL},{0x95L,0UL},{0x95L,0x95L}},{{0xE9L,0xC5L},{0x37L,8UL},{246UL,250UL},{0xC5L,246UL}},{{0x16L,0x7FL},{0x16L,246UL},{0xC5L,250UL},{246UL,8UL}},{{0x37L,0xC5L},{0xE9L,0x95L},{0x95L,0UL},{0x95L,1UL}},{{8UL,0x37L},{0xAEL,0x2BL},{8UL,0x2BL},{0xAEL,0x37L}},{{8UL,1UL},{0x95L,0UL},{0x95L,0x95L},{0xE9L,0xC5L}}};
    int16_t l_1043 = 1L;
    int32_t l_1075 = 0x1D281A24L;
    uint32_t l_1119 = 5UL;
    uint32_t l_1158[8] = {1UL,2UL,1UL,2UL,1UL,2UL,1UL,2UL};
    const int64_t *l_1261 = &g_1262[0];
    int i, j, k;
    if ((safe_mul_func_uint32_t_u_u(((*l_601) = (g_10[2][6][4] , 0xADB666B6L)), ((l_602 != &p_75) < g_253))))
    { /* block id: 250 */
        uint64_t l_610 = 0x8707426CCCEB9223LL;
        int32_t l_617 = (-1L);
        int32_t l_627[10][3][8] = {{{0x96DCC6A6L,0x19505512L,0x29D35A72L,0x9DBB37CBL,(-7L),0x1563CD70L,0x19505512L,0xDD393762L},{0x96DCC6A6L,0x3C954E47L,8L,(-7L),0x19505512L,(-1L),0x1563CD70L,(-8L)},{0x20CCB4A9L,0x4A45B770L,(-10L),0x2C286DA5L,0xCFEF81B0L,6L,0x50152CB2L,0x19505512L}},{{0x69418C04L,0xE10D5725L,(-1L),0x0A6E9E5EL,0L,1L,0L,(-1L)},{5L,(-8L),0x2C286DA5L,0x716C9D47L,8L,(-1L),0xB2D1A48EL,0L},{0x1563CD70L,0x50152CB2L,1L,0x19505512L,0x6C2D9113L,0L,1L,0L}},{{0L,(-7L),8L,0xDD393762L,0x4A45B770L,1L,1L,0x4A45B770L},{(-1L),1L,1L,(-1L),0xDC9E0EFCL,0xBF8BE1ABL,0x69418C04L,0x19505512L},{0x50152CB2L,0L,(-7L),(-1L),0xB823BB19L,0x4A45B770L,0xCFEF81B0L,1L}},{{0x17BDD031L,0L,5L,(-9L),8L,0xBF8BE1ABL,0xAE62BA8CL,6L},{1L,1L,0xB0E62C1BL,0x9DBB37CBL,0x1563CD70L,1L,0x716C9D47L,1L},{9L,(-7L),0x19505512L,0xDB70E432L,(-9L),0L,0xBEF88E1EL,0x1CB59F38L}},{{0x20CCB4A9L,0x50152CB2L,(-9L),0xBF8BE1ABL,(-8L),(-1L),0x69418C04L,(-10L)},{0x716C9D47L,(-8L),0x29D35A72L,0xB0E62C1BL,3L,1L,(-8L),0xDD393762L},{6L,0xE10D5725L,0xABEC01EBL,(-9L),0x19505512L,6L,0L,6L}},{{0xBEF88E1EL,0x4A45B770L,1L,0x4A45B770L,0xBEF88E1EL,(-1L),0x50152CB2L,1L},{9L,0x3C954E47L,0x4A45B770L,0x0A6E9E5EL,1L,0x1563CD70L,0x19505512L,0x725E2328L},{(-1L),0x2C286DA5L,0x725E2328L,0xDB70E432L,0x6C2D9113L,0x29D35A72L,6L,0x20CCB4A9L}},{{(-1L),0x96DCC6A6L,0x353BB131L,0xDC9E0EFCL,9L,6L,(-8L),0xCFEF81B0L},{0xDD393762L,0x1563CD70L,1L,0xBF8BE1ABL,0x725E2328L,(-1L),4L,0xDC32D320L},{0x19505512L,(-1L),0L,5L,0x50152CB2L,(-8L),0x20CCB4A9L,0xDC9E0EFCL}},{{0x716C9D47L,8L,(-1L),0xB2D1A48EL,0L,0x50152CB2L,0x9DBB37CBL,0xABEC01EBL},{0x0A6E9E5EL,0xABEC01EBL,0x2C286DA5L,0xB0E62C1BL,0x6C2D9113L,1L,0xBF8BE1ABL,0xBF8BE1ABL},{0x2C286DA5L,(-8L),0L,0L,(-8L),0x2C286DA5L,0x3C954E47L,0x353BB131L}},{{(-7L),0x1563CD70L,(-1L),6L,(-1L),0xDD393762L,(-7L),1L},{0x9DBB37CBL,6L,3L,6L,0x4A45B770L,1L,0x20CCB4A9L,0x353BB131L},{0x1CB59F38L,0x4A45B770L,(-1L),0L,0x17BDD031L,0xA157C793L,0x4A45B770L,0xBF8BE1ABL}},{{0xDB70E432L,6L,0x8EECC1ADL,0xB0E62C1BL,4L,(-8L),(-1L),0xABEC01EBL},{(-1L),0L,0x353BB131L,0xB2D1A48EL,(-7L),0xABEC01EBL,0x96DCC6A6L,0xDC9E0EFCL},{(-7L),(-1L),0xDC32D320L,5L,(-1L),0x0A6E9E5EL,1L,0xDC32D320L}}};
        int64_t l_633[10] = {0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL,0x6D8958DBA63C4D49LL};
        int64_t **l_688 = &g_326[1];
        uint16_t *l_772 = &g_714;
        uint16_t *l_773 = (void*)0;
        uint16_t l_774 = 0UL;
        int32_t l_827 = (-2L);
        int16_t l_924[6][6] = {{0L,4L,6L,1L,(-1L),(-1L)},{7L,4L,4L,7L,0x100CL,0x8245L},{7L,0x100CL,0x8245L,1L,4L,0x8245L},{0L,(-1L),4L,0xEBC5L,4L,(-1L)},{1L,0x100CL,6L,0xEBC5L,0x100CL,4L},{0L,4L,6L,1L,(-1L),(-1L)}};
        uint64_t **l_939 = &g_202;
        int16_t l_945[7][10][1] = {{{(-5L)},{0x3221L},{(-1L)},{1L},{(-3L)},{1L},{(-1L)},{0x3221L},{(-5L)},{0x3752L}},{{(-4L)},{(-4L)},{0x3752L},{(-5L)},{0x3221L},{(-1L)},{1L},{(-3L)},{1L},{(-1L)}},{{0x3221L},{(-5L)},{0x3752L},{(-4L)},{(-4L)},{0x3752L},{(-5L)},{0x3221L},{(-1L)},{1L}},{{(-3L)},{1L},{(-1L)},{0x3221L},{(-5L)},{0x3752L},{(-4L)},{(-4L)},{0x3752L},{(-1L)}},{{(-3L)},{(-1L)},{0xAC20L},{(-1L)},{0xAC20L},{(-1L)},{(-3L)},{(-1L)},{(-5L)},{1L}},{{1L},{(-5L)},{(-1L)},{(-3L)},{(-1L)},{0xAC20L},{(-1L)},{0xAC20L},{(-1L)},{(-3L)}},{{(-1L)},{(-5L)},{1L},{1L},{(-5L)},{(-1L)},{(-3L)},{(-1L)},{0xAC20L},{(-1L)}}};
        int i, j, k;
        for (g_233 = (-6); (g_233 < (-2)); g_233 = safe_add_func_uint32_t_u_u(g_233, 5))
        { /* block id: 253 */
            int32_t l_615 = 1L;
            int32_t l_626 = 0x54C621C8L;
            int32_t l_631 = 0x7C6050E9L;
            uint32_t *l_771 = &g_406[1];
            uint16_t *l_787 = (void*)0;
            int8_t l_798 = 1L;
            const union U1 **l_813 = &g_811;
            int32_t l_889 = 8L;
            int32_t l_892 = 0xC68EB890L;
            int32_t l_905 = 0xB827365EL;
            int32_t l_910 = 0xFA003ADFL;
            int32_t l_913 = (-4L);
            int32_t l_915 = 0x5D150201L;
            int32_t l_918 = 0x81BA5D0FL;
            int32_t l_919 = 0x5C5F122EL;
            int32_t l_920 = 8L;
            int32_t l_921 = 1L;
            int32_t l_922 = 0x5C99C19DL;
            int32_t l_925 = 0L;
            int8_t l_946 = 5L;
            uint64_t l_947 = 5UL;
            int8_t l_1004 = 0L;
            int32_t l_1046 = (-1L);
            int32_t l_1047 = (-5L);
            for (g_323 = 10; (g_323 == 29); g_323 = safe_add_func_uint32_t_u_u(g_323, 5))
            { /* block id: 256 */
                int32_t l_616 = 0xA7C9D6F4L;
                int32_t l_621 = 0x255887EFL;
                int32_t l_622 = 0x2C130EDEL;
                int32_t l_629 = 0xCF7F8522L;
                int32_t l_630 = 0xA3C65904L;
                int32_t l_635 = 0xBB95BEB6L;
                int64_t **l_659 = (void*)0;
                uint16_t *l_683 = &g_176[0];
                for (g_168.f3 = (-21); (g_168.f3 == 13); g_168.f3 = safe_add_func_uint16_t_u_u(g_168.f3, 3))
                { /* block id: 259 */
                    int32_t *l_609[8][7][4] = {{{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]}},{{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103}},{{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103}},{{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]}},{{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103}},{{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_10[3][4][3]},{&g_103,&g_103,&g_94,&g_103},{&g_103,&g_10[3][4][3],&g_10[3][4][3],&g_103},{&g_10[3][4][3],&g_103,&g_10[3][4][3],&g_94},{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]},{&g_10[3][4][3],&g_94,&g_94,&g_10[3][4][3]}},{{&g_94,&g_10[3][4][3],&g_94,&g_94},{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]},{&g_10[3][4][3],&g_94,&g_94,&g_10[3][4][3]},{&g_94,&g_10[3][4][3],&g_94,&g_94},{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]},{&g_10[3][4][3],&g_94,&g_94,&g_10[3][4][3]},{&g_94,&g_10[3][4][3],&g_94,&g_94}},{{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]},{&g_10[3][4][3],&g_94,&g_94,&g_10[3][4][3]},{&g_94,&g_10[3][4][3],&g_94,&g_94},{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]},{&g_10[3][4][3],&g_94,&g_94,&g_10[3][4][3]},{&g_94,&g_10[3][4][3],&g_94,&g_94},{&g_10[3][4][3],&g_10[3][4][3],&g_103,&g_10[3][4][3]}}};
                    union U0 **l_651 = &g_185;
                    uint8_t *l_664[3][1][1];
                    int8_t *l_678 = &g_408[0];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 1; j++)
                        {
                            for (k = 0; k < 1; k++)
                                l_664[i][j][k] = &g_665[5];
                        }
                    }
                    l_610--;
                    for (g_70 = 19; (g_70 >= 16); g_70 = safe_sub_func_uint8_t_u_u(g_70, 2))
                    { /* block id: 263 */
                        uint64_t l_618 = 4UL;
                        int32_t l_623[2];
                        int32_t l_624 = 0x499DCCCBL;
                        int32_t l_625[10] = {0xF98E3D35L,0xB532BB79L,0xB532BB79L,0xF98E3D35L,0xB532BB79L,0xB532BB79L,0xF98E3D35L,0xB532BB79L,0xB532BB79L,0xF98E3D35L};
                        union U0 ***l_652[2];
                        int64_t *l_660 = &g_304;
                        int64_t *l_661 = &g_632;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_623[i] = 0x68385F17L;
                        for (i = 0; i < 2; i++)
                            l_652[i] = &g_184;
                        l_618--;
                        ++g_636;
                        (*p_75) |= (safe_rshift_func_uint16_t_u_u((p_74 < l_633[2]), ((((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u(0x86C3L, 3)), (((safe_div_func_uint8_t_u_u((0x7A61973A50A3243FLL && p_74), (safe_mul_func_uint16_t_u_u(((l_653 = l_651) != (void*)0), (g_174.f3 = (safe_mul_func_int8_t_s_s((safe_add_func_int64_t_s_s(((*l_661) = ((*l_660) = (l_635 = (l_658 == (p_74 , l_659))))), p_74)), g_10[0][2][6]))))))) | 0L) && p_74))) | l_625[3]) , (*g_275)) < (-1L))));
                    }
                    (*g_275) &= ((l_629 != (safe_rshift_func_uint8_t_u_s((p_74 &= ((void*)0 != &g_323)), 6))) || ((p_74 > (safe_add_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((*l_678) = (safe_add_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u(((((((((*l_601)--) || ((safe_add_func_uint64_t_u_u(l_621, l_627[9][1][6])) == (((void*)0 == p_75) || (g_145 , p_74)))) & l_616) < (-8L)) | (*p_75)) , g_176[8]) & g_87), l_633[3])) == g_145), g_103))), p_74)), p_74))) <= l_630));
                }
                (*g_19) = &l_635;
                (*l_602) = p_75;
                if ((l_626 , (4UL || ((safe_add_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((--(*l_683)), ((7UL ^ ((*p_75) , 4294967295UL)) | ((safe_rshift_func_uint16_t_u_s(g_408[2], (((&g_326[1] == l_688) <= p_74) , (**l_602)))) && 0xD8L)))), 1L)) == 0x97F829C244CA3F8ELL))))
                { /* block id: 281 */
                    if ((0x00EB78F0L > 0xC3AA8410L))
                    { /* block id: 282 */
                        (**l_602) &= (**g_19);
                        (*g_19) = p_75;
                        return (*p_75);
                    }
                    else
                    { /* block id: 286 */
                        return l_633[2];
                    }
                }
                else
                { /* block id: 289 */
                    uint64_t *l_694 = &g_253;
                    int32_t l_697 = 0x95AC88EDL;
                    int16_t *l_711 = &g_174.f3;
                    int8_t *l_712[1];
                    uint16_t *l_713 = &g_714;
                    uint8_t l_733 = 9UL;
                    int32_t *l_752 = (void*)0;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_712[i] = &g_408[8];
                    if (((((((safe_mod_func_int16_t_s_s(p_74, (safe_mod_func_uint8_t_u_u((!(++(*l_694))), l_697)))) == ((*l_710) = ((((*g_275) = (((*l_713) ^= (safe_mod_func_int8_t_s_s((l_627[6][2][4] ^= ((((g_665[3] = ((safe_sub_func_int16_t_s_s(((*l_711) = (((safe_mul_func_uint8_t_u_u((safe_unary_minus_func_int16_t_s((safe_unary_minus_func_uint64_t_u(l_629)))), 0xDCL)) ^ (0x6986DBE7C585F1BBLL > (((&l_610 != ((safe_add_func_int8_t_s_s((safe_add_func_int16_t_s_s(0x493DL, (l_635 > p_74))), l_697)) , l_710)) == l_697) != p_74))) ^ p_74)), g_176[8])) <= (**l_602))) , p_74) , g_2) < (-1L))), l_615))) || l_631)) == 0x3BE63B42L) != 0x37EEA70E28A209CBLL))) , &g_665[5]) != &p_74) && 0xE67A9DADL) , l_697))
                    { /* block id: 297 */
                        uint8_t *l_734 = &l_733;
                        int32_t l_735[2];
                        int64_t l_742 = 5L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_735[i] = (-1L);
                        (*g_275) = ((0x2237L | (safe_div_func_int8_t_s_s((+(safe_rshift_func_int8_t_s_u(l_615, g_665[5]))), p_74))) | (safe_mul_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u(0xA1L, (safe_sub_func_uint8_t_u_u(g_87, ((*l_734) = (p_74 == (g_176[3] = (((((~(safe_mul_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_s((safe_sub_func_uint32_t_u_u(((((*l_601) ^= ((p_74 ^ (g_148 , p_74)) , p_74)) | 0x56EF0CD5L) , 0xA74DDBB6L), 1UL)), 1)) , 0x72L) && g_47[5][1][1]), 0xADL))) < 18446744073709551615UL) , l_733) ^ (-10L)) , 0x1E67L)))))))) & p_74), 0xD434L)));
                        (*g_19) = ((l_735[0] & (+0UL)) , func_30(((safe_lshift_func_int16_t_s_u((**l_602), 3)) , ((safe_add_func_uint16_t_u_u((g_176[1] = (safe_unary_minus_func_int64_t_s((l_742 & (&g_176[5] != l_743))))), (l_630 = ((*l_711) = ((safe_lshift_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((((**l_602) , ((&g_304 != g_750) >= p_74)) < g_148), 14)), 0xC4L)) > g_665[5]) == (**l_602)) < g_47[2][3][1]), p_74)) < 1L))))) , (-1L))), &l_697, p_74));
                    }
                    else
                    { /* block id: 306 */
                        uint32_t l_751[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_751[i] = 0xFD49154DL;
                        if (l_751[0])
                            break;
                        (*g_275) |= 0L;
                    }
                    if ((l_752 != (*g_19)))
                    { /* block id: 310 */
                        volatile int16_t ***l_755[4][2];
                        int i, j;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_755[i][j] = &g_753[0][5];
                        }
                        g_753[0][5] = g_753[0][5];
                        return (*p_75);
                    }
                    else
                    { /* block id: 313 */
                        return (*p_75);
                    }
                }
            }
            (*g_19) = func_30(((g_145 & (safe_rshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_s(p_74, 7)), (((((((safe_mod_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((~(((((*g_184) != (g_767 = (void*)0)) , l_615) & g_632) <= (safe_add_func_int16_t_s_s((l_627[9][1][6] = (((l_771 = p_75) == p_75) , ((l_772 = (void*)0) != l_773))), g_47[6][4][0])))), g_636)), l_774)), l_626)) > g_104[1]) , (-5L)) ^ 0xDCD0604DL) , l_631) & p_74) <= (-5L))))) >= p_74), p_75, p_74);
            (*g_19) = (*g_19);
            if (((*g_275) = ((*p_75) = 0x53BE3F62L)))
            { /* block id: 326 */
                const union U1 **l_776 = (void*)0;
                const union U1 *l_778 = (void*)0;
                const union U1 **l_777 = &l_778;
                int32_t l_825 = 2L;
                union U0 **l_849 = &g_767;
                (*l_777) = ((((*l_688) = &g_233) != &g_632) , l_775);
                for (l_617 = 0; (l_617 > 25); l_617++)
                { /* block id: 331 */
                    uint16_t **l_788 = &l_743;
                    uint32_t l_797 = 0xF092EDB4L;
                    if ((((((safe_sub_func_uint16_t_u_u(0x9A39L, ((((safe_lshift_func_int8_t_s_s(((((l_785 != (void*)0) <= (((((((+g_60) >= (*p_75)) , l_787) == ((*l_788) = &g_176[8])) < (safe_mul_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u((p_74 <= (safe_mod_func_int8_t_s_s(((l_797 , (void*)0) != (void*)0), p_74))), 0x76113F8F400B80A6LL)) | p_74), 1L)) | g_70), p_74))) && g_441) == 0x1FAFL)) > (-7L)) == l_798), g_406[2])) & (*g_20)) && 0xDA73L) & 0UL))) & 0x0D0D98C1L) | p_74) || l_774) && 0x457066AFL))
                    { /* block id: 333 */
                        const union U1 ***l_814[2][10][1] = {{{&l_813},{&l_776},{&l_776},{&l_813},{&l_776},{&l_813},{&l_776},{&l_776},{&l_813},{&l_776}},{{&l_813},{&l_776},{&l_776},{&l_813},{&l_776},{&l_813},{&l_776},{&l_776},{&l_813},{&l_776}}};
                        uint16_t ***l_815 = &l_788;
                        uint16_t **l_817[5][2][3] = {{{&l_787,&l_787,&l_787},{&l_787,&l_787,&l_787}},{{&l_787,&l_787,&l_787},{&l_787,&l_787,&l_787}},{{&l_787,&l_787,&l_787},{&l_787,&l_787,&l_787}},{{&l_787,&l_787,&l_787},{&l_787,&l_787,&l_787}},{{&l_787,&l_787,&l_787},{&l_787,&l_787,&l_787}}};
                        uint16_t ***l_816[9] = {&l_817[4][0][0],&l_817[2][0][1],&l_817[4][0][0],&l_817[2][0][1],&l_817[4][0][0],&l_817[2][0][1],&l_817[4][0][0],&l_817[2][0][1],&l_817[4][0][0]};
                        int32_t l_826 = 0xB227009FL;
                        int32_t *l_828 = &l_627[9][1][6];
                        int64_t *l_837 = &l_633[7];
                        int64_t *l_838 = &g_304;
                        int64_t *l_852 = &g_632;
                        int16_t *l_853 = (void*)0;
                        int i, j, k;
                        (*l_828) ^= ((((*p_75) = (((safe_mod_func_int64_t_s_s(((((((((((*p_75) < (((safe_mul_func_int16_t_s_s(((~((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s(65535UL, 14)), 7)) == (((*g_275) = ((g_810 != (l_777 = l_813)) | g_60)) >= (((*l_815) = &l_743) != (g_818[0] = &l_787))))) && (safe_lshift_func_int8_t_s_u((safe_add_func_int16_t_s_s((!(g_174.f3 < ((void*)0 != &g_323))), 0x2F4BL)), p_74))), l_825)) >= g_145) != p_74)) , p_75) != (void*)0) != l_825) && p_74) <= g_176[8]) , p_74) & 0x7AL) , l_826), p_74)) | g_176[8]) , l_827)) , (*p_75)) & 0x92CDB5BFL);
                        (*g_275) ^= (safe_mul_func_int8_t_s_s(g_103, (safe_add_func_int32_t_s_s((p_74 <= (safe_div_func_uint8_t_u_u(g_406[1], (safe_add_func_int32_t_s_s(((((*l_838) = ((*l_837) = l_797)) > (((*p_75) >= ((((*l_852) = (safe_lshift_func_uint16_t_u_s((l_825 |= (safe_unary_minus_func_uint8_t_u((safe_lshift_func_uint8_t_u_s((((safe_add_func_uint16_t_u_u(((*l_743) = (safe_unary_minus_func_int16_t_s((p_74 == (l_849 != &g_109))))), ((safe_lshift_func_int16_t_s_u(((p_74 < p_74) || 4294967295UL), p_74)) , 0xBA4DL))) , l_797) && 0x53845660B9C12E64LL), p_74))))), 4))) , l_853) != l_772)) , p_74)) < p_74), 0xB3A888D5L))))), 1L))));
                    }
                    else
                    { /* block id: 346 */
                        int64_t ***l_854 = &l_688;
                        (*l_854) = &g_326[1];
                    }
                    for (g_148 = 0; (g_148 > 8); g_148 = safe_add_func_int64_t_s_s(g_148, 1))
                    { /* block id: 351 */
                        (*p_75) ^= l_797;
                        (*g_275) |= (*g_20);
                        (*g_275) &= (safe_mod_func_uint8_t_u_u(p_74, 0x61L));
                    }
                    (*g_275) ^= l_631;
                }
            }
            else
            { /* block id: 358 */
                int32_t l_893 = (-9L);
                int32_t l_900 = 0x85AA29ACL;
                int32_t l_902[10] = {4L,(-1L),(-1L),4L,(-1L),(-1L),4L,(-1L),(-1L),4L};
                int32_t l_917 = 0x473EACDCL;
                uint32_t l_927 = 18446744073709551613UL;
                int8_t *l_963 = &l_798;
                int64_t *l_975 = &l_633[2];
                uint32_t l_976 = 0xD0FE852FL;
                int16_t l_1020[9] = {0x93DEL,0x93DEL,0x93DEL,0x93DEL,0x93DEL,0x93DEL,0x93DEL,0x93DEL,0x93DEL};
                int i;
                for (g_441 = 0; (g_441 <= 3); g_441 += 1)
                { /* block id: 361 */
                    uint8_t l_891 = 254UL;
                    int32_t l_903 = 0x29153992L;
                    int32_t l_909 = 2L;
                    int16_t l_911 = 0x7614L;
                    int32_t l_912 = (-5L);
                    int32_t l_914 = 0x147F2923L;
                    int32_t l_916 = 0x2415B9D6L;
                    int32_t l_923 = 0L;
                    int32_t l_926[10] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
                    int16_t *l_948 = (void*)0;
                    int16_t *l_949 = &g_155[3][1].f3;
                    int32_t *l_955 = &l_916;
                    int i;
                    for (g_714 = 0; (g_714 <= 3); g_714 += 1)
                    { /* block id: 364 */
                        int8_t *l_878[4][6][5] = {{{&g_323,(void*)0,(void*)0,&g_323,&g_408[8]},{&g_408[8],(void*)0,&l_798,&l_798,(void*)0},{&g_408[8],(void*)0,&l_798,&g_408[8],&l_798},{(void*)0,&g_408[8],(void*)0,&l_798,&g_408[8]},{&g_323,&g_323,&l_798,&g_408[8],(void*)0},{(void*)0,&g_408[8],&g_323,&l_798,&g_408[8]}},{{(void*)0,(void*)0,&g_408[8],&l_798,&g_408[8]},{(void*)0,&g_323,&g_408[8],(void*)0,(void*)0},{(void*)0,(void*)0,&g_408[4],&l_798,(void*)0},{(void*)0,&g_323,&g_408[8],&g_323,&g_323},{&g_408[8],(void*)0,&g_408[8],&g_408[4],&g_323},{&l_798,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_323,(void*)0,(void*)0,&l_798,(void*)0},{&g_408[8],(void*)0,(void*)0,(void*)0,&g_408[8]},{(void*)0,&g_408[8],&g_408[8],(void*)0,&g_408[8]},{(void*)0,&l_798,&g_408[8],&l_798,&l_798},{&g_408[8],&g_323,&g_408[4],(void*)0,&g_323},{&g_323,&g_408[8],&g_408[8],&l_798,(void*)0}},{{&l_798,(void*)0,&g_408[8],(void*)0,&l_798},{&g_408[8],(void*)0,&g_408[8],(void*)0,(void*)0},{(void*)0,&g_408[8],(void*)0,&l_798,(void*)0},{(void*)0,&g_323,(void*)0,(void*)0,(void*)0},{(void*)0,&l_798,&g_408[4],&g_408[4],&l_798},{(void*)0,&g_408[8],&g_408[4],&g_323,(void*)0}}};
                        int8_t **l_877 = &l_878[1][4][1];
                        int32_t *l_894 = &l_627[9][1][6];
                        int32_t *l_895 = &g_104[2];
                        int32_t *l_896 = (void*)0;
                        int32_t *l_897 = &l_626;
                        int32_t *l_898 = &g_104[(g_441 + 6)];
                        int32_t *l_899 = &g_47[(g_714 + 1)][(g_714 + 5)][g_441];
                        int32_t *l_901[2];
                        int32_t l_908 = 0x7FF53B71L;
                        uint64_t ***l_940[8][10] = {{&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939},{&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939},{&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939},{&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939},{&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939},{&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939},{&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939,&l_939,&l_785,&l_939},{&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939,&l_939}};
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_901[i] = &l_615;
                        (*l_894) &= (safe_mul_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s(((safe_sub_func_uint64_t_u_u((g_104[(g_441 + 6)] <= (safe_unary_minus_func_int16_t_s((safe_add_func_int32_t_s_s((safe_rshift_func_int8_t_s_u(0xC7L, (+g_47[(g_714 + 1)][(g_714 + 5)][g_441]))), ((g_665[8] = ((((safe_lshift_func_uint16_t_u_s((l_631 |= ((safe_mod_func_uint8_t_u_u((((*l_877) = (void*)0) != &g_323), ((safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_u(g_406[2], 2)), ((safe_mod_func_uint32_t_u_u((&l_743 != ((g_408[8] ^= (((((l_626 = g_70) , ((((safe_mul_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(l_889, p_74)), p_74)) > (*g_275)) , g_145) >= l_890)) , l_891) < 0x40L) >= p_74)) , &l_743)), 6L)) == g_104[3]))) , g_636))) == g_47[(g_714 + 1)][(g_714 + 5)][g_441])), l_892)) , g_148) , l_889) & (*p_75))) || l_893)))))), 0x85146F568DC2F30DLL)) <= (-6L)), (*g_20))) , l_615), 12)) , p_74), 250UL));
                        ++l_927;
                        if ((*g_20))
                            break;
                        (*g_275) = (l_947 = ((*l_899) > (!((((safe_div_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((((l_923 |= (p_74 && (((p_74 != ((g_941 = (g_408[9] , l_939)) == (g_942[2][8][1] = &g_201))) == (0xA4E2BC208CE3CB60LL != (safe_mod_func_uint32_t_u_u((l_633[2] & p_74), l_945[3][3][0])))) , p_74))) <= g_145) , 0x2218C6B2L) | (*g_20)), 1UL)), l_946)), g_323)) <= p_74), l_903)) != 0L) > (*p_75)) >= 0x50B19CBD1A4AEBC8LL))));
                    }
                    for (l_889 = 0; (l_889 <= 9); l_889 += 1)
                    { /* block id: 381 */
                        int i;
                        (*l_653) = (void*)0;
                        if (g_104[(g_441 + 5)])
                            break;
                    }
                    g_104[(g_441 + 2)] = (-4L);
                    (*g_275) = ((((((*l_949) = g_104[(g_441 + 1)]) >= ((0L <= (g_104[(g_441 + 3)] != (g_441 || (l_633[8] <= p_74)))) & (-1L))) , &l_773) != l_950[0][0]) <= 0x11190C88BD3AD33CLL);
                    for (l_891 = 0; (l_891 <= 3); l_891 += 1)
                    { /* block id: 390 */
                        union U1 *l_956 = (void*)0;
                        int i, j, k;
                        (*p_75) = (0xB1013A6EL || ((*g_275) = ((&g_47[(l_891 + 2)][(g_441 + 1)][g_441] == (void*)0) != (safe_div_func_int16_t_s_s(p_74, 0x74BFL)))));
                        (*l_602) = l_955;
                        (*l_813) = l_956;
                        if (l_921)
                            break;
                    }
                }
                (*g_19) = (*g_19);
                if (((g_145 <= ((((**l_785) |= (safe_sub_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((9UL != (safe_sub_func_uint64_t_u_u(p_74, ((p_74 > ((*l_963) = (-7L))) > ((*l_975) = (safe_mod_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(0x565DL, ((safe_div_func_uint32_t_u_u((safe_div_func_int16_t_s_s(((p_74 != 0xFE69DEB3L) >= ((safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_int16_t_s(((0xD6ECBAA8L < g_174.f3) < (*p_75)))), g_104[2])) == l_904)), p_74)), p_74)) ^ 3L))), p_74))))))), l_927)), l_827))) ^ p_74) , l_976)) && 1UL))
                { /* block id: 402 */
                    uint8_t l_981 = 0x9DL;
                    int16_t l_1002 = 0x2243L;
                    uint32_t *l_1003 = (void*)0;
                    int32_t *l_1005 = &l_915;
                    int32_t *l_1006 = &l_905;
                    int32_t *l_1007 = &l_627[8][1][4];
                    int32_t *l_1008 = &l_626;
                    int32_t *l_1009 = &g_47[5][1][1];
                    int32_t *l_1010 = (void*)0;
                    int32_t *l_1011 = &l_900;
                    int32_t *l_1012 = (void*)0;
                    int32_t *l_1013 = &l_920;
                    int32_t *l_1014 = (void*)0;
                    int32_t *l_1015 = (void*)0;
                    int32_t *l_1016 = &l_910;
                    int32_t *l_1017[7][5] = {{(void*)0,&l_900,&l_921,&l_918,&l_921},{(void*)0,(void*)0,&l_626,&l_615,&l_627[9][1][6]},{&l_900,(void*)0,(void*)0,&l_900,&l_921},{&l_920,&l_615,(void*)0,(void*)0,(void*)0},{&l_631,&l_918,&l_902[7],&l_921,&l_921},{&l_615,&l_627[9][1][6],&l_615,&l_626,(void*)0},{&l_904,(void*)0,&l_921,(void*)0,&l_904}};
                    int32_t l_1019 = 1L;
                    int i, j;
                    l_890 ^= (((g_145 = ((p_74 | (safe_lshift_func_int16_t_s_s(((safe_add_func_uint64_t_u_u((((l_981 = 0xB74658ABF635F6E0LL) , ((safe_mul_func_uint8_t_u_u((0x15L & ((+(safe_div_func_int32_t_s_s((*p_75), (l_900 = ((safe_mod_func_uint64_t_u_u(((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u((~((safe_sub_func_int16_t_s_s(0x7E78L, 0xE632L)) > ((((safe_mod_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(l_798, (((*l_601) = (safe_sub_func_int32_t_s_s((-10L), (l_925 == l_1002)))) & 4294967287UL))), (-1L))) & l_889) ^ p_74) < 0x0AL))), 15)) | 0x76L), g_104[3])) != 0x8AL), p_74)) , 0x7268DECDL))))) > l_1004)), p_74)) == l_981)) <= g_103), p_74)) & p_74), g_2))) || l_902[7])) && 0xFB903CD5L) ^ l_927);
                    ++l_1021[1][2][1];
                    for (l_890 = 12; (l_890 <= (-3)); l_890 = safe_sub_func_int64_t_s_s(l_890, 6))
                    { /* block id: 411 */
                        uint32_t **l_1026 = &l_771;
                        uint32_t **l_1027 = &l_601;
                        int32_t l_1035 = 0xC9868EFCL;
                        int16_t *l_1036 = (void*)0;
                        int16_t *l_1037 = &l_1020[6];
                        if ((**g_19))
                            break;
                        (*l_1016) |= ((*l_1008) &= ((((((p_74 , (((0L == ((*l_1037) = ((((*l_1026) = l_1015) != ((*l_1027) = &g_406[2])) < ((((65529UL > (safe_div_func_uint8_t_u_u((p_74 | 65535UL), (safe_unary_minus_func_uint16_t_u((((((safe_div_func_int64_t_s_s((safe_add_func_int16_t_s_s((((*p_75) = l_610) > (*g_275)), g_148)), l_1035)) != (*g_20)) & 0UL) || l_1035) >= 0x52206704L)))))) ^ 6L) < l_1020[8]) | (*g_275))))) , g_233) > l_1035)) | g_714) ^ 0xE7872E7827C85EE9LL) != 1UL) ^ l_905) ^ l_900));
                        (*l_1013) ^= 1L;
                    }
                }
                else
                { /* block id: 421 */
                    int32_t *l_1038 = &l_918;
                    int32_t *l_1039 = (void*)0;
                    int32_t *l_1040 = (void*)0;
                    int32_t *l_1041 = &l_913;
                    int32_t *l_1042[1];
                    int64_t l_1045 = 4L;
                    uint8_t l_1048 = 0x70L;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1042[i] = &l_615;
                    ++l_1048;
                }
            }
        }
    }
    else
    { /* block id: 426 */
        const union U1 **l_1051 = &g_811;
        const int16_t *l_1060[1];
        const int16_t **l_1059 = &l_1060[0];
        int16_t *l_1062 = (void*)0;
        int16_t **l_1061 = &l_1062;
        int16_t ***l_1063[1];
        int32_t l_1076 = 0x84602211L;
        int8_t *l_1077 = &g_323;
        int64_t **l_1120 = &g_326[0];
        int32_t l_1129 = 0x26C1F79FL;
        uint32_t l_1139 = 18446744073709551615UL;
        const uint32_t *l_1150[5] = {&g_406[2],&g_406[2],&g_406[2],&g_406[2],&g_406[2]};
        const uint32_t **l_1149 = &l_1150[1];
        uint8_t *l_1250 = &l_1021[1][2][1];
        uint32_t l_1256 = 18446744073709551615UL;
        int i;
        for (i = 0; i < 1; i++)
            l_1060[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_1063[i] = &l_1061;
lbl_1225:
        (*l_1051) = l_775;
        if ((safe_add_func_int32_t_s_s(((*g_275) = (safe_lshift_func_uint8_t_u_s(p_74, 7))), ((safe_mul_func_int16_t_s_s((!(p_74 & ((l_1059 == (g_1064 = l_1061)) | (0L > (((**l_785) &= 4UL) == p_74))))), (safe_sub_func_int8_t_s_s((safe_rshift_func_int16_t_s_s((((0x75L && ((*l_1077) = (safe_div_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s((!l_1075), 6)), l_1076)))) >= l_1076) == g_1044), (*g_1065))), 0L)))) >= g_304))))
        { /* block id: 432 */
            int64_t l_1084 = 0x050CFAA92BBFE530LL;
            int32_t l_1089[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
            int64_t * const *l_1121[4];
            int16_t l_1122 = 0x0B99L;
            int8_t l_1214 = 0xF8L;
            uint16_t *l_1219 = &g_714;
            int16_t ***l_1220[10][5][2] = {{{&l_1061,&l_1061},{(void*)0,&l_1061},{(void*)0,&g_1064},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{&g_1064,&l_1061},{(void*)0,&l_1061},{&l_1061,(void*)0},{&g_1064,(void*)0},{&g_1064,&l_1061}},{{&l_1061,&l_1061},{(void*)0,&l_1061},{&l_1061,&l_1061},{&g_1064,(void*)0},{&g_1064,(void*)0}},{{&l_1061,&l_1061},{(void*)0,&l_1061},{&g_1064,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_1064}},{{(void*)0,&l_1061},{(void*)0,&l_1061},{&l_1061,(void*)0},{&l_1061,(void*)0},{&l_1061,(void*)0}},{{&l_1061,&l_1061},{(void*)0,&l_1061},{(void*)0,&g_1064},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{&g_1064,&l_1061},{(void*)0,&l_1061},{&l_1061,(void*)0},{&g_1064,(void*)0},{&g_1064,&l_1061}},{{&l_1061,&l_1061},{(void*)0,&l_1061},{&l_1061,&l_1061},{&g_1064,(void*)0},{&g_1064,(void*)0}},{{&l_1061,&l_1061},{(void*)0,&l_1061},{&g_1064,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_1064}},{{(void*)0,&l_1061},{(void*)0,&l_1061},{&l_1061,(void*)0},{&l_1061,(void*)0},{&l_1061,(void*)0}}};
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_1121[i] = &g_326[1];
            for (g_152.f3 = 0; (g_152.f3 == (-18)); g_152.f3 = safe_sub_func_uint8_t_u_u(g_152.f3, 9))
            { /* block id: 435 */
                uint8_t *l_1092 = &l_1021[1][2][1];
                uint8_t *l_1123 = &g_665[4];
                int32_t l_1124 = 7L;
                int32_t l_1125 = (-1L);
                uint8_t *l_1126 = (void*)0;
                uint8_t *l_1127[8] = {&g_1128,&g_1128,&g_1128,&g_1128,&g_1128,&g_1128,&g_1128,&g_1128};
                int32_t l_1130 = 0xF92A8693L;
                int32_t *l_1131 = &l_1075;
                uint16_t **l_1138[6][2][8] = {{{&l_743,&l_743,&g_819,&l_743,&g_819,(void*)0,&g_819,&l_743},{(void*)0,&g_819,(void*)0,&g_819,&g_819,&g_819,&g_819,&l_743}},{{&g_819,&g_819,&g_819,(void*)0,&l_743,&g_819,&g_819,&g_819},{&g_819,&l_743,&g_819,&g_819,&g_819,&g_819,&l_743,&g_819}},{{(void*)0,&l_743,&g_819,&g_819,&g_819,&g_819,(void*)0,&l_743},{&l_743,&g_819,&g_819,&g_819,&g_819,&g_819,&g_819,&g_819}},{{(void*)0,&l_743,&l_743,&l_743,&g_819,&g_819,&g_819,&g_819},{&g_819,&g_819,(void*)0,&g_819,&l_743,&g_819,(void*)0,(void*)0}},{{&g_819,(void*)0,(void*)0,&g_819,&g_819,&g_819,&g_819,(void*)0},{&l_743,&l_743,&g_819,&g_819,&g_819,&g_819,&g_819,&l_743}},{{(void*)0,&g_819,&l_743,&g_819,&g_819,&l_743,(void*)0,&l_743},{&g_819,&g_819,(void*)0,&g_819,(void*)0,&g_819,&g_819,(void*)0}}};
                uint32_t **l_1148 = (void*)0;
                const uint32_t ***l_1151 = (void*)0;
                const uint32_t ***l_1152 = (void*)0;
                const uint32_t ***l_1153[1][1][2];
                int16_t *l_1165 = &g_152.f3;
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 2; k++)
                            l_1153[i][j][k] = &l_1149;
                    }
                }
                (*l_1131) &= (safe_div_func_uint16_t_u_u(((((((l_1084 ^ (g_47[5][1][1] < (safe_sub_func_uint16_t_u_u((safe_div_func_int32_t_s_s((((l_1089[0] = p_74) | (p_74 , ((l_1130 ^= (((safe_lshift_func_uint8_t_u_s(((*l_1092)--), l_1076)) & ((safe_lshift_func_uint8_t_u_u(0xAAL, 3)) | (l_1129 |= (safe_mod_func_int32_t_s_s(((*p_75) |= (((safe_add_func_int64_t_s_s((l_1124 = ((**l_658) = (safe_sub_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_u(((*l_1123) = (safe_lshift_func_int8_t_s_u((((!(safe_div_func_int64_t_s_s(l_1084, (safe_mul_func_int8_t_s_s(((*l_1077) = l_1076), (safe_mod_func_uint32_t_u_u(((!((safe_lshift_func_int16_t_s_s(((*g_1065) = (((safe_mod_func_int16_t_s_s((l_1119 < p_74), (*g_1065))) , l_1120) != l_1121[0])), p_74)) >= 1UL)) < l_1122), (-7L)))))))) & g_714) & p_74), g_152.f3))), 0)) != (-2L)), 0xFAL)))), p_74)) | 5L) > l_1125)), (*g_275)))))) , (-1L))) >= l_1076))) > p_74), g_406[2])), 0x9D86L)))) != l_1076) , 18446744073709551610UL) , 0xB11B1AF2L) <= 0xE56A1092L) | l_1084), 1UL));
                if ((*g_20))
                    continue;
                (*p_75) = ((safe_rshift_func_uint16_t_u_s(((1L < (g_10[1][4][6] <= ((safe_lshift_func_uint8_t_u_u(((((safe_mod_func_uint64_t_u_u(((l_1138[2][0][1] == (void*)0) != l_1139), (safe_mod_func_int8_t_s_s(((safe_mod_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u(((l_1148 == (g_1155 = (g_1154 = l_1149))) != ((void*)0 == &g_811)), p_74)) | (*l_1131)), g_665[5])) >= p_74), l_1139)) , l_1076), 0x8EL)))) >= (*l_1131)) >= (*l_1131)) >= (*l_1131)), 5)) < (-5L)))) != l_1158[5]), p_74)) == 255UL);
                for (l_1129 = (-10); (l_1129 != 13); ++l_1129)
                { /* block id: 453 */
                    int16_t *l_1166[4][2][1] = {{{(void*)0},{(void*)0}},{{&g_152.f3},{(void*)0}},{{(void*)0},{&g_152.f3}},{{(void*)0},{(void*)0}}};
                    const int32_t l_1173 = 0x49A4EF8FL;
                    int32_t l_1188 = 0x50C66B62L;
                    union U0 ** const l_1192 = &g_767;
                    uint32_t l_1213 = 18446744073709551615UL;
                    int i, j, k;
                    for (l_634 = 0; (l_634 == (-17)); l_634 = safe_sub_func_uint16_t_u_u(l_634, 6))
                    { /* block id: 456 */
                        return (*p_75);
                    }
                }
            }
            (*g_275) ^= ((((safe_rshift_func_int16_t_s_s(((l_1060[0] != l_1219) || p_74), 13)) != (l_1220[6][3][1] != (void*)0)) >= ((void*)0 != l_1051)) & (g_1018 == (safe_add_func_int16_t_s_s(((safe_rshift_func_int8_t_s_u(l_1129, g_406[2])) == l_1122), 0x13A7L))));
            (*p_75) = l_1084;
        }
        else
        { /* block id: 479 */
            for (g_103 = 0; (g_103 <= 1); g_103 += 1)
            { /* block id: 482 */
                uint32_t l_1231 = 1UL;
                for (g_1128 = 0; (g_1128 <= 0); g_1128 += 1)
                { /* block id: 485 */
                    (*g_275) |= (-1L);
                    for (g_94 = 1; (g_94 >= 0); g_94 -= 1)
                    { /* block id: 489 */
                        int32_t *l_1226 = &l_907[2][8][1];
                        int32_t *l_1227 = &l_634;
                        int32_t *l_1228 = &l_1129;
                        int32_t *l_1229 = &l_904;
                        int32_t *l_1230[1][4] = {{&g_47[5][1][1],&g_47[5][1][1],&g_47[5][1][1],&g_47[5][1][1]}};
                        int i, j, k;
                        (*g_275) = l_1021[(g_94 + 2)][(g_1128 + 2)][g_94];
                        (*g_275) = 1L;
                        if (l_904)
                            goto lbl_1225;
                        --l_1231;
                    }
                }
                return (*p_75);
            }
        }
        (*p_75) = (safe_mul_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((safe_div_func_int32_t_s_s(((g_1044 > ((safe_lshift_func_int16_t_s_u(((((((safe_div_func_uint64_t_u_u((((**l_785) ^= (safe_rshift_func_int8_t_s_u(((safe_add_func_uint8_t_u_u(((*l_1250)--), (safe_unary_minus_func_int64_t_s(p_74)))) < 0x10A2L), 7))) <= ((safe_add_func_int64_t_s_s((((((**l_658) = l_1256) | ((safe_lshift_func_int16_t_s_u(((safe_mul_func_uint8_t_u_u(((g_750 = &g_304) == (l_1261 = &g_632)), (1L ^ ((((safe_add_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((((0xB759A49DDBCCA79ALL != (((((0xAFA9L <= l_1256) == p_74) == p_74) != (-4L)) ^ 4L)) > p_74) != l_1129), 5)), p_74)) < (*p_75)) == 0x8FL) <= 0L)))) && l_904), 8)) <= 0UL)) && l_1139) != g_406[0]), p_74)) || 0xA1D8981E237C47B7LL)), p_74)) < g_1018) || p_74) ^ 0x6A2C96E562BDB73BLL) <= l_1129) > 0x42L), 10)) < p_74)) < p_74), (*g_20))), p_74)), 0x97L));
        if ((safe_lshift_func_int8_t_s_u(0x06L, 1)))
        { /* block id: 505 */
            uint32_t **l_1269 = &l_601;
            uint32_t ***l_1270 = &l_1269;
            int16_t * const *l_1287 = &g_1065;
            int16_t * const **l_1286 = &l_1287;
            (*p_75) = ((*g_275) = (((*l_1270) = l_1269) == ((safe_sub_func_uint16_t_u_u(0x3E3CL, ((safe_lshift_func_int16_t_s_s(p_74, ((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_u((safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_s((-1L), 3)), (((**l_785) = (~p_74)) | (l_1256 || l_1256)))), (((void*)0 == l_1286) != 0xE9951F9FL))) < p_74) || (-1L)), p_74)), 255UL)) , p_74))) , 0xF3B1L))) , (void*)0)));
        }
        else
        { /* block id: 510 */
            uint16_t ***l_1288 = &l_950[4][3];
            (*g_275) = ((l_1288 = &g_818[2]) == (void*)0);
        }
    }
    return (*p_75);
}


/* ------------------------------------------ */
/* 
 * reads : g_253 g_87 g_20 g_10 g_304 g_406 g_104 g_103 g_176 g_145 g_275 g_408 g_19 g_184 g_185 g_233 g_70 g_60
 * writes: g_253 g_104 g_304 g_441 g_408 g_176 g_145 g_406 g_47 g_103 g_60 g_20 g_185 g_233 g_174.f3
 */
static int8_t  func_82(const uint64_t * p_83, int32_t * p_84, int32_t  p_85)
{ /* block id: 213 */
    int32_t *l_508 = &g_104[5];
    int32_t *l_509 = &g_104[5];
    int32_t *l_510 = &g_104[2];
    int32_t *l_511 = &g_103;
    int32_t *l_512 = &g_104[9];
    int32_t *l_513 = &g_104[2];
    int32_t *l_514[1][8][2] = {{{&g_104[2],&g_104[9]},{&g_47[5][1][1],&g_94},{&g_47[5][1][1],&g_104[9]},{&g_104[2],&g_104[2]},{&g_104[9],&g_47[5][1][1]},{&g_94,&g_47[5][1][1]},{&g_104[9],&g_104[2]},{&g_104[2],&g_104[9]}}};
    uint8_t l_515 = 255UL;
    int64_t *l_593 = &g_233;
    int16_t *l_596 = &g_174.f3;
    int i, j, k;
    l_515++;
    for (g_253 = 0; (g_253 <= 1); g_253 += 1)
    { /* block id: 217 */
        const uint16_t l_520 = 0x5C10L;
        int32_t l_538[10] = {0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L,0x08B50E12L};
        uint16_t l_540 = 4UL;
        int32_t l_541 = 0L;
        int32_t l_573 = 0x065501E3L;
        int i;
        if ((safe_lshift_func_uint16_t_u_s(((*p_83) , l_520), 13)))
        { /* block id: 218 */
            uint8_t l_523 = 255UL;
            if ((*g_20))
                break;
            (*l_509) = (safe_add_func_uint64_t_u_u((*p_83), (--l_523)));
        }
        else
        { /* block id: 222 */
            uint32_t l_537[8];
            uint8_t l_570 = 6UL;
            uint16_t l_571 = 0x07B2L;
            int i;
            for (i = 0; i < 8; i++)
                l_537[i] = 1UL;
            for (g_304 = 0; (g_304 <= 1); g_304 += 1)
            { /* block id: 225 */
                uint32_t l_526 = 0UL;
                int32_t **l_531[4][2] = {{&l_511,&l_511},{&l_511,&l_511},{&l_511,&l_511},{&l_511,&l_511}};
                uint64_t *l_539 = &g_441;
                uint8_t *l_544 = &l_515;
                int8_t *l_547 = &g_408[8];
                uint32_t *l_550 = &g_145;
                uint32_t *l_551 = &g_406[2];
                int64_t *l_572[4][3][7] = {{{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233,(void*)0},{&g_233,(void*)0,&g_233,&g_233,(void*)0,&g_233,(void*)0},{&g_233,&g_233,&g_233,&g_233,(void*)0,&g_233,&g_233}},{{(void*)0,(void*)0,&g_233,&g_233,&g_233,(void*)0,(void*)0},{(void*)0,&g_233,(void*)0,&g_233,(void*)0,(void*)0,&g_233},{(void*)0,(void*)0,(void*)0,&g_233,&g_233,(void*)0,(void*)0}},{{&g_233,(void*)0,(void*)0,(void*)0,(void*)0,&g_233,(void*)0},{(void*)0,&g_233,&g_233,(void*)0,(void*)0,(void*)0,&g_233},{(void*)0,(void*)0,&g_233,(void*)0,&g_233,(void*)0,(void*)0}},{{(void*)0,&g_233,&g_233,&g_233,(void*)0,(void*)0,&g_233},{&g_233,(void*)0,&g_233,&g_233,&g_233,&g_233,(void*)0},{&g_233,(void*)0,&g_233,&g_233,(void*)0,&g_233,(void*)0}}};
                int i, j, k;
                l_541 |= (((g_406[1] || l_526) & ((((*l_539) = ((safe_sub_func_int16_t_s_s(0x45AEL, g_253)) , (l_520 , (((safe_lshift_func_uint8_t_u_s((((void*)0 != l_531[2][1]) && (safe_mul_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(((!(((l_538[4] = (0UL == l_537[3])) && (*l_509)) , p_85)) || g_406[2]), g_406[0])), (*l_508)))), 2)) , &g_87) != p_83)))) < l_520) && 0xA6BF248C26EFAB0FLL)) != l_540);
                (*g_275) = (l_537[0] || (safe_mod_func_int8_t_s_s(((*l_547) = (((void*)0 != &g_326[1]) | (++(*l_544)))), (p_85 & (((*l_551) = (((*l_550) = (l_541 ^= (safe_mod_func_uint8_t_u_u(((*l_511) , (((((((((g_406[2] , 0x9F84L) == (g_176[8] &= g_104[5])) >= (g_10[2][0][5] , l_537[4])) && 0UL) ^ 2UL) & (*p_83)) ^ g_145) ^ g_304) <= 0x78252D0B0A86E23DLL)), g_87)))) >= (*p_84))) , 4L)))));
                (*g_19) = func_30(((safe_mul_func_int8_t_s_s(p_85, ((((*l_511) = (l_541 ^= ((5L | l_537[0]) > (safe_lshift_func_uint8_t_u_u((((*p_83) <= ((l_573 = (safe_lshift_func_int16_t_s_u(((p_85 , 0xE29DD1885BECD53ALL) || (safe_mul_func_uint8_t_u_u((((((((((((((safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(((safe_div_func_uint16_t_u_u(g_103, (safe_mod_func_int64_t_s_s((safe_sub_func_int16_t_s_s((p_85 && (-7L)), p_85)), 0xB6B204A71E08714DLL)))) & 0xB2BB1E63L), l_570)), 0xFC90L)) , 0UL) , p_85) , (void*)0) == &g_20) ^ g_145) & l_538[4]) || p_85) ^ g_408[8]) & p_85) , 1L) ^ p_85) == l_571), p_85))), (*l_512)))) && p_85)) ^ l_537[3]), 3))))) == l_520) ^ 1L))) , l_537[3]), p_84, l_537[3]);
                (*g_184) = (*g_184);
            }
        }
    }
    (*l_512) = ((g_10[2][6][4] , (safe_lshift_func_uint16_t_u_s((((safe_rshift_func_int16_t_s_u((~((*l_509) || ((safe_mod_func_uint16_t_u_u((safe_div_func_int16_t_s_s(g_253, ((*l_596) = (safe_mul_func_int16_t_s_s((safe_div_func_uint8_t_u_u((((((safe_sub_func_uint32_t_u_u((safe_sub_func_int64_t_s_s(((*l_593) &= (safe_div_func_uint8_t_u_u((p_85 == p_85), g_408[9]))), p_85)), (safe_add_func_uint32_t_u_u((g_408[0] > (*l_510)), (*l_513))))) & (*l_513)) & 0x5AL) , 0x41E42F5FL) , (*l_508)), 0x54L)), g_70))))), (*l_512))) & 6UL))), 0)) ^ (*p_83)) , 65529UL), 0))) == g_60);
    return p_85;
}


/* ------------------------------------------ */
/* 
 * reads : g_104 g_70 g_202 g_94 g_60 g_103 g_174.f3 g_168.f3 g_19 g_20 g_10 g_145 g_176 g_275 g_47 g_184 g_185 g_233 g_323 g_406 g_408 g_253 g_441 g_304 g_148 g_2 g_236.f3
 * writes: g_201 g_202 g_94 g_70 g_47 g_103 g_174.f3 g_168.f3 g_145 g_176 g_275 g_104 g_406 g_408 g_253 g_441 g_155.f3 g_148 g_236.f3 g_60
 */
static uint32_t  func_88(uint16_t  p_89, uint32_t  p_90)
{ /* block id: 85 */
    int32_t l_191 = 0x803F65F4L;
    uint64_t **l_203 = &g_202;
    union U0 ***l_204[4][9] = {{&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184},{&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184},{&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184},{&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184,&g_184}};
    int32_t *l_205 = &g_94;
    int32_t *l_206 = &g_70;
    int32_t *l_207 = &g_47[3][6][1];
    int32_t l_238 = (-7L);
    int16_t *l_271[5][2][3] = {{{&g_152.f3,&g_152.f3,&g_152.f3},{&g_168.f3,&g_168.f3,&g_168.f3}},{{&g_152.f3,&g_152.f3,&g_152.f3},{&g_168.f3,&g_168.f3,&g_168.f3}},{{&g_152.f3,&g_152.f3,&g_152.f3},{&g_168.f3,&g_168.f3,&g_168.f3}},{{&g_152.f3,&g_152.f3,&g_152.f3},{&g_168.f3,&g_168.f3,&g_168.f3}},{{&g_152.f3,&g_152.f3,&g_152.f3},{&g_168.f3,&g_168.f3,&g_168.f3}}};
    int32_t l_284 = 0x057BBC09L;
    int32_t l_285 = 9L;
    int32_t l_288 = 0x6CF2EFE8L;
    int32_t l_292 = 0L;
    int32_t l_294 = 0x850C3E0DL;
    int32_t l_297 = 0x3068350EL;
    int32_t l_298[3][7] = {{0x99A69BFDL,0xF460535FL,0x965B400EL,0x965B400EL,0xF460535FL,0x99A69BFDL,1L},{0x99A69BFDL,0xF460535FL,0x965B400EL,0x965B400EL,0xF460535FL,0x99A69BFDL,1L},{0x99A69BFDL,0xF460535FL,0x965B400EL,0x965B400EL,0xF460535FL,0x99A69BFDL,1L}};
    int16_t l_303 = 0x6233L;
    int8_t l_361 = 0xA1L;
    uint64_t l_363 = 0xB325E379C5A7B4FALL;
    int32_t *l_364 = &g_104[2];
    int32_t l_462 = 0xD3992348L;
    int i, j, k;
    g_103 ^= (safe_sub_func_int32_t_s_s(l_191, ((safe_sub_func_uint8_t_u_u(((safe_rshift_func_int8_t_s_s(p_89, g_104[0])) == l_191), (safe_div_func_int32_t_s_s(((*l_207) = ((*l_206) = ((*l_205) |= (((((safe_mul_func_int8_t_s_s(g_70, p_90)) > (0x1319184DCA25D329LL || (+((((((g_201 = (void*)0) != ((*l_203) = g_202)) , 0xD795C9B6659C981ELL) || p_89) && p_89) , p_90)))) <= 0x3CA8674CC7DA5D6DLL) , (void*)0) != l_204[1][1])))), g_60)))) < g_104[2])));
    for (g_174.f3 = (-26); (g_174.f3 <= (-23)); ++g_174.f3)
    { /* block id: 94 */
        uint32_t l_234 = 0x7E3E0D2DL;
        union U0 *l_235 = &g_236;
        const uint64_t l_249 = 0UL;
        int16_t *l_250[3][1];
        int32_t l_257 = 2L;
        int32_t l_280 = (-9L);
        int32_t l_281 = 0xB9C9771CL;
        int32_t l_282 = 9L;
        int32_t l_283 = 0xDD1D8D23L;
        int32_t l_286 = 0L;
        int32_t l_287 = (-3L);
        int32_t l_289 = 0xACDF0841L;
        int32_t l_290 = 0xA164C548L;
        int32_t l_291 = 1L;
        int32_t l_293 = (-1L);
        int32_t l_295 = 8L;
        int32_t l_296 = 0x680E14F9L;
        int32_t l_299 = 0xCC5D8070L;
        int32_t l_300 = 0x5D790C8DL;
        int32_t l_301 = 0L;
        int32_t l_302[10] = {(-1L),0x37224AA4L,(-1L),0x37224AA4L,(-1L),0x37224AA4L,(-1L),0x37224AA4L,(-1L),0x37224AA4L};
        int16_t l_324 = 0L;
        int64_t *l_325 = (void*)0;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_250[i][j] = &g_174.f3;
        }
        for (g_168.f3 = (-2); (g_168.f3 < (-20)); --g_168.f3)
        { /* block id: 97 */
            uint8_t l_226 = 255UL;
            int32_t **l_231 = &l_207;
            int16_t *l_232 = &g_152.f3;
            int32_t l_237[10] = {0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L,0xC7877F76L};
            int64_t l_278 = (-1L);
            int32_t *l_279[6];
            uint32_t l_305 = 0xF52DB4BCL;
            int8_t *l_322 = &g_323;
            int64_t *l_328 = &g_233;
            int64_t **l_327 = &l_328;
            int i;
            for (i = 0; i < 6; i++)
                l_279[i] = &l_191;
        }
        if ((**g_19))
            break;
    }
    for (g_145 = 0; (g_145 < 29); ++g_145)
    { /* block id: 139 */
        uint16_t *l_347[7];
        int32_t l_360 = 5L;
        int64_t *l_362[10][9] = {{&g_233,(void*)0,(void*)0,&g_304,(void*)0,(void*)0,&g_304,(void*)0,(void*)0},{&g_233,&g_304,&g_304,&g_233,(void*)0,&g_304,&g_304,(void*)0,&g_233},{&g_233,&g_304,&g_233,&g_304,&g_304,&g_233,&g_304,&g_304,&g_233},{&g_304,&g_304,&g_233,&g_304,&g_304,&g_233,(void*)0,&g_304,&g_304},{(void*)0,(void*)0,&g_233,&g_304,&g_233,(void*)0,(void*)0,&g_304,(void*)0},{(void*)0,(void*)0,&g_304,&g_233,(void*)0,&g_233,&g_304,(void*)0,(void*)0},{(void*)0,&g_233,&g_304,&g_304,&g_233,&g_233,&g_233,&g_304,&g_304},{(void*)0,(void*)0,&g_304,&g_233,(void*)0,&g_304,(void*)0,&g_304,(void*)0},{(void*)0,&g_233,&g_233,(void*)0,&g_233,(void*)0,&g_304,&g_304,&g_304},{(void*)0,&g_233,&g_304,&g_304,&g_233,(void*)0,(void*)0,(void*)0,&g_304}};
        int32_t **l_365[10][2][6];
        uint64_t l_459[1];
        int32_t l_501 = 5L;
        int64_t l_504 = 3L;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_347[i] = &g_176[8];
        for (i = 0; i < 10; i++)
        {
            for (j = 0; j < 2; j++)
            {
                for (k = 0; k < 6; k++)
                    l_365[i][j][k] = (void*)0;
            }
        }
        for (i = 0; i < 1; i++)
            l_459[i] = 0xAE2400A7F5142F57LL;
        (*l_206) = ((-1L) > (l_363 = ((p_89 > ((safe_mul_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s(p_89, (safe_rshift_func_uint16_t_u_s((p_90 != (safe_lshift_func_uint8_t_u_s(((((*l_205) = p_90) > (safe_add_func_uint32_t_u_u(0UL, (safe_sub_func_int8_t_s_s(((((p_90 & (safe_rshift_func_uint16_t_u_u((--g_176[8]), (safe_div_func_uint8_t_u_u(255UL, (safe_rshift_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((safe_rshift_func_int16_t_s_u((safe_div_func_uint8_t_u_u((p_89 & (*g_275)), p_90)), 12)) != 2UL) & 0xC745L), 0xD9E53581L)), l_360))))))) & p_89) , &l_298[2][4]) == (*g_19)), (*l_207)))))) || 9L), l_361))), 10)))) != g_70), 8L)) & 0x2A805C9324BEC069LL)) > 0x5DEE8C98L)));
        g_275 = l_364;
        for (g_94 = (-7); (g_94 != (-8)); g_94 = safe_sub_func_uint32_t_u_u(g_94, 2))
        { /* block id: 147 */
            int16_t l_386 = 0x18DCL;
            int32_t l_387 = 7L;
            const uint32_t *l_388 = &g_145;
            uint8_t l_398[4][5] = {{0xEBL,0xEBL,0xEBL,0xEBL,0xEBL},{255UL,255UL,255UL,255UL,255UL},{0xEBL,0xEBL,0xEBL,0xEBL,0xEBL},{255UL,255UL,255UL,255UL,255UL}};
            int32_t l_449 = 7L;
            int32_t l_450 = 0x74731A7AL;
            int32_t l_454 = 0x4AD7A4BEL;
            int32_t l_455 = 0xDF75DB71L;
            int32_t l_456 = 6L;
            int32_t l_457 = (-4L);
            int32_t l_458[2][10][6] = {{{5L,1L,0L,0xFAA541C9L,1L,0x86AD9FF1L},{0x86AD9FF1L,0x1E9459AAL,0xD605B91AL,0xFAA541C9L,0xB75675D8L,0xFAA541C9L},{5L,0x3CE15001L,5L,0L,(-1L),(-4L)},{5L,0xD8488520L,0x29737CB8L,0xFAA541C9L,0xD8488520L,0x5546D369L},{0x86AD9FF1L,0xB75675D8L,0xD3FB5A29L,0xFAA541C9L,0x90B1CABDL,0L},{5L,0x7D92B08AL,0x86AD9FF1L,0L,0x3CE15001L,0xD605B91AL},{5L,4L,0xFAA541C9L,0xFAA541C9L,4L,5L},{0x86AD9FF1L,0x90B1CABDL,(-4L),0xFAA541C9L,0x1E9459AAL,0x29737CB8L},{5L,(-1L),0x5546D369L,0L,0x7D92B08AL,0xD3FB5A29L},{5L,1L,0L,0xFAA541C9L,1L,0x86AD9FF1L}},{{0x86AD9FF1L,0x1E9459AAL,0xD605B91AL,0xFAA541C9L,0xB75675D8L,0xFAA541C9L},{5L,0x3CE15001L,5L,0L,(-1L),(-4L)},{5L,0xD8488520L,0x29737CB8L,0xFAA541C9L,0xD8488520L,0x5546D369L},{0x86AD9FF1L,0xB75675D8L,0xD3FB5A29L,0xFAA541C9L,0x90B1CABDL,0L},{5L,0x7D92B08AL,0x86AD9FF1L,0L,0x3CE15001L,0xD605B91AL},{5L,4L,0xFAA541C9L,0xFAA541C9L,4L,5L},{0x86AD9FF1L,0x90B1CABDL,(-4L),0xFAA541C9L,0x1E9459AAL,0x29737CB8L},{5L,(-1L),0x5546D369L,0L,0x7D92B08AL,0xD3FB5A29L},{5L,1L,0L,0xFAA541C9L,1L,0x86AD9FF1L},{0x86AD9FF1L,0x1E9459AAL,0xD605B91AL,0xFAA541C9L,0xB75675D8L,0xFAA541C9L}}};
            int i, j, k;
            for (g_103 = 2; (g_103 >= 0); g_103 -= 1)
            { /* block id: 150 */
                int32_t *l_410[4][8] = {{(void*)0,&l_288,(void*)0,&g_104[2],&l_288,&g_10[2][6][4],&g_10[2][6][4],&l_288},{&l_288,&g_10[2][6][4],&g_10[2][6][4],&l_288,&g_104[2],(void*)0,&l_288,(void*)0},{&l_288,&l_294,&g_10[2][6][5],&l_294,&l_288,&g_10[2][6][5],(void*)0,(void*)0},{(void*)0,&l_294,&g_104[2],&g_104[2],&l_294,(void*)0,&g_10[2][6][4],&l_294}};
                union U0 **l_411 = &g_185;
                uint8_t l_434 = 0xCCL;
                int i, j;
                if ((safe_rshift_func_uint8_t_u_u(l_298[g_103][(g_103 + 1)], 4)))
                { /* block id: 151 */
                    uint16_t l_378[10][7] = {{65532UL,1UL,0x530DL,0x6FE9L,0x530DL,1UL,65532UL},{0x0C05L,0xD227L,65535UL,65529UL,0x559DL,0x97D9L,0x5961L},{0x0785L,1UL,0xD471L,65533UL,0x0785L,65533UL,0xD471L},{0x559DL,0x559DL,65535UL,0x5961L,0x0C05L,65535UL,0xD227L},{0x530DL,65535UL,0x530DL,65533UL,65532UL,65535UL,65532UL},{65529UL,0x5961L,0x5961L,65529UL,0x0C05L,65535UL,0x97D9L},{0x0785L,0x6FE9L,0x106BL,0x6FE9L,0x0785L,65535UL,0x106BL},{65535UL,0x559DL,0xD227L,0xD227L,0x559DL,65535UL,0x97D9L},{65532UL,65533UL,0x530DL,65535UL,0x530DL,65533UL,65532UL},{65535UL,0xD227L,0x97D9L,65529UL,65529UL,0x97D9L,0xD227L}};
                    int i, j;
                    if ((((+(safe_add_func_uint64_t_u_u(6UL, (safe_sub_func_uint64_t_u_u(((l_387 = (p_89 = ((p_89 < (safe_div_func_int64_t_s_s((l_378[4][6] = (~(*l_205))), (safe_mul_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u((p_89 >= g_10[1][5][1]), 8)), (safe_unary_minus_func_uint8_t_u(g_176[8]))))))) <= (safe_rshift_func_uint16_t_u_s((((l_386 ^ ((*g_184) != (*g_184))) , 0x8C3DFA595A85423CLL) , g_233), (*l_364)))))) | 3UL), l_386))))) , l_388) == (void*)0))
                    { /* block id: 155 */
                        const int32_t *l_391 = &g_70;
                        const int32_t **l_390 = &l_391;
                        (*l_364) = (+(*l_207));
                        (*l_206) = p_90;
                        (*l_390) = (*g_19);
                    }
                    else
                    { /* block id: 159 */
                        uint32_t *l_405[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int8_t *l_407[1];
                        int32_t l_409 = (-7L);
                        int i;
                        for (i = 0; i < 1; i++)
                            l_407[i] = &l_361;
                        (*g_275) = (((0xBE3FFED5L || (safe_div_func_int64_t_s_s((l_378[1][0] && (0x5DL && g_323)), (safe_div_func_uint8_t_u_u(p_89, ((safe_rshift_func_int8_t_s_s(l_398[1][3], (g_408[8] = (safe_add_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(((g_406[2] ^= 0x9E7C6FAAL) <= (((void*)0 == &l_386) || g_104[4])), 0x13L)) ^ 0UL), (*l_207)))))) | 0x56A7662CDD30DC64LL)))))) == p_90) , 0x656C4C73L);
                        if (l_409)
                            break;
                    }
                    l_410[2][0] = &l_387;
                }
                else
                { /* block id: 166 */
                    union U0 **l_412 = (void*)0;
                    uint16_t l_420 = 65535UL;
                    int32_t l_447 = 0x8413C5CFL;
                    int32_t l_448 = 0x1109FB84L;
                    int32_t l_453[1];
                    int64_t l_463 = 1L;
                    uint8_t l_464 = 248UL;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_453[i] = 0L;
                    if ((((l_411 = (void*)0) != l_412) || ((safe_add_func_uint32_t_u_u((safe_div_func_int16_t_s_s(p_90, (~(safe_sub_func_int32_t_s_s(((0x17L ^ 0x4EL) , p_90), (l_420 , p_89)))))), l_387)) ^ g_104[3])))
                    { /* block id: 168 */
                        uint64_t *l_427 = &l_363;
                        uint64_t *l_437 = &g_253;
                        uint64_t *l_440 = &g_441;
                        int32_t l_445[5][1] = {{0L},{(-3L)},{0L},{(-3L)},{0L}};
                        int i, j;
                        (*g_275) = ((safe_lshift_func_int16_t_s_s((*l_205), (g_155[3][1].f3 = (safe_sub_func_uint8_t_u_u((p_89 || p_90), (((p_90 >= ((((((g_408[9] , (safe_sub_func_uint64_t_u_u((--(*l_427)), (((safe_rshift_func_int16_t_s_u(0x1371L, 8)) && ((safe_add_func_int64_t_s_s(((l_434 > ((safe_div_func_uint8_t_u_u((((*l_440) &= ((*l_437)++)) ^ (((safe_unary_minus_func_uint32_t_u((safe_rshift_func_uint8_t_u_u(g_304, (((l_445[2][0] = p_90) | 0x9C2D89C04322BBD3LL) == g_176[1]))))) , p_90) , 18446744073709551607UL)), 0x5AL)) <= p_90)) >= p_89), p_90)) >= 0xB6385858740637E2LL)) <= g_47[5][2][0])))) >= g_148) & 0x57F7L) , 0L) != 3L) & (*g_275))) != g_103) <= p_90)))))) < g_2);
                    }
                    else
                    { /* block id: 175 */
                        const int32_t *l_446 = &l_238;
                        l_410[2][0] = &l_387;
                        l_446 = (*g_19);
                    }
                    (*l_206) = (-1L);
                    for (g_148 = 0; (g_148 <= 1); g_148 += 1)
                    { /* block id: 182 */
                        int32_t l_451 = (-5L);
                        int32_t l_452[3];
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_452[i] = 0x654DC8DDL;
                        l_459[0]--;
                        --l_464;
                    }
                }
                return g_104[2];
            }
            if ((*l_205))
                break;
            if ((**g_19))
                break;
        }
        if (p_89)
        { /* block id: 192 */
            int32_t l_469 = (-1L);
            uint32_t *l_482 = &g_406[2];
            l_469 = (safe_add_func_int64_t_s_s((-8L), (l_469 , (l_469 & (((((safe_sub_func_int64_t_s_s(0x938D1B6D45D71162LL, ((safe_add_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u(g_103, g_408[8])) , (safe_rshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s((((*l_482) = (p_90 && (2L <= ((*l_207) = (0x5F2CA809A42870F1LL | p_89))))) || 1UL), p_90)), 9))), (*l_364))) , p_90))) && 0xD239L) , 0x6EBD3F06L) == (-8L)) != 1UL)))));
            return g_104[2];
        }
        else
        { /* block id: 197 */
            int32_t l_488 = (-1L);
            int32_t l_489 = 0L;
            int32_t l_491 = 8L;
            int32_t l_492[9][4][7] = {{{0L,0x9F41DDB1L,0x9F41DDB1L,0L,(-1L),0x77636DDBL,0x5E0D26D7L},{0x92675F20L,0xA39681ABL,0x73981DD3L,0xA112D293L,0xA0B21617L,0x92675F20L,0x92675F20L},{0L,0x5E0D26D7L,0xCE06F598L,0x5E0D26D7L,0L,3L,0x5E0D26D7L},{0xBD115495L,0x61F3CC80L,0x3A21DF84L,0xA0B21617L,0x73981DD3L,0x3A21DF84L,0xDA892971L}},{{0x9F41DDB1L,0x3E8C6C34L,0L,0L,0x3E8C6C34L,0x9F41DDB1L,(-1L)},{0xBD115495L,0xA0B21617L,0L,0xBD115495L,0xDA892971L,(-1L),0xA0B21617L},{0L,0xB0A56FE6L,0x9F41DDB1L,0xDA3F8B6EL,0x9F41DDB1L,0xB0A56FE6L,0L},{0x92675F20L,0xA0B21617L,0xA112D293L,0x73981DD3L,0xA39681ABL,0x92675F20L,0x73981DD3L}},{{0L,0x3E8C6C34L,(-1L),0x5E0D26D7L,0x5E0D26D7L,(-1L),0x3E8C6C34L},{0xA0B21617L,0x61F3CC80L,0xA112D293L,0x5893E5B5L,0x61F3CC80L,0x73981DD3L,0xDA892971L},{0x77636DDBL,0x5E0D26D7L,0x9F41DDB1L,0x77636DDBL,0x3E8C6C34L,0x77636DDBL,0x9F41DDB1L},{0xA39681ABL,0xA39681ABL,0L,0x5893E5B5L,0xA0B21617L,2L,0xA39681ABL}},{{0L,0x9F41DDB1L,0L,0x5E0D26D7L,0xB0A56FE6L,0xB0A56FE6L,0x5E0D26D7L},{0x3A21DF84L,0xDA892971L,0x3A21DF84L,0x73981DD3L,0xA0B21617L,0x3A21DF84L,0x61F3CC80L},{0x5E0D26D7L,0x3E8C6C34L,0xCE06F598L,0xDA3F8B6EL,0x3E8C6C34L,0xB8B03CFDL,0x3E8C6C34L},{0xBD115495L,0x73981DD3L,0x73981DD3L,0xBD115495L,0x61F3CC80L,0x3A21DF84L,0xA0B21617L}},{{0xB0A56FE6L,0L,0x9F41DDB1L,0L,0x5E0D26D7L,0xB0A56FE6L,0xB0A56FE6L},{0xA39681ABL,0xA0B21617L,0xEEE1171DL,0xA0B21617L,0xA39681ABL,2L,0xA0B21617L},{0L,(-1L),0x77636DDBL,0x5E0D26D7L,0x9F41DDB1L,0x77636DDBL,0x3E8C6C34L},{0x73981DD3L,0xDA892971L,0xA112D293L,0xA112D293L,0xDA892971L,0x73981DD3L,2L}},{{0L,0x77636DDBL,0L,0L,0xB0A56FE6L,0xDA3F8B6EL,0x77636DDBL},{0x73981DD3L,0L,(-1L),0x61F3CC80L,(-1L),0L,0x73981DD3L},{0xB8B03CFDL,0x77636DDBL,1L,(-1L),0x9F41DDB1L,0xB8B03CFDL,(-1L)},{0xA112D293L,0x92675F20L,0x5893E5B5L,0x3A21DF84L,0x3A21DF84L,0x5893E5B5L,0x92675F20L}},{{0x77636DDBL,3L,1L,(-1L),3L,(-1L),0xB0A56FE6L},{0xEEE1171DL,0x3A21DF84L,(-1L),0xEEE1171DL,0x92675F20L,0xEEE1171DL,(-1L)},{0x9F41DDB1L,0x9F41DDB1L,0L,(-1L),0x77636DDBL,0x5E0D26D7L,0x9F41DDB1L},{0x73981DD3L,(-1L),0x4D40593DL,0x3A21DF84L,0L,0L,0x3A21DF84L}},{{0xCE06F598L,0xB0A56FE6L,0xCE06F598L,(-1L),0x77636DDBL,0xCE06F598L,3L},{0x3A21DF84L,0x92675F20L,0xDA892971L,0x61F3CC80L,0x92675F20L,0xBD115495L,0x92675F20L},{0L,(-1L),(-1L),0L,3L,0xCE06F598L,0x77636DDBL},{0L,0x73981DD3L,(-1L),0x4D40593DL,0x3A21DF84L,0L,0L}},{{0x9F41DDB1L,0x77636DDBL,0x3E8C6C34L,0x77636DDBL,0x9F41DDB1L,0x5E0D26D7L,0x77636DDBL},{0xA112D293L,2L,0xEEE1171DL,0x3A21DF84L,(-1L),0xEEE1171DL,0x92675F20L},{(-1L),0xB0A56FE6L,1L,1L,0xB0A56FE6L,(-1L),3L},{0xA112D293L,0x3A21DF84L,0xBD115495L,0xA112D293L,0x92675F20L,0x5893E5B5L,0x3A21DF84L}}};
            uint8_t l_505 = 255UL;
            int i, j, k;
            for (g_236.f3 = 1; (g_236.f3 >= 0); g_236.f3 -= 1)
            { /* block id: 200 */
                uint32_t l_483 = 0xCFA0B696L;
                const int32_t *l_487 = &g_70;
                const int32_t **l_486 = &l_487;
                int32_t l_490 = 0xB4AD28C2L;
                int32_t l_493 = 0xA60E739FL;
                int32_t l_494 = 0x543E31D0L;
                int32_t l_495 = 0x6F0DEDEEL;
                int32_t l_496 = (-9L);
                int32_t l_497 = 0x903545B2L;
                int32_t l_498 = (-1L);
                int32_t l_499 = 0xC2B57B12L;
                int32_t l_500 = 0L;
                int32_t l_502[10][6][2] = {{{(-1L),(-1L)},{0xFD223439L,0x4B72F697L},{(-3L),8L},{0xF197085EL,0x75167E72L},{0x3412618EL,0xF197085EL},{0xD6DC3CF5L,(-1L)}},{{0xD6DC3CF5L,0xF197085EL},{0x3412618EL,0x75167E72L},{0xF197085EL,8L},{(-3L),0x4B72F697L},{0xFD223439L,(-1L)},{(-1L),0x0EECC642L}},{{0x72DFE671L,(-10L)},{0xF197085EL,(-7L)},{1L,0xD1EC6F33L},{0xAE255001L,(-1L)},{0xD763FB99L,0xC9586375L},{0x1BBE75F0L,(-9L)}},{{0xF197085EL,(-9L)},{0x1BBE75F0L,0xC9586375L},{0xD763FB99L,(-1L)},{0xAE255001L,0xD1EC6F33L},{1L,(-7L)},{0xF197085EL,(-10L)}},{{0x72DFE671L,0x0EECC642L},{(-1L),(-1L)},{0xFD223439L,0x4B72F697L},{(-3L),8L},{0xF197085EL,0x75167E72L},{0x3412618EL,0xF197085EL}},{{0xD6DC3CF5L,(-1L)},{0xD6DC3CF5L,0xF197085EL},{0x3412618EL,0x75167E72L},{0xF197085EL,8L},{(-3L),0x4B72F697L},{0xFD223439L,(-1L)}},{{(-1L),0x0EECC642L},{0x72DFE671L,(-10L)},{0xF197085EL,0xFD223439L},{(-1L),(-3L)},{0x0EECC642L,0xF197085EL},{0xD1EC6F33L,0x3412618EL}},{{0x72FBA2F9L,0xD6DC3CF5L},{0x1BBE75F0L,0xD6DC3CF5L},{0x72FBA2F9L,0x3412618EL},{0xD1EC6F33L,0xF197085EL},{0x0EECC642L,(-3L)},{(-1L),0xFD223439L}},{{0x1BBE75F0L,(-1L)},{1L,0x72DFE671L},{0xF197085EL,0xF197085EL},{0x4B72F697L,1L},{0xA05C152BL,0xAE255001L},{0x1BBE75F0L,0xD763FB99L}},{{0x81F548BCL,0x1BBE75F0L},{0xC9586375L,0xF197085EL},{0xC9586375L,0x1BBE75F0L},{0x81F548BCL,0xD763FB99L},{0x1BBE75F0L,0xAE255001L},{0xA05C152BL,1L}}};
                int32_t l_503 = 2L;
                int i, j, k;
                l_483--;
                (*l_486) = (*g_19);
                ++l_505;
                for (g_60 = 0; (g_60 <= 1); g_60 += 1)
                { /* block id: 206 */
                    return g_60;
                }
            }
        }
    }
    return p_90;
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_109 g_104 g_10 g_70 g_47 g_87 g_19 g_20 g_94 g_103 g_184 g_176
 * writes: g_60 g_94 g_70 g_103 g_104 g_47 g_5 g_145 g_148 g_176 g_184
 */
static int8_t  func_91(int32_t * p_92, int32_t  p_93)
{ /* block id: 28 */
    int8_t l_118[10][4][6] = {{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}},{{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L},{0x08L,0x08L,0x08L,0x08L,0x08L,0x08L}}};
    int32_t l_121 = 0xF32220C7L;
    int32_t l_125 = (-7L);
    int32_t l_126 = 0x89889316L;
    int32_t l_128 = (-6L);
    int32_t l_130[2][1];
    int32_t l_132[8][1][10] = {{{0L,0L,0xE0EDF683L,0x6ACA0D50L,0L,0L,0x6ACA0D50L,0xE0EDF683L,0L,0L}},{{0L,0x6ACA0D50L,0xE0EDF683L,0L,0L,0xE0EDF683L,0x6ACA0D50L,0L,0L,0x6ACA0D50L}},{{0L,0L,0x6ACA0D50L,0x6ACA0D50L,0L,0L,0xE0EDF683L,0xE0EDF683L,0L,0L}},{{0L,0x6ACA0D50L,0x6ACA0D50L,0L,0L,0xE0EDF683L,0xE0EDF683L,0L,0L,0x6ACA0D50L}},{{0L,0L,0xE0EDF683L,0x6ACA0D50L,0L,0L,0x6ACA0D50L,0xE0EDF683L,0L,0L}},{{0L,0x6ACA0D50L,0xE0EDF683L,0L,0L,0xE0EDF683L,0x6ACA0D50L,0L,0L,0x6ACA0D50L}},{{0L,0L,0x6ACA0D50L,0x6ACA0D50L,0L,0L,0xE0EDF683L,0xE0EDF683L,0L,0L}},{{0L,0x6ACA0D50L,0x6ACA0D50L,0L,0L,0xE0EDF683L,0xE0EDF683L,0L,0L,0x6ACA0D50L}}};
    int16_t l_161 = (-9L);
    int32_t l_162 = 9L;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_130[i][j] = 1L;
    }
    for (g_60 = 15; (g_60 > (-10)); --g_60)
    { /* block id: 31 */
        int32_t *l_114 = &g_47[6][7][0];
        int32_t l_123[6] = {1L,1L,0L,1L,1L,0L};
        union U0 *l_151 = &g_152;
        int i;
        for (p_93 = 21; (p_93 >= 8); p_93--)
        { /* block id: 34 */
            int8_t l_107 = 2L;
            int32_t l_108[8][9] = {{0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L},{1L,0xEA90673AL,1L,0xEA90673AL,1L,0xEA90673AL,1L,0xEA90673AL,1L},{0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L},{(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L)},{0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L},{1L,0xEA90673AL,1L,0xEA90673AL,1L,0xEA90673AL,1L,0xEA90673AL,1L},{0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L,0x757E1CA6L,(-1L),(-1L),0x757E1CA6L},{(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L),0xEA90673AL,(-1L)}};
            union U0 *l_154 = &g_155[3][1];
            uint64_t l_163 = 1UL;
            int i, j;
            for (g_94 = 0; (g_94 >= 10); g_94++)
            { /* block id: 37 */
                union U0 **l_111 = (void*)0;
                union U0 *l_113 = (void*)0;
                union U0 **l_112 = &l_113;
                for (g_70 = 0; g_70 < 7; g_70 += 1)
                {
                    for (g_103 = 0; g_103 < 9; g_103 += 1)
                    {
                        for (g_104[2] = 0; g_104[2] < 4; g_104[2] += 1)
                        {
                            g_47[g_70][g_103][g_104[2]] = 0x7535322EL;
                        }
                    }
                }
                for (g_70 = (-6); (g_70 > 10); g_70 = safe_add_func_uint32_t_u_u(g_70, 7))
                { /* block id: 41 */
                    l_108[4][8] = l_107;
                }
                (*l_112) = g_109;
                l_114 = &p_93;
            }
            for (g_70 = 0; (g_70 <= 3); g_70 += 1)
            { /* block id: 49 */
                int8_t l_117 = (-6L);
                int32_t l_119 = 0xE6373546L;
                int32_t l_120 = 0xE7F7E744L;
                int32_t l_122 = 0x2CDE1B85L;
                int32_t l_124 = (-8L);
                int32_t l_127 = 9L;
                int32_t l_129[9] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
                int32_t l_131 = 0xD3381A7BL;
                uint64_t l_133[7] = {0x763C7C4FD43417B0LL,0x763C7C4FD43417B0LL,8UL,0x763C7C4FD43417B0LL,0x763C7C4FD43417B0LL,8UL,0x763C7C4FD43417B0LL};
                union U0 *l_166[9] = {&g_167,&g_167,&g_167,&g_167,&g_167,&g_167,&g_167,&g_167,&g_167};
                int i;
                for (l_107 = 0; (l_107 <= 3); l_107 += 1)
                { /* block id: 52 */
                    int32_t *l_115 = (void*)0;
                    int32_t *l_116[4] = {&g_104[2],&g_104[2],&g_104[2],&g_104[2]};
                    int i, j, k;
                    ++l_133[0];
                }
                for (g_94 = 0; (g_94 <= 3); g_94 += 1)
                { /* block id: 57 */
                    int32_t **l_136 = (void*)0;
                    int32_t **l_137 = (void*)0;
                    int32_t **l_138[4] = {&g_5,&g_5,&g_5,&g_5};
                    uint32_t *l_144 = &g_145;
                    union U0 **l_153 = &l_151;
                    uint64_t *l_160 = &l_133[6];
                    int i, j, k;
                    if ((*p_92))
                        break;
                    g_5 = &l_132[7][0][3];
                    l_108[4][8] &= (safe_div_func_int64_t_s_s((!(((((safe_mod_func_uint32_t_u_u(((*l_144) = l_130[1][0]), (safe_sub_func_uint8_t_u_u((g_148 = 0UL), g_70)))) > (safe_lshift_func_uint16_t_u_u(g_47[5][8][1], (((*l_153) = l_151) != l_154)))) , (void*)0) != (((safe_mul_func_int8_t_s_s(((p_92 = &g_104[5]) == ((safe_mod_func_uint64_t_u_u(((*l_160) = ((l_107 ^ p_93) || g_87)), g_60)) , (*g_19))), 0x0DL)) ^ g_104[3]) , &g_20)) < g_104[2])), g_10[2][6][4]));
                    --l_163;
                }
                l_166[3] = g_109;
            }
        }
        for (l_125 = 0; (l_125 < (-22)); l_125 = safe_sub_func_int16_t_s_s(l_125, 1))
        { /* block id: 73 */
            union U0 **l_171 = &l_151;
            int32_t l_172 = 0x37835E58L;
            union U0 *l_173 = &g_174;
            uint16_t *l_175 = &g_176[8];
            uint32_t *l_180 = &g_145;
            union U0 ***l_186 = &g_184;
            int32_t *l_187 = (void*)0;
            int32_t *l_188 = &l_132[7][0][3];
            (*l_171) = (p_93 , g_109);
            if (l_172)
                continue;
            (*l_188) ^= (((*l_180) = (((l_173 != ((*l_171) = (((*l_175) = 0x03E0L) , l_151))) <= g_70) == (safe_rshift_func_int8_t_s_s((p_93 ^ (+0x15L)), 6)))) != (((((safe_sub_func_uint64_t_u_u(g_103, ((~(&l_173 != ((*l_186) = g_184))) <= p_93))) , 18446744073709551614UL) || 18446744073709551614UL) , 0xF8BFL) & p_93));
        }
        if ((*p_92))
            break;
    }
    return g_176[8];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_10[i][j][k], "g_10[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_47[i][j][k], "g_47[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_110.f0, "g_110.f0", print_hash_value);
    transparent_crc(g_145, "g_145", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_152.f0, "g_152.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_155[i][j].f0, "g_155[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_167.f0, "g_167.f0", print_hash_value);
    transparent_crc(g_168.f0, "g_168.f0", print_hash_value);
    transparent_crc(g_174.f0, "g_174.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_176[i], "g_176[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_233, "g_233", print_hash_value);
    transparent_crc(g_236.f0, "g_236.f0", print_hash_value);
    transparent_crc(g_253, "g_253", print_hash_value);
    transparent_crc(g_304, "g_304", print_hash_value);
    transparent_crc(g_323, "g_323", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_406[i], "g_406[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_408[i], "g_408[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_441, "g_441", print_hash_value);
    transparent_crc(g_632, "g_632", print_hash_value);
    transparent_crc(g_636, "g_636", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_665[i], "g_665[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_714, "g_714", print_hash_value);
    transparent_crc(g_768.f0, "g_768.f0", print_hash_value);
    transparent_crc(g_812.f0, "g_812.f0", print_hash_value);
    transparent_crc(g_812.f1, "g_812.f1", print_hash_value);
    transparent_crc(g_1018, "g_1018", print_hash_value);
    transparent_crc(g_1044, "g_1044", print_hash_value);
    transparent_crc(g_1128, "g_1128", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1157[i], "g_1157[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1262[i], "g_1262[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1334.f0, "g_1334.f0", print_hash_value);
    transparent_crc(g_1334.f1, "g_1334.f1", print_hash_value);
    transparent_crc(g_1364, "g_1364", print_hash_value);
    transparent_crc(g_1369, "g_1369", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1516[i], "g_1516[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1571[i][j][k].f0, "g_1571[i][j][k].f0", print_hash_value);
                transparent_crc(g_1571[i][j][k].f1, "g_1571[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1673[i][j], "g_1673[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1810.f0, "g_1810.f0", print_hash_value);
    transparent_crc(g_1822.f0, "g_1822.f0", print_hash_value);
    transparent_crc(g_1822.f1, "g_1822.f1", print_hash_value);
    transparent_crc(g_1873.f0, "g_1873.f0", print_hash_value);
    transparent_crc(g_1905, "g_1905", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1963[i], "g_1963[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1969, "g_1969", print_hash_value);
    transparent_crc(g_1981.f0, "g_1981.f0", print_hash_value);
    transparent_crc(g_1986.f0, "g_1986.f0", print_hash_value);
    transparent_crc(g_2004.f0, "g_2004.f0", print_hash_value);
    transparent_crc(g_2004.f1, "g_2004.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2005[i].f0, "g_2005[i].f0", print_hash_value);
        transparent_crc(g_2005[i].f1, "g_2005[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2006.f0, "g_2006.f0", print_hash_value);
    transparent_crc(g_2006.f1, "g_2006.f1", print_hash_value);
    transparent_crc(g_2066.f0, "g_2066.f0", print_hash_value);
    transparent_crc(g_2081, "g_2081", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2083[i], "g_2083[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2093, "g_2093", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2141[i][j][k].f0, "g_2141[i][j][k].f0", print_hash_value);
                transparent_crc(g_2141[i][j][k].f1, "g_2141[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2159[i][j], "g_2159[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2163, "g_2163", print_hash_value);
    transparent_crc(g_2172, "g_2172", print_hash_value);
    transparent_crc(g_2234.f0, "g_2234.f0", print_hash_value);
    transparent_crc(g_2234.f1, "g_2234.f1", print_hash_value);
    transparent_crc(g_2300.f0, "g_2300.f0", print_hash_value);
    transparent_crc(g_2300.f1, "g_2300.f1", print_hash_value);
    transparent_crc(g_2316, "g_2316", print_hash_value);
    transparent_crc(g_2360.f0, "g_2360.f0", print_hash_value);
    transparent_crc(g_2360.f1, "g_2360.f1", print_hash_value);
    transparent_crc(g_2434, "g_2434", print_hash_value);
    transparent_crc(g_2438, "g_2438", print_hash_value);
    transparent_crc(g_2445, "g_2445", print_hash_value);
    transparent_crc(g_2457, "g_2457", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_2467[i][j].f0, "g_2467[i][j].f0", print_hash_value);
            transparent_crc(g_2467[i][j].f1, "g_2467[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2468[i].f0, "g_2468[i].f0", print_hash_value);
        transparent_crc(g_2468[i].f1, "g_2468[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2506[i][j][k], "g_2506[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2511, "g_2511", print_hash_value);
    transparent_crc(g_2520.f0, "g_2520.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_2590[i][j].f0, "g_2590[i][j].f0", print_hash_value);
            transparent_crc(g_2590[i][j].f1, "g_2590[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2631.f0, "g_2631.f0", print_hash_value);
    transparent_crc(g_2631.f1, "g_2631.f1", print_hash_value);
    transparent_crc(g_2698.f0, "g_2698.f0", print_hash_value);
    transparent_crc(g_2698.f1, "g_2698.f1", print_hash_value);
    transparent_crc(g_2740, "g_2740", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 748
XXX total union variables: 19

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 50
breakdown:
   depth: 1, occurrence: 332
   depth: 2, occurrence: 83
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 3
   depth: 18, occurrence: 6
   depth: 19, occurrence: 4
   depth: 20, occurrence: 4
   depth: 21, occurrence: 5
   depth: 22, occurrence: 2
   depth: 23, occurrence: 5
   depth: 25, occurrence: 3
   depth: 26, occurrence: 7
   depth: 27, occurrence: 3
   depth: 28, occurrence: 1
   depth: 29, occurrence: 4
   depth: 30, occurrence: 4
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 35, occurrence: 5
   depth: 40, occurrence: 3
   depth: 42, occurrence: 1
   depth: 47, occurrence: 2
   depth: 50, occurrence: 1

XXX total number of pointers: 534

XXX times a variable address is taken: 1333
XXX times a pointer is dereferenced on RHS: 299
breakdown:
   depth: 1, occurrence: 221
   depth: 2, occurrence: 63
   depth: 3, occurrence: 15
XXX times a pointer is dereferenced on LHS: 345
breakdown:
   depth: 1, occurrence: 327
   depth: 2, occurrence: 15
   depth: 3, occurrence: 3
XXX times a pointer is compared with null: 51
XXX times a pointer is compared with address of another variable: 15
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 12808

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1314
   level: 2, occurrence: 390
   level: 3, occurrence: 98
   level: 4, occurrence: 4
XXX number of pointers point to pointers: 218
XXX number of pointers point to scalars: 299
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29
XXX average alias set size: 1.46

XXX times a non-volatile is read: 2165
XXX times a non-volatile is write: 1068
XXX times a volatile is read: 29
XXX    times read thru a pointer: 14
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3.91e+03
XXX percentage of non-volatile access: 99

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 332
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 27
   depth: 2, occurrence: 48
   depth: 3, occurrence: 52
   depth: 4, occurrence: 71
   depth: 5, occurrence: 100

XXX percentage a fresh-made variable is used: 14.6
XXX percentage an existing variable is used: 85.4
********************* end of statistics **********************/

