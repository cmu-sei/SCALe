/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      361228907
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   signed f0 : 20;
   const signed f1 : 27;
   const unsigned f2 : 18;
};
#pragma pack(pop)

struct S1 {
   volatile int32_t  f0;
   volatile unsigned f1 : 6;
   const signed f2 : 18;
   volatile unsigned f3 : 3;
};

struct S2 {
   const signed f0 : 21;
   uint8_t  f1;
   int16_t  f2;
   const struct S0  f3;
   int16_t  f4;
   const uint64_t  f5;
   volatile uint8_t  f6;
   volatile struct S1  f7;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 0x0DA0BDBDL;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0xD95DA228L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 6L;
static volatile int32_t g_6[1][3] = {{8L,8L,8L}};
static int32_t g_7 = (-1L);
static int32_t g_9 = 0xF88D9675L;
static uint32_t g_48 = 4294967293UL;
static int8_t g_49 = 0x81L;
static uint8_t g_69 = 1UL;
static int32_t g_84 = 1L;
static struct S1 g_93[2][8] = {{{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0}},{{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0},{-9L,7,-453,0}}};
static const struct S1 *g_92 = &g_93[1][3];
static const struct S1 ** volatile g_94 = (void*)0;/* VOLATILE GLOBAL g_94 */
static const struct S1 ** volatile g_95[3] = {&g_92,&g_92,&g_92};
static const struct S1 ** volatile g_96 = &g_92;/* VOLATILE GLOBAL g_96 */
static uint8_t g_105 = 0x92L;
static uint32_t g_119 = 0x053C14B3L;
static int8_t g_121 = 0xA3L;
static int8_t g_123 = 0xBEL;
static uint8_t *g_137 = &g_105;
static uint8_t **g_136 = &g_137;
static uint8_t **g_138 = &g_137;
static volatile struct S2 g_141 = {848,255UL,-4L,{-263,11269,357},0L,0x518D710777038A06LL,0x41L,{0xCE23272CL,1,-273,1}};/* VOLATILE GLOBAL g_141 */
static int32_t *g_145 = &g_84;
static int32_t **g_144[9][9][3] = {{{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,(void*)0},{&g_145,(void*)0,&g_145},{(void*)0,&g_145,(void*)0},{&g_145,&g_145,&g_145}},{{(void*)0,&g_145,&g_145},{(void*)0,&g_145,&g_145},{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145},{(void*)0,&g_145,&g_145},{&g_145,&g_145,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145}},{{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,(void*)0},{&g_145,&g_145,&g_145},{&g_145,(void*)0,&g_145}},{{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145}},{{(void*)0,&g_145,&g_145},{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145},{(void*)0,&g_145,&g_145},{&g_145,&g_145,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145}},{{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,(void*)0},{&g_145,&g_145,&g_145},{&g_145,(void*)0,&g_145},{&g_145,&g_145,&g_145}},{{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,&g_145},{&g_145,&g_145,&g_145},{&g_145,(void*)0,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145},{(void*)0,&g_145,&g_145}},{{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145},{(void*)0,&g_145,&g_145},{&g_145,&g_145,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145}},{{(void*)0,&g_145,(void*)0},{&g_145,&g_145,&g_145},{&g_145,&g_145,&g_145},{&g_145,&g_145,(void*)0},{&g_145,&g_145,&g_145},{&g_145,(void*)0,&g_145},{&g_145,(void*)0,&g_145},{&g_145,&g_145,&g_145},{(void*)0,&g_145,&g_145}}};
static int64_t g_163 = 0x4275F2EE7B83AFE1LL;
static int16_t g_166 = 8L;
static uint16_t g_168 = 0x0B45L;
static int16_t g_169 = 1L;
static volatile int32_t g_183 = (-1L);/* VOLATILE GLOBAL g_183 */
static uint32_t *g_202 = &g_119;
static int32_t ***g_205 = &g_144[4][2][2];
static uint32_t g_209 = 1UL;
static int32_t g_214 = 0L;
static volatile struct S1 g_217 = {0xE17F5D89L,5,207,0};/* VOLATILE GLOBAL g_217 */
static struct S2 g_228 = {-318,0UL,-10L,{-878,1130,169},0x6188L,0x7C297B866B586D94LL,0x15L,{0x376F26C4L,3,501,1}};/* VOLATILE GLOBAL g_228 */
static struct S2 g_229 = {-1232,0x83L,0x092EL,{-517,-1870,264},0xA5F3L,0UL,8UL,{0x401A2E84L,2,494,1}};/* VOLATILE GLOBAL g_229 */
static struct S1 g_277 = {0L,5,214,1};/* VOLATILE GLOBAL g_277 */
static struct S2 g_278[9] = {{1208,246UL,1L,{784,-3469,350},-4L,0x8F44888DD2009CEDLL,0x09L,{0x2B0DF9F3L,7,334,1}},{768,255UL,0x3CAEL,{142,3876,315},1L,6UL,255UL,{1L,2,30,0}},{1208,246UL,1L,{784,-3469,350},-4L,0x8F44888DD2009CEDLL,0x09L,{0x2B0DF9F3L,7,334,1}},{768,255UL,0x3CAEL,{142,3876,315},1L,6UL,255UL,{1L,2,30,0}},{1208,246UL,1L,{784,-3469,350},-4L,0x8F44888DD2009CEDLL,0x09L,{0x2B0DF9F3L,7,334,1}},{768,255UL,0x3CAEL,{142,3876,315},1L,6UL,255UL,{1L,2,30,0}},{1208,246UL,1L,{784,-3469,350},-4L,0x8F44888DD2009CEDLL,0x09L,{0x2B0DF9F3L,7,334,1}},{768,255UL,0x3CAEL,{142,3876,315},1L,6UL,255UL,{1L,2,30,0}},{1208,246UL,1L,{784,-3469,350},-4L,0x8F44888DD2009CEDLL,0x09L,{0x2B0DF9F3L,7,334,1}}};
static volatile struct S1 g_281 = {0x085F6703L,6,-504,0};/* VOLATILE GLOBAL g_281 */
static struct S2 g_305[1][10][9] = {{{{1072,0UL,0xFD3CL,{878,7643,99},0x069CL,18446744073709551615UL,1UL,{0xB57440BBL,7,-10,1}},{-706,255UL,0x06EAL,{-616,2611,353},0L,0UL,250UL,{8L,5,-43,1}},{301,3UL,0x22AFL,{-67,3389,453},0xBCC9L,0x6377D892B7D04263LL,255UL,{0xFC062B1DL,4,389,1}},{732,0x9EL,1L,{797,505,431},9L,0UL,0UL,{8L,7,463,0}},{648,255UL,0x65DCL,{-287,-7639,215},1L,0x066F0E95BBEDBF36LL,249UL,{0x7BA598CCL,6,-280,1}},{1094,250UL,-1L,{-476,-10654,336},0x5211L,18446744073709551614UL,0UL,{-8L,5,74,0}},{-640,249UL,1L,{600,5253,63},-1L,0x936D6041AD61AE6CLL,255UL,{-8L,0,169,1}},{140,0x07L,0xA0E5L,{-786,10102,71},0x2C85L,18446744073709551606UL,0x74L,{0xB81CB72EL,4,241,1}},{1325,0x19L,0xD9D1L,{617,-7587,339},0x7848L,0x3DFA595A85423C13LL,0xAEL,{-1L,0,361,1}}},{{-706,255UL,0x06EAL,{-616,2611,353},0L,0UL,250UL,{8L,5,-43,1}},{64,1UL,0xFD60L,{-322,5846,2},1L,5UL,255UL,{6L,6,97,1}},{1344,255UL,0L,{-662,4262,369},-7L,0x8DF115A7B03AEDEELL,6UL,{-2L,6,95,0}},{1155,0x65L,1L,{990,-5470,300},0L,0UL,0UL,{-9L,0,-461,1}},{837,0xA1L,0xAA90L,{-392,-1584,153},0x624DL,0xC2A805C9324BEC06LL,0xEFL,{0x35DEE8C9L,0,-5,0}},{732,0x9EL,1L,{797,505,431},9L,0UL,0UL,{8L,7,463,0}},{1094,250UL,-1L,{-476,-10654,336},0x5211L,18446744073709551614UL,0UL,{-8L,5,74,0}},{-140,0x46L,0x4B78L,{-695,-11287,460},3L,0x2B8E166F187F81E8LL,0x55L,{0xE729135AL,2,-137,0}},{1430,1UL,0x3111L,{956,1095,253},0x751FL,18446744073709551606UL,250UL,{0x97CE6600L,7,-261,1}}},{{-431,2UL,0x7796L,{-264,8007,390},0x9E29L,18446744073709551612UL,2UL,{-8L,0,148,0}},{140,0x07L,0xA0E5L,{-786,10102,71},0x2C85L,18446744073709551606UL,0x74L,{0xB81CB72EL,4,241,1}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{1384,248UL,0x9419L,{136,6339,203},0x6FFAL,0x68A6DDACA1B0B983LL,0xF0L,{0L,3,-501,0}},{-311,0x85L,-4L,{962,-5666,247},0L,0x19D763D559D433BALL,0x37L,{0xD4718C70L,6,-127,1}},{-27,0x65L,0x0604L,{841,-5033,46},-8L,0x9FA72BA41123DACCLL,249UL,{0x04CD6CF8L,1,103,0}},{1072,0UL,0xFD3CL,{878,7643,99},0x069CL,18446744073709551615UL,1UL,{0xB57440BBL,7,-10,1}},{1344,255UL,0L,{-662,4262,369},-7L,0x8DF115A7B03AEDEELL,6UL,{-2L,6,95,0}},{1344,255UL,0L,{-662,4262,369},-7L,0x8DF115A7B03AEDEELL,6UL,{-2L,6,95,0}}},{{837,0xA1L,0xAA90L,{-392,-1584,153},0x624DL,0xC2A805C9324BEC06LL,0xEFL,{0x35DEE8C9L,0,-5,0}},{59,0xD0L,0xFAA8L,{379,6810,467},0x0D08L,0x4883A07420DEE21BLL,0x5CL,{6L,0,259,1}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{1238,251UL,0xF7ADL,{-268,2207,399},0L,0x4E41BF4CAF491075LL,0x24L,{0x4DA04BA7L,1,-35,0}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{59,0xD0L,0xFAA8L,{379,6810,467},0x0D08L,0x4883A07420DEE21BLL,0x5CL,{6L,0,259,1}},{837,0xA1L,0xAA90L,{-392,-1584,153},0x624DL,0xC2A805C9324BEC06LL,0xEFL,{0x35DEE8C9L,0,-5,0}},{-625,0xB0L,0L,{-745,-9523,210},0x1522L,0UL,255UL,{1L,3,-197,0}},{-1122,0x6EL,0xC743L,{-256,10900,446},0xB556L,0x62880767B325E379LL,4UL,{-1L,7,26,1}}},{{1430,1UL,0x3111L,{956,1095,253},0x751FL,18446744073709551606UL,250UL,{0x97CE6600L,7,-261,1}},{859,251UL,-7L,{-771,3472,420},0L,18446744073709551615UL,0UL,{0xC1123FF1L,3,-440,0}},{1344,255UL,0L,{-662,4262,369},-7L,0x8DF115A7B03AEDEELL,6UL,{-2L,6,95,0}},{-625,0xB0L,0L,{-745,-9523,210},0x1522L,0UL,255UL,{1L,3,-197,0}},{1155,0x65L,1L,{990,-5470,300},0L,0UL,0UL,{-9L,0,-461,1}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{-706,255UL,0x06EAL,{-616,2611,353},0L,0UL,250UL,{8L,5,-43,1}},{732,0x9EL,1L,{797,505,431},9L,0UL,0UL,{8L,7,463,0}},{-835,0x64L,0x7212L,{614,9198,99},0xBD59L,0x1F9C3E5F62A79737LL,0UL,{-5L,1,369,0}}},{{732,0x9EL,1L,{797,505,431},9L,0UL,0UL,{8L,7,463,0}},{-140,0x46L,0x4B78L,{-695,-11287,460},3L,0x2B8E166F187F81E8LL,0x55L,{0xE729135AL,2,-137,0}},{301,3UL,0x22AFL,{-67,3389,453},0xBCC9L,0x6377D892B7D04263LL,255UL,{0xFC062B1DL,4,389,1}},{859,251UL,-7L,{-771,3472,420},0L,18446744073709551615UL,0UL,{0xC1123FF1L,3,-440,0}},{1027,5UL,4L,{-292,-1336,472},-1L,0UL,1UL,{0L,3,-79,0}},{648,255UL,0x65DCL,{-287,-7639,215},1L,0x066F0E95BBEDBF36LL,249UL,{0x7BA598CCL,6,-280,1}},{1384,248UL,0x9419L,{136,6339,203},0x6FFAL,0x68A6DDACA1B0B983LL,0xF0L,{0L,3,-501,0}},{-625,0xB0L,0L,{-745,-9523,210},0x1522L,0UL,255UL,{1L,3,-197,0}},{61,252UL,-1L,{715,-6843,90},9L,0xCAAA314B29B03E1DLL,0xBAL,{2L,1,303,1}}},{{832,255UL,0x0269L,{917,-1739,474},0xE877L,0UL,0x5CL,{0x7CB75CA9L,3,-0,1}},{-524,0UL,-7L,{-535,6102,153},0xAAB4L,0x7388A2AF69D36941LL,0x65L,{0xE78C9CE5L,4,-60,1}},{61,252UL,-1L,{715,-6843,90},9L,0xCAAA314B29B03E1DLL,0xBAL,{2L,1,303,1}},{1325,0x19L,0xD9D1L,{617,-7587,339},0x7848L,0x3DFA595A85423C13LL,0xAEL,{-1L,0,361,1}},{1394,0x6BL,-7L,{341,-458,379},-7L,1UL,1UL,{0xE957D3D4L,3,-462,0}},{-625,0xB0L,0L,{-745,-9523,210},0x1522L,0UL,255UL,{1L,3,-197,0}},{136,0x65L,0x70BBL,{-32,9388,268},-9L,5UL,0x6AL,{0x02289046L,6,494,1}},{1344,255UL,0L,{-662,4262,369},-7L,0x8DF115A7B03AEDEELL,6UL,{-2L,6,95,0}},{-140,0x46L,0x4B78L,{-695,-11287,460},3L,0x2B8E166F187F81E8LL,0x55L,{0xE729135AL,2,-137,0}}},{{-140,0x46L,0x4B78L,{-695,-11287,460},3L,0x2B8E166F187F81E8LL,0x55L,{0xE729135AL,2,-137,0}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{832,255UL,0x0269L,{917,-1739,474},0xE877L,0UL,0x5CL,{0x7CB75CA9L,3,-0,1}},{1325,0x19L,0xD9D1L,{617,-7587,339},0x7848L,0x3DFA595A85423C13LL,0xAEL,{-1L,0,361,1}},{1325,0x19L,0xD9D1L,{617,-7587,339},0x7848L,0x3DFA595A85423C13LL,0xAEL,{-1L,0,361,1}},{832,255UL,0x0269L,{917,-1739,474},0xE877L,0UL,0x5CL,{0x7CB75CA9L,3,-0,1}},{260,7UL,0x9E53L,{-853,8051,137},0L,9UL,0xF4L,{1L,7,259,1}},{-140,0x46L,0x4B78L,{-695,-11287,460},3L,0x2B8E166F187F81E8LL,0x55L,{0xE729135AL,2,-137,0}},{-706,255UL,0x06EAL,{-616,2611,353},0L,0UL,250UL,{8L,5,-43,1}}},{{381,7UL,0x0D64L,{-294,-8726,397},-9L,0x3B39E1A2263929AFLL,0xC6L,{0xDF845B01L,1,-90,0}},{-431,2UL,0x7796L,{-264,8007,390},0x9E29L,18446744073709551612UL,2UL,{-8L,0,148,0}},{1325,0x19L,0xD9D1L,{617,-7587,339},0x7848L,0x3DFA595A85423C13LL,0xAEL,{-1L,0,361,1}},{859,251UL,-7L,{-771,3472,420},0L,18446744073709551615UL,0UL,{0xC1123FF1L,3,-440,0}},{136,0x65L,0x70BBL,{-32,9388,268},-9L,5UL,0x6AL,{0x02289046L,6,494,1}},{301,3UL,0x22AFL,{-67,3389,453},0xBCC9L,0x6377D892B7D04263LL,255UL,{0xFC062B1DL,4,389,1}},{1430,1UL,0x3111L,{956,1095,253},0x751FL,18446744073709551606UL,250UL,{0x97CE6600L,7,-261,1}},{140,0x07L,0xA0E5L,{-786,10102,71},0x2C85L,18446744073709551606UL,0x74L,{0xB81CB72EL,4,241,1}},{233,0x54L,0x5023L,{-10,1480,463},7L,0x45E4628A9877D3E9LL,0x46L,{0x21A4FC54L,4,494,0}}},{{136,0x65L,0x70BBL,{-32,9388,268},-9L,5UL,0x6AL,{0x02289046L,6,494,1}},{1394,0x6BL,-7L,{341,-458,379},-7L,1UL,1UL,{0xE957D3D4L,3,-462,0}},{1238,251UL,0xF7ADL,{-268,2207,399},0L,0x4E41BF4CAF491075LL,0x24L,{0x4DA04BA7L,1,-35,0}},{-625,0xB0L,0L,{-745,-9523,210},0x1522L,0UL,255UL,{1L,3,-197,0}},{832,255UL,0x0269L,{917,-1739,474},0xE877L,0UL,0x5CL,{0x7CB75CA9L,3,-0,1}},{829,0x7CL,7L,{-909,-298,459},0x7066L,1UL,247UL,{-9L,5,-473,1}},{859,251UL,-7L,{-771,3472,420},0L,18446744073709551615UL,0UL,{0xC1123FF1L,3,-440,0}},{1155,0x65L,1L,{990,-5470,300},0L,0UL,0UL,{-9L,0,-461,1}},{-706,255UL,0x06EAL,{-616,2611,353},0L,0UL,250UL,{8L,5,-43,1}}}}};
static struct S1 g_308 = {0xA39FC44FL,1,51,1};/* VOLATILE GLOBAL g_308 */
static uint32_t *g_310 = &g_209;
static int32_t * volatile g_311 = &g_7;/* VOLATILE GLOBAL g_311 */
static struct S1 g_326 = {0xFA90737FL,4,-82,1};/* VOLATILE GLOBAL g_326 */
static uint32_t g_365 = 0x05A6E97CL;
static struct S1 g_376 = {-1L,0,255,1};/* VOLATILE GLOBAL g_376 */
static uint64_t g_399[4] = {18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL};
static struct S1 *g_417 = (void*)0;
static struct S1 * const *g_416[2] = {&g_417,&g_417};
static struct S1 g_419 = {0x29A6743CL,6,49,0};/* VOLATILE GLOBAL g_419 */
static uint32_t **g_421[2] = {(void*)0,(void*)0};
static volatile uint32_t g_472 = 1UL;/* VOLATILE GLOBAL g_472 */
static volatile int64_t g_477 = 0L;/* VOLATILE GLOBAL g_477 */
static const volatile int64_t * volatile g_476 = &g_477;/* VOLATILE GLOBAL g_476 */
static const volatile int64_t * volatile *g_475 = &g_476;
static uint64_t g_500 = 0x819832AA6CD671A2LL;
static const struct S1 g_505[9] = {{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1},{-1L,1,485,1}};
static uint16_t g_525 = 65531UL;
static struct S0 g_541 = {13,-10797,107};
static struct S0 *g_540 = &g_541;
static struct S0 g_544 = {-806,-2583,508};
static const struct S2 g_578[6][5] = {{{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{1068,0x21L,0x88C1L,{216,9138,103},1L,18446744073709551615UL,0xD8L,{0x1FC06942L,3,431,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}}},{{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{-477,1UL,0xA0C0L,{416,-9110,192},0x8097L,18446744073709551612UL,0xF7L,{-8L,1,311,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}}},{{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{1068,0x21L,0x88C1L,{216,9138,103},1L,18446744073709551615UL,0xD8L,{0x1FC06942L,3,431,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}}},{{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{-477,1UL,0xA0C0L,{416,-9110,192},0x8097L,18446744073709551612UL,0xF7L,{-8L,1,311,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}}},{{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{1068,0x21L,0x88C1L,{216,9138,103},1L,18446744073709551615UL,0xD8L,{0x1FC06942L,3,431,0}},{-1032,0x66L,-1L,{741,-1886,190},3L,0x1A71107104D961C2LL,248UL,{-1L,0,-243,0}},{-782,0xA0L,1L,{-829,10528,494},0xA0DDL,0x8C9EA31A11C084ABLL,0x36L,{0x88746B2AL,3,202,0}}},{{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{-477,1UL,0xA0C0L,{416,-9110,192},0x8097L,18446744073709551612UL,0xF7L,{-8L,1,311,0}},{-1044,0x2CL,0L,{617,-3871,189},0xDE82L,0x2F340B5B707F08B5LL,1UL,{0L,7,-186,0}},{1167,0x3CL,6L,{-127,1510,93},8L,1UL,0x3BL,{1L,3,495,0}}}};
static struct S1 **g_581[8][4][6] = {{{&g_417,&g_417,&g_417,&g_417,(void*)0,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}},{{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417},{&g_417,&g_417,&g_417,&g_417,&g_417,&g_417}}};
static struct S1 ***g_580[6][1] = {{&g_581[2][1][1]},{&g_581[2][3][1]},{&g_581[2][1][1]},{&g_581[2][3][1]},{&g_581[2][1][1]},{&g_581[2][3][1]}};
static uint16_t *g_601 = &g_168;
static struct S2 g_608 = {-140,255UL,0xF41DL,{493,6910,139},0x1154L,0UL,1UL,{0xF598C61FL,3,-316,0}};/* VOLATILE GLOBAL g_608 */
static struct S1 g_614 = {-1L,3,-287,1};/* VOLATILE GLOBAL g_614 */
static volatile struct S2 g_634 = {689,0UL,0x4B26L,{217,-6534,289},0x853FL,0x5F0478069F4DAD03LL,0xC6L,{-7L,0,-41,0}};/* VOLATILE GLOBAL g_634 */
static struct S0 **g_641 = &g_540;
static struct S2 g_663 = {1138,5UL,0xA7D5L,{683,1182,114},0xE2FAL,0x3CA840E3108EF2E6LL,255UL,{0xD48E1684L,6,-447,1}};/* VOLATILE GLOBAL g_663 */
static int32_t ** volatile g_705 = &g_145;/* VOLATILE GLOBAL g_705 */
static volatile struct S2 g_710 = {-512,0x94L,0xF9CEL,{338,3420,18},0x7292L,6UL,0UL,{0L,7,137,1}};/* VOLATILE GLOBAL g_710 */
static volatile struct S2 g_734 = {1292,252UL,0x9DEBL,{-718,720,293},0xD73FL,1UL,0x5DL,{4L,3,-91,1}};/* VOLATILE GLOBAL g_734 */
static int64_t *g_741[2] = {&g_163,&g_163};
static int64_t **g_740 = &g_741[1];
static int64_t ***g_739 = &g_740;
static int64_t g_781 = 0L;
static struct S1 g_799 = {0x8FD8AE62L,3,330,0};/* VOLATILE GLOBAL g_799 */
static struct S2 g_805 = {876,7UL,0xEB8EL,{94,10157,58},1L,0xAB4C11250152CB22LL,0xF8L,{7L,2,379,0}};/* VOLATILE GLOBAL g_805 */
static const struct S1 ** volatile g_836 = &g_92;/* VOLATILE GLOBAL g_836 */
static struct S2 *g_849 = (void*)0;
static uint32_t **g_852 = &g_202;
static uint32_t *** volatile g_851 = &g_852;/* VOLATILE GLOBAL g_851 */
static const int32_t ** volatile g_879 = (void*)0;/* VOLATILE GLOBAL g_879 */
static const int32_t *g_881 = &g_7;
static struct S2 g_920 = {587,8UL,0L,{-498,-526,65},0xA700L,18446744073709551613UL,0x3BL,{1L,6,435,0}};/* VOLATILE GLOBAL g_920 */
static struct S1 g_926 = {0xD2340990L,7,201,0};/* VOLATILE GLOBAL g_926 */
static volatile struct S2 g_929[6][1] = {{{1045,8UL,0x31C7L,{-980,-9505,334},0x0F9DL,18446744073709551610UL,1UL,{0x8C137C1EL,1,184,0}}},{{479,8UL,0x820DL,{242,8368,392},0x5E77L,6UL,0xA5L,{0xD32713F0L,5,191,0}}},{{1045,8UL,0x31C7L,{-980,-9505,334},0x0F9DL,18446744073709551610UL,1UL,{0x8C137C1EL,1,184,0}}},{{1045,8UL,0x31C7L,{-980,-9505,334},0x0F9DL,18446744073709551610UL,1UL,{0x8C137C1EL,1,184,0}}},{{479,8UL,0x820DL,{242,8368,392},0x5E77L,6UL,0xA5L,{0xD32713F0L,5,191,0}}},{{1045,8UL,0x31C7L,{-980,-9505,334},0x0F9DL,18446744073709551610UL,1UL,{0x8C137C1EL,1,184,0}}}};
static uint16_t g_950[7][1] = {{0UL},{0x4BC0L},{65535UL},{65535UL},{0x4BC0L},{65535UL},{65535UL}};
static int32_t g_981[6] = {0x785A7C96L,(-1L),0x785A7C96L,0x785A7C96L,(-1L),0x785A7C96L};
static struct S2 g_982 = {3,0x67L,0x8A2DL,{-232,3463,178},-1L,0x6468B4E5B4F23C6ALL,0xFEL,{-4L,1,57,0}};/* VOLATILE GLOBAL g_982 */
static struct S1 g_986 = {0x1BE8B41AL,0,-195,0};/* VOLATILE GLOBAL g_986 */
static struct S1 g_988 = {0xD6CB2841L,5,377,0};/* VOLATILE GLOBAL g_988 */
static uint16_t g_999 = 0xE2CCL;
static uint16_t ** const g_1043 = &g_601;
static uint16_t ** const *g_1042[6][8][5] = {{{&g_1043,(void*)0,(void*)0,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,(void*)0},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,&g_1043,&g_1043,&g_1043}},{{&g_1043,&g_1043,&g_1043,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,(void*)0,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043}},{{(void*)0,&g_1043,(void*)0,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,(void*)0,(void*)0},{&g_1043,(void*)0,&g_1043,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043}},{{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,(void*)0,&g_1043},{(void*)0,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,(void*)0,&g_1043,(void*)0,&g_1043},{&g_1043,(void*)0,&g_1043,(void*)0,&g_1043},{&g_1043,(void*)0,&g_1043,&g_1043,&g_1043}},{{&g_1043,&g_1043,(void*)0,&g_1043,&g_1043},{&g_1043,&g_1043,(void*)0,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,(void*)0},{(void*)0,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,(void*)0,&g_1043,&g_1043},{&g_1043,(void*)0,&g_1043,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,(void*)0}},{{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1043,(void*)0},{&g_1043,&g_1043,&g_1043,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,(void*)0,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,&g_1043,(void*)0,(void*)0},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043}}};
static int8_t *g_1071 = &g_49;
static int8_t **g_1070[7] = {&g_1071,&g_1071,&g_1071,&g_1071,&g_1071,&g_1071,&g_1071};
static int8_t **g_1077 = &g_1071;
static struct S1 g_1080 = {0xE9E8FC92L,0,511,1};/* VOLATILE GLOBAL g_1080 */
static struct S1 *g_1079 = &g_1080;
static int32_t ** const  volatile g_1111 = &g_145;/* VOLATILE GLOBAL g_1111 */
static int64_t g_1114 = (-7L);
static volatile struct S2 g_1138 = {705,0UL,1L,{799,1949,133},0x7B43L,0x413DC4A1A3DA5D0CLL,251UL,{-1L,7,-162,1}};/* VOLATILE GLOBAL g_1138 */
static int64_t ** const *g_1159 = &g_740;
static int64_t ** const **g_1158 = &g_1159;
static const int64_t *g_1170[2][9][3] = {{{&g_781,(void*)0,&g_1114},{&g_1114,&g_1114,&g_781},{&g_781,(void*)0,&g_163},{&g_781,&g_163,&g_163},{&g_163,&g_1114,&g_163},{&g_1114,&g_1114,&g_163},{(void*)0,&g_1114,&g_781},{&g_1114,&g_163,&g_1114},{&g_163,&g_1114,&g_1114}},{{(void*)0,&g_1114,&g_781},{&g_1114,&g_1114,&g_1114},{&g_1114,&g_163,&g_163},{(void*)0,(void*)0,&g_163},{&g_163,&g_1114,(void*)0},{&g_1114,(void*)0,&g_163},{(void*)0,(void*)0,&g_163},{&g_1114,&g_781,&g_1114},{&g_163,&g_781,&g_781}}};
static const int64_t **g_1169 = &g_1170[0][0][0];
static const int64_t ***g_1168 = &g_1169;
static const int64_t ****g_1167 = &g_1168;
static struct S2 g_1205 = {-608,0x55L,0x9095L,{-666,-5182,25},9L,0x5856D0E2BA6B3372LL,251UL,{-9L,7,495,1}};/* VOLATILE GLOBAL g_1205 */
static const struct S2 *g_1245[2] = {&g_228,&g_228};
static const struct S2 ** volatile g_1244 = &g_1245[0];/* VOLATILE GLOBAL g_1244 */
static struct S2 g_1253[9] = {{1005,0x58L,0xFCCCL,{-885,-10473,131},-1L,1UL,0xD3L,{0xA249A4EFL,0,-143,1}},{359,0x94L,0xE3D0L,{-383,10836,308},0L,0x44884DBD02D7DCB7LL,0x14L,{-1L,0,57,0}},{1005,0x58L,0xFCCCL,{-885,-10473,131},-1L,1UL,0xD3L,{0xA249A4EFL,0,-143,1}},{359,0x94L,0xE3D0L,{-383,10836,308},0L,0x44884DBD02D7DCB7LL,0x14L,{-1L,0,57,0}},{1005,0x58L,0xFCCCL,{-885,-10473,131},-1L,1UL,0xD3L,{0xA249A4EFL,0,-143,1}},{359,0x94L,0xE3D0L,{-383,10836,308},0L,0x44884DBD02D7DCB7LL,0x14L,{-1L,0,57,0}},{1005,0x58L,0xFCCCL,{-885,-10473,131},-1L,1UL,0xD3L,{0xA249A4EFL,0,-143,1}},{359,0x94L,0xE3D0L,{-383,10836,308},0L,0x44884DBD02D7DCB7LL,0x14L,{-1L,0,57,0}},{1005,0x58L,0xFCCCL,{-885,-10473,131},-1L,1UL,0xD3L,{0xA249A4EFL,0,-143,1}}};
static volatile struct S1 g_1278 = {4L,7,-63,0};/* VOLATILE GLOBAL g_1278 */
static int32_t g_1321 = 1L;
static uint32_t g_1379[10] = {18446744073709551615UL,6UL,6UL,18446744073709551615UL,0UL,18446744073709551615UL,6UL,6UL,18446744073709551615UL,0UL};
static const struct S2 ** volatile g_1383 = &g_1245[0];/* VOLATILE GLOBAL g_1383 */
static uint32_t g_1396 = 1UL;
static volatile uint8_t g_1405 = 0x1CL;/* VOLATILE GLOBAL g_1405 */
static int32_t g_1413 = (-8L);
static volatile int32_t * volatile * volatile *** volatile g_1424 = (void*)0;/* VOLATILE GLOBAL g_1424 */
static uint32_t g_1473 = 0x8822F311L;
static int32_t * volatile g_1541 = (void*)0;/* VOLATILE GLOBAL g_1541 */
static int32_t * const  volatile g_1542[3][1] = {{&g_84},{&g_84},{&g_84}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_17(int64_t  p_18, const int64_t  p_19);
static uint8_t  func_22(const int32_t * p_23, int32_t  p_24, int32_t  p_25, int32_t * p_26, int32_t * p_27);
static const int32_t * func_28(int32_t * const  p_29);
static struct S2  func_38(const int64_t  p_39);
static int32_t  func_45(uint8_t  p_46);
static uint8_t  func_50(const uint64_t  p_51, uint32_t  p_52, uint32_t  p_53, uint64_t  p_54, uint32_t  p_55);
static int32_t * func_58(uint32_t * p_59, const uint32_t * p_60, int32_t  p_61);
static int32_t  func_70(uint8_t  p_71, struct S0  p_72, int32_t * p_73);
static uint8_t  func_74(uint64_t  p_75, uint32_t * p_76, uint32_t * p_77);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_982 g_137 g_105 g_805.f1 g_278.f2 g_881 g_7 g_601 g_739 g_740 g_741 g_163 g_138 g_1158 g_1167 g_1071 g_49 g_852 g_202 g_119 g_311 g_578.f3.f1 g_851 g_229.f3.f0 g_136 g_168 g_981 g_145 g_1205 g_399 g_578.f1 g_48 g_1043 g_663.f0 g_123 g_950 g_84 g_705 g_1244 g_205 g_144 g_1159 g_229.f1 g_1111 g_710.f7.f2 g_305.f3.f0 g_1278 g_540 g_541 g_1245 g_608 g_228 g_1077 g_1253.f2 g_734.f4 g_1253.f7.f3 g_305.f3.f1 g_214 g_1321 g_476 g_477 g_999 g_305.f4 g_1379 g_1169 g_1170 g_1405 g_663.f7.f3 g_1413 g_500 g_1424 g_734.f2 g_277.f2 g_1396 g_641 g_1473 g_734.f3.f1 g_525
 * writes: g_5 g_7 g_3 g_9 g_105 g_168 g_229.f4 g_1158 g_1167 g_982.f1 g_84 g_399 g_119 g_365 g_48 g_950 g_123 g_805.f1 g_1245 g_608.f4 g_209 g_229.f1 g_145 g_1253.f2 g_663.f4 g_214 g_1321 g_169 g_608.f1 g_608.f2 g_999 g_305.f4 g_49 g_1379 g_416 g_163 g_1396 g_1405 g_1070 g_500 g_1205.f1 g_540 g_920.f2 g_1473 g_1138.f7.f0 g_634.f2 g_525
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2[9] = {0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL,0x7ECC2443AC46DDCDLL};
    uint8_t l_1537 = 0UL;
    int16_t l_1544[4] = {(-1L),(-1L),(-1L),(-1L)};
    int i;
    for (g_5 = 8; (g_5 >= 3); g_5 -= 1)
    { /* block id: 3 */
        uint16_t *l_1538 = (void*)0;
        uint16_t *l_1539 = &g_525;
        int32_t *l_1540 = &g_1321;
        int32_t *l_1543[5];
        int i;
        for (i = 0; i < 5; i++)
            l_1543[i] = &g_1413;
        for (g_7 = 6; (g_7 >= 2); g_7 -= 1)
        { /* block id: 6 */
            int32_t *l_8[8] = {&g_9,&g_9,&g_9,&g_9,&g_9,&g_9,&g_9,&g_9};
            int i;
            g_3 &= 5L;
            for (g_9 = 5; (g_9 >= 0); g_9 -= 1)
            { /* block id: 10 */
                uint64_t l_10 = 0x62C5D177CCE45D76LL;
                ++l_10;
            }
        }
        l_1544[0] = ((*l_1540) = (l_2[g_5] , (safe_div_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(func_17(l_2[g_5], l_2[8]), ((*l_1539) ^= l_1537))), l_2[3]))));
    }
    return (**g_852);
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_982 g_137 g_105 g_805.f1 g_278.f2 g_881 g_7 g_601 g_739 g_740 g_741 g_163 g_138 g_229.f4 g_1158 g_1167 g_1071 g_49 g_852 g_202 g_119 g_311 g_578.f3.f1 g_851 g_229.f3.f0 g_136 g_168 g_981 g_145 g_1205 g_399 g_578.f1 g_48 g_1043 g_663.f0 g_123 g_950 g_84 g_705 g_1244 g_205 g_144 g_608.f4 g_1159 g_209 g_229.f1 g_1111 g_710.f7.f2 g_305.f3.f0 g_1278 g_540 g_541 g_1245 g_228 g_1077 g_1253.f2 g_734.f4 g_1253.f7.f3 g_305.f3.f1 g_5 g_214 g_1321 g_169 g_476 g_477 g_999 g_305.f4 g_1379 g_1169 g_1170 g_1405 g_663.f7.f3 g_1413 g_500 g_1424 g_734.f2 g_277.f2 g_1396 g_641 g_920.f2 g_1473 g_734.f3.f1 g_608.f3.f1 g_608
 * writes: g_9 g_7 g_105 g_168 g_229.f4 g_1158 g_1167 g_982.f1 g_84 g_399 g_119 g_365 g_48 g_950 g_123 g_805.f1 g_1245 g_608.f4 g_209 g_229.f1 g_145 g_1253.f2 g_663.f4 g_214 g_1321 g_169 g_608.f1 g_608.f2 g_999 g_305.f4 g_49 g_1379 g_416 g_163 g_1396 g_1405 g_1070 g_500 g_1205.f1 g_540 g_920.f2 g_1473 g_1138.f7.f0 g_634.f2
 */
static uint16_t  func_17(int64_t  p_18, const int64_t  p_19)
{ /* block id: 14 */
    struct S0 ***l_1302 = &g_641;
    int32_t l_1303[7][8] = {{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL},{0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL,0x8DA2B70BL}};
    int32_t *l_1309 = &g_5;
    int32_t **l_1308 = &l_1309;
    int64_t *l_1314[8][9] = {{&g_1114,&g_781,&g_1114,&g_781,&g_163,&g_163,&g_163,&g_781,&g_1114},{&g_163,&g_781,(void*)0,&g_1114,(void*)0,&g_1114,&g_163,&g_163,&g_1114},{(void*)0,&g_1114,&g_1114,&g_1114,(void*)0,&g_1114,&g_1114,&g_163,&g_781},{&g_781,&g_163,(void*)0,(void*)0,&g_163,&g_1114,&g_781,&g_781,(void*)0},{&g_1114,&g_1114,(void*)0,&g_781,(void*)0,&g_1114,(void*)0,&g_163,&g_163},{(void*)0,&g_1114,&g_163,&g_163,&g_163,&g_1114,(void*)0,&g_1114,&g_163},{&g_163,&g_781,&g_781,&g_163,(void*)0,&g_163,&g_781,(void*)0,(void*)0},{&g_1114,(void*)0,&g_781,&g_163,&g_1114,&g_781,&g_1114,&g_1114,&g_1114}};
    int32_t l_1315 = (-1L);
    int32_t *l_1316 = (void*)0;
    int32_t *l_1317 = &g_214;
    int32_t *l_1318 = &g_5;
    int32_t *l_1320 = &g_1321;
    int8_t l_1331 = 1L;
    uint8_t l_1344[5] = {0x08L,0x08L,0x08L,0x08L,0x08L};
    int8_t ***l_1410 = &g_1070[4];
    uint64_t *l_1414 = (void*)0;
    uint64_t *l_1415 = &g_500;
    int32_t l_1437 = (-9L);
    int32_t l_1443 = 0x8F6FB098L;
    uint32_t l_1456 = 0xEE38A395L;
    int64_t ****l_1462 = &g_739;
    int64_t *****l_1461 = &l_1462;
    uint8_t *** const l_1531 = &g_136;
    int i, j;
    (*l_1320) ^= (safe_add_func_uint8_t_u_u(func_22(func_28(&g_7), ((void*)0 != l_1302), ((*l_1317) &= (((g_663.f4 = ((l_1303[6][0] == p_18) == (safe_rshift_func_uint16_t_u_u(((l_1315 = (safe_div_func_int8_t_s_s((((*g_205) != l_1308) & (safe_div_func_uint64_t_u_u(((safe_add_func_uint8_t_u_u(255UL, (*l_1309))) > (**g_740)), p_18))), 1UL))) < (**g_740)), 1)))) , p_18) == 18446744073709551615UL)), (*l_1308), l_1318), p_18));
    for (g_169 = 0; (g_169 > 3); g_169 = safe_add_func_int16_t_s_s(g_169, 9))
    { /* block id: 641 */
        int32_t l_1324 = 0x0D089E0DL;
        int32_t l_1332 = (-5L);
        int32_t l_1333 = 0x64AB402CL;
        int32_t l_1334 = (-3L);
        int32_t l_1343[10] = {0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL,0xED3E08DFL};
        int16_t l_1372 = 0xD410L;
        int32_t *l_1402 = &l_1332;
        int32_t *l_1403[9];
        int32_t l_1404 = 1L;
        int i;
        for (i = 0; i < 9; i++)
            l_1403[i] = &l_1303[3][2];
        for (g_663.f4 = 0; (g_663.f4 <= 4); g_663.f4 += 1)
        { /* block id: 644 */
            int32_t *l_1325 = &l_1315;
            int32_t *l_1326 = &l_1315;
            int32_t *l_1327 = &l_1303[5][0];
            int32_t *l_1328 = &g_84;
            int32_t *l_1329 = &l_1324;
            int32_t *l_1330[8];
            uint32_t l_1335 = 1UL;
            int i;
            for (i = 0; i < 8; i++)
                l_1330[i] = &l_1303[6][0];
            if (p_19)
                break;
            --l_1335;
            for (g_608.f1 = 0; (g_608.f1 <= 7); g_608.f1 += 1)
            { /* block id: 649 */
                int8_t l_1338[9][10][2] = {{{0xCEL,0x7DL},{0xFEL,0xBEL},{0xB5L,0L},{(-2L),(-6L)},{1L,0xBEL},{0x5FL,(-6L)},{0xCEL,0L},{(-1L),0xBEL},{0x5DL,0x7DL},{(-2L),0x7DL}},{{0x5DL,0xBEL},{(-1L),0L},{0xCEL,(-6L)},{0x5FL,0xBEL},{1L,(-6L)},{(-2L),0L},{0xB5L,0xBEL},{0xFEL,0x7DL},{0xCEL,0x7DL},{0xFEL,0xBEL}},{{0xB5L,0L},{(-2L),(-6L)},{1L,0xBEL},{0x5FL,(-6L)},{0xCEL,0L},{(-1L),0xBEL},{0x5DL,0x7DL},{(-2L),0x7DL},{0x5DL,0xBEL},{(-1L),0L}},{{0xCEL,(-6L)},{0x5FL,0xBEL},{1L,(-6L)},{(-2L),0L},{0xB5L,0xBEL},{0xFEL,6L},{0x77L,6L},{(-2L),0x9FL},{0x2FL,(-9L)},{0x6EL,0xBEL}},{{7L,0x9FL},{0x3FL,0xBEL},{0x77L,(-9L)},{1L,0x9FL},{0xCEL,6L},{0x6EL,6L},{0xCEL,0x9FL},{1L,(-9L)},{0x77L,0xBEL},{0x3FL,0x9FL}},{{7L,0xBEL},{0x6EL,(-9L)},{0x2FL,0x9FL},{(-2L),6L},{0x77L,6L},{(-2L),0x9FL},{0x2FL,(-9L)},{0x6EL,0xBEL},{7L,0x9FL},{0x3FL,0xBEL}},{{0x77L,(-9L)},{1L,0x9FL},{0xCEL,6L},{0x6EL,6L},{0xCEL,0x9FL},{1L,(-9L)},{0x77L,0xBEL},{0x3FL,0x9FL},{7L,0xBEL},{0x6EL,(-9L)}},{{0x2FL,0x9FL},{(-2L),6L},{0x77L,6L},{(-2L),0x9FL},{0x2FL,(-9L)},{0x6EL,0xBEL},{7L,0x9FL},{0x3FL,0xBEL},{0x77L,(-9L)},{1L,0x9FL}},{{0xCEL,6L},{0x6EL,6L},{0xCEL,0x9FL},{1L,(-9L)},{0x77L,0xBEL},{0x3FL,0x9FL},{7L,0xBEL},{0x6EL,(-9L)},{0x2FL,0x9FL},{(-2L),6L}}};
                int32_t l_1339 = (-6L);
                int32_t l_1375[5] = {(-3L),(-3L),(-3L),(-3L),(-3L)};
                int8_t l_1377 = 0xA9L;
                int64_t *l_1401[4];
                int i, j, k;
                for (i = 0; i < 4; i++)
                    l_1401[i] = &g_781;
                for (g_608.f2 = 4; (g_608.f2 >= 1); g_608.f2 -= 1)
                { /* block id: 652 */
                    for (l_1324 = 6; (l_1324 >= 0); l_1324 -= 1)
                    { /* block id: 655 */
                        uint16_t l_1340 = 0x7EDFL;
                        l_1340--;
                    }
                }
                ++l_1344[1];
                for (g_999 = 0; (g_999 <= 7); g_999 += 1)
                { /* block id: 662 */
                    uint32_t l_1347 = 0x71C1710AL;
                    int16_t *l_1354 = &g_305[0][5][6].f4;
                    int32_t l_1369[1][9] = {{0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL,0x9355365DL}};
                    int i, j;
                    if ((l_1347 | ((safe_mod_func_int8_t_s_s((4L && ((*g_202) |= (0xBA007B64L != p_18))), ((*g_1071) = (((((*l_1354) = (safe_div_func_uint64_t_u_u(1UL, (p_18 | (safe_mod_func_int16_t_s_s(g_48, 0xB4E5L)))))) || p_18) || (*g_476)) | g_999)))) ^ p_19)))
                    { /* block id: 666 */
                        int8_t l_1363 = 0x60L;
                        const uint32_t *l_1365 = &l_1335;
                        const uint32_t **l_1364 = &l_1365;
                        int32_t l_1366 = 0x5460DB6AL;
                        int32_t l_1367[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1367[i] = 0L;
                        l_1367[1] ^= ((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u((g_608.f4 > (***g_1159)))), (l_1347 || 1L))), ((*l_1354) &= (l_1366 = (255UL < (((*l_1325) &= (-4L)) <= ((*g_202) = (func_38(((+(l_1363 > (l_1364 == (void*)0))) > l_1324)) , p_18)))))))), 255UL)) > 0xB85A0DA3L);
                    }
                    else
                    { /* block id: 672 */
                        int8_t l_1368 = (-1L);
                        int32_t l_1370 = (-1L);
                        int32_t l_1371 = 0x5861ED31L;
                        int32_t l_1373 = 1L;
                        int32_t l_1374 = 0x3ED6356BL;
                        int32_t l_1376 = (-10L);
                        int32_t l_1378 = (-1L);
                        (*l_1327) &= (*l_1320);
                        g_1379[3]++;
                    }
                }
                for (g_365 = 0; (g_365 <= 4); g_365 += 1)
                { /* block id: 688 */
                    struct S1 **l_1386 = &g_417;
                    struct S1 * const **l_1387 = &g_416[1];
                    uint64_t *l_1388 = &g_399[0];
                    uint32_t *l_1392 = &g_48;
                    uint32_t *l_1395 = &g_1396;
                    (*l_1329) ^= (safe_sub_func_uint32_t_u_u(((((*l_1388) = (l_1386 != ((*l_1387) = (void*)0))) <= (l_1332 &= ((***g_739) = ((safe_mul_func_int16_t_s_s(p_19, (&g_1077 == (void*)0))) , (*g_476))))) < ((!(*g_202)) ^ ((-3L) && ((*l_1395) = ((*l_1392)++))))), ((safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(((l_1401[0] == (*g_1169)) , 251UL), p_18)), p_18)) < (-1L))));
                }
            }
            for (g_229.f4 = 7; (g_229.f4 >= 0); g_229.f4 -= 1)
            { /* block id: 700 */
                (*l_1325) = ((*l_1327) = (**g_705));
            }
        }
        g_1405++;
    }
    (*l_1308) = (void*)0;
    if ((((-8L) ^ p_19) | ((*l_1415) ^= (((((-1L) & ((***g_1159) = (((((*l_1320) = (g_663.f7.f3 , (safe_sub_func_int8_t_s_s((((*l_1410) = (void*)0) == (p_19 , (void*)0)), (safe_add_func_uint64_t_u_u(4UL, ((**g_1043) & p_19))))))) < (**g_852)) | g_105) , p_18))) > g_1413) , 0x01CE8345L) && (*g_881)))))
    { /* block id: 712 */
        (*l_1320) &= p_19;
    }
    else
    { /* block id: 714 */
        struct S0 *l_1438 = &g_541;
        int32_t l_1439 = 0xF03719AAL;
        int32_t l_1444 = 0x1F0D7070L;
        int32_t l_1445 = 0xBD0E4CE5L;
        int32_t l_1446 = 0L;
        int32_t l_1447 = 0xF266C0BBL;
        int32_t l_1448 = 0xFCA32035L;
        int32_t l_1449 = 0xD1AC9996L;
        int32_t l_1450 = 0x1833921EL;
        int32_t l_1451 = 0x44C3CD5CL;
        int32_t l_1452 = 0x97C02107L;
        uint16_t l_1453 = 0x87BFL;
        int32_t l_1469 = 0xCEC115DFL;
        int32_t l_1470 = (-8L);
        int32_t l_1471[8] = {2L,2L,2L,2L,2L,2L,2L,2L};
        int32_t l_1472 = 6L;
        uint64_t *l_1481 = (void*)0;
        const int8_t *l_1494 = &g_123;
        const int8_t **l_1493 = &l_1494;
        const int8_t ***l_1492 = &l_1493;
        const int8_t ***l_1496 = &l_1493;
        int32_t *l_1511 = (void*)0;
        int i;
        for (g_48 = 16; (g_48 <= 13); g_48 = safe_sub_func_int16_t_s_s(g_48, 6))
        { /* block id: 717 */
            int64_t l_1420[6][1] = {{(-4L)},{(-4L)},{0L},{(-4L)},{(-4L)},{0L}};
            int i, j;
            for (g_1205.f1 = (-11); (g_1205.f1 >= 24); g_1205.f1++)
            { /* block id: 720 */
                int32_t *l_1421 = &l_1315;
                int32_t ****l_1423 = &g_205;
                int32_t ***** const l_1422 = &l_1423;
                struct S0 l_1436[1] = {{801,8320,123}};
                int i;
                if (l_1420[4][0])
                    break;
                l_1421 = (*l_1308);
                (*g_145) = (l_1422 == g_1424);
                (*l_1320) = ((((*g_1071) & (safe_sub_func_uint8_t_u_u((((**g_740) = (safe_rshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s(p_19, 2)), (((*g_145) ^= 0L) & (safe_lshift_func_int16_t_s_s(g_734.f2, 2)))))) & (((*g_137) = 0x1EL) & p_18)), (((!((((((safe_div_func_int16_t_s_s(0x92C0L, (((((l_1436[0] , (p_19 & 0xDFL)) , (*g_881)) && p_18) ^ 0xD6L) , g_277.f2))) && 0L) , l_1437) & p_18) && g_1396) == 0x04AFL)) , p_19) , p_18)))) < g_578[4][3].f1) > p_19);
            }
            (*g_641) = l_1438;
            l_1439 = l_1420[4][0];
        }
        for (g_920.f2 = 1; (g_920.f2 >= 0); g_920.f2 -= 1)
        { /* block id: 734 */
            int32_t *l_1440 = (void*)0;
            int32_t *l_1441 = &g_7;
            int32_t *l_1442[8] = {&l_1303[6][2],&l_1303[6][1],&l_1303[6][1],&l_1303[6][2],&l_1303[6][1],&l_1303[6][1],&l_1303[6][2],&l_1303[6][1]};
            int64_t ****l_1460 = &g_739;
            int64_t ***** const l_1459 = &l_1460;
            int64_t ******l_1463[1][5][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1461,&l_1461,&l_1461,&l_1461,&l_1461},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1461,&l_1461,&l_1461,&l_1461,&l_1461},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
            const int8_t **l_1512 = &l_1494;
            int i, j, k;
            l_1453--;
            ++l_1456;
            if ((l_1459 != (l_1461 = l_1461)))
            { /* block id: 738 */
                int32_t l_1464 = 0x05FE6973L;
                int32_t l_1465 = 0x0B467BD7L;
                int32_t l_1466 = 1L;
                int32_t l_1467 = 0x02F1672BL;
                int32_t l_1468[8] = {(-7L),(-1L),(-7L),(-1L),(-7L),(-1L),(-7L),(-1L)};
                int32_t *l_1476[8][4] = {{&l_1303[1][3],&l_1303[1][3],&l_1303[6][0],&l_1303[1][3]},{&l_1303[1][3],&l_1303[4][1],&l_1303[4][1],&l_1303[1][3]},{&l_1303[4][1],&l_1303[1][3],&l_1303[4][1],&l_1303[4][1]},{&l_1303[4][1],&l_1303[4][1],&l_1303[1][3],&l_1303[4][1]},{&l_1303[4][1],&l_1303[6][0],&l_1303[6][0],&l_1303[4][1]},{&l_1303[6][0],&l_1303[4][1],&l_1303[6][0],&l_1303[6][0]},{&l_1303[4][1],&l_1303[4][1],&l_1303[1][3],&l_1303[4][1]},{&l_1303[4][1],&l_1303[6][0],&l_1303[6][0],&l_1303[4][1]}};
                int i, j;
                ++g_1473;
                l_1476[6][3] = (*g_705);
                if (p_18)
                    continue;
            }
            else
            { /* block id: 742 */
                uint64_t **l_1482 = &l_1414;
                uint64_t **l_1483 = &l_1415;
                int32_t l_1490[1][9];
                int8_t ***l_1491 = (void*)0;
                const int8_t ****l_1495[10] = {&l_1492,&l_1492,&l_1492,&l_1492,&l_1492,&l_1492,&l_1492,&l_1492,&l_1492,&l_1492};
                uint64_t *l_1501 = &g_399[3];
                uint8_t *l_1532 = (void*)0;
                int32_t l_1533 = 1L;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 9; j++)
                        l_1490[i][j] = 0xD2CC331BL;
                }
                if (((*l_1441) ^= (safe_mul_func_int8_t_s_s((((safe_add_func_uint8_t_u_u((((((*l_1483) = ((*l_1482) = l_1481)) == ((safe_div_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((safe_add_func_int32_t_s_s((0xE9L ^ l_1490[0][0]), ((l_1491 != (l_1496 = (l_1492 = l_1492))) || (safe_div_func_int8_t_s_s(((((**g_852) = (l_1490[0][0] & 0x16L)) >= ((l_1444 = (--(*g_137))) && (l_1451 <= (*l_1320)))) > p_18), l_1490[0][0]))))), p_19)), p_19)) , l_1501)) < l_1490[0][0]) , p_18), p_18)) != (*l_1320)) , (-1L)), p_18))))
                { /* block id: 751 */
                    if (l_1490[0][1])
                        break;
                }
                else
                { /* block id: 753 */
                    (*l_1441) = (((safe_unary_minus_func_uint64_t_u(g_734.f3.f1)) != 0xDDA1L) | (safe_add_func_uint32_t_u_u((((((((safe_add_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u(p_19, ((((((*g_202) && p_18) != (safe_sub_func_int8_t_s_s((((((0x3CL != (p_19 < (-1L))) , (***l_1302)) , l_1511) == (void*)0) ^ (-1L)), 0x24L))) & 4294967295UL) ^ g_608.f3.f1) && p_19))) >= l_1490[0][7]), (*g_1071))) , 0x18L) , (*l_1496)) != l_1512) || p_18) > 18446744073709551615UL) > p_18), 0xA009A5A6L)));
                    l_1490[0][4] |= p_19;
                }
                (*l_1441) = ((safe_sub_func_uint32_t_u_u((*l_1441), (safe_mul_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u((***g_851), (safe_div_func_int8_t_s_s((-1L), ((safe_div_func_uint16_t_u_u(((l_1490[0][6] = (safe_rshift_func_uint8_t_u_s((p_19 < (safe_sub_func_uint16_t_u_u((--(*g_601)), (safe_lshift_func_int16_t_s_s(g_1413, 6))))), (((l_1531 == &g_138) , l_1532) == l_1532)))) , p_18), p_19)) | (*l_1320)))))) == g_305[0][5][6].f3.f0), p_19)))) < l_1533);
            }
        }
        l_1450 = (-10L);
        for (g_982.f1 = 0; (g_982.f1 != 54); g_982.f1 = safe_add_func_uint16_t_u_u(g_982.f1, 3))
        { /* block id: 765 */
            struct S0 *l_1536[5];
            int i;
            for (i = 0; i < 5; i++)
                l_1536[i] = &g_541;
            (*g_641) = l_1536[0];
            for (g_1138.f7.f0 = 0; g_1138.f7.f0 < 8; g_1138.f7.f0 += 1)
            {
                for (g_634.f2 = 0; g_634.f2 < 9; g_634.f2 += 1)
                {
                    l_1314[g_1138.f7.f0][g_634.f2] = &g_163;
                }
            }
        }
    }
    return (*l_1320);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_22(const int32_t * p_23, int32_t  p_24, int32_t  p_25, int32_t * p_26, int32_t * p_27)
{ /* block id: 636 */
    int8_t l_1319 = 0x39L;
    return l_1319;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_982 g_137 g_105 g_805.f1 g_278.f2 g_881 g_7 g_601 g_739 g_740 g_741 g_163 g_138 g_229.f4 g_1158 g_1167 g_1071 g_49 g_852 g_202 g_119 g_311 g_578.f3.f1 g_851 g_229.f3.f0 g_136 g_168 g_981 g_145 g_1205 g_399 g_578.f1 g_48 g_1043 g_663.f0 g_123 g_950 g_84 g_705 g_1244 g_205 g_144 g_608.f4 g_1159 g_209 g_229.f1 g_1111 g_710.f7.f2 g_305.f3.f0 g_1278 g_540 g_541 g_1245 g_228 g_1077 g_1253.f2 g_734.f4 g_1253.f7.f3 g_305.f3.f1 g_608
 * writes: g_9 g_7 g_105 g_168 g_229.f4 g_1158 g_1167 g_982.f1 g_84 g_399 g_119 g_365 g_48 g_950 g_123 g_805.f1 g_1245 g_608.f4 g_209 g_229.f1 g_145 g_1253.f2
 */
static const int32_t * func_28(int32_t * const  p_29)
{ /* block id: 15 */
    int16_t l_30 = 0x8483L;
    uint8_t l_37[1];
    int32_t *l_983 = (void*)0;
    struct S1 *l_987 = &g_988;
    int32_t l_995 = (-1L);
    int32_t l_997 = 5L;
    struct S0 l_1016 = {-967,8408,316};
    struct S0 * const *l_1176 = &g_540;
    int32_t ** const *l_1185[4][5][2] = {{{&g_144[8][4][2],(void*)0},{&g_144[4][2][2],&g_144[8][4][2]},{(void*)0,&g_144[4][2][2]},{(void*)0,&g_144[8][4][2]},{&g_144[4][2][2],(void*)0}},{{&g_144[8][4][2],&g_144[4][2][2]},{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[8][4][2],(void*)0}},{{&g_144[4][2][2],&g_144[8][4][2]},{(void*)0,&g_144[4][2][2]},{(void*)0,&g_144[8][4][2]},{&g_144[4][2][2],(void*)0},{&g_144[8][4][2],&g_144[4][2][2]}},{{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[4][2][2],&g_144[4][2][2]},{&g_144[8][4][2],(void*)0},{&g_144[4][2][2],&g_144[8][4][2]}}};
    int32_t ** const **l_1184 = &l_1185[2][2][1];
    int32_t ** const ***l_1183 = &l_1184;
    int32_t l_1196[2][7] = {{(-10L),0x49F4AA07L,(-10L),0x49F4AA07L,(-10L),0x49F4AA07L,(-10L)},{0x3C63D8FEL,0x3C63D8FEL,0x3C63D8FEL,0x3C63D8FEL,0x3C63D8FEL,0x3C63D8FEL,0x3C63D8FEL}};
    uint8_t l_1204 = 0xAEL;
    int16_t *l_1208 = (void*)0;
    uint64_t *l_1216 = &g_399[0];
    uint32_t l_1219 = 0xB6F2C23DL;
    uint8_t l_1220[8][1];
    uint32_t *l_1221[8][5][5] = {{{&l_1219,&g_48,(void*)0,&g_48,&l_1219},{&g_365,&g_365,(void*)0,&g_48,(void*)0},{&l_1219,(void*)0,&l_1219,&g_48,(void*)0},{&l_1219,(void*)0,&g_48,&g_48,&g_365},{&l_1219,&g_48,&l_1219,(void*)0,&l_1219}},{{(void*)0,&g_48,(void*)0,(void*)0,&g_48},{&l_1219,&g_48,&l_1219,&g_365,&l_1219},{&g_48,&l_1219,(void*)0,&g_365,(void*)0},{&l_1219,&g_48,&l_1219,&g_365,&l_1219},{&g_365,&g_365,&g_48,&l_1219,&l_1219}},{{(void*)0,&g_365,&l_1219,&l_1219,&l_1219},{(void*)0,(void*)0,(void*)0,&g_48,&g_365},{&l_1219,&g_365,(void*)0,&g_365,&l_1219},{&l_1219,&g_365,&g_48,(void*)0,&g_48},{&l_1219,&g_48,&l_1219,&g_48,(void*)0}},{{&g_48,&l_1219,(void*)0,&g_48,&l_1219},{(void*)0,&g_48,&l_1219,(void*)0,&l_1219},{&g_48,&g_48,(void*)0,&l_1219,&l_1219},{&l_1219,&g_48,&g_365,&g_48,&l_1219},{&l_1219,(void*)0,&l_1219,&g_365,&g_365}},{{&l_1219,(void*)0,&l_1219,&g_48,(void*)0},{(void*)0,&g_365,(void*)0,(void*)0,&g_48},{(void*)0,(void*)0,&l_1219,&l_1219,(void*)0},{&g_48,(void*)0,&l_1219,&g_365,&l_1219},{(void*)0,&g_48,&l_1219,&l_1219,&l_1219}},{{&g_365,&g_48,&g_48,(void*)0,&l_1219},{(void*)0,&g_365,&g_365,&l_1219,(void*)0},{&l_1219,(void*)0,&g_48,&g_365,&g_365},{(void*)0,&l_1219,(void*)0,&l_1219,(void*)0},{&l_1219,&g_365,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_48,(void*)0,(void*)0,(void*)0},{(void*)0,&g_48,(void*)0,(void*)0,&l_1219},{(void*)0,&g_48,(void*)0,(void*)0,(void*)0},{&g_365,&g_48,&g_48,&g_48,&l_1219},{(void*)0,(void*)0,&g_365,(void*)0,(void*)0}},{{&l_1219,&l_1219,&g_48,&g_365,&g_365},{&l_1219,(void*)0,&l_1219,(void*)0,(void*)0},{&l_1219,&g_48,&l_1219,&l_1219,&g_48},{(void*)0,&g_48,&l_1219,&g_48,(void*)0},{&g_48,&g_48,(void*)0,&g_365,&l_1219}}};
    uint16_t *l_1222 = (void*)0;
    uint16_t *l_1223 = &g_950[5][0];
    uint32_t l_1224 = 0UL;
    uint16_t l_1225 = 65529UL;
    const struct S2 *l_1243[3];
    struct S2 *l_1251[8][7][4] = {{{(void*)0,&g_229,&g_1205,(void*)0},{&g_278[3],&g_1205,(void*)0,&g_278[6]},{&g_305[0][2][7],&g_663,&g_1205,&g_1205},{(void*)0,&g_278[3],&g_805,&g_805},{(void*)0,&g_278[3],(void*)0,&g_1205},{&g_1205,&g_1205,&g_663,&g_920},{(void*)0,&g_305[0][5][6],&g_805,&g_920}},{{&g_278[6],&g_608,&g_278[3],&g_608},{&g_229,(void*)0,&g_278[3],&g_278[3]},{&g_1205,&g_982,&g_805,(void*)0},{&g_228,&g_608,&g_228,(void*)0},{&g_608,(void*)0,&g_228,&g_278[3]},{(void*)0,&g_278[6],(void*)0,&g_920},{&g_229,&g_228,&g_278[5],&g_228}},{{&g_663,&g_1205,&g_278[3],&g_278[3]},{&g_663,&g_663,&g_228,&g_805},{(void*)0,&g_229,&g_278[3],(void*)0},{(void*)0,&g_663,&g_228,&g_608},{&g_663,(void*)0,&g_278[3],(void*)0},{&g_663,(void*)0,&g_278[5],&g_278[3]},{&g_229,&g_920,(void*)0,&g_229}},{{(void*)0,&g_278[3],&g_228,&g_805},{&g_608,&g_228,&g_228,&g_663},{&g_228,&g_1205,&g_805,&g_663},{&g_1205,&g_1205,&g_305[0][5][6],(void*)0},{&g_228,(void*)0,&g_278[3],&g_982},{&g_805,&g_663,(void*)0,(void*)0},{&g_305[0][7][0],&g_228,(void*)0,(void*)0}},{{&g_1205,&g_805,(void*)0,&g_278[0]},{&g_1205,&g_278[3],&g_278[5],&g_805},{&g_278[4],(void*)0,&g_228,(void*)0},{&g_805,&g_920,(void*)0,&g_278[3]},{(void*)0,&g_228,&g_278[3],&g_305[0][0][0]},{&g_305[0][7][0],&g_229,&g_278[8],&g_278[8]},{&g_278[0],&g_278[0],&g_278[3],&g_920}},{{(void*)0,(void*)0,(void*)0,&g_663},{&g_278[3],(void*)0,&g_229,(void*)0},{&g_305[0][0][0],(void*)0,(void*)0,&g_663},{(void*)0,(void*)0,&g_278[3],&g_920},{&g_278[4],&g_278[0],&g_663,&g_278[8]},{&g_228,&g_229,&g_278[3],&g_305[0][0][0]},{&g_805,&g_228,&g_278[4],&g_278[3]}},{{(void*)0,&g_920,&g_305[0][5][6],(void*)0},{&g_1205,(void*)0,&g_278[3],&g_805},{(void*)0,&g_278[3],&g_805,&g_278[0]},{(void*)0,&g_805,&g_229,(void*)0},{&g_805,&g_228,&g_278[3],(void*)0},{&g_982,&g_663,&g_278[3],&g_982},{&g_278[4],(void*)0,&g_608,(void*)0}},{{&g_920,&g_1205,(void*)0,&g_920},{&g_229,&g_228,(void*)0,&g_805},{&g_278[3],&g_278[3],&g_229,(void*)0},{&g_278[3],&g_1205,&g_278[3],&g_229},{&g_229,&g_663,(void*)0,&g_278[3]},{&g_305[0][7][0],&g_982,&g_305[0][7][0],(void*)0},{&g_278[3],&g_1205,(void*)0,&g_229}}};
    uint32_t l_1279 = 4UL;
    int32_t l_1297 = 0x71E3A6E8L;
    int16_t l_1301 = 1L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_37[i] = 0x46L;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
            l_1220[i][j] = 0xCEL;
    }
    for (i = 0; i < 3; i++)
        l_1243[i] = &g_608;
    for (g_9 = 0; (g_9 >= 0); g_9 -= 1)
    { /* block id: 18 */
        int32_t l_31 = 0xFB18BA70L;
        int32_t *l_984[9][5][5] = {{{&g_9,(void*)0,&g_5,&l_31,&g_9},{&g_84,&l_31,&g_9,&g_84,&g_5},{&g_84,&g_9,&g_84,&g_84,&g_9},{(void*)0,&l_31,(void*)0,&l_31,&g_5},{&g_9,&g_5,&g_84,&g_84,&g_9}},{{&l_31,&g_5,&g_5,(void*)0,&g_84},{&g_84,(void*)0,&g_5,&g_84,&g_5},{&g_5,&g_5,&g_84,&g_5,&g_9},{&g_84,&g_5,&g_5,&g_5,&g_5},{&l_31,&g_84,&g_5,&l_31,(void*)0}},{{&g_84,&g_5,&l_31,(void*)0,&g_84},{(void*)0,&g_5,&g_5,&g_5,&g_84},{&g_84,(void*)0,&g_84,&g_9,(void*)0},{&l_31,&g_9,&g_5,(void*)0,&g_84},{&g_5,&l_31,&l_31,&l_31,(void*)0}},{{&l_31,&g_5,&l_31,(void*)0,&g_84},{&g_9,&g_84,&g_5,&l_31,&g_84},{&g_84,&g_5,&g_9,&g_9,(void*)0},{(void*)0,&g_9,&g_84,&l_31,&g_84},{&g_9,&g_5,&l_31,&g_5,(void*)0}},{{&g_84,&g_9,(void*)0,&g_84,&g_84},{&g_84,&g_5,&g_84,&g_5,&l_31},{&g_84,&g_84,&g_5,&g_84,&g_84},{&g_5,(void*)0,(void*)0,&g_84,&l_31},{&g_5,(void*)0,&g_5,&g_84,&g_9}},{{&g_9,&g_84,&g_84,&g_9,&g_84},{&g_84,&g_5,(void*)0,&g_84,&g_84},{&g_5,&g_84,&l_31,&l_31,&g_9},{&g_5,&l_31,&g_84,&l_31,(void*)0},{&g_9,&l_31,&g_9,&g_5,&g_5}},{{&l_31,&g_84,&g_5,&g_5,&g_84},{&l_31,(void*)0,&l_31,&g_9,&g_84},{&g_9,&g_5,&l_31,&g_5,(void*)0},{&g_5,&g_5,&g_5,(void*)0,&g_84},{&g_5,&g_84,&g_5,&l_31,&g_5}},{{&g_84,&g_9,&g_9,&g_84,&l_31},{&g_9,&g_84,&g_5,&g_9,&g_84},{&g_5,&g_84,&g_84,&g_5,&g_84},{&g_5,&g_84,&l_31,&g_9,&g_84},{&g_84,&g_84,&g_5,&g_84,&g_5}},{{&g_84,&g_9,&g_84,&l_31,&l_31},{&g_84,&g_84,(void*)0,(void*)0,&g_5},{&g_9,&g_5,&g_84,&g_5,&g_5},{(void*)0,&l_31,(void*)0,&g_9,&g_84},{&g_84,&g_84,&g_9,&g_5,(void*)0}}};
        struct S1 *l_985 = &g_986;
        uint32_t l_989 = 0UL;
        int32_t l_1023 = 0xDE5DA318L;
        uint32_t l_1121 = 4294967295UL;
        uint64_t l_1137[7] = {18446744073709551615UL,0xD782302AF1DE719DLL,0xD782302AF1DE719DLL,18446744073709551615UL,0xD782302AF1DE719DLL,0xD782302AF1DE719DLL,18446744073709551615UL};
        int8_t ***l_1141 = &g_1070[2];
        const uint16_t l_1178 = 0x9382L;
        int i, j, k;
        if (((((((l_31 = l_30) , (((*g_601) = ((((safe_lshift_func_int16_t_s_s(((((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u(((*g_137) |= ((l_37[0] || ((l_31 < ((func_38(l_31) , (void*)0) == (l_984[6][3][2] = l_983))) != l_37[0])) != (l_985 == l_987))))), l_31)) || 255UL) == g_805.f1) == g_278[3].f2), 15)) , (*g_881)) <= 4294967295UL) , l_989)) | g_982.f3.f1)) , (***g_739)) , (**g_138)) , p_29) == l_983))
        { /* block id: 468 */
            uint32_t l_990 = 6UL;
            int32_t l_993 = 0L;
            uint32_t **l_1015 = &g_310;
            uint32_t l_1017 = 0xC68B908EL;
            uint16_t ** const *l_1045[5][5] = {{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{&g_1043,(void*)0,(void*)0,&g_1043,(void*)0},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043},{(void*)0,&g_1043,(void*)0,(void*)0,&g_1043},{&g_1043,&g_1043,&g_1043,&g_1043,&g_1043}};
            int8_t **l_1072 = &g_1071;
            int32_t l_1117[1];
            struct S1 *l_1131 = (void*)0;
            int i, j;
            for (i = 0; i < 1; i++)
                l_1117[i] = 0x4DBA11CCL;
            for (g_229.f4 = 0; (g_229.f4 >= 0); g_229.f4 -= 1)
            { /* block id: 471 */
                int16_t l_994 = 1L;
                int32_t l_996 = 0xA61F149BL;
                uint32_t l_1018 = 0x22004F8FL;
                int32_t ***l_1031 = &g_144[6][6][1];
                uint16_t ***l_1046 = (void*)0;
                int8_t **l_1073[5] = {&g_1071,&g_1071,&g_1071,&g_1071,&g_1071};
                int32_t l_1113 = 1L;
                int32_t l_1116 = 0x0E2EBC0EL;
                int32_t l_1119 = 0x6738CC94L;
                int32_t **l_1124 = &l_984[6][3][2];
                int i;
            }
        }
        else
        { /* block id: 539 */
            int32_t l_1148 = 0xDA6E1E9DL;
            int64_t ** const ***l_1160 = &g_1158;
            const int64_t *****l_1171 = (void*)0;
            const int64_t ****l_1173 = &g_1168;
            const int64_t *****l_1172 = &l_1173;
            uint32_t l_1174 = 1UL;
            uint32_t *l_1175 = &l_989;
            struct S0 * const **l_1177 = &l_1176;
            l_1148 = (((((safe_lshift_func_uint8_t_u_s((*g_137), 4)) ^ (safe_sub_func_uint8_t_u_u((2L > ((((*l_1177) = (((*g_311) = ((safe_div_func_uint8_t_u_u((((*l_1175) ^= ((((((void*)0 == &l_983) & (l_1148 <= (~(safe_lshift_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u((-7L), (safe_sub_func_uint64_t_u_u(l_1148, (safe_rshift_func_uint8_t_u_s((((*l_1160) = g_1158) == ((*l_1172) = (g_1167 = (((safe_div_func_int32_t_s_s((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint8_t_u_u(l_1148, 1)), (*g_137))), 0x4F742CCAL)) <= 0xAB96ED0DL) , g_1167)))), (*g_1071))))))) || (-6L)), l_1148))))) , l_1174) | (**g_852)) | 9UL)) != (*g_202)), (**g_138))) & 4294967295UL)) , l_1176)) != &g_540) ^ 0x333CL)), l_1178))) , 5L) | g_578[4][3].f3.f1) , 0x0F627464L);
            if ((*p_29))
                break;
        }
        (*g_145) = ((((**g_136) = (safe_add_func_uint16_t_u_u(((*g_137) == (safe_mod_func_uint32_t_u_u(((void*)0 == l_1183), (safe_lshift_func_uint8_t_u_u(((*g_852) == (**g_851)), 3))))), ((g_229.f3.f0 >= ((**g_136) >= (((*p_29) &= (safe_rshift_func_uint8_t_u_s((safe_mod_func_uint8_t_u_u((++g_982.f1), (*g_137))), 6))) > ((*g_601) == g_981[4])))) < l_1196[1][0])))) | 247UL) >= (-9L));
    }
    if ((safe_lshift_func_uint16_t_u_u(((((((safe_div_func_uint16_t_u_u(((-5L) != (*g_1071)), ((*l_1223) = ((**g_1043) &= ((*g_881) | (safe_unary_minus_func_uint16_t_u(((safe_lshift_func_uint8_t_u_s(l_1204, 2)) | (g_1205 , (safe_add_func_int8_t_s_s((&l_30 == l_1208), (0xF82798ABL | (g_48 ^= (g_365 = ((**g_852) |= (!((+((safe_div_func_int64_t_s_s(((safe_sub_func_uint8_t_u_u(((~(++(*l_1216))) , (((0L | g_578[4][3].f1) | (*g_881)) == 0x4DL)), 0L)) , l_1219), 18446744073709551615UL)) , (***g_739))) || l_1220[0][0]))))))))))))))))) > l_1224) , 0x67E4L) < 0x5DA1L) & g_663.f0) & (*p_29)), l_1225)))
    { /* block id: 560 */
        uint8_t l_1240 = 0xF8L;
        int8_t l_1241 = (-4L);
        int32_t l_1260 = 6L;
        int32_t l_1261 = (-4L);
        uint64_t l_1263 = 0x05EAF6AA35453A04LL;
        for (g_123 = 0; (g_123 <= 0); g_123 += 1)
        { /* block id: 563 */
            uint16_t **l_1227 = &g_601;
            uint16_t ***l_1226 = &l_1227;
            struct S0 *l_1238[5][2][9] = {{{&g_544,&l_1016,(void*)0,&l_1016,&g_544,&g_544,&l_1016,(void*)0,&l_1016},{&l_1016,&g_544,(void*)0,(void*)0,&g_544,&l_1016,&g_544,(void*)0,(void*)0}},{{&g_544,&g_544,&l_1016,(void*)0,&l_1016,&g_544,&g_544,&l_1016,(void*)0},{&g_541,&g_544,&g_541,&l_1016,&l_1016,&g_541,&g_544,&g_541,&l_1016}},{{&g_541,&l_1016,&l_1016,&g_541,&g_544,&g_541,&l_1016,&l_1016,&g_541},{&g_544,&l_1016,(void*)0,&l_1016,&g_544,&g_544,&l_1016,(void*)0,&l_1016}},{{&l_1016,&g_544,(void*)0,(void*)0,&g_544,&l_1016,&g_544,(void*)0,(void*)0},{&g_544,&g_544,&l_1016,(void*)0,&l_1016,&g_544,&g_544,&l_1016,(void*)0}},{{&g_541,&g_544,&g_541,&l_1016,&l_1016,&g_541,&g_544,&g_541,&l_1016},{&g_541,&l_1016,&l_1016,&g_541,&g_544,&g_541,&l_1016,&l_1016,&g_541}}};
            int32_t l_1239 = (-1L);
            int32_t l_1242 = 0L;
            int64_t **l_1250 = (void*)0;
            int32_t *l_1254 = &l_995;
            int i, j, k;
            for (g_805.f1 = 0; (g_805.f1 <= 0); g_805.f1 += 1)
            { /* block id: 566 */
                uint16_t ****l_1228 = &l_1226;
                int i, j;
                l_1242 &= ((*g_145) |= (((*l_1228) = l_1226) == ((safe_add_func_int64_t_s_s((g_950[(g_123 + 3)][g_123] <= (safe_div_func_uint8_t_u_u((((func_38(l_37[g_123]) , l_37[g_123]) & ((safe_unary_minus_func_int64_t_s(((safe_lshift_func_int16_t_s_s(l_37[g_123], 3)) , ((safe_mod_func_uint16_t_u_u((0xDBDFL | ((l_1238[2][0][5] == l_1238[0][1][3]) | 9UL)), l_1239)) ^ l_1240)))) , l_1240)) == (*g_202)), l_37[g_123]))), l_1241)) , (void*)0)));
                if ((**g_705))
                    break;
                (*g_1244) = l_1243[1];
            }
            if ((*p_29))
            { /* block id: 573 */
                uint32_t l_1246 = 4294967286UL;
                int64_t *l_1248[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int i;
                (*p_29) = ((*g_145) &= ((((((*g_137) &= (l_1246 , ((void*)0 != &g_1111))) >= ((((~(((((**g_852) && ((*p_29) < ((**l_1183) != (void*)0))) , (*g_205)) != &p_29) >= l_1240)) || l_1239) && (***g_851)) >= l_1241)) & 0x75L) > l_1246) > l_1241));
                (*p_29) &= l_1240;
                for (g_608.f4 = 0; (g_608.f4 >= 0); g_608.f4 -= 1)
                { /* block id: 580 */
                    for (l_1225 = 0; (l_1225 <= 0); l_1225 += 1)
                    { /* block id: 583 */
                        (*p_29) = 1L;
                    }
                }
                (*g_145) = ((l_1239 ^= (****g_1158)) <= ((((l_1242 > l_1246) , (~(((l_1250 != l_1250) , (void*)0) != (*g_851)))) ^ (((*g_137) = (**g_138)) | (l_1246 , 0xBAL))) , l_1240));
            }
            else
            { /* block id: 590 */
                struct S2 *l_1252 = &g_1253[1];
                l_1252 = l_1251[5][6][0];
                (*p_29) = (*p_29);
            }
            l_1254 = &l_1242;
            for (g_209 = 0; (g_209 <= 0); g_209 += 1)
            { /* block id: 597 */
                int32_t *l_1255 = &g_7;
                int32_t l_1262[7][10][3] = {{{0x6247FD8DL,8L,1L},{0xC41609CBL,0xB12CAE7CL,1L},{0xBEE9B5B0L,0xF8657FE5L,0L},{0x2CD6A6A8L,8L,(-2L)},{8L,0x0F4C7329L,(-2L)},{7L,0L,0L},{1L,9L,1L},{4L,(-1L),1L},{0x6BBCA515L,0xE640FF22L,0x9E17346BL},{(-2L),0xBFB8566BL,0x0AD1B581L}},{{0x081ED744L,0xE640FF22L,0x0F4C7329L},{1L,(-1L),0x4B5C090CL},{0x43B7116CL,9L,0x01CFFBA7L},{0x5D499000L,0L,0L},{0x2BC3E883L,0x0F4C7329L,0xBFB8566BL},{0x2BC3E883L,8L,0x4F5E8A69L},{0x5D499000L,0xF8657FE5L,(-4L)},{0x43B7116CL,0xB12CAE7CL,0x0D2A1B2DL},{1L,8L,0xF8CAF525L},{0x081ED744L,0xF8CAF525L,(-1L)}},{{(-2L),0xC73663E1L,0xF8CAF525L},{0x6BBCA515L,1L,0x0D2A1B2DL},{4L,(-2L),(-4L)},{1L,0x0D2A1B2DL,0x4F5E8A69L},{7L,0x4B5C090CL,0xBFB8566BL},{8L,0x4B5C090CL,0L},{0x2CD6A6A8L,0x0D2A1B2DL,0x01CFFBA7L},{0xBEE9B5B0L,(-2L),0x4B5C090CL},{0xC41609CBL,1L,0x0F4C7329L},{0x6247FD8DL,0L,5L}},{{0L,0xF7D16B12L,0xF6E9E842L},{0x08B1BD1FL,2L,(-6L)},{(-4L),0x27578322L,1L},{1L,0xBCED0F35L,(-9L)},{(-6L),0x62541A89L,(-4L)},{8L,0L,(-4L)},{0L,(-9L),(-9L)},{0x47122679L,1L,1L},{0x0AD1B581L,0x9A98F82CL,(-6L)},{0x1D29C2F1L,(-8L),0xF6E9E842L}},{{0xF8657FE5L,9L,5L},{0x4B5C090CL,(-8L),0L},{0xBFB8566BL,0x9A98F82CL,1L},{0x0F4C7329L,1L,(-1L)},{0x0826E962L,(-9L),8L},{8L,0L,9L},{8L,0x62541A89L,0x13A79982L},{0x0826E962L,0xBCED0F35L,0L},{0x0F4C7329L,0x27578322L,5L},{0xBFB8566BL,2L,0xF7D16B12L}},{{0x4B5C090CL,0xF7D16B12L,0xC55E2E4CL},{0xF8657FE5L,0L,0xF7D16B12L},{0x1D29C2F1L,1L,5L},{0x0AD1B581L,(-4L),0L},{0x47122679L,5L,0x13A79982L},{0L,1L,9L},{8L,1L,8L},{(-6L),5L,(-1L)},{1L,(-4L),1L},{(-4L),1L,0L}},{{0x08B1BD1FL,0L,5L},{0L,0xF7D16B12L,0xF6E9E842L},{0x08B1BD1FL,2L,(-6L)},{(-4L),0x27578322L,1L},{1L,0xBCED0F35L,(-9L)},{(-6L),0x62541A89L,(-4L)},{8L,0L,(-4L)},{0L,(-9L),(-9L)},{0x47122679L,1L,1L},{0x0AD1B581L,0x9A98F82CL,(-6L)}}};
                int i, j, k;
                for (g_229.f1 = 0; (g_229.f1 <= 0); g_229.f1 += 1)
                { /* block id: 600 */
                    for (l_995 = 0; (l_995 >= 0); l_995 -= 1)
                    { /* block id: 603 */
                        int i, j;
                        l_1255 = ((*g_1111) = ((0x10B0ED3DL < (g_950[(g_229.f1 + 5)][g_123] & (**g_138))) , (*g_1111)));
                        l_1255 = &l_1239;
                    }
                    (*l_1254) = (((*l_1255) , ((*l_1255) |= ((**g_852)++))) >= (safe_mod_func_uint64_t_u_u(g_710.f7.f2, g_305[0][5][6].f3.f0)));
                    l_1263--;
                }
                if ((*p_29))
                    continue;
            }
        }
    }
    else
    { /* block id: 616 */
        uint32_t l_1268 = 0x6A8DC702L;
        int32_t l_1273[1][8][10] = {{{0x76EC83ABL,0xE2BF139FL,0xFF9C5437L,0xFFBFA21DL,7L,7L,0xFFBFA21DL,0xFF9C5437L,0xE2BF139FL,0x76EC83ABL},{7L,0xFFBFA21DL,0xFF9C5437L,0xE2BF139FL,0x76EC83ABL,7L,0xE2BF139FL,2L,0xE2BF139FL,7L},{0x76EC83ABL,0xFFBFA21DL,0x34612F08L,0xFFBFA21DL,0x76EC83ABL,0x6009DE09L,0xFFBFA21DL,2L,(-4L),0x76EC83ABL},{0x76EC83ABL,0xE2BF139FL,0xFF9C5437L,0xFFBFA21DL,7L,7L,0xFFBFA21DL,0xFF9C5437L,0xE2BF139FL,0x76EC83ABL},{7L,0xFFBFA21DL,0xFF9C5437L,0xE2BF139FL,0x76EC83ABL,7L,0xE2BF139FL,2L,0xE2BF139FL,7L},{0x76EC83ABL,0xFFBFA21DL,0x34612F08L,0xFFBFA21DL,0x76EC83ABL,0x6009DE09L,0xFFBFA21DL,2L,(-4L),0x76EC83ABL},{0x76EC83ABL,0xE2BF139FL,0xFF9C5437L,0xFFBFA21DL,7L,7L,0xFFBFA21DL,0xFF9C5437L,0xE2BF139FL,0xE2BF139FL},{(-4L),0x7A9C8F89L,0xD3FC35D2L,7L,0xE2BF139FL,(-4L),7L,4L,7L,(-4L)}}};
        uint64_t *l_1277 = &g_399[0];
        uint64_t **l_1276 = &l_1277;
        int16_t l_1280 = 0xB78EL;
        struct S1 **l_1281 = &g_417;
        int32_t l_1282 = 2L;
        int16_t *l_1290 = &g_1253[1].f2;
        int i, j, k;
        l_1282 |= ((*g_145) &= ((((safe_rshift_func_uint16_t_u_u(((((*p_29) = (l_1268 , (safe_lshift_func_int16_t_s_u((0UL & ((**g_136) = ((safe_lshift_func_uint16_t_u_u((((l_1273[0][2][5] > (*p_29)) == (safe_div_func_int16_t_s_s(((((*l_1223) = (((l_1273[0][2][5] , g_950[5][0]) , ((l_1216 == ((*l_1276) = &g_500)) , g_1278)) , (**g_1043))) ^ (*g_601)) >= (***g_739)), l_1273[0][2][5]))) <= l_1279), 4)) ^ 0x260524FC977852BBLL))), l_1280)))) , (**l_1176)) , l_1273[0][2][5]), 2)) , l_1281) == &l_987) <= 250UL));
        (*p_29) |= ((((**g_1244) , (safe_lshift_func_uint16_t_u_s((((*g_601) = (l_1273[0][2][5] > ((+0xC4L) | (**g_1077)))) < (safe_mod_func_uint16_t_u_u(l_1273[0][2][5], (l_1282 &= (l_1280 , 0x5D5BL))))), ((((*l_1290) &= l_1280) & (((--(**g_136)) < (safe_mul_func_uint16_t_u_u(l_1280, l_1273[0][7][5]))) > g_734.f4)) , l_1273[0][2][5])))) >= (***g_1159)) & 0x6DB4L);
        return (*g_1111);
    }
    (*g_145) &= (((***g_1159) != ((void*)0 == l_1221[2][0][1])) < (safe_mul_func_int8_t_s_s(((**g_1043) & (l_1297 < ((((**g_136) = (~(safe_add_func_uint8_t_u_u((*g_137), ((((g_1253[1].f7.f3 & g_1205.f0) != (((*p_29) >= 0x6FD74EA0L) , g_305[0][5][6].f3.f1)) <= 0xF2AA90E61DB39D87LL) != (*p_29)))))) & 0UL) | l_1301))), 252UL)));
    return (*g_705);
}


/* ------------------------------------------ */
/* 
 * reads : g_982
 * writes: g_7
 */
static struct S2  func_38(const int64_t  p_39)
{ /* block id: 20 */
    int16_t l_42 = 0x6182L;
    int32_t * const l_57 = &g_5;
    int32_t *l_78 = &g_9;
    int32_t *l_83 = &g_84;
    int32_t l_171[2][10] = {{0x5C3D3C4AL,(-5L),(-1L),(-5L),0x5C3D3C4AL,0x5C3D3C4AL,(-5L),(-1L),(-5L),0x5C3D3C4AL},{0x5C3D3C4AL,(-5L),(-1L),(-5L),0x5C3D3C4AL,0x5C3D3C4AL,(-5L),(-1L),(-5L),0x5C3D3C4AL}};
    uint64_t l_173 = 0xED09C0B3F9B22F94LL;
    uint32_t l_176 = 0xCDC1F2F3L;
    int8_t l_180 = 0x29L;
    int8_t l_184 = 0L;
    uint64_t l_186[8] = {18446744073709551614UL,18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL};
    uint8_t *l_195 = &g_69;
    uint32_t *l_200 = (void*)0;
    int32_t ***l_203 = &g_144[4][2][2];
    int64_t *l_220 = &g_163;
    int64_t l_234 = 3L;
    const struct S0 l_442 = {-870,8419,62};
    uint32_t l_443 = 0x5A205E78L;
    int32_t *l_486 = &g_84;
    int32_t *l_487 = &l_171[1][6];
    int32_t *l_488 = &g_84;
    int32_t *l_489 = &l_171[0][5];
    int32_t *l_490 = &g_84;
    int32_t *l_491 = &g_7;
    int32_t *l_492 = &l_171[0][8];
    int32_t *l_493 = &l_171[0][0];
    int32_t *l_494 = &g_7;
    int32_t *l_495 = &g_84;
    int32_t *l_496 = &l_171[0][3];
    int32_t *l_497 = &g_84;
    int32_t *l_498 = &l_171[0][6];
    int32_t *l_499[5];
    const uint8_t l_521 = 251UL;
    struct S1 **l_579 = &g_417;
    const uint8_t l_603 = 0x4DL;
    int16_t l_647 = 0x0B71L;
    int64_t l_729 = 0x41B769553BD0E54FLL;
    uint16_t **l_907 = &g_601;
    int16_t l_941[2];
    int32_t l_944 = 0x91CDB411L;
    int i, j;
    for (i = 0; i < 5; i++)
        l_499[i] = &g_7;
    for (i = 0; i < 2; i++)
        l_941[i] = 0x2FD7L;
    for (g_7 = 0; (g_7 >= 0); g_7 -= 1)
    { /* block id: 23 */
        int32_t *l_99[9] = {&g_9,&g_7,&g_7,&g_9,&g_7,&g_7,&g_9,&g_7,&g_7};
        int64_t l_126 = 0xDF95FD1089186393LL;
        int32_t l_170 = 0xC190A5E1L;
        int i;
    }
    return g_982;
}


/* ------------------------------------------ */
/* 
 * reads : g_169
 * writes: g_169
 */
static int32_t  func_45(uint8_t  p_46)
{ /* block id: 65 */
    g_169 ^= p_46;
    return p_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_141 g_144 g_93.f0 g_105 g_9 g_163 g_93.f2 g_123 g_137 g_166 g_7 g_145 g_84
 * writes: g_136 g_138 g_4 g_144 g_121 g_163 g_105 g_168 g_84
 */
static uint8_t  func_50(const uint64_t  p_51, uint32_t  p_52, uint32_t  p_53, uint64_t  p_54, uint32_t  p_55)
{ /* block id: 53 */
    int32_t *l_128[6] = {&g_5,&g_84,&g_84,&g_5,&g_84,&g_84};
    int32_t l_129[2][7][1] = {{{0x5B7E4AC2L},{1L},{0x5B7E4AC2L},{0x5B7E4AC2L},{1L},{0x5B7E4AC2L},{0x5B7E4AC2L}},{{1L},{0x5B7E4AC2L},{0x5B7E4AC2L},{1L},{0x5B7E4AC2L},{0x5B7E4AC2L},{1L}}};
    uint32_t l_130 = 0xE88D44B5L;
    uint8_t *l_134[4][1][8] = {{{&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69}},{{&g_105,&g_69,&g_69,&g_69,&g_105,&g_105,&g_69,&g_69}},{{&g_105,&g_105,&g_69,&g_69,&g_69,&g_105,&g_105,&g_69}},{{&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69,&g_69}}};
    uint8_t **l_133 = &l_134[1][0][1];
    uint8_t ***l_135[5] = {&l_133,&l_133,&l_133,&l_133,&l_133};
    int32_t ***l_146[1];
    int8_t *l_159 = &g_121;
    int64_t *l_162[4][5] = {{&g_163,&g_163,&g_163,&g_163,&g_163},{&g_163,&g_163,(void*)0,&g_163,&g_163},{&g_163,&g_163,&g_163,&g_163,&g_163},{&g_163,&g_163,&g_163,&g_163,&g_163}};
    uint32_t l_164 = 0UL;
    uint32_t l_165 = 0x8A5466BBL;
    uint16_t *l_167[6] = {&g_168,&g_168,&g_168,&g_168,&g_168,&g_168};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_146[i] = (void*)0;
    --l_130;
    g_138 = (g_136 = l_133);
    g_4 = (((p_54 | (safe_mul_func_uint16_t_u_u(p_51, p_52))) | (-4L)) >= ((g_141 , (*l_133)) == (void*)0));
    (*g_145) ^= (safe_sub_func_uint16_t_u_u(((g_144[1][7][2] = g_144[4][2][2]) != &g_145), (((g_168 = (safe_div_func_uint16_t_u_u(((((((safe_sub_func_uint8_t_u_u(((*g_137) = ((((safe_sub_func_uint8_t_u_u(p_55, (safe_sub_func_int64_t_s_s((safe_sub_func_int16_t_s_s(g_93[1][3].f0, ((g_163 ^= ((safe_mod_func_uint8_t_u_u(((((*l_159) = (p_52 | 0x33EB4EFABF27EFC0LL)) & (g_105 , (safe_mod_func_uint8_t_u_u((&p_52 == l_128[2]), g_9)))) > 0x0772C01CL), p_55)) == p_55)) | p_53))), l_164)))) ^ g_93[1][3].f2) >= g_123) | 0x683EFAFE794198D2LL)), p_51)) < g_9) & l_165) || 246UL) , 0x11L) && g_166), p_53))) | g_7) & 7UL)));
    return p_53;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_58(uint32_t * p_59, const uint32_t * p_60, int32_t  p_61)
{ /* block id: 50 */
    int32_t *l_127 = (void*)0;
    return l_127;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_84 g_5 g_9 g_123 g_6
 * writes: g_105 g_84 g_119 g_121 g_123
 */
static int32_t  func_70(uint8_t  p_71, struct S0  p_72, int32_t * p_73)
{ /* block id: 40 */
    uint8_t *l_104 = &g_105;
    int32_t l_106 = 0x92811E28L;
    int32_t *l_107 = &g_84;
    uint32_t l_108 = 18446744073709551608UL;
    int32_t *l_117 = &g_5;
    int32_t **l_116 = &l_117;
    uint32_t *l_118 = &g_119;
    int8_t *l_120 = &g_121;
    int8_t *l_122 = &g_123;
    int32_t *l_124 = &l_106;
    (*l_124) = (safe_sub_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_s(((*l_104) = g_7), 5)) || ((*l_107) |= l_106)) == (((*l_122) ^= (((&p_73 == &l_107) == l_108) == (((safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((~((*l_120) = (safe_add_func_uint32_t_u_u(((*l_118) = (&g_7 == ((*l_116) = p_73))), 0x84DD3EA5L)))) == 6UL), 0x4028L)), p_72.f0)) || (**l_116)) , 0x27L))) , g_5)), g_6[0][0]));
    return (*p_73);
}


/* ------------------------------------------ */
/* 
 * reads : g_84 g_92 g_96
 * writes: g_84 g_92
 */
static uint8_t  func_74(uint64_t  p_75, uint32_t * p_76, uint32_t * p_77)
{ /* block id: 31 */
    uint64_t l_97 = 18446744073709551615UL;
    for (g_84 = 0; (g_84 > (-23)); g_84--)
    { /* block id: 34 */
        int32_t *l_89 = &g_5;
        int32_t **l_88 = &l_89;
        int32_t *l_91 = &g_9;
        int32_t **l_90 = &l_91;
        (*l_90) = ((*l_88) = &g_84);
    }
    (*g_96) = g_92;
    return l_97;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_6[i][j], "g_6[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_93[i][j].f0, "g_93[i][j].f0", print_hash_value);
            transparent_crc(g_93[i][j].f1, "g_93[i][j].f1", print_hash_value);
            transparent_crc(g_93[i][j].f2, "g_93[i][j].f2", print_hash_value);
            transparent_crc(g_93[i][j].f3, "g_93[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_141.f0, "g_141.f0", print_hash_value);
    transparent_crc(g_141.f1, "g_141.f1", print_hash_value);
    transparent_crc(g_141.f2, "g_141.f2", print_hash_value);
    transparent_crc(g_141.f3.f0, "g_141.f3.f0", print_hash_value);
    transparent_crc(g_141.f3.f1, "g_141.f3.f1", print_hash_value);
    transparent_crc(g_141.f3.f2, "g_141.f3.f2", print_hash_value);
    transparent_crc(g_141.f4, "g_141.f4", print_hash_value);
    transparent_crc(g_141.f5, "g_141.f5", print_hash_value);
    transparent_crc(g_141.f6, "g_141.f6", print_hash_value);
    transparent_crc(g_141.f7.f0, "g_141.f7.f0", print_hash_value);
    transparent_crc(g_141.f7.f1, "g_141.f7.f1", print_hash_value);
    transparent_crc(g_141.f7.f2, "g_141.f7.f2", print_hash_value);
    transparent_crc(g_141.f7.f3, "g_141.f7.f3", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_166, "g_166", print_hash_value);
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    transparent_crc(g_209, "g_209", print_hash_value);
    transparent_crc(g_214, "g_214", print_hash_value);
    transparent_crc(g_217.f0, "g_217.f0", print_hash_value);
    transparent_crc(g_217.f1, "g_217.f1", print_hash_value);
    transparent_crc(g_217.f2, "g_217.f2", print_hash_value);
    transparent_crc(g_217.f3, "g_217.f3", print_hash_value);
    transparent_crc(g_228.f0, "g_228.f0", print_hash_value);
    transparent_crc(g_228.f1, "g_228.f1", print_hash_value);
    transparent_crc(g_228.f2, "g_228.f2", print_hash_value);
    transparent_crc(g_228.f3.f0, "g_228.f3.f0", print_hash_value);
    transparent_crc(g_228.f3.f1, "g_228.f3.f1", print_hash_value);
    transparent_crc(g_228.f3.f2, "g_228.f3.f2", print_hash_value);
    transparent_crc(g_228.f4, "g_228.f4", print_hash_value);
    transparent_crc(g_228.f5, "g_228.f5", print_hash_value);
    transparent_crc(g_228.f6, "g_228.f6", print_hash_value);
    transparent_crc(g_228.f7.f0, "g_228.f7.f0", print_hash_value);
    transparent_crc(g_228.f7.f1, "g_228.f7.f1", print_hash_value);
    transparent_crc(g_228.f7.f2, "g_228.f7.f2", print_hash_value);
    transparent_crc(g_228.f7.f3, "g_228.f7.f3", print_hash_value);
    transparent_crc(g_229.f0, "g_229.f0", print_hash_value);
    transparent_crc(g_229.f1, "g_229.f1", print_hash_value);
    transparent_crc(g_229.f2, "g_229.f2", print_hash_value);
    transparent_crc(g_229.f3.f0, "g_229.f3.f0", print_hash_value);
    transparent_crc(g_229.f3.f1, "g_229.f3.f1", print_hash_value);
    transparent_crc(g_229.f3.f2, "g_229.f3.f2", print_hash_value);
    transparent_crc(g_229.f4, "g_229.f4", print_hash_value);
    transparent_crc(g_229.f5, "g_229.f5", print_hash_value);
    transparent_crc(g_229.f6, "g_229.f6", print_hash_value);
    transparent_crc(g_229.f7.f0, "g_229.f7.f0", print_hash_value);
    transparent_crc(g_229.f7.f1, "g_229.f7.f1", print_hash_value);
    transparent_crc(g_229.f7.f2, "g_229.f7.f2", print_hash_value);
    transparent_crc(g_229.f7.f3, "g_229.f7.f3", print_hash_value);
    transparent_crc(g_277.f0, "g_277.f0", print_hash_value);
    transparent_crc(g_277.f1, "g_277.f1", print_hash_value);
    transparent_crc(g_277.f2, "g_277.f2", print_hash_value);
    transparent_crc(g_277.f3, "g_277.f3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_278[i].f0, "g_278[i].f0", print_hash_value);
        transparent_crc(g_278[i].f1, "g_278[i].f1", print_hash_value);
        transparent_crc(g_278[i].f2, "g_278[i].f2", print_hash_value);
        transparent_crc(g_278[i].f3.f0, "g_278[i].f3.f0", print_hash_value);
        transparent_crc(g_278[i].f3.f1, "g_278[i].f3.f1", print_hash_value);
        transparent_crc(g_278[i].f3.f2, "g_278[i].f3.f2", print_hash_value);
        transparent_crc(g_278[i].f4, "g_278[i].f4", print_hash_value);
        transparent_crc(g_278[i].f5, "g_278[i].f5", print_hash_value);
        transparent_crc(g_278[i].f6, "g_278[i].f6", print_hash_value);
        transparent_crc(g_278[i].f7.f0, "g_278[i].f7.f0", print_hash_value);
        transparent_crc(g_278[i].f7.f1, "g_278[i].f7.f1", print_hash_value);
        transparent_crc(g_278[i].f7.f2, "g_278[i].f7.f2", print_hash_value);
        transparent_crc(g_278[i].f7.f3, "g_278[i].f7.f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_281.f0, "g_281.f0", print_hash_value);
    transparent_crc(g_281.f1, "g_281.f1", print_hash_value);
    transparent_crc(g_281.f2, "g_281.f2", print_hash_value);
    transparent_crc(g_281.f3, "g_281.f3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_305[i][j][k].f0, "g_305[i][j][k].f0", print_hash_value);
                transparent_crc(g_305[i][j][k].f1, "g_305[i][j][k].f1", print_hash_value);
                transparent_crc(g_305[i][j][k].f2, "g_305[i][j][k].f2", print_hash_value);
                transparent_crc(g_305[i][j][k].f3.f0, "g_305[i][j][k].f3.f0", print_hash_value);
                transparent_crc(g_305[i][j][k].f3.f1, "g_305[i][j][k].f3.f1", print_hash_value);
                transparent_crc(g_305[i][j][k].f3.f2, "g_305[i][j][k].f3.f2", print_hash_value);
                transparent_crc(g_305[i][j][k].f4, "g_305[i][j][k].f4", print_hash_value);
                transparent_crc(g_305[i][j][k].f5, "g_305[i][j][k].f5", print_hash_value);
                transparent_crc(g_305[i][j][k].f6, "g_305[i][j][k].f6", print_hash_value);
                transparent_crc(g_305[i][j][k].f7.f0, "g_305[i][j][k].f7.f0", print_hash_value);
                transparent_crc(g_305[i][j][k].f7.f1, "g_305[i][j][k].f7.f1", print_hash_value);
                transparent_crc(g_305[i][j][k].f7.f2, "g_305[i][j][k].f7.f2", print_hash_value);
                transparent_crc(g_305[i][j][k].f7.f3, "g_305[i][j][k].f7.f3", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_308.f0, "g_308.f0", print_hash_value);
    transparent_crc(g_308.f1, "g_308.f1", print_hash_value);
    transparent_crc(g_308.f2, "g_308.f2", print_hash_value);
    transparent_crc(g_308.f3, "g_308.f3", print_hash_value);
    transparent_crc(g_326.f0, "g_326.f0", print_hash_value);
    transparent_crc(g_326.f1, "g_326.f1", print_hash_value);
    transparent_crc(g_326.f2, "g_326.f2", print_hash_value);
    transparent_crc(g_326.f3, "g_326.f3", print_hash_value);
    transparent_crc(g_365, "g_365", print_hash_value);
    transparent_crc(g_376.f0, "g_376.f0", print_hash_value);
    transparent_crc(g_376.f1, "g_376.f1", print_hash_value);
    transparent_crc(g_376.f2, "g_376.f2", print_hash_value);
    transparent_crc(g_376.f3, "g_376.f3", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_399[i], "g_399[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_419.f0, "g_419.f0", print_hash_value);
    transparent_crc(g_419.f1, "g_419.f1", print_hash_value);
    transparent_crc(g_419.f2, "g_419.f2", print_hash_value);
    transparent_crc(g_419.f3, "g_419.f3", print_hash_value);
    transparent_crc(g_472, "g_472", print_hash_value);
    transparent_crc(g_477, "g_477", print_hash_value);
    transparent_crc(g_500, "g_500", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_505[i].f0, "g_505[i].f0", print_hash_value);
        transparent_crc(g_505[i].f1, "g_505[i].f1", print_hash_value);
        transparent_crc(g_505[i].f2, "g_505[i].f2", print_hash_value);
        transparent_crc(g_505[i].f3, "g_505[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_525, "g_525", print_hash_value);
    transparent_crc(g_541.f0, "g_541.f0", print_hash_value);
    transparent_crc(g_541.f1, "g_541.f1", print_hash_value);
    transparent_crc(g_541.f2, "g_541.f2", print_hash_value);
    transparent_crc(g_544.f0, "g_544.f0", print_hash_value);
    transparent_crc(g_544.f1, "g_544.f1", print_hash_value);
    transparent_crc(g_544.f2, "g_544.f2", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_578[i][j].f0, "g_578[i][j].f0", print_hash_value);
            transparent_crc(g_578[i][j].f1, "g_578[i][j].f1", print_hash_value);
            transparent_crc(g_578[i][j].f2, "g_578[i][j].f2", print_hash_value);
            transparent_crc(g_578[i][j].f3.f0, "g_578[i][j].f3.f0", print_hash_value);
            transparent_crc(g_578[i][j].f3.f1, "g_578[i][j].f3.f1", print_hash_value);
            transparent_crc(g_578[i][j].f3.f2, "g_578[i][j].f3.f2", print_hash_value);
            transparent_crc(g_578[i][j].f4, "g_578[i][j].f4", print_hash_value);
            transparent_crc(g_578[i][j].f5, "g_578[i][j].f5", print_hash_value);
            transparent_crc(g_578[i][j].f6, "g_578[i][j].f6", print_hash_value);
            transparent_crc(g_578[i][j].f7.f0, "g_578[i][j].f7.f0", print_hash_value);
            transparent_crc(g_578[i][j].f7.f1, "g_578[i][j].f7.f1", print_hash_value);
            transparent_crc(g_578[i][j].f7.f2, "g_578[i][j].f7.f2", print_hash_value);
            transparent_crc(g_578[i][j].f7.f3, "g_578[i][j].f7.f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_608.f0, "g_608.f0", print_hash_value);
    transparent_crc(g_608.f1, "g_608.f1", print_hash_value);
    transparent_crc(g_608.f2, "g_608.f2", print_hash_value);
    transparent_crc(g_608.f3.f0, "g_608.f3.f0", print_hash_value);
    transparent_crc(g_608.f3.f1, "g_608.f3.f1", print_hash_value);
    transparent_crc(g_608.f3.f2, "g_608.f3.f2", print_hash_value);
    transparent_crc(g_608.f4, "g_608.f4", print_hash_value);
    transparent_crc(g_608.f5, "g_608.f5", print_hash_value);
    transparent_crc(g_608.f6, "g_608.f6", print_hash_value);
    transparent_crc(g_608.f7.f0, "g_608.f7.f0", print_hash_value);
    transparent_crc(g_608.f7.f1, "g_608.f7.f1", print_hash_value);
    transparent_crc(g_608.f7.f2, "g_608.f7.f2", print_hash_value);
    transparent_crc(g_608.f7.f3, "g_608.f7.f3", print_hash_value);
    transparent_crc(g_614.f0, "g_614.f0", print_hash_value);
    transparent_crc(g_614.f1, "g_614.f1", print_hash_value);
    transparent_crc(g_614.f2, "g_614.f2", print_hash_value);
    transparent_crc(g_614.f3, "g_614.f3", print_hash_value);
    transparent_crc(g_634.f0, "g_634.f0", print_hash_value);
    transparent_crc(g_634.f1, "g_634.f1", print_hash_value);
    transparent_crc(g_634.f2, "g_634.f2", print_hash_value);
    transparent_crc(g_634.f3.f0, "g_634.f3.f0", print_hash_value);
    transparent_crc(g_634.f3.f1, "g_634.f3.f1", print_hash_value);
    transparent_crc(g_634.f3.f2, "g_634.f3.f2", print_hash_value);
    transparent_crc(g_634.f4, "g_634.f4", print_hash_value);
    transparent_crc(g_634.f5, "g_634.f5", print_hash_value);
    transparent_crc(g_634.f6, "g_634.f6", print_hash_value);
    transparent_crc(g_634.f7.f0, "g_634.f7.f0", print_hash_value);
    transparent_crc(g_634.f7.f1, "g_634.f7.f1", print_hash_value);
    transparent_crc(g_634.f7.f2, "g_634.f7.f2", print_hash_value);
    transparent_crc(g_634.f7.f3, "g_634.f7.f3", print_hash_value);
    transparent_crc(g_663.f0, "g_663.f0", print_hash_value);
    transparent_crc(g_663.f1, "g_663.f1", print_hash_value);
    transparent_crc(g_663.f2, "g_663.f2", print_hash_value);
    transparent_crc(g_663.f3.f0, "g_663.f3.f0", print_hash_value);
    transparent_crc(g_663.f3.f1, "g_663.f3.f1", print_hash_value);
    transparent_crc(g_663.f3.f2, "g_663.f3.f2", print_hash_value);
    transparent_crc(g_663.f4, "g_663.f4", print_hash_value);
    transparent_crc(g_663.f5, "g_663.f5", print_hash_value);
    transparent_crc(g_663.f6, "g_663.f6", print_hash_value);
    transparent_crc(g_663.f7.f0, "g_663.f7.f0", print_hash_value);
    transparent_crc(g_663.f7.f1, "g_663.f7.f1", print_hash_value);
    transparent_crc(g_663.f7.f2, "g_663.f7.f2", print_hash_value);
    transparent_crc(g_663.f7.f3, "g_663.f7.f3", print_hash_value);
    transparent_crc(g_710.f0, "g_710.f0", print_hash_value);
    transparent_crc(g_710.f1, "g_710.f1", print_hash_value);
    transparent_crc(g_710.f2, "g_710.f2", print_hash_value);
    transparent_crc(g_710.f3.f0, "g_710.f3.f0", print_hash_value);
    transparent_crc(g_710.f3.f1, "g_710.f3.f1", print_hash_value);
    transparent_crc(g_710.f3.f2, "g_710.f3.f2", print_hash_value);
    transparent_crc(g_710.f4, "g_710.f4", print_hash_value);
    transparent_crc(g_710.f5, "g_710.f5", print_hash_value);
    transparent_crc(g_710.f6, "g_710.f6", print_hash_value);
    transparent_crc(g_710.f7.f0, "g_710.f7.f0", print_hash_value);
    transparent_crc(g_710.f7.f1, "g_710.f7.f1", print_hash_value);
    transparent_crc(g_710.f7.f2, "g_710.f7.f2", print_hash_value);
    transparent_crc(g_710.f7.f3, "g_710.f7.f3", print_hash_value);
    transparent_crc(g_734.f0, "g_734.f0", print_hash_value);
    transparent_crc(g_734.f1, "g_734.f1", print_hash_value);
    transparent_crc(g_734.f2, "g_734.f2", print_hash_value);
    transparent_crc(g_734.f3.f0, "g_734.f3.f0", print_hash_value);
    transparent_crc(g_734.f3.f1, "g_734.f3.f1", print_hash_value);
    transparent_crc(g_734.f3.f2, "g_734.f3.f2", print_hash_value);
    transparent_crc(g_734.f4, "g_734.f4", print_hash_value);
    transparent_crc(g_734.f5, "g_734.f5", print_hash_value);
    transparent_crc(g_734.f6, "g_734.f6", print_hash_value);
    transparent_crc(g_734.f7.f0, "g_734.f7.f0", print_hash_value);
    transparent_crc(g_734.f7.f1, "g_734.f7.f1", print_hash_value);
    transparent_crc(g_734.f7.f2, "g_734.f7.f2", print_hash_value);
    transparent_crc(g_734.f7.f3, "g_734.f7.f3", print_hash_value);
    transparent_crc(g_781, "g_781", print_hash_value);
    transparent_crc(g_799.f0, "g_799.f0", print_hash_value);
    transparent_crc(g_799.f1, "g_799.f1", print_hash_value);
    transparent_crc(g_799.f2, "g_799.f2", print_hash_value);
    transparent_crc(g_799.f3, "g_799.f3", print_hash_value);
    transparent_crc(g_805.f0, "g_805.f0", print_hash_value);
    transparent_crc(g_805.f1, "g_805.f1", print_hash_value);
    transparent_crc(g_805.f2, "g_805.f2", print_hash_value);
    transparent_crc(g_805.f3.f0, "g_805.f3.f0", print_hash_value);
    transparent_crc(g_805.f3.f1, "g_805.f3.f1", print_hash_value);
    transparent_crc(g_805.f3.f2, "g_805.f3.f2", print_hash_value);
    transparent_crc(g_805.f4, "g_805.f4", print_hash_value);
    transparent_crc(g_805.f5, "g_805.f5", print_hash_value);
    transparent_crc(g_805.f6, "g_805.f6", print_hash_value);
    transparent_crc(g_805.f7.f0, "g_805.f7.f0", print_hash_value);
    transparent_crc(g_805.f7.f1, "g_805.f7.f1", print_hash_value);
    transparent_crc(g_805.f7.f2, "g_805.f7.f2", print_hash_value);
    transparent_crc(g_805.f7.f3, "g_805.f7.f3", print_hash_value);
    transparent_crc(g_920.f0, "g_920.f0", print_hash_value);
    transparent_crc(g_920.f1, "g_920.f1", print_hash_value);
    transparent_crc(g_920.f2, "g_920.f2", print_hash_value);
    transparent_crc(g_920.f3.f0, "g_920.f3.f0", print_hash_value);
    transparent_crc(g_920.f3.f1, "g_920.f3.f1", print_hash_value);
    transparent_crc(g_920.f3.f2, "g_920.f3.f2", print_hash_value);
    transparent_crc(g_920.f4, "g_920.f4", print_hash_value);
    transparent_crc(g_920.f5, "g_920.f5", print_hash_value);
    transparent_crc(g_920.f6, "g_920.f6", print_hash_value);
    transparent_crc(g_920.f7.f0, "g_920.f7.f0", print_hash_value);
    transparent_crc(g_920.f7.f1, "g_920.f7.f1", print_hash_value);
    transparent_crc(g_920.f7.f2, "g_920.f7.f2", print_hash_value);
    transparent_crc(g_920.f7.f3, "g_920.f7.f3", print_hash_value);
    transparent_crc(g_926.f0, "g_926.f0", print_hash_value);
    transparent_crc(g_926.f1, "g_926.f1", print_hash_value);
    transparent_crc(g_926.f2, "g_926.f2", print_hash_value);
    transparent_crc(g_926.f3, "g_926.f3", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_929[i][j].f0, "g_929[i][j].f0", print_hash_value);
            transparent_crc(g_929[i][j].f1, "g_929[i][j].f1", print_hash_value);
            transparent_crc(g_929[i][j].f2, "g_929[i][j].f2", print_hash_value);
            transparent_crc(g_929[i][j].f3.f0, "g_929[i][j].f3.f0", print_hash_value);
            transparent_crc(g_929[i][j].f3.f1, "g_929[i][j].f3.f1", print_hash_value);
            transparent_crc(g_929[i][j].f3.f2, "g_929[i][j].f3.f2", print_hash_value);
            transparent_crc(g_929[i][j].f4, "g_929[i][j].f4", print_hash_value);
            transparent_crc(g_929[i][j].f5, "g_929[i][j].f5", print_hash_value);
            transparent_crc(g_929[i][j].f6, "g_929[i][j].f6", print_hash_value);
            transparent_crc(g_929[i][j].f7.f0, "g_929[i][j].f7.f0", print_hash_value);
            transparent_crc(g_929[i][j].f7.f1, "g_929[i][j].f7.f1", print_hash_value);
            transparent_crc(g_929[i][j].f7.f2, "g_929[i][j].f7.f2", print_hash_value);
            transparent_crc(g_929[i][j].f7.f3, "g_929[i][j].f7.f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_950[i][j], "g_950[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_981[i], "g_981[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_982.f0, "g_982.f0", print_hash_value);
    transparent_crc(g_982.f1, "g_982.f1", print_hash_value);
    transparent_crc(g_982.f2, "g_982.f2", print_hash_value);
    transparent_crc(g_982.f3.f0, "g_982.f3.f0", print_hash_value);
    transparent_crc(g_982.f3.f1, "g_982.f3.f1", print_hash_value);
    transparent_crc(g_982.f3.f2, "g_982.f3.f2", print_hash_value);
    transparent_crc(g_982.f4, "g_982.f4", print_hash_value);
    transparent_crc(g_982.f5, "g_982.f5", print_hash_value);
    transparent_crc(g_982.f6, "g_982.f6", print_hash_value);
    transparent_crc(g_982.f7.f0, "g_982.f7.f0", print_hash_value);
    transparent_crc(g_982.f7.f1, "g_982.f7.f1", print_hash_value);
    transparent_crc(g_982.f7.f2, "g_982.f7.f2", print_hash_value);
    transparent_crc(g_982.f7.f3, "g_982.f7.f3", print_hash_value);
    transparent_crc(g_986.f0, "g_986.f0", print_hash_value);
    transparent_crc(g_986.f1, "g_986.f1", print_hash_value);
    transparent_crc(g_986.f2, "g_986.f2", print_hash_value);
    transparent_crc(g_986.f3, "g_986.f3", print_hash_value);
    transparent_crc(g_988.f0, "g_988.f0", print_hash_value);
    transparent_crc(g_988.f1, "g_988.f1", print_hash_value);
    transparent_crc(g_988.f2, "g_988.f2", print_hash_value);
    transparent_crc(g_988.f3, "g_988.f3", print_hash_value);
    transparent_crc(g_999, "g_999", print_hash_value);
    transparent_crc(g_1080.f0, "g_1080.f0", print_hash_value);
    transparent_crc(g_1080.f1, "g_1080.f1", print_hash_value);
    transparent_crc(g_1080.f2, "g_1080.f2", print_hash_value);
    transparent_crc(g_1080.f3, "g_1080.f3", print_hash_value);
    transparent_crc(g_1114, "g_1114", print_hash_value);
    transparent_crc(g_1138.f0, "g_1138.f0", print_hash_value);
    transparent_crc(g_1138.f1, "g_1138.f1", print_hash_value);
    transparent_crc(g_1138.f2, "g_1138.f2", print_hash_value);
    transparent_crc(g_1138.f3.f0, "g_1138.f3.f0", print_hash_value);
    transparent_crc(g_1138.f3.f1, "g_1138.f3.f1", print_hash_value);
    transparent_crc(g_1138.f3.f2, "g_1138.f3.f2", print_hash_value);
    transparent_crc(g_1138.f4, "g_1138.f4", print_hash_value);
    transparent_crc(g_1138.f5, "g_1138.f5", print_hash_value);
    transparent_crc(g_1138.f6, "g_1138.f6", print_hash_value);
    transparent_crc(g_1138.f7.f0, "g_1138.f7.f0", print_hash_value);
    transparent_crc(g_1138.f7.f1, "g_1138.f7.f1", print_hash_value);
    transparent_crc(g_1138.f7.f2, "g_1138.f7.f2", print_hash_value);
    transparent_crc(g_1138.f7.f3, "g_1138.f7.f3", print_hash_value);
    transparent_crc(g_1205.f0, "g_1205.f0", print_hash_value);
    transparent_crc(g_1205.f1, "g_1205.f1", print_hash_value);
    transparent_crc(g_1205.f2, "g_1205.f2", print_hash_value);
    transparent_crc(g_1205.f3.f0, "g_1205.f3.f0", print_hash_value);
    transparent_crc(g_1205.f3.f1, "g_1205.f3.f1", print_hash_value);
    transparent_crc(g_1205.f3.f2, "g_1205.f3.f2", print_hash_value);
    transparent_crc(g_1205.f4, "g_1205.f4", print_hash_value);
    transparent_crc(g_1205.f5, "g_1205.f5", print_hash_value);
    transparent_crc(g_1205.f6, "g_1205.f6", print_hash_value);
    transparent_crc(g_1205.f7.f0, "g_1205.f7.f0", print_hash_value);
    transparent_crc(g_1205.f7.f1, "g_1205.f7.f1", print_hash_value);
    transparent_crc(g_1205.f7.f2, "g_1205.f7.f2", print_hash_value);
    transparent_crc(g_1205.f7.f3, "g_1205.f7.f3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1253[i].f0, "g_1253[i].f0", print_hash_value);
        transparent_crc(g_1253[i].f1, "g_1253[i].f1", print_hash_value);
        transparent_crc(g_1253[i].f2, "g_1253[i].f2", print_hash_value);
        transparent_crc(g_1253[i].f3.f0, "g_1253[i].f3.f0", print_hash_value);
        transparent_crc(g_1253[i].f3.f1, "g_1253[i].f3.f1", print_hash_value);
        transparent_crc(g_1253[i].f3.f2, "g_1253[i].f3.f2", print_hash_value);
        transparent_crc(g_1253[i].f4, "g_1253[i].f4", print_hash_value);
        transparent_crc(g_1253[i].f5, "g_1253[i].f5", print_hash_value);
        transparent_crc(g_1253[i].f6, "g_1253[i].f6", print_hash_value);
        transparent_crc(g_1253[i].f7.f0, "g_1253[i].f7.f0", print_hash_value);
        transparent_crc(g_1253[i].f7.f1, "g_1253[i].f7.f1", print_hash_value);
        transparent_crc(g_1253[i].f7.f2, "g_1253[i].f7.f2", print_hash_value);
        transparent_crc(g_1253[i].f7.f3, "g_1253[i].f7.f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1278.f0, "g_1278.f0", print_hash_value);
    transparent_crc(g_1278.f1, "g_1278.f1", print_hash_value);
    transparent_crc(g_1278.f2, "g_1278.f2", print_hash_value);
    transparent_crc(g_1278.f3, "g_1278.f3", print_hash_value);
    transparent_crc(g_1321, "g_1321", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1379[i], "g_1379[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1396, "g_1396", print_hash_value);
    transparent_crc(g_1405, "g_1405", print_hash_value);
    transparent_crc(g_1413, "g_1413", print_hash_value);
    transparent_crc(g_1473, "g_1473", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 386
   depth: 1, occurrence: 18
   depth: 2, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 7
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 4
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 68
breakdown:
   indirect level: 0, occurrence: 35
   indirect level: 1, occurrence: 22
   indirect level: 2, occurrence: 8
   indirect level: 3, occurrence: 2
   indirect level: 4, occurrence: 1
XXX full-bitfields structs in the program: 7
breakdown:
   indirect level: 0, occurrence: 7
XXX times a bitfields struct's address is taken: 160
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 44
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 78

XXX max expression depth: 37
breakdown:
   depth: 1, occurrence: 106
   depth: 2, occurrence: 30
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 37, occurrence: 1

XXX total number of pointers: 337

XXX times a variable address is taken: 1114
XXX times a pointer is dereferenced on RHS: 228
breakdown:
   depth: 1, occurrence: 162
   depth: 2, occurrence: 52
   depth: 3, occurrence: 12
   depth: 4, occurrence: 2
XXX times a pointer is dereferenced on LHS: 246
breakdown:
   depth: 1, occurrence: 217
   depth: 2, occurrence: 22
   depth: 3, occurrence: 7
XXX times a pointer is compared with null: 32
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 10
XXX times a pointer is qualified to be dereferenced: 5772

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1011
   level: 2, occurrence: 260
   level: 3, occurrence: 130
   level: 4, occurrence: 47
   level: 5, occurrence: 22
XXX number of pointers point to pointers: 143
XXX number of pointers point to scalars: 168
XXX number of pointers point to structs: 26
XXX percent of pointers has null in alias set: 30.6
XXX average alias set size: 1.44

XXX times a non-volatile is read: 1305
XXX times a non-volatile is write: 726
XXX times a volatile is read: 95
XXX    times read thru a pointer: 14
XXX times a volatile is write: 16
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4.1e+03
XXX percentage of non-volatile access: 94.8

XXX forward jumps: 0
XXX backward jumps: 10

XXX stmts: 107
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 27
   depth: 1, occurrence: 16
   depth: 2, occurrence: 21
   depth: 3, occurrence: 26
   depth: 4, occurrence: 10
   depth: 5, occurrence: 7

XXX percentage a fresh-made variable is used: 17.4
XXX percentage an existing variable is used: 82.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

