/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4041315396
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint8_t  f0;
};

union U1 {
   struct S0  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_27 = 0x19ADB821L;
static int32_t g_29 = (-2L);
static int32_t g_41 = 0x61940C9BL;
static int64_t g_45 = (-1L);
static volatile uint32_t g_46 = 0UL;/* VOLATILE GLOBAL g_46 */
static struct S0 *g_58 = (void*)0;
static volatile struct S0 g_66 = {0xEEL};/* VOLATILE GLOBAL g_66 */
static struct S0 g_95[4] = {{0xAAL},{0xAAL},{0xAAL},{0xAAL}};
static union U1 g_102 = {{0x28L}};
static union U1 ** volatile g_103[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 *g_105[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 ** volatile g_104 = &g_105[4];/* VOLATILE GLOBAL g_104 */
static int8_t g_108 = 0x1AL;
static uint16_t g_118 = 1UL;
static volatile int32_t * volatile *g_124[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint64_t g_173 = 0UL;
static int32_t g_176 = (-1L);
static int32_t *g_175 = &g_176;
static int32_t g_213 = (-1L);
static uint8_t g_214 = 0xC7L;
static volatile int32_t g_242 = 0x509249F8L;/* VOLATILE GLOBAL g_242 */
static volatile int32_t *g_241 = &g_242;
static int16_t g_277 = 0xAE82L;
static struct S0 ** volatile g_356 = &g_58;/* VOLATILE GLOBAL g_356 */
static int32_t **g_366[7][5][1] = {{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}},{{&g_175},{&g_175},{&g_175},{&g_175},{&g_175}}};
static int32_t ***g_365 = &g_366[0][4][0];
static int16_t * volatile * const g_431 = (void*)0;
static const int16_t *g_433 = &g_277;
static const int16_t **g_432 = &g_433;
static uint8_t g_458 = 2UL;
static const int32_t * volatile g_465 = (void*)0;/* VOLATILE GLOBAL g_465 */
static const int32_t * volatile *g_464 = &g_465;
static uint64_t g_475 = 0x1287C2FF62C3F630LL;
static int32_t g_546[1][9][2] = {{{0L,0L},{0L,0xC5F3F46AL},{(-1L),(-1L)},{0xC5F3F46AL,(-1L)},{(-1L),0xC5F3F46AL},{0L,0L},{0L,0xC5F3F46AL},{(-1L),(-1L)},{0xC5F3F46AL,(-1L)}}};
static uint8_t g_549 = 0x02L;
static uint8_t g_552 = 0xEBL;
static struct S0 **g_602 = &g_58;
static int32_t g_699 = 0L;
static uint16_t g_725 = 65530UL;
static uint32_t g_762 = 0UL;
static volatile struct S0 g_783 = {251UL};/* VOLATILE GLOBAL g_783 */
static uint32_t g_841[8][4] = {{0UL,18446744073709551609UL,0UL,0x93894187L},{0UL,0x93894187L,0UL,18446744073709551609UL},{0UL,18446744073709551609UL,0UL,0x93894187L},{0UL,0x93894187L,0UL,18446744073709551609UL},{0UL,18446744073709551609UL,0UL,0x93894187L},{0UL,0x93894187L,0UL,18446744073709551609UL},{0UL,18446744073709551609UL,0UL,0x93894187L},{0UL,0x93894187L,0UL,18446744073709551609UL}};
static volatile uint16_t g_859 = 5UL;/* VOLATILE GLOBAL g_859 */
static int8_t *g_900 = &g_108;
static int8_t **g_899 = &g_900;
static int64_t g_920 = (-7L);
static int64_t g_923 = 0x0189F2FDBBFE388CLL;
static uint16_t g_930 = 65531UL;
static volatile uint64_t *g_934 = (void*)0;
static volatile uint64_t * volatile *g_933 = &g_934;
static int8_t g_1061 = (-10L);
static volatile int8_t g_1102 = 0x66L;/* VOLATILE GLOBAL g_1102 */
static int32_t g_1184 = 6L;
static uint32_t *g_1221 = (void*)0;
static const struct S0 g_1253 = {0UL};
static const union U1 *g_1322 = &g_102;
static const union U1 **g_1321 = &g_1322;
static const union U1 ***g_1320 = &g_1321;
static int8_t g_1367 = 4L;
static uint64_t *g_1458 = &g_475;
static uint64_t **g_1457 = &g_1458;
static uint64_t ***g_1456 = &g_1457;
static volatile uint32_t g_1472 = 18446744073709551613UL;/* VOLATILE GLOBAL g_1472 */
static int32_t ****g_1484 = &g_365;
static int8_t g_1516[4][5][1] = {{{0L},{0L},{0L},{0L},{0L}},{{0L},{0L},{0L},{0L},{0L}},{{0L},{0L},{0L},{0L},{0L}},{{0L},{0L},{0L},{0L},{0L}}};
static volatile uint8_t *g_1623 = &g_66.f0;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t * func_2(const struct S0  p_3, int64_t  p_4);
static struct S0  func_5(int32_t  p_6, union U1  p_7, uint8_t  p_8);
static union U1  func_12(struct S0  p_13, int32_t  p_14, const int32_t * p_15, int32_t * p_16);
static const int32_t * func_19(struct S0 * p_20, int32_t * p_21);
static int16_t  func_30(int32_t * p_31, const uint32_t  p_32, int16_t  p_33);
static int32_t * func_34(int32_t  p_35, uint16_t  p_36);
static int16_t  func_49(struct S0  p_50, const int64_t  p_51, const struct S0 * p_52, int32_t  p_53);
static struct S0  func_54(struct S0 * p_55, int32_t * p_56, struct S0  p_57);
static int32_t * func_59(struct S0 * p_60, int16_t  p_61, struct S0  p_62, uint8_t  p_63, int32_t  p_64);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_27 g_46 g_41 g_58 g_66 g_95 g_104 g_108 g_118 g_124 g_45 g_102.f0.f0 g_173 g_241 g_602 g_900 g_549 g_105 g_365 g_366 g_175 g_176 g_841 g_899 g_546 g_1221 g_458 g_920 g_475 g_762 g_432 g_433 g_277 g_242 g_464 g_214 g_356 g_552 g_699 g_1456 g_1457 g_1458 g_1623 g_1367 g_1253.f0 g_1484 g_725 g_29 g_1322 g_102 g_1184 g_213 g_465 g_930 g_783.f0 g_859
 * writes: g_29 g_46 g_41 g_105 g_108 g_118 g_173 g_175 g_242 g_549 g_213 g_45 g_95 g_176 g_920 g_475 g_58 g_465 g_214 g_552 g_546 g_762 g_102.f0.f0 g_725 g_1367 g_699 g_27 g_923
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9 = 0x7FL;
    int32_t l_10 = 1L;
    int32_t l_11[9];
    struct S0 l_17 = {0x76L};
    struct S0 *l_18 = &l_17;
    int32_t *l_28[4];
    uint16_t l_39 = 1UL;
    int32_t l_1298 = 7L;
    struct S0 *l_1302 = &g_95[2];
    union U1 l_1780 = {{0xB4L}};
    int i;
    for (i = 0; i < 9; i++)
        l_11[i] = 0x30CC2FDCL;
    for (i = 0; i < 4; i++)
        l_28[i] = &g_29;
    (*g_464) = func_2(func_5(((l_9 = 1UL) < (((l_10 , l_11[0]) , func_12(((*l_18) = l_17), l_10, func_19(((safe_mod_func_int16_t_s_s(((~(safe_sub_func_int32_t_s_s(l_11[1], (g_29 = g_27)))) != 0xEDB39523L), func_30(func_34((safe_add_func_uint16_t_u_u((g_27 , g_27), l_39)), g_27), g_699, l_1298))) , l_1302), &l_10), &l_10)) , (*g_1623))), l_1780, g_841[6][3]), g_277);
    return (*g_175);
}


/* ------------------------------------------ */
/* 
 * reads : g_546 g_699 g_1484 g_365 g_366 g_175 g_29 g_41 g_176 g_214 g_45 g_900 g_108 g_1623 g_66.f0 g_458 g_552 g_58
 * writes: g_95
 */
static int32_t * func_2(const struct S0  p_3, int64_t  p_4)
{ /* block id: 825 */
    uint8_t l_1783 = 6UL;
    int32_t l_1793 = 0L;
    union U1 l_1794 = {{0xA9L}};
    (*g_58) = func_5((((1L && ((~g_546[0][6][1]) >= g_699)) , l_1783) ^ ((****g_1484) > (safe_sub_func_uint8_t_u_u((((((+((-1L) != (((~(safe_rshift_func_int8_t_s_u(((l_1783 & ((g_214 , (l_1793 &= (~((g_45 && l_1783) > l_1783)))) < (*g_900))) ^ 1L), (*g_1623)))) > p_4) || g_699))) != g_458) >= l_1783) || 0xDFL) , l_1793), 9L)))), l_1794, g_552);
    return (***g_1484);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static struct S0  func_5(int32_t  p_6, union U1  p_7, uint8_t  p_8)
{ /* block id: 823 */
    struct S0 l_1781 = {0UL};
    return l_1781;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_725 g_433 g_277 g_900 g_108 g_432 g_175 g_29 g_176 g_899 g_1484 g_365 g_366 g_1367 g_241 g_242 g_102.f0.f0 g_95 g_58 g_1623 g_66.f0 g_602 g_356 g_1456 g_1457 g_1458 g_699 g_1322 g_102 g_546 g_1184 g_118 g_27 g_46 g_464 g_213 g_762 g_465 g_214 g_930 g_783.f0 g_549 g_173 g_859 g_552
 * writes: g_725 g_29 g_41 g_176 g_242 g_102.f0.f0 g_1367 g_175 g_95 g_58 g_475 g_108 g_699 g_118 g_27 g_465 g_762 g_214 g_549 g_923 g_920
 */
static union U1  func_12(struct S0  p_13, int32_t  p_14, const int32_t * p_15, int32_t * p_16)
{ /* block id: 745 */
    int8_t l_1628 = 0x48L;
    int16_t l_1642 = (-1L);
    uint16_t *l_1643 = &g_725;
    const int64_t *l_1647 = &g_923;
    int32_t *l_1665 = &g_29;
    int32_t l_1668 = 0xA18B5127L;
    uint16_t l_1718 = 65526UL;
    uint64_t l_1778 = 1UL;
    union U1 l_1779 = {{0x2AL}};
    if (((6UL != (safe_div_func_int8_t_s_s((l_1628 ^ (p_13 , (safe_mul_func_int16_t_s_s(((((safe_mod_func_uint32_t_u_u(((!(safe_rshift_func_int16_t_s_u(p_13.f0, (safe_sub_func_uint16_t_u_u(g_41, (safe_div_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u(((*l_1643)++), (*g_433))) > p_13.f0), (+((((((void*)0 == &g_433) & p_14) , l_1628) ^ 4294967289UL) | p_13.f0))))))))) && l_1642), l_1642)) != 0UL) | (*g_900)) , (**g_432)), l_1628)))), 0x6CL))) == (-3L)))
    { /* block id: 747 */
        (*p_16) |= l_1642;
    }
    else
    { /* block id: 749 */
        (*g_175) ^= (-9L);
    }
    (*g_241) &= ((*p_16) = ((((l_1647 == l_1647) < (*g_900)) != (**g_899)) , ((safe_sub_func_uint16_t_u_u(((((((safe_add_func_int32_t_s_s(1L, ((safe_div_func_int64_t_s_s(((((safe_mod_func_uint8_t_u_u((&g_900 != (void*)0), (safe_lshift_func_int8_t_s_u((safe_add_func_uint8_t_u_u((safe_div_func_int64_t_s_s(l_1628, l_1628)), 255UL)), 4)))) | 0xFCC6L) > (**g_899)) & (**g_432)), 1UL)) || (*p_15)))) < (****g_1484)) , p_13.f0) != 251UL) ^ l_1642) , p_14), p_13.f0)) && g_1367)));
    for (g_176 = 3; (g_176 >= 0); g_176 -= 1)
    { /* block id: 756 */
        int32_t l_1674 = 0x2B34A45AL;
        uint16_t l_1712 = 0xD10CL;
        struct S0 l_1738 = {0UL};
        uint8_t *l_1763[6] = {&g_102.f0.f0,&g_549,&g_102.f0.f0,&g_102.f0.f0,&g_549,&g_102.f0.f0};
        uint64_t * const *l_1771[9];
        int64_t *l_1774 = (void*)0;
        int64_t *l_1775 = &g_923;
        int i;
        for (i = 0; i < 9; i++)
            l_1771[i] = &g_1458;
        for (g_102.f0.f0 = 0; (g_102.f0.f0 <= 3); g_102.f0.f0 += 1)
        { /* block id: 759 */
            int32_t l_1671 = 0L;
            uint64_t l_1685 = 5UL;
            struct S0 *l_1690 = &g_95[0];
            int i;
            (*g_241) = 1L;
            for (g_1367 = 0; (g_1367 <= 5); g_1367 += 1)
            { /* block id: 763 */
                const int32_t l_1682 = 0x5896E454L;
                int32_t *l_1683 = &g_699;
                int i;
                if (l_1628)
                { /* block id: 764 */
                    int8_t l_1662[6][7][6] = {{{1L,(-8L),(-1L),(-1L),(-8L),1L},{0L,0x6EL,0x87L,5L,(-6L),0x2AL},{(-1L),1L,9L,0x46L,0L,0x0AL},{(-1L),0x6DL,0x46L,5L,9L,0xCCL},{0L,(-6L),0x0EL,(-1L),0x0EL,(-6L)},{1L,0xB1L,0x89L,0x87L,(-1L),1L},{0x2AL,5L,0x93L,9L,(-6L),9L}},{{0x0AL,5L,0x6EL,0x46L,(-1L),0xF8L},{0xCCL,0xB1L,0x46L,0x0EL,0x0EL,0x46L},{(-6L),(-6L),1L,0x89L,9L,0xC5L},{1L,0x6DL,1L,0x93L,0L,1L},{9L,1L,1L,0x6EL,(-6L),0xC5L},{0xF8L,0x6EL,1L,0x46L,(-8L),0x46L},{0x46L,(-8L),0x46L,1L,0x6EL,0xF8L}},{{0xC5L,(-6L),0x6EL,1L,1L,9L},{1L,0L,0x93L,1L,0x6DL,1L},{0xC5L,9L,0x89L,1L,(-6L),(-6L)},{0x93L,0x46L,0x46L,0x93L,0L,0x87L},{1L,0xC5L,0x93L,0xCCL,(-1L),0x89L},{5L,1L,0xF8L,0xB1L,(-1L),9L},{0x0AL,0xC5L,0L,0x6DL,0L,0x0AL}},{{1L,0x46L,(-8L),0x46L,1L,0x6EL},{0x87L,0xF8L,(-1L),0x93L,0x2AL,(-1L)},{0x89L,9L,0x93L,0xF8L,0x0AL,(-1L)},{9L,1L,(-1L),0L,0xCCL,0x6EL},{0x0AL,(-6L),(-8L),(-8L),(-6L),0x0AL},{0x6EL,0xCCL,0L,(-1L),1L,9L},{(-1L),0x0AL,0xF8L,0x93L,9L,0x89L}},{{(-1L),0x2AL,0x93L,(-1L),0xF8L,0x87L},{0x6EL,1L,0x46L,(-8L),0x46L,1L},{0x0AL,0L,0x6DL,0L,0xC5L,0x0AL},{9L,(-1L),0xB1L,0xF8L,1L,5L},{0x89L,(-1L),0xCCL,0x93L,0xC5L,1L},{0x87L,0L,0x93L,0x46L,0x46L,0x93L},{1L,1L,0x0AL,0x6DL,0xF8L,0x0EL}},{{0x0AL,0x2AL,(-1L),0xB1L,9L,0x0AL},{5L,0x0AL,(-1L),0xCCL,1L,0x0EL},{1L,0xCCL,0x0AL,0x93L,(-6L),0x93L},{0x93L,(-6L),0x93L,0x0AL,0xCCL,1L},{0x0EL,1L,0xCCL,(-1L),0x0AL,5L},{0x0AL,9L,0xB1L,(-1L),0x2AL,0x0AL},{0x0EL,0xF8L,0x6DL,0x0AL,1L,1L}}};
                    int32_t l_1663 = 0x7A09246EL;
                    uint8_t l_1664 = 0xEBL;
                    int i, j, k;
                    if ((*p_15))
                        break;
                    l_1664 &= (l_1663 = l_1662[5][1][0]);
                }
                else
                { /* block id: 768 */
                    int i;
                    (**g_365) = l_1665;
                    (*g_58) = g_95[g_176];
                }
                (*l_1665) = 0L;
                (*l_1683) |= (((safe_sub_func_uint64_t_u_u((l_1668 == (((**g_899) = (((*g_1623) && ((((*g_356) = (*g_602)) != &p_13) <= (l_1671 == (safe_add_func_uint32_t_u_u(l_1674, (~(((*l_1665) = (((***g_1456) = (g_95[1] , (safe_mul_func_int32_t_s_s(3L, (safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(0x11L, p_13.f0)), 0UL)))))) , 0xED0AA1E3L)) == (*p_16)))))))) < p_14)) <= p_14)), p_14)) | (-1L)) > l_1682);
                for (g_725 = 0; (g_725 <= 0); g_725 += 1)
                { /* block id: 780 */
                    uint32_t l_1707[10][1] = {{4294967295UL},{0UL},{0UL},{4294967295UL},{0UL},{0UL},{4294967295UL},{0UL},{0UL},{4294967295UL}};
                    int i, j;
                    for (l_1642 = 0; (l_1642 >= 0); l_1642 -= 1)
                    { /* block id: 783 */
                        int32_t *l_1684[9] = {&g_29,&l_1668,&g_29,&l_1668,&g_29,&l_1668,&g_29,&l_1668,&g_29};
                        uint8_t *l_1693 = &g_95[0].f0;
                        uint16_t *l_1708 = &g_118;
                        uint32_t *l_1711 = &g_27;
                        int i, j, k;
                        ++l_1685;
                        (*g_464) = func_59(((safe_sub_func_int32_t_s_s(0xC2753AAEL, (-10L))) , l_1690), (safe_rshift_func_uint8_t_u_u(((*l_1693)++), (((*l_1711) |= ((*g_1322) , (safe_rshift_func_int8_t_s_s((~g_546[l_1642][(g_1367 + 3)][g_725]), (safe_mod_func_uint8_t_u_u(((1UL != (safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(((*l_1708) = (safe_lshift_func_uint8_t_u_s((*g_1623), l_1707[3][0]))), 8)) , ((*l_1708) &= (safe_mul_func_int8_t_s_s((g_1184 , p_13.f0), p_13.f0)))), p_13.f0))) > l_1707[9][0]), 0xE7L)))))) , p_13.f0))), p_13, l_1712, p_14);
                    }
                    for (g_27 = 0; (g_27 <= 5); g_27 += 1)
                    { /* block id: 793 */
                        uint32_t *l_1717 = &g_762;
                        int16_t *l_1719 = (void*)0;
                        int16_t *l_1720 = &l_1642;
                        uint8_t *l_1735 = (void*)0;
                        uint8_t *l_1736 = (void*)0;
                        uint8_t *l_1737 = &g_549;
                        int64_t *l_1743 = &g_923;
                        int i, j, k;
                        (*l_1683) ^= ((*p_16) = ((((safe_add_func_int32_t_s_s(g_546[g_725][(g_725 + 2)][(g_725 + 1)], ((*l_1717) ^= g_213))) ^ ((**g_365) != (*g_464))) == l_1718) > ((**g_899) &= (((*l_1720) = 0xE7C1L) < ((safe_lshift_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((g_214--), ((safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u((18446744073709551611UL && g_930), ((*l_1737) = 254UL))), (*p_15))), 1L)) , 255UL))), 0x19L)), g_546[g_725][(g_725 + 2)][(g_725 + 1)])) || p_13.f0)))));
                        (***g_1484) = func_59((*g_602), ((*l_1720) ^= 0x1451L), ((**g_602) = l_1738), (g_783.f0 , 0xE7L), (((*l_1665) |= (safe_div_func_int16_t_s_s((safe_lshift_func_int8_t_s_s(p_14, 3)), ((((((*l_1683) &= ((*l_1743) = 0xA1ADFABD6A0563DALL)) , 0x8DFF8F27L) | 0xA390E0C5L) <= 5L) & p_13.f0)))) < (*p_16)));
                        p_15 = func_59((*g_356), g_546[g_725][(g_725 + 2)][(g_725 + 1)], p_13, ((*l_1737) ^= p_14), ((safe_unary_minus_func_uint32_t_u((g_762 = (((****g_1484) = (*p_15)) && g_546[g_725][(g_725 + 2)][(g_725 + 1)])))) & (safe_div_func_int16_t_s_s((*g_433), 0x4274L))));
                        if ((*l_1665))
                            break;
                    }
                }
            }
        }
        (*p_16) &= (((safe_add_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u(((safe_rshift_func_int16_t_s_u((((((safe_mul_func_uint8_t_u_u(((((safe_lshift_func_int8_t_s_s(((**g_899) |= (-8L)), (((*l_1665) = (safe_div_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s(((safe_mod_func_uint16_t_u_u((l_1763[4] == (((!(safe_mul_func_uint8_t_u_u((((*l_1665) , ((safe_sub_func_uint8_t_u_u((l_1738.f0 | (safe_sub_func_uint64_t_u_u(((void*)0 == l_1771[5]), ((safe_div_func_uint16_t_u_u((*l_1665), ((g_920 = ((*l_1775) = 0xDAE84457DEEBFEB0LL)) , (safe_div_func_int16_t_s_s((g_546[0][6][1] , (*l_1665)), p_13.f0))))) | (*l_1665))))), p_13.f0)) | l_1778)) ^ g_173), (*g_1623)))) | 0x00L) , &g_552)), g_213)) ^ 1UL), l_1738.f0)) & 0x61L), 0x91D6L))) && p_13.f0))) , 3L) == l_1674) || l_1712), g_118)) || g_859) || 246UL) && p_14) && (*l_1665)), 11)) ^ 0xFA1C6F71L), 1)), 0x619F2925C2E3FF77LL)) > g_552) , (*g_175));
    }
    return l_1779;
}


/* ------------------------------------------ */
/* 
 * reads : g_102.f0.f0 g_365 g_366 g_1456 g_1457 g_1458 g_475 g_1623 g_841 g_899 g_900 g_108 g_46 g_1367 g_1253.f0 g_241 g_1484 g_175
 * writes: g_102.f0.f0 g_175 g_920 g_242
 */
static const int32_t * func_19(struct S0 * p_20, int32_t * p_21)
{ /* block id: 596 */
    const union U1 ***l_1325 = (void*)0;
    int32_t l_1330 = 0x8CDA91FFL;
    struct S0 *l_1333 = &g_102.f0;
    union U1 *l_1337 = &g_102;
    int32_t l_1388 = 0L;
    int64_t *l_1411 = (void*)0;
    int32_t l_1421 = 0x7D4B13A7L;
    int32_t l_1422 = 0xCA37E8C6L;
    int32_t l_1424 = 0xBBB3A754L;
    int32_t l_1426 = 1L;
    int32_t l_1427[4] = {0x22F559E2L,0x22F559E2L,0x22F559E2L,0x22F559E2L};
    int8_t l_1428 = (-6L);
    int64_t l_1430 = 0x93685746BF14E9A6LL;
    int32_t l_1470 = (-1L);
    int8_t l_1486 = 0xA7L;
    uint16_t l_1584 = 0xF88FL;
    uint16_t *l_1611 = &l_1584;
    uint8_t *l_1616 = &g_552;
    uint8_t **l_1617 = &l_1616;
    uint64_t ***l_1618 = (void*)0;
    uint64_t ***l_1620 = &g_1457;
    uint64_t ****l_1619 = &l_1620;
    uint64_t ***l_1622 = &g_1457;
    uint64_t ****l_1621 = &l_1622;
    int64_t l_1624[6][1][1] = {{{0L}},{{0x55811A655C58421ELL}},{{0L}},{{0L}},{{0x55811A655C58421ELL}},{{0L}}};
    int64_t *l_1625 = &g_920;
    int i, j, k;
    for (g_102.f0.f0 = 0; (g_102.f0.f0 < 50); g_102.f0.f0 = safe_add_func_int8_t_s_s(g_102.f0.f0, 5))
    { /* block id: 599 */
        int32_t *l_1305 = &g_29;
        union U1 ****l_1383 = (void*)0;
        const uint16_t l_1386 = 0x5BDFL;
        int64_t *l_1413 = &g_920;
        int32_t l_1414 = 0xBA970B95L;
        int32_t l_1415 = 0x8D594C19L;
        int32_t l_1416 = (-9L);
        int32_t l_1417[3][8] = {{0xB95884A9L,0x899B69E0L,0x5226E8D9L,0x899B69E0L,0xB95884A9L,0xB95884A9L,0x899B69E0L,0x5226E8D9L},{0xB95884A9L,0xB95884A9L,0x899B69E0L,1L,0x7369B608L,0x899B69E0L,0x899B69E0L,0x7369B608L},{0x5226E8D9L,0x7369B608L,0x7369B608L,0x5226E8D9L,0xB95884A9L,0x5226E8D9L,0x7369B608L,0x7369B608L}};
        int16_t l_1423 = 0x1983L;
        int16_t l_1429 = 0x7744L;
        union U1 l_1444 = {{0xEDL}};
        int32_t ****l_1483[8];
        int8_t * const l_1485 = &l_1428;
        uint8_t l_1489 = 0xD3L;
        uint32_t l_1556 = 0x2D96D616L;
        uint8_t l_1585 = 0x2EL;
        int i, j;
        for (i = 0; i < 8; i++)
            l_1483[i] = &g_365;
        (**g_365) = l_1305;
    }
    (*g_241) = (safe_add_func_uint8_t_u_u((0x86L != ((((l_1430 != (((((((*l_1625) = ((***g_1456) != (safe_rshift_func_int8_t_s_u(((((-2L) | (safe_div_func_uint64_t_u_u((((safe_rshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_s(((*l_1611) |= l_1424), (safe_mod_func_uint64_t_u_u((safe_sub_func_int64_t_s_s(0x4F92CC1E9321A2F8LL, (((*l_1617) = l_1616) == ((l_1618 != ((*l_1621) = ((*l_1619) = l_1618))) , g_1623)))), l_1427[3])))) < g_841[6][1]), 4)), (**g_899))) && g_46) , (**g_1457)), g_1367))) && l_1426) , (**g_899)), l_1624[3][0][0])))) && 0x73C4A5D1749D2F5ELL) && (*g_1458)) == 65535UL) == 0x2A63L) & 0x35L)) ^ 1L) | g_1253.f0) >= l_1470)), l_1470));
    return (***g_1484);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_58
 */
static int16_t  func_30(int32_t * p_31, const uint32_t  p_32, int16_t  p_33)
{ /* block id: 593 */
    struct S0 * const l_1299 = &g_95[1];
    struct S0 **l_1300 = &g_58;
    int32_t l_1301 = 0L;
    (*l_1300) = l_1299;
    return l_1301;
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_41 g_58 g_66 g_27 g_95 g_104 g_108 g_118 g_124 g_45 g_102.f0.f0 g_173 g_241 g_602 g_900 g_549 g_105 g_365 g_366 g_175 g_176 g_841 g_899 g_546 g_1221 g_458 g_920 g_475 g_762 g_432 g_433 g_277 g_242 g_464 g_214 g_356 g_552 g_699
 * writes: g_46 g_41 g_105 g_108 g_118 g_173 g_175 g_242 g_549 g_213 g_45 g_95 g_176 g_920 g_475 g_58 g_465 g_214 g_552 g_546 g_762
 */
static int32_t * func_34(int32_t  p_35, uint16_t  p_36)
{ /* block id: 4 */
    int32_t *l_40 = &g_41;
    int32_t *l_42 = &g_41;
    int32_t l_43 = (-1L);
    int32_t *l_44[8] = {&l_43,&g_41,&g_41,&l_43,&g_41,&g_41,&l_43,&g_41};
    struct S0 *l_65[8];
    int64_t l_144 = 0xD5BCCF1A09896714LL;
    union U1 l_210 = {{0xABL}};
    uint32_t l_215 = 0x82C358F4L;
    uint32_t l_220 = 0x2B290D55L;
    int32_t l_237 = 0x0B00CF65L;
    uint8_t l_302 = 0xE0L;
    int32_t l_307 = 1L;
    int32_t ***l_367 = (void*)0;
    int16_t *l_401 = &g_277;
    int32_t l_515 = 0x67BA0C65L;
    const uint8_t l_537 = 0x42L;
    struct S0 *l_558 = &l_210.f0;
    int8_t *l_713 = &g_108;
    union U1 *l_796 = &l_210;
    int16_t l_852 = 1L;
    int32_t *l_894 = &l_515;
    uint8_t *l_951 = &g_95[0].f0;
    uint32_t l_984[10] = {0x2F3F2BFEL,0x5A49CC71L,0x2F3F2BFEL,0x8EB1EC46L,0x8EB1EC46L,0x2F3F2BFEL,0x5A49CC71L,0x2F3F2BFEL,0x8EB1EC46L,0x8EB1EC46L};
    uint64_t l_986 = 18446744073709551615UL;
    uint8_t l_999 = 0xFFL;
    uint32_t l_1040 = 0x5CCC14E4L;
    int64_t l_1071 = 0L;
    uint16_t l_1086[3][3] = {{0x6789L,0x6789L,0x6789L},{0x2EEFL,65527UL,0x2EEFL},{0x6789L,0x6789L,0x6789L}};
    int32_t ****l_1101 = &l_367;
    union U1 **l_1126 = &g_105[1];
    const struct S0 **l_1250 = (void*)0;
    int i, j;
    for (i = 0; i < 8; i++)
        l_65[i] = (void*)0;
    g_46++;
    if ((*l_42))
    { /* block id: 6 */
        const uint32_t l_67 = 0xFAD54077L;
        struct S0 l_68 = {0x82L};
        int32_t **l_94 = &l_40;
        int32_t l_98 = 0x930CB047L;
        const int32_t *l_126 = &l_98;
        const int32_t **l_125 = &l_126;
        int32_t l_135 = 0xC179BD3BL;
        int32_t l_139 = (-9L);
        int32_t l_143 = 0L;
        int32_t l_147 = 0x98758D7FL;
        int32_t l_148 = 0x0311F254L;
        int32_t l_149 = 1L;
        int32_t l_150 = 0xA0514B5FL;
        int32_t l_151 = 0x9EDF83F4L;
        int32_t l_152 = 0x8CD9319AL;
        union U1 **l_179[2];
        int64_t l_180 = 0x99AC91F7FDD43B54LL;
        struct S0 l_181[7][9] = {{{0UL},{0x55L},{1UL},{1UL},{1UL},{1UL},{0x55L},{0UL},{3UL}},{{255UL},{1UL},{0xDBL},{0UL},{0xAAL},{0x55L},{0x55L},{0xAAL},{0UL}},{{0xEDL},{255UL},{0xEDL},{0x4FL},{0x55L},{1UL},{0x3CL},{3UL},{3UL}},{{1UL},{255UL},{3UL},{0x55L},{3UL},{255UL},{1UL},{0x3CL},{0xDBL}},{{0x3CL},{1UL},{0x55L},{0x4FL},{0xEDL},{255UL},{0xEDL},{0x4FL},{0x55L}},{{0x55L},{0x55L},{0xAAL},{0UL},{0xDBL},{1UL},{255UL},{0x3CL},{255UL}},{{0x55L},{1UL},{1UL},{1UL},{1UL},{0x55L},{0UL},{3UL},{2UL}}};
        int i, j;
        for (i = 0; i < 2; i++)
            l_179[i] = (void*)0;
        l_98 |= (func_49(func_54(g_58, ((*l_94) = func_59(l_65[6], ((0x37E05AF849FB95C1LL <= (g_66 , g_41)) != l_67), l_68, ((safe_div_func_uint32_t_u_u((g_27 ^ (safe_mod_func_uint16_t_u_u(p_36, g_41))), 4294967295UL)) != p_35), g_41)), g_95[0]), g_27, l_65[1], g_95[0].f0) , p_36);
        for (g_41 = 16; (g_41 >= 5); --g_41)
        { /* block id: 19 */
            uint32_t l_134 = 0UL;
            int32_t l_136 = 0x40C85F22L;
            int32_t l_138[2];
            int i;
            for (i = 0; i < 2; i++)
                l_138[i] = 1L;
            for (p_36 = 0; (p_36 <= 7); p_36 += 1)
            { /* block id: 22 */
                union U1 *l_101 = &g_102;
                int8_t *l_107[10] = {&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108};
                int16_t l_132[3];
                int32_t l_141 = (-1L);
                int32_t l_142 = 0xA4ECE64CL;
                int32_t l_145 = 5L;
                int32_t l_146 = 0x8DF6465DL;
                int i;
                for (i = 0; i < 3; i++)
                    l_132[i] = 0xE758L;
                (*g_104) = l_101;
                if (((safe_unary_minus_func_int8_t_s((g_108 &= g_27))) == 0x4A2B8684L))
                { /* block id: 25 */
                    int16_t l_121[4] = {9L,9L,9L,9L};
                    int32_t l_137 = (-6L);
                    int32_t l_140[5] = {0x5E10BBF0L,0x5E10BBF0L,0x5E10BBF0L,0x5E10BBF0L,0x5E10BBF0L};
                    uint32_t l_153 = 0x1C38EE3FL;
                    int i;
                    for (l_43 = 7; (l_43 >= 0); l_43 -= 1)
                    { /* block id: 28 */
                        uint16_t *l_117[9][8] = {{&g_118,&g_118,(void*)0,&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{(void*)0,&g_118,&g_118,(void*)0,&g_118,&g_118,&g_118,(void*)0},{&g_118,(void*)0,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,(void*)0,&g_118,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118,(void*)0,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118}};
                        const int32_t ***l_127 = &l_125;
                        union U1 l_131 = {{1UL}};
                        int32_t *l_133 = &l_43;
                        int i, j;
                        p_35 = (((&g_41 == ((p_35 & ((((safe_rshift_func_uint16_t_u_s(((((safe_div_func_uint8_t_u_u(g_27, (safe_add_func_int64_t_s_s((safe_rshift_func_uint16_t_u_s((g_118--), 3)), (((l_121[0] = g_41) <= (((safe_mod_func_int64_t_s_s(((g_124[5] == ((*l_127) = l_125)) ^ (safe_mod_func_uint32_t_u_u((p_35 , (~((l_131 , p_35) > g_41))), 0x9E83D486L))), p_36)) && 7UL) , p_36)) , (*l_42)))))) , 0xD4ECL) > 65534UL) <= l_132[1]), 2)) | 1L) , p_36) ^ 0UL)) , l_133)) >= g_45) && g_108);
                        l_135 |= (4UL ^ l_134);
                        l_44[p_36] = &p_35;
                    }
                    --l_153;
                    p_35 ^= 0xDE66CDFBL;
                }
                else
                { /* block id: 38 */
                    uint16_t *l_160 = &g_118;
                    uint64_t *l_172 = &g_173;
                    int32_t *l_174[10][4][5] = {{{&l_151,&l_136,&l_149,&l_136,&l_151},{&g_41,&l_138[1],&l_152,&l_149,&l_149},{&l_149,&l_136,&l_141,&l_136,&l_149},{&l_149,&l_149,&l_152,&l_138[1],&g_41}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&l_149,&l_138[1],&l_138[0],&l_149,&g_41},{&l_149,&l_136,&l_141,&l_136,&l_149},{&g_41,&l_149,&l_138[0],&l_138[1],&l_149}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&g_41,&l_138[1],&l_152,&l_149,&l_149},{&l_149,&l_136,&l_141,&l_136,&l_149},{&l_149,&l_149,&l_152,&l_138[1],&g_41}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&l_149,&l_138[1],&l_138[0],&l_149,&g_41},{&l_149,&l_136,&l_141,&l_136,&l_149},{&g_41,&l_149,&l_138[0],&l_138[1],&l_149}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&g_41,&l_138[1],&l_152,&l_149,&l_149},{&l_149,&l_136,&l_141,&l_136,&l_149},{&l_149,&l_149,&l_152,&l_138[1],&g_41}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&l_149,&l_138[1],&l_138[0],&l_149,&g_41},{&l_149,&l_136,&l_141,&l_136,&l_149},{&g_41,&l_149,&l_138[0],&l_138[1],&l_149}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&g_41,&l_138[1],&l_152,&l_149,&l_149},{&l_149,&l_136,&l_141,&l_136,&l_149},{&l_149,&l_149,&l_152,&l_138[1],&g_41}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&l_149,&l_138[1],&l_138[0],&l_149,&g_41},{&l_149,&l_136,&l_141,&l_136,&l_149},{&g_41,&l_149,&l_138[0],&l_138[1],&l_149}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&g_41,&l_138[1],&l_152,&l_149,&l_149},{&l_149,&l_136,&l_141,&l_136,&l_149},{&l_149,&l_149,&l_152,&l_138[1],&g_41}},{{&l_151,&l_136,&l_149,&l_136,&l_151},{&l_149,&l_138[1],&l_138[0],&l_149,(void*)0},{(void*)0,&l_141,&l_143,&l_141,(void*)0},{(void*)0,&l_149,(void*)0,&l_149,&l_138[1]}}};
                    int i, j, k;
                    p_35 = (((((*l_160) = (safe_rshift_func_uint8_t_u_s(g_66.f0, (safe_sub_func_int8_t_s_s(0x76L, 0x1AL))))) > 65535UL) || (safe_add_func_int8_t_s_s(l_134, (l_142 || ((safe_lshift_func_uint16_t_u_s(((safe_mul_func_int16_t_s_s(((safe_sub_func_uint64_t_u_u(((safe_div_func_int8_t_s_s(l_141, (~((*l_172) = ((-1L) || 4UL))))) || g_102.f0.f0), g_27)) >= p_36), 65535UL)) , 0xE988L), 3)) < p_35))))) , 3L);
                    (*l_125) = l_174[6][3][2];
                }
                if (p_36)
                    continue;
                if ((((g_175 = &g_41) != (void*)0) != (2UL | (l_180 = (((g_27 || ((g_173 ^ (safe_add_func_uint32_t_u_u((((void*)0 != g_124[2]) || (l_179[1] != (void*)0)), p_35))) < l_138[0])) , 0L) , 1L)))))
                { /* block id: 47 */
                    for (l_150 = 0; (l_150 <= 7); l_150 += 1)
                    { /* block id: 50 */
                        p_35 |= l_132[1];
                    }
                }
                else
                { /* block id: 53 */
                    l_138[1] = 0x5B1A0453L;
                    l_181[2][3] = l_68;
                }
            }
        }
    }
    else
    { /* block id: 59 */
        uint64_t l_186 = 18446744073709551615UL;
        int32_t **l_199 = &l_44[7];
        int32_t ***l_198[7][4][9] = {{{(void*)0,(void*)0,&l_199,(void*)0,&l_199,(void*)0,(void*)0,&l_199,&l_199},{&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0},{&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199},{&l_199,&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199}},{{(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,(void*)0,(void*)0,&l_199},{&l_199,(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199},{&l_199,(void*)0,&l_199,(void*)0,&l_199,(void*)0,&l_199,(void*)0,&l_199},{&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0}},{{(void*)0,(void*)0,&l_199,(void*)0,&l_199,(void*)0,(void*)0,&l_199,&l_199},{&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0},{&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199},{&l_199,&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199}},{{(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,(void*)0,(void*)0,&l_199},{&l_199,(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199},{&l_199,(void*)0,&l_199,(void*)0,&l_199,(void*)0,&l_199,(void*)0,&l_199},{&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0}},{{(void*)0,(void*)0,&l_199,(void*)0,&l_199,(void*)0,(void*)0,&l_199,&l_199},{&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0},{&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199},{&l_199,&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199}},{{&l_199,&l_199,(void*)0,(void*)0,(void*)0,&l_199,&l_199,&l_199,(void*)0},{&l_199,(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199},{&l_199,&l_199,&l_199,(void*)0,(void*)0,&l_199,&l_199,&l_199,(void*)0},{(void*)0,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,&l_199,(void*)0}},{{&l_199,&l_199,(void*)0,&l_199,(void*)0,&l_199,&l_199,&l_199,(void*)0},{(void*)0,(void*)0,&l_199,&l_199,&l_199,&l_199,&l_199,&l_199,(void*)0},{&l_199,&l_199,&l_199,&l_199,(void*)0,&l_199,&l_199,&l_199,(void*)0},{&l_199,&l_199,&l_199,(void*)0,(void*)0,&l_199,&l_199,&l_199,&l_199}}};
        uint8_t *l_200 = &g_95[0].f0;
        const union U1 l_201[6][6] = {{{{0xE7L}},{{0xE7L}},{{0x9FL}},{{1UL}},{{0x2AL}},{{1UL}}},{{{0x11L}},{{0xE7L}},{{0x11L}},{{0xA2L}},{{0x9FL}},{{0x9FL}}},{{{0xDEL}},{{0x11L}},{{0x11L}},{{0xDEL}},{{0xE7L}},{{1UL}}},{{{1UL}},{{0xDEL}},{{0x9FL}},{{0xDEL}},{{1UL}},{{0xA2L}}},{{{0xDEL}},{{1UL}},{{0xA2L}},{{0xA2L}},{{1UL}},{{0xDEL}}},{{{0x11L}},{{0xDEL}},{{0xE7L}},{{1UL}},{{0xE7L}},{{0xDEL}}}};
        uint8_t l_208 = 1UL;
        struct S0 l_219 = {1UL};
        int32_t * const *l_246 = (void*)0;
        int32_t *l_255 = &l_237;
        int8_t l_322[4][6] = {{0xE5L,0x23L,0xE5L,0x23L,0xE5L,0x23L},{0x22L,0x23L,0x22L,0x23L,0x22L,0x23L},{0xE5L,0x23L,0xE5L,0x23L,0xE5L,0x23L},{0x22L,0x23L,0x22L,0x23L,0x22L,0x23L}};
        int16_t *l_399[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int64_t l_460 = 1L;
        int16_t l_506 = 0x3C6AL;
        struct S0 **l_603[4][1] = {{&g_58},{&l_65[6]},{&g_58},{&l_65[6]}};
        struct S0 l_647 = {0UL};
        int8_t l_655 = 0x83L;
        int32_t *l_663 = &l_515;
        uint64_t l_701 = 0x44DA25A450A46DE2LL;
        int8_t *l_710 = &l_322[0][0];
        union U1 **l_790 = (void*)0;
        int64_t l_921[10] = {0x8CF1849EF3FAE03BLL,0x7D17204324117E5BLL,0x8CF1849EF3FAE03BLL,0x8CF1849EF3FAE03BLL,0x7D17204324117E5BLL,0x8CF1849EF3FAE03BLL,0x8CF1849EF3FAE03BLL,0x7D17204324117E5BLL,0x8CF1849EF3FAE03BLL,0x8CF1849EF3FAE03BLL};
        uint64_t l_927 = 0xECBC5B1240871DCBLL;
        int i, j, k;
        for (g_41 = 0; (g_41 < 23); g_41 = safe_add_func_uint16_t_u_u(g_41, 8))
        { /* block id: 62 */
            return &g_41;
        }
    }
    (*g_241) = l_986;
    if (((l_65[6] != (*g_602)) , (+((*g_900) = ((*l_558) , (p_35 & p_35))))))
    { /* block id: 408 */
        const int32_t *l_1006 = &l_307;
        const int32_t **l_1005 = &l_1006;
        const int32_t ***l_1004[10];
        int32_t l_1084[6][6] = {{0x5EE438A4L,(-1L),(-9L),(-1L),0x5EE438A4L,0x5EE438A4L},{0xB246FEA2L,(-1L),(-1L),0xB246FEA2L,0x5E1457C5L,0xB246FEA2L},{0xB246FEA2L,0x5E1457C5L,0xB246FEA2L,(-1L),(-1L),0xB246FEA2L},{0x5EE438A4L,0x5EE438A4L,(-1L),(-9L),(-1L),0x5EE438A4L},{(-1L),0x5E1457C5L,(-9L),(-9L),0x5E1457C5L,(-1L)},{0x5EE438A4L,(-1L),(-9L),(-1L),(-1L),(-1L)}};
        struct S0 l_1117 = {0xB0L};
        union U1 **l_1120 = (void*)0;
        uint32_t l_1154 = 0x75C5B201L;
        const int32_t l_1167 = 0xE790980FL;
        int i, j;
        for (i = 0; i < 10; i++)
            l_1004[i] = &l_1005;
        for (l_307 = (-13); (l_307 != 24); l_307 = safe_add_func_uint64_t_u_u(l_307, 1))
        { /* block id: 411 */
            uint64_t *l_990 = &l_986;
            const int32_t ****l_1007 = (void*)0;
            const int32_t ****l_1008 = &l_1004[0];
            uint32_t *l_1009 = &l_984[2];
            int32_t l_1036 = 0x3BE3EAFEL;
            int8_t **l_1062 = &g_900;
            uint8_t l_1064[5] = {1UL,1UL,1UL,1UL,1UL};
            uint64_t l_1083[3];
            int32_t l_1085 = 0xB1992013L;
            struct S0 l_1116 = {4UL};
            uint64_t l_1132[1][5][4] = {{{1UL,0xCBD6523FDF8749A0LL,0xCBD6523FDF8749A0LL,1UL},{18446744073709551607UL,0xCBD6523FDF8749A0LL,0xD17EEC927CDAC6C8LL,0xCBD6523FDF8749A0LL},{0xCBD6523FDF8749A0LL,3UL,0xD17EEC927CDAC6C8LL,0xD17EEC927CDAC6C8LL},{18446744073709551607UL,18446744073709551607UL,0xCBD6523FDF8749A0LL,0xD17EEC927CDAC6C8LL},{1UL,3UL,1UL,0xCBD6523FDF8749A0LL}}};
            uint32_t l_1133[10];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_1083[i] = 0x6B8D04513C532233LL;
            for (i = 0; i < 10; i++)
                l_1133[i] = 9UL;
        }
        (*l_894) = 0x704A20DEL;
    }
    else
    { /* block id: 509 */
        union U1 l_1216[9][9][3] = {{{{{0x07L}},{{255UL}},{{0x3FL}}},{{{0x0BL}},{{0xF7L}},{{6UL}}},{{{0x19L}},{{0x19L}},{{0x07L}}},{{{0x57L}},{{0x30L}},{{252UL}}},{{{255UL}},{{0x12L}},{{247UL}}},{{{0xCBL}},{{0x59L}},{{2UL}}},{{{255UL}},{{255UL}},{{247UL}}},{{{247UL}},{{1UL}},{{252UL}}},{{{255UL}},{{0x3BL}},{{0x07L}}}},{{{{255UL}},{{0x75L}},{{6UL}}},{{{0x7DL}},{{247UL}},{{0x3FL}}},{{{0xB9L}},{{0x57L}},{{255UL}}},{{{0xC9L}},{{0x9BL}},{{255UL}}},{{{7UL}},{{1UL}},{{1UL}}},{{{0xA5L}},{{4UL}},{{0x43L}}},{{{1UL}},{{1UL}},{{1UL}}},{{{252UL}},{{0x07L}},{{0x2AL}}},{{{0xA8L}},{{247UL}},{{0xECL}}}},{{{{0x79L}},{{1UL}},{{1UL}}},{{{1UL}},{{0x57L}},{{0xCBL}}},{{{0x30L}},{{1UL}},{{0x4FL}}},{{{0xB4L}},{{247UL}},{{254UL}}},{{{0x3FL}},{{0x07L}},{{250UL}}},{{{252UL}},{{1UL}},{{0xA8L}}},{{{0UL}},{{4UL}},{{0x2FL}}},{{{250UL}},{{1UL}},{{0xE2L}}},{{{255UL}},{{0x9BL}},{{0xB8L}}}},{{{{0xADL}},{{0x57L}},{{0x34L}}},{{{0x07L}},{{247UL}},{{255UL}}},{{{0x57L}},{{0x75L}},{{0x57L}}},{{{6UL}},{{0x3BL}},{{0x9BL}}},{{{0xE2L}},{{1UL}},{{0x75L}}},{{{0x21L}},{{255UL}},{{0x30L}}},{{{0x97L}},{{0x59L}},{{0x8FL}}},{{{0x21L}},{{0x12L}},{{3UL}}},{{{0xE2L}},{{0x30L}},{{0xF7L}}}},{{{{6UL}},{{0x19L}},{{255UL}}},{{{0x57L}},{{0xF7L}},{{0x8DL}}},{{{0x07L}},{{255UL}},{{0x7DL}}},{{{0xADL}},{{0x34L}},{{8UL}}},{{{255UL}},{{0x2FL}},{{6UL}}},{{{250UL}},{{1UL}},{{0x57L}}},{{{0UL}},{{0x2AL}},{{0x47L}}},{{{252UL}},{{252UL}},{{250UL}}},{{{0x3FL}},{{1UL}},{{0x19L}}}},{{{{0xB4L}},{{0xADL}},{{246UL}}},{{{0x30L}},{{0UL}},{{0x3BL}}},{{{1UL}},{{0xB4L}},{{246UL}}},{{{0x79L}},{{0x7DL}},{{0x19L}}},{{{0xA8L}},{{2UL}},{{250UL}}},{{{252UL}},{{0x4FL}},{{0x47L}}},{{{1UL}},{{246UL}},{{0x57L}}},{{{0xA5L}},{{0x3FL}},{{6UL}}},{{{7UL}},{{254UL}},{{8UL}}}},{{{{0xC9L}},{{1UL}},{{0x21L}}},{{{255UL}},{{0xCBL}},{{252UL}}},{{{0x21L}},{{0x7DL}},{{0x7DL}}},{{{0x59L}},{{6UL}},{{0xE4L}}},{{{247UL}},{{0x07L}},{{0UL}}},{{{0x8EL}},{{8UL}},{{254UL}}},{{{0x7DL}},{{255UL}},{{255UL}}},{{{0xA8L}},{{8UL}},{{0x57L}}},{{{1UL}},{{0x07L}},{{3UL}}}},{{{{3UL}},{{6UL}},{{0xB4L}}},{{{0x07L}},{{0x7DL}},{{247UL}}},{{{0xE2L}},{{0xCBL}},{{1UL}}},{{{0xF4L}},{{250UL}},{{6UL}}},{{{0x8DL}},{{0x91L}},{{255UL}}},{{{4UL}},{{0xC0L}},{{1UL}}},{{{6UL}},{{247UL}},{{246UL}}},{{{255UL}},{{0x3FL}},{{255UL}}},{{{2UL}},{{0x8FL}},{{0x91L}}}},{{{{6UL}},{{0x21L}},{{0x3FL}}},{{{0x34L}},{{0x30L}},{{0xA8L}}},{{{0x30L}},{{0x2AL}},{{0x9BL}}},{{{0x34L}},{{0x97L}},{{0x0BL}}},{{{6UL}},{{0xC9L}},{{1UL}}},{{{2UL}},{{250UL}},{{1UL}}},{{{255UL}},{{1UL}},{{0x19L}}},{{{6UL}},{{0x8DL}},{{5UL}}},{{{4UL}},{{1UL}},{{255UL}}}}};
        int32_t l_1285 = 0xAFF58AB1L;
        int i, j, k;
        for (g_549 = 0; (g_549 <= 3); g_549 += 1)
        { /* block id: 512 */
            uint32_t *l_1214[6];
            uint8_t *l_1226 = (void*)0;
            struct S0 l_1242[9] = {{0x2AL},{0x2AL},{0x2AL},{0x2AL},{0x2AL},{0x2AL},{0x2AL},{0x2AL},{0x2AL}};
            union U1 l_1256 = {{1UL}};
            int64_t *l_1284 = &g_45;
            uint32_t l_1289[1][1][9] = {{{7UL,0xB377BB6FL,7UL,0xB377BB6FL,7UL,0xB377BB6FL,7UL,0xB377BB6FL,7UL}}};
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_1214[i] = &g_841[6][3];
            for (g_213 = 3; (g_213 >= 0); g_213 -= 1)
            { /* block id: 515 */
                (*l_1126) = (*l_1126);
            }
            for (l_210.f0.f0 = 0; (l_210.f0.f0 <= 0); l_210.f0.f0 += 1)
            { /* block id: 520 */
                struct S0 l_1225[2][4] = {{{0xB1L},{0xA9L},{0xA9L},{0xB1L}},{{0xA9L},{0xB1L},{0xA9L},{0xA9L}}};
                struct S0 *l_1243 = &l_1242[1];
                const struct S0 *l_1252[6][6] = {{&g_1253,&g_1253,&g_1253,&g_1253,&g_1253,(void*)0},{&g_1253,&g_1253,(void*)0,&g_1253,&g_1253,&g_1253},{&g_1253,&g_1253,&g_1253,&g_1253,&g_1253,&g_1253},{&g_1253,&g_1253,(void*)0,(void*)0,&g_1253,(void*)0},{&g_1253,&g_1253,&g_1253,(void*)0,&g_1253,(void*)0},{&g_1253,&g_1253,&g_1253,&g_1253,&g_1253,(void*)0}};
                const struct S0 **l_1251 = &l_1252[1][4];
                int32_t l_1260[2];
                int i, j;
                for (i = 0; i < 2; i++)
                    l_1260[i] = (-9L);
                for (g_45 = 0; g_45 < 4; g_45 += 1)
                {
                    struct S0 tmp = {0x3AL};
                    g_95[g_45] = tmp;
                }
                for (l_999 = 0; (l_999 <= 3); l_999 += 1)
                { /* block id: 524 */
                    const uint8_t l_1208[6] = {0UL,0UL,247UL,0UL,0UL,247UL};
                    uint32_t *l_1215 = &l_1040;
                    int32_t l_1218 = 1L;
                    int i;
                    for (l_852 = 0; (l_852 <= 0); l_852 += 1)
                    { /* block id: 527 */
                        int i, j, k;
                        (***g_365) ^= (-3L);
                        p_35 ^= (safe_add_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((l_1208[2] ^ (((((safe_unary_minus_func_uint64_t_u(0UL)) , g_841[0][0]) != (***g_365)) , (((0x45L | (safe_rshift_func_uint8_t_u_s((((*l_951) = 0xFEL) >= ((safe_lshift_func_uint16_t_u_s(l_1208[1], ((**g_899) ^ (l_1214[0] == l_1215)))) & 0x41D362F9B33ED1F8LL)), p_36))) , 0x26A8ECE3L) , l_1216[3][8][1])) , 0x7520D0FBL)), 0x0DAEL)), p_36));
                    }
                    for (l_144 = 0; (l_144 >= 0); l_144 -= 1)
                    { /* block id: 534 */
                        int64_t *l_1223 = &l_1071;
                        int64_t *l_1224 = &g_920;
                        uint64_t *l_1237 = &g_173;
                        uint64_t *l_1240 = &g_475;
                        uint32_t l_1241[8][6][5] = {{{0x8CB80592L,1UL,0UL,0x2612CD30L,0x7B69E098L},{0x9164ADDAL,0UL,1UL,4294967295UL,4294967287UL},{3UL,4294967292UL,0x0EBEB8F4L,6UL,0x9164ADDAL},{0x68121D1CL,0x0EBEB8F4L,0x5595731EL,0xF57EE488L,0x11490709L},{4294967295UL,0xC3D63D6EL,0x94B8334EL,0xC1CA1CC0L,4294967295UL},{0x34A59604L,4294967294UL,4294967295UL,0xF4EEEC0FL,0x68121D1CL}},{{0x0EBEB8F4L,0xE917E849L,0x8CB80592L,0xC14D6858L,0xCE0448BEL},{1UL,0x8D5C5AFBL,0x2612CD30L,0x8CB80592L,0UL},{4294967295UL,3UL,0x8E161FC3L,4294967295UL,0x1E50BC6BL},{1UL,4294967291UL,0x0052A276L,0xC310A276L,4294967295UL},{0xF4EEEC0FL,0xE7F63121L,0x6D8EDA4EL,4294967294UL,0UL},{0x061F5E48L,0UL,4294967295UL,0xCE0448BEL,4294967295UL}},{{1UL,0UL,0xC559EBDEL,0xE922FE6DL,4294967292UL},{0UL,6UL,1UL,1UL,0xCE0448BEL},{4294967295UL,0x6D8EDA4EL,1UL,0x9A80439CL,1UL},{0x5D6A3C97L,0x275DFE3FL,1UL,0x275DFE3FL,0x5D6A3C97L},{0x8C3D4598L,0x62D23F24L,0UL,6UL,0x9D896E78L},{6UL,4294967294UL,0xE917E849L,0x9164ADDAL,0x21DE6865L}},{{4294967291UL,0UL,0x7BA9D61EL,0x62D23F24L,0x9D896E78L},{0x5F5ED0F4L,0x9164ADDAL,0x6D2E4563L,0xC559EBDEL,0x5D6A3C97L},{0x9D896E78L,0x9AEE804AL,0xEDD766F6L,0x63FFBDACL,1UL},{0x6D8EDA4EL,4294967295UL,0x275DFE3FL,0x1E50BC6BL,0xCE0448BEL},{0x62D23F24L,0UL,0x94B8334EL,0x5595731EL,4294967292UL},{0x7BA9D61EL,7UL,0x8D5C5AFBL,0xC1CA1CC0L,4294967295UL}},{{4294967291UL,1UL,1UL,0x7B69E098L,0UL},{1UL,0x0EBEB8F4L,0x2D60BB2EL,8UL,4294967295UL},{0xA3CF8492L,4294967295UL,1UL,0x34A59604L,0x1E50BC6BL},{4294967291UL,4294967295UL,0x2612CD30L,1UL,0xFB38F0FBL},{0xC1CA1CC0L,0x0EBEB8F4L,4294967295UL,0xE917E849L,0x98AF298FL},{4UL,1UL,0UL,0xA3CF8492L,0x34A59604L}},{{0x2A55190BL,7UL,0xF4EEEC0FL,4294967291UL,1UL},{0xD4846BEFL,0UL,1UL,1UL,0x275DFE3FL},{0x11490709L,4294967295UL,0xE922FE6DL,0x8D5C5AFBL,0UL},{0xFF5C96B8L,0x9AEE804AL,0x9AEE804AL,0xFF5C96B8L,0x061F5E48L},{0x2D60BB2EL,0x9164ADDAL,0xFF5C96B8L,4294967295UL,0xA567886BL},{4294967292UL,0UL,0x8CB80592L,4294967291UL,0xF4EEEC0FL}},{{0UL,4294967294UL,0UL,4294967295UL,4294967295UL},{1UL,0x62D23F24L,0x5F5ED0F4L,0xFF5C96B8L,0x94B8334EL},{0x0EBEB8F4L,0x275DFE3FL,0xC3D63D6EL,0x8D5C5AFBL,0x62D23F24L},{0x5595731EL,0x6D8EDA4EL,1UL,1UL,0x68121D1CL},{0x94B8334EL,6UL,1UL,4294967291UL,0UL},{4294967295UL,0UL,0xD4846BEFL,0xA3CF8492L,0x6D8EDA4EL}},{{0x8CB80592L,0UL,4294967295UL,0xE917E849L,0x11490709L},{0x2612CD30L,0xE7F63121L,0UL,1UL,1UL},{0x8E161FC3L,4294967291UL,0x5595731EL,0x34A59604L,0x9AEE804AL},{0x8E161FC3L,0x2570E6B1L,0UL,8UL,0x8D5C5AFBL},{0x2612CD30L,4294967291UL,0xA567886BL,0x7B69E098L,0x2A55190BL},{4294967295UL,0x34A59604L,4294967292UL,0x2D60BB2EL,0x2612CD30L}}};
                        int i, j, k;
                        (***g_365) |= 0x14BDBD01L;
                        p_35 ^= ((l_1086[(l_210.f0.f0 + 1)][l_144] | (!65534UL)) , (l_1218 = g_546[l_210.f0.f0][(l_999 + 2)][l_210.f0.f0]));
                        (*g_241) = ((***g_365) = ((0x028DL <= (((((g_546[l_144][(l_144 + 5)][l_144] , (safe_div_func_int64_t_s_s(((((void*)0 == g_1221) > (((+g_458) | 4L) ^ ((((*l_1224) |= ((*l_1223) = g_27)) | (g_46 <= ((g_95[(l_144 + 3)] = l_1225[1][3]) , g_475))) || 0x8CF57CBEL))) ^ l_1216[3][8][1].f0.f0), 0xA3C526E3DC175F22LL))) || p_36) != (-1L)) && 0x6287L) , 0x61A5L)) && g_762));
                        (*g_241) = ((*g_175) = ((((((void*)0 != l_1226) , l_1208[2]) != (**g_432)) <= (safe_add_func_int16_t_s_s(((((**g_899) = (p_36 > (p_35 & (safe_add_func_int64_t_s_s((safe_mod_func_uint32_t_u_u((safe_add_func_int64_t_s_s((safe_add_func_uint64_t_u_u((g_841[3][1] > (0x34F2CC92D8950CD4LL != (++(*l_1237)))), ((*l_1240) = p_35))), 0xB0ECF19422747159LL)), (*g_175))), g_242))))) <= 1L) ^ l_1241[1][1][0]), 0x3A67L))) & 0x3C76D881L));
                    }
                }
                l_1242[1] = func_54(&l_1225[1][0], l_1214[0], (g_95[(l_210.f0.f0 + 1)] = l_1216[3][8][1].f0));
                for (l_144 = 0; (l_144 >= 0); l_144 -= 1)
                { /* block id: 554 */
                    struct S0 l_1244 = {0xA6L};
                    (*g_464) = func_59(((*g_602) = l_1243), l_1225[1][3].f0, l_1244, g_46, ((!((safe_rshift_func_int8_t_s_u((*g_900), ((**g_432) | ((safe_mul_func_int16_t_s_s(((l_1251 = l_1250) == ((&l_852 != (*g_432)) , g_602)), 5L)) == 2UL)))) || 0x0477L)) < 0x3F8F0A80L));
                    for (g_214 = 0; (g_214 <= 0); g_214 += 1)
                    { /* block id: 560 */
                        int16_t **l_1259 = &l_401;
                        (**g_365) = func_59((*g_356), (p_36 || 2L), (*g_58), (g_552 = ((safe_div_func_uint8_t_u_u((((p_35 & (l_1256 , g_552)) & p_36) || (safe_rshift_func_uint8_t_u_u(((*l_951) = (((((void*)0 == l_1259) , (-1L)) || 4294967295UL) , g_173)), 7))), p_35)) || p_36)), p_36);
                    }
                    for (l_220 = 0; (l_220 <= 0); l_220 += 1)
                    { /* block id: 567 */
                        uint32_t l_1261 = 0x9031259EL;
                        uint32_t *l_1283 = &g_762;
                        uint64_t *l_1287 = &g_173;
                        uint64_t **l_1286 = &l_1287;
                        uint64_t ***l_1288 = &l_1286;
                        int i, j, k;
                        --l_1261;
                        (*g_241) = ((~(+0UL)) , (l_1285 = (((safe_lshift_func_int8_t_s_u(((safe_rshift_func_int8_t_s_s(((4294967288UL <= ((0x0ECE1437L == ((((*l_1283) ^= (safe_lshift_func_uint8_t_u_u(((*g_241) < (7L ^ (((g_546[l_210.f0.f0][(l_210.f0.f0 + 6)][(l_210.f0.f0 + 1)] = (~(((safe_add_func_uint8_t_u_u((18446744073709551609UL > (safe_sub_func_int8_t_s_s(((p_36 , (((((-10L) ^ (safe_mul_func_int8_t_s_s(((0x500134FBL || p_35) >= p_36), p_35))) , l_1216[3][8][1].f0.f0) < p_36) > g_552)) , p_35), l_1244.f0))), (*g_900))) , l_1244.f0) < 4294967293UL))) , p_35) < p_35))), 6))) < p_35) <= g_699)) & p_36)) && (*l_894)), 4)) > 0xBEL), 5)) , (void*)0) == l_1284)));
                        (*l_1288) = l_1286;
                        (*l_40) = 0xEBF2E69FL;
                    }
                }
            }
            ++l_1289[0][0][1];
        }
        for (g_41 = 0; (g_41 == (-2)); --g_41)
        { /* block id: 582 */
            return (**g_365);
        }
        (*g_175) = (((safe_rshift_func_uint16_t_u_u(l_1285, 4)) > 1L) ^ 0x15B4L);
        for (l_1040 = 2; (l_1040 == 56); l_1040++)
        { /* block id: 588 */
            (*l_40) |= (&g_105[4] == (void*)0);
        }
    }
    return (**g_365);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_49(struct S0  p_50, const int64_t  p_51, const struct S0 * p_52, int32_t  p_53)
{ /* block id: 14 */
    uint64_t l_97 = 0xCD76E668196E547ELL;
    return l_97;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static struct S0  func_54(struct S0 * p_55, int32_t * p_56, struct S0  p_57)
{ /* block id: 12 */
    struct S0 l_96 = {9UL};
    return l_96;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_46 g_41
 * writes: g_41
 */
static int32_t * func_59(struct S0 * p_60, int16_t  p_61, struct S0  p_62, uint8_t  p_63, int32_t  p_64)
{ /* block id: 7 */
    int8_t l_78 = (-4L);
    int32_t l_93 = 0xF9AB13FDL;
    g_41 = (l_93 = (safe_sub_func_uint8_t_u_u((!((&g_66 != &g_66) && g_27)), (safe_add_func_int16_t_s_s(l_78, (safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(((((p_62.f0 || ((safe_add_func_uint16_t_u_u(g_46, l_78)) || ((safe_lshift_func_uint8_t_u_u(g_41, ((safe_rshift_func_uint8_t_u_u(0xE8L, 4)) > g_41))) >= g_27))) || g_46) != 0x1FL) == g_27), 0)), p_64)) , (-1L)), l_78)), p_61)))))));
    return &g_41;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_66.f0, "g_66.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_95[i].f0, "g_95[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_102.f0.f0, "g_102.f0.f0", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_214, "g_214", print_hash_value);
    transparent_crc(g_242, "g_242", print_hash_value);
    transparent_crc(g_277, "g_277", print_hash_value);
    transparent_crc(g_458, "g_458", print_hash_value);
    transparent_crc(g_475, "g_475", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_546[i][j][k], "g_546[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_549, "g_549", print_hash_value);
    transparent_crc(g_552, "g_552", print_hash_value);
    transparent_crc(g_699, "g_699", print_hash_value);
    transparent_crc(g_725, "g_725", print_hash_value);
    transparent_crc(g_762, "g_762", print_hash_value);
    transparent_crc(g_783.f0, "g_783.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_841[i][j], "g_841[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_859, "g_859", print_hash_value);
    transparent_crc(g_920, "g_920", print_hash_value);
    transparent_crc(g_923, "g_923", print_hash_value);
    transparent_crc(g_930, "g_930", print_hash_value);
    transparent_crc(g_1061, "g_1061", print_hash_value);
    transparent_crc(g_1102, "g_1102", print_hash_value);
    transparent_crc(g_1184, "g_1184", print_hash_value);
    transparent_crc(g_1253.f0, "g_1253.f0", print_hash_value);
    transparent_crc(g_1367, "g_1367", print_hash_value);
    transparent_crc(g_1472, "g_1472", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1516[i][j][k], "g_1516[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 442
   depth: 1, occurrence: 27
XXX total union variables: 16

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 42
breakdown:
   depth: 1, occurrence: 98
   depth: 2, occurrence: 27
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 12, occurrence: 1
   depth: 15, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 2
   depth: 22, occurrence: 4
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 2
   depth: 30, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 42, occurrence: 1

XXX total number of pointers: 284

XXX times a variable address is taken: 687
XXX times a pointer is dereferenced on RHS: 234
breakdown:
   depth: 1, occurrence: 151
   depth: 2, occurrence: 62
   depth: 3, occurrence: 17
   depth: 4, occurrence: 4
XXX times a pointer is dereferenced on LHS: 284
breakdown:
   depth: 1, occurrence: 235
   depth: 2, occurrence: 30
   depth: 3, occurrence: 16
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 37
XXX times a pointer is compared with address of another variable: 12
XXX times a pointer is compared with another pointer: 13
XXX times a pointer is qualified to be dereferenced: 6075

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 807
   level: 2, occurrence: 189
   level: 3, occurrence: 99
   level: 4, occurrence: 25
   level: 5, occurrence: 3
XXX number of pointers point to pointers: 103
XXX number of pointers point to scalars: 149
XXX number of pointers point to structs: 21
XXX percent of pointers has null in alias set: 30.6
XXX average alias set size: 1.51

XXX times a non-volatile is read: 1544
XXX times a non-volatile is write: 823
XXX times a volatile is read: 59
XXX    times read thru a pointer: 15
XXX times a volatile is write: 34
XXX    times written thru a pointer: 27
XXX times a volatile is available for access: 881
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 2
XXX backward jumps: 6

XXX stmts: 99
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 23
   depth: 1, occurrence: 14
   depth: 2, occurrence: 9
   depth: 3, occurrence: 13
   depth: 4, occurrence: 19
   depth: 5, occurrence: 21

XXX percentage a fresh-made variable is used: 17
XXX percentage an existing variable is used: 83
********************* end of statistics **********************/

