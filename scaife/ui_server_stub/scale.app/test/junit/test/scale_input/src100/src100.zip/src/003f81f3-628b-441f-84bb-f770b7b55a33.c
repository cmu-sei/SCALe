/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      182561164
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile int8_t  f0;
   unsigned f1 : 25;
   const volatile int16_t  f2;
   uint32_t  f3;
};

union U1 {
   volatile uint8_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-1L);
static uint8_t g_11[7][8][4] = {{{0x08L,0x19L,0UL,0xCFL},{4UL,0x41L,0x4DL,246UL},{0x6BL,255UL,255UL,0x6BL},{0xDCL,1UL,250UL,0UL},{0x52L,1UL,252UL,0UL},{0x92L,0x6BL,0x6FL,0UL},{1UL,1UL,7UL,0UL},{0UL,1UL,0x19L,0x6BL}},{{0x4DL,255UL,0x6EL,246UL},{0x74L,0x41L,1UL,0xCFL},{0x6EL,0x19L,255UL,0UL},{1UL,255UL,0x67L,0UL},{250UL,0x6BL,0UL,1UL},{251UL,255UL,252UL,0x08L},{0x08L,0x8FL,1UL,0xD9L},{0x08L,0xCFL,252UL,0UL}},{{251UL,0xD9L,0UL,7UL},{250UL,255UL,0x67L,1UL},{255UL,255UL,0x08L,0x41L},{0x6BL,255UL,4UL,1UL},{0x67L,0x52L,0x6BL,0x6BL},{0x74L,0x74L,0xDCL,0x8FL},{255UL,0UL,0x52L,255UL},{255UL,0x41L,0x92L,0x52L}},{{0UL,0x41L,1UL,255UL},{0x41L,0UL,0UL,0x8FL},{1UL,0x74L,0x4DL,0x6BL},{0x19L,0x52L,0x74L,1UL},{0xCFL,255UL,0x6EL,0x41L},{0UL,255UL,1UL,1UL},{0xD9L,255UL,0xD9L,7UL},{0xAEL,0xD9L,0UL,0UL}},{{1UL,0xCFL,255UL,0xD9L},{4UL,0x8FL,255UL,0x08L},{1UL,255UL,0UL,1UL},{0xAEL,0x6BL,0xD9L,0UL},{0xD9L,0UL,1UL,0x6EL},{0UL,0xDCL,0x6EL,252UL},{0xCFL,1UL,0x74L,0UL},{0x19L,0x4DL,0x4DL,0x19L}},{{1UL,255UL,0UL,255UL},{0x41L,4UL,1UL,251UL},{0UL,0x19L,0x92L,251UL},{255UL,4UL,0x52L,255UL},{255UL,255UL,0xDCL,0x19L},{0x74L,0x4DL,0x6BL,0UL},{0x67L,1UL,4UL,252UL},{0x6BL,0xDCL,0x08L,0x6EL}},{{255UL,0UL,0x67L,0UL},{250UL,0x6BL,0UL,1UL},{251UL,255UL,252UL,0x08L},{0x08L,0x8FL,1UL,0xD9L},{0x08L,0xCFL,252UL,0UL},{251UL,0xD9L,0UL,7UL},{250UL,255UL,0x67L,1UL},{255UL,255UL,0x08L,0x41L}}};
static int8_t g_17 = 0x3AL;
static int8_t g_29 = 0x81L;
static int8_t * volatile g_28 = &g_29;/* VOLATILE GLOBAL g_28 */
static volatile int32_t g_51 = (-4L);/* VOLATILE GLOBAL g_51 */
static volatile int32_t g_52 = 0L;/* VOLATILE GLOBAL g_52 */
static volatile int32_t g_53 = 0x1153AA9BL;/* VOLATILE GLOBAL g_53 */
static int32_t g_54 = 0x54120977L;
static volatile int32_t g_57 = 0x2F33BC6CL;/* VOLATILE GLOBAL g_57 */
static int32_t g_58 = (-10L);
static volatile int32_t g_61 = 0x02D1F73EL;/* VOLATILE GLOBAL g_61 */
static int32_t g_62 = 0xB68169B2L;
static int16_t g_92 = 1L;
static int32_t g_97[4] = {0x0AFDD742L,0x0AFDD742L,0x0AFDD742L,0x0AFDD742L};
static volatile int8_t g_109 = (-1L);/* VOLATILE GLOBAL g_109 */
static int32_t *g_125 = (void*)0;
static int32_t ** const  volatile g_130 = &g_125;/* VOLATILE GLOBAL g_130 */
static int32_t ** volatile g_135 = &g_125;/* VOLATILE GLOBAL g_135 */
static volatile union U0 g_136 = {1L};/* VOLATILE GLOBAL g_136 */
static uint16_t g_151 = 0x2C95L;
static uint64_t g_165 = 18446744073709551615UL;
static uint16_t g_173 = 0xA349L;
static uint32_t g_174[5] = {0x1ADF2D24L,0x1ADF2D24L,0x1ADF2D24L,0x1ADF2D24L,0x1ADF2D24L};
static int64_t g_178 = 1L;
static volatile union U1 g_191 = {0xF0L};/* VOLATILE GLOBAL g_191 */
static union U0 g_194 = {0x76L};/* VOLATILE GLOBAL g_194 */
static const int8_t *g_206 = &g_29;
static const int8_t **g_205 = &g_206;
static int16_t * volatile g_212 = &g_92;/* VOLATILE GLOBAL g_212 */
static int16_t *g_213 = (void*)0;
static int16_t * volatile *g_211[8] = {&g_213,(void*)0,&g_213,(void*)0,&g_213,(void*)0,&g_213,(void*)0};
static int16_t * volatile **g_210 = &g_211[5];
static const uint16_t g_275[3] = {65526UL,65526UL,65526UL};
static const uint16_t g_277 = 0x1925L;
static const uint16_t *g_276 = &g_277;
static union U0 g_281 = {0xFEL};/* VOLATILE GLOBAL g_281 */
static int16_t g_284 = 0x13B8L;
static int64_t g_286 = 0x34BBA67F9AE2D6AALL;
static union U1 g_289 = {0x1AL};/* VOLATILE GLOBAL g_289 */
static union U1 *g_299[10][1][1] = {{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}},{{&g_289}}};
static union U1 ** volatile g_298[8] = {&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0]};
static uint64_t g_303 = 0xD6BA3BECF33F7443LL;
static volatile union U1 g_329 = {0xDDL};/* VOLATILE GLOBAL g_329 */
static int8_t g_393 = (-6L);
static volatile union U1 g_413 = {0UL};/* VOLATILE GLOBAL g_413 */
static int16_t * const * const **g_420 = (void*)0;
static int32_t ***g_437 = (void*)0;
static uint32_t g_459 = 0xEE05F0E4L;
static union U1 g_469[6][9] = {{{249UL},{255UL},{0x5EL},{0x47L},{0xF6L},{0x39L},{0UL},{0xB6L},{0UL}},{{0UL},{7UL},{255UL},{0x6FL},{0x0AL},{0xB6L},{0x0AL},{0x6FL},{255UL}},{{255UL},{255UL},{0x75L},{0UL},{0xA9L},{247UL},{0x0AL},{0x63L},{249UL}},{{0x47L},{253UL},{0x0CL},{0x5EL},{249UL},{0UL},{0UL},{249UL},{0x5EL}},{{0x75L},{247UL},{0x75L},{0x39L},{0xB6L},{253UL},{7UL},{249UL},{0xA9L}},{{247UL},{0x0CL},{255UL},{0xA9L},{7UL},{0x63L},{0x5EL},{0x63L},{7UL}}};
static union U0 g_472 = {0xDAL};/* VOLATILE GLOBAL g_472 */
static union U1 ** volatile g_475 = &g_299[6][0][0];/* VOLATILE GLOBAL g_475 */
static uint16_t g_491[4] = {0x7AB0L,0x7AB0L,0x7AB0L,0x7AB0L};
static int8_t *g_503 = &g_29;
static union U0 g_574 = {1L};/* VOLATILE GLOBAL g_574 */
static uint32_t g_585[8] = {9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL};
static const volatile union U0 g_589 = {-1L};/* VOLATILE GLOBAL g_589 */
static union U1 ** volatile g_752 = &g_299[5][0][0];/* VOLATILE GLOBAL g_752 */
static uint32_t g_786 = 0UL;
static uint16_t *g_790[8] = {&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151};
static uint16_t **g_789 = &g_790[5];
static uint16_t *** volatile g_788 = &g_789;/* VOLATILE GLOBAL g_788 */
static int16_t *g_805 = (void*)0;
static int16_t *g_806 = &g_92;
static int16_t *g_807 = &g_284;
static int16_t *g_808 = &g_284;
static int16_t *g_809 = &g_284;
static int16_t *g_810 = &g_284;
static int16_t *g_811 = &g_284;
static int16_t *g_812 = (void*)0;
static int16_t *g_813 = &g_92;
static int16_t *g_814 = (void*)0;
static int16_t *g_815 = &g_92;
static int16_t *g_816 = &g_92;
static int16_t *g_817 = &g_92;
static int16_t *g_818[10] = {&g_92,(void*)0,&g_92,&g_92,(void*)0,&g_92,&g_92,(void*)0,&g_92,&g_92};
static int16_t *g_819 = (void*)0;
static int16_t *g_820[3][6][8] = {{{&g_92,&g_92,&g_284,&g_284,&g_284,&g_92,&g_284,&g_284},{&g_284,&g_92,&g_92,(void*)0,&g_284,&g_92,(void*)0,(void*)0},{&g_92,&g_284,(void*)0,&g_284,(void*)0,(void*)0,(void*)0,&g_284},{&g_92,(void*)0,&g_284,&g_92,&g_284,&g_92,&g_92,(void*)0},{(void*)0,(void*)0,&g_284,&g_92,&g_92,&g_92,(void*)0,&g_92},{(void*)0,(void*)0,(void*)0,&g_92,(void*)0,(void*)0,&g_92,(void*)0}},{{&g_92,&g_92,&g_284,&g_92,&g_284,&g_284,&g_92,&g_92},{&g_284,&g_92,&g_92,(void*)0,(void*)0,(void*)0,&g_92,&g_92},{&g_92,&g_284,(void*)0,&g_92,&g_284,&g_92,&g_92,(void*)0},{&g_284,&g_92,&g_92,&g_92,&g_92,&g_92,&g_284,&g_92},{&g_92,&g_92,&g_284,&g_92,&g_284,&g_92,&g_284,&g_92},{&g_284,&g_284,&g_92,&g_92,&g_284,&g_92,&g_92,&g_92}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_92,(void*)0,&g_92},{&g_92,&g_92,&g_284,&g_92,&g_92,&g_284,&g_284,(void*)0},{&g_92,&g_284,&g_284,(void*)0,&g_284,(void*)0,(void*)0,&g_92},{&g_92,(void*)0,(void*)0,&g_92,(void*)0,&g_284,&g_92,(void*)0},{&g_284,&g_284,&g_92,&g_92,(void*)0,&g_92,&g_284,&g_92},{&g_92,&g_92,&g_284,(void*)0,&g_92,&g_92,&g_284,&g_284}}};
static int16_t *g_821 = &g_92;
static int16_t *g_822[6] = {&g_284,&g_284,&g_284,&g_284,&g_284,&g_284};
static int16_t *g_823[3] = {&g_284,&g_284,&g_284};
static int16_t *g_824 = &g_284;
static int16_t *g_825 = (void*)0;
static int16_t *g_826 = &g_92;
static int16_t *g_827 = &g_284;
static int16_t *g_828 = &g_284;
static int16_t *g_829 = &g_284;
static int16_t *g_830 = (void*)0;
static int16_t *g_831 = &g_92;
static int16_t *g_832 = &g_92;
static int16_t *g_833 = &g_92;
static int16_t *g_834 = &g_284;
static int16_t *g_835 = &g_92;
static int16_t *g_836[2] = {&g_284,&g_284};
static int16_t ** const g_804[3][8][4] = {{{&g_827,&g_833,&g_812,&g_829},{&g_810,(void*)0,&g_818[8],&g_815},{&g_808,&g_836[1],&g_807,&g_815},{&g_819,(void*)0,&g_809,&g_829},{&g_813,&g_833,&g_826,&g_825},{(void*)0,&g_819,&g_824,(void*)0},{&g_809,(void*)0,&g_836[1],&g_827},{&g_813,(void*)0,&g_831,&g_833}},{{&g_830,&g_832,&g_807,(void*)0},{&g_829,&g_810,&g_829,&g_821},{&g_810,(void*)0,&g_834,&g_805},{&g_805,&g_809,&g_819,(void*)0},{(void*)0,&g_830,&g_819,(void*)0},{&g_805,&g_833,&g_834,&g_808},{&g_810,&g_816,&g_829,&g_815},{&g_829,&g_815,&g_807,&g_836[1]}},{{&g_830,(void*)0,&g_831,&g_808},{&g_813,&g_821,&g_836[1],&g_825},{&g_809,&g_830,&g_824,&g_824},{(void*)0,(void*)0,&g_826,&g_805},{&g_813,&g_824,&g_809,&g_833},{&g_819,&g_810,&g_807,&g_809},{&g_808,&g_810,&g_818[8],&g_833},{&g_810,&g_824,&g_812,&g_805}}};
static int16_t ** const *g_803 = &g_804[0][6][1];
static int16_t ** const **g_802 = &g_803;
static int16_t ** const ***g_801 = &g_802;
static volatile union U1 g_847 = {0x5EL};/* VOLATILE GLOBAL g_847 */
static int32_t g_882 = 0xF1C2D842L;
static volatile uint8_t g_884 = 0x4DL;/* VOLATILE GLOBAL g_884 */
static int32_t ****g_895[3] = {&g_437,&g_437,&g_437};
static int16_t g_929 = 0x0122L;
static volatile union U1 g_939 = {0x1BL};/* VOLATILE GLOBAL g_939 */
static volatile union U1 g_1008 = {0x6CL};/* VOLATILE GLOBAL g_1008 */
static volatile union U0 g_1011 = {0L};/* VOLATILE GLOBAL g_1011 */
static const volatile union U1 g_1017 = {0x51L};/* VOLATILE GLOBAL g_1017 */
static volatile uint32_t *g_1019 = (void*)0;
static volatile uint32_t * volatile * volatile g_1018[1][3] = {{&g_1019,&g_1019,&g_1019}};
static int16_t g_1032 = 0L;
static int16_t g_1033[5][3][7] = {{{0L,0x1922L,0L,0L,0x1922L,0L,0L},{0xBE56L,0xBE56L,1L,0xBE56L,0xBE56L,1L,0xBE56L},{0x1922L,6L,6L,0L,6L,6L,0L}},{{1L,1L,1L,1L,1L,1L,1L},{0L,0L,0x1922L,0L,0L,0x1922L,0L},{1L,1L,1L,1L,1L,1L,1L}},{{6L,0L,6L,6L,0L,6L,6L},{1L,1L,0xBE56L,1L,1L,0xBE56L,1L},{0L,6L,6L,0L,6L,6L,0L}},{{1L,1L,1L,1L,1L,1L,1L},{0L,0L,0x1922L,0L,0L,0x1922L,0L},{1L,1L,1L,1L,1L,1L,1L}},{{6L,0L,6L,6L,0L,6L,6L},{1L,1L,0xBE56L,1L,1L,0xBE56L,1L},{0L,6L,6L,0L,6L,6L,0L}}};
static volatile uint64_t g_1067[5] = {0x24770CE0866C003BLL,0x24770CE0866C003BLL,0x24770CE0866C003BLL,0x24770CE0866C003BLL,0x24770CE0866C003BLL};
static int16_t **g_1090 = &g_833;
static int16_t ***g_1089 = &g_1090;
static int16_t ****g_1088 = &g_1089;
static int16_t *****g_1087 = &g_1088;
static int16_t ******g_1086 = &g_1087;
static union U0 g_1091[1] = {{0L}};
static union U0 g_1097 = {0L};/* VOLATILE GLOBAL g_1097 */
static union U0 *g_1099 = (void*)0;
static union U0 ** volatile g_1098 = &g_1099;/* VOLATILE GLOBAL g_1098 */
static int8_t g_1114 = 3L;
static int8_t *g_1113 = &g_1114;
static union U1 g_1122 = {255UL};/* VOLATILE GLOBAL g_1122 */
static uint64_t g_1145 = 0x0BDD0914C32DD2BBLL;
static union U0 g_1147 = {-1L};/* VOLATILE GLOBAL g_1147 */
static volatile uint32_t g_1202 = 8UL;/* VOLATILE GLOBAL g_1202 */
static int16_t *** const g_1211 = (void*)0;
static int16_t *** const *g_1210 = &g_1211;
static int16_t *** const **g_1209 = &g_1210;
static int32_t g_1271 = 0x078C0D4EL;
static uint16_t g_1274 = 65535UL;
static int32_t * const  volatile g_1302 = &g_54;/* VOLATILE GLOBAL g_1302 */
static volatile uint16_t g_1318 = 0x8A84L;/* VOLATILE GLOBAL g_1318 */
static int32_t g_1335 = 0x6771CA7FL;
static union U0 ** volatile g_1426 = &g_1099;/* VOLATILE GLOBAL g_1426 */
static volatile uint8_t g_1448 = 1UL;/* VOLATILE GLOBAL g_1448 */
static int32_t ** volatile g_1473[4][6][9] = {{{&g_125,&g_125,&g_125,&g_125,(void*)0,(void*)0,(void*)0,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125},{&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125,(void*)0,&g_125,(void*)0}},{{&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125,(void*)0,(void*)0,&g_125},{&g_125,(void*)0,&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,(void*)0}},{{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,(void*)0,&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0,&g_125}},{{(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0,(void*)0,&g_125,&g_125},{&g_125,(void*)0,&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125},{(void*)0,(void*)0,(void*)0,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125}}};
static int32_t ** volatile g_1474 = &g_125;/* VOLATILE GLOBAL g_1474 */
static int32_t g_1576 = 8L;
static union U0 g_1616 = {0xD4L};/* VOLATILE GLOBAL g_1616 */
static union U1 ** volatile g_1630 = &g_299[5][0][0];/* VOLATILE GLOBAL g_1630 */
static union U1 ** volatile g_1660 = &g_299[0][0][0];/* VOLATILE GLOBAL g_1660 */
static volatile union U0 g_1705 = {0x8FL};/* VOLATILE GLOBAL g_1705 */
static union U0 g_1734[6] = {{-2L},{-8L},{-2L},{-2L},{-8L},{-2L}};
static union U0 g_1735[7][9][1] = {{{{1L}},{{4L}},{{1L}},{{0xE9L}},{{9L}},{{7L}},{{1L}},{{0xBEL}},{{0xF3L}}},{{{0xBEL}},{{1L}},{{7L}},{{9L}},{{0xE9L}},{{1L}},{{4L}},{{1L}},{{0xE9L}}},{{{9L}},{{7L}},{{1L}},{{0xBEL}},{{0xF3L}},{{0xBEL}},{{1L}},{{7L}},{{9L}}},{{{0xE9L}},{{1L}},{{4L}},{{1L}},{{0xE9L}},{{9L}},{{7L}},{{1L}},{{0xBEL}}},{{{0xF3L}},{{0xBEL}},{{1L}},{{7L}},{{9L}},{{0xE9L}},{{1L}},{{4L}},{{1L}}},{{{0xE9L}},{{9L}},{{7L}},{{1L}},{{0xBEL}},{{0xF3L}},{{0xBEL}},{{1L}},{{7L}}},{{{9L}},{{0xE9L}},{{1L}},{{4L}},{{1L}},{{0xE9L}},{{9L}},{{7L}},{{1L}}}};


/* --- FORWARD DECLARATIONS --- */
static union U0  func_1(void);
static int16_t  func_7(uint64_t  p_8, int32_t  p_9);
static int32_t  func_12(uint8_t  p_13);
static uint8_t  func_22(uint32_t  p_23, uint8_t  p_24, uint8_t  p_25, int8_t  p_26, const int8_t * p_27);
static uint8_t  func_31(int16_t  p_32, int8_t * p_33, int8_t * p_34);
static int32_t  func_36(int8_t * p_37, int32_t  p_38);
static union U0  func_39(uint64_t  p_40, uint8_t  p_41);
static int32_t  func_47(const uint16_t  p_48);
static int32_t * func_63(int16_t  p_64, uint8_t  p_65, int8_t * p_66, const uint64_t  p_67, int8_t  p_68);
static const int8_t  func_69(int8_t  p_70, uint32_t  p_71, uint32_t  p_72);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_491 g_503 g_1097.f0 g_11 g_1474 g_806 g_92 g_1033 g_1088 g_1089 g_1090 g_833 g_1145 g_1113 g_1114 g_929 g_1274 g_303 g_882 g_284 g_151 g_1335 g_125 g_54 g_1302 g_1086 g_1087 g_97 g_472.f3 g_836 g_276 g_277 g_135 g_174 g_475 g_299 g_1122 g_289 g_585 g_1576 g_109 g_817 g_205 g_206 g_29 g_62 g_834 g_393 g_1616 g_1630 g_811 g_1660 g_1147.f3 g_130 g_17 g_1271 g_1705 g_808 g_788 g_789 g_790 g_832 g_1202 g_459 g_589.f0 g_813 g_1097.f1 g_1734 g_1735
 * writes: g_2 g_29 g_125 g_1114 g_1274 g_299 g_165 g_178 g_786 g_1145 g_54 g_472.f3 g_1576 g_92 g_585 g_97 g_194.f3 g_1147.f3 g_11 g_1097.f3 g_491
 */
static union U0  func_1(void)
{ /* block id: 0 */
    int32_t ****l_1482 = &g_437;
    const uint16_t l_1511 = 0x01EBL;
    uint8_t *l_1514 = &g_11[3][0][1];
    int32_t l_1521 = 0x8F457C4CL;
    int32_t l_1534 = 0xE628E737L;
    int32_t l_1535 = 0x6B784430L;
    int32_t l_1537 = 0xC01ED533L;
    int32_t l_1538 = (-1L);
    int32_t *l_1558 = &l_1537;
    uint32_t l_1613[8] = {0x28A2786DL,0x28A2786DL,1UL,1UL,0x28A2786DL,1UL,1UL,0x28A2786DL};
    uint16_t l_1669[8];
    uint8_t l_1694 = 253UL;
    uint64_t *l_1702 = &g_165;
    int64_t l_1716 = 0x99E243E04982A4EFLL;
    int i;
    for (i = 0; i < 8; i++)
        l_1669[i] = 0x16FDL;
    for (g_2 = (-10); (g_2 > 5); g_2 = safe_add_func_int8_t_s_s(g_2, 7))
    { /* block id: 3 */
        int16_t l_10 = 0L;
        int16_t l_1481 = 0x86A3L;
        union U1 *l_1491 = &g_1122;
        int16_t **** const * const l_1516 = (void*)0;
        int32_t l_1536 = 1L;
        uint64_t l_1565 = 3UL;
        int32_t l_1666 = (-1L);
        int32_t l_1668 = 0x70E092A0L;
        if ((safe_mul_func_int8_t_s_s((func_7(g_2, l_10) <= (((*g_1113) = (0xB59C4178L & (g_1033[2][2][5] || ((l_1481 || ((((****g_1088) , l_1482) == &g_437) && 0x32L)) , g_1145)))) || (*g_1113))), g_929)))
        { /* block id: 592 */
            uint16_t *l_1487 = &g_1274;
            int32_t l_1490 = 0x829568E0L;
            union U1 **l_1492 = &g_299[5][0][0];
            uint32_t *l_1512 = (void*)0;
            uint32_t *l_1513[6][10][4] = {{{&g_459,(void*)0,&g_585[4],&g_459},{&g_585[6],&g_585[4],(void*)0,(void*)0},{&g_786,&g_786,&g_585[0],&g_174[0]},{&g_585[6],(void*)0,&g_459,&g_174[2]},{&g_174[2],(void*)0,&g_786,&g_459},{&g_585[4],(void*)0,&g_174[2],&g_174[2]},{(void*)0,(void*)0,&g_174[2],&g_174[0]},{&g_174[2],&g_786,&g_174[2],(void*)0},{&g_459,&g_585[4],&g_174[2],&g_459},{&g_585[6],(void*)0,&g_585[4],&g_174[2]}},{{&g_459,&g_174[1],&g_174[2],&g_174[2]},{&g_585[4],&g_174[0],&g_786,&g_585[6]},{&g_174[3],&g_459,&g_459,&g_459},{&g_174[2],&g_585[6],&g_174[1],&g_585[6]},{&g_174[2],&g_174[2],&g_585[4],&g_174[2]},{&g_174[1],&g_174[2],(void*)0,&g_585[0]},{&g_585[4],&g_459,&g_459,&g_585[1]},{&g_585[4],&g_174[3],(void*)0,&g_174[1]},{&g_174[1],&g_585[1],&g_585[4],&g_174[2]},{&g_174[2],&g_585[4],&g_174[1],&g_585[4]}},{{&g_174[2],&g_174[0],&g_459,&g_585[4]},{&g_174[3],&g_174[2],&g_786,(void*)0},{&g_585[4],(void*)0,&g_174[2],&g_174[1]},{&g_459,&g_786,&g_585[4],&g_459},{&g_585[6],&g_174[3],&g_174[2],&g_174[3]},{&g_459,&g_174[2],&g_174[2],&g_459},{&g_174[2],&g_174[2],&g_174[2],&g_174[0]},{(void*)0,&g_585[6],&g_174[2],&g_459},{&g_585[4],&g_786,&g_786,&g_459},{&g_174[2],&g_585[6],&g_459,&g_174[0]}},{{&g_585[6],&g_174[2],&g_585[0],&g_459},{&g_786,&g_174[2],(void*)0,&g_174[3]},{&g_585[6],&g_174[3],&g_585[4],&g_459},{&g_459,&g_786,&g_585[4],&g_174[1]},{&g_459,(void*)0,&g_174[0],(void*)0},{&g_174[2],&g_174[2],&g_174[0],&g_585[4]},{&g_786,&g_174[0],&g_174[2],&g_585[4]},{&g_585[4],&g_585[4],&g_585[4],&g_174[2]},{&g_459,&g_585[1],(void*)0,&g_174[1]},{(void*)0,&g_174[3],&g_585[4],&g_585[1]}},{{&g_174[1],&g_459,&g_585[4],&g_585[0]},{(void*)0,&g_174[2],(void*)0,&g_174[2]},{&g_459,&g_174[2],&g_585[4],&g_585[6]},{&g_585[4],&g_585[6],&g_174[2],&g_459},{&g_786,&g_459,&g_174[0],&g_585[6]},{&g_174[2],&g_174[0],&g_174[0],&g_174[0]},{&g_459,(void*)0,(void*)0,&g_585[4]},{&g_585[6],&g_786,&g_174[2],&g_585[4]},{&g_174[3],&g_174[2],&g_174[3],&g_174[3]},{&g_459,&g_459,&g_174[1],&g_459}},{{&g_585[6],&g_585[4],&g_786,&g_459},{&g_585[4],&g_174[3],&g_585[4],&g_786},{&g_174[2],&g_174[3],&g_174[0],&g_459},{&g_174[3],&g_585[4],&g_585[4],&g_459},{&g_174[0],&g_459,&g_585[4],&g_174[3]},{(void*)0,&g_174[2],&g_174[0],&g_585[4]},{&g_459,&g_786,&g_174[2],&g_585[4]},{&g_585[1],(void*)0,&g_585[4],&g_174[0]},{&g_459,&g_459,&g_459,&g_459},{&g_174[1],(void*)0,&g_585[1],&g_459}}};
            int16_t * const ****l_1515[5];
            uint64_t *l_1517 = &g_1145;
            const int8_t l_1518 = 0xF0L;
            int32_t *l_1519 = &g_97[0];
            int32_t *l_1520 = &g_58;
            int32_t *l_1522 = &g_58;
            int32_t *l_1523 = &g_54;
            int32_t *l_1524 = &g_58;
            int32_t *l_1525 = &l_1490;
            int32_t *l_1526 = (void*)0;
            int32_t *l_1527 = &l_1490;
            int32_t *l_1528 = &l_1490;
            int32_t *l_1529 = &g_58;
            int32_t *l_1530 = &g_54;
            int32_t *l_1531 = (void*)0;
            int32_t *l_1532 = &l_1490;
            int32_t *l_1533[1];
            uint8_t l_1539 = 1UL;
            const union U1 *l_1544 = &g_1122;
            const union U1 **l_1543 = &l_1544;
            const union U1 ***l_1542 = &l_1543;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_1515[i] = (void*)0;
            for (i = 0; i < 1; i++)
                l_1533[i] = &l_1490;
            (*g_125) &= (safe_mul_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(((++(*l_1487)) < (l_1490 < (l_1491 != ((*l_1492) = l_1491)))), (safe_rshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((g_165 = g_303), (((safe_mod_func_int64_t_s_s((g_178 = g_1097.f0), (safe_sub_func_uint16_t_u_u(((g_882 >= (((safe_add_func_uint8_t_u_u((((((!((*l_1517) = ((((safe_sub_func_int64_t_s_s(g_284, (((((g_786 = (~((safe_mul_func_int16_t_s_s(l_1511, (0xA373L || l_1481))) == l_1490))) , 1UL) ^ 65535UL) , l_1514) != &g_11[4][7][3]))) , l_1515[1]) == l_1516) == g_151))) != l_1481) , l_10) & 8UL) ^ g_1033[4][2][3]), l_1490)) < l_10) != g_92)) ^ (*g_1113)), l_1490)))) , g_1335) , l_1518))), l_1481)), 5)))), 0UL));
            l_1539++;
            (*g_1302) = ((void*)0 != l_1542);
        }
        else
        { /* block id: 602 */
            int64_t l_1554[8];
            int32_t l_1606 = 4L;
            int64_t l_1610[2];
            int32_t l_1611 = 1L;
            int32_t l_1612[6] = {7L,7L,7L,7L,7L,7L};
            uint32_t *l_1626[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t **l_1625[5];
            int16_t l_1658 = 4L;
            uint16_t *l_1712 = &g_491[0];
            int32_t **l_1732 = &g_125;
            int i;
            for (i = 0; i < 8; i++)
                l_1554[i] = 5L;
            for (i = 0; i < 2; i++)
                l_1610[i] = 0xE66370AB03B47C17LL;
            for (i = 0; i < 5; i++)
                l_1625[i] = &l_1626[3];
            if ((**g_1474))
            { /* block id: 603 */
                int8_t *l_1545 = &g_393;
                int32_t l_1547 = 0xF2F35CD4L;
                int32_t * const *l_1553 = &g_125;
                int32_t *l_1557 = &g_97[3];
                (*g_1474) = func_63((******g_1086), g_1097.f0, l_1545, (safe_unary_minus_func_uint8_t_u((l_1547 >= (safe_add_func_uint8_t_u_u(g_1033[4][0][6], l_1536))))), (((((safe_sub_func_uint32_t_u_u((+l_1547), ((void*)0 == l_1553))) || g_97[3]) < g_54) | l_1554[6]) != 0xB465164EL));
                if ((**l_1553))
                    break;
                for (g_472.f3 = 0; (g_472.f3 <= 1); g_472.f3 += 1)
                { /* block id: 608 */
                    int32_t l_1555[6] = {1L,1L,1L,1L,1L,1L};
                    int64_t *l_1556 = &g_178;
                    int i;
                    l_1558 = ((1UL != ((*l_1556) = ((**l_1553) , (((void*)0 == g_836[g_472.f3]) < l_1555[1])))) , l_1557);
                    if (((safe_sub_func_uint16_t_u_u((&g_1019 == &g_1019), (*g_276))) , (safe_div_func_int64_t_s_s((safe_mod_func_uint32_t_u_u(l_1554[6], (l_1565 || (~((l_1555[2] , ((((**g_135) ^ g_174[1]) , (safe_add_func_int64_t_s_s((!(safe_sub_func_int64_t_s_s(((((safe_mul_func_int8_t_s_s((((safe_mul_func_uint16_t_u_u((((**g_475) , (-1L)) != 0xB057L), l_1554[3])) , (**l_1553)) && l_1554[0]), g_585[4])) , (*l_1558)) && 0x7C5AAF03L) , l_1481), 0x2D9C9C53E5847511LL))), l_1555[1]))) != 18446744073709551615UL)) >= (*g_1113)))))), g_1576))))
                    { /* block id: 611 */
                        uint32_t *l_1601 = &g_585[4];
                        uint64_t *l_1602 = &l_1565;
                        int32_t l_1603 = (-9L);
                        (*l_1558) = (safe_mod_func_int16_t_s_s((safe_mul_func_int16_t_s_s(l_1555[1], (((safe_div_func_uint8_t_u_u(((g_151 == g_109) > (safe_sub_func_uint64_t_u_u((safe_add_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(((g_1576 = (**l_1553)) , ((*l_1602) = (((((((*l_1601) = ((l_1554[2] || ((safe_sub_func_uint16_t_u_u(((void*)0 != g_299[1][0][0]), (safe_unary_minus_func_uint16_t_u((safe_mul_func_uint8_t_u_u(l_1555[1], ((safe_add_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((+(safe_rshift_func_int16_t_s_s(((*g_817) = (**l_1553)), 8))) || (**g_205)), (*g_503))), l_1554[6])) , 1L))))))) >= 0xCB1641D4ED5D281ALL)) < (-4L))) || g_62) == g_1335) || 6UL) | (*g_834)) , 0x0E3C66A30A8CD4D4LL))), g_174[1])), l_1603)), 7L))), 0x03L)) || g_393) | l_1554[6]))), l_1603));
                    }
                    else
                    { /* block id: 617 */
                        int32_t *l_1604 = &g_882;
                        int32_t *l_1605 = &g_58;
                        int32_t *l_1607 = &g_54;
                        int32_t *l_1608 = (void*)0;
                        int32_t *l_1609[3][2] = {{&g_882,&l_1538},{&l_1538,&g_882},{&l_1538,&l_1538}};
                        int i, j;
                        ++l_1613[2];
                    }
                    return g_1616;
                }
            }
            else
            { /* block id: 622 */
                union U1 *l_1629[9][6][4] = {{{(void*)0,&g_289,(void*)0,&g_289},{&g_1122,&g_1122,(void*)0,&g_469[4][1]},{(void*)0,&g_469[0][0],&g_289,&g_1122},{&g_469[1][1],&g_289,&g_289,(void*)0},{(void*)0,&g_1122,(void*)0,&g_289},{&g_1122,&g_289,(void*)0,&g_289}},{{(void*)0,&g_289,&g_1122,&g_469[0][0]},{&g_289,&g_1122,(void*)0,&g_469[0][2]},{&g_1122,&g_469[1][1],&g_469[1][1],&g_1122},{&g_289,&g_289,(void*)0,&g_469[0][0]},{&g_289,&g_1122,(void*)0,&g_289},{&g_469[0][2],&g_1122,(void*)0,&g_289}},{{&g_1122,&g_1122,&g_289,&g_469[0][0]},{(void*)0,&g_289,&g_1122,&g_1122},{&g_289,&g_469[1][1],&g_289,&g_469[0][2]},{(void*)0,&g_1122,&g_289,&g_469[0][0]},{&g_1122,&g_289,&g_469[5][6],&g_289},{&g_469[0][2],&g_289,&g_1122,&g_289}},{{&g_289,&g_1122,(void*)0,(void*)0},{&g_1122,&g_289,&g_469[5][1],&g_1122},{&g_1122,&g_469[0][0],(void*)0,&g_469[4][1]},{&g_289,&g_1122,&g_1122,&g_289},{&g_469[0][2],&g_289,&g_469[5][6],&g_289},{&g_1122,&g_289,&g_289,&g_469[4][1]}},{{(void*)0,&g_289,&g_289,&g_289},{&g_289,&g_289,&g_1122,&g_469[0][2]},{(void*)0,(void*)0,&g_289,&g_289},{&g_1122,&g_289,(void*)0,&g_289},{&g_469[0][0],&g_1122,(void*)0,&g_289},{&g_1122,(void*)0,&g_469[5][6],&g_469[0][0]}},{{&g_469[5][1],&g_289,(void*)0,&g_469[5][1]},{&g_469[1][1],&g_289,&g_469[0][2],(void*)0},{&g_1122,&g_469[5][1],(void*)0,&g_289},{&g_469[3][8],&g_469[0][0],&g_469[3][8],(void*)0},{(void*)0,&g_469[1][1],&g_289,(void*)0},{(void*)0,&g_1122,&g_469[5][1],&g_469[1][1]}},{{(void*)0,&g_289,&g_469[5][1],&g_469[3][8]},{(void*)0,&g_1122,&g_289,&g_289},{(void*)0,(void*)0,&g_469[3][8],&g_1122},{&g_469[3][8],&g_1122,(void*)0,&g_1122},{&g_1122,&g_1122,&g_469[0][2],&g_469[0][0]},{&g_469[1][1],(void*)0,(void*)0,&g_469[1][1]}},{{&g_469[5][1],&g_289,&g_469[5][6],&g_289},{&g_1122,&g_469[1][1],(void*)0,&g_289},{&g_469[0][0],&g_1122,&g_469[3][8],&g_289},{(void*)0,&g_469[1][1],(void*)0,&g_289},{(void*)0,&g_289,&g_289,&g_469[1][1]},{&g_289,(void*)0,&g_469[5][1],&g_469[0][0]}},{{&g_469[5][6],&g_1122,(void*)0,&g_1122},{(void*)0,&g_1122,&g_289,&g_1122},{&g_469[0][0],(void*)0,(void*)0,&g_289},{(void*)0,&g_1122,&g_469[5][6],&g_469[3][8]},{&g_469[1][1],&g_289,&g_289,&g_469[1][1]},{&g_469[1][1],&g_1122,&g_469[5][6],(void*)0}}};
                const uint64_t *l_1643[6][4][8] = {{{&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565},{&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303},{&l_1565,&l_1565,&g_1145,&l_1565,&l_1565,&g_1145,&l_1565,&l_1565},{&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565}},{{&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303},{&l_1565,&l_1565,&g_1145,&l_1565,&l_1565,&g_1145,&l_1565,&l_1565},{&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565},{&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303}},{{&l_1565,&l_1565,&g_1145,&l_1565,&l_1565,&g_1145,&l_1565,&l_1565},{&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565},{&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_1145},{&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303}},{{&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303},{&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145},{&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303},{&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303}},{{&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145},{&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303},{&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303},{&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145}},{{&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303},{&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303},{&g_303,&g_1145,&g_1145,&g_303,&g_1145,&g_1145,&g_303,&g_1145},{&g_303,&g_303,&l_1565,&g_303,&g_303,&l_1565,&g_303,&g_303}}};
                int32_t l_1667 = (-1L);
                uint32_t l_1695 = 0x26F8FAC7L;
                uint32_t *l_1727 = &g_459;
                int32_t **l_1731[2][8][10] = {{{(void*)0,&g_125,&l_1558,&l_1558,&g_125,&l_1558,&g_125,&g_125,&g_125,&l_1558},{(void*)0,&l_1558,&l_1558,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,(void*)0,(void*)0,&g_125,&l_1558,&g_125,&g_125,&g_125,&l_1558,&g_125},{(void*)0,&g_125,&l_1558,&l_1558,&g_125,&g_125,(void*)0,&g_125,&l_1558,(void*)0},{&g_125,&g_125,&l_1558,&g_125,&g_125,&l_1558,&g_125,&g_125,&g_125,&g_125},{&g_125,&l_1558,(void*)0,&g_125,(void*)0,&l_1558,&g_125,&g_125,&g_125,&g_125},{&l_1558,&g_125,&g_125,&l_1558,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&l_1558,(void*)0}},{{&g_125,&l_1558,&l_1558,&g_125,&g_125,&g_125,&g_125,&g_125,&l_1558,&g_125},{&l_1558,&l_1558,&l_1558,&g_125,&l_1558,&l_1558,&g_125,&g_125,&l_1558,&l_1558},{&g_125,&g_125,&g_125,&l_1558,&l_1558,&g_125,&l_1558,&l_1558,&g_125,&g_125},{&l_1558,&g_125,&l_1558,&g_125,&g_125,&g_125,&l_1558,&g_125,&g_125,&g_125},{(void*)0,&g_125,(void*)0,&g_125,&g_125,&l_1558,&l_1558,&l_1558,&l_1558,&g_125},{(void*)0,&l_1558,&g_125,(void*)0,&g_125,&g_125,&l_1558,&l_1558,&g_125,(void*)0},{&g_125,&g_125,(void*)0,&g_125,&l_1558,&l_1558,&l_1558,&g_125,&g_125,&l_1558},{&l_1558,&l_1558,&l_1558,&l_1558,&l_1558,&l_1558,&g_125,&l_1558,&l_1558,&g_125}}};
                int32_t ***l_1733 = &l_1732;
                int i, j, k;
                for (g_194.f3 = 0; (g_194.f3 <= 1); g_194.f3 += 1)
                { /* block id: 625 */
                    uint32_t l_1621 = 6UL;
                    int16_t l_1624[2][10][9] = {{{0xEEABL,(-1L),0L,8L,0xF4E0L,0x3CC3L,1L,0xA3CCL,0xC0B8L},{0x67BFL,2L,(-1L),0x96F5L,(-3L),(-1L),(-1L),(-3L),0x96F5L},{0x144CL,(-7L),0x144CL,0x0BF4L,0xF4E0L,0xA3CCL,0L,0x0969L,0x71C6L},{0x82C4L,0x2974L,(-3L),(-4L),0xC893L,(-1L),0xC893L,(-4L),(-3L)},{0x71C6L,0x3CC3L,(-1L),0x0BF4L,0xD445L,(-1L),0xC0B8L,0x8C50L,0L},{0L,0L,(-1L),0x96F5L,0x2A67L,0x2A67L,0x96F5L,(-1L),0L},{0xC132L,0L,(-1L),8L,0x333BL,0x0BF4L,0x71C6L,(-1L),0xF4E0L},{(-4L),0L,(-3L),0L,0x5FF2L,0L,(-3L),0L,(-4L)},{0x333BL,0L,0x144CL,4L,0x71C6L,0x3CD2L,0L,(-7L),(-10L)},{0x821FL,0L,(-1L),(-1L),(-1L),(-1L),0L,0x821FL,0x67BFL}},{{0x333BL,0x3CC3L,0L,0x9E70L,(-1L),2L,0xF4E0L,4L,0L},{(-4L),0x2974L,0x96F5L,0x821FL,0x96F5L,0x2974L,(-4L),0x2A67L,0x67BFL},{0xC132L,(-7L),1L,0L,0L,0x0969L,(-10L),0x3CC3L,0L},{0x5FF2L,0xC893L,0x2974L,0x2974L,0xC893L,0x5FF2L,0x2A67L,(-1L),0x821FL},{1L,(-1L),0x144CL,0x9E70L,(-1L),(-7L),0x71C6L,0x3CC3L,(-1L)},{0x2974L,0x96F5L,0x821FL,0x96F5L,0x2974L,(-4L),0x2A67L,0x67BFL,0L},{0xF4E0L,0x3CC3L,1L,0xA3CCL,0xC0B8L,0x3CD2L,0L,0x3CD2L,0xC0B8L},{0x2A67L,(-3L),(-3L),0x2A67L,7L,(-4L),0x821FL,0x5FF2L,(-1L)},{0xC132L,(-1L),0x333BL,0x8C50L,(-1L),(-7L),(-1L),0x0969L,1L},{(-1L),0L,(-1L),2L,7L,0x5FF2L,0L,0x82C4L,(-4L)}}};
                    int i, j, k;
                    for (g_54 = 0; (g_54 <= 1); g_54 += 1)
                    { /* block id: 628 */
                        int64_t l_1617 = 1L;
                        int32_t *l_1618 = (void*)0;
                        int32_t *l_1619 = &g_97[3];
                        int32_t *l_1620 = (void*)0;
                        ++l_1621;
                        if (l_1624[0][7][4])
                            continue;
                        (*l_1558) = (*g_1302);
                        if (l_1536)
                            break;
                    }
                    (*l_1558) = (&g_1019 == l_1625[1]);
                }
                if (((*l_1558) = (-7L)))
                { /* block id: 637 */
                    uint64_t *l_1644 = (void*)0;
                    int32_t l_1665 = 0L;
                    int32_t ***l_1693 = (void*)0;
                    for (l_1565 = (-29); (l_1565 < 2); l_1565 = safe_add_func_int64_t_s_s(l_1565, 5))
                    { /* block id: 640 */
                        uint8_t l_1639 = 1UL;
                        union U0 ***l_1640 = (void*)0;
                        union U0 **l_1642[1][4][7] = {{{(void*)0,&g_1099,&g_1099,(void*)0,&g_1099,(void*)0,&g_1099},{&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099},{&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099},{&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099,&g_1099}}};
                        union U0 ***l_1641 = &l_1642[0][0][5];
                        uint64_t *l_1659 = &g_165;
                        int i, j, k;
                        (*g_1630) = l_1629[2][5][2];
                        (**g_1474) = l_1481;
                        (*g_125) = (safe_mul_func_uint16_t_u_u(((safe_add_func_int8_t_s_s(1L, (((*g_1113) = (safe_mul_func_uint8_t_u_u(((safe_add_func_uint64_t_u_u(((l_1639 != (((*l_1641) = &g_1099) == &g_1099)) <= (l_1643[2][1][7] != l_1644)), ((*l_1659) = (safe_lshift_func_int8_t_s_u(((**g_135) != (safe_div_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((safe_add_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(((safe_div_func_int8_t_s_s(((*g_811) | (safe_div_func_uint32_t_u_u((0xE1B46230L & 4294967293UL), 0x7B74A87BL))), (*g_1113))) , 8L))), 3L)), 10)), 0x7311929C10417D9ELL))), l_1658))))) && g_54), 1L))) && l_10))) == (**g_205)), (*g_276)));
                        (*g_1660) = l_1629[2][5][2];
                    }
                    for (g_1147.f3 = (-10); (g_1147.f3 < 55); g_1147.f3 = safe_add_func_uint16_t_u_u(g_1147.f3, 6))
                    { /* block id: 651 */
                        int32_t *l_1663 = (void*)0;
                        int32_t *l_1664[1][4];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 4; j++)
                                l_1664[i][j] = &g_97[2];
                        }
                        --l_1669[3];
                        (*g_125) = ((safe_add_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_u((+((*l_1514) = ((((safe_mod_func_int8_t_s_s((6UL < ((**g_130) , 0xED6838D7CB638C46LL)), (safe_mul_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(l_1554[1], (((~((safe_mul_func_uint8_t_u_u(g_17, g_1271)) >= (((safe_add_func_uint32_t_u_u((safe_mul_func_int8_t_s_s((~(l_1666 < ((g_2 == (++g_1145)) && ((l_1606 = (*****g_1087)) && 0x4761L)))), (*g_206))), l_1554[6])) == g_92) > l_1667))) , l_1693) != (void*)0))), 1L)))) <= l_1694) , 0x8F1BB71FL) && l_1667))), l_1695)) ^ g_303), (*g_206))) > 0x6BC5152DL);
                        if (l_1554[3])
                            break;
                    }
                }
                else
                { /* block id: 659 */
                    uint8_t l_1713 = 1UL;
                    int32_t l_1714 = 0L;
                    for (g_1097.f3 = 0; (g_1097.f3 >= 60); g_1097.f3++)
                    { /* block id: 662 */
                        int64_t l_1698 = 6L;
                        int32_t **l_1699 = &g_125;
                        uint64_t *l_1715[6][4] = {{&l_1565,(void*)0,&g_1145,&l_1565},{&g_1145,&l_1565,(void*)0,(void*)0},{&g_1145,&g_1145,&g_1145,&g_1145},{&g_1145,(void*)0,(void*)0,&g_1145},{&g_1145,&g_1145,&g_1145,(void*)0},{&l_1565,&g_1145,&g_1145,&g_1145}};
                        int i, j;
                        if (l_1698)
                            break;
                        (*l_1699) = &l_1606;
                        (*l_1558) = (((((safe_add_func_int32_t_s_s(((((l_1702 != (((*g_276) , (safe_lshift_func_uint8_t_u_s((((g_1705 , (((safe_add_func_uint8_t_u_u(((*l_1514) |= (safe_rshift_func_int16_t_s_s((*g_808), ((*g_832) = (((safe_mod_func_uint16_t_u_u((l_1712 != (**g_788)), (l_1611 = l_1695))) <= ((((((**l_1699) &= 9L) && ((((0x8C339B3F267BFCC8LL == l_1536) <= (*l_1558)) | l_1713) <= 0UL)) != (-1L)) && 0L) | l_1714)) & (-1L)))))), 0xF8L)) , (void*)0) != &g_178)) != l_1667) , l_1714), (*g_206)))) , l_1715[0][2])) , l_1714) | l_1536) , l_1666), 0x4D568D64L)) , l_1716) , g_1202) > g_459) && l_1610[0]);
                        (*l_1558) ^= ((safe_rshift_func_int8_t_s_u((safe_add_func_int16_t_s_s((l_1713 > ((safe_sub_func_uint64_t_u_u((safe_div_func_int32_t_s_s((l_1695 >= (-3L)), l_1668)), g_589.f0)) , ((-5L) == ((*l_1712) = (l_1727 != (void*)0))))), ((((safe_add_func_int16_t_s_s((*g_813), l_1713)) , g_1097.f1) && g_1097.f1) < 0UL))), g_11[0][6][1])) | l_1565);
                    }
                }
                (*l_1558) = (safe_unary_minus_func_int16_t_s(((l_1611 , l_1731[1][4][6]) == ((*l_1733) = l_1732))));
            }
            return g_1734[4];
        }
    }
    return g_1735[1][1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_491 g_503 g_1097.f0 g_11 g_1474 g_806 g_92
 * writes: g_29 g_125
 */
static int16_t  func_7(uint64_t  p_8, int32_t  p_9)
{ /* block id: 4 */
    const int8_t *l_30 = (void*)0;
    int32_t l_1148 = 0L;
    int32_t l_1340 = 0x81D46CA2L;
    int32_t l_1341 = 5L;
    uint16_t *l_1351 = &g_151;
    int16_t **** const * const * const *l_1360 = (void*)0;
    int32_t l_1363 = 0xFA0C6C12L;
    int32_t l_1410 = 0xCC9CA735L;
    uint8_t l_1424 = 247UL;
    const uint32_t *l_1441 = &g_174[2];
    union U1 **l_1471 = &g_299[5][0][0];
    int8_t *l_1472 = &g_17;
    int32_t *l_1475 = &l_1410;
    int32_t *l_1476[3][2] = {{(void*)0,&g_882},{(void*)0,(void*)0},{&g_882,(void*)0}};
    uint8_t l_1477 = 0xF7L;
    int i, j;
    for (p_9 = 0; (p_9 <= 3); p_9 += 1)
    { /* block id: 7 */
        int8_t *l_16 = &g_17;
        const int32_t l_1146 = 0x2552BDFEL;
        int32_t *l_1339[2];
        int16_t *****l_1350 = &g_1088;
        uint8_t *l_1361 = (void*)0;
        uint8_t *l_1362[2][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_11[4][3][0],&g_11[4][3][0],&g_11[4][3][0],&g_11[4][3][0],&g_11[4][3][0]}};
        int16_t *****l_1392 = &g_1088;
        uint16_t * const l_1412 = &g_491[2];
        uint64_t l_1443[9] = {0UL,1UL,0UL,0UL,1UL,0UL,0UL,1UL,0UL};
        int i, j;
        for (i = 0; i < 2; i++)
            l_1339[i] = (void*)0;
    }
lbl_1480:
    (*g_1474) = func_63(l_1341, (safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(0x142DL, ((~(safe_sub_func_uint16_t_u_u((g_491[0] || p_8), 0UL))) ^ 0xF4EAAEBDL))), ((safe_add_func_int8_t_s_s(((*g_503) = 4L), l_1424)) > ((((((safe_rshift_func_int8_t_s_u((-7L), 0)) , 65533UL) , (void*)0) != l_1471) >= l_1363) == p_8)))), l_1472, g_1097.f0, l_1424);
    ++l_1477;
    if (l_1341)
        goto lbl_1480;
    return (*g_806);
}


/* ------------------------------------------ */
/* 
 * reads : g_1097.f3 g_58 g_1067 g_1088 g_1089 g_1090 g_833 g_206 g_29 g_503 g_151 g_165 g_97 g_62 g_1202 g_92 g_191.f0 g_28 g_1113 g_1114 g_275 g_205 g_393 g_1033 g_53 g_286 g_54 g_178 g_1032 g_1271 g_1274 g_491 g_329.f0 g_1097.f1 g_125 g_1147.f3 g_1302 g_459 g_1318
 * writes: g_1097.f3 g_58 g_286 g_29 g_151 g_11 g_62 g_574.f3 g_1202 g_1209 g_303 g_173 g_178 g_54 g_1032 g_1271 g_125 g_1147.f3 g_459 g_1318
 */
static int32_t  func_12(uint8_t  p_13)
{ /* block id: 422 */
    uint64_t l_1159 = 5UL;
    int32_t l_1177 = 0x5AC983E0L;
    int32_t l_1183 = 5L;
    int32_t l_1185 = (-1L);
    int32_t l_1186 = 0x070C73FDL;
    int32_t l_1187 = 0x23DFA96AL;
    int32_t l_1189 = 0xAD3E6433L;
    int32_t l_1190[5];
    uint32_t l_1191 = 0x7ADF979AL;
    int16_t *** const *l_1207 = &g_1089;
    int16_t *** const **l_1206 = &l_1207;
    int32_t ****l_1245 = &g_437;
    uint32_t l_1246 = 0xAA90E5B1L;
    int32_t l_1249 = 1L;
    union U1 *l_1290 = &g_469[4][5];
    int64_t *l_1296 = &g_286;
    int8_t l_1315[7] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
    int32_t *l_1321 = &g_1271;
    int32_t *l_1322 = &l_1249;
    int32_t *l_1323 = &g_62;
    int32_t *l_1324 = &l_1190[1];
    int32_t *l_1325 = &l_1187;
    int32_t *l_1326 = &l_1183;
    int32_t *l_1327 = &g_882;
    int32_t *l_1328 = &l_1183;
    int32_t *l_1329 = &l_1249;
    int32_t *l_1330 = (void*)0;
    int32_t *l_1331 = (void*)0;
    int32_t *l_1332 = &g_62;
    int32_t *l_1333 = &g_97[3];
    int32_t *l_1334[4];
    uint16_t l_1336 = 0xADBCL;
    int i;
    for (i = 0; i < 5; i++)
        l_1190[i] = 2L;
    for (i = 0; i < 4; i++)
        l_1334[i] = &g_97[3];
    for (g_1097.f3 = 7; (g_1097.f3 < 21); ++g_1097.f3)
    { /* block id: 425 */
        const int16_t *l_1155[3];
        int32_t l_1157 = 0xC85F9582L;
        int32_t l_1182 = 0L;
        int32_t l_1184 = 0xC0456AE8L;
        int32_t l_1188[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
        int16_t *** const ***l_1208[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t **l_1219 = &g_125;
        uint64_t *l_1220 = &g_303;
        uint16_t *l_1221 = &g_173;
        union U0 *l_1285 = &g_574;
        union U1 *l_1291 = (void*)0;
        int32_t *l_1309 = &l_1249;
        int32_t *l_1310 = &l_1190[2];
        int32_t *l_1311 = (void*)0;
        int32_t *l_1312 = &g_1271;
        int32_t *l_1313 = &l_1186;
        int32_t *l_1314[1];
        int64_t l_1316 = 0x7BB5E5612FA2EA8ALL;
        int8_t l_1317 = 0x46L;
        int i;
        for (i = 0; i < 3; i++)
            l_1155[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_1314[i] = (void*)0;
        for (g_58 = 0; (g_58 <= 4); g_58 += 1)
        { /* block id: 428 */
            const int16_t **l_1156 = &l_1155[1];
            int64_t *l_1158 = &g_286;
            uint16_t *l_1166 = &g_151;
            int32_t l_1175 = (-7L);
            int32_t *l_1176 = &g_62;
            int32_t *l_1178 = &g_97[3];
            int32_t *l_1179 = (void*)0;
            int32_t *l_1180 = (void*)0;
            int32_t *l_1181[9] = {&g_882,&g_2,&g_882,&g_2,&g_882,&g_2,&g_882,&g_2,&g_882};
            int i;
            l_1159 |= (((*g_503) = (g_1067[g_58] && ((safe_rshift_func_uint8_t_u_u(0xB7L, ((safe_add_func_uint64_t_u_u((((*l_1156) = (p_13 , l_1155[2])) != (***g_1088)), 18446744073709551614UL)) != (*g_206)))) ^ ((*l_1158) = l_1157)))) & (p_13 >= l_1157));
            (*l_1176) ^= (65533UL & (((((safe_div_func_int64_t_s_s((4294967293UL && ((safe_mod_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(((g_11[0][0][1] = ((--(*l_1166)) , (0x248CL != (safe_sub_func_uint64_t_u_u(g_165, g_97[3]))))) >= (safe_sub_func_int64_t_s_s(0x8B9FD6B237FBD0CDLL, p_13))), l_1159)), (safe_rshift_func_uint8_t_u_u(0xF9L, l_1157)))) == p_13)), g_1067[g_58])) == 0L) >= l_1175) ^ g_97[3]) != l_1157));
            if (p_13)
                break;
            ++l_1191;
        }
        for (g_574.f3 = 0; (g_574.f3 >= 18); ++g_574.f3)
        { /* block id: 441 */
            int32_t *l_1196 = &l_1190[2];
            int32_t *l_1197 = (void*)0;
            int32_t *l_1198 = &l_1186;
            int32_t *l_1199 = &l_1183;
            int32_t *l_1200[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t l_1201 = 0x4C9A2EF0L;
            int i;
            g_1202--;
            if (l_1190[3])
                continue;
            l_1183 &= (~p_13);
        }
        if ((((g_1209 = l_1206) != &g_802) & ((*l_1221) = (((safe_add_func_int16_t_s_s((l_1184 = (-10L)), (safe_rshift_func_uint8_t_u_s(((p_13 ^ (((*l_1220) = (((((+(0L >= ((p_13 != ((l_1188[7] == 0L) ^ ((*g_28) = (safe_mul_func_int8_t_s_s((((0x19E0A6CFL && l_1185) & l_1185) ^ (*g_833)), g_191.f0))))) , p_13))) , (void*)0) != l_1219) == (*g_1113)) != (-6L))) <= g_275[0])) >= p_13), p_13)))) , (-2L)) == 0xF030L))))
        { /* block id: 451 */
            int64_t l_1223[5];
            int64_t *l_1247 = &g_286;
            int64_t *l_1248[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t *l_1250 = &g_54;
            union U1 **l_1264[10][4] = {{&g_299[5][0][0],(void*)0,&g_299[5][0][0],&g_299[6][0][0]},{&g_299[5][0][0],&g_299[5][0][0],&g_299[6][0][0],&g_299[6][0][0]},{(void*)0,(void*)0,&g_299[5][0][0],&g_299[5][0][0]},{&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0]},{(void*)0,&g_299[5][0][0],&g_299[6][0][0],&g_299[5][0][0]},{&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0],&g_299[5][0][0]},{&g_299[5][0][0],&g_299[5][0][0],(void*)0,&g_299[5][0][0]},{&g_299[5][0][0],(void*)0,&g_299[5][0][0],&g_299[6][0][0]},{&g_299[5][0][0],&g_299[5][0][0],&g_299[6][0][0],&g_299[6][0][0]},{(void*)0,(void*)0,&g_299[5][0][0],&g_299[5][0][0]}};
            int i, j;
            for (i = 0; i < 5; i++)
                l_1223[i] = 0x7CBDAA33DB8D1C85LL;
            (*l_1250) &= ((((0x3D4FL < ((safe_unary_minus_func_int64_t_s((l_1190[1] = (g_178 = ((*l_1247) &= (l_1223[0] < (safe_mod_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s(0x29L, 2)), (((((safe_add_func_int8_t_s_s(((**g_205) & ((safe_lshift_func_uint8_t_u_s((safe_add_func_uint8_t_u_u((~(safe_mod_func_uint32_t_u_u((((safe_mul_func_uint8_t_u_u(p_13, (safe_rshift_func_uint16_t_u_u((((246UL == (0x5168BAB0B5401196LL && (safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u(g_393, ((p_13 , 0x4AL) || (-1L)))) <= l_1223[0]), 14)))) || p_13) | g_1033[4][2][0]), l_1191)))) , l_1245) != (void*)0), l_1223[1]))), 1L)), p_13)) >= l_1246)), p_13)) & p_13) , 18446744073709551615UL) || 0x1643E7D3B6DFDCCBLL) | g_53))))))))) < 0xD3L)) > l_1249) >= p_13) >= p_13);
            for (l_1177 = 0; (l_1177 < (-30)); --l_1177)
            { /* block id: 458 */
                int8_t l_1268 = 9L;
                int32_t *l_1275 = &l_1184;
                const uint32_t l_1289[9][1] = {{0x2F247B95L},{0x5A4873ADL},{0x2F247B95L},{0x2F247B95L},{0x5A4873ADL},{0x2F247B95L},{0x2F247B95L},{0x5A4873ADL},{0x2F247B95L}};
                int i, j;
                for (g_178 = 2; (g_178 >= 0); g_178 -= 1)
                { /* block id: 461 */
                    union U1 **l_1265 = &g_299[5][0][0];
                    int32_t l_1273 = (-3L);
                    for (g_1032 = 0; (g_1032 <= 2); g_1032 += 1)
                    { /* block id: 464 */
                        union U1 ***l_1266 = (void*)0;
                        union U1 ***l_1267 = &l_1265;
                        uint8_t *l_1269 = &g_11[5][6][0];
                        uint8_t *l_1270[2];
                        uint32_t l_1272 = 0x19F16BC6L;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_1270[i] = (void*)0;
                        (*l_1250) = g_1033[(g_178 + 1)][g_178][(g_1032 + 3)];
                        (*l_1250) = p_13;
                        (*l_1250) = ((safe_rshift_func_uint8_t_u_s((p_13 || ((g_1033[(g_178 + 1)][g_178][(g_1032 + 3)] & (safe_div_func_uint16_t_u_u(((((safe_lshift_func_int8_t_s_u((safe_unary_minus_func_uint16_t_u((((g_1271 &= ((*l_1269) = (p_13 <= (safe_div_func_int32_t_s_s((((8L < (safe_lshift_func_uint16_t_u_s(65533UL, 4))) , (((0xE0L < (l_1264[7][0] != ((*l_1267) = l_1265))) & l_1268) == p_13)) < p_13), (*l_1250)))))) , 7UL) | l_1272))), l_1273)) <= p_13) <= p_13) == p_13), l_1273))) != g_1274)), (*g_503))) >= g_1033[(g_178 + 1)][g_178][(g_1032 + 3)]);
                    }
                }
                (*l_1219) = l_1275;
                for (g_151 = 0; (g_151 <= 3); g_151 += 1)
                { /* block id: 476 */
                    int i;
                    return g_491[g_151];
                }
                for (l_1157 = 0; (l_1157 >= (-7)); l_1157 = safe_sub_func_uint8_t_u_u(l_1157, 3))
                { /* block id: 481 */
                    uint32_t l_1280 = 9UL;
                    union U0 *l_1284 = &g_574;
                    (*g_125) |= (0xEFEAFBB4L || ((((safe_sub_func_int8_t_s_s((0x73B51860291D2E47LL & ((*l_1220) = 18446744073709551612UL)), l_1280)) <= (0x6874L | (~(((*l_1247) = (((safe_lshift_func_int8_t_s_u((1L > (l_1284 != l_1285)), 0)) != (+(((safe_rshift_func_uint16_t_u_s(0x2AE1L, 11)) > 0xF8L) , g_329.f0))) != (*l_1250))) == p_13)))) & l_1289[6][0]) >= g_1097.f1));
                }
            }
            l_1291 = l_1290;
        }
        else
        { /* block id: 488 */
            int64_t *l_1297 = &g_286;
            int32_t l_1301 = 1L;
            for (l_1189 = 0; (l_1189 >= 0); l_1189 -= 1)
            { /* block id: 491 */
                return l_1157;
            }
            for (l_1159 = 0; (l_1159 == 22); l_1159 = safe_add_func_uint16_t_u_u(l_1159, 2))
            { /* block id: 496 */
                int32_t l_1300[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_1300[i] = 0x13DCF1EEL;
                for (g_1147.f3 = 0; (g_1147.f3 <= 5); g_1147.f3 += 1)
                { /* block id: 499 */
                    int64_t *l_1295 = &g_286;
                    int64_t **l_1294 = &l_1295;
                    int64_t **l_1298 = (void*)0;
                    int64_t **l_1299 = &l_1296;
                    l_1300[2] |= (((*l_1294) = &g_286) != ((*l_1299) = (l_1297 = l_1296)));
                    (*l_1219) = (void*)0;
                    if (p_13)
                        break;
                    (*g_1302) = l_1301;
                }
                for (g_459 = 1; (g_459 <= 5); g_459 += 1)
                { /* block id: 510 */
                    int i;
                    l_1188[(g_459 + 2)] &= p_13;
                }
                for (g_286 = 27; (g_286 < (-11)); --g_286)
                { /* block id: 515 */
                    int16_t *****l_1307 = &g_1088;
                    int32_t *l_1308 = &l_1249;
                    for (g_29 = 0; (g_29 < (-25)); g_29 = safe_sub_func_uint16_t_u_u(g_29, 6))
                    { /* block id: 518 */
                        l_1190[4] = (-1L);
                    }
                    (*l_1308) = ((void*)0 == l_1307);
                }
            }
            return p_13;
        }
        g_1318++;
    }
    l_1336++;
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_29 g_54 g_58 g_62 g_11 g_61 g_57 g_130 g_97 g_135 g_136 g_125 g_165 g_191 g_194 g_205 g_206 g_210 g_178 g_194.f0 g_92 g_281 g_151 g_276 g_284 g_275 g_289 g_303 g_174 g_329 g_286 g_212 g_413 g_51 g_469 g_472 g_475 g_491 g_503 g_574 g_277 g_585 g_173 g_589 g_299 g_459 g_28 g_136.f0 g_329.f0 g_574.f0 g_413.f0 g_752 g_786 g_788 g_52 g_847 g_574.f3 g_589.f0 g_393 g_803 g_804 g_884 g_882 g_939 g_816 g_834 g_789 g_831 g_1008 g_1011 g_1017 g_1018 g_833 g_1032 g_1033 g_827 g_817 g_1067 g_1091 g_1098 g_1087 g_1088 g_1089 g_1091.f0 g_1113 g_1122 g_1011.f0 g_815 g_1145 g_472.f0
 * writes: g_29 g_54 g_58 g_62 g_97 g_125 g_151 g_165 g_173 g_174 g_178 g_205 g_92 g_276 g_284 g_286 g_194.f3 g_211 g_299 g_303 g_213 g_420 g_437 g_393 g_459 g_11 g_491 g_503 g_786 g_789 g_801 g_574.f3 g_884 g_895 g_790 g_1067 g_1086 g_1099 g_1008.f0 g_1089 g_1145
 */
static uint8_t  func_22(uint32_t  p_23, uint8_t  p_24, uint8_t  p_25, int8_t  p_26, const int8_t * p_27)
{ /* block id: 9 */
    int64_t l_35 = 0x199E1F9531DEFCECLL;
    int8_t *l_44 = &g_29;
    int16_t l_502 = (-1L);
    int8_t **l_504[9] = {&g_503,&g_503,&g_503,&g_503,&g_503,&g_503,&g_503,&g_503,&g_503};
    int i;
    g_1145 &= ((((func_31(l_35, ((func_36((func_39((((safe_rshift_func_uint8_t_u_s((18446744073709551611UL <= (g_2 , (l_44 != ((safe_add_func_int32_t_s_s(func_47(g_2), (safe_lshift_func_uint16_t_u_s(l_502, p_25)))) , (g_503 = g_503))))), l_35)) || (-1L)) , l_35), p_25) , &p_26), g_275[2]) , 0UL) , &p_26), g_1113) && (*g_28)) & 254UL) , l_502) , l_35);
    return g_472.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_1122 g_1067 g_1011.f0 g_815 g_92 g_165 g_585
 * writes: g_92
 */
static uint8_t  func_31(int16_t  p_32, int8_t * p_33, int8_t * p_34)
{ /* block id: 414 */
    int8_t l_1121 = (-1L);
    int64_t *l_1123[4] = {&g_178,&g_178,&g_178,&g_178};
    int64_t **l_1124 = &l_1123[3];
    int64_t *l_1125 = &g_178;
    uint8_t *l_1136 = (void*)0;
    int32_t l_1137 = 0x73D309EBL;
    uint8_t l_1143 = 0xA2L;
    int32_t l_1144[9][8] = {{0xC3C641C1L,0xD6104484L,0x7E07380AL,0x7E07380AL,0xD6104484L,0xC3C641C1L,0xD6104484L,0x7E07380AL},{0xAE3BEF5CL,0xD6104484L,0xAE3BEF5CL,0xC3C641C1L,0xC3C641C1L,0xAE3BEF5CL,0xD6104484L,0xAE3BEF5CL},{4L,0xC3C641C1L,0x7E07380AL,0xC3C641C1L,4L,4L,0xC3C641C1L,0x7E07380AL},{4L,4L,0xC3C641C1L,0x7E07380AL,0xC3C641C1L,4L,4L,0xC3C641C1L},{0xAE3BEF5CL,0xC3C641C1L,0xC3C641C1L,0xAE3BEF5CL,0xD6104484L,0xAE3BEF5CL,0xC3C641C1L,0xC3C641C1L},{0xC3C641C1L,0xD6104484L,0x7E07380AL,0x7E07380AL,0xD6104484L,0xC3C641C1L,0xD6104484L,0x7E07380AL},{0xAE3BEF5CL,0xD6104484L,0xAE3BEF5CL,0xC3C641C1L,0xC3C641C1L,0xAE3BEF5CL,0xD6104484L,0xAE3BEF5CL},{4L,0xC3C641C1L,0x7E07380AL,0xC3C641C1L,4L,4L,0xC3C641C1L,0x7E07380AL},{4L,4L,0xC3C641C1L,0x7E07380AL,0xC3C641C1L,4L,4L,0xC3C641C1L}};
    int i, j;
    l_1144[2][3] &= ((-1L) > ((safe_div_func_uint8_t_u_u(((((safe_mul_func_int16_t_s_s(l_1121, ((g_1122 , ((*l_1124) = l_1123[3])) == l_1125))) || ((*g_815) ^= (((safe_sub_func_int16_t_s_s((((safe_lshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_s(8L, 13)), (safe_sub_func_int8_t_s_s(0x28L, (safe_sub_func_int64_t_s_s((((l_1137 = g_1067[4]) , ((((safe_div_func_int32_t_s_s((((safe_rshift_func_uint16_t_u_s((~0x8B1D8EDA908AC9E0LL), 14)) != 0L) < l_1137), l_1121)) && p_32) & l_1137) | l_1137)) ^ p_32), l_1143)))))) >= p_32) || g_1011.f0), l_1143)) >= l_1121) > p_32))) , (*p_33)) ^ 247UL), g_165)) != g_585[4]));
    return p_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_165 g_97 g_174 g_503 g_54 g_574 g_303 g_62 g_277 g_286 g_585 g_173 g_589 g_475 g_299 g_275 g_29 g_11 g_491 g_206 g_459 g_51 g_284 g_28 g_136.f0 g_472 g_329.f0 g_178 g_2 g_151 g_205 g_574.f0 g_212 g_92 g_413.f0 g_752 g_786 g_788 g_52 g_847 g_58 g_574.f3 g_589.f0 g_393 g_803 g_804 g_210 g_884 g_882 g_939 g_816 g_834 g_789 g_831 g_1008 g_1011 g_289 g_1017 g_1018 g_833 g_1032 g_1033 g_136 g_827 g_817 g_1067 g_1091 g_1098 g_1087 g_1088 g_1089 g_1091.f0
 * writes: g_174 g_29 g_165 g_393 g_491 g_151 g_97 g_173 g_62 g_11 g_303 g_299 g_54 g_92 g_284 g_786 g_789 g_801 g_574.f3 g_211 g_884 g_895 g_459 g_790 g_1067 g_1086 g_1099 g_1008.f0 g_1089
 */
static int32_t  func_36(int8_t * p_37, int32_t  p_38)
{ /* block id: 227 */
    int32_t l_509 = 0L;
    int32_t *l_510 = &g_62;
    int32_t l_511 = 0x37975316L;
    int32_t *l_512 = &g_97[3];
    int32_t *l_513 = &g_54;
    int32_t l_514 = (-7L);
    int32_t *l_515 = (void*)0;
    int32_t *l_516 = &g_97[1];
    int32_t l_517[10][4] = {{0L,1L,0L,0L},{1L,1L,(-1L),1L},{1L,0L,0L,1L},{0L,1L,0L,0L},{1L,1L,(-1L),1L},{1L,0L,0L,1L},{0L,1L,0L,0L},{1L,1L,(-1L),1L},{1L,0L,0L,1L},{0L,1L,0L,0L}};
    int32_t *l_518 = &l_517[7][3];
    int32_t *l_519 = &l_517[7][3];
    int32_t *l_520 = &l_517[7][3];
    int32_t *l_521 = (void*)0;
    int32_t *l_522 = &g_62;
    int32_t *l_523 = (void*)0;
    int32_t *l_524 = &g_54;
    int32_t *l_525 = (void*)0;
    int32_t *l_526[5][8][1] = {{{(void*)0},{&l_514},{&g_97[3]},{&g_97[2]},{(void*)0},{&l_517[4][3]},{&g_97[1]},{&g_62}},{{&g_97[1]},{&l_517[4][3]},{(void*)0},{&g_97[2]},{&g_97[3]},{&l_514},{(void*)0},{(void*)0}},{{&l_517[7][3]},{&g_97[3]},{&g_97[1]},{&l_517[7][3]},{(void*)0},{&g_62},{&l_511},{&g_54}},{{&l_514},{(void*)0},{&g_58},{(void*)0},{&l_514},{&g_54},{&l_511},{&g_62}},{{(void*)0},{&l_517[7][3]},{&g_97[1]},{&g_97[3]},{&g_97[3]},{&g_97[1]},{&l_517[7][3]},{(void*)0}}};
    uint64_t l_527 = 0x5A10D9DC63889E4DLL;
    uint32_t *l_564 = &g_174[2];
    uint64_t *l_565[1];
    int8_t *l_566 = &g_393;
    int64_t l_680 = 0x3B3742652061A5A5LL;
    uint32_t l_697 = 0x1CC1A3A6L;
    const int16_t *l_728 = &g_284;
    const int16_t *****l_744[9];
    uint8_t l_842 = 0x01L;
    uint8_t l_889 = 0x72L;
    int32_t ****l_892[1][7][9] = {{{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437},{(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437,(void*)0,&g_437,&g_437}}};
    uint32_t l_930 = 1UL;
    int16_t l_1076 = 0x9903L;
    int16_t * const *l_1109 = &g_807;
    int16_t * const **l_1108 = &l_1109;
    int64_t l_1110 = 0x820ECC6A05116081LL;
    uint8_t *l_1111[10] = {&l_889,(void*)0,(void*)0,(void*)0,(void*)0,&l_889,(void*)0,(void*)0,(void*)0,(void*)0};
    uint64_t l_1112 = 0xF8BA8590E45D2955LL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_565[i] = &l_527;
    for (i = 0; i < 9; i++)
        l_744[i] = (void*)0;
    --l_527;
    if ((safe_rshift_func_int8_t_s_s((((safe_div_func_int16_t_s_s((((safe_sub_func_int16_t_s_s((safe_mod_func_int32_t_s_s((safe_sub_func_int8_t_s_s((safe_add_func_uint8_t_u_u((((safe_add_func_uint8_t_u_u(g_165, (*l_516))) ^ p_38) && ((safe_sub_func_int8_t_s_s(((*l_566) = (((safe_rshift_func_uint16_t_u_u(((-9L) <= (((g_165 |= (safe_mul_func_int8_t_s_s((((safe_mul_func_int8_t_s_s(((*g_503) = (safe_sub_func_int64_t_s_s((!p_38), (safe_mul_func_int8_t_s_s(((((safe_mul_func_int16_t_s_s(0x7C56L, ((((*p_37) = (safe_unary_minus_func_uint32_t_u(((*l_564) &= ((((p_38 == (safe_rshift_func_int16_t_s_s((safe_add_func_int32_t_s_s(p_38, 0UL)), 14))) && (*p_37)) >= 0x43A2DC47L) > p_38))))) == p_38) != 0x26D3AFBAL))) | (*l_518)) <= (*l_519)) | (-1L)), p_38))))), p_38)) || 0xC5136358L) || 0L), 0xF3L))) || (*l_516)) & (*l_518))), p_38)) , (*l_519)) == 5UL)), 6UL)) , (*l_519))), 8L)), 0x73L)), p_38)), 0x9E1FL)) == p_38) > p_38), p_38)) == (*l_520)) & 0x8B54B96F0554102ALL), (*l_513))))
    { /* block id: 234 */
        return (*l_513);
    }
    else
    { /* block id: 236 */
        uint16_t *l_582 = &g_491[3];
        int32_t l_586 = 6L;
        int64_t l_628 = 0x985448A605787FA0LL;
        int32_t l_629 = 0x051DF730L;
        int32_t l_630 = 0xC2BBE005L;
        int8_t *l_658 = (void*)0;
        uint8_t l_679[4] = {0xE6L,0xE6L,0xE6L,0xE6L};
        uint16_t l_685 = 2UL;
        uint32_t l_694 = 0xBEFA6CD6L;
        uint64_t l_698 = 18446744073709551615UL;
        union U1 * const l_715 = &g_289;
        uint32_t l_717 = 0x9CE1620FL;
        int16_t l_755 = 0x869CL;
        uint64_t **l_782 = &l_565[0];
        int16_t ** const *l_799 = (void*)0;
        int16_t ** const **l_798 = &l_799;
        int16_t ** const ***l_797 = &l_798;
        const int8_t ***l_872 = &g_205;
        int32_t ** const l_898 = &l_526[2][4][0];
        int32_t ** const *l_897 = &l_898;
        int32_t ** const **l_896[2];
        uint16_t l_985 = 0x7D8AL;
        const int32_t l_986 = 0x67022595L;
        uint8_t l_987 = 0UL;
        uint32_t l_1007 = 0x2139EB63L;
        int16_t **l_1081 = &g_213;
        int16_t ***l_1080 = &l_1081;
        int16_t ****l_1079[9] = {&l_1080,&l_1080,&l_1080,&l_1080,&l_1080,&l_1080,&l_1080,&l_1080,&l_1080};
        int16_t *****l_1078 = &l_1079[2];
        int16_t ******l_1077 = &l_1078;
        uint32_t **l_1095 = &l_564;
        int i;
        for (i = 0; i < 2; i++)
            l_896[i] = &l_897;
        (*l_512) = (7UL <= ((~(safe_div_func_int32_t_s_s(((((((safe_rshift_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u((g_574 , (safe_add_func_uint16_t_u_u((p_38 ^ (p_38 & (((g_303 || (safe_lshift_func_uint8_t_u_s(((((+(safe_mul_func_uint16_t_u_u(((*l_582) = (*l_522)), (safe_lshift_func_uint16_t_u_s((g_151 = (0x1947EE9EF8EE94C0LL < g_277)), 3))))) | p_38) || 5L) == p_38), (*p_37)))) < (*l_510)) , 0x85D5D54AL))), p_38))), g_286)) < 0x13L), 0)) < (*p_37)) == 2L) > g_585[4]) & l_586) , p_38), p_38))) > 0L));
        for (g_173 = (-25); (g_173 >= 9); ++g_173)
        { /* block id: 242 */
            return p_38;
        }
        if ((g_589 , (safe_sub_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(((l_586 ^ (safe_div_func_int16_t_s_s((safe_add_func_int32_t_s_s((1UL < (safe_add_func_int8_t_s_s((*p_37), (((p_38 < ((!(~(safe_unary_minus_func_uint64_t_u((safe_lshift_func_int16_t_s_s((((*l_512) = ((safe_lshift_func_int16_t_s_s((-1L), ((*l_522) = (l_629 |= ((((safe_lshift_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((!(safe_lshift_func_uint16_t_u_u(((void*)0 == (*g_475)), (((((safe_sub_func_int8_t_s_s((((safe_div_func_int8_t_s_s(((g_165--) & (((safe_lshift_func_int8_t_s_s((*p_37), l_586)) , p_38) == (*l_524))), 7L)) | 8L) || 4L), 0xB2L)) , g_97[3]) < g_275[2]) != l_586) > 0x7055L)))), 0xD86AFA23L)), 0)) & p_38) & l_628), 7)) >= 0UL) <= l_628) && l_586))))) | 0xAA3BL)) >= p_38), l_630)))))) & 0x45D4762FL)) ^ 2L) | g_29)))), (*l_518))), l_630))) , p_38), p_38)), g_11[1][3][3]))))
        { /* block id: 249 */
            uint8_t l_642[4][1];
            int32_t **l_652 = &l_526[2][2][0];
            int32_t l_681 = 1L;
            int32_t l_682 = (-8L);
            int32_t l_683 = 0x1BEF2121L;
            int32_t l_684 = 0x37C8F884L;
            int16_t *l_739 = &g_284;
            uint16_t **l_747[10][5][5] = {{{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{(void*)0,&l_582,(void*)0,(void*)0,(void*)0},{&l_582,&l_582,&l_582,&l_582,(void*)0},{&l_582,&l_582,&l_582,&l_582,&l_582}},{{&l_582,&l_582,&l_582,(void*)0,&l_582},{(void*)0,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,(void*)0,(void*)0},{&l_582,&l_582,(void*)0,(void*)0,&l_582},{(void*)0,&l_582,&l_582,&l_582,&l_582}},{{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,(void*)0,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{(void*)0,&l_582,&l_582,(void*)0,&l_582}},{{&l_582,(void*)0,(void*)0,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{(void*)0,(void*)0,(void*)0,&l_582,(void*)0},{&l_582,&l_582,&l_582,&l_582,(void*)0}},{{&l_582,&l_582,&l_582,(void*)0,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,(void*)0,&l_582,&l_582,&l_582}},{{&l_582,&l_582,&l_582,(void*)0,&l_582},{(void*)0,&l_582,(void*)0,&l_582,&l_582},{&l_582,(void*)0,&l_582,(void*)0,(void*)0},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,(void*)0,(void*)0,&l_582,&l_582}},{{&l_582,&l_582,&l_582,(void*)0,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,(void*)0,&l_582},{&l_582,(void*)0,(void*)0,&l_582,&l_582},{&l_582,(void*)0,&l_582,&l_582,(void*)0}},{{&l_582,(void*)0,&l_582,&l_582,(void*)0},{&l_582,&l_582,(void*)0,&l_582,&l_582},{(void*)0,&l_582,&l_582,(void*)0,&l_582},{&l_582,&l_582,&l_582,&l_582,(void*)0},{&l_582,&l_582,&l_582,&l_582,&l_582}},{{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,(void*)0,(void*)0,&l_582},{&l_582,(void*)0,&l_582,&l_582,&l_582}},{{&l_582,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,(void*)0,(void*)0,&l_582},{&l_582,&l_582,&l_582,&l_582,&l_582},{(void*)0,&l_582,&l_582,&l_582,&l_582},{&l_582,&l_582,&l_582,(void*)0,&l_582}}};
            int16_t l_756 = (-1L);
            int8_t *l_778[7] = {&g_393,(void*)0,(void*)0,&g_393,(void*)0,(void*)0,&g_393};
            int16_t l_848 = 1L;
            uint32_t l_864 = 0xE80FC676L;
            int32_t l_888 = 0xB6FDCFE4L;
            int32_t l_923 = 0x514CFCB3L;
            int32_t l_926[3];
            int64_t l_928[10] = {5L,5L,5L,5L,5L,5L,5L,5L,5L,5L};
            const union U1 **l_945 = (void*)0;
            int16_t * const *l_1031 = (void*)0;
            int16_t * const **l_1030 = &l_1031;
            int16_t * const ***l_1029 = &l_1030;
            int16_t * const ****l_1028 = &l_1029;
            int16_t l_1034 = 8L;
            int i, j, k;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 1; j++)
                    l_642[i][j] = 250UL;
            }
            for (i = 0; i < 3; i++)
                l_926[i] = 1L;
            if ((safe_mod_func_int32_t_s_s(4L, ((safe_mod_func_int32_t_s_s(((((safe_add_func_int32_t_s_s(((-1L) || (safe_mul_func_uint8_t_u_u((g_491[3] & (safe_add_func_int32_t_s_s((((((*p_37) = (*g_206)) >= g_459) && g_51) & ((+l_642[2][0]) || ((safe_unary_minus_func_uint32_t_u(g_303)) , 0xDB38DEF3L))), 0x6BF01C10L))), p_38))), g_303)) , 1UL) , 0L) , l_586), g_54)) || l_628))))
            { /* block id: 251 */
                uint8_t *l_650 = &g_11[5][2][3];
                int32_t l_657[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_657[i] = 0xC6AE4CC5L;
                (*l_652) = func_63(l_628, (l_642[2][0] , (safe_rshift_func_int16_t_s_u((((((safe_rshift_func_int16_t_s_s(p_38, p_38)) & g_284) < (safe_mul_func_uint8_t_u_u(((*l_650) = 0xC2L), (~(l_652 == (func_39(((((*g_28) = l_628) , (safe_sub_func_int64_t_s_s((((safe_mul_func_int8_t_s_s((-1L), g_136.f0)) ^ p_38) , (*l_510)), p_38))) && l_657[1]), p_38) , (void*)0)))))) ^ p_38) , l_630), 0))), l_658, p_38, (*p_37));
                (*l_519) |= (safe_add_func_uint16_t_u_u((g_173 = 0xCF60L), (0x050FL < (safe_lshift_func_int16_t_s_s((0x3CL ^ (safe_rshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(0xAFF6L, ((safe_mod_func_int32_t_s_s((((p_38 , (((p_38 >= 6UL) , (((*l_582) &= (safe_div_func_uint16_t_u_u(((g_303 |= g_329.f0) ^ ((safe_add_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u(((*l_650) = ((safe_mod_func_int16_t_s_s(p_38, p_38)) != g_62)), p_38)) && g_174[3]), 0L)), 0xCD804A26505FB3C2LL)) , p_38)), l_679[2]))) ^ p_38)) < (-8L))) | l_629) , (*l_524)), p_38)) || p_38))), g_178))), p_38)))));
                l_685++;
                (*l_652) = ((safe_mod_func_uint64_t_u_u((((((safe_add_func_int32_t_s_s(((*l_512) = (l_657[3] , (((((void*)0 != &g_135) <= p_38) >= ((safe_rshift_func_int8_t_s_s((*g_28), 4)) > p_38)) >= 1L))), l_694)) , (safe_add_func_int64_t_s_s(((p_38 | g_2) ^ 0xCFA66510CD305ED1LL), l_586))) != l_679[2]) , 0x0E42L) <= l_697), l_698)) , (void*)0);
            }
            else
            { /* block id: 263 */
                int64_t l_714[5] = {0x70D2EA1D7DA4107DLL,0x70D2EA1D7DA4107DLL,0x70D2EA1D7DA4107DLL,0x70D2EA1D7DA4107DLL,0x70D2EA1D7DA4107DLL};
                int32_t l_734 = 1L;
                int8_t l_754 = (-10L);
                uint32_t l_757 = 4294967286UL;
                uint64_t **l_783 = (void*)0;
                int32_t l_784[8] = {(-6L),(-6L),(-1L),(-1L),(-6L),(-1L),(-1L),(-6L)};
                uint16_t **l_787 = &l_582;
                int16_t *l_876[7][2] = {{&g_284,&l_755},{&g_284,&g_284},{&l_755,&g_284},{&g_284,&l_755},{&g_284,&g_284},{&l_755,&g_284},{&g_284,&l_755}};
                uint16_t l_903 = 3UL;
                int64_t l_950 = 0xE8484AE1CA2D8DC4LL;
                int i, j;
                if (p_38)
                { /* block id: 264 */
                    int32_t *l_699 = &l_682;
                    (*l_652) = l_699;
                    for (l_680 = 0; (l_680 >= 0); l_680 -= 1)
                    { /* block id: 268 */
                        union U1 **l_716 = &g_299[2][0][0];
                        int i;
                        l_630 |= ((safe_rshift_func_uint16_t_u_u(g_174[(l_680 + 2)], 15)) != (((safe_rshift_func_uint16_t_u_s((p_38 | g_151), (0x9913L == (safe_lshift_func_int16_t_s_s((*l_519), (safe_mul_func_uint8_t_u_u((l_586 = (safe_mul_func_int8_t_s_s((**g_205), (safe_mod_func_int64_t_s_s(((0UL && ((safe_rshift_func_uint16_t_u_s(l_714[1], (l_582 == l_582))) >= (*p_37))) & 4L), g_574.f0))))), 0UL))))))) , p_38) != 0xCD61L));
                        (*l_716) = l_715;
                        (*l_652) = func_63(l_717, ((safe_rshift_func_uint16_t_u_u((g_173 = (safe_add_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u((0UL | (((*p_37) &= 1L) ^ (((l_714[1] > (((g_491[0] = (g_174[4] >= (-2L))) == ((((0x13L == (safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s((p_38 <= (l_728 == l_728)), 0x31B9C8C15D9E4BD8LL)), 0xD6FCF09A67368467LL))) > g_174[(l_680 + 2)]) , 255UL) , p_38)) & (-1L))) , (*l_699)) , 1L))), (*g_206))) <= g_174[(l_680 + 2)]), 0x993B8949L))), 5)) , g_574.f0), l_658, g_275[0], l_685);
                    }
                    (*l_524) ^= 0x6079EBA8L;
                }
                else
                { /* block id: 278 */
                    int32_t *l_731 = &l_681;
                    for (l_684 = 0; (l_684 < (-4)); l_684 = safe_sub_func_int8_t_s_s(l_684, 2))
                    { /* block id: 281 */
                        int16_t *l_735 = (void*)0;
                        int32_t l_736[2];
                        uint16_t **l_749[5] = {&l_582,&l_582,&l_582,&l_582,&l_582};
                        uint16_t ***l_748 = &l_749[0];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_736[i] = (-1L);
                        (*l_652) = l_731;
                        l_734 &= (safe_mod_func_int16_t_s_s((*g_212), 0xC106L));
                        l_736[1] = (((*g_212) = p_38) > (-5L));
                        (*l_519) = ((0x138CEB85L < (p_38 , (safe_sub_func_uint8_t_u_u(((0xD0F3BAF9L >= 0x54BA32A1L) == (((void*)0 == l_739) ^ (safe_div_func_uint64_t_u_u((safe_lshift_func_int8_t_s_u(((l_744[2] != ((safe_rshift_func_uint8_t_u_s(((l_747[7][3][1] != ((*l_748) = l_747[5][1][1])) >= (*l_731)), 7)) , (void*)0)) ^ l_717), 6)), g_413.f0)))), (*g_503))))) >= 18446744073709551615UL);
                    }
                    for (g_165 = (-20); (g_165 == 14); g_165++)
                    { /* block id: 291 */
                        (*g_752) = (*g_475);
                        (*l_522) ^= (+0x48918AD2AC952816LL);
                        if (p_38)
                            break;
                        if (l_754)
                            continue;
                    }
                    --l_757;
                    if (l_757)
                        goto lbl_887;
                }
lbl_887:
                if (((*l_516) = (safe_mod_func_int8_t_s_s((*g_503), (safe_add_func_int8_t_s_s((p_38 != ((*l_739) = 7L)), (safe_sub_func_uint16_t_u_u(0x4F31L, (((~(safe_sub_func_uint8_t_u_u(g_54, (p_38 > g_2)))) > (0L & (safe_lshift_func_int8_t_s_s(((void*)0 == &l_698), (*g_28))))) || 0L)))))))))
                { /* block id: 301 */
                    int64_t *l_779 = &l_714[4];
                    int32_t l_785[7][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}};
                    uint64_t *l_837 = &g_165;
                    int i, j;
                    if ((g_786 ^= ((~(safe_div_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((*l_518), ((0xADF7L == (l_785[4][2] = ((((l_778[0] != (void*)0) | ((p_38 && ((*l_779) = g_51)) > ((safe_sub_func_uint8_t_u_u((*l_512), ((((l_782 == l_783) , 1L) | g_62) != (*p_37)))) || 2UL))) ^ 253UL) >= l_784[7]))) , p_38))), p_38))) , l_630)))
                    { /* block id: 305 */
                        int32_t *l_791 = &l_682;
                        (*g_788) = l_787;
                        l_791 = &l_785[0][0];
                        (*l_524) = (((*l_520) >= ((void*)0 == &g_205)) , (((*l_564)++) ^ ((*l_510) = (g_52 , l_754))));
                        (*l_652) = &l_785[4][2];
                    }
                    else
                    { /* block id: 312 */
                        int16_t ** const ****l_800 = (void*)0;
                        uint64_t *l_838 = &g_165;
                        (*l_522) = (p_38 != (safe_lshift_func_uint16_t_u_u(l_785[4][2], (!((((**l_782) &= ((g_801 = l_797) != (void*)0)) < (l_837 == l_838)) & (safe_add_func_uint8_t_u_u(((l_785[4][2] & (+l_842)) & l_714[1]), p_38)))))));
                    }
                }
                else
                { /* block id: 317 */
                    int8_t l_849 = 0x26L;
                    int16_t *l_875 = &g_92;
                    l_784[7] = ((safe_div_func_uint32_t_u_u(((((safe_lshift_func_uint16_t_u_u(((g_847 , 65535UL) , 0x2107L), 3)) , l_848) <= l_755) , g_491[0]), (l_849 || (safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_u(((safe_rshift_func_uint8_t_u_s((p_38 == ((safe_add_func_int32_t_s_s(((*l_522) |= (safe_sub_func_int64_t_s_s((safe_mod_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s((((((**l_782) = (((void*)0 != l_782) == 0x25BFL)) == l_849) < l_685) && p_38), (*g_206))), l_754)), p_38))), g_58)) && p_38)), l_864)) , 0xF6L), 7)) , 0xD165L), 15))))) != 0x77L);
                    for (g_574.f3 = 1; (g_574.f3 <= 4); g_574.f3 += 1)
                    { /* block id: 323 */
                        int i;
                        (*l_516) |= 1L;
                        return g_174[g_574.f3];
                    }
                    for (g_92 = 0; (g_92 == 15); g_92 = safe_add_func_int32_t_s_s(g_92, 4))
                    { /* block id: 329 */
                        const int8_t ***l_874 = &g_205;
                        const int8_t ****l_873 = &l_874;
                        int16_t ***l_881 = (void*)0;
                        int32_t l_883 = (-4L);
                        (*l_524) = (((((safe_lshift_func_uint16_t_u_s(((+65528UL) == (((l_872 == ((*l_873) = (void*)0)) , 9UL) <= (l_875 != (g_589.f0 , l_876[5][1])))), (((safe_lshift_func_uint16_t_u_u((((safe_div_func_uint8_t_u_u(0xBCL, 0x43L)) <= g_393) < p_38), l_849)) , g_54) , p_38))) && l_849) | g_459) && p_38) > 0xD980B936AA53512CLL);
                        (*l_652) = &l_734;
                        (*g_210) = (*g_803);
                        --g_884;
                    }
                }
lbl_1064:
                l_889--;
                for (l_680 = 5; (l_680 >= 0); l_680 -= 1)
                { /* block id: 341 */
                    int32_t *****l_893 = (void*)0;
                    int32_t *****l_894[2][6][9] = {{{&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0],&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][3],&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0],&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][3],&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0],&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]}},{{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][3],&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0],&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][3],&l_892[0][0][0],&l_892[0][0][0],(void*)0},{&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0],&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]},{&l_892[0][0][0],&l_892[0][0][0],(void*)0,&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][3],&l_892[0][0][0],&l_892[0][0][0],&l_892[0][2][0]}}};
                    uint32_t * const *l_916 = (void*)0;
                    uint16_t **l_955 = (void*)0;
                    int8_t *l_1044 = (void*)0;
                    int i, j, k;
                    if (((g_895[1] = l_892[0][0][0]) == l_896[0]))
                    { /* block id: 343 */
                        l_784[7] = 0xCE7CBC7FL;
                    }
                    else
                    { /* block id: 345 */
                        int32_t l_899 = (-3L);
                        int32_t l_900 = 0x7CE9BBF4L;
                        int32_t l_901[9][8] = {{6L,0L,6L,0x5F15BB36L,0x5F15BB36L,6L,0L,6L},{0x9C1F4ECCL,0x5F15BB36L,(-3L),0x5F15BB36L,0x9C1F4ECCL,0x9C1F4ECCL,0x5F15BB36L,(-3L)},{0x9C1F4ECCL,0x9C1F4ECCL,0x5F15BB36L,(-3L),0x5F15BB36L,0x9C1F4ECCL,0x9C1F4ECCL,0x5F15BB36L},{6L,0x5F15BB36L,0x5F15BB36L,6L,0L,(-3L),6L,6L},{6L,0x9C1F4ECCL,0L,0L,0x9C1F4ECCL,6L,0x9C1F4ECCL,0L},{(-3L),0x9C1F4ECCL,(-3L),6L,6L,(-3L),0x9C1F4ECCL,(-3L)},{0x5F15BB36L,6L,0L,6L,0x5F15BB36L,0x5F15BB36L,6L,0L},{0x5F15BB36L,0x5F15BB36L,6L,0L,6L,0x5F15BB36L,0x5F15BB36L,6L},{(-3L),6L,6L,(-3L),0x9C1F4ECCL,(-3L),6L,6L}};
                        int8_t l_902 = 0x36L;
                        const uint64_t *l_909 = (void*)0;
                        const uint64_t **l_908 = &l_909;
                        uint32_t * const *l_917 = &l_564;
                        int i, j;
                        ++l_903;
                        (*l_524) &= (-3L);
                        (*l_898) = func_63((((-2L) && (safe_lshift_func_int16_t_s_s((((*l_782) = &g_165) != ((*l_908) = (void*)0)), 4))) > (safe_mod_func_int32_t_s_s(0x3CEA3E30L, ((safe_div_func_uint16_t_u_u(l_901[8][5], (((*l_564) = p_38) | ((l_902 != (((*p_37) = (((safe_mod_func_uint8_t_u_u((((0x576FE423L > ((g_58 , (void*)0) != &p_37)) || (*p_37)) && g_393), (**g_205))) < 0x62DDL) , 0L)) , g_329.f0)) >= (*g_206))))) & g_882)))), g_491[0], &g_393, g_173, l_901[1][2]);
                        l_917 = l_916;
                    }
                    for (g_459 = 0; (g_459 <= 5); g_459 += 1)
                    { /* block id: 357 */
                        int32_t l_918 = 0x4C258F15L;
                        int32_t l_919 = 1L;
                        int32_t l_920 = 0x009DC52BL;
                        int32_t l_921 = (-1L);
                        int32_t l_922 = 0L;
                        int32_t l_924 = 0x29C39B4EL;
                        int32_t l_925 = 0L;
                        int32_t l_927[2];
                        const union U1 ***l_946 = &l_945;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_927[i] = 9L;
                        l_930++;
                        (*l_512) = (safe_add_func_uint16_t_u_u((((safe_mod_func_int64_t_s_s((((safe_sub_func_uint8_t_u_u((((*g_834) = (g_939 , ((((*l_513) || ((*l_510) |= (*g_816))) >= ((safe_sub_func_uint64_t_u_u((p_38 ^ (g_165 , (+(safe_add_func_uint8_t_u_u(((((*l_946) = l_945) != ((((g_51 | (p_38 != (!((-3L) == p_38)))) > l_919) >= 0x004B6DBA52002F2ELL) , (void*)0)) > (*p_37)), g_284))))), g_284)) & (*l_513))) <= p_38))) > 1L), l_950)) || p_38) && (*g_206)), 0xA9A7213BF0B5C33DLL)) == (*g_206)) != (*p_37)), l_926[1]));
                        (*l_522) ^= (safe_mod_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((l_955 != (*g_788)), (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_s((((*l_518) = ((l_784[7] ^= (l_921 = (safe_lshift_func_int8_t_s_u(((safe_sub_func_uint64_t_u_u((((safe_add_func_uint64_t_u_u(((safe_add_func_uint32_t_u_u(((*l_524) = (safe_div_func_int8_t_s_s((~((*g_831) = (*l_513))), (safe_lshift_func_int16_t_s_s(l_921, (l_734 = l_918)))))), (*l_520))) , ((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_div_func_int64_t_s_s((safe_lshift_func_int16_t_s_s((((safe_add_func_int32_t_s_s(l_754, (0x40F12A117C747784LL && 18446744073709551608UL))) == p_38) , (-3L)), 15)), 2L)), p_38)), (*p_37))) , l_985)), p_38)) & p_38) <= 0x7976L), l_986)) || g_174[2]), g_2)))) || 0x91599F2FL)) >= 0L), 11)), p_38)), g_459)))), l_987));
                        (*l_652) = func_63(p_38, (((safe_rshift_func_int16_t_s_s((safe_add_func_int32_t_s_s((safe_add_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s((safe_sub_func_uint32_t_u_u(g_178, ((((safe_add_func_int8_t_s_s((**g_205), (safe_lshift_func_uint8_t_u_s((!(((safe_lshift_func_uint8_t_u_u((((l_1007 , l_918) < ((g_1008 , ((safe_add_func_int32_t_s_s(0L, p_38)) != l_927[0])) ^ (-1L))) != p_38), 2)) , (void*)0) == (void*)0)), 4)))) < p_38) , p_38) , p_38))), 10)), p_38)), p_38)), p_38)) < 0L) != 0UL), &g_29, p_38, (**g_205));
                    }
                    (*l_512) ^= (g_1011 , ((*g_503) , ((((safe_rshift_func_int8_t_s_u((safe_sub_func_uint16_t_u_u(((~((((*l_715) , g_1017) , ((g_1018[0][1] != (void*)0) > (((safe_sub_func_int8_t_s_s((safe_add_func_int64_t_s_s((((((((((*g_833) ^= (l_784[7] ^ 0x5DL)) <= (safe_rshift_func_int16_t_s_u((((safe_rshift_func_uint16_t_u_s(p_38, 11)) , 0x06EF359A38FA88DELL) , p_38), p_38))) , 0xF4L) > g_62) & (*p_37)) >= p_38) , (void*)0) == (void*)0), 0x62734C0D7DA1E1B8LL)), 255UL)) , l_1028) == (void*)0))) && 0x9C77534DAB602306LL)) | l_734), 0xCAB6L)), l_784[7])) < g_1032) > 0xC77AFD70L) ^ g_1033[4][2][0])));
                    (*l_513) ^= l_1034;
                    for (l_629 = 5; (l_629 >= 0); l_629 -= 1)
                    { /* block id: 377 */
                        int8_t *l_1043[3];
                        uint64_t l_1051 = 1UL;
                        uint16_t *l_1063 = &l_685;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1043[i] = &g_393;
                        (*l_519) ^= (((safe_lshift_func_uint8_t_u_s((safe_mod_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u(((((l_1043[1] = p_37) == l_1044) && ((((*p_37) == (*p_37)) & (((*g_789) = &l_985) != l_728)) ^ ((safe_sub_func_uint32_t_u_u((((safe_mul_func_uint8_t_u_u((g_136 , 0x07L), (safe_div_func_uint16_t_u_u((p_38 , p_38), 5L)))) < l_1051) ^ g_174[3]), l_903)) < (**g_205)))) , 0xA1L), 4)) >= 0xF1A6C6980DD0B37BLL), (-10L))), p_38)), 0)) & g_58) & p_38);
                        l_926[2] ^= (safe_sub_func_int8_t_s_s((+p_38), (255UL > (((*l_582) = 0x88C9L) & (l_757 <= (((*l_513) = ((*l_519) = (safe_add_func_int16_t_s_s((((*l_516) = ((*l_510) = (((((*g_827) ^= p_38) && (safe_lshift_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((l_1063 = l_1063) != (void*)0), ((void*)0 == &l_897))), p_38))) ^ g_11[0][3][0]) != (*l_518)))) < 0xE85CE357L), (*g_817))))) & p_38))))));
                        if (l_734)
                            goto lbl_1064;
                    }
                }
            }
        }
        else
        { /* block id: 393 */
            int32_t l_1065 = 6L;
            int32_t l_1066[6] = {1L,1L,0xC654F72AL,1L,1L,0xC654F72AL};
            int16_t *******l_1082 = (void*)0;
            int16_t *******l_1083 = &l_1077;
            int16_t ******l_1085 = &l_1078;
            int16_t *******l_1084[8];
            uint8_t *l_1092 = &g_11[1][7][3];
            union U0 *l_1096 = &g_1097;
            int i;
            for (i = 0; i < 8; i++)
                l_1084[i] = &l_1085;
            g_1067[4]--;
            if (((safe_div_func_uint16_t_u_u(((*l_582)++), (*g_833))) || (((safe_div_func_uint16_t_u_u(l_1076, ((((g_1086 = ((*l_1083) = l_1077)) != (void*)0) != ((*l_1092) = (g_1091[0] , g_54))) | (((safe_sub_func_uint16_t_u_u(((void*)0 != l_1095), p_38)) != (*l_520)) & p_38)))) | 0x5584L) == l_1066[0])))
            { /* block id: 399 */
                l_1096 = (void*)0;
                return p_38;
            }
            else
            { /* block id: 402 */
                (*g_1098) = l_1096;
                return p_38;
            }
        }
    }
    for (g_1008.f0 = 0; g_1008.f0 < 1; g_1008.f0 += 1)
    {
        l_565[g_1008.f0] = &g_165;
    }
    (*l_516) = ((p_38 < (((*g_503) == p_38) && ((0xF722B690L || p_38) == ((((*g_503) = ((((safe_rshift_func_uint16_t_u_u((safe_div_func_int8_t_s_s((-1L), ((*l_524) |= (safe_add_func_int16_t_s_s(((((*l_522) ^ (((*g_1088) = (**g_1087)) != l_1108)) ^ 0xF3FD4956L) ^ g_1091[0].f0), l_1110))))), 9)) ^ (*l_512)) & p_38) & p_38)) < g_1033[1][0][4]) == (*p_37))))) < g_303);
    return l_1112;
}


/* ------------------------------------------ */
/* 
 * reads : g_472
 * writes:
 */
static union U0  func_39(uint64_t  p_40, uint8_t  p_41)
{ /* block id: 224 */
    uint64_t l_507 = 0UL;
    int32_t l_508 = 0x48F9BC9DL;
    l_508 = (safe_mod_func_uint64_t_u_u(l_507, p_40));
    return g_472;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_54 g_58 g_62 g_11 g_61 g_57 g_2 g_130 g_97 g_135 g_136 g_125 g_165 g_191 g_194 g_205 g_206 g_210 g_178 g_194.f0 g_92 g_281 g_151 g_276 g_284 g_275 g_289 g_303 g_174 g_329 g_286 g_212 g_413 g_51 g_469 g_472 g_475 g_491
 * writes: g_29 g_54 g_58 g_62 g_97 g_125 g_151 g_165 g_173 g_174 g_178 g_205 g_92 g_276 g_284 g_286 g_194.f3 g_211 g_299 g_303 g_213 g_420 g_437 g_393 g_459 g_11 g_491
 */
static int32_t  func_47(const uint16_t  p_48)
{ /* block id: 10 */
    int16_t *l_115 = (void*)0;
    int8_t *l_121 = (void*)0;
    int32_t l_149 = 0x95B5F3EEL;
    int8_t **l_234 = &l_121;
    int8_t ***l_233[9][10][2] = {{{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0},{&l_234,&l_234}},{{&l_234,&l_234},{&l_234,&l_234},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,(void*)0},{&l_234,&l_234},{(void*)0,&l_234},{&l_234,&l_234},{&l_234,&l_234},{&l_234,(void*)0}},{{(void*)0,&l_234},{(void*)0,&l_234},{&l_234,&l_234},{&l_234,&l_234},{(void*)0,(void*)0},{(void*)0,&l_234},{&l_234,&l_234},{&l_234,&l_234},{(void*)0,&l_234},{(void*)0,(void*)0}}};
    int16_t **l_244 = &l_115;
    int16_t ***l_243 = &l_244;
    uint64_t l_268 = 0xE1A63A71FD06F51ELL;
    uint32_t l_306 = 1UL;
    int32_t **l_331 = &g_125;
    int32_t ***l_330 = &l_331;
    int32_t l_347 = 0xFABE88D6L;
    int32_t l_353 = 0xCC790F11L;
    uint8_t l_356[7];
    int32_t l_430 = 0xE2E95BB5L;
    int32_t l_431 = 0x4DCE7EF3L;
    int32_t l_457 = 8L;
    int8_t l_473[3][4] = {{0x56L,0x56L,0x56L,0x56L},{0x56L,0x56L,0x56L,0x56L},{0x56L,0x56L,0x56L,0x56L}};
    int32_t *l_476 = &l_457;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_356[i] = 6UL;
    for (g_29 = 0; (g_29 < (-9)); g_29--)
    { /* block id: 13 */
        int32_t *l_128 = (void*)0;
        for (g_54 = (-12); (g_54 != 0); g_54 = safe_add_func_int8_t_s_s(g_54, 2))
        { /* block id: 16 */
            int32_t l_116 = 0x8532663EL;
            int32_t *l_127[1];
            int32_t **l_129 = (void*)0;
            int i;
            for (i = 0; i < 1; i++)
                l_127[i] = &g_62;
            for (g_58 = 0; (g_58 == (-27)); --g_58)
            { /* block id: 19 */
                int32_t **l_126[5][6][7] = {{{(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,(void*)0,(void*)0,&g_125,(void*)0},{&g_125,&g_125,&g_125,&g_125,(void*)0,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125}},{{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,(void*)0,&g_125,&g_125,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125}},{{&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125},{(void*)0,(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125},{(void*)0,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,(void*)0,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0}},{{&g_125,&g_125,&g_125,(void*)0,(void*)0,(void*)0,&g_125},{(void*)0,&g_125,(void*)0,(void*)0,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,(void*)0},{&g_125,&g_125,&g_125,&g_125,(void*)0,&g_125,&g_125}},{{&g_125,(void*)0,&g_125,&g_125,(void*)0,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125,&g_125}}};
                int i, j, k;
                for (g_62 = 3; (g_62 >= 0); g_62 -= 1)
                { /* block id: 22 */
                    int16_t *l_119 = &g_92;
                    int16_t **l_120 = &l_119;
                    int32_t *l_124 = &g_97[3];
                    int32_t **l_123[10][4] = {{&l_124,&l_124,&l_124,&l_124},{&l_124,&l_124,(void*)0,&l_124},{(void*)0,&l_124,(void*)0,&l_124},{&l_124,&l_124,&l_124,&l_124},{(void*)0,&l_124,(void*)0,&l_124},{(void*)0,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124},{(void*)0,&l_124,(void*)0,&l_124},{(void*)0,(void*)0,&l_124,(void*)0},{&l_124,(void*)0,(void*)0,&l_124}};
                    int i, j, k;
                    g_125 = func_63((func_69(g_11[g_62][g_62][g_62], p_48, g_62) , ((l_115 == (void*)0) == (l_116 , (((safe_mod_func_uint64_t_u_u((((*l_120) = l_119) == &g_92), 18446744073709551615UL)) | g_61) != g_54)))), g_2, l_121, g_11[g_62][g_62][g_62], l_116);
                }
                l_127[0] = &l_116;
            }
            (*g_130) = l_128;
        }
        return p_48;
    }
lbl_262:
    for (g_54 = 24; (g_54 > (-13)); g_54--)
    { /* block id: 44 */
        int32_t *l_133 = &g_97[0];
        (*l_133) = 0x6ACFB1E1L;
        if ((*l_133))
            break;
    }
lbl_499:
    for (g_54 = 3; (g_54 >= 0); g_54 -= 1)
    { /* block id: 50 */
        int32_t *l_134 = &g_97[2];
        int8_t **l_145 = &l_121;
        uint16_t *l_150 = &g_151;
        int32_t l_158 = 0x276A10C0L;
        uint16_t l_214 = 0xC8C4L;
        const int64_t l_282 = (-1L);
        int32_t l_396 = (-9L);
        int32_t l_397 = 0x6134B4CCL;
        int32_t l_398[5];
        union U1 * const l_439 = (void*)0;
        int32_t l_466 = 0x006623E4L;
        int i;
        for (i = 0; i < 5; i++)
            l_398[i] = 0xCBD0F30AL;
        (*g_135) = l_134;
        if ((((*l_150) = (((g_136 , g_57) < g_2) < (((safe_div_func_int64_t_s_s(((safe_sub_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(g_58, (safe_add_func_uint8_t_u_u((((*l_145) = &g_29) != (void*)0), (safe_unary_minus_func_uint16_t_u((0UL | ((safe_rshift_func_uint16_t_u_s(((*l_134) == ((0xA9L & g_2) , p_48)), 10)) ^ p_48)))))))), 8L)) , (*l_134)), g_54)) == l_149) || 0UL))) < (-1L)))
        { /* block id: 54 */
            int16_t ***l_155 = (void*)0;
            int16_t **l_157 = &l_115;
            int16_t ***l_156 = &l_157;
            int i;
            l_158 &= (g_97[g_54] = ((safe_lshift_func_int16_t_s_u(0x3AC8L, (+3L))) <= (((*l_156) = (void*)0) != &l_115)));
        }
        else
        { /* block id: 58 */
            (*l_134) = (**g_135);
        }
        for (l_158 = 3; (l_158 >= 0); l_158 -= 1)
        { /* block id: 63 */
            uint64_t *l_164 = &g_165;
            uint16_t *l_172 = &g_173;
            int64_t *l_177 = &g_178;
            uint32_t l_181[8] = {0xAFF6EFABL,1UL,1UL,0xAFF6EFABL,1UL,1UL,0xAFF6EFABL,1UL};
            int32_t *l_182[7] = {&g_58,&g_58,&g_54,&g_58,&g_58,&g_54,&g_58};
            uint32_t l_237 = 0UL;
            int i;
            l_182[4] = func_63((safe_sub_func_uint64_t_u_u(g_97[l_158], (safe_lshift_func_int8_t_s_u((g_97[g_54] , (!(++(*l_164)))), (safe_rshift_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((g_174[2] = ((*l_172) = (((*l_150) = 0xBFE5L) ^ 65533UL))), (safe_add_func_int64_t_s_s(((*l_177) = 6L), (((**g_135) ^ ((-9L) <= (safe_add_func_uint32_t_u_u((&p_48 != (((4UL == 0x8FL) , l_181[6]) , &p_48)), p_48)))) && g_97[g_54]))))) != 0x87BBL), 4)))))), l_149, l_121, p_48, g_97[g_54]);
            for (g_62 = 0; (g_62 <= 3); g_62 += 1)
            { /* block id: 72 */
                int32_t **l_183[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int16_t *l_221 = &g_92;
                const int16_t *l_247 = &g_92;
                const int16_t **l_246 = &l_247;
                const int16_t ***l_245[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_245[i] = &l_246;
                l_182[4] = ((*g_135) = (*g_135));
                for (l_149 = 3; (l_149 >= 0); l_149 -= 1)
                { /* block id: 77 */
                    const int8_t ***l_207[9] = {&g_205,&g_205,&g_205,&g_205,&g_205,&g_205,&g_205,&g_205,&g_205};
                    int16_t **l_209 = &l_115;
                    int16_t ***l_208 = &l_209;
                    int32_t l_215 = 0x79C5B4EDL;
                    int i, j, k;
                    if ((((+(l_215 = (safe_sub_func_int32_t_s_s((((safe_mul_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(0x0EEFAAB1L, (g_191 , (safe_div_func_uint8_t_u_u(g_11[(l_149 + 1)][(g_62 + 2)][l_158], (g_191 , ((**l_145) = ((g_97[l_149] = 0x1AA5C5DEL) || (g_194 , (safe_add_func_int64_t_s_s((safe_lshift_func_int8_t_s_u(((((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(((((((safe_add_func_uint64_t_u_u((g_97[l_149] = (g_11[(g_62 + 3)][(l_149 + 2)][g_54] , ((g_205 = g_205) != ((g_194 , g_191) , &l_121)))), g_11[0][3][3])) | p_48) , 1UL) == (*g_206)) > 0x169658B3L) | p_48), 0)), 0x61A9AB88E0C3C7F2LL)) | 0xBBB9L) , l_208) != g_210), p_48)), p_48))))))))))), g_178)) == l_214) & p_48), (-2L))))) == p_48) < p_48))
                    { /* block id: 83 */
                        int16_t l_220 = 0xCF6DL;
                        int64_t l_224[5][3] = {{0L,0L,0L},{0L,0L,0L},{0L,0L,0L},{0L,0L,0L},{0L,0L,0L}};
                        int8_t * const *l_236 = &l_121;
                        int8_t * const **l_235 = &l_236;
                        uint32_t *l_238 = &g_174[2];
                        int i, j;
                        g_97[g_62] &= ((safe_add_func_uint16_t_u_u((g_136 , ((*l_172) = (safe_rshift_func_int8_t_s_s(l_220, p_48)))), (((**l_208) = &g_92) != l_221))) != ((safe_sub_func_uint8_t_u_u(l_224[3][2], (safe_add_func_uint32_t_u_u(((*l_238) = ((safe_mod_func_int32_t_s_s(((p_48 | (safe_div_func_uint32_t_u_u(((0xFB746B9F5D823547LL > (((((safe_div_func_uint32_t_u_u(((4L >= p_48) , g_178), 4294967289UL)) , l_233[4][1][0]) != l_235) ^ l_149) != 9UL)) | p_48), 9UL))) <= p_48), l_237)) ^ 0UL)), 0x43D3039AL)))) , p_48));
                        if ((*l_134))
                            break;
                        return p_48;
                    }
                    else
                    { /* block id: 90 */
                        int16_t ***l_241 = &l_209;
                        int16_t ****l_242[9] = {(void*)0,(void*)0,&l_208,(void*)0,(void*)0,&l_208,(void*)0,(void*)0,&l_208};
                        int32_t l_259[9][1] = {{(-9L)},{(-9L)},{0x67CE192BL},{(-9L)},{(-9L)},{0x67CE192BL},{(-9L)},{(-9L)},{0x67CE192BL}};
                        int i, j;
                        (*g_125) &= (-5L);
                        if ((*g_125))
                            break;
                        (**g_135) = ((((safe_sub_func_uint32_t_u_u(((l_243 = l_241) == l_245[0]), 0x4C5BC5EBL)) , &g_28) != (((safe_lshift_func_uint16_t_u_u((((safe_mul_func_int8_t_s_s(((**l_145) = ((safe_rshift_func_uint16_t_u_u(g_194.f0, ((g_2 | ((((safe_mul_func_uint8_t_u_u(((((safe_unary_minus_func_int16_t_s(((safe_lshift_func_uint16_t_u_u(g_54, l_259[6][0])) < p_48))) == (**g_205)) | g_178) , g_97[1]), p_48)) == (-1L)) && p_48) || p_48)) , 65526UL))) == g_11[(g_62 + 3)][(l_149 + 2)][g_54])), g_11[(l_149 + 1)][(g_62 + 2)][l_158])) , 1L) & g_92), 9)) < p_48) , &g_206)) <= (*l_134));
                        return l_149;
                    }
                }
            }
        }
        for (g_178 = 3; (g_178 >= 0); g_178 -= 1)
        { /* block id: 103 */
            uint64_t l_260[4] = {0x973DCB5AACB81C1DLL,0x973DCB5AACB81C1DLL,0x973DCB5AACB81C1DLL,0x973DCB5AACB81C1DLL};
            int32_t **l_261 = &g_125;
            int16_t *l_265 = &g_92;
            const uint16_t *l_274 = &g_275[2];
            const uint16_t **l_273[8][1][8] = {{{&l_274,(void*)0,&l_274,(void*)0,&l_274,&l_274,&l_274,&l_274}},{{(void*)0,&l_274,&l_274,(void*)0,&l_274,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,(void*)0,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274}},{{&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274,&l_274}}};
            int64_t *l_278 = (void*)0;
            int16_t *l_283 = &g_284;
            int64_t *l_285 = &g_286;
            int32_t l_346 = (-1L);
            int32_t l_352 = 0xCDE5C421L;
            int32_t l_354 = 1L;
            int32_t l_355[1][6][10] = {{{0x748A7D60L,0xF862F7F5L,0xEE490E6CL,0x0B452CE8L,0xA687B620L,0x0E7CF8B9L,0x64D1F370L,0x0E7CF8B9L,0xA687B620L,0x0B452CE8L},{0x748A7D60L,0x0E7CF8B9L,0x748A7D60L,(-1L),(-9L),0x64D1F370L,0x0B452CE8L,4L,0xEE490E6CL,0L},{0x64D1F370L,0x0B452CE8L,4L,0xEE490E6CL,0L,0L,0xEE490E6CL,4L,0x0B452CE8L,0x64D1F370L},{0x6FD94D4FL,0x44009106L,0x748A7D60L,0xF862F7F5L,0xEE490E6CL,0x0B452CE8L,0xA687B620L,0x0E7CF8B9L,0x64D1F370L,0x0E7CF8B9L},{(-1L),0x748A7D60L,0xEE490E6CL,0x44009106L,0xEE490E6CL,0x748A7D60L,(-1L),0L,0L,0x64D1F370L},{0xEE490E6CL,0xA687B620L,0L,4L,0L,(-9L),0xF862F7F5L,0xF862F7F5L,(-9L),0L}}};
            int8_t l_394 = (-1L);
            int64_t l_460 = (-1L);
            union U1 *l_474 = (void*)0;
            int i, j, k;
            (*l_134) ^= l_260[2];
            (*l_261) = &l_158;
            if (g_54)
                goto lbl_262;
            if ((((*l_285) = (safe_div_func_int16_t_s_s(((*l_265) = (l_149 = ((**l_261) = p_48))), ((*l_283) |= (((safe_lshift_func_int16_t_s_u(((l_268 <= g_97[3]) , ((((safe_div_func_int16_t_s_s(((safe_mod_func_int32_t_s_s(((((g_191 , ((g_276 = &p_48) == (((((*l_134) = 0xCC754962DFEED02CLL) >= p_48) , (safe_sub_func_uint64_t_u_u((*l_134), ((((((g_281 , p_48) , p_48) ^ l_282) ^ (*g_206)) , 0xF62DL) == p_48)))) , &g_277))) , g_151) ^ 0x3A83041FB209ACC2LL) || (*g_276)), p_48)) , l_268), l_268)) && p_48) >= 0x5E57BF45L) >= 1L)), p_48)) , l_268) , 8L))))) & g_275[2]))
            { /* block id: 114 */
                uint64_t *l_288 = &l_268;
                uint64_t **l_287 = &l_288;
                int32_t l_332 = 0L;
                int32_t l_348[6] = {(-4L),0xBCF66C92L,(-4L),(-4L),0xBCF66C92L,(-4L)};
                int32_t l_366 = (-5L);
                int16_t l_387 = 0L;
                int8_t **l_389 = &l_121;
                int8_t *l_392 = &g_393;
                uint16_t l_399[5][1][10] = {{{0x3B24L,0x20A3L,5UL,1UL,0x5B73L,0x3B24L,0x3B24L,0x5B73L,1UL,5UL}},{{0x20A3L,0x20A3L,0UL,0x113FL,0x5B73L,0UL,0x20A3L,0x5B73L,0x1D01L,0x5B73L}},{{0x20A3L,0x3B24L,5UL,0x113FL,5UL,0x3B24L,0x20A3L,5UL,1UL,0x5B73L}},{{0x3B24L,0x20A3L,5UL,1UL,0x5B73L,0x3B24L,0x3B24L,0x5B73L,1UL,5UL}},{{0x20A3L,0x20A3L,0UL,0x113FL,0x5B73L,0UL,0x20A3L,0x5B73L,0x1D01L,0x5B73L}}};
                int16_t * const *l_419 = &l_115;
                int16_t * const * const *l_418 = &l_419;
                int16_t * const * const **l_417 = &l_418;
                uint32_t l_461 = 0x4E239630L;
                int i, j, k;
                (**l_261) = ((-5L) && 0xFAE3L);
                if ((((*l_287) = &g_165) == &l_268))
                { /* block id: 117 */
                    int16_t l_295 = 6L;
                    (*g_125) ^= (l_145 == (g_289 , l_145));
                    for (g_194.f3 = 0; (g_194.f3 <= 3); g_194.f3 += 1)
                    { /* block id: 121 */
                        (*g_210) = ((*l_243) = &g_213);
                    }
                    for (g_165 = 0; (g_165 <= 3); g_165 += 1)
                    { /* block id: 127 */
                        int16_t ***l_294 = &l_244;
                        union U1 *l_297[6][6] = {{&g_289,(void*)0,(void*)0,&g_289,&g_289,&g_289},{(void*)0,&g_289,&g_289,(void*)0,&g_289,&g_289},{&g_289,(void*)0,(void*)0,&g_289,&g_289,(void*)0},{&g_289,(void*)0,&g_289,&g_289,&g_289,&g_289},{&g_289,&g_289,&g_289,(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289,&g_289,(void*)0,&g_289}};
                        union U1 **l_296 = &l_297[4][5];
                        union U1 **l_300 = &g_299[5][0][0];
                        int i, j, k;
                        if (g_11[(g_165 + 2)][g_54][g_178])
                            break;
                        l_295 = (safe_lshift_func_int16_t_s_u((safe_rshift_func_uint8_t_u_u(0x90L, 3)), (g_11[(g_178 + 3)][(g_165 + 1)][g_165] , (l_294 != (void*)0))));
                        (*l_300) = ((*l_296) = &g_289);
                    }
                    if (p_48)
                        continue;
                }
                else
                { /* block id: 134 */
                    union U1 *l_311 = &g_289;
                    for (l_158 = 3; (l_158 >= 0); l_158 -= 1)
                    { /* block id: 137 */
                        int32_t ***l_312 = &l_261;
                        int i, j, k;
                        (*l_134) ^= (0x0150L < (((safe_lshift_func_uint16_t_u_u(g_11[(g_54 + 2)][(g_178 + 4)][g_54], (g_303 <= (g_194 , ((*l_265) = ((safe_mul_func_int16_t_s_s(l_306, (((((safe_div_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(((&p_48 != (void*)0) && 0L), (((p_48 < p_48) >= 0xE397L) , p_48))), (*g_206))) ^ g_11[(g_54 + 2)][(g_178 + 4)][g_54]) > g_303) , (void*)0) != l_311))) > 1UL)))))) > 1L) != g_284));
                        (*l_312) = &g_125;
                    }
                }
                if ((safe_mul_func_int16_t_s_s(p_48, (safe_add_func_int8_t_s_s(((safe_add_func_int8_t_s_s((*g_206), (p_48 , p_48))) == (((*l_134) |= ((safe_div_func_int64_t_s_s((((safe_div_func_int64_t_s_s((safe_mod_func_uint8_t_u_u(g_174[2], (safe_div_func_uint8_t_u_u((g_329 , ((void*)0 == l_330)), g_165)))), p_48)) , g_275[2]) , g_286), 18446744073709551614UL)) , (**g_130))) > 1UL)), l_332)))))
                { /* block id: 144 */
                    int8_t l_333 = 7L;
                    int32_t l_336 = 0L;
                    int32_t l_349 = 1L;
                    int32_t l_350 = 0x59288803L;
                    int32_t l_351[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_351[i] = 0xA41679F9L;
                    for (g_165 = 0; (g_165 <= 3); g_165 += 1)
                    { /* block id: 147 */
                        int32_t *l_334 = &g_97[3];
                        int32_t *l_335 = &g_97[3];
                        int32_t *l_337 = (void*)0;
                        int32_t *l_338 = &l_336;
                        int32_t *l_339 = &g_97[0];
                        int32_t *l_340 = (void*)0;
                        int32_t *l_341 = (void*)0;
                        int32_t *l_342 = &l_149;
                        int32_t *l_343 = &g_62;
                        int32_t *l_344 = (void*)0;
                        int32_t *l_345[6][3][1] = {{{(void*)0},{&l_336},{(void*)0}},{{&l_336},{(void*)0},{&l_336}},{{(void*)0},{&l_336},{(void*)0}},{{&l_336},{(void*)0},{&l_336}},{{(void*)0},{&l_336},{(void*)0}},{{&l_336},{(void*)0},{&l_336}}};
                        int8_t **l_388[3][8] = {{&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121},{&l_121,&l_121,(void*)0,&l_121,&l_121,(void*)0,&l_121,&l_121},{&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121,&l_121}};
                        int8_t *l_391 = &l_333;
                        int8_t **l_390[4][2][8] = {{{&l_391,&l_121,(void*)0,(void*)0,&l_121,&l_391,&l_121,&l_391},{&l_121,&l_391,&l_121,&l_391,&l_121,(void*)0,(void*)0,&l_121}},{{&l_391,(void*)0,(void*)0,&l_391,&l_391,&l_121,&l_391,&l_391},{(void*)0,&l_391,(void*)0,(void*)0,&l_121,&l_121,(void*)0,(void*)0}},{{&l_391,&l_391,&l_121,&l_121,&l_391,&l_121,&l_121,&l_391},{&l_391,(void*)0,(void*)0,&l_121,&l_121,(void*)0,(void*)0,&l_391}},{{(void*)0,&l_391,&l_391,&l_121,&l_391,&l_391,(void*)0,(void*)0},{&l_391,&l_121,(void*)0,(void*)0,&l_121,&l_391,&l_121,&l_391}}};
                        int i, j, k;
                        --l_356[1];
                        if (l_349)
                            continue;
                        if (l_149)
                            goto lbl_499;
                        (**l_330) = func_63((*g_212), ((safe_add_func_uint64_t_u_u((((~((safe_lshift_func_uint16_t_u_s((((safe_lshift_func_uint8_t_u_u(l_366, 4)) , 18446744073709551614UL) , (((*l_342) = (l_349 |= (*g_125))) | (safe_add_func_int16_t_s_s((safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((safe_rshift_func_int8_t_s_u((safe_mod_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((((safe_lshift_func_int8_t_s_u(((**l_234) = ((~(+(**g_205))) == (l_387 == p_48))), 1)) , l_388[1][2]) != (l_390[3][1][6] = l_389)), 0x49L)), 0xCFL)), (*l_134))), (***l_330))) , (*l_134)), p_48)), 0)), p_48)), p_48)))), 5)) <= p_48)) ^ l_333) == 1L), (-1L))) >= 0UL), l_392, (**l_261), l_394);
                    }
                    for (g_303 = 0; (g_303 <= 3); g_303 += 1)
                    { /* block id: 158 */
                        int32_t *l_395[5][9] = {{&l_149,&l_349,(void*)0,&l_149,&l_348[1],&l_149,&l_149,&l_348[1],&l_149},{&l_149,&l_351[4],(void*)0,(void*)0,&l_351[4],&l_149,&g_97[2],&l_348[1],(void*)0},{&l_149,&l_348[1],&l_149,(void*)0,&l_349,&l_149,&l_149,&l_349,(void*)0},{&g_2,&l_351[4],&g_2,&l_149,&l_349,&g_2,&g_97[2],&l_348[1],&l_149},{&g_2,&l_349,&l_149,&g_2,&l_351[4],&g_2,&l_149,&l_349,&g_2}};
                        int i, j;
                        l_399[3][0][9]--;
                        if (p_48)
                            break;
                        (*l_134) = (safe_add_func_uint64_t_u_u(0x0B3FAAC7D03E1FDALL, p_48));
                        if (p_48)
                            break;
                    }
                }
                else
                { /* block id: 164 */
                    uint32_t l_404 = 18446744073709551615UL;
                    int16_t ****l_421[10][3][1] = {{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}},{{&l_243},{&l_243},{&l_243}}};
                    int16_t *****l_422 = &l_421[0][1][0];
                    int i, j, k;
                    (*l_331) = (p_48 , func_63(l_404, (safe_sub_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(((safe_sub_func_int16_t_s_s((((((*l_134) < l_404) , l_150) == ((*l_244) = (g_413 , &g_284))) == ((safe_unary_minus_func_int8_t_s(0xD4L)) , ((***l_330) = (((safe_mod_func_int32_t_s_s((*l_134), (*g_125))) == p_48) , (*g_125))))), p_48)) , p_48), p_48)), 0L)) != 0x0F31F02A5E1613AELL), p_48)), &g_29, l_348[1], p_48));
                    (*l_134) = ((g_420 = l_417) != ((*l_422) = l_421[0][1][0]));
                    for (l_353 = 3; (l_353 >= 0); l_353 -= 1)
                    { /* block id: 173 */
                        int32_t l_423 = 1L;
                        (*l_134) = 1L;
                        if (l_423)
                            continue;
                        if (p_48)
                            break;
                    }
                }
                for (g_58 = 3; (g_58 >= 0); g_58 -= 1)
                { /* block id: 181 */
                    int32_t *l_424 = &g_62;
                    int32_t *l_425 = &l_348[1];
                    int32_t *l_426 = &l_355[0][2][9];
                    int32_t *l_427 = &l_354;
                    int32_t *l_428 = &l_366;
                    int32_t *l_429[2][10] = {{&l_332,&g_62,&l_332,&g_62,&l_332,&g_62,&l_332,&g_62,&l_332,&g_62},{&l_332,&g_62,&l_332,&g_62,&l_332,&g_62,&l_332,&g_62,&l_332,&g_62}};
                    uint8_t l_432 = 1UL;
                    int32_t ****l_436[5] = {&l_330,&l_330,&l_330,&l_330,&l_330};
                    uint64_t *l_438 = &g_165;
                    int i, j;
                    ++l_432;
                    if ((((p_48 != (!((**l_145) = (((*l_134) = (-1L)) ^ (p_48 , ((((g_437 = (void*)0) != (void*)0) > (l_387 <= ((void*)0 != l_438))) <= (**l_261))))))) && g_58) || 5UL))
                    { /* block id: 186 */
                        return p_48;
                    }
                    else
                    { /* block id: 188 */
                        union U1 **l_440 = (void*)0;
                        union U1 *l_441 = &g_289;
                        uint32_t *l_458 = &g_459;
                        l_441 = l_439;
                        (*l_425) = ((*l_134) = ((safe_sub_func_int64_t_s_s((g_174[2] >= p_48), (((safe_lshift_func_int8_t_s_u((safe_div_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_u((0x6FB4B6336E1642DFLL < 0xA4E22AA32CBFFB4BLL), 15)) == p_48), ((*l_134) && (((*l_458) = (+(safe_mod_func_uint64_t_u_u(((safe_rshift_func_int8_t_s_u(((*l_392) = ((((**l_389) = (l_441 != ((l_457 <= ((**l_261) ^ 0xE18071D578C2FD50LL)) , l_439))) == p_48) & 1UL)), 5)) | p_48), g_51)))) != p_48)))), l_332)) <= (*g_276)) == l_460))) , p_48));
                        l_461++;
                        (*l_426) = ((((*l_285) = p_48) == (252UL != (*l_134))) & (safe_div_func_int16_t_s_s(((-1L) ^ l_466), (safe_sub_func_uint16_t_u_u((((g_469[0][0] , (safe_add_func_uint32_t_u_u((g_472 , p_48), p_48))) >= l_473[0][0]) > p_48), l_387)))));
                    }
                }
            }
            else
            { /* block id: 200 */
                (*g_475) = l_474;
                return p_48;
            }
            for (l_394 = 3; (l_394 >= 0); l_394 -= 1)
            { /* block id: 206 */
                int16_t l_498[6] = {6L,6L,6L,6L,6L,6L};
                int i;
                (**l_330) = l_476;
                for (g_92 = 3; (g_92 >= 0); g_92 -= 1)
                { /* block id: 210 */
                    uint8_t *l_490[4][3][9] = {{{&l_356[3],&l_356[1],&l_356[1],&l_356[1],&l_356[1],&l_356[0],&l_356[1],&l_356[1],&l_356[1]},{&l_356[1],&l_356[1],&l_356[1],&l_356[4],&l_356[6],(void*)0,&l_356[1],&l_356[1],&l_356[1]},{&l_356[5],&l_356[6],&l_356[1],(void*)0,&l_356[2],(void*)0,&l_356[1],(void*)0,&l_356[1]}},{{&l_356[6],(void*)0,&l_356[1],&l_356[6],(void*)0,&l_356[1],&l_356[1],&l_356[2],&l_356[3]},{&l_356[1],&l_356[6],&l_356[1],&l_356[1],(void*)0,&l_356[1],&l_356[1],&l_356[5],&l_356[6]},{&l_356[1],&l_356[1],&l_356[1],&l_356[1],(void*)0,&l_356[1],&l_356[1],&l_356[1],&l_356[1]}},{{&l_356[2],(void*)0,&l_356[5],&l_356[5],(void*)0,&l_356[2],&l_356[1],&l_356[3],&l_356[1]},{(void*)0,&l_356[1],&l_356[1],&l_356[2],&l_356[2],&l_356[1],&l_356[1],(void*)0,&l_356[5]},{&l_356[1],&l_356[1],&l_356[1],&l_356[0],&l_356[6],&l_356[2],&l_356[1],&l_356[1],&l_356[2]}},{{&l_356[1],(void*)0,&l_356[1],&l_356[6],&l_356[1],&l_356[6],&l_356[1],&l_356[1],(void*)0},{&l_356[6],&l_356[1],&l_356[1],&l_356[3],&l_356[4],&l_356[5],&l_356[1],&l_356[2],(void*)0},{(void*)0,&l_356[2],&l_356[1],&l_356[1],&l_356[1],&l_356[1],&l_356[1],&l_356[1],&l_356[2]}}};
                    int i, j, k;
                    (**l_330) = (*g_135);
                    (*l_134) = (((safe_lshift_func_uint16_t_u_s((g_62 != (((p_48 || (safe_unary_minus_func_int16_t_s(((safe_add_func_uint32_t_u_u(0xAA1D81B0L, ((p_48 < (safe_rshift_func_uint8_t_u_s((g_11[(g_92 + 2)][g_54][g_92]++), (((**l_261) , (safe_mod_func_int8_t_s_s((**l_331), (g_491[0]--)))) , (safe_add_func_int32_t_s_s((**g_135), ((g_97[3] & (l_498[3] = ((safe_div_func_uint8_t_u_u(((**l_261) , g_92), 7L)) , p_48))) , 0xB21BCFB3L))))))) > p_48))) && p_48)))) < p_48) != g_165)), p_48)) , p_48) & p_48);
                }
            }
        }
    }
    (*l_476) = (*l_476);
    return p_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static int32_t * func_63(int16_t  p_64, uint8_t  p_65, int8_t * p_66, const uint64_t  p_67, int8_t  p_68)
{ /* block id: 31 */
    uint64_t l_122 = 1UL;
    l_122 |= g_11[1][6][3];
    return &g_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_61 g_11 g_57 g_29 g_62
 * writes: g_97
 */
static const int8_t  func_69(int8_t  p_70, uint32_t  p_71, uint32_t  p_72)
{ /* block id: 23 */
    uint16_t l_83 = 1UL;
    int16_t l_90 = (-9L);
    int16_t *l_91[8][7] = {{&g_92,&g_92,&g_92,&g_92,&g_92,&g_92,&g_92},{&l_90,&l_90,&l_90,&l_90,&l_90,&l_90,&l_90},{&g_92,&g_92,&g_92,&g_92,&g_92,&g_92,&g_92},{&l_90,&l_90,&l_90,&l_90,&l_90,&l_90,&l_90},{&g_92,&g_92,&g_92,&g_92,&g_92,&g_92,&g_92},{&l_90,&l_90,&l_90,&l_90,&l_90,&l_90,&l_90},{&g_92,&g_92,&g_92,&g_92,&g_92,&g_92,&g_92},{&l_90,&l_90,&l_90,&l_90,&l_90,&l_90,&l_90}};
    int32_t l_93 = 4L;
    int32_t *l_95 = &g_54;
    int32_t **l_94 = &l_95;
    int32_t *l_96 = &g_97[3];
    int32_t l_98 = 0xBAF72093L;
    int32_t *l_99 = (void*)0;
    int32_t *l_100 = &g_97[3];
    int32_t *l_101 = &g_97[3];
    int32_t *l_102 = (void*)0;
    int32_t *l_103 = &g_97[0];
    int32_t *l_104 = &g_97[3];
    int32_t *l_105 = (void*)0;
    int32_t *l_106 = (void*)0;
    int32_t *l_107[1][2];
    int32_t l_108 = 6L;
    uint16_t l_110[2][3][1];
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_107[i][j] = (void*)0;
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
                l_110[i][j][k] = 65535UL;
        }
    }
    (*l_96) = (((*l_94) = (((p_70 <= ((void*)0 == &g_29)) , ((safe_lshift_func_uint16_t_u_s(((((safe_mod_func_int16_t_s_s((l_93 |= (safe_rshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((g_61 , ((g_11[5][5][0] <= l_83) , ((((0x39L >= ((((safe_add_func_uint64_t_u_u((((l_83 == (safe_div_func_int32_t_s_s((((l_83 || g_57) , (void*)0) == (void*)0), 0x9E808E27L))) >= p_72) < l_90), p_72)) <= l_83) , p_72) >= p_70)) | l_90) == l_90) , g_29))), g_62)), 0UL)), l_90))), g_62)) != 2L) > l_90) > 0UL), l_83)) || p_72)) , &l_93)) != &g_58);
    (*l_94) = (void*)0;
    --l_110[0][1][0];
    return p_72;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_11[i][j][k], "g_11[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_97[i], "g_97[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_109, "g_109", print_hash_value);
    transparent_crc(g_136.f0, "g_136.f0", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_165, "g_165", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_174[i], "g_174[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_191.f0, "g_191.f0", print_hash_value);
    transparent_crc(g_194.f0, "g_194.f0", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_275[i], "g_275[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_277, "g_277", print_hash_value);
    transparent_crc(g_281.f0, "g_281.f0", print_hash_value);
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_286, "g_286", print_hash_value);
    transparent_crc(g_289.f0, "g_289.f0", print_hash_value);
    transparent_crc(g_303, "g_303", print_hash_value);
    transparent_crc(g_329.f0, "g_329.f0", print_hash_value);
    transparent_crc(g_393, "g_393", print_hash_value);
    transparent_crc(g_413.f0, "g_413.f0", print_hash_value);
    transparent_crc(g_459, "g_459", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_469[i][j].f0, "g_469[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_472.f0, "g_472.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_491[i], "g_491[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_574.f0, "g_574.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_585[i], "g_585[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_589.f0, "g_589.f0", print_hash_value);
    transparent_crc(g_786, "g_786", print_hash_value);
    transparent_crc(g_847.f0, "g_847.f0", print_hash_value);
    transparent_crc(g_882, "g_882", print_hash_value);
    transparent_crc(g_884, "g_884", print_hash_value);
    transparent_crc(g_929, "g_929", print_hash_value);
    transparent_crc(g_939.f0, "g_939.f0", print_hash_value);
    transparent_crc(g_1008.f0, "g_1008.f0", print_hash_value);
    transparent_crc(g_1011.f0, "g_1011.f0", print_hash_value);
    transparent_crc(g_1017.f0, "g_1017.f0", print_hash_value);
    transparent_crc(g_1032, "g_1032", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_1033[i][j][k], "g_1033[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1067[i], "g_1067[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1091[i].f0, "g_1091[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1097.f0, "g_1097.f0", print_hash_value);
    transparent_crc(g_1114, "g_1114", print_hash_value);
    transparent_crc(g_1122.f0, "g_1122.f0", print_hash_value);
    transparent_crc(g_1145, "g_1145", print_hash_value);
    transparent_crc(g_1147.f0, "g_1147.f0", print_hash_value);
    transparent_crc(g_1202, "g_1202", print_hash_value);
    transparent_crc(g_1271, "g_1271", print_hash_value);
    transparent_crc(g_1274, "g_1274", print_hash_value);
    transparent_crc(g_1318, "g_1318", print_hash_value);
    transparent_crc(g_1335, "g_1335", print_hash_value);
    transparent_crc(g_1448, "g_1448", print_hash_value);
    transparent_crc(g_1576, "g_1576", print_hash_value);
    transparent_crc(g_1616.f0, "g_1616.f0", print_hash_value);
    transparent_crc(g_1705.f0, "g_1705.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1734[i].f0, "g_1734[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1735[i][j][k].f0, "g_1735[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 396
XXX total union variables: 23

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 17
breakdown:
   indirect level: 0, occurrence: 13
   indirect level: 1, occurrence: 4
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 4
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 18
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 3

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 258
   depth: 2, occurrence: 61
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 4
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 5
   depth: 19, occurrence: 4
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 3
   depth: 26, occurrence: 5
   depth: 27, occurrence: 2
   depth: 28, occurrence: 5
   depth: 29, occurrence: 3
   depth: 30, occurrence: 1
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 3
   depth: 36, occurrence: 2
   depth: 39, occurrence: 1
   depth: 44, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 435

XXX times a variable address is taken: 1055
XXX times a pointer is dereferenced on RHS: 159
breakdown:
   depth: 1, occurrence: 121
   depth: 2, occurrence: 33
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
XXX times a pointer is dereferenced on LHS: 214
breakdown:
   depth: 1, occurrence: 197
   depth: 2, occurrence: 16
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 28
XXX times a pointer is compared with address of another variable: 5
XXX times a pointer is compared with another pointer: 7
XXX times a pointer is qualified to be dereferenced: 5358

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 948
   level: 2, occurrence: 252
   level: 3, occurrence: 49
   level: 4, occurrence: 28
   level: 5, occurrence: 2
   level: 6, occurrence: 2
XXX number of pointers point to pointers: 165
XXX number of pointers point to scalars: 253
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.5
XXX average alias set size: 1.49

XXX times a non-volatile is read: 1281
XXX times a non-volatile is write: 599
XXX times a volatile is read: 73
XXX    times read thru a pointer: 0
XXX times a volatile is write: 25
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4.01e+03
XXX percentage of non-volatile access: 95

XXX forward jumps: 2
XXX backward jumps: 3

XXX stmts: 254
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 17
   depth: 2, occurrence: 33
   depth: 3, occurrence: 38
   depth: 4, occurrence: 50
   depth: 5, occurrence: 84

XXX percentage a fresh-made variable is used: 16.6
XXX percentage an existing variable is used: 83.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

