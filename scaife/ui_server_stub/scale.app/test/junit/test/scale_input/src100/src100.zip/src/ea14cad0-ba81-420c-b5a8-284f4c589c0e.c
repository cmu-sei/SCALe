/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      966037137
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile signed f0 : 7;
   const volatile unsigned f1 : 2;
   signed f2 : 29;
   volatile signed f3 : 20;
   signed f4 : 21;
   signed f5 : 26;
   const unsigned f6 : 17;
   unsigned : 0;
   signed f7 : 3;
   signed f8 : 7;
};

#pragma pack(push)
#pragma pack(1)
struct S1 {
   signed f0 : 4;
};
#pragma pack(pop)

union U2 {
   volatile int32_t  f0;
   int8_t  f1;
   uint32_t  f2;
};

union U3 {
   volatile int8_t  f0;
   int32_t  f1;
   int32_t  f2;
};

union U4 {
   int32_t  f0;
};

union U5 {
   volatile uint16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 9L;
static int32_t g_6 = (-1L);
static int32_t g_14[1][10] = {{0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL,0x5BBBDEBFL}};
static struct S1 g_66[6] = {{0},{0},{0},{0},{0},{0}};
static struct S1 * volatile g_65 = &g_66[3];/* VOLATILE GLOBAL g_65 */
static int16_t g_73 = 1L;
static struct S1 g_81 = {3};
static struct S1 *g_80[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static uint16_t g_100 = 65533UL;
static uint32_t g_105 = 4UL;
static int32_t g_132 = (-4L);
static int8_t g_136 = 0xE1L;
static union U5 g_149 = {65528UL};/* VOLATILE GLOBAL g_149 */
static union U5 g_152 = {65532UL};/* VOLATILE GLOBAL g_152 */
static union U4 g_158 = {0x56CB911FL};
static uint8_t g_172 = 0x10L;
static union U2 g_177 = {1L};/* VOLATILE GLOBAL g_177 */
static const union U2 g_178[2][10] = {{{2L},{0x61EF6001L},{0x61EF6001L},{2L},{2L},{0x61EF6001L},{0x61EF6001L},{2L},{2L},{0x61EF6001L}},{{2L},{2L},{0x61EF6001L},{0x61EF6001L},{2L},{2L},{0x61EF6001L},{0x61EF6001L},{2L},{2L}}};
static int8_t g_185[8] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
static uint8_t g_186[4][7][7] = {{{0x6CL,0xA3L,0x9FL,1UL,0UL,4UL,0x73L},{0x44L,0xFBL,2UL,0x05L,3UL,255UL,0UL},{0xB1L,8UL,1UL,1UL,254UL,0UL,0x9FL},{0x68L,0UL,253UL,8UL,0xFBL,0x23L,3UL},{0xA3L,254UL,0x6FL,0xDEL,2UL,2UL,0xDEL},{0xFCL,0xDCL,0xFCL,0xA2L,0x0CL,0x08L,0x26L},{2UL,0x6FL,0xB1L,1UL,0x21L,0UL,8UL}},{{0x04L,251UL,3UL,0xFBL,1UL,0x08L,0x59L},{1UL,248UL,0x22L,0xA3L,1UL,2UL,0UL},{0x62L,255UL,0x59L,3UL,255UL,0x23L,0x23L},{0UL,0x56L,0UL,0x56L,0UL,0UL,1UL},{0x0CL,0xFBL,0x05L,0x23L,0xDCL,255UL,0x44L},{0x6FL,0UL,0UL,4UL,1UL,4UL,1UL},{0x0CL,0x23L,255UL,1UL,0x05L,0x68L,0x42L}},{{0UL,0x73L,4UL,2UL,250UL,0x56L,1UL},{0x62L,0xACL,255UL,2UL,255UL,0xACL,0x62L},{1UL,0UL,0xF1L,0x00L,248UL,249UL,0x22L},{0x04L,0xFEL,0x26L,0xFCL,0x08L,3UL,0xACL},{2UL,0xB3L,0xF1L,0UL,0xDEL,0UL,255UL},{0xFCL,2UL,255UL,0x59L,255UL,0x26L,5UL},{0xA3L,0UL,4UL,1UL,4UL,1UL,4UL}},{{0x68L,0x68L,255UL,0xFEL,0x62L,5UL,0xFCL},{0xB1L,249UL,0UL,4UL,0UL,0xC2L,254UL},{0x44L,0x6CL,0x05L,0xDCL,0x62L,0x04L,255UL},{0x6CL,0x00L,0UL,0xB1L,4UL,0x22L,0x56L},{251UL,0x0CL,0x59L,0xFBL,255UL,0UL,255UL},{0UL,0x22L,0x22L,0UL,0xDEL,4UL,0xB3L},{0x42L,0xA2L,2UL,0x62L,255UL,2UL,3UL}}};
static volatile int32_t g_191 = 0xE21FB040L;/* VOLATILE GLOBAL g_191 */
static volatile int32_t *g_190 = &g_191;
static volatile int32_t * volatile *g_189 = &g_190;
static uint64_t g_197 = 0x12F6A2AC77CF8A12LL;
static int16_t g_203 = 0xE830L;
static uint64_t g_205 = 8UL;
static uint32_t g_208 = 5UL;
static union U5 g_220 = {0xAF0AL};/* VOLATILE GLOBAL g_220 */
static union U5 *g_219 = &g_220;
static union U5 **g_218[2][2][5] = {{{&g_219,&g_219,&g_219,&g_219,&g_219},{&g_219,(void*)0,&g_219,(void*)0,&g_219}},{{&g_219,&g_219,&g_219,&g_219,&g_219},{&g_219,(void*)0,&g_219,(void*)0,&g_219}}};
static int64_t g_234[1][4][2] = {{{0L,(-1L)},{(-1L),0L},{(-1L),(-1L)},{0L,(-1L)}}};
static struct S0 g_259 = {0,0,-6573,811,-1217,6345,70,-1,1};/* VOLATILE GLOBAL g_259 */
static struct S0 g_278 = {-5,0,-8587,-279,-791,-282,253,0,0};/* VOLATILE GLOBAL g_278 */
static struct S0 *g_277 = &g_278;
static int16_t * const g_285 = &g_203;
static int16_t * const *g_284 = &g_285;
static struct S0 g_293 = {5,0,22422,747,-1063,-4766,87,-0,9};/* VOLATILE GLOBAL g_293 */
static union U2 g_305 = {0xF4A77C49L};/* VOLATILE GLOBAL g_305 */
static union U2 g_307 = {0xF359F1E0L};/* VOLATILE GLOBAL g_307 */
static union U2 g_308 = {0L};/* VOLATILE GLOBAL g_308 */
static union U2 g_309 = {0xEC70156CL};/* VOLATILE GLOBAL g_309 */
static union U2 g_310 = {0x1CDF39E8L};/* VOLATILE GLOBAL g_310 */
static union U2 g_311[4] = {{3L},{3L},{3L},{3L}};
static union U2 *g_306[4][9] = {{&g_310,(void*)0,&g_307,&g_311[0],&g_311[0],&g_307,(void*)0,&g_310,(void*)0},{&g_308,(void*)0,&g_307,&g_307,(void*)0,&g_308,&g_311[0],&g_308,(void*)0},{&g_308,(void*)0,(void*)0,&g_308,&g_310,(void*)0,&g_310,&g_308,(void*)0},{&g_310,&g_310,&g_311[0],(void*)0,&g_309,(void*)0,&g_311[0],&g_310,&g_310}};
static int32_t g_344 = 0x67176CBDL;
static int32_t *g_350 = &g_6;
static int16_t g_374 = (-4L);
static struct S0 g_381 = {10,0,-20053,-219,-314,-5495,108,1,4};/* VOLATILE GLOBAL g_381 */
static int64_t g_423[5] = {(-6L),(-6L),(-6L),(-6L),(-6L)};
static union U2 g_431 = {-8L};/* VOLATILE GLOBAL g_431 */
static union U3 g_444 = {0xC9L};/* VOLATILE GLOBAL g_444 */
static uint16_t *g_446 = &g_100;
static uint16_t g_483 = 0x4608L;
static const union U2 *** const g_508 = (void*)0;
static const union U2 *** const  volatile *g_507 = &g_508;
static int32_t g_511 = 0L;
static union U3 g_535 = {0xB3L};/* VOLATILE GLOBAL g_535 */
static union U3 g_536 = {-5L};/* VOLATILE GLOBAL g_536 */
static union U3 g_537 = {0x9AL};/* VOLATILE GLOBAL g_537 */
static volatile union U3 *g_538 = (void*)0;
static union U2 g_546 = {1L};/* VOLATILE GLOBAL g_546 */
static struct S1 * const  volatile g_647[2][2][5] = {{{(void*)0,&g_66[5],(void*)0,&g_66[5],(void*)0},{&g_66[3],&g_66[3],&g_66[3],&g_66[3],&g_66[3]}},{{&g_66[3],&g_66[5],&g_66[3],&g_66[5],&g_66[3]},{&g_66[3],&g_66[3],&g_66[3],&g_66[3],&g_66[3]}}};
static struct S1 * volatile g_648 = &g_66[3];/* VOLATILE GLOBAL g_648 */
static struct S1 * volatile g_689[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile union U5 g_695 = {0xA9B2L};/* VOLATILE GLOBAL g_695 */
static union U5 g_707 = {0xEAA4L};/* VOLATILE GLOBAL g_707 */
static volatile union U3 g_722[4] = {{0x00L},{0x00L},{0x00L},{0x00L}};
static volatile union U5 g_724 = {0x5B71L};/* VOLATILE GLOBAL g_724 */
static int16_t *g_732 = &g_374;
static int16_t ** const g_731 = &g_732;
static int16_t ** const *g_730[6][2][5] = {{{&g_731,&g_731,&g_731,(void*)0,&g_731},{(void*)0,&g_731,&g_731,&g_731,(void*)0}},{{(void*)0,&g_731,&g_731,&g_731,&g_731},{&g_731,&g_731,&g_731,(void*)0,&g_731}},{{(void*)0,&g_731,&g_731,&g_731,(void*)0},{(void*)0,&g_731,&g_731,&g_731,&g_731}},{{&g_731,&g_731,&g_731,(void*)0,&g_731},{(void*)0,&g_731,&g_731,&g_731,(void*)0}},{{(void*)0,&g_731,&g_731,&g_731,&g_731},{&g_731,&g_731,&g_731,(void*)0,&g_731}},{{(void*)0,&g_731,&g_731,&g_731,(void*)0},{(void*)0,&g_731,&g_731,&g_731,&g_731}}};
static const volatile union U2 g_824 = {1L};/* VOLATILE GLOBAL g_824 */
static const int32_t *g_841 = &g_14[0][3];
static volatile struct S0 g_842 = {3,1,-12192,208,64,-7222,23,0,-3};/* VOLATILE GLOBAL g_842 */
static int64_t g_861 = 8L;
static uint16_t g_865 = 1UL;
static volatile union U5 g_900 = {1UL};/* VOLATILE GLOBAL g_900 */
static union U2 g_920 = {0x14D030DEL};/* VOLATILE GLOBAL g_920 */
static volatile struct S0 g_953[9][4] = {{{7,0,15197,430,-1385,-1202,314,-0,8},{10,1,19994,738,-994,6180,325,1,-2},{7,0,15197,430,-1385,-1202,314,-0,8},{7,0,15197,430,-1385,-1202,314,-0,8}},{{10,1,19994,738,-994,6180,325,1,-2},{10,1,19994,738,-994,6180,325,1,-2},{0,0,-771,524,-979,-7081,59,0,2},{10,1,19994,738,-994,6180,325,1,-2}},{{10,1,19994,738,-994,6180,325,1,-2},{7,0,15197,430,-1385,-1202,314,-0,8},{7,0,15197,430,-1385,-1202,314,-0,8},{10,1,19994,738,-994,6180,325,1,-2}},{{7,0,15197,430,-1385,-1202,314,-0,8},{10,1,19994,738,-994,6180,325,1,-2},{7,0,15197,430,-1385,-1202,314,-0,8},{7,0,15197,430,-1385,-1202,314,-0,8}},{{10,1,19994,738,-994,6180,325,1,-2},{10,1,19994,738,-994,6180,325,1,-2},{0,0,-771,524,-979,-7081,59,0,2},{7,0,15197,430,-1385,-1202,314,-0,8}},{{7,0,15197,430,-1385,-1202,314,-0,8},{0,0,-771,524,-979,-7081,59,0,2},{0,0,-771,524,-979,-7081,59,0,2},{7,0,15197,430,-1385,-1202,314,-0,8}},{{0,0,-771,524,-979,-7081,59,0,2},{7,0,15197,430,-1385,-1202,314,-0,8},{0,0,-771,524,-979,-7081,59,0,2},{0,0,-771,524,-979,-7081,59,0,2}},{{7,0,15197,430,-1385,-1202,314,-0,8},{7,0,15197,430,-1385,-1202,314,-0,8},{10,1,19994,738,-994,6180,325,1,-2},{7,0,15197,430,-1385,-1202,314,-0,8}},{{7,0,15197,430,-1385,-1202,314,-0,8},{0,0,-771,524,-979,-7081,59,0,2},{0,0,-771,524,-979,-7081,59,0,2},{7,0,15197,430,-1385,-1202,314,-0,8}}};
static union U2 ** volatile g_985[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U2 ** volatile g_986 = &g_306[2][3];/* VOLATILE GLOBAL g_986 */
static const struct S0 *g_1008 = &g_259;
static const struct S0 **g_1007 = &g_1008;
static const struct S0 **g_1010 = &g_1008;
static volatile union U3 g_1015 = {0x85L};/* VOLATILE GLOBAL g_1015 */
static struct S1 * volatile g_1021 = (void*)0;/* VOLATILE GLOBAL g_1021 */
static uint16_t g_1025 = 1UL;
static const uint32_t g_1051 = 18446744073709551615UL;
static struct S1 * volatile g_1053 = &g_66[4];/* VOLATILE GLOBAL g_1053 */
static const int32_t g_1062 = 1L;
static const int32_t *g_1061[2][7][9] = {{{&g_1062,&g_1062,&g_1062,(void*)0,(void*)0,&g_1062,(void*)0,&g_1062,(void*)0},{&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,(void*)0},{(void*)0,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062},{&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,(void*)0,&g_1062,&g_1062},{&g_1062,&g_1062,(void*)0,(void*)0,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062},{&g_1062,(void*)0,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062},{&g_1062,(void*)0,(void*)0,&g_1062,(void*)0,(void*)0,&g_1062,&g_1062,(void*)0}},{{&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,(void*)0},{(void*)0,&g_1062,&g_1062,&g_1062,(void*)0,(void*)0,&g_1062,&g_1062,&g_1062},{&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,(void*)0,&g_1062,(void*)0},{&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,(void*)0},{&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,(void*)0,(void*)0},{&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,&g_1062},{&g_1062,&g_1062,&g_1062,&g_1062,&g_1062,(void*)0,&g_1062,&g_1062,&g_1062}}};
static const int32_t *g_1063 = (void*)0;
static union U2 g_1123 = {-1L};/* VOLATILE GLOBAL g_1123 */
static int32_t g_1125 = 0x197844F6L;
static union U4 *g_1128 = (void*)0;
static union U4 ** volatile g_1127 = &g_1128;/* VOLATILE GLOBAL g_1127 */
static uint32_t *g_1152 = (void*)0;
static volatile union U2 g_1159 = {0L};/* VOLATILE GLOBAL g_1159 */
static volatile uint64_t g_1167 = 2UL;/* VOLATILE GLOBAL g_1167 */
static volatile uint64_t g_1168[8] = {0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL,0x5693CB5BA6E02584LL};
static volatile uint64_t *g_1166[5] = {&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5],&g_1168[5]};
static volatile uint64_t **g_1165 = &g_1166[3];
static struct S0 **g_1221 = &g_277;
static struct S0 ***g_1220 = &g_1221;
static struct S0 ****g_1219[10] = {&g_1220,&g_1220,&g_1220,&g_1220,&g_1220,&g_1220,&g_1220,&g_1220,&g_1220,&g_1220};
static volatile struct S0 g_1237 = {10,1,-15953,-359,431,6599,357,-1,3};/* VOLATILE GLOBAL g_1237 */
static const struct S1 g_1267 = {-0};
static const struct S1 *g_1266[6][3][5] = {{{(void*)0,&g_1267,(void*)0,(void*)0,&g_1267},{&g_1267,(void*)0,&g_1267,&g_1267,&g_1267},{&g_1267,&g_1267,&g_1267,(void*)0,&g_1267}},{{&g_1267,(void*)0,&g_1267,&g_1267,&g_1267},{(void*)0,(void*)0,(void*)0,&g_1267,&g_1267},{&g_1267,&g_1267,&g_1267,(void*)0,(void*)0}},{{&g_1267,&g_1267,&g_1267,&g_1267,(void*)0},{&g_1267,&g_1267,&g_1267,(void*)0,&g_1267},{&g_1267,&g_1267,(void*)0,&g_1267,&g_1267}},{{&g_1267,(void*)0,&g_1267,(void*)0,&g_1267},{(void*)0,&g_1267,&g_1267,&g_1267,&g_1267},{&g_1267,&g_1267,&g_1267,(void*)0,&g_1267}},{{&g_1267,&g_1267,&g_1267,&g_1267,&g_1267},{&g_1267,&g_1267,&g_1267,&g_1267,&g_1267},{&g_1267,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1267,&g_1267,&g_1267,&g_1267,(void*)0},{(void*)0,(void*)0,&g_1267,&g_1267,&g_1267},{&g_1267,&g_1267,&g_1267,&g_1267,&g_1267}}};
static union U5 g_1312 = {0x858FL};/* VOLATILE GLOBAL g_1312 */
static union U3 g_1331[2] = {{3L},{3L}};
static union U2 g_1335[1][4][1] = {{{{1L}},{{0L}},{{1L}},{{0L}}}};
static volatile union U2 g_1339 = {3L};/* VOLATILE GLOBAL g_1339 */
static union U5 g_1373[3][6][10] = {{{{65535UL},{0UL},{0xF4FAL},{0UL},{0UL},{0UL},{65530UL},{0x13A0L},{0x84B2L},{0xE41DL}},{{6UL},{0UL},{0x57E2L},{65535UL},{0x46CCL},{0xE703L},{0x13A0L},{1UL},{65535UL},{1UL}},{{0xA2B9L},{7UL},{0x13A0L},{65529UL},{0x13A0L},{7UL},{0xA2B9L},{65535UL},{65528UL},{0x069BL}},{{0UL},{0xBAC1L},{0x84B2L},{65534UL},{1UL},{0xBA39L},{0x22C5L},{65535UL},{8UL},{65535UL}},{{0x613CL},{0xBAC1L},{65529UL},{65535UL},{0xFD23L},{0xB212L},{0xA2B9L},{0x069BL},{0UL},{5UL}},{{0x3344L},{7UL},{0xDDE4L},{0xE41DL},{1UL},{0x92F2L},{0x13A0L},{0x22C5L},{1UL},{0x0A56L}}},{{{0xFDCDL},{0UL},{7UL},{0x6F95L},{1UL},{65535UL},{65530UL},{6UL},{0xDDE4L},{65535UL}},{{0xA1D5L},{0UL},{1UL},{0x613CL},{65535UL},{0x7463L},{65535UL},{0UL},{0xE703L},{1UL}},{{3UL},{65535UL},{0x46CCL},{0x7463L},{0UL},{0x22C5L},{0xC928L},{1UL},{0x4E34L},{0xE93CL}},{{65535UL},{6UL},{0xAB5DL},{0x0A56L},{0xDDE4L},{65528UL},{0xF558L},{65535UL},{65535UL},{0xF558L}},{{0x57E2L},{0UL},{1UL},{1UL},{0UL},{0x57E2L},{0x0A56L},{0x613CL},{0UL},{0x84B2L}},{{1UL},{0x128CL},{0UL},{0xFDCDL},{0xBA39L},{0xE7A7L},{4UL},{0xEBB9L},{1UL},{0x6965L}}},{{{65532UL},{65535UL},{0xF558L},{0xB1F4L},{0xB212L},{0UL},{0x6965L},{0xBAC1L},{0x46CCL},{0x92F2L}},{{0UL},{0x6965L},{0xBAC1L},{0x46CCL},{0x92F2L},{65529UL},{0x069BL},{8UL},{65535UL},{1UL}},{{0x3DFBL},{0xF4FAL},{0x92F2L},{0xE703L},{65535UL},{0x46CCL},{3UL},{0x6CFFL},{65534UL},{1UL}},{{0x6965L},{0x13A0L},{0xAB5DL},{1UL},{0x7463L},{0x613CL},{0xC928L},{65535UL},{0xB212L},{0UL}},{{0x0A56L},{65535UL},{8UL},{65535UL},{0x22C5L},{0xBA39L},{1UL},{65534UL},{0x84B2L},{0xBAC1L}},{{0UL},{3UL},{0xB1F4L},{0xFBC7L},{65528UL},{1UL},{5UL},{65535UL},{5UL},{1UL}}}};
static union U5 g_1374[5][4] = {{{0x211BL},{0x29A9L},{0x211BL},{0x211BL}},{{0x29A9L},{0x29A9L},{65535UL},{0x29A9L}},{{0x29A9L},{0x211BL},{0x211BL},{0x29A9L}},{{0x211BL},{0x29A9L},{0x211BL},{0x211BL}},{{0x29A9L},{0x29A9L},{65535UL},{0x29A9L}}};
static int32_t g_1413 = 0xD852010CL;
static uint8_t g_1434 = 249UL;
static const union U3 g_1446 = {0xA2L};/* VOLATILE GLOBAL g_1446 */
static const union U3 *g_1445 = &g_1446;
static struct S0 g_1458[8] = {{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1},{10,1,14259,-851,-1028,1965,93,-1,1}};
static volatile union U2 g_1486 = {0x4E538FC5L};/* VOLATILE GLOBAL g_1486 */
static volatile union U5 g_1504 = {65527UL};/* VOLATILE GLOBAL g_1504 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_35(union U4  p_36, uint32_t  p_37, const int32_t * p_38, uint16_t  p_39, int32_t * p_40);
static union U4  func_41(const int32_t  p_42, int16_t  p_43, const uint64_t  p_44);
static int64_t  func_45(uint64_t  p_46);
static const uint8_t  func_49(uint32_t  p_50, int32_t * p_51);
static int32_t * func_52(uint8_t  p_53, int32_t * p_54, int32_t * p_55, int32_t * p_56);
static int32_t * func_57(uint16_t  p_58, int32_t  p_59, int32_t * p_60, int32_t * p_61);
static uint16_t  func_62(int64_t  p_63);
static int32_t * func_67(int8_t  p_68, int64_t  p_69, int8_t  p_70);
static struct S0 * func_76(uint32_t  p_77, int32_t  p_78, const int16_t  p_79);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_132 g_1486 g_446 g_100 g_284 g_285 g_203 g_259.f4 g_731 g_732 g_374 g_197 g_483 g_278.f1 g_259.f6 g_1504 g_1165 g_1166 g_1168 g_1167 g_344 g_190
 * writes: g_2 g_1434 g_14 g_197 g_205 g_423 g_306 g_191
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_13[10] = {0xB9L,0xB9L,(-5L),0xB9L,0xB9L,(-5L),0xB9L,0xB9L,(-5L),0xB9L};
    int32_t l_18 = 0xA0C844FCL;
    int32_t l_19 = 1L;
    int32_t l_20 = 1L;
    int32_t l_21 = 9L;
    int32_t l_22 = (-9L);
    int32_t l_23 = 1L;
    uint8_t l_24 = 1UL;
    int32_t l_1088 = (-5L);
    struct S1 l_1092 = {-1};
    uint32_t *l_1153 = &g_105;
    int16_t ***l_1160 = (void*)0;
    uint64_t *l_1164 = (void*)0;
    uint64_t **l_1163 = &l_1164;
    const int64_t l_1283 = 0L;
    const union U5 * const l_1311 = &g_1312;
    const uint32_t l_1338 = 2UL;
    struct S1 **l_1346[9][9][3] = {{{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],&g_80[3]},{(void*)0,&g_80[3],(void*)0},{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],&g_80[2],&g_80[3]},{&g_80[1],(void*)0,&g_80[3]},{&g_80[3],&g_80[3],(void*)0},{&g_80[2],&g_80[3],&g_80[2]}},{{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],(void*)0},{(void*)0,&g_80[3],&g_80[3]},{&g_80[1],&g_80[3],&g_80[2]},{&g_80[1],&g_80[3],&g_80[1]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[2],&g_80[3],&g_80[3]},{&g_80[1],&g_80[3],(void*)0},{(void*)0,(void*)0,&g_80[3]}},{{&g_80[3],&g_80[2],&g_80[1]},{&g_80[3],&g_80[3],(void*)0},{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],(void*)0},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],(void*)0},{&g_80[3],&g_80[3],&g_80[2]},{&g_80[3],&g_80[3],&g_80[3]},{(void*)0,&g_80[3],(void*)0}},{{&g_80[3],&g_80[3],&g_80[3]},{&g_80[1],&g_80[2],&g_80[3]},{(void*)0,(void*)0,&g_80[2]},{&g_80[3],&g_80[3],(void*)0},{&g_80[3],&g_80[2],&g_80[2]},{&g_80[3],&g_80[1],&g_80[3]},{&g_80[2],&g_80[3],&g_80[3]},{&g_80[2],&g_80[3],&g_80[3]},{&g_80[2],&g_80[2],&g_80[1]}},{{&g_80[3],&g_80[1],&g_80[0]},{&g_80[3],&g_80[2],&g_80[3]},{&g_80[3],(void*)0,&g_80[2]},{&g_80[3],(void*)0,&g_80[2]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[2],&g_80[3]},{&g_80[3],(void*)0,&g_80[3]},{&g_80[3],&g_80[3],&g_80[1]}},{{&g_80[3],&g_80[1],(void*)0},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[2],&g_80[1]},{&g_80[2],&g_80[3],&g_80[2]},{&g_80[2],&g_80[3],&g_80[3]},{&g_80[2],&g_80[3],&g_80[2]},{&g_80[3],&g_80[2],&g_80[1]},{&g_80[3],&g_80[2],&g_80[2]},{&g_80[3],(void*)0,&g_80[3]}},{{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[1],&g_80[3],(void*)0},{&g_80[3],&g_80[3],(void*)0},{(void*)0,&g_80[3],&g_80[3]},{&g_80[3],(void*)0,&g_80[3]},{&g_80[3],&g_80[2],&g_80[1]},{&g_80[3],&g_80[2],&g_80[1]},{&g_80[3],&g_80[3],(void*)0}},{{(void*)0,&g_80[3],&g_80[1]},{&g_80[3],&g_80[3],&g_80[3]},{&g_80[3],&g_80[2],&g_80[3]},{&g_80[3],&g_80[3],&g_80[3]},{(void*)0,&g_80[1],&g_80[1]},{&g_80[2],&g_80[3],&g_80[3]},{&g_80[3],(void*)0,&g_80[1]},{(void*)0,&g_80[2],&g_80[2]},{&g_80[3],&g_80[3],&g_80[2]}},{{&g_80[2],&g_80[3],&g_80[1]},{&g_80[1],(void*)0,&g_80[3]},{&g_80[3],(void*)0,&g_80[1]},{&g_80[3],&g_80[2],&g_80[3]},{(void*)0,&g_80[1],&g_80[3]},{&g_80[3],&g_80[2],&g_80[3]},{&g_80[1],&g_80[3],&g_80[1]},{(void*)0,&g_80[3],(void*)0},{&g_80[3],&g_80[1],&g_80[1]}}};
    union U5 *l_1372[5][3] = {{&g_1374[0][0],&g_1374[0][0],&g_1374[0][0]},{&g_1373[0][1][6],&g_1373[0][1][6],&g_1373[0][1][6]},{&g_1374[0][0],&g_1374[0][0],&g_1374[0][0]},{&g_1373[0][1][6],&g_1373[0][1][6],&g_1373[0][1][6]},{&g_1374[0][0],&g_1374[0][0],&g_1374[0][0]}};
    int16_t l_1377 = 1L;
    int16_t l_1389 = 0x109EL;
    int32_t l_1436 = 0x6B6C95D6L;
    int8_t l_1512[7][6][6] = {{{0x7EL,0L,1L,0x0EL,1L,1L},{0L,0x0EL,0xF8L,0xF8L,0x0EL,0L},{0xF8L,0x0EL,0L,0x2EL,1L,1L},{0L,0xD0L,0x0EL,0xD0L,0L,0xF8L},{0L,1L,0xD0L,1L,1L,1L},{1L,1L,1L,1L,0x0EL,1L}},{{0x7EL,1L,0xD0L,0xF8L,1L,0xF8L},{0x0EL,0x2EL,0x0EL,0L,1L,0L},{0xD0L,1L,0x7EL,0x0EL,0x0EL,0x7EL},{1L,1L,1L,0x0EL,1L,0L},{0xD0L,1L,0L,0L,0L,1L},{0x0EL,0xD0L,0L,0xF8L,1L,0L}},{{0x7EL,0xF8L,1L,1L,0xF8L,0x7EL},{1L,0xF8L,0x7EL,1L,1L,0L},{0L,0xD0L,0x0EL,0xD0L,0L,0xF8L},{0L,1L,0xD0L,1L,1L,1L},{1L,1L,1L,1L,0x0EL,1L},{0x7EL,1L,0xD0L,0xF8L,1L,0xF8L}},{{0x0EL,0x2EL,0x0EL,0L,1L,0L},{0xD0L,1L,0x7EL,0x0EL,0x0EL,0x7EL},{1L,1L,1L,0x0EL,1L,0L},{0xD0L,1L,0L,0L,0L,1L},{0x0EL,0xD0L,0L,0xF8L,1L,0L},{0x7EL,0xF8L,1L,1L,0xF8L,0x7EL}},{{1L,0xF8L,0x7EL,1L,1L,0L},{0L,0xD0L,0x0EL,0xD0L,0L,0xF8L},{0L,1L,0xD0L,1L,1L,1L},{1L,1L,1L,1L,0x0EL,1L},{0x7EL,1L,0xD0L,0xF8L,1L,0xF8L},{0x0EL,0x2EL,0x0EL,0L,1L,0L}},{{0xD0L,1L,0x7EL,0x0EL,0x0EL,0x7EL},{1L,1L,1L,0x0EL,1L,0L},{0xD0L,1L,0L,0L,0L,1L},{0x0EL,0xD0L,0L,0xF8L,1L,0L},{0x7EL,0xF8L,1L,1L,0xF8L,0x0EL},{1L,1L,0x0EL,1L,0L,0x7EL}},{{0x7EL,0x2EL,0xF8L,0x2EL,0x7EL,1L},{0x7EL,1L,0x2EL,1L,0L,0L},{1L,0L,0L,1L,0xF8L,0L},{0x0EL,0L,0x2EL,1L,1L,1L},{0xF8L,1L,0xF8L,0xD0L,1L,0x7EL},{0x2EL,0L,0x0EL,0xF8L,0xF8L,0x0EL}}};
    int i, j, k;
    for (g_2 = 0; (g_2 == (-2)); g_2 = safe_sub_func_uint64_t_u_u(g_2, 2))
    { /* block id: 3 */
        int32_t *l_5 = &g_6;
        int32_t *l_7 = &g_6;
        int32_t *l_8 = &g_6;
        int32_t *l_9 = &g_6;
        int32_t *l_10 = (void*)0;
        int32_t *l_11 = (void*)0;
        int32_t *l_12 = &g_6;
        int32_t *l_15 = &g_14[0][8];
        int32_t l_16 = 7L;
        int32_t *l_17[10][10] = {{&l_16,(void*)0,&g_14[0][8],&g_14[0][8],(void*)0,&l_16,(void*)0,&l_16,&g_14[0][8],&g_6},{(void*)0,&g_14[0][3],(void*)0,(void*)0,(void*)0,(void*)0,&g_14[0][8],&l_16,(void*)0,&g_2},{(void*)0,(void*)0,&l_16,&g_6,&g_6,&l_16,&g_2,&g_14[0][8],&g_14[0][8],(void*)0},{&l_16,&g_2,&g_14[0][8],&g_14[0][8],(void*)0,&g_14[0][3],&l_16,(void*)0,(void*)0,(void*)0},{&g_6,&g_6,&g_2,&g_14[0][3],&g_2,&g_6,&g_6,&g_14[0][8],&g_14[0][5],&l_16},{&g_14[0][8],&g_14[0][8],&l_16,&g_14[0][3],&g_6,&l_16,&g_14[0][3],(void*)0,&l_16,&g_14[0][8]},{(void*)0,&g_14[0][8],&g_14[0][7],&g_14[0][8],&g_14[0][3],&g_14[0][5],&g_6,&l_16,&l_16,&l_16},{(void*)0,&g_6,&g_6,&g_6,&g_6,&g_2,&l_16,(void*)0,&l_16,&l_16},{(void*)0,&g_2,&l_16,&l_16,&l_16,&l_16,&g_2,(void*)0,&g_6,&g_14[0][3]},{&g_14[0][8],(void*)0,(void*)0,&l_16,&l_16,(void*)0,&g_14[0][8],(void*)0,&l_16,&l_16}};
        int i, j;
        l_24--;
    }
    for (l_24 = 0; (l_24 <= 34); l_24++)
    { /* block id: 8 */
        uint64_t l_71 = 0xC0D74891BC53C27CLL;
        int32_t *l_651 = &l_20;
        int64_t l_1126 = (-1L);
        struct S1 *l_1177 = &g_66[3];
        struct S1 l_1239 = {0};
        struct S0 **l_1257 = &g_277;
        int32_t l_1263 = 0x921AD4A2L;
        union U5 * const *l_1269 = (void*)0;
        union U5 * const **l_1268[8][8] = {{&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269},{&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269},{&l_1269,&l_1269,&l_1269,(void*)0,&l_1269,&l_1269,&l_1269,(void*)0},{&l_1269,(void*)0,&l_1269,&l_1269,(void*)0,&l_1269,&l_1269,(void*)0},{(void*)0,&l_1269,&l_1269,(void*)0,&l_1269,&l_1269,(void*)0,&l_1269},{(void*)0,&l_1269,&l_1269,&l_1269,(void*)0,&l_1269,&l_1269,&l_1269},{&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269},{&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269}};
        uint32_t l_1274 = 1UL;
        union U2 *l_1334 = &g_1335[0][1][0];
        const uint16_t l_1376 = 65527UL;
        int8_t l_1385 = 0L;
        int8_t l_1433 = 0L;
        int32_t l_1471[8][7][4] = {{{0xF735771EL,1L,0L,1L},{0xD1812CF2L,0L,0L,(-1L)},{0x050791E1L,(-1L),0xE6098128L,(-1L)},{0xE1745550L,0x72D6B9D0L,0L,0L},{0xE1745550L,0x9E64F0A6L,0xE6098128L,0x574C254DL},{0x050791E1L,0L,0L,0x9499FC58L},{0xD1812CF2L,2L,0L,0x57315458L}},{{0xF735771EL,0x8CE6FD99L,(-1L),0xB73AFB11L},{2L,0xCD088D2AL,0L,(-9L)},{0xDD9DCE91L,0xE1745550L,1L,0x24310124L},{0L,0x72D6B9D0L,0xD1812CF2L,(-4L)},{0xECAD03DFL,0xD6EAB493L,0xA38F5E48L,0x831202DBL},{0x8CE6FD99L,5L,0x831202DBL,(-6L)},{8L,(-1L),0L,(-1L)}},{{0xCEDCF4C0L,1L,0L,3L},{5L,(-1L),(-6L),0xDEEF5FFEL},{0x504DA43EL,1L,0xCD088D2AL,0x24310124L},{0xE1745550L,0x504DA43EL,(-1L),1L},{0x4E9F4BA2L,0L,0xE1745550L,0x9499FC58L},{0x72D6B9D0L,9L,0x0D614953L,0L},{8L,2L,(-1L),(-1L)}},{{9L,0x24310124L,0xC20EC436L,0xDD9DCE91L},{5L,0xE1745550L,0x6ED8C86BL,0xF3025ADCL},{(-1L),1L,1L,(-1L)},{0xECAD03DFL,0xB73AFB11L,2L,0xF735771EL},{0xF1BB38CEL,5L,0L,(-6L)},{3L,(-1L),0x0D614953L,(-6L)},{0xD1812CF2L,5L,0L,0xF735771EL}},{{0xF8777406L,0xB73AFB11L,(-1L),(-1L)},{0x9E64F0A6L,1L,0xD5EF4BC4L,0xF3025ADCL},{0x504DA43EL,0xE1745550L,0xE6098128L,0xDD9DCE91L},{0x4E9F4BA2L,0x24310124L,0x9E64F0A6L,(-1L)},{1L,2L,(-4L),0L},{3L,9L,0x831202DBL,0x9499FC58L},{2L,0L,0xC20EC436L,1L}},{{1L,0x504DA43EL,0x6C8EFF4DL,0x24310124L},{0x5CAEFE89L,1L,0x6ED8C86BL,0xDEEF5FFEL},{0xDD9DCE91L,(-1L),0xA38F5E48L,3L},{0xF1BB38CEL,1L,8L,(-1L)},{0L,(-1L),(-4L),(-6L)},{0x72D6B9D0L,5L,0L,0x831202DBL},{5L,0xD6EAB493L,(-1L),(-4L)}},{{0x57315458L,0x72D6B9D0L,0xF3025ADCL,0x24310124L},{0x9E64F0A6L,0xE1745550L,(-1L),0xD6EAB493L},{0L,0xCEDCF4C0L,(-1L),0L},{(-4L),0xECAD03DFL,0x4062AD97L,(-6L)},{0L,9L,0L,0xE47D27FAL},{0xECAD03DFL,0x6ED8C86BL,0L,0x3B4AA5F2L},{(-6L),1L,0x5CAEFE89L,0x6ED8C86BL}},{{0L,0L,0x5CAEFE89L,0xE1745550L},{(-6L),5L,0L,0L},{0xECAD03DFL,(-1L),0L,0xF1BB38CEL},{0L,0xF1BB38CEL,0x4062AD97L,(-7L)},{(-4L),1L,(-1L),0xF3025ADCL},{0L,(-8L),(-1L),0L},{1L,0L,0xD1812CF2L,0x6ED8C86BL}}};
        uint16_t l_1472 = 0x639CL;
        uint32_t l_1513 = 0xBEAD5395L;
        union U5 **l_1516[1][6] = {{&l_1372[3][2],&l_1372[3][2],&l_1372[3][2],&l_1372[3][2],&l_1372[3][2],&l_1372[3][2]}};
        int i, j, k;
        for (l_19 = 8; (l_19 >= 3); l_19 -= 1)
        { /* block id: 11 */
            int32_t l_1017[4][5] = {{0L,0L,0L,0L,0L},{1L,0xBBCF2439L,1L,0xBBCF2439L,1L},{0L,0L,0L,0L,0L},{1L,0xBBCF2439L,1L,0xBBCF2439L,1L}};
            struct S0 **l_1090 = (void*)0;
            struct S0 ***l_1089 = &l_1090;
            struct S0 ***l_1136 = &l_1090;
            int16_t l_1138 = 0xD742L;
            uint16_t l_1139 = 0UL;
            const struct S1 l_1156 = {-3};
            int32_t *l_1176 = &g_132;
            int32_t l_1258[8][5][4] = {{{0x99518CE3L,0x0ACBD6E1L,1L,0x25546C3CL},{0L,0x6CBE3EAEL,0L,0x45CC6396L},{0x140A02ECL,0x25546C3CL,1L,0x3EE9FB15L},{0x6CBE3EAEL,1L,0x45194843L,0x25546C3CL},{8L,0x140A02ECL,0x45194843L,0x0ACBD6E1L}},{{0x6CBE3EAEL,0x99518CE3L,1L,(-9L)},{0x140A02ECL,0L,0L,0x140A02ECL},{0L,0x140A02ECL,1L,8L},{0x99518CE3L,0x6CBE3EAEL,(-1L),0x3EE9FB15L},{0x140A02ECL,8L,0x45CC6396L,0x3EE9FB15L}},{{1L,0x6CBE3EAEL,0x45194843L,8L},{0x25546C3CL,0x140A02ECL,8L,0x140A02ECL},{0x6CBE3EAEL,0L,0x45CC6396L,(-9L)},{0x0ACBD6E1L,0x99518CE3L,0L,0x0ACBD6E1L},{0x99518CE3L,0x140A02ECL,0x6562352AL,0x25546C3CL}},{{0x99518CE3L,1L,0L,0x3EE9FB15L},{0x0ACBD6E1L,0x25546C3CL,0x45CC6396L,0x45CC6396L},{0x6CBE3EAEL,0x6CBE3EAEL,8L,0x25546C3CL},{0x25546C3CL,0x0ACBD6E1L,0x45194843L,0x140A02ECL},{1L,0x99518CE3L,0x45CC6396L,0x45194843L}},{{0x140A02ECL,0x99518CE3L,(-1L),0x140A02ECL},{0x99518CE3L,0x0ACBD6E1L,1L,0x25546C3CL},{0L,0x6CBE3EAEL,0L,0x45CC6396L},{0x140A02ECL,0x25546C3CL,1L,0x3EE9FB15L},{0x6CBE3EAEL,1L,0x45194843L,0x25546C3CL}},{{8L,0x140A02ECL,0x45194843L,0x0ACBD6E1L},{0x6CBE3EAEL,0x99518CE3L,1L,(-9L)},{0x140A02ECL,0L,0L,0x140A02ECL},{0L,0x140A02ECL,1L,1L},{8L,0xD2214E80L,0x25546C3CL,0x45194843L}},{{0L,1L,8L,0x45194843L},{0x46814555L,0xD2214E80L,0x6562352AL,1L},{0x45CC6396L,0L,0x6CBE3EAEL,0L},{0xD2214E80L,0xE4C6131DL,8L,1L},{(-1L),8L,0xE4C6131DL,(-1L)}},{{8L,0L,0xEC6570D2L,0x45CC6396L},{8L,0x46814555L,0xE4C6131DL,0x45194843L},{(-1L),0x45CC6396L,8L,8L},{0xD2214E80L,0xD2214E80L,0x6CBE3EAEL,0x45CC6396L},{0x45CC6396L,(-1L),0x6562352AL,0L}}};
            int64_t *l_1264 = (void*)0;
            union U5 * const l_1310 = (void*)0;
            uint16_t l_1342 = 0UL;
            struct S1 l_1378 = {0};
            uint8_t l_1384[5] = {250UL,250UL,250UL,250UL,250UL};
            union U2 **l_1443 = &g_306[1][3];
            const union U3 *l_1444 = &g_1331[0];
            uint64_t l_1496[8] = {0x0CC0F8114CD53898LL,0x47A3B8450FCC68F2LL,0x47A3B8450FCC68F2LL,0x0CC0F8114CD53898LL,0x47A3B8450FCC68F2LL,0x47A3B8450FCC68F2LL,0x0CC0F8114CD53898LL,0x47A3B8450FCC68F2LL};
            uint8_t l_1518 = 1UL;
            int i, j, k;
            for (l_21 = 9; (l_21 >= 0); l_21 -= 1)
            { /* block id: 14 */
                int16_t *l_72 = &g_73;
                int32_t **l_649 = (void*)0;
                int32_t **l_650 = &g_350;
                uint32_t l_1143 = 0x7C828107L;
                uint32_t l_1196 = 0UL;
                uint16_t *l_1203 = (void*)0;
                uint16_t *l_1204 = &g_483;
                uint32_t **l_1215 = &g_1152;
                uint8_t *l_1216[7][8] = {{&g_186[3][3][1],(void*)0,&g_186[3][5][4],&g_186[3][5][4],&g_186[3][5][4],&g_186[3][5][4],&g_186[3][5][4],(void*)0},{&g_186[2][5][5],&g_186[3][5][4],&g_186[1][2][5],&g_186[3][5][4],&g_172,&g_172,&g_172,&g_172},{&g_186[0][5][1],&g_172,&g_172,&g_186[0][5][1],&g_186[2][5][5],(void*)0,&g_172,&g_186[3][3][1]},{&g_186[3][5][4],&g_186[0][5][1],&g_186[1][2][5],&g_172,&g_186[1][2][5],&g_186[0][5][1],&g_186[3][5][4],&g_186[3][5][4]},{&g_186[1][2][5],&g_186[0][5][1],&g_186[3][5][4],&g_186[3][5][4],(void*)0,(void*)0,&g_186[3][5][4],&g_186[3][5][4]},{&g_172,&g_172,&g_186[0][5][1],&g_186[2][5][5],(void*)0,&g_172,&g_186[3][3][1],&g_172},{&g_186[1][2][5],&g_186[3][5][4],&g_186[2][5][5],&g_186[3][5][4],&g_186[1][2][5],&g_186[3][5][4],&g_172,&g_172}};
                struct S1 l_1240 = {0};
                union U2 * const *l_1245 = &g_306[1][6];
                union U2 * const **l_1244 = &l_1245;
                union U2 * const ***l_1243 = &l_1244;
                union U4 **l_1249[3][5] = {{&g_1128,&g_1128,&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128,&g_1128,&g_1128},{&g_1128,&g_1128,&g_1128,&g_1128,&g_1128}};
                const struct S1 **l_1265[1];
                int16_t l_1272 = 0x3DE0L;
                int16_t l_1294 = 0xA5A8L;
                union U5 *l_1380 = &g_1373[2][2][3];
                uint32_t l_1410 = 0xDE4EE8F0L;
                int32_t l_1430 = (-2L);
                uint16_t l_1437[8] = {65530UL,0xC080L,65530UL,65530UL,0xC080L,65530UL,65530UL,0xC080L};
                int i, j;
                for (i = 0; i < 1; i++)
                    l_1265[i] = (void*)0;
            }
            for (g_1434 = 5; (g_1434 >= 15); g_1434++)
            { /* block id: 639 */
                int32_t *l_1462 = &l_1017[1][3];
                int32_t *l_1463 = (void*)0;
                int32_t *l_1464 = (void*)0;
                int32_t *l_1465 = &g_14[0][8];
                int32_t *l_1466 = &l_1263;
                int32_t l_1467 = 0xE90EACC8L;
                int32_t *l_1468 = &l_1467;
                int32_t *l_1469 = (void*)0;
                int32_t *l_1470[3];
                int64_t *l_1477[4];
                uint8_t *l_1493 = &l_1384[2];
                int i;
                for (i = 0; i < 3; i++)
                    l_1470[i] = &l_18;
                for (i = 0; i < 4; i++)
                    l_1477[i] = &g_423[2];
                --l_1472;
                if ((safe_sub_func_int32_t_s_s(((((((((*l_1465) = 1L) & 0xDD3DC3AEE3FEBAD5LL) || (((safe_mod_func_int32_t_s_s((safe_mod_func_int16_t_s_s((g_132 , (safe_mul_func_uint8_t_u_u((((((safe_mod_func_int16_t_s_s((((l_1389 <= (((g_1486 , (((*g_446) >= (l_1378 , (~(+((safe_div_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(((*l_1493)++), ((l_1264 == (void*)0) , 0x65L))), (*g_446))) == 18446744073709551610UL))))) | (*g_446))) , (-1L)) != (**g_284))) < g_259.f4) , (**g_731)), (*g_446))) || l_1436) & (-1L)) & (*g_446)) & g_197), g_483))), 0xCFBCL)), l_1496[7])) != 0x71L) || g_278.f1)) ^ (*l_1176)) <= (*l_1176)) & g_259.f6) ^ 7L), (*l_1176))))
                { /* block id: 643 */
                    uint16_t l_1499 = 0x53F9L;
                    int8_t *l_1500 = &l_1385;
                    uint64_t *l_1503 = &g_197;
                    int64_t **l_1509 = &l_1264;
                    union U2 *l_1510[1][8];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 8; j++)
                            l_1510[i][j] = &g_1123;
                    }
                    (*l_1443) = ((safe_mul_func_int8_t_s_s(l_1499, (((*l_1500) = (*l_1176)) == ((l_1499 , (safe_add_func_uint64_t_u_u(((g_205 = ((*l_1503) = (*l_651))) || (((g_1504 , (safe_rshift_func_uint8_t_u_s((((g_423[2] = l_1389) >= (safe_div_func_uint64_t_u_u((**g_1165), ((l_1477[1] == ((*l_1509) = l_1503)) || 0x4CL)))) || 254UL), l_1283))) | (*l_1466)) | 0xCEL)), 0xD4DCFD459FB34771LL))) >= g_344)))) , l_1510[0][5]);
                }
                else
                { /* block id: 650 */
                    int32_t l_1511[3];
                    union U5 **l_1517 = &g_219;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1511[i] = 0x8886FFF2L;
                    l_1513++;
                    (*g_190) = 0x52B98AEDL;
                    l_1517 = l_1516[0][2];
                    l_1518--;
                }
            }
            if ((*l_651))
                continue;
        }
    }
    return l_1389;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_483 g_309.f1 g_841 g_14
 * writes: g_81 g_2 g_1025 g_483 g_309.f1
 */
static const int32_t  func_35(union U4  p_36, uint32_t  p_37, const int32_t * p_38, uint16_t  p_39, int32_t * p_40)
{ /* block id: 453 */
    struct S1 l_1030 = {0};
    int32_t *l_1031 = (void*)0;
    int32_t *l_1032 = &g_14[0][9];
    int32_t *l_1033 = (void*)0;
    int32_t *l_1034 = &g_2;
    int32_t *l_1035[7];
    uint16_t l_1036 = 0x0993L;
    int i;
    for (i = 0; i < 7; i++)
        l_1035[i] = &g_132;
    for (p_37 = 0; (p_37 == 51); p_37++)
    { /* block id: 456 */
        struct S1 l_1020 = {-2};
        struct S1 *l_1022 = &g_81;
        (*l_1022) = l_1020;
        for (g_2 = 0; (g_2 >= (-17)); g_2 = safe_sub_func_uint32_t_u_u(g_2, 4))
        { /* block id: 460 */
            g_1025 = 0x50CD8817L;
        }
        (*p_40) &= 0xE74AEF55L;
    }
    for (g_483 = 2; (g_483 > 35); g_483 = safe_add_func_uint16_t_u_u(g_483, 3))
    { /* block id: 467 */
        for (g_309.f1 = 0; (g_309.f1 > (-2)); g_309.f1 = safe_sub_func_int16_t_s_s(g_309.f1, 1))
        { /* block id: 470 */
            l_1030 = l_1030;
        }
    }
    l_1036++;
    return (*g_841);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static union U4  func_41(const int32_t  p_42, int16_t  p_43, const uint64_t  p_44)
{ /* block id: 451 */
    union U4 l_1016[9] = {{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL},{0xF15F462FL}};
    int i;
    return l_1016[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_203 g_65 g_66 g_1007 g_350 g_2 g_293.f6 g_732 g_1015 g_841 g_14 g_132 g_444.f0
 * writes: g_185 g_431.f1 g_100 g_1007 g_1010 g_511 g_374
 */
static int64_t  func_45(uint64_t  p_46)
{ /* block id: 441 */
    int8_t *l_993 = &g_185[4];
    int8_t *l_994 = &g_431.f1;
    int32_t l_1003 = 1L;
    uint16_t *l_1004 = &g_100;
    const struct S0 ***l_1009[5];
    uint32_t l_1011 = 0x945FFAE8L;
    int32_t l_1012 = 0xF6E5D169L;
    int8_t *l_1013[6] = {&g_136,&g_136,&g_136,&g_136,&g_136,&g_136};
    const int32_t **l_1014 = &g_841;
    int i;
    for (i = 0; i < 5; i++)
        l_1009[i] = (void*)0;
    l_1003 = (safe_mod_func_uint32_t_u_u((safe_add_func_int8_t_s_s(((*l_994) = ((*l_993) = ((safe_lshift_func_uint16_t_u_u(p_46, 10)) < 0x76L))), (safe_rshift_func_int8_t_s_u(((((((p_46 , ((*g_732) = (0xABL == ((((((g_511 = ((((((safe_add_func_int8_t_s_s(((g_203 > 4UL) == (safe_sub_func_uint64_t_u_u(((((*l_1004) = l_1003) || ((((*g_65) , ((safe_div_func_uint64_t_u_u(((g_1010 = (g_1007 = g_1007)) != &g_1008), p_46)) && 0L)) <= (*g_350)) >= g_293.f6)) || 0x38L), (-4L)))), 0xB5L)) > p_46) < p_46) || l_1003) || l_1011) , l_1012)) , l_1013[3]) != l_994) & l_1011) , l_1014) != (void*)0)))) , g_1015) , 0L) != (**l_1014)) , 18446744073709551611UL) , g_132), g_14[0][2])))), (*g_841)));
    return g_444.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_132 g_234 g_986 g_511
 * writes: g_306
 */
static const uint8_t  func_49(uint32_t  p_50, int32_t * p_51)
{ /* block id: 435 */
    int8_t l_964 = 0x70L;
    union U4 l_965 = {0xB10FA54AL};
    int32_t l_966 = 0L;
    uint8_t *l_967 = (void*)0;
    int32_t l_968 = 0L;
    int32_t l_982 = (-8L);
    union U2 *l_983 = &g_310;
    union U2 **l_984 = &l_983;
    (*g_986) = ((*l_984) = (((l_964 & (l_968 = (l_965 , (l_966 > 1UL)))) < (safe_unary_minus_func_uint32_t_u((l_965.f0 , (safe_lshift_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((safe_div_func_uint64_t_u_u(g_132, (safe_rshift_func_int8_t_s_u((l_982 = (safe_mul_func_int8_t_s_s((-8L), 0x1BL))), g_234[0][0][1])))), p_50)), l_965.f0)) || 65530UL), l_964)))))) , l_983));
    return g_511;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_185 g_14 g_189 g_190 g_953 g_731 g_732 g_374 g_536 g_381.f4
 * writes: g_6 g_14 g_191 g_309.f1 g_483 g_185
 */
static int32_t * func_52(uint8_t  p_53, int32_t * p_54, int32_t * p_55, int32_t * p_56)
{ /* block id: 309 */
    int32_t l_708 = 0xCDAA7ED9L;
    union U3 *l_773 = (void*)0;
    union U4 l_808 = {0x6A40921FL};
    int16_t l_821 = 0L;
    int32_t l_857 = 0x7182AA54L;
    int16_t l_858[8][6] = {{(-6L),(-1L),0x016DL,3L,3L,0x016DL},{(-1L),(-1L),0x188CL,(-6L),(-1L),3L},{0x5571L,0xEF36L,0L,0x188CL,1L,0x188CL},{0L,0x5571L,0L,0x724FL,(-1L),3L},{1L,0x724FL,0x188CL,(-3L),0x016DL,0x016DL},{(-3L),0x016DL,0x016DL,(-3L),0x188CL,0x724FL},{1L,3L,(-1L),0xEF36L,3L,(-6L)},{3L,0x5571L,1L,0x5571L,3L,(-1L)}};
    int32_t l_864 = 0L;
    int32_t l_889 = 0x89F400FAL;
    int32_t l_890 = (-3L);
    int32_t l_891 = (-3L);
    int32_t l_943 = 9L;
    int32_t l_944 = 0x6260C86DL;
    int32_t l_945[8][2] = {{0x9034065CL,7L},{0x9034065CL,0x9034065CL},{7L,0x9034065CL},{0x9034065CL,7L},{0x9034065CL,0x9034065CL},{7L,0x9034065CL},{0x9034065CL,7L},{0x9034065CL,0x9034065CL}};
    const int16_t *l_960 = &l_858[3][1];
    const int16_t **l_959 = &l_960;
    const int16_t ***l_958 = &l_959;
    int8_t *l_961 = &g_185[7];
    int32_t l_962 = (-4L);
    uint32_t l_963 = 0UL;
    int i, j;
    for (g_6 = 2; (g_6 <= 7); g_6 += 1)
    { /* block id: 312 */
        int32_t l_658 = 0L;
        struct S1 l_691 = {-1};
        uint32_t l_736 = 0xADD58FC7L;
        const union U3 **l_761 = (void*)0;
        uint32_t l_765 = 18446744073709551608UL;
        uint64_t *l_798 = &g_197;
        union U5 *l_845 = &g_220;
        int32_t l_860 = 0xA163D95AL;
        int32_t l_862 = 0x2CA2ABDAL;
        int32_t l_863[2];
        const int8_t l_898 = (-3L);
        struct S1 l_904 = {0};
        int32_t l_942[4];
        int i;
        for (i = 0; i < 2; i++)
            l_863[i] = (-4L);
        for (i = 0; i < 4; i++)
            l_942[i] = (-1L);
        (**g_189) = ((*p_56) ^= g_185[g_6]);
        for (g_309.f1 = 0; (g_309.f1 >= 0); g_309.f1 -= 1)
        { /* block id: 317 */
            uint16_t l_683 = 65535UL;
            struct S1 l_688 = {3};
            int8_t *l_694 = (void*)0;
            for (g_483 = 0; (g_483 <= 3); g_483 += 1)
            { /* block id: 320 */
                uint32_t *l_659 = (void*)0;
                int32_t l_660 = 9L;
                uint32_t *l_661 = &g_105;
                int64_t *l_671 = &g_234[0][1][1];
                uint8_t l_682 = 0xF2L;
                uint16_t *l_684 = (void*)0;
                uint16_t *l_685 = &g_100;
                union U3 * const l_687 = &g_537;
                struct S0 **l_709[2][1];
                union U3 *l_725 = &g_536;
                uint8_t l_754[9][1] = {{0xF1L},{0xE1L},{0xF1L},{0xE1L},{0xF1L},{0xE1L},{0xF1L},{0xE1L},{0xF1L}};
                int16_t * const ** const l_760 = &g_284;
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_709[i][j] = &g_277;
                }
            }
        }
    }
    l_963 = ((safe_div_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s(p_53, (p_53 , (g_953[4][0] , (safe_add_func_int16_t_s_s(((**g_731) == (safe_rshift_func_int8_t_s_u(((*l_961) ^= ((&g_284 != (g_536 , l_958)) > l_891)), 0))), ((g_381.f4 , (-1L)) | p_53))))))), p_53)) > l_962);
    return p_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_190 g_191 g_648
 * writes: g_191 g_66
 */
static int32_t * func_57(uint16_t  p_58, int32_t  p_59, int32_t * p_60, int32_t * p_61)
{ /* block id: 304 */
    struct S1 l_646 = {-2};
    (*g_190) &= 0L;
    (*g_648) = l_646;
    return &g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_65
 * writes: g_66
 */
static uint16_t  func_62(int64_t  p_63)
{ /* block id: 15 */
    const struct S1 l_64[8][4] = {{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}},{{-3},{-3},{-3},{-3}}};
    int i, j;
    (*g_65) = l_64[5][2];
    return l_64[5][2].f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_80 g_14 g_100 g_6 g_73 g_132 g_136 g_158 g_172 g_186 g_189 g_197 g_205 g_208 g_178.f1 g_203 g_185 g_105 g_177.f1 g_158.f0 g_259.f6 g_277 g_284 g_278.f7 g_259.f2 g_306 g_308.f2 g_293.f4 g_259.f7 g_293.f6 g_344 g_278.f8 g_285 g_259.f5 g_293.f5 g_259.f4 g_374 g_310.f1 g_307.f2 g_81 g_311.f2 g_293.f2 g_381.f5 g_234 g_381.f7 g_293.f7 g_309.f1 g_259.f8 g_507 g_511 g_293.f8 g_538 g_350 g_381.f4 g_546.f1 g_423 g_307.f1 g_431.f1 g_309.f2 g_308.f1 g_311.f1
 * writes: g_2 g_100 g_105 g_132 g_136 g_172 g_81 g_186 g_197 g_205 g_208 g_218 g_234 g_6 g_158 g_259.f2 g_350 g_309.f2 g_73 g_374 g_259.f8 g_277 g_310.f1 g_185 g_423 g_293.f2 g_344 g_446 g_483 g_293.f8 g_381.f7 g_546.f1 g_431.f1 g_278.f4 g_293.f7
 */
static int32_t * func_67(int8_t  p_68, int64_t  p_69, int8_t  p_70)
{ /* block id: 19 */
    const uint32_t l_74 = 8UL;
    int32_t *l_75[10][4] = {{&g_14[0][8],&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_14[0][8],&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_14[0][8],&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_14[0][8],&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6},{&g_14[0][8],&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,&g_6}};
    const struct S1 *l_82 = &g_81;
    int16_t l_107 = 0x5F9FL;
    const int64_t l_108 = 0L;
    const union U2 **l_417 = (void*)0;
    const union U2 ***l_416 = &l_417;
    union U2 ***l_418 = (void*)0;
    union U2 ****l_419 = &l_418;
    uint64_t *l_420 = &g_205;
    uint64_t *l_421[3][9];
    int16_t l_422 = 0x44ACL;
    int64_t l_441 = 0L;
    int32_t l_470 = 2L;
    uint8_t l_540[4];
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
            l_421[i][j] = &g_197;
    }
    for (i = 0; i < 4; i++)
        l_540[i] = 0x49L;
    g_2 &= l_74;
    for (g_2 = 3; (g_2 >= 0); g_2 -= 1)
    { /* block id: 23 */
        uint16_t *l_99[8][6] = {{(void*)0,&g_100,(void*)0,&g_100,&g_100,&g_100},{(void*)0,&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,(void*)0,(void*)0,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100,&g_100},{&g_100,(void*)0,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100,(void*)0},{&g_100,(void*)0,&g_100,&g_100,&g_100,&g_100},{(void*)0,&g_100,(void*)0,&g_100,&g_100,(void*)0}};
        int32_t l_101[1];
        uint32_t *l_104 = &g_105;
        int8_t l_106 = 0x60L;
        struct S0 **l_382[2][9][8] = {{{&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277},{&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277},{&g_277,&g_277,&g_277,(void*)0,(void*)0,(void*)0,&g_277,&g_277},{(void*)0,(void*)0,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277},{&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277},{&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277,(void*)0,&g_277},{&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0},{&g_277,(void*)0,&g_277,&g_277,&g_277,&g_277,&g_277,&g_277},{(void*)0,&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,&g_277}},{{&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277},{&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277,&g_277,&g_277},{&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277},{&g_277,(void*)0,&g_277,(void*)0,&g_277,&g_277,(void*)0,(void*)0},{&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,&g_277,&g_277},{&g_277,(void*)0,&g_277,(void*)0,&g_277,&g_277,(void*)0,(void*)0},{&g_277,(void*)0,&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0},{(void*)0,(void*)0,(void*)0,&g_277,&g_277,&g_277,&g_277,(void*)0},{&g_277,&g_277,&g_277,&g_277,&g_277,(void*)0,(void*)0,&g_277}}};
        int32_t l_394 = 0x9BE5BE9DL;
        union U4 *l_408 = &g_158;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_101[i] = 0x9C6BD3C7L;
        g_277 = func_76((((((-6L) == (g_80[3] != l_82)) , ((safe_lshift_func_uint8_t_u_u(g_14[0][8], (safe_div_func_int16_t_s_s((((((safe_div_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u(p_68, (l_106 = (safe_rshift_func_int8_t_s_u(((+(~(((g_14[0][0] && (safe_sub_func_uint32_t_u_u(((*l_104) = (p_68 >= (g_100++))), p_69))) > p_68) , 5L))) > 0L), p_70))))), g_6)) < 4294967286UL) || l_107) != g_73) || p_69), 0x53EDL)))) || p_68)) || 0xA9L) & 0xAD8DB6A5085D5259LL), p_69, l_108);
        if (p_69)
            continue;
        for (g_310.f1 = 0; (g_310.f1 <= 3); g_310.f1 += 1)
        { /* block id: 186 */
            int8_t *l_393 = &g_185[7];
            int32_t l_409 = 0x227830DFL;
            int i, j;
            l_75[(g_310.f1 + 1)][g_2] = (void*)0;
            l_394 ^= ((((safe_rshift_func_int8_t_s_s(0xEDL, 3)) != (((((0L & ((g_100 ^= p_69) == ((((safe_mul_func_int16_t_s_s((l_75[g_310.f1][g_2] != (void*)0), (safe_rshift_func_int16_t_s_s((((safe_div_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u(p_70, g_307.f2)) >= ((*l_393) ^= (((*l_82) , (0L < 0xA83BA71EL)) > (-1L)))), 7UL)) & l_106) & g_205), 1)))) | l_101[0]) > l_101[0]) && p_70))) >= p_70) || p_69) > 0x7DD8CD350E768BA2LL) != 18446744073709551608UL)) > g_172) || 0x880848E3L);
            l_409 = (safe_sub_func_uint8_t_u_u(((~l_394) ^ l_101[0]), ((safe_mod_func_uint16_t_u_u((g_100 = (0x0C904608L & (safe_mul_func_int16_t_s_s(((((g_208 <= g_311[0].f2) , (0xF997C4A7911EC5A6LL ^ ((0x357D6EC1892ABD19LL || ((-5L) == (safe_mod_func_uint32_t_u_u(((safe_div_func_int32_t_s_s((((safe_add_func_uint32_t_u_u(((((*g_285) > 0L) != 65535UL) , g_307.f2), p_68)) , (void*)0) == l_408), g_172)) == p_68), 0xBE84A8F5L)))) , 0xE8E080FC9B504F2BLL))) || p_69) == g_293.f2), l_101[0])))), p_68)) != p_69)));
        }
    }
    if (((g_178[1][8].f1 | (g_423[2] = (+(g_307.f2 ^ ((!(g_381.f5 != (((g_197 = (((safe_lshift_func_uint8_t_u_s(g_234[0][0][1], (safe_sub_func_int32_t_s_s((((*l_420) = (((g_381.f7 ^ (0x2EL ^ p_70)) | (l_416 != ((*l_419) = l_418))) <= p_69)) >= g_293.f5), (-1L))))) > g_310.f1) > p_69)) == (-1L)) & l_422))) && p_69))))) && g_344))
    { /* block id: 199 */
        union U2 *l_430 = &g_431;
        const uint64_t *l_434 = (void*)0;
        union U4 l_436 = {0x1FCC4563L};
        int32_t *l_442[1][8] = {{&g_14[0][9],(void*)0,&g_14[0][9],&g_14[0][9],(void*)0,&g_14[0][9],&g_14[0][9],(void*)0}};
        int i, j;
        g_293.f2 &= (safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u(((safe_sub_func_uint16_t_u_u((((l_430 != (((((safe_mul_func_uint8_t_u_u((p_70 || (1UL || ((l_434 != (((!(6UL > 0x9A405D67222A531ELL)) || (0xBE759395L <= (l_436 , (safe_mul_func_int8_t_s_s((((((safe_sub_func_int16_t_s_s(1L, l_436.f0)) <= 0UL) & g_132) < p_70) < 0xA95EC7957A547AB5LL), p_70))))) , l_421[0][8])) && l_436.f0))), 255UL)) == 4294967295UL) >= l_441) || g_293.f7) , g_306[1][6])) | l_436.f0) || 0x9A52E3E6L), p_70)) , (*g_285)), 15)), g_309.f1));
        return l_442[0][2];
    }
    else
    { /* block id: 202 */
        uint16_t l_471 = 0xC1C5L;
        int16_t *l_503 = (void*)0;
        int16_t **l_502 = &l_503;
        int16_t ***l_501 = &l_502;
        int32_t l_504[5];
        int32_t l_509 = (-3L);
        union U3 *l_534[8] = {&g_537,&g_536,&g_536,&g_537,&g_536,&g_536,&g_537,&g_536};
        union U4 l_547 = {-1L};
        const uint64_t *l_570 = (void*)0;
        int64_t l_578 = 0x51C7555E3DCA4C07LL;
        const int32_t l_641 = 0x35AB57C8L;
        int i;
        for (i = 0; i < 5; i++)
            l_504[i] = (-5L);
        for (g_136 = 0; (g_136 <= 3); g_136 += 1)
        { /* block id: 205 */
            const uint32_t *l_453 = &g_178[1][8].f2;
            int16_t *l_456[4];
            int16_t **l_455 = &l_456[1];
            int16_t ***l_454 = &l_455;
            int32_t l_462[7][1] = {{0L},{0L},{(-8L)},{0L},{0L},{(-8L)},{0L}};
            int32_t l_469 = 0L;
            int8_t *l_527[8] = {&g_177.f1,&g_431.f1,&g_431.f1,&g_177.f1,&g_431.f1,&g_431.f1,&g_177.f1,&g_431.f1};
            union U2 * const l_541 = (void*)0;
            int i, j;
            for (i = 0; i < 4; i++)
                l_456[i] = &l_422;
            for (g_158.f0 = 0; (g_158.f0 <= 3); g_158.f0 += 1)
            { /* block id: 208 */
                int16_t ***l_457 = &l_455;
                int8_t l_505 = 0L;
                int32_t *l_515 = &g_14[0][8];
                int32_t **l_516 = &g_350;
                union U2 *l_545 = &g_546;
                for (g_344 = 7; (g_344 >= 0); g_344 -= 1)
                { /* block id: 211 */
                    union U3 *l_443 = &g_444;
                    union U3 **l_445 = &l_443;
                    union U2 * const *l_493 = &g_306[1][4];
                    union U2 * const **l_492 = &l_493;
                    int32_t l_510 = 0L;
                    uint64_t **l_513[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_513[i] = &l_421[1][4];
                    (*l_445) = l_443;
                    if ((&g_100 != (g_446 = (void*)0)))
                    { /* block id: 214 */
                        int i, j, k;
                        g_259.f8 &= (g_186[g_136][(g_158.f0 + 2)][g_136] & (safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_rshift_func_uint8_t_u_s(((g_158.f0 , l_453) != ((((l_454 != l_457) & (safe_div_func_int8_t_s_s((safe_add_func_uint64_t_u_u(((l_462[4][0] = 9UL) <= ((***l_454) ^= (safe_rshift_func_uint8_t_u_u((0x89L <= (safe_lshift_func_int16_t_s_u((**g_284), (safe_add_func_int16_t_s_s(((l_469 == 0x6BL) || l_469), g_259.f4))))), p_70)))), l_470)), l_471))) , 1UL) , (void*)0)), p_70)), 8)), p_69)));
                    }
                    else
                    { /* block id: 218 */
                        uint16_t *l_472 = &l_471;
                        uint16_t *l_475 = &g_100;
                        uint16_t *l_482 = &g_483;
                        int16_t ***l_500 = &l_455;
                        uint32_t *l_506[10][5] = {{&g_105,&g_105,&g_208,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_208,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_208,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_208,&g_105,&g_105}};
                        int32_t l_512[2][6][2];
                        uint64_t **l_514 = &l_421[0][1];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 6; j++)
                            {
                                for (k = 0; k < 2; k++)
                                    l_512[i][j][k] = 0x3D24DBABL;
                            }
                        }
                        g_293.f8 |= (((++(*l_472)) & (((*l_475) = p_68) >= (safe_rshift_func_uint8_t_u_s((safe_div_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_s(((*l_482) = (0x86F2L != l_469)), 4)) | (safe_add_func_uint8_t_u_u((((((+((l_509 &= (((safe_lshift_func_int8_t_s_u((+((((p_68 ^ ((void*)0 == l_492)) | (g_208 = (safe_mod_func_uint64_t_u_u(((safe_mod_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u((l_500 != l_501), 1L)) && l_504[2]) , p_70), g_293.f6)) , l_505), p_70)))) != l_504[2]) , 0x4DL)), g_177.f1)) , g_507) != &g_508)) | l_510)) ^ 8UL) && p_69) != l_504[2]) ^ g_511), l_512[1][5][1]))), g_6)), g_14[0][8])))) , 0xFC24E9BDL);
                        l_514 = l_513[1];
                    }
                    l_462[4][0] &= l_510;
                }
                (*l_516) = l_515;
                for (l_441 = 0; (l_441 <= 0); l_441 += 1)
                { /* block id: 232 */
                    const uint8_t l_539[7] = {1UL,0x14L,0x82L,0x82L,1UL,0x82L,0x82L};
                    union U4 l_542 = {-1L};
                    int32_t *l_548 = &g_14[0][8];
                    int i, j, k;
                    if ((((-5L) && g_234[l_441][g_136][l_441]) , (safe_mul_func_uint8_t_u_u(((**g_284) <= (((safe_mul_func_uint8_t_u_u(((safe_lshift_func_int16_t_s_u((safe_add_func_uint32_t_u_u((p_68 < (safe_add_func_int8_t_s_s(((void*)0 != l_527[1]), (safe_add_func_uint8_t_u_u(((((safe_mul_func_uint8_t_u_u(g_136, ((safe_rshift_func_uint8_t_u_u(((l_534[4] != g_538) || g_511), g_278.f8)) > p_68))) , 1L) , (-5L)) == l_462[4][0]), p_68))))), g_234[l_441][g_136][l_441])), 11)) >= l_539[5]), (**l_516))) | g_100) != l_540[1])), 0UL))))
                    { /* block id: 233 */
                        g_381.f7 = ((g_381.f4 , l_541) == (l_542 , ((safe_rshift_func_int8_t_s_s((-8L), 6)) , l_545)));
                    }
                    else
                    { /* block id: 235 */
                        int32_t **l_549 = &l_75[5][1];
                        (*l_549) = (l_547 , ((*l_516) = l_548));
                    }
                }
            }
            for (g_546.f1 = 1; (g_546.f1 <= 4); g_546.f1 += 1)
            { /* block id: 243 */
                int32_t l_583[9] = {0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L,0x471C3844L};
                uint16_t l_596 = 65535UL;
                int i;
                l_462[4][0] = ((g_423[g_546.f1] && (safe_rshift_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(0x78433BF013BC37C7LL, (safe_add_func_int8_t_s_s((0xE9L >= g_423[(g_136 + 1)]), p_69)))), 10))) , (safe_mod_func_int8_t_s_s((+(safe_lshift_func_uint16_t_u_u(((l_547 , g_158) , (g_293.f2 < p_70)), 4))), l_509)));
                for (g_483 = 0; (g_483 <= 3); g_483 += 1)
                { /* block id: 247 */
                    int32_t l_582 = (-9L);
                    for (g_158.f0 = 5; (g_158.f0 >= 0); g_158.f0 -= 1)
                    { /* block id: 250 */
                        uint16_t l_561 = 6UL;
                        int i, j, k;
                        l_561--;
                        g_350 = &g_14[0][6];
                        g_293.f8 ^= (l_583[7] = (g_259.f8 |= (safe_unary_minus_func_int64_t_s(((g_186[g_136][(g_546.f1 + 2)][(g_136 + 2)] == (~(l_509 = (safe_rshift_func_uint8_t_u_s(((safe_mod_func_uint64_t_u_u((g_197 = ((*l_420) = (l_421[1][3] != l_570))), ((p_70 <= (1L > (g_185[(g_546.f1 + 3)] ^= (safe_mul_func_int16_t_s_s((p_70 >= (safe_unary_minus_func_uint8_t_u(p_69))), ((safe_div_func_int16_t_s_s((safe_div_func_uint16_t_u_u(l_578, ((+(safe_sub_func_uint8_t_u_u((p_69 || g_186[g_136][(g_546.f1 + 2)][(g_136 + 2)]), 0x26L))) ^ l_582))), (**g_284))) && p_68)))))) , g_185[7]))) || l_582), p_68))))) <= p_68)))));
                    }
                    l_582 = (((1L >= ((((p_68 > 0x559713CEL) < ((l_582 , (safe_mod_func_int64_t_s_s(0x9186D15CB9C7F3DDLL, (((safe_add_func_uint32_t_u_u((safe_sub_func_int64_t_s_s(((safe_add_func_uint16_t_u_u(((&l_107 == &l_422) >= (safe_mul_func_uint16_t_u_u(5UL, p_68))), 0xC670L)) , p_70), g_307.f1)), l_509)) <= 0x1478L) && p_70)))) != p_70)) ^ p_68) , g_178[1][8].f1)) >= p_68) ^ l_596);
                }
            }
            for (g_431.f1 = 6; (g_431.f1 >= 0); g_431.f1 -= 1)
            { /* block id: 266 */
                int64_t l_621 = 0x121B054E2E740D2FLL;
                int32_t *l_642 = (void*)0;
                if (p_68)
                { /* block id: 267 */
                    uint32_t l_602 = 18446744073709551614UL;
                    int32_t l_631[10][6][4] = {{{0L,0x76D5D337L,0xEDEB804DL,0x76D5D337L},{(-3L),1L,0x2D52A82CL,0x4784100FL},{0x5EBE0B57L,1L,(-1L),(-1L)},{0x76D5D337L,0x7124EA65L,0xBDF8CE8FL,(-10L)},{0x76D5D337L,0x9B632092L,(-1L),0x1E9BAE57L},{0x5EBE0B57L,(-10L),0x2D52A82CL,1L}},{{(-3L),0x93D66BECL,0xEDEB804DL,0x671F1FE2L},{0L,(-1L),1L,7L},{(-6L),0L,3L,(-6L)},{0L,1L,5L,0xD27F52E2L},{0x4784100FL,0xECD8DBFDL,5L,1L},{(-1L),0x671F1FE2L,(-6L),0x3EAD22FEL}},{{(-5L),0xEA6F1BE8L,(-3L),0xD27F52E2L},{0x93D66BECL,0x2CAB29C4L,(-1L),(-2L)},{0xB9DC7967L,0L,0L,(-1L)},{(-10L),(-9L),(-9L),0x671F1FE2L},{1L,(-1L),0xD22F0553L,6L},{(-1L),(-10L),(-1L),(-1L)}},{{(-1L),0x208D937AL,0x8638DE1FL,(-10L)},{0x84F101D3L,5L,(-1L),(-1L)},{(-1L),1L,(-1L),1L},{(-8L),(-5L),0L,0x76D5D337L},{1L,0x944EB55DL,0x2CAB29C4L,1L},{0x9CCD04E4L,0x84F101D3L,0L,0L}},{{0xA8A26D01L,0xA8A26D01L,8L,(-5L)},{0x93D66BECL,1L,0xC1905892L,1L},{1L,0x4784100FL,(-6L),0xC1905892L},{0x1E9BAE57L,0x4784100FL,0x00DB706CL,1L},{0x4784100FL,1L,7L,(-5L)},{0xF5A14CEFL,0xA8A26D01L,3L,0L}},{{(-2L),0x84F101D3L,(-1L),1L},{0L,0x944EB55DL,(-1L),0x76D5D337L},{0xC1905892L,(-5L),0x2D52A82CL,1L},{6L,1L,(-1L),(-1L)},{0x76D5D337L,5L,0xB162AE1FL,(-10L)},{0x944EB55DL,0x208D937AL,(-1L),(-1L)}},{{6L,(-10L),8L,6L},{(-3L),(-1L),(-1L),0x671F1FE2L},{3L,(-9L),1L,(-1L)},{(-2L),0L,0xC6DB580DL,(-2L)},{0L,0x2CAB29C4L,7L,0xD27F52E2L},{1L,0xEA6F1BE8L,5L,0x3EAD22FEL}},{{0x1E9BAE57L,0x671F1FE2L,0x5A2FEA32L,1L},{(-5L),0xECD8DBFDL,0xC1905892L,0xD27F52E2L},{(-1L),0xF5A14CEFL,0x487BE48BL,0xC6DB580DL},{5L,0xECD8DBFDL,1L,0xB162AE1FL},{0x944EB55DL,0L,0L,(-1L)},{0xF981A2ECL,(-6L),0xF981A2ECL,0x00DB706CL}},{{(-1L),0x944EB55DL,(-2L),0xB9DC7967L},{1L,0x51BC57A3L,0xBDF8CE8FL,0x944EB55DL},{0L,(-1L),0xBDF8CE8FL,0xEE85D8EFL},{1L,0x3EAD22FEL,(-2L),1L},{(-1L),0xC23847E2L,0xF981A2ECL,7L},{0xF981A2ECL,7L,0L,0x89B4A36CL}},{{0x944EB55DL,0L,1L,0x2CAB29C4L},{5L,(-8L),0x487BE48BL,0x5EBE0B57L},{0x5A2FEA32L,5L,(-7L),0L},{0x5EBE0B57L,1L,0L,2L},{0xB9DC7967L,(-1L),0x02ABF76AL,0xF5A14CEFL},{(-1L),5L,0L,0xC23847E2L}}};
                    int32_t **l_645 = &g_350;
                    int i, j, k;
                    if (l_462[4][0])
                        break;
                    for (p_70 = 0; (p_70 <= 3); p_70 += 1)
                    { /* block id: 271 */
                        uint16_t **l_605 = &g_446;
                        uint16_t *l_608 = &g_483;
                        int i, j, k;
                        if (g_186[g_136][p_70][(g_136 + 2)])
                            break;
                        g_2 ^= (p_68 & (l_504[2] , ((~(((safe_div_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((p_70 || l_602) && (safe_div_func_uint32_t_u_u(((g_185[(g_431.f1 + 1)] = (((*l_605) = &g_483) == ((((*l_608) = (l_509 > (0xC2L <= ((safe_mul_func_uint8_t_u_u(g_259.f8, ((l_602 && g_100) != 0xDDL))) & g_186[g_136][p_70][(g_136 + 2)])))) > p_69) , (void*)0))) <= (-1L)), p_68))), g_309.f2)), 253UL)) && g_203) , 0x94C22A94L)) == 0x4C1FL)));
                        g_278.f4 = p_68;
                    }
                    if (l_462[4][0])
                    { /* block id: 279 */
                        uint32_t *l_630[7][1] = {{&g_208},{&g_208},{&g_208},{&g_208},{&g_208},{&g_208},{&g_208}};
                        int32_t l_639 = 0xA5562988L;
                        uint16_t *l_640 = &l_471;
                        int32_t **l_643[2];
                        int i, j;
                        for (i = 0; i < 2; i++)
                            l_643[i] = (void*)0;
                        g_293.f7 &= ((safe_sub_func_uint64_t_u_u((l_504[2] = (g_197 &= (safe_mod_func_uint8_t_u_u(p_68, (((((((((((*l_420) ^= p_68) <= (((safe_mod_func_int8_t_s_s((((g_105 = (safe_unary_minus_func_uint16_t_u((!((((*l_640) ^= (safe_lshift_func_int8_t_s_u((((safe_add_func_int64_t_s_s((l_602 , l_621), ((safe_div_func_uint16_t_u_u(g_381.f7, l_602)) && (((safe_div_func_int8_t_s_s((safe_lshift_func_int8_t_s_s((p_70 = (((safe_sub_func_int32_t_s_s(((((l_631[8][1][0] |= g_308.f1) & ((safe_mul_func_int32_t_s_s((p_68 | (safe_mul_func_int16_t_s_s((!(l_462[5][0] = (((((**g_284) == l_639) || 0x59L) | 9UL) >= g_423[2]))), 0UL))), 0L)) > 1UL)) <= 4294967292UL) != 0x3C5CL), l_621)) > l_621) < p_70)), 1)), g_186[3][5][4])) & l_504[0]) == 0xAFL)))) & g_136) > l_469), g_136))) != l_639) >= 0x950EL))))) == l_621) && g_423[3]), g_344)) != g_259.f7) == p_69)) , 0x7201F70B8FC5D5C2LL) & 0x81D414C82FBFFFF2LL) || g_311[0].f1) | 0xCFFD9628L) ^ p_69) ^ l_641) < 0x64EF5326FCD628AELL) & p_69))))), g_293.f4)) ^ g_158.f0);
                        g_293.f2 &= p_70;
                        g_350 = l_642;
                        l_469 ^= ((g_307.f2 , g_185[7]) & l_462[6][0]);
                    }
                    else
                    { /* block id: 292 */
                        int32_t **l_644 = &l_642;
                        (*l_644) = (void*)0;
                        l_645 = l_645;
                        g_350 = (void*)0;
                    }
                }
                else
                { /* block id: 297 */
                    return &g_2;
                }
            }
        }
    }
    return &g_132;
}


/* ------------------------------------------ */
/* 
 * reads : g_73 g_6 g_14 g_132 g_136 g_158 g_172 g_186 g_189 g_197 g_205 g_208 g_178.f1 g_203 g_185 g_105 g_177.f1 g_100 g_158.f0 g_259.f6 g_277 g_284 g_278.f7 g_259.f2 g_306 g_308.f2 g_293.f4 g_259.f7 g_293.f6 g_344 g_278.f8 g_285 g_259.f5 g_293.f5 g_259.f4 g_374
 * writes: g_105 g_132 g_136 g_172 g_81 g_186 g_197 g_205 g_100 g_208 g_218 g_234 g_6 g_158 g_259.f2 g_350 g_309.f2 g_73 g_374 g_259.f8
 */
static struct S0 * func_76(uint32_t  p_77, int32_t  p_78, const int16_t  p_79)
{ /* block id: 27 */
    uint32_t l_129 = 0UL;
    union U5 *l_148 = &g_149;
    int32_t l_166 = 1L;
    int32_t l_167 = 0xC174BAE2L;
    int32_t l_171[2];
    const union U2 *l_176[8] = {&g_177,&g_177,&g_177,&g_177,&g_177,&g_177,&g_177,&g_177};
    const struct S1 l_180 = {-1};
    int64_t l_204 = (-6L);
    uint16_t l_235 = 0x0836L;
    const struct S1 l_279 = {0};
    struct S0 *l_292 = &g_293;
    int32_t *l_378 = (void*)0;
    int32_t *l_379[8][1] = {{&l_171[1]},{(void*)0},{&l_171[1]},{(void*)0},{&l_171[1]},{(void*)0},{&l_171[1]},{(void*)0}};
    struct S0 *l_380 = &g_381;
    int i, j;
    for (i = 0; i < 2; i++)
        l_171[i] = 0xA0F0CF81L;
    if (g_73)
    { /* block id: 28 */
        int64_t l_109 = 0xC21D3621AE722093LL;
        uint32_t *l_130 = &g_105;
        int32_t *l_131 = &g_132;
        int8_t *l_135 = &g_136;
        uint16_t l_137 = 1UL;
        int32_t l_182 = (-1L);
        int32_t l_184 = 0xB8070DB4L;
        union U5 **l_200 = &l_148;
        (*l_131) ^= ((((p_77 > (0xC193L || 0UL)) != l_109) <= (+(safe_sub_func_uint32_t_u_u((((safe_mul_func_uint16_t_u_u((g_6 & (safe_add_func_int32_t_s_s((safe_sub_func_uint64_t_u_u(0x555874C7D6E71340LL, ((safe_mul_func_uint8_t_u_u(0x9DL, (safe_add_func_int64_t_s_s((((*l_130) = (((safe_add_func_int8_t_s_s((safe_add_func_int32_t_s_s((safe_lshift_func_int16_t_s_u(p_77, 12)), (l_129 > 0x57D5AD653C032282LL))), 0L)) <= 0x66F312D9EA3BD3CCLL) | l_109)) && l_129), (-1L))))) ^ 0xCD10L))), 0x4FFD0F06L))), g_14[0][9])) , p_77) , 1UL), g_14[0][6])))) < g_6);
        if (((safe_mul_func_int8_t_s_s(((*l_135) ^= 0xCAL), ((p_78 > g_14[0][8]) , ((((*l_131) |= l_137) != (!(!(safe_mul_func_uint16_t_u_u(0xB280L, (1L >= 0xA835L)))))) <= p_77)))) , (((safe_lshift_func_uint16_t_u_s(((safe_sub_func_int16_t_s_s(0x3FB5L, 1UL)) >= p_78), 12)) != g_14[0][5]) ^ g_136)))
        { /* block id: 33 */
            union U5 *l_151 = &g_152;
            int8_t *l_157[7][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_136,&g_136,&g_136,&g_136,&g_136},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_136,(void*)0,&g_136,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_136,&g_136,&g_136,&g_136,&g_136},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            union U4 l_161 = {0x44A4BF25L};
            int32_t l_169 = 0L;
            int32_t l_170 = (-1L);
            int32_t *l_183[9] = {(void*)0,&l_171[1],(void*)0,&l_171[1],(void*)0,&l_171[1],(void*)0,&l_171[1],(void*)0};
            int i, j;
            for (p_78 = (-18); (p_78 == 17); ++p_78)
            { /* block id: 36 */
                union U5 **l_150[2];
                int32_t l_163 = 0L;
                int32_t l_165 = (-1L);
                int32_t l_168 = 0x0C45E751L;
                struct S1 *l_181 = &g_81;
                int i;
                for (i = 0; i < 2; i++)
                    l_150[i] = &l_148;
                l_151 = l_148;
                if (((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((((void*)0 == l_157[4][2]) > (g_158 , (-1L))), (safe_add_func_uint32_t_u_u(4294967293UL, 0x9E6D6167L)))), (&l_137 == &l_137))) && ((l_161 , 254UL) ^ g_14[0][8])))
                { /* block id: 38 */
                    int32_t l_162[2][4][7] = {{{1L,0L,0x291AC2CDL,0L,0L,6L,(-2L)},{0L,0x17299F8DL,0xCC831229L,6L,6L,0xCC831229L,0x17299F8DL},{1L,0L,0L,6L,0x3B90B52BL,0xCC831229L,(-1L)},{0L,7L,(-1L),0x291AC2CDL,0xF75E263BL,6L,0xF75E263BL}},{{6L,0xF75E263BL,0xF75E263BL,6L,0x9D57AA8CL,(-1L),0x291AC2CDL},{(-1L),0xF75E263BL,0L,6L,1L,0x9D57AA8CL,0L},{0x291AC2CDL,7L,(-1L),0L,(-1L),7L,0x291AC2CDL},{0x3B90B52BL,0L,7L,0L,(-1L),0x17299F8DL,0xF75E263BL}}};
                    int32_t *l_164[4];
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_164[i] = &g_132;
                    --g_172;
                    if (g_73)
                        continue;
                    for (l_129 = 0; (l_129 <= 4); l_129 += 1)
                    { /* block id: 43 */
                        int32_t **l_175 = &l_164[3];
                        (*l_175) = &l_168;
                        (*l_131) ^= ((void*)0 != &p_79);
                    }
                }
                else
                { /* block id: 47 */
                    const union U2 **l_179 = &l_176[7];
                    g_132 = (*l_131);
                    (*l_179) = l_176[7];
                    l_168 ^= (*l_131);
                }
                (*l_181) = l_180;
            }
            ++g_186[3][5][4];
        }
        else
        { /* block id: 55 */
            (*l_131) &= (&l_131 == g_189);
        }
        for (g_132 = 0; (g_132 < (-14)); g_132 = safe_sub_func_uint32_t_u_u(g_132, 8))
        { /* block id: 60 */
            int32_t *l_194 = &l_182;
            int32_t *l_195 = &l_166;
            int32_t *l_196[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int i;
            g_197--;
        }
        (*l_200) = l_148;
    }
    else
    { /* block id: 64 */
        int32_t *l_201 = &l_167;
        int32_t *l_202[3][5][6] = {{{&g_14[0][8],&l_171[0],&l_166,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_166,&l_171[0]},{&g_14[0][8],&l_171[0],&g_2,&l_171[0],&l_171[0],&g_14[0][8]},{&l_171[0],&l_166,&l_166,&l_166,&l_171[0],&g_14[0][3]},{&g_14[0][8],&l_171[0],&l_171[0],(void*)0,&l_166,&g_2}},{{&g_2,(void*)0,&l_171[0],&l_171[0],(void*)0,&g_2},{(void*)0,&l_171[0],&l_171[0],&l_171[0],&g_2,&g_14[0][3]},{(void*)0,&g_14[0][8],&l_166,&g_2,&l_166,&g_14[0][8]},{(void*)0,&g_14[0][3],&g_2,&l_171[0],&l_171[0],&l_171[0]},{(void*)0,&g_2,(void*)0,&l_171[0],&l_171[0],(void*)0}},{{&g_2,&g_2,&l_166,(void*)0,&l_171[0],&l_171[0]},{&g_14[0][8],&g_14[0][3],&l_171[0],&l_166,&l_166,&l_166},{&l_171[0],&g_14[0][8],&l_171[0],&l_171[0],&g_2,&l_171[0]},{&g_14[0][8],&l_171[0],&l_166,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_166,&l_171[0]}}};
        struct S0 *l_211[7][2];
        union U4 l_246 = {-5L};
        int16_t **l_289 = (void*)0;
        uint32_t l_321 = 0xC59DEBC2L;
        uint8_t *l_361[5];
        uint32_t *l_370[1][9];
        uint32_t l_371 = 1UL;
        int16_t *l_372 = &g_73;
        int16_t *l_373 = &g_374;
        int i, j, k;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 2; j++)
                l_211[i][j] = (void*)0;
        }
        for (i = 0; i < 5; i++)
            l_361[i] = &g_186[2][4][0];
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 9; j++)
                l_370[i][j] = &g_308.f2;
        }
lbl_263:
        ++g_205;
        for (g_100 = 0; (g_100 <= 2); g_100 += 1)
        { /* block id: 68 */
            uint16_t l_215[6] = {0x56BAL,0x56BAL,0x56BAL,0x56BAL,0x56BAL,0x56BAL};
            union U5 **l_216[2];
            int32_t l_236 = 0xC6DDDA66L;
            int32_t **l_238[9];
            int16_t *l_287 = &g_203;
            int16_t **l_286 = &l_287;
            union U2 *l_304[7];
            int i;
            for (i = 0; i < 2; i++)
                l_216[i] = &l_148;
            for (i = 0; i < 9; i++)
                l_238[i] = &l_202[2][1][5];
            for (i = 0; i < 7; i++)
                l_304[i] = &g_305;
            ++g_208;
            for (g_172 = 0; (g_172 <= 3); g_172 += 1)
            { /* block id: 72 */
                return l_211[3][0];
            }
            if (g_136)
            { /* block id: 75 */
                uint32_t *l_212 = &g_105;
                uint8_t *l_213 = &g_186[3][1][0];
                union U5 ***l_217[8][2] = {{&l_216[1],(void*)0},{&l_216[1],&l_216[1]},{(void*)0,&l_216[1]},{&l_216[1],(void*)0},{&l_216[1],&l_216[1]},{(void*)0,&l_216[1]},{&l_216[1],(void*)0},{&l_216[1],&l_216[1]}};
                int32_t l_232 = 0L;
                int64_t *l_233 = &g_234[0][0][1];
                int32_t *l_274 = &l_171[1];
                union U4 *l_275 = &g_158;
                int i, j;
                l_215[1] = (p_79 <= (0x33L || (((*l_213) = ((((*l_212) = (&g_100 != (void*)0)) , p_79) && 0UL)) != (l_180 , (((0x668E1CF2L || ((((~3L) , 0xECL) | p_77) >= 0x9B05L)) == g_73) != p_79)))));
                if (((((((g_218[1][1][0] = l_216[1]) == &g_219) ^ ((!(safe_mul_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(0x5BL, (!(g_178[1][8].f1 | (safe_lshift_func_int8_t_s_s(g_186[1][6][6], 1)))))), (l_204 | p_78)))) & ((*l_233) = (((safe_sub_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u(l_215[0])), g_203)) || 9UL) <= l_232)))) > p_78) & l_235) && p_77))
                { /* block id: 81 */
                    uint8_t l_237[2];
                    int32_t l_239[2][3];
                    int32_t l_253[8][7][4] = {{{5L,0xF08E0E4DL,0x9E89ED31L,8L},{0x9E89ED31L,8L,0xFEBC8253L,0x60BF896EL},{0x82A85E6CL,2L,0xF7FF6CDEL,1L},{(-1L),0xF7A61055L,(-9L),1L},{0xA276C94BL,0xB7F49CFEL,0xF7A61055L,0xF7FF6CDEL},{0L,0xCB4D8023L,0x82A85E6CL,0x82A85E6CL},{5L,5L,1L,8L}},{{0L,(-8L),(-1L),1L},{2L,0xFEBC8253L,0xCB4D8023L,(-1L)},{0xB7F49CFEL,0xFEBC8253L,0L,1L},{0xFEBC8253L,(-8L),0xDB0FBA3AL,8L},{0x832A488DL,5L,0x60BF896EL,0x82A85E6CL},{(-5L),0xCB4D8023L,0x0BEC7A0FL,0xF7FF6CDEL},{(-1L),0xB7F49CFEL,8L,1L}},{{0x0BEC7A0FL,0xF7A61055L,(-8L),1L},{0x0994805AL,2L,1L,0x60BF896EL},{0xF7FF6CDEL,8L,0xF08E0E4DL,8L},{(-8L),0xF08E0E4DL,(-6L),0xF7A61055L},{0x60BF896EL,0x2F0E14FAL,0xA276C94BL,5L},{(-1L),0L,(-9L),0x0BEC7A0FL},{(-1L),(-8L),0xB7F49CFEL,5L}},{{0L,0x0BEC7A0FL,0L,0xD24E3423L},{0x82A85E6CL,(-5L),1L,0xDB0FBA3AL},{0xE4E52E89L,0x9E89ED31L,(-1L),0x82A85E6CL},{0xDB0FBA3AL,(-6L),0x82A85E6CL,5L},{0x832A488DL,8L,0xCB4D8023L,0x240C9C9EL},{0x9E89ED31L,0x2F0E14FAL,0x832A488DL,0xDE5116E1L},{0xF7FF6CDEL,0L,0L,0xF7FF6CDEL}},{{(-6L),(-1L),0xDE5116E1L,0x2F0E14FAL},{2L,5L,(-8L),(-8L)},{(-9L),0xD24E3423L,0x1E0AABE5L,(-8L)},{0x60BF896EL,5L,0L,0x2F0E14FAL},{0x240C9C9EL,(-1L),0x0994805AL,0xF7FF6CDEL},{0xC29F5B1EL,0L,0xFEBC8253L,0xDE5116E1L},{(-8L),0x2F0E14FAL,0xF08E0E4DL,0x240C9C9EL}},{{0xB7F49CFEL,8L,1L,5L},{(-5L),(-6L),0xE4E52E89L,0x82A85E6CL},{0xFEBC8253L,0x9E89ED31L,2L,0xDB0FBA3AL},{1L,(-5L),1L,0xD24E3423L},{0xD24E3423L,0x0BEC7A0FL,5L,5L},{1L,(-8L),0xF7A61055L,0x0BEC7A0FL},{1L,0L,0xF7A61055L,0xC29F5B1EL}},{{1L,0x932FCE17L,5L,0xF08E0E4DL},{0xD24E3423L,1L,1L,0xCB4D8023L},{1L,0xCB4D8023L,2L,0L},{0xFEBC8253L,0x60BF896EL,0xE4E52E89L,1L},{(-5L),0xF08E0E4DL,1L,0x0994805AL},{0xB7F49CFEL,(-9L),0xF08E0E4DL,0xE4E52E89L},{(-8L),0x1E0AABE5L,0xFEBC8253L,0xFEBC8253L}},{{0xC29F5B1EL,0xC29F5B1EL,0x0994805AL,(-1L)},{0x240C9C9EL,0x82A85E6CL,0L,(-1L)},{0x60BF896EL,2L,0x1E0AABE5L,0L},{(-9L),2L,(-8L),(-1L)},{2L,0x82A85E6CL,0xDE5116E1L,(-1L)},{(-6L),0xC29F5B1EL,0L,0xFEBC8253L},{0xF7FF6CDEL,0x1E0AABE5L,0x832A488DL,0xE4E52E89L}}};
                    struct S1 l_256 = {0};
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_237[i] = 255UL;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 3; j++)
                            l_239[i][j] = (-1L);
                    }
                    g_6 = g_208;
                    if (l_215[1])
                        continue;
                    if (((void*)0 == &g_218[1][1][0]))
                    { /* block id: 84 */
                        (*l_201) |= l_236;
                        (*l_201) |= ((l_237[0] && (l_239[0][2] &= (g_6 = ((void*)0 == l_238[2])))) < (g_185[2] < (((*l_212) &= l_180.f0) != (+g_177.f1))));
                        l_171[1] &= (l_232 = (safe_rshift_func_uint8_t_u_u(249UL, ((void*)0 == &l_215[1]))));
                    }
                    else
                    { /* block id: 92 */
                        int32_t *l_243[5];
                        union U4 l_247 = {0x61852D11L};
                        union U4 *l_248 = &g_158;
                        union U4 *l_249 = &l_246;
                        int8_t *l_252[4][1];
                        struct S1 *l_257 = &g_81;
                        struct S0 *l_258 = &g_259;
                        int i, j;
                        for (i = 0; i < 5; i++)
                            l_243[i] = &g_6;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_252[i][j] = &g_177.f1;
                        }
                        l_243[4] = &g_14[0][8];
                        g_132 |= (safe_mod_func_uint32_t_u_u((p_78 <= ((((*l_249) = ((*l_248) = (l_246 , l_247))) , (safe_mul_func_uint8_t_u_u(0x96L, (l_253[2][6][3] = p_79)))) || 0x7AL)), (((g_178[1][8].f1 , 5L) && (safe_sub_func_int16_t_s_s(p_79, p_79))) && g_100)));
                        (*l_257) = l_256;
                        return l_258;
                    }
                }
                else
                { /* block id: 101 */
                    uint16_t l_260 = 65528UL;
                    struct S1 l_273 = {-2};
                    if (g_208)
                        break;
                    --l_260;
                    for (l_236 = 2; (l_236 >= 0); l_236 -= 1)
                    { /* block id: 106 */
                        uint8_t l_264 = 255UL;
                        union U5 * const *l_270 = &g_219;
                        if (g_205)
                            goto lbl_263;
                        ++l_264;
                        if (g_14[0][8])
                            break;
                        l_171[0] = ((*l_201) = (((0x54L && g_172) , (safe_rshift_func_uint8_t_u_u((((~(&g_234[0][2][1] != l_233)) , l_270) == &l_148), 5))) | ((safe_mul_func_int16_t_s_s(((l_273 , (g_158.f0 , g_132)) <= 0xEBB0L), (*l_201))) , (-1L))));
                    }
                }
                l_274 = &l_171[0];
                if ((p_78 >= g_259.f6))
                { /* block id: 115 */
                    (*l_274) &= 1L;
                    for (g_205 = 0; (g_205 <= 2); g_205 += 1)
                    { /* block id: 119 */
                        union U4 **l_276 = &l_275;
                        (*l_276) = l_275;
                    }
                    l_202[0][3][5] = &g_14[0][6];
                }
                else
                { /* block id: 123 */
                    return g_277;
                }
            }
            else
            { /* block id: 126 */
                uint32_t l_312 = 0xE0A9D3A4L;
                int32_t l_318 = 0x9AF7FB3CL;
                struct S1 l_335 = {-3};
                int32_t *l_345 = (void*)0;
                struct S1 *l_346 = &g_81;
                for (l_246.f0 = 0; (l_246.f0 <= 2); l_246.f0 += 1)
                { /* block id: 129 */
                    int16_t *l_283 = &g_203;
                    int16_t **l_282 = &l_283;
                    union U4 l_315 = {0L};
                    int32_t l_319 = (-1L);
                    int32_t l_320[8];
                    struct S1 *l_343 = &l_335;
                    int i;
                    for (i = 0; i < 8; i++)
                        l_320[i] = 0xFC19A040L;
                    for (p_77 = 0; (p_77 <= 2); p_77 += 1)
                    { /* block id: 132 */
                        int16_t ***l_288 = &l_286;
                        l_289 = (l_279 , ((*l_288) = (((safe_lshift_func_int16_t_s_u((l_282 == g_284), 2)) > 1UL) , l_286)));
                    }
                    if ((9UL >= (safe_mul_func_uint16_t_u_u(g_278.f7, g_73))))
                    { /* block id: 136 */
                        g_259.f2 |= 3L;
                        return l_292;
                    }
                    else
                    { /* block id: 139 */
                        union U2 **l_316 = &l_304[1];
                        union U2 ***l_317 = &l_316;
                        struct S1 l_336 = {-1};
                        (*l_201) = (safe_mod_func_int16_t_s_s(((safe_mod_func_uint16_t_u_u(l_180.f0, (((g_208 || ((safe_add_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u(((l_304[0] == g_306[1][6]) && l_312), 7)) ^ p_79), ((safe_sub_func_int8_t_s_s(g_308.f2, ((l_315 , ((*l_317) = l_316)) != &l_304[0]))) && p_77))), g_177.f1)) > 0x52L)) >= g_293.f4) || 0x2856L))) || (-1L)), g_105));
                        l_321--;
                        l_171[0] = (((((((0x61C088709E21C6ADLL != (safe_mod_func_int16_t_s_s(0x735CL, ((safe_add_func_uint8_t_u_u(l_235, (safe_add_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s(g_105, (safe_unary_minus_func_int16_t_s(((((((void*)0 != &g_190) > (((l_336 = l_335) , ((safe_div_func_uint32_t_u_u(((l_320[1] = (safe_mod_func_int64_t_s_s((g_132 || ((safe_div_func_uint32_t_u_u((((((p_78 && p_79) <= g_259.f7) == p_79) , l_343) != l_343), l_315.f0)) == p_78)), g_259.f7))) < 0xAEB25E59L), 0x0C7D5AC8L)) == g_293.f6)) <= l_312)) == p_77) , 0x63FD6FBCL) >= 0x90764872L))))) || 0x0B4C9AE7DD1FC34ELL), g_186[2][4][4])) ^ g_344), 3UL)))) , 65532UL)))) == p_77) > 0x0BB389C6337962B1LL) ^ l_279.f0) | (-6L)) >= g_177.f1) && 251UL);
                    }
                    for (l_319 = 2; (l_319 >= 0); l_319 -= 1)
                    { /* block id: 149 */
                        int i, j, k;
                        (*l_201) = (g_277 == (void*)0);
                        l_345 = (l_202[g_100][(l_246.f0 + 1)][g_100] = l_202[l_319][(g_100 + 1)][(g_100 + 2)]);
                    }
                }
                (*l_346) = l_279;
                for (l_246.f0 = 0; (l_246.f0 <= (-2)); l_246.f0 = safe_sub_func_int32_t_s_s(l_246.f0, 2))
                { /* block id: 158 */
                    int32_t *l_349[10] = {&l_171[1],(void*)0,(void*)0,&l_171[1],(void*)0,(void*)0,&l_171[1],(void*)0,(void*)0,&l_171[1]};
                    int32_t *l_351 = &g_344;
                    int i;
                    (*l_201) = ((l_351 = (g_350 = (l_349[8] = (void*)0))) != (void*)0);
                }
            }
        }
        (*l_201) &= p_79;
        g_81.f0 = ((((safe_lshift_func_uint16_t_u_s((p_78 & (!(safe_add_func_int32_t_s_s((safe_mul_func_int8_t_s_s((g_278.f8 , (safe_lshift_func_uint8_t_u_u((l_167 = 252UL), p_77))), (((safe_mul_func_uint16_t_u_u((((~(0x99C612458E79AB5FLL <= (((!((*l_373) ^= ((safe_sub_func_int64_t_s_s((((safe_mod_func_uint16_t_u_u(((g_293.f6 >= ((*l_372) &= ((l_166 = ((((((((**g_284) < ((g_309.f2 = ((((((l_171[0] = ((void*)0 == &g_234[0][0][1])) > g_259.f5) != p_77) & g_136) > g_259.f5) <= g_293.f5)) , l_129)) >= 0x26L) | l_180.f0) && 0L) && l_371) & g_178[1][8].f1) ^ p_79)) > l_235))) || 0x7643B7C93A7CE971LL), 0xB046L)) == g_293.f5) | p_78), g_100)) < g_259.f4))) & 1UL) > g_308.f2))) , 0x552CC7C46ECD58CFLL) , 0x3F52L), p_78)) & l_129) , p_78))), l_129)))), (**g_284))) >= p_79) < 18446744073709551615UL) >= 4294967286UL);
    }
    for (g_132 = (-22); (g_132 < 0); g_132 = safe_add_func_uint32_t_u_u(g_132, 1))
    { /* block id: 177 */
        int32_t **l_377 = &g_350;
        (*l_377) = (void*)0;
    }
    g_259.f8 = p_78;
    return l_380;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_14[i][j], "g_14[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_66[i].f0, "g_66[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_81.f0, "g_81.f0", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_149.f0, "g_149.f0", print_hash_value);
    transparent_crc(g_152.f0, "g_152.f0", print_hash_value);
    transparent_crc(g_158.f0, "g_158.f0", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    transparent_crc(g_177.f0, "g_177.f0", print_hash_value);
    transparent_crc(g_177.f1, "g_177.f1", print_hash_value);
    transparent_crc(g_177.f2, "g_177.f2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_178[i][j].f0, "g_178[i][j].f0", print_hash_value);
            transparent_crc(g_178[i][j].f1, "g_178[i][j].f1", print_hash_value);
            transparent_crc(g_178[i][j].f2, "g_178[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_185[i], "g_185[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_186[i][j][k], "g_186[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_197, "g_197", print_hash_value);
    transparent_crc(g_203, "g_203", print_hash_value);
    transparent_crc(g_205, "g_205", print_hash_value);
    transparent_crc(g_208, "g_208", print_hash_value);
    transparent_crc(g_220.f0, "g_220.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_234[i][j][k], "g_234[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_259.f0, "g_259.f0", print_hash_value);
    transparent_crc(g_259.f1, "g_259.f1", print_hash_value);
    transparent_crc(g_259.f2, "g_259.f2", print_hash_value);
    transparent_crc(g_259.f3, "g_259.f3", print_hash_value);
    transparent_crc(g_259.f4, "g_259.f4", print_hash_value);
    transparent_crc(g_259.f5, "g_259.f5", print_hash_value);
    transparent_crc(g_259.f6, "g_259.f6", print_hash_value);
    transparent_crc(g_259.f7, "g_259.f7", print_hash_value);
    transparent_crc(g_259.f8, "g_259.f8", print_hash_value);
    transparent_crc(g_278.f0, "g_278.f0", print_hash_value);
    transparent_crc(g_278.f1, "g_278.f1", print_hash_value);
    transparent_crc(g_278.f2, "g_278.f2", print_hash_value);
    transparent_crc(g_278.f3, "g_278.f3", print_hash_value);
    transparent_crc(g_278.f4, "g_278.f4", print_hash_value);
    transparent_crc(g_278.f5, "g_278.f5", print_hash_value);
    transparent_crc(g_278.f6, "g_278.f6", print_hash_value);
    transparent_crc(g_278.f7, "g_278.f7", print_hash_value);
    transparent_crc(g_278.f8, "g_278.f8", print_hash_value);
    transparent_crc(g_293.f0, "g_293.f0", print_hash_value);
    transparent_crc(g_293.f1, "g_293.f1", print_hash_value);
    transparent_crc(g_293.f2, "g_293.f2", print_hash_value);
    transparent_crc(g_293.f3, "g_293.f3", print_hash_value);
    transparent_crc(g_293.f4, "g_293.f4", print_hash_value);
    transparent_crc(g_293.f5, "g_293.f5", print_hash_value);
    transparent_crc(g_293.f6, "g_293.f6", print_hash_value);
    transparent_crc(g_293.f7, "g_293.f7", print_hash_value);
    transparent_crc(g_293.f8, "g_293.f8", print_hash_value);
    transparent_crc(g_305.f0, "g_305.f0", print_hash_value);
    transparent_crc(g_305.f1, "g_305.f1", print_hash_value);
    transparent_crc(g_305.f2, "g_305.f2", print_hash_value);
    transparent_crc(g_307.f0, "g_307.f0", print_hash_value);
    transparent_crc(g_307.f1, "g_307.f1", print_hash_value);
    transparent_crc(g_307.f2, "g_307.f2", print_hash_value);
    transparent_crc(g_308.f0, "g_308.f0", print_hash_value);
    transparent_crc(g_308.f1, "g_308.f1", print_hash_value);
    transparent_crc(g_308.f2, "g_308.f2", print_hash_value);
    transparent_crc(g_309.f0, "g_309.f0", print_hash_value);
    transparent_crc(g_309.f1, "g_309.f1", print_hash_value);
    transparent_crc(g_309.f2, "g_309.f2", print_hash_value);
    transparent_crc(g_310.f0, "g_310.f0", print_hash_value);
    transparent_crc(g_310.f1, "g_310.f1", print_hash_value);
    transparent_crc(g_310.f2, "g_310.f2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_311[i].f0, "g_311[i].f0", print_hash_value);
        transparent_crc(g_311[i].f1, "g_311[i].f1", print_hash_value);
        transparent_crc(g_311[i].f2, "g_311[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_344, "g_344", print_hash_value);
    transparent_crc(g_374, "g_374", print_hash_value);
    transparent_crc(g_381.f0, "g_381.f0", print_hash_value);
    transparent_crc(g_381.f1, "g_381.f1", print_hash_value);
    transparent_crc(g_381.f2, "g_381.f2", print_hash_value);
    transparent_crc(g_381.f3, "g_381.f3", print_hash_value);
    transparent_crc(g_381.f4, "g_381.f4", print_hash_value);
    transparent_crc(g_381.f5, "g_381.f5", print_hash_value);
    transparent_crc(g_381.f6, "g_381.f6", print_hash_value);
    transparent_crc(g_381.f7, "g_381.f7", print_hash_value);
    transparent_crc(g_381.f8, "g_381.f8", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_423[i], "g_423[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_431.f0, "g_431.f0", print_hash_value);
    transparent_crc(g_431.f1, "g_431.f1", print_hash_value);
    transparent_crc(g_431.f2, "g_431.f2", print_hash_value);
    transparent_crc(g_444.f0, "g_444.f0", print_hash_value);
    transparent_crc(g_483, "g_483", print_hash_value);
    transparent_crc(g_511, "g_511", print_hash_value);
    transparent_crc(g_535.f0, "g_535.f0", print_hash_value);
    transparent_crc(g_536.f0, "g_536.f0", print_hash_value);
    transparent_crc(g_537.f0, "g_537.f0", print_hash_value);
    transparent_crc(g_546.f0, "g_546.f0", print_hash_value);
    transparent_crc(g_546.f1, "g_546.f1", print_hash_value);
    transparent_crc(g_546.f2, "g_546.f2", print_hash_value);
    transparent_crc(g_695.f0, "g_695.f0", print_hash_value);
    transparent_crc(g_707.f0, "g_707.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_722[i].f0, "g_722[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_724.f0, "g_724.f0", print_hash_value);
    transparent_crc(g_824.f0, "g_824.f0", print_hash_value);
    transparent_crc(g_824.f1, "g_824.f1", print_hash_value);
    transparent_crc(g_824.f2, "g_824.f2", print_hash_value);
    transparent_crc(g_842.f0, "g_842.f0", print_hash_value);
    transparent_crc(g_842.f1, "g_842.f1", print_hash_value);
    transparent_crc(g_842.f2, "g_842.f2", print_hash_value);
    transparent_crc(g_842.f3, "g_842.f3", print_hash_value);
    transparent_crc(g_842.f4, "g_842.f4", print_hash_value);
    transparent_crc(g_842.f5, "g_842.f5", print_hash_value);
    transparent_crc(g_842.f6, "g_842.f6", print_hash_value);
    transparent_crc(g_842.f7, "g_842.f7", print_hash_value);
    transparent_crc(g_842.f8, "g_842.f8", print_hash_value);
    transparent_crc(g_861, "g_861", print_hash_value);
    transparent_crc(g_865, "g_865", print_hash_value);
    transparent_crc(g_900.f0, "g_900.f0", print_hash_value);
    transparent_crc(g_920.f0, "g_920.f0", print_hash_value);
    transparent_crc(g_920.f1, "g_920.f1", print_hash_value);
    transparent_crc(g_920.f2, "g_920.f2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_953[i][j].f0, "g_953[i][j].f0", print_hash_value);
            transparent_crc(g_953[i][j].f1, "g_953[i][j].f1", print_hash_value);
            transparent_crc(g_953[i][j].f2, "g_953[i][j].f2", print_hash_value);
            transparent_crc(g_953[i][j].f3, "g_953[i][j].f3", print_hash_value);
            transparent_crc(g_953[i][j].f4, "g_953[i][j].f4", print_hash_value);
            transparent_crc(g_953[i][j].f5, "g_953[i][j].f5", print_hash_value);
            transparent_crc(g_953[i][j].f6, "g_953[i][j].f6", print_hash_value);
            transparent_crc(g_953[i][j].f7, "g_953[i][j].f7", print_hash_value);
            transparent_crc(g_953[i][j].f8, "g_953[i][j].f8", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1015.f0, "g_1015.f0", print_hash_value);
    transparent_crc(g_1025, "g_1025", print_hash_value);
    transparent_crc(g_1051, "g_1051", print_hash_value);
    transparent_crc(g_1062, "g_1062", print_hash_value);
    transparent_crc(g_1123.f0, "g_1123.f0", print_hash_value);
    transparent_crc(g_1123.f1, "g_1123.f1", print_hash_value);
    transparent_crc(g_1123.f2, "g_1123.f2", print_hash_value);
    transparent_crc(g_1125, "g_1125", print_hash_value);
    transparent_crc(g_1159.f0, "g_1159.f0", print_hash_value);
    transparent_crc(g_1159.f1, "g_1159.f1", print_hash_value);
    transparent_crc(g_1159.f2, "g_1159.f2", print_hash_value);
    transparent_crc(g_1167, "g_1167", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1168[i], "g_1168[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1237.f0, "g_1237.f0", print_hash_value);
    transparent_crc(g_1237.f1, "g_1237.f1", print_hash_value);
    transparent_crc(g_1237.f2, "g_1237.f2", print_hash_value);
    transparent_crc(g_1237.f3, "g_1237.f3", print_hash_value);
    transparent_crc(g_1237.f4, "g_1237.f4", print_hash_value);
    transparent_crc(g_1237.f5, "g_1237.f5", print_hash_value);
    transparent_crc(g_1237.f6, "g_1237.f6", print_hash_value);
    transparent_crc(g_1237.f7, "g_1237.f7", print_hash_value);
    transparent_crc(g_1237.f8, "g_1237.f8", print_hash_value);
    transparent_crc(g_1267.f0, "g_1267.f0", print_hash_value);
    transparent_crc(g_1312.f0, "g_1312.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1331[i].f0, "g_1331[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1335[i][j][k].f0, "g_1335[i][j][k].f0", print_hash_value);
                transparent_crc(g_1335[i][j][k].f1, "g_1335[i][j][k].f1", print_hash_value);
                transparent_crc(g_1335[i][j][k].f2, "g_1335[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1339.f0, "g_1339.f0", print_hash_value);
    transparent_crc(g_1339.f1, "g_1339.f1", print_hash_value);
    transparent_crc(g_1339.f2, "g_1339.f2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_1373[i][j][k].f0, "g_1373[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1374[i][j].f0, "g_1374[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1413, "g_1413", print_hash_value);
    transparent_crc(g_1434, "g_1434", print_hash_value);
    transparent_crc(g_1446.f0, "g_1446.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1458[i].f0, "g_1458[i].f0", print_hash_value);
        transparent_crc(g_1458[i].f1, "g_1458[i].f1", print_hash_value);
        transparent_crc(g_1458[i].f2, "g_1458[i].f2", print_hash_value);
        transparent_crc(g_1458[i].f3, "g_1458[i].f3", print_hash_value);
        transparent_crc(g_1458[i].f4, "g_1458[i].f4", print_hash_value);
        transparent_crc(g_1458[i].f5, "g_1458[i].f5", print_hash_value);
        transparent_crc(g_1458[i].f6, "g_1458[i].f6", print_hash_value);
        transparent_crc(g_1458[i].f7, "g_1458[i].f7", print_hash_value);
        transparent_crc(g_1458[i].f8, "g_1458[i].f8", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1486.f0, "g_1486.f0", print_hash_value);
    transparent_crc(g_1486.f1, "g_1486.f1", print_hash_value);
    transparent_crc(g_1486.f2, "g_1486.f2", print_hash_value);
    transparent_crc(g_1504.f0, "g_1504.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 339
   depth: 1, occurrence: 25
XXX total union variables: 26

XXX non-zero bitfields defined in structs: 11
XXX zero bitfields defined in structs: 1
XXX const bitfields defined in structs: 2
XXX volatile bitfields defined in structs: 3
XXX structs with bitfields in the program: 48
breakdown:
   indirect level: 0, occurrence: 25
   indirect level: 1, occurrence: 12
   indirect level: 2, occurrence: 6
   indirect level: 3, occurrence: 4
   indirect level: 4, occurrence: 1
XXX full-bitfields structs in the program: 25
breakdown:
   indirect level: 0, occurrence: 25
XXX times a bitfields struct's address is taken: 113
XXX times a bitfields struct on LHS: 6
XXX times a bitfields struct on RHS: 31
XXX times a single bitfield on LHS: 17
XXX times a single bitfield on RHS: 92

XXX max expression depth: 53
breakdown:
   depth: 1, occurrence: 175
   depth: 2, occurrence: 42
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 22, occurrence: 3
   depth: 23, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 35, occurrence: 2
   depth: 37, occurrence: 1
   depth: 42, occurrence: 1
   depth: 46, occurrence: 1
   depth: 53, occurrence: 1

XXX total number of pointers: 369

XXX times a variable address is taken: 835
XXX times a pointer is dereferenced on RHS: 153
breakdown:
   depth: 1, occurrence: 112
   depth: 2, occurrence: 41
XXX times a pointer is dereferenced on LHS: 184
breakdown:
   depth: 1, occurrence: 172
   depth: 2, occurrence: 11
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 30
XXX times a pointer is compared with address of another variable: 9
XXX times a pointer is compared with another pointer: 11
XXX times a pointer is qualified to be dereferenced: 3006

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 914
   level: 2, occurrence: 134
   level: 3, occurrence: 19
   level: 4, occurrence: 2
XXX number of pointers point to pointers: 113
XXX number of pointers point to scalars: 194
XXX number of pointers point to structs: 26
XXX percent of pointers has null in alias set: 27.4
XXX average alias set size: 1.38

XXX times a non-volatile is read: 1179
XXX times a non-volatile is write: 563
XXX times a volatile is read: 70
XXX    times read thru a pointer: 23
XXX times a volatile is write: 26
XXX    times written thru a pointer: 19
XXX times a volatile is available for access: 1.42e+03
XXX percentage of non-volatile access: 94.8

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 164
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 23
   depth: 2, occurrence: 19
   depth: 3, occurrence: 19
   depth: 4, occurrence: 35
   depth: 5, occurrence: 40

XXX percentage a fresh-made variable is used: 19.9
XXX percentage an existing variable is used: 80.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

