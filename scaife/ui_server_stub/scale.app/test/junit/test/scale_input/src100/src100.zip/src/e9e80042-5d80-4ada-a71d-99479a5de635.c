/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3879303351
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   volatile signed f0 : 26;
   signed f1 : 9;
   volatile unsigned f2 : 8;
   signed f3 : 19;
   int32_t  f4;
};
#pragma pack(pop)

struct S1 {
   signed f0 : 24;
   unsigned f1 : 17;
   signed f2 : 22;
   volatile unsigned : 0;
   volatile signed f3 : 13;
   signed f4 : 21;
   signed f5 : 22;
   volatile unsigned f6 : 17;
};

union U2 {
   unsigned f0 : 25;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_4[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
static const volatile int32_t g_30 = 0L;/* VOLATILE GLOBAL g_30 */
static int32_t g_33 = 8L;
static int32_t g_36 = 6L;
static int32_t g_40 = 5L;
static int16_t g_48[10] = {0x58F8L,(-1L),0x58F8L,0L,0L,0x58F8L,(-1L),0x58F8L,0L,0L};
static uint16_t g_50 = 1UL;
static volatile struct S1 g_74 = {1277,143,-24,-61,27,163,213};/* VOLATILE GLOBAL g_74 */
static uint8_t g_96 = 249UL;
static int32_t *g_100 = (void*)0;
static int32_t ** volatile g_99 = &g_100;/* VOLATILE GLOBAL g_99 */
static int64_t g_102 = 0x0B67C402FB512259LL;
static uint16_t g_104 = 65532UL;
static uint16_t *g_103 = &g_104;
static uint64_t g_106 = 0x6296EF6A07EB839BLL;
static uint32_t g_107 = 0x2AA969AAL;
static int32_t * const  volatile g_108 = &g_40;/* VOLATILE GLOBAL g_108 */
static int32_t * volatile g_114 = &g_40;/* VOLATILE GLOBAL g_114 */
static union U2 *g_124 = (void*)0;
static union U2 g_126[4][1] = {{{0xB0794679L}},{{0xB0794679L}},{{0xB0794679L}},{{0xB0794679L}}};
static int32_t g_149 = 0xDD07668EL;
static int32_t * volatile g_148 = &g_149;/* VOLATILE GLOBAL g_148 */
static struct S1 g_153 = {1336,121,85,54,-674,-148,218};/* VOLATILE GLOBAL g_153 */
static struct S0 g_159[7][3][8] = {{{{5375,-17,12,-54,-8L},{2189,11,11,-472,1L},{-4154,15,10,122,0x3125455DL},{6179,6,2,195,0xCC15F2E4L},{2649,-7,9,656,0xBFFB9DE4L},{1763,12,9,-77,-1L},{-235,21,3,-59,-1L},{7444,20,5,-657,0x3F436BBBL}},{{6017,-8,4,445,-5L},{2189,11,11,-472,1L},{-2930,-9,2,-323,0x0FF9CC6DL},{6784,6,5,-510,0x735459D1L},{8117,-3,15,-288,-3L},{1647,16,15,529,0xD61A28F2L},{1673,18,10,568,1L},{-1515,8,6,718,1L}},{{5940,-11,11,684,0x27877F70L},{-3210,1,7,-636,0x03803073L},{-2938,17,9,249,0xFDFC6210L},{2993,20,6,448,-6L},{-3453,-21,7,315,6L},{6179,6,2,195,0xCC15F2E4L},{-2009,9,15,-553,5L},{-6511,-7,10,366,-1L}}},{{{-173,20,12,40,0xC2DAC23FL},{-6812,16,12,-429,0x6BF972A1L},{6502,-8,6,0,0x7C2C8185L},{-960,20,13,187,0x3BAF00BCL},{-2099,12,6,688,0x0A6F42BAL},{5357,3,7,-235,-1L},{-319,18,5,617,5L},{238,12,5,453,7L}},{{-6812,16,12,-429,0x6BF972A1L},{6552,-7,1,409,1L},{2993,20,6,448,-6L},{5477,-18,13,-305,0x0D4F074CL},{941,-5,2,-677,0x4284727EL},{2670,-4,5,667,0x8FED00A9L},{6017,-8,4,445,-5L},{-6812,16,12,-429,0x6BF972A1L}},{{2952,-4,2,562,2L},{5357,3,7,-235,-1L},{1839,-20,4,-326,0x4E14C39AL},{5291,-0,14,-722,0xA31BD4A4L},{6179,6,2,195,0xCC15F2E4L},{-3925,-15,7,-276,0xD25ECE1FL},{46,-9,9,133,0xA2498811L},{6450,0,15,-504,0x85D562BBL}}},{{{3163,13,6,-56,0x7FF8115BL},{6784,6,5,-510,0x735459D1L},{-3910,4,15,489,2L},{5375,-17,12,-54,-8L},{8117,-3,15,-288,-3L},{-2390,14,12,627,0xC26539BAL},{7748,3,1,458,2L},{2670,-4,5,667,0x8FED00A9L}},{{7320,-3,2,-10,0x72512C82L},{-8169,6,2,-373,3L},{4969,18,2,-497,-4L},{2309,18,4,-327,0x9C3F61B7L},{2189,11,11,-472,1L},{1839,-20,4,-326,0x4E14C39AL},{-3453,-21,7,315,6L},{-319,18,5,617,5L}},{{7748,3,1,458,2L},{-7053,12,6,-559,0x1719B2E0L},{-4655,-8,13,-494,0xBD967F9DL},{-2938,17,9,249,0xFDFC6210L},{-945,-9,11,-365,0xFD1FBCF3L},{-2938,17,9,249,0xFDFC6210L},{-4655,-8,13,-494,0xBD967F9DL},{-7053,12,6,-559,0x1719B2E0L}}},{{{6502,-8,6,0,0x7C2C8185L},{4240,3,6,-254,-10L},{-3925,-15,7,-276,0xD25ECE1FL},{2189,11,11,-472,1L},{-6511,-7,10,366,-1L},{-2930,-9,2,-323,0x0FF9CC6DL},{238,12,5,453,7L},{-5962,-20,10,-631,0xB8834005L}},{{4969,18,2,-497,-4L},{3229,-1,7,-429,0x133990FFL},{-5962,-20,10,-631,0xB8834005L},{2952,-4,2,562,2L},{6502,-8,6,0,0x7C2C8185L},{-4154,15,10,122,0x3125455DL},{238,12,5,453,7L},{7320,-3,2,-10,0x72512C82L}},{{-6812,16,12,-429,0x6BF972A1L},{2952,-4,2,562,2L},{-3925,-15,7,-276,0xD25ECE1FL},{-2930,-9,2,-323,0x0FF9CC6DL},{-2390,14,12,627,0xC26539BAL},{-3210,1,7,-636,0x03803073L},{-4655,-8,13,-494,0xBD967F9DL},{5291,-0,14,-722,0xA31BD4A4L}}},{{{-2390,14,12,627,0xC26539BAL},{-3210,1,7,-636,0x03803073L},{-4655,-8,13,-494,0xBD967F9DL},{5291,-0,14,-722,0xA31BD4A4L},{6552,-7,1,409,1L},{2649,-7,9,656,0xBFFB9DE4L},{-3453,-21,7,315,6L},{-960,20,13,187,0x3BAF00BCL}},{{3229,-1,7,-429,0x133990FFL},{-319,18,5,617,5L},{4969,18,2,-497,-4L},{3163,13,6,-56,0x7FF8115BL},{-7053,12,6,-559,0x1719B2E0L},{-235,21,3,-59,-1L},{7748,3,1,458,2L},{5375,-17,12,-54,-8L}},{{-173,20,12,40,0xC2DAC23FL},{-6692,-8,12,-525,-7L},{-3910,4,15,489,2L},{4138,3,15,109,6L},{656,-19,2,-494,-3L},{2189,11,11,-472,1L},{46,-9,9,133,0xA2498811L},{238,12,5,453,7L}}},{{{-6692,-8,12,-525,-7L},{-7053,12,6,-559,0x1719B2E0L},{1839,-20,4,-326,0x4E14C39AL},{941,-5,2,-677,0x4284727EL},{-2563,-12,13,195,1L},{5934,-18,7,-59,-1L},{6017,-8,4,445,-5L},{-6692,-8,12,-525,-7L}},{{6075,2,8,195,-1L},{1375,-3,14,-408,0xD05B2AB3L},{2993,20,6,448,-6L},{-3944,-13,6,-61,-1L},{-6511,-7,10,366,-1L},{-3925,-15,7,-276,0xD25ECE1FL},{-319,18,5,617,5L},{8117,-3,15,-288,-3L}},{{-3910,4,15,489,2L},{7444,20,5,-657,0x3F436BBBL},{6502,-8,6,0,0x7C2C8185L},{-235,21,3,-59,-1L},{8117,-3,15,-288,-3L},{-2009,9,15,-553,5L},{7320,-3,2,-10,0x72512C82L},{7320,-3,2,-10,0x72512C82L}}},{{{2670,-4,5,667,0x8FED00A9L},{-2938,17,9,249,0xFDFC6210L},{2309,18,4,-327,0x9C3F61B7L},{2309,18,4,-327,0x9C3F61B7L},{-2938,17,9,249,0xFDFC6210L},{2670,-4,5,667,0x8FED00A9L},{-3944,-13,6,-61,-1L},{3229,-1,7,-429,0x133990FFL}},{{5934,-18,7,-59,-1L},{-4154,15,10,122,0x3125455DL},{-4655,-8,13,-494,0xBD967F9DL},{5357,3,7,-235,-1L},{6450,0,15,-504,0x85D562BBL},{1763,12,9,-77,-1L},{4138,3,15,109,6L},{6552,-7,1,409,1L}},{{3163,13,6,-56,0x7FF8115BL},{4240,3,6,-254,-10L},{-173,20,12,40,0xC2DAC23FL},{5357,3,7,-235,-1L},{-5962,-20,10,-631,0xB8834005L},{-235,21,3,-59,-1L},{-3112,-19,1,233,0x91C28AAAL},{3229,-1,7,-429,0x133990FFL}}}};
static int32_t * volatile g_163[7][8] = {{&g_36,&g_149,&g_36,&g_149,&g_149,&g_149,&g_149,&g_36},{&g_149,&g_149,&g_149,(void*)0,&g_33,(void*)0,&g_149,&g_149},{&g_149,&g_36,&g_149,&g_149,&g_149,&g_149,&g_36,&g_149},{&g_36,(void*)0,&g_149,(void*)0,&g_149,(void*)0,&g_36,&g_36},{(void*)0,(void*)0,&g_149,&g_149,(void*)0,(void*)0,&g_149,(void*)0},{(void*)0,(void*)0,&g_149,(void*)0,(void*)0,&g_149,&g_149,&g_149},{&g_36,(void*)0,(void*)0,&g_36,&g_33,&g_149,&g_33,&g_36}};
static int8_t g_184[7] = {0x6CL,0x6CL,0x6CL,0x6CL,0x6CL,0x6CL,0x6CL};
static uint8_t g_187 = 1UL;
static volatile uint64_t * const  volatile *g_189 = (void*)0;
static volatile uint64_t * const  volatile ** volatile g_190 = &g_189;/* VOLATILE GLOBAL g_190 */
static int64_t g_202 = 0x7905C1DEC4DA857BLL;
static int32_t g_203[9][9][3] = {{{0x7E24B3D2L,(-1L),1L},{(-5L),0xFED949C4L,0L},{0xB957851BL,0x02BF3D27L,0x5D76A2BAL},{(-3L),(-5L),0x097C5824L},{1L,(-1L),0L},{(-1L),1L,1L},{0xD9FA94B1L,1L,(-6L)},{1L,0x1D69343EL,1L},{0x6A971BE7L,0xEE8C25C5L,4L}},{{0xEF3DB105L,1L,(-5L)},{0x609D93A6L,0xEE8C25C5L,0xCB9B15BCL},{0x0FD3D768L,0x1D69343EL,0L},{0xB0871CD1L,1L,(-1L)},{0xAD31C045L,1L,(-1L)},{6L,(-1L),0x181D7501L},{0x1D69343EL,(-5L),0x1D69343EL},{0xE776B26CL,0x02BF3D27L,0xB0871CD1L},{0x12867139L,0xFED949C4L,0x7A7E32EAL}},{{0x5D76A2BAL,(-1L),0x6A971BE7L},{6L,0L,3L},{0x5D76A2BAL,1L,1L},{0x12867139L,0x760C6957L,1L},{0xE776B26CL,0xB4079A8AL,0xB957851BL},{0x1D69343EL,(-5L),1L},{6L,(-1L),0x18FED6ADL},{0xAD31C045L,0xAD31C045L,0x669614EAL},{0xB0871CD1L,3L,6L}},{{0x0FD3D768L,1L,(-1L)},{0x609D93A6L,0L,0xF078178AL},{0xEF3DB105L,0x0FD3D768L,(-1L)},{0x6A971BE7L,0L,6L},{1L,0xC5B9279EL,0x669614EAL},{0xD9FA94B1L,0L,0x18FED6ADL},{(-1L),0x097C5824L,1L},{1L,0xD02CFC97L,0xB957851BL},{(-3L),0x148729FDL,1L}},{{0xB957851BL,0x9418F546L,1L},{(-5L),0xEF3DB105L,3L},{0x7E24B3D2L,0xB3D9BBB4L,0x6A971BE7L},{0xF42256BBL,0xEF3DB105L,0x7A7E32EAL},{0xC258296FL,0x9418F546L,0xB0871CD1L},{0L,0x148729FDL,0x1D69343EL},{0x7B85D166L,0xD02CFC97L,0x181D7501L},{0L,0x097C5824L,(-1L)},{(-1L),0L,(-1L)}},{{(-1L),0xC5B9279EL,0L},{(-10L),0L,0xCB9B15BCL},{0x669614EAL,0x0FD3D768L,(-5L)},{0xC5E22E70L,0L,4L},{0x669614EAL,1L,1L},{(-10L),3L,(-6L)},{(-1L),0xAD31C045L,1L},{(-1L),(-1L),0L},{0L,(-5L),0x097C5824L}},{{0x7B85D166L,0xB4079A8AL,0x5D76A2BAL},{0L,0x760C6957L,0L},{0xC258296FL,1L,1L},{0xF42256BBL,0L,0x148729FDL},{0x18FED6ADL,4L,0L},{6L,0xEF3DB105L,0L},{0x609D93A6L,0xC81B91DDL,6L},{(-5L),(-1L),0xC5B9279EL},{0L,0x02BF3D27L,(-6L)}},{{1L,0xF42256BBL,0xF42256BBL},{0x6551609BL,0x9418F546L,0x7B85D166L},{0xF42256BBL,0x760C6957L,(-1L)},{0xC5E22E70L,(-1L),0xADDCDD08L},{0x097C5824L,0xAD31C045L,6L},{(-3L),(-1L),0xF078178AL},{0x669614EAL,0x760C6957L,3L},{4L,0x9418F546L,0x6F68FCF2L},{1L,0xF42256BBL,(-1L)}},{{0xB0871CD1L,0x02BF3D27L,0xE776B26CL},{0x760C6957L,(-1L),0x760C6957L},{(-10L),0xC81B91DDL,4L},{1L,0xEF3DB105L,0x148729FDL},{6L,4L,0xC5E22E70L},{(-3L),0L,0x97F3C724L},{6L,0xB3D9BBB4L,1L},{1L,0x0FD3D768L,0xAD31C045L},{(-10L),0x960E54F6L,0x609D93A6L}}};
static struct S1 g_228 = {-364,48,-1445,50,1052,1934,34};/* VOLATILE GLOBAL g_228 */
static const union U2 ** volatile g_232 = (void*)0;/* VOLATILE GLOBAL g_232 */
static union U2 **g_251 = &g_124;
static struct S1 g_274 = {1146,82,523,10,-1123,812,289};/* VOLATILE GLOBAL g_274 */
static int32_t g_279 = 0x6EB8B460L;
static volatile struct S1 g_288 = {-1861,14,1370,-71,754,180,300};/* VOLATILE GLOBAL g_288 */
static uint64_t g_311 = 18446744073709551615UL;
static int32_t * volatile g_395 = (void*)0;/* VOLATILE GLOBAL g_395 */
static int32_t * volatile g_396 = &g_203[6][8][2];/* VOLATILE GLOBAL g_396 */
static struct S1 g_397 = {1240,117,1203,39,767,-1103,269};/* VOLATILE GLOBAL g_397 */
static struct S0 g_405[9][7] = {{{-5105,-3,11,349,0xEA0E835CL},{-5105,-3,11,349,0xEA0E835CL},{7625,-17,12,231,0x265F740AL},{1269,2,0,-699,-1L},{1441,-4,15,-421,-1L},{7625,-17,12,231,0x265F740AL},{1441,-4,15,-421,-1L}},{{1269,2,0,-699,-1L},{5427,-7,0,319,-1L},{5427,-7,0,319,-1L},{1269,2,0,-699,-1L},{6276,-8,9,614,0x931866CFL},{-6375,7,10,172,8L},{1269,2,0,-699,-1L}},{{-6375,7,10,172,8L},{1441,-4,15,-421,-1L},{6276,-8,9,614,0x931866CFL},{6276,-8,9,614,0x931866CFL},{1441,-4,15,-421,-1L},{-6375,7,10,172,8L},{5427,-7,0,319,-1L}},{{1441,-4,15,-421,-1L},{1269,2,0,-699,-1L},{7625,-17,12,231,0x265F740AL},{-5105,-3,11,349,0xEA0E835CL},{-5105,-3,11,349,0xEA0E835CL},{7625,-17,12,231,0x265F740AL},{1269,2,0,-699,-1L}},{{1441,-4,15,-421,-1L},{5427,-7,0,319,-1L},{-6375,7,10,172,8L},{1441,-4,15,-421,-1L},{6276,-8,9,614,0x931866CFL},{6276,-8,9,614,0x931866CFL},{1441,-4,15,-421,-1L}},{{-6375,7,10,172,8L},{1269,2,0,-699,-1L},{-6375,7,10,172,8L},{6276,-8,9,614,0x931866CFL},{1269,2,0,-699,-1L},{5427,-7,0,319,-1L},{5427,-7,0,319,-1L}},{{1269,2,0,-699,-1L},{1441,-4,15,-421,-1L},{7625,-17,12,231,0x265F740AL},{1441,-4,15,-421,-1L},{1269,2,0,-699,-1L},{7625,-17,12,231,0x265F740AL},{-5105,-3,11,349,0xEA0E835CL}},{{-5105,-3,11,349,0xEA0E835CL},{5427,-7,0,319,-1L},{6276,-8,9,614,0x931866CFL},{-5105,-3,11,349,0xEA0E835CL},{6276,-8,9,614,0x931866CFL},{5427,-7,0,319,-1L},{-5105,-3,11,349,0xEA0E835CL}},{{-6375,7,10,172,8L},{-5105,-3,11,349,0xEA0E835CL},{5427,-7,0,319,-1L},{6276,-8,9,614,0x931866CFL},{-5105,-3,11,349,0xEA0E835CL},{6276,-8,9,614,0x931866CFL},{5427,-7,0,319,-1L}}};
static int8_t g_428 = 0x2CL;
static volatile uint8_t g_436 = 0x1BL;/* VOLATILE GLOBAL g_436 */
static int32_t ** volatile g_439 = &g_100;/* VOLATILE GLOBAL g_439 */
static int32_t * volatile g_441 = (void*)0;/* VOLATILE GLOBAL g_441 */
static volatile int32_t g_450[3] = {0x9094F612L,0x9094F612L,0x9094F612L};
static volatile int32_t *g_449 = &g_450[0];
static volatile int32_t ** volatile g_448 = &g_449;/* VOLATILE GLOBAL g_448 */
static volatile struct S1 g_474 = {2696,202,1220,45,-836,2026,172};/* VOLATILE GLOBAL g_474 */
static struct S0 g_511[7] = {{-1230,19,9,553,9L},{-1230,19,9,553,9L},{3820,-4,14,-231,0x5C01F232L},{-1230,19,9,553,9L},{-1230,19,9,553,9L},{3820,-4,14,-231,0x5C01F232L},{-1230,19,9,553,9L}};
static struct S0 * volatile g_512 = &g_405[0][4];/* VOLATILE GLOBAL g_512 */
static union U2 * const *g_525 = &g_124;
static union U2 * const **g_524 = &g_525;
static uint8_t g_614[7] = {1UL,0x7FL,0x7FL,1UL,0x7FL,0x7FL,1UL};
static int32_t ** volatile g_617 = &g_100;/* VOLATILE GLOBAL g_617 */
static struct S1 g_646 = {2941,242,1409,79,234,-1542,298};/* VOLATILE GLOBAL g_646 */
static int32_t * volatile g_706 = &g_203[1][7][1];/* VOLATILE GLOBAL g_706 */
static volatile struct S0 g_707 = {-367,3,13,-189,-10L};/* VOLATILE GLOBAL g_707 */
static volatile struct S0 * volatile g_709 = &g_707;/* VOLATILE GLOBAL g_709 */
static int32_t ** volatile g_710 = &g_100;/* VOLATILE GLOBAL g_710 */
static uint32_t g_714 = 0xC2DA02AFL;
static volatile struct S0 g_722 = {-4283,3,12,-166,0x6BB5DA25L};/* VOLATILE GLOBAL g_722 */
static struct S1 g_729 = {-3816,324,-618,19,-1083,1846,350};/* VOLATILE GLOBAL g_729 */
static int8_t g_749 = 0xEBL;
static int16_t g_751 = 0x3B4BL;
static struct S0 g_752 = {2011,2,1,236,0x5709D868L};/* VOLATILE GLOBAL g_752 */
static struct S1 *g_753 = &g_729;
static struct S1 *g_754 = &g_228;
static int64_t *g_819[8][2][8] = {{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}},{{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102},{&g_102,&g_102,&g_202,(void*)0,(void*)0,&g_202,&g_102,&g_102}}};
static int64_t **g_818 = &g_819[3][0][3];
static struct S0 g_833 = {391,-7,1,211,-2L};/* VOLATILE GLOBAL g_833 */
static uint16_t g_852 = 0x2AC4L;
static struct S1 g_858 = {-1002,162,1182,5,1237,-1582,300};/* VOLATILE GLOBAL g_858 */
static volatile uint8_t g_860 = 254UL;/* VOLATILE GLOBAL g_860 */
static volatile struct S1 g_871 = {-2163,211,-82,2,83,78,211};/* VOLATILE GLOBAL g_871 */
static const int32_t *g_884 = &g_149;
static const int32_t ** volatile g_883 = &g_884;/* VOLATILE GLOBAL g_883 */
static int8_t g_885 = 0L;
static struct S0 g_917 = {-4929,-7,14,-316,0L};/* VOLATILE GLOBAL g_917 */
static struct S0 g_918 = {4436,3,10,-32,-1L};/* VOLATILE GLOBAL g_918 */
static int32_t g_968 = 0L;
static uint64_t *g_986 = &g_106;
static uint64_t **g_985 = &g_986;
static int16_t *g_1011 = (void*)0;
static int16_t * volatile * const  volatile g_1010 = &g_1011;/* VOLATILE GLOBAL g_1010 */
static int64_t *** const  volatile g_1059 = &g_818;/* VOLATILE GLOBAL g_1059 */
static uint16_t g_1094 = 0x32ABL;
static uint32_t g_1115 = 6UL;
static struct S1 **g_1119 = (void*)0;
static volatile struct S1 g_1186[2] = {{2682,84,-734,82,-1280,-298,274},{2682,84,-734,82,-1280,-298,274}};
static union U2 *g_1221 = &g_126[2][0];
static struct S1 g_1286 = {3149,79,1703,5,232,-212,330};/* VOLATILE GLOBAL g_1286 */
static struct S1 g_1290 = {2404,127,-914,-27,1017,426,185};/* VOLATILE GLOBAL g_1290 */
static int32_t **g_1300 = &g_100;
static int32_t *** volatile g_1299 = &g_1300;/* VOLATILE GLOBAL g_1299 */
static volatile struct S0 g_1338[7] = {{7715,-6,9,-710,0xD7E9CAADL},{7715,-6,9,-710,0xD7E9CAADL},{-2304,2,11,-590,0xC11D0335L},{7715,-6,9,-710,0xD7E9CAADL},{7715,-6,9,-710,0xD7E9CAADL},{-2304,2,11,-590,0xC11D0335L},{7715,-6,9,-710,0xD7E9CAADL}};
static volatile struct S0 * volatile g_1340 = &g_1338[4];/* VOLATILE GLOBAL g_1340 */
static const union U2 g_1344 = {0x467A5311L};
static const union U2 *g_1343 = &g_1344;
static const union U2 **g_1342 = &g_1343;
static uint32_t g_1359 = 0xE44F6DC8L;
static struct S0 g_1364 = {68,15,7,118,0x6AE820EAL};/* VOLATILE GLOBAL g_1364 */
static const volatile struct S0 g_1385 = {-3952,11,15,-697,0xFDC52F20L};/* VOLATILE GLOBAL g_1385 */
static int32_t g_1468 = 0L;
static const uint16_t * volatile * const  volatile *g_1528 = (void*)0;
static union U2 ** volatile *g_1534 = &g_251;
static union U2 ** volatile * volatile *g_1533 = &g_1534;
static union U2 ** volatile * volatile **g_1532 = &g_1533;
static volatile uint32_t g_1541 = 0x770FD2FBL;/* VOLATILE GLOBAL g_1541 */
static uint64_t g_1555[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static uint8_t *g_1574 = &g_96;
static uint8_t **g_1573 = &g_1574;
static uint8_t *** volatile g_1572 = &g_1573;/* VOLATILE GLOBAL g_1572 */
static struct S1 g_1632 = {2734,146,-716,-55,1411,-894,204};/* VOLATILE GLOBAL g_1632 */
static volatile struct S0 g_1652 = {-1141,15,10,588,0xC61098A4L};/* VOLATILE GLOBAL g_1652 */
static struct S0 ** volatile g_1654 = (void*)0;/* VOLATILE GLOBAL g_1654 */
static union U2 ***g_1700 = &g_251;
static union U2 ****g_1699 = &g_1700;
static union U2 *****g_1698 = &g_1699;
static uint32_t g_1702 = 18446744073709551610UL;
static struct S1 g_1708 = {785,101,-1120,79,1270,748,19};/* VOLATILE GLOBAL g_1708 */
static const uint64_t *g_1728 = (void*)0;
static const uint64_t **g_1727 = &g_1728;
static const uint64_t ***g_1726[4] = {&g_1727,&g_1727,&g_1727,&g_1727};
static uint64_t *g_1734[2] = {&g_1555[3],&g_1555[3]};
static uint64_t ** const g_1733 = &g_1734[0];
static uint64_t ** const *g_1732 = &g_1733;
static uint8_t g_1739 = 0xC7L;
static int32_t *g_1796 = &g_203[6][8][2];
static volatile uint16_t g_1806 = 0x984BL;/* VOLATILE GLOBAL g_1806 */
static struct S0 g_1810[4] = {{1756,21,0,369,0x68ECC8B1L},{1756,21,0,369,0x68ECC8B1L},{1756,21,0,369,0x68ECC8B1L},{1756,21,0,369,0x68ECC8B1L}};
static volatile struct S1 *g_1812 = &g_871;
static volatile struct S1 ** volatile g_1811 = &g_1812;/* VOLATILE GLOBAL g_1811 */
static int32_t *g_1822 = &g_159[0][0][2].f4;
static int32_t **g_1821 = &g_1822;
static union U2 ***** volatile * volatile g_1826 = (void*)0;/* VOLATILE GLOBAL g_1826 */
static union U2 ***** volatile * volatile * volatile g_1825 = &g_1826;/* VOLATILE GLOBAL g_1825 */
static volatile struct S1 g_1831 = {-2486,338,524,-64,1028,-1328,63};/* VOLATILE GLOBAL g_1831 */
static struct S0 g_1832 = {-7910,20,12,-120,0x56638106L};/* VOLATILE GLOBAL g_1832 */
static struct S0 * volatile g_1833 = &g_1810[2];/* VOLATILE GLOBAL g_1833 */
static struct S1 g_1849 = {-529,75,-172,-78,-407,-934,246};/* VOLATILE GLOBAL g_1849 */
static volatile struct S1 g_1868[9] = {{-1585,109,-609,73,1032,1391,339},{-1585,109,-609,73,1032,1391,339},{2580,102,-527,-12,-971,1781,152},{-1585,109,-609,73,1032,1391,339},{-1585,109,-609,73,1032,1391,339},{2580,102,-527,-12,-971,1781,152},{-1585,109,-609,73,1032,1391,339},{-1585,109,-609,73,1032,1391,339},{2580,102,-527,-12,-971,1781,152}};
static uint32_t g_1902 = 0xA717DC7EL;
static const int16_t *g_1963 = (void*)0;
static const int16_t **g_1962 = &g_1963;
static volatile struct S0 g_1981[4][5] = {{{-4661,-16,12,307,0xE9C41ADBL},{3486,12,14,619,-4L},{-4661,-16,12,307,0xE9C41ADBL},{3486,12,14,619,-4L},{-4661,-16,12,307,0xE9C41ADBL}},{{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L}},{{-4661,-16,12,307,0xE9C41ADBL},{3486,12,14,619,-4L},{-4661,-16,12,307,0xE9C41ADBL},{3486,12,14,619,-4L},{-4661,-16,12,307,0xE9C41ADBL}},{{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L},{1705,-12,4,572,0L}}};
static struct S0 *g_1996 = &g_405[0][4];
static struct S0 **g_1995 = &g_1996;
static struct S0 *** const  volatile g_1994 = &g_1995;/* VOLATILE GLOBAL g_1994 */
static volatile struct S0 g_2014 = {4856,-7,11,-700,0xA81A9698L};/* VOLATILE GLOBAL g_2014 */
static struct S1 g_2024 = {-1472,107,-726,9,1352,1752,54};/* VOLATILE GLOBAL g_2024 */
static volatile uint16_t *g_2036[4] = {&g_1806,&g_1806,&g_1806,&g_1806};
static volatile uint16_t **g_2035 = &g_2036[2];
static volatile uint16_t ***g_2034 = &g_2035;
static int32_t ** volatile g_2053 = (void*)0;/* VOLATILE GLOBAL g_2053 */
static struct S0 g_2094 = {550,-21,12,-524,1L};/* VOLATILE GLOBAL g_2094 */
static const struct S0 g_2116 = {2392,12,9,-545,0L};/* VOLATILE GLOBAL g_2116 */
static struct S1 g_2163[4][8][2] = {{{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}}},{{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}}},{{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}}},{{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}},{{-1707,192,450,-30,-1375,1766,320},{-617,85,1573,24,-917,-1562,273}}}};
static uint64_t ***g_2170 = (void*)0;
static uint64_t ****g_2169 = &g_2170;
static int32_t g_2184 = 6L;
static int32_t g_2185[6] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
static int32_t g_2186 = (-7L);
static int32_t g_2187 = 0x07E557A3L;
static int32_t g_2188[6][3] = {{0x8C34DFCCL,(-8L),(-8L)},{0xC1A5F9FAL,(-1L),(-1L)},{0x8C34DFCCL,(-8L),(-8L)},{0xC1A5F9FAL,(-1L),(-1L)},{0x8C34DFCCL,(-8L),(-8L)},{0xC1A5F9FAL,(-1L),(-1L)}};
static int32_t g_2189 = 0xECECFA7AL;
static int32_t g_2190 = 4L;
static int32_t g_2191 = (-4L);
static int32_t g_2192 = 0x6B4AFEBBL;
static int32_t g_2193 = (-1L);
static int32_t g_2194 = 0x62593635L;
static int32_t g_2195 = 0x644EB067L;
static uint8_t g_2229 = 0x87L;
static volatile int32_t * volatile g_2253 = (void*)0;/* VOLATILE GLOBAL g_2253 */
static volatile int32_t * volatile * const  volatile g_2254 = &g_2253;/* VOLATILE GLOBAL g_2254 */
static struct S1 * const g_2255 = &g_1632;
static struct S1 ** volatile g_2257[2] = {&g_754,&g_754};
static int64_t * volatile * volatile g_2264 = &g_819[1][0][0];/* VOLATILE GLOBAL g_2264 */
static int64_t * volatile * volatile *g_2263 = &g_2264;
static int32_t ** volatile g_2308[4][6] = {{&g_100,&g_1796,&g_1796,&g_1796,&g_100,(void*)0},{&g_1796,&g_100,(void*)0,(void*)0,&g_100,&g_1796},{&g_1796,&g_1796,&g_100,&g_100,&g_100,&g_1796},{&g_100,&g_1796,(void*)0,&g_1796,&g_1796,(void*)0}};
static int32_t ** volatile g_2309 = &g_1796;/* VOLATILE GLOBAL g_2309 */
static int64_t *g_2321[10][8] = {{&g_102,&g_102,&g_202,&g_102,&g_102,&g_202,&g_102,&g_102},{(void*)0,&g_202,&g_202,&g_202,&g_102,&g_202,(void*)0,&g_202},{&g_102,&g_202,&g_102,&g_102,&g_202,&g_202,&g_102,&g_202},{&g_102,&g_202,(void*)0,&g_102,&g_102,&g_202,&g_102,&g_102},{&g_202,&g_102,&g_202,&g_102,&g_202,&g_202,(void*)0,&g_202},{&g_202,(void*)0,&g_202,&g_202,&g_102,&g_102,&g_202,&g_202},{&g_202,&g_102,&g_202,&g_102,&g_202,(void*)0,&g_102,&g_102},{&g_202,&g_102,&g_202,&g_202,&g_102,&g_202,&g_202,&g_102},{&g_102,(void*)0,&g_102,&g_202,&g_202,&g_202,&g_102,(void*)0},{&g_102,&g_202,&g_202,&g_202,&g_102,&g_202,&g_202,&g_102}};
static int64_t g_2342 = 0L;
static uint32_t g_2369 = 0xBCE0EE98L;
static volatile struct S0 g_2388 = {-1430,-19,4,607,0L};/* VOLATILE GLOBAL g_2388 */
static const int32_t ** volatile g_2414[7] = {&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884};
static const int32_t ** volatile g_2415 = (void*)0;/* VOLATILE GLOBAL g_2415 */
static const int32_t ** volatile g_2416 = &g_884;/* VOLATILE GLOBAL g_2416 */
static struct S1 g_2444 = {8,200,1695,50,1316,-1876,281};/* VOLATILE GLOBAL g_2444 */
static struct S0 g_2471 = {-2075,11,3,-154,0xBCB941C5L};/* VOLATILE GLOBAL g_2471 */
static struct S0 g_2495 = {3103,2,1,554,-6L};/* VOLATILE GLOBAL g_2495 */
static int32_t *** const *g_2538 = (void*)0;
static uint32_t g_2742 = 0xB1316676L;
static int32_t g_2754 = 0xAEDE6AF3L;
static int32_t g_2757 = 0xEE555506L;
static volatile struct S0 g_2819 = {-7364,-14,7,-304,-1L};/* VOLATILE GLOBAL g_2819 */
static int8_t g_2831 = 0x78L;
static struct S0 g_2873 = {314,9,2,255,0xA3357E65L};/* VOLATILE GLOBAL g_2873 */
static volatile uint16_t g_2874 = 0UL;/* VOLATILE GLOBAL g_2874 */
static volatile struct S1 g_2875[2] = {{-2050,255,-382,84,-346,-36,271},{-2050,255,-382,84,-346,-36,271}};
static int32_t * const *g_2881 = (void*)0;
static int32_t * const **g_2880 = &g_2881;
static int32_t * const ***g_2879 = &g_2880;
static int32_t * const ****g_2878 = &g_2879;
static const int32_t * const *g_2886 = &g_884;
static const int32_t * const * const *g_2885 = &g_2886;
static const int32_t * const * const **g_2884 = &g_2885;
static const int32_t * const * const ***g_2883 = &g_2884;
static union U2 *** volatile * volatile *g_2956 = (void*)0;
static union U2 *** volatile * volatile ** volatile g_2955 = &g_2956;/* VOLATILE GLOBAL g_2955 */
static union U2 *** volatile * volatile ** volatile * const g_2954 = &g_2955;
static uint64_t g_3050 = 18446744073709551615UL;
static int16_t g_3051[4] = {0xBD25L,0xBD25L,0xBD25L,0xBD25L};
static int32_t *g_3068[10] = {&g_2193,&g_2193,&g_2193,&g_2193,&g_2193,&g_2193,&g_2193,&g_2193,&g_2193,&g_2193};
static struct S1 g_3102 = {1732,211,-924,-33,1221,1073,148};/* VOLATILE GLOBAL g_3102 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint32_t  func_5(union U2  p_6, int64_t  p_7);
static uint16_t  func_15(int32_t * p_16, const uint64_t  p_17);
static int32_t * func_18(int32_t * p_19, uint32_t  p_20, int32_t * p_21, const int32_t * p_22);
static int32_t * func_23(union U2  p_24);
static union U2  func_25(int32_t * p_26, int16_t  p_27);
static const int32_t  func_41(uint32_t  p_42, const int64_t  p_43, uint32_t  p_44, int8_t  p_45, uint16_t  p_46);
static int16_t  func_53(int32_t  p_54, int32_t * p_55, int32_t  p_56, uint32_t  p_57);
static uint8_t  func_58(int32_t * p_59, int64_t  p_60, uint32_t  p_61);
static uint32_t  func_62(uint32_t  p_63, int32_t * p_64, uint16_t * p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_74.f0
 * writes:
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = (void*)0;
    int32_t *l_3 = &g_4[2];
    union U2 l_8 = {0xBB4AAD9DL};
    int32_t *l_460 = (void*)0;
    const uint8_t l_880[1] = {0x4EL};
    uint8_t l_939 = 0UL;
    int8_t l_1001 = 0L;
    const int16_t *l_1013 = (void*)0;
    const int16_t **l_1012 = &l_1013;
    uint32_t l_1090 = 0UL;
    uint32_t l_1103 = 4294967289UL;
    uint16_t l_1109 = 65534UL;
    struct S1 **l_1118[9] = {&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754,&g_754};
    uint8_t l_1149 = 0x5DL;
    int32_t l_1228 = 0x5E7B9BD3L;
    int32_t l_1229 = 0x763446DDL;
    int32_t l_1234 = 1L;
    int32_t *l_1239 = &l_1229;
    struct S1 *l_1289 = &g_1290;
    int32_t * const l_1296 = &g_511[2].f4;
    int32_t * const *l_1295 = &l_1296;
    int32_t * const **l_1294[3];
    int32_t l_1311 = 0x63E5FA42L;
    int32_t l_1312 = 0xF9AD5ACFL;
    const uint16_t l_1331 = 0xE02AL;
    union U2 **l_1341 = &g_1221;
    uint32_t l_1467 = 18446744073709551615UL;
    int16_t l_1504 = 0xEE81L;
    int8_t l_1507 = 0x13L;
    int8_t l_1575 = (-2L);
    uint32_t l_1597 = 6UL;
    uint32_t l_1641 = 0xDE4C031FL;
    int32_t l_1644[5][9] = {{0L,0xA4C92620L,0xC93FEA56L,(-5L),8L,0x8D9F79BFL,(-1L),(-6L),0x32E0AE39L},{0xF2E2F3F1L,0x4104CEC4L,0x08E12F6CL,4L,(-1L),4L,0x08E12F6CL,0x4104CEC4L,0xA4C92620L},{1L,(-5L),0x32E0AE39L,(-1L),0xF2E2F3F1L,4L,(-6L),0xC8F12440L,0x4104CEC4L},{(-5L),4L,8L,1L,1L,8L,4L,(-5L),0L},{1L,0xF2E2F3F1L,(-6L),1L,1L,0x8D9F79BFL,0xC93FEA56L,(-1L),(-1L)}};
    int8_t l_1711 = 0x0AL;
    int64_t l_1797 = (-1L);
    struct S1 * const *l_1917 = (void*)0;
    int32_t l_1935[10][6][4] = {{{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)},{4L,1L,0x245490CFL,0x4084A86AL},{0xA82987A2L,1L,8L,(-1L)},{8L,(-1L),4L,9L},{8L,0xF52C7C26L,8L,1L},{0xA82987A2L,9L,0x245490CFL,1L}},{{4L,0xF52C7C26L,0xDED7BA5EL,9L},{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)},{4L,1L,0x245490CFL,0x4084A86AL},{0xA82987A2L,1L,8L,(-1L)},{8L,(-1L),4L,9L},{8L,0xF52C7C26L,8L,1L}},{{0xA82987A2L,9L,0x245490CFL,1L},{4L,0xF52C7C26L,0xDED7BA5EL,9L},{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)},{4L,1L,0x245490CFL,0x4084A86AL},{0xA82987A2L,1L,8L,(-1L)},{8L,(-1L),4L,9L}},{{8L,0xF52C7C26L,8L,1L},{0xA82987A2L,9L,0x245490CFL,1L},{4L,0xF52C7C26L,0xDED7BA5EL,9L},{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)},{4L,1L,0x245490CFL,0x4084A86AL},{0xA82987A2L,1L,8L,(-1L)}},{{8L,(-1L),4L,9L},{8L,0xF52C7C26L,8L,1L},{0xA82987A2L,9L,0x245490CFL,1L},{4L,0xF52C7C26L,0xDED7BA5EL,9L},{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)},{4L,1L,0x245490CFL,0x4084A86AL}},{{0xA82987A2L,1L,8L,(-1L)},{8L,(-1L),4L,9L},{8L,0xF52C7C26L,8L,1L},{0xA82987A2L,9L,0x245490CFL,1L},{4L,0xF52C7C26L,0xDED7BA5EL,9L},{0x6883CD06L,(-1L),0xDED7BA5EL,(-1L)}},{{4L,1L,0x245490CFL,0x4084A86AL},{0xA82987A2L,1L,8L,(-1L)},{8L,(-1L),4L,1L},{0x6883CD06L,0xF0B82200L,0x6883CD06L,0x4084A86AL},{8L,1L,0xDED7BA5EL,0x4084A86AL},{0x6D77CD4CL,0xF0B82200L,4L,1L}},{{0x245490CFL,1L,4L,1L},{0x6D77CD4CL,9L,0xDED7BA5EL,0xF52C7C26L},{8L,9L,0x6883CD06L,1L},{0x6883CD06L,1L,0x6D77CD4CL,1L},{0x6883CD06L,0xF0B82200L,0x6883CD06L,0x4084A86AL},{8L,1L,0xDED7BA5EL,0x4084A86AL}},{{0x6D77CD4CL,0xF0B82200L,4L,1L},{0x245490CFL,1L,4L,1L},{0x6D77CD4CL,9L,0xDED7BA5EL,0xF52C7C26L},{8L,9L,0x6883CD06L,1L},{0x6883CD06L,1L,0x6D77CD4CL,1L},{0x6883CD06L,0xF0B82200L,0x6883CD06L,0x4084A86AL}},{{8L,1L,0xDED7BA5EL,0x4084A86AL},{0x6D77CD4CL,0xF0B82200L,4L,1L},{0x245490CFL,1L,4L,1L},{0x6D77CD4CL,9L,0xDED7BA5EL,0xF52C7C26L},{8L,9L,0x6883CD06L,1L},{0x6883CD06L,1L,0x6D77CD4CL,1L}}};
    int32_t l_1952 = 1L;
    int64_t l_1967[6] = {0xAC2BE1A5B8965B66LL,0xAC2BE1A5B8965B66LL,0xAC2BE1A5B8965B66LL,0xAC2BE1A5B8965B66LL,0xAC2BE1A5B8965B66LL,0xAC2BE1A5B8965B66LL};
    int8_t l_2079 = 0x9AL;
    int8_t *l_2099 = &g_885;
    int64_t l_2110 = (-9L);
    int64_t l_2147[10] = {0xF6B1ECE25835522ALL,(-3L),0xF6B1ECE25835522ALL,(-3L),0xF6B1ECE25835522ALL,(-3L),0xF6B1ECE25835522ALL,(-3L),0xF6B1ECE25835522ALL,(-3L)};
    int32_t l_2148 = 9L;
    uint64_t ***l_2168[8] = {&g_985,&g_985,&g_985,&g_985,&g_985,&g_985,&g_985,&g_985};
    uint64_t ****l_2167 = &l_2168[1];
    int32_t * const l_2183[10][3] = {{&g_2193,&g_2188[3][2],&g_2189},{&g_2194,(void*)0,(void*)0},{&g_2189,&g_2193,&g_2191},{&g_2192,&g_2194,&g_2190},{&g_2189,&g_2189,&g_2185[2]},{&g_2194,&g_2192,&g_2186},{&g_2193,&g_2189,&g_2193},{(void*)0,&g_2194,&g_2184},{&g_2188[3][2],&g_2193,&g_2193},{&g_2184,(void*)0,&g_2186}};
    int32_t * const *l_2182 = &l_2183[8][2];
    int64_t l_2221 = (-2L);
    uint64_t l_2231[6] = {18446744073709551615UL,18446744073709551612UL,18446744073709551615UL,18446744073709551615UL,18446744073709551612UL,18446744073709551615UL};
    int32_t *l_2246[2];
    union U2 l_2302 = {0xAE3D4752L};
    int32_t l_2311 = 1L;
    uint32_t l_2421 = 1UL;
    struct S0 ** const l_2426 = &g_1996;
    uint8_t l_2448 = 0x21L;
    union U2 l_2492 = {4294967295UL};
    int32_t l_2501 = 0xF8D69C6DL;
    uint32_t l_2522 = 4UL;
    int32_t *** const *l_2534 = (void*)0;
    union U2 ****l_2557 = &g_1700;
    int64_t l_2641 = 0xA7AE086F864AFC71LL;
    uint8_t l_2647 = 246UL;
    uint16_t **l_2666[2][8][4] = {{{&g_103,&g_103,(void*)0,(void*)0},{(void*)0,&g_103,(void*)0,&g_103},{(void*)0,&g_103,&g_103,(void*)0},{&g_103,(void*)0,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,&g_103},{&g_103,&g_103,(void*)0,&g_103},{&g_103,(void*)0,&g_103,(void*)0},{&g_103,(void*)0,&g_103,(void*)0}},{{(void*)0,&g_103,(void*)0,&g_103},{&g_103,&g_103,&g_103,(void*)0},{(void*)0,&g_103,(void*)0,&g_103},{&g_103,(void*)0,(void*)0,&g_103},{&g_103,&g_103,(void*)0,(void*)0},{(void*)0,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,(void*)0},{(void*)0,(void*)0,&g_103,&g_103}}};
    const uint8_t *l_2732[9] = {&g_614[2],&g_614[2],&g_614[2],&g_614[2],&g_614[2],&g_614[2],&g_614[2],&g_614[2],&g_614[2]};
    const uint8_t * const * const l_2731 = &l_2732[2];
    int16_t l_2738 = 0L;
    uint8_t l_2769 = 0x02L;
    union U2 ******l_2775 = &g_1698;
    union U2 *******l_2774 = &l_2775;
    int32_t l_2823 = 0xF9FEE777L;
    int32_t l_2836 = 1L;
    int8_t l_2896 = (-9L);
    int64_t l_2937 = 0x92EDF0C71DB36898LL;
    int32_t l_2974 = 4L;
    uint8_t l_3002 = 0xE1L;
    int32_t l_3003 = 1L;
    const int32_t *l_3022 = &l_2311;
    int16_t l_3083 = 0xD86EL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1294[i] = &l_1295;
    for (i = 0; i < 2; i++)
        l_2246[i] = &g_2187;
    return g_74.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_203 g_149 g_103 g_104 g_818 g_917 g_918 g_311 g_752.f3 g_33
 * writes: g_107 g_100 g_819 g_184 g_33 g_149
 */
static uint32_t  func_5(union U2  p_6, int64_t  p_7)
{ /* block id: 382 */
    uint64_t l_888 = 0UL;
    int8_t *l_897 = (void*)0;
    int32_t l_898[5] = {0xE44A3288L,0xE44A3288L,0xE44A3288L,0xE44A3288L,0xE44A3288L};
    uint32_t *l_903 = &g_107;
    uint64_t *l_906 = (void*)0;
    uint64_t **l_905 = &l_906;
    uint64_t ***l_904[1][2][2];
    uint64_t ****l_907 = &l_904[0][0][0];
    int32_t **l_908 = &g_100;
    int32_t *l_909 = &g_4[2];
    int32_t *l_921 = &g_33;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 2; k++)
                l_904[i][j][k] = &l_905;
        }
    }
    l_909 = ((*l_908) = (((safe_mul_func_uint8_t_u_u(l_888, (((((safe_add_func_uint64_t_u_u(p_6.f0, (safe_rshift_func_uint16_t_u_u(((((safe_rshift_func_int8_t_s_u(((((*l_903) = ((l_898[3] = g_203[6][8][2]) >= (((safe_rshift_func_uint16_t_u_u(0x3BC9L, 2)) < ((safe_add_func_int8_t_s_s(l_888, g_149)) < p_7)) | p_7))) == (((*l_907) = l_904[0][1][0]) == &g_189)) < 0x6DDDL), l_888)) | (-1L)) ^ 0xD01B754ACC6C1A73LL) < p_6.f0), 15)))) >= p_6.f0) , 6L) ^ l_888) == p_6.f0))) < 0xC7F5E372CC59C31FLL) , (void*)0));
    (*l_921) = (!((safe_add_func_int64_t_s_s((safe_mod_func_uint8_t_u_u(0xB9L, (safe_add_func_uint16_t_u_u((*g_103), (((*g_818) = l_906) != ((g_184[5] = (g_917 , p_7)) , (g_918 , l_906))))))), 0x111EEA8AB18645C7LL)) <= (safe_mod_func_int16_t_s_s((g_311 <= 1L), (*g_103)))));
    for (g_149 = (-7); (g_149 != (-16)); g_149 = safe_sub_func_int8_t_s_s(g_149, 1))
    { /* block id: 393 */
        return g_752.f3;
    }
    (*l_921) &= (p_7 | (safe_rshift_func_int8_t_s_s(0L, 5)));
    return (*l_921);
}


/* ------------------------------------------ */
/* 
 * reads : g_883 g_103 g_104
 * writes: g_884
 */
static uint16_t  func_15(int32_t * p_16, const uint64_t  p_17)
{ /* block id: 379 */
    union U2 l_881 = {0x0249EFF8L};
    const int32_t *l_882[4] = {&g_203[6][8][2],&g_203[6][8][2],&g_203[6][8][2],&g_203[6][8][2]};
    int i;
    (*g_883) = l_882[1];
    return (*g_103);
}


/* ------------------------------------------ */
/* 
 * reads : g_159.f2 g_126.f0 g_428 g_33 g_474 g_153.f1 g_148 g_149 g_48 g_405.f3 g_159.f1 g_251 g_511 g_512 g_153.f4 g_524 g_114 g_40 g_228.f5 g_203 g_108 g_106 g_103 g_153.f2 g_396 g_228.f4 g_614 g_288 g_617 g_100 g_104 g_646 g_397.f5 g_4 g_397.f0 g_274.f5 g_311 g_50 g_439 g_187 g_274.f1 g_706 g_707 g_709 g_710 g_714 g_722 g_36 g_729 g_525 g_749 g_752 g_818 g_450 g_833 g_852 g_858 g_753 g_397 g_860 g_871 g_1632
 * writes: g_428 g_48 g_149 g_106 g_124 g_405 g_279 g_524 g_104 g_203 g_614 g_474 g_100 g_228.f1 g_126.f0 g_187 g_40 g_707 g_50 g_749 g_751 g_753 g_754 g_107 g_714 g_852
 */
static int32_t * func_18(int32_t * p_19, uint32_t  p_20, int32_t * p_21, const int32_t * p_22)
{ /* block id: 215 */
    const union U2 **l_463 = (void*)0;
    int32_t l_464 = (-10L);
    uint32_t *l_488[2][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0}};
    union U2 l_559 = {0xBF8368DDL};
    uint32_t l_561 = 0x372545D5L;
    int32_t l_566 = 0xDE28B015L;
    int32_t l_571 = (-1L);
    int32_t l_573 = 0L;
    int32_t l_576 = 0xA47D0882L;
    int32_t l_577 = 1L;
    int32_t l_610 = 0x2D686E53L;
    int32_t l_611 = 0x43EE45D8L;
    int32_t l_612 = 2L;
    int32_t l_613[8][4][8] = {{{1L,0x273911DAL,0xBF49EC4AL,0x745239B1L,1L,0x2F70BE73L,0xD79C8A86L,(-9L)},{0xBF49EC4AL,0x49E0991FL,(-1L),0x808949F9L,1L,0x3285CDADL,0xD79C8A86L,0x4B31F1D4L},{0x5246EDA3L,0x808949F9L,0xBF49EC4AL,0x2F70BE73L,(-9L),0xCA55B224L,(-9L),0x2F70BE73L},{(-9L),0xCA55B224L,(-9L),0x2F70BE73L,0xBF49EC4AL,0x808949F9L,0x5246EDA3L,0x4B31F1D4L}},{{0xD79C8A86L,0x3285CDADL,1L,0x808949F9L,(-1L),0x49E0991FL,0xBF49EC4AL,(-9L)},{0xD79C8A86L,0x2F70BE73L,1L,0x745239B1L,0xBF49EC4AL,0x273911DAL,1L,0x273911DAL},{(-9L),0xAFEA62D6L,0xA315DE52L,0xAFEA62D6L,(-9L),0x273911DAL,(-3L),0x3285CDADL},{0x5246EDA3L,0x2F70BE73L,7L,5L,1L,0x49E0991FL,0x05EE917AL,0xAFEA62D6L}},{{0xBF49EC4AL,0x3285CDADL,7L,(-9L),1L,0x808949F9L,(-3L),0xEF06B95FL},{1L,0xCA55B224L,0xA315DE52L,0x3285CDADL,0xA315DE52L,0xCA55B224L,1L,0xEF06B95FL},{(-3L),0x808949F9L,1L,(-9L),7L,0x3285CDADL,0xBF49EC4AL,0xAFEA62D6L},{0x05EE917AL,0x49E0991FL,1L,5L,7L,0x2F70BE73L,0x5246EDA3L,0x3285CDADL}},{{(-3L),0x273911DAL,(-9L),0xAFEA62D6L,0xA315DE52L,0xAFEA62D6L,(-9L),0x273911DAL},{1L,0x273911DAL,0xBF49EC4AL,0x745239B1L,1L,0x2F70BE73L,0xD79C8A86L,(-9L)},{0xBF49EC4AL,0x49E0991FL,(-1L),0x808949F9L,1L,0x3285CDADL,0xD79C8A86L,0x4B31F1D4L},{0x5246EDA3L,0x808949F9L,0xBF49EC4AL,0x2F70BE73L,(-9L),0xCA55B224L,(-9L),0x2F70BE73L}},{{(-9L),0xCA55B224L,(-9L),0x2F70BE73L,0xBF49EC4AL,0x808949F9L,0x5246EDA3L,0x4B31F1D4L},{0xD79C8A86L,0x3285CDADL,1L,0x808949F9L,(-1L),0x49E0991FL,0xBF49EC4AL,(-9L)},{0xD79C8A86L,0x2F70BE73L,1L,0x745239B1L,0xBF49EC4AL,0x81944A7BL,0x05EE917AL,0x81944A7BL},{(-1L),0xCA55B224L,0x5246EDA3L,0xCA55B224L,(-1L),0x81944A7BL,0xD79C8A86L,0xAFEA62D6L}},{{(-9L),0x273911DAL,(-3L),0x3285CDADL,0x05EE917AL,5L,0xBF49EC4AL,0xCA55B224L},{7L,0xAFEA62D6L,(-3L),0x2F70BE73L,0xA315DE52L,0x49E0991FL,0xD79C8A86L,0x745239B1L},{0x05EE917AL,(-9L),0x5246EDA3L,0xAFEA62D6L,0x5246EDA3L,(-9L),0x05EE917AL,0x745239B1L},{0xD79C8A86L,0x49E0991FL,0xA315DE52L,0x2F70BE73L,(-3L),0xAFEA62D6L,7L,0xCA55B224L}},{{0xBF49EC4AL,5L,0x05EE917AL,0x3285CDADL,(-3L),0x273911DAL,(-9L),0xAFEA62D6L},{0xD79C8A86L,0x81944A7BL,(-1L),0xCA55B224L,0x5246EDA3L,0xCA55B224L,(-1L),0x81944A7BL},{0x05EE917AL,0x81944A7BL,7L,0x808949F9L,0xA315DE52L,0x273911DAL,(-1L),0x2F70BE73L},{7L,5L,1L,0x49E0991FL,0x05EE917AL,0xAFEA62D6L,(-1L),0xEF06B95FL}},{{(-9L),0x49E0991FL,7L,0x273911DAL,(-1L),(-9L),(-1L),0x273911DAL},{(-1L),(-9L),(-1L),0x273911DAL,7L,0x49E0991FL,(-9L),0xEF06B95FL},{(-1L),0xAFEA62D6L,0x05EE917AL,0x49E0991FL,1L,5L,7L,0x2F70BE73L},{(-1L),0x273911DAL,0xA315DE52L,0x808949F9L,7L,0x81944A7BL,0x05EE917AL,0x81944A7BL}}};
    uint64_t *l_724 = &g_311;
    uint64_t **l_723 = &l_724;
    int8_t * const l_730 = &g_184[5];
    uint16_t **l_843 = &g_103;
    uint16_t ***l_842 = &l_843;
    union U2 ** const *l_846[9] = {(void*)0,&g_251,&g_251,(void*)0,&g_251,&g_251,(void*)0,&g_251,&g_251};
    int32_t *l_879[4];
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_879[i] = &g_36;
    if ((safe_sub_func_uint8_t_u_u((g_159[0][0][2].f2 != p_20), ((l_463 == (g_126[3][0].f0 , l_463)) || l_464))))
    { /* block id: 216 */
        uint32_t l_487[10] = {0x4B031B8EL,0x3A4DD918L,0x3A4DD918L,0x4B031B8EL,0x3A4DD918L,0x3A4DD918L,0x4B031B8EL,0x3A4DD918L,0x3A4DD918L,0x4B031B8EL};
        const union U2 ***l_523[5] = {&l_463,&l_463,&l_463,&l_463,&l_463};
        int32_t l_540 = 0L;
        int32_t l_568 = (-10L);
        int32_t l_569 = 0L;
        int32_t l_572 = 0x461C1FD1L;
        int32_t l_574 = 0x21D507E5L;
        int32_t l_575 = 0x30B90B54L;
        int8_t l_595 = 0xE2L;
        int32_t l_596 = 0x1C19BE4DL;
        int32_t l_597 = 0x4566DB87L;
        int32_t l_598 = (-4L);
        int32_t l_599 = 0L;
        int32_t l_601 = (-10L);
        int32_t l_602 = 0x4F5C6AF1L;
        int32_t l_603 = 0x1E06CC81L;
        int32_t l_604 = 0xC2BB102AL;
        int32_t l_605 = 1L;
        int32_t l_606 = 0x7F95C52AL;
        int32_t l_607[4][8] = {{6L,(-1L),6L,(-1L),6L,(-1L),6L,(-1L)},{6L,(-1L),6L,(-1L),6L,(-1L),6L,(-1L)},{6L,(-1L),6L,(-1L),6L,(-1L),6L,(-1L)},{6L,(-1L),6L,(-1L),6L,(-1L),6L,(-1L)}};
        struct S1 *l_650 = &g_397;
        struct S1 **l_649[6][9] = {{(void*)0,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,(void*)0,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,(void*)0,&l_650,(void*)0,&l_650,(void*)0,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650},{&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,&l_650,(void*)0}};
        union U2 *l_659[6];
        int i, j;
        for (i = 0; i < 6; i++)
            l_659[i] = &g_126[3][0];
        for (g_428 = 0; (g_428 < 3); g_428++)
        { /* block id: 219 */
            uint32_t l_489 = 18446744073709551606UL;
            int32_t *l_491 = &l_464;
            union U2 l_503 = {0UL};
            int32_t l_562 = 9L;
            int32_t l_563[1][7][5] = {{{(-1L),(-1L),0x7DE2FD3DL,9L,0x7DE2FD3DL},{0x7C003011L,0x7C003011L,0xCFFB1964L,0xFD3C1CA4L,0x45F86510L},{(-1L),(-1L),(-1L),(-1L),0x7DE2FD3DL},{0xD075AC7CL,0xFD3C1CA4L,1L,1L,0xFD3C1CA4L},{0x7DE2FD3DL,(-1L),0L,(-9L),(-9L)},{4L,0x7C003011L,4L,1L,0xCFFB1964L},{9L,(-1L),(-9L),(-1L),9L}}};
            int32_t l_600 = 0L;
            int64_t l_608 = (-4L);
            int64_t l_651 = 6L;
            uint32_t l_665 = 1UL;
            int i, j, k;
            if ((((safe_div_func_int64_t_s_s((safe_add_func_int16_t_s_s((((((safe_lshift_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u(g_33)), 15)) < ((g_474 , ((+0xABEFA54BL) , ((((safe_add_func_uint64_t_u_u((safe_lshift_func_int8_t_s_u((!(~(safe_add_func_uint16_t_u_u(0xC2B2L, (safe_rshift_func_int8_t_s_s(((safe_unary_minus_func_int64_t_s(p_20)) || (0x5286DB47L != l_487[4])), 0)))))), (((void*)0 == l_488[1][0]) ^ l_489))), g_153.f1)) , 0xF38FL) || 65526UL) , (void*)0))) == (void*)0)) , (-1L)) != l_487[4]) || (*g_148)), l_464)), (-1L))) || p_20) , (-1L)))
            { /* block id: 220 */
                int64_t l_505 = 0x1F0B54B9A13D9129LL;
                uint8_t l_507 = 255UL;
                union U2 l_560 = {0x448292A6L};
                int32_t l_564 = 1L;
                int32_t l_565 = 0xB3170294L;
                int32_t l_567[1];
                int64_t l_609 = 0L;
                int i;
                for (i = 0; i < 1; i++)
                    l_567[i] = 1L;
                if ((+0xD8D3FF57AF3EF03FLL))
                { /* block id: 221 */
                    int32_t **l_492[10][3] = {{&l_491,&l_491,(void*)0},{&l_491,&l_491,&l_491},{(void*)0,&l_491,&g_100},{&g_100,&l_491,&g_100},{(void*)0,(void*)0,&g_100},{&l_491,&g_100,&g_100},{&l_491,(void*)0,&l_491},{&l_491,&l_491,(void*)0},{&l_491,&l_491,&l_491},{(void*)0,&l_491,&g_100}};
                    int16_t *l_494 = &g_48[4];
                    int i, j;
                    p_19 = l_491;
                    (*p_19) = ((safe_unary_minus_func_int64_t_s(p_20)) == ((*l_494) = p_20));
                    for (l_464 = 0; (l_464 <= 9); l_464 += 1)
                    { /* block id: 227 */
                        int32_t * const l_504 = &g_149;
                        int i;
                        (*l_504) = (g_48[l_464] && ((((safe_rshift_func_int8_t_s_s(9L, 0)) , (safe_add_func_uint8_t_u_u((((safe_mul_func_int16_t_s_s(1L, 0x787BL)) | g_48[l_464]) != ((safe_div_func_int8_t_s_s(((l_503 , l_504) == (void*)0), g_405[0][4].f3)) ^ l_487[4])), 0L))) <= g_159[0][0][2].f1) ^ 0L));
                    }
                    l_505 &= ((*p_19) = 0x2688993FL);
                }
                else
                { /* block id: 232 */
                    union U2 *l_510 = (void*)0;
                    int32_t l_522 = 0xC303B057L;
                    int32_t l_570[2][3] = {{0xB0C61D83L,0x1305F060L,0xB0C61D83L},{0xB0C61D83L,0x1305F060L,0xB0C61D83L}};
                    struct S1 *l_632 = (void*)0;
                    struct S1 **l_631 = &l_632;
                    int i, j;
                    for (g_106 = 0; (g_106 <= 9); g_106 += 1)
                    { /* block id: 235 */
                        int32_t *l_506[5][5][6] = {{{&g_33,&l_464,(void*)0,(void*)0,&l_464,&g_33},{&g_33,&g_149,&g_33,(void*)0,&g_149,(void*)0},{&g_33,&g_203[4][4][0],&g_33,(void*)0,&g_203[4][4][0],&g_33},{&g_33,&l_464,(void*)0,(void*)0,&l_464,&g_33},{&g_33,&g_149,&g_33,(void*)0,&g_149,(void*)0}},{{&g_33,&g_203[4][4][0],&g_33,(void*)0,&g_203[4][4][0],&g_33},{&g_33,&l_464,(void*)0,(void*)0,&l_464,&g_33},{&g_33,&g_149,&g_33,(void*)0,&g_149,(void*)0},{&g_33,&g_203[4][4][0],&g_33,(void*)0,&g_203[4][4][0],&g_33},{&g_33,&l_464,(void*)0,(void*)0,&l_464,&g_33}},{{&g_33,&g_149,&g_33,(void*)0,&g_149,(void*)0},{&g_33,&g_203[4][4][0],&g_33,(void*)0,&g_203[4][4][0],&g_33},{&g_33,&l_464,(void*)0,(void*)0,&l_464,&g_33},{&g_33,&g_149,&g_33,(void*)0,&g_149,(void*)0},{&g_33,&g_203[4][4][0],&g_33,(void*)0,&g_203[4][4][0],&g_33}},{{&g_33,&l_464,(void*)0,&g_203[0][1][2],(void*)0,&g_203[6][8][2]},{&g_203[6][8][2],&g_33,&g_4[2],&g_203[0][1][2],&g_33,&g_203[0][1][2]},{&g_203[6][8][2],&g_33,&g_203[6][8][2],&g_203[0][1][2],&g_33,&g_4[2]},{&g_203[6][8][2],(void*)0,&g_203[0][1][2],&g_203[0][1][2],(void*)0,&g_203[6][8][2]},{&g_203[6][8][2],&g_33,&g_4[2],&g_203[0][1][2],&g_33,&g_203[0][1][2]}},{{&g_203[6][8][2],&g_33,&g_203[6][8][2],&g_203[0][1][2],&g_33,&g_4[2]},{&g_203[6][8][2],(void*)0,&g_203[0][1][2],&g_203[0][1][2],(void*)0,&g_203[6][8][2]},{&g_203[6][8][2],&g_33,&g_4[2],&g_203[0][1][2],&g_33,&g_203[0][1][2]},{&g_203[6][8][2],&g_33,&g_203[6][8][2],&g_203[0][1][2],&g_33,&g_4[2]},{&g_203[6][8][2],(void*)0,&g_203[0][1][2],&g_203[0][1][2],(void*)0,&g_203[6][8][2]}}};
                        int i, j, k;
                        l_507--;
                        l_464 &= l_487[0];
                        (*g_251) = l_510;
                        (*g_512) = g_511[2];
                    }
                    for (g_279 = (-21); (g_279 >= (-26)); g_279--)
                    { /* block id: 243 */
                        union U2 * const ***l_526[4];
                        int32_t l_539 = 1L;
                        int8_t *l_541[5][4] = {{&g_184[4],&g_184[5],&g_184[4],&g_184[4]},{&g_184[5],&g_184[5],&g_184[1],&g_184[5]},{&g_184[5],&g_184[4],&g_184[4],&g_184[5]},{&g_184[4],&g_184[5],&g_184[4],&g_184[4]},{&g_184[5],&g_184[5],&g_184[1],&g_184[5]}};
                        uint64_t *l_557 = (void*)0;
                        int32_t **l_558[7][7][5] = {{{&g_100,&g_100,&g_100,&l_491,&g_100},{&l_491,&l_491,&l_491,(void*)0,&g_100},{&l_491,&l_491,&g_100,&g_100,&l_491},{&l_491,(void*)0,&l_491,(void*)0,&g_100},{&g_100,&l_491,&g_100,&l_491,&l_491},{&g_100,&l_491,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,&l_491,&g_100}},{{&l_491,&l_491,&l_491,(void*)0,&g_100},{&l_491,&l_491,&g_100,&g_100,&l_491},{&l_491,(void*)0,&l_491,(void*)0,&g_100},{&g_100,&l_491,&g_100,&l_491,&l_491},{&g_100,&l_491,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,&l_491,&g_100},{&l_491,&l_491,&l_491,(void*)0,&g_100}},{{&l_491,&l_491,&g_100,&g_100,&l_491},{&l_491,(void*)0,&l_491,(void*)0,&g_100},{&g_100,&l_491,&g_100,&l_491,&l_491},{&g_100,&l_491,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,&l_491,&g_100},{&l_491,&l_491,&l_491,(void*)0,&g_100},{&l_491,&l_491,&g_100,&g_100,&l_491}},{{&l_491,(void*)0,&l_491,(void*)0,&g_100},{&g_100,&l_491,&g_100,&l_491,(void*)0},{&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100},{&l_491,(void*)0,&l_491,&l_491,(void*)0},{&g_100,&g_100,&g_100,(void*)0,(void*)0}},{{&g_100,(void*)0,&l_491,&g_100,(void*)0},{&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100},{&l_491,(void*)0,&l_491,&l_491,(void*)0},{&g_100,&g_100,&g_100,(void*)0,(void*)0},{&g_100,(void*)0,&l_491,&g_100,(void*)0}},{{&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100},{&l_491,(void*)0,&l_491,&l_491,(void*)0},{&g_100,&g_100,&g_100,(void*)0,(void*)0},{&g_100,(void*)0,&l_491,&g_100,(void*)0},{&g_100,&g_100,&g_100,&g_100,&g_100}},{{&g_100,&g_100,&l_491,&g_100,&g_100},{&g_100,&g_100,&g_100,(void*)0,&g_100},{&l_491,(void*)0,&l_491,&l_491,(void*)0},{&g_100,&g_100,&g_100,(void*)0,(void*)0},{&g_100,(void*)0,&l_491,&g_100,(void*)0},{&g_100,&g_100,&g_100,&g_100,&g_100},{&g_100,&g_100,&l_491,&g_100,&g_100}}};
                        uint16_t l_578 = 0UL;
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_526[i] = &g_524;
                        l_539 = (((safe_sub_func_int8_t_s_s(((*l_491) = ((+(l_540 &= (g_153.f4 >= (0x16L == (l_522 < ((l_523[4] != (g_524 = g_524)) >= (l_487[4] != (safe_unary_minus_func_int8_t_s((safe_sub_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(((safe_add_func_int32_t_s_s((*g_114), (safe_add_func_int8_t_s_s((safe_unary_minus_func_uint32_t_u(((*l_491) < ((safe_mod_func_int64_t_s_s((g_228.f5 != g_33), g_203[7][2][0])) , g_203[6][8][2])))), (-1L))))) , l_539), 0x68L)), l_464))))))))))) >= 255UL)), l_507)) > 0xAC94L) >= l_522);
                        (*l_491) |= (*g_108);
                        (*g_396) &= ((((l_487[4] , (safe_sub_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u(((*g_103) = (safe_mul_func_uint16_t_u_u((+(((safe_add_func_uint64_t_u_u((safe_add_func_int8_t_s_s(p_20, p_20)), (g_106 ^= l_522))) <= p_20) | (l_560 , p_20))), l_560.f0))), p_20)) & 4294967290UL), 14)), l_522)), p_20))) || l_561) ^ g_153.f2) && l_522);
                        ++l_578;
                    }
                    if ((safe_lshift_func_uint8_t_u_s((safe_add_func_int8_t_s_s(l_561, (g_228.f4 || 0xDF51DE63L))), 3)))
                    { /* block id: 256 */
                        int32_t l_585 = 0x3AD6C905L;
                        int32_t *l_586 = &l_576;
                        int32_t l_587 = (-10L);
                        int32_t *l_588 = &l_571;
                        int32_t *l_589 = &l_569;
                        int32_t *l_590 = (void*)0;
                        int32_t *l_591 = &l_570[1][0];
                        int32_t *l_592 = &l_585;
                        int32_t *l_593 = &g_203[6][4][1];
                        int32_t *l_594[10][6][2] = {{{&l_568,&l_568},{&l_568,&l_587},{&l_571,&l_576},{&l_567[0],&g_203[7][4][1]},{&l_573,&l_567[0]},{&g_203[6][4][2],&l_572}},{{&g_203[6][4][2],&l_567[0]},{&l_573,&g_203[7][4][1]},{&l_567[0],&l_576},{&l_571,&l_587},{&l_568,&l_568},{&l_568,&l_571}},{{&l_587,(void*)0},{&l_565,&l_571},{&g_4[2],&g_203[8][8][0]},{(void*)0,&g_33},{&g_149,&l_571},{(void*)0,&l_575}},{{&l_587,&l_566},{(void*)0,&l_568},{&l_562,&l_573},{&l_571,(void*)0},{&l_563[0][4][2],&g_203[7][4][1]},{&l_587,&l_563[0][4][2]}},{{&g_203[6][4][2],&l_585},{&l_564,&l_567[0]},{&l_587,&g_4[2]},{&l_567[0],(void*)0},{&l_567[0],&l_587},{&l_562,&g_33}},{{&l_564,(void*)0},{&g_149,&l_572},{&l_566,&g_40},{&l_587,&l_565},{&l_569,&l_565},{&l_587,&g_40}},{{&l_566,&l_572},{&g_149,(void*)0},{&l_564,&g_33},{&g_4[2],&g_203[8][8][0]},{&g_40,&l_571},{&l_576,&l_574}},{{&g_203[8][8][0],&l_576},{&l_570[1][0],(void*)0},{&l_575,&l_564},{&g_203[8][8][0],&l_572},{&l_564,&l_571},{&l_568,&l_564}},{{&g_4[2],&l_564},{&g_33,(void*)0},{&l_567[0],&g_203[2][7][0]},{&l_566,&l_568},{&l_522,&l_565},{&l_571,&l_574}},{{&l_587,&l_568},{&l_567[0],&l_572},{&l_567[0],&g_4[3]},{&l_564,&l_564},{&l_464,&g_203[8][8][0]},{&l_568,&l_569}}};
                        int i, j, k;
                        (*g_251) = l_510;
                        g_614[2]++;
                    }
                    else
                    { /* block id: 259 */
                        g_474 = g_288;
                        (*g_617) = &l_571;
                        (*g_100) = ((*l_491) = 0x145F511CL);
                        return p_21;
                    }
                    for (l_595 = 0; (l_595 > 5); l_595 = safe_add_func_uint32_t_u_u(l_595, 6))
                    { /* block id: 268 */
                        int32_t *l_620 = &l_575;
                        int32_t *l_621 = &l_611;
                        int32_t l_622 = 0L;
                        int32_t *l_623[2];
                        uint8_t l_624 = 0xC1L;
                        const uint64_t *l_633 = &g_311;
                        int16_t l_647 = 5L;
                        union U2 l_648 = {4294967292UL};
                        int i;
                        for (i = 0; i < 2; i++)
                            l_623[i] = &l_607[0][1];
                        --l_624;
                        (*l_621) = ((safe_sub_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((l_631 == (((void*)0 == l_633) , (((&g_614[4] == (void*)0) , (((*g_103) & ((safe_div_func_uint32_t_u_u((0L < ((((safe_sub_func_uint32_t_u_u((((safe_rshift_func_int8_t_s_s(((p_20 ^ ((((safe_sub_func_int64_t_s_s(((safe_lshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_s(((g_646 , (*l_620)) == l_570[1][0]), 2)), g_397.f5)) , g_614[2]), p_20)) >= 1L) != (*g_103)) ^ g_4[2])) && 8UL), g_397.f0)) > l_647) , p_20), (*l_491))) == 0xA0D04C04067AF384LL) | p_20) >= 0xA2CFBEF2L)), l_567[0])) , g_274.f5)) , l_648)) , l_649[2][0]))), g_311)), g_50)) , l_651);
                        return (*g_439);
                    }
                }
            }
            else
            { /* block id: 274 */
                int16_t * const l_656 = &g_48[6];
                uint64_t *l_664 = &g_106;
                uint64_t **l_663 = &l_664;
                uint64_t ***l_662 = &l_663;
                uint64_t ****l_661 = &l_662;
                for (l_601 = (-8); (l_601 >= 23); l_601 = safe_add_func_int32_t_s_s(l_601, 1))
                { /* block id: 277 */
                    union U2 *l_660 = &g_126[0][0];
                    (*l_491) |= ((g_126[3][0].f0 = ((safe_div_func_int8_t_s_s(0x60L, (((void*)0 != l_656) , p_20))) , (g_228.f1 = (0x645C4E86C7ECAB6CLL == (((&g_190 == ((((*g_251) = l_659[3]) != l_660) , l_661)) | 0L) >= l_665))))) , p_20);
                    if (l_613[4][2][4])
                        break;
                }
                return p_21;
            }
            (*l_491) ^= (*g_148);
        }
        for (l_610 = (-5); (l_610 == 12); ++l_610)
        { /* block id: 290 */
            return (*g_439);
        }
    }
    else
    { /* block id: 293 */
        uint16_t l_674 = 0xC577L;
        int32_t l_687 = 1L;
        uint8_t *l_688[4][8];
        int16_t **l_701 = (void*)0;
        int16_t **l_702 = (void*)0;
        int16_t *l_704[9];
        int16_t **l_703 = &l_704[7];
        int32_t *l_705 = &g_40;
        volatile struct S0 *l_708 = (void*)0;
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 8; j++)
                l_688[i][j] = &g_614[2];
        }
        for (i = 0; i < 9; i++)
            l_704[i] = &g_48[4];
        (*g_706) = (safe_rshift_func_uint8_t_u_s((~(0x57L < (!(safe_mod_func_uint64_t_u_u((l_674 >= (((safe_lshift_func_int16_t_s_u(p_20, 8)) <= (safe_lshift_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_u((safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s(((safe_add_func_int8_t_s_s(0x14L, (++g_187))) != (safe_mod_func_uint32_t_u_u(p_20, (+((((~((*l_705) = (l_687 <= ((safe_sub_func_int16_t_s_s(0x6BD7L, (((((((safe_mul_func_uint16_t_u_u(((safe_sub_func_int8_t_s_s(l_687, ((((*l_703) = (void*)0) != &g_48[6]) == p_20))) & 0xABL), p_20)) && p_20) >= l_687) | l_674) < g_274.f1) , l_674) , 0xD0B0L))) , 0xC210L)))) > (*g_103)) || p_20) < 1UL))))), g_511[2].f1)), 8UL)), 6)) && (*l_705)) | l_577), 2))) | g_288.f3)), 0x95741363A316BDCCLL))))), g_274.f1));
        (*g_709) = g_707;
        (*g_251) = &l_559;
    }
    l_576 &= (*g_148);
    (*g_710) = &l_611;
    for (g_50 = 10; (g_50 != 41); ++g_50)
    { /* block id: 305 */
        uint8_t l_713[1][2];
        int8_t *l_715 = &g_428;
        struct S1 *l_721 = (void*)0;
        uint64_t ***l_746[6] = {(void*)0,(void*)0,&l_723,(void*)0,(void*)0,&l_723};
        uint64_t ****l_745 = &l_746[5];
        uint16_t **l_757 = (void*)0;
        int32_t *l_781 = &l_612;
        int32_t l_797 = 0L;
        int32_t l_803 = 0xB396988EL;
        int32_t l_804 = 0xC90239F5L;
        const union U2 l_832 = {0x4260C69AL};
        uint64_t l_859 = 18446744073709551609UL;
        union U2 * const ***l_872 = &g_524;
        int64_t l_877 = 0xCEE8A52296224E2CLL;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_713[i][j] = 7UL;
        }
        if (((l_713[0][1] , ((*l_715) = g_714)) , ((safe_unary_minus_func_uint8_t_u(p_20)) , (safe_div_func_int64_t_s_s(((l_721 == l_721) && (7UL != ((g_722 , l_723) != ((g_36 | 0xB4L) , (void*)0)))), p_20)))))
        { /* block id: 307 */
            union U2 *l_725 = &g_126[3][0];
            int32_t *l_726 = &g_40;
            if ((*g_114))
                break;
            (*g_251) = l_725;
            return l_726;
        }
        else
        { /* block id: 311 */
            const union U2 ***l_732 = &l_463;
            int32_t l_737 = 0xF63985F2L;
            const uint64_t **l_744 = (void*)0;
            const uint64_t ***l_743 = &l_744;
            const uint64_t ****l_742[7] = {&l_743,&l_743,&l_743,&l_743,&l_743,&l_743,&l_743};
            int16_t *l_747 = &g_48[2];
            int16_t *l_748 = (void*)0;
            int16_t *l_750 = &g_751;
            uint16_t * const *l_756[8] = {&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103};
            int32_t l_794 = 0xFE9E93AEL;
            int64_t l_802 = (-1L);
            int32_t l_807 = (-1L);
            struct S1 *l_816[2][10][9] = {{{&g_228,&g_153,(void*)0,&g_397,(void*)0,&g_153,&g_729,&g_228,&g_397},{&g_274,&g_646,&g_274,&g_228,&g_274,&g_153,&g_397,&g_729,&g_397},{&g_646,&g_153,&g_729,&g_729,&g_153,&g_646,&g_153,&g_646,&g_153},{&g_646,&g_646,&g_228,&g_153,&g_646,&g_646,&g_646,&g_153,&g_228},{&g_397,&g_153,&g_153,&g_153,&g_228,(void*)0,&g_153,&g_397,&g_397},{&g_397,&g_153,&g_274,&g_646,&g_274,&g_153,&g_397,&g_646,&g_153},{&g_153,&g_646,&g_153,&g_646,&g_153,&g_397,&g_729,(void*)0,&g_646},{&g_228,&g_729,&g_228,&g_153,&g_729,&g_228,(void*)0,&g_646,&g_646},{&g_397,(void*)0,&g_729,(void*)0,(void*)0,&g_729,(void*)0,&g_397,&g_228},{&g_153,&g_646,&g_274,&g_153,&g_274,&g_153,&g_274,&g_153,&g_274}},{{&g_646,&g_228,(void*)0,&g_646,&g_397,&g_153,&g_153,&g_646,&g_228},{&g_646,&g_729,&g_729,&g_646,&g_274,&g_646,&g_729,&g_729,&g_646},{&g_228,(void*)0,&g_153,&g_397,&g_228,(void*)0,(void*)0,&g_153,&g_228},{&g_274,&g_646,&g_274,&g_646,&g_274,&g_228,&g_274,&g_153,&g_397},{&g_153,&g_228,(void*)0,&g_153,&g_397,&g_397,&g_153,(void*)0,&g_228},{&g_274,&g_646,&g_729,&g_729,&g_646,&g_228,&g_228,&g_646,&g_228},{&g_228,&g_729,&g_153,(void*)0,&g_397,(void*)0,&g_153,&g_228,&g_397},{&g_397,&g_646,&g_274,&g_646,&g_729,&g_153,&g_729,&g_646,&g_274},{&g_228,&g_228,&g_153,&g_729,&g_646,&g_397,&g_153,&g_153,&g_228},{&g_228,&g_646,&g_274,&g_153,&g_274,&g_646,&g_228,&g_646,&g_228}}};
            int64_t **l_820 = &g_819[5][0][7];
            union U2 ***l_848[3];
            union U2 ****l_847 = &l_848[2];
            uint32_t l_857 = 0xACBD6027L;
            const int32_t *l_873 = &g_833.f4;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_848[i] = &g_251;
            if ((safe_add_func_int16_t_s_s((g_729 , (l_730 == ((safe_unary_minus_func_uint8_t_u((((p_20 < (((*l_732) = (void*)0) != (*g_524))) <= (safe_rshift_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_u(l_737, 6)) == (((((*l_750) = (l_566 = (g_749 ^= ((*l_747) = (safe_rshift_func_uint16_t_u_s((((((safe_div_func_int32_t_s_s(((l_742[2] == l_745) ^ (0x157403F0L & 0xE7589E6CL)), (*g_396))) ^ g_153.f4) <= 1L) < 0x7D324E3DL) && 0x7730A487ED32A41BLL), p_20)))))) , 0x2DE3B54CL) , &l_724) == (void*)0)) , p_20), l_737))) & (-10L)))) , &g_749))), p_20)))
            { /* block id: 317 */
                g_754 = (g_752 , (g_753 = &g_397));
                (*g_100) ^= (safe_unary_minus_func_uint8_t_u((l_756[2] == l_757)));
                if (l_576)
                    continue;
            }
            else
            { /* block id: 322 */
                uint8_t l_778 = 3UL;
                int32_t l_798[8][8] = {{0x30E660C8L,0x8B078581L,0xB54845ACL,0x8B078581L,0x30E660C8L,(-1L),(-1L),0x30E660C8L},{0x8B078581L,0xF43C2E3CL,0xF43C2E3CL,0x8B078581L,(-7L),0x30E660C8L,(-7L),0x8B078581L},{0xF43C2E3CL,(-7L),0xF43C2E3CL,(-1L),0xB54845ACL,0xB54845ACL,(-1L),0xF43C2E3CL},{(-7L),(-7L),0xB54845ACL,0x30E660C8L,0x74EC1EBAL,0x30E660C8L,0xB54845ACL,(-7L)},{(-7L),0xF43C2E3CL,(-1L),0xB54845ACL,0xB54845ACL,(-1L),0xF43C2E3CL,(-7L)},{0xF43C2E3CL,0x8B078581L,(-7L),0x30E660C8L,(-7L),0x8B078581L,0xF43C2E3CL,0xF43C2E3CL},{0x8B078581L,0x30E660C8L,(-1L),(-1L),0x30E660C8L,0x8B078581L,0xB54845ACL,0x8B078581L},{0x30E660C8L,0x8B078581L,0xB54845ACL,0x8B078581L,0x30E660C8L,(-1L),(-1L),0x30E660C8L}};
                uint16_t l_809 = 0x5588L;
                const uint16_t *l_814 = &l_809;
                const uint16_t **l_813 = &l_814;
                int64_t **l_821 = &g_819[3][0][3];
                int64_t **l_822 = &g_819[2][0][6];
                uint32_t l_825 = 1UL;
                int i, j;
                for (g_106 = (-11); (g_106 < 3); g_106 = safe_add_func_uint8_t_u_u(g_106, 2))
                { /* block id: 325 */
                    int32_t l_779[6][7] = {{0x765F8A7AL,0L,0x8CEB6DFAL,0x8CEB6DFAL,0L,0x765F8A7AL,0L},{(-1L),0L,1L,(-1L),(-1L),(-1L),1L},{0x36D8A8D6L,0x36D8A8D6L,0x765F8A7AL,0x8CEB6DFAL,0x765F8A7AL,0x36D8A8D6L,0x36D8A8D6L},{0x9F2B81AEL,0L,0xD4744E75L,0L,0x9F2B81AEL,4L,1L},{1L,0L,1L,0x765F8A7AL,0x765F8A7AL,1L,0L},{1L,0xD8C9211FL,0xD4744E75L,0xBBF90DE3L,(-1L),0L,(-1L)}};
                    uint8_t *l_780 = &l_713[0][1];
                    int32_t l_793 = 3L;
                    int32_t l_795 = (-1L);
                    int32_t l_799 = 0xE0282052L;
                    int32_t l_800 = (-6L);
                    int32_t l_805 = 4L;
                    int32_t l_806 = 2L;
                    int32_t l_808 = 4L;
                    int i, j;
                    if ((((safe_lshift_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((safe_div_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((((g_749 = l_737) | ((safe_rshift_func_int8_t_s_u((safe_rshift_func_int8_t_s_u((((safe_rshift_func_int8_t_s_s(((*l_715) = (safe_lshift_func_uint16_t_u_u(9UL, ((0x9A6D4700L & (**g_710)) != l_778)))), 3)) && (&g_251 == (void*)0)) && (l_779[3][5] == ((*l_780) = (&p_19 == (void*)0)))), g_153.f2)), 2)) , (-9L))) | g_274.f1) | l_778), 0x2FL)), g_729.f1)), (-1L))), g_729.f2)) <= g_646.f5) >= g_274.f1))
                    { /* block id: 329 */
                        int32_t *l_782 = &g_149;
                        int32_t *l_783 = &l_464;
                        int32_t *l_784 = &l_610;
                        int32_t l_785 = 8L;
                        int32_t *l_786 = &l_611;
                        int32_t *l_787 = &g_149;
                        int32_t *l_788 = &g_36;
                        int32_t *l_789 = &g_203[0][3][0];
                        int32_t *l_790 = &g_40;
                        int32_t *l_791 = (void*)0;
                        int32_t *l_792[9];
                        int64_t l_796[1];
                        int32_t l_801[7][10] = {{0x170B8098L,4L,4L,0x170B8098L,0L,0x64209538L,0L,(-1L),4L,(-7L)},{0L,(-7L),0x102EFC25L,0x31D1A9CAL,0L,0x6750CA1DL,(-1L),0x57733369L,(-1L),0x6750CA1DL},{0x102EFC25L,4L,0L,4L,0x102EFC25L,1L,0x31D1A9CAL,0x102EFC25L,(-7L),0L},{0x57733369L,0x0AF251E8L,0x3F18F02BL,0x102EFC25L,(-5L),0x2D4A08D9L,0L,0x0AF251E8L,0x0AF251E8L,0L},{0x158DCCE8L,0x102EFC25L,0x6750CA1DL,0x6750CA1DL,0x102EFC25L,0x158DCCE8L,0x3F18F02BL,4L,0x2D4A08D9L,0x6750CA1DL},{0x64209538L,0x57733369L,5L,0x31D1A9CAL,0L,0L,0x31D1A9CAL,0x64209538L,5L,0x64209538L},{0x64209538L,0x158DCCE8L,0x0AF251E8L,0x102EFC25L,0x0AF251E8L,0x158DCCE8L,0x64209538L,(-1L),0x158DCCE8L,0x57733369L}};
                        uint16_t * const *l_812 = &g_103;
                        const uint16_t ***l_815 = &l_813;
                        struct S1 **l_817 = &g_754;
                        int i, j;
                        for (i = 0; i < 9; i++)
                            l_792[i] = &g_203[6][8][2];
                        for (i = 0; i < 1; i++)
                            l_796[i] = 0xDEE711B8E63925F6LL;
                        l_781 = p_21;
                        l_809--;
                        (*l_817) = ((l_812 == ((*l_815) = l_813)) , l_816[0][3][2]);
                    }
                    else
                    { /* block id: 334 */
                        l_822 = (l_821 = (l_820 = g_818));
                    }
                }
                for (l_809 = 0; (l_809 < 12); l_809 = safe_add_func_int16_t_s_s(l_809, 5))
                { /* block id: 342 */
                    l_464 &= l_825;
                    for (g_428 = 6; (g_428 >= 1); g_428 -= 1)
                    { /* block id: 346 */
                        union U2 l_830 = {0x900BF073L};
                        uint64_t l_831[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_831[i] = 0xDBA384D1CB582FE4LL;
                        (*g_100) = (safe_mod_func_int32_t_s_s((-1L), ((safe_mod_func_uint8_t_u_u((l_830 , 0x8EL), l_831[0])) && g_707.f0)));
                    }
                    for (g_187 = 0; (g_187 <= 2); g_187 += 1)
                    { /* block id: 351 */
                        int i;
                        if (g_450[g_187])
                            break;
                        if (g_450[g_187])
                            break;
                    }
                }
                (*g_100) = ((((((l_573 ^= (l_737 ^ ((g_107 = ((l_832 , (g_4[6] == l_794)) | ((g_833 , (((safe_add_func_int8_t_s_s(p_20, (safe_mul_func_int8_t_s_s((((l_798[4][5] || (safe_sub_func_uint16_t_u_u((l_566 |= ((p_20 != ((*l_715) ^= (safe_sub_func_uint64_t_u_u(p_20, l_802)))) , p_20)), l_559.f0))) < l_794) | g_833.f4), 0UL)))) , &l_813) == l_842)) , g_153.f4))) < 0x7CC0DB0EL))) <= (*g_103)) != (*g_103)) <= 7L) > p_20) & p_20);
            }
            if ((safe_mul_func_int8_t_s_s((l_846[7] != ((*l_847) = (void*)0)), (safe_unary_minus_func_uint8_t_u((safe_rshift_func_int16_t_s_s(((g_852 > 0xD707C0DEC1D1CF0BLL) && (((safe_div_func_uint8_t_u_u((~(((g_228.f1 = ((safe_unary_minus_func_uint16_t_u(p_20)) > l_857)) & (l_857 != ((g_858 , (*g_753)) , l_612))) && l_859)), l_803)) & p_20) , g_860)), 3)))))))
            { /* block id: 364 */
                const uint64_t * const ***l_874 = (void*)0;
                int32_t l_875 = 0x319FB964L;
                int32_t **l_878[9] = {&l_781,&g_100,&l_781,&l_781,&g_100,&l_781,&l_781,&g_100,&l_781};
                int i;
                (*g_100) |= 0L;
                if (((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s(((safe_lshift_func_int16_t_s_s(((l_577 | (((safe_sub_func_int64_t_s_s((-1L), ((g_714 = (((((safe_add_func_uint32_t_u_u((0xB21EB2C7L != (&g_524 != (g_871 , l_872))), (((0UL <= p_20) , l_873) != &g_279))) == 0xED681380527AA6A5LL) <= 0xD46AL) , l_874) == &l_743)) < l_875))) != 0x75L) , 0x9CB4FC4FL)) , (-6L)), 6)) , (*g_103)), 12)), l_857)) , (*g_114)))
                { /* block id: 367 */
                    int32_t *l_876 = &g_40;
                    return l_876;
                }
                else
                { /* block id: 369 */
                    if (l_877)
                        break;
                }
                l_879[0] = &l_737;
            }
            else
            { /* block id: 373 */
                return p_21;
            }
        }
    }
    return p_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_311 g_439 g_100 g_99
 * writes: g_311
 */
static int32_t * func_23(union U2  p_24)
{ /* block id: 208 */
    for (g_311 = 0; (g_311 == 8); ++g_311)
    { /* block id: 211 */
        return (*g_439);
    }
    return (*g_99);
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_36 g_4
 * writes: g_33 g_36 g_40
 */
static union U2  func_25(int32_t * p_26, int16_t  p_27)
{ /* block id: 2 */
    uint32_t l_214 = 0UL;
    volatile struct S1 *l_344 = &g_74;
    uint64_t *l_375 = &g_106;
    uint64_t **l_374[6];
    uint64_t ***l_373 = &l_374[4];
    uint16_t **l_389 = &g_103;
    union U2 l_409 = {1UL};
    int32_t l_431 = 0xFB56047EL;
    int32_t l_435 = 3L;
    int i;
    for (i = 0; i < 6; i++)
        l_374[i] = &l_375;
    for (p_27 = (-26); (p_27 <= 23); p_27 = safe_add_func_int16_t_s_s(p_27, 4))
    { /* block id: 5 */
        uint16_t l_47 = 0x1FE9L;
        union U2 **l_406 = &g_124;
        int64_t l_427 = 0xC3CCBCB5017AC22ALL;
        for (g_33 = 0; (g_33 != 27); ++g_33)
        { /* block id: 8 */
            int16_t l_347[5] = {0xEAC0L,0xEAC0L,0xEAC0L,0xEAC0L,0xEAC0L};
            int32_t l_422 = (-5L);
            int32_t l_432 = 1L;
            int32_t l_433 = 0x68CB8E34L;
            int32_t l_434 = 0xD5B52918L;
            int i;
            for (g_36 = 0; (g_36 >= (-6)); --g_36)
            { /* block id: 11 */
                uint32_t l_39[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
                uint16_t *l_49 = &g_50;
                uint16_t *l_67 = &l_47;
                uint16_t **l_66 = &l_67;
                uint16_t *l_69 = (void*)0;
                uint16_t **l_68 = &l_69;
                uint32_t *l_234 = &g_107;
                union U2 l_341 = {0x12D54F6AL};
                int32_t l_376[3];
                int8_t *l_404 = &g_184[5];
                uint16_t l_440[10] = {0x75F2L,0xB8CDL,0xB8CDL,0x75F2L,0xB8CDL,0xB8CDL,0x75F2L,0xB8CDL,0xB8CDL,0x75F2L};
                uint32_t l_454[2][3][5] = {{{0xC6F740F6L,4294967294UL,0UL,5UL,0x22E1007CL},{0xC6F740F6L,0UL,5UL,0UL,0xC6F740F6L},{4294967294UL,0x31996778L,2UL,5UL,0x932D405FL}},{{2UL,0x31996778L,4294967294UL,4294967294UL,0x31996778L},{5UL,0UL,0xC6F740F6L,0x31996778L,0x932D405FL},{0UL,4294967294UL,0xC6F740F6L,4294967295UL,0xC6F740F6L}}};
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_376[i] = (-4L);
                for (g_40 = 0; g_40 < 6; g_40 += 1)
                {
                    l_39[g_40] = 0xDE2A9078L;
                }
            }
        }
        if ((*p_26))
            break;
    }
    return l_409;
}


/* ------------------------------------------ */
/* 
 * reads : g_148 g_149 g_99 g_228.f4 g_103 g_104 g_40 g_187 g_48 g_159.f0 g_106 g_74.f6 g_228.f1 g_100 g_274 g_74.f1 g_159.f4
 * writes: g_149 g_100 g_251 g_106 g_153.f1 g_104 g_40 g_274 g_187
 */
static const int32_t  func_41(uint32_t  p_42, const int64_t  p_43, uint32_t  p_44, int8_t  p_45, uint16_t  p_46)
{ /* block id: 95 */
    uint32_t l_241 = 18446744073709551615UL;
    int32_t *l_242 = &g_40;
    union U2 **l_249 = &g_124;
    int64_t l_291 = (-1L);
    struct S1 **l_312 = (void*)0;
    int32_t **l_316[10][9];
    int32_t l_321 = 0x13FBFF31L;
    int32_t l_322[8][1] = {{0x1C2187E7L},{1L},{0x1C2187E7L},{1L},{0x1C2187E7L},{1L},{0x1C2187E7L},{1L}};
    int32_t l_323 = (-3L);
    int32_t l_328 = 0x06634665L;
    struct S1 * const l_337 = &g_228;
    struct S1 **l_338 = (void*)0;
    struct S1 *l_340 = &g_274;
    struct S1 **l_339 = &l_340;
    int i, j;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
            l_316[i][j] = (void*)0;
    }
    for (p_45 = (-5); (p_45 > 17); p_45++)
    { /* block id: 98 */
        uint64_t l_237 = 0x2199AC41A2DBA9F2LL;
        --l_237;
    }
    if (p_46)
    { /* block id: 101 */
        int32_t *l_240 = &g_149;
        union U2 ***l_250 = (void*)0;
        uint32_t *l_254[6][6] = {{(void*)0,&g_107,&g_107,&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107,(void*)0,&g_107,&g_107},{&g_107,&g_107,&g_107,&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107,(void*)0,&g_107,&g_107},{&g_107,&g_107,&g_107,&g_107,&g_107,&g_107},{(void*)0,&g_107,&g_107,&g_107,&g_107,&g_107}};
        uint64_t *l_306 = &g_106;
        int32_t *l_318 = &g_203[7][0][1];
        int32_t *l_319[5][8] = {{&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36},{&g_203[6][8][2],&g_203[6][8][2],&g_36,&g_203[6][8][2],&g_203[6][8][2],&g_36,&g_203[6][8][2],&g_203[6][8][2]},{&g_36,&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2]},{&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36},{&g_36,&g_36,&g_203[6][8][2],&g_36,&g_36,&g_203[6][8][2],&g_36,&g_36}};
        int32_t l_320 = (-1L);
        int32_t l_324[8][5] = {{0x6E5C56B9L,(-3L),0x6E5C56B9L,0xCDD651CBL,(-3L)},{0xC71873C1L,0x3313FFE9L,0xCDD651CBL,0xC71873C1L,0xCDD651CBL},{0xC71873C1L,0xC71873C1L,0L,(-3L),0xD93873DDL},{0x6E5C56B9L,0xD93873DDL,0xCDD651CBL,0xCDD651CBL,0xD93873DDL},{0xD93873DDL,0x3313FFE9L,0x6E5C56B9L,0xD93873DDL,0xCDD651CBL},{(-3L),0xD93873DDL,0L,0xD93873DDL,(-3L)},{0x6E5C56B9L,0xC71873C1L,0x3313FFE9L,0xCDD651CBL,0xC71873C1L},{(-3L),0x3313FFE9L,0x3313FFE9L,(-3L),0xCDD651CBL}};
        uint32_t l_325 = 1UL;
        int i, j;
        l_241 = ((*l_240) = (*g_148));
        (*g_99) = l_242;
        if ((((p_42 = (safe_lshift_func_uint8_t_u_u((g_228.f4 > 0xCCDF0915L), ((safe_mod_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u((*g_103), ((*l_242) , (*l_242)))) && (l_249 != (g_251 = l_249))), g_187)) || (((*l_240) |= ((((safe_lshift_func_uint8_t_u_s(0xA7L, p_44)) , g_48[4]) > p_45) != 0UL)) > g_159[0][0][2].f0))))) , (*l_242)) | 0xFF50L))
        { /* block id: 108 */
            uint32_t l_285 = 0x9EF29D04L;
            for (g_106 = 0; (g_106 <= 2); g_106 += 1)
            { /* block id: 111 */
                uint16_t * const l_261 = (void*)0;
                int8_t *l_272[10][5][1] = {{{&g_184[5]},{&g_184[5]},{&g_184[3]},{&g_184[6]},{&g_184[6]}},{{&g_184[3]},{&g_184[5]},{&g_184[5]},{&g_184[3]},{&g_184[5]}},{{&g_184[5]},{&g_184[3]},{&g_184[6]},{&g_184[6]},{&g_184[3]}},{{&g_184[5]},{&g_184[5]},{&g_184[3]},{&g_184[5]},{&g_184[5]}},{{&g_184[3]},{&g_184[6]},{&g_184[6]},{&g_184[3]},{&g_184[5]}},{{&g_184[5]},{&g_184[3]},{&g_184[5]},{&g_184[5]},{&g_184[3]}},{{&g_184[6]},{&g_184[6]},{&g_184[3]},{&g_184[5]},{&g_184[5]}},{{&g_184[3]},{&g_184[5]},{&g_184[5]},{&g_184[3]},{&g_184[6]}},{{&g_184[6]},{&g_184[3]},{&g_184[5]},{&g_184[5]},{&g_184[3]}},{{&g_184[5]},{&g_184[5]},{&g_184[3]},{&g_184[6]},{&g_184[6]}}};
                int32_t l_273 = 0x4C12E7F5L;
                struct S1 *l_275 = &g_274;
                uint64_t *l_307 = &g_106;
                uint32_t l_309[9][7] = {{1UL,1UL,3UL,0xF85C249BL,0UL,18446744073709551615UL,0UL},{0UL,0xFF3373FFL,1UL,0xCD473E2EL,18446744073709551615UL,1UL,1UL},{9UL,1UL,18446744073709551615UL,4UL,18446744073709551615UL,1UL,9UL},{0xA6213D03L,0UL,4UL,0UL,0xCD473E2EL,18446744073709551615UL,0xC8F9E45DL},{18446744073709551615UL,18446744073709551615UL,0xF85C249BL,0xFF3373FFL,18446744073709551615UL,0UL,0UL},{18446744073709551615UL,0x16BC2C94L,4UL,0x306B2812L,0x1E770A2EL,18446744073709551615UL,3UL},{0x16BC2C94L,3UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,3UL},{18446744073709551615UL,0xF85C249BL,1UL,1UL,3UL,0xCD473E2EL,0UL},{0UL,18446744073709551615UL,3UL,0x801D432DL,1UL,18446744073709551615UL,0xC8F9E45DL}};
                int i, j, k;
                (*g_100) = (((safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(g_74.f6, 5)), (g_153.f1 = (safe_add_func_uint32_t_u_u((&p_46 != l_261), 0x5EAFA43AL))))) & (((p_44 || (*g_103)) && (safe_add_func_int16_t_s_s((p_42 > 0x20F062ECA18747C1LL), ((*g_103) = ((safe_sub_func_int8_t_s_s((p_45 = (safe_mul_func_int8_t_s_s(((((safe_add_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((0xB19036AB275723CCLL && 9L), 1L)), g_228.f1)) == p_46) > 0UL) != 18446744073709551609UL), 0L))), 0L)) , p_46))))) > 1UL)) != l_273);
                (*l_275) = g_274;
                for (g_187 = 0; (g_187 <= 2); g_187 += 1)
                { /* block id: 119 */
                    int32_t *l_278 = &g_159[0][0][2].f4;
                    uint32_t l_284 = 4294967295UL;
                    int32_t l_303 = 0x8F848041L;
                    struct S1 **l_313 = &l_275;
                    uint32_t l_314[9][3][9] = {{{0x633B9458L,18446744073709551615UL,0x77DC7200L,0x6EADA4A3L,7UL,18446744073709551607UL,0x3BA1EA0FL,0x83C83D12L,18446744073709551611UL},{0x5656C1BFL,0xE7332D91L,7UL,1UL,0x5A8E75D0L,18446744073709551614UL,0x919B5D5DL,0xD3FBEF06L,3UL},{0xC996D737L,0UL,0x5656C1BFL,1UL,0x5797B168L,0x00041B72L,0x9D5C334FL,18446744073709551615UL,18446744073709551607UL}},{{0xCB4FB55EL,0x5A8E75D0L,8UL,0x3CAAAD1EL,18446744073709551615UL,18446744073709551609UL,0UL,0x633B9458L,0x77DC7200L},{0UL,0xDCAAEBCDL,4UL,0xC95A0841L,0x919B5D5DL,0x5E339E2DL,0xD08975AAL,18446744073709551609UL,18446744073709551609UL},{1UL,18446744073709551609UL,0x7A2844A8L,0x5797B168L,0x7A2844A8L,18446744073709551609UL,1UL,0x919B5D5DL,0x75387496L}},{{0x6F84ED78L,0x9D5C334FL,3UL,0x8293C637L,18446744073709551607UL,18446744073709551615UL,18446744073709551609UL,1UL,0UL},{18446744073709551610UL,18446744073709551608UL,0x5797B168L,0x185B386FL,18446744073709551607UL,0x8293C637L,0x5A8E75D0L,0x919B5D5DL,0x9D5C334FL},{18446744073709551610UL,18446744073709551609UL,0x83C83D12L,0xC8D4C02BL,0x04D07659L,0xC996D737L,8UL,18446744073709551609UL,0x3CAAAD1EL}},{{0xCB4FB55EL,18446744073709551615UL,0xDE809165L,0x89EC74CDL,0x6F84ED78L,18446744073709551615UL,2UL,0x633B9458L,0xDCA90170L},{18446744073709551615UL,2UL,0UL,0xC996D737L,0x633B9458L,0x83C83D12L,0xA4BC5AE5L,0xFEF068E4L,0x5E339E2DL},{0x09A7D0FCL,0xDCA90170L,0x5A8E75D0L,1UL,0x5E339E2DL,18446744073709551607UL,0UL,1UL,0UL}},{{1UL,1UL,0x5A8E75D0L,18446744073709551615UL,0x4F5053C8L,18446744073709551607UL,0x633B9458L,0x5656C1BFL,0UL},{0x75387496L,0x0D47D5A1L,0UL,0x5656C1BFL,0UL,0xC95A0841L,0xD62BFCDAL,0x89EC74CDL,0xB803B281L},{0x5A8E75D0L,18446744073709551607UL,0xDE809165L,18446744073709551614UL,0x3CAAAD1EL,0x600AA300L,0x83C83D12L,3UL,0x83C83D12L}},{{0UL,4UL,0x83C83D12L,0x83C83D12L,4UL,0UL,1UL,0x16B24A49L,18446744073709551614UL},{0x13111722L,0xA4BC5AE5L,0x5797B168L,1UL,1UL,8UL,18446744073709551607UL,0x00041B72L,0UL},{0x9901EBCEL,8UL,3UL,18446744073709551607UL,0x161AC998L,1UL,1UL,0x3BA1EA0FL,1UL}},{{0UL,0x00041B72L,0x7A2844A8L,0x4F5053C8L,0x8293C637L,18446744073709551611UL,0x83C83D12L,18446744073709551607UL,0x8674BF43L},{0x8293C637L,0x5797B168L,4UL,0x3BA1EA0FL,0x9901EBCEL,8UL,0xD62BFCDAL,0xDE809165L,0xE7332D91L},{0x77DC7200L,0x919B5D5DL,8UL,0x8674BF43L,18446744073709551614UL,0x591A1096L,0x633B9458L,0UL,0x0D47D5A1L}},{{7UL,0xC95A0841L,0xD3FBEF06L,18446744073709551615UL,18446744073709551609UL,0x6FB56C8CL,0UL,0x5E339E2DL,18446744073709551608UL},{0x5656C1BFL,0xC95A0841L,18446744073709551611UL,8UL,0x600AA300L,0xE7332D91L,0xA4BC5AE5L,0x77DC7200L,18446744073709551607UL},{0UL,0x919B5D5DL,0x04D07659L,0x09A7D0FCL,0x5656C1BFL,18446744073709551615UL,2UL,18446744073709551607UL,18446744073709551615UL}},{{0xD62BFCDAL,0x5797B168L,18446744073709551615UL,18446744073709551609UL,0x161AC998L,0xB803B281L,0xCB4FB55EL,0xCB4FB55EL,0xB803B281L},{0x7A2844A8L,0x161AC998L,0x04D07659L,0x161AC998L,0x7A2844A8L,0xD08975AAL,0xE7332D91L,0x591A1096L,8UL},{3UL,2UL,7UL,0x633B9458L,18446744073709551611UL,0x5E339E2DL,1UL,1UL,0x77DC7200L}}};
                    int i, j, k;
                }
            }
        }
        else
        { /* block id: 143 */
            int32_t **l_317 = (void*)0;
            l_317 = l_316[5][2];
        }
        ++l_325;
    }
    else
    { /* block id: 147 */
        int16_t l_333 = 0xB3FEL;
        int32_t l_336[7] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
        int i;
        l_336[1] ^= ((*l_242) &= ((l_328 & p_44) > ((((safe_div_func_int16_t_s_s(((void*)0 == &g_48[4]), (((0xB3796D65L ^ g_187) , (safe_lshift_func_int8_t_s_u(l_333, ((safe_sub_func_uint8_t_u_u((0xE4L < g_74.f1), 0x8AL)) <= 2L)))) && 0x80L))) , l_333) , g_159[0][0][2].f4) || l_333)));
    }
    (*l_339) = l_337;
    return p_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_99 g_100 g_103 g_228
 * writes: g_48 g_104 g_228
 */
static int16_t  func_53(int32_t  p_54, int32_t * p_55, int32_t  p_56, uint32_t  p_57)
{ /* block id: 83 */
    uint64_t *l_217 = &g_106;
    int16_t *l_218 = (void*)0;
    int16_t *l_219 = &g_48[1];
    int32_t l_220 = 7L;
    int8_t *l_225 = &g_184[1];
    const union U2 *l_233 = &g_126[3][0];
    if ((safe_mod_func_uint64_t_u_u((((l_220 = ((*l_219) = (l_217 != l_217))) && ((safe_mod_func_uint8_t_u_u(p_56, ((safe_mod_func_uint16_t_u_u((l_225 != l_225), ((*g_103) = (((void*)0 != &g_104) & ((*g_99) != &g_149))))) , p_57))) , l_220)) < 0x33L), (-6L))))
    { /* block id: 87 */
        struct S1 *l_229 = (void*)0;
        struct S1 *l_230 = &g_228;
        (*l_230) = g_228;
    }
    else
    { /* block id: 89 */
        const union U2 *l_231 = &g_126[3][0];
        l_233 = l_231;
        return p_56;
    }
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_96 g_153 g_159 g_103 g_104 g_36 g_106 g_4 g_40 g_74.f2 g_189 g_190 g_149
 * writes: g_96 g_40 g_153 g_104 g_184 g_107 g_187 g_189
 */
static uint8_t  func_58(int32_t * p_59, int64_t  p_60, uint32_t  p_61)
{ /* block id: 56 */
    uint64_t *l_157[5][4] = {{&g_106,&g_106,&g_106,(void*)0},{&g_106,(void*)0,(void*)0,(void*)0},{&g_106,&g_106,&g_106,(void*)0},{(void*)0,&g_106,&g_106,&g_106},{&g_106,&g_106,(void*)0,&g_106}};
    int32_t l_158 = 0x465DCB78L;
    int64_t *l_162 = &g_102;
    int32_t *l_191 = &g_40;
    int32_t *l_192 = &g_40;
    int32_t *l_193 = &g_149;
    int32_t *l_194 = (void*)0;
    int32_t *l_195 = &g_40;
    int32_t *l_196 = &g_40;
    int32_t *l_197 = &g_149;
    int32_t *l_198 = &l_158;
    int32_t *l_199 = &g_149;
    int32_t *l_200[4];
    int16_t l_201 = 0xB137L;
    int32_t l_204 = 0x127E7C44L;
    int32_t l_205 = (-10L);
    int16_t l_206[5] = {(-9L),(-9L),(-9L),(-9L),(-9L)};
    int64_t l_207 = 0L;
    uint64_t l_208[1];
    struct S1 *l_212 = &g_153;
    struct S1 **l_213 = &l_212;
    int i, j;
    for (i = 0; i < 4; i++)
        l_200[i] = (void*)0;
    for (i = 0; i < 1; i++)
        l_208[i] = 1UL;
lbl_211:
    for (g_96 = (-12); (g_96 < 32); ++g_96)
    { /* block id: 59 */
        int32_t *l_152 = &g_40;
        struct S1 *l_154 = &g_153;
        int32_t *l_164[3];
        uint32_t l_182[3][5] = {{4294967295UL,0x7BA435B6L,0x7BA435B6L,4294967295UL,0x7BA435B6L},{4294967295UL,4294967295UL,0x22F1BDA6L,4294967295UL,4294967295UL},{0x7BA435B6L,4294967295UL,0x7BA435B6L,0x7BA435B6L,4294967295UL}};
        int8_t *l_183[1];
        uint32_t *l_185 = &g_107;
        uint32_t *l_186 = &l_182[2][3];
        int i, j;
        for (i = 0; i < 3; i++)
            l_164[i] = &l_158;
        for (i = 0; i < 1; i++)
            l_183[i] = &g_184[5];
        (*l_152) = 1L;
        (*l_154) = g_153;
        l_158 = ((*l_152) = ((safe_sub_func_uint8_t_u_u(((p_60 < (&g_106 == (l_157[1][1] = l_157[1][1]))) ^ l_158), ((((((g_159[0][0][2] , ((*g_103)++)) , &g_102) == (l_162 = l_162)) >= (((void*)0 == &g_106) == p_61)) == g_36) != g_159[0][0][2].f3))) && 0x1335F78AL));
        if (((*l_152) = ((g_187 = ((g_106 != ((+((safe_sub_func_int32_t_s_s(((((*l_186) = (((*l_185) = ((((safe_div_func_int16_t_s_s(l_158, (safe_lshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(g_4[2], (0x16A212EBL < ((l_158 == 0L) < l_158)))), (g_184[4] = (p_61 ^ (safe_mod_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u((safe_div_func_int64_t_s_s(((l_182[0][1] ^ 9L) , 0xECF98005EDC9C37ALL), p_60)), (*g_103))) == (*l_152)), l_158)))))), 1)))) , l_158) & p_61) != (-6L))) > 0xE77FEEE3L)) != (*p_59)) , (*l_152)), l_158)) == 1UL)) > 0x9AB53173L)) , g_74.f2)) ^ g_153.f1)))
        { /* block id: 72 */
            uint64_t l_188[4] = {1UL,1UL,1UL,1UL};
            int i;
            return l_188[1];
        }
        else
        { /* block id: 74 */
            (*g_190) = g_189;
            return p_61;
        }
    }
    l_208[0]--;
    if (p_60)
        goto lbl_211;
    (*l_213) = l_212;
    return (*l_199);
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_74 g_36 g_48 g_40 g_99 g_102 g_103 g_107 g_108 g_114 g_124 g_104 g_33 g_148
 * writes: g_40 g_96 g_100 g_102 g_103 g_106 g_107 g_104 g_48 g_126 g_149
 */
static uint32_t  func_62(uint32_t  p_63, int32_t * p_64, uint16_t * p_65)
{ /* block id: 16 */
    const int32_t l_98[3][4][7] = {{{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L}},{{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L}},{{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L},{0x031B10CDL,0x8DAE6E92L,(-5L),(-5L),(-5L),(-5L),0x8DAE6E92L}}};
    int32_t *l_115 = &g_40;
    int32_t l_116 = 0xB9876582L;
    union U2 *l_125 = &g_126[3][0];
    union U2 l_138 = {0UL};
    union U2 *l_139 = &l_138;
    int i, j, k;
    for (p_63 = 0; (p_63 > 57); p_63++)
    { /* block id: 19 */
        int32_t l_82 = (-5L);
        uint8_t l_120 = 0x46L;
        uint16_t l_123 = 1UL;
        union U2 l_127 = {0xC62769A4L};
        if ((g_40 = (*p_64)))
        { /* block id: 21 */
            int32_t *l_94 = (void*)0;
            uint8_t *l_95 = &g_96;
            const int32_t l_97 = 0L;
            if ((&g_4[2] != ((safe_mul_func_int16_t_s_s(((g_74 , (safe_lshift_func_uint8_t_u_s(((safe_rshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u(1UL, (safe_unary_minus_func_uint64_t_u(l_82)))), 9)) , g_74.f2), 7))) >= (safe_sub_func_uint32_t_u_u((((safe_mul_func_int8_t_s_s((((l_82 < ((safe_lshift_func_uint8_t_u_u(((*l_95) = (safe_unary_minus_func_int32_t_s((((((safe_rshift_func_uint16_t_u_u(l_82, 1)) | 255UL) || (((&g_4[2] == l_94) , g_36) != 0x555AL)) && (-1L)) & g_48[4])))), l_82)) , 0L)) <= g_40) , l_97), 7UL)) >= 4294967295UL) != l_98[0][0][3]), (*p_64)))), (-1L))) , (void*)0)))
            { /* block id: 23 */
                int64_t *l_101 = &g_102;
                uint64_t *l_105[8] = {&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106};
                int i;
                (*g_99) = p_64;
                (*g_108) &= (((*l_101) |= (-4L)) ^ (g_107 &= (g_106 = ((g_103 = g_103) == &g_104))));
            }
            else
            { /* block id: 30 */
                for (g_96 = 0; (g_96 == 30); ++g_96)
                { /* block id: 33 */
                    uint16_t l_113[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_113[i] = 0x3E65L;
                    for (g_102 = 0; (g_102 >= 25); g_102++)
                    { /* block id: 36 */
                        (*g_114) &= l_113[2];
                    }
                }
            }
            for (g_104 = 0; g_104 < 10; g_104 += 1)
            {
                g_48[g_104] = 2L;
            }
        }
        else
        { /* block id: 42 */
            int32_t *l_117 = (void*)0;
            int32_t *l_118 = &g_40;
            int32_t *l_119[4];
            int i;
            for (i = 0; i < 4; i++)
                l_119[i] = (void*)0;
            l_115 = &l_82;
            for (g_106 = 0; g_106 < 10; g_106 += 1)
            {
                g_48[g_106] = 0x1EEAL;
            }
            --l_120;
            return l_123;
        }
        l_125 = g_124;
        (*l_115) ^= (l_127 , ((g_126[3][0] = l_127) , (*p_64)));
    }
    (*g_148) = ((((((&p_64 == (void*)0) , (((*g_103) & (safe_mod_func_uint64_t_u_u(((safe_div_func_uint16_t_u_u(0x084DL, (safe_mul_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(((*l_115) &= (*g_103)), (p_63 && (safe_add_func_int16_t_s_s(p_63, ((((((*l_139) = l_138) , (safe_div_func_int64_t_s_s((((safe_add_func_int8_t_s_s((safe_mod_func_int16_t_s_s((safe_sub_func_int8_t_s_s((-1L), p_63)), p_63)), p_63)) != 0x792153B3L) , g_104), p_63))) , 0xFBD3DF35L) && p_63) != g_33)))))), l_98[2][3][3])))) , 5UL), 0x2E6F118E40900504LL))) , (*l_115))) & g_74.f1) || 0xD26C8B9CL) , &g_114) == (void*)0);
    return (*l_115);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_48[i], "g_48[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_74.f0, "g_74.f0", print_hash_value);
    transparent_crc(g_74.f1, "g_74.f1", print_hash_value);
    transparent_crc(g_74.f2, "g_74.f2", print_hash_value);
    transparent_crc(g_74.f3, "g_74.f3", print_hash_value);
    transparent_crc(g_74.f4, "g_74.f4", print_hash_value);
    transparent_crc(g_74.f5, "g_74.f5", print_hash_value);
    transparent_crc(g_74.f6, "g_74.f6", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_126[i][j].f0, "g_126[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_153.f0, "g_153.f0", print_hash_value);
    transparent_crc(g_153.f1, "g_153.f1", print_hash_value);
    transparent_crc(g_153.f2, "g_153.f2", print_hash_value);
    transparent_crc(g_153.f3, "g_153.f3", print_hash_value);
    transparent_crc(g_153.f4, "g_153.f4", print_hash_value);
    transparent_crc(g_153.f5, "g_153.f5", print_hash_value);
    transparent_crc(g_153.f6, "g_153.f6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_159[i][j][k].f0, "g_159[i][j][k].f0", print_hash_value);
                transparent_crc(g_159[i][j][k].f1, "g_159[i][j][k].f1", print_hash_value);
                transparent_crc(g_159[i][j][k].f2, "g_159[i][j][k].f2", print_hash_value);
                transparent_crc(g_159[i][j][k].f3, "g_159[i][j][k].f3", print_hash_value);
                transparent_crc(g_159[i][j][k].f4, "g_159[i][j][k].f4", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_184[i], "g_184[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_187, "g_187", print_hash_value);
    transparent_crc(g_202, "g_202", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_203[i][j][k], "g_203[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_228.f0, "g_228.f0", print_hash_value);
    transparent_crc(g_228.f1, "g_228.f1", print_hash_value);
    transparent_crc(g_228.f2, "g_228.f2", print_hash_value);
    transparent_crc(g_228.f3, "g_228.f3", print_hash_value);
    transparent_crc(g_228.f4, "g_228.f4", print_hash_value);
    transparent_crc(g_228.f5, "g_228.f5", print_hash_value);
    transparent_crc(g_228.f6, "g_228.f6", print_hash_value);
    transparent_crc(g_274.f0, "g_274.f0", print_hash_value);
    transparent_crc(g_274.f1, "g_274.f1", print_hash_value);
    transparent_crc(g_274.f2, "g_274.f2", print_hash_value);
    transparent_crc(g_274.f3, "g_274.f3", print_hash_value);
    transparent_crc(g_274.f4, "g_274.f4", print_hash_value);
    transparent_crc(g_274.f5, "g_274.f5", print_hash_value);
    transparent_crc(g_274.f6, "g_274.f6", print_hash_value);
    transparent_crc(g_279, "g_279", print_hash_value);
    transparent_crc(g_288.f0, "g_288.f0", print_hash_value);
    transparent_crc(g_288.f1, "g_288.f1", print_hash_value);
    transparent_crc(g_288.f2, "g_288.f2", print_hash_value);
    transparent_crc(g_288.f3, "g_288.f3", print_hash_value);
    transparent_crc(g_288.f4, "g_288.f4", print_hash_value);
    transparent_crc(g_288.f5, "g_288.f5", print_hash_value);
    transparent_crc(g_288.f6, "g_288.f6", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    transparent_crc(g_397.f0, "g_397.f0", print_hash_value);
    transparent_crc(g_397.f1, "g_397.f1", print_hash_value);
    transparent_crc(g_397.f2, "g_397.f2", print_hash_value);
    transparent_crc(g_397.f3, "g_397.f3", print_hash_value);
    transparent_crc(g_397.f4, "g_397.f4", print_hash_value);
    transparent_crc(g_397.f5, "g_397.f5", print_hash_value);
    transparent_crc(g_397.f6, "g_397.f6", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_405[i][j].f0, "g_405[i][j].f0", print_hash_value);
            transparent_crc(g_405[i][j].f1, "g_405[i][j].f1", print_hash_value);
            transparent_crc(g_405[i][j].f2, "g_405[i][j].f2", print_hash_value);
            transparent_crc(g_405[i][j].f3, "g_405[i][j].f3", print_hash_value);
            transparent_crc(g_405[i][j].f4, "g_405[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_428, "g_428", print_hash_value);
    transparent_crc(g_436, "g_436", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_450[i], "g_450[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_474.f0, "g_474.f0", print_hash_value);
    transparent_crc(g_474.f1, "g_474.f1", print_hash_value);
    transparent_crc(g_474.f2, "g_474.f2", print_hash_value);
    transparent_crc(g_474.f3, "g_474.f3", print_hash_value);
    transparent_crc(g_474.f4, "g_474.f4", print_hash_value);
    transparent_crc(g_474.f5, "g_474.f5", print_hash_value);
    transparent_crc(g_474.f6, "g_474.f6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_511[i].f0, "g_511[i].f0", print_hash_value);
        transparent_crc(g_511[i].f1, "g_511[i].f1", print_hash_value);
        transparent_crc(g_511[i].f2, "g_511[i].f2", print_hash_value);
        transparent_crc(g_511[i].f3, "g_511[i].f3", print_hash_value);
        transparent_crc(g_511[i].f4, "g_511[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_614[i], "g_614[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_646.f0, "g_646.f0", print_hash_value);
    transparent_crc(g_646.f1, "g_646.f1", print_hash_value);
    transparent_crc(g_646.f2, "g_646.f2", print_hash_value);
    transparent_crc(g_646.f3, "g_646.f3", print_hash_value);
    transparent_crc(g_646.f4, "g_646.f4", print_hash_value);
    transparent_crc(g_646.f5, "g_646.f5", print_hash_value);
    transparent_crc(g_646.f6, "g_646.f6", print_hash_value);
    transparent_crc(g_707.f0, "g_707.f0", print_hash_value);
    transparent_crc(g_707.f1, "g_707.f1", print_hash_value);
    transparent_crc(g_707.f2, "g_707.f2", print_hash_value);
    transparent_crc(g_707.f3, "g_707.f3", print_hash_value);
    transparent_crc(g_707.f4, "g_707.f4", print_hash_value);
    transparent_crc(g_714, "g_714", print_hash_value);
    transparent_crc(g_722.f0, "g_722.f0", print_hash_value);
    transparent_crc(g_722.f1, "g_722.f1", print_hash_value);
    transparent_crc(g_722.f2, "g_722.f2", print_hash_value);
    transparent_crc(g_722.f3, "g_722.f3", print_hash_value);
    transparent_crc(g_722.f4, "g_722.f4", print_hash_value);
    transparent_crc(g_729.f0, "g_729.f0", print_hash_value);
    transparent_crc(g_729.f1, "g_729.f1", print_hash_value);
    transparent_crc(g_729.f2, "g_729.f2", print_hash_value);
    transparent_crc(g_729.f3, "g_729.f3", print_hash_value);
    transparent_crc(g_729.f4, "g_729.f4", print_hash_value);
    transparent_crc(g_729.f5, "g_729.f5", print_hash_value);
    transparent_crc(g_729.f6, "g_729.f6", print_hash_value);
    transparent_crc(g_749, "g_749", print_hash_value);
    transparent_crc(g_751, "g_751", print_hash_value);
    transparent_crc(g_752.f0, "g_752.f0", print_hash_value);
    transparent_crc(g_752.f1, "g_752.f1", print_hash_value);
    transparent_crc(g_752.f2, "g_752.f2", print_hash_value);
    transparent_crc(g_752.f3, "g_752.f3", print_hash_value);
    transparent_crc(g_752.f4, "g_752.f4", print_hash_value);
    transparent_crc(g_833.f0, "g_833.f0", print_hash_value);
    transparent_crc(g_833.f1, "g_833.f1", print_hash_value);
    transparent_crc(g_833.f2, "g_833.f2", print_hash_value);
    transparent_crc(g_833.f3, "g_833.f3", print_hash_value);
    transparent_crc(g_833.f4, "g_833.f4", print_hash_value);
    transparent_crc(g_852, "g_852", print_hash_value);
    transparent_crc(g_858.f0, "g_858.f0", print_hash_value);
    transparent_crc(g_858.f1, "g_858.f1", print_hash_value);
    transparent_crc(g_858.f2, "g_858.f2", print_hash_value);
    transparent_crc(g_858.f3, "g_858.f3", print_hash_value);
    transparent_crc(g_858.f4, "g_858.f4", print_hash_value);
    transparent_crc(g_858.f5, "g_858.f5", print_hash_value);
    transparent_crc(g_858.f6, "g_858.f6", print_hash_value);
    transparent_crc(g_860, "g_860", print_hash_value);
    transparent_crc(g_871.f0, "g_871.f0", print_hash_value);
    transparent_crc(g_871.f1, "g_871.f1", print_hash_value);
    transparent_crc(g_871.f2, "g_871.f2", print_hash_value);
    transparent_crc(g_871.f3, "g_871.f3", print_hash_value);
    transparent_crc(g_871.f4, "g_871.f4", print_hash_value);
    transparent_crc(g_871.f5, "g_871.f5", print_hash_value);
    transparent_crc(g_871.f6, "g_871.f6", print_hash_value);
    transparent_crc(g_885, "g_885", print_hash_value);
    transparent_crc(g_917.f0, "g_917.f0", print_hash_value);
    transparent_crc(g_917.f1, "g_917.f1", print_hash_value);
    transparent_crc(g_917.f2, "g_917.f2", print_hash_value);
    transparent_crc(g_917.f3, "g_917.f3", print_hash_value);
    transparent_crc(g_917.f4, "g_917.f4", print_hash_value);
    transparent_crc(g_918.f0, "g_918.f0", print_hash_value);
    transparent_crc(g_918.f1, "g_918.f1", print_hash_value);
    transparent_crc(g_918.f2, "g_918.f2", print_hash_value);
    transparent_crc(g_918.f3, "g_918.f3", print_hash_value);
    transparent_crc(g_918.f4, "g_918.f4", print_hash_value);
    transparent_crc(g_968, "g_968", print_hash_value);
    transparent_crc(g_1094, "g_1094", print_hash_value);
    transparent_crc(g_1115, "g_1115", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1186[i].f0, "g_1186[i].f0", print_hash_value);
        transparent_crc(g_1186[i].f1, "g_1186[i].f1", print_hash_value);
        transparent_crc(g_1186[i].f2, "g_1186[i].f2", print_hash_value);
        transparent_crc(g_1186[i].f3, "g_1186[i].f3", print_hash_value);
        transparent_crc(g_1186[i].f4, "g_1186[i].f4", print_hash_value);
        transparent_crc(g_1186[i].f5, "g_1186[i].f5", print_hash_value);
        transparent_crc(g_1186[i].f6, "g_1186[i].f6", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1286.f0, "g_1286.f0", print_hash_value);
    transparent_crc(g_1286.f1, "g_1286.f1", print_hash_value);
    transparent_crc(g_1286.f2, "g_1286.f2", print_hash_value);
    transparent_crc(g_1286.f3, "g_1286.f3", print_hash_value);
    transparent_crc(g_1286.f4, "g_1286.f4", print_hash_value);
    transparent_crc(g_1286.f5, "g_1286.f5", print_hash_value);
    transparent_crc(g_1286.f6, "g_1286.f6", print_hash_value);
    transparent_crc(g_1290.f0, "g_1290.f0", print_hash_value);
    transparent_crc(g_1290.f1, "g_1290.f1", print_hash_value);
    transparent_crc(g_1290.f2, "g_1290.f2", print_hash_value);
    transparent_crc(g_1290.f3, "g_1290.f3", print_hash_value);
    transparent_crc(g_1290.f4, "g_1290.f4", print_hash_value);
    transparent_crc(g_1290.f5, "g_1290.f5", print_hash_value);
    transparent_crc(g_1290.f6, "g_1290.f6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1338[i].f0, "g_1338[i].f0", print_hash_value);
        transparent_crc(g_1338[i].f1, "g_1338[i].f1", print_hash_value);
        transparent_crc(g_1338[i].f2, "g_1338[i].f2", print_hash_value);
        transparent_crc(g_1338[i].f3, "g_1338[i].f3", print_hash_value);
        transparent_crc(g_1338[i].f4, "g_1338[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1344.f0, "g_1344.f0", print_hash_value);
    transparent_crc(g_1359, "g_1359", print_hash_value);
    transparent_crc(g_1364.f0, "g_1364.f0", print_hash_value);
    transparent_crc(g_1364.f1, "g_1364.f1", print_hash_value);
    transparent_crc(g_1364.f2, "g_1364.f2", print_hash_value);
    transparent_crc(g_1364.f3, "g_1364.f3", print_hash_value);
    transparent_crc(g_1364.f4, "g_1364.f4", print_hash_value);
    transparent_crc(g_1385.f0, "g_1385.f0", print_hash_value);
    transparent_crc(g_1385.f1, "g_1385.f1", print_hash_value);
    transparent_crc(g_1385.f2, "g_1385.f2", print_hash_value);
    transparent_crc(g_1385.f3, "g_1385.f3", print_hash_value);
    transparent_crc(g_1385.f4, "g_1385.f4", print_hash_value);
    transparent_crc(g_1468, "g_1468", print_hash_value);
    transparent_crc(g_1541, "g_1541", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1555[i], "g_1555[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1632.f0, "g_1632.f0", print_hash_value);
    transparent_crc(g_1632.f1, "g_1632.f1", print_hash_value);
    transparent_crc(g_1632.f2, "g_1632.f2", print_hash_value);
    transparent_crc(g_1632.f3, "g_1632.f3", print_hash_value);
    transparent_crc(g_1632.f4, "g_1632.f4", print_hash_value);
    transparent_crc(g_1632.f5, "g_1632.f5", print_hash_value);
    transparent_crc(g_1632.f6, "g_1632.f6", print_hash_value);
    transparent_crc(g_1652.f0, "g_1652.f0", print_hash_value);
    transparent_crc(g_1652.f1, "g_1652.f1", print_hash_value);
    transparent_crc(g_1652.f2, "g_1652.f2", print_hash_value);
    transparent_crc(g_1652.f3, "g_1652.f3", print_hash_value);
    transparent_crc(g_1652.f4, "g_1652.f4", print_hash_value);
    transparent_crc(g_1702, "g_1702", print_hash_value);
    transparent_crc(g_1708.f0, "g_1708.f0", print_hash_value);
    transparent_crc(g_1708.f1, "g_1708.f1", print_hash_value);
    transparent_crc(g_1708.f2, "g_1708.f2", print_hash_value);
    transparent_crc(g_1708.f3, "g_1708.f3", print_hash_value);
    transparent_crc(g_1708.f4, "g_1708.f4", print_hash_value);
    transparent_crc(g_1708.f5, "g_1708.f5", print_hash_value);
    transparent_crc(g_1708.f6, "g_1708.f6", print_hash_value);
    transparent_crc(g_1739, "g_1739", print_hash_value);
    transparent_crc(g_1806, "g_1806", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1810[i].f0, "g_1810[i].f0", print_hash_value);
        transparent_crc(g_1810[i].f1, "g_1810[i].f1", print_hash_value);
        transparent_crc(g_1810[i].f2, "g_1810[i].f2", print_hash_value);
        transparent_crc(g_1810[i].f3, "g_1810[i].f3", print_hash_value);
        transparent_crc(g_1810[i].f4, "g_1810[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1831.f0, "g_1831.f0", print_hash_value);
    transparent_crc(g_1831.f1, "g_1831.f1", print_hash_value);
    transparent_crc(g_1831.f2, "g_1831.f2", print_hash_value);
    transparent_crc(g_1831.f3, "g_1831.f3", print_hash_value);
    transparent_crc(g_1831.f4, "g_1831.f4", print_hash_value);
    transparent_crc(g_1831.f5, "g_1831.f5", print_hash_value);
    transparent_crc(g_1831.f6, "g_1831.f6", print_hash_value);
    transparent_crc(g_1832.f0, "g_1832.f0", print_hash_value);
    transparent_crc(g_1832.f1, "g_1832.f1", print_hash_value);
    transparent_crc(g_1832.f2, "g_1832.f2", print_hash_value);
    transparent_crc(g_1832.f3, "g_1832.f3", print_hash_value);
    transparent_crc(g_1832.f4, "g_1832.f4", print_hash_value);
    transparent_crc(g_1849.f0, "g_1849.f0", print_hash_value);
    transparent_crc(g_1849.f1, "g_1849.f1", print_hash_value);
    transparent_crc(g_1849.f2, "g_1849.f2", print_hash_value);
    transparent_crc(g_1849.f3, "g_1849.f3", print_hash_value);
    transparent_crc(g_1849.f4, "g_1849.f4", print_hash_value);
    transparent_crc(g_1849.f5, "g_1849.f5", print_hash_value);
    transparent_crc(g_1849.f6, "g_1849.f6", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1868[i].f0, "g_1868[i].f0", print_hash_value);
        transparent_crc(g_1868[i].f1, "g_1868[i].f1", print_hash_value);
        transparent_crc(g_1868[i].f2, "g_1868[i].f2", print_hash_value);
        transparent_crc(g_1868[i].f3, "g_1868[i].f3", print_hash_value);
        transparent_crc(g_1868[i].f4, "g_1868[i].f4", print_hash_value);
        transparent_crc(g_1868[i].f5, "g_1868[i].f5", print_hash_value);
        transparent_crc(g_1868[i].f6, "g_1868[i].f6", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1902, "g_1902", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1981[i][j].f0, "g_1981[i][j].f0", print_hash_value);
            transparent_crc(g_1981[i][j].f1, "g_1981[i][j].f1", print_hash_value);
            transparent_crc(g_1981[i][j].f2, "g_1981[i][j].f2", print_hash_value);
            transparent_crc(g_1981[i][j].f3, "g_1981[i][j].f3", print_hash_value);
            transparent_crc(g_1981[i][j].f4, "g_1981[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2014.f0, "g_2014.f0", print_hash_value);
    transparent_crc(g_2014.f1, "g_2014.f1", print_hash_value);
    transparent_crc(g_2014.f2, "g_2014.f2", print_hash_value);
    transparent_crc(g_2014.f3, "g_2014.f3", print_hash_value);
    transparent_crc(g_2014.f4, "g_2014.f4", print_hash_value);
    transparent_crc(g_2024.f0, "g_2024.f0", print_hash_value);
    transparent_crc(g_2024.f1, "g_2024.f1", print_hash_value);
    transparent_crc(g_2024.f2, "g_2024.f2", print_hash_value);
    transparent_crc(g_2024.f3, "g_2024.f3", print_hash_value);
    transparent_crc(g_2024.f4, "g_2024.f4", print_hash_value);
    transparent_crc(g_2024.f5, "g_2024.f5", print_hash_value);
    transparent_crc(g_2024.f6, "g_2024.f6", print_hash_value);
    transparent_crc(g_2094.f0, "g_2094.f0", print_hash_value);
    transparent_crc(g_2094.f1, "g_2094.f1", print_hash_value);
    transparent_crc(g_2094.f2, "g_2094.f2", print_hash_value);
    transparent_crc(g_2094.f3, "g_2094.f3", print_hash_value);
    transparent_crc(g_2094.f4, "g_2094.f4", print_hash_value);
    transparent_crc(g_2116.f0, "g_2116.f0", print_hash_value);
    transparent_crc(g_2116.f1, "g_2116.f1", print_hash_value);
    transparent_crc(g_2116.f2, "g_2116.f2", print_hash_value);
    transparent_crc(g_2116.f3, "g_2116.f3", print_hash_value);
    transparent_crc(g_2116.f4, "g_2116.f4", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2163[i][j][k].f0, "g_2163[i][j][k].f0", print_hash_value);
                transparent_crc(g_2163[i][j][k].f1, "g_2163[i][j][k].f1", print_hash_value);
                transparent_crc(g_2163[i][j][k].f2, "g_2163[i][j][k].f2", print_hash_value);
                transparent_crc(g_2163[i][j][k].f3, "g_2163[i][j][k].f3", print_hash_value);
                transparent_crc(g_2163[i][j][k].f4, "g_2163[i][j][k].f4", print_hash_value);
                transparent_crc(g_2163[i][j][k].f5, "g_2163[i][j][k].f5", print_hash_value);
                transparent_crc(g_2163[i][j][k].f6, "g_2163[i][j][k].f6", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2184, "g_2184", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2185[i], "g_2185[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2186, "g_2186", print_hash_value);
    transparent_crc(g_2187, "g_2187", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2188[i][j], "g_2188[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2189, "g_2189", print_hash_value);
    transparent_crc(g_2190, "g_2190", print_hash_value);
    transparent_crc(g_2191, "g_2191", print_hash_value);
    transparent_crc(g_2192, "g_2192", print_hash_value);
    transparent_crc(g_2193, "g_2193", print_hash_value);
    transparent_crc(g_2194, "g_2194", print_hash_value);
    transparent_crc(g_2195, "g_2195", print_hash_value);
    transparent_crc(g_2229, "g_2229", print_hash_value);
    transparent_crc(g_2342, "g_2342", print_hash_value);
    transparent_crc(g_2369, "g_2369", print_hash_value);
    transparent_crc(g_2388.f0, "g_2388.f0", print_hash_value);
    transparent_crc(g_2388.f1, "g_2388.f1", print_hash_value);
    transparent_crc(g_2388.f2, "g_2388.f2", print_hash_value);
    transparent_crc(g_2388.f3, "g_2388.f3", print_hash_value);
    transparent_crc(g_2388.f4, "g_2388.f4", print_hash_value);
    transparent_crc(g_2444.f0, "g_2444.f0", print_hash_value);
    transparent_crc(g_2444.f1, "g_2444.f1", print_hash_value);
    transparent_crc(g_2444.f2, "g_2444.f2", print_hash_value);
    transparent_crc(g_2444.f3, "g_2444.f3", print_hash_value);
    transparent_crc(g_2444.f4, "g_2444.f4", print_hash_value);
    transparent_crc(g_2444.f5, "g_2444.f5", print_hash_value);
    transparent_crc(g_2444.f6, "g_2444.f6", print_hash_value);
    transparent_crc(g_2471.f0, "g_2471.f0", print_hash_value);
    transparent_crc(g_2471.f1, "g_2471.f1", print_hash_value);
    transparent_crc(g_2471.f2, "g_2471.f2", print_hash_value);
    transparent_crc(g_2471.f3, "g_2471.f3", print_hash_value);
    transparent_crc(g_2471.f4, "g_2471.f4", print_hash_value);
    transparent_crc(g_2495.f0, "g_2495.f0", print_hash_value);
    transparent_crc(g_2495.f1, "g_2495.f1", print_hash_value);
    transparent_crc(g_2495.f2, "g_2495.f2", print_hash_value);
    transparent_crc(g_2495.f3, "g_2495.f3", print_hash_value);
    transparent_crc(g_2495.f4, "g_2495.f4", print_hash_value);
    transparent_crc(g_2742, "g_2742", print_hash_value);
    transparent_crc(g_2754, "g_2754", print_hash_value);
    transparent_crc(g_2757, "g_2757", print_hash_value);
    transparent_crc(g_2819.f0, "g_2819.f0", print_hash_value);
    transparent_crc(g_2819.f1, "g_2819.f1", print_hash_value);
    transparent_crc(g_2819.f2, "g_2819.f2", print_hash_value);
    transparent_crc(g_2819.f3, "g_2819.f3", print_hash_value);
    transparent_crc(g_2819.f4, "g_2819.f4", print_hash_value);
    transparent_crc(g_2831, "g_2831", print_hash_value);
    transparent_crc(g_2873.f0, "g_2873.f0", print_hash_value);
    transparent_crc(g_2873.f1, "g_2873.f1", print_hash_value);
    transparent_crc(g_2873.f2, "g_2873.f2", print_hash_value);
    transparent_crc(g_2873.f3, "g_2873.f3", print_hash_value);
    transparent_crc(g_2873.f4, "g_2873.f4", print_hash_value);
    transparent_crc(g_2874, "g_2874", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2875[i].f0, "g_2875[i].f0", print_hash_value);
        transparent_crc(g_2875[i].f1, "g_2875[i].f1", print_hash_value);
        transparent_crc(g_2875[i].f2, "g_2875[i].f2", print_hash_value);
        transparent_crc(g_2875[i].f3, "g_2875[i].f3", print_hash_value);
        transparent_crc(g_2875[i].f4, "g_2875[i].f4", print_hash_value);
        transparent_crc(g_2875[i].f5, "g_2875[i].f5", print_hash_value);
        transparent_crc(g_2875[i].f6, "g_2875[i].f6", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3050, "g_3050", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3051[i], "g_3051[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3102.f0, "g_3102.f0", print_hash_value);
    transparent_crc(g_3102.f1, "g_3102.f1", print_hash_value);
    transparent_crc(g_3102.f2, "g_3102.f2", print_hash_value);
    transparent_crc(g_3102.f3, "g_3102.f3", print_hash_value);
    transparent_crc(g_3102.f4, "g_3102.f4", print_hash_value);
    transparent_crc(g_3102.f5, "g_3102.f5", print_hash_value);
    transparent_crc(g_3102.f6, "g_3102.f6", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 813
   depth: 1, occurrence: 44
XXX total union variables: 28

XXX non-zero bitfields defined in structs: 13
XXX zero bitfields defined in structs: 1
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 5
XXX structs with bitfields in the program: 150
breakdown:
   indirect level: 0, occurrence: 72
   indirect level: 1, occurrence: 36
   indirect level: 2, occurrence: 22
   indirect level: 3, occurrence: 5
   indirect level: 4, occurrence: 5
   indirect level: 5, occurrence: 6
   indirect level: 6, occurrence: 1
   indirect level: 7, occurrence: 3
XXX full-bitfields structs in the program: 22
breakdown:
   indirect level: 0, occurrence: 22
XXX times a bitfields struct's address is taken: 132
XXX times a bitfields struct on LHS: 6
XXX times a bitfields struct on RHS: 85
XXX times a single bitfield on LHS: 11
XXX times a single bitfield on RHS: 213

XXX max expression depth: 37
breakdown:
   depth: 1, occurrence: 145
   depth: 2, occurrence: 29
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 3
   depth: 30, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 37, occurrence: 1

XXX total number of pointers: 652

XXX times a variable address is taken: 1437
XXX times a pointer is dereferenced on RHS: 488
breakdown:
   depth: 1, occurrence: 417
   depth: 2, occurrence: 57
   depth: 3, occurrence: 11
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
XXX times a pointer is dereferenced on LHS: 425
breakdown:
   depth: 1, occurrence: 397
   depth: 2, occurrence: 24
   depth: 3, occurrence: 4
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 15
XXX times a pointer is compared with another pointer: 21
XXX times a pointer is qualified to be dereferenced: 10788

XXX max dereference level: 7
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2577
   level: 2, occurrence: 369
   level: 3, occurrence: 97
   level: 4, occurrence: 28
   level: 5, occurrence: 10
   level: 6, occurrence: 2
   level: 7, occurrence: 1
XXX number of pointers point to pointers: 274
XXX number of pointers point to scalars: 320
XXX number of pointers point to structs: 41
XXX percent of pointers has null in alias set: 30.7
XXX average alias set size: 1.52

XXX times a non-volatile is read: 2375
XXX times a non-volatile is write: 1154
XXX times a volatile is read: 214
XXX    times read thru a pointer: 21
XXX times a volatile is write: 59
XXX    times written thru a pointer: 7
XXX times a volatile is available for access: 8.39e+03
XXX percentage of non-volatile access: 92.8

XXX forward jumps: 0
XXX backward jumps: 9

XXX stmts: 140
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 26
   depth: 2, occurrence: 20
   depth: 3, occurrence: 20
   depth: 4, occurrence: 17
   depth: 5, occurrence: 26

XXX percentage a fresh-made variable is used: 18.3
XXX percentage an existing variable is used: 81.7
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

