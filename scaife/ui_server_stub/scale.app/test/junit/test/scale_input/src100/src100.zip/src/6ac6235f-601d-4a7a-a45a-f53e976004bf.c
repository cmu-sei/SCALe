/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1120236029
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint32_t  f0;
   int8_t  f1;
   const volatile uint8_t  f2;
};

union U1 {
   uint64_t  f0;
   volatile uint16_t  f1;
};

union U2 {
   uint32_t  f0;
   const uint8_t  f1;
   uint32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-9L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0x961C0F80L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4[3] = {0x307B5CA9L,0x307B5CA9L,0x307B5CA9L};
static int32_t g_7 = 0x80BE39E3L;
static int32_t g_13 = (-7L);
static int32_t * volatile g_12 = &g_13;/* VOLATILE GLOBAL g_12 */
static volatile int32_t g_15 = 0x2280643BL;/* VOLATILE GLOBAL g_15 */
static volatile int32_t g_16 = 0x77EBD004L;/* VOLATILE GLOBAL g_16 */
static volatile int32_t g_17 = 0L;/* VOLATILE GLOBAL g_17 */
static int32_t g_18[8][2] = {{0x29478C9DL,0L},{0x0B597857L,0x5AEE0CD9L},{0x0B597857L,0L},{0x29478C9DL,0x29478C9DL},{0L,0x0B597857L},{0x5AEE0CD9L,0x0B597857L},{0L,0x29478C9DL},{0x29478C9DL,0L}};
static volatile int32_t g_23 = 1L;/* VOLATILE GLOBAL g_23 */
static int32_t g_24 = 1L;
static int32_t g_25 = 0x69FDB81FL;
static volatile int32_t g_26 = 0x628AEA38L;/* VOLATILE GLOBAL g_26 */
static int32_t g_27 = 0x6845925FL;
static union U1 g_66 = {2UL};/* VOLATILE GLOBAL g_66 */
static uint16_t g_76 = 0xA2D5L;
static uint64_t g_81[3][9] = {{1UL,1UL,0xFFD363BF156DE04BLL,0x032F891D98557C7BLL,0xFFD363BF156DE04BLL,1UL,1UL,0xFFD363BF156DE04BLL,0x032F891D98557C7BLL},{1UL,18446744073709551615UL,1UL,0xFFD363BF156DE04BLL,0xFFD363BF156DE04BLL,1UL,18446744073709551615UL,1UL,0xFFD363BF156DE04BLL},{1UL,0xFFD363BF156DE04BLL,0xFFD363BF156DE04BLL,1UL,18446744073709551615UL,1UL,0xFFD363BF156DE04BLL,0xFFD363BF156DE04BLL,1UL}};
static union U1 *g_84 = &g_66;
static union U1 ** volatile g_83 = &g_84;/* VOLATILE GLOBAL g_83 */
static union U2 g_85[9][4][7] = {{{{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL}},{{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL}},{{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L}},{{2UL},{2UL},{1UL},{2UL},{2UL},{1UL},{2UL}}},{{{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL}},{{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L}},{{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL}},{{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL}}},{{{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L}},{{2UL},{2UL},{1UL},{2UL},{2UL},{1UL},{2UL}},{{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL}},{{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L}}},{{{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL}},{{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL}},{{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L}},{{2UL},{2UL},{1UL},{2UL},{2UL},{1UL},{2UL}}},{{{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL}},{{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L}},{{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL}},{{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL}}},{{{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L}},{{2UL},{2UL},{1UL},{2UL},{2UL},{1UL},{2UL}},{{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL}},{{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L}}},{{{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL},{18446744073709551609UL},{0UL},{18446744073709551609UL}},{{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL}},{{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L}},{{2UL},{2UL},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L}}},{{{0x9BB10DA9L},{0UL},{0UL},{0x9BB10DA9L},{0UL},{0UL},{0x9BB10DA9L}},{{1UL},{0x8D8C4114L},{1UL},{1UL},{0x8D8C4114L},{1UL},{1UL}},{{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L},{0x9BB10DA9L},{18446744073709551609UL},{0x9BB10DA9L}},{{0x8D8C4114L},{1UL},{1UL},{0x8D8C4114L},{1UL},{1UL},{0x8D8C4114L}}},{{{0UL},{0x9BB10DA9L},{0UL},{0UL},{0x9BB10DA9L},{0UL},{0UL}},{{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L},{0x8D8C4114L},{2UL},{0x8D8C4114L}},{{0x9BB10DA9L},{0UL},{0UL},{0x9BB10DA9L},{0UL},{0UL},{0x9BB10DA9L}},{{1UL},{0x8D8C4114L},{1UL},{1UL},{0x8D8C4114L},{1UL},{1UL}}}};
static int32_t g_88 = 1L;
static int32_t * volatile g_104 = &g_88;/* VOLATILE GLOBAL g_104 */
static uint32_t g_106 = 0x515E6AD3L;
static union U0 g_117 = {18446744073709551607UL};/* VOLATILE GLOBAL g_117 */
static union U1 g_188 = {0x8293169C20454707LL};/* VOLATILE GLOBAL g_188 */
static uint16_t g_191[2] = {4UL,4UL};
static int32_t * volatile g_192[3][5][1] = {{{&g_88},{(void*)0},{&g_88},{(void*)0},{&g_88}},{{(void*)0},{&g_88},{(void*)0},{&g_88},{(void*)0}},{{&g_88},{(void*)0},{&g_88},{(void*)0},{&g_88}}};
static int32_t * volatile g_193 = (void*)0;/* VOLATILE GLOBAL g_193 */
static int32_t * volatile g_194[5][5] = {{(void*)0,&g_25,(void*)0,&g_25,(void*)0},{&g_88,&g_88,&g_88,&g_88,&g_88},{(void*)0,&g_25,(void*)0,&g_25,(void*)0},{&g_88,&g_88,&g_88,&g_88,&g_88},{(void*)0,&g_25,(void*)0,&g_25,(void*)0}};
static int32_t * volatile g_196[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t * const  volatile g_197[8][7][4] = {{{(void*)0,&g_13,&g_27,&g_4[1]},{&g_88,&g_27,&g_27,&g_88},{(void*)0,&g_88,(void*)0,&g_7},{&g_4[2],(void*)0,&g_7,&g_4[2]},{&g_7,&g_4[2],(void*)0,&g_4[2]},{&g_27,(void*)0,&g_13,&g_7},{&g_88,&g_88,&g_4[2],&g_88}},{{&g_13,&g_27,&g_4[1],&g_4[1]},{&g_13,&g_13,&g_4[2],(void*)0},{&g_88,&g_4[1],&g_13,&g_88},{&g_27,&g_4[2],(void*)0,&g_13},{&g_7,&g_4[2],&g_7,&g_88},{&g_4[2],&g_4[1],(void*)0,(void*)0},{(void*)0,&g_13,&g_27,&g_4[1]}},{{&g_88,&g_27,&g_27,&g_88},{(void*)0,&g_88,(void*)0,&g_7},{&g_4[2],(void*)0,&g_7,&g_4[2]},{&g_7,&g_4[2],(void*)0,&g_4[2]},{&g_27,(void*)0,&g_13,&g_7},{&g_88,(void*)0,&g_4[2],&g_13},{&g_4[2],&g_88,&g_27,&g_27}},{{&g_4[2],&g_4[2],&g_4[2],&g_88},{&g_7,&g_27,&g_4[2],(void*)0},{&g_88,(void*)0,&g_88,&g_4[2]},{&g_4[1],(void*)0,&g_4[1],(void*)0},{(void*)0,&g_27,(void*)0,&g_88},{&g_88,&g_4[2],&g_88,&g_27},{&g_13,&g_88,&g_88,&g_13}},{{&g_88,(void*)0,(void*)0,&g_4[1]},{(void*)0,(void*)0,&g_4[1],&g_4[2]},{&g_4[1],&g_4[2],&g_88,&g_4[2]},{&g_88,(void*)0,&g_4[2],&g_4[1]},{&g_7,(void*)0,&g_4[2],&g_13},{&g_4[2],&g_88,&g_27,&g_27},{&g_4[2],&g_4[2],&g_4[2],&g_88}},{{&g_7,&g_27,&g_4[2],(void*)0},{&g_88,(void*)0,&g_88,&g_4[2]},{&g_4[1],(void*)0,&g_4[1],(void*)0},{(void*)0,&g_27,(void*)0,&g_88},{&g_88,&g_4[2],&g_88,&g_27},{&g_13,&g_88,&g_88,&g_13},{&g_88,(void*)0,(void*)0,&g_4[1]}},{{(void*)0,(void*)0,&g_4[1],&g_4[2]},{&g_4[1],&g_4[2],&g_88,&g_4[2]},{&g_88,(void*)0,&g_4[2],&g_4[1]},{&g_7,(void*)0,&g_4[2],&g_13},{&g_4[2],&g_88,&g_27,&g_27},{&g_4[2],&g_4[2],&g_4[2],&g_88},{&g_7,&g_27,&g_4[2],(void*)0}},{{&g_88,(void*)0,&g_88,&g_4[2]},{&g_4[1],(void*)0,&g_4[1],(void*)0},{(void*)0,&g_27,(void*)0,&g_88},{&g_88,&g_4[2],&g_88,&g_27},{&g_13,&g_88,&g_88,&g_13},{&g_88,(void*)0,(void*)0,&g_4[1]},{(void*)0,(void*)0,&g_4[1],&g_4[2]}}};
static volatile union U0 g_215 = {0x3A84E4E4L};/* VOLATILE GLOBAL g_215 */
static uint8_t g_221 = 2UL;
static int32_t *g_226 = (void*)0;
static int32_t ** const  volatile g_225[7][4] = {{&g_226,&g_226,&g_226,&g_226},{(void*)0,&g_226,(void*)0,&g_226},{&g_226,&g_226,&g_226,&g_226},{(void*)0,(void*)0,&g_226,&g_226},{(void*)0,(void*)0,&g_226,&g_226},{&g_226,&g_226,(void*)0,&g_226},{(void*)0,&g_226,&g_226,(void*)0}};
static union U1 g_257 = {1UL};/* VOLATILE GLOBAL g_257 */
static int8_t g_259 = 0x63L;
static int16_t g_261 = 7L;
static int32_t ** volatile g_263[8][3][7] = {{{&g_226,(void*)0,&g_226,&g_226,&g_226,&g_226,&g_226},{&g_226,(void*)0,&g_226,&g_226,&g_226,&g_226,(void*)0},{&g_226,&g_226,(void*)0,&g_226,&g_226,&g_226,&g_226}},{{&g_226,&g_226,&g_226,&g_226,(void*)0,&g_226,(void*)0},{&g_226,(void*)0,(void*)0,&g_226,(void*)0,&g_226,&g_226},{&g_226,(void*)0,&g_226,&g_226,&g_226,(void*)0,&g_226}},{{&g_226,&g_226,&g_226,(void*)0,&g_226,&g_226,&g_226},{&g_226,(void*)0,&g_226,&g_226,&g_226,&g_226,(void*)0},{&g_226,&g_226,&g_226,&g_226,&g_226,&g_226,&g_226}},{{&g_226,(void*)0,&g_226,&g_226,(void*)0,&g_226,&g_226},{&g_226,&g_226,&g_226,&g_226,(void*)0,(void*)0,&g_226},{&g_226,&g_226,&g_226,&g_226,&g_226,&g_226,&g_226}},{{&g_226,&g_226,(void*)0,&g_226,&g_226,&g_226,(void*)0},{&g_226,&g_226,&g_226,&g_226,&g_226,&g_226,&g_226},{&g_226,&g_226,(void*)0,&g_226,&g_226,&g_226,&g_226}},{{&g_226,&g_226,&g_226,&g_226,&g_226,(void*)0,(void*)0},{&g_226,&g_226,&g_226,&g_226,&g_226,&g_226,&g_226},{&g_226,(void*)0,&g_226,(void*)0,&g_226,&g_226,&g_226}},{{(void*)0,&g_226,&g_226,&g_226,&g_226,&g_226,&g_226},{&g_226,(void*)0,(void*)0,&g_226,&g_226,&g_226,&g_226},{&g_226,&g_226,&g_226,&g_226,(void*)0,&g_226,(void*)0}},{{&g_226,(void*)0,(void*)0,&g_226,(void*)0,&g_226,&g_226},{&g_226,(void*)0,&g_226,&g_226,&g_226,(void*)0,&g_226},{&g_226,&g_226,&g_226,(void*)0,&g_226,&g_226,&g_226}}};
static union U2 *g_267 = &g_85[1][2][4];
static union U2 ** volatile g_266[7][10][3] = {{{&g_267,(void*)0,&g_267},{&g_267,&g_267,(void*)0},{&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,&g_267},{&g_267,&g_267,(void*)0},{&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,&g_267},{&g_267,&g_267,(void*)0}},{{&g_267,&g_267,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0}},{{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267}},{{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0}},{{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267}},{{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0}},{{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{(void*)0,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{&g_267,&g_267,&g_267},{(void*)0,(void*)0,&g_267},{&g_267,&g_267,&g_267},{&g_267,(void*)0,(void*)0},{(void*)0,&g_267,&g_267},{(void*)0,(void*)0,&g_267}}};
static const uint64_t g_282 = 0x164A4B153B5C7476LL;
static const uint64_t g_284[8][4][8] = {{{0UL,18446744073709551608UL,0xC1DFA2340815C885LL,1UL,0UL,0xE451AA7E5032B20FLL,0xAF21F3CBF744FCCALL,9UL},{18446744073709551611UL,0xAF21F3CBF744FCCALL,0xE10AC72715D12D35LL,0x4E396D1898FDDD54LL,0xCFDBA259CDA87769LL,0xB200F8A826AD5A5FLL,0x83AFEF4EC5B960CALL,0x83AFEF4EC5B960CALL},{1UL,0x04C18D013F6FB8DCLL,9UL,9UL,0xC5EEC6CABB0AE272LL,0x40767F2EEB82D4F0LL,0UL,0xC1DFA2340815C885LL},{0xC44B694AD86DD0FDLL,18446744073709551615UL,0x68CE296E4B58B70ALL,0xCAD51E188A6EBA9FLL,18446744073709551615UL,0xE10AC72715D12D35LL,0UL,0x88E26377905A4FDELL}},{{18446744073709551608UL,18446744073709551615UL,0UL,0xCAD51E188A6EBA9FLL,0x1FC442DDCB8241A0LL,0x3604912DCD832BE4LL,0x3F3ABE089725B4D9LL,0xC1DFA2340815C885LL},{6UL,0x1FC442DDCB8241A0LL,0UL,1UL,0UL,0xB046F15C1AE0B1E6LL,18446744073709551615UL,0xE451AA7E5032B20FLL},{18446744073709551608UL,0x68CE296E4B58B70ALL,0xE10AC72715D12D35LL,0UL,1UL,18446744073709551615UL,9UL,1UL},{0UL,1UL,1UL,18446744073709551615UL,1UL,18446744073709551610UL,18446744073709551608UL,1UL}},{{1UL,0UL,0UL,1UL,0xCAD51E188A6EBA9FLL,0x88E26377905A4FDELL,18446744073709551615UL,9UL},{18446744073709551615UL,0xE10AC72715D12D35LL,0UL,0UL,0x88E26377905A4FDELL,0x1F51FECF9D78492DLL,0UL,1UL},{0UL,18446744073709551615UL,0x3604912DCD832BE4LL,18446744073709551608UL,1UL,8UL,1UL,18446744073709551608UL},{1UL,0UL,1UL,6UL,0xEFCDF892E813BFA9LL,18446744073709551615UL,1UL,1UL}},{{0xCAD51E188A6EBA9FLL,0UL,0xEE815A87531F4ECELL,18446744073709551608UL,0UL,18446744073709551615UL,0xEFCDF892E813BFA9LL,0xE10AC72715D12D35LL},{0xCAD51E188A6EBA9FLL,0xC1DFA2340815C885LL,0xAF21F3CBF744FCCALL,0xC44B694AD86DD0FDLL,0xEFCDF892E813BFA9LL,0x04C18D013F6FB8DCLL,0xC44B694AD86DD0FDLL,0x4EBD6529741549FFLL},{1UL,0x1FC442DDCB8241A0LL,0x1F51FECF9D78492DLL,0x40767F2EEB82D4F0LL,1UL,0x68CE296E4B58B70ALL,0x9875F892B5805980LL,0x3F3ABE089725B4D9LL},{0UL,0xEE815A87531F4ECELL,0xB046F15C1AE0B1E6LL,0xC1DFA2340815C885LL,0x88E26377905A4FDELL,0xE10AC72715D12D35LL,0UL,18446744073709551615UL}},{{18446744073709551615UL,0x4EBD6529741549FFLL,0xCC35247419DDA72DLL,9UL,0xCAD51E188A6EBA9FLL,0xBFC8718FD8965500LL,18446744073709551608UL,0x4EBD6529741549FFLL},{1UL,0xC5EEC6CABB0AE272LL,18446744073709551606UL,18446744073709551615UL,1UL,6UL,18446744073709551615UL,18446744073709551615UL},{0UL,0xB046F15C1AE0B1E6LL,18446744073709551615UL,18446744073709551608UL,1UL,0xCA8746FC31715504LL,0x4EBD6529741549FFLL,0UL},{18446744073709551608UL,18446744073709551608UL,1UL,0UL,0UL,1UL,18446744073709551608UL,18446744073709551608UL}},{{6UL,0xCAD51E188A6EBA9FLL,0xB200F8A826AD5A5FLL,18446744073709551615UL,0x1FC442DDCB8241A0LL,18446744073709551615UL,0UL,0UL},{18446744073709551608UL,18446744073709551615UL,0xB046F15C1AE0B1E6LL,0UL,18446744073709551615UL,18446744073709551615UL,18446744073709551610UL,0x40767F2EEB82D4F0LL},{0xC44B694AD86DD0FDLL,0xCAD51E188A6EBA9FLL,1UL,0xE451AA7E5032B20FLL,0xC5EEC6CABB0AE272LL,1UL,0xC44B694AD86DD0FDLL,1UL},{0x40767F2EEB82D4F0LL,18446744073709551608UL,18446744073709551615UL,0xEE815A87531F4ECELL,18446744073709551610UL,0xCA8746FC31715504LL,0xB046F15C1AE0B1E6LL,0x1FC442DDCB8241A0LL}},{{0xC1DFA2340815C885LL,0xB046F15C1AE0B1E6LL,0xEE815A87531F4ECELL,0UL,0x9875F892B5805980LL,6UL,0xE451AA7E5032B20FLL,1UL},{9UL,0xC5EEC6CABB0AE272LL,18446744073709551615UL,0x1FC442DDCB8241A0LL,0xC5EEC6CABB0AE272LL,0xBFC8718FD8965500LL,1UL,0xC1DFA2340815C885LL},{18446744073709551615UL,0x4EBD6529741549FFLL,0xAF21F3CBF744FCCALL,1UL,0xB200F8A826AD5A5FLL,18446744073709551606UL,0UL,18446744073709551606UL},{6UL,18446744073709551610UL,0xBFC8718FD8965500LL,0UL,8UL,0xAF21F3CBF744FCCALL,1UL,0xAF21F3CBF744FCCALL}},{{0x68CE296E4B58B70ALL,6UL,0xED05CF7DCBB15B2CLL,6UL,0x68CE296E4B58B70ALL,0xC5EEC6CABB0AE272LL,0xB200F8A826AD5A5FLL,0xCA8746FC31715504LL},{0xCC35247419DDA72DLL,18446744073709551615UL,18446744073709551606UL,0x83AFEF4EC5B960CALL,0xCA8746FC31715504LL,0x04C18D013F6FB8DCLL,18446744073709551615UL,6UL},{0x80943305E4FAD0D5LL,0xBFC8718FD8965500LL,18446744073709551606UL,18446744073709551615UL,8UL,0xCC35247419DDA72DLL,0xB200F8A826AD5A5FLL,8UL},{0xCA8746FC31715504LL,0x80943305E4FAD0D5LL,0xED05CF7DCBB15B2CLL,0xCA8746FC31715504LL,0UL,0xCAD51E188A6EBA9FLL,1UL,1UL}}};
static volatile uint32_t g_288 = 0xAB829022L;/* VOLATILE GLOBAL g_288 */
static volatile uint32_t *g_287 = &g_288;
static volatile uint32_t **g_286 = &g_287;
static int32_t ** volatile g_294 = (void*)0;/* VOLATILE GLOBAL g_294 */
static int32_t ** volatile g_296 = &g_226;/* VOLATILE GLOBAL g_296 */
static int8_t g_333 = 0L;
static volatile union U1 g_360 = {0x6D0E269AAF8453B7LL};/* VOLATILE GLOBAL g_360 */
static int8_t *g_365 = &g_117.f1;
static uint16_t *g_387 = &g_76;
static int32_t * volatile g_389[2][1][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
static int32_t * volatile g_390 = &g_88;/* VOLATILE GLOBAL g_390 */
static const union U1 *g_401 = &g_188;
static const union U1 **g_400 = &g_401;
static uint16_t **g_415[2] = {&g_387,&g_387};
static uint16_t *** volatile g_414 = &g_415[1];/* VOLATILE GLOBAL g_414 */
static union U1 g_486 = {18446744073709551615UL};/* VOLATILE GLOBAL g_486 */
static union U1 g_561[10][10] = {{{0UL},{1UL},{0UL},{0UL},{1UL},{18446744073709551614UL},{0x7AA850CFCD5D4EF2LL},{0xB9936B6C9741DC32LL},{18446744073709551606UL},{0x7C07B1CC5B015CB7LL}},{{0x7C07B1CC5B015CB7LL},{18446744073709551614UL},{0x50FF37BDC370AB0DLL},{2UL},{0xB9936B6C9741DC32LL},{18446744073709551615UL},{18446744073709551615UL},{0xB9936B6C9741DC32LL},{2UL},{0x50FF37BDC370AB0DLL}},{{0x19E11B61509602AELL},{0x19E11B61509602AELL},{0UL},{1UL},{18446744073709551606UL},{1UL},{18446744073709551615UL},{0x14954DFE439CB778LL},{0xB9936B6C9741DC32LL},{0x899225A4937A474ALL}},{{18446744073709551615UL},{0x7AA850CFCD5D4EF2LL},{0x19E11B61509602AELL},{18446744073709551615UL},{18446744073709551615UL},{1UL},{18446744073709551615UL},{18446744073709551615UL},{0x19E11B61509602AELL},{0x7AA850CFCD5D4EF2LL}},{{0xB9936B6C9741DC32LL},{0x19E11B61509602AELL},{2UL},{0x7C07B1CC5B015CB7LL},{0x899225A4937A474ALL},{0UL},{18446744073709551615UL},{1UL},{1UL},{0x14954DFE439CB778LL}},{{1UL},{18446744073709551614UL},{18446744073709551615UL},{0x7AA850CFCD5D4EF2LL},{0UL},{0UL},{0x7AA850CFCD5D4EF2LL},{18446744073709551615UL},{18446744073709551614UL},{1UL}},{{0xB9936B6C9741DC32LL},{1UL},{0UL},{18446744073709551615UL},{0x19E11B61509602AELL},{1UL},{2UL},{18446744073709551614UL},{18446744073709551615UL},{0x3611B2C5614742BCLL}},{{18446744073709551615UL},{0x50FF37BDC370AB0DLL},{0x14954DFE439CB778LL},{1UL},{0x19E11B61509602AELL},{1UL},{0x14954DFE439CB778LL},{0x50FF37BDC370AB0DLL},{18446744073709551615UL},{1UL}},{{0x19E11B61509602AELL},{2UL},{0x7C07B1CC5B015CB7LL},{0x899225A4937A474ALL},{0UL},{18446744073709551615UL},{1UL},{1UL},{0x14954DFE439CB778LL},{0x14954DFE439CB778LL}},{{0x7C07B1CC5B015CB7LL},{0UL},{18446744073709551614UL},{0x899225A4937A474ALL},{0x899225A4937A474ALL},{18446744073709551614UL},{0UL},{0x7C07B1CC5B015CB7LL},{18446744073709551615UL},{0x7AA850CFCD5D4EF2LL}}};
static union U1 g_668 = {5UL};/* VOLATILE GLOBAL g_668 */
static const volatile int64_t g_686[1][10][4] = {{{2L,0xCD8E67A1D8F2943ELL,2L,1L},{2L,1L,1L,2L},{0x3CC918E08D04154ALL,1L,0x531EE4EACFE1940FLL,1L},{1L,0xCD8E67A1D8F2943ELL,0x531EE4EACFE1940FLL,0x531EE4EACFE1940FLL},{0x3CC918E08D04154ALL,0x3CC918E08D04154ALL,1L,0x531EE4EACFE1940FLL},{2L,0xCD8E67A1D8F2943ELL,2L,1L},{2L,1L,1L,2L},{0x3CC918E08D04154ALL,1L,0x531EE4EACFE1940FLL,1L},{1L,0x3CC918E08D04154ALL,0xCD8E67A1D8F2943ELL,0xCD8E67A1D8F2943ELL},{1L,1L,2L,0xCD8E67A1D8F2943ELL}}};
static const volatile int64_t *g_685 = &g_686[0][5][1];
static volatile union U0 g_699[2][5] = {{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xE7C234F4L},{0xE7C234F4L},{0xE7C234F4L},{0xE7C234F4L},{0xE7C234F4L}}};
static volatile union U1 g_716 = {18446744073709551613UL};/* VOLATILE GLOBAL g_716 */
static int64_t g_753 = 0x42DCD3A0FBCB9A3BLL;
static volatile union U1 g_765 = {2UL};/* VOLATILE GLOBAL g_765 */
static int32_t * volatile g_783 = (void*)0;/* VOLATILE GLOBAL g_783 */
static int8_t **g_868 = &g_365;
static volatile union U1 g_886 = {0xEDE59209412CA4E3LL};/* VOLATILE GLOBAL g_886 */
static union U1 g_889 = {0UL};/* VOLATILE GLOBAL g_889 */
static int32_t g_904[6] = {0xEFD5AE4CL,0xEFD5AE4CL,0xEFD5AE4CL,0xEFD5AE4CL,0xEFD5AE4CL,0xEFD5AE4CL};
static const union U0 g_936[2] = {{18446744073709551615UL},{18446744073709551615UL}};
static const union U0 *g_948 = (void*)0;
static int32_t * volatile g_953 = &g_88;/* VOLATILE GLOBAL g_953 */
static volatile union U0 g_979 = {0x5B0306E5L};/* VOLATILE GLOBAL g_979 */
static union U1 g_1027 = {0x834B2A07B282CD30LL};/* VOLATILE GLOBAL g_1027 */
static union U1 ** const *g_1046 = (void*)0;
static int32_t * volatile g_1055[8][10][3] = {{{&g_13,&g_18[1][0],&g_88},{&g_4[0],&g_18[6][0],&g_4[2]},{&g_88,(void*)0,&g_18[3][0]},{&g_13,&g_18[6][0],&g_13},{&g_4[2],&g_18[1][0],&g_18[0][1]},{(void*)0,&g_13,&g_18[1][0]},{&g_27,(void*)0,&g_27},{&g_13,&g_88,&g_27},{&g_18[0][1],(void*)0,&g_24},{&g_18[1][0],(void*)0,&g_7}},{{(void*)0,&g_4[2],&g_25},{(void*)0,(void*)0,&g_18[0][1]},{&g_18[1][0],(void*)0,&g_4[2]},{&g_18[0][1],&g_25,&g_24},{&g_13,&g_25,(void*)0},{&g_27,&g_27,&g_13},{(void*)0,(void*)0,&g_4[0]},{&g_4[2],&g_4[0],&g_13},{&g_13,(void*)0,&g_18[0][1]},{&g_88,&g_4[2],&g_13}},{{&g_4[0],&g_18[1][0],&g_4[0]},{&g_13,&g_4[2],&g_13},{(void*)0,&g_18[0][1],(void*)0},{(void*)0,(void*)0,&g_24},{&g_13,&g_4[0],&g_4[2]},{(void*)0,(void*)0,&g_18[0][1]},{&g_25,&g_13,&g_25},{&g_4[0],&g_13,&g_7},{&g_13,(void*)0,&g_24},{&g_18[6][0],&g_4[0],&g_27}},{{(void*)0,(void*)0,&g_27},{&g_18[1][0],&g_18[0][1],&g_18[1][0]},{&g_25,&g_4[2],&g_18[0][1]},{&g_4[2],&g_18[1][0],&g_13},{&g_4[2],&g_4[2],&g_18[3][0]},{&g_13,(void*)0,&g_4[2]},{&g_4[2],&g_4[0],&g_88},{&g_4[2],(void*)0,&g_13},{&g_25,&g_27,(void*)0},{&g_18[1][0],&g_25,&g_18[0][1]}},{{(void*)0,&g_25,(void*)0},{&g_18[6][0],(void*)0,&g_4[2]},{&g_13,(void*)0,&g_4[1]},{&g_4[0],&g_4[2],&g_4[1]},{&g_25,(void*)0,&g_4[2]},{(void*)0,(void*)0,(void*)0},{&g_13,&g_88,&g_18[0][1]},{(void*)0,(void*)0,(void*)0},{(void*)0,&g_13,&g_13},{&g_13,&g_18[1][0],&g_88}},{{&g_4[0],&g_18[6][0],&g_4[2]},{&g_88,(void*)0,&g_18[3][0]},{&g_13,&g_18[6][0],&g_13},{&g_4[2],&g_18[1][0],&g_18[0][1]},{(void*)0,&g_13,&g_18[1][0]},{&g_27,&g_18[1][0],&g_13},{&g_13,&g_13,&g_4[0]},{&g_25,&g_18[1][0],&g_27},{(void*)0,&g_4[0],&g_4[2]},{&g_13,(void*)0,&g_25}},{{&g_13,&g_4[2],&g_25},{(void*)0,&g_13,&g_4[2]},{&g_25,&g_25,&g_4[1]},{&g_13,&g_13,(void*)0},{(void*)0,(void*)0,&g_4[0]},{&g_4[2],&g_4[0],(void*)0},{&g_4[2],(void*)0,&g_25},{&g_25,&g_25,&g_25},{&g_13,&g_4[2],&g_25},{&g_88,(void*)0,(void*)0}},{{&g_13,&g_18[1][0],&g_4[0]},{&g_18[1][0],&g_25,(void*)0},{&g_25,&g_4[0],&g_4[1]},{(void*)0,&g_88,&g_4[2]},{&g_18[1][0],(void*)0,&g_25},{&g_13,(void*)0,&g_25},{(void*)0,(void*)0,&g_4[2]},{&g_13,(void*)0,&g_27},{&g_24,&g_88,&g_4[0]},{(void*)0,&g_4[0],&g_13}}};
static int32_t * volatile g_1056 = &g_88;/* VOLATILE GLOBAL g_1056 */
static union U0 g_1059 = {0xFFFC76C7L};/* VOLATILE GLOBAL g_1059 */
static volatile union U0 *g_1084 = (void*)0;
static volatile union U0 * volatile *g_1083 = &g_1084;
static volatile union U0 * volatile * const * volatile g_1082 = &g_1083;/* VOLATILE GLOBAL g_1082 */
static union U0 g_1169 = {1UL};/* VOLATILE GLOBAL g_1169 */
static int16_t g_1187 = 0x2094L;
static union U0 **g_1193 = (void*)0;
static union U0 ***g_1192 = &g_1193;
static volatile union U1 g_1359 = {0xC19F654EFE6981BDLL};/* VOLATILE GLOBAL g_1359 */
static union U1 **g_1430 = (void*)0;
static union U1 ***g_1429[10] = {&g_1430,&g_1430,&g_1430,&g_1430,&g_1430,&g_1430,&g_1430,&g_1430,&g_1430,&g_1430};
static uint32_t g_1438 = 0xEFA56EC1L;
static volatile uint16_t * volatile g_1453 = (void*)0;/* VOLATILE GLOBAL g_1453 */
static volatile uint16_t * volatile *g_1452 = &g_1453;
static volatile uint16_t * volatile **g_1451[8] = {&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452,&g_1452};
static volatile uint16_t * volatile *** const g_1450 = &g_1451[3];
static volatile uint16_t * volatile *** const * const  volatile g_1449[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint8_t g_1491 = 0x81L;
static const volatile int64_t **g_1494[3][10][6] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_685,(void*)0,(void*)0,&g_685,(void*)0,&g_685},{&g_685,(void*)0,&g_685,(void*)0,(void*)0,&g_685},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_685,(void*)0,(void*)0,&g_685,(void*)0,&g_685},{&g_685,(void*)0,&g_685,(void*)0,(void*)0,&g_685},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_685,(void*)0,(void*)0,&g_685,(void*)0,&g_685},{&g_685,(void*)0,&g_685,(void*)0,(void*)0,&g_685},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_685},{(void*)0,&g_685,(void*)0,&g_685,(void*)0,(void*)0},{(void*)0,&g_685,&g_685,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_685,&g_685,(void*)0},{(void*)0,(void*)0,&g_685,(void*)0,&g_685,(void*)0}},{{&g_685,(void*)0,(void*)0,(void*)0,(void*)0,&g_685},{(void*)0,&g_685,(void*)0,&g_685,(void*)0,(void*)0},{(void*)0,&g_685,&g_685,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_685,&g_685,(void*)0},{(void*)0,(void*)0,&g_685,(void*)0,&g_685,(void*)0},{&g_685,(void*)0,(void*)0,(void*)0,(void*)0,&g_685},{(void*)0,&g_685,(void*)0,&g_685,(void*)0,(void*)0},{(void*)0,&g_685,&g_685,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_685,&g_685,(void*)0},{(void*)0,(void*)0,&g_685,(void*)0,&g_685,(void*)0}}};
static const volatile int64_t *** volatile g_1493[6] = {&g_1494[0][7][0],&g_1494[0][0][4],&g_1494[0][0][4],&g_1494[0][7][0],&g_1494[0][0][4],&g_1494[0][0][4]};
static const volatile int64_t *** volatile g_1495 = (void*)0;/* VOLATILE GLOBAL g_1495 */
static uint32_t *g_1513 = &g_106;
static uint32_t **g_1512 = &g_1513;
static uint16_t g_1519 = 65532UL;
static uint64_t * volatile g_1539 = &g_188.f0;/* VOLATILE GLOBAL g_1539 */
static uint64_t * volatile *g_1538 = &g_1539;
static uint64_t * volatile **g_1537 = &g_1538;
static volatile union U1 g_1590 = {0x32D09995EA5AEFA3LL};/* VOLATILE GLOBAL g_1590 */
static union U1 g_1593 = {0x67DEA573643A6E60LL};/* VOLATILE GLOBAL g_1593 */
static int32_t **g_1640 = &g_226;
static volatile int16_t g_1663 = 0x3B8EL;/* VOLATILE GLOBAL g_1663 */
static volatile uint16_t g_1709[2] = {0xD27DL,0xD27DL};
static union U0 g_1717 = {0UL};/* VOLATILE GLOBAL g_1717 */
static volatile int32_t g_1757[2][2][7] = {{{(-1L),(-1L),(-6L),(-1L),(-1L),(-6L),(-1L)},{0xF286B4FDL,(-4L),0xB707173DL,0x30E1AE3CL,0xB707173DL,(-4L),0xF286B4FDL}},{{8L,(-1L),8L,8L,(-1L),8L,8L},{0xF286B4FDL,0x30E1AE3CL,0L,0x30E1AE3CL,0xF286B4FDL,(-7L),0xF286B4FDL}}};
static volatile uint32_t g_1809 = 1UL;/* VOLATILE GLOBAL g_1809 */
static uint64_t g_1846 = 0x3831182037980FF0LL;
static volatile union U0 g_1847 = {0x5B21241DL};/* VOLATILE GLOBAL g_1847 */
static int32_t *g_1861 = &g_88;
static int32_t ** const  volatile g_1860[3] = {&g_1861,&g_1861,&g_1861};
static union U2 ** const  volatile g_1921 = &g_267;/* VOLATILE GLOBAL g_1921 */
static uint32_t * const  volatile ** volatile g_1948 = (void*)0;/* VOLATILE GLOBAL g_1948 */


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static int8_t  func_19(int32_t * p_20);
static int32_t * func_28(const int32_t * p_29, int32_t * p_30, int32_t * p_31, int32_t * p_32);
static int32_t * func_33(int32_t * p_34, union U2  p_35, uint64_t  p_36, uint32_t  p_37, uint8_t  p_38);
static int32_t * func_39(int32_t * p_40, int32_t  p_41, int8_t  p_42, int32_t * p_43);
static int32_t * func_44(union U2  p_45, int32_t * p_46, int32_t * const  p_47, int32_t * p_48, int32_t * const  p_49);
static union U2  func_50(int32_t * p_51, uint32_t  p_52, int64_t  p_53);
static int32_t * func_54(int32_t  p_55, int32_t * p_56);
static int32_t * func_57(uint32_t  p_58, int32_t * p_59, uint32_t  p_60, int8_t  p_61);
static union U2  func_62(union U2  p_63, uint32_t  p_64, uint16_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_7 g_12 g_13 g_18 g_1861 g_88 g_1948 g_259 g_83 g_84 g_400
 * writes: g_4 g_7 g_13 g_18 g_1640 g_88 g_401
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_21 = &g_13;
    int32_t l_1924 = 6L;
    int8_t l_1942 = 0x2AL;
    uint32_t ***l_1949 = &g_1512;
    int32_t l_1959[3];
    int64_t l_1961 = (-4L);
    int i;
    for (i = 0; i < 3; i++)
        l_1959[i] = 0x2728222AL;
    for (g_4[2] = 0; (g_4[2] > 14); g_4[2] = safe_add_func_uint16_t_u_u(g_4[2], 5))
    { /* block id: 3 */
        uint32_t l_14[8] = {18446744073709551611UL,0xB060D2F3L,0xB060D2F3L,18446744073709551611UL,0xB060D2F3L,0xB060D2F3L,18446744073709551611UL,0xB060D2F3L};
        int8_t *l_1945 = &g_1169.f1;
        int32_t l_1950 = 0L;
        int32_t l_1960 = 0x992A7382L;
        int32_t l_1962[3];
        uint8_t l_1963 = 0xE8L;
        int i;
        for (i = 0; i < 3; i++)
            l_1962[i] = 0x77CBA34EL;
        for (g_7 = 21; (g_7 <= (-25)); g_7 = safe_sub_func_int32_t_s_s(g_7, 7))
        { /* block id: 6 */
            int8_t l_11 = 0xC0L;
            int8_t ** const l_1940 = &g_365;
            uint16_t l_1943[8][6] = {{0UL,0UL,65534UL,0x0110L,0x1185L,0x0B80L},{65535UL,0xC296L,0x1185L,65528UL,0xACF1L,65534UL},{7UL,65535UL,0x1185L,0xDBEFL,0UL,0x0B80L},{0xBFCDL,0xDBEFL,65534UL,0xDCF4L,65534UL,0xDBEFL},{0xDCF4L,65534UL,0xDBEFL,0xBFCDL,0x5A9AL,0xA37DL},{0xDBEFL,0x1185L,65535UL,7UL,65528UL,65535UL},{65528UL,0x1185L,0xC296L,65535UL,0x5A9AL,65532UL},{0x0110L,65534UL,0UL,0UL,65534UL,0x0110L}};
            int32_t *l_1951 = (void*)0;
            int32_t *l_1952 = &g_18[1][0];
            int32_t *l_1953 = &g_27;
            int32_t l_1954 = 0x8C1C11A4L;
            int32_t *l_1955 = &g_18[4][1];
            int32_t *l_1956 = &g_24;
            int32_t *l_1957 = &g_88;
            int32_t *l_1958[9][4][1] = {{{&g_18[1][0]},{(void*)0},{(void*)0},{(void*)0}},{{(void*)0},{&g_18[1][0]},{(void*)0},{(void*)0}},{{&g_18[1][0]},{&g_18[1][0]},{(void*)0},{&g_18[1][0]}},{{&g_18[1][0]},{&g_18[1][0]},{&g_18[1][0]},{(void*)0}},{{&g_18[1][0]},{&g_18[1][0]},{&g_18[1][0]},{&g_18[1][0]}},{{(void*)0},{&g_18[1][0]},{&g_18[1][0]},{&g_18[1][0]}},{{&g_18[1][0]},{(void*)0},{&g_18[1][0]},{&g_18[1][0]}},{{&g_18[1][0]},{&g_18[1][0]},{(void*)0},{&g_18[1][0]}},{{&g_18[1][0]},{&g_18[1][0]},{&g_18[1][0]},{(void*)0}}};
            int i, j, k;
            (*g_12) ^= (!l_11);
            for (l_11 = 7; (l_11 >= 0); l_11 -= 1)
            { /* block id: 10 */
                uint16_t l_1937 = 0x7860L;
                int32_t l_1944 = 4L;
                for (g_13 = 7; (g_13 >= 1); g_13 -= 1)
                { /* block id: 13 */
                    uint8_t l_1925 = 0x86L;
                    int32_t ***l_1946 = (void*)0;
                    int32_t ***l_1947 = &g_1640;
                    int i;
                    for (g_18[1][0] = 7; (g_18[1][0] >= 0); g_18[1][0] -= 1)
                    { /* block id: 16 */
                        int32_t *l_1922 = (void*)0;
                        int32_t *l_1923[2][6][2];
                        int8_t **l_1934[9][2][3] = {{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}},{{&g_365,&g_365,&g_365},{&g_365,&g_365,&g_365}}};
                        int32_t l_1941 = 0x4754C574L;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 6; j++)
                            {
                                for (k = 0; k < 2; k++)
                                    l_1923[i][j][k] = (void*)0;
                            }
                        }
                    }
                    (*g_1861) ^= (l_14[l_11] , (&l_21 != ((*l_1947) = &g_226)));
                }
                l_1950 = (g_1948 != l_1949);
            }
            l_1963--;
        }
        return g_259;
    }
    (*g_400) = (*g_83);
    return (*l_21);
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_25 g_685 g_686 g_1512 g_1513 g_106 g_27 g_191 g_1809 g_1082 g_1083 g_261 g_333 g_936.f1 g_1640 g_226 g_104 g_868 g_365 g_117.f1 g_287 g_288 g_13 g_1846 g_1717.f2 g_387 g_76 g_1847 g_267 g_85 g_83 g_284 g_88 g_486.f0 g_1861 g_390 g_1538 g_1539 g_188.f0 g_221 g_904 g_979 g_1921
 * writes: g_24 g_25 g_27 g_486.f0 g_261 g_1809 g_88 g_226 g_1491 g_1169.f1 g_106 g_2 g_16 g_81 g_84 g_259 g_1169.f0 g_76 g_117.f1 g_191 g_221 g_85.f0 g_753 g_267
 */
static int8_t  func_19(int32_t * p_20)
{ /* block id: 17 */
    uint64_t l_22[10][5] = {{18446744073709551615UL,18446744073709551615UL,1UL,0x4108FA7AD11E7587LL,0xF0A644184EB300A9LL},{1UL,0UL,0UL,0UL,0UL},{0xF0A644184EB300A9LL,0x69CD17CD9532955FLL,2UL,0xF0A644184EB300A9LL,0xB83DE37D660F181ELL},{0UL,0UL,0x12C005D9C7279C90LL,0UL,0UL},{2UL,18446744073709551615UL,0x69CD17CD9532955FLL,0xB83DE37D660F181ELL,18446744073709551615UL},{0UL,0x9F2B7826243A5D8DLL,0x9F2B7826243A5D8DLL,0UL,0UL},{0xF0A644184EB300A9LL,0x4108FA7AD11E7587LL,1UL,18446744073709551615UL,18446744073709551615UL},{1UL,0UL,1UL,0UL,0UL},{18446744073709551615UL,0x69CD17CD9532955FLL,0xB83DE37D660F181ELL,18446744073709551615UL,0xB83DE37D660F181ELL},{18446744073709551608UL,18446744073709551608UL,0x12C005D9C7279C90LL,0UL,0UL}};
    union U2 l_67 = {0x7725EFF8L};
    int32_t *l_950[3];
    uint32_t l_1765 = 0x19BB313AL;
    const union U0 *** const * const l_1843 = (void*)0;
    uint16_t *l_1854 = &g_76;
    int64_t l_1863 = 0x663AC627FFEC17DDLL;
    int64_t l_1864 = 0xCF41153AD099A895LL;
    uint32_t l_1865 = 0xBA4DA158L;
    int i, j;
    for (i = 0; i < 3; i++)
        l_950[i] = &g_4[2];
lbl_1868:
    for (g_24 = 1; (g_24 <= 4); g_24 += 1)
    { /* block id: 20 */
        uint8_t l_86 = 3UL;
        int32_t * const l_951[7][8] = {{&g_7,&g_7,&g_7,&g_24,&g_7,&g_24,&g_7,&g_7},{&g_7,&g_24,&g_7,&g_7,&g_7,&g_24,&g_7,&g_24},{&g_7,&g_7,&g_25,&g_7,&g_7,&g_4[1],&g_7,&g_7},{&g_7,&g_7,&g_7,&g_24,&g_7,&g_24,&g_7,&g_7},{&g_7,&g_24,&g_7,&g_7,&g_7,&g_24,&g_7,&g_24},{&g_7,&g_7,&g_25,&g_7,&g_7,&g_4[1],&g_7,&g_7},{&g_7,&g_7,&g_7,&g_24,&g_7,&g_24,&g_7,&g_7}};
        int32_t *l_987 = &g_24;
        uint32_t l_1768 = 0x62EC3053L;
        int16_t l_1796 = 0L;
        const union U0 **l_1818[9] = {&g_948,&g_948,&g_948,&g_948,&g_948,&g_948,&g_948,&g_948,&g_948};
        int8_t ***l_1827 = &g_868;
        uint16_t l_1858 = 5UL;
        int i, j;
        for (g_25 = 3; (g_25 >= 0); g_25 -= 1)
        { /* block id: 23 */
            uint64_t l_955[3];
            int32_t l_1776 = (-1L);
            uint32_t l_1800[10][2] = {{4294967288UL,4294967294UL},{4294967288UL,4294967288UL},{4294967294UL,4294967288UL},{4294967288UL,4294967294UL},{4294967288UL,4294967288UL},{4294967294UL,4294967288UL},{4294967288UL,4294967294UL},{4294967288UL,4294967288UL},{4294967294UL,4294967288UL},{4294967288UL,4294967294UL}};
            int32_t l_1802 = 0xCAEF7091L;
            int32_t l_1803 = 1L;
            int32_t l_1804 = 0xAFB1F830L;
            int32_t l_1805 = 0x89DBAFD3L;
            int32_t l_1806[4][2] = {{0x287BCB9AL,0x287BCB9AL},{0xDB886C68L,0x287BCB9AL},{0x287BCB9AL,0xDB886C68L},{0x287BCB9AL,0x287BCB9AL}};
            int i, j;
            for (i = 0; i < 3; i++)
                l_955[i] = 0x1EC0EF9560D42D25LL;
            for (g_27 = 1; (g_27 <= 4); g_27 += 1)
            { /* block id: 26 */
                uint16_t *l_75 = &g_76;
                int32_t **l_786 = &g_226;
                union U2 l_961 = {18446744073709551613UL};
                int32_t l_1748[3];
                uint8_t l_1777 = 0x31L;
                int i, j;
                for (i = 0; i < 3; i++)
                    l_1748[i] = 0x5F177DB5L;
            }
            if ((safe_mul_func_int8_t_s_s((l_22[(g_24 + 3)][(g_25 + 1)] & (*g_685)), (safe_rshift_func_int16_t_s_u(l_955[1], (safe_sub_func_int32_t_s_s(((safe_sub_func_int64_t_s_s((((safe_mul_func_int16_t_s_s((safe_sub_func_int32_t_s_s((0x06AF7804L ^ ((((((safe_mod_func_uint16_t_u_u(0xE85AL, (-10L))) , (safe_div_func_uint32_t_u_u((**g_1512), (**g_1512)))) & ((l_22[(g_24 + 3)][(g_25 + 1)] , l_955[0]) || 0L)) != (**g_1512)) , g_27) ^ g_191[0])), l_955[1])), (*l_987))) == l_1796) ^ 0xB083L), (-10L))) || (*g_1513)), 1L)))))))
            { /* block id: 853 */
                uint32_t l_1797[4][5] = {{0xCB1A120EL,4294967294UL,0xCB1A120EL,2UL,1UL},{4294967295UL,0x2E1B666EL,1UL,0x2E1B666EL,4294967295UL},{0xCB1A120EL,0x2E1B666EL,4294967294UL,4294967295UL,4294967294UL},{4294967294UL,4294967294UL,1UL,4294967295UL,0x005C0E6EL}};
                int32_t l_1808 = 1L;
                const union U0 ***l_1819 = &l_1818[4];
                const uint16_t l_1824 = 0x232DL;
                int i, j;
                for (g_486.f0 = 0; (g_486.f0 <= 1); g_486.f0 += 1)
                { /* block id: 856 */
                    int i;
                    l_1797[0][0]++;
                }
                for (g_261 = 2; (g_261 >= 0); g_261 -= 1)
                { /* block id: 861 */
                    int32_t l_1801[3][7] = {{0x4D7C710EL,0x75B7ECF7L,0x75B7ECF7L,0x4D7C710EL,0x75B7ECF7L,0x75B7ECF7L,0x4D7C710EL},{0x39DEE9B6L,0x7D55C9F4L,0x39DEE9B6L,0x39DEE9B6L,0x7D55C9F4L,0x39DEE9B6L,0x39DEE9B6L},{0x4D7C710EL,0x4D7C710EL,0x46382556L,0x4D7C710EL,0x4D7C710EL,0x46382556L,0x4D7C710EL}};
                    int8_t l_1807[6][5] = {{0L,0x34L,0L,0x34L,0L},{(-3L),0x1DL,0x1DL,(-3L),(-3L)},{2L,0x34L,2L,0x34L,2L},{(-3L),(-3L),0x1DL,0x1DL,(-3L)},{0L,0x34L,0L,0x34L,0L},{(-3L),0x1DL,0x1DL,(-3L),(-3L)}};
                    int i, j, k;
                    l_1801[2][3] &= l_1800[7][0];
                    g_1809++;
                }
                (*g_1640) = func_54(((safe_add_func_uint8_t_u_u((safe_sub_func_int64_t_s_s(((void*)0 == &g_1083), ((((((*g_1082) == ((*l_1819) = l_1818[4])) | 3UL) < (safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u(g_261, l_1824)), 1L))) < (((safe_sub_func_int8_t_s_s(((void*)0 != l_1827), l_22[(g_24 + 3)][(g_25 + 1)])) >= 0x67L) == g_333)) <= g_936[0].f1))), 0x26L)) != l_1800[7][0]), (*g_1640));
            }
            else
            { /* block id: 867 */
                (*g_1640) = l_987;
                l_1803 |= ((void*)0 != (**l_1827));
            }
        }
        for (g_1491 = 0; (g_1491 <= 4); g_1491 += 1)
        { /* block id: 874 */
            return (*g_365);
        }
        for (g_1169.f1 = 4; (g_1169.f1 >= 0); g_1169.f1 -= 1)
        { /* block id: 879 */
            uint64_t l_1836 = 0UL;
            uint16_t *l_1853 = &g_191[0];
            int32_t l_1859 = 0x301F2339L;
            int32_t **l_1862 = &l_950[0];
            g_25 |= (safe_mod_func_uint32_t_u_u((safe_sub_func_int16_t_s_s(((0L != ((safe_lshift_func_int8_t_s_u(0xFCL, (((((safe_sub_func_uint8_t_u_u(l_1836, (safe_mod_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u(((safe_sub_func_uint8_t_u_u(l_1836, ((void*)0 == l_1843))) , (g_686[0][5][1] , (*g_287))), ((**g_1512) |= (safe_add_func_uint32_t_u_u(((l_1836 | (*p_20)) <= (*l_987)), g_1846))))) ^ l_1836), (*l_987))))) ^ g_191[0]) , (**g_868)) || g_1717.f2) & (*g_387)))) > l_1836)) && (*p_20)), g_261)), 0x1BAB8C10L));
            (*l_1862) = (g_1847 , ((*g_1640) = func_39(func_54((safe_add_func_int8_t_s_s((safe_unary_minus_func_uint32_t_u((safe_mul_func_int8_t_s_s((**g_868), ((func_62((*g_267), l_1836, (l_1853 != l_1854)) , (safe_unary_minus_func_uint32_t_u((safe_mul_func_int64_t_s_s((l_1859 = l_1858), ((l_1836 >= l_1836) != (-1L))))))) >= (**g_868)))))), l_1836)), (*g_1640)), (*l_987), (**g_868), (*g_1640))));
            if (g_1491)
                goto lbl_1869;
        }
    }
    l_1865--;
lbl_1869:
    if (g_24)
        goto lbl_1868;
    for (g_486.f0 = 19; (g_486.f0 >= 1); --g_486.f0)
    { /* block id: 892 */
        const uint64_t l_1872 = 0x64ADA69643EA1CECLL;
        int32_t l_1877[9][10][1] = {{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)}},{{0x1E1FD489L},{0xF71F1E60L},{0x1E1FD489L},{(-10L)},{(-10L)},{0xF71F1E60L},{(-10L)},{0xF71F1E60L},{0L},{0L}}};
        uint64_t l_1881[10][5] = {{0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL},{18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL,18446744073709551612UL},{0x8DF45AC10E19FD48LL,0xDACD93FBCF8E38DELL,0x8DF45AC10E19FD48LL,0xDACD93FBCF8E38DELL,0x8DF45AC10E19FD48LL},{18446744073709551612UL,18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL},{0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL},{18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL,18446744073709551612UL},{0x8DF45AC10E19FD48LL,0xDACD93FBCF8E38DELL,0x8DF45AC10E19FD48LL,0xDACD93FBCF8E38DELL,0x8DF45AC10E19FD48LL},{18446744073709551612UL,18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL},{0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL,0xDACD93FBCF8E38DELL,0x25A5C75F1725F4BCLL},{18446744073709551612UL,18446744073709551614UL,18446744073709551614UL,18446744073709551612UL,18446744073709551612UL}};
        int16_t *l_1916 = &g_261;
        uint32_t l_1919 = 1UL;
        int i, j, k;
        (*g_1861) ^= l_1872;
        for (l_67.f2 = 0; (l_67.f2 == 29); l_67.f2 = safe_add_func_uint32_t_u_u(l_67.f2, 6))
        { /* block id: 896 */
            int16_t l_1875 = 0xD489L;
            int32_t l_1876 = 1L;
            int32_t l_1878 = 0xE5DB2F7AL;
            int32_t l_1879 = 0x68C9BBF1L;
            int32_t l_1880 = (-2L);
            int8_t l_1917[4];
            union U2 l_1920 = {0xB664670CL};
            int i;
            for (i = 0; i < 4; i++)
                l_1917[i] = 0x26L;
            l_1881[3][0]++;
            for (l_1876 = 19; (l_1876 <= 5); l_1876--)
            { /* block id: 900 */
                uint16_t *l_1894 = &g_191[1];
                int32_t ***l_1901 = (void*)0;
                uint8_t *l_1902 = &g_221;
                int32_t l_1915 = 0x22658B75L;
                uint32_t *l_1918 = &l_1865;
                for (g_259 = 2; (g_259 >= 0); g_259 -= 1)
                { /* block id: 903 */
                    for (g_1169.f0 = 0; (g_1169.f0 <= 2); g_1169.f0 += 1)
                    { /* block id: 906 */
                        int i, j, k;
                        (*g_390) ^= 8L;
                        return (*g_365);
                    }
                }
                (*g_1640) = func_33(func_39(p_20, ((((*g_365) ^= (((*g_387)--) , 0x81L)) >= (safe_unary_minus_func_int32_t_s(((g_85[1][2][4].f0 = ((*l_1918) = ((l_1879 && (safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s((!0x13L), (++(*l_1894)))), ((safe_sub_func_uint64_t_u_u((**g_1538), (safe_lshift_func_uint8_t_u_u(((*l_1902) &= ((void*)0 == l_1901)), ((((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u((safe_sub_func_int64_t_s_s(((safe_mod_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s((18446744073709551615UL >= (((((safe_mod_func_int8_t_s_s((((*g_267) , l_1915) , l_1881[3][0]), (-7L))) > (*g_1513)) , l_1894) != l_1916) || l_1872)), 2)), l_1877[3][8][0])) <= 4294967295UL), l_1877[7][5][0])), l_1878)), l_1917[2])) & (-1L)) > 0xDB43E83AL) < l_1877[0][9][0]))))) > 255UL)))) < l_1876))) , (*g_104))))) || l_1877[7][5][0]), l_1919, (*g_1640)), l_1920, l_1917[2], l_1880, l_1872);
                (*g_1921) = &l_67;
            }
        }
        (*g_1640) = p_20;
        return l_1877[7][5][0];
    }
    return (*g_365);
}


/* ------------------------------------------ */
/* 
 * reads : g_868 g_365 g_117.f1 g_387 g_76 g_104 g_88 g_904 g_979 g_7 g_106 g_226 g_936.f2 g_257.f0 g_333 g_24 g_1027 g_561.f0 g_85.f1 g_85.f2 g_287 g_288 g_1429 g_486.f0 g_84 g_66 g_1438 g_953 g_286 g_1449 g_282 g_259 g_191 g_221 g_1491 g_389 g_1512 g_414 g_415 g_1519 g_390 g_188.f1 g_18 g_889.f0 g_12 g_13 g_23 g_1640 g_1192 g_1193 g_1593.f1 g_1663 g_296 g_1513 g_1169.f2 g_1709 g_1593.f0 g_753 g_1717 g_2 g_1717.f0 g_1537 g_1538 g_1539 g_188.f0 g_261 g_1059.f0 g_1169.f0
 * writes: g_753 g_76 g_106 g_261 g_88 g_226 g_1429 g_1059.f0 g_1491 g_1187 g_389 g_1519 g_1169.f0 g_1640 g_221 g_1709 g_1593.f0 g_192 g_191 g_365 g_333
 */
static int32_t * func_28(const int32_t * p_29, int32_t * p_30, int32_t * p_31, int32_t * p_32)
{ /* block id: 454 */
    union U2 l_988[8][3] = {{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}},{{0xD3999C0DL},{0xD3999C0DL},{18446744073709551615UL}}};
    uint32_t *l_989[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_990 = 0xDA31B516L;
    const uint32_t l_993 = 0x5CE71FE3L;
    union U0 *l_998 = &g_117;
    union U0 **l_997 = &l_998;
    union U0 ***l_996 = &l_997;
    uint32_t l_999 = 0x308A5AECL;
    int64_t *l_1000[1][10] = {{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753}};
    int16_t * const l_1001 = &g_261;
    int32_t **l_1002 = &g_226;
    int32_t *l_1017 = &l_990;
    uint32_t l_1087 = 4UL;
    int32_t l_1091 = 0xDE30F4B4L;
    int32_t *l_1310 = &g_904[5];
    int32_t ** const l_1309 = &l_1310;
    uint16_t * const *l_1314 = &g_387;
    uint16_t * const **l_1313 = &l_1314;
    uint16_t * const ***l_1312 = &l_1313;
    int32_t l_1352 = 0x1E7E07AFL;
    int32_t l_1414 = 0x83A8CD8DL;
    uint32_t **l_1515[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    union U1 *l_1587 = &g_486;
    uint8_t l_1638 = 0x0EL;
    uint32_t l_1639[7];
    int32_t l_1664 = (-1L);
    int i, j;
    for (i = 0; i < 7; i++)
        l_1639[i] = 0xC8FFA7DEL;
lbl_1315:
    (*l_1002) = func_33(p_30, l_988[1][1], l_988[1][1].f1, (l_990 = 0xA30522CBL), (((-1L) && (((*g_387) ^= (((((((safe_add_func_uint64_t_u_u(l_993, (g_753 = ((safe_rshift_func_int8_t_s_u((-4L), (&g_948 != ((*l_996) = (void*)0)))) >= l_999)))) , 1UL) , l_988[1][1].f0) & l_999) , (**g_868)) , l_1001) == (void*)0)) , l_988[1][1].f1)) <= (*g_104)));
    (*l_1017) ^= ((((safe_rshift_func_uint16_t_u_s(((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((l_1000[0][0] != &g_282), 9)), (**l_1002))) & (((((1L < ((safe_sub_func_int16_t_s_s((**l_1002), ((*g_387) = (safe_add_func_uint8_t_u_u(((~((+(0xACL || 0x78L)) , (safe_add_func_uint64_t_u_u((0L || 0xBFEBEA33L), 0xC3419791FFD49CA0LL)))) == g_936[0].f2), (**l_1002)))))) <= 0x306FL)) , 8UL) & 0xA67DL) <= (**l_1002)) , (**l_1002))), g_904[5])) & g_257.f0) | g_333) < (*p_32));
    if ((safe_mul_func_int8_t_s_s((((**g_868) || (safe_add_func_uint32_t_u_u(4294967295UL, ((((safe_div_func_int8_t_s_s(((*l_1017) | (*l_1017)), ((((safe_unary_minus_func_uint8_t_u(((*l_1017) && (((safe_mul_func_uint16_t_u_u(9UL, (*l_1017))) , g_1027) , 0L)))) == (**l_1002)) != g_561[8][2].f0) , (**l_1002)))) , 0x1AB7L) , 0x84E4A226L) >= g_85[1][2][4].f1)))) ^ g_85[1][2][4].f2), (*l_1017))))
    { /* block id: 462 */
        const int32_t l_1028 = (-7L);
        const union U2 *l_1032 = (void*)0;
        const union U2 **l_1031 = &l_1032;
        union U0 *l_1058[9][7] = {{&g_117,&g_1059,&g_117,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,&g_117,&g_117,&g_117,(void*)0,(void*)0},{&g_117,&g_117,&g_1059,&g_117,&g_117,&g_117,&g_117},{(void*)0,&g_117,(void*)0,&g_117,(void*)0,&g_117,(void*)0},{(void*)0,&g_117,&g_117,&g_117,&g_1059,(void*)0,&g_117},{&g_1059,&g_117,&g_117,(void*)0,(void*)0,&g_117,&g_117},{&g_117,&g_1059,&g_117,&g_117,&g_1059,&g_117,&g_117},{&g_117,(void*)0,(void*)0,&g_117,&g_117,&g_117,(void*)0},{&g_1059,&g_1059,&g_1059,&g_117,&g_117,&g_117,&g_1059}};
        int32_t l_1086 = (-9L);
        int32_t l_1106[7];
        union U1 **l_1164 = &g_84;
        int32_t *l_1232 = (void*)0;
        int8_t l_1239 = 6L;
        uint16_t ***l_1270 = &g_415[1];
        uint16_t ****l_1269 = &l_1270;
        uint16_t *****l_1268[10] = {&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269,&l_1269};
        union U2 l_1302 = {0x457F7735L};
        uint8_t *l_1311[7] = {&g_221,&g_221,&g_221,&g_221,&g_221,&g_221,&g_221};
        int32_t l_1413 = (-1L);
        int i, j;
        for (i = 0; i < 7; i++)
            l_1106[i] = 0xA2377890L;
        (*l_1017) = ((0xF22CA999B66E933ALL ^ 0L) > l_1028);
    }
    else
    { /* block id: 636 */
        uint64_t *l_1425 = &g_257.f0;
        union U1 * const *l_1428 = &g_84;
        union U1 * const **l_1427 = &l_1428;
        union U1 ****l_1431 = &g_1429[5];
        int32_t l_1432 = (-1L);
        int32_t l_1433[1];
        int32_t *l_1434 = &l_1433[0];
        int i;
        for (i = 0; i < 1; i++)
            l_1433[i] = 0x303A667AL;
        (*l_996) = (*l_996);
        (*l_1434) = ((safe_rshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s((safe_div_func_int8_t_s_s((-7L), (((!(((*l_1017) &= (*g_287)) & (l_1432 = (((*p_30) , l_1425) == (((**l_1002) == (~(((l_1427 == ((*l_1431) = g_1429[7])) < l_1432) != (g_106 = g_561[8][2].f0)))) , &g_284[2][1][7]))))) & l_1433[0]) & (*g_226)))), 18446744073709551609UL)), (**l_1002))) > l_1433[0]);
    }
    if ((**l_1002))
    { /* block id: 644 */
        union U0 **** const l_1435 = &g_1192;
        union U0 ****l_1436 = &g_1192;
        int32_t l_1439 = 0x188E8DC0L;
        int32_t *l_1441[8][2][10] = {{{(void*)0,&g_18[1][0],&g_18[1][0],&l_990,&g_7,&g_88,&g_7,&g_4[2],&g_18[0][0],(void*)0},{(void*)0,&g_25,(void*)0,&g_25,&l_1091,(void*)0,&l_1414,&g_4[2],(void*)0,&l_1414}},{{&g_18[1][0],(void*)0,&l_1439,&g_18[1][0],&g_25,(void*)0,&l_1091,&g_13,&l_1091,(void*)0},{(void*)0,(void*)0,(void*)0,&g_13,(void*)0,&g_27,(void*)0,&g_24,(void*)0,&g_7}},{{&g_24,(void*)0,&g_88,&l_1414,&l_1439,&l_1439,&l_1414,&g_88,(void*)0,&g_24},{&g_4[2],&g_4[2],&l_1091,&g_88,&g_13,&g_25,&l_1439,&g_7,(void*)0,&g_88}},{{&g_25,(void*)0,&g_18[1][0],&g_4[2],&g_13,&g_88,&g_24,(void*)0,(void*)0,&g_24},{&g_13,&l_1439,&g_18[7][1],(void*)0,&l_1439,(void*)0,&l_1414,&g_18[1][0],&g_18[1][0],&g_7}},{{&l_1352,&g_7,&g_88,&g_88,(void*)0,&g_88,&g_88,&g_7,&l_1352,(void*)0},{(void*)0,(void*)0,(void*)0,&l_1414,&g_25,&g_18[0][0],&g_13,&g_25,&l_990,&l_1414}},{{&g_13,(void*)0,&g_88,&l_1414,&l_1091,&g_18[7][1],(void*)0,&l_1091,&l_1352,(void*)0},{&g_88,&g_25,&g_18[1][0],&g_88,&g_25,&g_25,&l_1352,&g_13,&g_18[1][0],&g_18[1][0]}},{{&l_1414,&g_13,&g_7,(void*)0,(void*)0,&g_7,&g_13,&l_1414,(void*)0,&l_1414},{&g_24,&g_18[7][1],(void*)0,&g_4[2],&g_88,&l_1352,&g_25,(void*)0,(void*)0,(void*)0}},{{&l_1439,&g_7,(void*)0,&g_88,&l_1414,(void*)0,&g_4[2],&l_1414,(void*)0,&l_1091},{&l_1414,(void*)0,&g_7,&l_1414,&g_25,&g_88,&g_24,&g_13,(void*)0,&g_13}}};
        union U1 **l_1486 = &g_84;
        const volatile int64_t **l_1496 = &g_685;
        union U2 l_1584 = {0UL};
        uint8_t l_1615 = 255UL;
        const union U0 **l_1648 = &g_948;
        int i, j, k;
        if ((((g_486.f0 != (((*g_84) , l_1435) == (l_1436 = &l_996))) < ((~g_1438) == ((*l_1017) , l_1439))) == (**l_1002)))
        { /* block id: 646 */
            union U2 *l_1443 = (void*)0;
            int32_t l_1480 = 0x5DAD904DL;
            union U1 **l_1485 = (void*)0;
            int32_t l_1488[2];
            int32_t l_1489 = (-6L);
            union U0 **l_1492[7][10][3] = {{{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,(void*)0,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,(void*)0,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,(void*)0}},{{&l_998,&l_998,&l_998},{&l_998,(void*)0,&l_998},{&l_998,(void*)0,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{(void*)0,&l_998,&l_998},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998}},{{&l_998,&l_998,&l_998},{&l_998,&l_998,(void*)0},{&l_998,&l_998,&l_998},{(void*)0,&l_998,(void*)0},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998}},{{(void*)0,&l_998,&l_998},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,(void*)0},{&l_998,&l_998,&l_998},{(void*)0,&l_998,(void*)0},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998}},{{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{(void*)0,&l_998,&l_998},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,(void*)0},{&l_998,&l_998,&l_998},{(void*)0,&l_998,(void*)0}},{{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{(void*)0,&l_998,&l_998},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998}},{{&l_998,&l_998,(void*)0},{&l_998,&l_998,&l_998},{(void*)0,&l_998,(void*)0},{(void*)0,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{&l_998,&l_998,&l_998},{(void*)0,&l_998,&l_998}}};
            int64_t **l_1586[4][7] = {{&l_1000[0][7],(void*)0,&l_1000[0][0],&l_1000[0][0],&l_1000[0][0],&l_1000[0][0],&l_1000[0][0]},{&l_1000[0][0],(void*)0,&l_1000[0][7],(void*)0,&l_1000[0][0],&l_1000[0][0],&l_1000[0][0]},{(void*)0,&l_1000[0][4],(void*)0,&l_1000[0][0],(void*)0,&l_1000[0][7],(void*)0},{&l_1000[0][0],&l_1000[0][0],&l_1000[0][0],&l_1000[0][0],&l_1000[0][0],(void*)0,&l_1000[0][7]}};
            union U2 l_1617 = {0UL};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_1488[i] = (-5L);
            for (g_1059.f0 = 0; (g_1059.f0 <= 9); g_1059.f0 += 1)
            { /* block id: 649 */
                union U2 l_1440[3] = {{0xA69D6340L},{0xA69D6340L},{0xA69D6340L}};
                int32_t *l_1442 = &g_88;
                const uint32_t *l_1517[6] = {&g_106,&l_1087,&g_106,&g_106,&l_1087,&g_106};
                const uint32_t **l_1516 = &l_1517[3];
                uint16_t *l_1591[9];
                union U0 *l_1614 = &g_117;
                int i;
                for (i = 0; i < 9; i++)
                    l_1591[i] = &g_76;
                (*l_1002) = func_44(l_1440[0], l_1441[5][0][4], &l_1439, p_31, func_54(((g_561[8][2].f0 & 0x25E95865486F2E03LL) , 1L), l_1442));
                for (g_106 = 0; (g_106 <= 0); g_106 += 1)
                { /* block id: 653 */
                    union U2 **l_1444 = &l_1443;
                    int8_t *l_1487[5][1];
                    int8_t l_1490 = 0xF6L;
                    uint32_t l_1518[4][1] = {{1UL},{1UL},{1UL},{1UL}};
                    int i, j;
                    for (i = 0; i < 5; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_1487[i][j] = &g_1169.f1;
                    }
                    (*l_1444) = l_1443;
                    g_1491 |= ((**g_286) , (((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((g_1449[2] != ((((safe_sub_func_uint32_t_u_u(((*l_1017) && (9L < ((((*l_1442) >= ((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((-1L), ((*l_1001) = (((safe_sub_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((((safe_lshift_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((safe_add_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s((+(l_1488[0] |= (!((safe_mod_func_int64_t_s_s(((((l_1480 |= (*g_365)) , (safe_add_func_uint16_t_u_u(0x2E45L, ((((safe_div_func_uint64_t_u_u((((((l_1485 == l_1486) >= 0xA76CL) > 0x75L) != (*l_1017)) | (*p_32)), 0x9E09F45C12063226LL)) ^ (*l_1017)) , g_282) != l_1480)))) , g_259) && 2L), 1UL)) <= g_191[0])))), (*l_1017))), 9)) > (**l_1002)), (*g_226))), 0x6BL)), l_1489)) <= 18446744073709551615UL) < (*l_1442)), 0x24CD79F5L)), (*l_1442))), (*g_387))) <= (*l_1442)) != (*g_226))))), 0x9DL)) > g_221)) , 0xAAD8L) & (*l_1017)))), 4294967295UL)) == 3L) ^ g_1438) , &g_1450)), 13)), g_486.f0)) , l_1490) < g_257.f0));
                    for (g_1187 = 3; (g_1187 <= 9); g_1187 += 1)
                    { /* block id: 661 */
                        int i, j, k;
                        (*l_996) = l_1492[4][2][2];
                        (*l_1017) ^= (*p_29);
                    }
                    for (g_1491 = 0; (g_1491 <= 0); g_1491 += 1)
                    { /* block id: 667 */
                        uint32_t ***l_1514[3][10] = {{&g_1512,&g_1512,&g_1512,(void*)0,(void*)0,&g_1512,&g_1512,&g_1512,&g_1512,&g_1512},{(void*)0,&g_1512,(void*)0,&g_1512,(void*)0,&g_1512,&g_1512,(void*)0,&g_1512,(void*)0},{&g_1512,&g_1512,(void*)0,(void*)0,&g_1512,(void*)0,(void*)0,&g_1512,&g_1512,(void*)0}};
                        int i, j, k;
                        l_1496 = &g_685;
                        g_389[g_1491][g_1491][(g_106 + 2)] = g_389[(g_106 + 1)][g_1491][(g_106 + 4)];
                        g_1519 |= ((((void*)0 != l_1435) , (safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((!(*p_29)), (safe_rshift_func_uint8_t_u_u(((safe_sub_func_int64_t_s_s((*l_1017), l_1488[1])) || (safe_sub_func_uint64_t_u_u((*l_1442), (safe_add_func_uint32_t_u_u(((*p_32) , (((safe_div_func_int16_t_s_s((((l_1515[2] = g_1512) != l_1516) > (***g_414)), l_1518[1][0])) && 0x98B50F0C93A22A47LL) <= 0x91B49CE5L)), (*g_226)))))), 4)))), l_1518[1][0]))) < l_1518[1][0]);
                    }
                }
            }
        }
        else
        { /* block id: 733 */
            union U2 l_1626 = {0xB2B08E3FL};
            const union U0 **l_1646 = &g_948;
            int8_t **l_1654 = &g_365;
            int32_t *l_1666 = (void*)0;
            int32_t l_1672 = 0x027BAF70L;
            int64_t l_1695 = 0x8D2B98539134D679LL;
            for (g_1169.f0 = 0; (g_1169.f0 > 23); ++g_1169.f0)
            { /* block id: 736 */
                int16_t l_1627 = 0x02F9L;
                int32_t *l_1665 = &l_1352;
                int32_t l_1679 = 7L;
                if ((*g_390))
                    break;
                if (((g_1640 = (((safe_mul_func_int16_t_s_s(0x827BL, ((safe_div_func_int16_t_s_s((safe_mod_func_int64_t_s_s((g_753 = (l_1626 , ((7L < l_1627) && ((void*)0 == &l_1000[0][3])))), ((safe_div_func_int64_t_s_s((g_188.f1 || ((safe_mul_func_uint16_t_u_u((safe_div_func_int16_t_s_s((safe_div_func_int64_t_s_s(l_1627, (safe_lshift_func_uint16_t_u_u(((**l_1314) = (*l_1017)), 6)))), 0x20C4L)), l_1638)) ^ (*l_1017))), g_18[1][0])) ^ l_1639[4]))), (*l_1017))) | g_889.f0))) || (*g_365)) , &g_226)) == &p_29))
                { /* block id: 741 */
                    const uint64_t l_1649 = 18446744073709551607UL;
                    if ((*g_12))
                    { /* block id: 742 */
                        int32_t l_1643 = 0x8E91BFE9L;
                        const union U0 ***l_1647[4];
                        int32_t l_1650 = 0x2D024981L;
                        int8_t ***l_1653[4][4][5] = {{{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868}},{{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868}},{{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868}},{{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868},{&g_868,&g_868,&g_868,&g_868,&g_868}}};
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_1647[i] = &l_1646;
                        l_1650 ^= (0xB6B3L && (l_1643 = ((*l_1001) = (safe_mul_func_int16_t_s_s(g_23, (l_1626.f1 == ((l_1643 , l_1627) , ((l_1627 <= ((**g_1640) != (l_1643 != (((safe_rshift_func_uint8_t_u_u(((l_1648 = l_1646) == (*g_1192)), 2)) | (*l_1017)) | 65534UL)))) & l_1649))))))));
                        l_1664 ^= (g_1593.f1 && ((((*g_1640) = func_54(((l_1627 && ((safe_add_func_uint64_t_u_u((&g_365 != (l_1654 = &g_365)), l_1643)) < ((safe_mul_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((safe_mul_func_int8_t_s_s(((l_1627 < (((((safe_add_func_int32_t_s_s((l_1650 &= ((l_1626.f0 & l_1643) < l_1627)), l_1627)) , (*g_365)) == l_1626.f1) && 0x18L) | 0x7CL)) | 0x4CAB37C0L), 0xC1L)) | 0x24EC09B5L), 1L)), l_1649)) , (*l_1017)))) <= g_1663), (*g_1640))) != p_32) == 254UL));
                        (*l_1017) |= l_1626.f0;
                        if ((**g_296))
                            continue;
                    }
                    else
                    { /* block id: 753 */
                        return (*g_1640);
                    }
                    return l_1666;
                }
                else
                { /* block id: 757 */
                    uint16_t l_1678 = 0xE85CL;
                    uint8_t *l_1694 = &g_221;
                    for (l_1626.f0 = 4; (l_1626.f0 != 23); l_1626.f0++)
                    { /* block id: 760 */
                        int32_t l_1671 = 1L;
                        l_1672 = (l_1671 <= ((void*)0 == (*l_1314)));
                        return (*l_1002);
                    }
                    l_1679 = ((*l_1017) = (safe_div_func_uint16_t_u_u(((*g_365) , (safe_lshift_func_int16_t_s_s(((*l_1665) ^= (!l_1678)), 11))), (*l_1017))));
                    (*l_1017) = ((**g_868) , (safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((**g_286) == 6L), (+(((*l_1017) >= (+(safe_mod_func_uint64_t_u_u(((((l_1678 || (((safe_sub_func_uint32_t_u_u((**g_1512), ((safe_rshift_func_int16_t_s_u(0x7E2EL, ((safe_div_func_int16_t_s_s(0x5EDDL, (((*l_1694) = (*l_1017)) ^ 1UL))) & g_259))) > (*l_1017)))) & (**l_1002)) != (*g_1513))) <= 0x1CA7L) != (**g_1640)) & l_1695), (**l_1002))))) != g_106)))), (*l_1665))));
                }
                (*l_1665) = ((g_1169.f2 , 6UL) , (*g_953));
            }
        }
        for (l_1584.f0 = 0; (l_1584.f0 <= 19); ++l_1584.f0)
        { /* block id: 775 */
            int32_t l_1702[6];
            int32_t l_1705 = (-1L);
            int32_t **l_1706 = &l_1441[4][1][4];
            int32_t l_1707 = 0xB2071B69L;
            int i;
            for (i = 0; i < 6; i++)
                l_1702[i] = 0L;
        }
    }
    else
    { /* block id: 781 */
        union U2 l_1712 = {0x8EA59E41L};
        int8_t *l_1729 = (void*)0;
        int32_t l_1738[2];
        int i;
        for (i = 0; i < 2; i++)
            l_1738[i] = 1L;
        for (g_76 = 0; (g_76 <= 0); g_76 += 1)
        { /* block id: 784 */
            int32_t *l_1708[2][1];
            int8_t *l_1728 = (void*)0;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_1708[i][j] = &l_1414;
            }
            --g_1709[1];
            if ((*g_226))
                continue;
            for (l_990 = 0; (l_990 <= 0); l_990 += 1)
            { /* block id: 789 */
                int32_t l_1715 = (-1L);
                int32_t l_1716 = 0xA95B9166L;
                uint16_t *l_1723 = &g_191[0];
                for (g_1593.f0 = 0; (g_1593.f0 <= 0); g_1593.f0 += 1)
                { /* block id: 792 */
                    int i;
                    if ((l_1712 , (safe_add_func_int64_t_s_s((g_753 ^= (l_1715 |= g_904[g_1593.f0])), l_1716))))
                    { /* block id: 795 */
                        int i;
                        return l_989[(g_1593.f0 + 1)];
                    }
                    else
                    { /* block id: 797 */
                        int32_t l_1720 = 0x2642510DL;
                        int i, j, k;
                        if (g_13)
                            goto lbl_1315;
                        g_192[(l_990 + 1)][(g_76 + 2)][g_76] = (*g_1640);
                        g_88 |= (l_1716 |= (g_1717 , ((safe_lshift_func_uint16_t_u_s(((((void*)0 == &g_267) > l_1720) == ((*g_365) < g_2)), 6)) <= (safe_add_func_int8_t_s_s(g_904[g_1593.f0], g_1717.f0)))));
                    }
                }
                l_1715 = (l_1716 &= ((*l_1017) & ((++(*l_1723)) >= 0UL)));
                for (l_1712.f2 = 0; (l_1712.f2 <= 4); l_1712.f2 += 1)
                { /* block id: 809 */
                    int64_t **l_1735 = &l_1000[0][5];
                    int64_t ***l_1734[4][9][1] = {{{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735}},{{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735}},{{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735}},{{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735},{&l_1735}}};
                    const int32_t l_1739[4][5] = {{(-1L),(-1L),0x051581F2L,(-1L),1L},{0x2C02B4BEL,0x0B6A2807L,0x0B6A2807L,0x2C02B4BEL,(-1L)},{0x2C02B4BEL,(-1L),0L,0L,(-1L)},{(-1L),0x0B6A2807L,0L,0x051581F2L,0x051581F2L}};
                    int32_t l_1741 = 1L;
                    uint32_t l_1743 = 18446744073709551615UL;
                    int i, j, k;
                    if ((safe_lshift_func_int16_t_s_u((((***g_1537) >= (((g_88 = (((*g_868) = l_1728) == l_1729)) | (l_1738[1] = (((*l_1001) &= (safe_mod_func_uint32_t_u_u(l_1716, (*g_226)))) ^ (l_1716 || ((safe_lshift_func_uint8_t_u_s(((void*)0 == l_1734[2][4][0]), (safe_add_func_int64_t_s_s(((0xD8EAL >= 1UL) , (-1L)), l_1712.f1)))) , 0x0083FE06L))))) > 0xD5BBL)) < l_1739[2][4]), l_1739[0][0])))
                    { /* block id: 814 */
                        return p_32;
                    }
                    else
                    { /* block id: 816 */
                        int32_t l_1740 = (-1L);
                        int32_t l_1742 = 1L;
                        int i, j, k;
                        --l_1743;
                        return p_32;
                    }
                }
            }
        }
        for (g_333 = (-7); (g_333 <= (-18)); g_333 = safe_sub_func_uint32_t_u_u(g_333, 9))
        { /* block id: 825 */
            (*g_1640) = p_30;
        }
    }
    return (*l_1002);
}


/* ------------------------------------------ */
/* 
 * reads : g_106 g_904 g_979 g_7 g_387 g_76 g_24 g_13
 * writes: g_106 g_261 g_88 g_753
 */
static int32_t * func_33(int32_t * p_34, union U2  p_35, uint64_t  p_36, uint32_t  p_37, uint8_t  p_38)
{ /* block id: 438 */
    uint32_t l_968 = 4UL;
    int32_t l_986 = 0x121DE513L;
    for (g_106 = 1; (g_106 <= 4); g_106 += 1)
    { /* block id: 441 */
        int32_t *l_962 = &g_88;
        int32_t *l_963 = &g_88;
        int32_t *l_964 = &g_88;
        int32_t *l_965 = &g_88;
        int32_t *l_966 = &g_88;
        int32_t *l_967 = &g_88;
        ++l_968;
        for (p_38 = 0; (p_38 <= 5); p_38 += 1)
        { /* block id: 445 */
            int16_t *l_980 = &g_261;
            int64_t *l_983 = (void*)0;
            int64_t *l_984[6][5][8] = {{{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753}},{{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0},{(void*)0,(void*)0,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753}},{{&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753,(void*)0,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753},{(void*)0,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753}},{{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753}},{{&g_753,&g_753,(void*)0,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,(void*)0,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{(void*)0,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753}},{{&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753,&g_753},{(void*)0,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753,&g_753},{&g_753,(void*)0,&g_753,&g_753,&g_753,&g_753,(void*)0,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,(void*)0},{&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753,&g_753}}};
            int32_t l_985 = 0x9A95F783L;
            int i, j, k;
            l_986 = (safe_add_func_int16_t_s_s(((safe_add_func_int64_t_s_s((g_753 = ((safe_add_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((g_904[p_38] > ((g_979 , ((*p_34) == (-9L))) | 0UL)), ((*l_980) = (g_106 && p_35.f0)))), ((4294967294UL ^ ((((safe_div_func_int64_t_s_s((l_985 = ((*l_962) = l_968)), 0x664CD1FA45DA7390LL)) , 5UL) , p_35.f2) | 0xDAFAL)) < 0UL))) , 0xDA543C06DD5E4A37LL)), (-1L))) | 0xD0466F04L), (*g_387)));
        }
    }
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_685 g_686 g_284 g_88
 * writes: g_88
 */
static int32_t * func_39(int32_t * p_40, int32_t  p_41, int8_t  p_42, int32_t * p_43)
{ /* block id: 434 */
    uint64_t *l_957 = &g_188.f0;
    uint64_t **l_956 = &l_957;
    uint64_t ***l_958 = &l_956;
    int32_t **l_960 = &g_226;
    g_88 &= (((-1L) == (((((((*l_958) = l_956) != (void*)0) , (**l_958)) != (void*)0) >= (safe_unary_minus_func_int64_t_s(0x32BEB55EBFF6FAF0LL))) < (*g_685))) < (g_284[0][2][6] >= ((void*)0 != l_960)));
    return p_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_953
 * writes: g_88
 */
static int32_t * func_44(union U2  p_45, int32_t * p_46, int32_t * const  p_47, int32_t * p_48, int32_t * const  p_49)
{ /* block id: 431 */
    int32_t l_952[3][2][10] = {{{0x5EF6B256L,0L,0xBB93F6B6L,0x91FF8692L,0L,(-6L),2L,0xBB93F6B6L,0xBB93F6B6L,2L},{(-6L),2L,0xBB93F6B6L,0xBB93F6B6L,2L,(-6L),0L,0x91FF8692L,0xBB93F6B6L,0L}},{{0x5EF6B256L,2L,(-1L),0x91FF8692L,2L,1L,2L,0x91FF8692L,(-1L),2L},{0x5EF6B256L,0L,0xBB93F6B6L,0x91FF8692L,0L,(-6L),2L,0xBB93F6B6L,0xBB93F6B6L,2L}},{{(-6L),2L,0xBB93F6B6L,0xBB93F6B6L,2L,(-6L),0L,0x91FF8692L,0xBB93F6B6L,0L},{0x5EF6B256L,2L,(-1L),0x91FF8692L,2L,1L,2L,0x91FF8692L,(-1L),2L}}};
    int32_t *l_954 = &g_7;
    int i, j, k;
    (*g_953) = l_952[0][1][3];
    return l_954;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_365 g_117.f1 g_85 g_81 g_3 g_83 g_387 g_76 g_286 g_287 g_288 g_13 g_296 g_226 g_221 g_390 g_88 g_104 g_886 g_191 g_66.f0 g_936 g_414 g_415
 * writes: g_2 g_16 g_81 g_84 g_261 g_117.f1 g_221 g_76 g_85.f0 g_868 g_333 g_259 g_88 g_904 g_668.f0 g_66.f0 g_948
 */
static union U2  func_50(int32_t * p_51, uint32_t  p_52, int64_t  p_53)
{ /* block id: 345 */
    int32_t *l_788 = &g_18[1][0];
    int64_t l_789 = (-5L);
    int32_t l_790 = 0L;
    union U1 **l_792 = &g_84;
    union U1 ***l_791[9];
    int32_t **l_793[3];
    uint16_t l_803 = 0xE7CBL;
    int16_t *l_804[8][8][4] = {{{&g_261,(void*)0,&g_261,(void*)0},{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,(void*)0,&g_261},{(void*)0,(void*)0,&g_261,&g_261},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261}},{{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,(void*)0,&g_261,&g_261},{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,(void*)0},{&g_261,(void*)0,&g_261,(void*)0},{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,(void*)0,&g_261}},{{(void*)0,(void*)0,&g_261,&g_261},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,(void*)0},{(void*)0,&g_261,(void*)0,&g_261}},{{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,&g_261,&g_261,(void*)0},{(void*)0,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,&g_261}},{{(void*)0,&g_261,&g_261,(void*)0},{&g_261,&g_261,&g_261,&g_261},{&g_261,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,(void*)0},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261}},{{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,&g_261,&g_261,(void*)0},{(void*)0,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,&g_261},{(void*)0,&g_261,&g_261,(void*)0},{&g_261,&g_261,&g_261,&g_261},{&g_261,(void*)0,&g_261,&g_261}},{{&g_261,(void*)0,(void*)0,(void*)0},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261},{(void*)0,&g_261,&g_261,(void*)0}},{{(void*)0,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,&g_261},{(void*)0,&g_261,&g_261,(void*)0},{&g_261,&g_261,&g_261,&g_261},{&g_261,(void*)0,&g_261,&g_261},{&g_261,(void*)0,(void*)0,(void*)0},{(void*)0,&g_261,(void*)0,&g_261},{&g_261,&g_261,&g_261,&g_261}}};
    uint16_t l_805 = 0x7E63L;
    int16_t l_814[10][1] = {{0x8ED2L},{0xCA20L},{0xCA20L},{0x8ED2L},{0x5C5CL},{0x8ED2L},{0xCA20L},{0xCA20L},{0x8ED2L},{0x5C5CL}};
    uint64_t l_816[3];
    uint8_t l_821 = 0xF5L;
    int16_t l_872 = (-9L);
    uint32_t l_942 = 3UL;
    const union U0 *l_947 = (void*)0;
    const union U0 **l_946[2];
    union U2 l_949[6] = {{8UL},{8UL},{8UL},{8UL},{8UL},{8UL}};
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_791[i] = &l_792;
    for (i = 0; i < 3; i++)
        l_793[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_816[i] = 0UL;
    for (i = 0; i < 2; i++)
        l_946[i] = &l_947;
    p_51 = func_57((safe_unary_minus_func_uint8_t_u(0xD2L)), l_788, ((((*l_788) , (l_790 &= l_789)) , l_791[0]) != &l_792), (*g_365));
    if (l_789)
        goto lbl_806;
lbl_806:
    l_805 = (safe_mul_func_uint16_t_u_u(65528UL, (g_261 = ((p_52 ^ ((((0x7387L >= (safe_mul_func_int8_t_s_s((((safe_div_func_uint64_t_u_u((0xC13D85B29D236ADBLL & (!(&p_51 == (void*)0))), p_52)) != (*g_387)) , ((l_803 = (safe_rshift_func_int8_t_s_u((p_53 , 0x6CL), 0))) , 0x70L)), p_53))) < (**g_286)) | g_13) <= 0xDA450B20L)) <= g_117.f1))));
    if ((safe_mul_func_int8_t_s_s(1L, (*g_365))))
    { /* block id: 352 */
        uint16_t l_809 = 0UL;
        int32_t *l_810[8][6] = {{&g_25,&g_25,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25},{&g_24,&g_24,&g_25,&g_24,&g_24,&g_25}};
        int8_t **l_866 = (void*)0;
        union U1 *l_888 = &g_889;
        union U1 **l_887[7] = {&l_888,&l_888,&l_888,&l_888,&l_888,&l_888,&l_888};
        uint64_t *l_890 = &l_816[2];
        int i, j;
        if ((p_51 != p_51))
        { /* block id: 353 */
            int32_t l_811 = 0xF832C994L;
            int32_t l_812 = 0x2EF130F3L;
            int32_t l_813 = (-1L);
            int32_t l_815 = 0x9E6E63BBL;
            int32_t l_819[10][8] = {{0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L},{0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL},{0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL},{0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L},{0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL},{0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL},{0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L},{0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL,1L,0x45B23A8FL,0x45B23A8FL},{0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL},{0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L,0xA17A4B60L,0x45B23A8FL,0xA17A4B60L}};
            int8_t l_820 = 0x3CL;
            int i, j;
            l_809 = p_52;
            l_810[6][5] = (*g_296);
            --l_816[2];
            ++l_821;
        }
        else
        { /* block id: 358 */
            int8_t l_825 = (-6L);
            uint32_t l_846 = 3UL;
            int32_t l_847 = 0x2546A970L;
            int32_t l_848 = 1L;
            l_825 &= (0UL | (safe_unary_minus_func_int8_t_s(0xC7L)));
            l_848 = ((safe_mod_func_int8_t_s_s(((*g_365) ^= 0x53L), (+(safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u((safe_lshift_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s(((safe_rshift_func_int16_t_s_u(((safe_unary_minus_func_uint16_t_u((((g_221 ^= (((safe_add_func_uint64_t_u_u((safe_sub_func_int8_t_s_s((((*l_788) <= 0xFEL) , (0x87L < 0x69L)), 1L)), (5L >= (safe_mul_func_int8_t_s_s(l_825, ((l_846 | l_825) == 0x947388DCL)))))) , p_52) > p_53)) <= p_53) || (-1L)))) ^ (*l_788)), p_53)) , (*g_390)), p_52)) , p_52), l_825)), l_825)), p_53))))) , l_847);
        }
        for (g_117.f1 = 0; (g_117.f1 != 19); g_117.f1++)
        { /* block id: 366 */
            int32_t l_851 = 0x3FBC2A64L;
            int32_t l_854[3][3][3] = {{{(-2L),0L,(-6L)},{0xB05B6699L,0x2763BC8EL,(-6L)},{0xE0E3690CL,0xB05B6699L,0x69A450D8L}},{{0L,0L,(-2L)},{0xE0E3690CL,(-2L),0xB05B6699L},{0xB05B6699L,(-2L),0xE0E3690CL}},{{(-2L),0L,0L},{0x69A450D8L,0xB05B6699L,0xE0E3690CL},{(-6L),0x2763BC8EL,0xB05B6699L}}};
            int8_t **l_867 = &g_365;
            int32_t *l_869 = &l_854[1][2][2];
            union U2 l_873 = {0UL};
            int i, j, k;
            if (l_851)
                break;
            for (g_76 = 0; (g_76 < 9); ++g_76)
            { /* block id: 370 */
                uint32_t l_855 = 0x2A232B04L;
                uint32_t *l_858 = &g_85[1][2][4].f0;
                uint8_t *l_861 = &g_221;
                int32_t l_884 = 0xA10B1D51L;
                int8_t *l_885[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_885[i] = (void*)0;
                --l_855;
                l_869 = (p_51 = func_57(((*l_858) = 0xB1905BF2L), p_51, (**g_286), (safe_sub_func_uint8_t_u_u(((*l_861) &= ((l_854[1][2][2] |= p_52) <= 65535UL)), ((safe_unary_minus_func_int16_t_s(0x0C52L)) == (!(safe_rshift_func_int8_t_s_s((l_866 != (g_868 = l_867)), 2))))))));
                p_51 = p_51;
                l_854[0][0][2] = (((((*l_861) = (0xABF1D7CAL == ((safe_rshift_func_uint16_t_u_u((((l_872 <= ((g_261 = (((((func_62(l_873, p_52, ((safe_mod_func_int64_t_s_s((253UL || ((*l_861) = (l_855 >= (safe_lshift_func_uint16_t_u_u(p_52, 13))))), (safe_rshift_func_int8_t_s_u((((g_259 = (g_333 = (safe_rshift_func_int8_t_s_u(((*g_104) >= (safe_sub_func_int16_t_s_s((l_884 = (g_88 == p_52)), (*g_387)))), 1)))) | 0xB4L) , p_53), 4)))) , p_53)) , (**g_286)) == 4294967295UL) , g_886) , &g_84) == l_887[1])) , p_52)) , p_52) ^ p_53), 15)) != 0L))) , 4294967287UL) , l_890) == (void*)0);
            }
            if (p_52)
                continue;
        }
    }
    else
    { /* block id: 389 */
        int32_t l_891 = 8L;
        int32_t l_892[2][3] = {{0x85BF58B7L,0x85BF58B7L,0x85BF58B7L},{0x446EB451L,0x446EB451L,0x446EB451L}};
        union U2 *l_926 = &g_85[1][2][4];
        int i, j;
lbl_945:
        for (g_88 = 0; (g_88 <= 1); g_88 += 1)
        { /* block id: 392 */
            int64_t l_893[5][10] = {{(-1L),0x00B38541A22B0E14LL,0x9AAE836A36EFD513LL,0x00B38541A22B0E14LL,(-1L),0x2CB0165E428443A5LL,0xA7E63E872DAC85A0LL,(-1L),0x2ADB9BC160BFBC5ALL,0xBEE95D48C8004BA5LL},{(-1L),(-10L),(-5L),(-1L),0xD1445FCF2C3580B1LL,2L,0xBEE95D48C8004BA5LL,(-10L),(-10L),0xBEE95D48C8004BA5LL},{(-9L),(-1L),0L,0L,(-1L),(-1L),0xEFF1D8FED41666C1LL,0x0798110487A60415LL,0x2CB0165E428443A5LL,0x9AAE836A36EFD513LL},{2L,0xD1445FCF2C3580B1LL,(-1L),(-5L),(-10L),(-1L),(-5L),2L,0x84DB3F1777D52C63LL,2L},{2L,(-1L),(-8L),0L,(-8L),(-1L),2L,(-3L),(-1L),0xD1445FCF2C3580B1LL}};
            int32_t l_894 = (-1L);
            int32_t l_895[10];
            uint16_t l_896 = 0xCE7FL;
            int i, j;
            for (i = 0; i < 10; i++)
                l_895[i] = 7L;
            l_896++;
            for (l_803 = 0; (l_803 <= 1); l_803 += 1)
            { /* block id: 396 */
                int32_t *l_903 = &g_904[5];
                union U2 l_905 = {18446744073709551615UL};
                int i;
                l_894 = (safe_rshift_func_uint8_t_u_u((((*l_903) = ((1L || (4294967292UL > g_191[l_803])) & l_893[4][5])) , p_52), 2));
                return l_905;
            }
        }
        for (l_821 = 0; (l_821 <= 2); l_821 += 1)
        { /* block id: 404 */
            union U2 *l_924 = &g_85[3][3][5];
            int32_t l_933[1][5] = {{0x7FA710A0L,0x7FA710A0L,0x7FA710A0L,0x7FA710A0L,0x7FA710A0L}};
            uint16_t ***l_938[9] = {&g_415[1],&g_415[1],&g_415[1],&g_415[1],&g_415[1],&g_415[1],&g_415[1],&g_415[1],&g_415[1]};
            int i, j;
            for (g_117.f1 = 0; (g_117.f1 <= 2); g_117.f1 += 1)
            { /* block id: 407 */
                union U2 **l_925[7] = {&g_267,(void*)0,(void*)0,&g_267,(void*)0,(void*)0,&g_267};
                uint64_t *l_931 = &g_668.f0;
                int32_t *l_932 = &g_904[0];
                uint16_t ***l_937 = (void*)0;
                int i;
                l_892[1][0] = (safe_rshift_func_uint16_t_u_s(((safe_sub_func_int16_t_s_s(l_816[g_117.f1], ((((l_816[l_821] == (~((safe_add_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u((~((l_892[1][0] , (++(*g_387))) || (p_53 > ((((*l_932) = (safe_mod_func_uint64_t_u_u((safe_div_func_int16_t_s_s(((l_924 = l_924) != l_926), (safe_rshift_func_uint8_t_u_u(p_53, (safe_div_func_uint32_t_u_u(((g_221 && ((*l_931) = g_221)) & p_52), (-4L))))))), g_18[4][0]))) , l_933[0][3]) | 0x74802FE2L)))), g_288)), l_933[0][0])) && 6UL), l_891)) ^ l_892[1][0]))) && l_933[0][3]) && 0xDDL) , p_52))) ^ 0x5CAD91F5L), p_52));
                for (g_66.f0 = 3; (g_66.f0 <= 8); g_66.f0 += 1)
                { /* block id: 415 */
                    uint16_t ****l_939 = &l_938[6];
                    g_88 |= ((l_933[0][3] , ((safe_mul_func_uint8_t_u_u((g_936[0] , ((p_52 ^ (l_937 != ((*l_939) = l_938[6]))) >= ((*l_931) = ((void*)0 == &g_266[0][1][1])))), l_816[g_117.f1])) && (g_261 = (safe_lshift_func_int16_t_s_s(((***g_414) || p_52), 12))))) < p_52);
                }
                if (l_892[1][0])
                    break;
            }
            if (l_816[l_821])
                continue;
            l_942--;
        }
        if (p_53)
            goto lbl_945;
        l_891 = p_52;
    }
    g_948 = &g_936[0];
    return l_949[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_104
 * writes: g_88
 */
static int32_t * func_54(int32_t  p_55, int32_t * p_56)
{ /* block id: 44 */
    int64_t l_103 = 0xB2F3DD08C68BE14BLL;
    uint32_t *l_105 = &g_106;
    int32_t l_132 = 1L;
    int32_t l_133[3];
    uint16_t *l_137[10] = {&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76,&g_76};
    int32_t l_161[2][7] = {{0x0D849AB6L,0x0D849AB6L,0L,0x0D849AB6L,0x0D849AB6L,0L,0x0D849AB6L},{0x0D849AB6L,0L,0L,0x0D849AB6L,0L,0L,0x0D849AB6L}};
    uint32_t l_168[10] = {0x05DEFB49L,1UL,0x05DEFB49L,0x05DEFB49L,1UL,0x05DEFB49L,0x05DEFB49L,1UL,0x05DEFB49L,0x05DEFB49L};
    const uint32_t *l_184 = (void*)0;
    union U1 *l_189 = (void*)0;
    int64_t l_190 = 0x918E3CBC813BED6CLL;
    union U1 ***l_206[1][1];
    int64_t l_228 = 0x6CDFC5EED3F469E8LL;
    union U2 l_239 = {8UL};
    uint32_t l_254[7] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
    int32_t l_275 = 1L;
    int32_t l_331 = 7L;
    uint32_t l_344 = 4294967295UL;
    uint16_t *l_385[7][6] = {{&g_191[0],&g_191[0],&g_191[0],&g_191[1],&g_76,&g_191[0]},{&g_191[0],&g_191[1],&g_191[0],&g_191[0],&g_191[0],&g_191[0]},{&g_191[1],&g_191[0],&g_191[0],(void*)0,&g_191[0],&g_191[0]},{&g_76,(void*)0,&g_191[0],&g_191[1],&g_191[0],&g_191[1]},{&g_191[1],&g_191[0],&g_191[1],&g_191[0],&g_191[0],(void*)0},{&g_76,&g_191[0],&g_76,&g_76,&g_191[0],&g_76},{&g_191[0],(void*)0,&g_191[0],&g_191[1],&g_191[0],&g_191[0]}};
    union U2 **l_398[3];
    uint64_t l_418 = 18446744073709551615UL;
    int32_t *l_423 = &g_88;
    int8_t l_452 = 0xC9L;
    int32_t l_506[3][1];
    int64_t l_569 = (-7L);
    uint64_t l_727 = 1UL;
    uint32_t l_736 = 0UL;
    int64_t *l_762 = &l_190;
    uint8_t l_778 = 246UL;
    int32_t *l_785[5][4][7] = {{{&g_4[2],&g_24,&l_133[2],&g_24,&g_7,&l_275,&g_88},{&g_27,&g_18[6][1],&g_18[1][0],&l_275,(void*)0,&g_25,&g_25},{&g_27,&g_24,&g_25,&g_24,&g_18[1][0],(void*)0,&g_4[0]},{&g_4[2],&g_13,&g_24,&l_133[0],&g_24,&g_13,&g_4[2]}},{{&g_24,(void*)0,&l_132,&g_27,&g_27,&l_275,&g_24},{&g_88,&l_132,&g_4[2],(void*)0,&g_18[2][1],&g_24,&g_13},{(void*)0,&g_88,&l_132,(void*)0,(void*)0,&g_13,&g_13},{&l_275,&g_18[1][0],&g_24,&g_88,&g_13,&g_25,&l_275}},{{&g_25,&l_133[2],&g_25,&l_133[0],&l_275,&g_13,&l_133[2]},{&g_4[2],&g_7,&g_4[2],&g_18[1][0],&g_88,&g_27,(void*)0},{&l_132,&l_132,&g_25,&g_4[2],&g_24,&g_25,&g_24},{&g_4[0],(void*)0,(void*)0,&g_4[0],&g_88,&g_4[2],&g_88}},{{&g_18[2][1],&g_88,(void*)0,&l_275,&g_4[2],&g_18[1][0],&g_25},{&g_13,&l_275,(void*)0,&g_25,&l_133[0],&g_13,&g_88},{&l_132,&g_24,(void*)0,&l_275,&l_133[0],&l_132,&g_24},{&g_18[1][0],&l_133[0],&l_133[0],&g_18[1][0],&g_4[2],&g_24,(void*)0}},{{(void*)0,&g_18[1][0],&g_88,(void*)0,&g_4[2],(void*)0,&l_133[2]},{&g_88,&g_18[1][0],&g_27,&g_4[2],(void*)0,&g_18[1][0],&g_18[6][1]},{&l_275,&l_133[0],&g_27,(void*)0,(void*)0,&g_27,&l_133[0]},{&g_4[2],&g_24,&g_13,&l_133[0],&g_27,&l_133[0],&g_18[1][0]}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_133[i] = 0x98B50884L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_206[i][j] = (void*)0;
    }
    for (i = 0; i < 3; i++)
        l_398[i] = &g_267;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_506[i][j] = 0xCBE9886FL;
    }
    (*g_104) = l_103;
    return p_56;
}


/* ------------------------------------------ */
/* 
 * reads : g_85 g_81 g_3 g_83
 * writes: g_2 g_16 g_81 g_84
 */
static int32_t * func_57(uint32_t  p_58, int32_t * p_59, uint32_t  p_60, int8_t  p_61)
{ /* block id: 32 */
    uint8_t l_99 = 1UL;
    int32_t *l_102 = (void*)0;
    for (p_61 = 2; (p_61 >= 0); p_61 -= 1)
    { /* block id: 35 */
        int32_t *l_87 = &g_88;
        int32_t l_89 = 1L;
        int32_t *l_90 = (void*)0;
        int32_t *l_91 = &l_89;
        int32_t *l_92 = &l_89;
        int32_t *l_93 = &l_89;
        int32_t *l_94 = &l_89;
        int32_t *l_95 = &l_89;
        int32_t *l_96 = &g_88;
        int32_t *l_97 = &l_89;
        int32_t *l_98[1];
        int i;
        for (i = 0; i < 1; i++)
            l_98[i] = &l_89;
        ++l_99;
        for (p_60 = 0; (p_60 <= 2); p_60 += 1)
        { /* block id: 39 */
            int i, j;
            p_59 = (func_62(g_85[0][1][5], g_81[p_60][(p_61 + 2)], (g_3 , l_99)) , &g_88);
        }
    }
    return l_102;
}


/* ------------------------------------------ */
/* 
 * reads : g_83 g_85
 * writes: g_2 g_16 g_81 g_84
 */
static union U2  func_62(union U2  p_63, uint32_t  p_64, uint16_t  p_65)
{ /* block id: 28 */
    union U1 *l_82 = &g_66;
    for (g_2 = 0; g_2 < 3; g_2 += 1)
    {
        for (g_16 = 0; g_16 < 9; g_16 += 1)
        {
            g_81[g_2][g_16] = 0UL;
        }
    }
    (*g_83) = l_82;
    return g_85[1][2][4];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_18[i][j], "g_18[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_66.f0, "g_66.f0", print_hash_value);
    transparent_crc(g_66.f1, "g_66.f1", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_81[i][j], "g_81[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_85[i][j][k].f0, "g_85[i][j][k].f0", print_hash_value);
                transparent_crc(g_85[i][j][k].f1, "g_85[i][j][k].f1", print_hash_value);
                transparent_crc(g_85[i][j][k].f2, "g_85[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_117.f0, "g_117.f0", print_hash_value);
    transparent_crc(g_117.f1, "g_117.f1", print_hash_value);
    transparent_crc(g_117.f2, "g_117.f2", print_hash_value);
    transparent_crc(g_188.f0, "g_188.f0", print_hash_value);
    transparent_crc(g_188.f1, "g_188.f1", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_191[i], "g_191[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_215.f0, "g_215.f0", print_hash_value);
    transparent_crc(g_215.f1, "g_215.f1", print_hash_value);
    transparent_crc(g_215.f2, "g_215.f2", print_hash_value);
    transparent_crc(g_221, "g_221", print_hash_value);
    transparent_crc(g_257.f0, "g_257.f0", print_hash_value);
    transparent_crc(g_257.f1, "g_257.f1", print_hash_value);
    transparent_crc(g_259, "g_259", print_hash_value);
    transparent_crc(g_261, "g_261", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_284[i][j][k], "g_284[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_288, "g_288", print_hash_value);
    transparent_crc(g_333, "g_333", print_hash_value);
    transparent_crc(g_360.f0, "g_360.f0", print_hash_value);
    transparent_crc(g_360.f1, "g_360.f1", print_hash_value);
    transparent_crc(g_486.f0, "g_486.f0", print_hash_value);
    transparent_crc(g_486.f1, "g_486.f1", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_561[i][j].f0, "g_561[i][j].f0", print_hash_value);
            transparent_crc(g_561[i][j].f1, "g_561[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_668.f0, "g_668.f0", print_hash_value);
    transparent_crc(g_668.f1, "g_668.f1", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_686[i][j][k], "g_686[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_699[i][j].f0, "g_699[i][j].f0", print_hash_value);
            transparent_crc(g_699[i][j].f1, "g_699[i][j].f1", print_hash_value);
            transparent_crc(g_699[i][j].f2, "g_699[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_716.f0, "g_716.f0", print_hash_value);
    transparent_crc(g_716.f1, "g_716.f1", print_hash_value);
    transparent_crc(g_753, "g_753", print_hash_value);
    transparent_crc(g_765.f0, "g_765.f0", print_hash_value);
    transparent_crc(g_765.f1, "g_765.f1", print_hash_value);
    transparent_crc(g_886.f0, "g_886.f0", print_hash_value);
    transparent_crc(g_886.f1, "g_886.f1", print_hash_value);
    transparent_crc(g_889.f0, "g_889.f0", print_hash_value);
    transparent_crc(g_889.f1, "g_889.f1", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_904[i], "g_904[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_936[i].f0, "g_936[i].f0", print_hash_value);
        transparent_crc(g_936[i].f1, "g_936[i].f1", print_hash_value);
        transparent_crc(g_936[i].f2, "g_936[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_979.f0, "g_979.f0", print_hash_value);
    transparent_crc(g_979.f1, "g_979.f1", print_hash_value);
    transparent_crc(g_979.f2, "g_979.f2", print_hash_value);
    transparent_crc(g_1027.f0, "g_1027.f0", print_hash_value);
    transparent_crc(g_1027.f1, "g_1027.f1", print_hash_value);
    transparent_crc(g_1059.f0, "g_1059.f0", print_hash_value);
    transparent_crc(g_1059.f1, "g_1059.f1", print_hash_value);
    transparent_crc(g_1059.f2, "g_1059.f2", print_hash_value);
    transparent_crc(g_1169.f0, "g_1169.f0", print_hash_value);
    transparent_crc(g_1169.f1, "g_1169.f1", print_hash_value);
    transparent_crc(g_1169.f2, "g_1169.f2", print_hash_value);
    transparent_crc(g_1187, "g_1187", print_hash_value);
    transparent_crc(g_1359.f0, "g_1359.f0", print_hash_value);
    transparent_crc(g_1359.f1, "g_1359.f1", print_hash_value);
    transparent_crc(g_1438, "g_1438", print_hash_value);
    transparent_crc(g_1491, "g_1491", print_hash_value);
    transparent_crc(g_1519, "g_1519", print_hash_value);
    transparent_crc(g_1590.f0, "g_1590.f0", print_hash_value);
    transparent_crc(g_1590.f1, "g_1590.f1", print_hash_value);
    transparent_crc(g_1593.f0, "g_1593.f0", print_hash_value);
    transparent_crc(g_1593.f1, "g_1593.f1", print_hash_value);
    transparent_crc(g_1663, "g_1663", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1709[i], "g_1709[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1717.f0, "g_1717.f0", print_hash_value);
    transparent_crc(g_1717.f1, "g_1717.f1", print_hash_value);
    transparent_crc(g_1717.f2, "g_1717.f2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_1757[i][j][k], "g_1757[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1809, "g_1809", print_hash_value);
    transparent_crc(g_1846, "g_1846", print_hash_value);
    transparent_crc(g_1847.f0, "g_1847.f0", print_hash_value);
    transparent_crc(g_1847.f1, "g_1847.f1", print_hash_value);
    transparent_crc(g_1847.f2, "g_1847.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 464
XXX total union variables: 40

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 50
breakdown:
   depth: 1, occurrence: 148
   depth: 2, occurrence: 45
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 15, occurrence: 2
   depth: 17, occurrence: 2
   depth: 18, occurrence: 1
   depth: 19, occurrence: 3
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 1
   depth: 23, occurrence: 4
   depth: 26, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 37, occurrence: 1
   depth: 45, occurrence: 1
   depth: 50, occurrence: 1

XXX total number of pointers: 449

XXX times a variable address is taken: 1048
XXX times a pointer is dereferenced on RHS: 332
breakdown:
   depth: 1, occurrence: 239
   depth: 2, occurrence: 84
   depth: 3, occurrence: 8
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 238
breakdown:
   depth: 1, occurrence: 228
   depth: 2, occurrence: 8
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 36
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 6
XXX times a pointer is qualified to be dereferenced: 5810

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1467
   level: 2, occurrence: 316
   level: 3, occurrence: 34
   level: 4, occurrence: 12
   level: 5, occurrence: 1
XXX number of pointers point to pointers: 164
XXX number of pointers point to scalars: 255
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 34.7
XXX average alias set size: 1.63

XXX times a non-volatile is read: 1718
XXX times a non-volatile is write: 747
XXX times a volatile is read: 121
XXX    times read thru a pointer: 27
XXX times a volatile is write: 20
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4.56e+03
XXX percentage of non-volatile access: 94.6

XXX forward jumps: 2
XXX backward jumps: 8

XXX stmts: 157
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 26
   depth: 2, occurrence: 33
   depth: 3, occurrence: 27
   depth: 4, occurrence: 18
   depth: 5, occurrence: 21

XXX percentage a fresh-made variable is used: 17
XXX percentage an existing variable is used: 83
********************* end of statistics **********************/

