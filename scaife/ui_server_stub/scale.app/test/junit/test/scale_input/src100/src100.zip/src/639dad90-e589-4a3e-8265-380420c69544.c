/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2459100621
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   const volatile uint8_t  f0;
   uint32_t  f1;
   uint32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x0BF34FDAL;
static int32_t g_14 = 1L;
static const int32_t *g_21[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const int32_t **g_20[1][8] = {{&g_21[7],&g_21[7],&g_21[7],&g_21[7],&g_21[7],&g_21[7],&g_21[7],&g_21[7]}};
static const int32_t *** volatile g_19[3][4] = {{&g_20[0][7],&g_20[0][7],&g_20[0][7],&g_20[0][7]},{&g_20[0][7],(void*)0,(void*)0,&g_20[0][7]},{(void*)0,&g_20[0][7],(void*)0,(void*)0}};
static union U0 g_23 = {9UL};/* VOLATILE GLOBAL g_23 */
static int32_t *g_45 = &g_3;
static int32_t **g_44 = &g_45;
static uint8_t g_62 = 4UL;
static const volatile uint8_t g_96 = 255UL;/* VOLATILE GLOBAL g_96 */
static uint16_t g_100 = 0xBDDFL;
static int32_t g_106 = 0x80504C99L;
static union U0 g_183[6] = {{0x90L},{0x90L},{0x90L},{0x90L},{0x90L},{0x90L}};
static volatile int16_t g_185 = (-2L);/* VOLATILE GLOBAL g_185 */
static int16_t g_201 = 0x1A33L;
static int16_t g_225[7] = {1L,1L,1L,1L,1L,1L,1L};
static int16_t g_227 = (-2L);
static int64_t g_229 = 0x2C45EFAB24A63803LL;
static int8_t g_242 = 5L;
static uint32_t g_270 = 0x5D3632D9L;
static uint64_t g_271 = 0x911AC779D52D5915LL;
static int64_t g_273 = 3L;
static uint8_t g_275 = 252UL;
static int8_t g_294 = 0xF8L;
static uint64_t g_339 = 1UL;
static volatile union U0 g_347 = {255UL};/* VOLATILE GLOBAL g_347 */
static uint16_t *g_400 = &g_100;
static uint16_t * volatile *g_399 = &g_400;
static int32_t *g_409 = &g_3;
static int32_t **g_408 = &g_409;
static uint16_t g_429 = 0x5B08L;
static int32_t **g_453[6][7][2] = {{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}},{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}},{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}},{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}},{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}},{{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45},{&g_45,&g_45}}};
static int32_t * volatile g_469 = &g_14;/* VOLATILE GLOBAL g_469 */
static int32_t ** const **g_489 = (void*)0;
static volatile int8_t g_493[3][10][8] = {{{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L}},{{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L}},{{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L},{0L,0x13L,0L,0x13L,0L,0x13L,0L,0x13L}}};
static int16_t g_498 = (-2L);
static volatile union U0 g_554[2] = {{1UL},{1UL}};
static uint32_t g_569 = 0xDB8722C5L;
static volatile union U0 g_598 = {1UL};/* VOLATILE GLOBAL g_598 */
static uint16_t g_614 = 65535UL;
static int32_t g_625 = 0x3C906673L;
static const volatile union U0 g_633 = {1UL};/* VOLATILE GLOBAL g_633 */
static int32_t g_642[4] = {0x06C66480L,0x06C66480L,0x06C66480L,0x06C66480L};
static uint64_t g_643[1] = {18446744073709551615UL};
static int32_t * volatile g_646 = &g_642[2];/* VOLATILE GLOBAL g_646 */
static int32_t * const  volatile g_662 = &g_14;/* VOLATILE GLOBAL g_662 */
static uint64_t g_677 = 0x6A8B81D8FD533BC4LL;
static volatile int64_t g_709 = 0x21B431EB5B991FE9LL;/* VOLATILE GLOBAL g_709 */
static volatile int64_t *g_708 = &g_709;
static volatile int64_t ** const  volatile g_707 = &g_708;/* VOLATILE GLOBAL g_707 */
static int16_t g_713 = 0xC1ADL;
static int16_t g_769 = 0x119FL;
static const int32_t ***g_821 = &g_20[0][7];
static const int32_t ****g_820 = &g_821;
static int64_t *g_838 = &g_273;
static int64_t **g_837 = &g_838;
static int64_t *** volatile g_836 = &g_837;/* VOLATILE GLOBAL g_836 */
static uint32_t *g_843 = &g_23.f1;
static const int64_t g_858 = 0L;
static volatile union U0 g_894 = {0x6AL};/* VOLATILE GLOBAL g_894 */
static union U0 g_940 = {255UL};/* VOLATILE GLOBAL g_940 */
static uint32_t g_947 = 0UL;
static volatile union U0 g_1113 = {0xD3L};/* VOLATILE GLOBAL g_1113 */
static volatile union U0 *g_1123 = &g_347;
static volatile union U0 ** volatile g_1122 = &g_1123;/* VOLATILE GLOBAL g_1122 */
static int8_t g_1126 = 0xD4L;
static uint8_t g_1261 = 0x2CL;
static uint8_t *g_1272 = &g_1261;
static uint8_t *g_1276[1] = {&g_62};
static uint8_t ** const  volatile g_1275 = &g_1276[0];/* VOLATILE GLOBAL g_1275 */
static volatile int32_t g_1315 = 0x4BCABD2EL;/* VOLATILE GLOBAL g_1315 */
static volatile int32_t *g_1314 = &g_1315;
static volatile int32_t ** const g_1313 = &g_1314;
static uint32_t g_1351 = 0x10DCB450L;
static int32_t g_1365[3][3][9] = {{{0L,0x3ACFD142L,(-4L),0x3ACFD142L,0L,0xB8063971L,0L,0x3ACFD142L,(-4L)},{0x688709FDL,0x688709FDL,(-1L),0x4F2AF598L,0x688709FDL,0xD852B306L,0x4F2AF598L,0x4F2AF598L,0xD852B306L},{0x06F463E1L,0x3ACFD142L,4L,0x3ACFD142L,0x06F463E1L,0xB8063971L,0x06F463E1L,0x3ACFD142L,4L}},{{0x688709FDL,0x4F2AF598L,(-1L),0x688709FDL,0x688709FDL,(-1L),0x4F2AF598L,0x688709FDL,0xD852B306L},{0L,0x3ACFD142L,(-4L),0x3ACFD142L,0L,0xB8063971L,0L,0x3ACFD142L,(-4L)},{0x688709FDL,0x688709FDL,(-1L),0x4F2AF598L,0x688709FDL,0xD852B306L,0x4F2AF598L,0x4F2AF598L,0xD852B306L}},{{0xAC64813DL,0x44813990L,0x06F463E1L,0x44813990L,0xAC64813DL,0x3ACFD142L,0xAC64813DL,0x44813990L,0x06F463E1L},{0x55F7C423L,(-5L),0x4F2AF598L,0x55F7C423L,0x55F7C423L,0x4F2AF598L,(-5L),0x55F7C423L,0x688709FDL},{1L,0x44813990L,0L,0x44813990L,1L,0x3ACFD142L,1L,0x44813990L,0L}}};
static volatile uint32_t g_1389 = 1UL;/* VOLATILE GLOBAL g_1389 */
static uint16_t **g_1437[1] = {&g_400};
static uint16_t ***g_1436 = &g_1437[0];
static uint16_t g_1448[3][2] = {{0xF53AL,0xF53AL},{0xF53AL,0xF53AL},{0xF53AL,0xF53AL}};
static uint16_t g_1449 = 0x25C0L;
static uint16_t g_1450 = 1UL;
static uint16_t g_1451 = 0x405DL;
static uint16_t g_1452 = 0xAE6AL;
static uint16_t g_1453 = 0UL;
static uint16_t g_1454 = 65535UL;
static uint16_t g_1455 = 65531UL;
static uint16_t g_1456 = 0x5BB9L;
static uint16_t g_1457 = 0x02E3L;
static uint16_t g_1458 = 65529UL;
static uint16_t g_1459[8] = {0xB2C1L,0xB2C1L,0xB2C1L,0xB2C1L,0xB2C1L,0xB2C1L,0xB2C1L,0xB2C1L};
static uint16_t g_1460 = 0x0922L;
static uint16_t g_1461 = 0xEEF8L;
static uint16_t g_1462 = 1UL;
static uint16_t g_1463 = 1UL;
static uint16_t g_1464 = 3UL;
static uint16_t g_1465 = 0x769CL;
static uint16_t g_1466[9] = {0x7891L,0x7891L,0x7891L,0x7891L,0x7891L,0x7891L,0x7891L,0x7891L,0x7891L};
static uint16_t g_1467 = 0x97E6L;
static uint16_t g_1468 = 1UL;
static uint16_t g_1469 = 0x8982L;
static uint16_t g_1470 = 0x83F3L;
static uint16_t g_1471 = 65529UL;
static uint16_t g_1472 = 0xBDF0L;
static uint16_t g_1473 = 0x08E8L;
static union U0 g_1482 = {0x54L};/* VOLATILE GLOBAL g_1482 */
static volatile union U0 ** volatile g_1484 = &g_1123;/* VOLATILE GLOBAL g_1484 */
static volatile union U0 **g_1523 = &g_1123;
static uint16_t ****g_1540 = (void*)0;
static volatile uint32_t g_1566 = 0x47F740C6L;/* VOLATILE GLOBAL g_1566 */
static int32_t g_1577 = 0x20C3B38EL;
static int32_t ** const g_1586 = &g_45;
static int16_t *g_1625 = &g_713;
static const int8_t *g_1666 = &g_242;
static const int8_t **g_1665 = &g_1666;
static const int8_t *** volatile g_1664 = &g_1665;/* VOLATILE GLOBAL g_1664 */
static union U0 g_1699 = {255UL};/* VOLATILE GLOBAL g_1699 */
static union U0 *g_1698 = &g_1699;
static volatile uint32_t ** volatile * const g_1702 = (void*)0;
static uint32_t **g_1788 = &g_843;
static uint32_t ***g_1787 = &g_1788;
static uint32_t ****g_1786[6][4] = {{&g_1787,&g_1787,(void*)0,&g_1787},{&g_1787,&g_1787,&g_1787,&g_1787},{&g_1787,&g_1787,&g_1787,&g_1787},{&g_1787,&g_1787,(void*)0,&g_1787},{&g_1787,&g_1787,&g_1787,&g_1787},{&g_1787,&g_1787,&g_1787,&g_1787}};
static int32_t ***g_1853 = &g_453[5][4][1];
static int32_t *** const *g_1852 = &g_1853;
static int32_t *** const **g_1851 = &g_1852;
static const union U0 *g_1877 = &g_183[3];
static const union U0 ** volatile g_1876 = &g_1877;/* VOLATILE GLOBAL g_1876 */
static int32_t *g_1903 = &g_625;
static int8_t *g_1910 = &g_294;
static int8_t **g_1909 = &g_1910;
static int8_t ***g_1908 = &g_1909;
static union U0 **g_2007[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U0 g_2025 = {1UL};/* VOLATILE GLOBAL g_2025 */
static union U0 g_2102 = {254UL};/* VOLATILE GLOBAL g_2102 */
static uint64_t g_2146 = 6UL;
static int64_t **g_2178 = &g_838;
static union U0 g_2234[10][4][6] = {{{{1UL},{0x73L},{255UL},{0x91L},{0xE4L},{1UL}},{{5UL},{0xB9L},{9UL},{4UL},{0x82L},{0UL}},{{0x7EL},{1UL},{0x98L},{1UL},{1UL},{0x50L}},{{3UL},{255UL},{0UL},{255UL},{3UL},{0UL}}},{{{0xC7L},{255UL},{7UL},{0xA6L},{0xCDL},{1UL}},{{0x42L},{5UL},{0x16L},{255UL},{248UL},{1UL}},{{252UL},{0UL},{7UL},{6UL},{0x39L},{0UL}},{{248UL},{1UL},{0UL},{0x24L},{1UL},{0x50L}}},{{{0x91L},{0UL},{0x98L},{0UL},{0xC8L},{0UL}},{{0x93L},{0x54L},{9UL},{0x78L},{6UL},{1UL}},{{0UL},{1UL},{255UL},{0x97L},{0xD5L},{0x47L}},{{255UL},{247UL},{0UL},{0UL},{0x94L},{0UL}}},{{{1UL},{0xACL},{0xC7L},{0x42L},{255UL},{0UL}},{{3UL},{255UL},{251UL},{255UL},{2UL},{0x73L}},{{1UL},{1UL},{255UL},{0x63L},{253UL},{0x6AL}},{{0xA6L},{0x94L},{247UL},{0xC1L},{252UL},{0UL}}},{{{247UL},{0x6AL},{0x78L},{2UL},{1UL},{0xABL}},{{0x6AL},{0x93L},{1UL},{0UL},{3UL},{1UL}},{{1UL},{0x7AL},{0x0AL},{5UL},{1UL},{253UL}},{{0UL},{0x13L},{0x97L},{1UL},{0x54L},{0x7AL}}},{{{0xF7L},{250UL},{0xCDL},{248UL},{0UL},{1UL}},{{0x98L},{1UL},{0x8DL},{0x8DL},{1UL},{0x98L}},{{0UL},{1UL},{0xC8L},{0xD5L},{0UL},{255UL}},{{1UL},{251UL},{0UL},{0UL},{5UL},{0xF1L}}},{{{1UL},{253UL},{0UL},{0xD5L},{255UL},{0x54L}},{{0UL},{0UL},{0xABL},{0x8DL},{255UL},{251UL}},{{0x98L},{249UL},{0x78L},{248UL},{1UL},{0x94L}},{{0xF7L},{0UL},{0x89L},{1UL},{0xB9L},{255UL}}},{{{0UL},{0UL},{247UL},{5UL},{0x73L},{249UL}},{{1UL},{253UL},{0x6AL},{1UL},{0xD3L},{0x13L}},{{0x8DL},{0x24L},{0x47L},{0x94L},{255UL},{3UL}},{{0UL},{248UL},{0UL},{6UL},{3UL},{1UL}}},{{{250UL},{0x50L},{4UL},{0UL},{0UL},{1UL}},{{3UL},{0x78L},{253UL},{1UL},{0x1FL},{0UL}},{{0UL},{6UL},{0UL},{1UL},{0x98L},{255UL}},{{0xC4L},{255UL},{1UL},{1UL},{6UL},{0UL}}},{{{248UL},{0xF1L},{253UL},{0xAEL},{0x97L},{250UL}},{{1UL},{0UL},{248UL},{1UL},{0UL},{0x50L}},{{0xD3L},{0xC8L},{0x63L},{251UL},{0xC8L},{253UL}},{{255UL},{0x89L},{1UL},{0xF1L},{1UL},{0x89L}}}};


/* --- FORWARD DECLARATIONS --- */
static union U0  func_1(void);
static const int32_t  func_29(const uint16_t  p_30);
static int32_t ** const  func_31(int32_t *** p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35);
static const uint16_t  func_39(int32_t ** const * p_40, int32_t ** p_41, int32_t ** p_42, int32_t * const  p_43);
static int32_t ** func_46(uint32_t  p_47);
static int32_t  func_48(int32_t *** p_49, const int16_t  p_50);
static int32_t *** func_51(int32_t ** p_52, uint64_t  p_53, int64_t  p_54, int32_t * const ** p_55);
static int32_t ** func_56(int32_t ** p_57, int64_t  p_58);
static int32_t ** func_59(uint8_t  p_60);
static const uint8_t  func_72(uint8_t * p_73, uint16_t  p_74);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_14 g_23 g_44 g_23.f1 g_96 g_100 g_62 g_106 g_45 g_23.f2 g_229 g_242 g_275 g_273 g_339 g_225 g_347 g_227 g_294 g_271 g_201 g_399 g_185 g_183.f0 g_400 g_409 g_270 g_429 g_23.f0 g_183 g_469 g_2 g_554 g_569 g_498 g_453 g_598 g_493 g_633 g_625 g_643 g_646 g_633.f0 g_642 g_662 g_1351 g_940.f2 g_821 g_20 g_1126 g_837 g_838 g_843 g_1389 g_1272 g_1261 g_1122 g_1123 g_1482 g_1458 g_1365 g_820 g_1484 g_1523 g_708 g_709 g_836 g_1466 g_1452 g_1566 g_1577 g_1482.f0 g_1586 g_1664 g_1665 g_1787 g_1788 g_1625 g_713 g_2234
 * writes: g_3 g_14 g_20 g_62 g_23.f1 g_100 g_106 g_45 g_229 g_275 g_273 g_339 g_227 g_242 g_408 g_271 g_225 g_489 g_201 g_400 g_498 g_569 g_642 g_643 g_677 g_1351 g_1126 g_940.f2 g_294 g_1365 g_1436 g_1461 g_1471 g_21 g_1123 g_429 g_1261 g_947 g_1540 g_270 g_23.f2 g_1566 g_1665
 */
static union U0  func_1(void)
{ /* block id: 0 */
    int32_t * const l_6 = &g_3;
    uint32_t l_26 = 0x588C5561L;
    for (g_3 = 24; (g_3 < 28); g_3++)
    { /* block id: 3 */
        int32_t *l_8 = &g_3;
        int32_t **l_7 = &l_8;
        int32_t l_9 = (-1L);
        (*l_7) = l_6;
        if (l_9)
            break;
    }
    if ((safe_lshift_func_int16_t_s_s((*l_6), 0)))
    { /* block id: 7 */
        for (g_3 = 0; (g_3 == 19); g_3++)
        { /* block id: 10 */
            for (g_14 = (-11); (g_14 >= (-8)); g_14 = safe_add_func_int32_t_s_s(g_14, 9))
            { /* block id: 13 */
                const int32_t *l_18 = &g_3;
                const int32_t **l_17 = &l_18;
                const int32_t ***l_22 = &g_20[0][7];
                (*l_22) = l_17;
            }
            return g_23;
        }
    }
    else
    { /* block id: 18 */
        int32_t *l_24 = &g_3;
        int32_t *l_25 = &g_3;
        l_26--;
    }
    (*g_409) = func_29((*l_6));
    return g_2234[5][0][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_44 g_23.f1 g_96 g_14 g_100 g_62 g_106 g_45 g_23.f2 g_229 g_242 g_275 g_273 g_339 g_225 g_347 g_227 g_294 g_271 g_201 g_399 g_185 g_183.f0 g_400 g_23 g_409 g_270 g_429 g_23.f0 g_183 g_469 g_2 g_554 g_569 g_498 g_453 g_598 g_493 g_633 g_625 g_643 g_646 g_633.f0 g_642 g_662 g_1351 g_940.f2 g_821 g_20 g_1126 g_837 g_838 g_843 g_1389 g_1272 g_1261 g_1122 g_1123 g_1482 g_1458 g_1365 g_820 g_1484 g_1523 g_708 g_709 g_836 g_1466 g_1452 g_1566 g_1577 g_1482.f0 g_1586 g_1664 g_1665 g_1787 g_1788 g_1625 g_713
 * writes: g_62 g_23.f1 g_100 g_106 g_45 g_229 g_275 g_273 g_339 g_227 g_242 g_14 g_408 g_271 g_225 g_489 g_201 g_400 g_498 g_569 g_642 g_643 g_677 g_1351 g_1126 g_940.f2 g_3 g_294 g_1365 g_1436 g_1461 g_1471 g_21 g_1123 g_429 g_1261 g_947 g_1540 g_270 g_23.f2 g_1566 g_1665
 */
static const int32_t  func_29(const uint16_t  p_30)
{ /* block id: 21 */
    int32_t *l_38 = &g_3;
    int32_t **l_37 = &l_38;
    int32_t ***l_36[4];
    uint8_t *l_61 = &g_62;
    int32_t * const *l_407 = &l_38;
    int32_t * const l_680[6][6][7] = {{{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3},{&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3}},{{(void*)0,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3},{&g_3,&g_3,&g_3,(void*)0,&g_3,(void*)0,&g_3}},{{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0},{&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3}},{{(void*)0,&g_3,(void*)0,&g_3,&g_3,(void*)0,&g_3},{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3},{&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,(void*)0,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,(void*)0}},{{&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,(void*)0,(void*)0,&g_3},{&g_3,(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,(void*)0}}};
    int32_t ***l_2206 = &g_408;
    int16_t l_2207[4][5] = {{(-1L),0x82EEL,(-1L),0x82EEL,(-1L)},{1L,0xF3A1L,0xF3A1L,1L,1L},{0x69CDL,0x82EEL,0x69CDL,0x82EEL,0x69CDL},{1L,1L,0xF3A1L,0xF3A1L,1L}};
    union U0 *l_2226[7];
    const int8_t ***l_2229 = &g_1665;
    int8_t * const * const l_2230 = &g_1910;
    const int32_t l_2231[6][5] = {{1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L}};
    int32_t ****** const *l_2232 = (void*)0;
    uint16_t l_2233 = 0xBA31L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_36[i] = &l_37;
    for (i = 0; i < 7; i++)
        l_2226[i] = &g_940;
    (*l_2206) = func_31(l_36[1], (g_3 > func_39(&l_37, g_44, func_46(((func_48(func_51(func_56(func_59(((*l_61) = 9UL)), ((l_407 != (g_408 = g_44)) , g_3)), g_270, (**l_37), &l_407), (*l_38)) || 0UL) && g_493[1][7][6])), l_680[5][3][0])), p_30, p_30);
    (*l_38) = ((l_2207[1][2] <= ((((*g_400) = (safe_unary_minus_func_int16_t_s(p_30))) == ((((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((safe_sub_func_int64_t_s_s((safe_add_func_uint64_t_u_u(((safe_div_func_int32_t_s_s(((p_30 <= (safe_unary_minus_func_uint32_t_u((((((void*)0 != l_2226[3]) >= ((safe_sub_func_uint8_t_u_u(((*l_61) = (((((*l_2229) = (*g_1664)) != l_2230) ^ ((p_30 != ((((l_2231[1][3] , l_2232) == (void*)0) , p_30) || 0x8DL)) , 0x93E0L)) || l_2233)), p_30)) != (***g_1787))) , (void*)0) != (void*)0)))) == p_30), 1L)) || 0xA4DF7CC14FF80E19LL), p_30)), (-1L))), 4)), (*g_1625))), 5)) , p_30) != 0L) | 0L)) <= (*l_38))) <= (*g_838));
    return (**l_37);
}


/* ------------------------------------------ */
/* 
 * reads : g_1351 g_940.f2 g_643 g_821 g_20 g_1126 g_294 g_837 g_838 g_400 g_100 g_642 g_843 g_3 g_1389 g_1272 g_1261 g_14 g_662 g_429 g_498 g_633.f0 g_1122 g_1123 g_347 g_23.f1 g_1482 g_1458 g_1365 g_820 g_1484 g_62 g_339 g_1523 g_399 g_708 g_709 g_225 g_229 g_836 g_273 g_409 g_1466 g_1452 g_201 g_1566 g_1577 g_1482.f0 g_1586
 * writes: g_62 g_1351 g_1126 g_940.f2 g_3 g_225 g_294 g_273 g_643 g_642 g_23.f1 g_100 g_14 g_1365 g_1436 g_1461 g_1471 g_21 g_1123 g_339 g_429 g_1261 g_947 g_677 g_271 g_1540 g_270 g_201 g_45 g_23.f2 g_1566 g_569
 */
static int32_t ** const  func_31(int32_t *** p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35)
{ /* block id: 567 */
    int32_t l_1344 = (-1L);
    int32_t l_1350[6] = {0x10355525L,0x10355525L,0x10355525L,0x10355525L,0x10355525L,0x10355525L};
    int32_t ** const l_1376 = &g_45;
    uint32_t l_1383[3];
    uint32_t l_1428 = 0xA5B6F19FL;
    int32_t l_1474 = 1L;
    union U0 *l_1525 = &g_183[3];
    union U0 **l_1524 = &l_1525;
    uint16_t ****l_1539 = (void*)0;
    int8_t *l_1552 = &g_1126;
    int32_t l_1581 = (-5L);
    uint16_t **l_1587 = &g_400;
    uint8_t **l_1693[1];
    uint8_t l_1707 = 2UL;
    uint64_t l_1718 = 0x36F546E4AF1BAFDCLL;
    int32_t *l_1721 = &g_642[1];
    uint32_t ****l_1791 = &g_1787;
    int32_t l_1842[9] = {(-1L),0xE523CEF9L,(-1L),(-1L),0xE523CEF9L,(-1L),(-1L),0xE523CEF9L,(-1L)};
    int8_t l_1843 = (-4L);
    int8_t ***l_1912 = &g_1909;
    int32_t l_1915[10] = {3L,3L,3L,3L,3L,3L,3L,3L,3L,3L};
    uint32_t ****l_1934[7][4][2] = {{{(void*)0,(void*)0},{&g_1787,&g_1787},{(void*)0,&g_1787},{(void*)0,&g_1787}},{{&g_1787,(void*)0},{(void*)0,&g_1787},{(void*)0,(void*)0},{&g_1787,&g_1787}},{{(void*)0,&g_1787},{(void*)0,&g_1787},{&g_1787,(void*)0},{(void*)0,&g_1787}},{{(void*)0,(void*)0},{&g_1787,&g_1787},{(void*)0,&g_1787},{(void*)0,&g_1787}},{{&g_1787,(void*)0},{(void*)0,&g_1787},{(void*)0,(void*)0},{&g_1787,&g_1787}},{{(void*)0,&g_1787},{(void*)0,&g_1787},{&g_1787,(void*)0},{(void*)0,&g_1787}},{{(void*)0,(void*)0},{&g_1787,&g_1787},{(void*)0,&g_1787},{(void*)0,&g_1787}}};
    uint64_t l_1976 = 18446744073709551614UL;
    int16_t l_2044[8][5] = {{1L,(-5L),2L,2L,(-5L)},{(-3L),0x1CF4L,(-9L),(-5L),1L},{0x1CF4L,2L,(-9L),0x8E7BL,(-9L)},{1L,1L,2L,(-3L),0x0FB7L},{0x1CF4L,0x0FB7L,1L,(-3L),(-3L)},{(-3L),0xCC85L,(-3L),0x8E7BL,0x7420L},{1L,0x0FB7L,0x1CF4L,(-5L),0x7420L},{2L,1L,1L,2L,(-3L)}};
    int16_t l_2145 = 3L;
    const union U0 **l_2166 = (void*)0;
    const union U0 ***l_2165 = &l_2166;
    uint32_t l_2194[4] = {0x3097BD0DL,0x3097BD0DL,0x3097BD0DL,0x3097BD0DL};
    uint8_t l_2203 = 0x2DL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1383[i] = 0x302D0829L;
    for (i = 0; i < 1; i++)
        l_1693[i] = &g_1276[0];
    for (g_62 = 0; (g_62 <= 2); g_62 += 1)
    { /* block id: 570 */
        int16_t l_1343 = 0xA013L;
        int32_t *l_1345 = (void*)0;
        int32_t *l_1346 = &g_642[2];
        int32_t *l_1347 = (void*)0;
        int32_t *l_1348 = &g_14;
        int32_t *l_1349[10] = {&l_1344,&l_1344,&l_1344,&l_1344,&l_1344,&l_1344,&l_1344,&l_1344,&l_1344,&l_1344};
        uint16_t ****l_1538[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int64_t **l_1541 = &g_838;
        union U0 * const * const l_1564 = &l_1525;
        int64_t l_1580 = 0x70FC6D74C3B9C9A1LL;
        int16_t l_1582 = 0x10A7L;
        int i;
        g_1351++;
        for (g_1126 = 6; (g_1126 >= 0); g_1126 -= 1)
        { /* block id: 574 */
            uint32_t **l_1401 = &g_843;
            uint32_t ***l_1400[5][2] = {{(void*)0,&l_1401},{&l_1401,&l_1401},{(void*)0,&l_1401},{&l_1401,&l_1401},{&l_1401,&l_1401}};
            int32_t l_1402 = 8L;
            int32_t l_1421 = 0x5AAD3BEBL;
            int32_t l_1425 = 9L;
            int64_t l_1427 = (-6L);
            uint16_t **l_1434 = &g_400;
            uint16_t ***l_1433 = &l_1434;
            int32_t l_1531[9][6][4] = {{{4L,0x2150A60BL,(-1L),(-3L)},{4L,(-1L),0x120D6D60L,0x824267F8L},{0x87ADC1B3L,(-3L),0xE9910945L,0x24E90F94L},{(-1L),7L,(-7L),(-1L)},{0xDFC89CB6L,0x87ADC1B3L,(-7L),0L},{(-1L),0x35000C1BL,0x824267F8L,(-7L)}},{{0L,0x120D6D60L,0x120D6D60L,0L},{0x1846B6F8L,0xC61E9024L,0x1D1D1496L,(-3L)},{0x120D6D60L,7L,0L,0xE9910945L},{0x87ADC1B3L,0xDFC89CB6L,0x24E90F94L,0xE9910945L},{(-1L),7L,5L,(-3L)},{0x32F57161L,0xC61E9024L,(-7L),0L}},{{0xF9E51EF7L,0x120D6D60L,0xE9910945L,(-7L)},{0xC61E9024L,0x35000C1BL,0L,0L},{0x1846B6F8L,0x87ADC1B3L,(-1L),(-1L)},{4L,7L,4L,0x24E90F94L},{0L,(-3L),0x24E90F94L,0x824267F8L},{0xF9E51EF7L,(-1L),(-7L),(-3L)}},{{(-3L),0x2150A60BL,(-7L),0L},{0xF9E51EF7L,0x1846B6F8L,0x24E90F94L,(-7L)},{0L,0x35000C1BL,4L,0xC61E9024L},{4L,0xC61E9024L,(-1L),0x32F57161L},{0x1846B6F8L,(-1L),0L,0x24E90F94L},{0xC61E9024L,0xA1C38334L,0xE9910945L,0xE9910945L}},{{0xF9E51EF7L,0xF9E51EF7L,(-7L),(-1L)},{0x32F57161L,0x2150A60BL,5L,0xC61E9024L},{(-1L),0x120D6D60L,0x24E90F94L,5L},{0x87ADC1B3L,0x120D6D60L,0L,0xC61E9024L},{0x120D6D60L,0x2150A60BL,0x1D1D1496L,(-1L)},{0x1846B6F8L,0xF9E51EF7L,0x120D6D60L,0xE9910945L}},{{0L,0xA1C38334L,0x824267F8L,0x24E90F94L},{(-1L),(-1L),(-7L),0x32F57161L},{0xDFC89CB6L,0xC61E9024L,(-7L),0xC61E9024L},{(-1L),0x35000C1BL,0xE9910945L,(-7L)},{0x87ADC1B3L,0x1846B6F8L,0x120D6D60L,0L},{4L,0x2150A60BL,(-1L),(-3L)}},{{4L,(-1L),0x120D6D60L,0x824267F8L},{0x87ADC1B3L,(-3L),0xE9910945L,0x24E90F94L},{(-1L),7L,(-7L),(-1L)},{0xDFC89CB6L,0x87ADC1B3L,(-7L),0L},{(-1L),0x35000C1BL,0x824267F8L,(-7L)},{0L,0x120D6D60L,0x120D6D60L,0L}},{{0x1846B6F8L,0xC61E9024L,0x1D1D1496L,(-3L)},{0x120D6D60L,0x5F015722L,0xA1C38334L,0L},{0x120D6D60L,0x24E90F94L,5L,0L},{0L,0x5F015722L,0x1D1D1496L,0x824267F8L},{0xE9910945L,4L,(-1L),0L},{(-3L),0x32F57161L,0L,(-1L)}},{{4L,0xDFC89CB6L,0xA1C38334L,0x35000C1BL},{(-3L),0x120D6D60L,0L,(-3L)},{(-1L),0x5F015722L,(-1L),5L},{0L,0x824267F8L,5L,(-7L)},{(-3L),0L,7L,0x824267F8L},{0x824267F8L,0x1846B6F8L,7L,0x35000C1BL}}};
            int32_t ** const l_1554 = &l_1348;
            union U0 **l_1557 = &l_1525;
            int i, j, k;
            for (g_940.f2 = 0; (g_940.f2 <= 0); g_940.f2 += 1)
            { /* block id: 577 */
                int32_t * const l_1364 = &g_1365[1][2][7];
                int32_t * const *l_1363 = &l_1364;
                int32_t * const **l_1362 = &l_1363;
                const uint8_t * const *l_1368 = (void*)0;
                int32_t *l_1377 = &g_14;
                int32_t l_1414 = 0x83D6A8EFL;
                int32_t l_1416 = 0xAA974110L;
                int32_t l_1420[4][6] = {{7L,0xAFEA707BL,0xAFEA707BL,7L,0xAFEA707BL,0xAFEA707BL},{7L,0xAFEA707BL,0xAFEA707BL,7L,0xAFEA707BL,0xAFEA707BL},{7L,0xAFEA707BL,0xAFEA707BL,7L,0xAFEA707BL,0xAFEA707BL},{7L,0xAFEA707BL,0xAFEA707BL,7L,0xAFEA707BL,0xAFEA707BL}};
                int16_t l_1424 = (-1L);
                uint16_t **l_1444 = &g_400;
                int i, j;
                (***p_32) = (safe_lshift_func_int16_t_s_s(g_643[g_940.f2], 9));
                (*l_1346) ^= ((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(((g_225[g_1126] = ((safe_mod_func_uint8_t_u_u((((*l_1362) = (*p_32)) != (*g_821)), p_35)) > 0xC703FDF5L)) , (safe_rshift_func_int8_t_s_s((g_294 &= 7L), 6))), 8)), (&g_1276[0] != (((**g_837) = (-10L)) , l_1368)))) < (g_643[g_940.f2] = ((((*g_400) , p_33) || p_34) , l_1350[5])));
                for (p_34 = 0; (p_34 <= 6); p_34 += 1)
                { /* block id: 587 */
                    uint32_t l_1386[10][2] = {{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL}};
                    const uint8_t *l_1411 = (void*)0;
                    const uint8_t **l_1410 = &l_1411;
                    int32_t l_1418 = (-4L);
                    int32_t l_1422 = 0x0E15BD9BL;
                    int32_t l_1423 = 0xBB33EED2L;
                    int32_t l_1426 = 0x3C36C7F5L;
                    int i, j;
                    if (((safe_add_func_uint16_t_u_u(((((p_35 | 0x6BL) | ((*g_843) = (safe_div_func_int64_t_s_s((~(*l_1346)), l_1350[5])))) ^ (255UL && 0UL)) > (***p_32)), ((*g_400) = ((safe_div_func_uint32_t_u_u(((&g_843 != (void*)0) , p_35), (***p_32))) | 0UL)))) , (***p_32)))
                    { /* block id: 590 */
                        return l_1376;
                    }
                    else
                    { /* block id: 592 */
                        l_1377 = (**p_32);
                        if ((***p_32))
                            continue;
                    }
                    if ((1UL && (~p_33)))
                    { /* block id: 596 */
                        int16_t l_1399 = 0xF99DL;
                        (*l_1348) |= (safe_rshift_func_int8_t_s_u(((safe_add_func_uint32_t_u_u((**l_1363), l_1383[0])) & (safe_div_func_uint32_t_u_u(l_1386[2][0], (safe_div_func_uint8_t_u_u((g_1389 < ((!((safe_lshift_func_uint16_t_u_u(((safe_unary_minus_func_int64_t_s((l_1386[3][0] , (p_35 = (~(safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(((((l_1402 = ((l_1399 , l_1400[3][1]) == (void*)0)) | (safe_lshift_func_int16_t_s_u((**l_1363), l_1386[2][1]))) | p_35) >= 1L), 7)), 12))))))) & (-1L)), 1)) | (**l_1363))) , 65531UL)), (*g_1272)))))), 1));
                        if ((*g_662))
                            break;
                    }
                    else
                    { /* block id: 601 */
                        int32_t l_1407 = 0xD30A2A0EL;
                        int32_t l_1415 = 0xA8F93E11L;
                        int32_t l_1417 = (-3L);
                        int32_t l_1419[5][6][7] = {{{1L,0x36238F30L,(-1L),(-1L),0x62D16C98L,0L,0x2D849B8AL},{(-1L),0L,3L,(-1L),0xFA5A9A38L,(-3L),1L},{1L,1L,5L,0x8FC014A1L,0x62D16C98L,0x62D16C98L,0x8FC014A1L},{8L,0xE90D3982L,8L,0xE48DC18BL,(-10L),1L,0xA694A3ECL},{0x38652032L,(-1L),0x112E3974L,0x46AB3BBAL,1L,(-1L),5L},{3L,0L,(-1L),0x4FA4BB70L,0xDE0664DEL,1L,0xDE0664DEL}},{{1L,1L,0x36238F30L,(-1L),(-1L),0x62D16C98L,0L},{(-4L),0x96A16334L,0xA694A3ECL,(-3L),8L,(-3L),6L},{(-1L),5L,0x112E3974L,(-8L),1L,0L,0L},{0x4299663EL,0xB90F8178L,(-1L),0xB90F8178L,0x4299663EL,0L,0xDE0664DEL},{(-1L),0x62D16C98L,5L,(-7L),0L,(-8L),5L},{0xEEAF5FBEL,1L,1L,(-3L),6L,0xE48DC18BL,0xA694A3ECL}},{{(-1L),(-7L),(-1L),1L,(-8L),0x2D849B8AL,0x8FC014A1L},{0x4299663EL,(-1L),0x025B98CFL,0x4FA4BB70L,1L,0x96A16334L,1L},{(-1L),0xB7AE4534L,7L,0L,0L,1L,7L},{(-2L),1L,0xA694A3ECL,0xB90F8178L,0xA694A3ECL,1L,(-2L)},{1L,(-1L),7L,0x62D16C98L,0x46AB3BBAL,0x2D849B8AL,0L},{0xDE0664DEL,0xE48DC18BL,9L,1L,0xFA5A9A38L,1L,0x025B98CFL}},{{0xB7AE4534L,1L,7L,(-7L),(-8L),(-1L),0x112E3974L},{0x998D9F9DL,0xE90D3982L,0xA694A3ECL,(-1L),0x8B8A710BL,0xB90F8178L,(-4L)},{(-1L),(-7L),(-7L),0xB7AE4534L,(-1L),(-1L),0L},{(-1L),1L,0x426FD4EDL,(-1L),1L,(-1L),0x426FD4EDL},{0x46AB3BBAL,0x46AB3BBAL,0x36238F30L,(-7L),1L,0x38652032L,7L},{8L,(-1L),0xEEAF5FBEL,1L,1L,(-3L),6L}},{{(-1L),0x36238F30L,(-7L),0x62D16C98L,1L,0x112E3974L,0x7D3D26A4L},{0xFA5A9A38L,0x4FA4BB70L,0xFA5A9A38L,0xB90F8178L,1L,(-3L),(-1L)},{0xB7AE4534L,1L,0x2D849B8AL,5L,(-1L),1L,(-7L)},{0xEEAF5FBEL,(-1L),8L,0x96A16334L,0x8B8A710BL,(-3L),0x8B8A710BL},{1L,0L,0L,1L,(-8L),0x112E3974L,5L},{0x426FD4EDL,1L,(-1L),0L,0xFA5A9A38L,(-3L),0x4299663EL}}};
                        uint16_t ****l_1435 = (void*)0;
                        uint16_t * const l_1447[7][5][7] = {{{&g_1448[2][0],&g_1457,(void*)0,&g_1468,&g_1468,(void*)0,&g_1457},{&g_1455,(void*)0,&g_1456,&g_1465,(void*)0,&g_1473,&g_1471},{&g_1464,&g_1468,&g_1459[0],&g_1464,&g_1457,&g_1464,&g_1459[0]},{&g_1450,&g_1450,&g_1463,&g_1465,&g_1455,&g_1458,&g_1450},{&g_1462,&g_1459[0],&g_1470,&g_1468,(void*)0,(void*)0,&g_1468}},{{&g_1452,&g_1471,&g_1452,&g_1473,&g_1455,&g_1452,(void*)0},{&g_1468,&g_1457,&g_1461,&g_1453,&g_1457,&g_1451,&g_1457},{&g_1460,&g_1473,&g_1473,&g_1460,(void*)0,&g_1452,&g_1455},{(void*)0,&g_1462,&g_1459[0],&g_1470,&g_1468,(void*)0,(void*)0},{&g_1450,&g_1455,&g_1449,&g_1455,&g_1450,&g_1458,&g_1455}},{{&g_1448[2][0],(void*)0,&g_1464,&g_1468,&g_1459[0],&g_1464,&g_1457},{&g_1473,&g_1471,&g_1456,&g_1456,&g_1471,&g_1473,(void*)0},{&g_1470,&g_1464,&g_1448[2][0],&g_1470,(void*)0,&g_1453,&g_1464},{&g_1473,&g_1463,&g_1469,(void*)0,&g_1469,&g_1463,&g_1473},{&g_1451,&g_1464,&g_1466[8],(void*)0,&g_1459[0],&g_1451,(void*)0}},{{&g_1456,&g_1467,&g_1465,&g_1452,&g_1452,&g_1465,&g_1467},{&g_1464,&g_1472,&g_1466[8],(void*)0,&g_1472,(void*)0,(void*)0},{&g_1449,&g_1452,&g_1469,&g_1449,&g_1467,&g_1449,&g_1469},{&g_1459[0],&g_1459[0],&g_1448[2][0],(void*)0,&g_1464,&g_1468,&g_1459[0]},{&g_1473,&g_1469,&g_1454,&g_1452,&g_1463,&g_1463,&g_1452}},{{&g_1461,(void*)0,&g_1461,(void*)0,&g_1464,&g_1461,&g_1472},{&g_1452,&g_1467,&g_1471,(void*)0,&g_1467,&g_1460,&g_1467},{&g_1470,(void*)0,(void*)0,&g_1470,&g_1472,&g_1461,&g_1464},{&g_1463,&g_1473,&g_1469,&g_1454,&g_1452,&g_1463,&g_1463},{&g_1459[0],&g_1464,&g_1457,&g_1464,&g_1459[0],&g_1468,&g_1464}},{{&g_1456,&g_1458,&g_1449,&g_1452,&g_1469,&g_1449,&g_1467},{(void*)0,(void*)0,&g_1466[8],&g_1466[8],(void*)0,(void*)0,&g_1472},{&g_1456,&g_1452,&g_1460,&g_1456,&g_1467,&g_1465,&g_1452},{&g_1459[0],&g_1451,(void*)0,(void*)0,(void*)0,&g_1451,&g_1459[0]},{&g_1463,&g_1452,&g_1454,&g_1469,&g_1473,&g_1463,&g_1469}},{{&g_1470,(void*)0,&g_1453,&g_1464,&g_1464,&g_1453,(void*)0},{&g_1452,&g_1458,&g_1454,(void*)0,&g_1458,&g_1469,&g_1467},{&g_1461,&g_1464,(void*)0,&g_1461,(void*)0,&g_1461,(void*)0},{&g_1473,&g_1473,&g_1460,(void*)0,&g_1452,&g_1455,&g_1473},{&g_1459[0],(void*)0,&g_1466[8],&g_1464,&g_1451,&g_1451,&g_1464}}};
                        uint16_t * const *l_1446 = &l_1447[3][0][0];
                        uint16_t * const **l_1445 = &l_1446;
                        int i, j, k;
                        if (l_1386[4][0])
                            break;
                        (*l_1364) = ((safe_rshift_func_uint16_t_u_u(l_1407, 4)) || (((((g_429 < ((p_35 || ((safe_add_func_int64_t_s_s((((p_35 <= 0x72L) == ((void*)0 != l_1410)) <= (*g_1272)), ((safe_mul_func_int16_t_s_s((p_33 , 0xC731L), p_35)) != (*l_1377)))) || p_35)) , g_498)) , p_35) != p_34) || (-1L)) < 0x60L));
                        --l_1428;
                        l_1421 = (safe_sub_func_uint8_t_u_u((&g_399 == (g_1436 = l_1433)), (safe_sub_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((p_33 | 4294967287UL), ((*g_1272) && ((safe_mul_func_int8_t_s_s(g_633.f0, (((*l_1433) = l_1444) == ((*l_1445) = &g_400)))) , (((*g_843) = ((*l_1377) &= ((**g_1122) , (*g_843)))) | 0x0B27FA43L))))), l_1474))));
                    }
                }
                if ((1UL >= (-1L)))
                { /* block id: 613 */
                    int64_t *l_1483 = &l_1427;
                    for (g_1461 = 0; (g_1461 <= 6); g_1461 += 1)
                    { /* block id: 616 */
                        (*l_1348) = l_1425;
                    }
                    (*l_1364) |= (safe_sub_func_uint64_t_u_u(0x3B2753F00666A715LL, ((*l_1483) = ((*g_838) = (((*l_1377) = (((~((l_1474 >= (safe_sub_func_int8_t_s_s(0x48L, ((((safe_lshift_func_int16_t_s_u(((*g_1272) , ((l_1364 != (void*)0) <= (g_1482 , 249UL))), (*l_1348))) , 1L) > (*g_1272)) , p_35)))) , (***p_32))) && 255UL) && g_1458)) & l_1402)))));
                    (*l_1348) = (p_35 >= (-10L));
                }
                else
                { /* block id: 624 */
                    uint8_t l_1489 = 255UL;
                    for (g_1471 = 0; (g_1471 <= 6); g_1471 += 1)
                    { /* block id: 627 */
                        int32_t l_1485 = 1L;
                        int32_t l_1486 = 0L;
                        int32_t l_1487 = (-4L);
                        int32_t l_1488 = 1L;
                        int i, j;
                        (*l_1364) ^= 0xB9B20553L;
                        (***g_820) = (void*)0;
                        (*g_1484) = (*g_1122);
                        --l_1489;
                    }
                    if ((***p_32))
                        break;
                }
            }
            for (g_339 = 2; (g_339 <= 6); g_339 += 1)
            { /* block id: 638 */
                int8_t l_1522 = (-2L);
                int32_t l_1527 = 0x9C1803EEL;
                int16_t l_1530 = (-1L);
                int8_t **l_1553 = &l_1552;
                int32_t ** const l_1555[1][10] = {{&l_1347,(void*)0,&l_1347,&l_1347,(void*)0,&l_1347,&l_1347,(void*)0,&l_1347,&l_1347}};
                int i, j;
                for (p_34 = 0; (p_34 <= 6); p_34 += 1)
                { /* block id: 641 */
                    uint8_t *l_1518[6][6][2] = {{{(void*)0,&g_62},{&g_275,(void*)0},{&g_62,&g_275},{&g_62,(void*)0},{&g_275,&g_62},{(void*)0,&g_275}},{{&g_275,&g_275},{&g_275,&g_275},{&g_275,&g_275},{(void*)0,&g_62},{&g_275,&g_275},{(void*)0,(void*)0}},{{(void*)0,&g_275},{&g_275,(void*)0},{&g_275,(void*)0},{&g_275,&g_275},{&g_275,&g_275},{&g_275,(void*)0}},{{&g_275,(void*)0},{&g_275,&g_275},{(void*)0,(void*)0},{(void*)0,&g_275},{&g_275,(void*)0},{&g_275,(void*)0}},{{&g_275,&g_275},{&g_275,&g_275},{&g_275,(void*)0},{&g_275,(void*)0},{&g_275,&g_275},{(void*)0,(void*)0}},{{(void*)0,&g_275},{&g_275,(void*)0},{&g_275,(void*)0},{&g_275,&g_275},{&g_275,&g_275},{&g_275,(void*)0}}};
                    int32_t l_1519 = 0xC1D16A9FL;
                    uint32_t *l_1528 = &g_947;
                    uint64_t *l_1529[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint64_t l_1549[10] = {0x4C8FC1159AA8A0F3LL,0x837608358EF19053LL,0x4C8FC1159AA8A0F3LL,0x4C8FC1159AA8A0F3LL,0x837608358EF19053LL,0x4C8FC1159AA8A0F3LL,0x4C8FC1159AA8A0F3LL,0x837608358EF19053LL,0x4C8FC1159AA8A0F3LL,0x4C8FC1159AA8A0F3LL};
                    int i, j, k;
                    for (g_429 = 0; (g_429 <= 3); g_429 += 1)
                    { /* block id: 644 */
                        int i, j, k;
                        (**p_32) = &g_1365[g_62][g_62][g_1126];
                    }
                    g_642[g_62] ^= (((safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_u((((g_1365[g_62][g_62][(g_339 + 2)] = (((safe_mul_func_uint8_t_u_u((+((l_1530 |= (((-1L) > (safe_lshift_func_int16_t_s_u((g_225[p_34] ^= ((safe_lshift_func_uint16_t_u_u((+(((safe_add_func_uint64_t_u_u((g_677 = ((((*l_1528) = (safe_rshift_func_uint16_t_u_u(((safe_add_func_uint64_t_u_u(((safe_mod_func_int8_t_s_s((g_1365[g_62][g_62][(g_339 + 2)] ^ ((safe_rshift_func_uint8_t_u_u(0xDEL, ((***p_32) , (l_1519 = ((*g_1272)--))))) != (l_1522 != (g_1523 != l_1524)))), (~(l_1527 = 0x56L)))) || p_34), 0L)) & g_1365[g_62][g_62][(g_339 + 2)]), (**g_399)))) , p_35) != 0xDF3FL)), (*g_708))) == p_34) <= 0xDBE6L)), (**g_399))) < l_1522)), 14))) >= p_34)) >= (-1L))), (-1L))) | 4UL) && 9L)) != 0xF11843E8CA3D0C91LL) == (*l_1348)), 5)), 5)), p_33)) != p_33) > p_34);
                    g_642[(g_62 + 1)] &= ((g_271 = l_1531[6][0][3]) == (safe_mod_func_uint64_t_u_u(((safe_rshift_func_int16_t_s_s(g_229, 10)) | ((((safe_sub_func_uint16_t_u_u(p_33, (((*g_400) , l_1538[0]) != (g_1540 = l_1539)))) , (void*)0) != l_1541) , (safe_mul_func_int8_t_s_s((~((+((~((safe_sub_func_int8_t_s_s(((((**p_32) == (**p_32)) , (***g_836)) | p_34), 7UL)) == 0x1C1AF68AD4FCF0A4LL)) , (*g_843))) && l_1519)), 6UL)))), (*g_838))));
                    ++l_1549[2];
                }
                (*g_409) ^= (&g_493[0][5][4] == ((*l_1553) = l_1552));
                return (*p_32);
            }
            for (g_270 = 0; (g_270 <= 2); g_270 += 1)
            { /* block id: 667 */
                union U0 **l_1565 = &l_1525;
                for (g_201 = 5; (g_201 >= 0); g_201 -= 1)
                { /* block id: 670 */
                    int i, j, k;
                    l_1531[(g_201 + 3)][(g_62 + 3)][(g_62 + 1)] = ((((l_1350[g_62] != ((**l_1434) = ((&g_1123 == ((!l_1344) , l_1557)) || (***p_32)))) | (safe_mul_func_uint8_t_u_u(p_35, (((safe_lshift_func_uint8_t_u_s(((((((((safe_rshift_func_uint16_t_u_s((((l_1564 != l_1565) & l_1350[g_62]) || g_1466[8]), p_35)) , g_1261) != p_33) <= p_35) == (***p_32)) >= p_35) , p_35) , 255UL), g_1452)) != p_35) < p_35)))) != p_35) || (*g_843));
                }
            }
            (*l_1376) = (*l_1554);
        }
        if ((***p_32))
            break;
        for (g_23.f2 = 0; (g_23.f2 <= 6); g_23.f2 += 1)
        { /* block id: 680 */
            const int32_t ** const *l_1576[4][3] = {{&g_20[0][7],&g_20[0][7],&g_20[0][6]},{&g_20[0][7],&g_20[0][7],&g_20[0][7]},{&g_20[0][7],&g_20[0][7],&g_20[0][6]},{&g_20[0][7],&g_20[0][7],&g_20[0][7]}};
            int32_t l_1578 = 0x45CD379CL;
            int32_t l_1579[7][5] = {{0xB81525DCL,(-1L),0x518CD5BFL,(-1L),0xB81525DCL},{3L,1L,(-8L),(-9L),1L},{0xB81525DCL,(-8L),(-8L),0xB81525DCL,(-9L)},{(-1L),0xB81525DCL,0x518CD5BFL,1L,1L},{3L,0xB81525DCL,3L,(-9L),0xB81525DCL},{1L,(-8L),(-9L),1L,(-9L)},{1L,1L,0x518CD5BFL,0xB81525DCL,(-1L)}};
            uint16_t l_1583 = 1UL;
            int i, j;
            for (l_1474 = 0; (l_1474 <= 0); l_1474 += 1)
            { /* block id: 683 */
                union U0 **l_1571 = &l_1525;
                uint32_t *l_1575 = &g_569;
                int i;
                g_1566--;
                (*l_1346) |= (safe_add_func_int16_t_s_s(g_643[l_1474], (l_1571 == l_1564)));
                (*l_1348) = (safe_lshift_func_uint16_t_u_s((((g_643[l_1474] == (((g_1261 <= (!g_643[l_1474])) && (((***p_32) <= (((*l_1575) = 0UL) , (l_1576[3][1] != (*g_820)))) < ((0x161A6FCAL > (p_33 ^ (***p_32))) == g_1577))) ^ p_34)) < p_33) <= p_34), g_1482.f0));
            }
            ++l_1583;
            return g_1586;
        }
    }
    return (*p_32);
}


/* ------------------------------------------ */
/* 
 * reads : g_400 g_100
 * writes:
 */
static const uint16_t  func_39(int32_t ** const * p_40, int32_t ** p_41, int32_t ** p_42, int32_t * const  p_43)
{ /* block id: 276 */
    uint64_t l_681 = 0xE4729DD162A96BCCLL;
    int32_t l_682 = 0x8CCFDC70L;
    int64_t *l_695 = &g_273;
    int64_t * const *l_694 = &l_695;
    int32_t l_715 = (-7L);
    int32_t l_718 = 0x9F1C370DL;
    int32_t l_767 = 0xB9EC3015L;
    int32_t l_772 = (-1L);
    int32_t l_780 = (-9L);
    int32_t l_781 = 1L;
    int32_t l_783 = 0L;
    int32_t l_788 = 1L;
    int32_t l_789[8][10][3] = {{{1L,0xAE87DF19L,0x05E87838L},{0L,0xC582B829L,0x46327EBEL},{1L,0L,0x36E22101L},{0x6C2AB61DL,1L,0L},{0x6481E8A3L,(-1L),1L},{(-8L),1L,(-6L)},{0x36E22101L,(-1L),0xAFB80606L},{0xBDEA25EDL,1L,0x219C14A9L},{(-1L),0L,0x25B1F392L},{0L,0xC582B829L,(-1L)}},{{0x25B1F392L,0xAE87DF19L,0x25B1F392L},{0x29E531C1L,1L,0x219C14A9L},{0xFD6E282FL,2L,0xAFB80606L},{0x46327EBEL,9L,(-6L)},{0x2FD63969L,0x1D8B8C13L,1L},{0x46327EBEL,0xBC0426B4L,0L},{0xFD6E282FL,0x949C5FF1L,0x36E22101L},{0x29E531C1L,(-9L),0x46327EBEL},{0x25B1F392L,0x8FDFED9DL,0x05E87838L},{0L,(-9L),0L}},{{(-1L),0x949C5FF1L,(-2L)},{0xBDEA25EDL,0xBC0426B4L,(-8L)},{0x36E22101L,0x1D8B8C13L,1L},{(-8L),9L,(-8L)},{0x6481E8A3L,2L,(-2L)},{0x6C2AB61DL,1L,0xC786C021L},{1L,0x6481E8A3L,(-5L)},{0x02E4C33DL,0L,(-1L)},{1L,(-2L),0xE2A7D0F0L},{0L,0x46327EBEL,0x1B060E08L}},{{0xD66B01D8L,0xAFB80606L,1L},{(-1L),0xBDEA25EDL,(-1L)},{0xE2A7D0F0L,0xAFB80606L,7L},{0xB6793769L,0x46327EBEL,0x99DE2F47L},{0xC6B2DD73L,(-2L),0x70A836E0L},{0x1B060E08L,0L,0L},{0x70A836E0L,0x6481E8A3L,0x70A836E0L},{0x80A07120L,0x64B418ACL,0x99DE2F47L},{0L,0x5C9EBB5DL,7L},{(-1L),0x29E531C1L,(-1L)}},{{(-5L),0x2FD63969L,1L},{(-1L),0x219C14A9L,0x1B060E08L},{0L,1L,0xE2A7D0F0L},{0x80A07120L,0L,(-1L)},{0x70A836E0L,(-1L),(-5L)},{0x1B060E08L,0L,0xC786C021L},{0xC6B2DD73L,1L,(-6L)},{0xB6793769L,0x219C14A9L,(-1L)},{0xE2A7D0F0L,0x2FD63969L,(-1L)},{(-1L),0x29E531C1L,(-1L)}},{{0xD66B01D8L,0x5C9EBB5DL,(-6L)},{0L,0x64B418ACL,0xC786C021L},{1L,0x6481E8A3L,(-5L)},{0x02E4C33DL,0L,(-1L)},{1L,(-2L),0xE2A7D0F0L},{0L,0x46327EBEL,0x1B060E08L},{0xD66B01D8L,0xAFB80606L,1L},{(-1L),0xBDEA25EDL,(-1L)},{0xE2A7D0F0L,0xAFB80606L,7L},{0xB6793769L,0x46327EBEL,0x99DE2F47L}},{{0xC6B2DD73L,(-2L),0x70A836E0L},{0x1B060E08L,0L,0L},{0x70A836E0L,0x6481E8A3L,0x70A836E0L},{0x80A07120L,0x64B418ACL,0x99DE2F47L},{0L,0x5C9EBB5DL,7L},{(-1L),0x29E531C1L,(-1L)},{(-5L),0x2FD63969L,1L},{(-1L),0x219C14A9L,0x1B060E08L},{0L,1L,0xE2A7D0F0L},{0x80A07120L,0L,(-1L)}},{{0x70A836E0L,(-1L),(-5L)},{0x1B060E08L,0L,0xC786C021L},{0xC6B2DD73L,1L,(-6L)},{0xB6793769L,0x219C14A9L,(-1L)},{0xE2A7D0F0L,0x2FD63969L,(-1L)},{(-1L),0x29E531C1L,(-1L)},{0xD66B01D8L,0x5C9EBB5DL,(-6L)},{0L,0x64B418ACL,0xC786C021L},{1L,0x6481E8A3L,(-5L)},{0x02E4C33DL,0L,(-1L)}}};
    uint16_t **l_828 = &g_400;
    uint16_t ***l_827[9] = {&l_828,&l_828,&l_828,&l_828,&l_828,&l_828,&l_828,&l_828,&l_828};
    int32_t *l_833[7] = {&l_682,&l_788,&l_682,&l_682,&l_788,&l_682,&l_682};
    int64_t l_852 = 0x33E2E208579C75A1LL;
    union U0 *l_876[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_883 = 6L;
    uint32_t l_961 = 0x3DF6430FL;
    int64_t l_965 = 6L;
    int16_t l_966 = 0x5F20L;
    int32_t l_967 = (-10L);
    union U0 **l_1015 = (void*)0;
    uint8_t l_1082[10] = {255UL,250UL,250UL,0x7FL,250UL,250UL,0x7FL,250UL,250UL,0x7FL};
    int32_t ***l_1106[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t ****l_1105 = &l_1106[7];
    int32_t **** const *l_1104 = &l_1105;
    int32_t *l_1111 = (void*)0;
    int64_t l_1138 = 0L;
    uint32_t ** const l_1243 = &g_843;
    uint16_t l_1249 = 0UL;
    uint32_t *l_1260 = &l_961;
    int32_t l_1262 = 1L;
    int8_t l_1288 = 0xB5L;
    int i, j, k;
    return (*g_400);
}


/* ------------------------------------------ */
/* 
 * reads : g_633 g_625 g_399 g_400 g_100 g_23.f1 g_643 g_469 g_14 g_646 g_106 g_498 g_633.f0 g_642 g_201 g_23.f2 g_662 g_225 g_294
 * writes: g_100 g_642 g_643 g_62 g_275 g_14 g_677
 */
static int32_t ** func_46(uint32_t  p_47)
{ /* block id: 256 */
    uint32_t l_628[3][8][4] = {{{0x370E0857L,0x807AE015L,0xB43416FDL,4294967295UL},{4294967292UL,0x370E0857L,0xCF40CAFBL,0x807AE015L},{0x359BA629L,6UL,0xCF40CAFBL,0x01C85804L},{4294967292UL,0xB43416FDL,0xB43416FDL,4294967292UL},{0x370E0857L,0x359BA629L,4294967288UL,0UL},{4294967288UL,0UL,0x807AE015L,6UL},{0xD998E924L,4UL,4294967293UL,6UL},{4294967295UL,0UL,0xD998E924L,0UL}},{{0xA0F5F9D2L,0x359BA629L,4294967295UL,4294967292UL},{0x807AE015L,0xB43416FDL,4294967295UL,0x01C85804L},{4UL,6UL,0x01C85804L,0x807AE015L},{4UL,0x370E0857L,4294967295UL,4294967295UL},{0x807AE015L,0x807AE015L,4294967295UL,0xCF40CAFBL},{0xA0F5F9D2L,4294967295UL,0xD998E924L,0x359BA629L},{4294967295UL,4294967288UL,4294967293UL,0xD998E924L},{0xD998E924L,4294967288UL,0x807AE015L,0x359BA629L}},{{4294967288UL,4294967295UL,4294967288UL,0xCF40CAFBL},{0x370E0857L,0x807AE015L,0xB43416FDL,4294967295UL},{4294967292UL,0x370E0857L,0xCF40CAFBL,0x807AE015L},{0x359BA629L,6UL,0xCF40CAFBL,0x01C85804L},{4294967292UL,0xB43416FDL,0xB43416FDL,4294967292UL},{0x370E0857L,0x359BA629L,4294967288UL,0UL},{4294967288UL,0UL,0x807AE015L,6UL},{0xD998E924L,4UL,4294967293UL,6UL}}};
    int32_t l_638[9][1];
    uint8_t l_670 = 0x3FL;
    int32_t *** const l_674 = &g_453[0][5][0];
    int8_t l_675 = 0x9AL;
    int8_t *l_676 = &l_675;
    int32_t *l_678[2][3][3] = {{{(void*)0,&l_638[4][0],(void*)0},{(void*)0,&l_638[4][0],(void*)0},{(void*)0,&l_638[4][0],(void*)0}},{{(void*)0,&l_638[4][0],(void*)0},{(void*)0,&l_638[4][0],(void*)0},{(void*)0,&l_638[4][0],(void*)0}}};
    uint32_t l_679 = 4294967289UL;
    int i, j, k;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
            l_638[i][j] = (-1L);
    }
    if (p_47)
    { /* block id: 257 */
        int32_t ***l_637 = &g_408;
        int32_t ****l_636[4];
        int16_t l_641 = 1L;
        int i;
        for (i = 0; i < 4; i++)
            l_636[i] = &l_637;
        l_628[2][4][2]++;
        g_642[2] = ((safe_rshift_func_int8_t_s_s(((g_633 , ((((**g_399) |= (safe_rshift_func_uint8_t_u_u(((void*)0 == l_636[2]), ((-4L) & (((l_628[0][7][0] & l_638[4][0]) ^ (0xDC0E0E50L | (safe_add_func_int8_t_s_s((-7L), (l_638[2][0] , 0x42L))))) ^ g_625))))) != 0x6677L) , 0x09022BF3L)) , 0xBDL), l_641)) || g_23.f1);
        ++g_643[0];
    }
    else
    { /* block id: 262 */
        uint8_t *l_649 = (void*)0;
        uint8_t *l_650 = &g_62;
        int32_t *l_661 = &g_642[2];
        (*g_646) = (*g_469);
        (*g_662) = (safe_lshift_func_uint16_t_u_u(((*g_400) = (((0xE1L > (((*l_650) = g_106) < (((safe_div_func_int64_t_s_s((safe_mul_func_int16_t_s_s((9L >= ((((safe_rshift_func_uint8_t_u_u((l_638[2][0] = g_498), (safe_lshift_func_uint8_t_u_u((g_275 = (((*l_661) ^= ((safe_lshift_func_uint16_t_u_u((**g_399), 4)) != g_633.f0)) <= ((l_628[2][4][2] | l_628[2][4][2]) || p_47))), p_47)))) ^ g_106) != 0x7B6B1C39990502B6LL) | g_201)), 0x312BL)), g_23.f2)) , l_628[2][4][2]) , 0x66L))) >= l_628[2][4][2]) != 0L)), l_628[1][0][0]));
    }
    l_679 = (g_14 , ((*g_662) = (g_677 = ((+(safe_div_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u((((safe_div_func_uint8_t_u_u(g_225[0], ((*l_676) = (l_670 ^ (((!l_628[0][5][0]) , g_294) , ((safe_sub_func_int32_t_s_s(p_47, ((void*)0 != l_674))) >= l_675)))))) ^ 4294967295UL) , g_642[0]), 11)) != g_625), p_47))) < 7UL))));
    return &g_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_183 g_23.f1 g_429 g_409 g_3 g_2 g_225 g_106 g_339 g_242 g_554 g_275 g_399 g_400 g_100 g_23.f0 g_201 g_294 g_569 g_498 g_44 g_453 g_598 g_62 g_229 g_469 g_227
 * writes: g_62 g_489 g_275 g_339 g_201 g_400 g_498 g_45 g_227 g_569
 */
static int32_t  func_48(int32_t *** p_49, const int16_t  p_50)
{ /* block id: 183 */
    uint16_t **l_472[4] = {&g_400,&g_400,&g_400,&g_400};
    uint16_t ***l_473 = &l_472[2];
    int32_t l_483 = (-1L);
    uint8_t *l_484 = &g_62;
    int32_t ** const *l_486 = &g_44;
    int32_t ** const **l_485 = &l_486;
    int32_t ** const ***l_487 = (void*)0;
    int32_t ** const ***l_488[1][3];
    uint8_t *l_490 = &g_275;
    uint64_t l_491 = 0x1099014910825B07LL;
    int16_t l_497 = 0L;
    uint32_t l_501 = 0UL;
    int8_t l_518[8][5][6] = {{{0x47L,0x43L,0xE7L,0x0AL,0xCBL,0L},{0L,2L,0x07L,5L,9L,9L},{0x0FL,(-3L),(-3L),0x0FL,1L,1L},{0x89L,0x07L,0x40L,0x26L,0x53L,(-9L)},{0x3DL,0L,0L,0x85L,0x53L,(-9L)}},{{0x18L,0x07L,7L,0xCFL,1L,0x79L},{(-6L),(-3L),1L,0x91L,9L,0x3DL},{0x5CL,2L,0x18L,(-1L),0xCBL,0x14L},{0xC5L,0x43L,0x5CL,0x66L,8L,0xC5L},{0x60L,2L,0x89L,(-10L),0x14L,5L}},{{0x92L,0L,(-4L),1L,0xD6L,0x64L},{2L,0x40L,1L,0x5CL,0x18L,0L},{1L,0x14L,0xF0L,7L,0x60L,0xF9L},{0x07L,0x60L,1L,0xF0L,3L,1L},{0x47L,0xC8L,0xC5L,(-9L),0x40L,0x79L}},{{0x14L,0x3DL,0xCBL,7L,(-9L),0x92L},{0x00L,0x40L,(-9L),0xFDL,0x3EL,0xC8L},{6L,0x0BL,0x64L,0xE7L,0x3DL,0xE7L},{(-4L),1L,(-4L),0x89L,1L,0x85L},{0x63L,5L,0xC5L,2L,1L,0x18L}},{{(-1L),(-1L),(-10L),2L,0xADL,0x89L},{0x63L,0xF0L,(-5L),0x89L,0x00L,0L},{(-4L),(-1L),0x18L,0xE7L,(-4L),0x76L},{6L,0xD6L,0xB5L,0xFDL,0x5CL,0x0AL},{0x00L,(-3L),0x89L,7L,0x0BL,0x53L}},{{0x14L,(-6L),(-1L),(-9L),0xADL,3L},{0x47L,0xC5L,0x07L,0xF0L,0x91L,0L},{0x07L,1L,0x0FL,7L,0L,0x07L},{1L,1L,0xF9L,0x5CL,0x14L,0x0AL},{2L,0x00L,0x14L,1L,(-9L),0x26L}},{{0x92L,0x60L,1L,(-10L),(-9L),0x40L},{0x91L,0x14L,(-5L),0x0FL,0L,0x63L},{0x07L,6L,0x5CL,0x70L,(-1L),1L},{7L,0x60L,0x85L,0x40L,0x40L,0x85L},{0L,0L,6L,7L,0x18L,2L}},{{0x0BL,0x60L,(-9L),0xB0L,0xD6L,6L},{0L,0x0BL,(-9L),0x92L,0L,2L},{(-4L),0x92L,6L,0xF9L,0L,0x85L},{0xF9L,0L,0x85L,(-9L),1L,1L},{(-3L),0x79L,0x5CL,2L,0x89L,0x63L}}};
    uint8_t l_521 = 5UL;
    int32_t *l_624[4] = {&g_625,&g_625,&g_625,&g_625};
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_488[i][j] = (void*)0;
    }
    if ((g_183[3] , (+(1UL ^ ((((*l_473) = l_472[2]) == ((l_491 |= (!(p_50 | ((3UL && (safe_sub_func_uint8_t_u_u((g_23.f1 , ((*l_490) = (safe_sub_func_int32_t_s_s((safe_div_func_int16_t_s_s((safe_mod_func_int64_t_s_s(((&g_19[1][3] == (g_489 = (((*l_484) = l_483) , l_485))) ^ 0L), g_429)), p_50)), (*g_409))))), g_2))) && g_225[6])))) , &g_400)) < p_50)))))
    { /* block id: 189 */
        int8_t l_492 = (-1L);
        int32_t l_494 = 0xDE434C83L;
        int32_t l_495 = 0xAAE100CFL;
        int32_t l_496[5] = {0x389F4B7CL,0x389F4B7CL,0x389F4B7CL,0x389F4B7CL,0x389F4B7CL};
        int32_t l_499 = 0xABB5BDF2L;
        int8_t l_500 = 0xF7L;
        uint32_t l_504 = 0UL;
        uint64_t *l_512 = &g_339;
        int32_t *l_513 = (void*)0;
        int32_t *l_514 = &l_499;
        int16_t *l_515 = &g_201;
        int32_t l_522 = 0xD5340A89L;
        uint16_t l_535 = 0xA089L;
        int32_t l_564 = 2L;
        int64_t *l_579 = (void*)0;
        int32_t ***l_623 = &g_453[0][5][0];
        int32_t ****l_622 = &l_623;
        uint64_t l_626[3][5][5];
        int i, j, k;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 5; j++)
            {
                for (k = 0; k < 5; k++)
                    l_626[i][j][k] = 1UL;
            }
        }
lbl_617:
        l_501++;
        l_504++;
        if ((safe_mod_func_uint32_t_u_u((0UL < (((*l_515) = (~(((*l_514) |= (safe_div_func_int64_t_s_s(1L, ((*l_512) |= g_106)))) , ((p_50 | p_50) & g_242)))) > (p_50 < (safe_div_func_uint16_t_u_u(((void*)0 == &p_49), l_494))))), l_518[6][1][1])))
        { /* block id: 195 */
            l_521 |= (safe_rshift_func_uint16_t_u_s(65535UL, 4));
        }
        else
        { /* block id: 197 */
            int8_t l_536 = 0x81L;
            uint16_t *l_555 = &g_100;
            int32_t l_556 = 0x72530C57L;
            int64_t l_568 = 0xE3017173AD7C5E2DLL;
            int32_t l_572[2][3][2] = {{{(-8L),(-8L)},{4L,(-8L)},{(-8L),4L}},{{(-8L),(-8L)},{4L,(-8L)},{(-8L),4L}}};
            int32_t *l_582 = &l_556;
            uint16_t l_588 = 65526UL;
            int32_t *l_621 = &g_14;
            int i, j, k;
            l_522 &= l_496[3];
            if (l_496[2])
            { /* block id: 199 */
                uint32_t *l_543 = &l_501;
                int32_t l_559 = 0xF6F3142EL;
                uint16_t *l_570 = &g_429;
                int64_t *l_575 = (void*)0;
                int32_t l_587[10] = {0x5C492B61L,0x5C492B61L,(-1L),0x5C492B61L,0x5C492B61L,(-1L),0x5C492B61L,0x5C492B61L,(-1L),0x5C492B61L};
                uint16_t * const l_613 = &g_614;
                uint16_t * const *l_612 = &l_613;
                uint16_t * const **l_611 = &l_612;
                int i;
                if ((safe_sub_func_int32_t_s_s((safe_add_func_uint32_t_u_u(((p_50 >= (((safe_lshift_func_uint16_t_u_s(((safe_add_func_uint32_t_u_u((safe_sub_func_int32_t_s_s(0xE4577FE7L, (l_535 < l_536))), (l_556 = ((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s(p_50, (p_50 && ((safe_rshift_func_int16_t_s_s((((p_50 >= ((*l_543)++)) && (safe_div_func_uint16_t_u_u((!(safe_add_func_int16_t_s_s(((*l_515) ^= ((safe_sub_func_uint16_t_u_u(((&l_535 == (((+((g_554[0] , 0L) | (-1L))) ^ g_275) , l_555)) , 0x8D11L), (**g_399))) && g_23.f0)), (*g_400)))), (**g_399)))) < (-10L)), 5)) , l_536)))), 7)) >= l_535)))) && 0L), p_50)) , &g_294) == (void*)0)) || g_294), 0xCA27DCEEL)), g_275)))
                { /* block id: 203 */
                    uint32_t l_567[3];
                    int16_t *l_571 = &g_498;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_567[i] = 0xDD4068BBL;
                    l_572[1][2][1] = (safe_rshift_func_int16_t_s_s(((*l_571) ^= (l_536 != (l_559 ^ (((**l_473) = l_555) == ((safe_rshift_func_int16_t_s_u((safe_sub_func_uint32_t_u_u((l_556 , (((p_50 ^ ((-6L) <= l_564)) && ((safe_rshift_func_int16_t_s_s(((0x7950E477L ^ (l_567[2] || p_50)) & 1L), l_568)) , p_50)) <= g_569)), g_201)), l_568)) , l_570))))), 3));
                }
                else
                { /* block id: 207 */
                    uint64_t l_580 = 0x2F9BF05AA96F9A89LL;
                    for (l_483 = 0; (l_483 < (-1)); l_483 = safe_sub_func_uint16_t_u_u(l_483, 6))
                    { /* block id: 210 */
                        int64_t **l_576 = (void*)0;
                        int64_t *l_578 = &l_568;
                        int64_t **l_577[6][5] = {{&l_578,&l_578,&l_575,&l_578,&l_575},{&l_578,&l_578,&l_578,&l_578,&l_578},{(void*)0,&l_578,&l_575,&l_575,&l_578},{&l_578,&l_578,(void*)0,&l_578,&l_575},{&l_578,&l_578,&l_578,&l_578,&l_578},{(void*)0,&l_578,&l_578,&l_575,&l_578}};
                        int32_t l_581 = 0xACB93179L;
                        int i, j;
                        l_559 ^= (l_575 != (l_579 = l_512));
                        l_581 &= (l_580 , l_572[0][1][0]);
                        (**p_49) = l_582;
                    }
                }
                for (l_491 = 8; (l_491 < 31); ++l_491)
                { /* block id: 219 */
                    int16_t l_585 = 0x7FF4L;
                    int32_t l_586[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_586[i] = 0x5EC1ACBAL;
                    --l_588;
                    (*l_582) = (!l_504);
                    for (g_227 = 12; (g_227 < 11); g_227 = safe_sub_func_uint64_t_u_u(g_227, 1))
                    { /* block id: 224 */
                        int32_t l_596 = 3L;
                        const uint16_t * const **l_599[4][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
                        int i, j;
                        (*l_582) = (safe_add_func_int16_t_s_s(l_596, (~(g_598 , ((void*)0 != l_599[1][0])))));
                        (*l_582) = (safe_add_func_int64_t_s_s((-8L), (safe_mul_func_uint16_t_u_u((g_62 , (safe_unary_minus_func_int32_t_s(p_50))), p_50))));
                        (*l_582) = l_559;
                    }
                }
                l_522 = (4294967295UL == (3UL > (safe_add_func_uint16_t_u_u((((((void*)0 == &g_225[0]) < p_50) | (((safe_rshift_func_int8_t_s_s((l_587[2] != (((*l_611) = &g_400) != &l_555)), 3)) | p_50) , l_559)) || g_225[0]), 3UL))));
            }
            else
            { /* block id: 232 */
                for (l_499 = 0; (l_499 >= 1); l_499++)
                { /* block id: 235 */
                    uint32_t l_618 = 1UL;
                    for (l_504 = 0; (l_504 <= 1); l_504 += 1)
                    { /* block id: 238 */
                        if (g_100)
                            goto lbl_617;
                    }
                    for (g_569 = 0; (g_569 <= 4); g_569 += 1)
                    { /* block id: 243 */
                        int i;
                        (*g_44) = &l_494;
                        --l_618;
                    }
                    l_621 = &l_556;
                }
            }
        }
        l_626[2][0][0] &= (p_50 <= (g_229 & ((((void*)0 == l_622) < (p_50 , p_50)) & (((void*)0 == &l_501) & (g_469 != l_624[3])))));
    }
    else
    { /* block id: 252 */
        uint16_t l_627[8][10][3] = {{{65535UL,0xE1E2L,0xDFFBL},{65527UL,65535UL,0xDFFBL},{65526UL,0xDFFBL,65535UL},{0x3DCBL,3UL,4UL},{0xDFFBL,0xDFFBL,3UL},{4UL,65535UL,0x0C56L},{4UL,0xE1E2L,0x3DCBL},{0xDFFBL,65535UL,65535UL},{0x3DCBL,4UL,0x3DCBL},{65526UL,0UL,0x0C56L}},{{65527UL,0UL,3UL},{65535UL,4UL,4UL},{5UL,65535UL,65535UL},{65535UL,0xE1E2L,0xDFFBL},{65527UL,65535UL,0xDFFBL},{65526UL,0xDFFBL,65535UL},{0x3DCBL,3UL,4UL},{0xDFFBL,0xDFFBL,3UL},{4UL,65535UL,0x0C56L},{4UL,0xE1E2L,0x3DCBL}},{{0xDFFBL,65535UL,65535UL},{0x3DCBL,4UL,0x3DCBL},{65526UL,0UL,0x0C56L},{65527UL,0UL,3UL},{65535UL,4UL,4UL},{5UL,65535UL,65535UL},{65535UL,0xE1E2L,0xDFFBL},{65527UL,65535UL,0xDFFBL},{65526UL,0xDFFBL,65535UL},{0x3DCBL,3UL,4UL}},{{0xDFFBL,0xDFFBL,3UL},{4UL,65535UL,0x0C56L},{4UL,0xE1E2L,0x3DCBL},{0xDFFBL,65535UL,65535UL},{0x3DCBL,4UL,0x3DCBL},{65526UL,0UL,0x0C56L},{65527UL,0UL,3UL},{65535UL,4UL,4UL},{5UL,65535UL,65535UL},{65535UL,0xE1E2L,0xDFFBL}},{{65527UL,65535UL,0xDFFBL},{65526UL,0xDFFBL,65535UL},{0x3DCBL,3UL,4UL},{0xDFFBL,0xDFFBL,3UL},{65526UL,65535UL,4UL},{65526UL,0x0C56L,65535UL},{3UL,5UL,65535UL},{65535UL,65526UL,65535UL},{0UL,0xE1E2L,4UL},{0x3DCBL,0xE1E2L,4UL}},{{5UL,65526UL,65527UL},{0xDFFBL,5UL,5UL},{5UL,0x0C56L,3UL},{0x3DCBL,65535UL,3UL},{0UL,3UL,5UL},{65535UL,4UL,65527UL},{3UL,3UL,4UL},{65526UL,65535UL,4UL},{65526UL,0x0C56L,65535UL},{3UL,5UL,65535UL}},{{65535UL,65526UL,65535UL},{0UL,0xE1E2L,4UL},{0x3DCBL,0xE1E2L,4UL},{5UL,65526UL,65527UL},{0xDFFBL,5UL,5UL},{5UL,0x0C56L,3UL},{0x3DCBL,65535UL,3UL},{0UL,3UL,5UL},{65535UL,4UL,65527UL},{3UL,3UL,4UL}},{{65526UL,65535UL,4UL},{65526UL,0x0C56L,65535UL},{3UL,5UL,65535UL},{65535UL,65526UL,65535UL},{0UL,0xE1E2L,4UL},{0x3DCBL,0xE1E2L,4UL},{5UL,65526UL,65527UL},{0xDFFBL,5UL,5UL},{5UL,0x0C56L,3UL},{0x3DCBL,65535UL,3UL}}};
        int i, j, k;
        return l_627[1][7][0];
    }
    return p_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_227 g_229 g_183 g_3 g_44 g_469
 * writes: g_45 g_14
 */
static int32_t *** func_51(int32_t ** p_52, uint64_t  p_53, int64_t  p_54, int32_t * const ** p_55)
{ /* block id: 171 */
    uint16_t l_456 = 0xC3C3L;
    int8_t * const l_466 = &g_242;
    int32_t ***l_470 = &g_453[0][0][1];
    if (((safe_sub_func_int8_t_s_s((((l_456 == l_456) ^ (safe_mod_func_uint16_t_u_u(((~(safe_div_func_uint64_t_u_u(g_227, g_229))) <= (safe_sub_func_uint32_t_u_u(((l_466 != l_466) >= (&p_54 != &g_273)), (g_183[5] , 0x22CC2BB6L)))), l_456))) & p_53), l_456)) | (***p_55)))
    { /* block id: 172 */
        uint16_t **l_467 = &g_400;
        if ((l_467 != (void*)0))
        { /* block id: 173 */
            int32_t *l_468 = &g_3;
            (*g_44) = l_468;
            (*g_469) = ((*l_468) && 1UL);
            return l_470;
        }
        else
        { /* block id: 177 */
            return &g_453[3][0][0];
        }
    }
    else
    { /* block id: 180 */
        return &g_44;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_271 g_14 g_399 g_400 g_23 g_409 g_3 g_270 g_100 g_429 g_44 g_23.f0 g_62 g_23.f1 g_45
 * writes: g_271 g_275 g_45 g_225 g_227 g_62 g_14
 */
static int32_t ** func_56(int32_t ** p_57, int64_t  p_58)
{ /* block id: 160 */
    int32_t l_410 = 0L;
    uint64_t *l_413 = &g_271;
    uint16_t *l_422 = &g_100;
    uint8_t *l_430[8];
    int32_t l_431 = 6L;
    int64_t l_438 = (-1L);
    uint32_t l_439[6][4][1] = {{{0x801DBF34L},{0xA28457B6L},{0UL},{0UL}},{{0xE7F411A9L},{0xA598A385L},{0xE7F411A9L},{0UL}},{{0UL},{0xA28457B6L},{0x801DBF34L},{0xA28457B6L}},{{0UL},{0UL},{0xE7F411A9L},{0xA598A385L}},{{0xE7F411A9L},{0UL},{0UL},{0xA28457B6L}},{{0x801DBF34L},{0xA28457B6L},{0UL},{0UL}}};
    int16_t *l_447 = &g_225[0];
    int16_t *l_448 = &g_227;
    int32_t *l_451 = &l_410;
    int32_t *l_452 = &g_14;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_430[i] = &g_275;
    l_431 = (l_410 == (((safe_add_func_uint64_t_u_u(((*l_413)--), (((g_275 = (safe_sub_func_int16_t_s_s(((g_14 == (safe_rshift_func_int8_t_s_u(((18446744073709551615UL || 0UL) | (safe_mul_func_int16_t_s_s((((*g_399) == (p_58 , l_422)) == (safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint32_t_u_u(((((safe_add_func_uint16_t_u_u((g_23 , (0x76E1L | p_58)), (-10L))) , 0xE9846308EB30CCE4LL) & 0UL) , 1UL), (*g_409))) , 0x0489L), g_270))), (*g_400)))), 5))) == g_429), 0x7352L))) <= l_410) <= p_58))) & l_410) , g_429));
    (*g_44) = &l_431;
    (*l_452) ^= (((*l_451) = (safe_lshift_func_int8_t_s_u(((safe_mod_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_s((**g_399), 2)) & l_438), l_439[0][1][0])) , 0x5AL), (safe_div_func_int8_t_s_s(((safe_mod_func_int64_t_s_s((!((safe_mul_func_int8_t_s_s(((((*l_448) = ((*l_447) = 1L)) && l_439[1][3][0]) , g_23.f0), ((0x4EL > (g_62++)) ^ l_439[0][1][0]))) , l_439[0][1][0])), g_23.f1)) | 0x0CA8L), l_439[2][3][0]))))) , (**g_44));
    return &g_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_23.f1 g_96 g_14 g_100 g_62 g_106 g_44 g_45 g_3 g_23.f2 g_229 g_242 g_275 g_273 g_339 g_225 g_347 g_227 g_294 g_271 g_201 g_399 g_185 g_183.f0 g_400
 * writes: g_23.f1 g_100 g_106 g_45 g_62 g_229 g_275 g_273 g_339 g_227 g_242 g_14
 */
static int32_t ** func_59(uint8_t  p_60)
{ /* block id: 23 */
    uint64_t l_85 = 0x0190438315EAC84CLL;
    int64_t l_95 = 0xF4D80A992350C165LL;
    uint64_t l_101 = 18446744073709551615UL;
    int32_t *l_107[8][7][1] = {{{(void*)0},{&g_14},{(void*)0},{(void*)0},{&g_106},{&g_14},{(void*)0}},{{&g_14},{&g_106},{(void*)0},{(void*)0},{&g_14},{(void*)0},{(void*)0}},{{&g_106},{&g_14},{(void*)0},{&g_14},{&g_106},{(void*)0},{(void*)0}},{{&g_14},{(void*)0},{(void*)0},{&g_106},{&g_14},{(void*)0},{&g_14}},{{&g_106},{(void*)0},{(void*)0},{&g_14},{(void*)0},{(void*)0},{&g_106}},{{&g_14},{(void*)0},{&g_14},{&g_106},{(void*)0},{(void*)0},{&g_14}},{{(void*)0},{(void*)0},{&g_106},{&g_14},{(void*)0},{&g_14},{&g_106}},{{(void*)0},{(void*)0},{&g_14},{(void*)0},{(void*)0},{&g_106},{&g_14}}};
    int32_t **l_109 = &l_107[7][1][0];
    uint16_t *l_118 = &g_100;
    uint16_t **l_119 = &l_118;
    uint16_t *l_121[8][3];
    uint16_t **l_120 = &l_121[5][2];
    uint64_t l_122 = 0xA0A6BD2E779239A8LL;
    uint8_t *l_123 = &g_62;
    int32_t l_124 = (-10L);
    uint64_t l_159 = 0xA6180E031660C04CLL;
    int32_t l_204 = (-1L);
    int32_t l_295 = 0x10FD701AL;
    const int32_t ***l_363 = (void*)0;
    const int32_t ****l_362 = &l_363;
    int i, j, k;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
            l_121[i][j] = &g_100;
    }
    for (g_23.f1 = (-16); (g_23.f1 <= 46); ++g_23.f1)
    { /* block id: 26 */
        uint32_t l_97[10] = {18446744073709551615UL,18446744073709551613UL,18446744073709551613UL,18446744073709551613UL,0xDCDB7A89L,18446744073709551615UL,0xDCDB7A89L,18446744073709551613UL,18446744073709551613UL,0xDCDB7A89L};
        int32_t **l_108 = &l_107[2][6][0];
        int i;
        if (p_60)
        { /* block id: 27 */
            int16_t l_71 = 0x1753L;
            uint64_t l_88 = 0x8EEB303A67D625C2LL;
            uint16_t *l_98 = (void*)0;
            uint16_t *l_99 = &g_100;
            int16_t l_102 = 5L;
            int32_t *l_104 = (void*)0;
            int32_t *l_105 = &g_106;
            (*l_105) ^= (safe_rshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((l_71 , func_72(&g_62, (((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((safe_div_func_int8_t_s_s(((safe_rshift_func_int8_t_s_s((((((safe_mul_func_uint16_t_u_u((l_85 > ((*l_99) &= ((safe_sub_func_int64_t_s_s((p_60 & l_88), (((safe_add_func_int64_t_s_s((((safe_div_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(l_95, g_96)), g_14)) , 0xB13E27C2130BEC3ALL) || 0x7DC0717824FFAD67LL), g_14)) || g_14) != 1L))) , l_97[0]))), g_14)) , 0L) , p_60) <= l_97[0]) || l_101), l_88)) , g_96), l_102)), 0xEB37L)), l_97[0])) , 0xFFL) >= l_71))), 6)) == l_88), 0x21E6L)), 3));
            (*l_105) = p_60;
            (*g_44) = l_107[2][6][0];
        }
        else
        { /* block id: 35 */
            (*g_44) = l_107[2][6][0];
        }
        return &g_45;
    }
    l_124 &= ((safe_sub_func_int8_t_s_s(p_60, ((*l_123) = (safe_mul_func_int8_t_s_s((((safe_div_func_uint32_t_u_u(((safe_sub_func_int64_t_s_s(((((((((0xCD11DCE2L != p_60) == (((*l_120) = ((*l_119) = l_118)) != &g_100)) <= 0x1A5503930A17C058LL) , &l_107[2][6][0]) != (((*g_44) == ((*l_109) = (*l_109))) , &l_107[3][6][0])) ^ l_122) , &g_44) == &l_109), p_60)) , 0x7043423DL), (*g_45))) , (*l_119)) == &g_100), 2UL))))) , p_60);
    g_106 |= (safe_add_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(g_96, ((((safe_mul_func_int16_t_s_s(0x39A4L, (safe_add_func_int32_t_s_s((g_3 < ((((safe_sub_func_uint32_t_u_u((!((safe_mod_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((((!0x755A17A538DB7D61LL) , (safe_rshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((g_100 == (safe_mod_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((((*l_109) = (*l_109)) == (void*)0), g_14)), (safe_add_func_uint32_t_u_u((((+(safe_mul_func_uint16_t_u_u((safe_add_func_uint8_t_u_u(g_62, p_60)), (-6L)))) , (*l_120)) == (void*)0), g_23.f2))))), l_85)), 7))) < p_60), p_60)), p_60)), 0x9DL)) , p_60)), l_124)) ^ p_60) , 1L) , g_23.f2)), (**g_44))))) >= 0xA657C725L) , &g_62) == (void*)0))) ^ p_60), 0x86FB9873L));
    for (l_101 = 0; (l_101 <= 0); l_101 += 1)
    { /* block id: 49 */
        uint64_t l_168 = 1UL;
        int32_t **l_169 = &g_45;
        uint16_t l_188 = 0UL;
        int32_t l_243 = 0x889F0797L;
        uint32_t l_337 = 0xB864D201L;
        int32_t *l_380 = (void*)0;
        int32_t l_385 = 3L;
        for (l_85 = 0; (l_85 <= 0); l_85 += 1)
        { /* block id: 52 */
            int32_t *l_158 = (void*)0;
            int32_t l_186[9][5] = {{1L,1L,1L,1L,1L},{0L,0L,0L,0L,0L},{1L,1L,1L,1L,1L},{0L,0L,0L,0L,0L},{1L,1L,1L,1L,1L},{0L,0L,0L,0L,0L},{1L,1L,1L,1L,1L},{0L,0L,0L,0L,0L},{1L,1L,1L,1L,1L}};
            int64_t *l_223 = &l_95;
            int16_t *l_224 = &g_225[0];
            int16_t *l_226[5] = {&g_227,&g_227,&g_227,&g_227,&g_227};
            int64_t *l_228 = &g_229;
            const int32_t ***l_254 = &g_20[0][7];
            const int32_t ****l_253 = &l_254;
            int i, j;
        }
        g_106 = (safe_lshift_func_uint8_t_u_s(((**l_169) , 0x07L), 6));
        for (g_229 = 0; (g_229 >= 0); g_229 -= 1)
        { /* block id: 137 */
            int32_t l_320 = (-9L);
            uint8_t *l_321[8] = {&g_275,&g_275,&g_275,&g_275,&g_275,&g_275,&g_275,&g_275};
            uint64_t *l_322 = &l_122;
            int64_t *l_338 = &g_273;
            int i;
            if ((safe_lshift_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(0x01L, ((*l_123)++))), (p_60 |= l_320))) , (((*l_322) = g_242) | ((~((safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(p_60, (~p_60))), l_320)) >= (g_339 |= (l_320 == ((safe_sub_func_int32_t_s_s((((*l_338) ^= ((safe_rshift_func_int16_t_s_u((safe_add_func_int8_t_s_s((((g_275++) >= g_23.f2) == g_62), p_60)), l_337)) | p_60)) > p_60), p_60)) < 18446744073709551612UL))))) & l_320))), 3)))
            { /* block id: 144 */
                const uint32_t l_381 = 0x6B38B31FL;
                int64_t *l_382 = &l_95;
                int32_t l_383 = 0xBC428E57L;
                int32_t *l_384[10] = {&g_3,&g_3,&l_204,&g_3,&g_3,&l_204,&g_3,&g_3,&l_204,&g_3};
                int i;
                l_385 = (safe_lshift_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u(p_60, (safe_div_func_uint16_t_u_u((safe_unary_minus_func_uint64_t_u(g_225[0])), (g_347 , (((((safe_div_func_int16_t_s_s((**l_169), (safe_mul_func_uint8_t_u_u((l_383 &= ((safe_lshift_func_int8_t_s_u(((((safe_rshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u(p_60, (safe_mod_func_int64_t_s_s(((*l_382) &= ((safe_add_func_int64_t_s_s((((l_362 != (void*)0) >= (safe_mod_func_uint8_t_u_u(((((safe_add_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((((*l_338) &= ((safe_mod_func_int16_t_s_s((g_227 ^= ((p_60 == (((((safe_mul_func_uint8_t_u_u((g_275 = (safe_rshift_func_int8_t_s_s((((safe_sub_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u((((*l_109) = l_380) == &l_320), 0x65F758B0L)), g_23.f1)) != l_381) , p_60), p_60))), g_106)) != p_60) <= 1L) == 0xB768L) , p_60)) > 65526UL)), g_96)) && 0x40L)) >= 0xDACE0EACEF595A54LL), g_62)), g_106)) , l_107[5][6][0]) == (void*)0) > 0x589C4CF2L), 0xC8L))) ^ g_106), p_60)) <= p_60)), g_3)))), g_294)) < g_271) == p_60) & g_201), g_23.f1)) || p_60)), (-8L))))) && 0xD7730AE06191B933LL) <= (**l_169)) | 0L) ^ p_60)))))) & p_60), 5));
            }
            else
            { /* block id: 152 */
                int8_t *l_405 = (void*)0;
                int8_t *l_406 = &g_242;
                g_14 = (safe_div_func_uint16_t_u_u(((~(safe_add_func_uint32_t_u_u(((safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(3UL, 0)), ((*l_406) &= ((safe_add_func_int8_t_s_s((safe_mul_func_int64_t_s_s(6L, ((l_320 , g_399) == (void*)0))), ((l_320 && ((safe_lshift_func_int16_t_s_s(g_185, 8)) < p_60)) , (g_183[3].f0 != g_100)))) ^ p_60)))) , g_201), 4294967295UL))) , 0UL), (**g_399)));
            }
        }
    }
    return &g_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_62
 * writes:
 */
static const uint8_t  func_72(uint8_t * p_73, uint16_t  p_74)
{ /* block id: 29 */
    int32_t *l_103 = &g_14;
    l_103 = l_103;
    return (*p_73);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_23.f0, "g_23.f0", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_183[i].f0, "g_183[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_185, "g_185", print_hash_value);
    transparent_crc(g_201, "g_201", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_225[i], "g_225[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_227, "g_227", print_hash_value);
    transparent_crc(g_229, "g_229", print_hash_value);
    transparent_crc(g_242, "g_242", print_hash_value);
    transparent_crc(g_270, "g_270", print_hash_value);
    transparent_crc(g_271, "g_271", print_hash_value);
    transparent_crc(g_273, "g_273", print_hash_value);
    transparent_crc(g_275, "g_275", print_hash_value);
    transparent_crc(g_294, "g_294", print_hash_value);
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_347.f0, "g_347.f0", print_hash_value);
    transparent_crc(g_429, "g_429", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_493[i][j][k], "g_493[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_498, "g_498", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_554[i].f0, "g_554[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_569, "g_569", print_hash_value);
    transparent_crc(g_598.f0, "g_598.f0", print_hash_value);
    transparent_crc(g_614, "g_614", print_hash_value);
    transparent_crc(g_625, "g_625", print_hash_value);
    transparent_crc(g_633.f0, "g_633.f0", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_642[i], "g_642[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_643[i], "g_643[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_677, "g_677", print_hash_value);
    transparent_crc(g_709, "g_709", print_hash_value);
    transparent_crc(g_713, "g_713", print_hash_value);
    transparent_crc(g_769, "g_769", print_hash_value);
    transparent_crc(g_858, "g_858", print_hash_value);
    transparent_crc(g_894.f0, "g_894.f0", print_hash_value);
    transparent_crc(g_940.f0, "g_940.f0", print_hash_value);
    transparent_crc(g_947, "g_947", print_hash_value);
    transparent_crc(g_1113.f0, "g_1113.f0", print_hash_value);
    transparent_crc(g_1126, "g_1126", print_hash_value);
    transparent_crc(g_1261, "g_1261", print_hash_value);
    transparent_crc(g_1315, "g_1315", print_hash_value);
    transparent_crc(g_1351, "g_1351", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_1365[i][j][k], "g_1365[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1389, "g_1389", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1448[i][j], "g_1448[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1449, "g_1449", print_hash_value);
    transparent_crc(g_1450, "g_1450", print_hash_value);
    transparent_crc(g_1451, "g_1451", print_hash_value);
    transparent_crc(g_1452, "g_1452", print_hash_value);
    transparent_crc(g_1453, "g_1453", print_hash_value);
    transparent_crc(g_1454, "g_1454", print_hash_value);
    transparent_crc(g_1455, "g_1455", print_hash_value);
    transparent_crc(g_1456, "g_1456", print_hash_value);
    transparent_crc(g_1457, "g_1457", print_hash_value);
    transparent_crc(g_1458, "g_1458", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1459[i], "g_1459[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1460, "g_1460", print_hash_value);
    transparent_crc(g_1461, "g_1461", print_hash_value);
    transparent_crc(g_1462, "g_1462", print_hash_value);
    transparent_crc(g_1463, "g_1463", print_hash_value);
    transparent_crc(g_1464, "g_1464", print_hash_value);
    transparent_crc(g_1465, "g_1465", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1466[i], "g_1466[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1467, "g_1467", print_hash_value);
    transparent_crc(g_1468, "g_1468", print_hash_value);
    transparent_crc(g_1469, "g_1469", print_hash_value);
    transparent_crc(g_1470, "g_1470", print_hash_value);
    transparent_crc(g_1471, "g_1471", print_hash_value);
    transparent_crc(g_1472, "g_1472", print_hash_value);
    transparent_crc(g_1473, "g_1473", print_hash_value);
    transparent_crc(g_1482.f0, "g_1482.f0", print_hash_value);
    transparent_crc(g_1566, "g_1566", print_hash_value);
    transparent_crc(g_1577, "g_1577", print_hash_value);
    transparent_crc(g_1699.f0, "g_1699.f0", print_hash_value);
    transparent_crc(g_2025.f0, "g_2025.f0", print_hash_value);
    transparent_crc(g_2102.f0, "g_2102.f0", print_hash_value);
    transparent_crc(g_2146, "g_2146", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_2234[i][j][k].f0, "g_2234[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 556
XXX total union variables: 12

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 53
breakdown:
   depth: 1, occurrence: 134
   depth: 2, occurrence: 36
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 10, occurrence: 1
   depth: 14, occurrence: 3
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 24, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 2
   depth: 28, occurrence: 1
   depth: 32, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 41, occurrence: 1
   depth: 53, occurrence: 1

XXX total number of pointers: 439

XXX times a variable address is taken: 855
XXX times a pointer is dereferenced on RHS: 318
breakdown:
   depth: 1, occurrence: 190
   depth: 2, occurrence: 68
   depth: 3, occurrence: 59
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 308
breakdown:
   depth: 1, occurrence: 251
   depth: 2, occurrence: 40
   depth: 3, occurrence: 15
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 46
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 8617

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1340
   level: 2, occurrence: 634
   level: 3, occurrence: 330
   level: 4, occurrence: 59
   level: 5, occurrence: 20
   level: 6, occurrence: 4
XXX number of pointers point to pointers: 218
XXX number of pointers point to scalars: 211
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 24.1
XXX average alias set size: 1.46

XXX times a non-volatile is read: 1854
XXX times a non-volatile is write: 934
XXX times a volatile is read: 103
XXX    times read thru a pointer: 33
XXX times a volatile is write: 28
XXX    times written thru a pointer: 4
XXX times a volatile is available for access: 944
XXX percentage of non-volatile access: 95.5

XXX forward jumps: 2
XXX backward jumps: 9

XXX stmts: 135
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 27
   depth: 1, occurrence: 25
   depth: 2, occurrence: 21
   depth: 3, occurrence: 18
   depth: 4, occurrence: 20
   depth: 5, occurrence: 24

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
********************* end of statistics **********************/

