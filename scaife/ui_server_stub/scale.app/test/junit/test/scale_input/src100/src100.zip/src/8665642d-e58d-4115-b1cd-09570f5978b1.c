/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      393501265
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   signed f0 : 7;
   signed f1 : 2;
};

#pragma pack(push)
#pragma pack(1)
struct S1 {
   volatile int32_t  f0;
   int8_t  f1;
   const unsigned f2 : 30;
   signed f3 : 9;
   unsigned f4 : 28;
};
#pragma pack(pop)

struct S2 {
   int16_t  f0;
};

#pragma pack(push)
#pragma pack(1)
struct S3 {
   unsigned f0 : 18;
   signed f1 : 4;
};
#pragma pack(pop)

struct S4 {
   const volatile struct S0  f0;
   struct S1  f1;
   uint64_t  f2;
   uint32_t  f3;
   const uint64_t  f4;
   struct S0  f5;
   int32_t  f6;
   const signed f7 : 17;
   volatile int16_t  f8;
};

union U5 {
   int64_t  f0;
   const uint8_t  f1;
   volatile struct S2  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-6L);/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 1L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 0x3C576436L;
static int32_t g_41 = (-1L);
static int32_t g_63 = 0xA0B5BCDCL;
static int32_t g_67 = 7L;
static int32_t g_69 = 0L;
static int8_t g_78 = (-3L);
static int16_t g_79[8] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
static uint64_t g_80 = 9UL;
static int8_t g_83 = 2L;
static uint16_t g_84 = 0x4801L;
static int8_t g_89 = (-3L);
static uint32_t g_90 = 18446744073709551607UL;
static struct S3 g_106[7] = {{172,-2},{172,-2},{172,-2},{172,-2},{172,-2},{172,-2},{172,-2}};
static struct S2 g_110[7][1][5] = {{{{-7L},{0x00C1L},{0L},{0L},{0x00C1L}}},{{{0x00C1L},{0xF597L},{-7L},{0x00C1L},{0L}}},{{{-6L},{0x00C1L},{1L},{0x00C1L},{-6L}}},{{{-7L},{7L},{0xF597L},{0L},{7L}}},{{{-6L},{0xF597L},{0xF597L},{-6L},{0L}}},{{{0x00C1L},{-6L},{1L},{7L},{7L}}},{{{-7L},{0xF597L},{9L},{0L},{0xF597L}}}};
static volatile int32_t g_134[3][7] = {{(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)},{0xB9E8BD09L,0xB9E8BD09L,0xB9E8BD09L,0xB9E8BD09L,0xB9E8BD09L,0xB9E8BD09L,0xB9E8BD09L},{(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)}};
static volatile int32_t *g_133 = &g_134[2][3];
static volatile int32_t **g_132[6][3] = {{&g_133,(void*)0,&g_133},{&g_133,&g_133,(void*)0},{&g_133,&g_133,&g_133},{(void*)0,&g_133,&g_133},{&g_133,&g_133,&g_133},{(void*)0,(void*)0,&g_133}};
static volatile int32_t ***g_131 = &g_132[3][1];
static int32_t *g_137 = &g_41;
static uint8_t g_193 = 0x0CL;
static int16_t g_200 = (-2L);
static uint64_t g_202 = 1UL;
static uint32_t *g_297 = (void*)0;
static const int32_t *g_327 = &g_69;
static uint32_t g_339 = 1UL;
static int64_t g_349 = (-4L);
static uint64_t g_350 = 18446744073709551615UL;
static uint32_t g_398 = 4294967295UL;
static int8_t g_420 = 0xCFL;
static int64_t g_421 = 0x26D02A296EA8E698LL;
static uint32_t g_424 = 0UL;
static uint32_t g_440 = 0UL;
static int32_t g_482[9] = {1L,0x6785EDF3L,1L,0x6785EDF3L,1L,0x6785EDF3L,1L,0x6785EDF3L,1L};
static struct S0 g_501 = {1,1};
static struct S2 * volatile g_507[5] = {&g_110[3][0][0],&g_110[3][0][0],&g_110[3][0][0],&g_110[3][0][0],&g_110[3][0][0]};
static int32_t ** volatile g_510 = &g_137;/* VOLATILE GLOBAL g_510 */
static int32_t g_513[7] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
static volatile struct S4 g_524 = {{-0,-1},{0x79C11F94L,0xE6L,18344,-14,3132},0xAE19E3B03DF24FB6LL,0x1C540CA7L,0xB6F990EEE9AD6C5ELL,{-7,0},0x9C2B25C5L,-340,-1L};/* VOLATILE GLOBAL g_524 */
static uint64_t *g_531 = (void*)0;
static const int32_t **g_546 = &g_327;
static struct S1 g_579 = {-9L,3L,2313,10,13986};/* VOLATILE GLOBAL g_579 */
static int16_t *g_583 = (void*)0;
static int16_t *g_584 = &g_110[3][0][0].f0;
static volatile union U5 g_619[4] = {{0x3DA23F776579A3ABLL},{0x3DA23F776579A3ABLL},{0x3DA23F776579A3ABLL},{0x3DA23F776579A3ABLL}};
static volatile struct S0 * volatile g_620 = &g_524.f5;/* VOLATILE GLOBAL g_620 */
static volatile int8_t g_633 = 0L;/* VOLATILE GLOBAL g_633 */
static const union U5 g_641[2] = {{8L},{8L}};
static int64_t * const g_657 = (void*)0;
static int64_t * const *g_656[7] = {&g_657,&g_657,&g_657,&g_657,&g_657,&g_657,&g_657};
static int64_t g_660[2][6][1] = {{{7L},{7L},{7L},{7L},{7L},{7L}},{{7L},{7L},{7L},{7L},{7L},{7L}}};
static volatile union U5 *g_694 = &g_619[0];
static volatile union U5 ** volatile g_693 = &g_694;/* VOLATILE GLOBAL g_693 */
static struct S1 *g_697[6] = {&g_579,&g_579,&g_579,&g_579,&g_579,&g_579};
static struct S1 ** volatile g_696 = &g_697[2];/* VOLATILE GLOBAL g_696 */
static volatile uint32_t g_770 = 0xA1BE2086L;/* VOLATILE GLOBAL g_770 */
static uint8_t g_776 = 1UL;
static uint8_t g_836 = 0x27L;
static int64_t **g_876 = (void*)0;
static int64_t ***g_875 = &g_876;
static int64_t ***g_879 = &g_876;
static int64_t ***g_880 = &g_876;
static struct S3 *g_905 = (void*)0;
static struct S3 ** volatile g_904 = &g_905;/* VOLATILE GLOBAL g_904 */


/* --- FORWARD DECLARATIONS --- */
static struct S3  func_1(void);
static int64_t  func_8(int64_t  p_9, struct S3  p_10, uint32_t  p_11, int8_t  p_12);
static int16_t  func_18(uint8_t  p_19);
static struct S2  func_20(uint64_t  p_21, int64_t  p_22, int8_t  p_23, uint32_t  p_24);
static int64_t  func_25(int32_t  p_26);
static int32_t  func_27(uint64_t  p_28, uint16_t  p_29);
static int64_t  func_34(uint64_t  p_35);
static uint16_t  func_44(uint32_t  p_45, struct S2  p_46, int32_t * const  p_47, int32_t * p_48, uint8_t  p_49);
static struct S2  func_50(uint64_t  p_51, int32_t * p_52, struct S0  p_53, struct S3  p_54, uint16_t  p_55);
static int32_t  func_56(int32_t * p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes: g_5
 */
static struct S3  func_1(void)
{ /* block id: 0 */
    int8_t l_2[3][7][5] = {{{0x34L,(-1L),1L,0xB1L,(-8L)},{0L,0L,0L,0L,(-10L)},{0x34L,0x3EL,(-1L),(-1L),0xB1L},{0L,0xBDL,0L,0L,0L},{0x5BL,0x5BL,0xB1L,(-1L),(-1L)},{1L,0x11L,(-10L),0L,0L},{1L,0xB1L,(-8L),0xB1L,1L}},{{0xD7L,0x11L,(-9L),0x20L,0L},{(-1L),0x5BL,0x74L,0x3EL,0x3EL},{0x20L,0xBDL,0x20L,0x11L,0L},{0x02L,0x3EL,0x5BL,0xBFL,1L},{0L,0L,0xA5L,0xA5L,0L},{0x74L,(-1L),0x5BL,1L,(-1L)},{0xBDL,(-7L),0x20L,(-10L),0L}},{{0L,0x74L,0x74L,0L,0xB1L},{0xBDL,0xA5L,(-9L),0xD7L,(-10L)},{0x74L,0x34L,(-8L),0x5BL,(-8L)},{0L,0L,(-10L),0xD7L,(-9L)},{0x02L,0xBFL,0xB1L,0L,0x74L},{0x20L,0xBDL,1L,0xBDL,0xA5L},{0xBFL,(-1L),(-8L),0x3EL,0xB1L}}};
    struct S3 l_13 = {21,-3};
    int32_t l_511[4];
    int32_t l_514 = 0xA60AA52BL;
    uint64_t *l_530 = &g_80;
    int8_t l_603 = 0x49L;
    int32_t l_618 = (-8L);
    int64_t * const l_659 = &g_660[0][1][0];
    int64_t * const *l_658 = &l_659;
    int32_t l_663 = 0x177D3097L;
    uint8_t l_667 = 9UL;
    const int32_t ** const *l_686 = &g_546;
    const int32_t *l_710 = (void*)0;
    const int16_t l_725 = (-1L);
    struct S3 l_746 = {92,3};
    int8_t l_833 = 0xE5L;
    int32_t **l_852 = &g_137;
    int32_t ***l_851 = &l_852;
    int32_t ****l_850 = &l_851;
    uint32_t l_861 = 0x68FBE963L;
    uint64_t l_868[2][10] = {{18446744073709551615UL,0xA7368E9E4422DF01LL,18446744073709551615UL,0x8480AFDF15CA4E80LL,1UL,1UL,0x8480AFDF15CA4E80LL,18446744073709551615UL,0xA7368E9E4422DF01LL,18446744073709551615UL},{18446744073709551615UL,5UL,0xA7368E9E4422DF01LL,0xCE3BE58119E481B5LL,0xA7368E9E4422DF01LL,5UL,18446744073709551615UL,18446744073709551615UL,5UL,0xA7368E9E4422DF01LL}};
    uint64_t l_869 = 0xA19014A398320956LL;
    struct S2 l_889 = {-6L};
    struct S3 l_906 = {47,1};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_511[i] = (-2L);
    for (g_5 = 2; (g_5 >= 0); g_5 -= 1)
    { /* block id: 3 */
        int16_t l_38 = 0x6B22L;
        uint64_t *l_201 = &g_202;
        uint16_t l_494 = 0x01F4L;
        int32_t *l_512[5];
        struct S2 *l_518 = &g_110[3][0][0];
        struct S2 **l_517[7] = {&l_518,&l_518,&l_518,&l_518,&l_518,&l_518,&l_518};
        const int64_t l_553 = 0x88BCF91D977C2E0CLL;
        uint32_t l_554 = 0xB7A1951DL;
        int32_t l_662 = 0xB991E16EL;
        int32_t **l_688[1][4][10];
        int32_t *** const l_687 = &l_688[0][0][8];
        const int32_t **l_727 = &g_327;
        int32_t l_766 = 9L;
        uint32_t l_799 = 0xF2A5B1D4L;
        uint8_t l_800[10];
        int16_t l_802 = 0x78CBL;
        int64_t **l_810 = (void*)0;
        uint8_t l_812 = 0xFAL;
        uint32_t l_822[10][10][2] = {{{18446744073709551608UL,0UL},{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL},{0x0B4CDAFDL,0xA0900F0EL},{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L},{0UL,0x9B96E27FL},{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L}},{{0x6ABE546AL,7UL},{18446744073709551615UL,0xA0900F0EL},{0x0B4CDAFDL,1UL},{18446744073709551608UL,0UL},{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL},{0x0B4CDAFDL,0xA0900F0EL},{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L}},{{0UL,0x9B96E27FL},{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L},{0x6ABE546AL,7UL},{18446744073709551615UL,0xA0900F0EL},{0x0B4CDAFDL,1UL},{18446744073709551608UL,0UL},{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL}},{{0x0B4CDAFDL,0xA0900F0EL},{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L},{0UL,0x9B96E27FL},{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L},{0x6ABE546AL,7UL},{18446744073709551615UL,0xA0900F0EL},{0x0B4CDAFDL,1UL},{18446744073709551608UL,0UL}},{{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL},{0x0B4CDAFDL,0xA0900F0EL},{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L},{0UL,0x9B96E27FL},{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L},{0x6ABE546AL,7UL}},{{18446744073709551615UL,0xA0900F0EL},{0x0B4CDAFDL,1UL},{18446744073709551608UL,0UL},{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL},{0x0B4CDAFDL,0xA0900F0EL},{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L},{0UL,0x9B96E27FL}},{{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L},{0x6ABE546AL,7UL},{18446744073709551615UL,0xA0900F0EL},{0x0B4CDAFDL,1UL},{18446744073709551608UL,0UL},{0x2EBF20D4L,18446744073709551612UL},{0x2EBF20D4L,0UL},{18446744073709551608UL,1UL},{0x0B4CDAFDL,0xA0900F0EL}},{{18446744073709551615UL,7UL},{0x6ABE546AL,0x8F12AC72L},{0UL,0x9B96E27FL},{18446744073709551612UL,0x9B96E27FL},{0UL,0x8F12AC72L},{0x6ABE546AL,7UL},{18446744073709551615UL,0xA0900F0EL},{0x6ABE546AL,0x03ADAD5DL},{18446744073709551612UL,0xDECB244DL},{4UL,0UL}},{{4UL,0xDECB244DL},{18446744073709551612UL,0x03ADAD5DL},{0x6ABE546AL,0x9B96E27FL},{0x2EBF20D4L,1UL},{0xA47F6B8EL,18446744073709551612UL},{0x34F63181L,18446744073709551614UL},{0UL,18446744073709551614UL},{0x34F63181L,18446744073709551612UL},{0xA47F6B8EL,1UL},{0x2EBF20D4L,0x9B96E27FL}},{{0x6ABE546AL,0x03ADAD5DL},{18446744073709551612UL,0xDECB244DL},{4UL,0UL},{4UL,0xDECB244DL},{18446744073709551612UL,0x03ADAD5DL},{0x6ABE546AL,0x9B96E27FL},{0x2EBF20D4L,1UL},{0xA47F6B8EL,18446744073709551612UL},{0x34F63181L,18446744073709551614UL},{0UL,18446744073709551614UL}}};
        struct S3 *l_855 = &l_746;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_512[i] = &g_513[2];
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 4; j++)
            {
                for (k = 0; k < 10; k++)
                    l_688[i][j][k] = (void*)0;
            }
        }
        for (i = 0; i < 10; i++)
            l_800[i] = 0x6CL;
    }
    return l_906;
}


/* ------------------------------------------ */
/* 
 * reads : g_421 g_133 g_134 g_501 g_106 g_110 g_510 g_4
 * writes: g_421 g_134 g_110 g_137
 */
static int64_t  func_8(int64_t  p_9, struct S3  p_10, uint32_t  p_11, int8_t  p_12)
{ /* block id: 221 */
    uint64_t l_506 = 2UL;
    int32_t *l_509 = &g_5;
    for (g_421 = (-5); (g_421 != (-10)); g_421 = safe_sub_func_uint32_t_u_u(g_421, 3))
    { /* block id: 224 */
        int32_t * const l_500 = &g_482[2];
        for (p_12 = (-2); (p_12 >= 29); ++p_12)
        { /* block id: 227 */
            struct S2 *l_508 = &g_110[3][0][0];
            (*g_133) ^= p_12;
            (*l_508) = func_50(((void*)0 != l_500), (p_10.f1 , &g_63), g_501, g_106[1], (safe_mod_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s(((l_506 != 0x6FL) ^ ((((p_12 <= p_12) || p_9) && 1L) == l_506)), 0)), 4L)));
            (*g_510) = l_509;
            if (p_11)
                continue;
        }
    }
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_18(uint8_t  p_19)
{ /* block id: 219 */
    uint8_t l_495 = 255UL;
    return l_495;
}


/* ------------------------------------------ */
/* 
 * reads : g_69 g_63 g_106.f0 g_349 g_134 g_67 g_133 g_110
 * writes: g_69 g_482 g_134 g_63
 */
static struct S2  func_20(uint64_t  p_21, int64_t  p_22, int8_t  p_23, uint32_t  p_24)
{ /* block id: 205 */
    int8_t l_478 = 2L;
    struct S2 l_493[5][7] = {{{-6L},{-6L},{-6L},{-6L},{-6L},{-6L},{-6L}},{{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L}},{{-6L},{-6L},{-6L},{-6L},{-6L},{-6L},{-6L}},{{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L},{0x3958L}},{{-6L},{-6L},{-6L},{-6L},{-6L},{-6L},{-6L}}};
    int i, j;
    for (g_69 = 0; (g_69 <= 2); g_69 += 1)
    { /* block id: 208 */
        int32_t *l_481[3];
        const int32_t l_491 = 0xC0A4F64AL;
        struct S2 l_492[4][4][9] = {{{{-1L},{0x592DL},{0x294CL},{0x947BL},{0x7456L},{0xEB1AL},{1L},{-6L},{0x0C22L}},{{0L},{-1L},{0x2E6FL},{6L},{0x5D67L},{0x20F7L},{0x3895L},{0x0C22L},{0x8D07L}},{{1L},{-10L},{-2L},{0x4ED6L},{0x4387L},{0x294CL},{0x5B4BL},{0L},{0x2E6FL}},{{-1L},{0x294CL},{-2L},{0L},{0x3279L},{0x5D67L},{0x5D67L},{0x3279L},{0L}}},{{{0x2E6FL},{-1L},{0x2E6FL},{0x3279L},{0x9276L},{0x47A8L},{0xB3A1L},{0x947BL},{0x5D67L}},{{0x3279L},{6L},{0x294CL},{-6L},{0x2E6FL},{1L},{0xEFD2L},{0L},{-1L}},{{0x577AL},{0x3895L},{-1L},{0x3279L},{-1L},{0x7456L},{-1L},{-2L},{0x710EL}},{{-6L},{2L},{0xB3A1L},{0L},{0xE1CFL},{-1L},{0x47A8L},{0x77A2L},{-1L}}},{{{0x20F7L},{1L},{0x77A2L},{0x4ED6L},{0xE1CFL},{0x947BL},{-6L},{-6L},{0x947BL}},{{-1L},{6L},{0xEB1AL},{6L},{-1L},{-1L},{0L},{0x2E6FL},{6L}},{{6L},{-6L},{0xA926L},{0x947BL},{0x2E6FL},{0xD0EEL},{-10L},{0x5D67L},{0x294CL}},{{-10L},{0x4ED6L},{0x47A8L},{0xEFD2L},{0x9276L},{-1L},{0x592DL},{0x86ECL},{-7L}}},{{{0x86ECL},{-2L},{-7L},{-1L},{-1L},{0xD0EEL},{0x5D67L},{-1L},{0x20F7L}},{{0x9276L},{0x0C22L},{-1L},{0x0426L},{6L},{0L},{0x5D67L},{-1L},{-1L}},{{0x947BL},{-10L},{0x8D07L},{-1L},{0x8D07L},{-10L},{0x947BL},{1L},{0x7456L}},{{1L},{0x77A2L},{0x5B4BL},{0x4E9FL},{-10L},{1L},{0x592DL},{0xA926L},{2L}}}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_481[i] = &g_482[8];
        (*g_133) = ((0UL || (safe_mod_func_uint32_t_u_u((safe_div_func_int16_t_s_s((safe_sub_func_int32_t_s_s((((((((~(p_22 != (l_478 <= ((((safe_add_func_uint32_t_u_u(p_24, (&p_23 != ((g_482[8] = g_63) , &p_23)))) | (safe_lshift_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(g_106[1].f0, (safe_rshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(l_478, 6)), 7)))), g_349))) , g_134[2][3]) ^ 0x540DL)))) >= g_67) && l_478) > p_23) <= p_24) == l_478) , p_21), l_491)), 0xEF32L)), p_22))) < 255UL);
        for (g_63 = 2; (g_63 >= 0); g_63 -= 1)
        { /* block id: 213 */
            return l_492[2][2][5];
        }
        return g_110[0][0][4];
    }
    return l_493[1][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_80 g_200 g_63 g_79 g_78 g_41 g_106 g_90 g_202 g_110.f0 g_67 g_89 g_5 g_69 g_339 g_350 g_327 g_110 g_193 g_131 g_132 g_84 g_398 g_424 g_440 g_420 g_83
 * writes: g_80 g_41 g_202 g_90 g_69 g_89 g_297 g_78 g_193 g_327 g_339 g_350 g_349 g_79 g_63 g_398 g_424 g_110.f0 g_440 g_84 g_106.f1
 */
static int64_t  func_25(int32_t  p_26)
{ /* block id: 97 */
    const int32_t l_229 = 0L;
    struct S3 l_233 = {157,3};
    uint16_t *l_264 = &g_84;
    const int8_t l_278 = 0x83L;
    struct S0 l_341 = {-5,0};
    int64_t l_455 = 1L;
    uint32_t l_466 = 1UL;
    uint64_t *l_467[3][5] = {{&g_80,&g_80,&g_350,&g_80,&g_80},{(void*)0,&g_80,(void*)0,(void*)0,&g_80},{&g_80,(void*)0,(void*)0,&g_80,(void*)0}};
    int32_t *l_468 = (void*)0;
    int32_t *l_469[6];
    uint8_t *l_470 = &g_193;
    int i, j;
    for (i = 0; i < 6; i++)
        l_469[i] = &g_63;
    for (g_80 = 20; (g_80 <= 16); --g_80)
    { /* block id: 100 */
        struct S3 *l_234[1];
        int32_t l_237 = 0L;
        int32_t **l_242 = (void*)0;
        uint8_t *l_243[1][3][1];
        const int32_t *l_250[10] = {&g_67,&g_41,&g_41,&g_67,(void*)0,&g_67,&g_41,&g_41,&g_67,(void*)0};
        struct S2 *l_371 = &g_110[5][0][4];
        int8_t l_403 = 9L;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_234[i] = &g_106[1];
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
            {
                for (k = 0; k < 1; k++)
                    l_243[i][j][k] = &g_193;
            }
        }
        if (p_26)
            break;
        if (((safe_div_func_int64_t_s_s((((((+l_229) >= 0x84B6L) ^ (!(safe_lshift_func_uint8_t_u_s((l_233 , (l_234[0] != (void*)0)), (p_26 & ((safe_mul_func_uint16_t_u_u((l_237 ^ (((safe_lshift_func_int16_t_s_s((safe_sub_func_int64_t_s_s((-5L), ((void*)0 != l_242))), g_200)) , p_26) & (-1L))), g_63)) , l_229)))))) > g_79[1]) & (-2L)), 0x1DAC2A05BAC6DDDALL)) || g_78))
        { /* block id: 102 */
            const int64_t l_244 = (-6L);
            const struct S3 l_246[10] = {{472,-1},{422,0},{472,-1},{422,0},{472,-1},{422,0},{472,-1},{422,0},{472,-1},{422,0}};
            uint16_t *l_263[6] = {&g_84,&g_84,&g_84,&g_84,&g_84,&g_84};
            uint32_t *l_296[1];
            int i;
            for (i = 0; i < 1; i++)
                l_296[i] = &g_90;
            if (((void*)0 == l_243[0][0][0]))
            { /* block id: 103 */
                int32_t *l_245 = &g_41;
                (*l_245) |= l_244;
            }
            else
            { /* block id: 105 */
                const int32_t **l_247 = (void*)0;
                const int32_t **l_248 = (void*)0;
                const int32_t **l_249[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                struct S2 * const l_251 = &g_110[3][0][0];
                struct S2 *l_253[3];
                struct S2 **l_252[6][2] = {{&l_253[2],&l_253[0]},{&l_253[2],&l_253[2]},{&l_253[0],&l_253[2]},{&l_253[2],&l_253[0]},{&l_253[2],&l_253[2]},{&l_253[0],&l_253[2]}};
                struct S2 **l_254 = &l_253[2];
                uint16_t * const l_265 = &g_84;
                int32_t l_281 = 0x540D8EDEL;
                struct S0 l_290 = {5,0};
                int i, j;
                for (i = 0; i < 3; i++)
                    l_253[i] = &g_110[6][0][2];
                l_233 = l_246[3];
                l_250[2] = &l_229;
                (*l_254) = (g_106[1] , l_251);
                if ((g_90 <= g_78))
                { /* block id: 109 */
                    int8_t l_255[5][5] = {{(-1L),0xACL,0xACL,(-1L),0x78L},{(-9L),(-1L),0x19L,(-9L),(-9L)},{(-9L),(-1L),(-9L),0x78L,(-1L)},{(-9L),0xACL,0x78L,(-9L),0x78L},{(-9L),(-9L),0x19L,(-1L),(-9L)}};
                    uint64_t *l_260 = &g_202;
                    uint32_t *l_261 = (void*)0;
                    uint32_t *l_262 = &g_90;
                    int32_t l_280[10][5] = {{0xFFB475F5L,0xA633CF6FL,0xA633CF6FL,0xFFB475F5L,0x9A4AC84FL},{0x5CD862EAL,(-1L),1L,1L,(-1L)},{0x9A4AC84FL,0xA633CF6FL,1L,0x348AB551L,0x348AB551L},{(-2L),7L,(-2L),1L,0L},{0xCD4D2746L,0xFFB475F5L,0x348AB551L,0xFFB475F5L,0xCD4D2746L},{(-2L),0x5CD862EAL,7L,(-1L),7L},{0x9A4AC84FL,0x9A4AC84FL,0x348AB551L,0xCD4D2746L,1L},{0x5CD862EAL,(-2L),(-2L),0x5CD862EAL,7L},{0xFFB475F5L,0xCD4D2746L,1L,1L,0xCD4D2746L},{7L,(-2L),1L,0L,0L}};
                    int i, j;
                    l_255[4][1] = 0x161852D1L;
                    if ((((l_264 = ((((0x2388C2A8L ^ (safe_lshift_func_uint8_t_u_s(g_202, 2))) , ((*l_262) = ((p_26 >= (l_229 <= ((((*l_260) |= p_26) != 0xFCB4D8023FC29F5BLL) <= (((l_233.f1 , p_26) < (p_26 <= p_26)) <= p_26)))) <= 0x76A276C9L))) , p_26) , l_263[0])) != l_265) & 0xDB0FBA3AL))
                    { /* block id: 114 */
                        if (l_255[4][3])
                            break;
                        if (l_255[4][1])
                            break;
                    }
                    else
                    { /* block id: 117 */
                        int32_t l_266 = 0x13F7A610L;
                        return l_266;
                    }
                    for (g_69 = 15; (g_69 < (-28)); --g_69)
                    { /* block id: 122 */
                        int32_t l_271[9][5] = {{0xB9182EEBL,0x82E84388L,0x97500012L,0xA190B2B2L,(-1L)},{0x31C7011DL,0xB9182EEBL,(-1L),0xB9182EEBL,0x31C7011DL},{(-1L),0L,(-1L),0x97500012L,0x572D124CL},{0xF45954D8L,0L,0x97500012L,0x8617D44FL,1L},{1L,0x31C7011DL,0x07CB16B7L,0L,1L},{0L,0x572D124CL,0x572D124CL,0L,0xB9182EEBL},{1L,0x572D124CL,(-1L),0x613F1AEBL,0L},{0x82E84388L,0xB9182EEBL,1L,0x31C7011DL,0x07CB16B7L},{(-1L),(-1L),0xF45954D8L,0x613F1AEBL,0x613F1AEBL}};
                        int8_t *l_279[5][10] = {{&g_89,&l_255[4][1],(void*)0,&g_89,&g_83,&g_83,&g_89,(void*)0,&l_255[4][1],&g_89},{(void*)0,&l_255[4][1],&l_255[4][1],&g_83,&l_255[4][1],&g_83,&l_255[4][1],&l_255[4][1],(void*)0,(void*)0},{&g_89,(void*)0,(void*)0,&l_255[4][1],&l_255[4][1],(void*)0,(void*)0,&g_89,(void*)0,&g_89},{&l_255[4][1],&l_255[4][1],&g_83,&l_255[4][1],&g_83,&l_255[4][1],&l_255[4][1],(void*)0,(void*)0,&l_255[4][1]},{(void*)0,&g_89,&g_83,&g_83,&g_89,(void*)0,&l_255[4][1],&g_89,&l_255[4][1],(void*)0}};
                        int i, j;
                        g_41 = (safe_add_func_int16_t_s_s(l_271[6][1], (safe_mul_func_uint16_t_u_u((((safe_mul_func_int8_t_s_s((l_281 = (l_280[8][4] = (safe_rshift_func_uint16_t_u_s(l_278, 8)))), l_271[6][1])) > (((!(~((((g_110[3][0][0].f0 || (safe_rshift_func_int16_t_s_u((safe_add_func_int8_t_s_s(p_26, (l_255[1][3] & (((-1L) >= (((safe_mul_func_int8_t_s_s(0L, (p_26 ^ 1UL))) | g_67) <= p_26)) , 0x150DD777C9553355LL)))), 12))) < 0x91AEC19C680A16CCLL) , l_271[1][1]) > l_233.f1))) ^ p_26) >= p_26)) > 0L), 1L))));
                        if (p_26)
                            break;
                        return g_90;
                    }
                }
                else
                { /* block id: 129 */
                    uint8_t l_320 = 0x7EL;
                    int32_t l_321 = 0x293A444AL;
                    int8_t *l_322 = &g_78;
                    for (g_69 = 0; (g_69 <= 7); g_69 += 1)
                    { /* block id: 132 */
                        struct S0 *l_291 = &l_290;
                        (*l_291) = l_290;
                        return g_200;
                    }
                    for (g_89 = 1; (g_89 <= 9); g_89 += 1)
                    { /* block id: 138 */
                        int i;
                        l_250[g_89] = l_250[g_89];
                    }
                    l_237 = (safe_sub_func_uint16_t_u_u((g_106[2] , (safe_rshift_func_uint8_t_u_u(((g_297 = l_296[0]) != &g_90), 7))), ((((*l_322) = (safe_sub_func_uint8_t_u_u((((safe_rshift_func_uint8_t_u_s(((safe_rshift_func_uint8_t_u_u(0xFEL, l_246[3].f0)) || (l_246[3].f1 != g_106[1].f0)), (safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((safe_sub_func_int64_t_s_s((safe_sub_func_int32_t_s_s(p_26, ((safe_mul_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((safe_rshift_func_int16_t_s_u(((l_321 = (65529UL ^ l_320)) & p_26), 15)) >= (-7L)), p_26)), 252UL)), p_26)) >= 0xB61F359F1E093644LL))), 0x2E7E911EC70156CELL)), g_5)), 0xD3L)))) , p_26) >= g_80), p_26))) | 250UL) >= l_244)));
                    for (l_321 = 0; l_321 < 1; l_321 += 1)
                    {
                        l_296[l_321] = &g_90;
                    }
                }
            }
        }
        else
        { /* block id: 148 */
            uint32_t l_328[7][6][1] = {{{1UL},{6UL},{18446744073709551610UL},{0UL},{0UL},{0xB3CA9607L}},{{0UL},{0UL},{18446744073709551610UL},{6UL},{1UL},{6UL}},{{18446744073709551610UL},{0UL},{0UL},{0xB3CA9607L},{0UL},{0UL}},{{18446744073709551610UL},{6UL},{1UL},{6UL},{18446744073709551610UL},{0UL}},{{0UL},{0xB3CA9607L},{0UL},{0UL},{18446744073709551610UL},{6UL}},{{1UL},{6UL},{18446744073709551610UL},{0UL},{0UL},{0xB3CA9607L}},{{0UL},{0UL},{18446744073709551610UL},{6UL},{1UL},{6UL}}};
            int32_t l_345 = (-1L);
            int32_t l_346 = (-8L);
            struct S0 l_387 = {4,-1};
            int i, j, k;
            for (g_193 = (-21); (g_193 > 60); g_193 = safe_add_func_uint64_t_u_u(g_193, 8))
            { /* block id: 151 */
                int32_t l_337 = 0x4937AF58L;
                int32_t l_343 = 0x20F7BB9FL;
                int32_t l_344[3];
                uint32_t l_370[6][9] = {{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L,0xE0E843E2L,0x6BF60B68L}};
                int64_t l_388 = 0xD33E085742EE5064LL;
                uint16_t l_431 = 7UL;
                int i, j;
                for (i = 0; i < 3; i++)
                    l_344[i] = (-1L);
                if ((safe_lshift_func_int8_t_s_u(p_26, 1)))
                { /* block id: 152 */
                    uint64_t l_336[3];
                    uint32_t *l_338 = &g_339;
                    struct S0 l_340 = {2,1};
                    int32_t l_347 = 0x6C81ED34L;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_336[i] = 0x00827C2B00AAE8DFLL;
                    g_327 = &l_229;
                    if (((-6L) < ((g_79[1] | l_328[4][4][0]) != (safe_div_func_uint32_t_u_u(((((*l_338) &= (safe_add_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(((-8L) <= ((g_69 || (((((g_67 && 65531UL) > (((l_336[1] , (g_106[2] , p_26)) ^ 0L) & 0x82L)) ^ 254UL) && l_337) > p_26)) , p_26)))), p_26))) | 0xEC976F7BL) < p_26), g_200)))))
                    { /* block id: 155 */
                        l_341 = l_340;
                    }
                    else
                    { /* block id: 157 */
                        int32_t *l_342[9];
                        int64_t l_348 = 0xBCDAE124F1985595LL;
                        int i;
                        for (i = 0; i < 9; i++)
                            l_342[i] = &g_63;
                        g_350++;
                        if ((*g_327))
                            continue;
                        return p_26;
                    }
                }
                else
                { /* block id: 162 */
                    uint8_t l_366[2][6] = {{1UL,1UL,0x55L,1UL,1UL,0x55L},{1UL,1UL,0x55L,1UL,1UL,0x55L}};
                    int16_t *l_367 = &g_79[1];
                    int32_t *l_368 = &g_63;
                    int i, j;
                    (*l_368) = ((safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((((0x09BFC39C174052BCLL | (((*l_367) = ((((g_349 = (safe_lshift_func_int8_t_s_s((p_26 == (((safe_rshift_func_uint16_t_u_u(65533UL, 5)) && p_26) < (g_110[0][0][4] , 0xACL))), 4))) == ((safe_add_func_int8_t_s_s((g_193 >= (safe_div_func_uint16_t_u_u(((!((*g_131) == (void*)0)) > l_366[0][3]), g_84))), g_5)) || l_344[0])) < 9UL) || g_79[6])) != p_26)) >= p_26) == 0xC055C2ACDC9DE390LL), l_344[2])), p_26)) , (*g_327));
                    for (g_78 = 1; (g_78 <= 9); g_78 += 1)
                    { /* block id: 168 */
                        const int32_t **l_369 = &l_250[2];
                        int i;
                        (*l_369) = l_250[g_78];
                        return l_370[3][0];
                    }
                    if ((*g_327))
                    { /* block id: 172 */
                        struct S2 **l_372 = &l_371;
                        int32_t *l_389 = &g_63;
                        int32_t *l_390 = &g_67;
                        int32_t *l_391 = &g_63;
                        int32_t *l_392 = &g_67;
                        int32_t *l_393 = &l_346;
                        int32_t *l_394 = &l_346;
                        int32_t *l_395 = &l_346;
                        int32_t *l_396 = &g_41;
                        int32_t *l_397 = &l_344[0];
                        (*l_372) = ((0L < p_26) , l_371);
                        (*l_368) = (safe_add_func_uint32_t_u_u(((((safe_sub_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((g_84 , 0L) , (((safe_rshift_func_uint16_t_u_u(g_202, (safe_add_func_uint16_t_u_u(((void*)0 == &l_344[1]), (safe_div_func_int32_t_s_s(((l_341.f0 ^= ((safe_lshift_func_int8_t_s_s(l_370[3][0], 3)) , (*l_368))) | ((18446744073709551607UL <= (p_26 | p_26)) < 0xFDAAB49CL)), p_26)))))) , l_387) , (*l_368))), l_388)), (-1L))) , g_84) < g_41) != (*l_368)), p_26));
                        ++g_398;
                    }
                    else
                    { /* block id: 177 */
                        int32_t *l_415 = &l_343;
                        int32_t l_422 = 0L;
                        int32_t l_423 = 0xFB4F0E17L;
                        uint64_t *l_427 = &g_202;
                        int16_t *l_430[5];
                        uint64_t *l_445 = &g_350;
                        int8_t *l_446 = &g_78;
                        int i;
                        for (i = 0; i < 5; i++)
                            l_430[i] = &g_110[3][0][0].f0;
                        (*l_415) |= (l_344[1] &= ((l_278 <= (l_237 = ((safe_rshift_func_uint16_t_u_s((((l_403 ^ (g_41 == (+g_202))) ^ g_5) , (l_370[3][0] | ((((safe_sub_func_int32_t_s_s((safe_sub_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((((((((safe_div_func_uint32_t_u_u(1UL, (3UL ^ (safe_rshift_func_uint8_t_u_s((g_67 | p_26), l_233.f0))))) || 4294967289UL) | p_26) ^ (*l_368)) <= g_200) | g_398) & 0xD2017B47L), 0xB7L)), 0x7CE971563B046F2CLL)), (*g_327))) || (*g_327)) & g_80) , 0xE590E9D9L))), g_200)) != 0UL))) & p_26));
                        (*l_415) = ((l_387.f1 |= ((*l_427) = (safe_mul_func_uint8_t_u_u((g_200 ^ l_337), (++g_424))))) & ((safe_sub_func_int16_t_s_s((g_110[3][0][0].f0 &= (l_344[2] = ((*l_367) = (-2L)))), l_431)) <= ((&l_431 == (void*)0) | (l_341.f0 < (safe_add_func_uint32_t_u_u((((*l_446) = (safe_div_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((++g_440), ((safe_lshift_func_int8_t_s_s((0x3EBB224FDA9CD144LL && ((*l_445) = ((((*l_368) = (p_26 , 1L)) , &l_250[1]) == (*g_131)))), 4)) > l_337))) ^ l_388), 14)) != g_69), 1UL))) >= (-6L)), g_89))))));
                    }
                    (*l_368) ^= p_26;
                }
            }
        }
    }
    g_106[1].f1 = (((((((*l_470) &= (((*l_264) = (safe_mod_func_uint8_t_u_u((safe_div_func_int8_t_s_s((g_89 = (((safe_add_func_int16_t_s_s(((g_69 ^= (0x0E76L | (((0x48L || ((g_202 = (p_26 > (safe_rshift_func_uint8_t_u_u(((l_455 <= l_341.f1) <= (safe_add_func_uint16_t_u_u(((safe_div_func_int8_t_s_s(((l_341.f1 < (((safe_mul_func_uint16_t_u_u(l_233.f0, (((safe_div_func_int8_t_s_s(0L, (safe_mod_func_uint16_t_u_u(1UL, g_350)))) || (-5L)) ^ g_420))) && 1UL) , p_26)) >= g_67), l_466)) > p_26), g_41))), 1)))) ^ p_26)) < l_233.f1) != p_26))) && 7L), g_83)) & g_106[1].f0) ^ 0L)), (-8L))), g_78))) != g_420)) & g_5) , p_26) == 0x4A8F585AL) == 8UL) < p_26);
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_110.f0 g_89 g_200 g_110 g_90 g_84 g_78 g_106.f1
 * writes: g_110.f0 g_106.f1 g_78
 */
static int32_t  func_27(uint64_t  p_28, uint16_t  p_29)
{ /* block id: 86 */
    int32_t l_203 = 0xEBD4AFBEL;
    int32_t **l_214[3][5];
    uint32_t l_215 = 18446744073709551606UL;
    const int16_t l_216 = 0L;
    int16_t *l_217[7][9] = {{&g_110[3][0][0].f0,&g_79[1],&g_79[1],&g_79[1],&g_110[3][0][0].f0,&g_200,&g_200,&g_110[3][0][0].f0,&g_200},{&g_79[6],&g_79[0],&g_79[1],&g_79[1],&g_200,&g_110[3][0][0].f0,&g_200,(void*)0,&g_110[3][0][0].f0},{&g_200,&g_79[1],&g_200,(void*)0,&g_79[7],&g_110[3][0][0].f0,&g_110[3][0][0].f0,&g_110[3][0][0].f0,&g_110[3][0][0].f0},{(void*)0,(void*)0,&g_200,(void*)0,(void*)0,&g_110[3][0][0].f0,(void*)0,&g_200,&g_110[3][0][0].f0},{&g_79[7],(void*)0,&g_200,&g_79[1],&g_200,&g_110[3][0][0].f0,&g_200,(void*)0,&g_110[3][0][0].f0},{&g_200,&g_79[1],&g_200,(void*)0,&g_79[7],&g_110[3][0][0].f0,&g_110[3][0][0].f0,&g_110[3][0][0].f0,&g_110[3][0][0].f0},{(void*)0,(void*)0,&g_200,(void*)0,(void*)0,&g_110[3][0][0].f0,(void*)0,&g_200,&g_110[3][0][0].f0}};
    struct S0 l_218 = {5,0};
    struct S3 l_219[6] = {{437,1},{437,1},{437,1},{437,1},{437,1},{437,1}};
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
            l_214[i][j] = &g_137;
    }
    g_106[1].f1 |= (l_203 , (safe_div_func_int8_t_s_s(((((func_50(((p_28 <= ((safe_mod_func_uint8_t_u_u((l_203 >= (g_110[3][0][0].f0 |= (l_203 | (safe_mod_func_uint8_t_u_u(((safe_div_func_int32_t_s_s(((l_203 && ((safe_add_func_uint64_t_u_u((((void*)0 == l_214[2][4]) <= (g_63 >= 0x37CAL)), l_215)) , 0x1F6060BAL)) , 8L), p_28)) != l_216), p_29))))), g_89)) , (-1L))) , p_28), &g_63, l_218, l_219[1], g_200) , p_29) != p_29) >= g_90) <= g_84), g_78)));
    for (g_78 = (-26); (g_78 == 0); g_78++)
    { /* block id: 91 */
        int32_t *l_222 = &l_203;
        int32_t l_223 = 1L;
        l_222 = l_222;
        l_223 |= ((*l_222) = ((p_28 <= ((void*)0 == l_222)) ^ p_29));
    }
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_63 g_67 g_80 g_84 g_90 g_83 g_106 g_110 g_69 g_131 g_132 g_79 g_5 g_78 g_137 g_89 g_200
 * writes: g_41 g_63 g_67 g_80 g_84 g_90 g_69 g_137 g_110.f0 g_89 g_193 g_106 g_200
 */
static int64_t  func_34(uint64_t  p_35)
{ /* block id: 4 */
    int32_t *l_40[5][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_41,&g_41,&g_41,&g_41,&g_41},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_41,&g_41,&g_41,&g_41,&g_41},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    int8_t l_104 = 0x3FL;
    struct S0 l_105[4][5] = {{{-2,1},{-1,1},{-1,1},{-2,1},{-1,1}},{{-2,1},{-2,1},{-1,-1},{-2,1},{-2,1}},{{-1,1},{-2,1},{-1,1},{-1,1},{-2,1}},{{-2,1},{-1,1},{-1,1},{-2,1},{-1,1}}};
    int i, j;
    g_41 = p_35;
    g_200 &= (safe_sub_func_uint16_t_u_u(func_44(p_35, func_50((4294967292UL <= (p_35 == ((func_56(l_40[2][1]) , ((safe_mod_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((((((safe_lshift_func_uint8_t_u_s(((void*)0 != l_40[2][1]), ((safe_rshift_func_uint16_t_u_s((safe_unary_minus_func_int32_t_s((((safe_mul_func_int16_t_s_s(p_35, (((g_67 && 0x7CL) , (void*)0) == &g_67))) || 255UL) == l_104))), 8)) ^ 255UL))) == p_35) <= g_90) & g_67) >= g_63), 1UL)), g_83)) & p_35)) == p_35))), l_40[2][1], l_105[0][0], g_106[1], g_106[1].f0), l_40[2][0], &g_69, g_83), 65535UL));
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_67 g_69 g_106.f1 g_83 g_63 g_131 g_80 g_84 g_132 g_79 g_5 g_41 g_78 g_137 g_89 g_106 g_90
 * writes: g_69 g_80 g_137 g_63 g_84 g_41 g_110.f0 g_89 g_193 g_106
 */
static uint16_t  func_44(uint32_t  p_45, struct S2  p_46, int32_t * const  p_47, int32_t * p_48, uint8_t  p_49)
{ /* block id: 29 */
    uint8_t l_111[9] = {0x00L,0x00L,0UL,0x00L,0x00L,0UL,0x00L,0x00L,0UL};
    const int32_t *l_123[1];
    int32_t ** const * const l_128 = (void*)0;
    int32_t ***l_129 = (void*)0;
    int32_t ****l_130 = &l_129;
    uint64_t *l_135 = &g_80;
    int32_t l_139[2][6] = {{0xAEA66F31L,0xAEA66F31L,5L,0xAEA66F31L,0xAEA66F31L,5L},{0xAEA66F31L,0xAEA66F31L,5L,0xAEA66F31L,0xAEA66F31L,5L}};
    int32_t *l_141 = &l_139[0][2];
    struct S3 l_198 = {382,-2};
    int i, j;
    for (i = 0; i < 1; i++)
        l_123[i] = &g_41;
    (*p_48) ^= g_67;
    ++l_111[5];
    if ((safe_mod_func_int8_t_s_s(((l_111[5] , (((safe_div_func_uint64_t_u_u(((*l_135) = (l_111[4] < ((+g_106[1].f1) >= ((safe_sub_func_int16_t_s_s((safe_mul_func_int16_t_s_s(l_111[5], g_83)), (p_46.f0 &= l_111[5]))) , ((l_123[0] == ((safe_sub_func_int8_t_s_s((((((safe_sub_func_uint32_t_u_u((l_128 != ((*l_130) = l_129)), 1L)) , g_63) , (*l_130)) != g_131) ^ p_45), g_80)) , (void*)0)) > g_84))))), g_63)) , (*g_131)) == &p_47)) , p_49), g_79[1])))
    { /* block id: 35 */
        const int32_t *l_140 = &g_5;
        uint32_t l_149 = 0x11896133L;
        int32_t **l_197 = &l_141;
        (*p_48) |= 0x6A5085D5L;
        if (((*p_48) = 6L))
        { /* block id: 38 */
            int32_t *l_136[4][9][7] = {{{&g_69,(void*)0,&g_67,&g_5,&g_41,&g_69,(void*)0},{(void*)0,&g_63,&g_69,&g_67,&g_69,&g_63,(void*)0},{(void*)0,(void*)0,&g_63,&g_67,&g_67,(void*)0,&g_5},{&g_69,&g_67,(void*)0,&g_5,(void*)0,&g_41,&g_41},{(void*)0,(void*)0,&g_63,(void*)0,(void*)0,&g_69,(void*)0},{(void*)0,(void*)0,&g_69,(void*)0,&g_67,&g_63,(void*)0},{(void*)0,&g_67,&g_67,&g_69,&g_63,&g_63,&g_69},{(void*)0,(void*)0,(void*)0,&g_63,(void*)0,&g_67,&g_69},{(void*)0,&g_63,&g_63,&g_69,&g_69,(void*)0,(void*)0}},{{&g_69,(void*)0,&g_67,&g_63,&g_69,&g_69,(void*)0},{&g_63,&g_41,&g_67,&g_63,&g_69,(void*)0,&g_41},{&g_67,(void*)0,&g_41,(void*)0,&g_63,(void*)0,&g_67},{&g_67,&g_69,&g_63,&g_63,&g_69,&g_67,&g_67},{&g_41,&g_67,&g_63,&g_69,(void*)0,&g_41,&g_69},{&g_41,&g_63,&g_41,&g_67,&g_69,&g_69,&g_69},{(void*)0,&g_67,&g_67,(void*)0,(void*)0,&g_69,(void*)0},{(void*)0,&g_69,&g_69,&g_63,&g_63,(void*)0,&g_63},{&g_41,(void*)0,(void*)0,&g_67,&g_41,&g_67,(void*)0}},{{&g_41,&g_41,(void*)0,&g_5,(void*)0,&g_67,&g_69},{&g_67,(void*)0,&g_69,&g_67,&g_41,(void*)0,&g_69},{&g_67,&g_69,(void*)0,&g_69,(void*)0,&g_69,&g_67},{&g_63,&g_67,(void*)0,&g_69,&g_41,&g_69,&g_67},{&g_63,&g_69,(void*)0,&g_67,&g_63,&g_41,&g_41},{(void*)0,&g_5,(void*)0,&g_5,(void*)0,&g_67,(void*)0},{(void*)0,&g_5,(void*)0,&g_67,&g_69,(void*)0,&g_63},{&g_5,&g_69,&g_69,&g_63,(void*)0,(void*)0,&g_63},{(void*)0,&g_67,(void*)0,(void*)0,&g_69,&g_69,&g_63}},{{(void*)0,&g_69,(void*)0,&g_67,&g_63,(void*)0,&g_63},{&g_63,(void*)0,&g_69,&g_69,&g_69,&g_69,(void*)0},{&g_63,&g_41,&g_67,&g_63,&g_69,(void*)0,&g_41},{&g_67,(void*)0,&g_41,(void*)0,&g_63,(void*)0,&g_67},{&g_67,&g_69,&g_63,&g_63,&g_69,&g_67,&g_67},{&g_41,&g_67,&g_63,&g_69,(void*)0,&g_41,&g_69},{&g_41,&g_63,&g_41,&g_67,&g_69,&g_69,&g_69},{(void*)0,&g_67,&g_67,(void*)0,(void*)0,&g_69,(void*)0},{(void*)0,&g_69,&g_69,&g_63,&g_63,(void*)0,&g_63}}};
            uint64_t l_138[5] = {0UL,0UL,0UL,0UL,0UL};
            int i, j, k;
            g_137 = l_136[0][3][1];
            l_123[0] = (((255UL && 0x47L) == (l_139[0][2] &= ((*p_48) = (g_63 = l_138[2])))) , l_140);
            (*p_48) = g_5;
        }
        else
        { /* block id: 45 */
            int32_t *l_142 = &g_41;
            int32_t *l_143 = &g_63;
            int32_t *l_144 = &l_139[0][4];
            int32_t *l_145 = &g_41;
            int32_t *l_146 = (void*)0;
            int32_t *l_147 = &g_63;
            int32_t *l_148[4];
            struct S2 *l_196 = &g_110[1][0][0];
            struct S2 **l_195 = &l_196;
            int i;
            for (i = 0; i < 4; i++)
                l_148[i] = &g_41;
            l_141 = (void*)0;
            l_149++;
            for (p_46.f0 = 0; (p_46.f0 <= 8); p_46.f0 += 1)
            { /* block id: 50 */
                uint16_t *l_156 = &g_84;
                int32_t **l_164 = &g_137;
                int16_t *l_173 = &g_110[3][0][0].f0;
                int i;
                (*l_145) |= (safe_sub_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(l_111[p_46.f0], 0xB5FCL)), (++(*l_156))));
                (*l_142) = ((*p_48) |= (safe_unary_minus_func_int64_t_s(((-1L) >= ((g_79[1] < ((((*l_173) = ((safe_mul_func_int8_t_s_s((!(~(((void*)0 == l_164) > (((safe_mod_func_int32_t_s_s((-6L), (((safe_add_func_uint16_t_u_u((0L & 0x682C8C66L), (((safe_div_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_s(g_79[2], g_78)) | (-1L)), p_45)) != 1L) != p_45))) < p_49) , (*g_137)))) , (**l_164)) && 65535UL)))), (-1L))) ^ g_80)) && (**l_164)) ^ g_84)) , (**l_164))))));
                for (g_89 = 3; (g_89 >= 0); g_89 -= 1)
                { /* block id: 58 */
                    int32_t l_178 = 0L;
                    for (g_84 = 0; (g_84 <= 3); g_84 += 1)
                    { /* block id: 61 */
                        if ((*g_137))
                            break;
                    }
                    for (g_63 = 0; (g_63 <= 2); g_63 += 1)
                    { /* block id: 66 */
                        int32_t l_190 = 1L;
                        uint8_t *l_191 = (void*)0;
                        uint8_t *l_192 = &g_193;
                        int i, j;
                        (*p_48) = (0xAA8CL >= (safe_rshift_func_uint16_t_u_s((((g_106[3] , (safe_sub_func_int8_t_s_s((l_178 , ((safe_add_func_int32_t_s_s((*g_137), (((g_89 || ((safe_sub_func_uint32_t_u_u((((((safe_add_func_int64_t_s_s(g_67, (g_106[1].f0 & (safe_mul_func_int8_t_s_s(g_90, ((*l_192) = ((safe_lshift_func_uint16_t_u_u(((*l_156) = (~(l_111[(g_63 + 5)] = (**l_164)))), l_190)) > p_46.f0))))))) != 1UL) != l_178) && 1L) , 0x7680494BL), 0L)) == 0x7861EF60L)) <= p_49) || g_106[1].f0))) ^ 0xF6L)), p_45))) , 0x4FC8L) > p_49), 8)));
                        (**l_164) &= (!p_46.f0);
                        if ((*p_48))
                            break;
                    }
                }
            }
            (*l_195) = &g_110[3][0][0];
        }
        (*l_197) = (void*)0;
    }
    else
    { /* block id: 79 */
        struct S3 *l_199[5][2] = {{&l_198,&l_198},{&l_198,&l_198},{&l_198,&l_198},{&l_198,&l_198},{&l_198,&l_198}};
        int i, j;
        g_106[2] = l_198;
    }
    return g_89;
}


/* ------------------------------------------ */
/* 
 * reads : g_110
 * writes:
 */
static struct S2  func_50(uint64_t  p_51, int32_t * p_52, struct S0  p_53, struct S3  p_54, uint16_t  p_55)
{ /* block id: 26 */
    int32_t *l_109 = (void*)0;
    int32_t **l_108 = &l_109;
    int32_t ***l_107 = &l_108;
    (*l_107) = &p_52;
    return g_110[3][0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_63 g_67 g_80 g_84 g_90
 * writes: g_41 g_63 g_67 g_80 g_84 g_90
 */
static int32_t  func_56(int32_t * p_57)
{ /* block id: 6 */
    const uint32_t l_60 = 0x20E9505CL;
    int16_t l_66[3];
    int i;
    for (i = 0; i < 3; i++)
        l_66[i] = (-3L);
    for (g_41 = 0; (g_41 != (-7)); --g_41)
    { /* block id: 9 */
        int32_t *l_61 = (void*)0;
        int32_t *l_62 = &g_63;
        int32_t l_71 = 0x819AFCA6L;
        (*l_62) = (0L >= l_60);
        for (g_63 = 0; (g_63 < (-30)); --g_63)
        { /* block id: 13 */
            uint16_t l_74 = 65535UL;
            int32_t l_77 = 0xA67F41B6L;
            int32_t *l_87 = (void*)0;
            int32_t *l_88[9][3][7] = {{{&g_69,&g_5,(void*)0,&g_69,&g_5,&g_41,&g_5},{(void*)0,&g_67,&g_67,(void*)0,&l_77,&l_71,&g_63},{(void*)0,&l_77,(void*)0,(void*)0,&g_69,(void*)0,(void*)0}},{{&g_69,&g_63,(void*)0,&g_63,&g_69,&g_63,&g_63},{(void*)0,(void*)0,&g_69,&g_69,(void*)0,&g_69,&g_5},{&g_67,&g_67,&g_5,&g_5,&g_67,&g_67,&l_77}},{{(void*)0,&g_69,&g_41,(void*)0,&g_5,&g_67,&g_69},{&g_69,&l_71,&g_67,&g_69,&g_67,&l_71,&g_69},{(void*)0,&g_69,(void*)0,(void*)0,&l_77,(void*)0,(void*)0}},{{(void*)0,&g_67,&g_5,&g_63,&g_63,&g_5,&g_67},{&g_69,(void*)0,(void*)0,&g_69,(void*)0,(void*)0,&g_5},{&l_71,&g_63,&g_67,&l_71,&g_67,&l_71,&g_67}},{{&l_77,&l_77,&g_41,&g_69,&g_69,(void*)0,&l_77},{&g_69,&g_67,&g_5,&g_63,&l_71,&l_71,&g_63},{&g_69,&g_5,&g_69,(void*)0,&g_69,&g_69,(void*)0}},{{&g_63,&g_67,(void*)0,&g_69,&g_67,&g_63,&g_67},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_69,&g_69},{&l_71,&g_69,&g_67,&g_5,&g_63,&l_71,&l_71}},{{&l_77,&g_69,(void*)0,&g_69,&l_77,(void*)0,&g_69},{(void*)0,&l_77,&l_71,&g_63,&g_67,&l_71,&g_67},{(void*)0,&g_5,(void*)0,(void*)0,&g_5,(void*)0,(void*)0}},{{(void*)0,&g_63,&g_63,(void*)0,&g_67,&g_5,&g_63},{&l_77,(void*)0,(void*)0,&g_69,(void*)0,(void*)0,&l_77},{&l_71,&g_63,&g_5,&g_67,&g_69,&l_71,&g_67}},{{(void*)0,&g_5,&g_67,&g_69,&g_69,&g_67,&g_5},{&g_63,&l_77,&g_5,&g_69,&l_77,&g_67,&g_67},{(void*)0,&g_69,&g_67,(void*)0,(void*)0,(void*)0,&g_67}}};
            int i, j, k;
            if (g_41)
                break;
            for (g_67 = 0; (g_67 <= 2); g_67 += 1)
            { /* block id: 17 */
                int32_t *l_68 = &g_69;
                int32_t *l_70 = &g_69;
                int32_t *l_72 = &l_71;
                int32_t *l_73[5][4] = {{&g_41,&g_41,(void*)0,&l_71},{&g_5,&g_63,&g_5,(void*)0},{&g_5,(void*)0,(void*)0,&g_5},{&g_41,(void*)0,&l_71,(void*)0},{(void*)0,&g_63,&l_71,&l_71}};
                int i, j;
                l_74--;
                --g_80;
                ++g_84;
            }
            --g_90;
        }
    }
    return g_90;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_79[i], "g_79[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_106[i].f0, "g_106[i].f0", print_hash_value);
        transparent_crc(g_106[i].f1, "g_106[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_110[i][j][k].f0, "g_110[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_134[i][j], "g_134[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_193, "g_193", print_hash_value);
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_202, "g_202", print_hash_value);
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_349, "g_349", print_hash_value);
    transparent_crc(g_350, "g_350", print_hash_value);
    transparent_crc(g_398, "g_398", print_hash_value);
    transparent_crc(g_420, "g_420", print_hash_value);
    transparent_crc(g_421, "g_421", print_hash_value);
    transparent_crc(g_424, "g_424", print_hash_value);
    transparent_crc(g_440, "g_440", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_482[i], "g_482[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_501.f0, "g_501.f0", print_hash_value);
    transparent_crc(g_501.f1, "g_501.f1", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_513[i], "g_513[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_524.f0.f0, "g_524.f0.f0", print_hash_value);
    transparent_crc(g_524.f0.f1, "g_524.f0.f1", print_hash_value);
    transparent_crc(g_524.f1.f0, "g_524.f1.f0", print_hash_value);
    transparent_crc(g_524.f1.f1, "g_524.f1.f1", print_hash_value);
    transparent_crc(g_524.f1.f2, "g_524.f1.f2", print_hash_value);
    transparent_crc(g_524.f1.f3, "g_524.f1.f3", print_hash_value);
    transparent_crc(g_524.f1.f4, "g_524.f1.f4", print_hash_value);
    transparent_crc(g_524.f2, "g_524.f2", print_hash_value);
    transparent_crc(g_524.f3, "g_524.f3", print_hash_value);
    transparent_crc(g_524.f4, "g_524.f4", print_hash_value);
    transparent_crc(g_524.f5.f0, "g_524.f5.f0", print_hash_value);
    transparent_crc(g_524.f5.f1, "g_524.f5.f1", print_hash_value);
    transparent_crc(g_524.f6, "g_524.f6", print_hash_value);
    transparent_crc(g_524.f7, "g_524.f7", print_hash_value);
    transparent_crc(g_524.f8, "g_524.f8", print_hash_value);
    transparent_crc(g_579.f0, "g_579.f0", print_hash_value);
    transparent_crc(g_579.f1, "g_579.f1", print_hash_value);
    transparent_crc(g_579.f2, "g_579.f2", print_hash_value);
    transparent_crc(g_579.f3, "g_579.f3", print_hash_value);
    transparent_crc(g_579.f4, "g_579.f4", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_619[i].f0, "g_619[i].f0", print_hash_value);
        transparent_crc(g_619[i].f1, "g_619[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_633, "g_633", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_641[i].f0, "g_641[i].f0", print_hash_value);
        transparent_crc(g_641[i].f1, "g_641[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_660[i][j][k], "g_660[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_770, "g_770", print_hash_value);
    transparent_crc(g_776, "g_776", print_hash_value);
    transparent_crc(g_836, "g_836", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 191
   depth: 1, occurrence: 29
   depth: 2, occurrence: 1
XXX total union variables: 2

XXX non-zero bitfields defined in structs: 8
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 2
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 26
breakdown:
   indirect level: 0, occurrence: 21
   indirect level: 1, occurrence: 5
XXX full-bitfields structs in the program: 19
breakdown:
   indirect level: 0, occurrence: 19
XXX times a bitfields struct's address is taken: 13
XXX times a bitfields struct on LHS: 4
XXX times a bitfields struct on RHS: 40
XXX times a single bitfield on LHS: 8
XXX times a single bitfield on RHS: 30

XXX max expression depth: 39
breakdown:
   depth: 1, occurrence: 111
   depth: 2, occurrence: 25
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 16, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 24, occurrence: 2
   depth: 25, occurrence: 3
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 39, occurrence: 1

XXX total number of pointers: 181

XXX times a variable address is taken: 340
XXX times a pointer is dereferenced on RHS: 60
breakdown:
   depth: 1, occurrence: 54
   depth: 2, occurrence: 6
XXX times a pointer is dereferenced on LHS: 94
breakdown:
   depth: 1, occurrence: 93
   depth: 2, occurrence: 1
XXX times a pointer is compared with null: 23
XXX times a pointer is compared with address of another variable: 2
XXX times a pointer is compared with another pointer: 2
XXX times a pointer is qualified to be dereferenced: 1508

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 388
   level: 2, occurrence: 38
   level: 3, occurrence: 27
   level: 4, occurrence: 5
XXX number of pointers point to pointers: 57
XXX number of pointers point to scalars: 104
XXX number of pointers point to structs: 19
XXX percent of pointers has null in alias set: 30.4
XXX average alias set size: 1.43

XXX times a non-volatile is read: 637
XXX times a non-volatile is write: 310
XXX times a volatile is read: 35
XXX    times read thru a pointer: 4
XXX times a volatile is write: 18
XXX    times written thru a pointer: 10
XXX times a volatile is available for access: 625
XXX percentage of non-volatile access: 94.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 106
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 14
   depth: 2, occurrence: 17
   depth: 3, occurrence: 12
   depth: 4, occurrence: 15
   depth: 5, occurrence: 24

XXX percentage a fresh-made variable is used: 20.9
XXX percentage an existing variable is used: 79.1
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

