/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3530546007
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   const volatile uint16_t  f0;
   volatile unsigned f1 : 15;
   const signed f2 : 9;
   signed f3 : 9;
   volatile unsigned f4 : 12;
};
#pragma pack(pop)

union U1 {
   int64_t  f0;
   volatile uint32_t  f1;
   signed f2 : 6;
   volatile unsigned f3 : 16;
};

/* --- GLOBAL VARIABLES --- */
static const volatile uint64_t g_7[9][6] = {{0x19820B275CF8B874LL,0xF9EB11DE2A907865LL,0x17A9413E458C458ALL,18446744073709551615UL,0x17A9413E458C458ALL,0xF9EB11DE2A907865LL},{0x19820B275CF8B874LL,0xB0E82CA9683648BDLL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0xEB8E136DC99220C4LL},{0x37BD55FD0A3205F5LL,18446744073709551615UL,0x19820B275CF8B874LL,0x393DDA37BB00868BLL,0x393DDA37BB00868BLL,0x19820B275CF8B874LL},{18446744073709551615UL,18446744073709551615UL,2UL,0x37BD55FD0A3205F5LL,18446744073709551615UL,0x393DDA37BB00868BLL},{0xF9EB11DE2A907865LL,0xB0E82CA9683648BDLL,18446744073709551615UL,2UL,0x17A9413E458C458ALL,2UL},{18446744073709551615UL,0xF9EB11DE2A907865LL,18446744073709551615UL,0xEB8E136DC99220C4LL,18446744073709551615UL,0x393DDA37BB00868BLL},{0xEA311C3FC0233FD5LL,0xEB8E136DC99220C4LL,2UL,0xBBD4AA41A80D1C1DLL,0x19820B275CF8B874LL,0x19820B275CF8B874LL},{0xBBD4AA41A80D1C1DLL,0x19820B275CF8B874LL,0x19820B275CF8B874LL,0xBBD4AA41A80D1C1DLL,0xF9EB11DE2A907865LL,0xB0E82CA9683648BDLL},{18446744073709551615UL,0x19820B275CF8B874LL,2UL,0xB0E82CA9683648BDLL,0x393DDA37BB00868BLL,0x37BD55FD0A3205F5LL}};
static int8_t g_16[4] = {(-1L),(-1L),(-1L),(-1L)};
static int32_t g_40 = 0x576953C5L;
static const int64_t g_43 = (-8L);
static uint8_t g_75[3][9] = {{0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL},{8UL,1UL,8UL,1UL,8UL,1UL,8UL,1UL,8UL},{0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL,0x8DL}};
static int32_t g_78 = (-3L);
static int32_t *g_77 = &g_78;
static uint64_t g_87 = 18446744073709551615UL;
static uint64_t g_92 = 18446744073709551611UL;
static int16_t g_108 = 9L;
static int64_t g_112 = (-9L);
static int32_t g_113 = (-10L);
static int32_t g_122 = (-8L);
static uint8_t g_123 = 1UL;
static uint64_t g_126 = 0x0DC27877F70597A7LL;
static int16_t g_144 = 0xD1FBL;
static int32_t g_145 = 0x719B2E0BL;
static int8_t g_146 = 1L;
static uint64_t g_147 = 0x685D562BBFFE0594LL;
static uint32_t g_180[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static union U1 g_184 = {0L};/* VOLATILE GLOBAL g_184 */
static union U1 g_187 = {0L};/* VOLATILE GLOBAL g_187 */
static union U1 g_188 = {0x334622F96A7537CALL};/* VOLATILE GLOBAL g_188 */
static union U1 g_189[1] = {{-1L}};
static union U1 *g_186[4][4] = {{&g_189[0],&g_188,&g_188,&g_189[0]},{&g_188,&g_189[0],&g_188,&g_188},{&g_189[0],&g_189[0],&g_187,&g_189[0]},{&g_189[0],&g_188,&g_188,&g_189[0]}};
static int32_t **g_201 = (void*)0;
static int32_t ***g_200 = &g_201;
static uint32_t g_223 = 0x8D706CD7L;
static uint8_t g_225[9][3] = {{1UL,0xAFL,0x97L},{1UL,1UL,0xAFL},{1UL,0xAFL,0xAFL},{0xAFL,0xD0L,0x97L},{1UL,0xD0L,1UL},{1UL,0xAFL,0x97L},{1UL,1UL,0xAFL},{1UL,0xAFL,0xAFL},{0xAFL,0xD0L,0x97L}};
static int32_t *g_235 = (void*)0;
static uint8_t g_269 = 250UL;
static uint8_t g_279[2][10] = {{0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL},{0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL,0xBAL}};
static uint16_t g_292 = 0x679CL;
static union U1 g_324 = {0L};/* VOLATILE GLOBAL g_324 */
static volatile uint32_t g_381 = 0xBB66C72AL;/* VOLATILE GLOBAL g_381 */
static volatile uint32_t * volatile g_380 = &g_381;/* VOLATILE GLOBAL g_380 */
static volatile uint32_t * volatile *g_379 = &g_380;
static const int32_t *g_392 = &g_122;
static const int32_t **g_391[2] = {&g_392,&g_392};
static const int32_t ***g_390 = &g_391[0];
static const int32_t ****g_389 = &g_390;
static int64_t g_442[3][3][4] = {{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}}};
static uint8_t *g_480 = &g_75[1][0];
static int8_t g_514 = 0x40L;
static uint64_t g_532 = 0x8622E75C981B6B1CLL;
static int16_t g_561[2] = {0xDEE3L,0xDEE3L};
static uint32_t g_633 = 0xD91697D3L;
static union U1 ***g_669[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 **g_679 = &g_186[0][1];
static union U1 ** volatile * const g_678 = &g_679;
static uint32_t *g_734 = &g_180[4];
static uint32_t g_756[8] = {0xF1432BBDL,0UL,0xF1432BBDL,0xF1432BBDL,0UL,0xF1432BBDL,0xF1432BBDL,0UL};
static volatile int16_t g_803 = 1L;/* VOLATILE GLOBAL g_803 */
static volatile int16_t * const g_802 = &g_803;
static volatile int16_t * const  volatile *g_801[8][4] = {{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802},{&g_802,&g_802,&g_802,&g_802}};
static const uint16_t g_816 = 0x7734L;
static uint64_t g_843[3][10] = {{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}};
static uint8_t **g_881 = &g_480;
static int32_t g_909 = 0xFBF42A6AL;
static uint16_t g_991 = 1UL;
static uint32_t g_997 = 18446744073709551615UL;
static int8_t *g_1004 = &g_146;
static int32_t g_1028 = 1L;
static int32_t g_1029 = 7L;
static int32_t g_1030 = 4L;
static int8_t g_1031 = (-5L);
static uint32_t g_1032 = 0x636CF44AL;
static union U1 g_1047 = {0x31C11950477D1036LL};/* VOLATILE GLOBAL g_1047 */
static union U1 g_1048 = {-1L};/* VOLATILE GLOBAL g_1048 */
static int64_t g_1112[10][3] = {{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)},{(-1L),(-1L),(-6L)}};
static uint64_t g_1113 = 0x8E07773B814A3F1BLL;
static int8_t g_1120 = 3L;
static int64_t g_1121[8][10][3] = {{{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL}},{{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)}},{{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL}},{{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)}},{{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL}},{{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)}},{{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL}},{{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)},{0x053605A3738014CBLL,0x024B246F3BDBA2E1LL,0xD1FC9525FE6A46B3LL},{0x0387701F00887225LL,6L,0x0BF0B743B2E6C399LL},{0x2E5099DB4FF48FBDLL,0x2E5099DB4FF48FBDLL,0xD1FC9525FE6A46B3LL},{(-8L),1L,(-8L)},{0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL,0x024B246F3BDBA2E1LL},{0x0387701F00887225LL,1L,0x0BF0B743B2E6C399LL},{0x053605A3738014CBLL,0x2E5099DB4FF48FBDLL,0x024B246F3BDBA2E1LL},{(-8L),6L,(-8L)}}};
static int8_t g_1122 = 1L;
static uint8_t g_1124 = 249UL;
static uint16_t g_1159 = 0x5A1BL;
static uint32_t * const *g_1193 = (void*)0;
static uint32_t g_1197 = 4294967290UL;
static uint32_t g_1198 = 4294967287UL;
static uint32_t g_1199 = 4294967295UL;
static uint32_t g_1200 = 0xF547B74BL;
static uint32_t g_1201 = 1UL;
static uint32_t g_1202 = 0UL;
static uint32_t g_1203 = 0x90626B2DL;
static uint32_t g_1204 = 1UL;
static uint32_t g_1205 = 4294967288UL;
static uint32_t g_1206 = 4294967289UL;
static uint32_t g_1207 = 0UL;
static uint32_t g_1208 = 4294967295UL;
static uint32_t g_1209 = 0x4D1CB582L;
static uint32_t g_1210 = 0xBE0FECEDL;
static uint32_t g_1211 = 0x6851D42BL;
static uint32_t g_1212[4][9] = {{0xCF9E7C65L,0x3EA79603L,0xDFC162D7L,0x3EA79603L,0xCF9E7C65L,0x107FDCACL,1UL,3UL,4294967295UL},{5UL,0x3EA79603L,0x107FDCACL,4294967295UL,0UL,4294967293UL,0xF121C24CL,4294967293UL,0UL},{1UL,0UL,0UL,1UL,4294967295UL,0x107FDCACL,0xDFC162D7L,0xF121C24CL,0x166C1A9DL},{1UL,0xCEBDD699L,0x83CB3843L,0x107FDCACL,0x166C1A9DL,4294967295UL,4294967295UL,0x166C1A9DL,0x107FDCACL}};
static uint32_t g_1213[9] = {4294967288UL,4294967288UL,0x0C69A935L,4294967288UL,4294967288UL,0x0C69A935L,4294967288UL,4294967288UL,0x0C69A935L};
static uint32_t g_1214 = 0x66F6977AL;
static uint32_t g_1215 = 1UL;
static uint32_t g_1216 = 0x57C9C1FFL;
static uint32_t g_1217 = 0x8EAE3F74L;
static uint32_t g_1218 = 4294967290UL;
static uint32_t g_1219 = 0xABE49F76L;
static uint32_t g_1220 = 0xC24EC16FL;
static uint32_t g_1221 = 0UL;
static uint32_t g_1222 = 0x1E0F46C6L;
static uint32_t g_1223 = 0x0992EF4FL;
static uint32_t g_1224 = 0xA3DB57EBL;
static uint32_t g_1225 = 0x420CCE37L;
static uint32_t g_1226 = 0xB4EB2051L;
static uint32_t g_1227 = 4294967295UL;
static uint32_t g_1228 = 0UL;
static uint32_t g_1229 = 0x7A21207CL;
static uint32_t g_1230[5][8] = {{1UL,1UL,4294967294UL,1UL,1UL,4294967294UL,1UL,1UL},{4294967292UL,1UL,4294967292UL,4294967292UL,1UL,4294967292UL,4294967292UL,1UL},{1UL,4294967292UL,4294967292UL,1UL,4294967292UL,4294967292UL,1UL,4294967292UL},{1UL,1UL,4294967294UL,1UL,1UL,1UL,4294967292UL,4294967292UL},{4294967294UL,4294967292UL,4294967294UL,4294967294UL,4294967292UL,4294967294UL,4294967294UL,4294967292UL}};
static uint32_t g_1231 = 0UL;
static uint32_t g_1232[8] = {4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL,4294967287UL};
static uint32_t g_1233 = 0xCE4134B6L;
static uint32_t g_1234 = 0x27A830BCL;
static uint32_t g_1235 = 0x88241C89L;
static uint32_t g_1236 = 0UL;
static uint32_t g_1237 = 1UL;
static uint32_t g_1238 = 0x8BF14479L;
static uint32_t g_1239 = 0x4DF0287DL;
static uint32_t g_1240 = 0UL;
static uint32_t g_1241[4] = {0x92FA8146L,0x92FA8146L,0x92FA8146L,0x92FA8146L};
static uint32_t g_1242 = 0x0DB0E308L;
static uint32_t g_1243 = 4294967287UL;
static uint32_t g_1244 = 0x7B7751DCL;
static uint32_t g_1245 = 0x3948F212L;
static uint32_t g_1246 = 0xEA81D353L;
static uint32_t g_1247 = 0xC92CB7D7L;
static uint32_t g_1248 = 9UL;
static uint32_t g_1249 = 2UL;
static uint32_t g_1250 = 5UL;
static uint32_t g_1251 = 4294967295UL;
static uint32_t g_1252 = 0x0C45B4CEL;
static uint32_t g_1253 = 4294967295UL;
static uint32_t g_1254 = 4294967290UL;
static uint32_t g_1255 = 0xC6B5D8A4L;
static uint32_t g_1256 = 0x51246CD2L;
static uint32_t g_1257[8][5] = {{0xAF8D8A22L,0UL,0xAF8D8A22L,0UL,0xAF8D8A22L},{0xC472D707L,0xC472D707L,1UL,1UL,0xC472D707L},{0xED638CB1L,0UL,0xED638CB1L,0UL,0xED638CB1L},{0xC472D707L,1UL,1UL,0xC472D707L,0xC472D707L},{0xAF8D8A22L,0UL,0xAF8D8A22L,0UL,0xAF8D8A22L},{0xC472D707L,0xC472D707L,1UL,1UL,0xC472D707L},{0xED638CB1L,0UL,0xED638CB1L,0UL,0xED638CB1L},{0xC472D707L,1UL,1UL,0xC472D707L,0xC472D707L}};
static uint32_t g_1258 = 4294967286UL;
static uint32_t g_1259[6][8][5] = {{{0x86CD623AL,4294967295UL,4294967295UL,0xE78E5E73L,1UL},{0xA7A23E93L,0x00878792L,0xC2A6FDFDL,4294967294UL,0x86CD623AL},{0xA7A23E93L,0xE78E5E73L,0xF05A4ED4L,0x1F442D83L,0x2E11857EL},{0x86CD623AL,0x00878792L,0xF05A4ED4L,0UL,0x4F3692BEL},{1UL,4294967295UL,0xC2A6FDFDL,0x1F442D83L,0x4F3692BEL},{0x2E11857EL,4294967294UL,4294967295UL,4294967294UL,0x2E11857EL},{1UL,4294967294UL,0UL,0xE78E5E73L,0x86CD623AL},{0x86CD623AL,4294967295UL,4294967295UL,0xE78E5E73L,1UL}},{{0xA7A23E93L,0x00878792L,0xC2A6FDFDL,4294967294UL,0x86CD623AL},{0xA7A23E93L,0xE78E5E73L,0xF05A4ED4L,0x1F442D83L,0x2E11857EL},{0x86CD623AL,0x00878792L,0xF05A4ED4L,0UL,0x4F3692BEL},{1UL,4294967295UL,0xC2A6FDFDL,0x1F442D83L,0x4F3692BEL},{0x2E11857EL,4294967294UL,4294967295UL,4294967294UL,0x2E11857EL},{1UL,4294967294UL,0UL,0xE78E5E73L,0x86CD623AL},{0x86CD623AL,4294967295UL,4294967295UL,0xE78E5E73L,1UL},{0xA7A23E93L,0x00878792L,0xC2A6FDFDL,4294967294UL,0x86CD623AL}},{{0xA7A23E93L,0xE78E5E73L,0xF05A4ED4L,0x1F442D83L,0x2E11857EL},{0x86CD623AL,0x00878792L,0xF05A4ED4L,0UL,0x4F3692BEL},{1UL,4294967295UL,0xC2A6FDFDL,0x1F442D83L,0x4F3692BEL},{0x2E11857EL,4294967294UL,4294967295UL,4294967294UL,0x2E11857EL},{1UL,4294967294UL,0UL,0xE78E5E73L,0x86CD623AL},{0x86CD623AL,4294967295UL,4294967295UL,0xE78E5E73L,1UL},{0xA7A23E93L,0x00878792L,0xC2A6FDFDL,4294967294UL,0x86CD623AL},{0xA7A23E93L,0xE78E5E73L,0xF05A4ED4L,0x1F442D83L,0x2E11857EL}},{{0x86CD623AL,0x00878792L,0xF05A4ED4L,0UL,0x4F3692BEL},{1UL,4294967295UL,0xC2A6FDFDL,0x9341F873L,4294967295UL},{0x1F442D83L,0xD2CC0F88L,0xE19BE3ECL,0xD2CC0F88L,0x1F442D83L},{0xE78E5E73L,0xD2CC0F88L,0xDC6D0161L,0xDACBD602L,0UL},{0UL,0UL,0xE19BE3ECL,0xDACBD602L,4294967294UL},{0x00878792L,0xCFC37BE3L,4294967286UL,0xD2CC0F88L,0UL},{0x00878792L,0xDACBD602L,0x0BFC97D1L,0x9341F873L,0x1F442D83L},{0UL,0xCFC37BE3L,0x0BFC97D1L,4294967295UL,4294967295UL}},{{0xE78E5E73L,0UL,4294967286UL,0x9341F873L,4294967295UL},{0x1F442D83L,0xD2CC0F88L,0xE19BE3ECL,0xD2CC0F88L,0x1F442D83L},{0xE78E5E73L,0xD2CC0F88L,0xDC6D0161L,0xDACBD602L,0UL},{0UL,0UL,0xE19BE3ECL,0xDACBD602L,4294967294UL},{0x00878792L,0xCFC37BE3L,4294967286UL,0xD2CC0F88L,0UL},{0x00878792L,0xDACBD602L,0x0BFC97D1L,0x9341F873L,0x1F442D83L},{0UL,0xCFC37BE3L,0x0BFC97D1L,4294967295UL,4294967295UL},{0xE78E5E73L,0UL,4294967286UL,0x9341F873L,4294967295UL}},{{0x1F442D83L,0xD2CC0F88L,0xE19BE3ECL,0xD2CC0F88L,0x1F442D83L},{0xE78E5E73L,0xD2CC0F88L,0xDC6D0161L,0xDACBD602L,0UL},{0UL,0UL,0xE19BE3ECL,0xDACBD602L,4294967294UL},{0x00878792L,0xCFC37BE3L,4294967286UL,0xD2CC0F88L,0UL},{0x00878792L,0xDACBD602L,0x0BFC97D1L,0x9341F873L,0x1F442D83L},{0UL,0xCFC37BE3L,0x0BFC97D1L,4294967295UL,4294967295UL},{0xE78E5E73L,0UL,4294967286UL,0x9341F873L,4294967295UL},{0x1F442D83L,0xD2CC0F88L,0xE19BE3ECL,0xD2CC0F88L,0x1F442D83L}}};
static int32_t g_1294 = 1L;
static uint64_t g_1297 = 0UL;
static int16_t *g_1302 = &g_561[0];
static int64_t g_1417 = 5L;
static int32_t *g_1442 = (void*)0;
static const union U1 g_1490 = {0xAD12C3011DAEC4D1LL};/* VOLATILE GLOBAL g_1490 */
static union U1 g_1493 = {-3L};/* VOLATILE GLOBAL g_1493 */
static int16_t g_1517 = 0x8204L;
static volatile union U1 g_1582 = {0x18F7E249C1FC6292LL};/* VOLATILE GLOBAL g_1582 */
static uint32_t g_1587 = 0x8EA067B1L;
static uint64_t g_1599 = 1UL;
static int32_t g_1624 = 1L;
static struct S0 g_1689 = {0xDBB2L,98,20,9,60};/* VOLATILE GLOBAL g_1689 */
static union U1 * const *g_1717[2] = {(void*)0,(void*)0};
static union U1 * const **g_1716 = &g_1717[0];
static union U1 * const ***g_1715[5][10] = {{(void*)0,(void*)0,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716},{&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,(void*)0,(void*)0,&g_1716,&g_1716},{(void*)0,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,(void*)0,(void*)0,&g_1716},{(void*)0,(void*)0,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716},{&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,&g_1716,(void*)0,(void*)0,&g_1716,&g_1716}};
static union U1 * const ****g_1714 = &g_1715[4][8];
static uint16_t g_1760[6][3][3] = {{{0x20EAL,0x106FL,3UL},{3UL,0xFBBFL,3UL},{3UL,65530UL,0x1E04L}},{{0x72E3L,0x3CF4L,65535UL},{0UL,0UL,0UL},{0x3CF4L,0UL,0UL}},{{0UL,65535UL,0x3CF4L},{0x72E3L,0x1E04L,65530UL},{3UL,3UL,0xFBBFL}},{{65535UL,65535UL,0xBA87L},{3UL,3UL,0UL},{0x72E3L,0UL,0x20EAL}},{{4UL,0x106FL,0UL},{3UL,0x72E3L,0x20EAL},{0xFBBFL,1UL,0UL}},{{65535UL,0xFBBFL,0xBA87L},{0UL,4UL,4UL},{0UL,0xBA87L,0xFBBFL}}};
static union U1 * volatile *g_1835 = &g_186[1][2];
static union U1 * volatile ** volatile g_1834 = &g_1835;/* VOLATILE GLOBAL g_1834 */
static uint32_t g_1851 = 0x62542DC3L;
static volatile struct S0 * volatile * const g_1858 = (void*)0;
static uint32_t *g_1909 = (void*)0;
static struct S0 *g_1911 = (void*)0;
static struct S0 ** volatile g_1910 = &g_1911;/* VOLATILE GLOBAL g_1910 */
static union U1 ** const *g_1940[9] = {&g_679,&g_679,&g_679,&g_679,&g_679,&g_679,&g_679,&g_679,&g_679};
static union U1 ** const **g_1939 = &g_1940[5];
static union U1 ** const ***g_1938 = &g_1939;
static union U1 ** const ****g_1937 = &g_1938;
static volatile struct S0 g_1946 = {0xF319L,22,16,11,3};/* VOLATILE GLOBAL g_1946 */
static volatile int16_t * const *g_2022 = &g_802;
static volatile int16_t * const ** const  volatile g_2021 = &g_2022;/* VOLATILE GLOBAL g_2021 */


/* --- FORWARD DECLARATIONS --- */
static const int16_t  func_1(void);
static int32_t * func_2(int8_t  p_3, uint32_t  p_4, uint32_t  p_5, uint8_t  p_6);
static int32_t * func_10(int32_t  p_11, int64_t  p_12, int8_t  p_13, int64_t  p_14, int8_t  p_15);
static uint64_t  func_27(int8_t  p_28, uint8_t  p_29, int32_t * p_30, int32_t * p_31);
static int8_t  func_34(int32_t  p_35);
static uint8_t  func_47(const uint8_t  p_48, uint16_t  p_49);
static int8_t  func_52(int32_t  p_53, uint64_t  p_54);
static uint64_t  func_57(uint16_t  p_58, uint64_t  p_59, int32_t ** p_60, const int8_t  p_61);
static int8_t  func_62(int32_t ** p_63, int32_t  p_64, const int64_t  p_65);
static int32_t ** func_66(int32_t * p_67);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_16 g_43 g_40 g_87 g_92 g_78 g_108 g_77 g_112 g_113 g_123 g_126 g_75 g_147 g_200 g_146 g_223 g_225 g_188.f0 g_145 g_235 g_189.f0 g_180 g_122 g_201 g_187.f0 g_188.f2 g_269 g_279 g_184.f0 g_189.f2 g_186 g_144 g_184.f2 g_389 g_390 g_391 g_756 g_679 g_480 g_801 g_292 g_843 g_514 g_1032 g_532 g_1004 g_1302 g_561 g_1207 g_1124 g_881 g_1255 g_1213 g_1030 g_1197 g_1210 g_1227 g_1256 g_1442 g_909 g_1294 g_1208 g_1252 g_1225 g_1031 g_1215 g_1121 g_1250 g_678 g_1251 g_1112 g_1259 g_1113 g_1517 g_392 g_1028 g_442 g_1219 g_1159 g_380 g_381 g_1047.f0 g_1582 g_1587 g_1490.f2 g_379 g_1233 g_1599 g_802 g_803 g_1624 g_991 g_184.f1 g_1218 g_1714 g_1212 g_997 g_1760 g_1238 g_1221 g_1203 g_1206 g_1201 g_1199 g_1417 g_1200 g_1253 g_1231 g_1493.f0 g_1214 g_1048.f3 g_1204 g_1241 g_1851 g_1258 g_1910 g_1937 g_1232 g_1946 g_1216 g_1490.f1 g_1689.f3 g_1689.f2 g_1047.f2 g_1205 g_2021
 * writes: g_40 g_75 g_77 g_87 g_78 g_108 g_112 g_113 g_123 g_126 g_147 g_223 g_180 g_144 g_122 g_146 g_92 g_269 g_279 g_292 g_184.f2 g_184.f0 g_145 g_189.f2 g_188.f0 g_392 g_442 g_187.f0 g_225 g_881 g_1032 g_186 g_1124 g_561 g_734 g_1004 g_1417 g_1210 g_532 g_1227 g_909 g_1209 g_480 g_1294 g_1252 g_1121 g_324.f0 g_1122 g_1517 g_1047.f0 g_991 g_1028 g_1238 g_1159 g_1714 g_1760 g_1200 g_1249 g_514 g_200 g_1203 g_1206 g_1201 g_1199 g_1214 g_1909 g_1911 g_201 g_1624 g_1937 g_1599 g_1205 g_2022
 */
static const int16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_17 = 0UL;
    int32_t *l_39 = &g_40;
    int32_t **l_38 = &l_39;
    int32_t *l_42 = &g_40;
    int32_t **l_41 = &l_42;
    uint16_t l_44[6] = {65528UL,65528UL,65528UL,65528UL,65528UL,65528UL};
    int8_t *l_1441 = &g_146;
    int32_t *l_1443 = &g_1294;
    int64_t *l_1484 = &g_1121[2][9][2];
    int32_t l_1485 = 0x95EF7014L;
    int32_t l_1518 = 0x054440A7L;
    uint16_t l_1549 = 0x5F70L;
    uint32_t l_1550 = 0x30D53984L;
    union U1 * const *l_1643 = &g_186[0][1];
    uint32_t l_1744 = 4294967292UL;
    int32_t l_1759 = 0L;
    int8_t l_1820 = 0L;
    int16_t **l_1827 = &g_1302;
    int16_t ***l_1826 = &l_1827;
    union U1 *l_1868 = &g_184;
    union U1 **l_1912 = (void*)0;
    uint8_t ** const *l_1986 = (void*)0;
    uint32_t l_1992[5] = {0x55FBC460L,0x55FBC460L,0x55FBC460L,0x55FBC460L,0x55FBC460L};
    uint32_t l_1995 = 0UL;
    uint8_t **l_2010[9] = {&g_480,&g_480,&g_480,&g_480,&g_480,&g_480,&g_480,&g_480,&g_480};
    int16_t *l_2018 = &g_1517;
    const uint64_t l_2023[6][3] = {{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL}};
    int i, j;
    (**g_390) = func_2((0x3607A988L & g_7[0][2]), ((safe_rshift_func_int8_t_s_s((((((*l_38) = func_10(g_16[1], l_17, (!(((*l_1484) &= (safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_div_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(func_27(((*l_1441) = (safe_div_func_int8_t_s_s(func_34((((safe_add_func_int64_t_s_s(((18446744073709551615UL || 0xE7675DAAFE497D6ALL) , (((*l_41) = ((*l_38) = (void*)0)) != &g_40)), (g_43 , g_40))) && l_44[3]) , g_43)), 251UL))), g_1256, g_1442, l_1443), 0xB147E73B118238C0LL)), g_1225)), g_1031)), g_1215))) && g_1207)), l_1485, g_1250)) == &l_1485) | g_1113) , 0xBBL), 2)) && g_1517), g_16[1], l_1518);
    if ((***g_390))
    { /* block id: 734 */
        uint8_t l_1523 = 0x9CL;
        int32_t *****l_1532 = (void*)0;
        int16_t l_1564 = 1L;
        const int64_t l_1566 = 0x4F261C1E0E8C4156LL;
        uint32_t l_1585 = 4294967295UL;
        int8_t l_1647 = 0xCCL;
        union U1 **l_1710 = &g_186[0][1];
        int32_t l_1752[3];
        int32_t *l_1769 = &g_40;
        uint8_t **l_1800 = &g_480;
        union U1 ****l_1936 = &g_669[5];
        union U1 *****l_1935 = &l_1936;
        union U1 ***** const *l_1934 = &l_1935;
        int i;
        for (i = 0; i < 3; i++)
            l_1752[i] = 0x55DCE5E2L;
        if ((*g_392))
        { /* block id: 735 */
            int16_t l_1548 = 0x9345L;
            int32_t l_1567 = 0L;
            uint32_t l_1671 = 0xC47131E5L;
            int32_t l_1698 = 0xB4EFFDB2L;
            uint64_t l_1719 = 0x423FE3728F0A167CLL;
            int32_t l_1757 = 1L;
            int32_t l_1758 = 0x353DE3BCL;
            int32_t *l_1770 = &l_1485;
lbl_1571:
            --l_1523;
            if ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_s((g_1122 = l_1523), (&g_909 != (void*)0))), 3)))
            { /* block id: 738 */
                uint32_t *l_1539 = &g_223;
                uint32_t **l_1538 = &l_1539;
                uint32_t ***l_1537 = &l_1538;
                int16_t *l_1540 = &g_1517;
                int32_t l_1558 = 9L;
                uint32_t l_1614 = 0UL;
                uint8_t * const *l_1632 = &g_480;
                uint64_t l_1669 = 0xB8E8923BC8CAA850LL;
                int32_t l_1670 = 0x1B7D6299L;
                union U1 ***** const l_1720 = (void*)0;
                uint32_t l_1763 = 0x051BD923L;
                if ((safe_sub_func_uint32_t_u_u(l_1523, ((&g_389 == l_1532) ^ (safe_rshift_func_int8_t_s_u((((safe_lshift_func_int16_t_s_s(((*g_1302) = (*l_39)), ((void*)0 != l_1537))) & ((*l_1540) = (*l_1443))) , ((safe_mod_func_int64_t_s_s((safe_lshift_func_int16_t_s_s((~g_1113), 6)), ((safe_lshift_func_uint8_t_u_s(((**g_881) = l_1548), (*l_39))) , l_1549))) != 0x0BB91B8FL)), l_1550))))))
                { /* block id: 742 */
                    const int32_t **l_1563 = &g_392;
                    uint8_t **l_1578[5];
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1578[i] = &g_480;
                    for (g_1047.f0 = (-2); (g_1047.f0 >= (-1)); g_1047.f0 = safe_add_func_uint64_t_u_u(g_1047.f0, 2))
                    { /* block id: 745 */
                        uint16_t *l_1553 = &g_991;
                        uint16_t *l_1565 = &l_1549;
                        uint8_t l_1568 = 253UL;
                        (*l_1443) ^= ((((*l_1553) = g_442[2][2][2]) || 65526UL) >= (safe_mod_func_int8_t_s_s((((**l_38) = ((safe_mod_func_int8_t_s_s(1L, (((l_1558 || (((((((((*l_1565) = ((((*g_480) , ((((((((safe_mul_func_int16_t_s_s(((*g_1302) = (((**l_1538) = 0xA7017F6EL) , ((((((((void*)0 == &g_1159) < ((*l_1540) = (((safe_div_func_uint64_t_u_u(l_1548, 0x608F7F540D011FBDLL)) & (*l_39)) , 1L))) || 0xE72700F2L) > 65535UL) , (*g_390)) == l_1563) , 0xA67AL))), (-1L))) , 0x8B971FB39E8DDBC6LL) & l_1564) || l_1548) == (**l_1563)) && 8UL) , l_1558) >= (**l_1563))) || (**g_881)) >= l_1558)) && l_1566) , 0L) == l_1567) > l_1568) , (*l_38)) != (*l_1563)) || l_1548)) , 0x47E5L) || g_1219))) > g_1159)) || (*g_380)), 0x99L)));
                    }
                    if ((**l_1563))
                    { /* block id: 754 */
                        int32_t *l_1569[6][3][2] = {{{&l_1558,&l_1558},{&l_1558,&g_1029},{&l_1558,&g_1028}},{{&g_1029,&g_1028},{&l_1558,&g_1029},{&l_1558,&l_1558}},{{&l_1558,&g_1029},{&l_1558,&g_1028},{&g_1029,&g_1028}},{{&l_1558,&g_1029},{&l_1558,&l_1558},{&l_1558,&g_1029}},{{&l_1558,&g_1028},{&g_1029,&g_1028},{&l_1558,&g_1029}},{{&l_1558,&l_1558},{&l_1558,&g_1029},{&l_1558,&g_1028}}};
                        int i, j, k;
                        l_1569[2][1][1] = ((*l_41) = (*l_38));
                        if (g_1047.f0)
                            goto lbl_1570;
lbl_1570:
                        (**l_41) |= (&g_7[0][2] != &g_843[1][2]);
                        if (g_188.f0)
                            goto lbl_1571;
                    }
                    else
                    { /* block id: 760 */
                        uint8_t * const *l_1576 = &g_480;
                        uint8_t * const **l_1577 = &l_1576;
                        uint64_t *l_1579[4][3];
                        int32_t l_1586 = 1L;
                        uint32_t *l_1598 = &g_1238;
                        int16_t ***l_1602 = (void*)0;
                        int i, j;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_1579[i][j] = &g_87;
                        }
                        (*l_1443) = ((**l_38) = ((safe_rshift_func_int16_t_s_s(4L, 2)) < ((g_1121[1][1][2] = ((((((*l_1577) = l_1576) == l_1578[2]) || (g_87--)) && ((*l_1540) = ((g_1582 , 246UL) & (0x1D37345EL ^ (safe_div_func_int8_t_s_s((l_1558 > (((**g_881) &= ((((((l_1585 || l_1586) == g_188.f2) >= l_1586) >= 3L) , 0x40F6784EL) & (-2L))) , 0x7634L)), g_1587)))))) , l_1548)) < 0x3F8F4266A9B79C5FLL)));
                        (**l_38) = (((safe_sub_func_int16_t_s_s((safe_div_func_uint8_t_u_u((*g_480), ((((*l_1539)++) >= l_1586) && (safe_mod_func_uint8_t_u_u((&l_1567 != &g_113), g_1490.f2))))), ((((safe_rshift_func_uint8_t_u_u((*g_480), 0)) , l_1567) | 0x6770L) < ((((((((*l_1598) = (*l_39)) == (**g_379)) | g_1233) > (*g_1302)) , (*l_1443)) | g_1599) & 0x202ADACBFCC4F4C4LL)))) || l_1558) , (***g_390));
                        (*l_1443) = (*g_392);
                        (**l_38) &= ((1L | (&g_801[4][0] != l_1602)) , (safe_add_func_int8_t_s_s(((safe_rshift_func_int8_t_s_s((((l_1585 | (((((((*l_1539)--) && (safe_div_func_uint8_t_u_u(((**g_881)++), (safe_unary_minus_func_uint16_t_u(l_1614))))) ^ 1UL) , l_1586) , ((safe_rshift_func_uint8_t_u_u(((((safe_mul_func_int8_t_s_s(((**l_1563) && (safe_rshift_func_int8_t_s_u((~((((safe_add_func_uint32_t_u_u(((*l_1539) |= (l_1558 != (-1L))), 0x54BF2BC9L)) && 0xE6L) < 6UL) < 0xFA99DE7DL)), 1))), l_1523)) <= g_561[0]) , (*g_802)) , (**g_881)), 4)) ^ (**l_1563))) < 1UL)) == 0xE28FB9600A7024DELL) <= 0x40C4EC5900D5DF76LL), 3)) == (-1L)), g_1624)));
                    }
                    (*l_1443) = (-1L);
                }
                else
                { /* block id: 778 */
                    uint16_t l_1625 = 65535UL;
                    uint16_t *l_1633 = &l_44[3];
                    uint64_t *l_1644 = (void*)0;
                    uint64_t *l_1645 = (void*)0;
                    uint64_t *l_1646 = &g_532;
                    int32_t *l_1687 = &g_145;
                    int32_t l_1747 = 0x258EE467L;
                    int32_t l_1753 = 0xE3D796A9L;
                    int32_t l_1754 = (-2L);
                    int32_t l_1755 = 0L;
                    int32_t l_1756[7][7] = {{6L,6L,0x8988EFF9L,0x8988EFF9L,6L,6L,0x8988EFF9L},{(-10L),0x3DED7B8FL,(-10L),0x3DED7B8FL,(-10L),0x3DED7B8FL,(-10L)},{6L,0x8988EFF9L,0x8988EFF9L,6L,6L,0x8988EFF9L,0x8988EFF9L},{0x6FC6B4C3L,0x3DED7B8FL,0x6FC6B4C3L,0x3DED7B8FL,0x6FC6B4C3L,0x3DED7B8FL,0x6FC6B4C3L},{6L,6L,0x8988EFF9L,0x8988EFF9L,6L,6L,0x8988EFF9L},{(-10L),0x3DED7B8FL,(-10L),0x3DED7B8FL,(-10L),0x3DED7B8FL,(-10L)},{6L,0x8988EFF9L,0x8988EFF9L,6L,6L,0x8988EFF9L,0x8988EFF9L}};
                    int i, j;
                    l_1625 = ((*g_77) = 1L);
                    if ((safe_unary_minus_func_uint16_t_u((((*g_480) |= (((((*g_1302) |= ((((safe_sub_func_int64_t_s_s(((*l_1484) = (&l_1585 == (*g_379))), (safe_div_func_uint16_t_u_u(l_1625, ((*l_1633) = ((safe_unary_minus_func_int8_t_s(((void*)0 == l_1632))) , l_1625)))))) & ((g_1517 < ((*l_1646) = (safe_mod_func_int8_t_s_s((safe_add_func_uint32_t_u_u((0xB4EFD1E4L & (safe_div_func_int8_t_s_s(((((safe_unary_minus_func_uint32_t_u(((safe_lshift_func_int8_t_s_s((l_1558 = (((l_1548 > l_1567) | 18446744073709551609UL) || 0UL)), l_1614)) <= l_1614))) & (-2L)) , (void*)0) == l_1643), l_1614))), (*g_392))), l_1614)))) & g_756[0])) | l_1647) != g_991)) ^ 0x0DF5L) <= 1UL) == 1UL)) >= (*l_1443)))))
                    { /* block id: 787 */
                        int16_t l_1663 = 0xD848L;
                        int8_t *l_1676[2][7] = {{&g_514,&g_514,(void*)0,&g_514,&g_514,(void*)0,&g_514},{&g_146,&g_1120,&g_1120,&g_146,&g_1120,&g_1120,&g_146}};
                        int i, j;
                        (*g_77) = 0L;
                        l_1671 &= ((safe_div_func_int64_t_s_s(((((safe_sub_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((~(g_184.f1 <= l_1548)) & (((((*l_39) ^ (((*l_1484) |= (((-6L) ^ (safe_rshift_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s((+(*g_480)), ((((((*l_39) < (+(l_1663 >= ((+(safe_lshift_func_int8_t_s_s((((safe_mod_func_uint32_t_u_u((**l_38), 1UL)) , l_1669) , g_108), 3))) , 252UL)))) | (**g_881)) != g_1251) | l_1614) , (*g_1302)))) , 0UL), l_1625))) ^ (*g_77))) > l_1663)) ^ 0L) , g_16[3]) , l_1663)), l_1670)), 7L)), (*g_480))) < 0xB529L) ^ 6UL) ^ (-1L)), 0x8BAC55286F1FABCBLL)) & 0x2EBA9BA6L);
                        (*g_77) |= ((*l_39) |= ((*g_380) >= (safe_rshift_func_uint16_t_u_u(0x7F68L, (((((safe_lshift_func_int8_t_s_s(g_113, 7)) | (l_1676[1][3] == (void*)0)) ^ g_1218) ^ (safe_add_func_uint64_t_u_u(((++(***l_1537)) ^ (safe_mul_func_int16_t_s_s(0x3CADL, ((safe_lshift_func_uint16_t_u_u((((*l_1633) ^= ((safe_mod_func_uint16_t_u_u(0xA9A8L, g_1252)) , 0xC801L)) > (-1L)), 15)) , (*g_1302))))), l_1663))) > (*g_1302))))));
                        (*l_41) = l_1687;
                    }
                    else
                    { /* block id: 796 */
                        struct S0 *l_1688 = &g_1689;
                        struct S0 **l_1690 = &l_1688;
                        int32_t l_1695 = 0x56F14B9DL;
                        const uint64_t l_1705 = 0x3EB89299D3F8A73BLL;
                        union U1 ***l_1711 = &l_1710;
                        const union U1 **l_1712 = (void*)0;
                        const union U1 ***l_1713 = &l_1712;
                        union U1 * const *****l_1718[9][9][3] = {{{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714}},{{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,(void*)0,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{(void*)0,&g_1714,&g_1714}},{{&g_1714,(void*)0,&g_1714},{(void*)0,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,(void*)0,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0}},{{&g_1714,(void*)0,(void*)0},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{&g_1714,&g_1714,(void*)0},{&g_1714,&g_1714,&g_1714},{(void*)0,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{(void*)0,&g_1714,(void*)0}},{{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714}},{{&g_1714,(void*)0,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{(void*)0,&g_1714,&g_1714},{&g_1714,(void*)0,&g_1714},{(void*)0,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714}},{{&g_1714,(void*)0,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{&g_1714,(void*)0,(void*)0},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{&g_1714,&g_1714,(void*)0}},{{&g_1714,&g_1714,&g_1714},{(void*)0,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{(void*)0,&g_1714,(void*)0},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,(void*)0},{&g_1714,(void*)0,(void*)0}},{{(void*)0,&g_1714,(void*)0},{(void*)0,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714},{&g_1714,&g_1714,&g_1714}}};
                        int i, j, k;
                        (*l_1690) = l_1688;
                        l_1698 ^= ((*l_1687) = ((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(l_1695, 1)), l_1614)) != ((--g_1159) & (**l_38))));
                        (*l_1443) |= (safe_sub_func_uint32_t_u_u(((**g_881) == (l_1698 &= l_1695)), ((safe_add_func_uint16_t_u_u((((-8L) ^ l_1705) & (&g_734 != &g_734)), ((safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_u((((*l_1711) = l_1710) == ((*l_1713) = l_1712)), ((g_1714 = g_1714) != &g_1715[4][8]))), 0xE4D40027L)) | (***g_390)))) != l_1719)));
                        (**g_390) = (((void*)0 != l_1720) , &l_1698);
                    }
                    (**l_38) = ((safe_lshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((l_1558 = (safe_add_func_uint16_t_u_u(g_1212[1][3], ((((0xE46AEAADL == (safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s(((-1L) & (((((((((safe_div_func_int16_t_s_s((*l_1687), (safe_rshift_func_int16_t_s_s((safe_div_func_int32_t_s_s((((safe_sub_func_uint32_t_u_u(0xAC9819BEL, ((((safe_unary_minus_func_uint8_t_u((safe_div_func_uint8_t_u_u((((safe_add_func_int32_t_s_s((((*l_1687) == l_1744) > ((*l_1484) ^= 0x187194DE3E02AA32LL)), (safe_add_func_uint16_t_u_u(((*l_1633) = (0xA9A48B76CD19D96CLL || l_1548)), 0x0446L)))) , (*g_480)) <= (-1L)), (*l_1443))))) | 0x1FB2L) , l_1669) != 18446744073709551612UL))) >= (-1L)) & (*g_380)), l_1698)), 7)))) && (*l_1687)) > g_1215) || 0L) | (-5L)) && l_1698) , (*g_480)) & g_997) < g_126)), (*l_39))), 0x76L))) ^ 0UL) & l_1567) != (*l_1687))))), (*g_1302))), l_1614)) > (*l_1687));
                    if ((*l_1687))
                    { /* block id: 812 */
                        return l_1670;
                    }
                    else
                    { /* block id: 814 */
                        int32_t *l_1748 = &g_122;
                        int32_t *l_1749 = &g_1029;
                        int32_t *l_1750 = &l_1558;
                        int32_t *l_1751[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1751[i] = &g_122;
                        (*l_38) = &l_1698;
                        ++g_1760[3][0][1];
                        ++l_1763;
                    }
                }
            }
            else
            { /* block id: 820 */
                int8_t l_1774[2];
                int32_t l_1777 = 0xAF67BED5L;
                int32_t l_1789 = (-8L);
                int i;
                for (i = 0; i < 2; i++)
                    l_1774[i] = (-6L);
                for (g_1200 = 0; (g_1200 != 21); g_1200 = safe_add_func_uint16_t_u_u(g_1200, 7))
                { /* block id: 823 */
                    const int8_t l_1768 = (-10L);
                    int32_t l_1771 = 0xC5914E6BL;
                    uint32_t l_1778 = 0x984DBCC7L;
                    if (l_1768)
                        break;
                    for (g_1249 = 0; (g_1249 <= 3); g_1249 += 1)
                    { /* block id: 827 */
                        int8_t l_1772 = (-1L);
                        int32_t l_1773 = 0x21B9052FL;
                        int32_t *l_1775 = &l_1698;
                        int32_t *l_1776[7][4][2] = {{{&g_1030,&l_1752[2]},{&l_1752[1],&g_1294},{&g_145,&l_1698},{&l_1757,&g_145}},{{&g_1029,&l_1485},{&g_1029,&g_145},{&l_1757,&l_1698},{&g_145,&g_1294}},{{&l_1752[1],&l_1752[2]},{&g_1030,&l_1485},{&l_1485,(void*)0},{&l_1758,&l_1752[2]}},{{&g_145,&g_1624},{(void*)0,&g_1624},{&l_1771,&l_1485},{&g_1028,&l_1752[0]}},{{&l_1485,&g_1294},{&g_145,&g_1294},{&l_1485,&l_1752[0]},{&g_1028,&l_1485}},{{&l_1771,&g_1624},{(void*)0,&g_1624},{&g_145,&l_1752[2]},{&l_1758,(void*)0}},{{&l_1485,&l_1485},{&g_1030,&l_1752[2]},{&l_1752[1],&g_1294},{&g_145,&l_1698}}};
                        int i, j, k;
                        l_1770 = l_1769;
                        --l_1778;
                        return (*l_1443);
                    }
                }
                for (l_1548 = 0; (l_1548 < 2); l_1548++)
                { /* block id: 835 */
                    int32_t ****l_1792 = &g_200;
                    int32_t ***l_1794 = (void*)0;
                    int32_t ****l_1793 = &l_1794;
                    uint16_t *l_1795 = (void*)0;
                    uint16_t *l_1796 = &g_1760[3][0][1];
                    for (g_514 = 0; (g_514 < (-3)); g_514 = safe_sub_func_uint16_t_u_u(g_514, 5))
                    { /* block id: 838 */
                        return (*g_1302);
                    }
                    (*l_39) &= (safe_sub_func_int64_t_s_s((((*l_1796) |= (safe_mod_func_int64_t_s_s(((5UL && (((((0x4E29L >= (((*g_480) = l_1789) || ((*l_1770) && (safe_mod_func_uint32_t_u_u(((&g_997 != (void*)0) || ((1UL & (((*l_1793) = ((*l_1792) = &g_201)) != (void*)0)) == 0x6BB3D67BL)), (*g_380)))))) || 0L) || g_1238) | 0xFA17L) , 0x7F6C82D87B220E3ELL)) > 0x8DE9F8BA12E8817DLL), g_1221))) != g_1032), (*l_1770)));
                }
                return l_1774[0];
            }
            (*g_77) &= 0xD4F7FBFFL;
            (***g_389) = (**g_390);
        }
        else
        { /* block id: 851 */
            uint8_t ***l_1799[3];
            int32_t l_1821 = 4L;
            struct S0 **l_1857 = (void*)0;
            union U1 **l_1914 = &l_1868;
            int32_t l_1924 = 0x8AD8C841L;
            int32_t l_1925 = (-3L);
            uint32_t l_1947[3];
            int i;
            for (i = 0; i < 3; i++)
                l_1799[i] = (void*)0;
            for (i = 0; i < 3; i++)
                l_1947[i] = 1UL;
            (*l_1769) ^= (((*g_1302) = (safe_add_func_uint8_t_u_u((&g_480 == (l_1800 = &g_480)), (*g_480)))) && ((safe_sub_func_int64_t_s_s(((((((0x94BBL && 0xEDE9L) , (void*)0) == (void*)0) || (~(safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u((safe_rshift_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u(1UL, (safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_s(l_1820, (*g_802))) , 1UL), (***g_390))), 1)), l_1821)))) && g_16[1]), (*l_39))), l_1821)), l_1821)))) | g_16[1]) == g_1760[5][0][2]), (*l_39))) || g_1212[1][6]));
            for (g_1203 = 0; (g_1203 > 34); g_1203 = safe_add_func_int8_t_s_s(g_1203, 2))
            { /* block id: 857 */
                int8_t l_1830[1];
                int32_t l_1859 = 0x49CFA247L;
                int32_t *l_1860[3][8] = {{&l_1518,(void*)0,&g_145,&l_1518,&g_145,(void*)0,&l_1518,(void*)0},{&l_1821,&l_1752[0],&g_1029,&l_1518,&l_1518,&g_1029,&l_1752[0],&l_1821},{(void*)0,&l_1518,(void*)0,&g_145,&l_1518,&g_145,(void*)0,&l_1518}};
                int i, j;
                for (i = 0; i < 1; i++)
                    l_1830[i] = 0x47L;
                for (g_1206 = (-28); (g_1206 != 54); g_1206 = safe_add_func_uint32_t_u_u(g_1206, 3))
                { /* block id: 860 */
                    uint16_t l_1831[2][10][2] = {{{65526UL,0x5C39L},{65528UL,0x5C39L},{65526UL,65526UL},{0x2FD5L,0xF1DCL},{0x8D9DL,0x730BL},{1UL,0UL},{0x5C39L,1UL},{0x8024L,65535UL},{0x8024L,1UL},{0x5C39L,0UL}},{{1UL,0x730BL},{0x8D9DL,0xF1DCL},{0x2FD5L,65526UL},{65526UL,0x5C39L},{65528UL,0x5C39L},{65526UL,65526UL},{0x2FD5L,0xF1DCL},{0x8D9DL,0x730BL},{1UL,0UL},{0x5C39L,1UL}}};
                    int i, j, k;
                }
                for (g_1201 = 0; (g_1201 > 38); ++g_1201)
                { /* block id: 875 */
                    return (*l_1769);
                }
                for (g_1199 = 0; (g_1199 != 8); g_1199 = safe_add_func_uint8_t_u_u(g_1199, 1))
                { /* block id: 880 */
                    uint16_t l_1865 = 65535UL;
                    (**l_38) = l_1821;
                    (*l_38) = func_10((****g_389), l_1865, l_1821, l_1865, ((((safe_sub_func_uint64_t_u_u(((l_1868 == (*l_1710)) , ((~(&g_380 == ((&g_390 != &g_200) , (void*)0))) < (*g_380))), 0x6F57E53A28F2458BLL)) || l_1865) || (**g_881)) >= l_1865));
                    if ((***g_390))
                        continue;
                    for (g_1417 = 1; (g_1417 >= (-1)); g_1417--)
                    { /* block id: 886 */
                        return (*g_802);
                    }
                }
            }
            for (g_1200 = 0; (g_1200 <= 5); g_1200 += 1)
            { /* block id: 893 */
                int32_t l_1890 = (-1L);
                uint32_t *l_1902 = &g_756[0];
                uint32_t *l_1903 = &g_1587;
                uint16_t l_1926[5][4] = {{0UL,65535UL,0UL,0UL},{65535UL,65535UL,65535UL,65535UL},{65535UL,0UL,0UL,65535UL},{0UL,65535UL,0UL,0UL},{65535UL,65535UL,65535UL,65535UL}};
                int32_t ** const l_1929 = &l_39;
                int i, j;
                (*l_38) = &l_1821;
                for (g_1214 = 0; (g_1214 <= 2); g_1214 += 1)
                { /* block id: 897 */
                    uint32_t *l_1888 = (void*)0;
                    uint32_t **l_1887 = &l_1888;
                    uint32_t ***l_1886 = &l_1887;
                    int32_t l_1889 = 0L;
                    uint16_t l_1893 = 2UL;
                    int32_t l_1922 = 0x40543576L;
                    int32_t l_1923 = (-5L);
                    int i, j;
                    if (((((0L && ((void*)0 != &g_1851)) <= (g_1253 ^ ((((*l_1441) = (~(l_1889 &= (g_225[(g_1214 + 3)][g_1214] = (safe_mul_func_uint16_t_u_u((safe_add_func_int64_t_s_s(((&g_380 != ((safe_lshift_func_uint16_t_u_u((+l_1821), 10)) , ((*l_1886) = ((safe_rshift_func_uint8_t_u_s((((safe_add_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(0UL, ((*g_379) != &g_1236))), 0x7052CBF0L)) == g_1231) , (*g_480)), g_1493.f0)) , (void*)0)))) == 0xB0407305L), 18446744073709551612UL)), 0xF94DL)))))) != 0xE2L) && (*l_1443)))) , g_1048.f3) | g_184.f0))
                    { /* block id: 902 */
                        uint32_t **l_1897 = &l_1888;
                        int32_t l_1898 = 0xC00E8623L;
                        uint32_t **l_1899[10] = {&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734,&g_734};
                        uint16_t *l_1908 = &l_1549;
                        int i;
                        (*l_41) = func_2(l_1890, (((safe_rshift_func_uint16_t_u_u(l_1893, g_1204)) && (safe_unary_minus_func_int32_t_s((safe_div_func_int64_t_s_s(0xF262321465327D78LL, 0x0B6B72EA31C66370LL))))) , 0UL), ((void*)0 == &l_1868), ((((((*l_1897) = (void*)0) == (void*)0) < g_184.f1) , l_1898) , (*l_39)));
                        (*l_41) = func_2(((((((g_734 = &g_1587) != (g_1909 = func_10(l_1898, ((safe_add_func_int8_t_s_s((4L && ((l_1902 = &g_633) == l_1903)), (g_225[(g_1214 + 3)][g_1214] <= (safe_rshift_func_uint8_t_u_s(((void*)0 != l_1888), 6))))) == (safe_mod_func_uint16_t_u_u(((*l_1908) = g_1241[1]), 1UL))), (**l_41), l_1898, g_1851))) , g_1258) >= l_1890) , (**g_379)) || (*g_380)), g_1231, l_1889, (*g_480));
                    }
                    else
                    { /* block id: 910 */
                        union U1 **l_1913 = (void*)0;
                        int32_t *l_1915 = &g_78;
                        int32_t *l_1916 = &g_145;
                        int32_t *l_1917 = &g_1294;
                        int32_t *l_1918 = &g_1294;
                        int32_t *l_1919 = &g_40;
                        int32_t *l_1920 = (void*)0;
                        int32_t *l_1921[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1921[i] = &l_1518;
                        (*g_1910) = &g_1689;
                        (*l_1443) = ((l_1912 != (l_1914 = l_1913)) , (***g_390));
                        l_1926[1][3]--;
                        return (*g_802);
                    }
                }
                for (g_1252 = 0; (g_1252 <= 2); g_1252 += 1)
                { /* block id: 920 */
                    (*g_200) = l_1929;
                }
            }
            for (g_1624 = (-8); (g_1624 < 14); ++g_1624)
            { /* block id: 926 */
                int32_t l_1932 = (-5L);
                union U1 ** const *****l_1941[2];
                int8_t l_1968 = 0xE5L;
                int32_t *l_1972 = (void*)0;
                int32_t *l_1973 = &l_1925;
                int32_t *l_1974 = &g_1028;
                int32_t *l_1975 = &l_1759;
                int32_t *l_1976 = &l_1759;
                int32_t *l_1977 = &g_40;
                int32_t *l_1978 = (void*)0;
                int32_t *l_1979 = &g_145;
                int32_t *l_1980[3][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
                uint32_t l_1981 = 0x7C1434B6L;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_1941[i] = &g_1937;
                l_1924 |= (*l_1443);
                (*l_41) = func_10(((l_1932 | (!(l_1934 == (l_1821 , (g_1937 = g_1937))))) & ((safe_div_func_int32_t_s_s((g_1232[4] | (safe_rshift_func_uint8_t_u_u(((l_1821 , (g_1946 , ((***l_1826) = (*g_802)))) & 1L), 6))), l_1947[1])) > 0xD5L)), g_1216, (*l_1769), l_1932, (**l_38));
                for (g_1599 = 0; (g_1599 <= 1); g_1599 += 1)
                { /* block id: 933 */
                    uint32_t l_1949 = 18446744073709551615UL;
                    int32_t l_1952[6][6] = {{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L},{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L},{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L},{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L},{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L},{6L,0xCC4D37FEL,6L,6L,0xCC4D37FEL,6L}};
                    int32_t *l_1953 = &g_145;
                    int32_t *l_1954 = &g_78;
                    int32_t *l_1955 = (void*)0;
                    int32_t *l_1956 = &l_1925;
                    int32_t *l_1957 = &g_145;
                    int32_t *l_1958 = &l_1759;
                    int32_t *l_1959 = &l_1952[0][0];
                    int32_t *l_1960 = &l_1518;
                    int32_t *l_1961 = &g_122;
                    int32_t *l_1962 = (void*)0;
                    int32_t *l_1963 = &l_1925;
                    int32_t *l_1964 = &l_1518;
                    int32_t *l_1965 = &l_1518;
                    int32_t *l_1966 = &l_1752[0];
                    int32_t *l_1967[9];
                    uint8_t l_1969[4];
                    int i, j;
                    for (i = 0; i < 9; i++)
                        l_1967[i] = (void*)0;
                    for (i = 0; i < 4; i++)
                        l_1969[i] = 252UL;
                    for (g_87 = 0; (g_87 <= 1); g_87 += 1)
                    { /* block id: 936 */
                        int i, j;
                        (*g_77) &= (((0x67L < g_843[g_87][(g_87 + 6)]) >= (g_188.f0 = ((~(l_1949 & ((&g_1032 != &g_997) <= l_1949))) , g_184.f0))) , (((safe_rshift_func_uint8_t_u_u((0xA4L < 0UL), (*g_480))) , l_1821) < l_1949));
                    }
                    l_1969[0]--;
                }
                l_1981--;
            }
        }
    }
    else
    { /* block id: 945 */
        uint8_t ** const l_1989 = (void*)0;
        uint8_t ** const *l_1988 = &l_1989;
        uint8_t ** const **l_1987 = &l_1988;
        int32_t l_2008 = 3L;
        int32_t l_2009 = 0xA7256E5EL;
        uint8_t ***l_2011 = &l_2010[8];
        l_1992[1] |= (safe_rshift_func_int8_t_s_u((&g_881 != ((*l_1987) = (l_1986 = (void*)0))), ((*g_480)++)));
        if (g_122)
            goto lbl_2019;
lbl_2019:
        (*g_77) = (safe_mul_func_uint16_t_u_u((l_1995 != (safe_add_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_s(((safe_mod_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s(((*l_1441) = l_2008), 0xB3L)), 7)), 0)), g_225[5][2])) < (l_2009 |= 4294967292UL)), (&g_480 == ((*l_2011) = l_2010[3])))) >= (safe_mul_func_uint8_t_u_u(((safe_lshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((((((l_2008 < g_1490.f1) == g_1493.f0) >= l_2008) , l_2018) == &g_561[0]) , 1L), 7)), l_2008)) , l_2008), g_1689.f3))), g_1689.f2))), g_1047.f2));
        for (g_1205 = 0; (g_1205 <= 3); g_1205 += 1)
        { /* block id: 957 */
            volatile int16_t * const **l_2020 = (void*)0;
            (*g_2021) = &g_802;
        }
    }
    return l_2023[1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_77 g_40 g_78 g_389 g_390 g_391 g_122
 * writes: g_40 g_78 g_77 g_392 g_122
 */
static int32_t * func_2(int8_t  p_3, uint32_t  p_4, uint32_t  p_5, uint8_t  p_6)
{ /* block id: 728 */
    uint32_t *l_1520 = &g_1257[4][2];
    uint32_t **l_1519 = &l_1520;
    int32_t *l_1521 = &g_122;
    int32_t **l_1522 = &g_77;
    (***g_389) = ((*l_1522) = (((*g_77) |= (l_1519 != &l_1520)) , l_1521));
    return (*l_1522);
}


/* ------------------------------------------ */
/* 
 * reads : g_678 g_679 g_1251 g_77 g_40 g_78 g_881 g_480 g_75 g_1302 g_561 g_1112 g_1259 g_188.f2 g_122
 * writes: g_186 g_40 g_78 g_324.f0 g_122
 */
static int32_t * func_10(int32_t  p_11, int64_t  p_12, int8_t  p_13, int64_t  p_14, int8_t  p_15)
{ /* block id: 719 */
    const int32_t l_1488 = 6L;
    const union U1 *l_1489 = &g_1490;
    const union U1 **l_1491 = &l_1489;
    union U1 *l_1492 = &g_1493;
    int32_t l_1508 = 0xDE300DDBL;
    int64_t *l_1514 = &g_324.f0;
    int32_t l_1515[9] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
    int16_t l_1516 = (-1L);
    int i;
    l_1516 = (((safe_rshift_func_uint16_t_u_s(((l_1488 , (((0UL || ((((((*l_1491) = l_1489) != ((**g_678) = l_1492)) , (safe_lshift_func_int8_t_s_s(((((g_1251 & (((*l_1514) = ((safe_rshift_func_uint8_t_u_s(l_1488, ((safe_sub_func_int32_t_s_s(((safe_sub_func_int64_t_s_s((safe_sub_func_int64_t_s_s((l_1488 < ((safe_mul_func_int16_t_s_s((safe_div_func_int16_t_s_s((((((l_1508 = ((*g_77) ^= p_13)) != (+((safe_div_func_int16_t_s_s((safe_rshift_func_int8_t_s_u(0x67L, (**g_881))), 0xFAA6L)) , 0x4BL))) || 0xFA89D90B72CF0233LL) && g_78) , (*g_1302)), 0x50DAL)), p_14)) | p_14)), 0x05EDF3DD0DE28F94LL)), g_1112[6][2])) && g_1259[4][3][4]), p_14)) , (-9L)))) != 0x68B5L)) | 0x634CF2DFD807D989LL)) | g_188.f2) > l_1488) > (**g_881)), 7))) || l_1515[4]) , 0x8D74DCA9L)) & l_1488) , p_14)) != 1UL), p_15)) ^ p_15) != l_1515[4]);
    return &g_1028;
}


/* ------------------------------------------ */
/* 
 * reads : g_909 g_390 g_391 g_1302 g_561 g_1294 g_881 g_480 g_1208 g_1252 g_1210 g_146
 * writes: g_909 g_1209 g_392 g_480 g_1294 g_1252 g_1210
 */
static uint64_t  func_27(int8_t  p_28, uint8_t  p_29, int32_t * p_30, int32_t * p_31)
{ /* block id: 693 */
    uint16_t l_1448 = 1UL;
    int32_t l_1449 = 0x6E5485A4L;
    int32_t l_1454 = 3L;
    int32_t l_1455 = 0xAC8B1ED0L;
    int64_t l_1456[6];
    int32_t l_1457 = (-5L);
    int32_t l_1458 = 0x676016A8L;
    int16_t l_1459 = 0x5B72L;
    int32_t l_1460[3];
    int32_t l_1461 = 7L;
    uint64_t l_1462 = 0xC710F22C97495C8BLL;
    uint16_t l_1477 = 0xB761L;
    uint8_t l_1478 = 0x42L;
    uint16_t l_1483 = 4UL;
    int i;
    for (i = 0; i < 6; i++)
        l_1456[i] = (-1L);
    for (i = 0; i < 3; i++)
        l_1460[i] = (-1L);
    for (g_909 = 0; (g_909 < 22); g_909 = safe_add_func_int64_t_s_s(g_909, 5))
    { /* block id: 696 */
        int32_t *l_1450 = (void*)0;
        int32_t *l_1451 = &g_1294;
        int32_t *l_1452 = &g_1294;
        int32_t *l_1453[10] = {(void*)0,&g_1030,(void*)0,&g_1030,(void*)0,&g_1030,(void*)0,&g_1030,(void*)0,&g_1030};
        int i;
        for (g_1209 = (-22); (g_1209 <= 25); ++g_1209)
        { /* block id: 699 */
            (**g_390) = p_31;
            if (l_1448)
                continue;
        }
        --l_1462;
        (*p_31) = ((((((safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((((((*g_1302) & p_29) > p_28) != ((((safe_add_func_uint32_t_u_u(p_29, (*p_31))) < ((((*g_881) = (*g_881)) == &g_75[1][0]) , ((safe_mod_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s((safe_mod_func_uint64_t_u_u(((((p_29 <= (4294967294UL != p_28)) >= l_1459) , 7L) & 1UL), (*l_1451))), l_1477)) == 0x82B6954D368B05B8LL), 0xA1L)) < 0x579C1B29EDC924C3LL))) , p_29) , p_29)) ^ l_1478), (*g_1302))), p_29)) , g_1208) || 0x650105685F6092EDLL) , &l_1459) == &g_108) < p_28);
        for (g_1252 = 19; (g_1252 >= 58); ++g_1252)
        { /* block id: 708 */
            for (g_1210 = (-5); (g_1210 != 36); g_1210++)
            { /* block id: 711 */
                if (l_1483)
                    break;
            }
            return p_29;
        }
    }
    return g_146;
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_43 g_87 g_92 g_78 g_16 g_108 g_77 g_112 g_113 g_123 g_126 g_75 g_147 g_200 g_146 g_223 g_225 g_188.f0 g_145 g_235 g_189.f0 g_180 g_122 g_201 g_187.f0 g_188.f2 g_269 g_279 g_184.f0 g_189.f2 g_186 g_144 g_184.f2 g_389 g_390 g_391 g_756 g_679 g_480 g_801 g_292 g_843 g_514 g_1032 g_532 g_1004 g_1302 g_561 g_1207 g_1124 g_881 g_1255 g_1213 g_1030 g_1197 g_1210 g_1227
 * writes: g_40 g_75 g_77 g_87 g_78 g_108 g_112 g_113 g_123 g_126 g_147 g_223 g_180 g_144 g_122 g_146 g_92 g_269 g_279 g_292 g_184.f2 g_184.f0 g_145 g_189.f2 g_188.f0 g_392 g_442 g_187.f0 g_225 g_881 g_1032 g_186 g_1124 g_561 g_734 g_1004 g_1417 g_1210 g_532 g_1227
 */
static int8_t  func_34(int32_t  p_35)
{ /* block id: 3 */
    int16_t l_277 = 0x0EFBL;
    uint8_t *l_278 = &g_279[1][3];
    int32_t ****l_289[8] = {&g_200,&g_200,&g_200,&g_200,&g_200,&g_200,&g_200,&g_200};
    int32_t *****l_288 = &l_289[3];
    int32_t ****l_290 = &g_200;
    uint16_t *l_291 = &g_292;
    int8_t *l_337 = &g_146;
    int32_t *l_350 = (void*)0;
    int64_t *l_1054 = &g_184.f0;
    uint32_t **l_1061 = &g_734;
    int8_t l_1089 = 0L;
    union U1 **l_1309 = &g_186[3][0];
    uint64_t l_1317 = 0x634B67FEFC595B7CLL;
    int32_t *l_1341 = (void*)0;
    uint8_t l_1342 = 1UL;
    uint8_t ***l_1371 = &g_881;
    uint8_t ***l_1372 = (void*)0;
    uint16_t l_1392 = 0xDBCDL;
    uint32_t l_1420[6];
    uint8_t l_1424 = 0x66L;
    int i;
    for (i = 0; i < 6; i++)
        l_1420[i] = 4294967292UL;
    if (((((safe_lshift_func_uint8_t_u_s(func_47((safe_mul_func_int8_t_s_s(func_52((((safe_add_func_uint64_t_u_u(func_57((p_35 < (((((*l_337) = func_62(func_66(&g_40), ((g_184.f2 = ((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((0x73L >= 0x5FL) , (((!((((*l_278) ^= l_277) && (g_279[1][3] >= (safe_sub_func_int16_t_s_s(l_277, ((*l_291) = (safe_lshift_func_int8_t_s_s((safe_add_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s((((((*l_288) = (void*)0) != l_290) , p_35) ^ g_225[8][0]), 7)), g_16[3])), p_35))))))) > g_145)) ^ g_145) >= (-1L))), p_35)), g_184.f0)), 0UL)) > g_225[8][0])) < l_277), p_35)) < g_225[7][0]) != g_225[8][0]) > 0x14L)), p_35, (**l_290), g_225[8][0]), 1UL)) , &g_145) != l_350), g_16[3]), 255UL)), p_35), 7)) == g_532) <= p_35) != p_35))
    { /* block id: 495 */
        int32_t l_1037 = 0xABA70269L;
        int32_t l_1041 = 0x315E358CL;
        l_1041 = (safe_sub_func_uint64_t_u_u(l_1037, ((((safe_lshift_func_uint8_t_u_u((p_35 ^ p_35), ((l_1037 | ((void*)0 != &g_801[6][1])) , (((safe_unary_minus_func_int64_t_s(1L)) ^ ((*g_1004) , p_35)) , 0xA7L)))) | 0xDDL) & 0x691EL) ^ l_1037)));
    }
    else
    { /* block id: 497 */
        int8_t l_1057 = 0x6AL;
        int32_t *l_1060 = (void*)0;
        int32_t * const * const l_1083 = &g_77;
        int32_t * const * const *l_1082 = &l_1083;
        int32_t l_1110[6][4][1] = {{{0x02E97064L},{0xBCE2CF56L},{1L},{0x02E97064L}},{{0x3BD6F450L},{0x3BD6F450L},{0x02E97064L},{1L}},{{0xBCE2CF56L},{0x02E97064L},{0xBCE2CF56L},{1L}},{{0x02E97064L},{0x3BD6F450L},{0x3BD6F450L},{0x02E97064L}},{{1L},{0xBCE2CF56L},{0x02E97064L},{0xBCE2CF56L}},{{1L},{0x02E97064L},{0x3BD6F450L},{0x3BD6F450L}}};
        int32_t l_1160 = 0x787AF391L;
        uint32_t *l_1174[1][2];
        uint32_t **l_1173[10][10][2] = {{{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{(void*)0,&l_1174[0][1]},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][0],&l_1174[0][0]},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],(void*)0},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],(void*)0}},{{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],(void*)0},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][1],&l_1174[0][1]},{&l_1174[0][0],(void*)0},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][1]}},{{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{(void*)0,&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][0],(void*)0},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],(void*)0},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][1],(void*)0},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],(void*)0},{(void*)0,&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],(void*)0},{&l_1174[0][1],(void*)0}},{{&l_1174[0][1],(void*)0},{(void*)0,&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{(void*)0,(void*)0},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][1],(void*)0},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],(void*)0},{&l_1174[0][1],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]}},{{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],(void*)0},{(void*)0,&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{&l_1174[0][1],&l_1174[0][0]},{&l_1174[0][0],&l_1174[0][1]},{&l_1174[0][0],&l_1174[0][0]},{(void*)0,(void*)0},{&l_1174[0][1],(void*)0}}};
        int16_t *l_1304 = &l_277;
        uint64_t *l_1331 = &l_1317;
        uint8_t ***l_1370 = &g_881;
        uint8_t ****l_1369[8][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
        const uint8_t l_1373 = 255UL;
        union U1 **l_1381 = &g_186[3][1];
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_1174[i][j] = &g_223;
        }
        for (g_122 = 21; (g_122 <= (-27)); g_122--)
        { /* block id: 500 */
            union U1 *l_1046[8] = {&g_1048,&g_1048,(void*)0,&g_1048,&g_1048,(void*)0,&g_1048,&g_1048};
            uint8_t *l_1052 = &g_225[8][0];
            int32_t **l_1058 = &g_77;
            uint16_t l_1088 = 0x7820L;
            int8_t *l_1090 = (void*)0;
            int8_t *l_1091 = &g_1031;
            int8_t *l_1092 = &l_1089;
            int32_t l_1103 = 0x07383ED6L;
            int32_t l_1107 = (-1L);
            int32_t l_1119 = (-6L);
            int8_t l_1163 = 6L;
            int32_t l_1190 = 0x6DF757D0L;
            int32_t l_1296 = (-1L);
            union U1 **l_1310 = &l_1046[5];
            union U1 ** const l_1311 = &g_186[2][2];
            int i;
            for (g_187.f0 = 0; (g_187.f0 != (-20)); --g_187.f0)
            { /* block id: 503 */
                int8_t l_1049 = 0x86L;
                int32_t l_1055 = 0L;
                (*g_679) = l_1046[5];
                if (l_1049)
                    continue;
            }
        }
        if ((safe_mul_func_int8_t_s_s((((safe_mod_func_int8_t_s_s(((**l_1083) != (p_35 | (safe_add_func_uint16_t_u_u((((*g_1004) = (-3L)) > (safe_add_func_uint8_t_u_u((1L > (safe_lshift_func_uint8_t_u_u((((void*)0 != &g_734) , (((((safe_lshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s((((p_35 || ((safe_div_func_uint32_t_u_u(0x34D6610EL, (safe_rshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u((((l_1371 = (void*)0) == l_1372) , p_35), 0xB0D4L)), 6)))) <= (***l_1082))) && g_269) ^ (***l_1082)), p_35)), (*g_1302))) > p_35) == g_1032) <= g_1207) , 1UL)), 3))), (***l_1082)))), 0x09FBL)))), l_1373)) > (**l_1083)) ^ 0x15L), 255UL)))
        { /* block id: 635 */
            uint8_t *l_1384 = &g_123;
            int32_t l_1389[1][1][4] = {{{0x9EAD3D7AL,0x9EAD3D7AL,0x9EAD3D7AL,0x9EAD3D7AL}}};
            union U1 **l_1406 = &g_186[0][2];
            int i, j, k;
            for (g_1124 = 0; (g_1124 > 36); g_1124 = safe_add_func_int32_t_s_s(g_1124, 6))
            { /* block id: 638 */
                uint32_t *l_1388 = &g_180[7];
                uint32_t **l_1387 = &l_1388;
                int32_t l_1395[10] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
                uint64_t l_1401 = 18446744073709551615UL;
                int i;
                if ((((*g_77) = (!1UL)) > (((safe_add_func_uint8_t_u_u(0x1BL, ((((*g_1302) = (-7L)) , (safe_add_func_int64_t_s_s(((void*)0 == l_1381), (safe_rshift_func_uint8_t_u_u(((*g_881) == l_1384), 1))))) >= (((safe_rshift_func_uint16_t_u_s((((*l_1061) = &g_756[0]) == ((*l_1387) = l_1060)), 7)) >= 0L) ^ p_35)))) , g_1255) , l_1389[0][0][0])))
                { /* block id: 643 */
                    int8_t **l_1390 = &g_1004;
                    if (p_35)
                        break;
                    (**l_1083) &= (((*l_1390) = &l_1089) != &l_1057);
                }
                else
                { /* block id: 647 */
                    int32_t l_1391 = 0x9C94C182L;
                    int32_t l_1396 = 0x14443DB9L;
                    int32_t l_1397 = (-5L);
                    int32_t l_1399 = (-1L);
                    if (p_35)
                    { /* block id: 648 */
                        int32_t l_1398 = 0x8AB4744DL;
                        int32_t l_1400 = 0x40AF235BL;
                        --l_1392;
                        if ((***l_1082))
                            break;
                        l_1401++;
                    }
                    else
                    { /* block id: 652 */
                        int32_t *l_1412 = &g_1030;
                        (*g_77) = ((((((*l_1331)--) , p_35) != p_35) == ((l_1406 != ((!(safe_lshift_func_uint8_t_u_u(p_35, 4))) , l_1406)) > (((((safe_sub_func_uint32_t_u_u(l_1397, (((*l_1054) ^= ((((***l_1082) > ((void*)0 != l_1412)) , (**g_881)) >= l_1395[2])) | g_1213[3]))) > l_1401) ^ p_35) , p_35) && p_35))) > 0xA61FL);
                        return (*l_1412);
                    }
                    (*g_77) ^= 0xDBD2972EL;
                    if (l_1396)
                        continue;
                    (***l_1082) = p_35;
                }
                if ((0x8F873A39L >= ((0x7E75L || ((((0x0EF52650C36B2584LL | (safe_add_func_uint16_t_u_u(((((***l_1370) = (**g_881)) >= (((((p_35 != (safe_mul_func_int16_t_s_s((0x195F47EFL != (g_1417 = (l_1395[2] = 4294967293UL))), 0xB31FL))) > (((safe_mul_func_int8_t_s_s((-8L), (*g_1004))) || 0x97L) & (**l_1083))) ^ (*g_1004)) , (-3L)) , p_35)) , 0xCAC3L), (**l_1083)))) > 0x5AL) | p_35) ^ p_35)) | l_1420[4])))
                { /* block id: 665 */
                    (*g_77) |= 0x5678D510L;
                    return p_35;
                }
                else
                { /* block id: 668 */
                    int32_t l_1423 = 4L;
                    (***l_1082) &= ((safe_div_func_int64_t_s_s(g_1197, l_1423)) <= l_1389[0][0][0]);
                }
                if ((***l_1082))
                    break;
            }
        }
        else
        { /* block id: 673 */
            l_1424++;
        }
    }
    (*g_77) ^= p_35;
    for (g_1210 = 0; (g_1210 >= 11); ++g_1210)
    { /* block id: 680 */
        uint64_t *l_1431[3];
        int32_t l_1432 = 7L;
        uint16_t l_1437[7][8][1] = {{{0xDA54L},{65534UL},{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L},{0xDA54L},{65534UL}},{{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L},{0xDA54L},{65534UL},{0xDA54L},{0xF487L}},{{0xC3BCL},{0xF487L},{0xDA54L},{65534UL},{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L}},{{0xDA54L},{65534UL},{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L},{0xDA54L},{65534UL}},{{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L},{0xDA54L},{65534UL},{0xDA54L},{0xF487L}},{{0xC3BCL},{0xF487L},{0xDA54L},{65534UL},{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L}},{{0xDA54L},{65534UL},{0xDA54L},{0xF487L},{0xC3BCL},{0xF487L},{0xDA54L},{65534UL}}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1431[i] = (void*)0;
        (*g_77) = (safe_sub_func_uint64_t_u_u((--g_532), ((*l_1054) = (safe_rshift_func_int8_t_s_u(l_1437[6][4][0], 2)))));
    }
    for (g_1227 = (-6); (g_1227 > 52); g_1227 = safe_add_func_int16_t_s_s(g_1227, 4))
    { /* block id: 687 */
        int32_t *l_1440 = (void*)0;
        (**g_390) = l_1440;
        (*g_77) = 0xE7FE9A26L;
    }
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_756 g_679 g_186 g_77 g_480 g_75 g_801 g_40 g_292 g_225 g_78 g_390 g_391 g_92 g_16 g_843 g_43 g_145 g_514 g_188.f0 g_1032
 * writes: g_40 g_78 g_113 g_92 g_146 g_292 g_442 g_392 g_187.f0 g_75 g_279 g_145 g_225 g_122 g_881 g_147 g_188.f0 g_1032
 */
static uint8_t  func_47(const uint8_t  p_48, uint16_t  p_49)
{ /* block id: 349 */
    union U1 ** const l_779 = &g_186[0][1];
    int32_t l_782 = 1L;
    uint64_t l_784 = 7UL;
    int16_t **l_800 = (void*)0;
    union U1 ****l_872 = (void*)0;
    uint32_t *l_889 = &g_223;
    int16_t l_910 = (-1L);
    int32_t *l_960 = (void*)0;
    int32_t l_962 = 0x3E47D1BCL;
    uint64_t l_963 = 0x7D04D774C35B5600LL;
    int32_t *l_998 = &g_78;
    int32_t *l_1022 = (void*)0;
    int32_t *l_1023 = &g_145;
    int32_t *l_1024 = &l_782;
    int32_t *l_1025 = &g_145;
    int32_t *l_1026[1][6][8] = {{{&g_122,&g_78,(void*)0,&l_782,&g_78,&g_78,&l_782,(void*)0},{&g_78,&g_78,&l_782,(void*)0,&l_782,&g_78,&g_78,&l_782},{&l_962,&l_782,&l_782,&l_962,&g_122,&l_962,&l_782,&l_782},{&l_782,&g_122,(void*)0,(void*)0,&g_122,&l_782,&g_122,(void*)0},{&l_962,&g_122,&l_962,&l_782,&l_782,&l_962,&g_122,&l_962},{&g_78,&l_782,(void*)0,&l_782,&g_78,&g_78,&l_782,(void*)0}}};
    int32_t l_1027 = 7L;
    int i, j, k;
    for (p_49 = 0; (p_49 < 27); ++p_49)
    { /* block id: 352 */
        int32_t *l_774 = &g_40;
        int32_t *l_775[6][6] = {{&g_145,&g_145,(void*)0,(void*)0,&g_40,&g_40},{&g_145,&g_122,&g_122,&g_145,&g_145,&g_40},{&g_78,&g_40,(void*)0,&g_122,(void*)0,&g_122},{&g_145,&g_145,&g_145,&g_78,(void*)0,&g_145},{(void*)0,&g_40,&g_78,&g_145,&g_145,&g_78},{&g_122,&g_122,&g_145,&g_145,&g_40,&g_78}};
        uint16_t l_776 = 6UL;
        int32_t *l_783 = (void*)0;
        uint8_t **l_879 = &g_480;
        uint32_t l_912 = 18446744073709551614UL;
        int32_t ****l_967 = &g_200;
        int32_t *****l_966 = &l_967;
        int32_t l_999 = 0xB19B19FFL;
        int i, j;
        --l_776;
        if (((p_49 == ((7UL == ((void*)0 == l_779)) , (((p_48 < (((g_756[7] , (*g_679)) == (((g_113 = ((((safe_mod_func_uint8_t_u_u(((((-1L) >= ((*g_77) = (0x3D48L != 0L))) , p_48) != l_782), l_782)) >= p_48) >= l_782) && (*g_480))) , 9UL) , (*l_779))) != g_75[1][0])) != p_48) & p_48))) , l_784))
        { /* block id: 356 */
            int16_t l_819[4][8] = {{0x15EBL,0x4AC8L,(-1L),(-1L),0x4AC8L,0x15EBL,0xFDABL,0x15EBL},{0x4AC8L,0x15EBL,0xFDABL,0x15EBL,0x4AC8L,(-1L),(-1L),0x4AC8L},{0x15EBL,0xC728L,0xC728L,0x15EBL,(-8L),0x4AC8L,(-8L),0x15EBL},{0xC728L,(-8L),0xC728L,(-1L),0xFDABL,0xFDABL,(-1L),0xC728L}};
            int16_t *l_839 = &g_561[0];
            int16_t **l_838 = &l_839;
            const int32_t *l_878 = (void*)0;
            uint8_t ***l_880 = (void*)0;
            uint8_t **l_883 = &g_480;
            uint8_t ***l_882 = &l_883;
            uint64_t *l_884 = &g_147;
            int i, j;
            if (p_48)
            { /* block id: 357 */
                int16_t *l_798[6];
                int16_t **l_797 = &l_798[5];
                int32_t l_818 = 0x032F84F1L;
                union U1 * const *l_825 = &g_186[2][0];
                union U1 * const **l_824 = &l_825;
                int i;
                for (i = 0; i < 6; i++)
                    l_798[i] = &g_561[1];
                for (g_92 = 13; (g_92 >= 31); ++g_92)
                { /* block id: 360 */
                    uint32_t l_822 = 5UL;
                    int16_t ***l_840 = &l_797;
                    int64_t *l_841 = &g_187.f0;
                    uint8_t *l_842 = &g_279[1][3];
                    for (g_146 = 0; (g_146 <= (-21)); g_146 = safe_sub_func_int32_t_s_s(g_146, 7))
                    { /* block id: 363 */
                        int16_t ***l_799[3];
                        int8_t *l_808 = (void*)0;
                        int32_t l_809 = 1L;
                        uint16_t *l_813 = &l_776;
                        uint16_t **l_812 = &l_813;
                        const uint16_t *l_815 = &g_816;
                        const uint16_t **l_814 = &l_815;
                        int32_t l_817[7][4] = {{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)},{0x48B32156L,(-1L),0x48B32156L,(-1L)}};
                        uint16_t *l_820 = &g_292;
                        int64_t *l_821 = &g_442[1][0][3];
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_799[i] = &l_797;
                        (*g_77) = p_48;
                        l_782 &= (((*l_821) = ((safe_rshift_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u(((((safe_mod_func_int8_t_s_s(p_48, 0x9EL)) , (l_800 = l_797)) != g_801[6][1]) == ((((*l_820) &= ((safe_add_func_uint16_t_u_u((((safe_lshift_func_int8_t_s_u((l_809 = (*l_774)), ((safe_mod_func_int32_t_s_s((((((*l_812) = &g_292) != ((*l_814) = (void*)0)) ^ 0x23L) , p_49), l_817[1][1])) > 18446744073709551606UL))) , l_818) == 0xAEL), p_48)) != l_819[0][1])) , (void*)0) == (void*)0)), l_819[0][1])) , p_48), 6)) , p_49)) ^ g_225[6][1]);
                    }
                    if (l_822)
                        break;
                    if (p_49)
                    { /* block id: 374 */
                        union U1 * const ***l_826 = &l_824;
                        l_782 &= l_819[0][6];
                        (*l_774) = (+(-1L));
                        (*g_77) |= ((((*l_826) = l_824) != &g_679) != p_49);
                    }
                    else
                    { /* block id: 379 */
                        (**g_390) = &l_782;
                        if (l_782)
                            break;
                        if (p_48)
                            break;
                    }
                    g_145 ^= (((((safe_add_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(((safe_rshift_func_int8_t_s_u(p_49, ((*l_842) = (p_49 && ((((((*g_480) = (safe_sub_func_uint8_t_u_u((*g_480), (((*l_841) = ((((*l_774) ^= 0L) , (+p_48)) , ((((safe_mod_func_int8_t_s_s((((*l_840) = l_838) != &g_802), 3UL)) ^ (1L || p_48)) <= p_48) && 0x3A50L))) > (-1L))))) && p_49) , 18446744073709551615UL) == g_92) == l_819[0][1]))))) < l_782), g_16[3])) <= l_818), 0xA200L)) | l_784) != g_843[1][2]) <= g_43) | l_822);
                }
                l_782 ^= ((*g_77) = p_49);
            }
            else
            { /* block id: 393 */
                int32_t l_851 = 0x09735B0BL;
                int64_t *l_866 = (void*)0;
                int64_t *l_867[3][10] = {{&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0,&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0,&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0,&g_187.f0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int i, j;
                if (((*l_774) = (safe_rshift_func_int16_t_s_s(p_49, (safe_rshift_func_uint8_t_u_s((p_48 > (safe_unary_minus_func_uint32_t_u(((((g_225[6][2] = (safe_sub_func_uint64_t_u_u(l_851, (l_782 = (((p_49 <= (((safe_mul_func_uint16_t_u_u((0x528BD31E24CD956ALL ^ (((safe_rshift_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(0x04L, 5)) , (p_48 , (safe_lshift_func_int16_t_s_u(((((*g_480)--) & (safe_add_func_uint64_t_u_u((safe_div_func_int64_t_s_s(0x226B493C6595D74ELL, (((2L && 0x45C8418D6ADD8DBBLL) <= l_782) | p_48))), l_819[2][2]))) , 1L), 12)))), g_843[2][6])) < l_819[0][5]) | p_49)), 0xCE46L)) & g_756[0]) | 0x8F7CL)) & l_819[1][7]) != g_514))))) <= l_851) | 1L) && p_49)))), 3))))))
                { /* block id: 398 */
                    union U1 ****l_871[1][7][10] = {{{&g_669[0],(void*)0,&g_669[5],&g_669[5],&g_669[5],&g_669[0],&g_669[3],&g_669[0],&g_669[0],&g_669[3]},{&g_669[0],&g_669[3],&g_669[0],&g_669[0],&g_669[3],&g_669[0],&g_669[5],&g_669[5],&g_669[5],&g_669[4]},{&g_669[5],&g_669[5],&g_669[3],&g_669[0],&g_669[4],&g_669[5],(void*)0,(void*)0,&g_669[5],&g_669[3]},{&g_669[5],(void*)0,(void*)0,&g_669[5],&g_669[3],&g_669[5],&g_669[3],&g_669[5],(void*)0,(void*)0},{&g_669[5],&g_669[3],&g_669[5],(void*)0,(void*)0,&g_669[5],&g_669[4],&g_669[0],&g_669[3],&g_669[5]},{&g_669[5],&g_669[4],&g_669[0],&g_669[3],&g_669[5],&g_669[5],&g_669[3],&g_669[3],&g_669[3],&g_669[3]},{&g_669[5],&g_669[3],&g_669[3],&g_669[3],&g_669[3],&g_669[5],&g_669[5],&g_669[3],&g_669[0],&g_669[4]}}};
                    union U1 *****l_870 = &l_871[0][4][4];
                    union U1 *****l_873 = &l_872;
                    int i, j, k;
                    for (g_146 = 1; (g_146 < (-15)); g_146--)
                    { /* block id: 401 */
                        (*g_77) = l_819[1][2];
                    }
                    l_782 = ((0x49D17FA3F4ACD91ALL < (((*l_870) = &g_669[3]) != ((*l_873) = l_872))) == g_16[1]);
                }
                else
                { /* block id: 407 */
                    return p_49;
                }
                for (g_146 = 0; (g_146 > 12); g_146 = safe_add_func_int32_t_s_s(g_146, 6))
                { /* block id: 412 */
                    for (g_122 = 0; (g_122 >= 9); g_122 = safe_add_func_int64_t_s_s(g_122, 1))
                    { /* block id: 415 */
                        return (*g_480);
                    }
                    (**g_390) = l_878;
                }
            }
            (*g_77) = (((void*)0 == (*l_779)) > ((*l_884) = ((g_881 = l_879) == ((*l_882) = &g_480))));
        }
        else
        { /* block id: 425 */
            (**g_390) = &l_782;
        }
        for (g_188.f0 = 0; (g_188.f0 > (-17)); g_188.f0 = safe_sub_func_int16_t_s_s(g_188.f0, 6))
        { /* block id: 430 */
            uint32_t **l_890 = &l_889;
            const int32_t l_904 = 0xC15B15F5L;
            int32_t *l_907 = &g_113;
            int32_t *l_908 = &g_909;
            uint32_t l_911[9] = {8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL};
            union U1 * const * const l_927[9][10] = {{&g_186[0][1],&g_186[0][1],&g_186[1][0],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1],&g_186[0][1],&g_186[2][2],(void*)0},{&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1],&g_186[0][1],&g_186[0][1],&g_186[2][1],(void*)0,&g_186[0][1],&g_186[0][1]},{&g_186[0][1],&g_186[0][1],&g_186[1][3],&g_186[2][3],&g_186[2][3],&g_186[1][3],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[2][2]},{(void*)0,&g_186[0][2],&g_186[0][1],&g_186[1][0],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1],(void*)0,&g_186[2][3]},{(void*)0,&g_186[0][1],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1]},{&g_186[0][1],&g_186[0][1],&g_186[1][3],&g_186[2][2],&g_186[0][1],&g_186[2][1],&g_186[0][1],(void*)0,&g_186[0][1],&g_186[2][1]},{&g_186[1][0],&g_186[2][1],(void*)0,&g_186[2][1],&g_186[1][0],&g_186[0][1],&g_186[0][1],&g_186[0][1],&g_186[0][1],&g_186[0][1]},{&g_186[0][1],&g_186[0][1],&g_186[1][0],&g_186[0][1],&g_186[0][1],&g_186[0][1],(void*)0,&g_186[0][1],&g_186[0][1],&g_186[0][1]},{&g_186[0][1],&g_186[0][1],(void*)0,(void*)0,&g_186[1][0],(void*)0,&g_186[0][1],&g_186[3][3],&g_186[0][1],&g_186[2][1]}};
            union U1 * const * const * const l_926 = &l_927[7][1];
            union U1 * const * const * const *l_925 = &l_926;
            int16_t ***l_953 = &l_800;
            int64_t * const l_996 = &g_112;
            int8_t *l_1003[3][6][5] = {{{(void*)0,(void*)0,&g_16[3],(void*)0,&g_16[1]},{(void*)0,&g_16[1],&g_16[3],&g_146,&g_16[3]},{&g_146,&g_146,(void*)0,&g_16[0],(void*)0},{&g_514,&g_16[1],(void*)0,&g_16[2],&g_16[2]},{&g_514,&g_16[1],&g_16[3],&g_514,&g_16[1]},{&g_146,&g_16[1],&g_16[1],&g_16[1],&g_146}},{{&g_16[1],&g_146,(void*)0,&g_514,&g_16[1]},{&g_16[1],&g_16[1],&g_16[2],&g_146,(void*)0},{&g_16[1],&g_16[1],(void*)0,&g_514,&g_16[2]},{(void*)0,&g_146,&g_146,(void*)0,&g_16[0]},{(void*)0,&g_16[2],&g_514,(void*)0,&g_16[1]},{(void*)0,&g_16[3],&g_514,&g_146,&g_146}},{{(void*)0,(void*)0,&g_146,(void*)0,(void*)0},{&g_16[1],&g_16[2],&g_16[1],(void*)0,&g_146},{&g_16[2],&g_16[3],&g_16[1],&g_514,&g_146},{(void*)0,&g_16[1],&g_514,&g_16[3],&g_146},{(void*)0,&g_146,&g_16[1],&g_16[1],&g_146},{&g_146,&g_16[1],&g_514,&g_146,(void*)0}}};
            int8_t **l_1002[7] = {&l_1003[0][3][1],&l_1003[0][3][1],&l_1003[0][3][1],&l_1003[0][3][1],&l_1003[0][3][1],&l_1003[0][3][1],&l_1003[0][3][1]};
            int i, j, k;
        }
    }
    --g_1032;
    return p_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_223 g_147 g_40 g_389 g_390 g_391
 * writes: g_223 g_147 g_40 g_392
 */
static int8_t  func_52(int32_t  p_53, uint64_t  p_54)
{ /* block id: 139 */
    uint16_t l_354 = 7UL;
    int32_t ****l_365 = &g_200;
    int32_t *****l_364 = &l_365;
    uint32_t l_368 = 0xE4552CEBL;
    int32_t l_407[9] = {0xFE383FABL,0xA84CD22CL,0xFE383FABL,0xA84CD22CL,0xFE383FABL,0xA84CD22CL,0xFE383FABL,0xA84CD22CL,0xFE383FABL};
    uint8_t *l_475 = &g_269;
    int64_t l_519 = 0xD9AA4E237DDDB9DCLL;
    int32_t l_558 = 6L;
    uint32_t l_763[3][4] = {{4294967289UL,0x74220B3BL,0x16449315L,0x16449315L},{4294967295UL,4294967295UL,4294967289UL,0x16449315L},{4294967295UL,0x74220B3BL,4294967295UL,4294967289UL}};
    int8_t l_767[2][8] = {{1L,0x0CL,(-1L),1L,(-1L),0x0CL,1L,1L},{0x0CL,1L,(-2L),(-2L),1L,0x0CL,6L,0x0CL}};
    int16_t l_768 = 3L;
    int i, j;
    for (g_223 = 0; (g_223 == 43); g_223++)
    { /* block id: 142 */
        int32_t *l_353[3];
        int i;
        for (i = 0; i < 3; i++)
            l_353[i] = &g_40;
        if (p_54)
            break;
        ++l_354;
        if (p_54)
            break;
    }
    for (g_147 = 0; (g_147 <= 2); g_147 += 1)
    { /* block id: 149 */
        uint8_t *l_359 = &g_123;
        int16_t *l_369[3];
        int32_t *l_371 = &g_78;
        int64_t l_441 = 0L;
        int32_t l_465 = 0x24A492DCL;
        int64_t l_466 = 1L;
        uint64_t *l_468 = &g_87;
        int64_t *l_469 = &g_112;
        const int8_t l_470 = 0x8EL;
        uint64_t *l_587 = (void*)0;
        const int16_t *l_598 = (void*)0;
        uint32_t **l_750 = (void*)0;
        const int16_t l_755 = 1L;
        int i;
        for (i = 0; i < 3; i++)
            l_369[i] = &g_144;
    }
    for (g_40 = 0; (g_40 < 27); g_40 = safe_add_func_int16_t_s_s(g_40, 3))
    { /* block id: 343 */
        uint8_t l_762[6] = {8UL,8UL,8UL,8UL,8UL,8UL};
        int32_t l_764[2];
        int32_t *l_765 = &g_145;
        int32_t *l_766[2];
        uint64_t l_769 = 0xD1F67B3170294C4FLL;
        int i;
        for (i = 0; i < 2; i++)
            l_764[i] = 0L;
        for (i = 0; i < 2; i++)
            l_766[i] = (void*)0;
        l_764[1] ^= (((0x5FL && l_762[3]) & 0x99EC8309L) , l_763[2][2]);
        --l_769;
        (***g_389) = &l_764[0];
    }
    return g_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_223 g_16
 * writes: g_108
 */
static uint64_t  func_57(uint16_t  p_58, uint64_t  p_59, int32_t ** p_60, const int8_t  p_61)
{ /* block id: 135 */
    int32_t l_338 = (-8L);
    int16_t *l_348 = &g_108;
    uint32_t l_349 = 4294967295UL;
    l_349 = (p_59 & (l_338 ^ (g_223 > (~((safe_rshift_func_uint8_t_u_s(l_338, 5)) , (((g_16[0] | 0xD1E39030A3B3E62BLL) , (safe_div_func_int16_t_s_s(((*l_348) = (l_338 , (safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(p_58, (-9L))), 2)))), 7L))) >= 0x36461E4DL))))));
    return l_349;
}


/* ------------------------------------------ */
/* 
 * reads : g_184.f0 g_77 g_189.f2 g_122 g_40 g_78 g_126 g_200 g_201 g_145 g_186 g_187.f0 g_223 g_144 g_279 g_184.f2
 * writes: g_184.f0 g_40 g_78 g_145 g_189.f2 g_122 g_126 g_188.f0 g_147
 */
static int8_t  func_62(int32_t ** p_63, int32_t  p_64, const int64_t  p_65)
{ /* block id: 109 */
    int32_t *l_293 = &g_145;
    int32_t **l_294 = &l_293;
    union U1 *l_323 = &g_324;
    int32_t l_336[6];
    int i;
    for (i = 0; i < 6; i++)
        l_336[i] = 0x64FCCB9FL;
    (*l_294) = l_293;
    for (g_184.f0 = (-1); (g_184.f0 != 9); g_184.f0++)
    { /* block id: 113 */
        int32_t l_297 = 0L;
        int32_t *l_298 = (void*)0;
        int32_t *l_299[2][3] = {{&g_122,&g_122,&g_122},{&g_122,&g_122,&g_122}};
        int i, j;
        g_122 |= (g_189[0].f2 ^= ((**l_294) = ((*g_77) = l_297)));
        if ((*g_77))
            break;
    }
    for (g_126 = 0; (g_126 > 44); g_126 = safe_add_func_int32_t_s_s(g_126, 8))
    { /* block id: 122 */
        int64_t *l_308 = &g_188.f0;
        const int32_t **l_311[3];
        int i;
        for (i = 0; i < 3; i++)
            l_311[i] = (void*)0;
        if ((((g_126 || (safe_sub_func_uint32_t_u_u(4UL, 0x972ECE0BL))) , (safe_div_func_int8_t_s_s(((void*)0 == l_293), (safe_sub_func_int64_t_s_s(((*l_308) = p_65), (safe_div_func_int32_t_s_s(((*g_200) != l_311[0]), (((((g_189[0].f2 && p_64) != p_64) & 1UL) != p_65) || (*l_293))))))))) >= 0xF8D6L))
        { /* block id: 124 */
            uint64_t *l_314 = &g_147;
            uint64_t *l_315[2][3][2] = {{{&g_126,&g_126},{&g_87,&g_126},{&g_126,&g_87}},{{&g_126,&g_126},{&g_87,&g_126},{&g_126,&g_87}}};
            int32_t l_316[6] = {2L,2L,3L,2L,2L,3L};
            int32_t l_335 = 0xD20B754DL;
            int i, j, k;
            (**l_294) = ((safe_rshift_func_int16_t_s_u((((l_316[1] = ((*l_314) = g_126)) == (safe_rshift_func_int16_t_s_u(((safe_sub_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((((&l_311[1] == (void*)0) , g_186[0][1]) == (p_64 , l_323)) != (0L && (safe_mul_func_uint64_t_u_u(0xE4898F8879DCF547LL, ((safe_add_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u(g_187.f0, l_335)) <= 1UL), 13)) , g_223), 0L)), g_144)) > l_335))))), 0x12C4BCE4L)), g_279[1][3])) && 0x0454L), g_78))) != g_184.f2), p_64)) , (*g_77));
            return l_316[1];
        }
        else
        { /* block id: 129 */
            l_336[5] ^= (7L >= (**l_294));
        }
    }
    return (*l_293);
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_43 g_87 g_92 g_78 g_16 g_108 g_77 g_112 g_113 g_123 g_126 g_75 g_147 g_200 g_146 g_223 g_225 g_188.f0 g_145 g_235 g_189.f0 g_180 g_122 g_201 g_187.f0 g_188.f2 g_269
 * writes: g_40 g_75 g_77 g_87 g_78 g_108 g_112 g_113 g_123 g_126 g_147 g_223 g_180 g_144 g_122 g_146 g_92 g_269
 */
static int32_t ** func_66(int32_t * p_67)
{ /* block id: 4 */
    uint16_t l_68[6] = {0x3D22L,0x3D22L,0x3D22L,0x3D22L,0x3D22L,0x3D22L};
    int64_t l_73 = 0L;
    int32_t *l_94 = &g_78;
    int32_t * const *l_93[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t **l_95 = (void*)0;
    int32_t **l_98 = &l_94;
    int32_t l_119 = 0xA6C391FFL;
    int16_t *l_139 = (void*)0;
    union U1 **l_221[6][7][1] = {{{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]}},{{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0}},{{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]}},{{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0}},{{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]}},{{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0},{&g_186[1][0]},{(void*)0}}};
    uint8_t l_265 = 255UL;
    uint16_t l_266[8] = {0x6F4FL,0xCFE6L,0x6F4FL,0x6F4FL,0xCFE6L,0x6F4FL,0x6F4FL,0xCFE6L};
    uint64_t *l_267 = &g_92;
    uint8_t *l_268 = &g_269;
    int i, j, k;
    (*p_67) = (l_68[1] , l_68[3]);
    for (g_40 = 1; (g_40 <= 5); g_40 += 1)
    { /* block id: 8 */
        uint8_t *l_74 = &g_75[1][0];
        int32_t *l_76 = &g_40;
        uint64_t *l_85 = (void*)0;
        uint64_t *l_86 = &g_87;
        int32_t **l_97[2];
        int32_t ***l_96 = &l_97[0];
        int16_t l_117 = (-5L);
        uint16_t l_156 = 0x823AL;
        union U1 *l_183 = &g_184;
        int i;
        for (i = 0; i < 2; i++)
            l_97[i] = &l_94;
        g_78 = ((l_98 = ((*l_96) = (l_95 = ((((safe_mul_func_int8_t_s_s(l_68[g_40], (safe_rshift_func_uint8_t_u_s((g_43 == ((*l_74) = l_73)), ((l_76 != (g_77 = &g_40)) ^ ((safe_add_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((safe_mod_func_int8_t_s_s((((*l_86)--) || (((((((g_92 <= ((void*)0 != &g_87)) & g_87) , l_93[0]) != (void*)0) >= 0x01L) || (*l_76)) || (*l_76))), (*l_94))) < 0UL) > g_16[1]), g_16[1])), (*l_76))) < (*l_76))))))) , (*l_76)) < 0xEA2DL) , &p_67)))) == &p_67);
        for (g_87 = 0; (g_87 <= 5); g_87 += 1)
        { /* block id: 18 */
            uint8_t *l_99 = &g_75[2][2];
            int32_t l_100 = 0L;
            int16_t *l_107 = &g_108;
            int32_t *l_111 = &g_78;
            int32_t l_118 = (-8L);
            int32_t l_120 = (-1L);
            int32_t l_136[9] = {0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L,0x864F27C2L};
            int16_t **l_140 = &l_139;
            int32_t ***l_204 = &l_98;
            uint32_t l_218 = 3UL;
            int i;
            g_112 |= ((l_99 != l_99) > (l_100 < (((void*)0 != &g_75[0][1]) < (safe_div_func_uint64_t_u_u((safe_div_func_int32_t_s_s(((((*l_95) = &g_78) != ((safe_lshift_func_int16_t_s_u(((*l_107) |= (-1L)), (((safe_add_func_int32_t_s_s(((g_92 == (65528UL && l_100)) | 18446744073709551614UL), 1UL)) , l_100) || 0xA7L))) , l_111)) , 0x15289768L), (*g_77))), (*l_94))))));
            for (g_112 = 5; (g_112 >= 0); g_112 -= 1)
            { /* block id: 24 */
                int8_t l_114 = (-1L);
                int32_t l_115 = 0x5BCBD5E9L;
                int32_t l_116 = 0x329EC220L;
                int32_t l_121 = 0x5DCB7840L;
                (*p_67) = ((void*)0 == (*l_96));
                g_113 |= (*p_67);
                g_123++;
                g_126++;
            }
            if (((safe_mul_func_int8_t_s_s((!g_87), ((safe_lshift_func_int16_t_s_s(g_126, 3)) & (safe_sub_func_int16_t_s_s(l_136[8], 0x858AL))))) < (((g_92 <= (g_16[3] , ((4294967295UL < (safe_sub_func_int32_t_s_s((((*l_107) = ((((((((*l_140) = l_139) != &l_117) , (***l_96)) <= 251UL) <= (***l_96)) || (*l_111)) < g_113)) | (*l_94)), (***l_96)))) , g_75[1][0]))) > 0xBBC9L) >= g_92)))
            { /* block id: 32 */
                int16_t l_141 = 0x9334L;
                int32_t l_143[10][3] = {{0xC200A6F4L,1L,0xBAF640DEL},{0L,3L,0xBAF640DEL},{4L,0xBAF640DEL,0xC200A6F4L},{0x09EE3F61L,0L,0xCFED7C6FL},{0xBAF640DEL,0xBAF640DEL,0L},{0xEBD967F9L,3L,0L},{0xEBD967F9L,1L,0x09EE3F61L},{0xBAF640DEL,0xC200A6F4L,3L},{0x09EE3F61L,0xEBD967F9L,0x09EE3F61L},{4L,0x31CE9D0EL,0L}};
                int32_t l_224 = 0x84601AF3L;
                int i, j;
                for (l_118 = 4; (l_118 >= 0); l_118 -= 1)
                { /* block id: 35 */
                    int32_t l_142 = 0L;
                    int32_t l_174 = (-5L);
                    int i;
                    ++g_147;
                }
                for (g_112 = 3; (g_112 <= 8); g_112 += 1)
                { /* block id: 57 */
                    uint64_t l_192 = 7UL;
                    int8_t l_213 = 1L;
                    int32_t l_226[1][10][3] = {{{0x0C132715L,(-1L),(-1L)},{0xF388FD20L,0xFDAD4E82L,(-1L)},{0xF388FD20L,(-1L),0x53A75C7AL},{0x0C132715L,(-1L),0x0C132715L},{0x53A75C7AL,(-1L),0xF388FD20L},{(-1L),0xFDAD4E82L,0xF388FD20L},{(-1L),(-1L),0x0C132715L},{0xAFA02245L,0xAFA02245L,0x53A75C7AL},{(-1L),0x53A75C7AL,(-1L)},{(-1L),0x53A75C7AL,(-1L)}}};
                    int i, j, k;
                    for (l_117 = 0; (l_117 <= 1); l_117 += 1)
                    { /* block id: 60 */
                        int32_t l_190 = 0x108AC6A7L;
                        int32_t l_191 = 3L;
                        int32_t ****l_202 = (void*)0;
                        int32_t ****l_203 = (void*)0;
                        uint32_t *l_222[6] = {&g_223,&g_223,&g_223,&g_223,&g_223,&g_223};
                        int i;
                        ++l_192;
                        l_226[0][6][2] |= (safe_div_func_int8_t_s_s((safe_mod_func_int64_t_s_s((l_136[(l_117 + 4)] <= ((+(((l_204 = g_200) == (void*)0) > (safe_rshift_func_uint8_t_u_s((((((((safe_lshift_func_int8_t_s_u(((safe_div_func_int16_t_s_s((safe_sub_func_int32_t_s_s((*p_67), (l_213 == ((&g_108 != ((safe_mod_func_uint32_t_u_u((g_223 ^= ((safe_lshift_func_int16_t_s_u((l_218 && (safe_div_func_int8_t_s_s(((void*)0 != l_221[5][1][0]), g_146))), (*l_111))) != 4294967295UL)), l_224)) , &g_144)) , l_143[7][1])))), g_126)) >= g_225[8][0]), (**l_98))) == g_188.f0) <= l_141) >= 65532UL) < 1UL) & g_145) <= l_213), l_192)))) , (*l_111))), l_213)), 0x1FL));
                    }
                    for (l_224 = 1; (l_224 >= 0); l_224 -= 1)
                    { /* block id: 68 */
                        uint32_t *l_232 = &l_218;
                        uint32_t **l_231 = &l_232;
                        uint32_t *l_241 = &g_180[0];
                        int i;
                        (*l_94) ^= l_136[(l_224 + 5)];
                        l_226[0][1][0] = (safe_mul_func_int16_t_s_s((((*l_241) = (l_93[(l_224 + 2)] == ((g_188.f0 < ((*l_99) = ((safe_rshift_func_int8_t_s_u(((&g_223 == ((*l_231) = &g_223)) <= ((safe_div_func_uint64_t_u_u((g_235 != (void*)0), ((~((l_68[g_40] = (safe_div_func_int32_t_s_s(l_141, (safe_lshift_func_uint16_t_u_s(65526UL, l_224))))) == 0x9C90L)) , g_189[0].f0))) | 0xDD29B11EE2376F68LL)), 4)) ^ g_75[1][0]))) , &p_67))) , (-9L)), 0xA8ACL));
                    }
                    if (l_136[(g_40 + 3)])
                        continue;
                }
            }
            else
            { /* block id: 78 */
                int8_t l_249 = 1L;
                for (g_123 = 1; (g_123 <= 5); g_123 += 1)
                { /* block id: 81 */
                    uint64_t l_248 = 18446744073709551612UL;
                    int32_t l_250 = 0xD16691D6L;
                    l_250 ^= ((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((((g_144 = ((0x9CEE8C25C54F0108LL != 4UL) != g_16[3])) == (safe_sub_func_int16_t_s_s(l_248, (**l_98)))) <= ((*p_67) | g_180[7])) >= ((l_248 & (3L && 65533UL)) < (***l_204))), l_249)), (***l_96))) != 0xAFL);
                    for (g_122 = 0; (g_122 <= 5); g_122 += 1)
                    { /* block id: 86 */
                        int32_t l_251 = 0x6A5F493BL;
                        l_251 &= ((**l_95) = (*g_77));
                        if (l_249)
                            break;
                    }
                    if (l_249)
                        continue;
                    return (*g_200);
                }
            }
        }
    }
    (*l_98) = ((((*l_268) ^= (g_123 = (((g_180[6] , (safe_lshift_func_int8_t_s_s(((**l_98) , ((*l_94) >= ((safe_rshift_func_uint16_t_u_s((**l_98), (((safe_mod_func_int64_t_s_s((1L != (+(*l_94))), ((*l_267) &= (((l_266[5] = (l_265 = (((((safe_mul_func_int8_t_s_s((*l_94), (safe_sub_func_uint32_t_u_u((g_123 < (g_146 = (safe_div_func_uint32_t_u_u((((g_113 , (**l_98)) | (*g_77)) || g_225[8][0]), g_225[3][0])))), (-4L))))) != g_187.f0) || 1UL) && (*l_94)) <= g_188.f2))) , 0x41L) , (*l_94))))) != 0x9B47L) <= 0x7DL))) == g_75[1][0]))), 6))) == (*p_67)) & (*p_67)))) < (*l_94)) , p_67);
    return (*g_200);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_7[i][j], "g_7[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_16[i], "g_16[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_75[i][j], "g_75[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_144, "g_144", print_hash_value);
    transparent_crc(g_145, "g_145", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    transparent_crc(g_147, "g_147", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_180[i], "g_180[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_184.f0, "g_184.f0", print_hash_value);
    transparent_crc(g_184.f1, "g_184.f1", print_hash_value);
    transparent_crc(g_184.f2, "g_184.f2", print_hash_value);
    transparent_crc(g_184.f3, "g_184.f3", print_hash_value);
    transparent_crc(g_187.f0, "g_187.f0", print_hash_value);
    transparent_crc(g_187.f1, "g_187.f1", print_hash_value);
    transparent_crc(g_187.f2, "g_187.f2", print_hash_value);
    transparent_crc(g_187.f3, "g_187.f3", print_hash_value);
    transparent_crc(g_188.f0, "g_188.f0", print_hash_value);
    transparent_crc(g_188.f1, "g_188.f1", print_hash_value);
    transparent_crc(g_188.f2, "g_188.f2", print_hash_value);
    transparent_crc(g_188.f3, "g_188.f3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_189[i].f2, "g_189[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_223, "g_223", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_225[i][j], "g_225[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_269, "g_269", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_279[i][j], "g_279[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_292, "g_292", print_hash_value);
    transparent_crc(g_324.f0, "g_324.f0", print_hash_value);
    transparent_crc(g_324.f1, "g_324.f1", print_hash_value);
    transparent_crc(g_324.f2, "g_324.f2", print_hash_value);
    transparent_crc(g_324.f3, "g_324.f3", print_hash_value);
    transparent_crc(g_381, "g_381", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_442[i][j][k], "g_442[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_514, "g_514", print_hash_value);
    transparent_crc(g_532, "g_532", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_561[i], "g_561[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_633, "g_633", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_756[i], "g_756[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_803, "g_803", print_hash_value);
    transparent_crc(g_816, "g_816", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_843[i][j], "g_843[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_909, "g_909", print_hash_value);
    transparent_crc(g_991, "g_991", print_hash_value);
    transparent_crc(g_997, "g_997", print_hash_value);
    transparent_crc(g_1028, "g_1028", print_hash_value);
    transparent_crc(g_1029, "g_1029", print_hash_value);
    transparent_crc(g_1030, "g_1030", print_hash_value);
    transparent_crc(g_1031, "g_1031", print_hash_value);
    transparent_crc(g_1032, "g_1032", print_hash_value);
    transparent_crc(g_1047.f0, "g_1047.f0", print_hash_value);
    transparent_crc(g_1047.f1, "g_1047.f1", print_hash_value);
    transparent_crc(g_1047.f2, "g_1047.f2", print_hash_value);
    transparent_crc(g_1047.f3, "g_1047.f3", print_hash_value);
    transparent_crc(g_1048.f0, "g_1048.f0", print_hash_value);
    transparent_crc(g_1048.f1, "g_1048.f1", print_hash_value);
    transparent_crc(g_1048.f2, "g_1048.f2", print_hash_value);
    transparent_crc(g_1048.f3, "g_1048.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_1112[i][j], "g_1112[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1113, "g_1113", print_hash_value);
    transparent_crc(g_1120, "g_1120", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1121[i][j][k], "g_1121[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1122, "g_1122", print_hash_value);
    transparent_crc(g_1124, "g_1124", print_hash_value);
    transparent_crc(g_1159, "g_1159", print_hash_value);
    transparent_crc(g_1197, "g_1197", print_hash_value);
    transparent_crc(g_1198, "g_1198", print_hash_value);
    transparent_crc(g_1199, "g_1199", print_hash_value);
    transparent_crc(g_1200, "g_1200", print_hash_value);
    transparent_crc(g_1201, "g_1201", print_hash_value);
    transparent_crc(g_1202, "g_1202", print_hash_value);
    transparent_crc(g_1203, "g_1203", print_hash_value);
    transparent_crc(g_1204, "g_1204", print_hash_value);
    transparent_crc(g_1205, "g_1205", print_hash_value);
    transparent_crc(g_1206, "g_1206", print_hash_value);
    transparent_crc(g_1207, "g_1207", print_hash_value);
    transparent_crc(g_1208, "g_1208", print_hash_value);
    transparent_crc(g_1209, "g_1209", print_hash_value);
    transparent_crc(g_1210, "g_1210", print_hash_value);
    transparent_crc(g_1211, "g_1211", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1212[i][j], "g_1212[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1213[i], "g_1213[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1214, "g_1214", print_hash_value);
    transparent_crc(g_1215, "g_1215", print_hash_value);
    transparent_crc(g_1216, "g_1216", print_hash_value);
    transparent_crc(g_1217, "g_1217", print_hash_value);
    transparent_crc(g_1218, "g_1218", print_hash_value);
    transparent_crc(g_1219, "g_1219", print_hash_value);
    transparent_crc(g_1220, "g_1220", print_hash_value);
    transparent_crc(g_1221, "g_1221", print_hash_value);
    transparent_crc(g_1222, "g_1222", print_hash_value);
    transparent_crc(g_1223, "g_1223", print_hash_value);
    transparent_crc(g_1224, "g_1224", print_hash_value);
    transparent_crc(g_1225, "g_1225", print_hash_value);
    transparent_crc(g_1226, "g_1226", print_hash_value);
    transparent_crc(g_1227, "g_1227", print_hash_value);
    transparent_crc(g_1228, "g_1228", print_hash_value);
    transparent_crc(g_1229, "g_1229", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1230[i][j], "g_1230[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1231, "g_1231", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1232[i], "g_1232[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1233, "g_1233", print_hash_value);
    transparent_crc(g_1234, "g_1234", print_hash_value);
    transparent_crc(g_1235, "g_1235", print_hash_value);
    transparent_crc(g_1236, "g_1236", print_hash_value);
    transparent_crc(g_1237, "g_1237", print_hash_value);
    transparent_crc(g_1238, "g_1238", print_hash_value);
    transparent_crc(g_1239, "g_1239", print_hash_value);
    transparent_crc(g_1240, "g_1240", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1241[i], "g_1241[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1242, "g_1242", print_hash_value);
    transparent_crc(g_1243, "g_1243", print_hash_value);
    transparent_crc(g_1244, "g_1244", print_hash_value);
    transparent_crc(g_1245, "g_1245", print_hash_value);
    transparent_crc(g_1246, "g_1246", print_hash_value);
    transparent_crc(g_1247, "g_1247", print_hash_value);
    transparent_crc(g_1248, "g_1248", print_hash_value);
    transparent_crc(g_1249, "g_1249", print_hash_value);
    transparent_crc(g_1250, "g_1250", print_hash_value);
    transparent_crc(g_1251, "g_1251", print_hash_value);
    transparent_crc(g_1252, "g_1252", print_hash_value);
    transparent_crc(g_1253, "g_1253", print_hash_value);
    transparent_crc(g_1254, "g_1254", print_hash_value);
    transparent_crc(g_1255, "g_1255", print_hash_value);
    transparent_crc(g_1256, "g_1256", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1257[i][j], "g_1257[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1258, "g_1258", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1259[i][j][k], "g_1259[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1294, "g_1294", print_hash_value);
    transparent_crc(g_1297, "g_1297", print_hash_value);
    transparent_crc(g_1417, "g_1417", print_hash_value);
    transparent_crc(g_1490.f0, "g_1490.f0", print_hash_value);
    transparent_crc(g_1490.f1, "g_1490.f1", print_hash_value);
    transparent_crc(g_1490.f2, "g_1490.f2", print_hash_value);
    transparent_crc(g_1490.f3, "g_1490.f3", print_hash_value);
    transparent_crc(g_1493.f0, "g_1493.f0", print_hash_value);
    transparent_crc(g_1493.f1, "g_1493.f1", print_hash_value);
    transparent_crc(g_1493.f2, "g_1493.f2", print_hash_value);
    transparent_crc(g_1493.f3, "g_1493.f3", print_hash_value);
    transparent_crc(g_1517, "g_1517", print_hash_value);
    transparent_crc(g_1582.f0, "g_1582.f0", print_hash_value);
    transparent_crc(g_1582.f1, "g_1582.f1", print_hash_value);
    transparent_crc(g_1582.f2, "g_1582.f2", print_hash_value);
    transparent_crc(g_1582.f3, "g_1582.f3", print_hash_value);
    transparent_crc(g_1587, "g_1587", print_hash_value);
    transparent_crc(g_1599, "g_1599", print_hash_value);
    transparent_crc(g_1624, "g_1624", print_hash_value);
    transparent_crc(g_1689.f0, "g_1689.f0", print_hash_value);
    transparent_crc(g_1689.f1, "g_1689.f1", print_hash_value);
    transparent_crc(g_1689.f2, "g_1689.f2", print_hash_value);
    transparent_crc(g_1689.f3, "g_1689.f3", print_hash_value);
    transparent_crc(g_1689.f4, "g_1689.f4", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1760[i][j][k], "g_1760[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1851, "g_1851", print_hash_value);
    transparent_crc(g_1946.f0, "g_1946.f0", print_hash_value);
    transparent_crc(g_1946.f1, "g_1946.f1", print_hash_value);
    transparent_crc(g_1946.f2, "g_1946.f2", print_hash_value);
    transparent_crc(g_1946.f3, "g_1946.f3", print_hash_value);
    transparent_crc(g_1946.f4, "g_1946.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 440
   depth: 1, occurrence: 1
XXX total union variables: 1

XXX non-zero bitfields defined in structs: 6
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 3
XXX structs with bitfields in the program: 39
breakdown:
   indirect level: 0, occurrence: 2
   indirect level: 1, occurrence: 8
   indirect level: 2, occurrence: 17
   indirect level: 3, occurrence: 5
   indirect level: 4, occurrence: 2
   indirect level: 5, occurrence: 3
   indirect level: 6, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 12
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 3
XXX times a single bitfield on LHS: 6
XXX times a single bitfield on RHS: 22

XXX max expression depth: 49
breakdown:
   depth: 1, occurrence: 210
   depth: 2, occurrence: 55
   depth: 3, occurrence: 3
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 13, occurrence: 2
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 2
   depth: 21, occurrence: 3
   depth: 22, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 3
   depth: 34, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 42, occurrence: 1
   depth: 45, occurrence: 1
   depth: 49, occurrence: 1

XXX total number of pointers: 408

XXX times a variable address is taken: 913
XXX times a pointer is dereferenced on RHS: 272
breakdown:
   depth: 1, occurrence: 198
   depth: 2, occurrence: 52
   depth: 3, occurrence: 20
   depth: 4, occurrence: 2
XXX times a pointer is dereferenced on LHS: 299
breakdown:
   depth: 1, occurrence: 248
   depth: 2, occurrence: 34
   depth: 3, occurrence: 17
XXX times a pointer is compared with null: 45
XXX times a pointer is compared with address of another variable: 17
XXX times a pointer is compared with another pointer: 15
XXX times a pointer is qualified to be dereferenced: 4472

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1108
   level: 2, occurrence: 268
   level: 3, occurrence: 194
   level: 4, occurrence: 76
   level: 5, occurrence: 60
XXX number of pointers point to pointers: 170
XXX number of pointers point to scalars: 229
XXX number of pointers point to structs: 2
XXX percent of pointers has null in alias set: 30.9
XXX average alias set size: 1.55

XXX times a non-volatile is read: 1741
XXX times a non-volatile is write: 920
XXX times a volatile is read: 34
XXX    times read thru a pointer: 20
XXX times a volatile is write: 3
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 677
XXX percentage of non-volatile access: 98.6

XXX forward jumps: 2
XXX backward jumps: 2

XXX stmts: 216
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 29
   depth: 2, occurrence: 25
   depth: 3, occurrence: 31
   depth: 4, occurrence: 46
   depth: 5, occurrence: 54

XXX percentage a fresh-made variable is used: 17.6
XXX percentage an existing variable is used: 82.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

