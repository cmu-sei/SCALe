/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2737465354
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   signed f0 : 19;
   uint64_t  f1;
   int32_t  f2;
};

union U1 {
   volatile int32_t  f0;
   int64_t  f1;
   int32_t  f2;
   uint32_t  f3;
};

union U2 {
   const uint16_t  f0;
   uint32_t  f1;
   volatile uint8_t  f2;
   uint32_t  f3;
   volatile int64_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x63E31551L;
static volatile int32_t g_5 = 0L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = (-1L);/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = (-1L);/* VOLATILE GLOBAL g_7 */
static int32_t g_8 = 0x247ADF1AL;
static int16_t g_61[1][9][8] = {{{0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L},{0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L},{0xB684L,0xB684L,1L,0xB684L,0xB684L,1L,0xB684L,0xB684L},{0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L},{0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L},{0xB684L,0xB684L,1L,0xB684L,0xB684L,1L,0x3D47L,0x3D47L},{1L,0x3D47L,1L,1L,0x3D47L,1L,1L,0x3D47L},{0x3D47L,1L,1L,0x3D47L,1L,1L,0x3D47L,1L},{0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L,0xB684L,0x3D47L,0x3D47L}}};
static int32_t g_77 = 0x61529ABCL;
static int32_t g_80 = (-1L);
static const int16_t g_102 = 1L;
static const int16_t g_104 = 0x2BDAL;
static const int16_t *g_103 = &g_104;
static int32_t g_112[9] = {0L,0xE185721BL,0L,0L,0xE185721BL,0L,0L,0xE185721BL,0L};
static int32_t *g_111 = &g_112[3];
static uint8_t g_134[3][1][9] = {{{0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L}},{{0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L}},{{0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L,0xB2L,1UL,0xB2L}}};
static uint8_t g_151 = 0UL;
static uint8_t *g_150 = &g_151;
static int64_t g_159 = (-2L);
static uint32_t g_163 = 0x0FC2DDDAL;
static int64_t g_167 = 0x19FD84452C2E73AFLL;
static union U0 g_227 = {0L};
static int8_t g_248 = 0xC0L;
static uint16_t g_268 = 65531UL;
static int16_t g_276[7][3] = {{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL},{0xA4AFL,0xA4AFL,0xA4AFL}};
static int16_t g_296 = (-9L);
static int32_t g_314 = 0x51A6A6CDL;
static uint64_t g_374[4] = {0x3BE82BF19AEE28D2LL,0x3BE82BF19AEE28D2LL,0x3BE82BF19AEE28D2LL,0x3BE82BF19AEE28D2LL};
static int16_t *g_419 = &g_276[1][2];
static int16_t **g_418 = &g_419;
static uint16_t *g_447 = &g_268;
static uint16_t **g_446 = &g_447;
static int8_t g_503 = (-8L);
static uint32_t g_540 = 0x713DD73CL;
static int64_t *g_552 = &g_159;
static int64_t **g_551[7][6] = {{&g_552,&g_552,&g_552,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552,(void*)0,&g_552},{&g_552,&g_552,&g_552,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552,(void*)0,&g_552},{&g_552,&g_552,&g_552,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552,(void*)0,&g_552},{&g_552,&g_552,&g_552,&g_552,&g_552,&g_552}};
static union U0 g_617[1] = {{-3L}};
static uint8_t g_743 = 246UL;
static uint32_t g_843 = 0UL;
static const volatile union U2 g_886 = {65535UL};/* VOLATILE GLOBAL g_886 */
static const volatile union U2 *g_885 = &g_886;
static union U2 g_892 = {0xAB88L};/* VOLATILE GLOBAL g_892 */
static union U2 g_893[7][1] = {{{0UL}},{{0UL}},{{0UL}},{{0UL}},{{0UL}},{{0UL}},{{0UL}}};
static union U2 g_894[5][10] = {{{0x87B6L},{0xFCC3L},{0x87B6L},{0x7044L},{4UL},{4UL},{0x7044L},{0x87B6L},{0xFCC3L},{0x87B6L}},{{0x87B6L},{0xC994L},{0xFCC3L},{7UL},{0xFCC3L},{0xC994L},{0x87B6L},{0x87B6L},{0xC994L},{0xFCC3L}},{{0xC994L},{0x87B6L},{0x87B6L},{0xC994L},{0xFCC3L},{7UL},{0xFCC3L},{0xC994L},{0x87B6L},{0x87B6L}},{{0xFCC3L},{0x87B6L},{0x7044L},{4UL},{4UL},{0x7044L},{0x87B6L},{0xFCC3L},{0x87B6L},{0x7044L}},{{7UL},{0xC994L},{4UL},{0xC994L},{7UL},{0x7044L},{0x7044L},{7UL},{0xC994L},{4UL}}};
static union U2 g_895 = {1UL};/* VOLATILE GLOBAL g_895 */
static union U2 g_896 = {2UL};/* VOLATILE GLOBAL g_896 */
static union U2 g_897 = {0x4122L};/* VOLATILE GLOBAL g_897 */
static union U2 g_898 = {4UL};/* VOLATILE GLOBAL g_898 */
static union U2 g_899 = {0x145EL};/* VOLATILE GLOBAL g_899 */
static union U2 g_900 = {0x81F7L};/* VOLATILE GLOBAL g_900 */
static union U2 g_901[2] = {{0x3534L},{0x3534L}};
static union U2 g_902 = {0x1BD5L};/* VOLATILE GLOBAL g_902 */
static union U2 g_903 = {0xF575L};/* VOLATILE GLOBAL g_903 */
static union U2 g_904[9][6] = {{{65535UL},{65535UL},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}},{{0x4697L},{0x4697L},{65535UL},{0x4697L},{0x4697L},{65535UL}}};
static union U2 g_905[2][2] = {{{65535UL},{65535UL}},{{65535UL},{65535UL}}};
static union U2 g_906 = {0x80FBL};/* VOLATILE GLOBAL g_906 */
static union U2 g_907[6] = {{65535UL},{65535UL},{65535UL},{65535UL},{65535UL},{65535UL}};
static union U2 g_908 = {0x40FEL};/* VOLATILE GLOBAL g_908 */
static volatile int16_t * const  volatile *g_949 = (void*)0;
static volatile int16_t * const  volatile ** const g_948 = &g_949;
static int16_t g_955 = 0xF889L;
static int16_t g_992 = 0x5725L;
static int64_t ***g_1020 = (void*)0;
static union U0 *g_1035 = &g_617[0];
static union U0 * volatile *g_1034 = &g_1035;
static union U0 **g_1038 = &g_1035;
static int16_t g_1102 = 0L;
static union U1 g_1130 = {0xE94EDCEDL};/* VOLATILE GLOBAL g_1130 */
static union U2 g_1190 = {65535UL};/* VOLATILE GLOBAL g_1190 */
static int8_t g_1207 = (-8L);
static int32_t g_1230[7][3][4] = {{{1L,0x6C580A37L,0x93068D97L,0x32ED6E30L},{0x2FBB614AL,0x4BBACA0FL,0x2FBB614AL,0x4F059FFDL},{0x4BBACA0FL,0x50F7597EL,0x54105C95L,0L}},{{0L,0x3775AD47L,1L,0x50F7597EL},{0xD2D80828L,1L,1L,0xD2D80828L},{0L,(-4L),0x54105C95L,0x613BCF6FL}},{{0x4BBACA0FL,(-8L),0x2FBB614AL,0L},{0x2FBB614AL,0L,0x93068D97L,0x78923D1DL},{1L,0x4DF4401DL,0L,0x613BCF6FL}},{{4L,0x4F059FFDL,0x78923D1DL,0x8C1EDB7AL},{0x3775AD47L,1L,0xABAD5C72L,0xABAD5C72L},{0x32ED6E30L,0x32ED6E30L,0x7DFF42BAL,0L}},{{4L,0xABAD5C72L,0x3775AD47L,(-4L)},{1L,0x4BBACA0FL,0x93068D97L,0x3775AD47L},{0x613BCF6FL,0x4BBACA0FL,0x0077BBCFL,(-4L)}},{{0x4BBACA0FL,0xABAD5C72L,0xDBF3FFA6L,0L},{(-1L),0x32ED6E30L,1L,0xABAD5C72L},{0x8C1EDB7AL,1L,0L,0x8C1EDB7AL}},{{0L,0x4F059FFDL,0xDBF3FFA6L,0x613BCF6FL},{0x6C580A37L,0x4DF4401DL,0x2FBB614AL,0x78923D1DL},{0x613BCF6FL,0L,(-1L),0L}}};
static int8_t g_1273[8] = {0x77L,0x77L,0x77L,0x77L,0x77L,0x77L,0x77L,0x77L};
static union U1 g_1290 = {0L};/* VOLATILE GLOBAL g_1290 */
static union U1 *g_1289 = &g_1290;
static uint8_t g_1305 = 0xF8L;
static union U1 g_1309 = {0x8935D6F4L};/* VOLATILE GLOBAL g_1309 */
static uint16_t g_1354 = 0x6981L;
static uint16_t ***g_1382 = &g_446;
static uint16_t ****g_1381 = &g_1382;
static uint16_t * const ***g_1384 = (void*)0;
static union U2 g_1401[1] = {{0x5FEBL}};
static union U2 g_1403[10][9] = {{{0x62F5L},{1UL},{1UL},{0x62F5L},{1UL},{1UL},{0x62F5L},{1UL},{1UL}},{{1UL},{65535UL},{65535UL},{1UL},{65535UL},{65535UL},{1UL},{65535UL},{65535UL}},{{0x62F5L},{1UL},{1UL},{0x62F5L},{1UL},{1UL},{0x62F5L},{1UL},{1UL}},{{1UL},{65535UL},{65535UL},{1UL},{65535UL},{65535UL},{1UL},{65535UL},{0x3805L}},{{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L}},{{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L}},{{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L}},{{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L}},{{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L},{1UL},{0xFC68L},{0xFC68L}},{{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L},{65535UL},{0x3805L},{0x3805L}}};
static union U2 *g_1402 = &g_1403[4][4];
static int32_t * volatile *g_1504 = &g_111;
static int32_t * volatile * volatile *g_1503 = &g_1504;
static int16_t g_1521 = 8L;
static int32_t g_1638 = 0x7524F88BL;
static int8_t * volatile g_1762 = &g_1273[7];/* VOLATILE GLOBAL g_1762 */
static int8_t * volatile *g_1761 = &g_1762;
static union U1 g_1782 = {0x9B49DBA9L};/* VOLATILE GLOBAL g_1782 */
static union U1 g_1787 = {0xFE0BE5B9L};/* VOLATILE GLOBAL g_1787 */
static union U1 g_1800 = {0x0C0EE21BL};/* VOLATILE GLOBAL g_1800 */
static union U1 g_1801 = {1L};/* VOLATILE GLOBAL g_1801 */
static union U1 g_1802 = {0xE64AD022L};/* VOLATILE GLOBAL g_1802 */
static union U1 g_1803 = {0xF46AADBAL};/* VOLATILE GLOBAL g_1803 */
static union U1 g_1804 = {0x9544A908L};/* VOLATILE GLOBAL g_1804 */
static union U1 g_1805 = {0x7ACE11F5L};/* VOLATILE GLOBAL g_1805 */
static union U1 g_1806[3] = {{0xA206C0C3L},{0xA206C0C3L},{0xA206C0C3L}};
static union U2 g_1832 = {0xCEA6L};/* VOLATILE GLOBAL g_1832 */
static int8_t g_1869 = (-4L);
static union U2 g_1997 = {0UL};/* VOLATILE GLOBAL g_1997 */
static union U2 g_1998[7][7][5] = {{{{0x8F70L},{0xEC35L},{0x8F70L},{0xF373L},{8UL}},{{65530UL},{0xE882L},{0x5C4EL},{7UL},{0x53BDL}},{{1UL},{0x63C0L},{0x3FEDL},{5UL},{0xCD4FL}},{{0UL},{0x8A8CL},{0x5C4EL},{0x53BDL},{0xBEBBL}},{{3UL},{0xC9CFL},{0x8F70L},{0x20FCL},{9UL}},{{65528UL},{0UL},{65532UL},{0xC85BL},{65534UL}},{{1UL},{5UL},{0x7C3FL},{65535UL},{65534UL}}},{{{0UL},{65529UL},{0xB8FDL},{0xD5C5L},{0x8064L}},{{8UL},{65535UL},{0UL},{65535UL},{0UL}},{{65530UL},{0x0F95L},{0xC7F4L},{0xC85BL},{0UL}},{{65535UL},{0x20FCL},{1UL},{0x20FCL},{65535UL}},{{5UL},{7UL},{0x4183L},{0x53BDL},{0xD5C5L}},{{1UL},{65535UL},{0UL},{5UL},{65529UL}},{{0x53BDL},{65529UL},{0UL},{7UL},{0xD5C5L}}},{{{0xD710L},{5UL},{1UL},{0xF373L},{65535UL}},{{0xD5C5L},{65532UL},{0UL},{0xE882L},{0UL}},{{0UL},{0xC9CFL},{8UL},{0x5D95L},{0UL}},{{65529UL},{65533UL},{0UL},{0xC7F4L},{0x8064L}},{{0x623DL},{0x63C0L},{0xCD4FL},{65535UL},{65534UL}},{{65529UL},{0UL},{0x4183L},{5UL},{65534UL}},{{0UL},{0xEC35L},{9UL},{65535UL},{9UL}}},{{{0xD5C5L},{0xD5C5L},{0xC7F4L},{0x50DCL},{0xBEBBL}},{{0xD710L},{0xF373L},{65534UL},{65535UL},{0xCD4FL}},{{0x53BDL},{0xC7F4L},{0xB8FDL},{65534UL},{0x53BDL}},{{1UL},{0xF373L},{0UL},{0x5D95L},{8UL}},{{5UL},{0xD5C5L},{65532UL},{0UL},{0xE882L}},{{65535UL},{0xEC35L},{65535UL},{0xC9CFL},{65534UL}},{{0x53BDL},{65532UL},{0xC7F4L},{65533UL},{0xE882L}}},{{{0UL},{65535UL},{0UL},{0x63C0L},{0x10FFL}},{{65528UL},{0xBEBBL},{0xC7F4L},{0UL},{0x8064L}},{{4UL},{0x20FCL},{0x3FEDL},{0xEC35L},{0xD710L}},{{0xD5C5L},{0xC85BL},{0xC85BL},{0xD5C5L},{65529UL}},{{1UL},{0x63C0L},{9UL},{0xF373L},{3UL}},{{65528UL},{5UL},{65526UL},{0xC7F4L},{65530UL}},{{65534UL},{0x20FCL},{1UL},{0xF373L},{1UL}}},{{{0x53BDL},{0x8A8CL},{65529UL},{0xD5C5L},{65528UL}},{{65529UL},{0xEC35L},{0xEEEAL},{0xEC35L},{65529UL}},{{0x0F95L},{65533UL},{0xB8FDL},{0UL},{65534UL}},{{9UL},{0x20FCL},{0x623DL},{0x63C0L},{0xCD4FL}},{{0xE882L},{0x50DCL},{0UL},{65533UL},{65534UL}},{{0x8F70L},{0x63C0L},{0UL},{0xC9CFL},{65529UL}},{{65534UL},{65528UL},{65532UL},{65532UL},{65528UL}}},{{{0x623DL},{0x20FCL},{65534UL},{5UL},{1UL}},{{5UL},{0x4183L},{0UL},{65529UL},{65530UL}},{{8UL},{65535UL},{0x10FFL},{65535UL},{3UL}},{{5UL},{0UL},{0xB8FDL},{7UL},{65529UL}},{{0x623DL},{65535UL},{0xD710L},{0x20FCL},{0xD710L}},{{65534UL},{0xC7F4L},{65529UL},{0x0F95L},{0x8064L}},{{0x8F70L},{0xC9CFL},{3UL},{65535UL},{0x10FFL}}}};
static union U2 g_1999 = {5UL};/* VOLATILE GLOBAL g_1999 */
static union U2 g_2000[8] = {{0x2316L},{0x2316L},{0x2316L},{0x2316L},{0x2316L},{0x2316L},{0x2316L},{0x2316L}};
static uint32_t g_2029 = 1UL;
static uint16_t g_2046[7] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static uint8_t g_2148 = 0x07L;
static const int32_t g_2149[6] = {0x98E12EEAL,0x98E12EEAL,0x98E12EEAL,0x98E12EEAL,0x98E12EEAL,0x98E12EEAL};
static int32_t * volatile g_2236 = &g_1309.f2;/* VOLATILE GLOBAL g_2236 */
static union U0 *** volatile g_2259 = &g_1038;/* VOLATILE GLOBAL g_2259 */
static volatile union U2 g_2278 = {1UL};/* VOLATILE GLOBAL g_2278 */
static int32_t g_2329 = 3L;
static union U2 ** volatile g_2356 = &g_1402;/* VOLATILE GLOBAL g_2356 */
static int64_t g_2364 = (-1L);
static volatile union U2 g_2409 = {0xF5D5L};/* VOLATILE GLOBAL g_2409 */
static volatile int16_t g_2457 = 0x0943L;/* VOLATILE GLOBAL g_2457 */
static volatile union U1 g_2482 = {1L};/* VOLATILE GLOBAL g_2482 */
static uint32_t g_2500 = 0x4465B749L;
static volatile union U1 g_2541 = {9L};/* VOLATILE GLOBAL g_2541 */
static volatile union U2 g_2567 = {0xEC3CL};/* VOLATILE GLOBAL g_2567 */
static const union U0 ** volatile g_2572 = (void*)0;/* VOLATILE GLOBAL g_2572 */
static const union U0 *g_2573[6] = {&g_617[0],&g_617[0],&g_617[0],&g_617[0],&g_617[0],&g_617[0]};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_16(union U0  p_17, const uint32_t  p_18);
static union U0  func_19(uint32_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t  p_23);
static int8_t  func_24(union U0  p_25, int8_t  p_26);
static uint32_t  func_35(const uint16_t  p_36, int32_t  p_37, int16_t  p_38);
static uint16_t  func_47(const int16_t  p_48, union U0  p_49, int32_t  p_50);
static union U0  func_53(uint16_t  p_54, const int16_t  p_55, uint8_t  p_56, uint8_t  p_57, uint64_t  p_58);
static int32_t  func_63(int16_t * p_64, int32_t  p_65, int16_t * p_66, int16_t * p_67, uint32_t  p_68);
static int16_t * func_71(int32_t  p_72);
static int32_t  func_83(int32_t  p_84, uint64_t  p_85, uint64_t  p_86, const uint64_t  p_87, int32_t  p_88);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_908.f2
 * writes: g_2 g_8
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_11[2];
    int32_t l_2238 = 0x0253B61DL;
    int32_t l_2239[3];
    uint8_t l_2240 = 0x8AL;
    uint32_t l_2260 = 3UL;
    int16_t **l_2272 = &g_419;
    int64_t ***l_2275[8];
    const int64_t l_2306 = 0L;
    const union U0 l_2318 = {4L};
    int32_t **l_2331[3][9] = {{(void*)0,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,(void*)0},{&g_111,&g_111,(void*)0,&g_111,&g_111,&g_111,&g_111,&g_111,(void*)0},{&g_111,&g_111,&g_111,&g_111,&g_111,&g_111,(void*)0,&g_111,&g_111}};
    int32_t l_2355 = (-1L);
    uint32_t l_2357 = 18446744073709551612UL;
    int32_t l_2392 = 0x5C83B2BDL;
    uint8_t l_2395 = 0x4CL;
    uint16_t **** const *l_2402 = &g_1381;
    int32_t l_2453 = 0x7E15BE1CL;
    int32_t l_2455 = 0L;
    int32_t l_2456 = 9L;
    int16_t l_2459 = 0x3C8DL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_11[i] = 0x25D2L;
    for (i = 0; i < 3; i++)
        l_2239[i] = 0L;
    for (i = 0; i < 8; i++)
        l_2275[i] = &g_551[5][5];
    for (g_2 = (-24); (g_2 == 12); ++g_2)
    { /* block id: 3 */
        uint64_t l_2140[9][1] = {{1UL},{0xB24044331748095FLL},{1UL},{0xB24044331748095FLL},{1UL},{0xB24044331748095FLL},{1UL},{0xB24044331748095FLL},{1UL}};
        uint16_t l_2231 = 0x9FDFL;
        int32_t l_2253 = (-1L);
        int32_t *l_2274[7][1];
        uint8_t l_2307 = 1UL;
        int16_t ***l_2326 = &g_418;
        uint8_t l_2332 = 0UL;
        int32_t l_2365 = (-10L);
        uint64_t l_2366[5][8][6] = {{{0x6CE235BBF7725A6DLL,9UL,0x0FD5B6BA7CE9A38ELL,18446744073709551608UL,0x7601C10D48CD8376LL,0x6CE235BBF7725A6DLL},{0xAD8E3870AA0E9867LL,4UL,0x2398FA38932FEBF8LL,18446744073709551615UL,0x83BDC9AC4171A6C4LL,2UL},{9UL,18446744073709551615UL,0UL,0xF50E11E3A59E253DLL,0xB7E851782DA5E5B5LL,0x0FD5B6BA7CE9A38ELL},{0x2398FA38932FEBF8LL,0xB7B65CB5CBD8C368LL,0xD1FC4DF2468A3139LL,0x82728A352BA2A9D1LL,9UL,9UL},{18446744073709551615UL,1UL,1UL,18446744073709551615UL,4UL,0xC9507E2888BD1160LL},{0UL,2UL,18446744073709551612UL,0x0FD5B6BA7CE9A38ELL,0x82728A352BA2A9D1LL,18446744073709551608UL},{0x7601C10D48CD8376LL,6UL,0x767117C768AC21EELL,18446744073709551615UL,0x82728A352BA2A9D1LL,0x2398FA38932FEBF8LL},{0x466FFC8C9FE280CDLL,2UL,0x76C017785D073137LL,9UL,4UL,1UL}},{{0x91AB292FDABE4B62LL,1UL,0UL,0x767117C768AC21EELL,9UL,18446744073709551615UL},{18446744073709551612UL,0xB7B65CB5CBD8C368LL,0x6CE235BBF7725A6DLL,0xF50E11E3A59E253DLL,0xB7E851782DA5E5B5LL,18446744073709551615UL},{2UL,1UL,18446744073709551615UL,0x0FD5B6BA7CE9A38ELL,1UL,0xF50E11E3A59E253DLL},{0xB0287E10008B8BEBLL,18446744073709551608UL,0xB7B65CB5CBD8C368LL,0UL,0x0FD5B6BA7CE9A38ELL,0xB0287E10008B8BEBLL},{0xB7B65CB5CBD8C368LL,0xAD8E3870AA0E9867LL,0x76C017785D073137LL,0UL,18446744073709551615UL,0x6CE235BBF7725A6DLL},{0x2398FA38932FEBF8LL,0x466FFC8C9FE280CDLL,9UL,0x466FFC8C9FE280CDLL,0x2398FA38932FEBF8LL,18446744073709551608UL},{18446744073709551615UL,0xB7B65CB5CBD8C368LL,0x466FFC8C9FE280CDLL,0xF3D5DE6A0B4DBAC1LL,2UL,0xC9507E2888BD1160LL},{18446744073709551615UL,18446744073709551615UL,1UL,0xB7B65CB5CBD8C368LL,0x767117C768AC21EELL,0xC9507E2888BD1160LL}},{{0xB0287E10008B8BEBLL,9UL,0x466FFC8C9FE280CDLL,18446744073709551608UL,0x82728A352BA2A9D1LL,18446744073709551608UL},{0x767117C768AC21EELL,0x2D218AE0BF9175DFLL,9UL,18446744073709551615UL,0x0CECDE521B0D62F1LL,0x6CE235BBF7725A6DLL},{18446744073709551608UL,0xBE321F6031B584B1LL,0x76C017785D073137LL,0x767117C768AC21EELL,0x7601C10D48CD8376LL,0xB0287E10008B8BEBLL},{1UL,1UL,0xB7B65CB5CBD8C368LL,2UL,2UL,0xF50E11E3A59E253DLL},{18446744073709551612UL,0x6978A9AF8CABC829LL,18446744073709551615UL,0xEB591F11CC971998LL,0x6CE235BBF7725A6DLL,18446744073709551615UL},{0x7601C10D48CD8376LL,18446744073709551608UL,0x6CE235BBF7725A6DLL,18446744073709551608UL,1UL,18446744073709551615UL},{1UL,0xAD8E3870AA0E9867LL,0UL,0UL,0xAD8E3870AA0E9867LL,1UL},{0x83BDC9AC4171A6C4LL,0x0FD5B6BA7CE9A38ELL,0x76C017785D073137LL,0x82728A352BA2A9D1LL,0x91AB292FDABE4B62LL,0x2398FA38932FEBF8LL}},{{18446744073709551615UL,0x466FFC8C9FE280CDLL,0x767117C768AC21EELL,18446744073709551612UL,0xB7E851782DA5E5B5LL,18446744073709551608UL},{18446744073709551615UL,0x6978A9AF8CABC829LL,18446744073709551612UL,0x82728A352BA2A9D1LL,0xBE321F6031B584B1LL,0xC9507E2888BD1160LL},{0x83BDC9AC4171A6C4LL,0x91AB292FDABE4B62LL,1UL,0UL,0x767117C768AC21EELL,9UL},{1UL,2UL,0xD1FC4DF2468A3139LL,18446744073709551608UL,0x0CECDE521B0D62F1LL,0x0FD5B6BA7CE9A38ELL},{0x7601C10D48CD8376LL,0xB6478E930543FF4CLL,9UL,0xEB591F11CC971998LL,9UL,0x2398FA38932FEBF8LL},{18446744073709551612UL,0xBE321F6031B584B1LL,1UL,2UL,4UL,0UL},{1UL,18446744073709551615UL,18446744073709551615UL,0x767117C768AC21EELL,0xBE321F6031B584B1LL,0xF50E11E3A59E253DLL},{18446744073709551608UL,0x83BDC9AC4171A6C4LL,0x6CE235BBF7725A6DLL,18446744073709551615UL,0x6CE235BBF7725A6DLL,0x83BDC9AC4171A6C4LL}},{{0x767117C768AC21EELL,1UL,0x63681741E5330FB9LL,18446744073709551608UL,18446744073709551615UL,0xEB591F11CC971998LL},{0xB0287E10008B8BEBLL,0x0FD5B6BA7CE9A38ELL,0UL,0xB7B65CB5CBD8C368LL,18446744073709551608UL,0xB0287E10008B8BEBLL},{18446744073709551615UL,0x0FD5B6BA7CE9A38ELL,1UL,0xF722B7FBFA4616B1LL,18446744073709551615UL,0x76C017785D073137LL},{0x76C017785D073137LL,6UL,18446744073709551608UL,18446744073709551615UL,0UL,0UL},{1UL,1UL,18446744073709551615UL,2UL,18446744073709551615UL,0x6CE235BBF7725A6DLL},{1UL,18446744073709551615UL,1UL,18446744073709551615UL,18446744073709551608UL,18446744073709551615UL},{0x767117C768AC21EELL,18446744073709551615UL,0x2D218AE0BF9175DFLL,18446744073709551615UL,0xBE321F6031B584B1LL,0xB7B65CB5CBD8C368LL},{18446744073709551608UL,0xF3D5DE6A0B4DBAC1LL,18446744073709551608UL,0xD1FC4DF2468A3139LL,9UL,0x76C017785D073137LL}}};
        const int64_t *l_2390[7];
        const int64_t ** const l_2389[8] = {&l_2390[3],&l_2390[3],&l_2390[1],&l_2390[3],&l_2390[3],&l_2390[1],&l_2390[3],&l_2390[3]};
        uint32_t l_2393 = 0xB3C01C96L;
        uint32_t l_2448 = 0xBBF5F38CL;
        int8_t l_2454 = 0x91L;
        int16_t l_2487 = (-8L);
        int64_t l_2551 = 0x4281FB8ECBADB9D0LL;
        int16_t l_2560 = 0L;
        uint8_t **l_2584 = &g_150;
        int i, j, k;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 1; j++)
                l_2274[i][j] = (void*)0;
        }
        for (i = 0; i < 7; i++)
            l_2390[i] = &g_159;
        for (g_8 = 0; (g_8 < (-15)); --g_8)
        { /* block id: 6 */
            union U0 l_27[8][9][3] = {{{{8L},{7L},{0x8E10A3BDL}},{{5L},{4L},{4L}},{{0x5E45DB0FL},{5L},{0x3CB8E004L}},{{-1L},{0x62C80F3BL},{-10L}},{{0x5E45DB0FL},{1L},{3L}},{{5L},{0x3C9E4A04L},{0L}},{{8L},{0x82E77E81L},{-1L}},{{0xE34F9A32L},{5L},{0L}},{{4L},{0L},{0x846C8C5CL}}},{{{0L},{0xCCE005ABL},{-10L}},{{-1L},{0x4A08DEB2L},{0xA2AAFA0BL}},{{8L},{9L},{4L}},{{3L},{0xE4C996E1L},{4L}},{{0L},{0xFA4A603DL},{0xA2AAFA0BL}},{{0x04DDC877L},{0x62C80F3BL},{-10L}},{{1L},{0x3C9E4A04L},{0x846C8C5CL}},{{5L},{8L},{0L}},{{-10L},{-1L},{-1L}}},{{{0x3CB8E004L},{0xFA4A603DL},{0L}},{{0L},{0L},{3L}},{{-4L},{7L},{-10L}},{{-1L},{0L},{0x3CB8E004L}},{{-10L},{7L},{4L}},{{5L},{0L},{0x8E10A3BDL}},{{0x5E45DB0FL},{0xFA4A603DL},{0xE34F9A32L}},{{0x82E77E81L},{-1L},{-10L}},{{1L},{8L},{5L}}},{{{3L},{0x3C9E4A04L},{0L}},{{0x3C9E4A04L},{0x62C80F3BL},{-8L}},{{0xE34F9A32L},{0xFA4A603DL},{0x5E45DB0FL}},{{-4L},{0xE4C996E1L},{0x846C8C5CL}},{{-4L},{9L},{0x3C9E4A04L}},{{0xE34F9A32L},{0x4A08DEB2L},{0x3CB8E004L}},{{0x3C9E4A04L},{0xCCE005ABL},{0x8E10A3BDL}},{{3L},{0L},{0L}},{{1L},{5L},{0xA2AAFA0BL}}},{{{0x82E77E81L},{0x82E77E81L},{0x3C9E4A04L}},{{0x5E45DB0FL},{0x3C9E4A04L},{5L}},{{5L},{1L},{0L}},{{-10L},{0x62C80F3BL},{0x04DDC877L}},{{-1L},{5L},{0L}},{{-4L},{4L},{5L}},{{0L},{7L},{0x3C9E4A04L}},{{0x3CB8E004L},{0x78B15B45L},{0xA2AAFA0BL}},{{-10L},{0xCCE005ABL},{0L}}},{{{5L},{0xE4C996E1L},{0x8E10A3BDL}},{{1L},{5L},{0x3CB8E004L}},{{0x04DDC877L},{-1L},{0x3C9E4A04L}},{{0L},{1L},{0x846C8C5CL}},{{3L},{1L},{0x8E10A3BDL}},{{-1L},{0x80EB60F9L},{0x095DBC2AL}},{{7L},{0x4A08DEB2L},{0L}},{{0xA2AAFA0BL},{0x5E45DB0FL},{0L}},{{0xE34F9A32L},{8L},{0x62C80F3BL}}},{{{0x7656540FL},{1L},{0x7656540FL}},{{-1L},{-10L},{0x33147F59L}},{{0x4A08DEB2L},{0L},{0xE34F9A32L}},{{0x8E10A3BDL},{0L},{0x59842251L}},{{0x80EB60F9L},{2L},{0x62C80F3BL}},{{0x8E10A3BDL},{0x82E77E81L},{-1L}},{{0x4A08DEB2L},{0x04DDC877L},{0x942C3B03L}},{{-1L},{0L},{0x80EB60F9L}},{{0x7656540FL},{0L},{0L}}},{{{0xE34F9A32L},{1L},{0x78B15B45L}},{{0xA2AAFA0BL},{8L},{-8L}},{{7L},{0x7A23A340L},{0xCCE005ABL}},{{-1L},{0x3C9E4A04L},{0xE34F9A32L}},{{-1L},{0x5E45DB0FL},{0xE34F9A32L}},{{0L},{0L},{0xCCE005ABL}},{{1L},{2L},{-8L}},{{4L},{0x04DDC877L},{0x78B15B45L}},{{0x4A08DEB2L},{-1L},{0L}}}};
            int32_t *l_2216 = &g_8;
            int i, j, k;
        }
    }
    return g_908.f2;
}


/* ------------------------------------------ */
/* 
 * reads : g_1762 g_1273
 * writes:
 */
static int8_t  func_16(union U0  p_17, const uint32_t  p_18)
{ /* block id: 1063 */
    int32_t *l_2203 = &g_1802.f2;
    int32_t *l_2204 = &g_112[3];
    int32_t *l_2205 = &g_77;
    int32_t *l_2206 = &g_1803.f2;
    int32_t *l_2207 = &g_314;
    int32_t *l_2208 = &g_112[1];
    int32_t *l_2209 = &g_1805.f2;
    int32_t *l_2210 = &g_617[0].f2;
    int32_t l_2211 = 0xCC2B4FBAL;
    int32_t *l_2212[10] = {(void*)0,&g_1782.f2,&g_1782.f2,(void*)0,&g_314,(void*)0,&g_1782.f2,&g_1782.f2,(void*)0,&g_314};
    uint16_t l_2213 = 0xBFA9L;
    int i;
    ++l_2213;
    return (*g_1762);
}


/* ------------------------------------------ */
/* 
 * reads : g_1504 g_1190.f3 g_1787.f3 g_948 g_949 g_1801.f2 g_150 g_151 g_447 g_268 g_1762 g_1273 g_227.f0 g_2029 g_1290.f1 g_2 g_296
 * writes: g_111 g_1190.f3 g_1787.f3 g_1801.f2 g_151 g_227.f1 g_1290.f1 g_1800.f0 g_296
 */
static union U0  func_19(uint32_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t  p_23)
{ /* block id: 1024 */
    int32_t *l_2150 = (void*)0;
    union U0 l_2155 = {1L};
    uint32_t *l_2162 = &g_1787.f3;
    int16_t **l_2163 = &g_419;
    int32_t *l_2180 = &g_1801.f2;
    uint64_t *l_2183 = (void*)0;
    uint64_t *l_2184[6][8] = {{&g_374[3],&g_374[1],&g_374[3],&g_374[3],(void*)0,&g_374[1],(void*)0,&g_374[3]},{&g_374[1],(void*)0,&g_374[1],&g_374[1],(void*)0,&g_374[1],&g_374[1],&g_374[1]},{(void*)0,&g_374[0],&g_374[1],(void*)0,&g_374[1],(void*)0,(void*)0,&g_374[0]},{(void*)0,&g_374[1],&g_374[1],(void*)0,(void*)0,&g_374[1],&g_374[1],(void*)0},{&g_374[1],&g_374[3],&g_374[0],(void*)0,(void*)0,&g_374[1],&g_374[1],&g_374[1]},{&g_374[3],(void*)0,&g_374[1],&g_374[1],(void*)0,&g_374[1],(void*)0,&g_374[1]}};
    int i, j;
    (*g_1504) = l_2150;
    for (g_1190.f3 = 0; (g_1190.f3 != 58); ++g_1190.f3)
    { /* block id: 1028 */
        uint32_t l_2154 = 4294967290UL;
        l_2154 = (safe_unary_minus_func_uint32_t_u(4294967295UL));
        return l_2155;
    }
    if ((safe_mod_func_uint64_t_u_u((g_227.f1 = ((safe_sub_func_uint32_t_u_u(((*l_2162) ^= (safe_add_func_int8_t_s_s(p_21, 7UL))), (((*g_948) != l_2163) == ((safe_add_func_uint32_t_u_u((safe_rshift_func_int8_t_s_s((safe_div_func_int8_t_s_s(((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u(((safe_div_func_int32_t_s_s(p_20, (safe_div_func_int32_t_s_s(((*l_2180) |= 1L), ((1UL < (p_22 >= ((((*g_150) ^= (safe_div_func_int16_t_s_s(p_22, p_20))) >= p_21) <= 0x4AD54CB855A1D2C6LL))) , 0x85A9B666L))))) , p_21), p_22)), (*g_447))), 2)) , (*g_1762)), g_227.f0)), p_20)), g_2029)) >= p_22)))) & l_2155.f0)), 0x560F399BE049B637LL)))
    { /* block id: 1036 */
        union U1 **l_2193 = &g_1289;
        int32_t l_2195 = 0x40AD48E3L;
        uint16_t l_2196 = 0xB64AL;
        for (p_23 = 0; (p_23 > 11); p_23 = safe_add_func_uint32_t_u_u(p_23, 4))
        { /* block id: 1039 */
            union U2 **l_2188 = &g_1402;
            union U0 l_2191[2] = {{0x9EC9914EL},{0x9EC9914EL}};
            int64_t l_2192 = 1L;
            int32_t *l_2194[5][1] = {{&g_314},{&g_227.f2},{&g_314},{&g_227.f2},{&g_314}};
            int i, j;
            if ((safe_unary_minus_func_int16_t_s((l_2188 != (void*)0))))
            { /* block id: 1040 */
                for (g_1290.f1 = 0; (g_1290.f1 < (-27)); g_1290.f1 = safe_sub_func_uint16_t_u_u(g_1290.f1, 8))
                { /* block id: 1043 */
                    return l_2191[1];
                }
            }
            else
            { /* block id: 1046 */
                return l_2191[1];
            }
            (*l_2180) ^= (((*g_1762) && l_2191[1].f0) && (((g_2 , l_2188) == (void*)0) || l_2192));
            g_1800.f0 = (l_2191[1].f0 |= (((void*)0 != l_2193) || (p_21 && (*l_2180))));
            ++l_2196;
        }
    }
    else
    { /* block id: 1054 */
        int64_t **l_2199[3];
        union U0 l_2202 = {-9L};
        int i;
        for (i = 0; i < 3; i++)
            l_2199[i] = &g_552;
        (*l_2180) ^= ((void*)0 != l_2199[0]);
        for (g_296 = 0; (g_296 <= 17); g_296 = safe_add_func_uint64_t_u_u(g_296, 8))
        { /* block id: 1058 */
            return l_2202;
        }
    }
    return l_2155;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_2 g_61 g_77 g_80 g_112 g_134 g_150 g_102 g_103 g_167 g_111 g_104 g_151 g_227 g_248 g_268 g_276 g_227.f2 g_159 g_418 g_419 g_447 g_296 g_446 g_503 g_163 g_552 g_617 g_314 g_617.f0 g_885 g_892.f0 g_948 g_955 g_905.f0 g_899.f0 g_540 g_992 g_843 g_898.f0 g_904.f0 g_1034 g_374 g_1020 g_551 g_906.f0 g_903.f0 g_907.f0 g_1102 g_898.f1 g_1035 g_897.f3 g_1190.f1 g_1207 g_949 g_1230 g_1190.f3 g_896.f0 g_1273 g_900.f0 g_1130.f3 g_908.f0 g_1289 g_743 g_1305 g_1309.f3 g_1354 g_1290.f2 g_1761 g_1309.f2 g_1309.f1 g_896.f1 g_895.f3 g_908.f1 g_1290.f3 g_1869 g_1802.f3 g_1804.f3 g_1401.f0 g_1521 g_1190.f0 g_895.f0 g_1130.f1 g_1801.f2 g_1381 g_1382 g_2029 g_1805.f1 g_1503 g_1504 g_1038 g_900.f1 g_1804.f2 g_1130.f2 g_1801.f3 g_902.f0
 * writes: g_61 g_77 g_80 g_103 g_111 g_134 g_159 g_163 g_112 g_167 g_151 g_248 g_268 g_276 g_227.f2 g_418 g_446 g_296 g_503 g_447 g_617 g_314 g_540 g_885 g_955 g_1020 g_1038 g_551 g_419 g_1102 g_898.f1 g_227.f1 g_897.f3 g_1190.f1 g_1230 g_1190.f3 g_1130.f3 g_1273 g_843 g_1290.f1 g_1035 g_1289 g_1309.f1 g_895.f3 g_896.f1 g_1521 g_908.f1 g_1207 g_1290.f3 g_374 g_1802.f3 g_1804.f3 g_1801.f2 g_1305 g_1130.f1 g_743 g_2029 g_1805.f1 g_1309.f3 g_2046 g_900.f1 g_1804.f2 g_1354
 */
static int8_t  func_24(union U0  p_25, int8_t  p_26)
{ /* block id: 7 */
    int64_t l_28 = 0x947A332A5B4D633CLL;
    uint16_t **l_1789 = (void*)0;
    int32_t ***l_1919 = (void*)0;
    uint8_t *l_1967[3];
    union U0 l_1995 = {1L};
    int32_t *l_2005 = &g_1801.f2;
    int32_t l_2125 = (-1L);
    int32_t l_2126 = 0xC8CBAD6CL;
    int32_t l_2128 = 1L;
    int32_t l_2129 = 0L;
    int32_t l_2130 = 1L;
    int32_t l_2131 = 0xAEB68F71L;
    int32_t l_2132[4][8][5] = {{{(-6L),0x756E6831L,0x314DA419L,(-4L),5L},{1L,0x92F0FF41L,7L,0x41AAB260L,4L},{0L,7L,(-8L),0L,(-1L)},{(-4L),7L,(-6L),0x58C1D990L,0x6CE8F382L},{(-3L),0x92F0FF41L,4L,(-2L),1L},{2L,0x756E6831L,0L,0xC59E15ECL,(-2L)},{0x60FB7176L,0L,0L,0x60FB7176L,0x059D0B49L},{0L,0x9342075DL,0x6E3E2CF6L,0x60E6FC57L,0xC4DB4BDDL}},{{0x5176B188L,0L,0x58C1D990L,(-3L),9L},{4L,0xC1E4C3BAL,0x677146C2L,0x60E6FC57L,0x314DA419L},{0xD34043F3L,3L,9L,0x60FB7176L,0x9A59CB10L},{3L,4L,4L,0xC59E15ECL,0x019BE666L},{(-8L),0xC59E15ECL,0x059D0B49L,0L,0x314DA419L},{(-6L),0L,9L,0xC4DB4BDDL,4L},{2L,5L,0x452E675EL,0x92F0FF41L,0xD8E062A9L},{2L,(-2L),1L,4L,0xD9E4EFA5L}},{{(-6L),(-3L),0x3263496EL,0L,0x756E6831L},{(-8L),0xD34043F3L,0x2A2849C3L,0L,0L},{0x99E89DFAL,0xD32CD744L,0x99E89DFAL,0x9A59CB10L,0xCE985894L},{(-3L),0x019BE666L,(-4L),0x99E89DFAL,(-1L)},{(-6L),0xC1E4C3BAL,(-1L),0x8C04BACEL,0xD34043F3L},{(-4L),0x58C1D990L,(-4L),(-1L),0x60E6FC57L},{4L,0x60FB7176L,0x99E89DFAL,0x6E3E2CF6L,(-6L)},{0x059D0B49L,(-1L),0x2A2849C3L,9L,0x3263496EL}},{{0L,0x050EAD52L,0x3263496EL,5L,(-3L)},{0x019BE666L,0x756E6831L,1L,0x58C1D990L,9L},{0L,1L,0x452E675EL,0x60E6FC57L,9L},{0x60E6FC57L,0L,9L,0x588BF8EDL,(-3L)},{0x050EAD52L,0x588BF8EDL,0x059D0B49L,0L,0x3263496EL},{1L,(-4L),(-6L),(-3L),(-6L)},{0x9342075DL,0x9342075DL,0x756E6831L,0x6CE8F382L,0x60E6FC57L},{1L,(-1L),0x5176B188L,0L,0xD34043F3L}}};
    uint8_t l_2134 = 0xFDL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_1967[i] = &g_134[1][0][5];
    if (l_28)
    { /* block id: 8 */
        uint32_t l_59 = 0x674DCCE6L;
        int16_t *l_60[9][8][1] = {{{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][7]},{&g_61[0][1][1]},{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][1][1]}},{{&g_61[0][3][7]},{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][3][7]},{(void*)0},{&g_61[0][8][4]}},{{(void*)0},{&g_61[0][7][6]},{&g_61[0][3][7]},{&g_61[0][7][6]},{(void*)0},{&g_61[0][8][4]},{(void*)0},{&g_61[0][3][7]}},{{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][7]},{&g_61[0][1][1]},{&g_61[0][3][6]},{&g_61[0][3][6]}},{{&g_61[0][1][1]},{&g_61[0][3][7]},{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][3][7]},{(void*)0}},{{&g_61[0][8][4]},{(void*)0},{&g_61[0][7][6]},{&g_61[0][3][7]},{&g_61[0][7][6]},{(void*)0},{&g_61[0][8][4]},{(void*)0}},{{&g_61[0][3][7]},{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][7]},{&g_61[0][1][1]},{&g_61[0][3][6]}},{{&g_61[0][3][6]},{&g_61[0][1][1]},{&g_61[0][3][7]},{&g_61[0][3][6]},{&g_61[0][2][2]},{&g_61[0][3][6]},{&g_61[0][3][6]},{&g_61[0][3][7]}},{{(void*)0},{&g_61[0][8][4]},{(void*)0},{&g_61[0][7][6]},{&g_61[0][3][7]},{&g_61[0][7][6]},{(void*)0},{&g_61[0][8][4]}}};
        int16_t *l_62 = &g_61[0][8][6];
        int32_t *l_1788 = &g_80;
        uint16_t ***l_1790 = &g_446;
        uint16_t ***l_1791 = &l_1789;
        int64_t *l_1828 = &g_1803.f1;
        int64_t l_1850[9] = {0x7ACCD607F158617ALL,0xCB473D80140B1067LL,0x7ACCD607F158617ALL,0x7ACCD607F158617ALL,0xCB473D80140B1067LL,0x7ACCD607F158617ALL,0x7ACCD607F158617ALL,0xCB473D80140B1067LL,0x7ACCD607F158617ALL};
        int64_t l_1890 = 0xFC168F6C9E1D7A3ELL;
        uint16_t l_1922 = 0UL;
        int16_t **l_1928 = &l_62;
        union U2 *l_1996[9] = {&g_2000[0],&g_1998[3][5][0],&g_2000[0],&g_1998[3][5][0],&g_2000[0],&g_1998[3][5][0],&g_2000[0],&g_1998[3][5][0],&g_2000[0]};
        int i, j, k;
        (*l_1788) = (safe_lshift_func_uint16_t_u_u((((safe_mod_func_uint8_t_u_u(0x49L, (safe_mul_func_int8_t_s_s(g_8, (func_35(p_26, (p_25.f0 && g_8), (safe_rshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_u((safe_rshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(func_47((safe_add_func_uint16_t_u_u(g_2, g_8)), func_53(l_28, ((*l_62) = (l_59 == p_26)), l_28, g_8, g_8), l_59), p_26)), 5)), 12)), 11))) <= 4294967290UL))))) | 0x63A5L) > p_25.f0), l_59));
        (*l_1788) = l_28;
        if ((((*l_1791) = l_1789) == (void*)0))
        { /* block id: 878 */
            return p_25.f0;
        }
        else
        { /* block id: 880 */
            int32_t l_1792 = 0x6EF99E65L;
            const int32_t * const l_1815[10] = {&g_80,&g_1806[1].f2,&g_80,&g_80,&g_1806[1].f2,&g_80,&g_80,&g_1806[1].f2,&g_80,&g_80};
            const int32_t * const *l_1814 = &l_1815[5];
            int64_t *l_1827[4][10][4] = {{{(void*)0,&g_1309.f1,&g_1309.f1,&g_1309.f1},{&g_1309.f1,(void*)0,&g_167,&g_1309.f1},{&g_167,&g_159,&l_28,&g_1309.f1},{&l_28,(void*)0,&g_159,&g_1309.f1},{&l_28,&g_1309.f1,&g_159,&l_28},{&g_1309.f1,&g_167,&g_159,&g_159},{(void*)0,&g_167,&l_28,(void*)0},{&g_167,&g_1309.f1,&g_1309.f1,&g_1309.f1},{(void*)0,(void*)0,&g_159,&g_167},{&g_1309.f1,&g_1309.f1,&g_159,&g_159}},{{(void*)0,&g_159,(void*)0,&l_28},{&l_28,&g_167,&g_167,&l_28},{&g_167,(void*)0,&g_1309.f1,&g_159},{&g_167,&l_28,&g_167,&g_159},{&g_167,&l_28,&l_28,&l_28},{&g_1309.f1,(void*)0,&l_28,&g_167},{&g_167,(void*)0,&g_1309.f1,&g_1309.f1},{&g_1309.f1,&g_167,&g_1309.f1,&l_28},{&g_1309.f1,&g_159,&g_1309.f1,&g_167},{&g_167,&l_28,&l_28,&l_28}},{{&g_1309.f1,(void*)0,&l_28,&g_1309.f1},{&g_167,&g_167,&g_167,&g_167},{&g_167,(void*)0,&g_1309.f1,&g_167},{&g_167,&g_167,&g_167,(void*)0},{&l_28,&g_159,(void*)0,&g_167},{(void*)0,&l_28,&g_159,&g_1309.f1},{&g_1309.f1,&g_159,&g_159,(void*)0},{(void*)0,&g_1309.f1,&g_1309.f1,(void*)0},{&g_167,&l_28,&l_28,(void*)0},{(void*)0,&g_159,&g_159,&g_159}},{{&g_1309.f1,&g_1309.f1,&g_159,(void*)0},{&l_28,&g_167,&g_159,&g_1309.f1},{&l_28,&g_1309.f1,&l_28,&g_159},{&g_167,&g_1309.f1,&g_167,&g_1309.f1},{&g_1309.f1,&g_167,&g_1309.f1,(void*)0},{(void*)0,&g_1309.f1,&g_167,&g_159},{&l_28,&g_159,&g_1309.f1,(void*)0},{&l_28,&l_28,&g_1309.f1,(void*)0},{&g_1309.f1,&g_1309.f1,&g_1309.f1,(void*)0},{&g_1309.f1,&g_159,(void*)0,&g_1309.f1}}};
            int32_t l_1855[4] = {0x3C02B7D1L,0x3C02B7D1L,0x3C02B7D1L,0x3C02B7D1L};
            int32_t *l_1923[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint8_t *l_1956 = &g_1305;
            uint32_t l_1993 = 1UL;
            int i, j, k;
lbl_2006:
            p_25.f2 = (l_1792 , (safe_rshift_func_int16_t_s_u(0x7F73L, (p_26 | 0x1D22L))));
            for (g_1309.f1 = 0; (g_1309.f1 >= 0); g_1309.f1 -= 1)
            { /* block id: 884 */
                uint16_t l_1796 = 0xF8F8L;
                int64_t *l_1829 = &g_159;
                uint32_t *l_1872[3][2][9] = {{{&g_163,&g_895.f1,&g_895.f1,(void*)0,&g_895.f1,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_59,&g_895.f1,&g_895.f1,&l_59,&l_59,&g_895.f1,&g_895.f1}},{{(void*)0,&g_895.f1,(void*)0,&g_895.f1,(void*)0,&g_895.f3,&l_59,(void*)0,&g_163},{(void*)0,(void*)0,&l_59,&g_895.f1,(void*)0,&g_895.f1,&l_59,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_59,&g_895.f1,&g_895.f1,&l_59,&l_59,&g_895.f1,&g_895.f1},{(void*)0,&g_895.f1,(void*)0,&g_895.f1,(void*)0,&g_895.f3,&l_59,(void*)0,&g_163}}};
                int32_t l_1873 = 0x1DB2BC57L;
                int8_t *l_1874 = &g_1207;
                int32_t **l_1875 = &l_1788;
                uint16_t l_1879 = 0xBA3BL;
                int16_t **l_1897[9][2][2] = {{{&l_62,&g_419},{&g_419,(void*)0}},{{&g_419,&g_419},{&l_62,&g_419}},{{&g_419,(void*)0},{&l_62,&l_62}},{{&l_62,&l_62},{&l_62,(void*)0}},{{&g_419,&g_419},{&l_62,&g_419}},{{&g_419,(void*)0},{&g_419,&g_419}},{{&l_62,&g_419},{&g_419,(void*)0}},{{&l_62,&l_62},{&l_62,&l_62}},{{&l_62,(void*)0},{&g_419,&g_419}}};
                uint8_t *l_1966 = &g_1305;
                int i, j, k;
                for (g_895.f3 = 0; (g_895.f3 <= 0); g_895.f3 += 1)
                { /* block id: 887 */
                    int32_t *l_1795[4][4][3] = {{{(void*)0,&g_314,&g_77},{&g_1309.f2,&l_1792,&g_80},{&g_1130.f2,&g_314,&g_314},{&g_314,(void*)0,&l_1792}},{{&g_80,&g_80,&g_314},{&g_80,&g_112[3],&g_1130.f2},{&g_314,&g_1309.f2,&g_1787.f2},{&g_1130.f2,&g_314,&g_314}},{{&g_1309.f2,&g_314,&g_1787.f2},{(void*)0,&g_80,&g_1130.f2},{&g_314,&g_314,&g_314},{(void*)0,&g_314,&l_1792}},{{&l_1792,&g_80,&g_314},{&g_314,&g_314,&g_80},{(void*)0,&g_314,&g_77},{&g_314,&g_1309.f2,&g_314}}};
                    union U1 *l_1799[9][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,&g_1806[1]},{&g_1803,&g_1801,&g_1801,&g_1803,&g_1801},{&g_1806[1],(void*)0,(void*)0,(void*)0,&g_1806[1]},{&g_1801,&g_1803,&g_1801,&g_1801,&g_1803},{&g_1806[1],(void*)0,(void*)0,(void*)0,(void*)0},{&g_1803,&g_1803,(void*)0,&g_1803,&g_1803},{(void*)0,(void*)0,(void*)0,(void*)0,&g_1806[1]},{&g_1803,&g_1801,&g_1801,&g_1803,&g_1801},{&g_1806[1],(void*)0,(void*)0,(void*)0,&g_1806[1]}};
                    union U1 **l_1807[8];
                    union U2 *l_1831 = &g_1832;
                    int i, j, k;
                    for (i = 0; i < 8; i++)
                        l_1807[i] = (void*)0;
                    l_1796++;
                    g_1289 = l_1799[0][0];
                    for (g_896.f1 = 0; (g_896.f1 <= 0); g_896.f1 += 1)
                    { /* block id: 892 */
                        union U0 l_1810 = {1L};
                        int64_t ***l_1813 = (void*)0;
                        int i, j, k;
                        (*l_1788) |= (&l_1788 == ((safe_lshift_func_uint8_t_u_u((0x3FB6L >= ((l_1813 = ((l_1810 , (g_134[g_1309.f1][g_896.f1][(g_1309.f1 + 3)] >= (l_1790 != ((((((safe_rshift_func_int16_t_s_s(0x31B0L, 2)) == 0x111BL) && ((void*)0 != &g_540)) , p_25.f2) && l_1810.f0) , (void*)0)))) , (void*)0)) == &g_551[3][4])), (*g_150))) , l_1814));
                        return l_28;
                    }
                    (*l_1788) = ((safe_rshift_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(0x26C3L, (&l_60[8][5][0] == (p_25.f0 , (*g_948))))) & ((p_25.f2 | (safe_rshift_func_int8_t_s_s((-3L), 0))) | ((((p_26 != (safe_mul_func_int16_t_s_s((g_1521 = (((safe_unary_minus_func_int8_t_s((safe_mul_func_uint16_t_u_u((((l_1828 = l_1827[1][2][3]) == l_1829) < p_25.f2), (-5L))))) , (*g_150)) != p_25.f0)), p_25.f0))) == 0x73L) || l_1796) != 0x4978L))), 7)) ^ g_896.f0);
                    for (g_908.f1 = 0; (g_908.f1 <= 0); g_908.f1 += 1)
                    { /* block id: 902 */
                        int8_t *l_1837 = (void*)0;
                        int8_t *l_1838 = (void*)0;
                        int8_t *l_1839 = &g_1207;
                        int i, j, k;
                        (*l_1788) = (5UL > (~0x9CD578F47D765B5BLL));
                        (*l_1788) = ((((((void*)0 != l_1831) > (g_134[(g_895.f3 + 1)][g_895.f3][(g_908.f1 + 1)] | ((*l_1839) |= (l_1796 != (safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_s(l_28, 6)), p_26)))))) || (safe_div_func_int8_t_s_s(((65526UL == (safe_div_func_int8_t_s_s((safe_add_func_uint8_t_u_u(((p_25 , (safe_mul_func_int16_t_s_s((g_61[g_895.f3][(g_1309.f1 + 4)][(g_1309.f1 + 5)] = (safe_lshift_func_int16_t_s_u((*g_103), 1))), 0UL))) & l_1850[2]), g_1230[4][1][3])), g_134[(g_895.f3 + 1)][g_895.f3][(g_908.f1 + 1)]))) , p_25.f2), (*l_1788)))) ^ 3UL) != g_374[1]);
                        if (p_25.f2)
                            break;
                    }
                }
                (*l_1788) = (safe_div_func_int16_t_s_s((*g_103), (safe_lshift_func_int8_t_s_s(((g_1290.f3 ^= l_1855[3]) , (safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s((5UL < (l_1792 = ((*l_1874) |= ((safe_sub_func_uint8_t_u_u(((*g_150) = (7UL >= ((safe_lshift_func_int8_t_s_s((((safe_mul_func_uint16_t_u_u(((p_26 , (l_1873 = ((safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int8_t_s_u(g_1869, 4)) > (safe_rshift_func_uint16_t_u_s(l_28, 12))))) < p_25.f2))) , p_25.f0), (-1L))) ^ 0x46L) , p_26), p_25.f0)) >= g_743))), p_26)) , (-4L))))), g_227.f2)), 12))), g_1802.f3))));
                (*l_1875) = l_1788;
                if ((((((g_1802.f3 = (((+(g_374[g_1309.f1] = (safe_add_func_uint64_t_u_u(18446744073709551608UL, (0x63L == l_1879))))) < (safe_div_func_uint64_t_u_u(0xE3D0DA4D031C846FLL, (safe_lshift_func_uint8_t_u_s(0x07L, (safe_mul_func_uint16_t_u_u((((safe_sub_func_int64_t_s_s((safe_sub_func_int64_t_s_s(((p_25 , l_1897[0][1][0]) != (void*)0), 0x7D864B2AF0899875LL)), p_25.f0)) != 18446744073709551615UL) || 0x8C76L), p_25.f0))))))) | p_26)) || 0xCFFE51A6L) != p_26) >= 0xA663L) < p_26))
                { /* block id: 923 */
                    int8_t l_1917 = (-1L);
                    uint64_t *l_1918[4] = {&g_227.f1,&g_227.f1,&g_227.f1,&g_227.f1};
                    int32_t l_1920[7][5] = {{(-3L),(-8L),0x139FF5E6L,0x8041BCC9L,0x8041BCC9L},{(-8L),(-3L),(-8L),0x139FF5E6L,0x8041BCC9L},{0L,(-8L),(-3L),(-8L),0x139FF5E6L},{0L,(-8L),(-1L),0x139FF5E6L,(-1L)},{(-1L),(-1L),(-3L),0x139FF5E6L,0x46EFA7B6L},{(-8L),0L,0L,(-8L),(-1L)},{(-8L),0x139FF5E6L,0x8041BCC9L,0x8041BCC9L,0x139FF5E6L}};
                    int i, j;
                    if ((safe_mod_func_int32_t_s_s((safe_add_func_int8_t_s_s((((*l_1874) ^= p_26) & ((((+(safe_mul_func_uint16_t_u_u(65535UL, p_25.f0))) != ((**l_1875) == (g_617[0].f1 = (l_1917 = (safe_div_func_int16_t_s_s(((p_25.f0 > ((((*g_150)++) != (l_28 != (((*l_1788) | (safe_lshift_func_int16_t_s_u(((safe_div_func_uint64_t_u_u(((safe_sub_func_int16_t_s_s((safe_add_func_uint8_t_u_u((p_25.f2 > 0UL), p_25.f2)), (*l_1788))) > 0xD9L), (**l_1875))) >= 0xCFF8B92F83D7791FLL), 0))) , p_25.f0))) && 1L)) != (*l_1788)), p_25.f2)))))) , &g_1504) != l_1919)), l_1920[6][2])), p_25.f0)))
                    { /* block id: 928 */
                        int32_t *l_1921 = (void*)0;
                        l_1921 = (void*)0;
                        return g_503;
                    }
                    else
                    { /* block id: 931 */
                        if (p_25.f0)
                            break;
                        return l_1922;
                    }
                }
                else
                { /* block id: 935 */
                    int64_t ****l_1933 = &g_1020;
                    const int32_t l_1936 = 4L;
                    int32_t l_1937 = 0x2CFBC97EL;
                    int32_t l_1938 = (-10L);
                    union U0 ***l_1957 = &g_1038;
                    for (p_26 = 0; (p_26 >= 0); p_26 -= 1)
                    { /* block id: 938 */
                        int16_t l_1929 = 0xF3E0L;
                        uint32_t *l_1930 = &g_1804.f3;
                        l_1923[8] = &g_112[3];
                        (*l_1788) |= (safe_mul_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u((*g_150), 7)), ((void*)0 != l_1928)));
                        l_1938 |= (((g_1102 < 3L) , (p_25.f2 && (((((l_1937 = (((*l_1874) &= 0x91L) & ((((((*l_1930)++) , l_1933) == (void*)0) >= ((*l_1788) != p_26)) < (safe_mod_func_uint16_t_u_u((l_1936 , p_26), (*l_1788)))))) & (*l_1788)) , l_1936) && 0xB8L) , (**l_1875)))) & g_1401[0].f0);
                        g_1801.f2 = ((((*g_150) = 0xE8L) && ((((safe_lshift_func_uint16_t_u_s((safe_mod_func_uint32_t_u_u((((*l_1788) |= p_26) != ((*l_1930) ^= (((safe_sub_func_int8_t_s_s((safe_mul_func_uint8_t_u_u(((*g_150) = ((((safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_s(((safe_lshift_func_int8_t_s_s((~(0x9D36L ^ ((g_374[3] > ((safe_mod_func_int64_t_s_s(((((void*)0 == l_1956) == ((l_1957 == l_1957) ^ 255UL)) , (*g_552)), (*g_552))) | 0xB520E1CE05C21E1FLL)) , (*g_447)))), 3)) >= (-5L)), l_1938)), l_1938)) != 5L) > l_1938) , (*g_150))), g_1521)), g_1190.f0)) ^ l_1929) & l_1929))), 4294967288UL)), 5)) , l_1936) ^ (-1L)) || (**l_1875))) , 0L);
                    }
                    (**l_1875) = 9L;
                }
                for (g_1102 = 0; (g_1102 <= 0); g_1102 += 1)
                { /* block id: 955 */
                    int16_t l_1958 = 0x862BL;
                    uint8_t **l_1965[10] = {&g_150,&g_150,&g_150,&g_150,&g_150,&g_150,&g_150,&g_150,&g_150,&g_150};
                    uint32_t *l_1973[10][7][3] = {{{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0}},{{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3}},{{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0}},{{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3}},{{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0}},{{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3}},{{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0}},{{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3}},{{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0}},{{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1802.f3,&g_1802.f3},{(void*)0,&g_1787.f3,(void*)0},{&g_1130.f3,&g_1130.f3,&g_1802.f3}}};
                    uint64_t l_1992 = 0x1B37F2D8B0CF4D2ELL;
                    int32_t l_1994 = 1L;
                    union U2 **l_2001 = &l_1996[2];
                    int i, j, k;
                    l_1958 &= (*l_1788);
                    l_1873 ^= (((*l_1788) &= ((*g_103) , (safe_mod_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(0x10L, ((((((*l_1956) = ((l_1966 = &g_134[1][0][2]) != l_1967[1])) , (*g_447)) > (255UL | 0xD1L)) | (safe_mod_func_int8_t_s_s((!p_25.f0), (safe_add_func_int32_t_s_s(1L, g_102))))) != (*g_447)))), (*g_150))) != p_26), (*g_103))))) , (-3L));
                    (*l_1788) ^= (((((void*)0 != l_1966) >= (((-1L) & p_25.f0) && (safe_mul_func_int16_t_s_s((safe_add_func_uint8_t_u_u(p_26, (safe_unary_minus_func_int32_t_s((p_26 >= (l_1995 , g_895.f0)))))), 9L)))) , p_25.f2) > l_1994);
                    (*l_2001) = l_1996[0];
                    for (g_1130.f1 = 0; (g_1130.f1 >= 0); g_1130.f1 -= 1)
                    { /* block id: 968 */
                        uint32_t l_2002 = 0x1C2DC653L;
                        ++l_2002;
                        (*l_1875) = l_2005;
                        return p_26;
                    }
                }
            }
            if (g_906.f0)
                goto lbl_2006;
        }
    }
    else
    { /* block id: 977 */
        uint32_t *l_2025 = &g_163;
        int32_t l_2028 = (-4L);
        union U1 ** const l_2045[3] = {(void*)0,(void*)0,(void*)0};
        int16_t ***l_2072 = &g_418;
        int16_t **** const l_2071[5] = {&l_2072,&l_2072,&l_2072,&l_2072,&l_2072};
        union U0 ***l_2083 = &g_1038;
        int32_t l_2120 = 0x060A7ADEL;
        int32_t l_2123[8];
        int64_t l_2127[3][3][8] = {{{0x66EA6E0DC59E6626LL,0x662C8DDBB9481920LL,(-1L),0xF4763EE86B0D10D0LL,0x1DF7688CC095DBCDLL,(-7L),8L,(-1L)},{0x174070912CF74662LL,0x662C8DDBB9481920LL,0x7F267FFE27445A1CLL,0xCA2FA3BCBAE1758CLL,0x7F267FFE27445A1CLL,0x662C8DDBB9481920LL,0x174070912CF74662LL,0x7B2B26049F1B8F4FLL},{0xBF72C7D1DE18522BLL,(-7L),0x7B2B26049F1B8F4FLL,0x662C8DDBB9481920LL,0xC91771634D173BF1LL,0x5692904DECBDB11FLL,(-1L),0xA11722D222F2E0A7LL}},{{0xA11722D222F2E0A7LL,(-1L),0xCA2FA3BCBAE1758CLL,0x1DF7688CC095DBCDLL,0xC91771634D173BF1LL,0xC91771634D173BF1LL,0x1DF7688CC095DBCDLL,0xCA2FA3BCBAE1758CLL},{0xBF72C7D1DE18522BLL,0xBF72C7D1DE18522BLL,(-7L),0xA11722D222F2E0A7LL,0x7F267FFE27445A1CLL,0x174070912CF74662LL,0xCA2FA3BCBAE1758CLL,(-1L)},{0x174070912CF74662LL,0x66EA6E0DC59E6626LL,0xBF72C7D1DE18522BLL,0x7F267FFE27445A1CLL,0x1DF7688CC095DBCDLL,(-1L),(-7L),(-1L)}},{{0x66EA6E0DC59E6626LL,0xA11722D222F2E0A7LL,0xC91771634D173BF1LL,0xA11722D222F2E0A7LL,0x66EA6E0DC59E6626LL,0xF4763EE86B0D10D0LL,(-7L),0xCA2FA3BCBAE1758CLL},{0xC91771634D173BF1LL,(-1L),(-1L),0x1DF7688CC095DBCDLL,8L,0x7F267FFE27445A1CLL,0x7B2B26049F1B8F4FLL,0xA11722D222F2E0A7LL},{0x7B2B26049F1B8F4FLL,(-7L),(-1L),0x662C8DDBB9481920LL,0x662C8DDBB9481920LL,(-1L),(-7L),0x7B2B26049F1B8F4FLL}}};
        const uint8_t *l_2138 = &g_743;
        const uint8_t * const *l_2137[9][5][5] = {{{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,&l_2138,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,&l_2138,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0}},{{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,(void*)0,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0}},{{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,(void*)0,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0}},{{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0},{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,(void*)0,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0}},{{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0},{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,(void*)0,&l_2138,&l_2138}},{{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0},{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138},{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138}},{{&l_2138,&l_2138,(void*)0,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0},{(void*)0,&l_2138,(void*)0,(void*)0,&l_2138}},{{(void*)0,&l_2138,&l_2138,(void*)0,&l_2138},{&l_2138,&l_2138,(void*)0,&l_2138,&l_2138},{&l_2138,(void*)0,&l_2138,&l_2138,(void*)0},{&l_2138,(void*)0,(void*)0,&l_2138,(void*)0},{(void*)0,(void*)0,&l_2138,(void*)0,(void*)0}}};
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2123[i] = 5L;
        for (g_159 = 0; g_159 < 3; g_159 += 1)
        {
            for (p_26 = 0; p_26 < 1; p_26 += 1)
            {
                for (g_227.f2 = 0; g_227.f2 < 9; g_227.f2 += 1)
                {
                    g_134[g_159][p_26][g_227.f2] = 249UL;
                }
            }
        }
        for (g_743 = 14; (g_743 == 25); ++g_743)
        { /* block id: 981 */
            int16_t l_2017 = 0x3D6BL;
            uint64_t *l_2019 = &g_374[1];
            uint64_t *l_2020 = &l_1995.f1;
            uint32_t **l_2026 = (void*)0;
            uint32_t **l_2027 = &l_2025;
            int16_t ***l_2044 = &g_418;
            int32_t l_2057 = 0xA15E5AEAL;
            uint64_t l_2058[1];
            union U0 *l_2105 = (void*)0;
            int32_t l_2118[1];
            int i;
            for (i = 0; i < 1; i++)
                l_2058[i] = 0xD1D75D09F2B5EB3BLL;
            for (i = 0; i < 1; i++)
                l_2118[i] = 9L;
            (*l_2005) = (((++(*g_150)) >= ((g_2029 &= (safe_mod_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u((l_2017 != ((*l_2020) = ((*l_2019) = (safe_unary_minus_func_int16_t_s(0L))))), l_2017)), ((****g_1381) = (safe_sub_func_int8_t_s_s((!((*g_111) &= (l_2017 >= (((!18446744073709551615UL) == p_25.f0) > (((g_80 & (((*l_2027) = l_2025) != &g_163)) < (*g_419)) != l_2028))))), (*l_2005)))))) ^ 0xEDL), p_25.f0))) , p_25.f0)) & 0UL);
            if (p_25.f0)
                break;
            for (g_1805.f1 = 2; (g_1805.f1 >= 0); g_1805.f1 -= 1)
            { /* block id: 993 */
                int64_t l_2030 = (-1L);
                uint32_t *l_2043 = &g_1309.f3;
                int32_t *l_2047 = &g_227.f2;
                int32_t *l_2048 = &g_1290.f2;
                int32_t *l_2049 = &l_2028;
                int32_t *l_2050 = (void*)0;
                int32_t *l_2051 = &g_1804.f2;
                int32_t *l_2052 = &g_1806[1].f2;
                int32_t *l_2053 = &g_1130.f2;
                int32_t *l_2054 = &g_1802.f2;
                int32_t *l_2055 = &g_1804.f2;
                int32_t *l_2056[7][3] = {{&g_1801.f2,&g_1782.f2,&g_1782.f2},{&g_1800.f2,&g_314,(void*)0},{&g_1801.f2,&g_1806[1].f2,&g_1801.f2},{&g_1804.f2,&g_1800.f2,(void*)0},{&g_77,&g_77,&g_1782.f2},{&g_1806[1].f2,&g_1800.f2,&g_1800.f2},{&g_1782.f2,&g_1806[1].f2,&g_1130.f2}};
                int64_t ***l_2082[8][1];
                const uint64_t l_2112 = 0x99974AE48FD3C9FELL;
                uint32_t l_2116 = 1UL;
                int i, j;
                for (i = 0; i < 8; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_2082[i][j] = &g_551[3][4];
                }
                g_2046[1] = ((((**g_446) &= l_2030) || (safe_add_func_int32_t_s_s((safe_mod_func_int8_t_s_s(((p_26 <= (((l_2030 < 1L) , (safe_sub_func_int16_t_s_s(((&g_1289 != (((((safe_rshift_func_int8_t_s_u((safe_mul_func_uint16_t_u_u(0x74C8L, (((((*l_2043) = ((void*)0 == (*g_948))) || ((l_2044 = &g_418) != (void*)0)) & 1UL) , 65526UL))), (*g_150))) != 0x8801L) < 0x50L) , l_2030) , l_2045[2])) ^ p_26), p_26))) > p_25.f0)) < 0x24L), (*g_150))), (***g_1503)))) , p_25.f0);
                ++l_2058[0];
                (*g_111) = (*l_2005);
                for (g_900.f1 = 0; (g_900.f1 <= 2); g_900.f1 += 1)
                { /* block id: 1002 */
                    int8_t *l_2084 = &g_248;
                    union U0 *l_2104 = &g_617[0];
                    int32_t l_2114 = 1L;
                    int32_t l_2121 = (-3L);
                    int32_t l_2122[1][8][2] = {{{0xBD081C78L,0x4F0F33E0L},{0L,0x4F0F33E0L},{0xBD081C78L,0x4F0F33E0L},{0L,0x4F0F33E0L},{0xBD081C78L,0x4F0F33E0L},{0L,0x4F0F33E0L},{0xBD081C78L,0x4F0F33E0L},{0L,0x4F0F33E0L}}};
                    int i, j, k;
                    if ((safe_lshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s((safe_div_func_int8_t_s_s((((safe_sub_func_int64_t_s_s(((safe_div_func_uint8_t_u_u(((((*g_1035) = (**g_1038)) , &l_2044) == l_2071[4]), ((*l_2084) &= (safe_lshift_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s(g_1230[(g_1805.f1 + 2)][g_900.f1][g_1805.f1], 65529UL)) , (((*l_2051) |= (safe_lshift_func_int8_t_s_s((((safe_rshift_func_uint16_t_u_s((((~l_2058[0]) , l_2082[6][0]) != (void*)0), 4)) ^ ((l_2083 != &g_1034) & p_26)) || (**g_446)), p_26))) ^ (**g_446))), 10))))) >= (*l_2053)), l_2028)) , (**g_418)) < l_2017), 0xB2L)), (*g_150))), (*g_103))))
                    { /* block id: 1006 */
                        int32_t l_2085 = 1L;
                        return l_2085;
                    }
                    else
                    { /* block id: 1008 */
                        uint16_t *l_2113 = &g_1354;
                        uint16_t l_2115[7];
                        int32_t l_2117 = 0x8267CE4BL;
                        int32_t l_2119 = 0L;
                        int32_t l_2124[4];
                        int32_t l_2133[10][4][5] = {{{0x94E7DE8BL,0x55C17F11L,0x0F75333AL,4L,8L},{4L,(-8L),1L,0x19AA3917L,9L},{0x6AA9DED0L,5L,0L,0x535B558FL,(-1L)},{(-3L),9L,1L,(-8L),(-3L)}},{{0L,0x55C17F11L,0x6E4880DAL,(-2L),0x94E7DE8BL},{(-3L),(-1L),(-1L),(-3L),0x19AA3917L},{0x6AA9DED0L,4L,(-1L),0x55C17F11L,0xBB4C7A60L},{4L,(-3L),0x610A89D0L,1L,(-3L)}},{{0x94E7DE8BL,5L,0xE8D1006BL,0x55C17F11L,0xE8D1006BL},{(-1L),0x5837730DL,1L,(-3L),9L},{0L,0x535B558FL,(-1L),(-2L),0x6AA9DED0L},{9L,0x7096D4FAL,0x610A89D0L,(-8L),0x19AA3917L}},{{(-1L),0x535B558FL,0x0F75333AL,0x535B558FL,(-1L)},{4L,0x5837730DL,(-1L),0x19AA3917L,(-1L)},{0xFA1450B2L,5L,1L,4L,(-1L)},{9L,(-3L),1L,0x5837730DL,(-1L)}},{{0L,4L,0L,(-2L),(-1L)},{(-1L),(-1L),1L,(-1L),0x19AA3917L},{0xBB4C7A60L,0x55C17F11L,(-1L),4L,0x6AA9DED0L},{4L,9L,1L,1L,9L}},{{8L,5L,0L,0x535B558FL,0xE8D1006BL},{(-3L),(-8L),1L,9L,(-3L)},{0L,0x55C17F11L,1L,(-2L),0xBB4C7A60L},{(-3L),0x7096D4FAL,(-1L),1L,0x19AA3917L}},{{8L,4L,0x0F75333AL,0x55C17F11L,0x94E7DE8BL},{4L,1L,0x610A89D0L,0x19AA3917L,(-3L)},{0xBB4C7A60L,5L,(-1L),0x55C17F11L,(-1L)},{(-1L),(-1L),1L,1L,9L}},{{0L,0x535B558FL,0xE8D1006BL,(-2L),8L},{9L,(-1L),0x610A89D0L,9L,0x19AA3917L},{0xFA1450B2L,0x535B558FL,(-1L),0x535B558FL,0xFA1450B2L},{4L,(-1L),(-1L),1L,(-1L)}},{{(-1L),5L,0x6E4880DAL,4L,0xE8D1006BL},{9L,1L,1L,(-1L),(-1L)},{0L,4L,0L,(-2L),0xFA1450B2L},{(-1L),0x7096D4FAL,0xF66872AAL,0x610A89D0L,0x87CB8375L}},{{0L,(-3L),0x94E7DE8BL,5L,0xE8D1006BL},{0L,1L,0xF66872AAL,0x87CB8375L,0x19AA3917L},{(-1L),0xF8CF8B38L,0L,(-2L),0xAD1EE977L},{0x7096D4FAL,0x19AA3917L,0x5837730DL,1L,0x7096D4FAL}}};
                        int i, j, k;
                        for (i = 0; i < 7; i++)
                            l_2115[i] = 1UL;
                        for (i = 0; i < 4; i++)
                            l_2124[i] = 1L;
                        (*l_2051) = (safe_unary_minus_func_uint64_t_u(l_2017));
                        (***g_1503) ^= ((0xEF483EDAL | (safe_unary_minus_func_uint8_t_u(((((((safe_add_func_uint64_t_u_u(0UL, 0xFF842C1B6A933A9BLL)) ^ (safe_div_func_int16_t_s_s(((~(safe_mul_func_uint8_t_u_u(((l_2114 |= (safe_unary_minus_func_int8_t_s(((((((*l_2113) ^= ((((safe_sub_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(((*l_2020)--), ((safe_sub_func_int64_t_s_s((((((*l_2005) = ((**l_2083) == (l_2105 = l_2104))) , ((safe_add_func_uint64_t_u_u(((*g_103) < ((void*)0 != l_2025)), (((safe_add_func_int16_t_s_s(((-10L) & l_2112), (*g_419))) < (*l_2005)) , g_1801.f3))) != g_903.f0)) ^ 4294967288UL) && l_2017), g_902.f0)) < g_1230[(g_1805.f1 + 2)][g_900.f1][g_1805.f1]))), l_2058[0])) || 0xFAL) || p_26) , (***g_1382))) , p_26) && g_163) & p_26) <= 0x3F3DL)))) < l_2058[0]), l_2028))) , l_2115[2]), (*g_419)))) >= p_25.f0) | l_2116) && p_26) & l_2058[0])))) || 0x20ED993CL);
                        --l_2134;
                    }
                    (***g_1503) ^= (((void*)0 != l_2137[3][3][1]) && 6UL);
                }
            }
        }
    }
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_102 g_314 g_552 g_159 g_617 g_61 g_276 g_418 g_419 g_80 g_103 g_104 g_885 g_892.f0 g_112 g_447 g_268 g_948 g_150 g_151 g_955 g_905.f0 g_899.f0 g_540 g_503 g_227 g_992 g_843 g_248 g_898.f0 g_904.f0 g_1034 g_374 g_1020 g_551 g_906.f0 g_903.f0 g_907.f0 g_227.f2 g_1102 g_898.f1 g_163 g_1035 g_897.f3 g_1190.f1 g_1207 g_77 g_949 g_1230 g_617.f0 g_1190.f3 g_296 g_896.f0 g_1273 g_900.f0 g_1130.f3 g_8 g_908.f0 g_1289 g_743 g_1305 g_134 g_1309.f3 g_1354 g_1290.f2 g_1761 g_1309.f2
 * writes: g_503 g_112 g_885 g_111 g_227.f2 g_540 g_159 g_955 g_268 g_617.f2 g_1020 g_151 g_1038 g_551 g_419 g_1102 g_80 g_898.f1 g_276 g_134 g_227.f1 g_897.f3 g_1190.f1 g_248 g_77 g_1230 g_1190.f3 g_1130.f3 g_1273 g_61 g_843 g_1290.f1 g_1035 g_1289 g_296
 */
static uint32_t  func_35(const uint16_t  p_36, int32_t  p_37, int16_t  p_38)
{ /* block id: 431 */
    int64_t l_867 = 6L;
    uint32_t l_868 = 8UL;
    uint16_t ***l_871[10] = {&g_446,&g_446,&g_446,&g_446,&g_446,&g_446,&g_446,&g_446,&g_446,&g_446};
    int64_t **l_927 = &g_552;
    int32_t l_957 = 0x4DFB9F33L;
    union U0 l_971[2] = {{-8L},{-8L}};
    int32_t *l_977 = &l_957;
    uint16_t l_1014 = 0UL;
    const int8_t *l_1048 = &g_248;
    uint32_t l_1061 = 18446744073709551612UL;
    int32_t l_1070 = 0xFF6F0263L;
    uint32_t l_1072 = 9UL;
    int32_t l_1119 = (-8L);
    uint16_t l_1137[8];
    int32_t l_1145 = (-9L);
    int32_t l_1146 = 0x8281AFD2L;
    int32_t l_1147 = 0x0506B8ADL;
    uint32_t l_1295 = 4294967288UL;
    union U1 * const l_1308 = &g_1309;
    union U2 *l_1400 = &g_1401[0];
    int32_t l_1427 = 0x16FBA905L;
    int32_t l_1428 = 0x771FF2D0L;
    int32_t l_1429 = (-7L);
    int32_t l_1434[6];
    uint32_t l_1441 = 0xDB28D366L;
    uint32_t l_1457 = 0xCFC9E7F4L;
    int32_t **l_1460 = &l_977;
    int32_t ***l_1459 = &l_1460;
    int16_t l_1493 = 0xCC56L;
    int32_t l_1596 = 6L;
    int64_t l_1623 = 0x260DC1116AFA219CLL;
    union U0 * const l_1779 = &l_971[1];
    int i;
    for (i = 0; i < 8; i++)
        l_1137[i] = 0x33CCL;
    for (i = 0; i < 6; i++)
        l_1434[i] = (-1L);
    if (g_102)
    { /* block id: 432 */
        int16_t *l_847 = (void*)0;
        union U0 l_856 = {0x0EB2D094L};
        int64_t **l_926 = (void*)0;
        int32_t l_980[6][4] = {{(-1L),0x67BE83D4L,(-1L),0xC91EADACL},{0x275FA5E3L,0x67BE83D4L,0x2D0609A9L,0x67BE83D4L},{0x275FA5E3L,0xC91EADACL,(-1L),0x67BE83D4L},{(-1L),0x67BE83D4L,(-1L),0xC91EADACL},{0x275FA5E3L,0x67BE83D4L,0x2D0609A9L,0x67BE83D4L},{0x275FA5E3L,0xC91EADACL,(-1L),0x67BE83D4L}};
        int32_t *l_1016 = (void*)0;
        uint64_t l_1113 = 1UL;
        union U1 *l_1129 = &g_1130;
        const uint64_t l_1151[9] = {18446744073709551614UL,0xA17446807325D34DLL,18446744073709551614UL,0xA17446807325D34DLL,18446744073709551614UL,0xA17446807325D34DLL,18446744073709551614UL,0xA17446807325D34DLL,18446744073709551614UL};
        union U2 *l_1189 = &g_1190;
        int32_t l_1199 = 0x92ACCBEFL;
        uint32_t l_1204 = 0xCC77ED86L;
        int i, j;
        if (g_314)
        { /* block id: 433 */
            union U0 *l_857[5][1] = {{&g_227},{&g_617[0]},{&g_227},{&g_617[0]},{&g_227}};
            int32_t l_866 = 0xB089B703L;
            int8_t *l_869 = &g_503;
            int16_t l_870 = 4L;
            int32_t *l_872 = &g_112[2];
            int16_t ***l_939 = (void*)0;
            int32_t l_963 = 0xAE73DB6AL;
            uint32_t l_964 = 1UL;
            int32_t l_981 = 0L;
            uint8_t l_983 = 0x4CL;
            int16_t l_1069 = 0x9EC2L;
            int32_t *l_1116 = &l_980[0][1];
            int32_t *l_1117 = &l_971[0].f2;
            int32_t *l_1118[5][7][7] = {{{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8}},{{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_957,&g_8,&l_1070,&l_957,&l_957,&l_1070,&g_8},{&l_866,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2}},{{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0}},{{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2},{&g_2,(void*)0,&l_957,&l_957,&l_957,&l_957,(void*)0},{&l_981,&g_227.f2,(void*)0,&l_866,&l_866,(void*)0,&g_227.f2}}};
            uint16_t l_1120[5][10][3] = {{{65535UL,65535UL,0x8119L},{6UL,0xDF0FL,0x7EFDL},{65527UL,0x15C5L,0x650AL},{65532UL,65535UL,0xDF0FL},{0x650AL,65527UL,0x650AL},{65530UL,0xA2A6L,0x7EFDL},{0x9E72L,0xF3BBL,0x8119L},{65535UL,6UL,0UL},{3UL,0xABDCL,0xABDCL},{65535UL,65533UL,65532UL}},{{0x9E72L,0x5FCAL,65535UL},{65530UL,65532UL,65535UL},{0x650AL,0x8119L,0x8CBDL},{65532UL,65532UL,0xA6D2L},{65527UL,0x5FCAL,65531UL},{6UL,65533UL,0xE639L},{65535UL,0xABDCL,0x5FCAL},{0xE639L,6UL,0xE639L},{0x7FC1L,0xF3BBL,65531UL},{0xD7E8L,0xA2A6L,0xA6D2L}},{{0xABDCL,65527UL,0x8CBDL},{65532UL,65535UL,65535UL},{3UL,65531UL,0x8119L},{0xE639L,65535UL,0xA6D2L},{0xF3BBL,0x8119L,3UL},{0xDF0FL,6UL,0xD7E8L},{0x8119L,0x8119L,65527UL},{65530UL,65535UL,0UL},{0x7FC1L,65531UL,0x5FCAL},{0xA6D2L,65535UL,65535UL}},{{0x5FCAL,0x7FC1L,0x5FCAL},{0xA2A6L,65533UL,0UL},{0x650AL,0x15C5L,65527UL},{65535UL,65530UL,0xD7E8L},{65535UL,3UL,3UL},{65535UL,0x7EFDL,0xA6D2L},{0x650AL,0xABDCL,0x8119L},{0xA2A6L,0xA6D2L,65535UL},{0x5FCAL,65527UL,0x9E72L},{0xA6D2L,0xA6D2L,6UL}},{{0x7FC1L,0xABDCL,0x8CBDL},{65530UL,0x7EFDL,0xDF0FL},{0x8119L,3UL,0xABDCL},{0xDF0FL,65530UL,0xDF0FL},{0xF3BBL,0x15C5L,0x8CBDL},{0xE639L,65533UL,6UL},{3UL,0x7FC1L,0x9E72L},{65532UL,65535UL,65535UL},{3UL,65531UL,0x8119L},{0xE639L,65535UL,0xA6D2L}}};
            int32_t l_1143 = (-1L);
            int i, j, k;
            if (((*l_872) = ((((l_847 == (((safe_mod_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((((safe_lshift_func_int8_t_s_u(((*l_869) = ((*g_552) == ((safe_div_func_int64_t_s_s(((((l_856 = g_617[0]) , (l_856 = l_856)) , p_36) || (((g_61[0][1][3] , ((safe_sub_func_int16_t_s_s((safe_mul_func_int8_t_s_s(g_276[3][2], (safe_lshift_func_uint16_t_u_s((((safe_div_func_uint64_t_u_u((((((((1UL | 0x3035L) < l_856.f0) | p_36) <= l_866) , g_61[0][4][2]) , 0xAC9A9211L) && l_866), p_38)) , p_37) , l_867), (**g_418))))), p_37)) <= 0UL)) >= g_80) < l_867)), l_868)) & l_868))), 3)) == 18446744073709551615UL) <= p_36), (*g_419))) | 0x67L), l_866)) , 18446744073709551615UL) , &p_38)) , l_870) , l_871[7]) != &g_446)))
            { /* block id: 438 */
                uint16_t *l_883[10];
                int32_t l_910 = 0L;
                union U0 l_933[5][6] = {{{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}},{{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}},{{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}},{{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}},{{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}}};
                int32_t l_961 = 1L;
                int32_t l_962 = 0x01A13C69L;
                int64_t ***l_1019 = &g_551[3][4];
                int32_t l_1071 = 0xBF405A4AL;
                int16_t * const *l_1085 = &g_419;
                int16_t * const **l_1084 = &l_1085;
                int i, j;
                for (i = 0; i < 10; i++)
                    l_883[i] = &g_268;
                if ((safe_rshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((p_37 == (0x7553D709L && ((safe_sub_func_int16_t_s_s(l_868, 0xAE8CL)) || (-1L)))) | ((&p_36 != (l_883[4] = l_883[3])) >= g_159)), l_868)) , (*g_103)), (*g_419))), p_38)))
                { /* block id: 440 */
                    int16_t l_884 = 0x39B7L;
                    const volatile union U2 **l_887 = &g_885;
                    int8_t **l_889 = &l_869;
                    union U2 * const l_891[2][4][9] = {{{&g_896,&g_899,&g_904[5][0],&g_893[6][0],&g_898,&g_906,&g_897,&g_906,&g_898},{(void*)0,&g_897,&g_897,(void*)0,&g_899,&g_902,&g_906,&g_894[3][4],&g_898},{&g_894[3][4],&g_905[0][0],&g_900,&g_897,&g_895,&g_893[6][0],&g_892,&g_892,&g_893[6][0]},{&g_899,&g_907[2],(void*)0,&g_907[2],&g_899,&g_894[3][4],&g_905[0][0],&g_900,&g_897}},{{&g_899,&g_902,&g_906,&g_894[3][4],&g_898,&g_905[0][0],(void*)0,&g_903,(void*)0},{&g_894[3][4],&g_892,&g_908,&g_908,&g_892,&g_894[3][4],&g_896,&g_899,&g_904[5][0]},{(void*)0,&g_892,&g_903,&g_898,(void*)0,&g_893[6][0],&g_908,&g_907[2],&g_907[2]},{&g_896,&g_902,&g_893[6][0],&g_900,&g_893[6][0],&g_902,&g_896,&g_908,&g_903}}};
                    union U2 * const *l_890 = &l_891[0][1][2];
                    int32_t l_954 = 0x30E1690BL;
                    int32_t l_956 = 0xB0769E0DL;
                    int8_t l_959[6] = {9L,9L,9L,9L,9L,9L};
                    uint32_t *l_967 = (void*)0;
                    uint32_t *l_968 = &g_540;
                    int32_t *l_975 = &l_957;
                    int32_t l_978 = 0x6F3E1431L;
                    int32_t l_979 = (-1L);
                    int32_t l_982 = 0x4D96B137L;
                    const int64_t **l_1006 = (void*)0;
                    int i, j, k;
                    (*l_872) = l_884;
                    if (l_870)
                        goto lbl_888;
lbl_888:
                    (*l_887) = g_885;
                    if (((g_617[0] , &g_503) == ((*l_889) = ((p_37 <= ((void*)0 == &g_447)) , l_869))))
                    { /* block id: 445 */
                        union U2 * const **l_909 = &l_890;
                        l_910 |= (((*l_909) = l_890) == &l_891[0][1][2]);
                        g_111 = &g_112[4];
                    }
                    else
                    { /* block id: 449 */
                        int16_t l_932 = 1L;
                        uint32_t *l_934 = &g_540;
                        int16_t ****l_940 = (void*)0;
                        int16_t ****l_941 = &l_939;
                        int32_t *l_958 = &l_856.f2;
                        int32_t *l_960[5][6][6] = {{{&l_956,&l_956,&l_956,&l_956,(void*)0,&l_910},{(void*)0,&l_856.f2,(void*)0,&l_910,&g_112[3],&g_77},{&g_112[3],(void*)0,&l_866,(void*)0,&g_112[3],&g_314},{&g_77,&l_856.f2,&g_112[8],&l_856.f2,(void*)0,(void*)0},{(void*)0,&l_956,&l_856.f2,&l_856.f2,&l_956,(void*)0},{&l_856.f2,&l_910,&g_112[8],&g_112[3],(void*)0,&g_314}},{{&l_956,&g_77,&l_866,(void*)0,&l_866,&g_77},{&l_956,&g_314,(void*)0,&g_112[3],&g_112[8],&l_910},{&l_856.f2,(void*)0,&l_956,&l_856.f2,&l_856.f2,&l_956},{(void*)0,(void*)0,(void*)0,&l_856.f2,&g_112[8],&l_856.f2},{&g_77,&g_314,&g_112[3],(void*)0,&l_866,(void*)0},{&g_112[3],&g_77,&g_112[3],&l_910,(void*)0,&l_856.f2}},{{(void*)0,&l_910,(void*)0,&l_956,&l_956,&l_956},{&l_956,&l_956,&l_956,&l_956,(void*)0,&l_910},{(void*)0,&l_856.f2,(void*)0,&l_910,&g_112[3],&g_77},{&g_112[3],(void*)0,&l_866,(void*)0,&g_112[3],&g_314},{&g_77,&l_856.f2,&g_112[8],&l_856.f2,(void*)0,(void*)0},{(void*)0,&l_956,&l_856.f2,&l_856.f2,&l_956,(void*)0}},{{&l_856.f2,&l_910,&g_112[8],&g_112[3],(void*)0,&g_314},{&l_956,&g_77,&l_866,(void*)0,&l_866,&g_77},{&l_956,&g_314,(void*)0,&g_112[3],&g_112[8],&l_910},{&l_856.f2,(void*)0,&l_956,&l_856.f2,&l_856.f2,&l_956},{(void*)0,(void*)0,(void*)0,&l_856.f2,&g_112[8],&l_856.f2},{&g_77,&g_314,&g_112[3],(void*)0,&l_866,(void*)0}},{{&g_112[3],&g_77,&g_112[3],&l_910,(void*)0,&l_856.f2},{(void*)0,&l_910,(void*)0,&l_956,&l_956,&l_956},{&l_956,&l_956,&l_956,&l_956,(void*)0,&l_910},{(void*)0,&l_856.f2,(void*)0,&l_910,&g_112[3],&g_77},{&g_112[3],(void*)0,&l_866,(void*)0,&g_112[3],&g_314},{&g_77,&l_856.f2,&g_112[8],&l_856.f2,(void*)0,(void*)0}}};
                        int i, j, k;
                        (*l_872) = (0L | (safe_div_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(g_892.f0, (safe_unary_minus_func_int32_t_s((safe_mul_func_uint8_t_u_u((((((*l_934) = (safe_mod_func_int32_t_s_s((g_227.f2 = (safe_div_func_uint64_t_u_u((safe_lshift_func_int8_t_s_u(((((void*)0 != &p_36) || ((l_926 != l_927) == ((18446744073709551607UL != (((l_933[3][1] , l_867) ^ (*g_552)) && 0x33L)) > l_884))) != (-1L)), 7)), l_933[3][1].f0))), l_856.f0))) & (*l_872)) > 0x7712L) & p_38), p_37)))))), p_36)));
                        l_957 |= (safe_mod_func_uint32_t_u_u(((((*l_941) = l_939) != (void*)0) < ((l_956 = ((*g_447) <= (safe_mul_func_uint16_t_u_u((l_856.f2 = (safe_div_func_int8_t_s_s(((safe_mul_func_int8_t_s_s(((*l_869) = l_932), ((((void*)0 != g_948) && (((l_933[3][1].f0 = ((g_955 ^= (safe_add_func_int64_t_s_s((((safe_add_func_int64_t_s_s(((-10L) & g_276[2][0]), (l_954 = ((**l_927) = 1L)))) >= (*g_150)) && (-9L)), l_856.f0))) && (*g_447))) > g_61[0][0][6]) ^ p_36)) || l_932))) & g_80), p_36))), l_884)))) != g_905[0][0].f0)), 0xE1A1CB10L));
                        l_964--;
                    }
                    if (((*l_975) &= (((l_956 = (g_899.f0 < ((*l_968)--))) && (l_971[0] , (safe_mod_func_int64_t_s_s(((**l_927) = ((*l_872) = (0x32FF62E9A8C1D677LL <= l_856.f0))), (~p_37))))) < (*g_150))))
                    { /* block id: 470 */
                        int32_t **l_976[8] = {&l_872,&l_872,&g_111,&l_872,&l_872,&g_111,&l_872,&l_872};
                        int8_t *l_1013[3];
                        uint64_t l_1015 = 0x122DEEF94759D2D4LL;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1013[i] = &l_959[4];
                        l_977 = &l_957;
                        l_983--;
                        g_617[0].f2 = (safe_sub_func_int16_t_s_s((((((**l_927) ^= (g_617[0] , (g_503 != (p_36 || ((safe_lshift_func_uint8_t_u_s(((safe_div_func_int64_t_s_s((((g_227 , g_992) || (safe_unary_minus_func_uint16_t_u(((safe_div_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((!((safe_add_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(((((safe_sub_func_uint8_t_u_u(((l_1006 != (((((*l_975) = ((safe_lshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_u(((*g_447)--), ((*l_975) | g_843))), (((l_933[3][1].f2 = p_37) <= g_248) | g_898.f0))) & (-1L))) < p_37) && p_37) , &g_552)) < l_910), p_38)) & l_856.f0) | p_37) != l_868))), p_36)) && p_38)), (**g_418))) >= l_856.f0), p_36)), (*l_872))) && 1UL)))) , 0x435641E9EC85D8F8LL), g_904[5][0].f0)) != l_1014), 0)) >= 0x768BL))))) < 0L) ^ l_1015) <= 255UL), l_980[3][2]));
                    }
                    else
                    { /* block id: 478 */
                        l_1016 = (void*)0;
                        return p_37;
                    }
                }
                else
                { /* block id: 482 */
                    uint64_t l_1028 = 5UL;
                    int32_t l_1030 = 0L;
                    int16_t *l_1060 = (void*)0;
                    int32_t l_1067 = (-1L);
                    int32_t l_1068[7][4][5] = {{{0x9110CFDEL,0L,0x1DA23EA4L,0x173593BFL,0x29B68FAEL},{0x29B68FAEL,(-3L),(-3L),0x8A6E96A3L,0L},{0x49A9F16DL,0xA8C2A913L,0x8A6E96A3L,0x1DA23EA4L,0L},{(-3L),0x29B68FAEL,0xA8C2A913L,(-8L),0x99BC6854L}},{{0xCFDD3AEBL,0x29B68FAEL,1L,0x29B68FAEL,0xCFDD3AEBL},{0xE58CE00EL,0xA8C2A913L,0L,(-1L),(-3L)},{0x9E7E38BCL,(-3L),0x0CE31476L,0L,2L},{0x8A6E96A3L,0L,2L,0xA8C2A913L,(-3L)}},{{6L,0L,(-8L),0xAE8F4390L,0xCFDD3AEBL},{(-3L),0xCFDD3AEBL,1L,0x0CE31476L,0x99BC6854L},{0L,0L,1L,1L,0L},{0x173593BFL,0x9110CFDEL,(-8L),0L,0L}},{{0L,0L,2L,0x99BC6854L,0x29B68FAEL},{0L,2L,0x0CE31476L,0x9E7E38BCL,0xE58CE00EL},{0L,0xAE8F4390L,0L,0x9110CFDEL,2L},{0x173593BFL,0x49A9F16DL,1L,0xB438BDC7L,(-1L)}},{{0L,(-3L),0xA8C2A913L,0xB438BDC7L,0xA8C2A913L},{(-3L),(-3L),0x8A6E96A3L,0x9110CFDEL,0xB438BDC7L},{6L,(-8L),(-3L),0x9E7E38BCL,0x173593BFL},{0x8A6E96A3L,0xB438BDC7L,0x1DA23EA4L,0x99BC6854L,(-1L)}},{{0x9E7E38BCL,(-8L),0x49A9F16DL,0L,6L},{0xE58CE00EL,(-3L),0xCFDD3AEBL,1L,0x0CE31476L},{0xCFDD3AEBL,(-3L),0xB438BDC7L,0x0CE31476L,0x0CE31476L},{(-3L),0x49A9F16DL,(-3L),0xAE8F4390L,6L}},{{0x49A9F16DL,0xAE8F4390L,0x173593BFL,0xA8C2A913L,(-1L)},{0x29B68FAEL,2L,(-1L),0L,0x173593BFL},{0x9110CFDEL,0L,0x173593BFL,(-1L),0xB438BDC7L},{1L,0x9110CFDEL,(-3L),0x29B68FAEL,0xA8C2A913L}}};
                    int i, j, k;
                    if (p_36)
                    { /* block id: 483 */
                        uint64_t *l_1029[9];
                        int32_t *l_1031 = &l_910;
                        union U0 **l_1037 = &g_1035;
                        union U0 ***l_1036[3];
                        uint32_t *l_1049 = (void*)0;
                        int16_t **l_1059 = &l_847;
                        int32_t *l_1062 = &l_971[0].f2;
                        int32_t *l_1063 = (void*)0;
                        int32_t *l_1064 = (void*)0;
                        int32_t *l_1065 = &l_933[3][1].f2;
                        int32_t *l_1066[8];
                        int i;
                        for (i = 0; i < 9; i++)
                            l_1029[i] = (void*)0;
                        for (i = 0; i < 3; i++)
                            l_1036[i] = &l_1037;
                        for (i = 0; i < 8; i++)
                            l_1066[i] = &g_80;
                        (*l_1031) |= (safe_mod_func_uint16_t_u_u(((&g_551[3][4] != (p_38 , (g_1020 = l_1019))) > (+(safe_div_func_int64_t_s_s(((l_1030 = (safe_lshift_func_int8_t_s_u((safe_mod_func_uint8_t_u_u(247UL, p_36)), ((*g_150) = (l_1028 >= (((*l_872) = (p_37 >= p_38)) < (*l_977))))))) , 0xF17CE9BBAC223709LL), p_36)))), 1UL));
                        (*l_977) = (((g_540 = ((safe_add_func_int64_t_s_s((p_37 || 3UL), 0x70D0503CA0E6915FLL)) , ((g_1034 == (g_1038 = &g_1035)) >= ((*g_447) |= (0x562051FDL != (safe_add_func_int32_t_s_s((safe_sub_func_uint64_t_u_u((((safe_sub_func_uint64_t_u_u(g_374[1], (safe_rshift_func_int16_t_s_s((!(((*l_872) = (((**g_418) , ((l_1048 == &g_248) , (*g_103))) | 1L)) <= p_38)), p_37)))) < l_933[3][1].f0) >= 0x170DL), g_955)), p_37))))))) > p_38) || (*l_872));
                        (*l_977) ^= (safe_div_func_uint64_t_u_u(((((((!((((safe_lshift_func_int8_t_s_u(((p_37 && ((**l_927) = 1L)) & (safe_mod_func_uint8_t_u_u(((*g_150) = ((*l_1031) && (l_1028 < (safe_add_func_uint8_t_u_u((l_926 == ((*g_1020) = (*g_1020))), ((*l_872) = (((*l_1059) = ((*g_418) = (void*)0)) == l_1060))))))), g_906.f0))), g_903.f0)) == l_961) >= 0x417EL) && (*l_1031))) & g_992) | p_36) <= l_1061) , l_1060) != &p_36), p_38));
                        l_1072--;
                    }
                    else
                    { /* block id: 502 */
                        uint8_t *l_1081 = &l_983;
                        uint16_t *l_1082 = (void*)0;
                        uint64_t *l_1083 = &g_227.f1;
                        (*l_977) |= ((safe_sub_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u(((*l_1081) = (++(*g_150))), 4)), (l_1030 ^= ((&p_36 == (l_1082 = &g_268)) , g_907[2].f0)))) && (((void*)0 != l_1084) & (safe_sub_func_int16_t_s_s(((void*)0 == &l_939), ((((void*)0 != &g_111) < 0x537F5D96L) | l_933[3][1].f0)))));
                    }
                }
                return g_227.f2;
            }
            else
            { /* block id: 511 */
                const uint16_t l_1103 = 0x4941L;
                (*l_872) = (safe_sub_func_uint16_t_u_u((((safe_rshift_func_uint8_t_u_s(0xACL, 0)) || ((safe_add_func_int8_t_s_s(((*l_869) = (safe_div_func_uint16_t_u_u(p_38, ((safe_add_func_int32_t_s_s((safe_add_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((g_1102 ^= (*g_447)), l_1103)), (safe_add_func_int8_t_s_s(((void*)0 != &g_268), l_1103)))), (((safe_div_func_uint32_t_u_u(p_38, (++g_540))) | ((safe_add_func_int16_t_s_s(((!(*l_872)) > l_1113), 0x5E02L)) , l_1103)) > 18446744073709551608UL))) , 0xEF2FL)))), (-10L))) ^ (*l_977))) & p_36), 0x8A1DL));
            }
            for (l_957 = 0; (l_957 < 22); l_957 = safe_add_func_uint8_t_u_u(l_957, 6))
            { /* block id: 519 */
                for (g_268 = 2; (g_268 <= 8); g_268 += 1)
                { /* block id: 522 */
                    int i;
                    return g_112[g_268];
                }
                for (l_870 = 3; (l_870 >= 0); l_870 -= 1)
                { /* block id: 527 */
                    int i, j;
                    return l_980[(l_870 + 2)][l_870];
                }
            }
            l_1120[4][7][2]--;
            for (g_159 = 0; (g_159 <= 0); g_159 += 1)
            { /* block id: 534 */
                const int64_t *l_1125 = &g_159;
                const int64_t **l_1124 = &l_1125;
                const int64_t ***l_1123 = &l_1124;
                int64_t ****l_1126 = &g_1020;
                int64_t ***l_1128 = &g_551[2][0];
                int64_t ****l_1127 = &l_1128;
                union U1 **l_1131 = &l_1129;
                int32_t l_1132 = 0L;
                int32_t l_1133 = 0x396B074DL;
                int32_t l_1134 = 2L;
                int32_t l_1135 = 0x83841314L;
                int32_t l_1136[9] = {7L,0x17705A81L,0x17705A81L,7L,0x17705A81L,0x17705A81L,7L,0x17705A81L,0x17705A81L};
                int i;
                (*l_1117) = ((*l_1116) |= (l_1123 == ((*l_1127) = ((*l_1126) = &l_926))));
                (*l_1131) = l_1129;
                ++l_1137[5];
                for (l_1133 = 4; (l_1133 >= 0); l_1133 -= 1)
                { /* block id: 543 */
                    int16_t l_1140 = 7L;
                    int32_t l_1141[2][5][5] = {{{0x4A4F0C6AL,0L,3L,0xCA22A564L,(-1L)},{0x3AE40D35L,0x4A4F0C6AL,1L,0L,0xCA22A564L},{0x5F535205L,1L,(-1L),0L,6L},{0x3AE40D35L,0L,0xB06BB7A2L,6L,0xB06BB7A2L},{0x4A4F0C6AL,0x4A4F0C6AL,4L,6L,(-1L)}},{{0L,0x3AE40D35L,0L,0L,0x4A4F0C6AL},{1L,0x5F535205L,3L,0L,0x5F535205L},{0x4A4F0C6AL,0x3AE40D35L,0x110AB2F6L,0xCA22A564L,0xCA22A564L},{0L,1L,0L,4L,0xB06BB7A2L},{3L,1L,9L,0L,0x110AB2F6L}}};
                    int i, j, k;
                    for (g_80 = 0; (g_80 <= 0); g_80 += 1)
                    { /* block id: 546 */
                        int8_t l_1142[5] = {0xA3L,0xA3L,0xA3L,0xA3L,0xA3L};
                        int32_t l_1144[1][7][8] = {{{(-10L),(-5L),(-9L),(-10L),(-5L),(-10L),(-9L),(-5L)},{(-10L),(-9L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)},{(-5L),(-5L),0xDBF81DCDL,0x37A27E92L,(-10L),0xDBF81DCDL,(-10L),0x37A27E92L},{(-10L),0x37A27E92L,(-10L),(-10L),0x37A27E92L,(-9L),(-9L),0x37A27E92L},{0x37A27E92L,(-9L),(-9L),0x37A27E92L,(-10L),(-10L),0x37A27E92L,(-10L)},{0x37A27E92L,(-10L),0xDBF81DCDL,(-10L),0x37A27E92L,0xDBF81DCDL,(-5L),(-5L)},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-9L),(-10L)}}};
                        uint8_t l_1148 = 1UL;
                        int i, j, k;
                        --l_1148;
                        return g_61[g_80][g_80][(g_80 + 2)];
                    }
                    (*l_872) = l_1151[0];
                    for (g_955 = 0; (g_955 <= 4); g_955 += 1)
                    { /* block id: 553 */
                        int32_t **l_1152 = &l_1118[3][0][4];
                        int i, j, k;
                        if (g_61[g_159][g_955][g_955])
                            break;
                        (*l_872) ^= 8L;
                        (*l_1152) = (void*)0;
                    }
                }
                for (l_866 = 0; (l_866 <= 4); l_866 += 1)
                { /* block id: 561 */
                    uint16_t l_1162 = 1UL;
                    int32_t **l_1187 = &l_872;
                    uint16_t ****l_1188 = &l_871[7];
                    union U2 **l_1191 = (void*)0;
                    union U2 **l_1192 = &l_1189;
                    for (g_898.f1 = 1; (g_898.f1 <= 4); g_898.f1 += 1)
                    { /* block id: 564 */
                        int32_t **l_1163 = &l_1118[3][0][4];
                        uint8_t *l_1177 = &g_134[1][0][6];
                        uint64_t *l_1186 = &g_227.f1;
                        int i, j, k;
                        (*l_1116) |= ((p_37 > (safe_lshift_func_int16_t_s_u(((((p_37 > (!g_163)) & (1L & (((*g_1035) , (((*g_419) = p_36) , (safe_sub_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_u((*g_447), 12)) ^ ((safe_mul_func_int8_t_s_s((1UL || ((0xA4AFL ^ 0x265FL) && 0L)), g_159)) , p_37)), (*g_150))))) != l_1162))) ^ l_1135) < 0x48D5L), 4))) != (*l_977));
                        (*l_1163) = &l_981;
                        (*l_1116) = (((p_38 , (*g_419)) , (safe_mul_func_int8_t_s_s(((safe_rshift_func_int16_t_s_s((**g_418), (+((safe_sub_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(0L, ((*l_1177) = ((*g_150)--)))), l_1135)) || ((safe_lshift_func_uint8_t_u_s(((safe_mul_func_uint16_t_u_u((safe_mul_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u((*l_977), 6)), ((*l_1186) = ((void*)0 != &l_971[1])))), 8UL)) > 0xB7DF12AA1E69468ELL), 2)) < g_248))))) > 0x4A462086L), p_36))) <= g_112[3]);
                    }
                    (*l_1187) = &g_112[3];
                    (*l_1116) |= ((((*l_1188) = &g_446) == (void*)0) | 0x874AL);
                    (*l_1192) = l_1189;
                    for (g_897.f3 = 0; (g_897.f3 <= 4); g_897.f3 += 1)
                    { /* block id: 579 */
                        return l_1136[4];
                    }
                }
            }
        }
        else
        { /* block id: 584 */
            uint32_t l_1193 = 0x0E53A9F0L;
            int32_t *l_1200 = &g_1130.f2;
            int32_t *l_1201 = (void*)0;
            int32_t *l_1202 = &l_856.f2;
            int32_t *l_1203[3][5] = {{&l_1070,&l_1070,&l_1147,&l_957,(void*)0},{(void*)0,&g_1130.f2,&g_1130.f2,(void*)0,&l_1070},{(void*)0,&l_957,&g_8,&g_8,&l_957}};
            int i, j;
            l_1193++;
            for (g_1190.f1 = (-26); (g_1190.f1 >= 41); g_1190.f1 = safe_add_func_uint8_t_u_u(g_1190.f1, 2))
            { /* block id: 588 */
                int8_t *l_1198[1][9] = {{&g_248,&g_503,&g_248,&g_503,&g_248,&g_503,&g_248,&g_503,&g_248}};
                int i, j;
                g_111 = ((g_248 |= 0x14L) , (void*)0);
                return l_1199;
            }
            l_1204--;
        }
        if ((p_38 > (g_1207 | ((((void*)0 == &p_36) ^ ((g_314 & p_36) == g_843)) & ((4L ^ (0UL >= (*g_552))) || 0x05L)))))
        { /* block id: 595 */
            int32_t **l_1208 = &l_977;
            l_1016 = ((*l_1208) = &l_980[1][0]);
        }
        else
        { /* block id: 598 */
            int32_t *l_1209 = &g_227.f2;
            int32_t **l_1210[6];
            int i;
            for (i = 0; i < 6; i++)
                l_1210[i] = &l_1209;
            l_977 = l_1209;
        }
    }
    else
    { /* block id: 601 */
        uint16_t l_1246 = 65535UL;
        int32_t l_1271 = (-1L);
        int32_t l_1299 = 0xEFB8CAE3L;
        int32_t l_1304 = 0x410587D6L;
        int16_t l_1379 = 0L;
        int8_t l_1380 = 7L;
        int32_t l_1415[8] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
        uint16_t ***l_1458[10][2] = {{&g_446,(void*)0},{&g_446,&g_446},{&g_446,(void*)0},{&g_446,&g_446},{(void*)0,&g_446},{&g_446,(void*)0},{&g_446,&g_446},{&g_446,(void*)0},{&g_446,&g_446},{(void*)0,&g_446}};
        uint16_t l_1624 = 0UL;
        int16_t l_1673 = (-8L);
        int16_t ***l_1691 = (void*)0;
        int16_t ****l_1690 = &l_1691;
        uint64_t l_1751 = 0x9CF19E78C9E50650LL;
        union U2 **l_1768 = &l_1400;
        union U2 ***l_1767 = &l_1768;
        union U1 *l_1786 = &g_1787;
        int i, j;
lbl_1291:
        for (l_1014 = (-21); (l_1014 < 49); l_1014 = safe_add_func_uint32_t_u_u(l_1014, 2))
        { /* block id: 604 */
            int16_t l_1215 = (-1L);
            const int16_t **l_1218[3];
            uint32_t *l_1258 = &g_1130.f3;
            int i;
            for (i = 0; i < 3; i++)
                l_1218[i] = &g_103;
            for (g_77 = 0; (g_77 != 2); g_77 = safe_add_func_uint32_t_u_u(g_77, 1))
            { /* block id: 607 */
                int8_t l_1228 = 0x38L;
                int32_t l_1232 = 0xAD355EFCL;
                if (p_36)
                { /* block id: 608 */
                    uint8_t l_1239 = 0x86L;
                    if (l_1215)
                    { /* block id: 609 */
                        int32_t *l_1229 = &l_971[0].f2;
                        int16_t *l_1231 = &g_955;
                        (*l_977) = (((*l_1231) |= (((*g_150) = (safe_lshift_func_int8_t_s_u(((l_1218[2] == (*g_948)) || (safe_mul_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(0x00L, (((g_1230[2][2][1] |= ((*g_447) &= (safe_sub_func_int32_t_s_s((0x07C2L != (safe_rshift_func_int16_t_s_u(((**g_418) = (p_37 , (-1L))), (*l_977)))), (((-5L) && (((safe_unary_minus_func_int32_t_s(((*l_1229) = l_1228))) >= p_36) , l_1228)) || l_1215))))) | 0L) , g_617[0].f0))), 1UL))), (*g_150)))) & 0x3BL)) < 0x7FE0L);
                        (*l_1229) = g_899.f0;
                        return p_36;
                    }
                    else
                    { /* block id: 619 */
                        int32_t *l_1233 = (void*)0;
                        int32_t *l_1234 = &l_1232;
                        int32_t *l_1235 = (void*)0;
                        int32_t *l_1236 = &l_1119;
                        int32_t *l_1237 = &g_617[0].f2;
                        int32_t *l_1238[8][10] = {{&l_1119,&l_1147,&g_1130.f2,&l_1147,(void*)0,&l_1119,&g_314,&l_1146,&g_8,&l_1119},{&l_1232,(void*)0,&g_80,&l_1147,&l_1119,&l_1146,&g_1130.f2,&g_80,(void*)0,&g_80},{&l_1232,&l_1146,(void*)0,&g_8,&g_2,&l_1119,&g_80,&g_80,&l_1119,&g_2},{&l_1119,&g_80,&g_80,&l_1119,&g_2,&g_8,(void*)0,&l_1146,&l_1232,&g_80},{(void*)0,&g_80,&g_1130.f2,&l_1146,&l_1119,&l_1147,&g_80,(void*)0,&l_1232,&l_1119},{&g_8,&l_1146,&g_314,&l_1119,(void*)0,&l_1147,&g_1130.f2,&l_1147,&l_1119,&l_1119},{(void*)0,(void*)0,&g_314,&g_8,&g_112[0],&g_8,&g_314,(void*)0,&l_1119,&l_1232},{&g_2,&l_1147,&l_1146,&g_1130.f2,&g_314,&g_2,(void*)0,&l_1232,&g_112[5],&g_112[3]}};
                        int i, j;
                        l_1239++;
                        if (g_955)
                            goto lbl_1291;
                        (*l_1234) = (-1L);
                    }
                    return g_276[1][1];
                }
                else
                { /* block id: 624 */
                    uint64_t l_1272 = 1UL;
                    for (g_1190.f3 = 0; (g_1190.f3 >= 29); ++g_1190.f3)
                    { /* block id: 627 */
                        return l_1232;
                    }
                    if (((safe_sub_func_int64_t_s_s(l_1246, (safe_lshift_func_int16_t_s_u((safe_unary_minus_func_uint8_t_u((((safe_mod_func_int16_t_s_s((0x13D0L <= (safe_rshift_func_uint16_t_u_s((safe_mod_func_int64_t_s_s((g_296 == (safe_mod_func_uint32_t_u_u(((void*)0 == l_1258), g_374[1]))), (safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s(((safe_sub_func_uint16_t_u_u(((4294967286UL || (((safe_div_func_uint16_t_u_u((l_1271 = (safe_sub_func_int8_t_s_s(((*l_977) , ((g_904[5][0].f0 | (*l_977)) , g_896.f0)), (*g_150)))), p_37)) | 0xB6D27CB3FA820A96LL) != 1UL)) != l_1272), 0xD7C7L)) > p_37), 1UL)), g_503)))), 15))), l_1215)) != g_1273[7]) < (*l_977)))), p_36)))) <= (-1L)))
                    { /* block id: 631 */
                        return p_37;
                    }
                    else
                    { /* block id: 633 */
                        int8_t *l_1286 = &g_1273[7];
                        int32_t l_1287 = 0x7ADD125BL;
                        int32_t l_1288 = (-2L);
                        (*l_977) = g_900.f0;
                        (*l_977) = (0x4B902778L | (safe_sub_func_int16_t_s_s(((--(*l_1258)) && ((((*g_150) || (safe_sub_func_uint32_t_u_u(0x13DF8607L, (l_1288 ^= (((safe_div_func_uint16_t_u_u((p_36 , (((safe_lshift_func_int8_t_s_s(((l_1232 |= 0x3200BBCCL) , ((*l_977) | (*l_977))), l_1246)) != (((*l_1286) = (safe_lshift_func_int8_t_s_u(g_8, 1))) ^ 255UL)) ^ g_908.f0)), 9UL)) || p_38) & l_1287))))) | 0xA2L) ^ 0x20FC332F22101481LL)), p_38)));
                        if (l_1272)
                            break;
                    }
                }
                (*l_977) = (((*g_150) |= ((g_1289 != (void*)0) , l_1215)) | 0xDEL);
            }
        }
lbl_1771:
        for (l_1271 = 0; (l_1271 > 9); ++l_1271)
        { /* block id: 650 */
            union U0 l_1294[2] = {{0x5BA8AA48L},{0x5BA8AA48L}};
            int64_t *l_1370[9][1] = {{&g_167},{(void*)0},{&g_167},{(void*)0},{&g_167},{(void*)0},{&g_167},{(void*)0},{&g_167}};
            int32_t **l_1389 = &l_977;
            int32_t l_1420 = 0x952703CBL;
            int32_t l_1425 = 0L;
            int32_t l_1430 = 0xBD907E51L;
            int32_t l_1431 = 9L;
            int32_t l_1432 = (-1L);
            int32_t l_1435 = 0xF26D7665L;
            int8_t l_1440 = 1L;
            int16_t ***l_1482 = &g_418;
            int32_t *l_1513 = &g_314;
            int8_t l_1520 = 0x81L;
            uint64_t l_1564 = 0x2267BB95EC14F2BELL;
            const int8_t l_1589[8][3] = {{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL},{(-7L),(-7L),0x9DL}};
            uint32_t l_1597 = 0x64B90866L;
            int i, j;
        }
        for (l_1295 = 0; (l_1295 >= 56); l_1295 = safe_add_func_uint32_t_u_u(l_1295, 7))
        { /* block id: 807 */
            int32_t *l_1676 = (void*)0;
            int32_t **l_1677 = (void*)0;
            int32_t **l_1678[10] = {&l_1676,&l_1676,&l_1676,&l_1676,&l_1676,&l_1676,&l_1676,&l_1676,&l_1676,&l_1676};
            int16_t *l_1685 = &g_61[0][3][6];
            int16_t *l_1686 = &g_955;
            uint32_t l_1701 = 0xD64F7E4BL;
            uint8_t *l_1707 = &g_134[1][0][0];
            uint32_t *l_1708 = &l_1441;
            uint64_t l_1734 = 0x4E4EFC018B200A84LL;
            int64_t ***l_1758 = &l_927;
            int i;
            g_111 = ((*l_1460) = l_1676);
            g_80 = (249UL | (safe_mul_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s(((g_743 < ((p_38 > ((((((((safe_rshift_func_int16_t_s_u((l_1380 , ((*l_1685) &= (**g_418))), (((*l_1686) = p_37) & (((*g_150) = (((~((g_617[0].f0 > ((safe_mod_func_uint16_t_u_u(0xED98L, (*g_447))) < p_37)) > p_37)) <= l_1624) != p_38)) == 0x3AL)))) > p_37) != g_102) < g_1305) , p_36) != 9L) , 1L) | 1UL)) & p_37)) , p_36), p_38)) >= 0xEAL), 0x12AFL)));
            l_1299 |= (((*l_1708) = ((((((*g_150) | ((l_1690 == &g_948) || ((l_1070 = (-8L)) >= (!(safe_sub_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((*l_1707) &= (safe_add_func_uint64_t_u_u((((((safe_sub_func_int64_t_s_s(l_1701, (*g_552))) , 0xE5L) > (safe_unary_minus_func_uint32_t_u(g_8))) == (safe_sub_func_uint32_t_u_u(((l_1145 = (l_1415[2] ^= ((safe_mod_func_int32_t_s_s(0xF9FD9B8FL, l_1673)) ^ 0xDCL))) , g_906.f0), g_896.f0))) | p_36), g_80))), g_1309.f3)), l_1380)))))) , g_102) , l_1379) <= p_38) && (*g_447))) && 0x0DB32BD3L);
            for (l_1427 = 6; (l_1427 <= (-3)); l_1427--)
            { /* block id: 822 */
                uint8_t l_1711 = 0x25L;
                int32_t l_1744 = 5L;
                int32_t l_1746 = 0x18F50915L;
                int32_t l_1748 = 0xE6C98FCAL;
                if (l_1711)
                { /* block id: 823 */
                    int64_t l_1749 = 0xB2B1834BA61F3A4DLL;
                    if ((safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((((*l_1708) = (((safe_lshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u((safe_sub_func_int32_t_s_s(((safe_unary_minus_func_uint16_t_u(0UL)) , 0x7640AB0CL), (safe_unary_minus_func_uint32_t_u((p_37 | (safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((((safe_sub_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s((((*l_1686) |= 0x764FL) ^ l_1734), (0UL != (safe_mul_func_int8_t_s_s(0xBCL, (safe_div_func_uint16_t_u_u(((((safe_mul_func_uint16_t_u_u(p_37, (safe_mod_func_int8_t_s_s((((p_37 ^ 5L) ^ l_1415[5]) & l_1711), 0x0BL)))) , p_38) && p_37) | (*g_419)), 65527UL))))))), 3)) , (void*)0) != l_1707), g_1354)) , l_1673) == 0L) , 0L), 8)), l_1299))))))), 18446744073709551615UL)), p_37)) ^ p_38) == g_1290.f2)) || g_900.f0) || p_36), (*g_447))), 1L)))
                    { /* block id: 826 */
                        uint64_t l_1743 = 18446744073709551615UL;
                        int32_t l_1745 = 9L;
                        int32_t l_1747 = 0x529FAEACL;
                        int32_t l_1750[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_1750[i] = 0xEB0FA336L;
                        if (l_1743)
                            break;
                        ++l_1751;
                    }
                    else
                    { /* block id: 829 */
                        return p_37;
                    }
                    for (l_1429 = 0; (l_1429 > (-12)); l_1429--)
                    { /* block id: 834 */
                        return g_1130.f3;
                    }
                }
                else
                { /* block id: 837 */
                    uint32_t l_1760[3][2] = {{0UL,0xFC0F4ED7L},{0UL,0UL},{0xFC0F4ED7L,0UL}};
                    int32_t l_1770 = 1L;
                    int i, j;
                    for (g_843 = 11; (g_843 == 43); g_843 = safe_add_func_uint64_t_u_u(g_843, 2))
                    { /* block id: 840 */
                        int64_t ****l_1759 = &g_1020;
                        int32_t l_1769 = 0x1AA543F8L;
                        l_1304 = (l_1770 = ((((((l_1760[1][0] = ((((*l_1759) = l_1758) != &l_927) & 0xFCE3FD629D012B75LL)) ^ (((p_38 ^ ((((void*)0 == g_1761) , 0xDF2CA21FL) <= ((((safe_mod_func_int16_t_s_s((safe_div_func_uint64_t_u_u((((void*)0 != l_1767) ^ l_1271), l_1769)), p_38)) >= (-1L)) != g_296) <= g_904[5][0].f0))) <= g_1309.f2) == 4294967290UL)) , p_37) >= p_36) , &l_1048) == (void*)0));
                    }
                    (**l_1459) = &g_112[3];
                    if (g_1102)
                        goto lbl_1771;
                }
                for (g_1290.f1 = (-19); (g_1290.f1 != 27); g_1290.f1 = safe_add_func_uint32_t_u_u(g_1290.f1, 6))
                { /* block id: 851 */
                    union U1 *l_1781 = &g_1782;
                    int32_t l_1784[2][7][6] = {{{0x7231996DL,0xFC03A68CL,0xFC03A68CL,0x7231996DL,0xF374EE5BL,4L},{0xBDB9C506L,0xFC03A68CL,0xF374EE5BL,0xBDB9C506L,0xF374EE5BL,0xFC03A68CL},{5L,0xFC03A68CL,4L,5L,0xF374EE5BL,0xF374EE5BL},{0x7231996DL,0xFC03A68CL,0xFC03A68CL,0x7231996DL,0xF374EE5BL,4L},{0xBDB9C506L,0xFC03A68CL,0xF374EE5BL,0xBDB9C506L,0xF374EE5BL,0xFC03A68CL},{5L,0xFC03A68CL,4L,5L,0xF374EE5BL,0xF374EE5BL},{0x7231996DL,0xFC03A68CL,0xFC03A68CL,0x7231996DL,0xF374EE5BL,4L}},{{0xBDB9C506L,0xFC03A68CL,0xF374EE5BL,0xBDB9C506L,0xF374EE5BL,0xFC03A68CL},{5L,0xFC03A68CL,4L,5L,0xF374EE5BL,0xF374EE5BL},{0x7231996DL,0xFC03A68CL,0xFC03A68CL,0x7231996DL,0xF374EE5BL,4L},{0xBDB9C506L,0xFC03A68CL,0xF374EE5BL,0xBDB9C506L,0xF374EE5BL,0xFC03A68CL},{5L,0xFC03A68CL,4L,5L,0xF374EE5BL,0xF374EE5BL},{0x7231996DL,0xFC03A68CL,0xFC03A68CL,0x7231996DL,0xF374EE5BL,4L},{0xBDB9C506L,0xFC03A68CL,0xF374EE5BL,0xBDB9C506L,0xF374EE5BL,0xFC03A68CL}}};
                    int i, j, k;
                    for (l_1751 = 11; (l_1751 > 22); l_1751++)
                    { /* block id: 854 */
                        uint16_t l_1776 = 0xC774L;
                        union U0 **l_1780 = &g_1035;
                        union U1 **l_1783 = &g_1289;
                        l_1776++;
                        (*l_1780) = l_1779;
                        (*l_1783) = l_1781;
                        if (l_1784[1][3][3])
                            continue;
                    }
                    if (p_37)
                        continue;
                    if (p_38)
                        break;
                }
                (*l_1460) = &l_1744;
                (**l_1459) = &g_112[7];
            }
        }
        for (g_296 = 5; (g_296 >= 0); g_296 -= 1)
        { /* block id: 869 */
            union U1 **l_1785[4] = {&g_1289,&g_1289,&g_1289,&g_1289};
            int i;
            g_112[2] &= ((l_1308 == (l_1786 = g_1289)) != (l_1434[g_296] , l_1434[g_296]));
        }
    }
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_47(const int16_t  p_48, union U0  p_49, int32_t  p_50)
{ /* block id: 429 */
    uint32_t l_846[1][3];
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_846[i][j] = 8UL;
    }
    return l_846[0][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_61 g_77 g_80 g_2 g_112 g_134 g_150 g_102 g_103 g_167 g_111 g_104 g_151 g_227 g_248 g_268 g_276 g_227.f2 g_159 g_418 g_419 g_447 g_296 g_446 g_503 g_163 g_552 g_617 g_314 g_8 g_617.f0 g_227.f0
 * writes: g_77 g_80 g_103 g_111 g_134 g_159 g_163 g_112 g_167 g_151 g_248 g_268 g_276 g_227.f2 g_418 g_446 g_296 g_503 g_447 g_617 g_314 g_540
 */
static union U0  func_53(uint16_t  p_54, const int16_t  p_55, uint8_t  p_56, uint8_t  p_57, uint64_t  p_58)
{ /* block id: 10 */
    int16_t *l_69 = &g_61[0][3][1];
    int32_t l_70 = 0x5B79C141L;
    uint32_t *l_842[9][9] = {{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,(void*)0,&g_843,(void*)0},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,(void*)0,&g_843,(void*)0},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843},{(void*)0,&g_843,&g_843,&g_843,&g_843,(void*)0,&g_843,&g_843,&g_843},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843},{(void*)0,&g_843,&g_843,&g_843,&g_843,(void*)0,&g_843,&g_843,&g_843},{&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843,&g_843}};
    int32_t l_844 = 0xDAA68A8DL;
    int32_t *l_845 = &g_112[3];
    int i, j;
    (*l_845) = (((l_844 |= (func_63(l_69, l_70, func_71(l_70), l_69, l_70) , p_57)) || p_56) , g_61[0][7][5]);
    return g_617[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_227.f2 g_80 g_447 g_268 g_150 g_151 g_61 g_419 g_276 g_552 g_159 g_134 g_617 g_418 g_314 g_112 g_104 g_8 g_103 g_617.f0 g_2
 * writes: g_227.f2 g_80 g_503 g_151 g_617 g_159 g_314 g_268 g_112 g_540
 */
static int32_t  func_63(int16_t * p_64, int32_t  p_65, int16_t * p_66, int16_t * p_67, uint32_t  p_68)
{ /* block id: 309 */
    uint16_t **l_642 = &g_447;
    int32_t l_672 = 1L;
    int32_t l_687 = (-1L);
    union U0 l_702 = {0xCDE55330L};
    uint16_t l_721 = 0x7537L;
    uint32_t *l_773 = &g_163;
    int64_t **l_777[5][7][4] = {{{&g_552,(void*)0,(void*)0,&g_552},{&g_552,(void*)0,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,(void*)0,&g_552,&g_552},{&g_552,(void*)0,&g_552,(void*)0},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,(void*)0}},{{&g_552,(void*)0,(void*)0,&g_552},{&g_552,(void*)0,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,(void*)0,&g_552,&g_552},{&g_552,(void*)0,&g_552,(void*)0},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,(void*)0}},{{&g_552,(void*)0,(void*)0,&g_552},{&g_552,(void*)0,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,(void*)0,&g_552,&g_552},{&g_552,(void*)0,&g_552,(void*)0},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,(void*)0}},{{&g_552,(void*)0,(void*)0,&g_552},{&g_552,(void*)0,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,(void*)0,&g_552,&g_552},{&g_552,(void*)0,&g_552,(void*)0},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,(void*)0}},{{&g_552,(void*)0,(void*)0,&g_552},{&g_552,(void*)0,&g_552,&g_552},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,(void*)0,&g_552,&g_552},{&g_552,(void*)0,&g_552,(void*)0},{(void*)0,&g_552,&g_552,&g_552},{(void*)0,&g_552,&g_552,(void*)0}}};
    int8_t l_799 = (-4L);
    int32_t l_804 = 0x210E88E2L;
    int32_t l_805 = 0xF42D5FFEL;
    int32_t l_806 = 1L;
    int32_t l_807 = (-1L);
    int32_t l_808 = 0xCFACB446L;
    int32_t l_809 = 0xEBE4E529L;
    int32_t l_810 = 1L;
    int32_t l_811 = 1L;
    int32_t l_812 = 0x80854915L;
    int32_t *l_841[10][10][2] = {{{&l_805,&g_80},{&g_227.f2,&g_227.f2},{&g_227.f2,&g_80},{&l_805,(void*)0},{&g_80,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}},{{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2},{&l_807,&l_805},{&g_80,&g_80},{&g_80,&l_805},{&l_807,&g_227.f2},{&l_805,&g_227.f2}}};
    int i, j, k;
    for (g_227.f2 = 9; (g_227.f2 == (-27)); g_227.f2 = safe_sub_func_int16_t_s_s(g_227.f2, 9))
    { /* block id: 312 */
        uint16_t **l_643[1][4][7] = {{{&g_447,(void*)0,(void*)0,&g_447,(void*)0,&g_447,(void*)0},{&g_447,&g_447,&g_447,&g_447,&g_447,&g_447,&g_447},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_447,&g_447,&g_447,&g_447,&g_447,&g_447,&g_447}}};
        int32_t *l_644 = &g_80;
        int16_t ***l_675 = &g_418;
        int32_t l_678 = (-1L);
        int8_t *l_685 = (void*)0;
        int8_t *l_686 = (void*)0;
        union U0 *l_688 = &g_617[0];
        int32_t *l_691[5];
        int16_t l_774 = 0x11ACL;
        int32_t l_784[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        uint64_t l_813 = 0UL;
        int8_t l_837 = (-1L);
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_691[i] = &g_77;
        (*l_644) |= ((l_643[0][1][2] = l_642) != l_642);
        for (p_68 = 0; (p_68 != 7); p_68 = safe_add_func_int8_t_s_s(p_68, 9))
        { /* block id: 317 */
            uint32_t l_657 = 0UL;
            int8_t *l_661 = &g_503;
            uint32_t *l_673[5][3][6] = {{{&g_163,&l_657,&g_163,&l_657,&l_657,&g_163},{(void*)0,(void*)0,(void*)0,&g_163,&l_657,&g_163},{&l_657,&l_657,(void*)0,&g_163,(void*)0,&l_657}},{{(void*)0,&g_163,&g_163,&g_163,(void*)0,&l_657},{&g_163,(void*)0,&l_657,&g_163,&g_163,&l_657},{&g_163,(void*)0,&g_163,(void*)0,&l_657,&l_657}},{{&g_163,(void*)0,&l_657,(void*)0,&l_657,&l_657},{&l_657,&g_163,&g_163,&g_163,&g_163,&l_657},{&l_657,&l_657,(void*)0,&l_657,(void*)0,&g_163}},{{&l_657,&l_657,(void*)0,&g_163,(void*)0,&g_163},{&l_657,&g_163,&g_163,&l_657,(void*)0,&g_163},{&l_657,(void*)0,&g_163,&g_163,&g_163,(void*)0}},{{&l_657,(void*)0,&g_163,(void*)0,&l_657,&l_657},{&g_163,&l_657,&g_163,(void*)0,(void*)0,(void*)0},{&g_163,&l_657,&l_657,&g_163,&l_657,&g_163}}};
            int16_t ***l_674 = (void*)0;
            int32_t *l_676 = (void*)0;
            int32_t *l_677[2][2][7] = {{{&g_112[8],(void*)0,&g_112[8],&g_314,&g_314,&g_112[8],(void*)0},{&g_77,&g_2,&g_112[3],&g_112[3],&g_2,&g_77,&g_2}},{{&g_112[8],&g_314,&g_314,&g_112[8],(void*)0,&g_112[8],&g_314},{&g_112[5],&g_112[5],&g_77,&g_112[3],&g_77,&g_112[5],&g_112[5]}}};
            int i, j, k;
            l_678 = (safe_sub_func_uint16_t_u_u(((*g_447) > (((-1L) > (safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((((safe_div_func_int32_t_s_s((((p_68 >= ((safe_lshift_func_int8_t_s_s(l_657, 0)) != ((p_68 < (safe_mod_func_int16_t_s_s((~(((((*l_661) = 0x97L) , (safe_mul_func_uint8_t_u_u((--(*g_150)), g_61[0][3][6]))) || (safe_sub_func_uint16_t_u_u(((((((l_657 , (((((*l_644) = (safe_add_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(l_672, (*g_419))), 1UL))) , l_674) == l_675) && p_65)) , p_65) & (*g_552)) & p_65) || (*g_447)) != (*g_447)), l_657))) || p_65)), 0x6662L))) & l_657))) < l_657) & p_65), 9L)) <= g_134[1][0][5]) , l_672), (-4L))), 0UL))) || 65535UL)), 0xD7DDL));
            if (p_65)
                continue;
        }
        p_65 = (g_61[0][2][5] >= ((safe_mod_func_uint16_t_u_u((((*l_644) = (safe_mul_func_int8_t_s_s(0x0BL, p_68))) ^ (((*p_66) | (*g_447)) || (safe_div_func_uint8_t_u_u(((l_687 |= l_672) & ((((((*l_688) = g_617[0]) , (((*g_552) = (18446744073709551615UL || (safe_add_func_int16_t_s_s((**g_418), 0xBC11L)))) <= l_672)) <= (*g_150)) ^ g_276[1][2]) ^ 0x9FC759012BACC6B3LL)), g_134[1][0][5])))), (*g_447))) , p_65));
        if (l_672)
        { /* block id: 329 */
            for (g_314 = 0; (g_314 <= 21); g_314++)
            { /* block id: 332 */
                for (g_268 = 0; (g_268 <= 2); g_268 += 1)
                { /* block id: 335 */
                    int i, j;
                    if (g_276[(g_268 + 3)][g_268])
                        break;
                    if (g_276[(g_268 + 3)][g_268])
                        continue;
                }
            }
            (*l_644) = (p_65 = (-1L));
            for (l_678 = 0; (l_678 < 12); ++l_678)
            { /* block id: 344 */
                int32_t **l_696 = &l_644;
                (*l_696) = &g_314;
                g_112[4] &= (**l_696);
            }
        }
        else
        { /* block id: 348 */
            union U0 l_701 = {0x234A7DCDL};
            uint32_t l_757[5];
            int32_t l_758 = 0x27612FD0L;
            int32_t l_800 = 0L;
            int32_t l_802 = 0xE26E571EL;
            int32_t l_803[3];
            int8_t *l_824 = &g_503;
            int32_t **l_839 = &l_691[2];
            int i;
            for (i = 0; i < 5; i++)
                l_757[i] = 0x47305ED1L;
            for (i = 0; i < 3; i++)
                l_803[i] = 0x597A9D6FL;
            for (g_268 = 11; (g_268 < 36); g_268 = safe_add_func_uint32_t_u_u(g_268, 3))
            { /* block id: 351 */
                uint32_t *l_709 = &g_540;
                int32_t l_718[10] = {0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL,0x666F4AAEL};
                int i;
            }
            for (l_701.f2 = 2; (l_701.f2 >= 0); l_701.f2 -= 1)
            { /* block id: 403 */
                int64_t l_833 = 0xDFBCCB7F2842176DLL;
                int32_t **l_838 = &l_644;
                for (l_812 = 2; (l_812 >= 0); l_812 -= 1)
                { /* block id: 406 */
                    union U0 **l_831 = &l_688;
                    uint64_t *l_832 = &l_813;
                    int32_t l_834 = (-7L);
                    int32_t l_835 = (-10L);
                    uint32_t *l_836 = &g_540;
                    (*l_644) = (safe_mul_func_int8_t_s_s((safe_mod_func_uint32_t_u_u(g_104, ((*l_836) = (safe_lshift_func_uint8_t_u_u((((l_834 = (((g_151 , (l_833 = ((safe_rshift_func_int16_t_s_s(((void*)0 != l_824), ((((((safe_add_func_int32_t_s_s((safe_mul_func_int16_t_s_s((((0xD8L != (p_68 < ((*g_552) = (((safe_unary_minus_func_uint16_t_u(((*g_447) = (+((0xB9F85D0C7DAC880ALL <= (((*l_831) = l_688) == &g_617[0])) , p_68))))) , l_757[4]) < p_65)))) , (void*)0) == l_832), p_68)), 0x78B5238FL)) < l_805) && p_65) <= 0xDF0770A5L) , p_65) && g_8))) , (*g_447)))) < (*g_419)) ^ p_65)) & (*g_103)) ^ 1UL), l_835))))), 0x2AL));
                    if (l_803[2])
                        continue;
                    if (l_837)
                        break;
                    if (l_802)
                        continue;
                }
                (*l_838) = &l_784[4];
                if (p_68)
                    continue;
            }
            (*l_839) = &p_65;
        }
    }
    g_617[0].f0 |= ((!(*g_150)) || 0x0FL);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_61 g_77 g_80 g_2 g_112 g_134 g_150 g_102 g_103 g_167 g_111 g_104 g_151 g_227 g_248 g_268 g_276 g_227.f2 g_159 g_418 g_419 g_447 g_296 g_446 g_503 g_163 g_227.f0
 * writes: g_77 g_80 g_103 g_111 g_134 g_159 g_163 g_112 g_167 g_151 g_248 g_268 g_276 g_227.f2 g_418 g_446 g_296 g_503 g_447
 */
static int16_t * func_71(int32_t  p_72)
{ /* block id: 11 */
    int32_t l_74[7];
    int16_t *l_183 = (void*)0;
    int16_t **l_182 = &l_183;
    union U0 l_237 = {0L};
    uint32_t *l_247 = &g_163;
    int64_t l_249[4];
    uint8_t l_250[8][8][4] = {{{0x02L,0xD2L,1UL,1UL},{0xFCL,8UL,0UL,0xD2L},{253UL,255UL,1UL,249UL},{0xF4L,246UL,1UL,0xF4L},{8UL,253UL,5UL,1UL},{3UL,1UL,0xA0L,0x3BL},{0x0BL,0xB9L,0UL,0x78L},{251UL,0xA0L,253UL,0xA0L}},{{1UL,0x27L,249UL,1UL},{0x64L,0UL,5UL,252UL},{1UL,1UL,0x12L,0x0BL},{1UL,0xF2L,5UL,251UL},{0x64L,0x0BL,249UL,248UL},{1UL,255UL,253UL,0xF4L},{251UL,247UL,0x27L,0x0DL},{0UL,255UL,0x64L,0x27L}},{{255UL,255UL,249UL,0x02L},{1UL,0x64L,0x77L,251UL},{0x9AL,1UL,248UL,0x64L},{0xF4L,1UL,8UL,1UL},{1UL,0x77L,0x77L,1UL},{0xF2L,0xF4L,247UL,9UL},{255UL,0xA0L,248UL,1UL},{0x0DL,1UL,0x27L,1UL}},{{5UL,0xA0L,0UL,9UL},{1UL,0xF4L,0x3BL,1UL},{0x0BL,0x77L,5UL,1UL},{1UL,1UL,252UL,0x64L},{1UL,1UL,3UL,251UL},{0x0BL,0x64L,249UL,0x02L},{0UL,255UL,0UL,0x27L},{251UL,255UL,249UL,0x0DL}},{{0x0DL,247UL,0x64L,0xF4L},{247UL,255UL,247UL,248UL},{1UL,0x0BL,1UL,251UL},{1UL,0xF2L,248UL,0x0BL},{0x27L,1UL,248UL,252UL},{1UL,0UL,1UL,1UL},{1UL,0x27L,247UL,0xA0L},{247UL,0xA0L,0x64L,0x78L}},{{0x0DL,1UL,249UL,1UL},{251UL,9UL,0UL,0xA0L},{0UL,0xF4L,249UL,0x9AL},{0x0BL,0UL,3UL,1UL},{1UL,0x78L,252UL,0x0BL},{1UL,1UL,5UL,5UL},{0x0BL,0x0BL,0x3BL,0x02L},{1UL,249UL,0UL,0xF4L}},{{5UL,255UL,0x27L,0UL},{0x0DL,255UL,248UL,0xF4L},{255UL,249UL,247UL,0x02L},{0xF2L,0x0BL,0x77L,5UL},{1UL,1UL,8UL,0x0BL},{0xF4L,0x78L,248UL,1UL},{0x9AL,0x27L,249UL,255UL},{0x77L,0x9AL,6UL,0x64L}},{{0x22L,248UL,253UL,1UL},{0xFCL,9UL,0x12L,1UL},{247UL,0x64L,0xF4L,0x64L},{248UL,1UL,0xB9L,0UL},{253UL,0x27L,249UL,3UL},{9UL,1UL,251UL,0UL},{9UL,1UL,249UL,247UL},{253UL,0UL,0xB9L,246UL}}};
    int16_t l_251[8][4][4] = {{{(-8L),0x19ACL,0xC167L,(-5L)},{0L,0x5BB6L,0L,0xF9B1L},{0x411AL,0xC167L,(-1L),0xA0FBL},{0L,0xC6E2L,5L,0xC6E2L}},{{1L,(-5L),0xA0FBL,(-8L)},{7L,0xA0FBL,(-2L),0xACF6L},{0xC6E2L,(-2L),1L,1L},{0xC6E2L,0xBBFDL,(-2L),0xC947L}},{{7L,1L,0xA0FBL,0x19ACL},{1L,1L,5L,(-1L)},{0L,(-2L),(-1L),0L},{0x411AL,0L,0L,0x411AL}},{{0L,(-5L),0xC167L,0L},{(-8L),(-8L),(-2L),0xA22FL},{0xC947L,(-1L),0x411AL,0xA22FL},{(-5L),(-8L),1L,0L}},{{1L,(-5L),0xC947L,0x411AL},{0x5BB6L,0L,0xF9B1L,0L},{1L,(-2L),(-5L),(-1L)},{0x9874L,1L,0x9874L,0x19ACL}},{{5L,1L,1L,0xC947L},{0xACF6L,0xBBFDL,0L,1L},{0xC167L,(-2L),0L,0xACF6L},{0xACF6L,0xA0FBL,1L,(-8L)}},{{5L,(-5L),0x9874L,0xC6E2L},{0x9874L,0xC6E2L,(-5L),0xA0FBL},{1L,0xC167L,0xF9B1L,0xF9B1L},{0x5BB6L,0x5BB6L,0xC947L,(-5L)}},{{1L,0x19ACL,1L,(-5L)},{(-5L),(-8L),0x411AL,1L},{0xC947L,(-8L),(-2L),(-5L)},{(-8L),0x19ACL,0xC167L,(-5L)}}};
    uint8_t l_279 = 0x98L;
    int32_t l_295[6][7] = {{0L,0x660EA5D8L,0x36107364L,0x36107364L,0x660EA5D8L,0L,0x660EA5D8L},{3L,0L,0L,3L,0x660EA5D8L,3L,0L},{1L,1L,0L,0x36107364L,0L,1L,1L},{1L,0L,0x36107364L,3L,0L,0L,3L},{0x36107364L,1L,0x36107364L,3L,3L,0x36107364L,1L},{3L,1L,0x660EA5D8L,0x660EA5D8L,1L,3L,1L}};
    int32_t l_297 = 0x98B304DBL;
    uint32_t l_343[4][8][1] = {{{0xAB566C38L},{0xAB566C38L},{0xBA474D16L},{18446744073709551607UL},{0xBA474D16L},{0xAB566C38L},{0xAB566C38L},{0xBA474D16L}},{{18446744073709551607UL},{0xBA474D16L},{0xAB566C38L},{0xAB566C38L},{0xBA474D16L},{18446744073709551607UL},{0xBA474D16L},{0xAB566C38L}},{{0xAB566C38L},{0xBA474D16L},{18446744073709551607UL},{0xBA474D16L},{0xAB566C38L},{0xAB566C38L},{0xBA474D16L},{18446744073709551607UL}},{{0xBA474D16L},{0xAB566C38L},{0xAB566C38L},{0xBA474D16L},{18446744073709551607UL},{0xBA474D16L},{0xAB566C38L},{0xAB566C38L}}};
    int32_t **l_471[7];
    union U0 *l_488 = &l_237;
    int8_t *l_548[5][10][5] = {{{&g_503,&g_248,&g_503,(void*)0,&g_503},{&g_503,&g_248,(void*)0,&g_503,&g_503},{&g_248,&g_503,&g_503,&g_248,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_248,(void*)0,&g_248},{(void*)0,&g_248,&g_248,&g_503,&g_503},{&g_503,&g_248,&g_503,(void*)0,&g_503},{&g_503,&g_248,(void*)0,&g_503,&g_503},{&g_248,&g_503,&g_503,&g_248,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248}},{{&g_503,&g_503,&g_248,(void*)0,&g_248},{(void*)0,&g_248,&g_248,&g_503,&g_503},{&g_503,&g_248,&g_503,(void*)0,&g_503},{&g_503,&g_248,(void*)0,&g_503,&g_503},{&g_248,&g_503,&g_503,&g_248,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_248,(void*)0,&g_248},{(void*)0,&g_248,&g_248,&g_503,&g_503},{&g_503,&g_248,&g_503,(void*)0,&g_503},{&g_503,&g_248,(void*)0,&g_503,&g_503}},{{&g_248,&g_503,&g_503,&g_248,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_248,(void*)0,&g_248},{(void*)0,&g_248,&g_248,&g_503,&g_503},{&g_503,&g_248,&g_503,(void*)0,&g_503},{&g_503,&g_248,(void*)0,&g_503,&g_503},{&g_248,&g_503,&g_503,&g_248,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_503,&g_503,&g_248},{(void*)0,&g_503,&g_248,(void*)0,&g_248}},{{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_248,&g_503,&g_503,&g_503,&g_248},{&g_248,&g_503,&g_248,&g_503,&g_248},{&g_248,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_503,&g_503,&g_248},{(void*)0,&g_503,&g_248,(void*)0,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_248,&g_503,&g_503,&g_503,&g_248},{&g_248,&g_503,&g_248,&g_503,&g_248},{&g_248,&g_248,&g_248,&g_503,&g_248}},{{&g_503,&g_503,&g_503,&g_503,&g_248},{(void*)0,&g_503,&g_248,(void*)0,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_248,&g_503,&g_503,&g_503,&g_248},{&g_248,&g_503,&g_248,&g_503,&g_248},{&g_248,&g_248,&g_248,&g_503,&g_248},{&g_503,&g_503,&g_503,&g_503,&g_248},{(void*)0,&g_503,&g_248,(void*)0,&g_248},{&g_503,&g_248,&g_248,&g_503,&g_248},{&g_248,&g_503,&g_503,&g_503,&g_248}}};
    int16_t l_607 = 0x573DL;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_74[i] = 0L;
    for (i = 0; i < 4; i++)
        l_249[i] = 0L;
    for (i = 0; i < 7; i++)
        l_471[i] = &g_111;
lbl_435:
    if ((safe_unary_minus_func_uint16_t_u((l_74[4] , g_61[0][3][6]))))
    { /* block id: 12 */
        int8_t l_106[6][6] = {{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L},{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L},{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L},{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L},{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L},{0xB5L,0xB5L,0xB5L,0xB5L,0xB5L,0xB5L}};
        union U0 l_187 = {0xE9FA99CDL};
        uint32_t l_190 = 0xF508D56EL;
        int32_t l_193 = 3L;
        uint64_t l_218 = 0x8CAB240058932948LL;
        int i, j;
        for (p_72 = (-15); (p_72 == (-5)); p_72 = safe_add_func_uint32_t_u_u(p_72, 9))
        { /* block id: 15 */
            const int8_t l_91 = 9L;
            int16_t *l_97[7] = {&g_61[0][2][6],&g_61[0][3][6],&g_61[0][2][6],&g_61[0][2][6],&g_61[0][3][6],&g_61[0][2][6],&g_61[0][2][6]};
            uint16_t l_105 = 3UL;
            union U0 l_173[1][7] = {{{0L},{0L},{0x7764D012L},{0L},{0L},{0x7764D012L},{0L}}};
            const uint8_t *l_191 = &g_134[1][0][5];
            int64_t l_201[2][6][10] = {{{(-1L),1L,1L,0L,(-1L),0x1FC9452628C699EDLL,0x178462E04F2ECF32LL,1L,(-2L),0xC28BBEDE7E56D926LL},{(-2L),0x1703F9351E36C2B6LL,(-6L),0x565C7EDEB1F1A4D4LL,0L,0x1B60A8C9BA8F9786LL,0x1B60A8C9BA8F9786LL,0L,0x565C7EDEB1F1A4D4LL,(-6L)},{0xC28BBEDE7E56D926LL,0xC28BBEDE7E56D926LL,0x2DC662D5AFF6A51DLL,0x55F3680C6D9DE4CBLL,0xF025D12158B1AF39LL,4L,(-1L),(-1L),1L,0x1703F9351E36C2B6LL},{0x178462E04F2ECF32LL,1L,1L,(-2L),4L,0xFA6EFE3CF7B5A891LL,0x565C7EDEB1F1A4D4LL,0x2DC662D5AFF6A51DLL,(-1L),0x1B60A8C9BA8F9786LL},{2L,0x1FC9452628C699EDLL,0x0719000718B624CALL,0xD07C0FF9DDB29366LL,0xA2C154B2775F8867LL,0x0719000718B624CALL,0x2DC662D5AFF6A51DLL,0xAEEF22598743DCC9LL,1L,(-1L)},{1L,0xA2C154B2775F8867LL,0L,1L,0xCB0D776FE5E69E21LL,0x55F3680C6D9DE4CBLL,0xCB0D776FE5E69E21LL,1L,0L,0xA2C154B2775F8867LL}},{{0x3E3C3B741B653921LL,0xFA6EFE3CF7B5A891LL,0x2DC662D5AFF6A51DLL,0xCB0D776FE5E69E21LL,0L,0x4FE3040C694B4B0CLL,0xAEEF22598743DCC9LL,2L,0x4FE3040C694B4B0CLL,(-1L)},{(-1L),0x3E3C3B741B653921LL,0x0719000718B624CALL,(-1L),(-2L),0x4FE3040C694B4B0CLL,(-1L),0x1FC9452628C699EDLL,0L,0x2DC662D5AFF6A51DLL},{0x3E3C3B741B653921LL,0x565C7EDEB1F1A4D4LL,(-1L),0x1FC9452628C699EDLL,1L,0x55F3680C6D9DE4CBLL,0x3E3C3B741B653921LL,1L,0x9BFD98B40E0213BFLL,(-6L)},{1L,0x4FE3040C694B4B0CLL,1L,0x1B60A8C9BA8F9786LL,0x0719000718B624CALL,0x0719000718B624CALL,0x1B60A8C9BA8F9786LL,1L,0x4FE3040C694B4B0CLL,1L},{2L,1L,0L,4L,0x1FC9452628C699EDLL,0xFA6EFE3CF7B5A891LL,0x0719000718B624CALL,(-6L),0x2DC662D5AFF6A51DLL,4L},{0xCB0D776FE5E69E21LL,0x565C7EDEB1F1A4D4LL,0x1703F9351E36C2B6LL,1L,0x1FC9452628C699EDLL,1L,1L,1L,(-1L),1L}}};
            int64_t *l_222 = &l_201[0][5][9];
            int64_t **l_221 = &l_222;
            int i, j, k;
            for (g_77 = 20; (g_77 > (-6)); g_77 = safe_sub_func_uint32_t_u_u(g_77, 7))
            { /* block id: 18 */
                union U0 l_96[9] = {{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L},{0x1AC0EF14L}};
                int i;
                for (g_80 = 0; (g_80 > 2); g_80 = safe_add_func_int16_t_s_s(g_80, 5))
                { /* block id: 21 */
                    const int16_t **l_98 = (void*)0;
                    const int16_t **l_99 = (void*)0;
                    const int16_t *l_101 = &g_102;
                    const int16_t **l_100[3][4] = {{(void*)0,&l_101,&l_101,(void*)0},{&l_101,(void*)0,&l_101,&l_101},{(void*)0,(void*)0,&l_101,(void*)0}};
                    int32_t *l_164 = &l_96[6].f2;
                    int i, j;
                    (*l_164) = func_83(((safe_mul_func_int16_t_s_s(g_61[0][6][6], (-1L))) , (l_91 <= ((l_105 = (safe_mul_func_uint64_t_u_u(18446744073709551607UL, ((l_96[6] , (l_91 , l_97[1])) != (g_103 = l_97[1]))))) != (7L != g_2)))), l_74[4], p_72, l_74[1], l_106[2][3]);
                    return &g_61[0][6][6];
                }
            }
            if ((((safe_rshift_func_int16_t_s_s((0xC7L | (g_167 &= g_2)), (p_72 ^ (((safe_mul_func_int8_t_s_s((safe_div_func_int64_t_s_s((+(l_173[0][1] , (((safe_lshift_func_int8_t_s_u(9L, 1)) <= 0xFEE76F7154ECD3A2LL) < (safe_add_func_int32_t_s_s(((*g_111) = (*g_111)), ((*g_103) && (0x1CL > 1UL))))))), g_102)), p_72)) , l_91) , l_106[2][0])))) >= 4L) , p_72))
            { /* block id: 61 */
                uint8_t *l_184 = &g_134[1][0][5];
                union U0 l_194 = {0x42947B03L};
                for (g_80 = 0; (g_80 <= (-5)); --g_80)
                { /* block id: 64 */
                    int32_t *l_192 = &l_187.f2;
                    l_193 &= ((*l_192) = (p_72 , ((*g_111) = (((*g_150) = (safe_add_func_int16_t_s_s((l_182 == &l_183), (l_184 == &g_134[1][0][5])))) <= (safe_lshift_func_int16_t_s_s((l_187 , (safe_sub_func_uint16_t_u_u(65535UL, (l_173[0][1].f2 = (((l_190 , l_191) == &g_134[0][0][8]) > 4294967291UL))))), 6))))));
                }
                l_193 ^= ((l_194 , (safe_lshift_func_uint16_t_u_u((g_104 == 0x6EL), 1))) < (safe_add_func_int32_t_s_s(l_74[4], ((safe_div_func_uint8_t_u_u(l_201[1][0][0], (safe_lshift_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((*g_150), ((safe_lshift_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((((((safe_mul_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(p_72, ((*g_111) , (safe_add_func_int8_t_s_s(l_187.f0, (*g_150)))))), p_72)) ^ g_151) > 0xCD61EF54L) < p_72) && 0L), l_74[4])), p_72)) , l_218), 7)) && p_72))), 0)))) || p_72))));
            }
            else
            { /* block id: 72 */
                (*g_111) ^= (safe_mod_func_int8_t_s_s(l_74[4], p_72));
            }
            l_187.f0 |= ((p_72 , (l_193 = (-1L))) != (((*l_221) = &l_201[1][5][8]) == &g_159));
            (*g_111) = 0x551DDD8CL;
        }
    }
    else
    { /* block id: 80 */
        (*g_111) |= 0x55FBD205L;
    }
    if ((safe_lshift_func_int16_t_s_s((safe_div_func_int8_t_s_s(((l_237.f0 = (g_227 , (((~(safe_mul_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((((safe_lshift_func_int16_t_s_s((safe_div_func_int16_t_s_s(((l_237 , (*l_182)) == (((*g_111) , ((safe_mod_func_int32_t_s_s((&g_104 != ((((safe_add_func_uint16_t_u_u(l_74[0], (((safe_sub_func_uint8_t_u_u(((7L && ((~((((((safe_sub_func_int8_t_s_s((g_248 &= (l_74[0] && (l_247 == (void*)0))), (*g_150))) | 0xCAL) || p_72) < p_72) <= l_74[5]) | 248UL)) | 0x5A9EE059EF32C187LL)) != (*g_150)), g_112[1])) | p_72) != 0xB58D0A97L))) & l_249[2]) != 6UL) , (void*)0)), p_72)) & 1UL)) , (void*)0)), l_74[5])), 10)) > l_250[6][4][0]) ^ 0x9CBAL), 1UL)), l_249[2]))) != l_251[3][2][2]) , l_250[6][4][0]))) < (*g_111)), p_72)), p_72)))
    { /* block id: 85 */
        int16_t l_274 = (-1L);
        int32_t l_292 = (-7L);
        int32_t l_293 = 0x62374D4AL;
        int32_t l_294[5];
        uint32_t l_298 = 0x1289C799L;
        int32_t *l_307 = &g_227.f2;
        uint16_t *l_349 = &g_268;
        uint64_t *l_373[5][8] = {{&g_374[1],&g_374[1],&g_374[1],&g_374[1],&g_374[1],&g_374[0],(void*)0,&g_374[1]},{&g_374[1],&g_374[1],&g_374[1],(void*)0,&g_374[1],&g_374[1],(void*)0,&g_374[1]},{(void*)0,(void*)0,&g_374[1],&g_374[0],&g_374[3],(void*)0,&g_374[1],(void*)0},{&g_374[3],(void*)0,&g_374[1],(void*)0,&g_374[3],&g_374[1],&g_374[3],(void*)0},{(void*)0,&g_374[1],(void*)0,&g_374[0],&g_374[0],&g_374[1],&g_374[1],&g_374[1]}};
        uint16_t l_432 = 0xE6D6L;
        int32_t l_456 = 4L;
        int i, j;
        for (i = 0; i < 5; i++)
            l_294[i] = 0x9558DB15L;
        for (g_167 = 0; (g_167 < 16); ++g_167)
        { /* block id: 88 */
            union U0 l_262 = {-2L};
            int32_t l_266 = 0xEC7C54E9L;
            int32_t *l_283 = &g_112[0];
            int32_t *l_284 = &g_80;
            int32_t *l_285 = &l_262.f2;
            int32_t *l_286 = &l_237.f2;
            int32_t *l_287 = &l_237.f2;
            int32_t *l_288 = &l_262.f2;
            int32_t *l_289 = (void*)0;
            int32_t *l_290 = &g_112[3];
            int32_t *l_291[8] = {(void*)0,&g_112[3],(void*)0,(void*)0,&g_112[3],(void*)0,(void*)0,&g_112[3]};
            uint16_t *l_350 = (void*)0;
            int i;
            for (g_151 = 0; (g_151 <= 6); g_151 += 1)
            { /* block id: 91 */
                int16_t l_269 = 0x7919L;
                int32_t *l_278[4][6][7] = {{{(void*)0,&g_80,&g_112[3],&g_77,&l_266,&g_2,&g_112[3]},{&g_112[6],&g_112[1],&g_8,&l_266,&g_77,&l_266,&g_112[4]},{&g_112[3],&g_80,(void*)0,&g_112[3],(void*)0,(void*)0,&g_112[3]},{(void*)0,&g_2,&g_80,&g_112[3],&g_80,&g_112[4],(void*)0},{&l_262.f2,&g_112[3],&l_266,&l_266,(void*)0,&g_112[0],&g_112[0]},{&g_77,&l_266,&g_112[1],&l_266,&g_77,&g_112[3],(void*)0}},{{(void*)0,&g_112[3],(void*)0,&g_2,&g_112[3],(void*)0,&g_112[5]},{&g_112[3],&g_112[6],&g_112[3],&g_8,&g_112[3],&g_2,&g_8},{(void*)0,&g_2,(void*)0,&g_112[3],&g_77,&g_77,&g_2},{&g_77,(void*)0,(void*)0,&g_8,&g_8,&g_77,&g_112[5]},{&g_8,(void*)0,(void*)0,(void*)0,&l_266,(void*)0,&g_77},{&g_112[5],(void*)0,(void*)0,&g_80,&l_266,&g_112[1],&g_112[7]}},{{&g_2,&g_2,&g_2,&l_266,&g_8,(void*)0,&g_80},{&g_112[3],&g_77,&g_8,&g_8,&g_77,&g_112[3],&g_8},{(void*)0,&g_80,&g_80,&l_266,&g_112[3],&g_2,&g_77},{&g_112[7],&g_8,&g_2,&g_8,&g_112[3],&l_266,&l_262.f2},{&g_2,&g_80,&g_80,&g_2,&g_77,(void*)0,(void*)0},{&g_112[3],&g_77,&g_77,&g_2,&g_112[5],&g_2,&g_80}},{{&g_112[7],&g_2,(void*)0,&g_2,&g_2,&g_8,&g_2},{&g_2,(void*)0,&g_77,&g_112[3],&l_266,&g_8,&g_112[3]},{&g_8,(void*)0,&g_2,&g_80,&g_112[7],&g_2,&g_77},{&g_2,(void*)0,(void*)0,&l_262.f2,(void*)0,(void*)0,&g_2},{(void*)0,&g_2,&g_2,&g_112[3],(void*)0,&l_266,&g_80},{&g_80,&g_112[6],&g_77,&g_80,&g_112[5],&g_2,&g_112[7]}}};
                int i, j, k;
                for (g_248 = 0; (g_248 <= 6); g_248 += 1)
                { /* block id: 94 */
                    uint8_t *l_263[4][4][5] = {{{&l_250[6][4][0],&g_134[1][0][5],&l_250[4][0][1],&g_134[1][0][5],&l_250[6][4][0]},{&l_250[5][2][3],(void*)0,(void*)0,&l_250[5][2][3],&g_134[1][0][5]},{&l_250[6][4][0],&g_134[1][0][5],&l_250[6][4][0],&l_250[6][3][2],&l_250[6][4][0]},{&l_250[5][2][3],&l_250[5][2][3],&g_134[2][0][2],(void*)0,&g_134[1][0][5]}},{{&l_250[6][4][0],&l_250[6][3][2],&l_250[4][0][1],&l_250[6][3][2],&l_250[6][4][0]},{&g_134[1][0][5],(void*)0,&g_134[2][0][2],&l_250[5][2][3],&l_250[5][2][3]},{&l_250[6][4][0],&l_250[6][3][2],&l_250[6][4][0],&g_134[1][0][5],&l_250[6][4][0]},{&g_134[1][0][5],&l_250[5][2][3],(void*)0,(void*)0,&l_250[5][2][3]}},{{&l_250[6][4][0],&g_134[1][0][5],&l_250[4][0][1],&g_134[1][0][5],&l_250[6][4][0]},{&l_250[5][2][3],(void*)0,(void*)0,&l_250[5][2][3],&g_134[1][0][5]},{&l_250[6][4][0],&g_134[1][0][5],&l_250[6][4][0],&l_250[6][3][2],&l_250[6][4][0]},{&l_250[5][2][3],&l_250[5][2][3],&g_134[2][0][2],(void*)0,&g_134[1][0][5]}},{{&l_250[6][4][0],&l_250[6][3][2],&l_250[4][0][1],&l_250[6][3][2],&l_250[6][4][0]},{&g_134[1][0][5],(void*)0,&g_134[2][0][2],&l_250[5][2][3],&l_250[5][2][3]},{&l_250[6][4][0],&l_250[6][3][2],&l_250[6][4][0],&g_134[1][0][5],&l_250[6][4][0]},{&g_134[1][0][5],&l_250[5][2][3],(void*)0,(void*)0,&l_250[5][2][3]}}};
                    uint16_t *l_267[5][3] = {{&g_268,&g_268,&g_268},{&g_268,&g_268,&g_268},{&g_268,&g_268,&g_268},{&g_268,&g_268,&g_268},{&g_268,&g_268,&g_268}};
                    uint64_t *l_275 = &l_237.f1;
                    int32_t *l_277 = (void*)0;
                    int i, j, k;
                    p_72 = (safe_lshift_func_uint16_t_u_s((safe_add_func_int8_t_s_s((l_74[g_248] | (((g_276[1][2] &= ((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((g_134[1][0][5] = (l_262 , l_74[g_248])), (((((safe_div_func_int64_t_s_s(((g_112[(g_248 + 1)] = (-4L)) ^ p_72), g_61[0][1][2])) == (--g_268)) > (((safe_add_func_uint16_t_u_u((g_151 , g_61[0][3][6]), l_251[6][3][1])) >= 0x3036L) == (*g_150))) , g_227) , l_274))), g_77)) > 0x003B070FL)) && 18446744073709551608UL) && 0x95B3EF35L)), 0x83L)), p_72));
                    (*g_111) = (*g_111);
                }
                ++l_279;
                if (l_74[g_151])
                    continue;
                (*g_111) = (~g_248);
            }
            l_298--;
        }
        (*l_307) = 0x739B65AEL;
        for (g_167 = 2; (g_167 < 22); g_167 = safe_add_func_int64_t_s_s(g_167, 9))
        { /* block id: 167 */
            int32_t l_386 = 0xE92700A7L;
            int32_t l_390 = (-1L);
            int32_t l_394[1];
            int16_t l_431 = 4L;
            uint16_t * const *l_448 = &g_447;
            int64_t l_450 = 0xD6C0E96209E92086LL;
            int i;
            for (i = 0; i < 1; i++)
                l_394[i] = 0x1838A191L;
            for (g_227.f2 = 0; (g_227.f2 >= 0); g_227.f2 -= 1)
            { /* block id: 170 */
                int32_t *l_378 = &l_293;
                int32_t l_385 = (-4L);
                int32_t l_392 = 0xA06170D6L;
                int32_t l_395 = 0x19ED1BD9L;
                int32_t l_396 = 9L;
                int16_t **l_421 = &g_419;
                int32_t l_451 = 0xB3311D27L;
                int32_t l_453 = 1L;
                int32_t l_454 = (-1L);
                int32_t l_455 = 0xBCD65B9FL;
                int32_t l_457[10][5][5] = {{{(-6L),(-6L),0x8E34C7ABL,(-6L),(-6L)},{0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL,1L},{(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL},{1L,1L,0x2B233BFEL,1L,1L},{0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L)}},{{1L,0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL},{(-6L),(-6L),0x8E34C7ABL,(-6L),(-6L)},{0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL,1L},{(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL},{1L,1L,0x2B233BFEL,1L,1L}},{{0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L)},{1L,0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL},{(-6L),(-6L),0x8E34C7ABL,(-6L),(-6L)},{0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL,1L},{(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL}},{{1L,1L,0x2B233BFEL,1L,1L},{0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L)},{1L,0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL},{(-6L),(-6L),0x8E34C7ABL,(-6L),(-6L)},{0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL,1L}},{{(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL},{1L,1L,0x2B233BFEL,1L,1L},{0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L)},{1L,0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL},{(-6L),(-6L),0x8E34C7ABL,(-6L),(-6L)}},{{0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL,1L},{(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL},{1L,1L,0x2B233BFEL,1L,1L},{0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL,(-6L)},{1L,0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL}},{{(-6L),0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL},{0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL},{0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL},{0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL},{0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL}},{{0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL},{0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL},{0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL},{0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL},{0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL}},{{0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL},{0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL},{0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL},{0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL},{0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL}},{{0xB2F9EC9FL,0xB2F9EC9FL,1L,0xB2F9EC9FL,0xB2F9EC9FL},{0x8E34C7ABL,0x8FB27FCAL,0x8E34C7ABL,0x8E34C7ABL,0x8FB27FCAL},{0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL},{0x8FB27FCAL,0x8FB27FCAL,(-6L),0x8FB27FCAL,0x8FB27FCAL},{0x2B233BFEL,0xB2F9EC9FL,0x2B233BFEL,0x2B233BFEL,0xB2F9EC9FL}}};
                int i, j, k;
                (*l_378) |= ((*g_111) &= p_72);
                (*l_378) = p_72;
                if ((*g_111))
                    continue;
                for (g_159 = 3; (g_159 >= 0); g_159 -= 1)
                { /* block id: 177 */
                    int16_t l_387 = 0xFCC4L;
                    int32_t l_388 = (-1L);
                    int32_t l_389 = (-1L);
                    int16_t l_391 = (-1L);
                    int32_t l_393 = 0xD2959398L;
                    int32_t l_397[3][10] = {{0x78D34727L,0x1D270B96L,0x1D270B96L,0x78D34727L,(-5L),6L,0x78D34727L,6L,(-5L),0x78D34727L},{6L,0x78D34727L,6L,(-5L),0x78D34727L,0x1D270B96L,0x1D270B96L,0x78D34727L,(-5L),6L},{0x516D3911L,0x516D3911L,7L,0x78D34727L,0x7F8E9E42L,7L,0x7F8E9E42L,0x78D34727L,7L,0x516D3911L}};
                    int64_t * const l_417 = &l_249[2];
                    uint16_t **l_444 = &l_349;
                    int64_t l_452[8][7][4] = {{{8L,0x10481290319C4D52LL,(-1L),8L},{(-1L),8L,(-8L),(-8L)},{0x4ADC3DF89C71296ELL,0x4ADC3DF89C71296ELL,2L,0x2201460715C58B04LL},{0x4ADC3DF89C71296ELL,0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL},{(-1L),0x2201460715C58B04LL,(-1L),(-8L)},{8L,0x2201460715C58B04LL,2L,0x4ADC3DF89C71296ELL},{0x2201460715C58B04LL,0x10481290319C4D52LL,0x10481290319C4D52LL,0x2201460715C58B04LL}},{{(-1L),0x4ADC3DF89C71296ELL,0x10481290319C4D52LL,(-8L)},{0x2201460715C58B04LL,8L,2L,8L},{8L,0x10481290319C4D52LL,(-1L),8L},{(-1L),8L,(-8L),(-8L)},{0x4ADC3DF89C71296ELL,0x4ADC3DF89C71296ELL,2L,0x2201460715C58B04LL},{0x4ADC3DF89C71296ELL,0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL},{(-1L),0x2201460715C58B04LL,(-1L),(-8L)}},{{8L,0x2201460715C58B04LL,2L,0x4ADC3DF89C71296ELL},{0x2201460715C58B04LL,0x10481290319C4D52LL,2L,0x10481290319C4D52LL},{0x841020F4F2EF531ALL,(-1L),2L,0x9BFE476B1B15B435LL},{0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL,(-8L)},{(-8L),2L,0x841020F4F2EF531ALL,(-8L)},{0x841020F4F2EF531ALL,(-8L),0x9BFE476B1B15B435LL,0x9BFE476B1B15B435LL},{(-1L),(-1L),0x4ADC3DF89C71296ELL,0x10481290319C4D52LL}},{{(-1L),2L,0x9BFE476B1B15B435LL,(-1L)},{0x841020F4F2EF531ALL,0x10481290319C4D52LL,0x841020F4F2EF531ALL,0x9BFE476B1B15B435LL},{(-8L),0x10481290319C4D52LL,0x4ADC3DF89C71296ELL,(-1L)},{0x10481290319C4D52LL,2L,2L,0x10481290319C4D52LL},{0x841020F4F2EF531ALL,(-1L),2L,0x9BFE476B1B15B435LL},{0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL,(-8L)},{(-8L),2L,0x841020F4F2EF531ALL,(-8L)}},{{0x841020F4F2EF531ALL,(-8L),0x9BFE476B1B15B435LL,0x9BFE476B1B15B435LL},{(-1L),(-1L),0x4ADC3DF89C71296ELL,0x10481290319C4D52LL},{(-1L),2L,0x9BFE476B1B15B435LL,(-1L)},{0x841020F4F2EF531ALL,0x10481290319C4D52LL,0x841020F4F2EF531ALL,0x9BFE476B1B15B435LL},{(-8L),0x10481290319C4D52LL,0x4ADC3DF89C71296ELL,(-1L)},{0x10481290319C4D52LL,2L,2L,0x10481290319C4D52LL},{0x841020F4F2EF531ALL,(-1L),2L,0x9BFE476B1B15B435LL}},{{0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL,(-8L)},{(-8L),2L,0x841020F4F2EF531ALL,(-8L)},{0x841020F4F2EF531ALL,(-8L),0x9BFE476B1B15B435LL,0x9BFE476B1B15B435LL},{(-1L),(-1L),0x4ADC3DF89C71296ELL,0x10481290319C4D52LL},{(-1L),2L,0x9BFE476B1B15B435LL,(-1L)},{0x841020F4F2EF531ALL,0x10481290319C4D52LL,0x841020F4F2EF531ALL,0x9BFE476B1B15B435LL},{(-8L),0x10481290319C4D52LL,0x4ADC3DF89C71296ELL,(-1L)}},{{0x10481290319C4D52LL,2L,2L,0x10481290319C4D52LL},{0x841020F4F2EF531ALL,(-1L),2L,0x9BFE476B1B15B435LL},{0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL,(-8L)},{(-8L),2L,0x841020F4F2EF531ALL,(-8L)},{0x841020F4F2EF531ALL,(-8L),0x9BFE476B1B15B435LL,0x9BFE476B1B15B435LL},{(-1L),(-1L),0x4ADC3DF89C71296ELL,0x10481290319C4D52LL},{(-1L),2L,0x9BFE476B1B15B435LL,(-1L)}},{{0x841020F4F2EF531ALL,0x10481290319C4D52LL,0x841020F4F2EF531ALL,0x9BFE476B1B15B435LL},{(-8L),0x10481290319C4D52LL,0x4ADC3DF89C71296ELL,(-1L)},{0x10481290319C4D52LL,2L,2L,0x10481290319C4D52LL},{0x841020F4F2EF531ALL,(-1L),2L,0x9BFE476B1B15B435LL},{0x10481290319C4D52LL,(-8L),0x4ADC3DF89C71296ELL,(-8L)},{(-8L),2L,0x841020F4F2EF531ALL,(-8L)},{0x841020F4F2EF531ALL,(-8L),0x9BFE476B1B15B435LL,0x9BFE476B1B15B435LL}}};
                    int64_t l_458[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                    uint64_t l_460 = 0xCE8A771857507327LL;
                    int i, j, k;
                    for (l_298 = 0; (l_298 <= 3); l_298 += 1)
                    { /* block id: 180 */
                        int32_t *l_379 = &l_294[0];
                        int32_t *l_380 = &g_77;
                        int32_t *l_381 = (void*)0;
                        int32_t *l_382 = (void*)0;
                        int32_t *l_383 = &l_237.f2;
                        int32_t *l_384[2];
                        uint8_t l_398 = 255UL;
                        int32_t **l_401 = (void*)0;
                        int32_t **l_402 = (void*)0;
                        int32_t **l_403 = &l_381;
                        int16_t ***l_420 = &g_418;
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_384[i] = &l_237.f2;
                        ++l_398;
                        (*l_403) = &g_77;
                        p_72 = g_134[(g_227.f2 + 2)][g_227.f2][(l_298 + 5)];
                        (*l_378) = (((+(l_397[1][6] &= (safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(l_250[(g_159 + 1)][(g_227.f2 + 2)][g_159], (((safe_lshift_func_int8_t_s_s(((safe_add_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((l_417 == ((((*g_150) <= (((*l_420) = g_418) == l_421)) , 0xCC75241BL) , l_417)), 2)), (safe_mod_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(l_251[3][0][2], (*g_150))), l_391)))), 3L)) & p_72), p_72)) <= 0L) & (*l_378)))), 6)))) || 255UL) > (*l_378));
                    }
                    for (g_77 = 0; (g_77 >= 0); g_77 -= 1)
                    { /* block id: 190 */
                        int32_t *l_426 = &l_292;
                        int32_t *l_427 = (void*)0;
                        int32_t *l_428 = &l_295[5][6];
                        int32_t *l_429 = &l_295[0][3];
                        int32_t *l_430[9][4] = {{&l_395,&l_385,&l_394[0],(void*)0},{&l_389,&g_2,&l_395,&g_2},{&l_396,&l_292,&l_292,&l_394[0]},{&g_112[3],(void*)0,&l_389,&g_77},{&l_385,(void*)0,&l_389,&l_395},{&g_2,(void*)0,&g_2,&g_2},{&l_395,&l_395,(void*)0,&l_390},{&l_292,(void*)0,&l_292,&l_394[0]},{&g_2,(void*)0,&g_77,&l_292}};
                        int i, j;
                        l_432--;
                    }
                    for (l_389 = 3; (l_389 >= 0); l_389 -= 1)
                    { /* block id: 195 */
                        uint16_t ***l_445[2];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_445[i] = (void*)0;
                        if (l_432)
                            goto lbl_435;
                        (*g_111) ^= (safe_lshift_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u((g_134[(g_227.f2 + 2)][g_227.f2][(g_159 + 5)] < ((safe_mul_func_int8_t_s_s((&g_159 == (void*)0), g_134[g_227.f2][g_227.f2][g_227.f2])) == l_250[(l_389 + 2)][(g_227.f2 + 6)][g_227.f2])), ((g_446 = l_444) != l_448))) , 1UL), 3));
                        return (*g_418);
                    }
                    (*g_111) = p_72;
                    for (p_72 = 0; (p_72 >= 0); p_72 -= 1)
                    { /* block id: 204 */
                        int32_t *l_449[6][9] = {{(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0]},{&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388},{(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0]},{&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388},{(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0],(void*)0,&l_394[0],&l_394[0]},{&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388,&l_397[1][5],&l_388,&l_388}};
                        int32_t l_459 = (-1L);
                        int i, j;
                        l_460++;
                        (*g_111) ^= (safe_lshift_func_uint16_t_u_s((*g_447), 11));
                    }
                }
            }
        }
        for (g_80 = 0; (g_80 == (-11)); g_80 = safe_sub_func_uint32_t_u_u(g_80, 6))
        { /* block id: 213 */
            union U0 *l_467 = &g_227;
            int32_t **l_472[9];
            int i;
            for (i = 0; i < 9; i++)
                l_472[i] = &g_111;
            l_467 = &l_237;
            for (l_297 = 0; (l_297 > (-11)); l_297--)
            { /* block id: 217 */
                int32_t *l_470 = (void*)0;
                (*l_307) |= 1L;
                l_470 = (void*)0;
                (*g_111) ^= (l_471[5] == l_472[6]);
            }
        }
    }
    else
    { /* block id: 223 */
        int8_t l_504 = 0x54L;
        int32_t l_515 = 0xB80C791EL;
        uint32_t l_516 = 0x64E88CF0L;
        for (g_227.f2 = (-28); (g_227.f2 == (-17)); g_227.f2++)
        { /* block id: 226 */
            for (g_80 = 0; (g_80 == (-15)); g_80 = safe_sub_func_int64_t_s_s(g_80, 1))
            { /* block id: 229 */
                if (g_227.f0)
                    goto lbl_435;
            }
            (*g_111) ^= 0L;
        }
        for (g_296 = 0; (g_296 <= 2); g_296 += 1)
        { /* block id: 236 */
            union U0 *l_485 = &g_227;
            union U0 **l_486 = (void*)0;
            union U0 **l_487[5] = {&l_485,&l_485,&l_485,&l_485,&l_485};
            int8_t *l_501 = &g_248;
            int8_t *l_502 = &g_503;
            int64_t *l_505 = &l_249[2];
            uint32_t *l_506 = &l_343[3][4][0];
            int32_t l_507 = 0x11764A40L;
            int16_t ***l_571 = &g_418;
            int32_t l_584 = 0x338F54AFL;
            uint16_t l_585 = 0x1C46L;
            union U0 * const l_616 = &g_617[0];
            union U0 * const *l_615 = &l_616;
            int i;
            (*g_111) = ((l_507 |= ((*l_506) &= ((safe_rshift_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((((safe_rshift_func_int8_t_s_u(p_72, ((l_488 = l_485) != (void*)0))) > (-1L)) , (**g_446)), (p_72 , (safe_lshift_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u((*g_150), ((safe_div_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_u((((*l_505) |= (safe_div_func_uint32_t_u_u((((safe_mul_func_int8_t_s_s(((*l_502) |= ((*l_501) ^= (-1L))), ((((l_504 < 1UL) , 0x28L) || p_72) , p_72))) == g_163) <= p_72), 0x3DD0CF83L))) && g_61[0][3][6]), p_72)) && l_504), 18446744073709551614UL)) >= 0x1FF991B0196139EDLL))) > 0L), 1))))), 0xD12CL)), 5)) , 3UL))) , l_504);
            p_72 = (safe_mod_func_uint8_t_u_u((+((((safe_mul_func_uint8_t_u_u(0xFFL, (l_505 == &g_374[1]))) & p_72) , (g_167 <= (p_72 != (((*g_446) = (*g_446)) == ((safe_sub_func_uint8_t_u_u((((p_72 >= (&g_2 != (void*)0)) > 0xF4BCL) > 9UL), 0xF9L)) , l_183))))) & p_72)), l_507));
            l_515 |= p_72;
        }
    }
    return (*g_418);
}


/* ------------------------------------------ */
/* 
 * reads : g_112 g_134 g_77 g_80 g_150 g_102 g_2 g_103 g_61
 * writes: g_111 g_134 g_159 g_163 g_112
 */
static int32_t  func_83(int32_t  p_84, uint64_t  p_85, uint64_t  p_86, const uint64_t  p_87, int32_t  p_88)
{ /* block id: 24 */
    int32_t *l_109 = &g_77;
    int32_t *l_118 = &g_112[3];
    int32_t l_122 = 0L;
    int32_t l_123 = 0x1814A667L;
    uint16_t l_124 = 8UL;
    uint8_t *l_133[10];
    int64_t *l_158 = &g_159;
    const uint64_t l_160 = 0x9A98420A5A07D037LL;
    uint8_t *l_161[6][9] = {{&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151},{&g_151,&g_151,&g_151,&g_151,&g_151,(void*)0,&g_151,&g_151,&g_151},{&g_151,&g_151,(void*)0,&g_151,&g_151,(void*)0,&g_151,&g_151,&g_151},{&g_151,&g_151,&g_151,&g_151,&g_151,(void*)0,&g_151,&g_151,(void*)0},{&g_151,&g_151,&g_151,&g_151,&g_151,(void*)0,&g_151,&g_151,&g_151},{&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151,&g_151}};
    uint32_t *l_162 = &g_163;
    int i, j;
    for (i = 0; i < 10; i++)
        l_133[i] = &g_134[1][0][5];
    for (p_86 = 0; (p_86 >= 57); p_86 = safe_add_func_int8_t_s_s(p_86, 3))
    { /* block id: 27 */
        int32_t **l_110 = (void*)0;
        int32_t **l_113 = &l_109;
        (*l_113) = (g_111 = l_109);
        if (p_88)
            continue;
        for (p_85 = 0; (p_85 != 14); ++p_85)
        { /* block id: 33 */
            if (p_85)
                break;
            for (p_88 = 0; (p_88 <= (-8)); p_88--)
            { /* block id: 37 */
                (*l_113) = l_118;
            }
            return p_84;
        }
        (*l_113) = &p_88;
    }
    for (p_85 = 0; (p_85 == 56); p_85 = safe_add_func_uint8_t_u_u(p_85, 1))
    { /* block id: 46 */
        int32_t *l_121[4][8] = {{&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8},{&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8},{&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8},{&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8,&g_112[3],&g_8}};
        int i, j;
        --l_124;
    }
    (*l_118) = (safe_mul_func_uint8_t_u_u((*l_118), (((*l_162) = (0UL && ((safe_mod_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_u((g_134[2][0][7]++), g_112[3])) < (safe_mod_func_uint32_t_u_u((safe_div_func_int16_t_s_s((1L | (((!(safe_rshift_func_int8_t_s_u((((*l_109) || (((safe_add_func_int64_t_s_s((safe_div_func_int8_t_s_s((safe_rshift_func_int8_t_s_u(g_80, ((l_133[9] = g_150) == ((safe_mod_func_int16_t_s_s(((safe_sub_func_int64_t_s_s(((*l_158) = ((((safe_div_func_int64_t_s_s(g_102, 0x260E86605BB6F065LL)) | p_87) < (*l_118)) <= g_2)), 0x484500A6B561C9B0LL)) , l_160), 0x8E35L)) , l_161[5][1])))), (*l_109))), 1UL)) && (*l_109)) != 1UL)) || (*l_118)), p_85))) && (-4L)) < 0xB63EL)), g_112[8])), p_85))), (*g_103))) || 0xF02C85B7L))) , p_87)));
    return p_84;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_61[i][j][k], "g_61[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_112[i], "g_112[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_134[i][j][k], "g_134[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_167, "g_167", print_hash_value);
    transparent_crc(g_227.f0, "g_227.f0", print_hash_value);
    transparent_crc(g_248, "g_248", print_hash_value);
    transparent_crc(g_268, "g_268", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_276[i][j], "g_276[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_296, "g_296", print_hash_value);
    transparent_crc(g_314, "g_314", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_374[i], "g_374[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_503, "g_503", print_hash_value);
    transparent_crc(g_540, "g_540", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_617[i].f0, "g_617[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_743, "g_743", print_hash_value);
    transparent_crc(g_843, "g_843", print_hash_value);
    transparent_crc(g_886.f0, "g_886.f0", print_hash_value);
    transparent_crc(g_886.f2, "g_886.f2", print_hash_value);
    transparent_crc(g_892.f0, "g_892.f0", print_hash_value);
    transparent_crc(g_892.f2, "g_892.f2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_893[i][j].f0, "g_893[i][j].f0", print_hash_value);
            transparent_crc(g_893[i][j].f2, "g_893[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_894[i][j].f0, "g_894[i][j].f0", print_hash_value);
            transparent_crc(g_894[i][j].f2, "g_894[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_895.f0, "g_895.f0", print_hash_value);
    transparent_crc(g_895.f2, "g_895.f2", print_hash_value);
    transparent_crc(g_896.f0, "g_896.f0", print_hash_value);
    transparent_crc(g_896.f2, "g_896.f2", print_hash_value);
    transparent_crc(g_897.f0, "g_897.f0", print_hash_value);
    transparent_crc(g_897.f2, "g_897.f2", print_hash_value);
    transparent_crc(g_898.f0, "g_898.f0", print_hash_value);
    transparent_crc(g_898.f2, "g_898.f2", print_hash_value);
    transparent_crc(g_899.f0, "g_899.f0", print_hash_value);
    transparent_crc(g_899.f2, "g_899.f2", print_hash_value);
    transparent_crc(g_900.f0, "g_900.f0", print_hash_value);
    transparent_crc(g_900.f2, "g_900.f2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_901[i].f0, "g_901[i].f0", print_hash_value);
        transparent_crc(g_901[i].f2, "g_901[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_902.f0, "g_902.f0", print_hash_value);
    transparent_crc(g_902.f2, "g_902.f2", print_hash_value);
    transparent_crc(g_903.f0, "g_903.f0", print_hash_value);
    transparent_crc(g_903.f2, "g_903.f2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_904[i][j].f0, "g_904[i][j].f0", print_hash_value);
            transparent_crc(g_904[i][j].f2, "g_904[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_905[i][j].f0, "g_905[i][j].f0", print_hash_value);
            transparent_crc(g_905[i][j].f2, "g_905[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_906.f0, "g_906.f0", print_hash_value);
    transparent_crc(g_906.f2, "g_906.f2", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_907[i].f0, "g_907[i].f0", print_hash_value);
        transparent_crc(g_907[i].f2, "g_907[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_908.f0, "g_908.f0", print_hash_value);
    transparent_crc(g_908.f2, "g_908.f2", print_hash_value);
    transparent_crc(g_955, "g_955", print_hash_value);
    transparent_crc(g_992, "g_992", print_hash_value);
    transparent_crc(g_1102, "g_1102", print_hash_value);
    transparent_crc(g_1130.f0, "g_1130.f0", print_hash_value);
    transparent_crc(g_1130.f2, "g_1130.f2", print_hash_value);
    transparent_crc(g_1130.f3, "g_1130.f3", print_hash_value);
    transparent_crc(g_1190.f0, "g_1190.f0", print_hash_value);
    transparent_crc(g_1190.f2, "g_1190.f2", print_hash_value);
    transparent_crc(g_1207, "g_1207", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1230[i][j][k], "g_1230[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1273[i], "g_1273[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1290.f0, "g_1290.f0", print_hash_value);
    transparent_crc(g_1290.f2, "g_1290.f2", print_hash_value);
    transparent_crc(g_1290.f3, "g_1290.f3", print_hash_value);
    transparent_crc(g_1305, "g_1305", print_hash_value);
    transparent_crc(g_1309.f0, "g_1309.f0", print_hash_value);
    transparent_crc(g_1309.f2, "g_1309.f2", print_hash_value);
    transparent_crc(g_1309.f3, "g_1309.f3", print_hash_value);
    transparent_crc(g_1354, "g_1354", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1401[i].f0, "g_1401[i].f0", print_hash_value);
        transparent_crc(g_1401[i].f2, "g_1401[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1403[i][j].f0, "g_1403[i][j].f0", print_hash_value);
            transparent_crc(g_1403[i][j].f2, "g_1403[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1521, "g_1521", print_hash_value);
    transparent_crc(g_1638, "g_1638", print_hash_value);
    transparent_crc(g_1782.f0, "g_1782.f0", print_hash_value);
    transparent_crc(g_1782.f2, "g_1782.f2", print_hash_value);
    transparent_crc(g_1782.f3, "g_1782.f3", print_hash_value);
    transparent_crc(g_1787.f0, "g_1787.f0", print_hash_value);
    transparent_crc(g_1787.f2, "g_1787.f2", print_hash_value);
    transparent_crc(g_1787.f3, "g_1787.f3", print_hash_value);
    transparent_crc(g_1800.f0, "g_1800.f0", print_hash_value);
    transparent_crc(g_1800.f2, "g_1800.f2", print_hash_value);
    transparent_crc(g_1800.f3, "g_1800.f3", print_hash_value);
    transparent_crc(g_1801.f0, "g_1801.f0", print_hash_value);
    transparent_crc(g_1801.f2, "g_1801.f2", print_hash_value);
    transparent_crc(g_1801.f3, "g_1801.f3", print_hash_value);
    transparent_crc(g_1802.f0, "g_1802.f0", print_hash_value);
    transparent_crc(g_1802.f2, "g_1802.f2", print_hash_value);
    transparent_crc(g_1802.f3, "g_1802.f3", print_hash_value);
    transparent_crc(g_1803.f0, "g_1803.f0", print_hash_value);
    transparent_crc(g_1803.f2, "g_1803.f2", print_hash_value);
    transparent_crc(g_1803.f3, "g_1803.f3", print_hash_value);
    transparent_crc(g_1804.f0, "g_1804.f0", print_hash_value);
    transparent_crc(g_1804.f2, "g_1804.f2", print_hash_value);
    transparent_crc(g_1804.f3, "g_1804.f3", print_hash_value);
    transparent_crc(g_1805.f0, "g_1805.f0", print_hash_value);
    transparent_crc(g_1805.f2, "g_1805.f2", print_hash_value);
    transparent_crc(g_1805.f3, "g_1805.f3", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1806[i].f0, "g_1806[i].f0", print_hash_value);
        transparent_crc(g_1806[i].f2, "g_1806[i].f2", print_hash_value);
        transparent_crc(g_1806[i].f3, "g_1806[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1832.f0, "g_1832.f0", print_hash_value);
    transparent_crc(g_1832.f2, "g_1832.f2", print_hash_value);
    transparent_crc(g_1869, "g_1869", print_hash_value);
    transparent_crc(g_1997.f0, "g_1997.f0", print_hash_value);
    transparent_crc(g_1997.f2, "g_1997.f2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1998[i][j][k].f0, "g_1998[i][j][k].f0", print_hash_value);
                transparent_crc(g_1998[i][j][k].f2, "g_1998[i][j][k].f2", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1999.f0, "g_1999.f0", print_hash_value);
    transparent_crc(g_1999.f2, "g_1999.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2000[i].f0, "g_2000[i].f0", print_hash_value);
        transparent_crc(g_2000[i].f2, "g_2000[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2029, "g_2029", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2046[i], "g_2046[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2148, "g_2148", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2149[i], "g_2149[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2278.f0, "g_2278.f0", print_hash_value);
    transparent_crc(g_2278.f2, "g_2278.f2", print_hash_value);
    transparent_crc(g_2329, "g_2329", print_hash_value);
    transparent_crc(g_2364, "g_2364", print_hash_value);
    transparent_crc(g_2409.f0, "g_2409.f0", print_hash_value);
    transparent_crc(g_2409.f2, "g_2409.f2", print_hash_value);
    transparent_crc(g_2457, "g_2457", print_hash_value);
    transparent_crc(g_2482.f0, "g_2482.f0", print_hash_value);
    transparent_crc(g_2482.f2, "g_2482.f2", print_hash_value);
    transparent_crc(g_2482.f3, "g_2482.f3", print_hash_value);
    transparent_crc(g_2500, "g_2500", print_hash_value);
    transparent_crc(g_2541.f0, "g_2541.f0", print_hash_value);
    transparent_crc(g_2541.f2, "g_2541.f2", print_hash_value);
    transparent_crc(g_2541.f3, "g_2541.f3", print_hash_value);
    transparent_crc(g_2567.f0, "g_2567.f0", print_hash_value);
    transparent_crc(g_2567.f2, "g_2567.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 629
XXX total union variables: 29

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 41
breakdown:
   indirect level: 0, occurrence: 24
   indirect level: 1, occurrence: 10
   indirect level: 2, occurrence: 4
   indirect level: 3, occurrence: 3
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 19
XXX times a bitfields struct on LHS: 2
XXX times a bitfields struct on RHS: 47
XXX times a single bitfield on LHS: 8
XXX times a single bitfield on RHS: 56

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 289
   depth: 2, occurrence: 82
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 3
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 3
   depth: 18, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 3
   depth: 21, occurrence: 4
   depth: 22, occurrence: 1
   depth: 23, occurrence: 4
   depth: 24, occurrence: 5
   depth: 25, occurrence: 1
   depth: 26, occurrence: 3
   depth: 27, occurrence: 3
   depth: 28, occurrence: 2
   depth: 29, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 3
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 40, occurrence: 2
   depth: 41, occurrence: 2

XXX total number of pointers: 449

XXX times a variable address is taken: 1307
XXX times a pointer is dereferenced on RHS: 310
breakdown:
   depth: 1, occurrence: 264
   depth: 2, occurrence: 40
   depth: 3, occurrence: 6
XXX times a pointer is dereferenced on LHS: 321
breakdown:
   depth: 1, occurrence: 292
   depth: 2, occurrence: 24
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 15
XXX times a pointer is compared with another pointer: 7
XXX times a pointer is qualified to be dereferenced: 9380

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1257
   level: 2, occurrence: 267
   level: 3, occurrence: 129
   level: 4, occurrence: 21
   level: 5, occurrence: 1
XXX number of pointers point to pointers: 166
XXX number of pointers point to scalars: 256
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.7
XXX average alias set size: 1.76

XXX times a non-volatile is read: 2013
XXX times a non-volatile is write: 1002
XXX times a volatile is read: 44
XXX    times read thru a pointer: 14
XXX times a volatile is write: 25
XXX    times written thru a pointer: 12
XXX times a volatile is available for access: 2.18e+03
XXX percentage of non-volatile access: 97.8

XXX forward jumps: 2
XXX backward jumps: 6

XXX stmts: 297
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 34
   depth: 2, occurrence: 52
   depth: 3, occurrence: 52
   depth: 4, occurrence: 60
   depth: 5, occurrence: 74

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

