/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      450808052
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint32_t  f0;
};

union U1 {
   volatile int32_t  f0;
   volatile int32_t  f1;
   const volatile int32_t  f2;
   uint32_t  f3;
   uint32_t  f4;
};

union U2 {
   int8_t * f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2[1] = {0x8C66F5A9L};
static volatile int32_t g_6 = 0x8E17B844L;/* VOLATILE GLOBAL g_6 */
static int32_t g_7[3][9] = {{0L,0L,0L,0L,0L,0L,0L,0L,0L},{(-7L),(-7L),0x9AAED6B6L,(-7L),(-7L),0x9AAED6B6L,(-7L),(-7L),0x9AAED6B6L},{0L,0L,0L,0L,0L,0L,0L,0L,0L}};
static volatile int32_t g_8 = 0xC3203BD6L;/* VOLATILE GLOBAL g_8 */
static volatile int32_t g_9 = (-2L);/* VOLATILE GLOBAL g_9 */
static int32_t g_10 = 0x531D14CDL;
static int32_t g_12 = 0x5A3D7F19L;
static int32_t g_31 = 0x4B1C2FBFL;
static volatile int64_t g_32[7] = {0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL,0x84A8988ED9E8BD61LL};
static volatile uint32_t g_34 = 18446744073709551610UL;/* VOLATILE GLOBAL g_34 */
static volatile uint16_t g_49[3][4] = {{0x332FL,1UL,0x332FL,1UL},{0x332FL,1UL,0x332FL,1UL},{0x332FL,1UL,0x332FL,1UL}};
static int32_t g_70 = 0xE9D6A361L;
static const int8_t g_92 = 0L;
static uint32_t g_98 = 1UL;
static uint16_t g_104 = 4UL;
static union U1 g_127[3] = {{1L},{1L},{1L}};
static int32_t g_130 = 1L;
static int8_t g_134 = 1L;
static volatile int64_t g_141 = 0x4D6DA33BDD32EFA2LL;/* VOLATILE GLOBAL g_141 */
static uint8_t g_142[6] = {0x94L,0x94L,0x94L,0x94L,0x94L,0x94L};
static int8_t *g_146 = &g_134;
static int8_t *g_147 = &g_134;
static int32_t *g_150 = (void*)0;
static int32_t ** const  volatile g_149 = &g_150;/* VOLATILE GLOBAL g_149 */
static volatile int32_t g_155 = 0x9DADCB93L;/* VOLATILE GLOBAL g_155 */
static volatile int64_t g_156 = 0xFB666E4592D3BF73LL;/* VOLATILE GLOBAL g_156 */
static uint64_t g_157 = 18446744073709551606UL;
static volatile union U1 g_170 = {-6L};/* VOLATILE GLOBAL g_170 */
static int64_t g_194 = 0x0CEB8E079F33D5E5LL;
static int16_t g_197 = (-3L);
static int16_t g_199 = 0x0E7BL;
static int64_t g_201 = 0x311A1F4821EC3EBDLL;
static volatile uint32_t g_260 = 4294967288UL;/* VOLATILE GLOBAL g_260 */
static const volatile int8_t g_281 = 0xB4L;/* VOLATILE GLOBAL g_281 */
static const volatile int8_t * volatile g_280[2][10] = {{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281},{&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281}};
static uint64_t g_282 = 0xF018AFD80ED765B6LL;
static int64_t g_289 = 4L;
static const volatile union U0 g_299 = {0UL};/* VOLATILE GLOBAL g_299 */
static volatile uint64_t g_347 = 18446744073709551606UL;/* VOLATILE GLOBAL g_347 */
static union U0 g_362[7] = {{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL},{4294967295UL}};
static int32_t *g_371 = &g_12;
static uint32_t g_374 = 0xAC2437B8L;
static int32_t g_375 = 0x4AA67286L;
static const volatile int64_t g_426 = 0x250AC2C4CDDD93D2LL;/* VOLATILE GLOBAL g_426 */
static volatile union U0 g_448 = {1UL};/* VOLATILE GLOBAL g_448 */
static union U2 g_449 = {0};
static uint16_t *g_452 = (void*)0;
static uint16_t **g_451 = &g_452;
static uint16_t ***g_450 = &g_451;
static union U2 g_454 = {0};
static uint64_t **g_459 = (void*)0;
static int32_t ** volatile g_461[2][5][10] = {{{&g_150,(void*)0,(void*)0,(void*)0,&g_150,&g_371,&g_150,&g_371,&g_150,(void*)0},{&g_150,(void*)0,(void*)0,&g_371,&g_150,&g_371,(void*)0,(void*)0,&g_150,(void*)0},{&g_150,&g_371,&g_150,&g_371,&g_150,(void*)0,(void*)0,(void*)0,&g_150,&g_371},{(void*)0,(void*)0,(void*)0,&g_371,(void*)0,(void*)0,&g_150,&g_150,&g_150,&g_150},{(void*)0,(void*)0,&g_150,&g_371,&g_150,(void*)0,(void*)0,&g_150,&g_150,(void*)0}},{{&g_150,&g_150,(void*)0,(void*)0,&g_150,&g_371,&g_150,(void*)0,(void*)0,&g_150},{&g_150,&g_150,&g_150,(void*)0,(void*)0,&g_371,(void*)0,(void*)0,(void*)0,&g_371},{&g_150,(void*)0,(void*)0,(void*)0,&g_150,&g_371,&g_150,&g_371,&g_150,(void*)0},{&g_150,(void*)0,(void*)0,&g_371,&g_150,&g_371,(void*)0,(void*)0,&g_150,(void*)0},{&g_150,&g_371,&g_150,&g_371,&g_150,(void*)0,(void*)0,(void*)0,&g_150,&g_371}}};
static int32_t ** volatile g_463[5] = {&g_150,&g_150,&g_150,&g_150,&g_150};
static int32_t ** volatile g_464 = &g_371;/* VOLATILE GLOBAL g_464 */
static int32_t * const g_478 = &g_130;
static int32_t * const *g_477 = &g_478;
static int8_t g_499 = (-1L);
static volatile union U0 g_527 = {0xD01C48E6L};/* VOLATILE GLOBAL g_527 */
static volatile union U1 g_547 = {1L};/* VOLATILE GLOBAL g_547 */
static union U1 *g_589[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 ** volatile g_588 = &g_589[4];/* VOLATILE GLOBAL g_588 */
static int32_t ** volatile g_599[9][9][3] = {{{(void*)0,&g_371,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_371,&g_150},{&g_371,(void*)0,&g_150},{(void*)0,&g_150,&g_371},{&g_150,&g_150,&g_371},{&g_371,&g_150,&g_150},{&g_150,&g_371,&g_371},{&g_371,&g_150,&g_150}},{{&g_371,&g_371,&g_371},{&g_371,&g_371,(void*)0},{&g_371,(void*)0,&g_150},{&g_150,&g_371,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_150,&g_371},{&g_150,&g_150,&g_371},{&g_371,&g_371,(void*)0},{&g_371,&g_371,&g_371}},{{&g_150,&g_150,&g_150},{&g_150,&g_150,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_371,&g_371},{&g_371,&g_371,(void*)0},{(void*)0,&g_150,&g_371},{(void*)0,&g_150,&g_150},{(void*)0,&g_150,&g_371},{(void*)0,&g_371,(void*)0}},{{&g_371,&g_150,&g_371},{&g_150,&g_371,&g_150},{&g_371,&g_150,(void*)0},{&g_150,&g_371,&g_150},{&g_150,(void*)0,&g_371},{&g_371,&g_371,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_150,&g_371},{&g_150,&g_150,&g_371}},{{&g_150,(void*)0,&g_150},{&g_371,&g_150,&g_371},{&g_150,&g_150,&g_150},{&g_371,&g_371,&g_371},{&g_371,&g_371,&g_371},{&g_371,(void*)0,&g_150},{&g_150,&g_371,&g_371},{&g_150,&g_150,&g_371},{&g_371,&g_371,&g_150}},{{&g_150,&g_150,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_150,&g_371},{(void*)0,&g_150,&g_371},{&g_150,&g_150,&g_150},{&g_371,&g_371,&g_371},{(void*)0,&g_371,&g_150},{&g_371,&g_371,&g_371},{&g_371,&g_150,&g_371}},{{&g_150,&g_150,&g_150},{&g_371,&g_371,&g_371},{&g_371,&g_371,&g_371},{&g_371,&g_150,&g_150},{&g_150,(void*)0,&g_371},{&g_371,&g_150,&g_150},{&g_371,&g_150,&g_371},{&g_371,&g_150,&g_371},{&g_150,&g_150,&g_150}},{{&g_371,&g_371,&g_371},{&g_371,&g_371,&g_371},{&g_371,&g_371,&g_150},{&g_150,&g_371,(void*)0},{&g_371,&g_371,&g_150},{&g_371,&g_371,&g_371},{(void*)0,&g_150,(void*)0},{&g_371,&g_371,&g_371},{&g_150,&g_150,&g_150}},{{(void*)0,&g_150,&g_371},{&g_150,&g_371,(void*)0},{&g_371,&g_150,&g_371},{&g_150,&g_371,&g_150},{&g_371,&g_371,&g_371},{&g_150,&g_371,&g_150},{&g_150,&g_150,&g_371},{&g_150,&g_150,&g_150},{&g_150,&g_150,&g_150}}};
static const union U1 g_630 = {0L};/* VOLATILE GLOBAL g_630 */
static volatile union U1 g_669 = {0x6E3B461CL};/* VOLATILE GLOBAL g_669 */
static volatile union U1 g_672 = {0xF075EE0CL};/* VOLATILE GLOBAL g_672 */
static volatile int16_t g_683 = (-10L);/* VOLATILE GLOBAL g_683 */
static int16_t g_685 = (-1L);
static int8_t **g_690[6] = {&g_146,&g_146,&g_147,&g_146,&g_146,&g_147};
static int8_t **g_691 = &g_147;
static volatile union U1 g_696 = {0L};/* VOLATILE GLOBAL g_696 */
static int32_t * volatile g_722 = &g_375;/* VOLATILE GLOBAL g_722 */
static int32_t g_758 = 0L;
static uint64_t *** volatile g_781[8] = {&g_459,&g_459,&g_459,&g_459,&g_459,&g_459,&g_459,&g_459};
static uint64_t *** volatile g_782[8][10] = {{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459},{&g_459,&g_459,(void*)0,(void*)0,&g_459,&g_459,&g_459,(void*)0,(void*)0,&g_459}};
static uint64_t *** const  volatile g_783 = &g_459;/* VOLATILE GLOBAL g_783 */
static volatile union U1 g_797[5][7][4] = {{{{0xAB0485ACL},{-5L},{0x2F827F01L},{0x2F827F01L}},{{1L},{1L},{1L},{0x24E4E2E8L}},{{0L},{0x2B502952L},{0x575A2302L},{0xAB0485ACL}},{{-10L},{3L},{0x3938C640L},{0x575A2302L}},{{7L},{3L},{0x8CEC57EFL},{0xAB0485ACL}},{{3L},{0x2B502952L},{0x797F2B74L},{0x24E4E2E8L}},{{0x4ACA3E0DL},{1L},{3L},{0x2F827F01L}}},{{{0xFA84412CL},{-5L},{6L},{0x3938C640L}},{{-10L},{4L},{1L},{0L}},{{0L},{0xAB0485ACL},{0x8EDF4113L},{0xAB0485ACL}},{{4L},{0x296C44E7L},{0x2F827F01L},{0x8EDF4113L}},{{7L},{0x4ACA3E0DL},{3L},{6L}},{{0x61991AB3L},{0x2B502952L},{-10L},{0x931DB879L}},{{0x61991AB3L},{4L},{3L},{6L}}},{{{7L},{0x931DB879L},{0x2F827F01L},{0x3938C640L}},{{4L},{0x21B51C94L},{0x8EDF4113L},{0x24E4E2E8L}},{{0L},{7L},{1L},{6L}},{{-10L},{0x296C44E7L},{6L},{1L}},{{0xFA84412CL},{3L},{3L},{0xFA84412CL}},{{0x4ACA3E0DL},{0xAB0485ACL},{0x797F2B74L},{0x931DB879L}},{{3L},{0x21B51C94L},{0x8CEC57EFL},{0x2F827F01L}}},{{{7L},{0L},{0x3938C640L},{0x2F827F01L}},{{0x1D69197FL},{0x27E85F33L},{0x797F2B74L},{6L}},{{0x2F827F01L},{0x61991AB3L},{-10L},{0x8CEC57EFL}},{{0x0A66318FL},{0L},{-1L},{-10L}},{{0x61991AB3L},{0L},{-5L},{0x296C44E7L}},{{0x931DB879L},{3L},{-2L},{-7L}},{{0x24E4E2E8L},{0x27E85F33L},{0x24E4E2E8L},{0x575A2302L}}},{{{0x8CEC57EFL},{6L},{0x575A2302L},{0x8EDF4113L}},{{0x0A66318FL},{-2L},{0x21B51C94L},{6L}},{{6L},{0x4ACA3E0DL},{0x21B51C94L},{0x296C44E7L}},{{0x0A66318FL},{0x931DB879L},{0x575A2302L},{0x21B51C94L}},{{0x8CEC57EFL},{0L},{0x24E4E2E8L},{0x61991AB3L}},{{0x24E4E2E8L},{0x61991AB3L},{-2L},{0x2F827F01L}},{{0x931DB879L},{-2L},{-5L},{0x575A2302L}}}};
static union U0 g_806 = {0xFD31EB6AL};/* VOLATILE GLOBAL g_806 */
static volatile int32_t g_821 = 0x2AA8A1EDL;/* VOLATILE GLOBAL g_821 */
static int32_t *g_837 = &g_31;
static int32_t * volatile g_838 = &g_10;/* VOLATILE GLOBAL g_838 */
static const volatile union U1 g_844 = {0xF9DD67AFL};/* VOLATILE GLOBAL g_844 */
static union U1 g_873[10] = {{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L}};
static union U1 g_875 = {-1L};/* VOLATILE GLOBAL g_875 */
static uint8_t g_912 = 8UL;
static volatile union U1 g_923[1][5] = {{{0xADAD76DCL},{0xADAD76DCL},{0xADAD76DCL},{0xADAD76DCL},{0xADAD76DCL}}};
static volatile int16_t * volatile *g_966 = (void*)0;
static volatile union U1 g_975 = {6L};/* VOLATILE GLOBAL g_975 */
static int32_t g_1000 = 0xEA1A2C96L;
static union U1 g_1060 = {0x440C6BD1L};/* VOLATILE GLOBAL g_1060 */
static volatile union U0 g_1073 = {0x36E1B84DL};/* VOLATILE GLOBAL g_1073 */
static volatile int16_t * volatile * volatile *g_1103[8][9][3] = {{{&g_966,&g_966,&g_966},{&g_966,&g_966,(void*)0},{(void*)0,(void*)0,&g_966},{(void*)0,&g_966,(void*)0},{&g_966,&g_966,&g_966},{&g_966,(void*)0,(void*)0},{(void*)0,(void*)0,&g_966},{&g_966,&g_966,(void*)0},{&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966},{(void*)0,&g_966,&g_966},{&g_966,(void*)0,&g_966},{&g_966,(void*)0,&g_966},{&g_966,&g_966,&g_966},{&g_966,&g_966,(void*)0},{&g_966,(void*)0,&g_966},{(void*)0,&g_966,(void*)0}},{{&g_966,&g_966,(void*)0},{&g_966,(void*)0,(void*)0},{&g_966,(void*)0,&g_966},{&g_966,&g_966,(void*)0},{(void*)0,&g_966,&g_966},{&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966},{(void*)0,&g_966,&g_966},{(void*)0,(void*)0,&g_966}},{{&g_966,(void*)0,&g_966},{&g_966,&g_966,&g_966},{&g_966,&g_966,(void*)0},{(void*)0,(void*)0,&g_966},{(void*)0,&g_966,(void*)0},{&g_966,&g_966,&g_966},{&g_966,(void*)0,(void*)0},{(void*)0,(void*)0,&g_966},{&g_966,&g_966,(void*)0}},{{&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966},{(void*)0,&g_966,&g_966},{&g_966,(void*)0,&g_966},{&g_966,&g_966,(void*)0},{&g_966,(void*)0,(void*)0},{(void*)0,(void*)0,&g_966},{&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966},{&g_966,(void*)0,&g_966},{(void*)0,&g_966,&g_966},{&g_966,(void*)0,&g_966},{&g_966,(void*)0,&g_966},{&g_966,&g_966,(void*)0},{(void*)0,&g_966,(void*)0},{&g_966,&g_966,&g_966},{&g_966,(void*)0,&g_966}},{{&g_966,(void*)0,&g_966},{(void*)0,&g_966,(void*)0},{&g_966,(void*)0,&g_966},{(void*)0,&g_966,&g_966},{&g_966,&g_966,&g_966},{&g_966,(void*)0,&g_966},{&g_966,(void*)0,&g_966},{(void*)0,&g_966,&g_966},{&g_966,(void*)0,&g_966}},{{&g_966,(void*)0,&g_966},{&g_966,&g_966,&g_966},{(void*)0,&g_966,(void*)0},{&g_966,&g_966,&g_966},{&g_966,(void*)0,&g_966},{&g_966,(void*)0,&g_966},{(void*)0,&g_966,(void*)0},{&g_966,(void*)0,(void*)0},{(void*)0,(void*)0,&g_966}}};
static volatile int16_t * volatile * volatile ** volatile g_1102 = &g_1103[0][5][0];/* VOLATILE GLOBAL g_1102 */
static int32_t ** const  volatile g_1131 = &g_837;/* VOLATILE GLOBAL g_1131 */
static const int32_t *g_1134 = &g_375;
static const int32_t ** volatile g_1133 = &g_1134;/* VOLATILE GLOBAL g_1133 */
static union U1 g_1160 = {0xE0152DACL};/* VOLATILE GLOBAL g_1160 */
static int8_t g_1175 = 0xA9L;
static uint32_t *g_1178 = &g_1060.f3;
static union U0 g_1231 = {4294967290UL};/* VOLATILE GLOBAL g_1231 */
static int32_t ** volatile g_1278 = &g_837;/* VOLATILE GLOBAL g_1278 */
static uint8_t g_1311 = 0UL;
static int32_t ** volatile g_1312[10] = {&g_371,&g_371,&g_371,&g_371,&g_371,&g_371,&g_371,&g_371,&g_371,&g_371};
static volatile union U1 g_1333 = {0x71D40D9FL};/* VOLATILE GLOBAL g_1333 */
static volatile union U0 g_1413 = {4294967290UL};/* VOLATILE GLOBAL g_1413 */
static union U1 ** volatile g_1432[9] = {&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4]};
static union U1 ** volatile g_1433[4][6] = {{&g_589[4],&g_589[2],&g_589[4],(void*)0,&g_589[4],&g_589[4]},{&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[2]},{&g_589[4],&g_589[4],&g_589[4],(void*)0,(void*)0,(void*)0},{&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],(void*)0}};
static union U1 ** volatile g_1434[6] = {&g_589[0],(void*)0,(void*)0,&g_589[0],(void*)0,(void*)0};
static union U1 ** volatile g_1435 = (void*)0;/* VOLATILE GLOBAL g_1435 */
static union U1 ** volatile g_1436 = &g_589[4];/* VOLATILE GLOBAL g_1436 */
static volatile union U0 g_1525 = {0x791D047DL};/* VOLATILE GLOBAL g_1525 */
static const int64_t *g_1536[6][8] = {{(void*)0,&g_289,&g_194,(void*)0,&g_194,&g_289,(void*)0,&g_194},{&g_289,&g_201,(void*)0,(void*)0,(void*)0,(void*)0,&g_201,&g_289},{&g_194,(void*)0,&g_289,&g_194,(void*)0,&g_194,&g_289,(void*)0},{&g_289,&g_289,&g_194,&g_289,&g_194,&g_194,&g_289,&g_194},{(void*)0,(void*)0,(void*)0,&g_201,&g_289,(void*)0,&g_289,&g_201},{&g_194,&g_201,&g_194,&g_194,&g_201,&g_289,&g_289,&g_201}};
static const int64_t * volatile * const g_1535 = &g_1536[1][4];
static int64_t *g_1541[9] = {&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194,&g_194};
static int64_t **g_1540 = &g_1541[5];
static int32_t * volatile g_1544 = (void*)0;/* VOLATILE GLOBAL g_1544 */
static int32_t * volatile g_1545 = &g_375;/* VOLATILE GLOBAL g_1545 */
static volatile uint8_t g_1658 = 0x10L;/* VOLATILE GLOBAL g_1658 */
static int16_t **g_1717 = (void*)0;
static int32_t ** volatile g_1724 = &g_837;/* VOLATILE GLOBAL g_1724 */
static volatile int32_t **g_1743 = (void*)0;
static volatile int32_t ** volatile * volatile g_1742 = &g_1743;/* VOLATILE GLOBAL g_1742 */
static int32_t ** volatile g_1764 = &g_837;/* VOLATILE GLOBAL g_1764 */
static uint16_t g_1799[2] = {65529UL,65529UL};
static uint8_t * volatile g_1822 = (void*)0;/* VOLATILE GLOBAL g_1822 */
static uint8_t * volatile * volatile g_1821 = &g_1822;/* VOLATILE GLOBAL g_1821 */
static volatile union U0 g_1845 = {0xBECAED50L};/* VOLATILE GLOBAL g_1845 */
static uint8_t *g_1885 = &g_1311;
static uint8_t **g_1884 = &g_1885;
static int32_t ** volatile g_1907 = &g_371;/* VOLATILE GLOBAL g_1907 */
static uint64_t g_1924[9] = {18446744073709551612UL,18446744073709551612UL,0x048B37B39D7779FFLL,18446744073709551612UL,18446744073709551612UL,0x048B37B39D7779FFLL,18446744073709551612UL,18446744073709551612UL,0x048B37B39D7779FFLL};
static union U0 g_1934 = {1UL};/* VOLATILE GLOBAL g_1934 */
static union U1 g_1969 = {0x0123CE87L};/* VOLATILE GLOBAL g_1969 */
static uint16_t g_1990 = 65535UL;
static union U2 *g_2006 = (void*)0;
static union U2 ** volatile g_2005 = &g_2006;/* VOLATILE GLOBAL g_2005 */
static const volatile union U1 g_2015 = {0L};/* VOLATILE GLOBAL g_2015 */
static int64_t ** volatile *g_2035 = &g_1540;
static int64_t ** volatile * volatile *g_2034 = &g_2035;
static volatile union U1 g_2044 = {-5L};/* VOLATILE GLOBAL g_2044 */
static volatile int64_t g_2143 = 1L;/* VOLATILE GLOBAL g_2143 */
static int32_t ** volatile g_2160 = &g_837;/* VOLATILE GLOBAL g_2160 */
static volatile union U0 g_2186 = {4294967295UL};/* VOLATILE GLOBAL g_2186 */
static union U1 g_2209 = {0x4F559678L};/* VOLATILE GLOBAL g_2209 */
static int8_t g_2247 = 5L;
static uint8_t ***g_2258 = &g_1884;
static uint16_t g_2289 = 0x0E00L;
static union U2 **g_2292 = (void*)0;
static volatile union U0 g_2296 = {2UL};/* VOLATILE GLOBAL g_2296 */
static volatile union U1 g_2304[8] = {{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L},{-1L}};
static volatile union U0 g_2358 = {0xDFCFA560L};/* VOLATILE GLOBAL g_2358 */
static int32_t g_2383[10][6][4] = {{{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L},{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L},{0xAC9A1551L,1L,3L,3L},{0x7A76585BL,0x7A76585BL,7L,1L},{1L,0xAC9A1551L,7L,0xAC9A1551L},{0x7A76585BL,0x8EEF6F30L,3L,7L}},{{0xAC9A1551L,0x8EEF6F30L,0x8EEF6F30L,0xAC9A1551L},{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L},{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L},{0xAC9A1551L,1L,3L,3L},{0x7A76585BL,0x7A76585BL,7L,1L},{1L,0xAC9A1551L,7L,0xAC9A1551L}},{{0x7A76585BL,0x8EEF6F30L,3L,7L},{0xAC9A1551L,0x8EEF6F30L,0x8EEF6F30L,0xAC9A1551L},{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L},{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L},{0xAC9A1551L,1L,3L,3L},{0x7A76585BL,0x7A76585BL,7L,1L}},{{1L,0xAC9A1551L,7L,0xAC9A1551L},{0x7A76585BL,0x8EEF6F30L,3L,7L},{0xAC9A1551L,0x8EEF6F30L,0x8EEF6F30L,0xAC9A1551L},{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L},{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L},{0xAC9A1551L,1L,3L,3L}},{{0x7A76585BL,0x7A76585BL,7L,1L},{1L,0xAC9A1551L,7L,0xAC9A1551L},{0x7A76585BL,0x8EEF6F30L,3L,7L},{0xAC9A1551L,0x8EEF6F30L,0x8EEF6F30L,0xAC9A1551L},{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L},{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L}},{{0xAC9A1551L,1L,3L,3L},{0x7A76585BL,0x7A76585BL,7L,1L},{1L,0xAC9A1551L,7L,0xAC9A1551L},{0x7A76585BL,0x8EEF6F30L,3L,7L},{0xAC9A1551L,0x8EEF6F30L,0x8EEF6F30L,0xAC9A1551L},{0x8EEF6F30L,0xAC9A1551L,0x7A76585BL,1L}},{{0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L,3L},{0xAC9A1551L,1L,3L,3L},{0x7A76585BL,0x7A76585BL,7L,1L},{1L,0xAC9A1551L,7L,0xAC9A1551L},{0x7A76585BL,0x8EEF6F30L,3L,7L},{0x8EEF6F30L,1L,1L,0x8EEF6F30L}},{{1L,0x8EEF6F30L,(-1L),3L},{1L,(-1L),1L,7L},{0x8EEF6F30L,3L,7L,7L},{(-1L),(-1L),0x7A76585BL,3L},{3L,0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L},{(-1L),1L,7L,0x7A76585BL}},{{0x8EEF6F30L,1L,1L,0x8EEF6F30L},{1L,0x8EEF6F30L,(-1L),3L},{1L,(-1L),1L,7L},{0x8EEF6F30L,3L,7L,7L},{(-1L),(-1L),0x7A76585BL,3L},{3L,0x8EEF6F30L,0x7A76585BL,0x8EEF6F30L}},{{(-1L),1L,7L,0x7A76585BL},{0x8EEF6F30L,1L,1L,0x8EEF6F30L},{1L,0x8EEF6F30L,(-1L),3L},{1L,(-1L),1L,7L},{0x8EEF6F30L,3L,7L,7L},{(-1L),(-1L),0x7A76585BL,3L}}};
static uint32_t g_2392 = 0xEB338806L;
static volatile int32_t ****g_2410 = (void*)0;
static union U1 * volatile * volatile g_2480 = &g_589[0];/* VOLATILE GLOBAL g_2480 */
static union U1 * volatile * volatile *g_2479 = &g_2480;
static union U1 * volatile * volatile **g_2478[9] = {&g_2479,&g_2479,&g_2479,&g_2479,&g_2479,&g_2479,&g_2479,&g_2479,&g_2479};
static union U1 **g_2483 = &g_589[4];
static union U1 ***g_2482 = &g_2483;
static union U1 ****g_2481 = &g_2482;
static uint8_t g_2485 = 0x85L;
static union U1 g_2517[1] = {{0xBDBECFBBL}};
static int32_t g_2519 = 0xA87BABE7L;
static const int32_t **g_2588[10][1] = {{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0},{(void*)0}};
static const int32_t ***g_2587 = &g_2588[3][0];
static const uint8_t g_2599[1][9][2] = {{{0UL,0UL},{0UL,0xCEL},{0UL,0UL},{0UL,0xCEL},{0UL,0UL},{0UL,0xCEL},{0UL,0UL},{0UL,0xCEL},{0UL,0UL}}};
static uint32_t g_2611 = 0x5EA1FB0CL;
static int32_t **g_2645 = &g_150;
static int32_t ***g_2644[1] = {&g_2645};
static int32_t ****g_2643 = &g_2644[0];
static volatile union U1 g_2679 = {6L};/* VOLATILE GLOBAL g_2679 */
static volatile union U1 g_2730 = {0x01155E84L};/* VOLATILE GLOBAL g_2730 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_52(int8_t * p_53, int32_t  p_54, int8_t * p_55);
static int8_t * func_56(int16_t  p_57, int8_t * p_58, int32_t * const  p_59, int8_t * p_60);
static int16_t  func_61(int32_t * p_62, uint32_t  p_63);
static int32_t * func_64(int8_t * p_65, int8_t * p_66, int8_t  p_67, union U2  p_68);
static int8_t * func_71(int32_t  p_72, uint16_t  p_73, int16_t  p_74);
static uint16_t  func_75(int32_t * p_76, uint32_t  p_77);
static int32_t * func_78(int8_t  p_79, uint32_t  p_80, int32_t  p_81);
static union U2  func_82(uint64_t  p_83, int64_t  p_84, uint32_t  p_85, int32_t  p_86);
static int32_t * func_87(int32_t * p_88, const int8_t * p_89, int32_t  p_90);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_7 g_34 g_49 g_2258 g_1884 g_1885 g_1311 g_451 g_452 g_1799 g_2730 g_1160.f3 g_146 g_837
 * writes: g_2 g_7 g_10 g_12 g_34 g_49 g_1311 g_1799 g_134 g_31
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5[3];
    int16_t l_37 = 0xF28FL;
    int32_t l_46[2][4][10] = {{{1L,0x324E311BL,(-1L),(-6L),0L,(-2L),0x377BC7A9L,0x37402B88L,0x377BC7A9L,(-2L)},{0xCE1F6DC3L,0x4C35F52DL,1L,0x4C35F52DL,0xCE1F6DC3L,0x450DE0B5L,(-7L),0x324E311BL,0x438CF835L,1L},{5L,1L,4L,(-2L),(-2L),4L,0x324E311BL,(-6L),0L,1L},{0xE342BA51L,(-2L),1L,0x3ECF3843L,0xCE1F6DC3L,0x377BC7A9L,0xC718FE3BL,0xE7740573L,1L,(-2L)}},{{(-1L),5L,0xEEACC200L,0xCE1F6DC3L,0L,0xD5AA0404L,5L,5L,0xD5AA0404L,0L},{1L,4L,4L,1L,(-1L),0x3ECF3843L,0x37402B88L,1L,0x6930A875L,0x324E311BL},{4L,(-7L),0L,1L,0x928D85E2L,0x377BC7A9L,4L,0x37402B88L,0x6930A875L,(-9L)},{0x37402B88L,0xE7740573L,1L,1L,(-1L),0L,1L,0x377BC7A9L,5L,0xC718FE3BL}}};
    const int8_t *l_91 = &g_92;
    int32_t *l_2317 = &l_46[0][3][1];
    const uint64_t l_2357 = 0x9AFEA7F0FB2469E4LL;
    int8_t *l_2409 = &g_2247;
    uint8_t l_2415 = 8UL;
    union U1 * const * const l_2427[5] = {&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4]};
    union U1 * const * const *l_2426 = &l_2427[0];
    union U1 **l_2431 = &g_589[4];
    union U1 ***l_2430 = &l_2431;
    union U2 l_2489 = {0};
    const int32_t l_2506[6][7][3] = {{{0xA2BCDE28L,0xAA54225DL,0L},{0xAA54225DL,0xA2BCDE28L,0xDA3525E9L},{0x22CD61D1L,0x97456AEAL,5L},{1L,0xAA54225DL,0x06CC583AL},{0x6FE41880L,(-7L),0x06CC583AL},{(-1L),0x2DC5F9BFL,5L},{0xA2BCDE28L,0x6FE41880L,0xDA3525E9L}},{{1L,8L,0L},{(-1L),0x97456AEAL,0xDA3525E9L},{(-7L),1L,5L},{0x6C71F3ECL,8L,0x06CC583AL},{0x22CD61D1L,0x22CD61D1L,0x06CC583AL},{8L,0x6C71F3ECL,5L},{1L,(-7L),0xDA3525E9L}},{{0x97456AEAL,(-1L),0L},{8L,1L,0xDA3525E9L},{0x6FE41880L,0xA2BCDE28L,5L},{0x2DC5F9BFL,(-1L),0x06CC583AL},{(-7L),0x6FE41880L,0x06CC583AL},{0xAA54225DL,1L,5L},{0x97456AEAL,0x22CD61D1L,0xDA3525E9L}},{{0xA2BCDE28L,0xAA54225DL,0L},{0xAA54225DL,0xA2BCDE28L,0xDA3525E9L},{0x22CD61D1L,0x97456AEAL,5L},{1L,0xAA54225DL,0x06CC583AL},{0x6FE41880L,(-7L),0x06CC583AL},{(-1L),0x2DC5F9BFL,5L},{0xA2BCDE28L,0x6FE41880L,0xDA3525E9L}},{{1L,8L,0L},{(-1L),0x97456AEAL,0xDA3525E9L},{(-7L),1L,5L},{0x6C71F3ECL,8L,0x06CC583AL},{0x22CD61D1L,0x22CD61D1L,0x06CC583AL},{8L,0x6C71F3ECL,5L},{1L,(-7L),0xDA3525E9L}},{{0x97456AEAL,(-1L),0L},{8L,1L,0xDA3525E9L},{0x6FE41880L,0xA2BCDE28L,5L},{0x2DC5F9BFL,(-1L),0x06CC583AL},{(-7L),0x6FE41880L,0x06CC583AL},{0xAA54225DL,1L,5L},{0x97456AEAL,0x22CD61D1L,0xDA3525E9L}}};
    uint16_t l_2524 = 0x7BA1L;
    int32_t l_2530[9][8] = {{1L,0x381E5287L,0L,0x381E5287L,1L,1L,0x381E5287L,0L},{1L,1L,0x381E5287L,0L,0x381E5287L,1L,1L,0x381E5287L},{(-1L),0x381E5287L,0x381E5287L,(-1L),0xDE16A3E7L,(-1L),0x381E5287L,0x381E5287L},{0x381E5287L,0xDE16A3E7L,0L,0L,0xDE16A3E7L,0x381E5287L,0xDE16A3E7L,0L},{(-1L),0xDE16A3E7L,(-1L),0x381E5287L,0x381E5287L,(-1L),0xDE16A3E7L,(-1L)},{1L,0x381E5287L,0L,0x381E5287L,1L,1L,0x381E5287L,0L},{1L,1L,0x381E5287L,0L,0x381E5287L,1L,1L,0x381E5287L},{0L,(-1L),(-1L),0L,1L,0L,(-1L),(-1L)},{(-1L),1L,0xDE16A3E7L,0xDE16A3E7L,1L,(-1L),1L,0xDE16A3E7L}};
    const int16_t l_2580 = 0x40FBL;
    uint16_t l_2687 = 0xE179L;
    uint32_t l_2692 = 4294967295UL;
    uint16_t *l_2723 = (void*)0;
    uint16_t *l_2724 = (void*)0;
    uint16_t *l_2725 = &g_1799[1];
    uint32_t l_2741 = 0x97BF0322L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_5[i] = 0xE6F7FBF2121F90EFLL;
    for (g_2[0] = 0; (g_2[0] != (-25)); g_2[0] = safe_sub_func_uint8_t_u_u(g_2[0], 1))
    { /* block id: 3 */
        int64_t l_44 = (-8L);
        int32_t l_45 = 0xE086565EL;
        int64_t l_47 = 0xCBDA12577EDFD631LL;
        int32_t l_48[6][9] = {{(-1L),(-9L),0xF5970FBDL,(-9L),(-1L),0xAF09E5C5L,0xAF09E5C5L,(-1L),(-9L)},{0x198010E0L,0x0EEAA445L,0x198010E0L,0xAF09E5C5L,0xF5970FBDL,0xF5970FBDL,0xAF09E5C5L,0x198010E0L,0x0EEAA445L},{0x0EEAA445L,0x198010E0L,0xAF09E5C5L,0xF5970FBDL,0xF5970FBDL,0xAF09E5C5L,0x198010E0L,0x0EEAA445L,0x198010E0L},{(-9L),(-1L),0xAF09E5C5L,0xAF09E5C5L,(-1L),(-9L),0xF5970FBDL,(-9L),(-1L)},{(-9L),0x198010E0L,0x198010E0L,(-9L),0x0EEAA445L,(-1L),0x0EEAA445L,(-9L),0x198010E0L},{0x0EEAA445L,0x0EEAA445L,0xF5970FBDL,(-1L),(-1L),(-1L),0xF5970FBDL,0x0EEAA445L,0x0EEAA445L}};
        int8_t *l_1725 = (void*)0;
        int8_t *l_2246 = &g_2247;
        union U2 **l_2293 = (void*)0;
        int32_t l_2315 = 0x4ACFA4E5L;
        int16_t ** const *l_2386 = &g_1717;
        uint32_t l_2394 = 1UL;
        int32_t **l_2417 = &l_2317;
        union U1 * const * const **l_2428 = (void*)0;
        union U1 * const * const *l_2429[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        union U1 ****l_2432 = &l_2430;
        int8_t l_2460[5][5] = {{3L,1L,1L,3L,1L},{0x1AL,0x0FL,0xC7L,0x0FL,0x1AL},{1L,3L,1L,1L,3L},{0x1AL,0xE3L,0x98L,0x0FL,0x98L},{3L,3L,(-7L),3L,3L}};
        uint32_t l_2465 = 18446744073709551607UL;
        uint8_t ** const l_2477 = (void*)0;
        const uint32_t l_2499 = 9UL;
        int64_t l_2503[5][4][8] = {{{0L,0x1D411996AC18B040LL,0x7BAF6ACB5B974B4ELL,(-7L),0x699D302D72378B10LL,0xC9851B6DC083601CLL,7L,0x5621383E184C7448LL},{0xC9851B6DC083601CLL,0x54D451FECA717395LL,0x087C3A5C4F2F5847LL,(-1L),0x087C3A5C4F2F5847LL,0x54D451FECA717395LL,0xC9851B6DC083601CLL,0xB7543FBE49ECA512LL},{0x5621383E184C7448LL,0L,(-1L),0xE98FF7FA16697889LL,7L,(-9L),0x7BAF6ACB5B974B4ELL,0x6335431FA81E3AF2LL},{(-1L),0x7BAF6ACB5B974B4ELL,0xE98FF7FA16697889LL,0xC88EEA078BFD083ALL,7L,0xAC479B9B320AFAF4LL,(-1L),(-1L)}},{{0x5621383E184C7448LL,0x087C3A5C4F2F5847LL,0x6335431FA81E3AF2LL,0x6335431FA81E3AF2LL,0x087C3A5C4F2F5847LL,0x5621383E184C7448LL,0L,(-1L)},{0xC9851B6DC083601CLL,(-1L),(-1L),0x54D451FECA717395LL,0x699D302D72378B10LL,(-4L),(-9L),0xD8C34014C235FF65LL},{0L,0xE98FF7FA16697889LL,0L,0x54D451FECA717395LL,0x6335431FA81E3AF2LL,(-1L),0x1D411996AC18B040LL,(-1L)},{0xAC479B9B320AFAF4LL,0x6335431FA81E3AF2LL,(-7L),0x6335431FA81E3AF2LL,0xAC479B9B320AFAF4LL,0x7BAF6ACB5B974B4ELL,0x699D302D72378B10LL,(-1L)}},{{0x699D302D72378B10LL,(-1L),(-4L),0xC88EEA078BFD083ALL,(-1L),(-1L),0x5621383E184C7448LL,0x6335431FA81E3AF2LL},{(-7L),0L,(-4L),0xE98FF7FA16697889LL,0xB7543FBE49ECA512LL,0x699D302D72378B10LL,0x699D302D72378B10LL,0xB7543FBE49ECA512LL},{(-1L),(-7L),(-7L),(-1L),0x54D451FECA717395LL,0x54D451FECA717395LL,0xC88EEA078BFD083ALL,0x6335431FA81E3AF2LL},{0x699D302D72378B10LL,0xE98FF7FA16697889LL,0x5621383E184C7448LL,0L,0x54D451FECA717395LL,0x1D411996AC18B040LL,0L,7L}},{{7L,0xE98FF7FA16697889LL,(-1L),0L,0x5621383E184C7448LL,0x54D451FECA717395LL,0x5621383E184C7448LL,0L},{0xB7543FBE49ECA512LL,0L,0xB7543FBE49ECA512LL,(-1L),0x087C3A5C4F2F5847LL,0L,(-9L),0x5621383E184C7448LL},{(-7L),0x5621383E184C7448LL,0x699D302D72378B10LL,0xAC479B9B320AFAF4LL,0L,0x7BAF6ACB5B974B4ELL,0x087C3A5C4F2F5847LL,0xE98FF7FA16697889LL},{(-7L),(-1L),0x7BAF6ACB5B974B4ELL,(-4L),0x087C3A5C4F2F5847LL,0x087C3A5C4F2F5847LL,(-4L),0x7BAF6ACB5B974B4ELL}},{{0xB7543FBE49ECA512LL,0xB7543FBE49ECA512LL,0x1D411996AC18B040LL,0x6335431FA81E3AF2LL,0x5621383E184C7448LL,(-1L),(-1L),0xC88EEA078BFD083ALL},{7L,0x699D302D72378B10LL,0x087C3A5C4F2F5847LL,(-1L),0x54D451FECA717395LL,0xE98FF7FA16697889LL,0L,0xC88EEA078BFD083ALL},{0x699D302D72378B10LL,0x7BAF6ACB5B974B4ELL,0xAC479B9B320AFAF4LL,0x6335431FA81E3AF2LL,(-7L),0x6335431FA81E3AF2LL,0xAC479B9B320AFAF4LL,0x7BAF6ACB5B974B4ELL},{(-9L),0x1D411996AC18B040LL,(-7L),(-4L),0xD8C34014C235FF65LL,(-1L),0x7BAF6ACB5B974B4ELL,0xE98FF7FA16697889LL}}};
        uint8_t l_2671 = 0x2AL;
        uint16_t *l_2686 = &g_1799[1];
        uint16_t l_2693 = 4UL;
        uint64_t *l_2694 = &g_1924[7];
        int64_t *l_2695[7][9] = {{&l_5[1],&g_194,&l_47,&l_44,&g_289,&l_44,&l_47,&g_194,&l_5[1]},{&l_2503[3][2][1],&l_2503[0][0][0],&g_289,&l_2503[0][0][0],&l_2503[3][2][1],&l_2503[3][2][1],&l_2503[0][0][0],&g_289,&l_2503[0][0][0]},{&l_47,(void*)0,&g_194,&l_2503[3][2][0],&g_289,&g_194,&g_289,&l_2503[3][2][0],&g_194},{&l_2503[3][2][1],&l_2503[3][2][1],&l_2503[0][0][0],&g_289,&l_2503[0][0][0],&l_2503[3][2][1],&l_2503[3][2][1],&l_2503[0][0][0],&g_289},{&l_5[1],(void*)0,&l_5[1],&g_194,&l_47,&l_44,&g_289,&l_44,&l_47},{&l_2503[3][2][0],&l_2503[0][0][0],&l_2503[0][0][0],&l_2503[3][2][0],&g_201,&l_2503[3][2][0],&l_2503[0][0][0],&l_2503[0][0][0],&l_2503[3][2][0]},{&l_2503[3][2][0],&g_194,&g_194,&g_194,&l_2503[3][2][0],&g_289,&l_47,&l_2503[3][2][0],&l_47}};
        int16_t *l_2696 = &l_37;
        uint16_t *l_2697[6] = {(void*)0,(void*)0,&g_104,(void*)0,(void*)0,&g_104};
        int32_t l_2698[8];
        int64_t l_2713 = 0xC1D78DC2BEDC92A4LL;
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_2698[i] = 0xEF8E918BL;
        for (g_7[0][5] = 0; (g_7[0][5] <= 2); g_7[0][5] += 1)
        { /* block id: 6 */
            int16_t l_33 = 0xECC4L;
            int32_t l_38 = (-4L);
            int32_t *l_39 = &g_10;
            int32_t *l_40 = &g_10;
            int32_t *l_41 = &g_10;
            int32_t *l_42 = &g_12;
            int32_t *l_43[6][6] = {{&l_38,&g_2[0],&g_2[0],&l_38,&g_31,&g_7[1][0]},{&g_12,&g_7[1][0],&g_12,&g_7[0][5],&g_7[0][5],&g_7[0][5]},{&g_31,&g_2[0],&g_31,(void*)0,&g_7[0][5],&l_38},{&g_12,&g_7[1][0],&g_12,&g_31,&g_31,&g_12},{&g_2[0],&g_2[0],&l_38,&g_31,&g_7[1][0],(void*)0},{&g_12,&l_38,&l_38,(void*)0,&l_38,&l_38}};
            int32_t *l_69 = &g_70;
            int8_t *l_96 = (void*)0;
            uint32_t *l_97 = &g_98;
            int32_t **l_372[4][7][8] = {{{(void*)0,(void*)0,(void*)0,&l_39,&l_42,&l_41,&g_150,&l_43[3][0]},{&l_39,&g_150,&l_42,(void*)0,&l_43[3][0],&l_39,&l_42,(void*)0},{&l_39,&l_39,&l_42,&l_43[3][3],&g_150,(void*)0,(void*)0,&g_150},{(void*)0,&l_42,&l_42,(void*)0,&g_150,(void*)0,(void*)0,(void*)0},{&l_39,&l_42,&l_41,&g_150,&l_43[3][0],&g_150,&l_41,&l_42},{&l_42,&l_42,(void*)0,&l_41,&l_42,(void*)0,&l_43[3][3],&l_43[3][3]},{(void*)0,&l_42,&l_39,&l_39,&l_42,(void*)0,&l_43[3][3],&l_43[3][0]}},{{(void*)0,&l_39,(void*)0,(void*)0,&l_41,&l_39,&l_41,(void*)0},{&l_41,&l_39,&l_41,(void*)0,(void*)0,&l_39,(void*)0,&l_43[3][0]},{&l_43[3][3],(void*)0,&l_42,&l_39,&l_39,&l_42,(void*)0,&l_43[3][3]},{&l_43[3][3],(void*)0,&l_42,&l_41,(void*)0,&l_42,&l_42,&l_42},{&l_41,&g_150,&l_43[3][0],&g_150,&l_41,&l_42,&l_39,(void*)0},{(void*)0,(void*)0,&g_150,(void*)0,&l_42,&l_42,(void*)0,&g_150},{(void*)0,(void*)0,&g_150,&l_43[3][3],&l_42,&l_39,&l_39,(void*)0}},{{&l_42,&l_39,&l_43[3][0],(void*)0,&l_43[3][0],&l_39,&l_42,(void*)0},{&l_39,&l_39,&l_42,&l_43[3][3],&g_150,(void*)0,(void*)0,&g_150},{(void*)0,&l_42,&l_42,(void*)0,&g_150,(void*)0,(void*)0,(void*)0},{&l_39,&l_42,&l_41,&g_150,&l_43[3][0],&g_150,&l_41,&l_42},{&l_42,&l_42,(void*)0,&l_41,&l_42,(void*)0,&l_43[3][3],&l_43[3][3]},{(void*)0,&l_42,&l_39,&l_39,&l_42,(void*)0,&l_43[3][3],&l_43[3][0]},{(void*)0,&l_39,(void*)0,(void*)0,&l_41,&l_39,&l_41,(void*)0}},{{&l_41,&l_39,&l_41,(void*)0,(void*)0,&l_39,(void*)0,&l_43[3][0]},{&l_43[3][3],(void*)0,&l_42,&l_39,&l_39,&l_42,(void*)0,&l_43[3][3]},{&l_43[3][3],(void*)0,&l_42,&l_41,(void*)0,&l_42,&l_42,&l_42},{&l_41,&g_150,&l_43[3][0],&g_150,&l_41,&l_42,&l_39,(void*)0},{(void*)0,(void*)0,&l_39,(void*)0,(void*)0,(void*)0,(void*)0,&l_39},{&g_150,&g_150,&l_39,(void*)0,&l_43[3][0],&l_42,&l_43[3][3],&l_41},{(void*)0,&l_43[3][3],(void*)0,&g_150,(void*)0,&l_43[3][3],(void*)0,&l_41}}};
            uint64_t *l_373[8][2][10] = {{{&g_282,&g_282,&g_157,&g_157,&g_282,&g_157,&g_282,(void*)0,&g_282,&g_157},{&g_282,&g_157,&g_157,&g_157,&g_282,&g_157,&g_282,&g_282,&g_157,&g_282}},{{&g_282,&g_157,&g_157,&g_282,&g_282,&g_282,&g_157,(void*)0,&g_157,&g_282},{&g_157,&g_282,&g_157,&g_282,&g_282,&g_157,&g_157,&g_282,&g_282,&g_157}},{{&g_282,&g_157,&g_157,&g_282,&g_282,&g_282,&g_282,&g_157,&g_157,&g_282},{&g_282,&g_157,(void*)0,&g_282,&g_282,&g_157,&g_282,&g_157,&g_157,&g_282}},{{&g_157,&g_282,&g_157,&g_157,&g_282,&g_282,&g_157,&g_282,&g_282,&g_282},{&g_282,&g_282,&g_157,&g_157,&g_282,&g_157,&g_282,(void*)0,&g_282,&g_157}},{{&g_282,&g_157,&g_157,&g_157,&g_282,&g_157,&g_282,&g_282,&g_157,&g_282},{&g_282,&g_157,&g_157,&g_282,&g_282,&g_282,&g_157,(void*)0,&g_157,&g_282}},{{&g_157,&g_282,&g_157,&g_282,&g_282,&g_157,&g_157,&g_282,&g_282,&g_157},{&g_282,&g_157,&g_157,&g_282,&g_282,&g_282,&g_282,&g_157,&g_157,&g_282}},{{&g_282,&g_157,(void*)0,&g_282,&g_282,&g_157,&g_282,&g_157,&g_157,&g_282},{&g_157,&g_282,&g_157,&g_157,&g_282,&g_282,&g_157,&g_282,&g_282,&g_282}},{{&g_282,&g_282,&g_157,&g_157,&g_282,&g_157,&g_282,(void*)0,&g_282,&g_157},{&g_282,&g_157,&g_157,&g_157,&g_282,&g_157,&g_282,&g_282,&g_157,&g_282}}};
            uint64_t l_2269 = 18446744073709551615UL;
            int16_t l_2272 = 1L;
            int8_t * const *l_2278 = &l_1725;
            uint8_t l_2303 = 0x04L;
            int16_t l_2309 = 0xBB43L;
            int64_t l_2388 = (-10L);
            uint16_t l_2389 = 0UL;
            int32_t *l_2395 = (void*)0;
            int8_t *l_2398 = (void*)0;
            int i, j, k;
            for (g_10 = 0; (g_10 <= 2); g_10 += 1)
            { /* block id: 9 */
                int32_t *l_11 = &g_12;
                int32_t l_18[2][10] = {{(-9L),(-9L),(-5L),(-5L),(-9L),(-9L),(-5L),(-5L),(-9L),(-9L)},{(-9L),(-5L),(-5L),(-9L),(-9L),(-5L),(-5L),(-9L),(-9L),(-5L)}};
                int i, j;
                (*l_11) |= 0xFA3DFAD5L;
                (*l_11) |= l_5[g_7[0][5]];
                if (g_12)
                { /* block id: 12 */
                    int32_t *l_13 = &g_12;
                    int32_t *l_14 = (void*)0;
                    int32_t *l_15 = (void*)0;
                    int32_t *l_16 = (void*)0;
                    int32_t *l_17 = (void*)0;
                    int32_t *l_19 = &g_12;
                    int32_t *l_20 = &g_12;
                    int32_t *l_21 = (void*)0;
                    int32_t *l_22 = &g_12;
                    int32_t *l_23 = &g_12;
                    int32_t *l_24 = &g_12;
                    int32_t *l_25 = &g_12;
                    int32_t *l_26 = &g_12;
                    int32_t *l_27 = &g_12;
                    int32_t *l_28 = &g_12;
                    int32_t *l_29 = &l_18[1][4];
                    int32_t *l_30[7][8][4] = {{{&g_12,&g_12,&g_12,&g_7[0][5]},{&g_12,&g_12,&g_2[0],(void*)0},{&g_12,&g_7[0][5],(void*)0,&g_12},{(void*)0,&g_12,(void*)0,&l_18[0][9]},{&g_12,&g_2[0],&g_2[0],&l_18[1][9]},{&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_7[0][5],(void*)0},{&g_2[0],&g_12,&l_18[1][3],(void*)0}},{{&g_12,(void*)0,&g_7[0][5],(void*)0},{&g_7[0][5],&g_12,(void*)0,(void*)0},{&g_12,&g_12,&l_18[1][4],&g_12},{&g_12,&g_12,&g_7[0][5],&l_18[1][9]},{&l_18[0][9],&g_2[0],&g_12,&l_18[0][9]},{&g_2[0],&g_12,(void*)0,&g_12},{&g_2[0],&g_7[0][5],&g_12,(void*)0},{&l_18[0][9],&g_12,&g_7[0][5],&g_7[0][5]}},{{&g_12,&g_12,&l_18[1][4],&g_12},{&g_12,&l_18[0][9],(void*)0,&g_12},{&g_7[0][5],&g_2[0],&g_7[0][5],(void*)0},{&g_12,&g_2[0],&l_18[1][3],&g_12},{&g_2[0],&l_18[0][9],&g_7[0][5],&g_12},{&g_12,&g_12,&g_12,&g_7[0][5]},{&g_12,&g_12,&g_2[0],(void*)0},{&g_12,&g_7[0][5],(void*)0,&g_12}},{{(void*)0,&g_12,(void*)0,&l_18[0][9]},{&g_12,&g_2[0],&g_2[0],&l_18[1][9]},{&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_7[0][5],(void*)0},{&g_2[0],&g_12,&l_18[1][3],(void*)0},{&g_12,(void*)0,&g_7[0][5],(void*)0},{&g_7[0][5],&g_12,(void*)0,(void*)0},{&g_12,&g_12,&l_18[1][4],&g_12}},{{&g_12,&g_12,&g_7[0][5],&l_18[1][9]},{&l_18[0][9],&g_2[0],&g_12,&l_18[0][9]},{&g_2[0],&g_12,(void*)0,&g_12},{&g_2[0],&g_7[0][5],&g_12,(void*)0},{&l_18[0][9],&g_12,&g_7[0][5],&g_7[0][5]},{&g_12,&g_12,&l_18[1][4],&g_12},{&g_12,&l_18[0][9],(void*)0,&g_12},{&g_7[0][5],&g_2[0],&g_7[0][5],(void*)0}},{{&g_12,&g_2[0],&l_18[1][3],&g_12},{&g_2[0],&l_18[0][9],&g_7[0][5],&g_12},{&g_12,&g_12,&g_12,&g_7[0][5]},{&g_12,&g_12,&g_2[0],(void*)0},{&g_12,&g_7[0][5],(void*)0,&g_7[0][5]},{&g_2[0],&g_12,(void*)0,&l_18[1][3]},{(void*)0,(void*)0,&l_18[1][9],&g_7[0][5]},{&g_12,&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12,&g_2[0]},{(void*)0,(void*)0,&g_12,(void*)0},{&g_12,&g_2[0],&l_18[1][4],(void*)0},{&g_12,(void*)0,(void*)0,&g_2[0]},{&g_7[0][5],&g_12,&g_12,&g_12},{(void*)0,&g_12,&l_18[1][4],&g_7[0][5]},{&l_18[1][3],(void*)0,&g_12,&l_18[1][3]},{(void*)0,&g_12,&g_2[0],&g_7[0][5]}}};
                    int i, j, k;
                    g_34--;
                    return l_37;
                }
                else
                { /* block id: 15 */
                    (*l_11) = l_5[0];
                }
            }
            --g_49[0][3];
        }
    }
    (*g_837) = (safe_add_func_int16_t_s_s((((+(safe_mod_func_uint8_t_u_u(((((--(***g_2258)) != ((&l_2524 != (l_2489 , (*g_451))) != ((((((*g_146) = (safe_add_func_uint16_t_u_u(((*l_2725)--), (!(((~(g_2730 , (*l_2317))) & (((*l_2317) & ((*l_2317) == (safe_unary_minus_func_int8_t_s((safe_sub_func_int8_t_s_s((safe_sub_func_int64_t_s_s(((*l_2317) > (safe_unary_minus_func_uint16_t_u(((safe_sub_func_int16_t_s_s((safe_sub_func_int16_t_s_s((*l_2317), g_1160.f3)), (*l_2317))) & (*l_2317))))), 18446744073709551615UL)), (*l_2317))))))) != 0x2AL)) ^ (*l_2317)))))) | 0xCEL) == (*l_2317)) , 0UL) != (*l_2317)))) < (*l_2317)) && l_2741), 0xDDL))) != 0x15L) , 0x178DL), (*l_2317)));
    return (**g_1884);
}


/* ------------------------------------------ */
/* 
 * reads : g_2034 g_2035 g_1540 g_1541 g_201 g_289 g_194 g_875.f4 g_837 g_1134 g_375
 * writes: g_2258 g_201 g_289 g_194 g_875.f4 g_31
 */
static int32_t  func_52(int8_t * p_53, int32_t  p_54, int8_t * p_55)
{ /* block id: 1072 */
    uint8_t l_2248 = 251UL;
    int64_t *** const l_2249 = (void*)0;
    int32_t *l_2254[2][5] = {{(void*)0,&g_70,&g_70,(void*)0,&g_70},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    int32_t **l_2253 = &l_2254[1][1];
    union U1 * const *l_2259[6][2][10] = {{{&g_589[4],&g_589[4],(void*)0,(void*)0,&g_589[4],&g_589[1],&g_589[4],&g_589[4],&g_589[1],&g_589[4]},{&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[1],&g_589[4],(void*)0,&g_589[4],(void*)0}},{{&g_589[4],&g_589[3],&g_589[2],(void*)0,&g_589[2],&g_589[3],&g_589[4],&g_589[4],&g_589[4],&g_589[4]},{&g_589[4],&g_589[1],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[4],&g_589[1],&g_589[4]}},{{&g_589[4],&g_589[1],&g_589[4],(void*)0,(void*)0,&g_589[4],&g_589[4],&g_589[4],(void*)0,(void*)0},{(void*)0,&g_589[3],(void*)0,&g_589[1],(void*)0,&g_589[2],&g_589[4],&g_589[2],&g_589[2],&g_589[4]}},{{(void*)0,&g_589[4],&g_589[2],&g_589[2],&g_589[4],(void*)0,&g_589[4],&g_589[2],&g_589[4],&g_589[4]},{&g_589[3],&g_589[4],(void*)0,&g_589[4],&g_589[2],&g_589[4],(void*)0,&g_589[4],&g_589[3],(void*)0}},{{&g_589[3],&g_589[2],&g_589[4],&g_589[4],&g_589[4],(void*)0,(void*)0,&g_589[4],&g_589[4],&g_589[4]},{(void*)0,(void*)0,&g_589[4],&g_589[4],&g_589[4],&g_589[2],&g_589[3],&g_589[4],&g_589[3],&g_589[2]}},{{(void*)0,&g_589[4],&g_589[2],&g_589[4],(void*)0,&g_589[4],&g_589[3],(void*)0,&g_589[4],&g_589[4]},{&g_589[4],(void*)0,&g_589[4],&g_589[2],&g_589[2],&g_589[4],(void*)0,&g_589[4],&g_589[2],&g_589[4]}}};
    uint32_t *l_2260 = (void*)0;
    uint32_t *l_2261 = (void*)0;
    int32_t l_2262[8];
    uint32_t *l_2263 = (void*)0;
    uint32_t *l_2264 = &g_875.f4;
    uint32_t **l_2266[8] = {&g_1178,&g_1178,&g_1178,&g_1178,&g_1178,&g_1178,&g_1178,&g_1178};
    uint32_t ***l_2265 = &l_2266[6];
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_2262[i] = 0x7C3DF892L;
    (*g_837) = ((l_2248 || (l_2248 >= (((void*)0 == l_2249) , (safe_unary_minus_func_int16_t_s((&g_1178 != ((*l_2265) = (((*l_2264) ^= (l_2262[6] = (safe_add_func_int64_t_s_s(((****g_2034) &= (l_2253 == ((~(safe_rshift_func_uint8_t_u_s((((l_2248 || (p_54 != ((((g_2258 = (void*)0) == &g_1884) , l_2259[2][1][1]) != (void*)0))) > p_54) && p_54), 7))) , &g_478))), l_2248)))) , &g_1178)))))))) || (-1L));
    return (*g_1134);
}


/* ------------------------------------------ */
/* 
 * reads : g_104 g_32 g_873 g_1742 g_837 g_31 g_282 g_1178 g_1060.f3 g_691 g_147 g_844 g_134 g_150 g_454 g_1131 g_1764 g_547.f3 g_2 g_197 g_758 g_1724 g_1175 g_1231.f0 g_685 g_722 g_375 g_797.f0 g_1821 g_1525.f0 g_1845 g_1884 g_1885 g_1540 g_1541 g_201 g_289 g_194 g_1907 g_1924 g_1934 g_1311 g_1134 g_477 g_478 g_146 g_875.f4 g_2160 g_130 g_2186 g_1000 g_98 g_450 g_451 g_1160.f4 g_1990 g_875.f3
 * writes: g_104 g_31 g_282 g_758 g_197 g_134 g_201 g_150 g_12 g_837 g_130 g_142 g_1799 g_685 g_98 g_1884 g_1311 g_371 g_1924 g_1175 g_499 g_1060.f3 g_289 g_194 g_1717 g_1160.f4 g_1990 g_875.f4 g_875.f3 g_1000
 */
static int8_t * func_56(int16_t  p_57, int8_t * p_58, int32_t * const  p_59, int8_t * p_60)
{ /* block id: 798 */
    union U1 *l_1726 = &g_873[1];
    union U1 **l_1727 = (void*)0;
    int32_t l_1729 = 0x37950EA0L;
    int32_t l_1733[8] = {4L,4L,4L,4L,4L,4L,4L,4L};
    int32_t * const *l_1739[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t * const * const *l_1738[3][3];
    int32_t *l_1751 = (void*)0;
    uint64_t l_1753[4];
    union U2 l_1760 = {0};
    int16_t l_1824 = 0xBA7CL;
    int32_t **l_1842 = &l_1751;
    int32_t ***l_1841[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint64_t *l_1849[1];
    uint64_t **l_1848[9] = {&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0],&l_1849[0]};
    uint64_t l_1871 = 0UL;
    int64_t ***l_1935 = &g_1540;
    int16_t *l_1947[9][8] = {{&g_199,&g_199,(void*)0,&g_199,(void*)0,&g_199,&g_199,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_685,(void*)0,(void*)0,(void*)0},{(void*)0,&g_685,&g_199,&g_199,&g_685,(void*)0,&g_685,&g_199},{(void*)0,&g_685,(void*)0,(void*)0,(void*)0,(void*)0,&g_685,(void*)0},{&g_199,(void*)0,&g_199,(void*)0,&g_199,&g_199,(void*)0,&g_199},{&g_199,&g_199,(void*)0,&g_199,(void*)0,&g_199,&g_199,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_685,(void*)0,(void*)0,(void*)0},{(void*)0,&g_685,&g_199,&g_199,&g_685,(void*)0,&g_685,&g_199},{(void*)0,&g_685,(void*)0,(void*)0,(void*)0,(void*)0,&g_685,(void*)0}};
    int16_t **l_1946 = &l_1947[8][1];
    int64_t l_1949[10][9] = {{0x4735F9A2B9A70595LL,(-10L),0L,0x178B861DC6D656B4LL,0xE99682D67778A2A8LL,0x4735F9A2B9A70595LL,0x178B861DC6D656B4LL,(-10L),0x178B861DC6D656B4LL},{3L,1L,0x15B721B4F441BB71LL,0x15B721B4F441BB71LL,1L,3L,(-5L),0xAC8273B93AE4EAA6LL,0x15B721B4F441BB71LL},{0x4735F9A2B9A70595LL,0xE99682D67778A2A8LL,0x178B861DC6D656B4LL,0L,(-10L),0x4735F9A2B9A70595LL,0x4735F9A2B9A70595LL,(-10L),0L},{0xD6A0403249474AFCLL,1L,0xD6A0403249474AFCLL,3L,1L,0xD6A0403249474AFCLL,(-5L),0xFC5BD4C2B013735CLL,3L},{0x105288C9A19E427ELL,(-10L),0x178B861DC6D656B4LL,0x105288C9A19E427ELL,0x903FBBD09046BAB0LL,0x105288C9A19E427ELL,0x178B861DC6D656B4LL,(-10L),0x105288C9A19E427ELL},{(-4L),1L,0x15B721B4F441BB71LL,3L,0xEED1D386CE409406LL,(-4L),3L,0xAC8273B93AE4EAA6LL,3L},{0x178B861DC6D656B4LL,0x903FBBD09046BAB0LL,0L,0L,0x903FBBD09046BAB0LL,0x178B861DC6D656B4LL,1L,(-10L),0L},{(-4L),0xEED1D386CE409406LL,3L,0x15B721B4F441BB71LL,1L,(-4L),(-4L),1L,0x15B721B4F441BB71LL},{0x105288C9A19E427ELL,0x903FBBD09046BAB0LL,0x105288C9A19E427ELL,0x178B861DC6D656B4LL,(-10L),0x105288C9A19E427ELL,1L,3L,0x178B861DC6D656B4LL},{0xD6A0403249474AFCLL,1L,3L,0xD6A0403249474AFCLL,1L,0xD6A0403249474AFCLL,3L,1L,0xD6A0403249474AFCLL}};
    int32_t * const *l_2051 = &g_371;
    uint64_t l_2087 = 0x53DDC09E455454E8LL;
    uint32_t l_2128 = 18446744073709551610UL;
    int8_t l_2141 = 4L;
    uint32_t l_2148 = 0xECA30EE5L;
    int32_t l_2184 = (-2L);
    int32_t *l_2190[10] = {(void*)0,&g_12,&l_1729,&g_12,(void*)0,(void*)0,&g_758,&g_758,&g_758,&g_12};
    uint16_t **l_2243[10];
    int32_t **l_2244 = (void*)0;
    int32_t **l_2245 = &g_150;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
            l_1738[i][j] = &l_1739[0];
    }
    for (i = 0; i < 4; i++)
        l_1753[i] = 0x3507130D2054903DLL;
    for (i = 0; i < 1; i++)
        l_1849[i] = &l_1753[2];
    for (i = 0; i < 10; i++)
        l_2243[i] = &g_452;
lbl_1744:
    l_1726 = l_1726;
lbl_2234:
    for (g_104 = 0; (g_104 <= 6); g_104 += 1)
    { /* block id: 802 */
        int32_t *l_1728 = &g_758;
        int32_t *l_1730 = (void*)0;
        int32_t *l_1731 = &g_758;
        int32_t *l_1732[7][1] = {{(void*)0},{(void*)0},{&l_1729},{(void*)0},{(void*)0},{&l_1729},{(void*)0}};
        int16_t l_1734 = 0x6613L;
        uint32_t l_1735 = 0x6F127195L;
        int32_t * const * const **l_1740 = (void*)0;
        int32_t * const * const **l_1741 = &l_1738[1][1];
        int64_t *l_1762 = &g_289;
        uint64_t **l_1850 = (void*)0;
        int8_t *l_1942 = &g_1175;
        int8_t *l_1943 = &g_499;
        int16_t *l_1945[2][4][5] = {{{&l_1824,(void*)0,&l_1824,&g_199,&g_199},{&l_1734,(void*)0,&l_1734,&g_199,&g_199},{&l_1824,(void*)0,&l_1824,&g_199,&g_199},{&l_1734,(void*)0,&l_1734,&g_199,&g_199}},{{&l_1824,(void*)0,&l_1824,&g_199,&g_199},{&l_1734,(void*)0,&l_1734,&g_199,&g_199},{&l_1824,(void*)0,&l_1824,&g_199,&g_199},{&l_1734,(void*)0,&l_1734,&g_199,&g_199}}};
        int16_t **l_1944 = &l_1945[1][3][2];
        int16_t ***l_1948 = &l_1946;
        int16_t ***l_1950 = &g_1717;
        int64_t l_1992 = 5L;
        int64_t l_2086 = (-9L);
        int i, j, k;
        ++l_1735;
        if (((((*l_1741) = l_1738[1][1]) != ((g_32[g_104] , (*l_1726)) , g_1742)) != 1UL))
        { /* block id: 805 */
            if (g_104)
                goto lbl_1744;
            (*g_837) &= 0x49185267L;
        }
        else
        { /* block id: 808 */
            const uint32_t l_1752 = 0x77F27761L;
            int32_t l_1756 = (-2L);
            uint64_t *l_1757 = &g_282;
            uint8_t *l_1761 = (void*)0;
            uint8_t *l_1792 = &g_142[5];
            int8_t l_1793 = 0x42L;
            uint32_t l_1804 = 0x595C1C79L;
            uint64_t l_1889[6][10][4] = {{{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL},{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL}},{{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL},{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL}},{{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL},{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL}},{{0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL},{0xDBC4E3BEEDA7C4EDLL,0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL},{0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL,0x8E02811CD3E4B93ELL},{0x8E02811CD3E4B93ELL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x72C48B6E07D18BAELL,0x72C48B6E07D18BAELL,0x8E02811CD3E4B93ELL,18446744073709551615UL},{18446744073709551615UL,0x72C48B6E07D18BAELL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{0xDBC4E3BEEDA7C4EDLL,0x72C48B6E07D18BAELL,18446744073709551615UL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL}},{{18446744073709551615UL,0x72C48B6E07D18BAELL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{0xDBC4E3BEEDA7C4EDLL,0x72C48B6E07D18BAELL,18446744073709551615UL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{18446744073709551615UL,0x72C48B6E07D18BAELL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{0xDBC4E3BEEDA7C4EDLL,0x72C48B6E07D18BAELL,18446744073709551615UL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL}},{{18446744073709551615UL,0x72C48B6E07D18BAELL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{0xDBC4E3BEEDA7C4EDLL,0x72C48B6E07D18BAELL,18446744073709551615UL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{18446744073709551615UL,0x72C48B6E07D18BAELL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL,0xDBC4E3BEEDA7C4EDLL},{0xDBC4E3BEEDA7C4EDLL,0x72C48B6E07D18BAELL,18446744073709551615UL,18446744073709551615UL},{0x8E02811CD3E4B93ELL,0x8E02811CD3E4B93ELL,0xDBC4E3BEEDA7C4EDLL,18446744073709551615UL}}};
            uint32_t l_1890 = 1UL;
            int i, j, k;
            (*g_837) = (safe_mod_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((((void*)0 == l_1751) <= ((((((((l_1752 >= l_1753[2]) <= ((3UL & (safe_mod_func_int32_t_s_s(((*l_1728) = (((*l_1757)--) > p_57)), ((l_1760 , ((p_57 < (g_197 = (l_1761 == &g_1311))) == (-6L))) , 1UL)))) || 0x39D0L)) , (-9L)) >= 0xC02C1C14L) < l_1752) == p_57) != p_57) | (*g_1178))), p_57)), l_1756)), l_1752));
            (*g_1764) = func_64((*g_691), func_71(((void*)0 == l_1762), l_1756, l_1752), (!1UL), g_454);
            for (g_130 = (-9); (g_130 != (-6)); ++g_130)
            { /* block id: 816 */
                int16_t l_1771[2];
                int16_t *l_1774 = &l_1734;
                int16_t *l_1779 = &g_197;
                int16_t *l_1780[6][7] = {{&l_1771[0],&g_199,&l_1771[0],&l_1771[0],&g_685,&l_1771[0],(void*)0},{&g_685,&g_199,&g_685,&g_199,&g_199,(void*)0,&g_199},{&g_685,&l_1771[0],&l_1771[0],&g_685,(void*)0,&l_1771[0],&g_685},{&l_1771[0],&l_1771[0],&l_1771[0],&l_1771[1],&g_685,&l_1771[0],&l_1771[0]},{&l_1771[0],&g_685,&g_685,&g_685,&l_1771[0],&g_685,&g_685},{&g_685,(void*)0,&l_1771[0],&g_685,&l_1771[0],&l_1771[0],&g_199}};
                int i, j;
                for (i = 0; i < 2; i++)
                    l_1771[i] = 0xAD5CL;
                (*g_837) = ((safe_div_func_uint16_t_u_u(((p_57 = ((*l_1779) |= (safe_mod_func_uint64_t_u_u((l_1771[0] , l_1771[0]), ((safe_lshift_func_int16_t_s_s(((*l_1774) = l_1771[0]), p_57)) , ((*l_1757) |= (safe_div_func_uint64_t_u_u((l_1752 < ((0x8D752CF4L && (((0x2FL || (safe_add_func_uint8_t_u_u(((p_57 | ((*l_1774) = (p_57 == 0x4CF0L))) , g_547.f3), l_1752))) , l_1756) == 0xACC98E1EF3CAE547LL)) < (*p_59))), p_57)))))))) && (*l_1731)), l_1771[1])) & l_1756);
                return p_58;
            }
            if ((!((((safe_rshift_func_uint8_t_u_u((l_1756 || ((((*g_1724) != p_59) >= (safe_sub_func_uint8_t_u_u(((*l_1792) = (safe_mod_func_int32_t_s_s((safe_div_func_uint16_t_u_u(65535UL, p_57)), (safe_rshift_func_uint8_t_u_u(1UL, 5))))), (((void*)0 != &g_1535) & (65527UL < p_57))))) == p_57)), 2)) > l_1793) <= g_1175) && p_57)))
            { /* block id: 826 */
                (*g_837) ^= (*p_59);
            }
            else
            { /* block id: 828 */
                const int16_t l_1796[2] = {0x76C5L,0x76C5L};
                uint16_t *l_1798 = &g_1799[1];
                uint8_t **l_1805 = &l_1792;
                int16_t *l_1806 = &g_685;
                uint64_t l_1833 = 1UL;
                uint64_t **l_1856 = &l_1849[0];
                int32_t l_1873 = 1L;
                uint16_t *l_1923[8][8] = {{(void*)0,&g_104,&g_104,(void*)0,(void*)0,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,(void*)0,&g_104,&g_104,&g_104,(void*)0},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,(void*)0,(void*)0},{(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{(void*)0,(void*)0,&g_104,(void*)0,&g_104,&g_104,(void*)0,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,(void*)0,&g_104},{&g_104,&g_104,&g_104,(void*)0,&g_104,(void*)0,&g_104,&g_104},{&g_104,&g_104,(void*)0,&g_104,&g_104,(void*)0,&g_104,&g_104}};
                const int64_t **l_1938[8][4][5] = {{{&g_1536[5][4],&g_1536[1][4],&g_1536[3][1],&g_1536[1][4],(void*)0},{&g_1536[1][4],(void*)0,&g_1536[5][7],&g_1536[5][4],&g_1536[2][6]},{&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[4][3],&g_1536[5][4]},{&g_1536[1][2],&g_1536[1][4],&g_1536[3][7],&g_1536[3][1],&g_1536[1][4]}},{{&g_1536[1][4],(void*)0,(void*)0,&g_1536[1][4],&g_1536[1][4]},{&g_1536[1][4],&g_1536[2][6],&g_1536[1][4],&g_1536[1][4],&g_1536[1][4]},{&g_1536[5][7],&g_1536[3][3],&g_1536[1][7],(void*)0,&g_1536[1][4]},{&g_1536[1][0],&g_1536[1][4],&g_1536[1][2],&g_1536[1][4],&g_1536[5][7]}},{{(void*)0,&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[4][7]},{&g_1536[0][0],&g_1536[1][4],&g_1536[1][4],&g_1536[3][1],&g_1536[1][4]},{&g_1536[1][4],&g_1536[1][1],(void*)0,&g_1536[4][3],&g_1536[3][7]},{(void*)0,(void*)0,&g_1536[1][4],&g_1536[5][4],&g_1536[0][7]}},{{&g_1536[1][4],&g_1536[1][4],(void*)0,&g_1536[1][4],&g_1536[1][4]},{(void*)0,&g_1536[1][0],&g_1536[1][4],&g_1536[1][4],(void*)0},{&g_1536[1][4],&g_1536[3][3],&g_1536[1][4],(void*)0,(void*)0},{&g_1536[1][4],&g_1536[5][7],&g_1536[3][3],&g_1536[2][6],&g_1536[1][4]}},{{(void*)0,&g_1536[1][4],&g_1536[4][1],&g_1536[1][4],&g_1536[1][4]},{&g_1536[1][4],&g_1536[0][0],&g_1536[1][4],(void*)0,&g_1536[4][1]},{(void*)0,&g_1536[1][4],(void*)0,&g_1536[1][4],&g_1536[3][3]},{&g_1536[1][4],&g_1536[2][6],&g_1536[1][4],&g_1536[1][4],&g_1536[1][4]}},{{&g_1536[0][0],&g_1536[3][7],&g_1536[0][0],(void*)0,&g_1536[1][4]},{(void*)0,&g_1536[3][1],(void*)0,&g_1536[1][4],&g_1536[1][4]},{&g_1536[1][0],&g_1536[1][4],&g_1536[1][4],&g_1536[2][6],&g_1536[1][4]},{&g_1536[5][7],&g_1536[1][4],(void*)0,&g_1536[1][4],&g_1536[1][4]}},{{&g_1536[1][4],&g_1536[1][4],&g_1536[0][0],&g_1536[1][4],&g_1536[1][4]},{&g_1536[1][4],&g_1536[4][7],&g_1536[1][4],&g_1536[5][7],(void*)0},{&g_1536[1][2],&g_1536[1][4],(void*)0,&g_1536[1][4],&g_1536[1][4]},{&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[1][4]}},{{&g_1536[1][4],&g_1536[4][1],&g_1536[4][1],&g_1536[1][4],&g_1536[5][3]},{&g_1536[5][4],(void*)0,&g_1536[3][3],&g_1536[1][4],&g_1536[3][3]},{&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[1][4],&g_1536[3][3]},{&g_1536[1][4],&g_1536[0][7],&g_1536[1][4],&g_1536[1][4],&g_1536[5][3]}}};
                const int64_t ***l_1937 = &l_1938[1][1][2];
                const int64_t ****l_1936 = &l_1937;
                const int32_t *l_1939 = (void*)0;
                int i, j, k;
                if ((safe_div_func_int32_t_s_s((p_57 | ((*l_1806) ^= (l_1756 , (((0xAAB9C55F7D3B8963LL & 0xA71291099A515589LL) | (l_1796[0] , (!((*l_1798) = p_57)))) <= ((safe_div_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(l_1756, (((*l_1805) = &g_1311) == l_1761))), l_1756)) <= g_1231.f0))))), 4UL)))
                { /* block id: 833 */
                    for (g_201 = 0; (g_201 > 12); g_201 = safe_add_func_uint8_t_u_u(g_201, 1))
                    { /* block id: 836 */
                        if ((*g_722))
                            break;
                        (*l_1731) = (((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((safe_add_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s(l_1796[0], ((p_57 ^ (g_797[0][1][1].f0 , 0x0A20L)) & (safe_div_func_uint32_t_u_u((*g_1178), (*g_1178)))))), (p_57 ^ p_57))), 9)), l_1804)) < p_57) & p_57);
                        return (*g_691);
                    }
                    for (g_98 = 0; (g_98 < 25); g_98 = safe_add_func_int16_t_s_s(g_98, 7))
                    { /* block id: 843 */
                        return p_60;
                    }
                }
                else
                { /* block id: 846 */
                    uint8_t * volatile * volatile l_1823[9] = {&l_1761,&l_1761,&l_1761,&l_1761,&l_1761,&l_1761,&l_1761,&l_1761,&l_1761};
                    int i;
                    l_1823[2] = g_1821;
                }
                if (l_1824)
                { /* block id: 849 */
                    int32_t **l_1840 = &l_1751;
                    int32_t ***l_1839 = &l_1840;
                    uint64_t ***l_1851 = (void*)0;
                    uint64_t ***l_1852 = &g_459;
                    uint64_t ***l_1853 = &g_459;
                    uint64_t ***l_1854 = &g_459;
                    uint64_t ***l_1855 = &g_459;
                    int32_t l_1872 = 0x58A16AA2L;
                    uint8_t ***l_1886 = &g_1884;
                    (*l_1731) &= ((safe_mul_func_uint8_t_u_u((((*p_59) > (p_57 , 0xC6492994L)) != (safe_add_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(0x1915L, 0)), (((safe_div_func_uint16_t_u_u(p_57, 0x0202L)) < l_1833) != ((safe_rshift_func_int16_t_s_u((+p_57), (safe_sub_func_uint16_t_u_u(0xA667L, g_1525.f0)))) , p_57))))), p_57)) <= (*g_147));
                    (*l_1731) = (((p_57 ^ (l_1839 == l_1841[3])) & ((((safe_lshift_func_int8_t_s_u((((g_1845 , p_58) == (*g_691)) || l_1872), 3)) , 251UL) , l_1833) | l_1872)) || p_57);
                    l_1756 = ((safe_add_func_int32_t_s_s(((safe_div_func_int64_t_s_s((safe_div_func_uint64_t_u_u((safe_lshift_func_int16_t_s_u((safe_add_func_int8_t_s_s(((((void*)0 != &l_1840) != l_1804) || l_1833), ((((*l_1886) = g_1884) == &g_1885) == ((safe_mod_func_uint32_t_u_u(4294967287UL, 0xABCB524AL)) , 0xDCL)))), 13)), l_1889[4][6][1])), 4L)) && l_1890), l_1873)) ^ (*l_1731));
                }
                else
                { /* block id: 858 */
                    for (g_201 = 0; (g_201 <= (-12)); g_201--)
                    { /* block id: 861 */
                        return p_60;
                    }
                }
                (*g_1907) = func_78(l_1796[0], p_57, ((safe_rshift_func_int8_t_s_u((0x0BL <= ((safe_lshift_func_int8_t_s_u((safe_rshift_func_uint8_t_u_u(247UL, (safe_add_func_uint8_t_u_u(((*g_1885) = 0UL), (safe_div_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_div_func_int8_t_s_s((*g_147), l_1796[0])), ((l_1760 , l_1756) | (**g_1540)))), (-1L))))))), 7)) < p_57)), p_57)) | 1L));
                (*g_837) |= ((((safe_lshift_func_uint16_t_u_u((l_1756 = (((safe_rshift_func_uint8_t_u_u((safe_unary_minus_func_int16_t_s(((p_57 , 7UL) , (((safe_sub_func_uint32_t_u_u((7UL || (((safe_mul_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u(((safe_mul_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((l_1796[0] , (g_1924[0] &= ((*l_1798) = p_57))), (~(safe_rshift_func_uint8_t_u_s((((((safe_sub_func_int8_t_s_s((safe_div_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(p_57, (((g_1934 , l_1935) != ((*l_1936) = (void*)0)) && l_1889[5][4][3]))), l_1833)), (**g_1884))) > 1L) , (void*)0) == (void*)0) || p_57), (*g_147)))))), (*l_1728))) && 255UL), 15)) > l_1796[0]), 0x0619L)) == 0x0FB9L) == 0L)), (*g_1134))) > 4UL) && p_57)))), 4)) , 0x95L) & 0x95L)), 12)) >= p_57) , (*g_477)) == l_1939);
            }
        }
        (*l_1950) = (p_57 , ((((**g_1540) &= (p_57 ^ (((safe_mul_func_int8_t_s_s(((*l_1943) = ((*l_1942) ^= ((*g_146) = 0x93L))), ((l_1944 == ((*l_1948) = l_1946)) != ((**g_1884) <= (**g_1884))))) < (*p_59)) | ((*g_1178) &= (p_57 , l_1949[0][0]))))) , p_57) , &l_1947[8][3]));
        if (((safe_rshift_func_uint8_t_u_u(((*g_1885) = (safe_div_func_int64_t_s_s((((*g_1178)++) >= (*l_1731)), p_57))), 2)) | p_57))
        { /* block id: 883 */
            union U2 *l_1959 = &l_1760;
            int16_t ** const **l_1960 = (void*)0;
            for (g_1311 = 0; (g_1311 > 43); g_1311 = safe_add_func_uint16_t_u_u(g_1311, 1))
            { /* block id: 886 */
                return p_58;
            }
            (*g_837) = ((((*l_1959) = g_454) , &g_1103[0][5][0]) != l_1960);
        }
        else
        { /* block id: 891 */
            uint64_t l_1976 = 0UL;
            int16_t *** const *l_1997 = &l_1948;
            uint16_t ****l_1998 = (void*)0;
            uint64_t * const *l_2003 = (void*)0;
            const int64_t * const l_2021 = &g_289;
            int32_t l_2038 = (-1L);
            int32_t l_2058 = 0x28BAF499L;
            union U2 l_2061 = {0};
            int16_t ****l_2068 = &l_1950;
            int32_t l_2082 = 0xEAD1A9FFL;
            int32_t l_2085[3];
            int i;
            for (i = 0; i < 3; i++)
                l_2085[i] = 0x354EF1E9L;
            for (g_1160.f4 = 0; (g_1160.f4 >= 51); g_1160.f4 = safe_add_func_uint8_t_u_u(g_1160.f4, 1))
            { /* block id: 894 */
                for (g_197 = 13; (g_197 != 11); g_197 = safe_sub_func_uint32_t_u_u(g_197, 1))
                { /* block id: 897 */
                    return p_58;
                }
            }
            for (g_130 = 0; (g_130 < 14); g_130 = safe_add_func_int32_t_s_s(g_130, 3))
            { /* block id: 903 */
                uint32_t l_1979[10] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
                int32_t l_1991 = 0L;
                int8_t l_2013 = 0xB1L;
                int64_t *l_2020 = &l_1992;
                union U2 *l_2026 = &g_454;
                union U1 **l_2042 = &l_1726;
                int16_t *l_2053 = &g_685;
                int32_t l_2078 = (-1L);
                int32_t l_2079 = 0x88F715F3L;
                int32_t l_2080 = 0x19EA6B4FL;
                int32_t l_2081 = 0x41655DDBL;
                int32_t l_2083 = 0xD4A6B77FL;
                int32_t l_2084 = (-1L);
                int i;
            }
        }
    }
    for (g_1990 = 0; (g_1990 >= 52); g_1990 = safe_add_func_int8_t_s_s(g_1990, 8))
    { /* block id: 981 */
        uint8_t l_2120[3][1];
        uint16_t *l_2121 = &g_104;
        int32_t *l_2122[2][1];
        int8_t ***l_2133 = &g_690[0];
        int8_t ***l_2134 = &g_690[1];
        int16_t l_2136 = (-6L);
        uint8_t l_2144 = 252UL;
        uint64_t *l_2166[9][4] = {{&g_282,&l_1871,&g_282,(void*)0},{&g_282,(void*)0,&g_282,&l_1871},{&g_282,&l_1871,&g_282,(void*)0},{&g_282,(void*)0,&g_282,&l_1871},{&g_282,&l_1871,&g_282,(void*)0},{&g_282,(void*)0,&g_282,&l_1871},{&g_282,&l_1871,&g_282,(void*)0},{&g_282,(void*)0,&g_282,&l_1871},{&g_282,&l_1871,&g_282,(void*)0}};
        union U2 l_2188[2] = {{0},{0}};
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
                l_2120[i][j] = 0x6DL;
        }
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 1; j++)
                l_2122[i][j] = &g_7[0][5];
        }
        if ((((safe_sub_func_int16_t_s_s(2L, 0L)) == 255UL) < (((l_2120[0][0] && (((*l_2121) = p_57) || p_57)) , p_59) == l_2122[1][0])))
        { /* block id: 984 */
            int8_t l_2135 = 1L;
            int32_t l_2137 = 0xC8C6AE91L;
            int32_t l_2138 = 1L;
            int32_t l_2139 = 0xFF02A376L;
            int32_t l_2140[8] = {0x97F4B072L,6L,0x97F4B072L,6L,0x97F4B072L,6L,0x97F4B072L,6L};
            int16_t l_2142 = (-1L);
            int32_t l_2147 = 7L;
            int i;
            l_2144++;
            for (g_875.f4 = 0; (g_875.f4 <= 2); g_875.f4 += 1)
            { /* block id: 988 */
                int i, j;
                if (l_1949[(g_875.f4 + 1)][g_875.f4])
                    break;
                for (g_104 = 1; (g_104 <= 8); g_104 += 1)
                { /* block id: 992 */
                    return (*g_691);
                }
            }
            l_2148++;
        }
        else
        { /* block id: 997 */
            for (g_134 = 0; (g_134 < (-14)); g_134 = safe_sub_func_uint16_t_u_u(g_134, 3))
            { /* block id: 1000 */
                uint32_t l_2155 = 0xC2045AF7L;
                int8_t *l_2158 = &g_499;
                union U2 l_2159 = {0};
                for (g_31 = 0; (g_31 <= 9); g_31++)
                { /* block id: 1003 */
                    --l_2155;
                    (*g_2160) = func_64(&l_2141, l_2158, l_2155, l_2159);
                }
                for (g_875.f3 = 0; (g_875.f3 == 17); g_875.f3 = safe_add_func_uint8_t_u_u(g_875.f3, 7))
                { /* block id: 1009 */
                    return p_60;
                }
            }
        }
        for (g_197 = 9; (g_197 == 7); g_197 = safe_sub_func_int16_t_s_s(g_197, 5))
        { /* block id: 1016 */
            int8_t *l_2165 = &g_134;
            int32_t l_2169 = (-4L);
            uint8_t *l_2180 = &g_142[5];
            uint8_t *l_2181 = (void*)0;
            uint8_t *l_2182 = (void*)0;
            uint8_t *l_2183 = &l_2144;
            uint64_t *l_2185[3][7] = {{&l_1871,&g_1924[0],(void*)0,&g_1924[0],&l_1871,&l_1871,&g_1924[0]},{&g_1924[2],&g_157,&g_1924[2],&g_1924[0],&g_1924[0],&g_1924[2],&g_157},{&g_1924[0],&g_157,(void*)0,(void*)0,&g_157,&g_1924[0],&g_157}};
            int32_t l_2187 = 0L;
            int32_t **l_2189[2][4][2];
            int64_t ** const l_2214 = (void*)0;
            int64_t ** const *l_2213 = &l_2214;
            int64_t ***l_2215 = &g_1540;
            union U2 l_2217 = {0};
            uint16_t l_2232 = 0x40BBL;
            uint32_t l_2235 = 0xD1B13877L;
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    for (k = 0; k < 2; k++)
                        l_2189[i][j][k] = &g_837;
                }
            }
            l_2190[5] = func_64(l_2165, (((l_2166[1][0] == ((((((safe_mul_func_uint16_t_u_u((((0x27302506A3CE64A8LL || ((l_2169 , (l_2169 = (((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_rshift_func_int16_t_s_s((((*g_1885) &= ((p_57 , (-4L)) > (*g_147))) ^ ((*l_2183) = ((*l_2180) = (safe_add_func_uint16_t_u_u(((*l_2121) = ((safe_lshift_func_int16_t_s_s((8L <= (p_57 <= p_57)), p_57)) ^ 0xD307EAAFL)), p_57))))), 4)), p_57)), (*g_147))) , p_59) == (void*)0))) && (*g_1178))) && l_2184) && l_2169), p_57)) == 4294967295UL) && 0UL) & (*g_146)) , (*g_478)) , l_2185[1][3])) , g_2186) , p_60), l_2187, l_2188[0]);
            (*g_1764) = (*g_1131);
            if ((*p_59))
                break;
            for (l_2128 = (-8); (l_2128 < 58); l_2128 = safe_add_func_uint32_t_u_u(l_2128, 3))
            { /* block id: 1027 */
                uint64_t l_2199 = 0x7482D2424C7660EELL;
                union U2 **l_2202[9][9] = {{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006},{&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006,&g_2006}};
                int32_t l_2227 = 0x983BAC80L;
                int i, j;
                for (g_1000 = 0; (g_1000 == (-28)); g_1000--)
                { /* block id: 1030 */
                    union U2 **l_2203 = (void*)0;
                    union U2 ***l_2204 = &l_2203;
                    int32_t l_2210 = 0x6C35D1A9L;
                    int64_t ***l_2223 = &g_1540;
                    int32_t *l_2233 = (void*)0;
                }
                for (g_130 = 0; (g_130 <= 8); g_130 += 1)
                { /* block id: 1055 */
                    uint32_t l_2238 = 0xBE1AB0F5L;
                    l_2235++;
                    if (l_2184)
                        goto lbl_1744;
                    l_2238 = 1L;
                    for (g_98 = 0; (g_98 <= 8); g_98 += 1)
                    { /* block id: 1061 */
                        int i;
                        if (g_197)
                            goto lbl_2234;
                        if (g_1924[g_98])
                            continue;
                        if (g_134)
                            goto lbl_1744;
                    }
                }
            }
        }
    }
    (*l_2245) = (l_1760 , func_64(p_58, &l_2141, (safe_sub_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((((*g_450) == ((*l_1726) , l_2243[9])) , l_1935) != l_1935), 0UL)), (-1L))), l_1760));
    return p_60;
}


/* ------------------------------------------ */
/* 
 * reads : g_197 g_1160.f4 g_10 g_1724
 * writes: g_197 g_1160.f4 g_10 g_837
 */
static int16_t  func_61(int32_t * p_62, uint32_t  p_63)
{ /* block id: 604 */
    int64_t l_1223 = 0x54B97EAA3B0F834DLL;
    int32_t l_1249 = 0x94EF1291L;
    int32_t l_1254 = (-10L);
    int32_t l_1256 = 3L;
    int32_t l_1257 = 0L;
    int32_t l_1258 = 0xB8116DC2L;
    union U1 *l_1431 = &g_873[1];
    int16_t l_1500 = 1L;
    int16_t *l_1507 = &g_197;
    int16_t **l_1506[1][3];
    int32_t l_1560 = 0L;
    int32_t l_1561 = 0x4878EA5AL;
    int32_t l_1562 = 0xE2B41F61L;
    int32_t l_1563 = 0x833A63A1L;
    int32_t l_1564 = 1L;
    int32_t l_1565 = 1L;
    int32_t l_1566 = (-10L);
    int32_t l_1567 = (-9L);
    int32_t l_1568 = 1L;
    int32_t l_1569 = 8L;
    int32_t l_1570 = 0x78208BCFL;
    int32_t l_1571 = 7L;
    int32_t l_1572 = 0xEB136BD8L;
    int32_t l_1573[5] = {0x2587ADE8L,0x2587ADE8L,0x2587ADE8L,0x2587ADE8L,0x2587ADE8L};
    int16_t l_1579 = 0L;
    int16_t l_1581 = 0x1727L;
    uint8_t l_1582 = 0xA5L;
    int64_t **l_1597 = &g_1541[4];
    uint16_t **l_1635 = &g_452;
    int32_t l_1676 = 0x1745A55AL;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_1506[i][j] = &l_1507;
    }
    for (g_197 = 1; (g_197 >= 0); g_197 -= 1)
    { /* block id: 607 */
        uint64_t l_1218 = 18446744073709551606UL;
        int32_t l_1250 = 0L;
        int32_t l_1251 = 4L;
        int32_t l_1252 = 0x6276D17DL;
        int32_t l_1253 = 0x3EE6513DL;
        int32_t l_1255[1][9];
        uint8_t l_1339[9] = {0xB0L,0xB0L,0xB0L,0xB0L,0xB0L,0xB0L,0xB0L,0xB0L,0xB0L};
        uint64_t *l_1391 = &l_1218;
        uint64_t **l_1390[6];
        uint32_t l_1396 = 0UL;
        union U1 ***l_1470 = (void*)0;
        union U2 l_1479 = {0};
        const int16_t **l_1508 = (void*)0;
        uint16_t l_1511 = 65533UL;
        int64_t *l_1538 = &g_194;
        int64_t **l_1537[3][3];
        int32_t l_1546 = 0x9183C9F1L;
        uint16_t l_1554 = 0xD727L;
        int32_t *l_1557 = &g_375;
        int32_t *l_1558 = (void*)0;
        int32_t *l_1559[3][3] = {{&g_2[0],&g_2[0],&g_2[0]},{&l_1258,&l_1258,&l_1258},{&g_2[0],&g_2[0],&g_2[0]}};
        int16_t l_1574 = 9L;
        uint32_t l_1575 = 0x5D3B5E85L;
        union U2 *l_1661 = &l_1479;
        uint64_t l_1695 = 0UL;
        int8_t *l_1702 = &g_1175;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 9; j++)
                l_1255[i][j] = 0xD9D1D444L;
        }
        for (i = 0; i < 6; i++)
            l_1390[i] = &l_1391;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
                l_1537[i][j] = &l_1538;
        }
        for (g_1160.f4 = 0; (g_1160.f4 <= 2); g_1160.f4 += 1)
        { /* block id: 610 */
            uint16_t l_1232 = 65535UL;
            int32_t l_1233 = 0xE5C2F3E8L;
            int32_t l_1235[9][8][3] = {{{0xA3DD6779L,0xD1FD6C71L,1L},{8L,(-1L),(-1L)},{7L,0xD1FD6C71L,0xD1FD6C71L},{(-6L),(-1L),5L},{(-10L),0L,0x1DB698B8L},{0L,8L,1L},{7L,0xF84A5771L,(-1L)},{5L,8L,(-1L)}},{{0x099C11FFL,0L,0x63F1600CL},{0x7276B36BL,0xDF6BD1E2L,(-8L)},{0L,1L,1L},{0L,0x0AA726AAL,8L},{1L,1L,(-1L)},{(-1L),0xDF6BD1E2L,0L},{0x56B29CACL,0L,(-9L)},{(-1L),8L,1L}},{{0L,0xF84A5771L,(-7L)},{0x2ADC495EL,8L,8L},{(-6L),0L,0x08E35E20L},{5L,0xDF6BD1E2L,0xCCBE081CL},{0xD1FD6C71L,1L,0x63F1600CL},{(-1L),0x0AA726AAL,0xF6E9F2CAL},{1L,1L,(-7L)},{0L,0xDF6BD1E2L,1L}},{{1L,0L,0x7766D627L},{5L,8L,0L},{0xD1FD6C71L,0xF84A5771L,1L},{0x7276B36BL,8L,0xF6E9F2CAL},{(-5L),0L,1L},{0x2ADC495EL,0xDF6BD1E2L,0x0E3BBED6L},{7L,1L,0x08E35E20L},{5L,0x0AA726AAL,(-1L)}},{{0x56B29CACL,1L,1L},{0L,0xDF6BD1E2L,1L},{1L,0L,0x1DB698B8L},{0L,8L,1L},{7L,0xF84A5771L,(-1L)},{5L,8L,(-1L)},{0x099C11FFL,0L,0x63F1600CL},{0x7276B36BL,0xDF6BD1E2L,(-8L)}},{{0L,1L,1L},{0L,0x0AA726AAL,8L},{1L,1L,(-1L)},{(-1L),0xDF6BD1E2L,0L},{0x56B29CACL,0L,(-9L)},{(-1L),8L,1L},{0L,0xF84A5771L,(-7L)},{0x2ADC495EL,8L,8L}},{{(-6L),0L,0x08E35E20L},{5L,0xDF6BD1E2L,0xCCBE081CL},{0xD1FD6C71L,1L,0x63F1600CL},{(-1L),0x0AA726AAL,0xF6E9F2CAL},{1L,1L,(-7L)},{0L,0xDF6BD1E2L,1L},{1L,0L,0x7766D627L},{5L,8L,0L}},{{0xD1FD6C71L,0xF84A5771L,1L},{0x7276B36BL,8L,0xF6E9F2CAL},{(-5L),0L,1L},{0x2ADC495EL,0xDF6BD1E2L,0x0E3BBED6L},{7L,1L,0x08E35E20L},{5L,0x0AA726AAL,(-1L)},{0x56B29CACL,1L,1L},{0L,0xDF6BD1E2L,1L}},{{1L,0L,0x1DB698B8L},{0L,8L,1L},{7L,0xF84A5771L,(-1L)},{5L,8L,(-1L)},{(-9L),0x7B210B8DL,0x696E5156L},{0L,3L,(-3L)},{(-1L),2L,(-6L)},{8L,0x537D6F9EL,0L}}};
            int32_t l_1236 = 0xBC05026DL;
            uint64_t l_1259 = 0UL;
            int32_t **l_1313 = &g_837;
            uint64_t * const l_1389 = &g_157;
            uint64_t * const *l_1388 = &l_1389;
            int8_t *l_1462 = &g_134;
            union U1 **l_1477 = &l_1431;
            union U1 ***l_1476 = &l_1477;
            int i, j, k;
            --l_1218;
        }
        ++l_1575;
        for (g_10 = 6; (g_10 >= 2); g_10 -= 1)
        { /* block id: 739 */
            int16_t l_1578 = 0xF0F5L;
            int32_t l_1580[1][5];
            union U1 * const *l_1611 = &g_589[4];
            union U1 * const **l_1610 = &l_1611;
            int64_t *l_1613[1];
            union U1 **l_1640 = &g_589[4];
            union U1 ***l_1639 = &l_1640;
            int8_t l_1690[8][10] = {{(-1L),1L,0L,0x6CL,(-1L),0x6CL,0L,1L,(-1L),5L},{(-1L),9L,0x63L,0x13L,0x6CL,5L,5L,0x6CL,0x13L,0x63L},{5L,5L,0x6CL,0x13L,0x63L,9L,(-1L),5L,(-1L),9L},{0L,0x6CL,(-1L),0x6CL,0L,1L,(-1L),5L,1L,1L},{0x13L,5L,0x64L,9L,9L,0x64L,5L,0x13L,(-1L),1L},{5L,9L,5L,1L,0L,(-1L),0L,1L,5L,9L},{0x64L,1L,5L,0L,0x63L,1L,0x13L,0x13L,1L,0x63L},{1L,0x64L,0x64L,1L,0x6CL,1L,5L,5L,0x63L,5L}};
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 5; j++)
                    l_1580[i][j] = 1L;
            }
            for (i = 0; i < 1; i++)
                l_1613[i] = &g_194;
            l_1582--;
        }
    }
    (*g_1724) = p_62;
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_1131 g_837
 * writes:
 */
static int32_t * func_64(int8_t * p_65, int8_t * p_66, int8_t  p_67, union U2  p_68)
{ /* block id: 466 */
    int32_t *l_857 = &g_375;
    int32_t l_863[3];
    union U1 **l_877[1][3];
    union U1 *** const l_876 = &l_877[0][1];
    union U2 l_894 = {0};
    int64_t *l_948[6] = {&g_201,&g_201,&g_201,&g_201,&g_201,&g_201};
    uint8_t l_1135 = 4UL;
    uint64_t l_1181 = 0xD3865839E0D1AD9ALL;
    int8_t *l_1198[10][7][2] = {{{&g_134,&g_1175},{&g_499,&g_499},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_499,(void*)0},{(void*)0,(void*)0},{&g_1175,&g_1175}},{{&g_1175,&g_134},{&g_134,&g_499},{(void*)0,&g_134},{&g_1175,&g_499},{&g_1175,&g_134},{(void*)0,&g_499},{&g_134,&g_134}},{{&g_1175,&g_1175},{&g_1175,(void*)0},{(void*)0,(void*)0},{&g_499,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_499},{&g_499,&g_1175}},{{&g_134,(void*)0},{(void*)0,(void*)0},{&g_134,&g_134},{&g_499,&g_499},{&g_499,(void*)0},{(void*)0,(void*)0},{&g_499,&g_499}},{{&g_499,&g_134},{&g_134,(void*)0},{(void*)0,(void*)0},{&g_134,&g_1175},{&g_499,&g_499},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{&g_499,(void*)0},{(void*)0,(void*)0},{&g_1175,&g_1175},{&g_1175,&g_134},{&g_134,&g_499},{(void*)0,&g_134},{&g_1175,&g_499}},{{&g_1175,&g_134},{(void*)0,&g_499},{&g_134,&g_134},{&g_1175,&g_1175},{&g_1175,&g_499},{&g_499,&g_499},{(void*)0,(void*)0}},{{&g_499,&g_134},{&g_499,(void*)0},{&g_499,&g_499},{&g_499,&g_134},{(void*)0,&g_499},{&g_1175,&g_1175},{(void*)0,&g_134}},{{(void*)0,&g_1175},{(void*)0,&g_1175},{(void*)0,&g_134},{(void*)0,&g_1175},{&g_1175,&g_499},{(void*)0,&g_134},{&g_499,&g_499}},{{&g_499,(void*)0},{&g_499,&g_134},{&g_499,(void*)0},{(void*)0,&g_499},{&g_499,&g_499},{&g_134,&g_1175},{&g_499,(void*)0}}};
    uint8_t l_1210 = 0xDAL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_863[i] = 0x8040AB84L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_877[i][j] = &g_589[4];
    }
    for (p_67 = 22; (p_67 == 20); p_67 = safe_sub_func_uint32_t_u_u(p_67, 4))
    { /* block id: 469 */
        int32_t **l_858 = &l_857;
        uint32_t *l_861[6] = {&g_98,&g_98,&g_98,&g_98,&g_98,&g_98};
        int32_t l_862 = 0x67CBF635L;
        union U1 ** const **l_983 = (void*)0;
        uint64_t l_990[1];
        int8_t l_999 = 0x18L;
        int32_t l_1009 = (-1L);
        int32_t l_1011 = 3L;
        int32_t l_1013 = (-1L);
        int32_t l_1016 = (-6L);
        int32_t l_1017[4][5][3] = {{{0x0993CAF8L,0xA38DCD46L,0L},{0xE257B11CL,0L,0xE87410A9L},{0L,0x6DEDF04BL,0x3CC47236L},{0L,0L,0x6DEDF04BL},{0L,0xA38DCD46L,9L}},{{0L,4L,0L},{0L,0xE87410A9L,0xA38DCD46L},{0L,0L,0L},{0xE257B11CL,(-1L),9L},{0x0993CAF8L,(-1L),0x6DEDF04BL}},{{0xE87410A9L,0L,0x3CC47236L},{(-2L),0xE87410A9L,0xE87410A9L},{0xE87410A9L,4L,0L},{0x0993CAF8L,0xA38DCD46L,0L},{0xE257B11CL,0L,0xE87410A9L}},{{0L,0x6DEDF04BL,0x3CC47236L},{0L,0L,0x6DEDF04BL},{0L,0xA38DCD46L,9L},{0L,4L,0L},{0L,0xE87410A9L,0xA38DCD46L}}};
        int32_t l_1035 = 0xA49918DEL;
        uint16_t ****l_1087 = &g_450;
        union U2 *l_1094 = &g_449;
        int32_t *l_1159[1][5][4] = {{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}}};
        int32_t **l_1158 = &l_1159[0][0][3];
        const int32_t *l_1162 = &g_130;
        const int32_t **l_1161 = &l_1162;
        int16_t l_1174 = (-5L);
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_990[i] = 18446744073709551609UL;
        (*l_858) = l_857;
    }
    for (l_1135 = 0; (l_1135 <= 54); l_1135++)
    { /* block id: 600 */
        uint64_t l_1217 = 0x3219B5CDBDA4188ALL;
        l_1217 &= (safe_sub_func_uint8_t_u_u(p_67, 255UL));
    }
    return (*g_1131);
}


/* ------------------------------------------ */
/* 
 * reads : g_844 g_147 g_134 g_150 g_837
 * writes: g_134 g_201 g_150 g_12
 */
static int8_t * func_71(int32_t  p_72, uint16_t  p_73, int16_t  p_74)
{ /* block id: 458 */
    union U1 **l_845 = &g_589[4];
    union U1 **l_847 = &g_589[4];
    union U1 ***l_846 = &l_847;
    int32_t l_848[10][9] = {{0xC749C002L,(-6L),1L,8L,1L,(-6L),0xC749C002L,0x11DC4ACBL,8L},{(-1L),0x568BA168L,0xC535EFB4L,0x6CBC01FCL,0x81BC0254L,(-8L),0x568BA168L,1L,0x51C576FBL},{(-8L),0x81BC0254L,0x6CBC01FCL,0xC535EFB4L,0x568BA168L,(-1L),0x11DC4ACBL,0x11DC4ACBL,(-1L)},{(-6L),1L,8L,1L,(-6L),0xC749C002L,0x11DC4ACBL,8L,0x6CBC01FCL},{0x51C576FBL,(-1L),0xF962AAA9L,1L,0x618B331BL,0x51C576FBL,0x568BA168L,0xCCFFEDAEL,0xB6D412E9L},{1L,(-6L),0x81BC0254L,0xCCFFEDAEL,0x6CBC01FCL,0xC749C002L,0xC749C002L,0x6CBC01FCL,0xCCFFEDAEL},{0xC535EFB4L,0x24EF138BL,0xC535EFB4L,(-8L),1L,0xF962AAA9L,(-6L),0xCCFFEDAEL,0xC535EFB4L},{8L,(-8L),(-1L),1L,0xC2BCC8F8L,0xB6D412E9L,0xC535EFB4L,(-6L),0xF962AAA9L},{1L,(-1L),(-1L),(-8L),0x51C576FBL,0x51C576FBL,(-8L),(-1L),(-1L)},{(-8L),0xC749C002L,(-1L),0x618B331BL,0x14EB9EEAL,(-8L),0xC2BCC8F8L,0L,0x568BA168L}};
    int64_t *l_849 = &g_201;
    int32_t l_850 = 0x5895A595L;
    int32_t l_851 = 0x8FFE551AL;
    int32_t l_852 = 1L;
    int32_t *l_853 = (void*)0;
    int8_t *l_854[6][1] = {{&g_499},{&g_134},{&g_499},{&g_134},{&g_499},{&g_134}};
    int i, j;
    l_853 = func_78((l_850 = (p_73 < ((*l_849) = (safe_sub_func_uint16_t_u_u(((safe_add_func_int8_t_s_s(p_73, 0x2FL)) == ((*g_147) &= (l_848[2][8] = ((g_844 , l_845) == ((*l_846) = l_845))))), p_73))))), ((l_851 | p_73) <= p_74), l_852);
    return l_854[2][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_838 g_10
 * writes: g_10
 */
static uint16_t  func_75(int32_t * p_76, uint32_t  p_77)
{ /* block id: 455 */
    int16_t l_839 = 0x0363L;
    (*g_838) &= (*p_76);
    return l_839;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_150 g_837
 * writes: g_150 g_12
 */
static int32_t * func_78(int8_t  p_79, uint32_t  p_80, int32_t  p_81)
{ /* block id: 315 */
    int32_t **l_600 = &g_150;
    int32_t *l_644 = &g_7[0][5];
    uint16_t l_658 = 65535UL;
    uint32_t l_725 = 4294967287UL;
    int8_t l_755 = 0xE8L;
    const union U1 *l_801 = &g_127[2];
    const union U1 **l_800 = &l_801;
    int64_t l_813[8] = {0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL,0xC90BAEB18C28E5B0LL};
    int32_t l_814 = (-4L);
    int32_t l_815 = 9L;
    int32_t l_816 = 0x395181FFL;
    int32_t l_817 = 0x770DFFC2L;
    int32_t l_818 = 8L;
    int32_t l_819 = 0x4649EAA5L;
    int32_t l_820 = 0xE2313A89L;
    int32_t l_823 = 0xE5CB6719L;
    int32_t l_824[5] = {0x16788461L,0x16788461L,0x16788461L,0x16788461L,0x16788461L};
    int i;
    (*l_600) = &p_81;
    for (g_12 = 6; (g_12 >= 1); g_12 -= 1)
    { /* block id: 319 */
        int32_t l_601 = 0xCA261437L;
        uint64_t l_631 = 18446744073709551607UL;
        int32_t l_661 = (-1L);
        uint64_t l_759 = 0xC8AB5AB81F3F0E78LL;
        int32_t l_808 = 1L;
        int32_t l_809 = 6L;
        int32_t l_822 = (-1L);
        int32_t l_825 = 0xE1BB765DL;
        int32_t l_826 = 0x69A41AB5L;
        int32_t l_827[6][7] = {{0L,0xA997A378L,0L,0x97DACD23L,(-1L),0x490720D2L,2L},{0x233E695FL,0x3E768A9DL,0L,0L,0x3E768A9DL,0x233E695FL,0x3E768A9DL},{0L,0x97DACD23L,(-1L),0x490720D2L,2L,0x490720D2L,(-1L)},{0x6A34DE02L,0x6A34DE02L,0x233E695FL,0L,0x233E695FL,0x6A34DE02L,0x6A34DE02L},{0L,0x97DACD23L,0xF305981EL,0x97DACD23L,0L,7L,(-1L)},{0L,0x3E768A9DL,0L,0x233E695FL,0x233E695FL,0L,0x3E768A9DL}};
        int i, j;
    }
    (*l_600) = (*l_600);
    return g_837;
}


/* ------------------------------------------ */
/* 
 * reads : g_375 g_146 g_134 g_70 g_199 g_142 g_104 g_426 g_155 g_31 g_448 g_449 g_450 g_454 g_464 g_130 g_477 g_157 g_2 g_147 g_362.f0 g_92 g_499 g_260 g_374 g_194 g_127.f3 g_527 g_32
 * writes: g_31 g_134 g_199 g_104 g_450 g_459 g_371 g_142 g_477 g_197 g_499 g_127.f3 g_194 g_98 g_10
 */
static union U2  func_82(uint64_t  p_83, int64_t  p_84, uint32_t  p_85, int32_t  p_86)
{ /* block id: 185 */
    int32_t l_376 = (-1L);
    int8_t **l_383 = &g_147;
    int64_t *l_387 = &g_289;
    uint16_t **l_391 = (void*)0;
    uint32_t l_400 = 1UL;
    int32_t l_412 = (-4L);
    int32_t l_413 = (-1L);
    int32_t l_414 = 0x0AC787F3L;
    int32_t l_415 = (-6L);
    int32_t l_420[10] = {0x3681FFCAL,7L,0x3681FFCAL,7L,0x3681FFCAL,7L,0x3681FFCAL,7L,0x3681FFCAL,7L};
    uint8_t l_423[4][2] = {{7UL,252UL},{7UL,252UL},{7UL,252UL},{7UL,252UL}};
    int32_t *l_497[1];
    int32_t **l_496 = &l_497[0];
    int32_t ***l_495 = &l_496;
    uint32_t l_530 = 0xDAD82CFAL;
    int16_t *l_532 = (void*)0;
    union U2 l_598 = {0};
    int i, j;
    for (i = 0; i < 1; i++)
        l_497[i] = &g_130;
lbl_521:
    if (l_376)
    { /* block id: 186 */
        uint16_t ***l_392 = &l_391;
        int32_t *l_393 = &g_31;
        int32_t *l_394 = &g_12;
        int32_t *l_395 = &g_10;
        int32_t *l_396 = &g_375;
        int32_t *l_397 = (void*)0;
        int32_t *l_398 = &g_375;
        int32_t *l_399[3];
        int i;
        for (i = 0; i < 3; i++)
            l_399[i] = &g_375;
        for (g_31 = 0; (g_31 != (-6)); g_31--)
        { /* block id: 189 */
            uint8_t l_384 = 2UL;
            uint16_t *l_388[10][1][9] = {{{(void*)0,&g_104,(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,(void*)0}},{{(void*)0,&g_104,&g_104,&g_104,(void*)0,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}}};
            int32_t l_389 = 1L;
            int32_t l_390 = 0x870DFB60L;
            int i, j, k;
            l_390 &= (safe_sub_func_int16_t_s_s((safe_add_func_int16_t_s_s(((void*)0 == l_383), (((g_375 >= l_384) <= (0xD714L < (l_389 = ((safe_sub_func_uint8_t_u_u((0x54L == ((*g_146) &= (1UL > (&p_84 != l_387)))), l_384)) && p_86)))) && g_70))), p_85));
        }
        (*l_392) = l_391;
        l_400--;
    }
    else
    { /* block id: 196 */
        int32_t l_409 = 0xDE2CA2B7L;
        int32_t l_411 = 6L;
        int32_t l_418 = 7L;
        int32_t l_421[7][3][10] = {{{0x049E541DL,2L,0xC7CFEDC1L,9L,0x205C7960L,(-1L),2L,(-1L),0xFB7E95BBL,0xC474B8D6L},{0x4DC67079L,5L,0xC7CFEDC1L,0x205C7960L,0L,(-1L),5L,(-1L),0L,0x205C7960L},{0xC7CFEDC1L,0x56B2362DL,0xC7CFEDC1L,0xFB7E95BBL,9L,0x049E541DL,0x56B2362DL,(-1L),0xC474B8D6L,0L}},{{(-1L),0x6EF8A517L,0xC7CFEDC1L,0L,0xFB7E95BBL,0x4DC67079L,0x6EF8A517L,(-1L),9L,9L},{(-1L),0xE05D2D85L,0xC7CFEDC1L,0xC474B8D6L,0xC474B8D6L,0xC7CFEDC1L,0xE05D2D85L,(-1L),0x205C7960L,0xFB7E95BBL},{0x049E541DL,2L,0xC7CFEDC1L,9L,0x205C7960L,(-1L),2L,(-1L),0xFB7E95BBL,0xC474B8D6L}},{{0x4DC67079L,5L,0xC7CFEDC1L,0x205C7960L,0L,(-1L),5L,(-1L),0L,0x205C7960L},{0xC7CFEDC1L,0x56B2362DL,0xC7CFEDC1L,0xFB7E95BBL,9L,0x049E541DL,0x56B2362DL,(-1L),0xC474B8D6L,0L},{(-1L),0x6EF8A517L,0xC7CFEDC1L,0L,0xFB7E95BBL,0x4DC67079L,0x6EF8A517L,(-1L),9L,9L}},{{(-1L),0xE05D2D85L,0xC7CFEDC1L,0xC474B8D6L,0xC474B8D6L,0xC7CFEDC1L,0xE05D2D85L,(-1L),0x205C7960L,0xFB7E95BBL},{0x049E541DL,2L,0xC7CFEDC1L,9L,0x205C7960L,(-1L),2L,(-1L),0xFB7E95BBL,0xC474B8D6L},{0x4DC67079L,5L,0xC7CFEDC1L,0x205C7960L,0L,(-1L),5L,(-1L),0L,0x205C7960L}},{{0xC7CFEDC1L,0x56B2362DL,0xC7CFEDC1L,0xFB7E95BBL,9L,0x049E541DL,0x56B2362DL,(-1L),0xC474B8D6L,0L},{(-1L),0x6EF8A517L,0xC7CFEDC1L,0L,0xFB7E95BBL,0x4DC67079L,0x6EF8A517L,(-1L),9L,9L},{(-1L),0xE05D2D85L,0xC7CFEDC1L,0xC474B8D6L,0xC474B8D6L,0xC7CFEDC1L,0xE05D2D85L,(-1L),0x205C7960L,0xFB7E95BBL}},{{0x049E541DL,2L,0xC7CFEDC1L,9L,0x205C7960L,(-1L),2L,(-1L),0xFB7E95BBL,0xC474B8D6L},{0x4DC67079L,5L,0xC7CFEDC1L,0x205C7960L,0L,(-1L),5L,(-1L),0L,0x205C7960L},{0xC7CFEDC1L,0x56B2362DL,0xC7CFEDC1L,0xFB7E95BBL,9L,0x049E541DL,0x56B2362DL,(-1L),0xC474B8D6L,0L}},{{0xC70C22F5L,(-1L),(-1L),0x049E541DL,(-1L),0xFE43280FL,(-1L),(-7L),(-1L),(-1L)},{(-7L),7L,(-1L),0xC7CFEDC1L,0xC7CFEDC1L,(-1L),7L,(-7L),0x4DC67079L,(-1L)},{1L,(-6L),(-1L),(-1L),0x4DC67079L,0xC70C22F5L,(-6L),(-7L),(-1L),0xC7CFEDC1L}}};
        int i, j, k;
        for (g_199 = 5; (g_199 >= 1); g_199 -= 1)
        { /* block id: 199 */
            int32_t l_417 = 0x212D3318L;
            int32_t l_419 = 0xFA9D26E6L;
            int32_t l_422 = 1L;
            int32_t l_440 = (-1L);
            uint16_t l_441 = 0xCA7BL;
            int8_t *l_460 = (void*)0;
            int32_t **l_462 = (void*)0;
            int i;
            if (g_142[g_199])
            { /* block id: 200 */
                union U2 l_403 = {0};
                p_86 ^= p_84;
                return l_403;
            }
            else
            { /* block id: 203 */
                int64_t l_410 = 0x39A542B23A96139CLL;
                int32_t l_416[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_416[i] = 0x4D7CD612L;
                for (l_376 = 0; (l_376 <= (-26)); --l_376)
                { /* block id: 206 */
                    int32_t *l_406 = &g_375;
                    int32_t *l_407 = &g_31;
                    int32_t *l_408[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    ++l_423[3][0];
                    for (g_104 = 0; (g_104 <= 5); g_104 += 1)
                    { /* block id: 210 */
                        int i;
                        l_420[(g_104 + 1)] = 0xC66CDE4AL;
                        if (g_426)
                            continue;
                        l_420[(g_199 + 1)] = l_420[(g_104 + 1)];
                        (*l_407) ^= ((safe_div_func_uint8_t_u_u((safe_add_func_int16_t_s_s((!0x3E0E3A60E65FA4F4LL), (l_420[(g_104 + 1)] != (safe_mul_func_uint8_t_u_u(p_83, ((*g_146) = p_83)))))), l_420[(g_104 + 1)])) != g_155);
                    }
                }
            }
            for (l_415 = 0; (l_415 > (-26)); l_415 = safe_sub_func_uint64_t_u_u(l_415, 2))
            { /* block id: 221 */
                int32_t *l_436 = &g_10;
                int32_t *l_437 = &l_420[9];
                int32_t *l_438 = (void*)0;
                int32_t *l_439[9] = {&g_10,&g_10,&g_10,&g_10,&g_10,&g_10,&g_10,&g_10,&g_10};
                int i;
                ++l_441;
                if (p_84)
                    break;
                for (l_418 = 0; (l_418 < (-22)); l_418 = safe_sub_func_int8_t_s_s(l_418, 3))
                { /* block id: 226 */
                    uint16_t ****l_453 = &g_450;
                    uint64_t *l_456 = &g_282;
                    uint64_t ** const l_455 = &l_456;
                    if ((safe_sub_func_int8_t_s_s(l_440, (((g_448 , g_449) , ((*l_453) = g_450)) != (void*)0))))
                    { /* block id: 228 */
                        return g_454;
                    }
                    else
                    { /* block id: 230 */
                        uint64_t **l_458 = (void*)0;
                        uint64_t ***l_457[7] = {&l_458,(void*)0,(void*)0,&l_458,(void*)0,(void*)0,&l_458};
                        int i;
                        g_459 = l_455;
                    }
                    (*l_437) = ((g_454 , (l_460 = l_460)) == (void*)0);
                }
            }
            (*g_464) = &l_440;
        }
    }
    for (p_85 = (-29); (p_85 > 39); p_85 = safe_add_func_int32_t_s_s(p_85, 1))
    { /* block id: 242 */
        int32_t * const *l_480 = &g_478;
        int32_t *l_482 = &g_2[0];
        uint64_t l_502 = 0x9D4347E3F54B1979LL;
        uint8_t l_528 = 1UL;
        uint32_t *l_529 = &g_98;
        int32_t *l_533 = &g_10;
        union U1 *l_587 = &g_127[0];
        union U1 **l_586 = &l_587;
        int32_t l_590[1][1];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
                l_590[i][j] = 0x6D420E61L;
        }
        if (p_84)
        { /* block id: 243 */
            uint8_t *l_473 = &g_142[5];
            int32_t * const **l_479 = &g_477;
            int32_t *l_481 = &l_420[9];
            int32_t l_487 = 0x46B3206FL;
            uint16_t *l_490 = &g_104;
            int16_t *l_493 = (void*)0;
            int16_t *l_494 = &g_197;
            int8_t *l_498 = &g_499;
            int16_t *l_509 = (void*)0;
            int16_t *l_510 = &g_199;
            uint32_t *l_511 = &g_127[0].f3;
            (*l_481) = ((safe_lshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u(3UL, (safe_sub_func_uint16_t_u_u((p_83 <= ((((((*l_473) = g_130) | (!((l_412 |= (safe_lshift_func_uint8_t_u_s((((((*l_479) = g_477) != l_480) && (((((g_104 = (l_481 != l_482)) ^ ((((*l_481) & ((safe_mod_func_uint16_t_u_u((l_487 = (safe_add_func_int64_t_s_s(((&g_463[3] != (void*)0) | (*g_146)), g_157))), p_83)) | (*l_481))) > p_86) != (*l_482))) & (-1L)) , p_84) || 0x1F72CB4BL)) != 0xD1F98C6FL), 5))) == (*g_147)))) != g_362[6].f0) & g_92) , (*l_481))), p_85)))), 12)) <= 0xDAAAD415CB8369F3LL);
            if (((((*l_511) = (safe_mod_func_uint32_t_u_u(((((((--(*l_490)) >= ((*l_494) = (*l_481))) , l_495) != ((1UL && (p_85 != (((*l_510) = ((((*g_146) ^= 8L) <= ((*l_498) &= p_86)) , (((safe_div_func_int8_t_s_s((((l_502 > ((safe_rshift_func_int8_t_s_s((safe_mul_func_int16_t_s_s((safe_mod_func_uint8_t_u_u((((g_260 && (*l_482)) == (*l_482)) , g_362[6].f0), p_86)), 0L)), p_84)) , 0x56L)) > 0x61AAB334F2BF692ALL) , 0x3AL), p_84)) , (-10L)) , l_423[2][0]))) < p_83))) , (void*)0)) ^ l_420[9]) , g_374), 4294967295UL))) > (*l_481)) == p_85))
            { /* block id: 256 */
                uint8_t l_512 = 253UL;
                --l_512;
                for (p_83 = 0; (p_83 <= 1); p_83 += 1)
                { /* block id: 260 */
                    int32_t *l_515[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    if (p_85)
                        break;
                    (*l_481) |= l_512;
                    for (g_194 = 0; (g_194 <= 1); g_194 += 1)
                    { /* block id: 265 */
                        int32_t **l_516 = &l_515[0];
                        int i, j, k;
                        (*l_516) = l_515[0];
                        return g_454;
                    }
                }
            }
            else
            { /* block id: 270 */
                p_86 ^= (((safe_rshift_func_int8_t_s_s(((--(*l_511)) != 0x6206822AL), 2)) == (*l_481)) >= ((*l_383) != &g_134));
                return g_449;
            }
            return g_454;
        }
        else
        { /* block id: 276 */
            if (g_374)
                goto lbl_521;
        }
        (*l_533) = (safe_lshift_func_int8_t_s_s(((~((safe_sub_func_uint8_t_u_u((g_527 , ((((*l_529) = l_528) & (l_530 && ((p_83 || 0x4D91C60BL) ^ (((~((((void*)0 == l_532) > ((void*)0 != l_480)) , 0x3362L)) >= (*l_482)) & g_32[3])))) > p_83)), p_85)) | 0xF9B321A739BD94ADLL)) < p_84), 7));
        for (g_134 = 4; (g_134 >= 1); g_134 -= 1)
        { /* block id: 283 */
            int8_t *l_545 = &g_499;
            int16_t *l_546[6][10][4] = {{{&g_197,&g_199,(void*)0,&g_197},{(void*)0,&g_197,&g_199,(void*)0},{(void*)0,&g_199,(void*)0,&g_199},{&g_199,&g_199,&g_197,&g_197},{&g_199,&g_199,&g_199,&g_199},{(void*)0,(void*)0,(void*)0,&g_199},{&g_199,&g_197,&g_197,&g_197},{&g_197,&g_199,&g_199,(void*)0},{&g_199,&g_199,&g_197,&g_199},{&g_197,&g_197,&g_199,&g_197}},{{&g_199,&g_197,&g_199,&g_197},{(void*)0,(void*)0,&g_199,(void*)0},{&g_199,&g_197,&g_199,(void*)0},{&g_199,&g_197,&g_199,&g_197},{&g_199,&g_197,&g_199,(void*)0},{&g_199,(void*)0,&g_199,(void*)0},{&g_199,(void*)0,&g_199,(void*)0},{&g_199,(void*)0,&g_199,&g_199},{(void*)0,&g_199,&g_199,&g_199},{&g_199,&g_199,&g_199,&g_199}},{{&g_197,&g_199,&g_197,(void*)0},{&g_199,(void*)0,&g_199,&g_199},{&g_197,&g_197,&g_197,(void*)0},{&g_199,&g_197,(void*)0,&g_197},{(void*)0,&g_199,&g_199,&g_197},{&g_199,&g_199,&g_197,&g_197},{&g_199,(void*)0,(void*)0,&g_197},{(void*)0,&g_197,&g_199,&g_199},{(void*)0,&g_199,(void*)0,&g_199},{&g_197,&g_197,&g_197,&g_197}},{{&g_199,&g_199,&g_199,&g_199},{&g_197,&g_197,&g_197,(void*)0},{&g_197,&g_197,&g_197,&g_199},{(void*)0,(void*)0,&g_197,&g_197},{&g_197,&g_197,&g_199,(void*)0},{(void*)0,&g_197,&g_199,&g_199},{&g_199,&g_197,&g_197,(void*)0},{&g_197,&g_197,&g_197,&g_197},{&g_199,(void*)0,&g_197,&g_199},{&g_197,&g_197,&g_199,&g_199}},{{(void*)0,&g_199,&g_199,&g_197},{&g_199,&g_197,&g_197,&g_197},{&g_199,&g_199,&g_197,&g_199},{&g_199,(void*)0,&g_199,&g_197},{&g_199,&g_199,&g_197,&g_199},{(void*)0,&g_199,&g_197,(void*)0},{(void*)0,(void*)0,&g_197,&g_197},{&g_199,&g_197,&g_199,&g_199},{(void*)0,&g_197,(void*)0,&g_197},{&g_199,&g_197,(void*)0,&g_197}},{{&g_199,&g_199,&g_197,&g_199},{(void*)0,&g_197,&g_197,(void*)0},{&g_197,&g_197,&g_199,&g_197},{&g_199,&g_199,&g_199,&g_199},{&g_199,&g_197,&g_199,&g_199},{&g_199,&g_199,&g_197,(void*)0},{&g_199,&g_199,&g_197,&g_199},{(void*)0,&g_197,&g_197,&g_199},{&g_199,&g_199,&g_197,&g_197},{&g_199,&g_199,&g_199,&g_199}}};
            uint64_t *l_596 = (void*)0;
            int32_t **l_597 = &l_482;
            int i, j, k;
        }
    }
    return l_598;
}


/* ------------------------------------------ */
/* 
 * reads : g_98 g_32 g_157 g_170 g_70 g_127.f3 g_147 g_134 g_49 g_194 g_104 g_7 g_199 g_2 g_146 g_170.f0 g_142 g_149 g_150 g_12 g_260 g_280 g_34 g_299 g_282 g_10 g_92 g_31 g_371
 * writes: g_98 g_157 g_170.f4 g_142 g_104 g_194 g_197 g_199 g_201 g_134 g_147 g_12 g_31 g_150 g_260 g_282 g_10
 */
static int32_t * func_87(int32_t * p_88, const int8_t * p_89, int32_t  p_90)
{ /* block id: 23 */
    int8_t l_99 = (-1L);
    int32_t *l_129 = &g_130;
    int32_t l_140 = 0x9B9E4C78L;
    int32_t l_153 = 0x3E1635C7L;
    int32_t l_154[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int8_t **l_168 = &g_147;
    uint8_t l_224[3][6][8] = {{{0x2BL,0x92L,2UL,0xD1L,0x92L,8UL,0x92L,0xD1L},{0xAEL,0x92L,0xAEL,0UL,0x2BL,0xAEL,0x49L,0xDDL},{0x6FL,0UL,1UL,0x2BL,0xC4L,0xC4L,0x2BL,1UL},{0x6FL,0x6FL,8UL,0xD1L,0x2BL,0xE4L,0x6FL,0x2BL},{0xAEL,0x2BL,0UL,0xAEL,0x92L,0xAEL,0UL,0x2BL},{0x2BL,0x49L,1UL,0xD1L,0x49L,0UL,0x92L,1UL}},{{0xDDL,0x92L,0x8FL,0x2BL,0x2BL,0x8FL,0x92L,0xDDL},{0xC4L,0x2BL,1UL,0UL,0x6FL,0xC4L,0UL,0xD1L},{0x6FL,0xC4L,0UL,0xD1L,0UL,0xC4L,0x6FL,0UL},{0xDDL,0x2BL,0xDDL,1UL,0xC4L,0xD1L,0xAEL,0xAEL},{0x8FL,0xC4L,1UL,1UL,0xC4L,0x8FL,0xE4L,0x49L},{1UL,0xE4L,2UL,0xAEL,0x8FL,2UL,0xC4L,2UL}},{{0UL,0xAEL,0x92L,0xAEL,0UL,0x2BL,0xAEL,0x49L},{8UL,0UL,0x8FL,1UL,0xAEL,8UL,8UL,0xAEL},{1UL,0x8FL,0x8FL,1UL,0xE4L,2UL,0xAEL,0x8FL},{0xAEL,0xC4L,0x92L,0x49L,0xC4L,0xDDL,0xC4L,0x49L},{2UL,0xC4L,2UL,0x8FL,0xAEL,2UL,0xE4L,1UL},{0UL,0x8FL,1UL,0xAEL,8UL,8UL,0xAEL,1UL}}};
    const uint64_t l_225 = 0x09291A3040AC3147LL;
    uint16_t l_237 = 0x1AC1L;
    uint16_t *l_243 = &l_237;
    int32_t *l_294 = &g_10;
    uint32_t **l_354[3];
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_354[i] = (void*)0;
lbl_177:
    (*p_88) = l_99;
    for (g_98 = 0; (g_98 <= 6); g_98 += 1)
    { /* block id: 27 */
        int32_t *l_128 = &g_70;
        int32_t l_137 = 0x2D3B2C25L;
        int32_t l_138 = (-1L);
        int32_t l_139[4][8][1] = {{{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L}},{{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L}},{{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L}},{{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L},{0xE6BB7537L},{0x976AA722L}}};
        uint32_t l_163[2];
        int32_t **l_169 = &g_150;
        int8_t **l_171 = (void*)0;
        union U2 l_310[9] = {{0},{0},{0},{0},{0},{0},{0},{0},{0}};
        uint64_t l_311 = 18446744073709551615UL;
        int64_t *l_330 = &g_201;
        int32_t *l_331 = (void*)0;
        int16_t *l_335 = &g_199;
        int16_t **l_334[8] = {&l_335,&l_335,&l_335,&l_335,&l_335,&l_335,&l_335,&l_335};
        uint32_t **l_357 = (void*)0;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_163[i] = 18446744073709551613UL;
        if (((+g_32[g_98]) , g_32[g_98]))
        { /* block id: 28 */
            int32_t l_135 = 0x34933705L;
            int32_t *l_151 = &g_31;
            int32_t *l_152[5] = {&g_2[0],&g_2[0],&g_2[0],&g_2[0],&g_2[0]};
            int i;
            for (l_99 = 2; (l_99 >= 0); l_99 -= 1)
            { /* block id: 31 */
                uint16_t *l_103 = &g_104;
                int32_t *l_109 = &g_10;
                int32_t **l_131 = &l_128;
                int8_t *l_132 = (void*)0;
                int8_t *l_133 = &g_134;
                int8_t **l_145[2][9] = {{(void*)0,&l_132,&l_132,(void*)0,(void*)0,&l_132,&l_132,(void*)0,(void*)0},{&l_132,&l_132,&l_132,&l_132,&l_132,&l_132,&l_132,&l_132,&l_132}};
                int32_t **l_148 = &l_109;
                int i, j;
            }
            ++g_157;
        }
        else
        { /* block id: 54 */
            int32_t *l_160 = &l_154[6];
            int32_t *l_161 = &l_137;
            int32_t *l_162[5];
            int i;
            for (i = 0; i < 5; i++)
                l_162[i] = &l_154[7];
            ++l_163[0];
            if ((safe_div_func_int16_t_s_s((l_168 != ((((l_169 != &p_88) >= 0x4223EEF5A3A185DDLL) , g_170) , l_171)), 0x4ED1L)))
            { /* block id: 56 */
                const uint32_t *l_176 = &g_127[0].f3;
                int32_t l_203 = (-7L);
                int i;
                if ((safe_add_func_uint8_t_u_u(((safe_mod_func_int64_t_s_s(((void*)0 != l_176), g_32[g_98])) || 0x9F95L), g_70)))
                { /* block id: 57 */
                    int32_t l_195 = (-9L);
                    uint16_t l_204 = 0UL;
                    for (g_170.f4 = 0; g_170.f4 < 6; g_170.f4 += 1)
                    {
                        g_142[g_170.f4] = 1UL;
                    }
                    if (g_98)
                        goto lbl_177;
                    for (g_104 = 0; (g_104 <= 6); g_104 += 1)
                    { /* block id: 62 */
                        uint32_t l_190 = 0UL;
                        int64_t *l_193 = &g_194;
                        int16_t *l_196 = &g_197;
                        int16_t *l_198[9] = {&g_199,&g_199,&g_199,&g_199,&g_199,&g_199,&g_199,&g_199,&g_199};
                        int64_t *l_200 = &g_201;
                        int32_t l_202 = 6L;
                        uint64_t *l_221 = &g_157;
                        int i;
                        (*l_160) ^= (l_99 | ((((*l_200) = ((g_199 ^= ((*l_196) = ((0L != g_127[0].f3) , (safe_lshift_func_int8_t_s_s((p_90 , (*g_147)), ((((safe_add_func_uint64_t_u_u(g_49[0][2], ((safe_mod_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((((*l_193) = (l_190 <= ((4UL <= (safe_add_func_uint8_t_u_u(0x07L, 5UL))) & p_90))) >= p_90), 0xA3L)) , g_194), 0x9D7677ECL)), l_99)), g_157)) == p_90))) | l_195) != g_104) == g_7[2][7])))))) > g_104)) < l_202) ^ l_203));
                        ++l_204;
                        (*l_161) = (0x63L || ((*p_88) == (((-1L) & (safe_sub_func_uint64_t_u_u((((safe_lshift_func_uint8_t_u_s(p_90, ((safe_div_func_uint16_t_u_u((18446744073709551608UL & ((*l_221) = (((*l_160) , (safe_mod_func_int32_t_s_s((((safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(g_2[0], 0xD1B8L)), (((((**l_168) = (safe_mod_func_uint64_t_u_u((((*l_160) = (p_90 || (*g_146))) , 0UL), g_170.f0))) > 0xAFL) != 248UL) <= 0x7442C56231903B4FLL))) & g_142[2]) >= p_90), l_203))) < 9L))), 0x2D61L)) , (*g_146)))) | 0x747DE5B8L) >= (*p_88)), g_7[0][5]))) , g_32[2])));
                    }
                }
                else
                { /* block id: 74 */
                    (*l_161) = (g_32[g_98] <= g_142[3]);
                }
            }
            else
            { /* block id: 77 */
                (*l_161) ^= 0x34DABC89L;
            }
            (*l_161) = ((void*)0 == &g_157);
        }
        (*p_88) = ((safe_mul_func_uint8_t_u_u((((-1L) > (l_224[2][4][2] && l_224[2][4][2])) | (&g_134 == &g_92)), (((*l_168) = &g_134) != (void*)0))) && 0x0F1A88DFL);
        if ((l_225 | l_154[2]))
        { /* block id: 84 */
            int32_t **l_226 = &l_128;
            (*p_88) = (l_224[1][4][4] == (0x7B97L == ((void*)0 != l_226)));
        }
        else
        { /* block id: 86 */
            int32_t l_227 = 0x382E4A64L;
            int32_t l_235 = 3L;
            int32_t l_255[3][7][2] = {{{(-1L),0x9D4D7828L},{(-10L),0x5629A1DBL},{1L,(-1L)},{(-9L),1L},{0x4365AD23L,0x773B8873L},{0x4365AD23L,1L},{(-9L),(-1L)}},{{1L,0x5629A1DBL},{(-10L),0x9D4D7828L},{(-1L),0x4301AFE7L},{0x4301AFE7L,0x4301AFE7L},{(-1L),0x9D4D7828L},{(-10L),0x5629A1DBL},{1L,(-1L)}},{{(-9L),1L},{0x4365AD23L,0x773B8873L},{0x4365AD23L,1L},{(-9L),(-1L)},{1L,0x5629A1DBL},{(-10L),(-1L)},{0x4301AFE7L,0L}}};
            uint32_t l_290 = 4294967292UL;
            int i, j, k;
            if ((((&l_140 != (*g_149)) > (0L <= p_90)) <= (6L == p_90)))
            { /* block id: 87 */
                int8_t l_236[6] = {0x69L,0x69L,0x69L,0x69L,0x69L,0x69L};
                int i;
                for (g_12 = 6; (g_12 >= 0); g_12 -= 1)
                { /* block id: 90 */
                    int32_t *l_228 = &l_138;
                    int32_t *l_229 = &l_140;
                    int32_t *l_230 = &l_139[1][0][0];
                    int32_t *l_231 = &l_139[0][0][0];
                    int32_t *l_232 = (void*)0;
                    int32_t *l_233 = &l_140;
                    int32_t *l_234[2][9] = {{&g_10,(void*)0,&g_10,(void*)0,&g_10,(void*)0,&g_10,(void*)0,&g_10},{&l_138,&l_137,&l_137,&l_138,&l_138,&l_137,&l_137,&l_138,&l_138}};
                    int i, j;
                    for (g_31 = 0; (g_31 <= 6); g_31 += 1)
                    { /* block id: 93 */
                        (*l_169) = (*g_149);
                    }
                    l_237++;
                }
            }
            else
            { /* block id: 98 */
                uint32_t *l_244 = &g_98;
                int32_t l_250 = 0xEEBF030DL;
                int32_t l_251 = 0x5093E27FL;
                int32_t l_252 = 1L;
                int32_t l_254 = 0xECB74F96L;
                int32_t l_256 = (-1L);
                int32_t l_257 = 0xBC6659E4L;
                int32_t l_258 = 0xCB3112E2L;
                uint64_t *l_269[6];
                uint8_t *l_276 = (void*)0;
                uint8_t *l_277 = &g_142[1];
                int i;
                for (i = 0; i < 6; i++)
                    l_269[i] = &g_157;
                for (l_153 = 6; (l_153 >= 0); l_153 -= 1)
                { /* block id: 101 */
                    uint16_t *l_242 = &l_237;
                    uint16_t **l_241 = &l_242;
                    uint32_t **l_245 = (void*)0;
                    uint32_t *l_247 = &g_98;
                    uint32_t **l_246 = &l_247;
                    int32_t *l_248 = &g_12;
                    int32_t l_253 = 8L;
                    int32_t l_259 = 0xA4317E70L;
                    (*l_248) |= (((!((*p_88) < (((*l_241) = &g_104) != l_243))) , l_244) != ((*l_246) = l_128));
                    (*l_169) = &p_90;
                    for (l_227 = 0; (l_227 >= 0); l_227 -= 1)
                    { /* block id: 108 */
                        int32_t *l_249[5][6] = {{&l_154[6],&l_154[6],&l_139[0][6][0],&l_139[1][0][0],&l_235,&l_139[0][6][0]},{&l_139[1][0][0],&l_235,&l_139[0][6][0],&l_235,&l_139[1][0][0],&l_139[0][6][0]},{&l_235,&l_139[1][0][0],&l_139[0][6][0],&l_154[6],&l_154[6],&l_139[0][6][0]},{&l_154[6],&l_154[6],&l_139[0][6][0],&l_139[1][0][0],&l_235,&l_139[0][6][0]},{&l_139[1][0][0],&l_235,&l_139[0][6][0],&l_235,&l_139[1][0][0],&l_139[0][6][0]}};
                        int i, j;
                        g_260--;
                    }
                }
                g_282 = ((*p_88) = (safe_mod_func_int32_t_s_s((safe_add_func_int16_t_s_s(((g_170 , (((safe_add_func_uint32_t_u_u((0UL >= (g_157 ^= 0x61DE7B98AA170369LL)), (-4L))) ^ ((safe_rshift_func_uint8_t_u_u(((*l_277) = (safe_rshift_func_uint8_t_u_u(l_140, (safe_mul_func_int16_t_s_s(1L, 0x848EL))))), 1)) < (safe_mul_func_uint8_t_u_u(((&g_92 != g_280[1][7]) > p_90), (-1L))))) , g_34)) , p_90), l_254)), 0xD5F4E809L)));
                for (l_138 = 5; (l_138 >= 0); l_138 -= 1)
                { /* block id: 118 */
                    int16_t l_285[3][4] = {{1L,1L,0xB6C0L,1L},{1L,(-1L),(-1L),1L},{(-1L),1L,(-1L),(-1L)}};
                    int32_t l_286 = 0x96A4ADB7L;
                    int32_t l_287 = (-6L);
                    int32_t l_288 = 0xDC00BD43L;
                    uint16_t l_296[2][9][10] = {{{0x35F6L,65535UL,0x3AD7L,0x761EL,0x761EL,0x3AD7L,65535UL,0x35F6L,65534UL,0x761EL},{0x35F6L,65527UL,1UL,0x761EL,0UL,1UL,65535UL,1UL,0UL,0x761EL},{1UL,65535UL,1UL,0UL,0x761EL,1UL,65527UL,0x35F6L,0UL,0UL},{0x35F6L,65535UL,0x3AD7L,0x761EL,0x761EL,0x3AD7L,65535UL,0x35F6L,65534UL,0x761EL},{0x35F6L,65527UL,1UL,0x761EL,0UL,1UL,65535UL,1UL,0UL,0x761EL},{1UL,65535UL,1UL,0UL,0x761EL,1UL,65527UL,0x35F6L,0UL,0UL},{0x35F6L,65535UL,0x3AD7L,0x761EL,0x761EL,0x3AD7L,65535UL,0x35F6L,65534UL,0x761EL},{0x35F6L,65527UL,1UL,0x761EL,0UL,1UL,65535UL,1UL,0UL,0x761EL},{1UL,65535UL,1UL,0UL,0x761EL,1UL,65527UL,0x35F6L,0UL,0UL}},{{0x35F6L,65535UL,0x3AD7L,0x761EL,0x761EL,0x3AD7L,65535UL,0x35F6L,65534UL,0x761EL},{0x35F6L,65527UL,1UL,0x761EL,0UL,1UL,65535UL,1UL,0UL,0x761EL},{1UL,65535UL,1UL,0UL,0x761EL,1UL,65527UL,0x35F6L,0UL,0UL},{0x35F6L,65535UL,1UL,1UL,1UL,1UL,0x1939L,65535UL,0x35F6L,1UL},{65535UL,2UL,65535UL,1UL,0x3AD7L,65535UL,0x1939L,65535UL,0x3AD7L,1UL},{65535UL,0x1939L,65535UL,0x3AD7L,1UL,65535UL,2UL,65535UL,0x3AD7L,0x3AD7L},{65535UL,0x1939L,1UL,1UL,1UL,1UL,0x1939L,65535UL,0x35F6L,1UL},{65535UL,2UL,65535UL,1UL,0x3AD7L,65535UL,0x1939L,65535UL,0x3AD7L,1UL},{65535UL,0x1939L,65535UL,0x3AD7L,1UL,65535UL,2UL,65535UL,0x3AD7L,0x3AD7L}}};
                    int i, j, k;
                    for (l_99 = 6; (l_99 >= 0); l_99 -= 1)
                    { /* block id: 121 */
                        int32_t *l_283 = (void*)0;
                        int32_t *l_284[8][10] = {{&l_235,&l_250,&g_2[0],&g_7[1][1],&l_153,&g_7[1][1],&g_2[0],&l_250,&l_235,(void*)0},{&g_7[1][4],&g_12,&g_2[0],&l_153,&l_250,&l_250,&l_153,&g_2[0],&g_12,&g_7[1][4]},{&g_12,&g_7[1][1],&l_235,&l_153,(void*)0,&g_7[1][4],(void*)0,&l_153,&l_235,&g_7[1][1]},{(void*)0,&g_2[0],&g_7[1][4],&g_7[1][1],(void*)0,&l_139[2][1][0],&l_139[2][1][0],(void*)0,&g_7[1][1],&g_7[1][4]},{(void*)0,(void*)0,&g_12,(void*)0,&l_250,&l_139[2][1][0],&l_235,&l_139[2][1][0],&l_250,(void*)0},{(void*)0,&g_7[0][5],(void*)0,&l_139[2][1][0],&l_153,&g_7[1][4],&l_235,&l_235,&g_7[1][4],&l_153},{&g_12,(void*)0,(void*)0,&g_12,(void*)0,&l_250,&l_139[2][1][0],&l_235,&l_139[2][1][0],&l_250},{&g_7[1][4],&g_2[0],(void*)0,&g_2[0],&g_7[1][4],&g_7[1][1],(void*)0,&l_139[2][1][0],&l_139[2][1][0],(void*)0}};
                        int32_t *l_293[3];
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_293[i] = &l_153;
                        (*l_169) = &p_90;
                        --l_290;
                        return l_294;
                    }
                    for (l_237 = 1; (l_237 <= 6); l_237 += 1)
                    { /* block id: 128 */
                        int32_t *l_295[10][8][3] = {{{&l_252,(void*)0,(void*)0},{&l_255[0][2][0],&g_12,&l_138},{(void*)0,&l_252,(void*)0},{&l_286,&l_255[1][4][1],&l_255[1][3][1]},{(void*)0,&l_255[1][4][1],&g_12},{&g_12,&l_252,&l_139[1][0][0]},{&l_255[2][6][1],&g_12,&g_12},{&g_12,(void*)0,&l_255[0][2][0]}},{{(void*)0,&l_138,&l_255[0][2][0]},{&l_286,&l_255[0][2][0],&g_12},{(void*)0,&g_12,&l_139[1][0][0]},{&l_255[0][2][0],&l_255[0][2][0],&g_12},{&l_252,&l_138,&l_255[1][3][1]},{&l_252,(void*)0,(void*)0},{&l_255[0][2][0],&g_12,&l_138},{(void*)0,&l_252,(void*)0}},{{&l_286,&l_255[1][4][1],&l_255[1][3][1]},{(void*)0,&l_255[1][4][1],&l_252},{&l_255[2][6][1],&l_286,(void*)0},{&l_255[0][2][0],&l_255[2][6][1],&l_255[2][6][1]},{&l_255[2][6][1],&l_255[1][3][1],&g_12},{(void*)0,&g_12,&g_12},{&l_255[1][4][1],&g_12,&l_255[2][6][1]},{&l_138,&l_252,(void*)0}},{{&g_12,&g_12,&l_252},{&l_286,&g_12,&l_139[1][0][0]},{&l_286,&l_255[1][3][1],&l_138},{&g_12,&l_255[2][6][1],&g_12},{&l_138,&l_286,&l_138},{&l_255[1][4][1],(void*)0,&l_139[1][0][0]},{(void*)0,(void*)0,&l_252},{&l_255[2][6][1],&l_286,(void*)0}},{{&l_255[0][2][0],&l_255[2][6][1],&l_255[2][6][1]},{&l_255[2][6][1],&l_255[1][3][1],&g_12},{(void*)0,&g_12,&g_12},{&l_255[1][4][1],&g_12,&l_255[2][6][1]},{&l_138,&l_252,(void*)0},{&g_12,&g_12,&l_252},{&l_286,&g_12,&l_139[1][0][0]},{&l_286,&l_255[1][3][1],&l_138}},{{&g_12,&l_255[2][6][1],&g_12},{&l_138,&l_286,&l_138},{&l_255[1][4][1],(void*)0,&l_139[1][0][0]},{(void*)0,(void*)0,&l_252},{&l_255[2][6][1],&l_286,(void*)0},{&l_255[0][2][0],&l_255[2][6][1],&l_255[2][6][1]},{&l_255[2][6][1],&l_255[1][3][1],&g_12},{(void*)0,&g_12,&g_12}},{{&l_255[1][4][1],&g_12,&l_255[2][6][1]},{&l_138,&l_252,(void*)0},{&g_12,&g_12,&l_252},{&l_286,&g_12,&l_139[1][0][0]},{&l_286,&l_255[1][3][1],&l_138},{&g_12,&l_255[2][6][1],&g_12},{&l_138,&l_286,&l_138},{&l_255[1][4][1],(void*)0,&l_139[1][0][0]}},{{(void*)0,(void*)0,&l_252},{&l_255[2][6][1],&l_286,(void*)0},{&l_255[0][2][0],&l_255[2][6][1],&l_255[2][6][1]},{&l_255[2][6][1],&l_255[1][3][1],&g_12},{(void*)0,&g_12,&g_12},{&l_255[1][4][1],&g_12,&l_255[2][6][1]},{&l_138,&l_252,(void*)0},{&g_12,&g_12,&l_252}},{{&l_286,&g_12,&l_139[1][0][0]},{&l_286,&l_255[1][3][1],&l_138},{&g_12,&l_255[2][6][1],&g_12},{&l_138,&l_286,&l_138},{&l_255[1][4][1],(void*)0,&l_139[1][0][0]},{(void*)0,(void*)0,&l_252},{&l_255[2][6][1],&l_286,(void*)0},{&l_255[0][2][0],&l_255[2][6][1],&l_255[2][6][1]}},{{&l_255[2][6][1],&l_255[1][3][1],&g_12},{(void*)0,&g_12,&g_12},{&l_255[1][4][1],&g_12,&l_255[2][6][1]},{&l_138,&l_252,(void*)0},{&g_12,&g_12,&l_252},{&l_286,&g_12,&l_139[1][0][0]},{&l_286,&l_255[1][3][1],&l_138},{&g_12,&l_255[2][6][1],&g_12}}};
                        int16_t *l_300 = (void*)0;
                        int16_t *l_301 = &l_285[0][2];
                        uint32_t *l_302 = &l_290;
                        int64_t *l_325 = &g_289;
                        int64_t **l_324 = &l_325;
                        int i, j, k;
                        --l_296[1][2][2];
                        g_31 &= (l_311 = (g_299 , (l_257 = (((*l_294) = (((*l_302) = (((*p_88) &= ((((*l_301) |= 0x6C9BL) && ((*l_301) = g_282)) , 1L)) == 0x37018047L)) , ((safe_unary_minus_func_uint32_t_u(((*l_302) = (~((safe_div_func_uint64_t_u_u((safe_div_func_int32_t_s_s((+(((&g_142[0] == (l_310[0] , &g_142[0])) | (l_286 = (&g_130 != p_88))) < g_10)), g_12)), 0x7D3A6776AFE39425LL)) <= 0xE0L))))) || (*p_89)))) | 4294967295UL))));
                        (*p_88) = ((0xB8L & (l_255[1][4][1] = (-8L))) >= ((*g_149) == ((safe_lshift_func_uint16_t_u_u((g_7[0][5] > (((((safe_add_func_uint64_t_u_u(4UL, (((safe_sub_func_int8_t_s_s((safe_mod_func_int8_t_s_s(0L, (((safe_rshift_func_uint16_t_u_u(((((*l_324) = &g_289) == (((g_282++) > ((0x1EA7L > (safe_lshift_func_uint16_t_u_u(((0x61L < l_285[2][3]) & 0x0F14374E9201B347LL), p_90))) | p_90)) , l_330)) != l_235), 3)) && p_90) , 0xD2L))), g_199)) != l_227) >= 0L))) && 6L) , &p_89) == l_168) > g_7[2][5])), (*l_294))) , (void*)0)));
                    }
                    return l_331;
                }
            }
            if (l_235)
                break;
            (*p_88) ^= (g_299 , (*l_294));
        }
        for (g_157 = 0; (g_157 <= 1); g_157 += 1)
        { /* block id: 153 */
            int16_t *l_333 = &g_199;
            int16_t **l_332 = &l_333;
            int32_t l_344 = 0x086BAE5DL;
            int32_t l_345 = 0xE318F79FL;
            (*l_294) = ((*p_88) = 0xA206E50AL);
            l_334[2] = l_332;
            for (l_237 = 0; (l_237 <= 8); l_237 += 1)
            { /* block id: 159 */
                int32_t l_336 = 0x593DA989L;
                int32_t l_343 = 8L;
                int32_t l_346[1];
                int32_t **l_369[1];
                int32_t ***l_370 = &l_169;
                int i;
                for (i = 0; i < 1; i++)
                    l_346[i] = 0xD99BF391L;
                for (i = 0; i < 1; i++)
                    l_369[i] = (void*)0;
            }
        }
    }
    return g_371;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_7[i][j], "g_7[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_32[i], "g_32[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_49[i][j], "g_49[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_127[i].f0, "g_127[i].f0", print_hash_value);
        transparent_crc(g_127[i].f1, "g_127[i].f1", print_hash_value);
        transparent_crc(g_127[i].f2, "g_127[i].f2", print_hash_value);
        transparent_crc(g_127[i].f3, "g_127[i].f3", print_hash_value);
        transparent_crc(g_127[i].f4, "g_127[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_142[i], "g_142[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_170.f0, "g_170.f0", print_hash_value);
    transparent_crc(g_170.f1, "g_170.f1", print_hash_value);
    transparent_crc(g_170.f2, "g_170.f2", print_hash_value);
    transparent_crc(g_170.f3, "g_170.f3", print_hash_value);
    transparent_crc(g_170.f4, "g_170.f4", print_hash_value);
    transparent_crc(g_194, "g_194", print_hash_value);
    transparent_crc(g_197, "g_197", print_hash_value);
    transparent_crc(g_199, "g_199", print_hash_value);
    transparent_crc(g_201, "g_201", print_hash_value);
    transparent_crc(g_260, "g_260", print_hash_value);
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    transparent_crc(g_289, "g_289", print_hash_value);
    transparent_crc(g_299.f0, "g_299.f0", print_hash_value);
    transparent_crc(g_347, "g_347", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_362[i].f0, "g_362[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_374, "g_374", print_hash_value);
    transparent_crc(g_375, "g_375", print_hash_value);
    transparent_crc(g_426, "g_426", print_hash_value);
    transparent_crc(g_448.f0, "g_448.f0", print_hash_value);
    transparent_crc(g_499, "g_499", print_hash_value);
    transparent_crc(g_527.f0, "g_527.f0", print_hash_value);
    transparent_crc(g_547.f0, "g_547.f0", print_hash_value);
    transparent_crc(g_547.f1, "g_547.f1", print_hash_value);
    transparent_crc(g_547.f2, "g_547.f2", print_hash_value);
    transparent_crc(g_547.f3, "g_547.f3", print_hash_value);
    transparent_crc(g_547.f4, "g_547.f4", print_hash_value);
    transparent_crc(g_630.f0, "g_630.f0", print_hash_value);
    transparent_crc(g_630.f1, "g_630.f1", print_hash_value);
    transparent_crc(g_630.f2, "g_630.f2", print_hash_value);
    transparent_crc(g_630.f3, "g_630.f3", print_hash_value);
    transparent_crc(g_630.f4, "g_630.f4", print_hash_value);
    transparent_crc(g_669.f0, "g_669.f0", print_hash_value);
    transparent_crc(g_669.f1, "g_669.f1", print_hash_value);
    transparent_crc(g_669.f2, "g_669.f2", print_hash_value);
    transparent_crc(g_669.f3, "g_669.f3", print_hash_value);
    transparent_crc(g_669.f4, "g_669.f4", print_hash_value);
    transparent_crc(g_672.f0, "g_672.f0", print_hash_value);
    transparent_crc(g_672.f1, "g_672.f1", print_hash_value);
    transparent_crc(g_672.f2, "g_672.f2", print_hash_value);
    transparent_crc(g_672.f3, "g_672.f3", print_hash_value);
    transparent_crc(g_672.f4, "g_672.f4", print_hash_value);
    transparent_crc(g_683, "g_683", print_hash_value);
    transparent_crc(g_685, "g_685", print_hash_value);
    transparent_crc(g_696.f0, "g_696.f0", print_hash_value);
    transparent_crc(g_696.f1, "g_696.f1", print_hash_value);
    transparent_crc(g_696.f2, "g_696.f2", print_hash_value);
    transparent_crc(g_696.f3, "g_696.f3", print_hash_value);
    transparent_crc(g_696.f4, "g_696.f4", print_hash_value);
    transparent_crc(g_758, "g_758", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_797[i][j][k].f0, "g_797[i][j][k].f0", print_hash_value);
                transparent_crc(g_797[i][j][k].f1, "g_797[i][j][k].f1", print_hash_value);
                transparent_crc(g_797[i][j][k].f2, "g_797[i][j][k].f2", print_hash_value);
                transparent_crc(g_797[i][j][k].f3, "g_797[i][j][k].f3", print_hash_value);
                transparent_crc(g_797[i][j][k].f4, "g_797[i][j][k].f4", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_806.f0, "g_806.f0", print_hash_value);
    transparent_crc(g_821, "g_821", print_hash_value);
    transparent_crc(g_844.f0, "g_844.f0", print_hash_value);
    transparent_crc(g_844.f1, "g_844.f1", print_hash_value);
    transparent_crc(g_844.f2, "g_844.f2", print_hash_value);
    transparent_crc(g_844.f3, "g_844.f3", print_hash_value);
    transparent_crc(g_844.f4, "g_844.f4", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_873[i].f0, "g_873[i].f0", print_hash_value);
        transparent_crc(g_873[i].f1, "g_873[i].f1", print_hash_value);
        transparent_crc(g_873[i].f2, "g_873[i].f2", print_hash_value);
        transparent_crc(g_873[i].f3, "g_873[i].f3", print_hash_value);
        transparent_crc(g_873[i].f4, "g_873[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_875.f0, "g_875.f0", print_hash_value);
    transparent_crc(g_875.f1, "g_875.f1", print_hash_value);
    transparent_crc(g_875.f2, "g_875.f2", print_hash_value);
    transparent_crc(g_875.f3, "g_875.f3", print_hash_value);
    transparent_crc(g_875.f4, "g_875.f4", print_hash_value);
    transparent_crc(g_912, "g_912", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_923[i][j].f0, "g_923[i][j].f0", print_hash_value);
            transparent_crc(g_923[i][j].f1, "g_923[i][j].f1", print_hash_value);
            transparent_crc(g_923[i][j].f2, "g_923[i][j].f2", print_hash_value);
            transparent_crc(g_923[i][j].f3, "g_923[i][j].f3", print_hash_value);
            transparent_crc(g_923[i][j].f4, "g_923[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_975.f0, "g_975.f0", print_hash_value);
    transparent_crc(g_975.f1, "g_975.f1", print_hash_value);
    transparent_crc(g_975.f2, "g_975.f2", print_hash_value);
    transparent_crc(g_975.f3, "g_975.f3", print_hash_value);
    transparent_crc(g_975.f4, "g_975.f4", print_hash_value);
    transparent_crc(g_1000, "g_1000", print_hash_value);
    transparent_crc(g_1060.f0, "g_1060.f0", print_hash_value);
    transparent_crc(g_1060.f1, "g_1060.f1", print_hash_value);
    transparent_crc(g_1060.f2, "g_1060.f2", print_hash_value);
    transparent_crc(g_1060.f3, "g_1060.f3", print_hash_value);
    transparent_crc(g_1060.f4, "g_1060.f4", print_hash_value);
    transparent_crc(g_1073.f0, "g_1073.f0", print_hash_value);
    transparent_crc(g_1160.f0, "g_1160.f0", print_hash_value);
    transparent_crc(g_1160.f1, "g_1160.f1", print_hash_value);
    transparent_crc(g_1160.f2, "g_1160.f2", print_hash_value);
    transparent_crc(g_1160.f3, "g_1160.f3", print_hash_value);
    transparent_crc(g_1160.f4, "g_1160.f4", print_hash_value);
    transparent_crc(g_1175, "g_1175", print_hash_value);
    transparent_crc(g_1231.f0, "g_1231.f0", print_hash_value);
    transparent_crc(g_1311, "g_1311", print_hash_value);
    transparent_crc(g_1333.f0, "g_1333.f0", print_hash_value);
    transparent_crc(g_1333.f1, "g_1333.f1", print_hash_value);
    transparent_crc(g_1333.f2, "g_1333.f2", print_hash_value);
    transparent_crc(g_1333.f3, "g_1333.f3", print_hash_value);
    transparent_crc(g_1333.f4, "g_1333.f4", print_hash_value);
    transparent_crc(g_1413.f0, "g_1413.f0", print_hash_value);
    transparent_crc(g_1525.f0, "g_1525.f0", print_hash_value);
    transparent_crc(g_1658, "g_1658", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1799[i], "g_1799[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1845.f0, "g_1845.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1924[i], "g_1924[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1934.f0, "g_1934.f0", print_hash_value);
    transparent_crc(g_1969.f0, "g_1969.f0", print_hash_value);
    transparent_crc(g_1969.f1, "g_1969.f1", print_hash_value);
    transparent_crc(g_1969.f2, "g_1969.f2", print_hash_value);
    transparent_crc(g_1969.f3, "g_1969.f3", print_hash_value);
    transparent_crc(g_1969.f4, "g_1969.f4", print_hash_value);
    transparent_crc(g_1990, "g_1990", print_hash_value);
    transparent_crc(g_2015.f0, "g_2015.f0", print_hash_value);
    transparent_crc(g_2015.f1, "g_2015.f1", print_hash_value);
    transparent_crc(g_2015.f2, "g_2015.f2", print_hash_value);
    transparent_crc(g_2015.f3, "g_2015.f3", print_hash_value);
    transparent_crc(g_2015.f4, "g_2015.f4", print_hash_value);
    transparent_crc(g_2044.f0, "g_2044.f0", print_hash_value);
    transparent_crc(g_2044.f1, "g_2044.f1", print_hash_value);
    transparent_crc(g_2044.f2, "g_2044.f2", print_hash_value);
    transparent_crc(g_2044.f3, "g_2044.f3", print_hash_value);
    transparent_crc(g_2044.f4, "g_2044.f4", print_hash_value);
    transparent_crc(g_2143, "g_2143", print_hash_value);
    transparent_crc(g_2186.f0, "g_2186.f0", print_hash_value);
    transparent_crc(g_2209.f0, "g_2209.f0", print_hash_value);
    transparent_crc(g_2209.f1, "g_2209.f1", print_hash_value);
    transparent_crc(g_2209.f2, "g_2209.f2", print_hash_value);
    transparent_crc(g_2209.f3, "g_2209.f3", print_hash_value);
    transparent_crc(g_2209.f4, "g_2209.f4", print_hash_value);
    transparent_crc(g_2247, "g_2247", print_hash_value);
    transparent_crc(g_2289, "g_2289", print_hash_value);
    transparent_crc(g_2296.f0, "g_2296.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2304[i].f0, "g_2304[i].f0", print_hash_value);
        transparent_crc(g_2304[i].f1, "g_2304[i].f1", print_hash_value);
        transparent_crc(g_2304[i].f2, "g_2304[i].f2", print_hash_value);
        transparent_crc(g_2304[i].f3, "g_2304[i].f3", print_hash_value);
        transparent_crc(g_2304[i].f4, "g_2304[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2358.f0, "g_2358.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2383[i][j][k], "g_2383[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2392, "g_2392", print_hash_value);
    transparent_crc(g_2485, "g_2485", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2517[i].f0, "g_2517[i].f0", print_hash_value);
        transparent_crc(g_2517[i].f1, "g_2517[i].f1", print_hash_value);
        transparent_crc(g_2517[i].f2, "g_2517[i].f2", print_hash_value);
        transparent_crc(g_2517[i].f3, "g_2517[i].f3", print_hash_value);
        transparent_crc(g_2517[i].f4, "g_2517[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2519, "g_2519", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2599[i][j][k], "g_2599[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2611, "g_2611", print_hash_value);
    transparent_crc(g_2679.f0, "g_2679.f0", print_hash_value);
    transparent_crc(g_2679.f1, "g_2679.f1", print_hash_value);
    transparent_crc(g_2679.f2, "g_2679.f2", print_hash_value);
    transparent_crc(g_2679.f3, "g_2679.f3", print_hash_value);
    transparent_crc(g_2679.f4, "g_2679.f4", print_hash_value);
    transparent_crc(g_2730.f0, "g_2730.f0", print_hash_value);
    transparent_crc(g_2730.f1, "g_2730.f1", print_hash_value);
    transparent_crc(g_2730.f2, "g_2730.f2", print_hash_value);
    transparent_crc(g_2730.f3, "g_2730.f3", print_hash_value);
    transparent_crc(g_2730.f4, "g_2730.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 674
XXX total union variables: 51

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 38
breakdown:
   depth: 1, occurrence: 180
   depth: 2, occurrence: 58
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 5
   depth: 9, occurrence: 3
   depth: 12, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1
   depth: 17, occurrence: 3
   depth: 18, occurrence: 2
   depth: 19, occurrence: 1
   depth: 24, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 28, occurrence: 2
   depth: 31, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1

XXX total number of pointers: 694

XXX times a variable address is taken: 1481
XXX times a pointer is dereferenced on RHS: 401
breakdown:
   depth: 1, occurrence: 308
   depth: 2, occurrence: 75
   depth: 3, occurrence: 11
   depth: 4, occurrence: 7
XXX times a pointer is dereferenced on LHS: 393
breakdown:
   depth: 1, occurrence: 361
   depth: 2, occurrence: 29
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 50
XXX times a pointer is compared with address of another variable: 21
XXX times a pointer is compared with another pointer: 11
XXX times a pointer is qualified to be dereferenced: 8912

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1831
   level: 2, occurrence: 426
   level: 3, occurrence: 127
   level: 4, occurrence: 48
XXX number of pointers point to pointers: 273
XXX number of pointers point to scalars: 401
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 35.3
XXX average alias set size: 1.48

XXX times a non-volatile is read: 2208
XXX times a non-volatile is write: 1119
XXX times a volatile is read: 146
XXX    times read thru a pointer: 20
XXX times a volatile is write: 32
XXX    times written thru a pointer: 4
XXX times a volatile is available for access: 6.28e+03
XXX percentage of non-volatile access: 94.9

XXX forward jumps: 0
XXX backward jumps: 10

XXX stmts: 194
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 23
   depth: 2, occurrence: 42
   depth: 3, occurrence: 34
   depth: 4, occurrence: 38
   depth: 5, occurrence: 27

XXX percentage a fresh-made variable is used: 15.9
XXX percentage an existing variable is used: 84.1
********************* end of statistics **********************/

