/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2908784097
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_47[9] = {0x58L,0x58L,0x58L,0x58L,0x58L,0x58L,0x58L,0x58L,0x58L};
static volatile int32_t g_56 = 1L;/* VOLATILE GLOBAL g_56 */
static int32_t g_57 = 0L;
static uint8_t g_66 = 0x8CL;
static int8_t g_78 = 0x5AL;
static int8_t *g_77 = &g_78;
static int32_t g_89 = 1L;
static int32_t *g_92 = &g_89;
static int32_t *g_102 = &g_89;
static int16_t g_147 = 0xB2A6L;
static int32_t g_150[9] = {0x5823B322L,0x819B780AL,0x5823B322L,0x819B780AL,0x5823B322L,0x819B780AL,0x5823B322L,0x819B780AL,0x5823B322L};
static int64_t g_153 = 0x71E14FE225A2E691LL;
static uint64_t g_162 = 7UL;
static int16_t *g_164 = &g_147;
static uint32_t g_176[3] = {4294967288UL,4294967288UL,4294967288UL};
static int32_t ** volatile g_194 = &g_92;/* VOLATILE GLOBAL g_194 */
static int32_t g_213 = 0x92528784L;
static volatile uint32_t g_232 = 0x62B46976L;/* VOLATILE GLOBAL g_232 */
static int32_t ** volatile g_234 = &g_92;/* VOLATILE GLOBAL g_234 */
static int64_t g_261 = 0xEEAEBF9CC5E223FELL;
static volatile uint64_t g_265[7][8] = {{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL},{18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL,18446744073709551614UL,0x922B4A908AD092DFLL}};
static uint32_t g_291[9] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static const volatile int16_t g_382 = 0xEDADL;/* VOLATILE GLOBAL g_382 */
static const volatile int16_t *g_381 = &g_382;
static int16_t g_426 = 0xD805L;
static int16_t *g_425[7] = {&g_426,&g_426,&g_426,&g_426,&g_426,&g_426,&g_426};
static int32_t g_443 = 0x626A351CL;
static int64_t g_452 = 0x8EBED17D936634F7LL;
static int16_t g_454 = 0x54C2L;
static const int32_t *g_528 = &g_213;
static const int32_t **g_527 = &g_528;
static uint32_t g_539 = 4294967290UL;
static const uint32_t g_560[5] = {0x5A71DBFEL,0x5A71DBFEL,0x5A71DBFEL,0x5A71DBFEL,0x5A71DBFEL};
static int32_t g_565 = 0xDCDB1B9FL;
static int32_t **g_640 = &g_92;
static int32_t *** volatile g_639 = &g_640;/* VOLATILE GLOBAL g_639 */
static volatile int16_t g_673 = 0xCB1FL;/* VOLATILE GLOBAL g_673 */
static uint8_t g_686[2] = {7UL,7UL};
static int8_t g_712[1][8][1] = {{{(-5L)},{(-5L)},{0x33L},{(-5L)},{(-5L)},{0x33L},{(-5L)},{(-5L)}}};
static const int8_t g_715 = 0x52L;
static int32_t * const  volatile g_737[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t * volatile g_739 = &g_150[5];/* VOLATILE GLOBAL g_739 */
static int8_t g_741 = (-1L);
static uint32_t * const g_794 = &g_291[3];
static uint32_t * const  volatile * volatile g_793 = &g_794;/* VOLATILE GLOBAL g_793 */
static const int8_t *g_821 = &g_47[8];
static const int8_t **g_820 = &g_821;
static volatile uint32_t ** volatile g_841 = (void*)0;/* VOLATILE GLOBAL g_841 */
static int32_t g_875 = (-1L);
static uint16_t g_918 = 0x9E7DL;
static uint16_t g_935 = 0xE6CEL;
static volatile uint64_t * volatile *g_942 = (void*)0;
static const int64_t g_962[5][7] = {{0x994EAC19E7D5BA88LL,(-1L),0x3AC73DA63E426A69LL,0x3AC73DA63E426A69LL,(-1L),0x994EAC19E7D5BA88LL,0x1303A171911DAB49LL},{0x850EB75317A23520LL,0x3AC73DA63E426A69LL,0xB35927EACF68DC70LL,0x1303A171911DAB49LL,(-8L),0x994EAC19E7D5BA88LL,0x994EAC19E7D5BA88LL},{0xC1F4516D10BE2CA3LL,(-8L),0x3D141D7EEF5EE48ELL,(-8L),0xC1F4516D10BE2CA3LL,0x80526D7DE773B73BLL,0x850EB75317A23520LL},{9L,0x3AC73DA63E426A69LL,0x994EAC19E7D5BA88LL,(-1L),0xC1F4516D10BE2CA3LL,0x850EB75317A23520LL,0xC1F4516D10BE2CA3LL},{0xF3BA7263E3921078LL,(-1L),(-1L),0xF3BA7263E3921078LL,(-8L),(-1L),9L}};
static const int64_t *g_961 = &g_962[1][6];
static const int64_t **g_960 = &g_961;
static const int64_t ***g_959 = &g_960;
static uint32_t g_1069 = 18446744073709551612UL;
static volatile int8_t g_1136 = 0x55L;/* VOLATILE GLOBAL g_1136 */
static int32_t *g_1194 = &g_57;
static uint32_t g_1198[1] = {18446744073709551607UL};
static uint32_t *g_1226 = &g_291[5];
static uint32_t **g_1225[2][7] = {{&g_1226,&g_1226,&g_1226,&g_1226,&g_1226,&g_1226,&g_1226},{&g_1226,&g_1226,&g_1226,&g_1226,&g_1226,&g_1226,&g_1226}};
static volatile uint64_t g_1259 = 0xADAA0F930B95EB0ELL;/* VOLATILE GLOBAL g_1259 */
static int64_t *g_1337 = &g_452;
static int64_t **g_1336 = &g_1337;
static int64_t *** volatile g_1335 = &g_1336;/* VOLATILE GLOBAL g_1335 */
static int32_t ***g_1373 = &g_640;
static int8_t **g_1400 = &g_77;
static int8_t ***g_1399 = &g_1400;
static int16_t g_1459 = (-9L);
static int32_t g_1564 = 0xC455D081L;
static int32_t * const *g_1572 = &g_102;
static int32_t * const **g_1571 = &g_1572;
static int32_t *g_1593 = &g_89;
static int32_t ** const g_1592 = &g_1593;
static int32_t ** const *g_1591 = &g_1592;
static volatile int16_t g_1637 = 9L;/* VOLATILE GLOBAL g_1637 */
static int32_t *g_1642 = (void*)0;
static volatile uint32_t *g_1689 = (void*)0;
static volatile uint32_t * volatile * volatile g_1688 = &g_1689;/* VOLATILE GLOBAL g_1688 */
static volatile uint32_t * volatile * volatile *g_1687 = &g_1688;
static volatile uint32_t * volatile * volatile * volatile *g_1686 = &g_1687;
static uint32_t g_1713 = 4294967295UL;
static uint64_t g_1715 = 0x1D874E178C4B03DDLL;
static uint32_t *g_1862[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint32_t **g_1861 = &g_1862[8];
static uint16_t *g_1953[3] = {(void*)0,(void*)0,(void*)0};
static uint16_t **g_1952 = &g_1953[0];
static uint16_t *** volatile g_1954[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint8_t g_1993[6] = {0x38L,0x38L,0x38L,0x38L,0x38L,0x38L};
static uint8_t g_2005 = 0x2AL;
static volatile int8_t g_2077 = 0x93L;/* VOLATILE GLOBAL g_2077 */
static volatile int8_t *g_2076 = &g_2077;
static volatile int8_t ** volatile g_2075 = &g_2076;/* VOLATILE GLOBAL g_2075 */
static volatile int8_t **g_2078 = &g_2076;
static volatile int8_t ** volatile *g_2074[5][6] = {{&g_2078,&g_2078,&g_2078,&g_2078,&g_2078,&g_2078},{&g_2078,&g_2078,&g_2078,&g_2078,&g_2078,&g_2078},{&g_2078,&g_2078,(void*)0,&g_2078,(void*)0,&g_2078},{(void*)0,&g_2078,&g_2078,&g_2078,&g_2078,&g_2078},{(void*)0,(void*)0,&g_2078,&g_2078,(void*)0,&g_2078}};
static volatile int8_t ** volatile * volatile *g_2073[6][9][1] = {{{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]}},{{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0}},{{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]}},{{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0}},{{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]}},{{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0},{&g_2074[3][3]},{(void*)0},{&g_2074[0][3]},{(void*)0}}};
static volatile int8_t ** volatile * volatile **g_2072[5][7] = {{&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[1][5][0],&g_2073[4][6][0]},{&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[1][5][0],&g_2073[4][6][0],&g_2073[1][5][0],&g_2073[4][6][0],&g_2073[4][6][0]},{&g_2073[4][6][0],&g_2073[0][6][0],&g_2073[4][6][0],&g_2073[4][6][0],(void*)0,&g_2073[1][5][0],(void*)0},{&g_2073[4][6][0],(void*)0,(void*)0,&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][1][0],&g_2073[4][6][0]},{&g_2073[4][6][0],&g_2073[4][1][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][6][0],&g_2073[4][1][0]}};
static uint32_t g_2118 = 0xD450BA5CL;
static int32_t ****g_2161[1] = {&g_1373};
static int32_t ****g_2162[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int16_t g_2253 = 1L;
static volatile uint64_t g_2419 = 0UL;/* VOLATILE GLOBAL g_2419 */
static const uint8_t g_2467 = 0UL;
static uint8_t *g_2511 = &g_686[0];
static uint8_t **g_2510 = &g_2511;
static int32_t g_2515 = 2L;
static int16_t g_2519[3] = {1L,1L,1L};
static volatile uint8_t g_2529 = 0x5EL;/* VOLATILE GLOBAL g_2529 */
static int8_t g_2534 = (-1L);
static uint32_t **g_2602 = &g_1862[1];
static uint32_t g_2626 = 4294967295UL;
static int32_t *g_2649[10][8] = {{&g_443,&g_89,&g_150[2],&g_213,&g_89,&g_150[1],&g_89,&g_213},{(void*)0,&g_89,(void*)0,&g_150[5],&g_443,(void*)0,&g_150[8],(void*)0},{(void*)0,&g_150[5],&g_89,&g_443,(void*)0,(void*)0,&g_443,&g_89},{(void*)0,(void*)0,&g_150[1],&g_213,&g_443,&g_875,(void*)0,&g_443},{(void*)0,&g_443,&g_150[5],(void*)0,&g_89,(void*)0,&g_150[5],&g_443},{&g_443,&g_150[8],&g_89,&g_213,&g_150[8],&g_150[5],&g_89,&g_89},{(void*)0,&g_89,&g_565,&g_443,&g_443,&g_565,&g_89,(void*)0},{(void*)0,&g_443,&g_89,&g_150[5],(void*)0,(void*)0,&g_150[5],&g_213},{(void*)0,(void*)0,&g_150[5],&g_213,&g_150[5],(void*)0,(void*)0,&g_150[5]},{(void*)0,&g_443,&g_150[1],(void*)0,&g_89,&g_565,&g_443,&g_443}};
static uint8_t g_2660 = 0UL;
static volatile uint64_t * const g_2667 = (void*)0;
static volatile uint64_t * const *g_2666 = &g_2667;
static volatile uint64_t * const * volatile *g_2665 = &g_2666;
static volatile uint64_t * const * volatile ** volatile g_2664 = &g_2665;/* VOLATILE GLOBAL g_2664 */
static uint16_t * const *g_2834 = (void*)0;
static uint16_t * const **g_2833 = &g_2834;
static uint64_t g_2845 = 9UL;
static volatile int32_t g_2846 = 0x06C304FEL;/* VOLATILE GLOBAL g_2846 */
static uint8_t g_2897 = 0UL;
static uint32_t g_2972[7][9][4] = {{{18446744073709551612UL,18446744073709551615UL,0x63F5129FL,18446744073709551607UL},{18446744073709551615UL,6UL,18446744073709551612UL,18446744073709551607UL},{6UL,18446744073709551615UL,6UL,8UL},{6UL,8UL,18446744073709551612UL,0x02AE5AF3L},{18446744073709551615UL,8UL,0x63F5129FL,8UL},{18446744073709551612UL,18446744073709551615UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL}},{{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L}},{{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL}},{{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL}},{{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L}},{{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,0x02AE5AF3L,6UL,18446744073709551607UL},{18446744073709551612UL,0x02AE5AF3L,1UL,0x02AE5AF3L},{6UL,6UL,1UL,18446744073709551615UL},{18446744073709551612UL,8UL,6UL,18446744073709551615UL},{0x63F5129FL,6UL,0x63F5129FL,0x02AE5AF3L},{0x63F5129FL,18446744073709551607UL,0x63F5129FL,18446744073709551615UL}},{{6UL,18446744073709551607UL,18446744073709551615UL,18446744073709551607UL},{0x63F5129FL,8UL,18446744073709551615UL,6UL},{6UL,0x02AE5AF3L,0x63F5129FL,6UL},{1UL,8UL,1UL,18446744073709551607UL},{1UL,18446744073709551607UL,0x63F5129FL,18446744073709551615UL},{6UL,18446744073709551607UL,18446744073709551615UL,18446744073709551607UL},{0x63F5129FL,8UL,18446744073709551615UL,6UL},{6UL,0x02AE5AF3L,0x63F5129FL,6UL},{1UL,8UL,1UL,18446744073709551607UL}}};
static uint64_t g_3053 = 18446744073709551612UL;
static int16_t g_3071[10] = {0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L,0x81C9L};
static volatile uint64_t g_3143 = 0xC840C608AE8E67EDLL;/* VOLATILE GLOBAL g_3143 */
static uint32_t g_3190 = 0x5F29164AL;
static uint32_t * const **g_3193 = (void*)0;
static volatile int8_t g_3218[4] = {0xD1L,0xD1L,0xD1L,0xD1L};
static uint32_t ***g_3248 = &g_1225[1][2];
static uint32_t ****g_3247 = &g_3248;
static const uint16_t g_3257[6] = {1UL,65529UL,65529UL,1UL,65529UL,65529UL};
static const uint16_t *g_3256[10] = {&g_3257[0],(void*)0,(void*)0,&g_3257[0],&g_3257[5],&g_3257[0],(void*)0,(void*)0,&g_3257[0],&g_3257[5]};
static const uint16_t **g_3255[7] = {(void*)0,&g_3256[4],(void*)0,(void*)0,&g_3256[4],(void*)0,(void*)0};
static int32_t *g_3318 = &g_1564;
static int32_t **g_3317 = &g_3318;
static uint32_t ***g_3339 = &g_1861;
static uint32_t ****g_3338 = &g_3339;
static uint16_t g_3530[3][8][1] = {{{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL}},{{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL}},{{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL},{0x4C0AL},{3UL}}};
static int64_t g_3620 = (-1L);
static const volatile int32_t *g_3640 = &g_56;
static const volatile int32_t * volatile *g_3639 = &g_3640;
static volatile uint8_t g_3857 = 0x2EL;/* VOLATILE GLOBAL g_3857 */
static uint8_t **g_3895 = (void*)0;
static uint32_t * volatile * volatile g_3939 = &g_1226;/* VOLATILE GLOBAL g_3939 */
static uint32_t * volatile * volatile *g_3938 = &g_3939;
static uint32_t * volatile * volatile * volatile *g_3937 = &g_3938;
static uint32_t * volatile * volatile * volatile * volatile * const g_3936 = &g_3937;
static uint32_t * volatile * volatile * volatile * volatile * const  volatile *g_3935 = &g_3936;
static volatile uint32_t g_3950 = 4UL;/* VOLATILE GLOBAL g_3950 */
static volatile uint32_t g_3995 = 0xD4C01E07L;/* VOLATILE GLOBAL g_3995 */
static uint64_t *g_4162 = &g_1715;
static uint64_t **g_4161 = &g_4162;
static uint64_t ***g_4160 = &g_4161;
static uint64_t ****g_4159 = &g_4160;
static volatile uint64_t g_4216 = 0UL;/* VOLATILE GLOBAL g_4216 */
static volatile int32_t g_4312 = 0L;/* VOLATILE GLOBAL g_4312 */
static int16_t g_4313[9] = {0x84FAL,0x84FAL,0x84FAL,0x84FAL,0x84FAL,0x84FAL,0x84FAL,0x84FAL,0x84FAL};
static volatile int64_t g_4547 = (-7L);/* VOLATILE GLOBAL g_4547 */
static int64_t ****g_4656 = (void*)0;
static int32_t g_4748 = 0x9B1E4D7AL;
static int32_t ** volatile g_4793 = &g_92;/* VOLATILE GLOBAL g_4793 */
static uint16_t g_4831[3][6][2] = {{{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L},{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L}},{{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L},{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L}},{{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L},{0x63EAL,0x63EAL},{0x5357L,0x63EAL},{0x63EAL,0x5357L}}};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4, int64_t  p_5);
static uint16_t  func_7(int32_t  p_8, const int16_t  p_9);
static uint32_t  func_11(int32_t  p_12, const uint64_t  p_13, int8_t  p_14);
static int16_t  func_17(uint32_t  p_18, uint32_t  p_19, int8_t  p_20, int32_t  p_21, const uint16_t  p_22);
static uint32_t  func_33(int32_t  p_34, const uint16_t  p_35);
static const int8_t * func_51(uint32_t  p_52, int8_t * p_53);
static const uint64_t  func_62(uint8_t  p_63, int32_t  p_64);
static uint32_t  func_72(int8_t * p_73, int8_t * const  p_74, uint64_t  p_75);
static int32_t * func_79(int32_t * p_80, int8_t ** p_81, uint16_t  p_82, uint64_t  p_83, int32_t * p_84);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_47 g_56 g_89 g_78 g_102 g_147 g_234 g_291 g_261 g_425 g_150 g_213 g_443 g_57 g_452 g_454 g_176 g_194 g_92 g_426 g_66 g_527 g_381 g_382 g_539 g_528 g_560 g_565 g_232 g_162 g_639 g_640 g_153 g_712 g_77 g_686 g_739 g_715 g_741 g_673 g_793 g_820 g_265 g_841 g_875 g_918 g_935 g_942 g_821 g_962 g_960 g_961 g_794 g_1136 g_1069 g_1194 g_1225 g_959 g_1259 g_2972 g_1592 g_2626 g_1373 g_1593 g_2660 g_1336 g_1337 g_2118 g_2511 g_3071 g_4159 g_4160 g_4161 g_4162 g_1715 g_3937 g_3938 g_3939 g_1226 g_1459
 * writes: g_47 g_57 g_77 g_92 g_102 g_66 g_78 g_89 g_147 g_162 g_164 g_153 g_425 g_213 g_426 g_443 g_452 g_454 g_527 g_539 g_528 g_176 g_640 g_150 g_565 g_261 g_741 g_820 g_712 g_875 g_918 g_686 g_935 g_959 g_1069 g_291 g_1198 g_1225 g_1593 g_2626 g_2660 g_2118 g_3071 g_1459
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_6[7];
    int8_t *l_46 = &g_47[4];
    int8_t **l_50 = (void*)0;
    int8_t *l_54 = &g_47[4];
    const int8_t *l_714[2];
    const int8_t **l_713 = &l_714[1];
    int32_t l_716 = 0x8774DD1BL;
    const int32_t l_1261[10] = {0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL,0x456C790EL};
    int64_t *l_1273 = &g_452;
    uint16_t l_4371 = 0x0478L;
    uint64_t l_4376 = 7UL;
    int32_t *l_4434 = &g_565;
    int32_t l_4435 = 8L;
    int32_t l_4454 = 0x994DAD8BL;
    uint64_t l_4471[6][1];
    const uint32_t l_4475[4] = {0x884BC436L,0x884BC436L,0x884BC436L,0x884BC436L};
    int16_t l_4484 = 1L;
    const int8_t l_4541 = 0x40L;
    int32_t l_4548[5][5] = {{1L,0x19A3AFD4L,0x19A3AFD4L,1L,1L},{1L,1L,1L,1L,1L},{1L,0x19A3AFD4L,1L,3L,3L},{0x19A3AFD4L,1L,0x19A3AFD4L,1L,3L},{1L,1L,3L,1L,1L}};
    uint8_t ***l_4610 = &g_3895;
    int32_t * const l_4637[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t l_4665 = 5L;
    uint32_t l_4674 = 1UL;
    uint64_t ***l_4681 = (void*)0;
    uint32_t **l_4711 = &g_1226;
    uint32_t l_4812 = 0x3F0EA465L;
    int i, j;
    for (i = 0; i < 7; i++)
        l_6[i] = 0x251D69F4L;
    for (i = 0; i < 2; i++)
        l_714[i] = &g_715;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_4471[i][j] = 0x3CDC22A9259230E6LL;
    }
    if (func_2(l_6[4], (func_7((((!((*l_1273) = (func_11(((*g_1194) = (safe_div_func_int16_t_s_s(func_17(((safe_mod_func_uint16_t_u_u((safe_unary_minus_func_uint8_t_u(((safe_unary_minus_func_uint8_t_u(((safe_sub_func_uint64_t_u_u((((safe_sub_func_uint16_t_u_u(l_6[5], (0xA44198D7L & (-3L)))) <= (g_741 &= (safe_mul_func_uint16_t_u_u(((func_33((l_716 = (((safe_mod_func_int32_t_s_s((safe_div_func_int32_t_s_s((safe_mod_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((((*l_46) = l_6[1]) , ((safe_div_func_uint8_t_u_u((g_47[4] > ((l_46 = l_46) != ((*l_713) = func_51(l_6[4], l_54)))), l_6[6])) , 0x70CE53FD21F79FC4LL)), g_712[0][1][0])), g_291[5])), g_560[1])), l_6[0])), g_712[0][3][0])) | l_6[0]) >= l_6[2])), g_686[0]) ^ (-6L)) ^ g_715), g_686[0])))) > 0UL), g_291[5])) && 0x70C7L))) && g_78))), 0x489FL)) >= g_291[5]), l_6[0], g_291[0], g_291[5], g_291[5]), l_6[2]))), l_1261[9], l_1261[9]) | l_6[4]))) | g_560[1]) , 0xA1994F35L), l_1261[9]) > g_2972[2][8][3]), l_6[4]))
    { /* block id: 1812 */
        int32_t *l_4355[1];
        int64_t **l_4368[1][2][9] = {{{&g_1337,&l_1273,&g_1337,&l_1273,&g_1337,&l_1273,&g_1337,&l_1273,&g_1337},{&l_1273,&l_1273,&l_1273,&l_1273,&l_1273,&l_1273,&l_1273,&l_1273,&l_1273}}};
        uint64_t l_4370 = 0x3B443D69298F8B1ALL;
        uint64_t l_4418[3];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_4355[i] = &g_57;
        for (i = 0; i < 3; i++)
            l_4418[i] = 18446744073709551615UL;
        for (l_716 = 8; (l_716 >= 0); l_716 -= 1)
        { /* block id: 1815 */
            int i;
            (*g_640) = (*g_1592);
            (*g_640) = l_4355[0];
            if (g_454)
                goto lbl_4417;
        }
lbl_4417:
        for (g_2660 = 14; (g_2660 >= 18); g_2660++)
        { /* block id: 1821 */
            uint64_t l_4369 = 0x3C75BD251C930952LL;
            uint16_t ***l_4372 = &g_1952;
            (**g_1592) = 1L;
            for (g_454 = 0; (g_454 <= 8); g_454 += 1)
            { /* block id: 1825 */
                uint16_t ***l_4374[4] = {&g_1952,&g_1952,&g_1952,&g_1952};
                uint16_t ****l_4373 = &l_4374[0];
                int32_t l_4375 = (-2L);
                uint32_t *l_4377 = &g_2118;
                int16_t *l_4416 = &g_3071[5];
                int i;
                g_150[g_454] = (((safe_lshift_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(g_150[g_454], g_150[g_454])), 14)) , (-1L)) == ((safe_mod_func_uint64_t_u_u((((((((g_150[g_454] , ((+(**g_1336)) , (l_1261[0] == (safe_div_func_uint32_t_u_u(((!(l_4368[0][1][8] != l_4368[0][1][8])) || l_4369), (-1L)))))) , l_4369) , l_4370) , l_4371) | l_4371) != l_4369) , 18446744073709551609UL), 5UL)) < 0xA3L));
                (*g_1593) = (((((l_4369 != (g_150[g_454] & (*g_961))) || (((((**g_1336) = (*g_1337)) , l_4372) == ((*l_4373) = &g_1952)) >= l_4375)) >= g_150[g_454]) != l_716) >= l_4369);
                (*g_1593) = (((((l_4376 >= l_4369) && ((*l_4377) |= l_4376)) & (safe_rshift_func_uint8_t_u_s((++(*g_2511)), 2))) , ((*l_46) = l_4376)) && (!(safe_div_func_int8_t_s_s(((safe_div_func_int8_t_s_s((safe_mul_func_int8_t_s_s(1L, (((safe_rshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(l_4369, 7)), (safe_sub_func_int16_t_s_s((safe_div_func_uint64_t_u_u(l_4371, (safe_sub_func_uint64_t_u_u(((safe_rshift_func_int8_t_s_u(((safe_div_func_uint16_t_u_u((((safe_sub_func_uint64_t_u_u((~(safe_div_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((*g_2511), ((*l_54) = (!((((safe_rshift_func_int16_t_s_u(((*l_4416) &= (safe_unary_minus_func_uint64_t_u(0x937020694CB92CFDLL))), 13)) <= g_150[g_454]) <= (****g_4159)) > (*g_739)))))), g_150[g_454]))), l_4369)) & l_4371) , l_4369), l_4369)) , (**g_820)), (*g_2511))) | g_150[g_454]), (**g_1336))))), g_150[g_454])))), l_6[4])) , (****g_3937)) , g_150[g_454]))), 1UL)) && l_4371), 255UL))));
            }
            (*g_1194) = (-7L);
        }
        l_4418[0]--;
    }
    else
    { /* block id: 1841 */
        (*g_1593) = l_4376;
    }
    for (g_1459 = (-7); (g_1459 > 4); g_1459 = safe_add_func_int16_t_s_s(g_1459, 9))
    { /* block id: 1846 */
        int32_t *l_4423 = &g_89;
        uint32_t l_4426 = 0x97FBFFACL;
        uint64_t ** const *l_4432 = &g_4161;
        uint64_t ** const * const *l_4431 = &l_4432;
        uint64_t ** const * const **l_4433 = &l_4431;
        uint32_t *l_4436 = (void*)0;
        uint32_t *l_4437 = (void*)0;
        uint32_t *l_4438 = &g_1713;
        int32_t *l_4441 = &l_716;
        int8_t **l_4442[6];
        uint32_t *l_4445 = &g_2626;
        int16_t *l_4455 = &g_426;
        uint16_t *l_4456 = (void*)0;
        uint16_t *l_4457 = &g_3530[1][7][0];
        uint64_t l_4470 = 0xB5C243B78E922B05LL;
        int64_t ***l_4473 = (void*)0;
        int64_t ****l_4472 = &l_4473;
        int64_t ***l_4474 = (void*)0;
        const int16_t l_4476[8] = {1L,0xF95FL,1L,0xF95FL,1L,0xF95FL,1L,0xF95FL};
        int64_t l_4477 = 1L;
        int i;
        for (i = 0; i < 6; i++)
            l_4442[i] = &l_54;
        (*g_527) = l_4423;
        (**g_1373) = l_4423;
    }
    for (g_261 = 9; (g_261 > 4); g_261 = safe_sub_func_int32_t_s_s(g_261, 6))
    { /* block id: 1864 */
        uint32_t l_4492 = 0UL;
        int32_t *l_4493[4][8][6] = {{{(void*)0,&g_875,&g_565,&g_213,&g_57,&g_89},{&g_57,&l_6[3],&g_57,&l_6[3],&g_57,(void*)0},{&g_875,&g_875,&g_150[7],&g_150[5],&l_6[3],&g_565},{(void*)0,&g_150[5],&g_875,&g_875,&g_150[5],&g_565},{&g_150[5],&g_213,&g_150[7],&g_57,(void*)0,(void*)0},{&g_150[5],&g_875,&g_57,(void*)0,(void*)0,&g_89},{&g_150[5],(void*)0,&g_565,&g_57,(void*)0,(void*)0},{&g_150[5],(void*)0,&g_89,&g_875,&g_875,&g_89}},{{(void*)0,(void*)0,&g_213,&g_150[5],(void*)0,&g_875},{&g_875,(void*)0,&g_213,&l_6[3],(void*)0,&g_213},{&g_57,&g_875,&g_213,&g_213,(void*)0,&g_875},{(void*)0,&g_213,&g_213,&l_716,&g_150[5],&g_89},{&l_716,&g_150[5],&g_89,&l_716,&l_6[3],(void*)0},{(void*)0,&g_875,&g_565,&g_213,&g_57,&g_89},{&g_57,&l_6[3],&g_57,&l_6[3],&g_57,(void*)0},{&g_875,&g_875,&g_150[7],&g_150[5],&l_6[3],&g_565}},{{(void*)0,&g_150[5],&g_875,&g_875,&g_150[5],&g_565},{&g_150[5],&g_213,&g_150[7],&g_57,(void*)0,(void*)0},{&g_150[5],&g_875,&g_57,(void*)0,(void*)0,&g_89},{&g_150[5],(void*)0,&g_565,&g_57,(void*)0,(void*)0},{&g_150[5],(void*)0,&g_89,&g_875,&g_875,&g_89},{(void*)0,(void*)0,&g_213,&g_150[5],(void*)0,&g_875},{&g_875,(void*)0,&g_213,&l_6[3],(void*)0,&g_213},{&g_57,&g_875,&g_213,&g_213,(void*)0,&g_875}},{{(void*)0,&g_213,&g_213,&l_716,&g_150[5],&g_89},{&l_716,&g_150[5],&g_89,&l_716,&l_6[3],(void*)0},{(void*)0,&g_875,&g_565,&l_716,&l_6[3],&g_150[5]},{&l_6[3],&g_57,(void*)0,&g_57,&l_6[3],(void*)0},{&g_150[5],&g_89,(void*)0,&l_716,&g_57,&l_6[3]},{&l_6[2],(void*)0,&g_150[5],&g_89,(void*)0,&l_6[3]},{&l_716,&l_716,(void*)0,&l_6[3],&l_6[2],(void*)0},{(void*)0,&g_150[5],(void*)0,&l_6[2],&l_716,&g_150[5]}}};
        int8_t l_4506 = 0x4DL;
        int32_t l_4570 = (-3L);
        uint32_t l_4595 = 0x8FE094B3L;
        uint64_t *l_4597 = &l_4376;
        uint32_t ***l_4602 = (void*)0;
        int16_t l_4609 = 0x3F6CL;
        uint16_t l_4695[6];
        int16_t l_4710[3][9] = {{1L,0x26FCL,1L,1L,1L,1L,0x26FCL,1L,1L},{1L,(-1L),(-1L),1L,0xE850L,1L,(-1L),(-1L),1L},{(-4L),1L,(-10L),1L,(-4L),(-4L),1L,(-10L),1L}};
        const uint8_t l_4746 = 6UL;
        int8_t **l_4751 = (void*)0;
        int32_t *l_4755 = &g_565;
        uint32_t l_4789 = 0x99B012CDL;
        int64_t l_4790 = 3L;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_4695[i] = 1UL;
    }
    (**g_1592) = (-9L);
    return (*l_4434);
}


/* ------------------------------------------ */
/* 
 * reads : g_640 g_1592 g_2626 g_1373 g_213
 * writes: g_102 g_92 g_1593 g_2626 g_213
 */
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4, int64_t  p_5)
{ /* block id: 1517 */
    int32_t *l_3634 = &g_213;
    int16_t l_3645 = 0xA0C0L;
    int8_t **l_3646[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    uint64_t *l_3657 = &g_3053;
    uint64_t **l_3656[5] = {&l_3657,&l_3657,&l_3657,&l_3657,&l_3657};
    uint64_t ***l_3655 = &l_3656[2];
    uint64_t **** const l_3654 = &l_3655;
    uint8_t * const l_3670 = &g_2005;
    int8_t l_3685 = (-1L);
    int32_t l_3748 = 0xC41EDE33L;
    int32_t l_3817 = 1L;
    int32_t l_3819 = 0x5EA33B66L;
    int32_t l_3821 = 0L;
    uint16_t **l_3846 = &g_1953[2];
    uint32_t ***l_3851 = &g_1225[0][0];
    int8_t ** const *l_3855 = &l_3646[3];
    int8_t ** const **l_3854 = &l_3855;
    uint32_t * const *l_3869 = &g_1226;
    uint32_t *****l_3900 = &g_3247;
    int32_t *** const *l_3961 = (void*)0;
    int32_t *** const **l_3960 = &l_3961;
    int32_t l_4142[5][6][4] = {{{0L,0xA5AF55B0L,0xC4010C40L,0xA673758FL},{0L,0L,0xA3B66FB3L,0x505418C0L},{0L,0x97D55FB7L,0L,0x505418C0L},{0xA3B66FB3L,0L,0L,0xA673758FL},{0xC4010C40L,0xA5AF55B0L,0L,0L},{0xDD8AA330L,0xDD8AA330L,0L,0L}},{{0xC4010C40L,0L,0L,0xA5AF55B0L},{0xA3B66FB3L,0L,0L,0L},{0L,0L,0xA3B66FB3L,0xA5AF55B0L},{0L,0L,0xC4010C40L,0L},{0L,0xDD8AA330L,0xDD8AA330L,0L},{0L,0xA5AF55B0L,0xC4010C40L,0xA673758FL}},{{0L,0L,0xA3B66FB3L,0x505418C0L},{0L,0x97D55FB7L,0L,0x505418C0L},{0xA3B66FB3L,0L,0L,0xA673758FL},{0xC4010C40L,0xA5AF55B0L,0L,0L},{0xDD8AA330L,0xDD8AA330L,0L,0L},{0xC4010C40L,0L,0L,0xA5AF55B0L}},{{0xA3B66FB3L,0L,0L,0L},{0L,0L,0xA3B66FB3L,0xA5AF55B0L},{0L,0L,0xC4010C40L,0L},{0L,0xDD8AA330L,0xDD8AA330L,0L},{0L,0xA5AF55B0L,0xC4010C40L,0xA673758FL},{0L,0L,0xA3B66FB3L,0x505418C0L}},{{0L,0x97D55FB7L,0L,0x505418C0L},{0xA3B66FB3L,0L,0L,0xA673758FL},{0xC4010C40L,0xA5AF55B0L,0L,0L},{0xDD8AA330L,0xDD8AA330L,0L,0L},{0xC4010C40L,0L,0L,0xA5AF55B0L},{0xC4010C40L,0x97D55FB7L,0xA5AF55B0L,0x97D55FB7L}}};
    uint32_t l_4147 = 0xB5132427L;
    int8_t l_4175 = (-8L);
    uint32_t l_4176 = 5UL;
    int64_t l_4224 = 0xDCB058202A962897LL;
    int32_t ****l_4271 = &g_1373;
    uint8_t l_4320 = 0UL;
    int32_t ***l_4353 = &g_640;
    int8_t l_4354 = 1L;
    int i, j, k;
    (*g_640) = l_3634;
    (*g_1592) = l_3634;
    for (g_2626 = 0; (g_2626 < 22); g_2626 = safe_add_func_int8_t_s_s(g_2626, 1))
    { /* block id: 1523 */
        int32_t l_3649[1][6];
        int32_t l_3682 = 4L;
        const uint16_t l_3693 = 0x0A3DL;
        uint16_t * const *l_3845 = &g_1953[0];
        int8_t ****l_3856 = &g_1399;
        int32_t l_3858 = (-4L);
        uint64_t l_3859 = 0x718DB647028B8D98LL;
        uint32_t *** const *l_3903[4][4][8] = {{{&l_3851,&l_3851,&l_3851,&l_3851,&g_3248,&l_3851,&l_3851,&l_3851},{(void*)0,&l_3851,&g_3248,&l_3851,(void*)0,&g_3248,&l_3851,&l_3851},{&g_3248,(void*)0,&l_3851,&l_3851,(void*)0,&g_3248,&l_3851,&g_3248},{&l_3851,&l_3851,&g_3248,&g_3248,&l_3851,&l_3851,&l_3851,&g_3248}},{{&l_3851,&l_3851,&l_3851,&g_3248,&g_3248,&l_3851,&l_3851,&g_3248},{&l_3851,&g_3248,(void*)0,&l_3851,&l_3851,(void*)0,&g_3248,&l_3851},{&l_3851,&g_3248,(void*)0,&l_3851,&g_3248,&l_3851,(void*)0,&l_3851},{&l_3851,&l_3851,&g_3248,&l_3851,&l_3851,&l_3851,&l_3851,&g_3248}},{{&l_3851,&g_3248,&l_3851,&g_3248,(void*)0,(void*)0,&g_3248,&l_3851},{&g_3248,&g_3248,&l_3851,&l_3851,(void*)0,&l_3851,&l_3851,&l_3851},{(void*)0,&l_3851,&g_3248,&g_3248,&g_3248,&l_3851,(void*)0,&l_3851},{&l_3851,&l_3851,(void*)0,&l_3851,&l_3851,&g_3248,&g_3248,&l_3851}},{{&g_3248,(void*)0,(void*)0,&g_3248,&l_3851,&g_3248,&l_3851,&g_3248},{&l_3851,&l_3851,&l_3851,&l_3851,&g_3248,&l_3851,&l_3851,&l_3851},{(void*)0,&l_3851,&g_3248,&l_3851,(void*)0,&g_3248,&l_3851,&l_3851},{&g_3248,(void*)0,&l_3851,&l_3851,(void*)0,&g_3248,&l_3851,&g_3248}}};
        uint32_t *** const **l_3902 = &l_3903[0][1][6];
        uint16_t ** const **l_4055 = (void*)0;
        int32_t l_4136[4][4][5] = {{{1L,1L,0xD37C6B6CL,0xD37C6B6CL,1L},{0x7F10DE08L,1L,0x7F10DE08L,1L,0x7F10DE08L},{1L,0xD37C6B6CL,0xD37C6B6CL,1L,1L},{0xE9BBA045L,1L,0xE9BBA045L,1L,0xE9BBA045L}},{{1L,1L,0xD37C6B6CL,0xD37C6B6CL,1L},{0x7F10DE08L,1L,0x7F10DE08L,1L,0x7F10DE08L},{1L,0xD37C6B6CL,0xD37C6B6CL,1L,1L},{0xE9BBA045L,1L,0xE9BBA045L,1L,0xE9BBA045L}},{{1L,1L,0xD37C6B6CL,0xD37C6B6CL,1L},{0x7F10DE08L,1L,0x7F10DE08L,1L,0x7F10DE08L},{1L,0xD37C6B6CL,0xD37C6B6CL,1L,1L},{0xE9BBA045L,1L,0xE9BBA045L,1L,0xE9BBA045L}},{{1L,1L,0xD37C6B6CL,0xD37C6B6CL,1L},{0x7F10DE08L,1L,0x7F10DE08L,1L,0x7F10DE08L},{1L,0xD37C6B6CL,0xD37C6B6CL,1L,1L},{0xE9BBA045L,1L,0xE9BBA045L,1L,0xE9BBA045L}}};
        int16_t l_4145 = 0x7AB9L;
        uint8_t *l_4193 = (void*)0;
        int16_t l_4200 = (-1L);
        int16_t l_4255 = (-10L);
        int32_t l_4287 = 0xF777CA29L;
        int64_t l_4319 = 0xDBA6118FB4D7C0C5LL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 6; j++)
                l_3649[i][j] = 1L;
        }
    }
    (*l_3634) |= (l_4353 != (*l_4271));
    return l_4354;
}


/* ------------------------------------------ */
/* 
 * reads : g_213
 * writes:
 */
static uint16_t  func_7(int32_t  p_8, const int16_t  p_9)
{ /* block id: 511 */
    uint16_t l_1274 = 0x8F37L;
    const uint32_t *l_1281 = &g_560[1];
    int64_t *l_1289 = &g_452;
    int64_t **l_1288 = &l_1289;
    int32_t *l_1310 = &g_213;
    uint32_t l_1414 = 0UL;
    int8_t * const *l_1528 = &g_77;
    int8_t * const **l_1527 = &l_1528;
    int32_t l_1540 = 7L;
    int32_t * const **l_1574[8][2] = {{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572},{&g_1572,&g_1572}};
    int32_t ** const *l_1590 = &g_640;
    uint32_t l_1666[10][4] = {{0xD4971303L,18446744073709551609UL,18446744073709551609UL,0xD4971303L},{18446744073709551609UL,0xD4971303L,18446744073709551609UL,18446744073709551609UL},{0xD4971303L,0xD4971303L,0x6A6C3F24L,0xD4971303L},{0xD4971303L,18446744073709551609UL,18446744073709551609UL,0xD4971303L},{18446744073709551609UL,0xD4971303L,18446744073709551609UL,18446744073709551609UL},{0xD4971303L,0xD4971303L,0x6A6C3F24L,0xD4971303L},{0xD4971303L,18446744073709551609UL,18446744073709551609UL,0xD4971303L},{18446744073709551609UL,0xD4971303L,18446744073709551609UL,18446744073709551609UL},{0xD4971303L,0xD4971303L,0x6A6C3F24L,0xD4971303L},{0xD4971303L,18446744073709551609UL,18446744073709551609UL,0xD4971303L}};
    int16_t *l_1692 = &g_426;
    int8_t l_1693[6][1][10] = {{{0x7DL,0L,(-2L),0x5CL,0xD6L,0x5CL,(-2L),0L,0x7DL,(-2L)}},{{0xC6L,0L,0L,0L,0L,0x38L,0xE4L,0xC6L,0xD2L,0L}},{{0xBEL,0x7DL,0xC9L,0L,(-2L),(-2L),0L,0xC9L,0x7DL,0xBEL}},{{0xC9L,0xC6L,0x7DL,0x5CL,0L,1L,0xC9L,0xBEL,1L,0x7DL}},{{0xC6L,0xBEL,(-5L),0xC6L,0L,0xD2L,0L,0xC6L,(-5L),0xBEL}},{{0L,0xC9L,0x83L,0xE4L,(-2L),0x83L,0xBEL,0x7DL,0xC9L,0L}}};
    int64_t *l_1732 = (void*)0;
    int8_t ****l_1793 = &g_1399;
    int32_t l_1987 = 0xD7DE28DAL;
    int8_t l_1988 = (-4L);
    int32_t l_2000 = 9L;
    uint32_t l_2012 = 0x2D59B2C0L;
    int8_t l_2035 = (-9L);
    uint32_t l_2119[7] = {1UL,18446744073709551606UL,1UL,1UL,18446744073709551606UL,1UL,1UL};
    uint8_t l_2122 = 0xEDL;
    int8_t l_2141 = 0x8CL;
    uint16_t l_2147[2][8] = {{65529UL,65529UL,65529UL,65529UL,65529UL,65529UL,65529UL,65529UL},{65529UL,65529UL,65529UL,65529UL,65529UL,65529UL,65529UL,65529UL}};
    uint32_t l_2150[4][3][5] = {{{0x2FA7EA55L,0x39CAAA70L,0x3A509AABL,18446744073709551607UL,0x7129BDE4L},{18446744073709551615UL,18446744073709551607UL,0x6493AB9CL,18446744073709551613UL,0x8D4E4177L},{18446744073709551615UL,18446744073709551615UL,0x7DAD0AE5L,0x7129BDE4L,0x188FF4CCL}},{{0xE8087445L,0x7DAD0AE5L,0x7DAD0AE5L,0xE8087445L,0x89AAC940L},{18446744073709551613UL,18446744073709551615UL,0x6493AB9CL,18446744073709551615UL,0xF75F4625L},{0xD1A9E11AL,0x8D4E4177L,0x3A509AABL,0x89AAC940L,18446744073709551615UL}},{{0xF75F4625L,1UL,0x65A88EF6L,0x3A509AABL,0x003AB439L},{18446744073709551615UL,0xD1A9E11AL,0x188FF4CCL,18446744073709551615UL,0x30B066A3L},{0x634775EAL,0x30B066A3L,0x003AB439L,0x003AB439L,0x30B066A3L}},{{0x7129BDE4L,0x6493AB9CL,0x5858E330L,0x89AAC940L,0x003AB439L},{0x7DAD0AE5L,0x89AAC940L,0xF75F4625L,0x7129BDE4L,0x39CAAA70L},{0x5858E330L,18446744073709551615UL,0x6493AB9CL,0x003AB439L,0xD1A9E11AL}}};
    uint64_t l_2182 = 3UL;
    int32_t l_2201 = 0xC6BBA6F4L;
    uint16_t l_2260[6];
    uint32_t l_2461[4][5][5] = {{{0x4E550D27L,4294967295UL,0x2EB3C94AL,0UL,2UL},{4UL,0UL,0xA389E9D2L,0x6C8EE47FL,0xE27E5E99L},{4294967295UL,0x21FC0D30L,0x942DFEF7L,0UL,8UL},{0UL,0x4260BFFEL,1UL,4294967295UL,1UL},{4294967294UL,4294967294UL,1UL,0x4E550D27L,0x21FC0D30L}},{{4294967295UL,0x6C8EE47FL,0x942DFEF7L,4UL,4294967295UL},{4294967295UL,0x95111280L,0xA389E9D2L,4294967295UL,4294967295UL},{0x4260BFFEL,0x6C8EE47FL,0x2EB3C94AL,0UL,0xA389E9D2L},{0x81312F68L,4294967294UL,4294967295UL,4294967294UL,0x81312F68L},{0x81312F68L,0x4260BFFEL,4294967295UL,4294967295UL,4294967294UL}},{{0x4260BFFEL,0x21FC0D30L,0UL,4294967295UL,4294967295UL},{4294967295UL,0UL,0x21FC0D30L,0x4260BFFEL,4294967294UL},{4294967295UL,4294967295UL,0x4260BFFEL,0x81312F68L,0x81312F68L},{4294967294UL,4294967295UL,4294967294UL,0x81312F68L,0xA389E9D2L},{0UL,0x2EB3C94AL,0x6C8EE47FL,0x4260BFFEL,4294967295UL}},{{4294967295UL,0xA389E9D2L,0x95111280L,4294967295UL,4294967295UL},{4UL,0x942DFEF7L,0x6C8EE47FL,4294967295UL,0x21FC0D30L},{0x4E550D27L,1UL,4294967294UL,4294967294UL,1UL},{4294967295UL,1UL,0x4260BFFEL,0UL,8UL},{0UL,0x942DFEF7L,0x21FC0D30L,4294967295UL,0xE27E5E99L}}};
    int32_t l_2475[2][1];
    uint32_t * const *l_2488 = (void*)0;
    uint32_t * const **l_2487 = &l_2488;
    int64_t l_2520 = 9L;
    uint32_t l_2543 = 0xB7E6CE02L;
    int32_t l_2544 = 0x6A0D4CFEL;
    int64_t * const l_2568[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int8_t l_2597 = 1L;
    uint16_t l_2599[7] = {0x3A77L,0x3A77L,0x3A77L,0x3A77L,0x3A77L,0x3A77L,0x3A77L};
    const uint32_t l_2610 = 18446744073709551615UL;
    uint32_t l_2717 = 0UL;
    int8_t l_2745 = 0x6BL;
    int32_t l_2788 = 0x6A27D6C4L;
    uint32_t l_2795 = 4294967295UL;
    int32_t *l_2824[10] = {&g_213,&g_213,&g_213,&g_213,&g_213,&g_213,&g_213,&g_213,&g_213,&g_213};
    uint8_t l_2912 = 1UL;
    uint64_t l_2932 = 0x038B126C247E935ELL;
    uint32_t l_3011 = 0xFC89456BL;
    uint64_t l_3035[1];
    uint8_t l_3072 = 0x01L;
    int8_t l_3108 = 0x4CL;
    uint16_t ***l_3128[8] = {&g_1952,&g_1952,&g_1952,&g_1952,&g_1952,&g_1952,&g_1952,&g_1952};
    uint16_t ****l_3127 = &l_3128[0];
    int8_t l_3131[2];
    uint8_t l_3144[4] = {1UL,1UL,1UL,1UL};
    int16_t l_3235 = 6L;
    int32_t l_3236 = (-5L);
    int32_t l_3272[5][9] = {{6L,0x29C951E3L,0x29C951E3L,6L,6L,0x29C951E3L,0x29C951E3L,6L,6L},{0x8F6C4830L,0xF842E50DL,0x8F6C4830L,0xF842E50DL,0x8F6C4830L,0xF842E50DL,0x8F6C4830L,0xF842E50DL,0x8F6C4830L},{6L,6L,0x29C951E3L,0x29C951E3L,6L,6L,0x29C951E3L,0x29C951E3L,6L},{0xDFC38EAEL,0xF842E50DL,0xDFC38EAEL,0xF842E50DL,0xDFC38EAEL,0xF842E50DL,0xDFC38EAEL,0xF842E50DL,0xDFC38EAEL},{6L,0x29C951E3L,0x29C951E3L,6L,6L,0x29C951E3L,0x29C951E3L,6L,6L}};
    int32_t l_3283 = (-8L);
    uint32_t ****l_3340 = &g_3339;
    uint16_t l_3395 = 0x34CDL;
    int64_t l_3544 = (-4L);
    uint32_t l_3572[6];
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_2260[i] = 1UL;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_2475[i][j] = 0xB91F25EDL;
    }
    for (i = 0; i < 1; i++)
        l_3035[i] = 0x8B20D80419617902LL;
    for (i = 0; i < 2; i++)
        l_3131[i] = 0x9BL;
    for (i = 0; i < 6; i++)
        l_3572[i] = 0xA8136EA2L;
    return (*l_1310);
}


/* ------------------------------------------ */
/* 
 * reads : g_261 g_426 g_715 g_640 g_560
 * writes: g_261 g_426 g_102 g_92
 */
static uint32_t  func_11(int32_t  p_12, const uint64_t  p_13, int8_t  p_14)
{ /* block id: 497 */
    for (g_261 = 10; (g_261 > (-23)); --g_261)
    { /* block id: 500 */
        uint32_t l_1270 = 0x867B3169L;
        for (g_426 = (-27); (g_426 > (-1)); g_426 = safe_add_func_int8_t_s_s(g_426, 8))
        { /* block id: 503 */
            int8_t l_1266 = 1L;
            int32_t l_1267[2][9] = {{(-8L),1L,2L,0xB0D28DD6L,0xB0D28DD6L,2L,1L,(-8L),1L},{0x4190D338L,0x624336FAL,2L,2L,0x624336FAL,0x4190D338L,0xB0D28DD6L,0x4190D338L,0x624336FAL}};
            int32_t *l_1268 = &g_565;
            int32_t *l_1269[10] = {&g_443,&g_443,&g_443,&g_443,&g_443,&g_443,&g_443,&g_443,&g_443,&g_443};
            int i, j;
            if (l_1266)
                break;
            --l_1270;
        }
    }
    (*g_640) = (g_715 , &p_12);
    return g_560[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_47 g_176 g_153 g_640 g_454 g_686 g_673 g_162 g_793 g_741 g_194 g_527 g_213 g_78 g_92 g_820 g_261 g_265 g_150 g_841 g_89 g_381 g_382 g_875 g_539 g_443 g_918 g_935 g_560 g_712 g_147 g_942 g_739 g_821 g_962 g_66 g_960 g_961 g_57 g_291 g_794 g_1136 g_1069 g_1194 g_1225 g_959 g_1259 g_715 g_565
 * writes: g_539 g_153 g_164 g_162 g_102 g_92 g_89 g_47 g_741 g_528 g_176 g_213 g_820 g_261 g_150 g_78 g_712 g_875 g_527 g_426 g_147 g_918 g_686 g_935 g_959 g_66 g_1069 g_291 g_1198 g_57 g_1225
 */
static int16_t  func_17(uint32_t  p_18, uint32_t  p_19, int8_t  p_20, int32_t  p_21, const uint16_t  p_22)
{ /* block id: 275 */
    const uint32_t l_751 = 1UL;
    int32_t l_824 = 9L;
    const uint32_t *l_843 = (void*)0;
    const uint32_t **l_842 = &l_843;
    int8_t l_855 = 0xB3L;
    int32_t l_861 = (-1L);
    int32_t * const *l_871 = &g_102;
    int64_t *l_887 = &g_261;
    int64_t **l_886 = &l_887;
    volatile uint64_t *l_945 = &g_265[6][6];
    volatile uint64_t * volatile *l_944 = &l_945;
    int8_t **l_949[7] = {&g_77,&g_77,&g_77,&g_77,&g_77,&g_77,&g_77};
    int64_t ***l_955[5][10] = {{&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886},{&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0,&l_886},{(void*)0,&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0},{&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886,&l_886},{&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0,&l_886,(void*)0,(void*)0,&l_886}};
    const int64_t *l_958 = &g_452;
    const int64_t **l_957[8][8] = {{&l_958,(void*)0,(void*)0,&l_958,&l_958,&l_958,(void*)0,(void*)0},{&l_958,&l_958,&l_958,&l_958,&l_958,&l_958,&l_958,(void*)0},{(void*)0,&l_958,&l_958,&l_958,&l_958,&l_958,&l_958,&l_958},{&l_958,&l_958,&l_958,&l_958,(void*)0,&l_958,(void*)0,&l_958},{(void*)0,&l_958,(void*)0,&l_958,&l_958,&l_958,&l_958,&l_958},{&l_958,&l_958,&l_958,&l_958,(void*)0,(void*)0,&l_958,&l_958},{&l_958,&l_958,&l_958,&l_958,(void*)0,(void*)0,(void*)0,(void*)0},{&l_958,&l_958,&l_958,&l_958,(void*)0,&l_958,&l_958,(void*)0}};
    const int64_t ***l_956 = &l_957[4][0];
    uint32_t *l_963 = (void*)0;
    uint32_t *l_964 = &g_539;
    uint8_t *l_965 = (void*)0;
    uint8_t *l_966 = &g_66;
    int64_t *l_967 = (void*)0;
    uint8_t l_968 = 0UL;
    int32_t *l_969[4][4][6] = {{{&g_150[5],&g_875,&g_150[3],&g_150[3],&g_875,&g_150[5]},{&g_443,&g_150[5],&l_861,&g_875,&l_861,&g_150[5]},{&l_861,&g_443,&g_150[3],&g_150[6],&g_150[6],&g_150[3]},{&l_861,&l_861,&g_150[6],&g_875,&g_89,&g_150[3]}},{{&g_875,&g_89,&g_875,&g_150[6],&l_861,&l_861},{&g_443,&g_875,&g_875,&g_443,&g_89,&g_150[3]},{&g_150[3],&g_443,&l_861,&g_443,&g_150[3],&g_150[6]},{&g_443,&g_150[3],&g_150[6],&g_150[6],&g_150[3],&g_443}},{{&g_875,&g_443,&g_89,&g_150[3],&g_89,&g_443},{&g_89,&g_875,&g_150[6],&l_861,&l_861,&g_150[6]},{&g_89,&g_89,&l_861,&g_150[3],&g_150[5],&g_150[3]},{&g_875,&g_89,&g_875,&g_150[6],&l_861,&l_861}},{{&g_443,&g_875,&g_875,&g_443,&g_89,&g_150[3]},{&g_150[3],&g_443,&l_861,&g_443,&g_150[3],&g_150[6]},{&g_443,&g_150[3],&g_150[6],&g_150[6],&g_150[3],&g_443},{&g_875,&g_443,&g_89,&g_150[3],&g_89,&g_443}}};
    int32_t l_970 = 1L;
    uint64_t l_995 = 0x093264DCE4A50AF7LL;
    uint32_t l_996[6][6][7] = {{{0x17481011L,0xB05E6326L,1UL,0xA8557109L,18446744073709551610UL,1UL,0x51DA9506L},{5UL,6UL,0x9FF74195L,18446744073709551615UL,0xB5D8AE78L,0x17481011L,0x9B169410L},{5UL,0x9578BE43L,0x84DE1E69L,18446744073709551610UL,0x0554DD0EL,6UL,0x796B3559L},{5UL,0x249D14D2L,0x703CDEACL,18446744073709551609UL,18446744073709551614UL,0x377C6ECEL,0x88BAD1B8L},{9UL,0x51DA9506L,0x562FE945L,0x562FE945L,0x51DA9506L,9UL,1UL},{0x496623E3L,0xF5759C25L,0UL,0xEE002086L,0x278441BCL,0x68BE21E3L,0x4E629D64L}},{{0x9FF74195L,3UL,18446744073709551615UL,4UL,0x17481011L,1UL,0x82E14080L},{0x94DC67B6L,0xF5759C25L,0x51DA9506L,0xB05E6326L,0x377C6ECEL,0UL,0xC2AB98CEL},{1UL,0x51DA9506L,0x4E629D64L,0x38928960L,0xC888FE3EL,18446744073709551615UL,0UL},{4UL,0x249D14D2L,9UL,0xF5D888C1L,7UL,18446744073709551608UL,18446744073709551609UL},{0x9B169410L,0x9578BE43L,18446744073709551615UL,5UL,0UL,0UL,8UL},{1UL,6UL,1UL,3UL,18446744073709551615UL,1UL,0x13C381D5L}},{{8UL,0xB05E6326L,2UL,1UL,1UL,18446744073709551615UL,0UL},{0UL,0UL,0x27770BD4L,1UL,0x9B169410L,18446744073709551615UL,18446744073709551612UL},{0xC2AB98CEL,0x17481011L,0x54C9012BL,1UL,18446744073709551615UL,1UL,0x9349FB09L},{0xD3866056L,1UL,0x38928960L,1UL,9UL,0x94DC67B6L,18446744073709551614UL},{0x7DBAB939L,1UL,0x08659854L,3UL,18446744073709551615UL,0x9578BE43L,0xB7512EC6L},{18446744073709551615UL,0xA1EB768DL,0xC888FE3EL,18446744073709551609UL,18446744073709551615UL,0x08659854L,6UL}},{{0x1E99333EL,0x249D14D2L,0x693DC406L,0x377C6ECEL,18446744073709551609UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,0x2F298F24L,2UL,1UL,0UL,0UL,1UL},{18446744073709551609UL,0x0554DD0EL,18446744073709551609UL,0x9B169410L,0x88BAD1B8L,18446744073709551615UL,0x703CDEACL},{0UL,0x08659854L,0x377C6ECEL,0x38928960L,18446744073709551609UL,1UL,0xC2AB98CEL},{0xB7512EC6L,0x496623E3L,0xEE002086L,1UL,0xA80E2524L,18446744073709551615UL,0x94DC67B6L},{0xDDC53108L,8UL,1UL,0xD3866056L,0UL,0UL,0x3832B520L}},{{0x82E14080L,18446744073709551615UL,0x9B169410L,0UL,0xEE002086L,18446744073709551615UL,18446744073709551612UL},{7UL,0xAB5EE36AL,0x6D7F62DCL,1UL,18446744073709551608UL,0x08659854L,1UL},{0x9349FB09L,18446744073709551609UL,0x13C381D5L,18446744073709551615UL,0x377C6ECEL,0UL,18446744073709551609UL},{1UL,0xC2AB98CEL,4UL,18446744073709551615UL,0x0554DD0EL,0xF5759C25L,1UL},{0x703CDEACL,9UL,18446744073709551615UL,0x54C9012BL,0x94DC67B6L,0xF5D888C1L,0x7DBAB939L},{1UL,0xA8557109L,0xF5D888C1L,0UL,18446744073709551609UL,0x68BE21E3L,1UL}},{{1UL,5UL,0UL,9UL,1UL,1UL,18446744073709551609UL},{0x703CDEACL,0x4E629D64L,0xA1EB768DL,2UL,1UL,18446744073709551615UL,0x51DA9506L},{1UL,1UL,0x562FE945L,1UL,18446744073709551612UL,18446744073709551614UL,18446744073709551615UL},{0x9349FB09L,0UL,18446744073709551615UL,18446744073709551609UL,1UL,3UL,0x278441BCL},{7UL,18446744073709551609UL,4UL,0x0554DD0EL,18446744073709551615UL,6UL,1UL},{0x82E14080L,0x9349FB09L,0x1E99333EL,1UL,0x1E99333EL,0x9349FB09L,0x82E14080L}}};
    int16_t l_1161 = 0x0836L;
    uint32_t l_1211 = 1UL;
    int32_t ***l_1228 = &g_640;
    int i, j, k;
    for (p_21 = 25; (p_21 < (-23)); p_21 = safe_sub_func_int32_t_s_s(p_21, 8))
    { /* block id: 278 */
        int64_t l_816 = 1L;
        int8_t **l_819 = &g_77;
        uint32_t *l_826 = &g_291[5];
        uint32_t **l_825 = &l_826;
        int32_t l_833 = 0x71511322L;
        uint32_t l_838[4] = {0x2BFAC3B4L,0x2BFAC3B4L,0x2BFAC3B4L,0x2BFAC3B4L};
        int32_t *l_844 = &g_213;
        int32_t *l_845 = &g_89;
        int32_t *l_846 = &g_443;
        int32_t *l_847 = &g_89;
        int32_t *l_848 = (void*)0;
        int32_t *l_849 = &g_89;
        int32_t *l_850 = &g_150[5];
        int32_t *l_851 = &l_833;
        int32_t *l_852 = &g_443;
        int32_t *l_853 = &l_824;
        int32_t *l_854 = &l_824;
        int32_t *l_856 = &g_150[5];
        int32_t *l_857 = &l_824;
        int32_t *l_858 = &g_213;
        int32_t *l_859 = (void*)0;
        int32_t *l_860[7][2][6] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_57,(void*)0,&g_213,&g_57,(void*)0,(void*)0}},{{&g_443,(void*)0,(void*)0,&g_443,(void*)0,&g_213},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_57,(void*)0,&g_213,&g_57,(void*)0,(void*)0},{&g_443,(void*)0,(void*)0,&g_443,(void*)0,&g_213}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_57,(void*)0,&g_213,&g_57,(void*)0,(void*)0}},{{&g_443,(void*)0,(void*)0,&g_443,&g_565,&g_150[5]},{&g_213,&g_213,&g_565,&g_213,&g_565,&g_213}},{{(void*)0,&g_213,&g_150[5],(void*)0,&g_565,&g_565},{(void*)0,&g_213,&g_213,(void*)0,&g_565,&g_150[5]}},{{&g_213,&g_213,&g_565,&g_213,&g_565,&g_213},{(void*)0,&g_213,&g_150[5],(void*)0,&g_565,&g_565}}};
        uint32_t l_862 = 4294967290UL;
        int64_t l_919 = 1L;
        int i, j, k;
        for (g_539 = 25; (g_539 == 38); ++g_539)
        { /* block id: 281 */
            const int32_t l_748 = 0x1CAE9058L;
            int32_t ***l_754 = &g_640;
            uint32_t * const l_759 = &g_176[1];
            uint32_t **l_812 = (void*)0;
            int32_t l_815 = 0x0F9F60B5L;
            for (g_153 = 0; (g_153 == (-13)); --g_153)
            { /* block id: 284 */
                int16_t *l_755 = &g_454;
                int16_t **l_756 = &g_164;
                uint64_t *l_765 = &g_162;
                uint32_t *l_772[5][6] = {{&g_291[5],&g_291[1],&g_291[1],&g_291[5],&g_291[1],&g_291[1]},{&g_291[5],&g_291[1],&g_291[1],&g_291[5],&g_291[1],&g_291[1]},{&g_291[5],&g_291[1],&g_291[1],&g_291[5],&g_291[1],&g_291[1]},{&g_291[5],&g_291[1],&g_291[1],&g_291[5],&g_291[1],&g_291[1]},{&g_291[5],&g_291[1],&g_291[1],&g_291[5],&g_291[1],&g_291[1]}};
                uint32_t **l_771[7] = {&l_772[3][4],&l_772[3][4],&l_772[3][4],&l_772[3][4],&l_772[3][4],&l_772[3][4],&l_772[3][4]};
                int32_t l_780 = (-5L);
                int8_t *l_832 = &g_78;
                int i, j;
                if (l_748)
                    break;
                (*g_640) = ((safe_div_func_int64_t_s_s((l_751 == (safe_add_func_uint16_t_u_u((((l_754 != (((((((*l_756) = l_755) == (void*)0) & (-1L)) >= (safe_rshift_func_int16_t_s_u((l_759 == &g_176[1]), (safe_rshift_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u((~((*l_765) = g_47[4])), 0x90B8F4A7L)) & p_20), g_176[1]))))) >= g_153) , &g_234)) > l_751) , 0xA004L), 0x55BDL))), 0x36C9D8F1DF37FF2BLL)) , (void*)0);
                for (g_89 = 0; (g_89 < (-24)); --g_89)
                { /* block id: 291 */
                    int16_t l_770 = 1L;
                    uint32_t ***l_773 = &l_771[1];
                    int8_t *l_779 = &g_47[4];
                    const int32_t l_800 = (-1L);
                    int32_t *l_802 = &g_213;
                    int32_t l_837 = 0xFCDFA088L;
                    if (((safe_add_func_int32_t_s_s(0x499FDF09L, (((((((l_770 != (((((*l_773) = l_771[5]) == (void*)0) && ((!(((g_454 ^ ((*l_779) = ((0x87A4L <= p_20) < ((safe_div_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(p_19, g_686[0])), 0x55L)) ^ p_20)))) , g_673) , p_19)) != 1L)) <= p_19)) & l_780) , 0x086CL) > 1UL) , l_751) , p_21) >= 0x53B6L))) >= 0x29L))
                    { /* block id: 294 */
                        int8_t *l_799 = &g_47[1];
                        int8_t *l_801 = &g_741;
                        int32_t l_803 = 0L;
                        uint32_t **l_813 = &l_772[3][4];
                        (*g_527) = ((*g_194) = ((((safe_mod_func_int8_t_s_s(p_18, ((safe_add_func_uint64_t_u_u((--(*l_765)), ((void*)0 != (*l_754)))) , ((*l_801) ^= ((safe_rshift_func_int16_t_s_u((safe_sub_func_uint8_t_u_u(((-7L) == (((p_20 , g_793) != (void*)0) <= ((safe_lshift_func_int8_t_s_s(((*l_799) &= (((safe_div_func_int16_t_s_s(((&p_20 != l_799) , p_21), p_20)) == 1L) & p_19)), l_780)) || l_800))), l_751)), 0)) != 1UL))))) & 0x569BL) , p_18) , l_802));
                        if (p_20)
                            continue;
                        l_815 = (l_803 && (((*l_802) ^ (safe_mul_func_int8_t_s_s((((safe_add_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(0x4AL, (safe_add_func_int8_t_s_s(0x99L, 0x30L)))), (((l_813 = l_812) != &l_772[0][0]) , ((((!0x0641L) < (0xF4A5L != p_22)) , g_78) == p_22)))) == p_22) > 0UL), 0UL))) != 0UL));
                        (*g_92) = (l_816 | ((*l_802) <= (g_176[1] = (((p_22 >= l_751) >= (safe_unary_minus_func_uint64_t_u(p_22))) , g_176[1]))));
                    }
                    else
                    { /* block id: 305 */
                        int8_t **l_818[1];
                        const int8_t ***l_822 = (void*)0;
                        const int8_t ***l_823 = &g_820;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_818[i] = &l_779;
                        l_824 = ((&g_77 == l_818[0]) , ((l_819 = &g_77) == ((*l_823) = g_820)));
                        if ((*l_802))
                            break;
                        (*l_802) = ((void*)0 != l_825);
                        l_780 |= (safe_add_func_uint8_t_u_u(0x15L, (safe_lshift_func_uint8_t_u_u(p_19, (safe_unary_minus_func_int16_t_s(0x9686L))))));
                    }
                    for (g_261 = 4; (g_261 >= 0); g_261 -= 1)
                    { /* block id: 315 */
                        int32_t *l_834 = &g_565;
                        int32_t *l_835 = &g_150[2];
                        int32_t *l_836[3][4][4] = {{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_150[0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_150[0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_150[0],(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_150[0],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}}};
                        int i, j, k;
                        (*l_802) &= (((&p_20 != l_832) == 0x031EBE07L) | g_265[(g_261 + 1)][(g_261 + 2)]);
                        l_838[0]--;
                        (*l_835) &= g_265[g_261][(g_261 + 3)];
                        (*g_640) = l_772[g_261][(g_261 + 1)];
                    }
                    (*l_802) = (g_841 != l_842);
                }
            }
        }
        l_862--;
        for (l_816 = 26; (l_816 == 10); l_816 = safe_sub_func_int32_t_s_s(l_816, 1))
        { /* block id: 328 */
            int32_t * const l_874 = &g_875;
            int32_t * const *l_873 = &l_874;
            for (g_78 = 0; (g_78 >= 24); ++g_78)
            { /* block id: 331 */
                uint32_t l_885 = 18446744073709551615UL;
                int32_t *l_891[10] = {&g_213,(void*)0,&g_213,&g_213,(void*)0,&g_213,&g_213,(void*)0,&g_213,&g_213};
                int64_t **l_911 = (void*)0;
                volatile uint64_t * volatile **l_943[9][4][1];
                int i, j, k;
                for (i = 0; i < 9; i++)
                {
                    for (j = 0; j < 4; j++)
                    {
                        for (k = 0; k < 1; k++)
                            l_943[i][j][k] = &g_942;
                    }
                }
                for (p_18 = 0; (p_18 <= 1); p_18 += 1)
                { /* block id: 334 */
                    int32_t * const **l_872[2];
                    const uint32_t * const l_880[3] = {(void*)0,(void*)0,(void*)0};
                    uint32_t *l_882 = &l_862;
                    uint32_t **l_881 = &l_882;
                    int8_t *l_890[5] = {&l_855,&l_855,&l_855,&l_855,&l_855};
                    int32_t **l_892 = &l_854;
                    int8_t **l_928 = &l_890[1];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_872[i] = (void*)0;
                    (*l_874) = ((((g_712[0][3][0] = (((l_873 = l_871) == (g_686[p_18] , &l_856)) > (safe_sub_func_uint8_t_u_u(((l_880[1] == ((*l_881) = &p_18)) == ((safe_rshift_func_int16_t_s_u((l_885 = p_18), 12)) < ((*l_847) = ((*l_853) &= (l_886 != (void*)0))))), (safe_mul_func_int16_t_s_s(0x3264L, 0L)))))) , p_21) >= g_47[4]) >= 0L);
                    (*g_640) = &l_824;
                    (*l_849) &= ((l_891[1] != ((*l_892) = l_891[1])) > p_19);
                    for (l_861 = 1; (l_861 >= 0); l_861 -= 1)
                    { /* block id: 347 */
                        uint32_t l_893[8];
                        int32_t ***l_905 = &l_892;
                        const int32_t ***l_906 = &g_527;
                        int64_t ***l_912 = (void*)0;
                        int64_t ***l_913 = &l_886;
                        int16_t *l_914 = (void*)0;
                        int16_t *l_915 = &g_426;
                        int16_t *l_916 = &g_147;
                        uint16_t *l_917 = &g_918;
                        int8_t **l_925[10][2];
                        int8_t ***l_926 = &l_925[0][1];
                        int8_t ***l_927[8][8][4] = {{{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,(void*)0,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,(void*)0,&l_819}},{{&l_819,&l_819,(void*)0,&l_819},{&l_819,&l_819,(void*)0,&l_819},{&l_819,&l_819,(void*)0,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,(void*)0,&l_819},{(void*)0,&l_819,&l_819,&l_819}},{{(void*)0,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819},{(void*)0,&l_819,(void*)0,&l_819},{&l_819,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819},{&l_819,&l_819,(void*)0,&l_819}},{{&l_819,(void*)0,(void*)0,&l_819},{&l_819,&l_819,&l_819,&l_819},{(void*)0,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,(void*)0,&l_819},{(void*)0,&l_819,&l_819,&l_819},{(void*)0,(void*)0,&l_819,&l_819}},{{(void*)0,&l_819,&l_819,&l_819},{(void*)0,&l_819,(void*)0,&l_819},{&l_819,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819},{&l_819,&l_819,(void*)0,&l_819},{&l_819,(void*)0,(void*)0,&l_819}},{{&l_819,&l_819,&l_819,&l_819},{(void*)0,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,(void*)0,&l_819},{(void*)0,&l_819,&l_819,&l_819},{(void*)0,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819}},{{(void*)0,&l_819,(void*)0,&l_819},{&l_819,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819},{&l_819,&l_819,(void*)0,&l_819},{&l_819,(void*)0,(void*)0,&l_819},{&l_819,&l_819,&l_819,&l_819}},{{(void*)0,(void*)0,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819},{&l_819,(void*)0,(void*)0,&l_819},{(void*)0,&l_819,&l_819,&l_819},{(void*)0,(void*)0,&l_819,&l_819},{(void*)0,&l_819,&l_819,&l_819},{&l_819,&l_819,&l_819,&l_819}}};
                        uint16_t *l_933 = (void*)0;
                        uint16_t *l_934 = &g_935;
                        int i, j, k;
                        for (i = 0; i < 8; i++)
                            l_893[i] = 4294967295UL;
                        for (i = 0; i < 10; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_925[i][j] = &g_77;
                        }
                        if (l_893[5])
                            break;
                        (*l_847) = ((*l_844) ^= ((!((((*g_381) > (safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((safe_div_func_int32_t_s_s(l_893[1], (safe_rshift_func_uint16_t_u_s(((*l_917) = (((((*l_905) = (void*)0) != ((*l_906) = &g_528)) < p_19) , (((g_176[2] , (!(safe_unary_minus_func_uint32_t_u((g_539 &= ((safe_add_func_int16_t_s_s((((*l_916) = ((*l_915) = (((l_911 == ((*l_913) = &l_887)) <= p_21) , (*l_847)))) || p_18), 65530UL)) && (*l_874))))))) , g_875) == g_176[1]))), p_22)))) , 3L), p_21)), 0)), p_18))) , g_454) , l_919)) > (*l_852)));
                        (*l_844) ^= ((g_443 , (!((*l_915) = ((safe_mod_func_uint8_t_u_u((((*l_934) |= ((*l_917) &= (safe_mul_func_int16_t_s_s(((((*l_926) = l_925[6][1]) != (l_928 = l_819)) > (safe_mul_func_int8_t_s_s(p_20, (g_686[p_18]--)))), g_47[4])))) <= (g_560[1] != (safe_mod_func_uint32_t_u_u((safe_sub_func_int16_t_s_s(((*l_916) ^= ((((((0UL ^ (((*l_849) && ((safe_lshift_func_int8_t_s_u((g_712[0][3][0] |= 0x93L), p_22)) , 0xE3C4CBA9C828A645LL)) && p_20)) == p_21) , 0xE0L) >= 0xC3L) == p_22) > 0x3E43L)), p_21)), p_18)))), g_454)) , 0xAFDEL)))) < p_22);
                    }
                }
                l_944 = g_942;
                if (l_861)
                    continue;
            }
            for (g_162 = (-15); (g_162 < 32); g_162++)
            { /* block id: 374 */
                if ((*g_739))
                    break;
                return (*g_381);
            }
        }
    }
    l_970 = (g_150[5] &= (p_22 == ((((~(&g_77 != l_949[0])) && (g_686[0] ^ (((l_824 = ((((*l_966) = (((*l_964) = ((&g_793 != ((((safe_add_func_uint64_t_u_u(((+(l_824 || (g_265[2][0] , (safe_sub_func_int64_t_s_s(((g_261 = ((((l_955[1][2] = l_955[0][4]) != (g_959 = l_956)) | (-10L)) & 0L)) < p_22), 1L))))) >= (*g_821)), l_824)) & p_18) <= g_213) , (void*)0)) && p_21)) < l_824)) ^ (*g_821)) | p_22)) < p_21) ^ 0x41A87B9FBE338A11LL))) && l_968) != 0x97L)));
    if ((g_875 ^= (0x813BE6E5D7188114LL >= ((((safe_lshift_func_int16_t_s_u((0UL > (g_962[1][6] != ((safe_add_func_int16_t_s_s((safe_div_func_uint64_t_u_u(g_265[5][0], (safe_lshift_func_uint16_t_u_s(((safe_lshift_func_uint8_t_u_u(p_20, ((((~((g_153 < (safe_rshift_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s((safe_div_func_uint64_t_u_u((+0x09L), (safe_mul_func_uint16_t_u_u((((p_18 & (safe_rshift_func_uint16_t_u_u(p_19, g_66))) & (**g_960)) , g_741), p_22)))), l_995)) & 1L), p_22))) & g_150[5])) , l_996[3][0][5]) , p_21) , 0xD5L))) <= g_147), 5)))), 0xA126L)) == p_21))), 10)) , 248UL) & p_21) , p_19))))
    { /* block id: 389 */
        uint64_t *l_1001 = (void*)0;
        uint64_t **l_1002 = &l_1001;
        int32_t l_1003[5][9][5] = {{{0xE5FC4625L,0xB8E13055L,0x07909B4EL,(-8L),(-2L)},{0xE5FC4625L,0x59BA71ECL,0x49E596E1L,0x07909B4EL,5L},{(-8L),0xA31A41D5L,0xD0FD5E9AL,(-8L),0x313E71D7L},{(-3L),0xA31A41D5L,0xC734FCEBL,0xC734FCEBL,0xA31A41D5L},{(-1L),0x59BA71ECL,0x041CE44DL,0L,0x313E71D7L},{0x373679BAL,0xB8E13055L,0x041CE44DL,(-2L),5L},{0xDD7B0B42L,0x313E71D7L,0xC734FCEBL,0x49E596E1L,(-2L)},{0x373679BAL,(-2L),0xD0FD5E9AL,0x49E596E1L,0xB63315FAL},{(-1L),1L,0x49E596E1L,(-2L),3L}},{{(-3L),(-2L),0x07909B4EL,0L,3L},{(-8L),0x313E71D7L,0x41723D5DL,0xC734FCEBL,0xB63315FAL},{0xE5FC4625L,0xB8E13055L,0x07909B4EL,(-8L),(-2L)},{0xE5FC4625L,0x59BA71ECL,0x49E596E1L,0x07909B4EL,5L},{(-8L),0xA31A41D5L,0xD0FD5E9AL,(-8L),0x313E71D7L},{(-3L),0xA31A41D5L,0xC734FCEBL,0xC734FCEBL,0xA31A41D5L},{(-1L),0x59BA71ECL,0x041CE44DL,0L,0x313E71D7L},{0x373679BAL,0xB8E13055L,0x041CE44DL,(-2L),5L},{0xDD7B0B42L,0x313E71D7L,0xC734FCEBL,0x49E596E1L,(-2L)}},{{0x373679BAL,(-2L),0xD0FD5E9AL,0x49E596E1L,0xB63315FAL},{(-1L),1L,0x49E596E1L,(-2L),3L},{(-3L),(-2L),0x07909B4EL,0L,3L},{(-8L),0x313E71D7L,0x41723D5DL,0xC734FCEBL,0xB63315FAL},{0xE5FC4625L,0xB8E13055L,0x07909B4EL,(-8L),(-2L)},{0xE5FC4625L,0x59BA71ECL,0x49E596E1L,0x07909B4EL,5L},{(-8L),0xA31A41D5L,0xD0FD5E9AL,(-8L),0x313E71D7L},{(-3L),0xA31A41D5L,0xC734FCEBL,0xC734FCEBL,0xA31A41D5L},{(-1L),0x59BA71ECL,0x041CE44DL,0L,0x313E71D7L}},{{0x373679BAL,0xB8E13055L,0x041CE44DL,(-2L),5L},{0xDD7B0B42L,0x313E71D7L,0xC734FCEBL,0x49E596E1L,(-2L)},{0x373679BAL,(-2L),0xD0FD5E9AL,0x49E596E1L,0xB63315FAL},{(-1L),1L,0x49E596E1L,(-2L),3L},{(-3L),(-2L),0x07909B4EL,0L,3L},{(-8L),0x313E71D7L,0x41723D5DL,0xC734FCEBL,0xB63315FAL},{0xE5FC4625L,0xB8E13055L,0x07909B4EL,(-8L),(-2L)},{0xE5FC4625L,0x59BA71ECL,0x49E596E1L,0x07909B4EL,5L},{(-8L),0xA31A41D5L,0xD0FD5E9AL,(-8L),0x313E71D7L}},{{(-3L),0xA31A41D5L,0x313E71D7L,0x313E71D7L,0x1E368913L},{1L,3L,0xED82DECEL,0xB8E13055L,0x037B1168L},{(-4L),1L,0xED82DECEL,0x59BA71ECL,0L},{9L,0x037B1168L,0x313E71D7L,0xA31A41D5L,8L},{(-4L),8L,0xB63315FAL,0xA31A41D5L,(-4L)},{1L,1L,0xA31A41D5L,0x59BA71ECL,0x261B4907L},{0xA9ABBBCCL,8L,1L,0xB8E13055L,0x261B4907L},{0x0C907888L,0x037B1168L,(-1L),0x313E71D7L,(-4L)},{8L,1L,1L,(-2L),8L}}};
        uint64_t *l_1006 = &l_995;
        uint32_t l_1017 = 0x83B92D60L;
        uint16_t *l_1018[7] = {&g_935,&g_935,&g_918,&g_935,&g_935,&g_918,&g_935};
        int32_t l_1019 = 0x3F23DAA9L;
        int i, j, k;
        l_1019 &= (safe_mul_func_uint16_t_u_u((g_918 = (((*l_964) = (((safe_mul_func_uint16_t_u_u(g_57, (((((*l_1002) = l_1001) == ((l_1003[0][4][1] & (safe_mul_func_int16_t_s_s((*g_381), 65528UL))) , l_1006)) , ((g_162 && (safe_div_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u((l_1003[0][4][1] | (safe_rshift_func_uint8_t_u_s((p_22 ^ l_1003[3][4][3]), p_19))), l_1003[4][0][3])) , p_18), 3)), l_1017)), p_21))) && p_20)) , g_560[1]))) , &p_20) != (*g_820))) ^ 0x17861635L)), p_21));
    }
    else
    { /* block id: 394 */
        int32_t l_1033 = 0x18263058L;
        int32_t l_1038 = 0xC1875206L;
        uint32_t **l_1049 = &l_963;
        uint64_t **l_1066 = (void*)0;
        uint64_t ***l_1065 = &l_1066;
        int32_t l_1067 = 1L;
        uint64_t l_1068 = 0xB9721179D1C9C7C6LL;
        uint64_t l_1071 = 0xFF7ED8CF4EC4E6D4LL;
        int64_t **l_1090 = &l_967;
        int16_t l_1195 = 7L;
        const int16_t l_1202[7][4] = {{1L,0x33B5L,0x33B5L,1L},{0x33B5L,1L,0x33B5L,0x33B5L},{1L,1L,0x3A59L,1L},{1L,0x33B5L,0x33B5L,1L},{0x33B5L,1L,0x33B5L,0x33B5L},{1L,1L,0x3A59L,1L},{1L,0x33B5L,0x33B5L,1L}};
        const uint64_t *l_1206 = (void*)0;
        const uint64_t **l_1205[7][2] = {{&l_1206,(void*)0},{&l_1206,(void*)0},{&l_1206,(void*)0},{&l_1206,&l_1206},{(void*)0,&l_1206},{(void*)0,&l_1206},{(void*)0,&l_1206}};
        int8_t l_1227 = 0x0BL;
        int32_t l_1232 = 0x61206F5DL;
        int i, j;
        for (p_18 = (-25); (p_18 == 46); p_18 = safe_add_func_int64_t_s_s(p_18, 2))
        { /* block id: 397 */
            uint64_t *l_1032[8] = {&g_162,&g_162,&g_162,&g_162,&g_162,&g_162,&g_162,&g_162};
            int32_t l_1034 = 0x08EEF6DDL;
            int32_t l_1035 = 0x46038E99L;
            int32_t l_1036 = 1L;
            int32_t l_1037 = 9L;
            int32_t **l_1045 = &g_102;
            int32_t **l_1046 = &g_92;
            int32_t **l_1047 = &l_969[3][0][4];
            uint32_t ***l_1050 = &l_1049;
            const uint32_t ***l_1051 = &l_842;
            const uint32_t l_1056 = 1UL;
            uint64_t l_1070 = 18446744073709551614UL;
            uint16_t l_1135 = 0x2306L;
            uint8_t l_1137 = 0x1FL;
            uint32_t * const *l_1224 = &g_794;
            int32_t ****l_1229 = &l_1228;
            int32_t *l_1231 = &l_1036;
            int i;
            for (g_78 = 27; (g_78 != 6); g_78 = safe_sub_func_int16_t_s_s(g_78, 8))
            { /* block id: 400 */
                uint64_t l_1024 = 0x5CCA06B2738BBC1DLL;
                l_1024 = ((void*)0 != &p_22);
                return p_21;
            }
            if ((((safe_mod_func_int32_t_s_s((safe_add_func_uint64_t_u_u((g_1069 = (safe_add_func_uint32_t_u_u((((~(++g_162)) != (!((safe_lshift_func_int8_t_s_u((+((&l_1034 == ((*l_1047) = &l_824)) != (((+(((*l_1050) = l_1049) == ((*l_1051) = &l_843))) || (safe_mod_func_uint8_t_u_u((((void*)0 != (*g_820)) & (safe_sub_func_int16_t_s_s(l_1056, (safe_mod_func_int64_t_s_s(((*l_887) ^= ((safe_sub_func_int8_t_s_s(0xB5L, (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s((((void*)0 == l_1065) && g_291[5]), 7)), 3)) || l_1033) , (*g_821)))) & (**g_820))), 0xD2395E4496408EFALL))))), l_1033))) <= (-3L)))), 2)) > l_1067))) , l_1068), p_18))), p_22)), l_1070)) | 0x9F44DF73L) <= l_1071))
            { /* block id: 410 */
                int32_t *l_1075 = (void*)0;
                uint32_t l_1134 = 0x3A08EC9DL;
                int32_t l_1141 = 0L;
                uint64_t ***l_1150 = &l_1066;
                int64_t ***l_1158 = &l_1090;
                uint32_t l_1187 = 18446744073709551615UL;
                uint64_t l_1196 = 0x645A0BBB2D6243B0LL;
                const uint64_t ***l_1207 = &l_1205[4][0];
                if (p_22)
                { /* block id: 411 */
                    int8_t * const *l_1073 = &g_77;
                    int8_t * const **l_1072 = &l_1073;
                    int8_t * const ***l_1074 = &l_1072;
                    int32_t l_1093 = 0xE6E30DF5L;
                    int32_t l_1094 = 0x2B2DE542L;
                    int32_t l_1095 = (-6L);
                    uint64_t ***l_1151 = &l_1066;
                    int64_t *** const l_1159 = &l_1090;
                    int32_t l_1162 = 0xC342B57BL;
                    if ((((*l_1074) = l_1072) != (void*)0))
                    { /* block id: 413 */
                        (*g_739) = ((void*)0 != (*g_960));
                    }
                    else
                    { /* block id: 415 */
                        uint32_t **l_1080 = &l_964;
                        uint16_t *l_1081 = &g_918;
                        uint16_t *l_1084 = &g_935;
                        int32_t l_1121 = (-1L);
                        (*l_1047) = l_1075;
                        l_1067 = (safe_mul_func_int8_t_s_s((*g_821), (safe_rshift_func_int16_t_s_s((((**g_960) >= (**g_960)) == (((((*l_1081) ^= (((*l_1050) = (*l_1050)) != l_1080)) > (((((safe_lshift_func_uint16_t_u_s((((((*l_1084)++) , p_20) < (~(safe_add_func_int8_t_s_s(0x75L, p_19)))) == 0xF54A22F171056775LL), p_18)) || (**g_820)) & p_18) < 65535UL) ^ 1L)) == 0xB0L) , 65532UL)), 10))));
                        l_1075 = ((*l_1047) = (((((void*)0 == l_1090) == l_1068) > ((p_20 || (safe_sub_func_int16_t_s_s(l_1093, (l_1095 = (l_1094 = p_18))))) || ((safe_lshift_func_int16_t_s_s(p_18, (((~(safe_rshift_func_int16_t_s_s((((safe_add_func_uint64_t_u_u((safe_add_func_int32_t_s_s((((l_1121 |= ((safe_sub_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_u((safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(p_20, p_21)), 2UL)), 0x98ACBABCCD212DA3LL)), g_560[1])) <= g_918), l_1094)), 0x95L)) || l_1068), 0L)) && p_22)) > 0L) && l_1071), l_1094)), 0x2A1F3186CA311B7CLL)) || 0UL) , 0x1FECL), 4))) , &g_673) != (void*)0))) || (**g_960)))) , (*l_1047)));
                    }
                    if ((p_22 , (((*g_794) , ((safe_sub_func_int8_t_s_s((l_1093 = (-4L)), (safe_mod_func_uint16_t_u_u((p_20 && (safe_mul_func_uint16_t_u_u(((((&l_1049 == l_1050) <= l_1095) , ((((((((safe_div_func_int8_t_s_s((p_20 = (((((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(((((**g_820) ^ 0x77L) | p_22) || (**g_820)), 15)), 3L)) || (-4L)) ^ l_1094) >= l_1134) & p_22)), 0xA8L)) <= l_1068) | 0x1BL) & p_22) | p_19) >= 0UL) | l_1095) == p_22)) <= p_18), p_19))), p_19)))) | l_1135)) < g_1136)))
                    { /* block id: 429 */
                        l_1137--;
                        l_1095 = (+0x5AL);
                    }
                    else
                    { /* block id: 432 */
                        uint32_t l_1142[9] = {4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL};
                        int i;
                        l_1142[6]++;
                    }
                    if ((safe_rshift_func_int8_t_s_u((**g_820), 7)))
                    { /* block id: 435 */
                        uint64_t ***l_1149[6];
                        uint64_t ****l_1152 = &l_1065;
                        int32_t l_1160 = 0x18EF0A35L;
                        int i;
                        for (i = 0; i < 6; i++)
                            l_1149[i] = (void*)0;
                        l_1038 = (0x617C32A5L & ((p_21 , 4L) > 1L));
                        l_1067 |= ((0x7FBDL > ((safe_mul_func_uint8_t_u_u((l_1094 != ((((((l_1038 |= ((((((((((((((l_1095 , (l_1150 = l_1149[4])) != ((*l_1152) = l_1151)) || (l_1033 , p_22)) > (safe_mul_func_uint8_t_u_u(((~(l_1071 , (((((safe_add_func_uint16_t_u_u((18446744073709551608UL & p_21), (*g_381))) >= 6L) , l_1158) != l_1159) <= 1L))) , l_1160), 9L))) , p_22) && l_1161) | p_18) < p_22) != 0x2C4AL) , (*g_381)) | l_1162) , (**g_820)) > p_22) || 18446744073709551615UL)) , (void*)0) != &l_968) || (-1L)) , p_22) || p_19)), g_935)) || p_20)) && p_21);
                        if (p_19)
                            break;
                    }
                    else
                    { /* block id: 442 */
                        uint16_t *l_1170 = &l_1135;
                        int32_t l_1173 = 0x88B30EA5L;
                        if (p_18)
                            break;
                        l_1141 = ((safe_sub_func_uint64_t_u_u(((&g_960 != &l_1090) & (~l_1033)), (safe_mod_func_int64_t_s_s(((((*l_1170) = 9UL) >= ((safe_add_func_int32_t_s_s(0x4D687A46L, ((l_1033 <= l_1173) < (safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(p_19, (safe_sub_func_int64_t_s_s((0UL & (*g_821)), (**g_960))))), g_686[0]))))) <= p_19)) < p_21), 0xE1230444D89AC283LL)))) && (*g_821));
                    }
                    if (p_20)
                        break;
                }
                else
                { /* block id: 448 */
                    int32_t ***l_1183 = (void*)0;
                    uint16_t *l_1197 = &g_918;
                    int32_t l_1199[10][5][2] = {{{1L,(-1L)},{0xC1D87349L,(-4L)},{0xCA9F1877L,0L},{0xC1D87349L,0xCA9F1877L},{1L,0x926935A9L}},{{1L,0xCA9F1877L},{0xC1D87349L,0L},{0xCA9F1877L,(-4L)},{0xC1D87349L,(-1L)},{1L,1L}},{{1L,(-1L)},{0xC1D87349L,(-4L)},{0xCA9F1877L,0L},{0xC1D87349L,0xCA9F1877L},{1L,0x926935A9L}},{{1L,0xCA9F1877L},{0xC1D87349L,0L},{0xCA9F1877L,(-4L)},{0xC1D87349L,(-1L)},{1L,1L}},{{1L,(-1L)},{0xC1D87349L,(-4L)},{0xCA9F1877L,0L},{0xC1D87349L,0xCA9F1877L},{1L,0x926935A9L}},{{1L,0xCA9F1877L},{0xC1D87349L,0L},{0xCA9F1877L,(-4L)},{0xC1D87349L,(-1L)},{1L,1L}},{{1L,(-1L)},{0xC1D87349L,(-4L)},{0xCA9F1877L,0L},{0xC1D87349L,0xCA9F1877L},{1L,0x926935A9L}},{{1L,0xCA9F1877L},{0xC1D87349L,0L},{0xCA9F1877L,(-4L)},{0xC1D87349L,(-1L)},{1L,1L}},{{1L,0L},{0x33A9D0DAL,1L},{0xC1D87349L,0x926935A9L},{0x33A9D0DAL,0xC1D87349L},{0xCA9F1877L,(-1L)}},{{0xCA9F1877L,0xC1D87349L},{0x33A9D0DAL,0x926935A9L},{0xC1D87349L,1L},{0x33A9D0DAL,0L},{0xCA9F1877L,0xCA9F1877L}}};
                    int i, j, k;
                    if (p_18)
                        break;
                    (*g_1194) |= (p_22 && ((g_1198[0] = (((p_19 ^ ((*l_1197) = ((((g_162 = (safe_sub_func_int16_t_s_s(((safe_unary_minus_func_int32_t_s(((void*)0 == l_1183))) != ((*l_966) ^= ((safe_rshift_func_uint16_t_u_s((~((((((((l_1187 , ((((*g_794) = (safe_sub_func_int64_t_s_s((safe_add_func_uint8_t_u_u((safe_div_func_int8_t_s_s((p_20 &= (((&l_1134 == ((*g_821) , &p_19)) | 0xBC01L) > l_1195)), g_1069)), p_18)), 0x2CE91B4305AE8F73LL))) , &l_996[3][0][5]) != (void*)0)) != 0x0EL) >= p_22) ^ l_1068) & 0x1518F3F358668C2ELL) & p_19) == l_1038) || g_1136)), l_1196)) >= 0x691E4372BC7E6B03LL))), p_22))) <= p_19) == p_21) && l_1038))) && p_20) || 4294967286UL)) ^ l_1199[0][2][1]));
                }
                (*g_640) = (*l_1047);
                if (((*g_1194) != (p_21 ^ (p_21 ^ (((65535UL > p_20) > (safe_sub_func_uint8_t_u_u(0x23L, ((l_1202[5][2] > ((safe_sub_func_uint64_t_u_u(p_21, (((*l_1207) = l_1205[0][1]) != &l_945))) <= (-1L))) | p_18)))) | (*g_961))))))
                { /* block id: 460 */
                    uint16_t l_1208 = 65527UL;
                    l_1208 &= 0x3290DBA4L;
                }
                else
                { /* block id: 462 */
                    return p_22;
                }
            }
            else
            { /* block id: 465 */
                uint8_t l_1212 = 255UL;
                (*g_194) = (void*)0;
                (*g_1194) = (((*l_887) = l_1067) , (*g_739));
                l_1035 &= (safe_mul_func_int32_t_s_s(0x70B3EDDAL, (0x818B036EE132F193LL < (l_1211 | l_1212))));
                l_1038 ^= (safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(0x6810879CL, l_1212)), g_89));
            }
            if ((~(safe_div_func_int32_t_s_s((p_20 || p_20), (((*l_966) = (safe_sub_func_uint16_t_u_u(p_20, p_22))) , ((*g_1194) = (safe_lshift_func_int16_t_s_s((l_1224 != (g_1225[1][2] = g_1225[1][2])), ((l_1227 , (&l_1047 != ((*l_1229) = l_1228))) , (*g_381))))))))))
            { /* block id: 476 */
                int32_t *l_1230[3][6][1] = {{{(void*)0},{&g_875},{(void*)0},{(void*)0},{&g_875},{&g_57}},{{&g_57},{&g_875},{(void*)0},{(void*)0},{&g_875},{(void*)0}},{{(void*)0},{&g_875},{&g_57},{&g_57},{&g_875},{(void*)0}}};
                int i, j, k;
                if ((*g_739))
                    break;
                (**l_1228) = &l_1038;
                l_1038 = 0L;
            }
            else
            { /* block id: 481 */
                uint32_t l_1233 = 6UL;
                int32_t l_1260 = 0xE8858B5BL;
                l_1233--;
                l_1038 = ((p_21 >= (1UL >= (+(safe_add_func_uint32_t_u_u(((!(l_1068 & (((safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((g_686[0] == ((safe_div_func_uint32_t_u_u(((((((*g_1194) = ((((~(((safe_lshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint16_t_u_u(((l_1233 < (safe_div_func_int16_t_s_s(p_20, (((safe_rshift_func_int8_t_s_s((g_712[0][3][0] = ((safe_div_func_int16_t_s_s(((void*)0 == (*g_959)), 6UL)) == p_22)), p_21)) >= (-1L)) & (-1L))))) <= g_47[6]), 0xFE4FL)) && g_1259), 15)), g_715)) == l_1038) && (*g_821))) <= p_19) == g_162) & (*g_821))) >= p_21) == l_1232) || p_19) > g_565), g_1069)) , 0xC1EAL)) ^ p_18), 0x67L)), l_1260)) >= (**g_820)) & p_19))) | p_21), 0x05D404ABL))))) ^ l_1068);
            }
        }
        return p_18;
    }
    for (p_18 = 0; (p_18 <= 2); p_18 += 1)
    { /* block id: 492 */
        int i;
        return g_47[(p_18 + 4)];
    }
    return (*g_381);
}


/* ------------------------------------------ */
/* 
 * reads : g_213 g_150 g_712 g_739
 * writes: g_261 g_454 g_150
 */
static uint32_t  func_33(int32_t  p_34, const uint16_t  p_35)
{ /* block id: 268 */
    int64_t *l_719 = &g_261;
    int32_t l_722 = 0x136C88C1L;
    uint32_t l_734 = 1UL;
    int16_t *l_735 = &g_454;
    int16_t l_736[2];
    int32_t *l_738 = (void*)0;
    uint8_t l_740 = 255UL;
    int i;
    for (i = 0; i < 2; i++)
        l_736[i] = 0xC459L;
    (*g_739) = ((safe_sub_func_uint8_t_u_u(1UL, ((((*l_719) = (-10L)) , 0xA0526DD5L) == (p_34 = p_35)))) , (safe_add_func_int8_t_s_s(l_722, ((+((*l_735) = (safe_add_func_int32_t_s_s((safe_mul_func_int16_t_s_s(((p_34 , ((l_722 ^ ((safe_lshift_func_int16_t_s_s((safe_mul_func_int16_t_s_s((g_213 , (safe_lshift_func_uint8_t_u_s((((0x24L == p_35) ^ p_34) ^ g_150[4]), l_722))), p_35)), 8)) , l_722)) , l_734)) != g_712[0][3][0]), p_34)), 1UL)))) || l_736[0]))));
    return l_740;
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_89 g_47 g_78 g_102 g_147 g_234 g_291 g_261 g_425 g_150 g_213 g_443 g_57 g_452 g_454 g_176 g_194 g_92 g_426 g_66 g_527 g_381 g_382 g_539 g_528 g_560 g_565 g_232 g_162 g_639 g_640 g_153 g_712 g_77
 * writes: g_57 g_77 g_92 g_102 g_66 g_78 g_89 g_147 g_162 g_164 g_153 g_425 g_213 g_426 g_443 g_452 g_454 g_527 g_539 g_528 g_176 g_640 g_150 g_565
 */
static const int8_t * func_51(uint32_t  p_52, int8_t * p_53)
{ /* block id: 3 */
    int8_t l_55[2];
    int32_t l_67 = 5L;
    uint8_t l_450 = 0x0FL;
    int64_t *l_471 = &g_261;
    int32_t l_482 = 0xE53E591AL;
    int32_t l_493 = 8L;
    int32_t l_495 = (-10L);
    int32_t l_496 = 0xA180D088L;
    int32_t l_497 = 0xEC1B9CDCL;
    int32_t l_498 = 0xB59CDB71L;
    int8_t l_501[2];
    int32_t l_502 = (-1L);
    int32_t l_503[8][5][4] = {{{(-1L),0xEC848632L,0xDB75509BL,(-1L)},{8L,(-1L),(-1L),(-1L)},{1L,1L,(-9L),0xA9E9EC50L},{1L,0xEC848632L,(-1L),7L},{8L,0x48E31009L,0xDB75509BL,(-1L)}},{{(-1L),0x48E31009L,(-9L),7L},{0x48E31009L,0xEC848632L,0xDA93DCBBL,0xA9E9EC50L},{8L,1L,0xDA93DCBBL,(-1L)},{0x48E31009L,(-1L),(-9L),(-1L)},{(-1L),0xEC848632L,0xDB75509BL,(-1L)}},{{8L,(-1L),(-1L),(-1L)},{1L,1L,(-9L),0xA9E9EC50L},{1L,0xEC848632L,(-1L),7L},{8L,0x48E31009L,0xDB75509BL,(-1L)},{(-1L),0x48E31009L,(-9L),7L}},{{0x48E31009L,0xEC848632L,0xDA93DCBBL,0xA9E9EC50L},{8L,1L,0xDA93DCBBL,(-1L)},{0x48E31009L,(-1L),(-9L),(-1L)},{(-1L),0xEC848632L,0xDB75509BL,(-1L)},{8L,(-1L),(-1L),(-1L)}},{{1L,1L,(-9L),0xA9E9EC50L},{1L,0xEC848632L,(-1L),7L},{8L,0x48E31009L,0xDB75509BL,(-1L)},{(-1L),0x48E31009L,(-9L),7L},{0x48E31009L,0xEC848632L,0xDA93DCBBL,0xA9E9EC50L}},{{8L,1L,0xDA93DCBBL,(-1L)},{0x48E31009L,(-1L),(-9L),(-1L)},{(-1L),0xEC848632L,0xDB75509BL,(-1L)},{8L,(-1L),(-1L),(-1L)},{1L,1L,(-9L),0xA9E9EC50L}},{{1L,0xEC848632L,(-1L),7L},{8L,0x48E31009L,0xDB75509BL,(-1L)},{(-1L),0x48E31009L,(-9L),7L},{0x48E31009L,0xEC848632L,0xDA93DCBBL,0xA9E9EC50L},{8L,1L,0xDA93DCBBL,(-1L)}},{{0x48E31009L,(-1L),(-9L),(-1L)},{(-1L),0xEC848632L,0xDB75509BL,(-1L)},{8L,(-1L),(-1L),(-1L)},{1L,1L,7L,0xDA93DCBBL},{8L,(-10L),(-9L),0xDB75509BL}}};
    uint8_t l_576 = 0x5FL;
    int32_t l_604 = 0x1B377784L;
    int32_t *l_670[7][3][6] = {{{(void*)0,(void*)0,&g_213,&l_502,&l_493,&g_89},{(void*)0,&g_213,&g_57,&g_89,&g_57,&g_213},{&l_502,(void*)0,&g_57,&l_482,(void*)0,&g_89}},{{&l_482,&l_482,&g_213,&g_213,&l_482,&l_482},{&g_213,&l_482,&l_482,&l_482,(void*)0,&g_57},{&g_57,(void*)0,&l_502,(void*)0,&g_57,&l_482}},{{&g_57,&g_213,(void*)0,&l_482,&l_493,&l_493},{&g_213,(void*)0,(void*)0,&g_213,&l_502,&l_493},{&l_482,&l_493,(void*)0,&l_482,&l_482,&l_482}},{{&l_502,(void*)0,&l_502,&g_89,&l_482,&g_57},{(void*)0,&l_493,&l_482,&l_502,&l_502,&l_482},{(void*)0,(void*)0,&g_213,&l_502,&l_493,&g_89}},{{(void*)0,&g_213,&g_57,&g_89,&g_57,&g_213},{&l_502,(void*)0,&g_57,&l_482,(void*)0,&g_89},{&l_482,&l_482,&g_213,&g_213,&l_482,&l_482}},{{&g_213,&l_482,&l_482,&l_482,(void*)0,&g_57},{&g_57,(void*)0,&l_502,(void*)0,&g_57,&l_482},{&g_57,&g_213,(void*)0,&l_482,&l_493,&l_493}},{{&g_213,(void*)0,(void*)0,&g_213,&l_502,&l_493},{&l_482,&l_493,(void*)0,&l_482,&l_482,&l_482},{&l_502,(void*)0,&l_502,&g_89,&l_482,&g_57}}};
    int64_t l_687 = 0x294372EEFF82E9B8LL;
    int32_t *l_693 = (void*)0;
    int8_t **l_698 = &g_77;
    const int8_t *l_704 = &g_47[4];
    int32_t l_709[9][8][3] = {{{5L,7L,(-1L)},{(-2L),6L,0L},{0x29000BE3L,5L,(-1L)},{(-5L),0L,1L},{(-1L),0x53B2C13DL,5L},{5L,0x2F0C26F3L,0xE5412B5FL},{0L,0x2F0C26F3L,0L},{0x39DAD0BAL,0x53B2C13DL,0xA123CD8CL}},{{1L,0L,0x53B2C13DL},{7L,5L,0x6ED64CA7L},{5L,6L,(-1L)},{7L,7L,0L},{1L,0x6ED64CA7L,(-1L)},{0x39DAD0BAL,0L,(-10L)},{0L,(-10L),(-10L)},{5L,1L,(-1L)}},{{(-1L),0xA500CB1CL,0L},{(-5L),1L,(-1L)},{0x29000BE3L,0L,0x6ED64CA7L},{(-2L),1L,0xEBEA1589L},{(-2L),1L,6L},{0xA123CD8CL,0x39DAD0BAL,(-1L)},{5L,0L,0x2F0C26F3L},{5L,5L,(-2L)}},{{0xA123CD8CL,(-1L),7L},{(-2L),(-5L),0xA500CB1CL},{(-1L),0x29000BE3L,(-1L)},{1L,(-2L),0xA500CB1CL},{0x6ED64CA7L,5L,7L},{(-1L),0xEBEA1589L,(-2L)},{(-2L),0L,0x2F0C26F3L},{(-1L),0L,(-1L)}},{{0x53B2C13DL,0xEBEA1589L,6L},{(-10L),5L,0xEBEA1589L},{0xE5412B5FL,(-2L),(-1L)},{(-2L),0x29000BE3L,1L},{0xE5412B5FL,(-5L),(-1L)},{(-10L),(-1L),7L},{0x53B2C13DL,5L,0L},{(-1L),0L,0L}},{{(-2L),0x39DAD0BAL,7L},{(-1L),1L,(-1L)},{0x6ED64CA7L,7L,1L},{1L,5L,(-1L)},{(-1L),7L,0xEBEA1589L},{(-2L),1L,6L},{0xA123CD8CL,0x39DAD0BAL,(-1L)},{5L,0L,0x2F0C26F3L}},{{5L,5L,(-2L)},{0xA123CD8CL,(-1L),7L},{(-2L),(-5L),0xA500CB1CL},{(-1L),0x29000BE3L,(-1L)},{1L,(-2L),0xA500CB1CL},{0x6ED64CA7L,5L,7L},{(-1L),0xEBEA1589L,(-2L)},{(-2L),0L,0x2F0C26F3L}},{{(-1L),0L,(-1L)},{0x53B2C13DL,0xEBEA1589L,6L},{(-10L),5L,0xEBEA1589L},{0xE5412B5FL,(-2L),(-1L)},{(-2L),0x29000BE3L,1L},{0xE5412B5FL,(-5L),(-1L)},{(-10L),(-1L),7L},{0x53B2C13DL,5L,0L}},{{(-1L),0L,0L},{(-2L),0x39DAD0BAL,7L},{(-1L),1L,(-1L)},{0x6ED64CA7L,7L,1L},{1L,5L,(-1L)},{(-1L),7L,0xEBEA1589L},{(-2L),1L,6L},{0xA123CD8CL,0x39DAD0BAL,(-1L)}}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_55[i] = (-5L);
    for (i = 0; i < 2; i++)
        l_501[i] = 0x26L;
    for (p_52 = 0; (p_52 <= 1); p_52 += 1)
    { /* block id: 6 */
        int32_t l_458 = (-1L);
        int32_t l_480 = (-3L);
        int32_t l_484[9] = {0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L,0x3F291D95L};
        int16_t l_491 = 2L;
        int8_t l_492 = 6L;
        int32_t **l_530 = (void*)0;
        int32_t l_569 = 0x89E0213AL;
        int64_t l_571 = 0x582AA7ED42B4A454LL;
        int64_t **l_696[3][2] = {{&l_471,&l_471},{&l_471,&l_471},{&l_471,&l_471}};
        int32_t *l_699 = &g_443;
        int i, j;
        for (g_57 = 0; (g_57 <= 1); g_57 += 1)
        { /* block id: 9 */
            uint8_t *l_65[5][3] = {{&g_66,&g_66,&g_66},{&g_66,&g_66,&g_66},{&g_66,&g_66,&g_66},{&g_66,&g_66,&g_66},{&g_66,&g_66,&g_66}};
            int64_t *l_451 = &g_452;
            int16_t *l_453 = &g_454;
            int32_t l_476[7] = {0L,0L,0L,0L,0L,0L,0L};
            int64_t l_483 = 0x488A88AE3D80F0B4LL;
            int32_t l_490 = 1L;
            uint16_t l_540 = 0x4AABL;
            uint32_t *l_556 = &g_291[8];
            uint8_t l_573 = 0UL;
            uint64_t l_614 = 18446744073709551615UL;
            int32_t l_620[4];
            uint32_t l_635[9] = {18446744073709551609UL,0x2C8B4D17L,18446744073709551609UL,0x2C8B4D17L,18446744073709551609UL,0x2C8B4D17L,18446744073709551609UL,0x2C8B4D17L,18446744073709551609UL};
            int32_t **l_638 = &g_102;
            int i, j;
            for (i = 0; i < 4; i++)
                l_620[i] = 0xADD86085L;
            if (((((l_55[p_52] || p_52) != ((safe_div_func_uint64_t_u_u(((func_62((l_67 &= p_52), g_56) , (-1L)) > (safe_lshift_func_int8_t_s_u(g_291[5], (((((*l_453) &= (((*l_451) ^= (g_57 != (safe_mod_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(((*p_53) >= 0x07L), l_55[0])) <= l_450), 0xECFFL)))) , 0x971CL)) , 1UL) & p_52) || 0xE7118666L)))), g_261)) == g_176[1])) & 0xAD4DL) & l_55[p_52]))
            { /* block id: 175 */
                int64_t l_477 = 1L;
                int32_t l_478 = 3L;
                int32_t l_486 = 0x7029BF50L;
                int32_t l_487 = 0x9396FF2EL;
                int32_t l_488 = 8L;
                int32_t l_489 = 0x31825AB7L;
                int32_t l_494 = 0L;
                int32_t l_500[4];
                uint8_t l_537 = 0x02L;
                int32_t l_543[8] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
                int64_t l_572 = 0x6A7CEC088D07CEAALL;
                uint16_t l_609 = 1UL;
                uint32_t *l_647 = &g_291[5];
                int8_t **l_688 = &g_77;
                int64_t l_692 = (-1L);
                int i;
                for (i = 0; i < 4; i++)
                    l_500[i] = 9L;
                if (((*g_102) ^= 2L))
                { /* block id: 177 */
                    int32_t *l_457 = &g_57;
                    int32_t l_479 = 1L;
                    int32_t l_481 = 0x2B34C746L;
                    int32_t l_485[4] = {0xFB86D640L,0xFB86D640L,0xFB86D640L,0xFB86D640L};
                    uint16_t l_504[2][10][4] = {{{0UL,65530UL,0x5840L,0x4032L},{1UL,65530UL,0UL,0UL},{65530UL,65530UL,0xE5D5L,0x4032L},{0xC03CL,65530UL,0x4032L,0UL},{0UL,65530UL,0x5840L,0x4032L},{1UL,65530UL,0UL,0UL},{65530UL,65530UL,0xE5D5L,0x4032L},{0xC03CL,65530UL,0x4032L,0UL},{0UL,65530UL,0x5840L,0x4032L},{1UL,65530UL,0UL,0UL}},{{65530UL,65530UL,0xE5D5L,0x4032L},{0xC03CL,65530UL,0x4032L,0UL},{0UL,65530UL,0x5840L,0x4032L},{1UL,65530UL,0UL,0UL},{65530UL,65530UL,0xE5D5L,0x4032L},{0xC03CL,65530UL,0x4032L,0UL},{0UL,65530UL,0x5840L,0x4032L},{1UL,65530UL,0UL,0UL},{65530UL,65530UL,0xE5D5L,0x4032L},{0xC03CL,65530UL,0x4032L,0UL}}};
                    int16_t *l_514 = (void*)0;
                    int16_t *l_515 = (void*)0;
                    int16_t *l_516 = &g_426;
                    const int32_t ***l_529 = &g_527;
                    uint32_t *l_538 = &g_539;
                    int64_t l_542 = (-2L);
                    uint32_t l_545 = 4294967290UL;
                    int16_t l_570 = 6L;
                    int i, j, k;
                    for (g_454 = 0; (g_454 >= (-7)); g_454 = safe_sub_func_int16_t_s_s(g_454, 8))
                    { /* block id: 180 */
                        int32_t **l_464 = &g_92;
                        int32_t ***l_463 = &l_464;
                        int64_t **l_472 = &l_451;
                        int32_t *l_473 = &l_67;
                        int32_t *l_474 = &l_458;
                        int32_t *l_475[3];
                        int32_t l_499 = (-7L);
                        int i;
                        for (i = 0; i < 3; i++)
                            l_475[i] = (void*)0;
                        (*g_234) = &l_67;
                        if (p_52)
                            break;
                        if (l_55[p_52])
                            break;
                        ++l_504[0][9][2];
                    }
                    (*g_102) = (**g_194);
                    if ((((((safe_mul_func_uint16_t_u_u((!(safe_sub_func_int32_t_s_s(l_476[4], ((safe_sub_func_int32_t_s_s(((p_52 && (((*l_516) |= ((*l_453) |= 1L)) | (~(((*l_538) ^= (safe_mod_func_int64_t_s_s(((g_78 == (((safe_mul_func_int16_t_s_s((((!g_66) != (safe_add_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_s(((((*l_529) = g_527) == l_530) , (safe_add_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(0L, (safe_rshift_func_uint16_t_u_u(((((7UL >= (*p_53)) == l_493) >= p_52) > l_486), 8)))), (*g_381)))), (*p_53))) <= (*l_457)), g_176[2]))) ^ p_52), l_476[6])) != l_501[1]) != p_52)) , (-1L)), l_537))) | 0xFF5B81F5L)))) , p_52), 9L)) || 9UL)))), p_52)) || 0UL) < l_540) < (*l_457)) > g_213))
                    { /* block id: 193 */
                        int32_t *l_541[9] = {&l_482,&l_482,&l_482,&l_482,&l_482,&l_482,&l_482,&l_482,&l_482};
                        int8_t l_544 = 1L;
                        int i;
                        --l_545;
                        (*g_234) = &l_490;
                    }
                    else
                    { /* block id: 196 */
                        const uint32_t **l_557 = (void*)0;
                        const uint32_t *l_559 = &g_560[1];
                        const uint32_t **l_558 = &l_559;
                        int32_t *l_566 = &l_495;
                        int32_t l_567 = 0L;
                        int32_t *l_568[10][9][2] = {{{&l_480,&l_494},{&l_481,&g_150[5]},{&g_150[5],&l_485[0]},{&g_150[5],&g_150[5]},{&l_481,&l_494},{&l_480,&l_482},{&l_502,&l_496},{&l_476[4],&l_484[3]},{&l_500[1],&l_484[3]}},{{(void*)0,&l_458},{&l_482,&g_57},{&l_478,&g_57},{&l_482,&l_458},{(void*)0,&l_484[3]},{&l_500[1],&l_484[3]},{&l_476[4],&l_496},{&l_502,&l_482},{&l_480,&l_494}},{{&l_481,&g_150[5]},{&g_150[5],&l_485[0]},{&g_150[5],&g_150[5]},{&l_481,&l_494},{&l_480,&l_482},{&l_502,&l_496},{&l_476[4],&l_484[3]},{&l_500[1],&l_484[3]},{(void*)0,&l_458}},{{&l_482,&g_57},{&l_478,&g_57},{&l_482,&l_458},{(void*)0,&l_484[3]},{&l_500[1],&l_484[3]},{&l_476[4],&l_496},{&l_502,&l_482},{&l_480,&l_494},{&l_481,&g_150[5]}},{{&g_150[5],&l_485[0]},{&g_150[5],&g_150[5]},{&l_481,&l_484[3]},{(void*)0,&g_57},{&l_543[3],&l_482},{(void*)0,(void*)0},{&g_150[5],&l_487},{&l_502,&l_484[3]},{&l_503[3][3][1],&l_485[0]}},{{(void*)0,&l_485[0]},{&l_503[3][3][1],&l_484[3]},{&l_502,&l_487},{&g_150[5],(void*)0},{(void*)0,&l_482},{&l_543[3],&g_57},{(void*)0,&l_484[3]},{&l_480,&l_494},{&l_478,&l_494}},{{&l_478,&l_494},{&l_480,&l_484[3]},{(void*)0,&g_57},{&l_543[3],&l_482},{(void*)0,(void*)0},{&g_150[5],&l_487},{&l_502,&l_484[3]},{&l_503[3][3][1],&l_485[0]},{(void*)0,&l_485[0]}},{{&l_503[3][3][1],&l_484[3]},{&l_502,&l_487},{&g_150[5],(void*)0},{(void*)0,&l_482},{&l_543[3],&g_57},{(void*)0,&l_484[3]},{&l_480,&l_494},{&l_478,&l_494},{&l_478,&l_494}},{{&l_480,&l_484[3]},{(void*)0,&g_57},{&l_543[3],&l_482},{(void*)0,(void*)0},{&g_150[5],&l_487},{&l_502,&l_484[3]},{&l_503[3][3][1],&l_485[0]},{(void*)0,&l_485[0]},{&l_503[3][3][1],&l_484[3]}},{{&l_502,&l_487},{&g_150[5],(void*)0},{(void*)0,&l_482},{&l_543[3],&g_57},{(void*)0,&l_484[3]},{&l_480,&l_494},{&l_478,&l_494},{&l_478,&l_494},{&l_480,&l_484[3]}}};
                        int i, j, k;
                        (*g_527) = (*g_527);
                        (*l_566) ^= (safe_div_func_int64_t_s_s((((safe_lshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s((((g_78 = (safe_mul_func_uint16_t_u_u(g_78, ((void*)0 != &p_52)))) , l_556) != ((*l_558) = &g_291[3])), (((safe_lshift_func_uint8_t_u_s(((((safe_lshift_func_int16_t_s_u((((g_213 , p_52) < l_476[4]) > g_452), 7)) > 0x4BCD78D1L) == g_560[1]) > g_147), g_565)) ^ (*g_92)) >= l_490))), g_150[7])) != g_232) || 0x036930AAL), p_52));
                        --l_573;
                        l_576++;
                    }
                }
                else
                { /* block id: 204 */
                    int16_t l_591 = 1L;
                    uint16_t *l_592 = &l_540;
                    int32_t l_605 = 0xF4CE3078L;
                    int32_t l_606 = 0x75395346L;
                    int32_t l_607 = 0xE8352028L;
                    int32_t l_608[5][4][10] = {{{0x81404A31L,1L,0x81404A31L,0x4E40EE1CL,0xF544460DL,(-1L),0xD126D1FBL,0L,0x52B8A8ADL,0L},{0x81404A31L,0L,0x52B8A8ADL,0x26C96903L,0x52B8A8ADL,0L,0x81404A31L,0L,5L,1L},{5L,0L,0x81404A31L,0L,0x52B8A8ADL,0x26C96903L,0x52B8A8ADL,0L,0x81404A31L,0L},{0x52B8A8ADL,0L,0xD126D1FBL,(-1L),0xF544460DL,0x4E40EE1CL,0x81404A31L,1L,0x81404A31L,0x4E40EE1CL}},{{(-10L),0L,0xF544460DL,0L,(-10L),0x4E40EE1CL,0xD126D1FBL,0x26C96903L,5L,(-1L)},{0x52B8A8ADL,1L,0xF544460DL,0x26C96903L,(-4L),0x26C96903L,0xF544460DL,1L,0x52B8A8ADL,(-1L)},{5L,0x26C96903L,0xD126D1FBL,0x4E40EE1CL,(-10L),0L,0xF544460DL,0L,(-10L),0x4E40EE1CL},{0x81404A31L,1L,0x81404A31L,0x4E40EE1CL,0xF544460DL,(-1L),0xD126D1FBL,0L,0x52B8A8ADL,0L}},{{0x81404A31L,0L,0x52B8A8ADL,0x26C96903L,0x52B8A8ADL,0L,0x81404A31L,0L,0x81404A31L,0L},{0x81404A31L,0x26C96903L,(-10L),0L,(-4L),0x4E40EE1CL,(-4L),0L,(-10L),0x26C96903L},{(-4L),0x26C96903L,0xF544460DL,1L,0x52B8A8ADL,(-1L),(-10L),0L,(-10L),(-1L)},{0xD126D1FBL,0L,0x52B8A8ADL,0L,0xD126D1FBL,(-1L),0xF544460DL,0x4E40EE1CL,0x81404A31L,1L}},{{(-4L),0L,0x52B8A8ADL,0x4E40EE1CL,5L,0x4E40EE1CL,0x52B8A8ADL,0L,(-4L),1L},{0x81404A31L,0x4E40EE1CL,0xF544460DL,(-1L),0xD126D1FBL,0L,0x52B8A8ADL,0L,0xD126D1FBL,(-1L)},{(-10L),0L,(-10L),(-1L),0x52B8A8ADL,1L,0xF544460DL,0x26C96903L,(-4L),0x26C96903L},{(-10L),0L,(-4L),0x4E40EE1CL,(-4L),0L,(-10L),0x26C96903L,0x81404A31L,0L}},{{0x81404A31L,0x26C96903L,(-10L),0L,(-4L),0x4E40EE1CL,(-4L),0L,(-10L),0x26C96903L},{(-4L),0x26C96903L,0xF544460DL,1L,0x52B8A8ADL,(-1L),(-10L),0L,(-10L),(-1L)},{0xD126D1FBL,0L,0x52B8A8ADL,0L,0xD126D1FBL,(-1L),0xF544460DL,0x4E40EE1CL,0x81404A31L,1L},{(-4L),0L,0x52B8A8ADL,0x4E40EE1CL,5L,0x4E40EE1CL,0x52B8A8ADL,0L,(-4L),1L}}};
                    uint32_t *l_619 = (void*)0;
                    uint32_t *l_621 = (void*)0;
                    uint32_t *l_622 = (void*)0;
                    uint32_t *l_623 = &g_176[1];
                    int16_t *l_628[8][7][3] = {{{&g_426,&g_426,(void*)0},{&g_426,&l_491,&g_147},{&g_147,&l_591,(void*)0},{&l_591,&g_147,&g_147},{(void*)0,&g_147,&g_147},{&g_426,&g_426,(void*)0},{(void*)0,&g_147,(void*)0}},{{(void*)0,&g_426,&l_491},{&l_491,&g_147,(void*)0},{&g_147,&g_426,(void*)0},{&l_591,&g_147,&l_591},{&l_491,&g_147,(void*)0},{&g_147,&l_591,(void*)0},{&l_591,&l_491,&g_147}},{{&l_591,&g_426,&g_147},{&l_591,&l_591,&g_426},{(void*)0,&g_426,&l_591},{&g_426,&l_491,&l_491},{(void*)0,(void*)0,&l_491},{&g_426,&l_591,&g_426},{&l_591,(void*)0,&g_426}},{{&l_591,&g_426,&l_491},{&g_147,&l_491,&l_491},{&g_426,&l_591,&l_591},{&g_426,&l_491,&g_426},{&l_491,&g_147,&g_147},{&l_591,(void*)0,(void*)0},{&l_591,(void*)0,&l_591}},{{&l_591,(void*)0,&l_491},{&g_426,&g_147,&g_426},{&g_426,&l_491,&l_591},{(void*)0,&g_147,&g_147},{&g_426,&g_426,&l_591},{&g_147,&l_591,&l_491},{&g_426,&g_147,&l_591}},{{(void*)0,&g_147,&g_426},{&g_426,&l_491,&l_591},{&g_426,(void*)0,&g_426},{&l_591,&g_147,&g_426},{&l_591,&g_426,&l_491},{&l_591,&l_591,&g_147},{&g_147,&l_591,(void*)0}},{{(void*)0,&g_147,(void*)0},{&g_426,&g_147,&g_426},{&l_591,&l_591,&g_147},{(void*)0,&g_426,&g_426},{&g_147,&g_426,&g_426},{&g_147,&l_591,&l_591},{(void*)0,&g_147,(void*)0}},{{&l_591,&g_147,&g_147},{&g_147,&l_591,&g_426},{&g_426,&l_591,(void*)0},{&g_147,&g_426,&g_147},{&g_147,&g_147,(void*)0},{&g_147,(void*)0,&g_147},{&l_491,&l_491,&l_491}}};
                    int i, j, k;
                    for (g_539 = 0; (g_539 >= 42); g_539 = safe_add_func_int32_t_s_s(g_539, 5))
                    { /* block id: 207 */
                        int32_t *l_593 = &l_480;
                        int32_t *l_594 = &g_443;
                        int32_t *l_595 = &l_480;
                        int32_t *l_596 = (void*)0;
                        int32_t *l_597 = (void*)0;
                        int32_t *l_598 = &l_476[4];
                        int32_t *l_599 = (void*)0;
                        int32_t *l_600 = &l_500[1];
                        int32_t *l_601 = (void*)0;
                        int32_t *l_602 = &l_543[3];
                        int32_t *l_603[7];
                        int i;
                        for (i = 0; i < 7; i++)
                            l_603[i] = &l_489;
                        l_476[3] ^= ((*g_102) = (safe_div_func_uint8_t_u_u(p_52, (safe_div_func_uint32_t_u_u((((safe_sub_func_int64_t_s_s(((safe_mul_func_uint16_t_u_u(((safe_sub_func_int64_t_s_s(l_591, (l_592 == (void*)0))) , (g_232 , (8L > (g_162 != p_52)))), g_539)) >= (**g_527)), 0x08F251F16DE756DCLL)) , p_52) && 0x56L), l_483)))));
                        if (p_52)
                            break;
                        l_609--;
                    }
                    if ((safe_lshift_func_int8_t_s_u((l_614 , (((l_606 = 252UL) ^ (g_66 = (l_483 >= l_540))) & (((((((safe_rshift_func_uint8_t_u_u(((void*)0 != &g_454), (((safe_sub_func_uint16_t_u_u(((--(*l_623)) | (safe_mod_func_int16_t_s_s((l_490 &= ((*l_453) = ((*g_381) < 0xA124L))), l_487))), 0xAAA8L)) <= p_52) <= l_503[0][4][2]))) ^ 1UL) > 1UL) , l_476[4]) > l_493) , p_52) ^ l_498))), 6)))
                    { /* block id: 218 */
                        int32_t *l_629 = &g_565;
                        int32_t *l_630 = &l_476[5];
                        int32_t *l_631 = (void*)0;
                        int32_t *l_632 = &g_89;
                        int32_t *l_633 = (void*)0;
                        int32_t *l_634[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_634[i] = &l_607;
                        if ((*g_92))
                            break;
                        if (l_476[4])
                            break;
                        l_635[5]++;
                        (*g_527) = (l_634[1] = &l_495);
                    }
                    else
                    { /* block id: 224 */
                        int8_t *l_662 = &l_55[0];
                        int32_t l_667 = 0L;
                        uint16_t l_668 = 0xACF1L;
                        int32_t l_669 = 0x71FEF55FL;
                        (*g_639) = l_638;
                        if (p_52)
                            break;
                        l_669 |= (safe_sub_func_uint32_t_u_u(0x3E02D23AL, ((!(safe_mul_func_int16_t_s_s((((~(l_647 != &g_291[4])) < (**l_638)) != (safe_mul_func_int8_t_s_s((safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((*l_592) = (safe_div_func_int32_t_s_s((-1L), ((safe_mod_func_int16_t_s_s(((safe_add_func_int16_t_s_s((p_52 | ((safe_mul_func_int8_t_s_s(((*l_662) = l_608[3][2][6]), (g_291[8] >= (((safe_add_func_uint64_t_u_u(((((safe_lshift_func_uint8_t_u_u((g_66 = (g_176[1] , 0x30L)), g_261)) && 249UL) || 0x00F5L) ^ l_608[0][0][2]), 1L)) , (*g_640)) == (*g_194))))) > l_450)), l_667)) >= l_495), p_52)) | (**l_638))))), l_668)), 0x91L)), 0x93L))), l_668))) , g_150[5])));
                        l_670[1][1][5] = &l_605;
                    }
                    for (l_495 = (-23); (l_495 != (-1)); l_495 = safe_add_func_int16_t_s_s(l_495, 5))
                    { /* block id: 235 */
                        uint8_t l_674[10][5] = {{0x50L,0x54L,0x3DL,0x50L,255UL},{5UL,0x50L,1UL,0x50L,5UL},{0x3DL,1UL,0x54L,255UL,1UL},{5UL,0x54L,0x54L,5UL,255UL},{0x50L,5UL,1UL,1UL,1UL},{0x3DL,5UL,0x3DL,255UL,5UL},{1UL,0x54L,255UL,1UL,255UL},{1UL,1UL,1UL,5UL,0x50L},{0x3DL,0x50L,255UL,255UL,0x50L},{0x50L,0x54L,0x3DL,0x50L,255UL}};
                        int32_t *l_679 = &g_57;
                        int8_t **l_689 = &g_77;
                        int i, j;
                        l_674[7][1]++;
                        (**l_638) |= (safe_lshift_func_int16_t_s_u(p_52, 9));
                        l_670[1][1][5] = (*g_194);
                    }
                }
                for (l_502 = 27; (l_502 < 20); l_502 = safe_sub_func_uint32_t_u_u(l_502, 1))
                { /* block id: 245 */
                    (**l_638) = l_692;
                    if ((*g_92))
                        break;
                }
            }
            else
            { /* block id: 249 */
                int64_t **l_697 = (void*)0;
                (*g_527) = l_693;
                for (l_540 = 14; (l_540 > 8); l_540 = safe_sub_func_uint64_t_u_u(l_540, 1))
                { /* block id: 253 */
                    l_697 = l_696[0][1];
                }
            }
            (*g_640) = (*g_194);
            return l_704;
        }
        if ((**g_640))
            continue;
    }
    g_565 &= (safe_rshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u(((l_709[3][0][2] , ((**g_640) = p_52)) , ((***g_639) >= (((*p_53) == (safe_lshift_func_uint8_t_u_u(p_52, 7))) > g_153))), (0x29C866FD35431F00LL != (g_454 <= g_712[0][3][0])))), 2));
    return (*l_698);
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_89 g_47 g_78 g_66 g_102 g_147 g_153 g_234 g_291 g_261 g_425 g_150 g_213 g_443
 * writes: g_77 g_92 g_102 g_66 g_78 g_89 g_147 g_162 g_164 g_153 g_425 g_213 g_426 g_443
 */
static const uint64_t  func_62(uint8_t  p_63, int32_t  p_64)
{ /* block id: 11 */
    int8_t * const l_76 = (void*)0;
    int16_t **l_427 = &g_425[1];
    int16_t * const l_428 = &g_426;
    int32_t *l_440 = &g_213;
    int32_t l_441 = 0L;
    int32_t *l_442 = &g_443;
    (*l_442) ^= (safe_rshift_func_uint8_t_u_u((((((safe_mod_func_uint32_t_u_u(func_72(&g_47[4], (g_77 = l_76), p_63), ((g_261 && (((*l_427) = g_425[5]) != l_428)) ^ (((((safe_sub_func_int16_t_s_s((safe_lshift_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((((g_150[5] , (+(g_426 = ((safe_sub_func_int32_t_s_s(((*l_440) &= (safe_div_func_int32_t_s_s((l_428 != l_428), g_261))), 4294967295UL)) | 1L)))) > g_291[7]) == 0x77L), 4)), 2)), (-1L))) <= g_150[2]) == 65535UL) ^ g_261) , p_64)))) , (*l_440)) & l_441) || (*l_440)) | g_47[3]), 7));
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_89 g_47 g_78 g_66 g_102 g_147 g_153 g_234 g_291
 * writes: g_92 g_102 g_66 g_78 g_89 g_147 g_162 g_164 g_153
 */
static uint32_t  func_72(int8_t * p_73, int8_t * const  p_74, uint64_t  p_75)
{ /* block id: 13 */
    int32_t *l_85 = &g_57;
    int32_t *l_88 = &g_89;
    int32_t *l_91 = &g_89;
    int32_t **l_90[7];
    const int8_t l_95 = 1L;
    const int32_t * const *l_98 = (void*)0;
    uint32_t l_101[6];
    int i;
    for (i = 0; i < 7; i++)
        l_90[i] = &l_91;
    for (i = 0; i < 6; i++)
        l_101[i] = 18446744073709551613UL;
    (*g_234) = func_79(l_85, &g_77, (safe_mod_func_int8_t_s_s(((((g_92 = (l_88 = l_85)) != (g_102 = ((g_56 < (safe_lshift_func_int8_t_s_u((l_95 , (((safe_add_func_int16_t_s_s(((((&l_85 == l_98) != 1L) & (safe_lshift_func_uint16_t_u_u(((l_101[2] | p_75) ^ g_89), (*l_91)))) < g_89), 0x0A65L)) , p_75) && p_75)), p_75))) , &g_89))) , 0x319FL) <= g_47[0]), 248UL)), g_78, &g_89);
    for (g_66 = 0; (g_66 <= 6); g_66 += 1)
    { /* block id: 163 */
        int32_t *l_422 = &g_150[1];
        int i;
        (*l_91) = 0x27954CA5L;
        (*g_234) = l_422;
    }
    return g_291[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_66 g_78 g_102 g_89 g_147 g_56 g_47 g_153
 * writes: g_66 g_78 g_89 g_147 g_162 g_164 g_153
 */
static int32_t * func_79(int32_t * p_80, int8_t ** p_81, uint16_t  p_82, uint64_t  p_83, int32_t * p_84)
{ /* block id: 17 */
    uint64_t l_154 = 18446744073709551615UL;
    int16_t *l_160 = &g_147;
    int16_t *l_163 = &g_147;
    int32_t l_165 = 0x7292A33AL;
    int8_t *l_186 = &g_47[4];
    int32_t l_193 = 0x4EE80DCCL;
    uint64_t l_231 = 18446744073709551606UL;
    int32_t l_237 = 0x46F66214L;
    int32_t l_238 = 0xE816EFC9L;
    int32_t l_247 = (-9L);
    int32_t l_252 = 1L;
    int32_t l_254 = 0x8AD40829L;
    int32_t l_258[5];
    int16_t l_325 = 0x5566L;
    int i;
    for (i = 0; i < 5; i++)
        l_258[i] = 0xB79274EEL;
    for (g_66 = 9; (g_66 >= 6); g_66--)
    { /* block id: 20 */
        uint32_t l_159 = 4294967295UL;
        int32_t l_166 = 0xC23271FEL;
        for (g_78 = 0; (g_78 > (-16)); --g_78)
        { /* block id: 23 */
            uint8_t l_148[1];
            int i;
            for (i = 0; i < 1; i++)
                l_148[i] = 0UL;
            if ((*g_102))
            { /* block id: 24 */
                uint8_t l_107 = 0x83L;
                (*p_84) ^= l_107;
            }
            else
            { /* block id: 26 */
                uint32_t l_122 = 0x17A8F3E7L;
                uint8_t l_151 = 0x24L;
                for (p_82 = (-15); (p_82 < 33); p_82 = safe_add_func_uint64_t_u_u(p_82, 4))
                { /* block id: 29 */
                    uint32_t l_123 = 0xA5CD88FCL;
                    uint8_t *l_145 = &g_66;
                    int16_t *l_146 = &g_147;
                    int32_t *l_149[6];
                    int64_t *l_152[10] = {&g_153,&g_153,&g_153,&g_153,&g_153,&g_153,&g_153,&g_153,&g_153,&g_153};
                    uint64_t *l_161 = &g_162;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_149[i] = &g_150[5];
                    (*p_84) = (safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(((((safe_lshift_func_uint8_t_u_s(((l_151 |= (safe_mod_func_uint64_t_u_u((((safe_lshift_func_uint8_t_u_u((((l_123 = (safe_sub_func_int8_t_s_s(l_122, l_122))) <= ((safe_lshift_func_int16_t_s_s(0x108DL, 10)) != (((safe_rshift_func_int16_t_s_s(((safe_sub_func_int8_t_s_s(0x54L, (safe_sub_func_uint64_t_u_u((((((0x78L > g_89) , ((p_82 >= (~(safe_lshift_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(p_82, ((((safe_sub_func_int32_t_s_s(((safe_mod_func_int16_t_s_s(((*l_146) ^= (safe_lshift_func_int8_t_s_s((l_145 != &g_66), l_122))), p_82)) , (*g_102)), 0x6F1F252AL)) ^ p_83) , l_145) != &g_47[4]))) , g_147), l_122)), p_82)))) & g_56)) ^ p_82) >= (-6L)) || 0xDEL), 0x0B978F22BB1B7708LL)))) > 0L), l_148[0])) && 0L) | 0x8499A8E0L))) , l_148[0]), 3)) , l_148[0]) | g_47[4]), g_89))) >= p_82), p_83)) && 0x28L) , 0xECL) || 9L), 6)) , 0xAF607F38L), p_83));
                    l_166 ^= (((((((g_89 >= (((l_154 = 0x7DDF4F03A57AA260LL) >= ((safe_sub_func_int8_t_s_s((safe_add_func_uint64_t_u_u(((*g_102) == (((*l_161) = (l_159 || ((void*)0 != l_160))) <= ((p_82 & (p_83 || (((((g_164 = (l_163 = (void*)0)) != (void*)0) >= 0xCA0AE64CL) , l_165) ^ 0xD8L))) , p_82))), 0x5370BFA85FE053DALL)), 0L)) , g_47[4])) == 0xFCB35CAECAF6BF14LL)) & 7L) , 0UL) <= p_82) , 0x1ECF65DDD0FC4F5ELL) != l_165) , 0x801A5785L);
                }
            }
            return &g_89;
        }
    }
    for (g_153 = 0; (g_153 <= 8); g_153 += 1)
    { /* block id: 46 */
        int16_t l_174 = 4L;
        int32_t l_177 = 0L;
        int8_t *l_185 = &g_47[4];
        int32_t l_240 = 0x7069160EL;
        int32_t l_241 = 0xF92F17FBL;
        int8_t l_242[1][8] = {{0x3DL,0xEBL,0xEBL,0x3DL,0xEBL,0xEBL,0x3DL,0xEBL}};
        int32_t l_243 = 0x78437ABAL;
        int32_t l_246 = 8L;
        int32_t l_251[9][2][1] = {{{0x5C01A54CL},{0x5C01A54CL}},{{0xD0B5B8E1L},{0x5C01A54CL}},{{0x5C01A54CL},{0xD0B5B8E1L}},{{0x5C01A54CL},{0x5C01A54CL}},{{0xD0B5B8E1L},{0x5C01A54CL}},{{0x5C01A54CL},{0xD0B5B8E1L}},{{0x5C01A54CL},{0x5C01A54CL}},{{0xD0B5B8E1L},{0x5C01A54CL}},{{0x5C01A54CL},{0xD0B5B8E1L}}};
        int32_t l_262 = 1L;
        int32_t **l_278 = &g_102;
        uint64_t l_348 = 1UL;
        uint32_t *l_401 = &g_176[2];
        int i, j, k;
        for (g_89 = 6; (g_89 >= 2); g_89 -= 1)
        { /* block id: 49 */
            int16_t *l_173 = &g_147;
            uint32_t *l_175 = &g_176[1];
            int16_t l_178 = 0xD2B4L;
            int32_t *l_179 = &g_150[(g_89 + 1)];
            uint16_t l_197 = 9UL;
            int32_t l_212[1][3][10] = {{{0L,8L,0L,8L,0L,8L,0L,8L,0L,8L},{0L,8L,0L,8L,0L,8L,0L,8L,0L,8L},{0L,8L,0L,8L,0L,8L,0L,8L,0L,8L}}};
            int32_t *l_216 = &g_150[(g_89 + 1)];
            int32_t l_245 = 0x4A5BA704L;
            int32_t l_248 = 1L;
            int32_t l_256 = (-3L);
            int32_t l_259[7][7] = {{0x06CB08EFL,0x1DAB9524L,0x616180E2L,0x1DAB9524L,0x06CB08EFL,0xD04AB980L,0x06CB08EFL},{0L,0L,6L,4L,0L,0L,4L},{0x52EE5E14L,0x1DAB9524L,0x52EE5E14L,0x689E5FA9L,0x7A5CF373L,0x689E5FA9L,0x52EE5E14L},{0L,4L,0x0640D2D8L,0L,0L,0x0640D2D8L,4L},{0x06CB08EFL,0x689E5FA9L,(-1L),0x1DAB9524L,(-1L),0x689E5FA9L,0x06CB08EFL},{0L,0L,6L,6L,0L,0L,6L},{0x7A5CF373L,0x1DAB9524L,(-8L),0x1DAB9524L,0x7A5CF373L,0xD04AB980L,0x7A5CF373L}};
            int16_t **l_270 = &l_160;
            int32_t *l_279 = (void*)0;
            uint32_t *l_290 = &g_291[5];
            uint64_t *l_302 = &l_154;
            uint64_t *l_305 = &l_231;
            uint64_t *l_306 = &g_162;
            uint16_t l_307 = 0x0CCCL;
            int i, j, k;
        }
    }
    return p_80;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_47[i], "g_47[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_147, "g_147", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_150[i], "g_150[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_176[i], "g_176[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_232, "g_232", print_hash_value);
    transparent_crc(g_261, "g_261", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_265[i][j], "g_265[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_291[i], "g_291[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_382, "g_382", print_hash_value);
    transparent_crc(g_426, "g_426", print_hash_value);
    transparent_crc(g_443, "g_443", print_hash_value);
    transparent_crc(g_452, "g_452", print_hash_value);
    transparent_crc(g_454, "g_454", print_hash_value);
    transparent_crc(g_539, "g_539", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_560[i], "g_560[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_565, "g_565", print_hash_value);
    transparent_crc(g_673, "g_673", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_686[i], "g_686[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_712[i][j][k], "g_712[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_715, "g_715", print_hash_value);
    transparent_crc(g_741, "g_741", print_hash_value);
    transparent_crc(g_875, "g_875", print_hash_value);
    transparent_crc(g_918, "g_918", print_hash_value);
    transparent_crc(g_935, "g_935", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_962[i][j], "g_962[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1069, "g_1069", print_hash_value);
    transparent_crc(g_1136, "g_1136", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1198[i], "g_1198[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1259, "g_1259", print_hash_value);
    transparent_crc(g_1459, "g_1459", print_hash_value);
    transparent_crc(g_1564, "g_1564", print_hash_value);
    transparent_crc(g_1637, "g_1637", print_hash_value);
    transparent_crc(g_1713, "g_1713", print_hash_value);
    transparent_crc(g_1715, "g_1715", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1993[i], "g_1993[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2005, "g_2005", print_hash_value);
    transparent_crc(g_2077, "g_2077", print_hash_value);
    transparent_crc(g_2118, "g_2118", print_hash_value);
    transparent_crc(g_2253, "g_2253", print_hash_value);
    transparent_crc(g_2419, "g_2419", print_hash_value);
    transparent_crc(g_2467, "g_2467", print_hash_value);
    transparent_crc(g_2515, "g_2515", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2519[i], "g_2519[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2529, "g_2529", print_hash_value);
    transparent_crc(g_2534, "g_2534", print_hash_value);
    transparent_crc(g_2626, "g_2626", print_hash_value);
    transparent_crc(g_2660, "g_2660", print_hash_value);
    transparent_crc(g_2845, "g_2845", print_hash_value);
    transparent_crc(g_2846, "g_2846", print_hash_value);
    transparent_crc(g_2897, "g_2897", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2972[i][j][k], "g_2972[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3053, "g_3053", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_3071[i], "g_3071[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3143, "g_3143", print_hash_value);
    transparent_crc(g_3190, "g_3190", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3218[i], "g_3218[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3257[i], "g_3257[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3530[i][j][k], "g_3530[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3620, "g_3620", print_hash_value);
    transparent_crc(g_3857, "g_3857", print_hash_value);
    transparent_crc(g_3950, "g_3950", print_hash_value);
    transparent_crc(g_3995, "g_3995", print_hash_value);
    transparent_crc(g_4216, "g_4216", print_hash_value);
    transparent_crc(g_4312, "g_4312", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_4313[i], "g_4313[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4547, "g_4547", print_hash_value);
    transparent_crc(g_4748, "g_4748", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_4831[i][j][k], "g_4831[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1203
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 54
breakdown:
   depth: 1, occurrence: 181
   depth: 2, occurrence: 44
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 12, occurrence: 2
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 17, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 24, occurrence: 3
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 3
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 37, occurrence: 3
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 46, occurrence: 1
   depth: 54, occurrence: 1

XXX total number of pointers: 866

XXX times a variable address is taken: 1829
XXX times a pointer is dereferenced on RHS: 699
breakdown:
   depth: 1, occurrence: 553
   depth: 2, occurrence: 130
   depth: 3, occurrence: 13
   depth: 4, occurrence: 3
XXX times a pointer is dereferenced on LHS: 673
breakdown:
   depth: 1, occurrence: 570
   depth: 2, occurrence: 83
   depth: 3, occurrence: 18
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 78
XXX times a pointer is compared with address of another variable: 35
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 21705

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2554
   level: 2, occurrence: 1133
   level: 3, occurrence: 507
   level: 4, occurrence: 149
   level: 5, occurrence: 15
XXX number of pointers point to pointers: 385
XXX number of pointers point to scalars: 481
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.6
XXX average alias set size: 1.53

XXX times a non-volatile is read: 4172
XXX times a non-volatile is write: 1991
XXX times a volatile is read: 181
XXX    times read thru a pointer: 90
XXX times a volatile is write: 29
XXX    times written thru a pointer: 3
XXX times a volatile is available for access: 4.33e+03
XXX percentage of non-volatile access: 96.7

XXX forward jumps: 2
XXX backward jumps: 12

XXX stmts: 179
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 20
   depth: 2, occurrence: 19
   depth: 3, occurrence: 31
   depth: 4, occurrence: 26
   depth: 5, occurrence: 51

XXX percentage a fresh-made variable is used: 13.1
XXX percentage an existing variable is used: 86.9
********************* end of statistics **********************/

