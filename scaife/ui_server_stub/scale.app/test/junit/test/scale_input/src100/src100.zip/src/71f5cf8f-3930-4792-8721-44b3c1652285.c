/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      569983261
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_18 = 0x5A1FA147L;
static uint32_t g_50 = 0x5F4B3F4BL;
static uint32_t *g_58[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t *g_65 = &g_18;
static int32_t ** volatile g_64 = &g_65;/* VOLATILE GLOBAL g_64 */
static int64_t g_75 = 0L;
static uint32_t * const *g_78 = &g_58[2];
static uint32_t * const ** volatile g_77 = &g_78;/* VOLATILE GLOBAL g_77 */
static uint16_t g_88 = 1UL;
static int64_t g_91[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int16_t g_95 = 1L;
static uint64_t g_97 = 0x829F48D0B90E515ELL;
static volatile uint32_t g_103 = 0x414CEA6EL;/* VOLATILE GLOBAL g_103 */
static volatile int16_t g_120 = (-3L);/* VOLATILE GLOBAL g_120 */
static volatile int16_t *g_119[4][5] = {{&g_120,&g_120,&g_120,&g_120,&g_120},{&g_120,&g_120,&g_120,&g_120,&g_120},{&g_120,&g_120,&g_120,&g_120,&g_120},{&g_120,&g_120,&g_120,&g_120,&g_120}};
static volatile int16_t **g_118 = &g_119[3][2];
static volatile int16_t *** volatile g_121 = &g_118;/* VOLATILE GLOBAL g_121 */
static int32_t ** volatile g_130 = &g_65;/* VOLATILE GLOBAL g_130 */
static int8_t g_139 = 8L;
static int8_t g_143 = 0x9CL;
static int32_t ** volatile g_147 = &g_65;/* VOLATILE GLOBAL g_147 */
static int32_t ** volatile g_148[10] = {&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,(void*)0,&g_65};
static int32_t ** volatile g_149 = &g_65;/* VOLATILE GLOBAL g_149 */
static volatile int16_t g_160 = (-3L);/* VOLATILE GLOBAL g_160 */
static uint64_t *g_170[4] = {&g_97,&g_97,&g_97,&g_97};
static uint32_t g_173 = 0xD65F59F4L;
static uint8_t g_213 = 0xCBL;
static volatile uint16_t * volatile *g_241 = (void*)0;
static const int32_t g_281 = 0x45664DC4L;
static const int32_t g_282 = 0x165E364BL;
static const int32_t g_283 = 1L;
static const int32_t g_284 = (-6L);
static const int32_t g_285 = 1L;
static const int32_t g_286[5] = {0L,0L,0L,0L,0L};
static const int32_t g_287 = 0xDA18E814L;
static const int32_t g_288 = 9L;
static const int32_t g_289 = 0x0ADE143DL;
static const int32_t g_290 = (-9L);
static const int32_t g_291 = 1L;
static const int32_t g_292[7][8] = {{0xBEB7BC3CL,0L,0L,0xBEB7BC3CL,(-1L),0xBEB7BC3CL,0L,0L},{0L,(-1L),0x65AA627CL,0x65AA627CL,(-1L),0L,(-1L),0x65AA627CL},{0xBEB7BC3CL,(-1L),0xBEB7BC3CL,0L,0L,0xBEB7BC3CL,(-1L),0xBEB7BC3CL},{0x0D8113C6L,0L,0x65AA627CL,0L,0x0D8113C6L,0x0D8113C6L,0L,0x65AA627CL},{0x0D8113C6L,0x0D8113C6L,0L,0x65AA627CL,0L,0x0D8113C6L,0x0D8113C6L,0L},{0xBEB7BC3CL,0L,0L,0xBEB7BC3CL,(-1L),0xBEB7BC3CL,0L,0L},{0L,(-1L),0x65AA627CL,0x65AA627CL,(-1L),0L,(-1L),0x65AA627CL}};
static const int32_t g_293 = 0x42329A77L;
static const int32_t g_294 = 0x760703F9L;
static const int32_t g_295 = 0x88BC39DAL;
static const int32_t g_296[8][9] = {{0x78338062L,0x7297D7F4L,0x7E8B2182L,0L,(-1L),7L,0xEE0DA896L,8L,0x8CD31550L},{5L,0x78338062L,0L,8L,8L,0L,0x78338062L,5L,0x7D63D277L},{0x32D43466L,5L,5L,8L,0x82274A53L,0x7D63D277L,1L,0x7297D7F4L,7L},{0x7D63D277L,0x98CBA876L,7L,0L,0x32D43466L,0L,7L,0x98CBA876L,0x7D63D277L},{0xEE0DA896L,0L,0x82274A53L,(-1L),0x32D43466L,1L,5L,0L,0x8CD31550L},{0x7297D7F4L,0L,(-1L),0xCC20415CL,0x82274A53L,0x82274A53L,0xCC20415CL,(-1L),0L},{0xEE0DA896L,0x32D43466L,5L,5L,8L,0x82274A53L,0x7D63D277L,1L,0x7297D7F4L},{0x7D63D277L,0xCC20415CL,0x32D43466L,0x8CD31550L,(-1L),1L,(-1L),0x8CD31550L,0x32D43466L}};
static const int32_t g_297[1] = {0xC57668B8L};
static const int32_t g_298 = (-8L);
static const int32_t g_299 = (-1L);
static const int32_t g_300 = (-1L);
static const int32_t g_301[4] = {0xB601ADE1L,0xB601ADE1L,0xB601ADE1L,0xB601ADE1L};
static const int32_t g_302 = 0x727D7274L;
static const int32_t g_303[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static const int32_t g_304[5][5] = {{0L,0xE0DA037CL,0L,0L,0xE0DA037CL},{0x23C34957L,0L,0xCD3D2653L,0xD5A770EAL,0xCD3D2653L},{0xE0DA037CL,0xE0DA037CL,0x3B03B971L,0xE0DA037CL,0xE0DA037CL},{0xCD3D2653L,0xD5A770EAL,0xCD3D2653L,0L,0x23C34957L},{0xE0DA037CL,0L,0L,0xE0DA037CL,0L}};
static const int32_t g_305 = 0xA92C8E55L;
static const int32_t g_306 = 0xD23FB492L;
static int32_t ** volatile g_376[6] = {&g_65,&g_65,&g_65,&g_65,&g_65,&g_65};
static int32_t ** volatile g_505 = &g_65;/* VOLATILE GLOBAL g_505 */
static uint16_t *g_604 = &g_88;
static uint16_t **g_603 = &g_604;
static uint16_t **g_605 = &g_604;
static int64_t g_661 = 1L;
static int8_t g_683 = 0L;
static int32_t g_706 = (-1L);
static int32_t * volatile g_705 = &g_706;/* VOLATILE GLOBAL g_705 */
static uint32_t g_813 = 3UL;
static volatile int8_t g_826 = 1L;/* VOLATILE GLOBAL g_826 */
static volatile int8_t *g_825[4][5] = {{(void*)0,&g_826,(void*)0,&g_826,(void*)0},{&g_826,&g_826,&g_826,&g_826,&g_826},{(void*)0,&g_826,(void*)0,&g_826,(void*)0},{&g_826,&g_826,&g_826,&g_826,&g_826}};
static volatile int8_t **g_824[10][5] = {{&g_825[1][0],&g_825[1][1],&g_825[1][3],&g_825[2][2],(void*)0},{(void*)0,&g_825[1][3],&g_825[2][1],&g_825[1][4],&g_825[3][0]},{&g_825[1][1],&g_825[1][0],&g_825[1][0],&g_825[1][1],(void*)0},{&g_825[0][3],&g_825[1][4],&g_825[1][0],&g_825[1][0],&g_825[1][4]},{(void*)0,&g_825[1][0],&g_825[1][0],&g_825[2][1],&g_825[2][1]},{&g_825[1][0],(void*)0,&g_825[1][0],&g_825[3][1],&g_825[2][1]},{&g_825[2][2],&g_825[1][1],&g_825[2][1],&g_825[0][3],&g_825[1][4]},{&g_825[1][0],&g_825[0][3],&g_825[1][3],&g_825[1][4],&g_825[1][3]},{(void*)0,(void*)0,(void*)0,&g_825[1][4],&g_825[2][3]},{&g_825[0][3],&g_825[1][0],&g_825[1][0],&g_825[0][3],(void*)0}};
static int32_t ** volatile g_885 = &g_65;/* VOLATILE GLOBAL g_885 */
static uint8_t g_929 = 0x35L;
static int32_t g_1015 = 0xECEA3158L;
static const int8_t g_1018 = 1L;
static const int8_t g_1020[9][8] = {{0x57L,0xC6L,0x11L,0x5FL,0xC6L,(-1L),0xEFL,(-1L)},{0xD0L,0x57L,0L,0x57L,0xD0L,9L,0x5FL,0xD0L},{(-1L),6L,0xC8L,(-1L),0x32L,0xC6L,1L,0x57L},{6L,1L,0xC8L,0x5FL,0x3AL,0x3AL,0x5FL,0xC8L},{0x32L,0x32L,0L,0xD0L,0x53L,0L,0xEFL,0x32L},{1L,6L,0x11L,0x3AL,0xEFL,0x11L,0xC8L,0x32L},{6L,(-1L),1L,0xD0L,1L,(-1L),6L,0xC8L},{0x57L,0xD0L,9L,0x5FL,0xD0L,0xADL,0xEFL,0x57L},{0xC6L,0x57L,0x3AL,(-1L),0xD0L,0x11L,0x11L,0xD0L}};
static const int8_t *g_1019 = &g_1020[8][6];
static uint16_t g_1027 = 65535UL;
static int64_t *g_1085[6][4][10] = {{{&g_91[1],&g_75,&g_75,(void*)0,&g_91[0],&g_91[1],&g_91[0],(void*)0,&g_75,&g_75},{&g_91[1],(void*)0,&g_91[1],&g_91[1],&g_91[1],&g_91[3],&g_75,&g_91[1],&g_91[1],&g_91[1]},{&g_75,(void*)0,&g_91[1],&g_75,&g_661,&g_91[3],&g_91[1],&g_75,&g_91[1],&g_661},{&g_91[1],&g_661,&g_91[1],&g_75,&g_661,&g_91[1],&g_661,&g_91[1],&g_91[1],&g_91[1]}},{{&g_91[1],&g_75,(void*)0,&g_91[1],&g_91[1],(void*)0,&g_75,&g_91[1],&g_661,&g_91[1]},{&g_75,&g_91[3],&g_75,&g_91[1],&g_661,&g_75,&g_91[3],&g_91[1],&g_661,(void*)0},{&g_91[3],&g_91[1],(void*)0,&g_75,(void*)0,&g_91[1],&g_661,&g_75,&g_661,(void*)0},{&g_91[6],(void*)0,&g_91[1],(void*)0,&g_661,&g_75,&g_91[1],(void*)0,&g_91[1],&g_75}},{{&g_75,&g_75,&g_661,&g_75,&g_75,&g_91[6],(void*)0,&g_661,&g_661,&g_91[3]},{&g_661,&g_75,&g_75,&g_91[1],&g_75,&g_661,&g_661,&g_91[1],&g_91[1],&g_91[3]},{&g_91[1],&g_91[1],(void*)0,&g_75,&g_75,&g_91[1],&g_91[1],&g_75,&g_91[1],&g_75},{(void*)0,&g_91[1],(void*)0,&g_75,&g_661,&g_75,&g_75,&g_661,&g_75,(void*)0}},{{&g_91[1],&g_91[1],&g_91[1],&g_75,(void*)0,&g_91[1],&g_91[1],&g_91[1],&g_75,(void*)0},{&g_661,&g_91[6],&g_661,&g_91[1],&g_75,&g_75,&g_91[1],&g_661,&g_91[1],(void*)0},{&g_75,&g_91[1],(void*)0,&g_91[1],(void*)0,&g_75,&g_75,&g_661,(void*)0,&g_75},{&g_91[1],&g_91[1],&g_91[1],(void*)0,&g_91[1],(void*)0,&g_91[1],&g_91[1],&g_91[1],&g_91[3]}},{{&g_91[3],&g_91[1],(void*)0,&g_91[1],&g_661,&g_75,&g_661,&g_75,&g_75,&g_661},{&g_91[1],&g_75,&g_75,&g_91[1],&g_91[6],&g_91[0],(void*)0,&g_75,&g_91[1],&g_661},{&g_91[1],&g_75,&g_91[1],(void*)0,&g_75,&g_75,&g_91[1],(void*)0,(void*)0,&g_91[1]},{&g_661,(void*)0,&g_91[1],&g_91[1],(void*)0,&g_661,&g_661,&g_75,&g_91[1],&g_661}},{{&g_75,&g_91[1],&g_661,&g_91[1],&g_75,&g_91[1],&g_91[3],&g_661,&g_75,&g_91[1]},{&g_75,&g_91[1],&g_75,&g_75,(void*)0,&g_661,&g_91[1],&g_91[1],&g_75,&g_91[1]},{&g_661,&g_91[1],&g_91[1],&g_75,&g_91[1],&g_75,&g_75,&g_75,&g_91[1],&g_75},{&g_91[1],&g_75,&g_91[1],&g_75,&g_661,&g_91[0],&g_75,(void*)0,&g_91[1],&g_75}}};
static int64_t **g_1084 = &g_1085[2][1][6];
static const int64_t g_1110 = 0xB1BAE7C2A9A05DDCLL;
static int16_t g_1152[8] = {(-1L),1L,(-1L),1L,(-1L),1L,(-1L),1L};
static uint8_t g_1217[8][4][2] = {{{0x2AL,9UL},{0x5CL,0x2AL},{9UL,3UL},{9UL,0x2AL}},{{0x5CL,9UL},{0x2AL,3UL},{9UL,9UL},{0x5CL,9UL}},{{9UL,3UL},{0x2AL,9UL},{0x5CL,0x2AL},{9UL,3UL}},{{9UL,0x2AL},{0x5CL,9UL},{0x2AL,3UL},{9UL,9UL}},{{0x5CL,9UL},{9UL,3UL},{0x2AL,9UL},{0x5CL,0x2AL}},{{9UL,3UL},{9UL,0x2AL},{0x5CL,9UL},{0x2AL,3UL}},{{9UL,9UL},{0x5CL,9UL},{9UL,3UL},{0x2AL,9UL}},{{0x5CL,0x2AL},{9UL,3UL},{9UL,0x2AL},{0x5CL,9UL}}};
static volatile int32_t g_1237 = 1L;/* VOLATILE GLOBAL g_1237 */
static volatile int32_t * volatile g_1283[1] = {&g_1237};
static volatile uint32_t g_1323 = 0x26F59AF4L;/* VOLATILE GLOBAL g_1323 */
static volatile uint32_t * volatile g_1322 = &g_1323;/* VOLATILE GLOBAL g_1322 */
static volatile uint32_t * volatile *g_1321 = &g_1322;
static int32_t ** volatile g_1328[4] = {&g_65,&g_65,&g_65,&g_65};
static uint32_t g_1366 = 18446744073709551612UL;
static int32_t ** volatile g_1369 = &g_65;/* VOLATILE GLOBAL g_1369 */
static volatile uint32_t g_1387[1][4][2] = {{{4294967286UL,4294967286UL},{0x4AF44AFBL,4294967286UL},{4294967286UL,0x4AF44AFBL},{4294967286UL,4294967286UL}}};
static int32_t g_1415 = 0x0493F888L;
static int16_t g_1446 = 0x07F7L;
static volatile uint32_t g_1455 = 0x9DC0B261L;/* VOLATILE GLOBAL g_1455 */


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static int32_t * func_2(int32_t * p_3, int32_t * p_4, int32_t  p_5, int8_t  p_6, int32_t * p_7);
static int32_t * func_8(int32_t * p_9, uint16_t  p_10, uint16_t  p_11, int8_t  p_12, uint32_t  p_13);
static int32_t * func_14(int32_t * p_15, int8_t  p_16);
static int32_t  func_22(int16_t  p_23, int32_t  p_24, uint16_t  p_25, int16_t  p_26);
static int32_t  func_27(int32_t * p_28, int32_t * const  p_29, uint8_t  p_30, int32_t  p_31, int16_t  p_32);
static int32_t * func_33(uint16_t  p_34);
static int8_t  func_37(int32_t  p_38, int32_t * p_39, uint8_t  p_40);
static int32_t * const  func_44(uint32_t  p_45, int32_t  p_46, uint32_t  p_47, int32_t * p_48);
static int16_t  func_51(int8_t  p_52, int32_t * p_53, uint32_t * p_54);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18 g_885 g_143 g_296 g_281 g_286 g_604 g_88 g_173 g_683 g_661 g_603 g_213 g_91 g_605 g_50 g_284 g_147 g_65 g_121 g_118 g_119 g_120 g_295 g_282 g_300 g_130 g_1027 g_301 g_64 g_1019 g_1020 g_291 g_813 g_95 g_303 g_297 g_1415 g_1455
 * writes: g_65 g_683 g_18 g_213 g_95 g_75 g_826 g_824 g_1015 g_1019 g_88 g_1027 g_1084 g_1415 g_1455
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_17 = &g_18;
    int32_t **l_886 = &g_65;
    int32_t l_893 = 0x1485BD28L;
    int8_t *l_910 = &g_683;
    int32_t l_1449 = 0x6CE00F81L;
    int32_t *l_1450 = (void*)0;
    int32_t *l_1451 = &g_18;
    int32_t *l_1452 = &l_1449;
    int32_t *l_1453[7] = {&g_18,&g_18,&g_18,&g_18,&g_18,&g_18,&g_18};
    int32_t l_1454 = 0x9C7A27D1L;
    int i;
    (*l_886) = func_2(((*l_886) = func_8(((*l_886) = func_14(l_17, (~(*l_17)))), (safe_sub_func_int64_t_s_s((safe_add_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u(l_893, (safe_lshift_func_int16_t_s_u((((((*l_910) &= (((safe_lshift_func_int8_t_s_u((safe_mul_func_int16_t_s_s((0xC36609D8L ^ (safe_mod_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((((safe_sub_func_uint32_t_u_u(g_143, ((*l_17) <= (g_296[4][1] , ((safe_mod_func_uint8_t_u_u((0xCFA4L <= (*l_17)), g_143)) >= g_281))))) || g_286[2]) , 246UL), (*l_17))), (*g_604))), 0x2C664CD1L))), (*l_17))), 3)) <= (*l_17)) >= g_173)) >= g_661) > (*l_17)) == g_286[0]), (*l_17))))) <= (*l_17)), (*l_17))), (*l_17))), (**g_603), (*l_17), (*l_17))), &g_1415, g_303[5], g_297[0], &g_706);
    g_1455++;
    return (*l_1451);
}


/* ------------------------------------------ */
/* 
 * reads : g_1415
 * writes: g_1415
 */
static int32_t * func_2(int32_t * p_3, int32_t * p_4, int32_t  p_5, int8_t  p_6, int32_t * p_7)
{ /* block id: 677 */
    int32_t *l_1448 = &g_706;
    (*p_4) ^= 1L;
    return l_1448;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_213 g_91 g_604 g_88 g_605 g_50 g_284 g_147 g_65 g_121 g_118 g_119 g_120 g_603 g_295 g_282 g_885 g_300 g_130 g_1027 g_301 g_64 g_1019 g_1020 g_291 g_813 g_95
 * writes: g_18 g_213 g_65 g_95 g_75 g_826 g_824 g_1015 g_1019 g_88 g_1027 g_1084
 */
static int32_t * func_8(int32_t * p_9, uint16_t  p_10, uint16_t  p_11, int8_t  p_12, uint32_t  p_13)
{ /* block id: 457 */
    uint64_t * const l_926[9][6] = {{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97},{&g_97,&g_97,&g_97,&g_97,&g_97,&g_97}};
    int32_t l_932 = 0x5693E5BEL;
    int32_t l_961 = (-1L);
    const int64_t * const l_991 = &g_75;
    const int64_t * const * const l_990 = &l_991;
    int8_t l_1032 = 0L;
    int32_t *l_1035 = &g_706;
    uint64_t l_1169 = 5UL;
    int32_t l_1221 = 0x58610288L;
    int32_t l_1230 = 1L;
    int32_t l_1236 = 0xD07C38F5L;
    int32_t l_1241 = 0L;
    int32_t l_1243 = 0xFDE0E54AL;
    int32_t l_1247 = 0x69BA0C5CL;
    int32_t l_1248 = 0x8B2B8C9FL;
    int32_t l_1254 = 0xAB2D8728L;
    int32_t l_1255 = 0x89A08A66L;
    int32_t l_1256[2][1];
    uint32_t *l_1307 = &g_813;
    uint32_t **l_1306 = &l_1307;
    const uint16_t *l_1443 = &g_1027;
    const uint16_t **l_1442[8][3][6] = {{{&l_1443,&l_1443,&l_1443,&l_1443,(void*)0,&l_1443},{&l_1443,(void*)0,&l_1443,(void*)0,(void*)0,&l_1443},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{&l_1443,(void*)0,&l_1443,&l_1443,(void*)0,&l_1443},{(void*)0,&l_1443,&l_1443,(void*)0,(void*)0,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{&l_1443,(void*)0,&l_1443,&l_1443,&l_1443,&l_1443},{(void*)0,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,(void*)0,(void*)0},{&l_1443,(void*)0,(void*)0,(void*)0,&l_1443,&l_1443},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,(void*)0,&l_1443,&l_1443,(void*)0},{&l_1443,&l_1443,&l_1443,(void*)0,&l_1443,&l_1443},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,(void*)0},{&l_1443,&l_1443,(void*)0,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{&l_1443,&l_1443,(void*)0,&l_1443,&l_1443,(void*)0},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443}},{{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{&l_1443,&l_1443,&l_1443,&l_1443,&l_1443,&l_1443},{(void*)0,&l_1443,&l_1443,&l_1443,&l_1443,(void*)0}}};
    const uint16_t ***l_1441[6] = {&l_1442[5][0][4],&l_1442[5][0][4],&l_1442[5][0][4],&l_1442[5][0][4],&l_1442[5][0][4],&l_1442[5][0][4]};
    int32_t *l_1447 = (void*)0;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_1256[i][j] = 0x2D4315E1L;
    }
    (*p_9) = 0x581E9204L;
    if (((*p_9) = (*p_9)))
    { /* block id: 460 */
        const int16_t **l_914 = (void*)0;
        const int16_t *** const l_913[4] = {&l_914,&l_914,&l_914,&l_914};
        int32_t l_962 = 7L;
        const int64_t *l_989 = &g_91[9];
        const int64_t **l_988 = &l_989;
        int32_t *l_1009 = &l_932;
        int i;
        for (g_213 = 0; (g_213 <= 9); g_213 += 1)
        { /* block id: 463 */
            int16_t l_930 = 0x2B58L;
            int32_t l_951[4] = {(-3L),(-3L),(-3L),(-3L)};
            int8_t l_992 = 6L;
            int i;
            for (p_13 = 0; (p_13 <= 9); p_13 += 1)
            { /* block id: 466 */
                uint32_t *l_921 = &g_173;
                int32_t l_927 = (-4L);
                uint8_t *l_928 = &g_929;
                uint32_t *l_931 = &g_813;
                int32_t **l_933[5] = {&g_65,&g_65,&g_65,&g_65,&g_65};
                int i;
                if (g_91[p_13])
                    break;
            }
            for (p_13 = 0; (p_13 <= 4); p_13 += 1)
            { /* block id: 483 */
                uint16_t l_952 = 9UL;
                const uint64_t l_958 = 0x462B85E9DB54FA27LL;
                int32_t **l_1005 = &g_65;
                for (g_18 = 7; (g_18 >= 0); g_18 -= 1)
                { /* block id: 486 */
                    int16_t *l_946 = &l_930;
                    int8_t *l_950[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint64_t *l_972 = &g_97;
                    int32_t l_993 = 1L;
                    int32_t *l_995 = &g_706;
                    int i, j;
                    if (((safe_add_func_int16_t_s_s(((*g_604) == ((safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((p_12 , &g_58[(p_13 + 1)]) == &g_58[p_13]), p_12)), (safe_add_func_int64_t_s_s(((safe_unary_minus_func_uint16_t_u((safe_lshift_func_uint8_t_u_u((((*l_946) |= ((*p_9) , 0L)) >= (!(((*p_9) > (safe_lshift_func_int8_t_s_s((l_951[3] |= (((**g_605) != 0xBBB9L) != l_932)), p_12))) || l_952))), 0)))) ^ (-4L)), 3L)))) & 4294967289UL)), p_10)) != 0UL))
                    { /* block id: 489 */
                        uint8_t *l_955[3][4] = {{(void*)0,&g_929,(void*)0,&g_929},{&g_929,&g_929,(void*)0,(void*)0},{(void*)0,(void*)0,&g_929,(void*)0}};
                        int32_t l_963 = (-1L);
                        int32_t **l_964[6][7] = {{&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,&g_65},{(void*)0,&g_65,(void*)0,(void*)0,&g_65,(void*)0,(void*)0},{&g_65,&g_65,(void*)0,&g_65,&g_65,(void*)0,&g_65},{&g_65,(void*)0,(void*)0,&g_65,(void*)0,(void*)0,&g_65},{&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65,&g_65,&g_65,&g_65,&g_65}};
                        int32_t **l_965 = &g_65;
                        const uint64_t *l_973 = &g_97;
                        uint32_t l_987 = 0x84FB3BFEL;
                        uint8_t l_994 = 5UL;
                        int i, j;
                        (*l_965) = func_44((safe_sub_func_int8_t_s_s((((l_932 |= p_10) , (((-1L) <= l_930) , ((g_50 || (g_284 != ((void*)0 == l_926[0][0]))) >= l_958))) != (safe_sub_func_uint64_t_u_u((6UL ^ l_961), 0xC9A3BE870B8E43FALL))), 1L)), l_962, l_963, p_9);
                        l_994 = ((safe_div_func_int16_t_s_s(((((g_95 = (safe_rshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((l_972 == l_973) < (((((0xA1E3C531L & 0xD33F0BBCL) >= (((safe_mod_func_int32_t_s_s((safe_div_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((((((p_12 = (safe_add_func_uint32_t_u_u((!(safe_lshift_func_uint16_t_u_s(5UL, ((safe_mod_func_uint64_t_u_u(0xA0F78D48D518D59ELL, p_11)) && (((***g_121) <= 1UL) , (**g_603)))))), 0x923CD6FCL))) ^ p_13) & 0x8D3EL) , 1UL) ^ l_987), p_11)), (**g_605))), g_295)) , l_988) == l_990)) <= l_992) , g_282) || l_961)), p_11)), 6))) >= 0UL) , (*p_9)) || (*p_9)), (**g_603))) & l_993);
                        return l_995;
                    }
                    else
                    { /* block id: 496 */
                        uint32_t l_999 = 18446744073709551615UL;
                        int64_t *l_1003[1][2];
                        int64_t **l_1002[2];
                        int32_t **l_1004 = &l_995;
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_1003[i][j] = &g_661;
                        }
                        for (i = 0; i < 2; i++)
                            l_1002[i] = &l_1003[0][1];
                        (*l_1004) = func_14(func_14(&l_961, (p_11 & p_10)), (safe_sub_func_int8_t_s_s((~(l_999 = (4294967295UL ^ g_300))), (safe_sub_func_int64_t_s_s((-1L), (p_13 == ((void*)0 != l_1002[1])))))));
                        (**l_1005) ^= (&g_65 != l_1005);
                        (**l_1004) = (safe_rshift_func_uint8_t_u_s(((~p_10) == (*p_9)), 3));
                    }
                }
                for (g_75 = 0; g_75 < 10; g_75 += 1)
                {
                    for (g_826 = 0; g_826 < 5; g_826 += 1)
                    {
                        g_824[g_75][g_826] = &g_825[1][4];
                    }
                }
            }
        }
        (*l_1009) ^= (**g_130);
    }
    else
    { /* block id: 507 */
        int8_t *l_1013 = &g_683;
        int8_t **l_1012 = &l_1013;
        int32_t *l_1014 = &g_1015;
        const int8_t *l_1017 = &g_1018;
        const int8_t **l_1016[8][9][3] = {{{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{(void*)0,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,(void*)0,(void*)0},{&l_1017,(void*)0,&l_1017},{&l_1017,&l_1017,&l_1017}},{{&l_1017,(void*)0,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{(void*)0,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,(void*)0,&l_1017}},{{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0}},{{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{(void*)0,&l_1017,&l_1017}},{{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,(void*)0,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017}},{{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,(void*)0,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,(void*)0,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017}},{{&l_1017,&l_1017,&l_1017},{(void*)0,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,(void*)0,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017}},{{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,(void*)0},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017},{&l_1017,&l_1017,&l_1017}}};
        const int32_t l_1021 = 0x6D8C045EL;
        uint16_t *l_1026 = &g_1027;
        int32_t **l_1033 = (void*)0;
        int32_t **l_1034[10];
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_1034[i] = (void*)0;
        l_1035 = (((l_961 = ((safe_rshift_func_uint8_t_u_u((((*l_1012) = &g_683) == (g_1019 = (((*l_1014) = 8L) , &p_12))), (((l_1021 && ((((safe_mul_func_int16_t_s_s(p_12, (l_932 &= ((*l_1026) ^= (--(**g_605)))))) | ((0x1C9CL & 65526UL) >= ((safe_mul_func_int8_t_s_s(0L, (safe_mul_func_int16_t_s_s((((l_1032 || 9L) & p_13) == l_1032), (**g_118))))) > p_12))) & 0x94895EB0L) > g_301[3])) && 0xF140L) , 0x38L))) >= p_11)) == l_1021) , (void*)0);
    }
    for (l_932 = 0; (l_932 >= 2); l_932++)
    { /* block id: 519 */
        uint32_t l_1038 = 0xC629878FL;
        int32_t l_1059 = 0x81B065EDL;
        uint16_t l_1060[1][2];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_1060[i][j] = 65531UL;
        }
        (*g_65) = (((**g_603) ^= p_11) > (l_1038 >= ((l_1038 > 0x5856L) || (safe_sub_func_uint16_t_u_u((((safe_div_func_uint64_t_u_u((l_1059 = ((safe_rshift_func_uint16_t_u_s((safe_sub_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u((p_10 , (safe_rshift_func_uint16_t_u_s((safe_sub_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_s((safe_mul_func_int16_t_s_s((((safe_mod_func_uint64_t_u_u(((l_1038 != ((-1L) ^ ((*p_9) , (**g_64)))) != p_13), l_1038)) < (*p_9)) || 5L), l_1038)), (*g_1019))) | g_284), (*p_9))), g_291))), p_10)), 0x1C8AL)), g_813)) != p_13)), l_1060[0][0])) , p_11) && l_1060[0][0]), 65534UL)))));
    }
    for (p_13 = 0; (p_13 <= 16); p_13 = safe_add_func_int8_t_s_s(p_13, 7))
    { /* block id: 526 */
        uint32_t *l_1066 = (void*)0;
        uint32_t **l_1065 = &l_1066;
        uint32_t *l_1068[2];
        uint32_t **l_1067 = &l_1068[0];
        int32_t l_1077 = 7L;
        uint8_t *l_1078 = &g_213;
        int64_t *l_1083 = &g_91[1];
        int64_t **l_1082 = &l_1083;
        int32_t l_1117 = 0L;
        int16_t *l_1142 = &g_95;
        int32_t l_1231 = 6L;
        int32_t l_1239 = 0x4B83AF58L;
        int32_t l_1250 = (-1L);
        int32_t l_1257 = 0x2378CE37L;
        int64_t l_1258 = 0x89D48A5A8F445F85LL;
        int32_t l_1259 = 0x3DF4509AL;
        int32_t l_1261[3];
        uint16_t ***l_1270 = &g_605;
        int8_t l_1354 = 0xE9L;
        int32_t l_1365[2];
        int32_t **l_1401 = &g_65;
        int32_t ** const *l_1400 = &l_1401;
        int i;
        for (i = 0; i < 2; i++)
            l_1068[i] = &g_173;
        for (i = 0; i < 3; i++)
            l_1261[i] = 0L;
        for (i = 0; i < 2; i++)
            l_1365[i] = 1L;
        if ((safe_sub_func_int16_t_s_s((l_1035 == ((*l_1067) = ((*l_1065) = func_14((*g_147), (*g_1019))))), (safe_add_func_uint8_t_u_u(((*l_1078) = (((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s(p_11, p_13)), 0UL)) > (p_13 < (safe_mod_func_uint16_t_u_u(65535UL, l_1077)))) >= 0x6BL)), 6L)))))
        { /* block id: 530 */
            int32_t *l_1079 = &l_932;
            return p_9;
        }
        else
        { /* block id: 532 */
            uint64_t l_1092[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
            int32_t *l_1119 = &l_1077;
            uint8_t l_1132 = 0x26L;
            int64_t *l_1158 = &g_661;
            int32_t l_1168 = 0xA40D55C7L;
            int32_t l_1225 = 0x496A03F5L;
            int32_t l_1226 = 0xB7758055L;
            int32_t l_1228 = 0xD94EFF7CL;
            int32_t l_1233[8];
            int i;
            for (i = 0; i < 8; i++)
                l_1233[i] = 1L;
            (*p_9) = (l_1077 ^ ((safe_mul_func_uint8_t_u_u(((g_1084 = l_1082) == &g_1085[2][1][6]), (safe_rshift_func_int8_t_s_s((((0UL > 0L) & (0L | ((safe_add_func_int64_t_s_s((&g_118 != (void*)0), (l_932 &= (p_11 != 0xF994L)))) , l_1092[0]))) && 0x8E204E5091CD2ED9LL), p_11)))) , l_1077));
            for (g_95 = 0; (g_95 <= 23); g_95++)
            { /* block id: 538 */
                int32_t l_1113 = 0x3085612BL;
                int32_t l_1115[3];
                int64_t **l_1136 = &l_1083;
                int32_t **l_1162[3][7][1] = {{{&l_1119},{&l_1119},{&l_1035},{&g_65},{&l_1119},{&g_65},{&l_1035}},{{&l_1119},{&l_1119},{&l_1119},{&l_1119},{&l_1119},{&l_1035},{&g_65}},{{&l_1119},{&g_65},{&l_1035},{&l_1119},{&l_1119},{&l_1119},{&l_1119}}};
                int32_t ***l_1161 = &l_1162[0][5][0];
                const uint32_t *l_1165 = &g_813;
                int32_t l_1178 = 0xEC66B4F3L;
                int8_t l_1227 = 9L;
                uint64_t l_1262[1];
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_1115[i] = 1L;
                for (i = 0; i < 1; i++)
                    l_1262[i] = 0x63B933BAF05D8F39LL;
            }
        }
        for (l_1239 = 0; (l_1239 == (-23)); l_1239 = safe_sub_func_int32_t_s_s(l_1239, 1))
        { /* block id: 604 */
            uint64_t *l_1272 = &l_1169;
            int32_t l_1274 = 0L;
            int32_t l_1363 = 0x77E2A260L;
            const uint32_t l_1384[8][8][3] = {{{0x18FBEA10L,18446744073709551607UL,0x0E190A72L},{1UL,0x2A33BB26L,0xEF07237EL},{1UL,0x4944ACA2L,0x41F63C9DL},{0x18FBEA10L,0xF5A94F65L,0x56B34773L},{0x41F63C9DL,0xE8AE94B1L,0x18FBEA10L},{0xEFBDF533L,0x3408E740L,0x56B34773L},{18446744073709551607UL,0xD06EB5B9L,0x41F63C9DL},{0xEF07237EL,0x7FDC0A12L,0xEF07237EL}},{{18446744073709551612UL,0x7FDC0A12L,0x0E190A72L},{0x0E190A72L,0xD06EB5B9L,0xA40A7149L},{18446744073709551606UL,0x3408E740L,1UL},{18446744073709551615UL,0xE8AE94B1L,0x3760990AL},{18446744073709551606UL,0xF5A94F65L,18446744073709551613UL},{0x0E190A72L,0x4944ACA2L,0x40A04830L},{18446744073709551612UL,0x2A33BB26L,0x40A04830L},{0xEF07237EL,18446744073709551607UL,18446744073709551613UL}},{{18446744073709551607UL,0x0DB6500EL,0x3760990AL},{0xEFBDF533L,0x180FB4BAL,1UL},{0x41F63C9DL,0x0DB6500EL,0xA40A7149L},{0x18FBEA10L,18446744073709551607UL,0x0E190A72L},{1UL,0x2A33BB26L,0xEF07237EL},{1UL,0x4944ACA2L,0x41F63C9DL},{0x18FBEA10L,0xF5A94F65L,0x56B34773L},{0x41F63C9DL,0xE8AE94B1L,0x18FBEA10L}},{{0xEFBDF533L,0x3408E740L,0x56B34773L},{18446744073709551607UL,0xD06EB5B9L,0x41F63C9DL},{0xEF07237EL,0x7FDC0A12L,0xEF07237EL},{18446744073709551612UL,0x7FDC0A12L,0x0E190A72L},{0x0E190A72L,0xD06EB5B9L,0xA40A7149L},{18446744073709551606UL,0x3408E740L,1UL},{18446744073709551615UL,0xE8AE94B1L,0x3760990AL},{18446744073709551606UL,0xF5A94F65L,18446744073709551613UL}},{{0x0E190A72L,0x4944ACA2L,0x40A04830L},{18446744073709551612UL,0x2A33BB26L,0x40A04830L},{0xEF07237EL,18446744073709551607UL,18446744073709551613UL},{18446744073709551607UL,0x0DB6500EL,0x3760990AL},{0xEFBDF533L,0x180FB4BAL,1UL},{0x41F63C9DL,0x0DB6500EL,0xA40A7149L},{0x18FBEA10L,18446744073709551607UL,0x0E190A72L},{1UL,0x2A33BB26L,0xEF07237EL}},{{1UL,0x4944ACA2L,0x41F63C9DL},{0x18FBEA10L,0xF5A94F65L,0x56B34773L},{0x41F63C9DL,0xE8AE94B1L,0x18FBEA10L},{0xEFBDF533L,0x3408E740L,0x56B34773L},{18446744073709551607UL,0xD06EB5B9L,0x41F63C9DL},{0xEF07237EL,0x7FDC0A12L,0xEF07237EL},{18446744073709551612UL,0x7FDC0A12L,0x0E190A72L},{0x0E190A72L,0xD06EB5B9L,0xA40A7149L}},{{18446744073709551606UL,0x3408E740L,1UL},{18446744073709551615UL,0xE8AE94B1L,0x3760990AL},{18446744073709551606UL,0xF5A94F65L,18446744073709551613UL},{0x0E190A72L,1UL,0xCBFB8F77L},{18446744073709551615UL,0xEFBDF533L,0xCBFB8F77L},{8UL,0x40A04830L,18446744073709551615UL},{8UL,18446744073709551612UL,0x8BDD6CA2L},{0xB7DC81D0L,0x56B34773L,18446744073709551611UL}},{{5UL,18446744073709551612UL,0x1992C544L},{18446744073709551610UL,0x40A04830L,7UL},{18446744073709551611UL,0xEFBDF533L,8UL},{18446744073709551611UL,1UL,5UL},{18446744073709551610UL,18446744073709551613UL,0x631FDED0L},{5UL,18446744073709551607UL,18446744073709551610UL},{0xB7DC81D0L,18446744073709551615UL,0x631FDED0L},{8UL,18446744073709551614UL,5UL}}};
            const int64_t **l_1412 = (void*)0;
            const int64_t ***l_1411 = &l_1412;
            int32_t l_1416 = 0x455ECC19L;
            uint32_t l_1418 = 0x51379201L;
            int i, j, k;
        }
    }
    return l_1447;
}


/* ------------------------------------------ */
/* 
 * reads : g_885
 * writes: g_65
 */
static int32_t * func_14(int32_t * p_15, int8_t  p_16)
{ /* block id: 1 */
    uint32_t l_211 = 18446744073709551611UL;
    int32_t l_594[10] = {1L,0x2BCB8E8BL,1L,0x2BCB8E8BL,1L,0x2BCB8E8BL,1L,0x2BCB8E8BL,1L,0x2BCB8E8BL};
    uint16_t l_595 = 65526UL;
    int64_t l_647 = 9L;
    uint64_t *l_676 = &g_97;
    int16_t l_726 = 0xE131L;
    int i;
    for (p_16 = 0; (p_16 <= (-13)); p_16 = safe_sub_func_uint64_t_u_u(p_16, 8))
    { /* block id: 4 */
        int32_t **l_202 = &g_65;
        int64_t *l_208 = (void*)0;
        uint32_t l_209 = 18446744073709551615UL;
        uint64_t *l_210 = &g_97;
        uint8_t *l_212 = &g_213;
        int8_t l_573 = 0xF5L;
        int32_t l_585[8][5][6] = {{{0x952C97EAL,(-8L),(-7L),0x0691F056L,0x0691F056L,(-7L)},{0x79B009DDL,0x79B009DDL,0L,0x0691F056L,(-8L),8L},{0x952C97EAL,0xF8F7E176L,0L,0x55CB2507L,0x1FF979B8L,0L},{0x0691F056L,0x952C97EAL,0L,0x6A2F2393L,0x79B009DDL,8L},{7L,0x6A2F2393L,0L,0xF8F7E176L,0x6A2F2393L,(-7L)}},{{0xF8F7E176L,0x6A2F2393L,(-7L),0xF18A1EB4L,0x79B009DDL,0L},{0x1FF979B8L,0x952C97EAL,0x245B78F9L,0x952C97EAL,0x1FF979B8L,0xA32C1DE5L},{0x1FF979B8L,0xF8F7E176L,0L,0xF18A1EB4L,(-8L),0x53F8B12BL},{0xF8F7E176L,0x79B009DDL,0L,0xF8F7E176L,0x0691F056L,0x53F8B12BL},{7L,(-8L),0L,0x6A2F2393L,0xF18A1EB4L,0xA32C1DE5L}},{{0x0691F056L,0xB2E83BECL,0x245B78F9L,0x55CB2507L,0xF18A1EB4L,0L},{0x952C97EAL,(-8L),(-7L),0x0691F056L,0x0691F056L,(-7L)},{0x79B009DDL,0x79B009DDL,0L,0x0691F056L,(-8L),8L},{0x952C97EAL,0xF8F7E176L,0L,0x55CB2507L,0x1FF979B8L,0L},{0x0691F056L,0x952C97EAL,0L,0x6A2F2393L,0x79B009DDL,8L}},{{7L,0x6A2F2393L,0L,0xF8F7E176L,0x6A2F2393L,(-7L)},{0xF8F7E176L,0x6A2F2393L,(-7L),0xF18A1EB4L,0x79B009DDL,0L},{0x1FF979B8L,0x952C97EAL,0x245B78F9L,0x952C97EAL,0x1FF979B8L,0xA32C1DE5L},{0x1FF979B8L,0xF8F7E176L,0L,0xF18A1EB4L,(-8L),0x53F8B12BL},{0xF8F7E176L,0x79B009DDL,0L,0xF8F7E176L,0x0691F056L,0x53F8B12BL}},{{7L,(-8L),0L,0x6A2F2393L,0xF18A1EB4L,0xA32C1DE5L},{0x0691F056L,0xB2E83BECL,0x245B78F9L,0x55CB2507L,0xF18A1EB4L,0L},{0x952C97EAL,(-8L),(-7L),0x0691F056L,0x0691F056L,(-7L)},{0x79B009DDL,0x79B009DDL,0L,0x0691F056L,(-8L),0x952C97EAL},{0x71CEF091L,8L,7L,0xE4EBF25BL,0xA8B24D84L,0x79B009DDL}},{{1L,0x71CEF091L,7L,(-2L),0x0AA9BE3DL,0x952C97EAL},{(-1L),(-2L),0x79B009DDL,8L,(-2L),0x0691F056L},{8L,(-2L),0x0691F056L,(-4L),0x0AA9BE3DL,7L},{0xA8B24D84L,0x71CEF091L,0x6A2F2393L,0x71CEF091L,0xA8B24D84L,0xF8F7E176L},{0xA8B24D84L,8L,0xB2E83BECL,(-4L),9L,0x1FF979B8L}},{{8L,0x0AA9BE3DL,0x55CB2507L,8L,1L,0x1FF979B8L},{(-1L),9L,0xB2E83BECL,(-2L),(-4L),0xF8F7E176L},{1L,0xDB8AFC65L,0x6A2F2393L,0xE4EBF25BL,(-4L),7L},{0x71CEF091L,9L,0x0691F056L,1L,1L,0x0691F056L},{0x0AA9BE3DL,0x0AA9BE3DL,0x79B009DDL,1L,9L,0x952C97EAL}},{{0x71CEF091L,8L,7L,0xE4EBF25BL,0xA8B24D84L,0x79B009DDL},{1L,0x71CEF091L,7L,(-2L),0x0AA9BE3DL,0x952C97EAL},{(-1L),(-2L),0x79B009DDL,8L,(-2L),0x0691F056L},{8L,(-2L),0x0691F056L,(-4L),0x0AA9BE3DL,7L},{0xA8B24D84L,0x71CEF091L,0x6A2F2393L,0x71CEF091L,0xA8B24D84L,0xF8F7E176L}}};
        int16_t * const *l_617 = (void*)0;
        int16_t * const **l_616 = &l_617;
        int8_t *l_625 = &g_139;
        int8_t * const *l_624 = &l_625;
        int32_t l_635 = 1L;
        int32_t l_658 = 0x10B51106L;
        int64_t l_684[7][5] = {{1L,1L,0xF84963089D4AFA1ELL,0x701E7D02930D43CDLL,0xB5891EFA005138BELL},{1L,9L,0xB5891EFA005138BELL,0L,0L},{6L,0L,(-1L),(-3L),0L},{0xBF582D20D0B74E70LL,9L,9L,0xBF582D20D0B74E70LL,0xDCB9819E421607EBLL},{0x4D20A63F859B36DBLL,1L,9L,0xB5891EFA005138BELL,0L},{0xB5891EFA005138BELL,6L,(-1L),6L,9L},{0L,0x4D20A63F859B36DBLL,0xB5891EFA005138BELL,0xB5891EFA005138BELL,0x4D20A63F859B36DBLL}};
        int32_t *l_707 = &l_635;
        int32_t *l_708 = (void*)0;
        int32_t *l_709 = &l_594[5];
        int32_t *l_710 = &l_635;
        int32_t *l_711[7][5][5] = {{{&l_585[2][0][4],(void*)0,&l_585[6][0][1],&l_635,&l_594[6]},{(void*)0,&l_585[2][0][4],&g_706,&g_18,&l_594[6]},{&g_706,&g_706,&l_594[6],&g_706,&g_18},{(void*)0,&g_706,(void*)0,&g_18,(void*)0},{&l_585[2][0][4],&l_585[2][0][4],&l_594[6],&g_18,&l_658}},{{&g_706,(void*)0,&g_706,&g_706,(void*)0},{&g_706,&g_706,&l_585[6][0][1],&g_18,&g_18},{&l_585[2][0][4],(void*)0,&l_585[6][0][1],&l_635,&l_594[6]},{(void*)0,&l_585[2][0][4],&g_706,&g_18,&l_594[6]},{&g_706,&g_706,&l_594[6],&g_706,&g_18}},{{(void*)0,&g_706,(void*)0,&g_18,(void*)0},{&l_585[2][0][4],&l_585[2][0][4],&l_594[6],&g_18,&l_658},{&g_706,&g_18,&l_585[6][0][1],&l_594[0],(void*)0},{&g_706,&l_585[6][0][1],&l_594[8],&l_635,&g_18},{&l_658,&g_18,&l_594[8],&l_585[1][0][3],&l_658}},{{&g_18,&l_658,&l_585[6][0][1],&l_635,&l_658},{&l_585[6][0][1],&g_706,&l_658,&l_594[0],&g_18},{&g_18,&g_706,(void*)0,&g_18,(void*)0},{&l_658,&l_658,&l_658,&g_18,&l_658},{&g_706,&g_18,&l_585[6][0][1],&l_594[0],(void*)0}},{{&g_706,&l_585[6][0][1],&l_594[8],&l_635,&g_18},{&l_658,&g_18,&l_594[8],&l_585[1][0][3],&l_658},{&g_18,&l_658,&l_585[6][0][1],&l_635,&l_658},{&l_585[6][0][1],&g_706,&l_658,&l_594[0],&g_18},{&g_18,&g_706,(void*)0,&g_18,(void*)0}},{{&l_658,&l_658,&l_658,&g_18,&l_658},{&g_706,&g_18,&l_585[6][0][1],&l_594[0],(void*)0},{&g_706,&l_585[6][0][1],&l_594[8],&l_635,&g_18},{&l_658,&g_18,&l_594[8],&l_585[1][0][3],&l_658},{&g_18,&l_658,&l_585[6][0][1],&l_635,&l_658}},{{&l_585[6][0][1],&g_706,&l_658,&l_594[0],&g_18},{&g_18,&g_706,(void*)0,&g_18,(void*)0},{&l_658,&l_658,&l_658,&g_18,&l_658},{&g_706,&g_18,&l_585[6][0][1],&l_594[0],(void*)0},{&g_706,&l_585[6][0][1],&l_594[8],&l_635,&g_18}}};
        uint64_t l_712 = 0x95C5BA4B734B081FLL;
        uint16_t *l_721[9][5][5] = {{{&g_88,&g_88,&l_595,&l_595,&l_595},{&l_595,&g_88,&l_595,&l_595,&l_595},{&l_595,&g_88,&g_88,(void*)0,&l_595},{&g_88,&g_88,&g_88,&l_595,&g_88},{&g_88,&g_88,&g_88,&l_595,&g_88}},{{&g_88,&l_595,&l_595,&g_88,&l_595},{(void*)0,&l_595,&l_595,(void*)0,&l_595},{&l_595,&g_88,&l_595,(void*)0,&l_595},{&g_88,&g_88,&l_595,(void*)0,&g_88},{&l_595,&g_88,&l_595,&g_88,&l_595}},{{&l_595,(void*)0,&g_88,&l_595,&g_88},{&g_88,&l_595,(void*)0,&l_595,&g_88},{(void*)0,&g_88,&g_88,(void*)0,&g_88},{&l_595,&l_595,&l_595,&l_595,&l_595},{&g_88,&l_595,&l_595,&l_595,&l_595}},{{&g_88,&g_88,&l_595,(void*)0,&l_595},{&l_595,&l_595,&l_595,&g_88,&l_595},{&g_88,&g_88,(void*)0,&l_595,(void*)0},{&g_88,&g_88,&g_88,&l_595,&g_88},{&g_88,&g_88,&l_595,&g_88,&g_88}},{{&l_595,&l_595,&l_595,&g_88,&l_595},{&g_88,&g_88,&l_595,&l_595,&l_595},{&l_595,&g_88,&l_595,&l_595,&g_88},{&l_595,&g_88,&g_88,&l_595,(void*)0},{&l_595,&l_595,&g_88,&l_595,&g_88}},{{(void*)0,&g_88,&g_88,(void*)0,&l_595},{&l_595,&l_595,&l_595,&l_595,&g_88},{&l_595,&l_595,&l_595,(void*)0,&l_595},{&g_88,&l_595,&l_595,&l_595,&g_88},{&g_88,(void*)0,&l_595,(void*)0,&g_88}},{{&l_595,&l_595,&g_88,&l_595,&l_595},{&l_595,&l_595,(void*)0,(void*)0,&g_88},{&g_88,&g_88,&l_595,&l_595,&l_595},{&l_595,&g_88,&l_595,&l_595,&g_88},{&g_88,&l_595,&l_595,&l_595,&l_595}},{{&g_88,&l_595,&l_595,&l_595,&g_88},{&l_595,&g_88,&l_595,&g_88,&g_88},{(void*)0,&l_595,&g_88,&g_88,&l_595},{&l_595,&g_88,&g_88,&l_595,&g_88},{&g_88,&g_88,&g_88,&l_595,&l_595}},{{&g_88,&l_595,&l_595,&g_88,&g_88},{&l_595,(void*)0,&l_595,(void*)0,(void*)0},{&g_88,&l_595,&l_595,&g_88,&g_88},{&l_595,&g_88,&l_595,&l_595,&l_595},{&l_595,&g_88,&l_595,&l_595,&l_595}}};
        int16_t *l_727[5][6] = {{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95}};
        int8_t l_829 = 1L;
        int8_t l_877[5][1][2] = {{{0x42L,0x42L}},{{0xF5L,0x42L}},{{0x42L,0xF5L}},{{0x42L,0x42L}},{{0xF5L,0x42L}}};
        int i, j, k;
    }
    (*g_885) = p_15;
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_286 g_149 g_65 g_18 g_147
 * writes: g_95 g_18
 */
static int32_t  func_22(int16_t  p_23, int32_t  p_24, uint16_t  p_25, int16_t  p_26)
{ /* block id: 293 */
    uint64_t l_542 = 0xB16F6DAA739D2EB0LL;
    int8_t *l_549[6] = {&g_139,&g_139,&g_139,&g_139,&g_139,&g_139};
    int8_t **l_548 = &l_549[3];
    int8_t *l_550[10] = {&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139,&g_139};
    int8_t **l_551 = (void*)0;
    int8_t **l_552 = &l_550[0];
    int64_t *l_559 = &g_91[1];
    int64_t **l_558 = &l_559;
    int64_t ***l_557 = &l_558;
    int32_t l_560 = 0x5EF3E9B5L;
    int16_t *l_564 = &g_95;
    uint8_t * const l_565 = &g_213;
    int i;
    (**g_149) |= (safe_lshift_func_uint8_t_u_u(((l_542 & ((safe_add_func_int8_t_s_s(0L, (safe_sub_func_uint8_t_u_u((+(((*l_548) = (void*)0) != ((*l_552) = l_550[0]))), (safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_s((l_560 = ((l_557 = l_557) != &l_558)), 5)), 5)))))) == ((safe_mod_func_int16_t_s_s(((*l_564) = (safe_unary_minus_func_uint16_t_u(l_542))), l_542)) >= (l_565 == &g_213)))) == p_25), g_286[1]));
    return (**g_147);
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_65 g_18 g_241 g_160 g_97 g_139 g_75 g_103 g_91 g_50 g_283
 * writes: g_95 g_143 g_75 g_88
 */
static int32_t  func_27(int32_t * p_28, int32_t * const  p_29, uint8_t  p_30, int32_t  p_31, int16_t  p_32)
{ /* block id: 123 */
    int32_t *l_214 = (void*)0;
    int32_t *l_215[4][3] = {{&g_18,&g_18,&g_18},{(void*)0,(void*)0,(void*)0},{&g_18,&g_18,&g_18},{(void*)0,(void*)0,(void*)0}};
    uint32_t l_216 = 4294967294UL;
    int8_t l_247 = 0x8CL;
    uint32_t l_248 = 0xFAE0A805L;
    int64_t *l_262 = (void*)0;
    int64_t **l_331 = &l_262;
    int32_t l_413 = 7L;
    const uint32_t *l_474 = &g_50;
    const uint32_t **l_473[8];
    const uint32_t *** const l_472 = &l_473[0];
    uint16_t *l_480 = &g_88;
    uint16_t *l_493 = &g_88;
    uint16_t ** const l_492 = &l_493;
    int i, j;
    for (i = 0; i < 8; i++)
        l_473[i] = &l_474;
    l_216--;
    l_214 = &p_31;
    for (l_216 = (-26); (l_216 < 14); l_216++)
    { /* block id: 128 */
        uint8_t l_223 = 0x58L;
        int16_t *l_230 = &g_95;
        int8_t *l_244 = &g_143;
        int64_t *l_245 = &g_75;
        uint16_t *l_246 = &g_88;
        int16_t **l_250[2][2];
        int16_t ** const *l_249 = &l_250[0][0];
        uint64_t l_251 = 4UL;
        int64_t **l_263 = &l_245;
        int64_t *l_265 = &g_75;
        int64_t **l_264 = &l_265;
        int64_t *l_267[3];
        int64_t **l_266 = &l_267[1];
        int64_t *l_268[9] = {&g_91[3],&g_91[3],&g_91[3],&g_91[3],&g_91[3],&g_91[3],&g_91[3],&g_91[3],&g_91[3]};
        uint16_t *** const l_269 = (void*)0;
        int32_t l_274 = (-8L);
        int64_t l_275 = 0L;
        const int32_t *l_278 = &l_274;
        const int32_t * const *l_277 = &l_278;
        int32_t l_378 = (-8L);
        uint32_t l_384[2];
        int32_t l_414 = 5L;
        uint16_t l_450 = 65535UL;
        uint32_t **l_464 = &g_58[2];
        uint32_t *** const l_463 = &l_464;
        int32_t *l_503 = &l_274;
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
                l_250[i][j] = &l_230;
        }
        for (i = 0; i < 3; i++)
            l_267[i] = &g_75;
        for (i = 0; i < 2; i++)
            l_384[i] = 4294967286UL;
        l_251 ^= (9L >= (((((**g_64) || (-5L)) < (safe_rshift_func_int16_t_s_u(p_31, 9))) , (((l_223 ^ ((((safe_div_func_int32_t_s_s((safe_add_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((((*l_230) = p_32) & ((*l_246) = (safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((((*l_245) = (((safe_mod_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((g_241 != g_241), 3)), ((safe_rshift_func_int8_t_s_s((((((*l_244) = ((p_31 <= p_32) , g_160)) || g_97) , g_139) , 0x1BL), g_75)) , (*l_214)))), 8L)) ^ 65535UL) , g_103)) , p_30) <= g_91[1]), g_18)), g_50)))), (*g_65))), 18446744073709551613UL)), l_247)) , l_248) | 0x460BF5C7C5DD18EDLL) , 9L)) , l_249) != (void*)0)) != p_32));
    }
    return g_283;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_58 g_64 g_139 g_173 g_147 g_65 g_75 g_91
 * writes: g_50 g_65 g_18
 */
static int32_t * func_33(uint16_t  p_34)
{ /* block id: 5 */
    uint8_t l_43 = 0xEEL;
    int32_t *l_201[6] = {&g_18,&g_18,&g_18,&g_18,&g_18,&g_18};
    int i;
    for (p_34 = (-21); (p_34 <= 48); p_34++)
    { /* block id: 8 */
        int32_t *l_41 = &g_18;
        uint16_t *l_199[6] = {&g_88,&g_88,&g_88,&g_88,&g_88,&g_88};
        uint16_t **l_198 = &l_199[0];
        uint16_t ***l_200 = &l_198;
        int i;
        (*l_41) = (((9L & func_37(g_18, l_41, (safe_unary_minus_func_int8_t_s(l_43)))) != (safe_div_func_int16_t_s_s(g_18, (safe_mul_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u((g_18 || (((*l_200) = l_198) != (void*)0)), g_91[1])), g_91[1]))))) , 0x1E25E91BL);
        if (p_34)
            break;
    }
    return l_201[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_58 g_64 g_139 g_173 g_147 g_65 g_75
 * writes: g_50 g_65
 */
static int8_t  func_37(int32_t  p_38, int32_t * p_39, uint8_t  p_40)
{ /* block id: 9 */
    uint32_t *l_49 = &g_50;
    int32_t l_57[9][2] = {{(-10L),(-10L)},{0xF0E26A25L,4L},{0xE214356EL,4L},{0xF0E26A25L,(-10L)},{(-10L),0xF0E26A25L},{4L,0xE214356EL},{4L,0xF0E26A25L},{(-10L),(-10L)},{0xF0E26A25L,4L}};
    int32_t *l_191 = &l_57[6][1];
    int i, j;
    l_191 = func_44(((*l_49) = 0x2C512DC6L), ((-9L) == ((65526UL && func_51(((safe_unary_minus_func_uint8_t_u(((((((!(*p_39)) || g_18) , ((void*)0 == &p_38)) == 0xC4CE10B4L) ^ ((l_57[6][1] == l_57[6][1]) && (*p_39))) && g_18))) == p_38), &l_57[2][1], g_58[2])) | g_139)), g_173, &l_57[6][1]);
    return g_75;
}


/* ------------------------------------------ */
/* 
 * reads : g_147 g_65
 * writes: g_65
 */
static int32_t * const  func_44(uint32_t  p_45, int32_t  p_46, uint32_t  p_47, int32_t * p_48)
{ /* block id: 109 */
    int32_t **l_190 = &g_65;
    (*l_190) = (*g_147);
    (*l_190) = (void*)0;
    return (*l_190);
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_18
 * writes: g_65
 */
static int16_t  func_51(int8_t  p_52, int32_t * p_53, uint32_t * p_54)
{ /* block id: 11 */
    int32_t *l_59 = &g_18;
    int32_t *l_60[2][9][2] = {{{(void*)0,&g_18},{&g_18,(void*)0},{&g_18,(void*)0},{&g_18,&g_18},{(void*)0,(void*)0},{(void*)0,&g_18},{&g_18,(void*)0},{&g_18,(void*)0},{&g_18,&g_18}},{{(void*)0,(void*)0},{(void*)0,&g_18},{&g_18,(void*)0},{&g_18,(void*)0},{&g_18,&g_18},{(void*)0,(void*)0},{(void*)0,&g_18},{&g_18,(void*)0},{&g_18,(void*)0}}};
    uint32_t l_61 = 0xE46ED4D3L;
    uint32_t * const *l_76 = &g_58[1];
    uint64_t *l_169 = &g_97;
    uint16_t *l_178 = &g_88;
    int16_t *l_184 = &g_95;
    int16_t **l_183[10] = {&l_184,&l_184,&l_184,&l_184,&l_184,&l_184,&l_184,&l_184,&l_184,&l_184};
    int16_t ***l_182[4][3] = {{&l_183[9],&l_183[4],&l_183[4]},{&l_183[4],&l_183[9],(void*)0},{&l_183[9],&l_183[9],&l_183[9]},{(void*)0,&l_183[4],(void*)0}};
    int32_t **l_189 = &l_60[0][1][1];
    int i, j, k;
    l_61--;
    for (l_61 = 0; (l_61 <= 7); l_61 += 1)
    { /* block id: 15 */
        uint8_t l_66[9];
        int32_t l_99 = 0xB087A7CDL;
        uint32_t *l_113 = (void*)0;
        uint32_t **l_126 = &g_58[2];
        uint32_t *** const l_125 = &l_126;
        uint64_t *l_131 = &g_97;
        int32_t l_164 = 1L;
        int32_t l_165[3][10][8] = {{{0x03CA480CL,(-7L),0x75AC5E7AL,0x905622B1L,0x75AC5E7AL,(-7L),0x03CA480CL,3L},{(-6L),3L,0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L},{0x75AC5E7AL,0x508459D8L,(-6L),0x905622B1L,0xABBA4A27L,3L,0xABBA4A27L,0x905622B1L},{(-6L),0x508459D8L,(-6L),3L,0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L},{0x03CA480CL,3L,(-6L),3L,0x03CA480CL,(-7L),0x75AC5E7AL,0x905622B1L},{0x03CA480CL,(-7L),0x75AC5E7AL,0x905622B1L,0x75AC5E7AL,(-7L),0x03CA480CL,3L},{(-6L),3L,0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L},{0x75AC5E7AL,0x508459D8L,(-6L),0x905622B1L,0xABBA4A27L,3L,0xABBA4A27L,0x905622B1L},{(-6L),(-7L),(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L},{0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L,(-6L),0x508459D8L}},{{0x75AC5E7AL,3L,(-6L),0x508459D8L,(-6L),3L,0x75AC5E7AL,0x3164FAC5L},{(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L,(-6L),0x3164FAC5L},{(-6L),(-7L),0xABBA4A27L,0x508459D8L,0x03CA480CL,0x3164FAC5L,0x03CA480CL,0x508459D8L},{(-6L),(-7L),(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L},{0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L,(-6L),0x508459D8L},{0x75AC5E7AL,3L,(-6L),0x508459D8L,(-6L),3L,0x75AC5E7AL,0x3164FAC5L},{(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L,(-6L),0x3164FAC5L},{(-6L),(-7L),0xABBA4A27L,0x508459D8L,0x03CA480CL,0x3164FAC5L,0x03CA480CL,0x508459D8L},{(-6L),(-7L),(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L},{0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L,(-6L),0x508459D8L}},{{0x75AC5E7AL,3L,(-6L),0x508459D8L,(-6L),3L,0x75AC5E7AL,0x3164FAC5L},{(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L,(-6L),0x3164FAC5L},{(-6L),(-7L),0xABBA4A27L,0x508459D8L,0x03CA480CL,0x3164FAC5L,0x03CA480CL,0x508459D8L},{(-6L),(-7L),(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L},{0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L,(-6L),0x508459D8L},{0x75AC5E7AL,3L,(-6L),0x508459D8L,(-6L),3L,0x75AC5E7AL,0x3164FAC5L},{(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L,(-6L),0x3164FAC5L},{(-6L),(-7L),0xABBA4A27L,0x508459D8L,0x03CA480CL,0x3164FAC5L,0x03CA480CL,0x508459D8L},{(-6L),(-7L),(-6L),0x3164FAC5L,(-6L),0x905622B1L,0x03CA480CL,0x905622B1L},{0x75AC5E7AL,0x3164FAC5L,0xABBA4A27L,0x3164FAC5L,0x75AC5E7AL,3L,(-6L),0x508459D8L}}};
        uint64_t l_166 = 0x9F640BDDAC85E214LL;
        int32_t l_187[9][1][5] = {{{(-2L),(-2L),0xC4E39F24L,(-2L),(-2L)}},{{0xCAD36BB7L,1L,0xCAD36BB7L,0xCAD36BB7L,1L}},{{(-2L),0xE685B2B2L,0xE685B2B2L,(-2L),0xE685B2B2L}},{{1L,0xCAD36BB7L,1L,0xCAD36BB7L,0xCAD36BB7L}},{{0xC4E39F24L,0xE685B2B2L,0xC4E39F24L,0xC4E39F24L,0xE685B2B2L}},{{0xCAD36BB7L,(-1L),(-1L),0xCAD36BB7L,(-1L)}},{{0xE685B2B2L,0xE685B2B2L,(-2L),0xE685B2B2L,0xE685B2B2L}},{{(-1L),0xCAD36BB7L,(-1L),(-1L),0xCAD36BB7L}},{{0xE685B2B2L,0xC4E39F24L,0xC4E39F24L,0xE685B2B2L,0xC4E39F24L}}};
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_66[i] = 0UL;
        (*g_64) = &g_18;
        for (p_52 = 1; (p_52 <= 7); p_52 += 1)
        { /* block id: 19 */
            uint64_t l_69 = 2UL;
            int32_t l_89[1][6][1] = {{{0xD9D018D1L},{0xB567AB62L},{0xD9D018D1L},{0xB567AB62L},{0xD9D018D1L},{0xB567AB62L}}};
            int32_t l_96 = (-8L);
            int32_t * const l_129 = &l_89[0][0][0];
            uint32_t *l_171 = (void*)0;
            uint32_t *l_172 = &g_173;
            uint16_t **l_179 = &l_178;
            uint16_t *l_186 = &g_88;
            uint16_t **l_185 = &l_186;
            int64_t *l_188 = (void*)0;
            int i, j, k;
            l_66[2]++;
            l_69++;
        }
    }
    (*l_189) = (void*)0;
    return (*l_59);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_91[i], "g_91[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_281, "g_281", print_hash_value);
    transparent_crc(g_282, "g_282", print_hash_value);
    transparent_crc(g_283, "g_283", print_hash_value);
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_285, "g_285", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_286[i], "g_286[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_287, "g_287", print_hash_value);
    transparent_crc(g_288, "g_288", print_hash_value);
    transparent_crc(g_289, "g_289", print_hash_value);
    transparent_crc(g_290, "g_290", print_hash_value);
    transparent_crc(g_291, "g_291", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_292[i][j], "g_292[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_293, "g_293", print_hash_value);
    transparent_crc(g_294, "g_294", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_296[i][j], "g_296[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_297[i], "g_297[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_298, "g_298", print_hash_value);
    transparent_crc(g_299, "g_299", print_hash_value);
    transparent_crc(g_300, "g_300", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_301[i], "g_301[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_302, "g_302", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_303[i], "g_303[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_304[i][j], "g_304[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_305, "g_305", print_hash_value);
    transparent_crc(g_306, "g_306", print_hash_value);
    transparent_crc(g_661, "g_661", print_hash_value);
    transparent_crc(g_683, "g_683", print_hash_value);
    transparent_crc(g_706, "g_706", print_hash_value);
    transparent_crc(g_813, "g_813", print_hash_value);
    transparent_crc(g_826, "g_826", print_hash_value);
    transparent_crc(g_929, "g_929", print_hash_value);
    transparent_crc(g_1015, "g_1015", print_hash_value);
    transparent_crc(g_1018, "g_1018", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1020[i][j], "g_1020[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1027, "g_1027", print_hash_value);
    transparent_crc(g_1110, "g_1110", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1152[i], "g_1152[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1217[i][j][k], "g_1217[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1237, "g_1237", print_hash_value);
    transparent_crc(g_1323, "g_1323", print_hash_value);
    transparent_crc(g_1366, "g_1366", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_1387[i][j][k], "g_1387[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1415, "g_1415", print_hash_value);
    transparent_crc(g_1446, "g_1446", print_hash_value);
    transparent_crc(g_1455, "g_1455", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 348
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 40
breakdown:
   depth: 1, occurrence: 56
   depth: 2, occurrence: 15
   depth: 3, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 19, occurrence: 1
   depth: 21, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 1
   depth: 32, occurrence: 1
   depth: 38, occurrence: 1
   depth: 40, occurrence: 1

XXX total number of pointers: 315

XXX times a variable address is taken: 782
XXX times a pointer is dereferenced on RHS: 194
breakdown:
   depth: 1, occurrence: 129
   depth: 2, occurrence: 59
   depth: 3, occurrence: 6
XXX times a pointer is dereferenced on LHS: 218
breakdown:
   depth: 1, occurrence: 202
   depth: 2, occurrence: 13
   depth: 3, occurrence: 3
XXX times a pointer is compared with null: 38
XXX times a pointer is compared with address of another variable: 13
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 5203

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 811
   level: 2, occurrence: 163
   level: 3, occurrence: 23
XXX number of pointers point to pointers: 129
XXX number of pointers point to scalars: 186
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.9
XXX average alias set size: 1.52

XXX times a non-volatile is read: 1203
XXX times a non-volatile is write: 613
XXX times a volatile is read: 76
XXX    times read thru a pointer: 15
XXX times a volatile is write: 17
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2.04e+03
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 58
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 11
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 6

XXX percentage a fresh-made variable is used: 15.8
XXX percentage an existing variable is used: 84.2
********************* end of statistics **********************/

