/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      809372761
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[1] = {0x0648261FL};
static volatile int32_t g_3 = (-9L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 0x9BE1D925L;
static volatile uint32_t g_45 = 18446744073709551615UL;/* VOLATILE GLOBAL g_45 */
static uint32_t g_46 = 4294967295UL;
static int32_t *g_80 = &g_4;
static int32_t **g_79 = &g_80;
static int16_t g_83 = 0x7F2FL;
static const int32_t *g_86 = &g_4;
static const int32_t **g_85 = &g_86;
static int32_t g_88 = 0x7F3A40B1L;
static int32_t g_100 = (-10L);
static int32_t g_103 = 8L;
static int64_t g_104[3] = {(-5L),(-5L),(-5L)};
static int32_t g_105 = (-7L);
static int16_t g_106 = (-1L);
static int8_t g_107[4] = {6L,6L,6L,6L};
static uint32_t g_108 = 18446744073709551615UL;
static int8_t g_112[10][4] = {{(-10L),(-2L),0x36L,0x2FL},{0x2FL,(-2L),(-2L),0x2FL},{(-10L),(-2L),0x36L,0x2FL},{0x2FL,(-2L),(-2L),0x2FL},{(-10L),(-2L),0x36L,0x2FL},{0x2FL,(-2L),(-2L),0x2FL},{(-10L),(-2L),0x36L,0x2FL},{0x2FL,(-2L),(-2L),0x2FL},{(-10L),(-2L),0x36L,0x2FL},{0x2FL,(-2L),(-2L),0x2FL}};
static int32_t *g_168 = (void*)0;
static uint64_t g_178[4][3] = {{0x40892B95AF383A4ALL,18446744073709551615UL,0x40892B95AF383A4ALL},{18446744073709551607UL,18446744073709551607UL,1UL},{18446744073709551607UL,18446744073709551607UL,18446744073709551607UL},{0x40892B95AF383A4ALL,18446744073709551607UL,18446744073709551607UL}};
static uint16_t g_194 = 5UL;
static int32_t g_267 = (-5L);
static uint8_t g_279[10][8] = {{0xBDL,5UL,5UL,0xBDL,255UL,254UL,0x10L,0x9FL},{0x85L,255UL,255UL,0x00L,9UL,0xCBL,248UL,250UL},{0xBBL,255UL,250UL,0xADL,0xB7L,254UL,1UL,5UL},{1UL,5UL,254UL,0x9EL,0x00L,0xBBL,0x00L,0x9EL},{1UL,254UL,1UL,0x12L,247UL,0x10L,255UL,1UL},{0xD8L,0x34L,0x9EL,0x9FL,254UL,248UL,247UL,0xADL},{0xD8L,0x1DL,254UL,0x85L,247UL,1UL,0x9FL,0xD8L},{1UL,9UL,252UL,0x1DL,0x00L,0x00L,0x1DL,252UL},{1UL,1UL,0xCBL,0xBBL,0xB7L,255UL,0x12L,0x10L},{0xBBL,0x85L,0xBDL,250UL,9UL,247UL,5UL,0x10L}};
static volatile int32_t g_288 = 1L;/* VOLATILE GLOBAL g_288 */
static volatile int32_t *g_287[10][2][5] = {{{&g_288,(void*)0,&g_288,&g_288,&g_288},{&g_288,&g_288,&g_288,&g_288,(void*)0}},{{&g_288,(void*)0,&g_288,&g_288,(void*)0},{&g_288,(void*)0,&g_288,&g_288,&g_288}},{{&g_288,(void*)0,&g_288,&g_288,&g_288},{&g_288,&g_288,&g_288,&g_288,&g_288}},{{&g_288,(void*)0,&g_288,&g_288,&g_288},{&g_288,&g_288,&g_288,&g_288,&g_288}},{{&g_288,&g_288,&g_288,&g_288,&g_288},{&g_288,(void*)0,&g_288,&g_288,&g_288}},{{&g_288,&g_288,&g_288,&g_288,(void*)0},{&g_288,(void*)0,&g_288,&g_288,(void*)0}},{{&g_288,(void*)0,&g_288,&g_288,&g_288},{&g_288,(void*)0,&g_288,&g_288,&g_288}},{{&g_288,&g_288,&g_288,&g_288,&g_288},{&g_288,(void*)0,&g_288,&g_288,&g_288}},{{&g_288,&g_288,&g_288,&g_288,&g_288},{&g_288,&g_288,&g_288,&g_288,&g_288}},{{&g_288,(void*)0,&g_288,&g_288,&g_288},{&g_288,&g_288,&g_288,(void*)0,(void*)0}}};
static volatile int32_t ** volatile g_286 = &g_287[3][0][0];/* VOLATILE GLOBAL g_286 */
static volatile int32_t ** volatile *g_285 = &g_286;
static int16_t g_290 = (-3L);
static uint16_t g_339 = 0x4E48L;
static uint16_t g_341[1][5] = {{0x388BL,0x388BL,0x388BL,0x388BL,0x388BL}};
static uint64_t g_393 = 0x2C70A36683586776LL;
static int32_t g_461 = 0x0E9B67A1L;
static const int32_t * const *g_466 = (void*)0;
static volatile int64_t g_520 = 0x468506E850736A8BLL;/* VOLATILE GLOBAL g_520 */
static uint32_t g_528 = 0xF7E1F3F5L;
static const uint64_t * volatile g_559 = (void*)0;/* VOLATILE GLOBAL g_559 */
static const uint64_t * volatile *g_558[2][2] = {{&g_559,&g_559},{&g_559,&g_559}};
static int32_t **g_569 = &g_168;
static int32_t ***g_568 = &g_569;
static volatile int64_t g_596 = 0x20D8DD8D36EE9CE8LL;/* VOLATILE GLOBAL g_596 */
static uint32_t g_727 = 4294967295UL;
static int32_t g_739 = 0x864DE413L;
static const int64_t g_756 = 0x94E3466B427F6B71LL;
static int8_t *g_828 = (void*)0;
static int16_t *g_871 = &g_290;
static int16_t **g_870[7][3] = {{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871},{&g_871,&g_871,&g_871}};
static uint8_t *** volatile g_891 = (void*)0;/* VOLATILE GLOBAL g_891 */
static uint8_t *** volatile g_892 = (void*)0;/* VOLATILE GLOBAL g_892 */
static uint8_t *g_895 = &g_279[8][2];
static uint8_t **g_894 = &g_895;
static uint8_t *** volatile g_893 = &g_894;/* VOLATILE GLOBAL g_893 */
static uint32_t *g_901[3] = {&g_727,&g_727,&g_727};
static uint32_t * volatile * volatile g_900 = &g_901[2];/* VOLATILE GLOBAL g_900 */
static const int32_t g_955 = (-1L);
static int32_t * const  volatile g_956 = &g_88;/* VOLATILE GLOBAL g_956 */
static volatile int8_t g_975 = 0L;/* VOLATILE GLOBAL g_975 */
static uint64_t g_977 = 0xDB5D86A5C1400692LL;
static int8_t g_1025 = (-1L);
static int32_t g_1055 = 4L;
static uint64_t **g_1231 = (void*)0;
static uint32_t **g_1274 = (void*)0;
static uint32_t ***g_1273 = &g_1274;
static uint16_t *g_1295 = (void*)0;
static volatile int32_t *g_1329 = &g_2[0];
static volatile int32_t ** volatile g_1328 = &g_1329;/* VOLATILE GLOBAL g_1328 */
static int32_t * volatile g_1396 = &g_461;/* VOLATILE GLOBAL g_1396 */
static int32_t g_1433[1] = {0L};
static const uint8_t g_1567 = 9UL;
static uint16_t **g_1686 = &g_1295;
static volatile int32_t * volatile * volatile g_1845 = &g_287[3][0][0];/* VOLATILE GLOBAL g_1845 */
static volatile int32_t * volatile * const  volatile *g_1844 = &g_1845;
static volatile int32_t * volatile * const  volatile ** volatile g_1843 = &g_1844;/* VOLATILE GLOBAL g_1843 */
static volatile int32_t * volatile * const  volatile ** volatile *g_1842 = &g_1843;
static uint8_t g_1847 = 0x4EL;
static const int32_t g_1908 = (-9L);
static int16_t ***g_1982 = &g_870[3][1];
static uint32_t g_1997 = 18446744073709551615UL;
static uint32_t g_2030 = 18446744073709551613UL;
static uint32_t *g_2132 = &g_1997;
static uint32_t **g_2131 = &g_2132;
static uint32_t *** volatile g_2130 = &g_2131;/* VOLATILE GLOBAL g_2130 */
static int32_t g_2163[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
static uint32_t g_2200[9][8][3] = {{{0x2B0F229BL,0x18014BE1L,1UL},{0xC2EB8277L,1UL,0xF2D2A5BFL},{1UL,0x2B0F229BL,1UL},{3UL,4294967295UL,0x1DC05AB7L},{8UL,4294967295UL,1UL},{1UL,0x2B0F229BL,0x952736A7L},{0xA22CA4C4L,1UL,1UL},{1UL,0x18014BE1L,0xC2EB8277L}},{{8UL,0xF2D2A5BFL,0xC2EB8277L},{3UL,0xC2EB8277L,1UL},{1UL,1UL,0x952736A7L},{0xC2EB8277L,0xC2EB8277L,1UL},{0x2B0F229BL,0xF2D2A5BFL,0x1DC05AB7L},{0x2B0F229BL,0x18014BE1L,1UL},{0xC2EB8277L,1UL,0xF2D2A5BFL},{1UL,0x2B0F229BL,1UL}},{{3UL,4294967295UL,0x1DC05AB7L},{8UL,4294967295UL,1UL},{1UL,0x2B0F229BL,0x952736A7L},{0xA22CA4C4L,1UL,1UL},{1UL,0x18014BE1L,0xC2EB8277L},{8UL,0xF2D2A5BFL,0xC2EB8277L},{3UL,0xC2EB8277L,1UL},{1UL,1UL,0x952736A7L}},{{0xC2EB8277L,0xC2EB8277L,1UL},{0x2B0F229BL,0xF2D2A5BFL,0x1DC05AB7L},{0x2B0F229BL,0x18014BE1L,1UL},{0xC2EB8277L,1UL,0xF2D2A5BFL},{1UL,0x2B0F229BL,1UL},{3UL,4294967295UL,0x1DC05AB7L},{8UL,4294967295UL,1UL},{1UL,0x2B0F229BL,0x952736A7L}},{{0xA22CA4C4L,1UL,1UL},{1UL,0x18014BE1L,0xC2EB8277L},{8UL,0xF2D2A5BFL,0xC2EB8277L},{3UL,0xC2EB8277L,1UL},{1UL,1UL,0x952736A7L},{0xC2EB8277L,0xC2EB8277L,1UL},{0x2B0F229BL,0xF2D2A5BFL,0x1DC05AB7L},{0x2B0F229BL,0x18014BE1L,1UL}},{{0xC2EB8277L,1UL,0xF2D2A5BFL},{1UL,0x2B0F229BL,1UL},{3UL,4294967295UL,0x1DC05AB7L},{8UL,4294967295UL,1UL},{1UL,0x2B0F229BL,0x952736A7L},{0xA22CA4C4L,1UL,1UL},{1UL,0x18014BE1L,0xC2EB8277L},{8UL,0xF2D2A5BFL,1UL}},{{4294967295UL,1UL,0xA22CA4C4L},{0xF2D2A5BFL,0x2B0F229BL,8UL},{1UL,1UL,0x2B0F229BL},{3UL,1UL,0x952736A7L},{3UL,0x1DC05AB7L,0xF2D2A5BFL},{1UL,0xA22CA4C4L,1UL},{0xF2D2A5BFL,3UL,0xF2D2A5BFL},{4294967295UL,0x18014BE1L,0x952736A7L}},{{1UL,0x18014BE1L,0x2B0F229BL},{0xA22CA4C4L,3UL,8UL},{0xC2EB8277L,0xA22CA4C4L,0xA22CA4C4L},{0xA22CA4C4L,0x1DC05AB7L,1UL},{1UL,1UL,1UL},{4294967295UL,1UL,0xA22CA4C4L},{0xF2D2A5BFL,0x2B0F229BL,8UL},{1UL,1UL,0x2B0F229BL}},{{3UL,1UL,0x952736A7L},{3UL,0x1DC05AB7L,0xF2D2A5BFL},{1UL,0xA22CA4C4L,1UL},{0xF2D2A5BFL,3UL,0xF2D2A5BFL},{4294967295UL,0x18014BE1L,0x952736A7L},{1UL,0x18014BE1L,0x2B0F229BL},{0xA22CA4C4L,3UL,8UL},{0xC2EB8277L,0xA22CA4C4L,0xA22CA4C4L}}};
static int16_t g_2321 = 0x1094L;
static volatile int32_t ** volatile g_2436[10][10][2] = {{{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0}},{{&g_1329,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0}},{{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329}},{{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329}},{{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329}},{{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{(void*)0,&g_1329},{&g_1329,(void*)0},{(void*)0,&g_1329}},{{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329}},{{(void*)0,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329}},{{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329}},{{(void*)0,&g_1329},{&g_1329,&g_1329},{(void*)0,&g_1329},{(void*)0,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329},{&g_1329,&g_1329},{&g_1329,(void*)0},{&g_1329,&g_1329}}};
static const uint8_t **g_2452 = (void*)0;
static const uint8_t ***g_2451 = &g_2452;
static const uint8_t ****g_2450 = &g_2451;
static int64_t g_2487 = 0x44CAB2CF204F4FA2LL;
static int16_t g_2497 = 8L;
static const int32_t g_2532[10] = {0xF3AC2458L,8L,0x48598CB1L,0x48598CB1L,8L,0xF3AC2458L,8L,0x48598CB1L,0x48598CB1L,8L};
static const int32_t g_2534 = 0L;
static const int32_t *g_2533 = &g_2534;
static int32_t ****g_2554[9][8][3] = {{{&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,(void*)0},{(void*)0,&g_568,&g_568}},{{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568}},{{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568}},{{&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568}},{{&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568}},{{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568}},{{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568},{&g_568,&g_568,(void*)0},{&g_568,(void*)0,&g_568},{&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568}},{{&g_568,&g_568,(void*)0},{&g_568,&g_568,(void*)0},{&g_568,&g_568,(void*)0},{&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,(void*)0,&g_568}},{{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568}}};
static int32_t *****g_2553 = &g_2554[6][7][0];
static uint32_t g_2582 = 0x16B300ABL;
static uint8_t *** const *g_2647 = (void*)0;
static uint8_t *** const * const *g_2646 = &g_2647;
static volatile int16_t g_2725 = 0x1C42L;/* VOLATILE GLOBAL g_2725 */
static int32_t g_2826 = 0x94A1862AL;
static volatile int32_t g_2837 = (-5L);/* VOLATILE GLOBAL g_2837 */
static int32_t *****g_2891 = &g_2554[2][6][1];
static uint16_t g_2905 = 65534UL;
static volatile int32_t g_2940 = 0x648F037CL;/* VOLATILE GLOBAL g_2940 */
static const uint32_t *g_2948 = &g_108;
static const uint32_t **g_2947[4][5][3] = {{{(void*)0,&g_2948,(void*)0},{(void*)0,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,&g_2948}},{{&g_2948,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,(void*)0},{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,(void*)0}},{{(void*)0,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,&g_2948},{&g_2948,&g_2948,&g_2948}},{{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,(void*)0},{&g_2948,&g_2948,&g_2948},{(void*)0,&g_2948,(void*)0},{(void*)0,&g_2948,&g_2948}}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_13(int8_t  p_14, int8_t  p_15, int64_t  p_16, int64_t  p_17);
static uint32_t  func_23(uint64_t  p_24, int16_t  p_25, int64_t  p_26, int16_t  p_27);
static int32_t * func_38(const int32_t * p_39, uint32_t  p_40);
static int64_t  func_52(const int32_t ** p_53, uint32_t  p_54, uint16_t  p_55, uint32_t  p_56);
static const int32_t ** func_57(int32_t * const  p_58, uint32_t  p_59, int16_t  p_60);
static int32_t ** func_131(uint16_t  p_132, uint64_t  p_133, int16_t * p_134, int32_t ** p_135, uint32_t  p_136);
static int32_t ** func_139(int32_t  p_140);
static int16_t  func_145(int32_t * p_146, int16_t * p_147);
static int32_t  func_156(int32_t  p_157, uint64_t  p_158, int32_t ** const  p_159, int32_t ** p_160);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_2 g_45 g_79 g_80 g_85 g_108 g_88 g_100 g_112 g_103 g_107 g_104 g_2200 g_1982 g_870 g_2532 g_894 g_895 g_279 g_871 g_2321 g_393 g_2905 g_46 g_739 g_341 g_893 g_1396 g_461 g_86 g_2948
 * writes: g_4 g_46 g_83 g_80 g_108 g_103 g_100 g_105 g_88 g_2553 g_2891 g_290 g_2321 g_86 g_267 g_828 g_112
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_30[1];
    int32_t **** const *l_2889[7][2] = {{&g_2554[6][7][0],(void*)0},{&g_2554[6][7][0],&g_2554[6][2][0]},{(void*)0,&g_2554[6][2][0]},{&g_2554[6][7][0],(void*)0},{&g_2554[6][7][0],&g_2554[6][7][0]},{&g_2554[6][7][0],(void*)0},{&g_2554[6][7][0],&g_2554[6][2][0]}};
    int32_t l_2910 = (-1L);
    int32_t l_2911[3][5][6] = {{{(-8L),0x0C18D08AL,0x575182B5L,0x0C18D08AL,(-8L),0L},{0x0C18D08AL,(-8L),0L,0x9F10E683L,(-8L),0x808E42CAL},{0xD5DE27D3L,0x0C18D08AL,(-7L),(-8L),1L,0x808E42CAL},{1L,0xD5DE27D3L,0L,(-2L),(-2L),0L},{1L,1L,0x575182B5L,(-8L),0L,0x9EA735C4L}},{{0xD5DE27D3L,1L,0x11C9789CL,0x9F10E683L,(-2L),0x575182B5L},{0x0C18D08AL,0xD5DE27D3L,0x11C9789CL,0x0C18D08AL,1L,0x9EA735C4L},{(-8L),0x0C18D08AL,0x575182B5L,0x0C18D08AL,(-8L),0L},{0x0C18D08AL,(-8L),0L,0x9F10E683L,(-8L),0x808E42CAL},{0xD5DE27D3L,0x0C18D08AL,(-7L),(-8L),1L,0x808E42CAL}},{{1L,0xD5DE27D3L,0L,(-2L),(-2L),0L},{1L,1L,0x575182B5L,(-8L),0L,0x9EA735C4L},{0xD5DE27D3L,1L,0x11C9789CL,0x9F10E683L,(-2L),0x575182B5L},{0x0C18D08AL,0xD5DE27D3L,0x11C9789CL,0x0C18D08AL,1L,0x9EA735C4L},{(-8L),0x0C18D08AL,0x575182B5L,0x0C18D08AL,(-8L),0L}}};
    uint64_t l_2958 = 0xE7717169ADE4D2FDLL;
    uint16_t l_3034 = 0x7579L;
    uint16_t l_3127 = 1UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_30[i] = 0UL;
    for (g_4 = 0; (g_4 < (-14)); g_4--)
    { /* block id: 3 */
        int64_t l_18[6][2];
        int16_t l_20 = 0x2DB8L;
        int32_t *l_2877 = &g_88;
        int32_t l_2908 = 0L;
        int16_t l_2912 = 2L;
        int32_t l_2913 = 0x2CB11DD5L;
        uint64_t l_2914 = 18446744073709551615UL;
        const uint32_t *l_2946 = &l_30[0];
        const uint32_t **l_2945 = &l_2946;
        int64_t l_2996 = (-1L);
        uint8_t l_3107 = 1UL;
        int i, j;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 2; j++)
                l_18[i][j] = (-6L);
        }
        if (((safe_add_func_int32_t_s_s(((*l_2877) = (safe_rshift_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(func_13(g_2[0], l_18[5][0], (~((l_18[5][0] , l_20) > g_4)), (safe_add_func_uint32_t_u_u(func_23(l_20, l_18[5][0], (((safe_mul_func_int8_t_s_s((l_30[0] >= (safe_lshift_func_uint8_t_u_s(((safe_lshift_func_int8_t_s_u(((safe_add_func_int16_t_s_s((!0xE3D1AA12AFD77CCCLL), g_4)) & l_30[0]), g_4)) == g_4), l_18[3][0]))), (-1L))) && 0x7276L) , 0xB752BF390F3BD791LL), g_4), (-7L)))), g_2200[8][0][0])), l_18[0][1]))), 9UL)) & 18446744073709551614UL))
        { /* block id: 1414 */
            int32_t ******l_2890[9][4][7] = {{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}},{{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553},{&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553,&g_2553}}};
            uint8_t *l_2902[10] = {&g_279[8][2],&g_279[8][2],&g_1847,&g_279[8][2],&g_279[8][2],&g_1847,&g_279[8][2],&g_279[8][2],&g_1847,&g_279[8][2]};
            int32_t l_2903 = 0xDA276BBBL;
            int32_t l_2904[5][2][7] = {{{0x3356297BL,0x814DFB9FL,0L,(-10L),0x0D693A94L,0x0D693A94L,(-10L)},{0L,0xF76D70DDL,0L,(-1L),1L,0x0D693A94L,(-1L)}},{{0x3356297BL,0xF76D70DDL,0x4172AF5EL,(-10L),1L,(-10L),(-10L)},{0x3356297BL,0x814DFB9FL,0L,(-10L),0x0D693A94L,0x0D693A94L,(-10L)}},{{0L,0x49ABD0C0L,0L,(-10L),0x814DFB9FL,0L,(-10L)},{(-1L),0x49ABD0C0L,0xE998F30EL,0x0D693A94L,0x814DFB9FL,0xF76D70DDL,0x0D693A94L}},{{(-1L),0L,0L,0x0D693A94L,0L,0L,0x0D693A94L},{0L,0x49ABD0C0L,0L,(-10L),0x814DFB9FL,0L,(-10L)}},{{(-1L),0x49ABD0C0L,0xE998F30EL,0x0D693A94L,0x814DFB9FL,0xF76D70DDL,0x0D693A94L},{(-1L),0L,0L,0x0D693A94L,0L,0L,0x0D693A94L}}};
            int16_t *l_2906 = &g_2321;
            int16_t l_2907 = (-4L);
            int32_t *l_2909[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int16_t l_2944 = 0x505BL;
            uint32_t l_3002 = 4294967293UL;
            uint64_t l_3026 = 0x4EFD0CFD83286408LL;
            const uint64_t l_3064 = 0x2CBC90C4842D7277LL;
            const int16_t *l_3103[8] = {&g_2321,&g_2321,&g_2321,&g_2321,&g_2321,&g_2321,&g_2321,&g_2321};
            const int16_t **l_3102 = &l_3103[5];
            const int16_t ***l_3101[8];
            int i, j, k;
            for (i = 0; i < 8; i++)
                l_3101[i] = &l_3102;
            (*g_85) = func_38((*g_79), (safe_sub_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(((*l_2906) = (safe_add_func_int32_t_s_s((l_30[0] < (safe_lshift_func_uint16_t_u_s(((((safe_rshift_func_uint16_t_u_s((+(l_2889[0][1] != (g_2891 = (g_2553 = &g_2554[6][7][0])))), 3)) , (safe_rshift_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(((((((safe_lshift_func_uint8_t_u_s(((*g_1982) == (g_2532[6] , (*g_1982))), (((((safe_sub_func_int16_t_s_s(((*g_871) = (safe_add_func_uint8_t_u_u((l_2903 &= (**g_894)), ((-1L) ^ 0L)))), (*l_2877))) , 0x478CL) >= l_2904[4][0][1]) >= g_2321) , g_393))) , l_2903) == l_30[0]) && l_2904[4][0][4]) & 0L) >= 0UL), 11)) && (-1L)), 12))) <= l_2904[3][1][2]) , l_30[0]), g_2905))), (*l_2877)))), l_2907)), 0x87L)));
            ++l_2914;
            for (l_2903 = 0; (l_2903 == 13); ++l_2903)
            { /* block id: 1424 */
                int32_t l_2939 = 0x755C2AE4L;
                int32_t l_2998 = 1L;
                int32_t l_3001 = 0x3AC9FF34L;
                uint32_t l_3007 = 0UL;
                const int32_t *l_3033 = (void*)0;
                const int32_t **l_3032 = &l_3033;
                const int32_t ** const *l_3031 = &l_3032;
                const int32_t ** const **l_3030 = &l_3031;
                uint8_t ***l_3058[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_3058[i] = &g_894;
            }
            for (g_267 = 0; (g_267 == (-2)); g_267 = safe_sub_func_uint64_t_u_u(g_267, 4))
            { /* block id: 1480 */
                uint32_t l_3105[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_3105[i] = 18446744073709551610UL;
                for (g_100 = (-29); (g_100 >= 1); g_100 = safe_add_func_uint64_t_u_u(g_100, 4))
                { /* block id: 1483 */
                    uint8_t l_3087 = 254UL;
                    uint8_t ***l_3090 = &g_894;
                    (*g_79) = func_38(&l_2904[4][0][1], (0x0D634F68241A5A2ELL == ((l_3087 , (&g_2554[6][7][0] != (void*)0)) > (((safe_rshift_func_uint8_t_u_s((l_3090 != (void*)0), ((*l_2877) = ((l_3090 == (void*)0) , 1L)))) , l_2958) || l_3087))));
                    for (g_46 = 0; (g_46 <= 2); g_46 += 1)
                    { /* block id: 1488 */
                        int8_t **l_3092 = (void*)0;
                        int8_t **l_3093 = &g_828;
                        int32_t l_3094[5] = {1L,1L,1L,1L,1L};
                        const int16_t ****l_3104 = &l_3101[5];
                        int8_t *l_3106[6][10][4] = {{{&g_107[2],&g_1025,&g_112[4][1],(void*)0},{(void*)0,&g_107[2],(void*)0,&g_1025},{&g_107[2],&g_112[6][1],(void*)0,&g_112[6][1]},{(void*)0,&g_1025,&g_112[4][1],&g_107[2]},{&g_107[2],&g_112[6][1],(void*)0,&g_107[2]},{(void*)0,&g_107[2],(void*)0,&g_1025},{&g_107[3],(void*)0,&g_112[1][2],(void*)0},{&g_107[2],&g_112[6][1],&g_112[6][1],&g_112[6][1]},{(void*)0,&g_112[7][1],&g_107[2],(void*)0},{&g_107[2],&g_112[6][1],&g_112[6][1],&g_112[4][1]}},{{&g_107[2],&g_112[6][1],(void*)0,(void*)0},{&g_112[1][0],(void*)0,&g_1025,&g_1025},{&g_112[4][1],&g_1025,(void*)0,&g_112[0][3]},{&g_107[2],&g_112[8][1],&g_1025,(void*)0},{&g_107[2],&g_1025,&g_107[2],&g_112[6][1]},{&g_107[2],(void*)0,&g_107[2],&g_1025},{(void*)0,&g_112[5][3],&g_112[1][2],&g_112[6][3]},{&g_107[2],&g_107[2],&g_1025,(void*)0},{&g_112[2][1],&g_107[3],&g_107[2],(void*)0},{&g_107[2],&g_1025,&g_107[2],(void*)0}},{{&g_1025,&g_107[2],&g_112[6][1],&g_112[6][1]},{&g_112[7][1],(void*)0,(void*)0,&g_112[5][3]},{&g_112[6][3],&g_112[6][1],&g_107[2],&g_107[2]},{&g_112[1][0],&g_112[1][0],&g_107[2],(void*)0},{(void*)0,&g_112[6][1],&g_112[6][1],&g_107[2]},{&g_1025,(void*)0,&g_112[6][0],&g_112[6][1]},{(void*)0,(void*)0,&g_112[6][1],&g_107[2]},{(void*)0,&g_112[6][1],(void*)0,(void*)0},{(void*)0,&g_112[1][0],&g_1025,&g_107[2]},{&g_107[2],&g_112[6][1],&g_107[2],&g_112[5][3]}},{{&g_107[2],(void*)0,(void*)0,&g_112[6][1]},{&g_112[1][0],&g_107[2],(void*)0,(void*)0},{&g_107[2],&g_1025,&g_112[6][1],&g_1025},{(void*)0,(void*)0,(void*)0,&g_112[3][2]},{(void*)0,&g_112[6][1],&g_112[6][1],(void*)0},{&g_107[0],&g_112[1][3],&g_107[2],(void*)0},{(void*)0,&g_112[6][1],&g_112[6][1],&g_107[2]},{&g_107[2],&g_107[2],&g_112[4][2],&g_1025},{&g_107[2],&g_112[6][0],&g_107[2],(void*)0},{(void*)0,(void*)0,&g_107[2],&g_107[2]}},{{(void*)0,&g_1025,&g_107[2],&g_112[6][1]},{&g_112[6][1],(void*)0,(void*)0,&g_107[2]},{&g_107[2],(void*)0,&g_112[4][2],&g_1025},{&g_112[6][1],&g_1025,&g_107[2],&g_112[6][1]},{(void*)0,&g_112[7][1],&g_107[1],&g_107[2]},{&g_107[0],&g_1025,&g_1025,(void*)0},{&g_107[2],&g_112[6][1],&g_1025,&g_112[6][1]},{(void*)0,(void*)0,&g_112[6][1],(void*)0},{&g_107[2],&g_112[5][3],&g_1025,(void*)0},{(void*)0,(void*)0,(void*)0,&g_107[2]}},{{(void*)0,&g_107[2],&g_1025,&g_1025},{&g_107[2],&g_107[2],&g_112[6][1],(void*)0},{(void*)0,&g_107[2],&g_1025,&g_112[3][2]},{&g_107[2],(void*)0,&g_1025,&g_112[6][1]},{&g_107[0],(void*)0,&g_107[1],(void*)0},{(void*)0,&g_112[6][1],&g_107[2],&g_107[2]},{&g_112[6][1],&g_107[2],&g_112[4][2],(void*)0},{&g_107[2],&g_112[1][0],(void*)0,(void*)0},{&g_112[6][1],&g_112[6][1],&g_107[2],&g_112[6][1]},{(void*)0,(void*)0,&g_107[2],&g_112[1][3]}}};
                        int i, j, k;
                        l_2908 &= ((*l_2877) = (safe_unary_minus_func_uint32_t_u(((((((*l_3093) = &g_112[8][1]) == (((0xB05D5398L ^ (l_3094[3] = g_2200[(g_46 + 1)][(g_46 + 5)][g_46])) , (*l_2877)) , (((((g_112[3][1] = (safe_mul_func_uint8_t_u_u(((((1L || (safe_add_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((g_739 <= ((((*l_3104) = l_3101[4]) == ((*l_2877) , &g_870[0][0])) & 1L)), g_341[0][0])), 1L))) <= (***g_893)) >= l_3087) & l_3105[0]), g_2200[7][6][1]))) <= l_3105[0]) , (*g_1396)) | l_2911[0][0][0]) , &g_107[0]))) >= l_3105[0]) <= l_2911[0][0][2]) , l_2911[0][2][1]))));
                    }
                    l_3107--;
                }
            }
        }
        else
        { /* block id: 1499 */
            int16_t l_3116 = 0xE679L;
            (*l_2877) = ((*l_2877) , (0UL || 6UL));
            (*g_79) = func_38(func_38(((*g_85) = func_38(&l_2911[0][0][0], ((safe_add_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((safe_mod_func_uint64_t_u_u((*l_2877), (l_3116 = g_2200[5][7][0]))) > ((((l_30[0] , (((*g_1396) & (*l_2877)) == (safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_s(l_30[0], ((6UL == (((safe_lshift_func_uint16_t_u_s((((*l_2877) > (**g_85)) | l_3127), 15)) <= (**g_85)) < (*l_2877))) ^ 0UL))), 0)), 253UL)))) | l_2958) < (-1L)) , (*g_895))), (*l_2877))), 1UL)) != 0UL))), l_2911[0][1][4]), l_2958);
        }
        if ((*l_2877))
            continue;
    }
    return (*g_2948);
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_4 g_79 g_80 g_85 g_108 g_88 g_100 g_112 g_103 g_107 g_104 g_2
 * writes: g_46 g_83 g_80 g_108 g_103 g_100 g_105
 */
static int8_t  func_13(int8_t  p_14, int8_t  p_15, int64_t  p_16, int64_t  p_17)
{ /* block id: 9 */
    int32_t *l_47 = (void*)0;
    int16_t *l_81 = (void*)0;
    int16_t *l_82 = &g_83;
    int32_t l_84[8][9][3] = {{{(-2L),0x5DE30EA3L,1L},{9L,9L,9L},{0x93A39D8EL,(-1L),0L},{(-2L),6L,8L},{(-1L),(-5L),1L},{(-1L),0x20603003L,5L},{(-1L),1L,(-1L)},{(-2L),0x1FBCDA4FL,1L},{0x93A39D8EL,1L,0L}},{{9L,(-2L),0xFD5B128CL},{(-2L),0xA8F9E1C2L,0x03FBD5CEL},{(-1L),1L,(-6L)},{1L,0xA8F9E1C2L,(-1L)},{0x94618C45L,(-2L),(-2L)},{1L,1L,0xA8F9E1C2L},{(-6L),0x1FBCDA4FL,0xD6825D0BL},{(-5L),1L,6L},{0xD6825D0BL,0x20603003L,0x94618C45L}},{{0x7F7A3747L,(-5L),6L},{0xF50FADE0L,6L,0xD6825D0BL},{0xA8F9E1C2L,(-1L),0xA8F9E1C2L},{0xD5916FF7L,9L,(-2L)},{0L,0x5DE30EA3L,(-1L)},{(-3L),7L,(-6L)},{0L,(-1L),0x03FBD5CEL},{(-3L),(-1L),0xFD5B128CL},{0L,0L,1L}},{{0x5D11E905L,(-4L),(-6L)},{0x93A39D8EL,0L,(-5L)},{5L,0x9CF818A8L,0xD6825D0BL},{(-1L),6L,0x7F7A3747L},{(-2L),0x9CF818A8L,0xF50FADE0L},{0L,0L,0xA8F9E1C2L},{(-1L),(-4L),0xD5916FF7L},{0x7F7A3747L,1L,0L},{(-1L),0xBE75688AL,(-3L)}},{{0L,(-2L),0L},{0xC23FAAB9L,(-2L),(-3L)},{0x03FBD5CEL,0x6AEF2D6AL,0L},{0xD5916FF7L,0x20603003L,0xD5916FF7L},{1L,(-1L),0xA8F9E1C2L},{9L,1L,0xF50FADE0L},{(-1L),0L,0x7F7A3747L},{1L,9L,0xD6825D0BL},{(-1L),(-1L),(-5L)}},{{9L,0x7E3B5251L,(-6L)},{1L,0x7F7A3747L,1L},{0xD5916FF7L,0x1FBCDA4FL,0x94618C45L},{0x03FBD5CEL,0x93A39D8EL,1L},{0xC23FAAB9L,1L,(-1L)},{0L,0x93A39D8EL,(-2L)},{(-1L),0x1FBCDA4FL,9L},{0x7F7A3747L,0x7F7A3747L,0x93A39D8EL},{(-1L),0x7E3B5251L,(-2L)}},{{0L,(-1L),(-1L)},{(-2L),9L,(-1L)},{(-1L),0L,(-1L)},{5L,1L,(-2L)},{0x93A39D8EL,(-1L),0x93A39D8EL},{0x5D11E905L,0x20603003L,9L},{0xA8F9E1C2L,0x6AEF2D6AL,(-2L)},{8L,(-2L),(-1L)},{0L,(-2L),1L}},{{8L,0xBE75688AL,0x94618C45L},{0xA8F9E1C2L,1L,1L},{0x5D11E905L,(-4L),(-6L)},{0x93A39D8EL,0L,(-5L)},{5L,0x9CF818A8L,0xD6825D0BL},{(-1L),6L,0x7F7A3747L},{(-2L),0x9CF818A8L,0xF50FADE0L},{0L,0L,0xA8F9E1C2L},{(-1L),(-4L),0xD5916FF7L}}};
    uint32_t l_111 = 0xED7DDA23L;
    int32_t *l_113 = &g_103;
    int32_t l_124 = (-1L);
    int32_t l_126 = 0L;
    int64_t *l_2101 = (void*)0;
    int64_t *l_2102[6];
    uint8_t l_2103[5][7] = {{247UL,0xF0L,247UL,0xBCL,8UL,8UL,0xBCL},{247UL,0xF0L,247UL,0xBCL,8UL,8UL,0xBCL},{247UL,0xF0L,247UL,0xBCL,8UL,8UL,0xBCL},{247UL,0xF0L,247UL,0xBCL,8UL,8UL,0xBCL},{247UL,0xF0L,247UL,0xBCL,8UL,8UL,0xBCL}};
    int32_t ***l_2667[6][9][4] = {{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}},{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}},{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}},{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}},{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}},{{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79},{&g_79,&g_79,&g_79,&g_79}}};
    uint64_t l_2668 = 0x56367524BDF4553ELL;
    uint64_t *l_2669 = &l_2668;
    uint8_t ** const *l_2778 = &g_894;
    uint16_t l_2779 = 0UL;
    uint8_t ***l_2786 = &g_894;
    uint8_t ****l_2785 = &l_2786;
    uint8_t ***** const l_2784 = &l_2785;
    uint8_t ***** const *l_2783[5][7][7] = {{{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0},{(void*)0,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784}},{{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784},{&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0},{(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784}},{{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784}},{{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0},{&l_2784,(void*)0,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,(void*)0,(void*)0,&l_2784,&l_2784,&l_2784}},{{&l_2784,(void*)0,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784},{&l_2784,&l_2784,&l_2784,(void*)0,&l_2784,&l_2784,(void*)0},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,(void*)0,&l_2784},{&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784,&l_2784}}};
    uint8_t ***** const **l_2782 = &l_2783[3][2][3];
    int32_t l_2838 = (-1L);
    int8_t l_2850[6][9][4] = {{{0xEEL,(-8L),0x8AL,0L},{(-1L),1L,0L,(-6L)},{0x03L,0xEEL,0L,0xEAL},{0x9FL,(-1L),(-1L),(-1L)},{0x9BL,0x9BL,0L,0x11L},{0x03L,(-1L),0x9FL,0x14L},{(-6L),0x15L,0x8AL,0x9FL},{(-6L),0x15L,0L,0x14L},{0x15L,(-1L),7L,0x11L}},{{(-5L),0x9BL,(-6L),(-1L)},{0xEAL,(-1L),0xB3L,0xEAL},{0x11L,0xEEL,7L,(-6L)},{0xAEL,1L,0xEEL,0L},{(-6L),(-8L),1L,(-8L)},{(-1L),0x87L,0x9FL,(-6L)},{0x87L,0x14L,0L,(-2L)},{0x9BL,(-1L),0x93L,0x42L},{0x9BL,0x9FL,0L,0x11L}},{{0x87L,0x42L,0x9FL,0xEEL},{(-1L),0x15L,1L,0x9BL},{(-6L),0xAEL,0xEEL,0x14L},{0xAEL,0x42L,7L,(-5L)},{0x11L,0x9BL,0xB3L,0x42L},{0xEAL,(-6L),(-6L),0xEAL},{(-5L),0x14L,7L,0xEEL},{0x15L,1L,0L,(-8L)},{(-6L),0L,0x8AL,(-8L)}},{{(-6L),1L,0x9FL,0xEEL},{0x03L,0x14L,0L,0xEAL},{0x9BL,(-6L),(-1L),0x42L},{0x9FL,0x9BL,0L,(-5L)},{0x03L,0x42L,0L,0x14L},{(-1L),0xAEL,0x8AL,0L},{0x93L,(-5L),0x93L,0L},{(-5L),(-6L),0L,0xEEL},{0xEEL,0L,(-2L),(-6L)}},{{0L,(-2L),(-2L),0L},{0xEEL,0x87L,0L,(-1L)},{(-5L),0x74L,0x93L,0xAEL},{0x93L,0xAEL,(-1L),5L},{(-2L),7L,(-8L),(-1L)},{0xEEL,0L,5L,0x9FL},{0L,(-2L),0xB3L,0xB3L},{0L,0L,0x15L,0xEEL},{0xEEL,0xB3L,0L,0x87L}},{{(-2L),(-5L),(-1L),0L},{(-1L),(-5L),0x42L,0x87L},{(-5L),0xB3L,1L,0xEEL},{0x2AL,0L,(-2L),0xB3L},{0x9FL,(-2L),0xEAL,0x9FL},{0xEEL,0L,1L,(-1L)},{6L,7L,0x93L,5L},{(-1L),0xAEL,0x03L,0xAEL},{(-2L),0x74L,0L,(-1L)}}};
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_2102[i] = &g_104[0];
    (*l_113) &= func_23((safe_add_func_uint32_t_u_u((g_45 < (g_46 = 0L)), (&g_4 == l_47))), (((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s(func_52(func_57(&g_4, (safe_div_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u(((0L <= func_23(g_4, func_23((((*l_82) = (safe_rshift_func_uint8_t_u_s((safe_add_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(((&l_47 != g_79) && (-3L)), 0xDCL)), g_4)), 5))) , 9UL), p_14, p_14, p_16), l_84[0][3][1], p_17)) <= 1UL), g_4)) && 0L), 0)), 1)), p_14)), p_15)), 9L)), g_4), p_17, g_4, l_84[5][4][1]), 0xC3BF42E135D25129LL)), p_15)) , l_111) != p_15), g_100, g_112[6][1]);
    for (g_100 = 0; (g_100 <= 24); ++g_100)
    { /* block id: 21 */
        uint8_t l_125[10] = {0x45L,7UL,0x45L,0x45L,7UL,0x45L,0x45L,7UL,0x45L,0x45L};
        int32_t *l_127[5][2];
        int32_t *l_128 = &l_84[1][8][2];
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 2; j++)
                l_127[i][j] = &l_126;
        }
        (*l_128) &= (safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(((((*l_113) <= (safe_add_func_uint64_t_u_u(((g_105 = (safe_div_func_int64_t_s_s((0L && (l_124 < l_125[3])), ((0x19L <= ((g_107[2] , (func_23((g_104[1] , func_23((p_16 & 4294967295UL), g_107[2], l_126, g_104[1])), p_15, p_17, p_15) != 4UL)) || l_125[1])) , g_2[0])))) , 18446744073709551606UL), 0L))) && g_100) , p_16), 0xCD61341CL)), p_16));
        (*l_128) &= 0xD48341D4L;
    }
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static uint32_t  func_23(uint64_t  p_24, int16_t  p_25, int64_t  p_26, int16_t  p_27)
{ /* block id: 4 */
    int32_t *l_42 = &g_4;
    int32_t **l_41 = &l_42;
    (*l_41) = func_38(&g_4, p_24);
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_38(const int32_t * p_39, uint32_t  p_40)
{ /* block id: 5 */
    return &g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_108 g_88
 * writes: g_108
 */
static int64_t  func_52(const int32_t ** p_53, uint32_t  p_54, uint16_t  p_55, uint32_t  p_56)
{ /* block id: 15 */
    int32_t *l_87 = &g_88;
    int32_t *l_89 = &g_88;
    int32_t *l_90 = &g_88;
    int32_t *l_91 = &g_88;
    int32_t l_92[9] = {0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L,0x85F08201L};
    int32_t *l_93 = &l_92[6];
    int32_t *l_94 = (void*)0;
    int32_t *l_95 = (void*)0;
    int32_t *l_96 = &l_92[0];
    int32_t *l_97 = &l_92[0];
    int32_t *l_98 = &g_88;
    int32_t *l_99 = &l_92[5];
    int32_t *l_101 = (void*)0;
    int32_t *l_102[5] = {&g_88,&g_88,&g_88,&g_88,&g_88};
    int i;
    g_108++;
    return (*l_87);
}


/* ------------------------------------------ */
/* 
 * reads : g_79 g_80 g_85
 * writes: g_80
 */
static const int32_t ** func_57(int32_t * const  p_58, uint32_t  p_59, int16_t  p_60)
{ /* block id: 12 */
    (*g_79) = (*g_79);
    return g_85;
}


/* ------------------------------------------ */
/* 
 * reads : g_956 g_88 g_1329 g_893 g_894 g_895 g_279 g_86 g_4 g_2131 g_558 g_108 g_80 g_2 g_79 g_288 g_871 g_290 g_83 g_900 g_901 g_727 g_85 g_2321 g_103 g_2130 g_2132 g_739 g_2553 g_1273 g_1274 g_112 g_2582 g_1908 g_1328 g_461 g_977 g_520 g_2646 g_194 g_287
 * writes: g_2 g_290 g_2132 g_112 g_108 g_727 g_83 g_977 g_80 g_1055 g_341 g_86 g_2533 g_739 g_103 g_2553 g_104 g_2163 g_267 g_100 g_2582 g_194 g_2646 g_2487 g_1847 g_88
 */
static int32_t ** func_131(uint16_t  p_132, uint64_t  p_133, int16_t * p_134, int32_t ** p_135, uint32_t  p_136)
{ /* block id: 970 */
    int8_t l_2106 = 0L;
    int64_t l_2107 = 1L;
    int32_t l_2108 = 0x68CB28B5L;
    int32_t l_2109[9][7] = {{0x3A5354B7L,0x1ED5CFF6L,0x832F6439L,0xCFB99B50L,0x70F41A95L,0xE87683E5L,0x34CC191DL},{(-1L),(-10L),0x7D491D92L,0x903480CBL,(-8L),0x1CD9203EL,7L},{0x832F6439L,0x903480CBL,0x34CC191DL,0xCFB99B50L,0x7D491D92L,0x7D491D92L,0xCFB99B50L},{0xD11C880BL,7L,0xD11C880BL,0xE87683E5L,0x7D491D92L,0x2E2E5EE3L,0x3A5354B7L},{(-10L),0x1CD9203EL,0L,7L,(-8L),0x1ED5CFF6L,(-1L)},{7L,0L,0x1CD9203EL,(-10L),0x70F41A95L,0x2E2E5EE3L,0x2E2E5EE3L},{0xE87683E5L,0xD11C880BL,7L,0xD11C880BL,0xE87683E5L,0x7D491D92L,0x2E2E5EE3L},{0xCFB99B50L,0x34CC191DL,0x903480CBL,0x832F6439L,0x2E2E5EE3L,0x1CD9203EL,(-1L)},{0x903480CBL,0x7D491D92L,(-10L),(-1L),7L,0xE87683E5L,0x3A5354B7L}};
    int32_t l_2110[10] = {(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L)};
    uint16_t l_2111[7][2] = {{0x2B2BL,1UL},{0x2B2BL,1UL},{0x2B2BL,1UL},{0x2B2BL,1UL},{0x2B2BL,1UL},{0x2B2BL,1UL},{0x2B2BL,1UL}};
    int16_t l_2198 = 0x5A57L;
    uint32_t **l_2248 = &g_901[2];
    uint64_t *l_2261 = &g_977;
    uint64_t **l_2260 = &l_2261;
    int8_t *l_2262 = &g_112[9][3];
    uint32_t ****l_2322 = &g_1273;
    int32_t *l_2371 = &g_103;
    int32_t l_2427[7][1] = {{7L},{3L},{3L},{7L},{3L},{3L},{7L}};
    int32_t ******l_2498 = (void*)0;
    int32_t l_2544 = 0xC985221FL;
    uint8_t ***l_2628 = &g_894;
    uint8_t **** const l_2627 = &l_2628;
    int i, j;
lbl_2203:
    (*g_1329) = (*g_956);
    for (g_290 = 7; (g_290 >= 0); g_290 -= 1)
    { /* block id: 974 */
        int32_t l_2104 = 0x909BAC14L;
        int32_t *l_2105[2][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
        int8_t l_2114 = 5L;
        uint32_t l_2115 = 0UL;
        uint32_t *l_2129 = &g_108;
        uint32_t **l_2128 = &l_2129;
        uint16_t **l_2138 = (void*)0;
        volatile int32_t *l_2177 = &g_2[0];
        const int32_t *l_2243 = (void*)0;
        int i, j;
        l_2111[0][1]--;
    }
    if (((0L > (safe_rshift_func_uint16_t_u_s(0x75E2L, 13))) == ((safe_mod_func_uint8_t_u_u((***g_893), (l_2109[6][5] |= ((safe_rshift_func_int8_t_s_u((((l_2110[5] < ((l_2108 = ((*g_895) ^ ((*l_2262) = ((p_133 == ((((*g_86) <= ((((safe_mod_func_uint64_t_u_u((((*g_2131) = (void*)0) != (void*)0), 0xF790EEF2254F9A70LL)) , p_133) , l_2260) != g_558[0][0])) , (void*)0) == (void*)0)) , (-7L))))) < p_133)) , (-1L)) >= 0UL), 1)) , (**g_894))))) <= l_2107)))
    { /* block id: 1072 */
        int16_t l_2293[5][4];
        int32_t l_2305[9][6] = {{0xD476FC58L,0xD476FC58L,(-1L),0x2106DF3FL,(-1L),0xD476FC58L},{(-1L),0x89AED293L,0x2106DF3FL,0x2106DF3FL,0x89AED293L,(-1L)},{0xD476FC58L,(-1L),0x2106DF3FL,(-1L),0xD476FC58L,0xD476FC58L},{1L,(-1L),(-1L),1L,0x89AED293L,1L},{1L,0x89AED293L,1L,(-1L),(-1L),1L},{0xD476FC58L,0xD476FC58L,(-1L),0x2106DF3FL,(-1L),0xD476FC58L},{(-1L),0x89AED293L,0x2106DF3FL,0x2106DF3FL,0x89AED293L,(-1L)},{0xD476FC58L,(-1L),0x2106DF3FL,(-1L),0xD476FC58L,0xD476FC58L},{1L,(-1L),(-1L),1L,0x89AED293L,1L}};
        int32_t **l_2334 = &g_80;
        uint64_t l_2372 = 0xA8FD6DDE4B234A56LL;
        uint64_t *l_2395 = &l_2372;
        uint64_t l_2430 = 0xCABE6A2B58D0A975LL;
        uint8_t *l_2448 = (void*)0;
        uint16_t *l_2476 = &g_341[0][0];
        uint32_t l_2490 = 4294967290UL;
        int32_t l_2494 = 0x0EDB35DEL;
        uint16_t l_2515 = 0x9E3CL;
        uint32_t **l_2526 = &g_2132;
        const int32_t *l_2531[5];
        const int32_t **l_2530[2];
        int64_t l_2543[6][5][7] = {{{0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL},{(-7L),0x482713B82C50AF9CLL,(-7L),8L,1L,8L,(-7L)},{0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL},{1L,8L,(-7L),0x482713B82C50AF9CLL,(-7L),8L,1L},{0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL}},{{1L,0x482713B82C50AF9CLL,1L,0x482713B82C50AF9CLL,1L,0x830E31B005505002LL,1L},{0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL},{(-7L),0x482713B82C50AF9CLL,(-7L),8L,1L,8L,(-7L)},{0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL},{1L,8L,(-7L),0x482713B82C50AF9CLL,(-7L),8L,1L}},{{0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL},{1L,0x482713B82C50AF9CLL,1L,0x482713B82C50AF9CLL,1L,0x830E31B005505002LL,1L},{0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL},{(-7L),0x482713B82C50AF9CLL,(-7L),8L,1L,8L,(-7L)},{0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL,0x57E6AA67BEE1DDF8LL,0x7E480CF2ABC83944LL,0x57E6AA67BEE1DDF8LL}},{{1L,8L,(-7L),0x482713B82C50AF9CLL,1L,0x830E31B005505002LL,(-7L)},{0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL},{(-7L),8L,1L,8L,(-7L),0x482713B82C50AF9CLL,(-7L)},{0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL},{1L,8L,1L,0x830E31B005505002LL,(-7L),0x830E31B005505002LL,1L}},{{0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL},{(-7L),0x830E31B005505002LL,1L,8L,1L,0x830E31B005505002LL,(-7L)},{0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL},{(-7L),8L,1L,8L,(-7L),0x482713B82C50AF9CLL,(-7L)},{0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL}},{{1L,8L,1L,0x830E31B005505002LL,(-7L),0x830E31B005505002LL,1L},{0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL,0x56CB48F3E2441A63LL,0x57E6AA67BEE1DDF8LL,0x56CB48F3E2441A63LL},{(-7L),0x830E31B005505002LL,1L,8L,1L,0x830E31B005505002LL,(-7L)},{0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL,0x56CB48F3E2441A63LL,0x7E480CF2ABC83944LL,0x7E480CF2ABC83944LL},{(-7L),8L,1L,8L,(-7L),0x482713B82C50AF9CLL,(-7L)}}};
        int i, j, k;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 4; j++)
                l_2293[i][j] = 0x684AL;
        }
        for (i = 0; i < 5; i++)
            l_2531[i] = &g_2532[0];
        for (i = 0; i < 2; i++)
            l_2530[i] = &l_2531[1];
        for (g_108 = 0; (g_108 <= 47); g_108++)
        { /* block id: 1075 */
            int32_t ***l_2288 = &g_569;
            int32_t l_2306[2];
            uint16_t l_2331[1];
            const uint8_t ****l_2458 = (void*)0;
            int32_t l_2464 = 0x82C875A0L;
            int32_t **l_2465 = &g_80;
            uint32_t ** const *l_2475 = &g_2131;
            int i;
            for (i = 0; i < 2; i++)
                l_2306[i] = (-1L);
            for (i = 0; i < 1; i++)
                l_2331[i] = 65535UL;
            (*g_1329) &= (**p_135);
            if ((**g_79))
                break;
            for (g_727 = 23; (g_727 <= 11); g_727 = safe_sub_func_int64_t_s_s(g_727, 1))
            { /* block id: 1080 */
                const uint64_t *l_2276 = &g_178[3][2];
                const uint64_t **l_2275 = &l_2276;
                int32_t l_2292[8] = {9L,9L,9L,9L,9L,9L,9L,9L};
                int32_t l_2294 = 0xD2CF3E4CL;
                int i;
                if (l_2107)
                    goto lbl_2203;
                if ((safe_sub_func_int16_t_s_s(1L, (p_132 || ((~((safe_unary_minus_func_int32_t_s((safe_mod_func_int16_t_s_s((5UL > 0xE0D8B48D68D77726LL), 0x145FL)))) & 9L)) , g_288)))))
                { /* block id: 1082 */
                    int16_t *l_2280 = &g_83;
                    uint32_t *l_2289[8][7][4] = {{{&g_2200[8][0][0],&g_2200[8][0][0],&g_727,(void*)0},{(void*)0,&g_727,&g_727,(void*)0},{&g_2200[8][0][0],(void*)0,&g_2200[8][0][0],(void*)0},{&g_528,&g_727,&g_46,(void*)0},{&g_2200[7][2][1],&g_2200[8][0][0],&g_2200[8][0][0],&g_528},{&g_727,&g_2200[8][0][0],&g_727,(void*)0},{&g_2200[8][0][0],&g_727,&g_727,(void*)0}},{{&g_727,(void*)0,&g_2200[8][0][0],(void*)0},{&g_2200[7][2][1],&g_727,&g_2200[4][6][0],(void*)0},{&g_528,&g_2200[8][0][0],&g_2200[8][0][0],&g_528},{&g_2200[8][0][0],&g_2200[8][0][0],&g_727,(void*)0},{(void*)0,&g_727,&g_727,(void*)0},{&g_2200[8][0][0],(void*)0,&g_2200[8][0][0],(void*)0},{&g_528,&g_727,&g_46,(void*)0}},{{&g_2200[7][2][1],&g_2200[8][0][0],&g_2200[8][0][0],&g_528},{&g_727,&g_2200[8][0][0],&g_727,(void*)0},{&g_2200[8][0][0],&g_727,&g_727,(void*)0},{&g_727,(void*)0,&g_2200[8][0][0],(void*)0},{&g_2200[7][2][1],&g_727,&g_2200[4][6][0],(void*)0},{&g_528,&g_2200[8][0][0],&g_2200[8][0][0],&g_528},{&g_2200[8][0][0],&g_46,&g_46,&g_528}},{{&g_528,(void*)0,&g_727,&g_2200[8][0][0]},{&g_2200[8][0][0],&g_2200[8][0][0],&g_2200[4][6][0],&g_2200[8][0][0]},{(void*)0,(void*)0,&g_727,&g_528},{&g_2200[8][0][0],&g_46,&g_2200[4][6][0],(void*)0},{(void*)0,&g_46,&g_727,&g_528},{&g_2200[7][2][1],(void*)0,&g_46,&g_2200[8][0][0]},{(void*)0,&g_2200[8][0][0],&g_46,&g_2200[8][0][0]}},{{&g_2200[8][0][0],(void*)0,&g_727,&g_528},{(void*)0,&g_46,&g_46,(void*)0},{&g_2200[8][0][0],&g_46,&g_46,&g_528},{&g_528,(void*)0,&g_727,&g_2200[8][0][0]},{&g_2200[8][0][0],&g_2200[8][0][0],&g_2200[4][6][0],&g_2200[8][0][0]},{(void*)0,(void*)0,&g_727,&g_528},{&g_2200[8][0][0],&g_46,&g_2200[4][6][0],(void*)0}},{{(void*)0,&g_46,&g_727,&g_528},{&g_2200[7][2][1],(void*)0,&g_46,&g_2200[8][0][0]},{(void*)0,&g_2200[8][0][0],&g_46,&g_2200[8][0][0]},{&g_2200[8][0][0],(void*)0,&g_727,&g_528},{(void*)0,&g_46,&g_46,(void*)0},{&g_2200[8][0][0],&g_46,&g_46,&g_528},{&g_528,(void*)0,&g_727,&g_2200[8][0][0]}},{{&g_2200[8][0][0],&g_2200[8][0][0],&g_2200[4][6][0],&g_2200[8][0][0]},{(void*)0,(void*)0,&g_727,&g_528},{&g_2200[8][0][0],&g_46,&g_2200[4][6][0],(void*)0},{(void*)0,&g_46,&g_727,&g_528},{&g_2200[7][2][1],(void*)0,&g_46,&g_2200[8][0][0]},{(void*)0,&g_2200[8][0][0],&g_46,&g_2200[8][0][0]},{&g_2200[8][0][0],(void*)0,&g_727,&g_528}},{{(void*)0,&g_46,&g_46,(void*)0},{&g_2200[8][0][0],&g_46,&g_46,&g_528},{&g_528,(void*)0,&g_727,&g_2200[8][0][0]},{&g_2200[8][0][0],&g_2200[8][0][0],&g_2200[4][6][0],&g_2200[8][0][0]},{(void*)0,(void*)0,&g_727,&g_528},{&g_2200[8][0][0],&g_46,&g_2200[4][6][0],(void*)0},{(void*)0,&g_46,&g_727,&g_528}}};
                    int32_t l_2290 = 0xBEAC3EFCL;
                    int16_t l_2291 = 0xC8C5L;
                    int32_t l_2304 = 0xE65120B8L;
                    const uint64_t l_2313 = 18446744073709551615UL;
                    uint32_t ****l_2314[3];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_2314[i] = &g_1273;
                    (*g_1329) = (safe_mul_func_int16_t_s_s(((l_2275 != ((l_2110[5] , (~(safe_sub_func_uint32_t_u_u((((*l_2280) |= (*g_871)) , ((((safe_mul_func_uint8_t_u_u(((((((((safe_sub_func_uint64_t_u_u((~((safe_rshift_func_int16_t_s_u(((void*)0 == l_2288), p_133)) , (l_2290 = p_133))), ((0x23CB8E00L != (**p_135)) <= 65532UL))) >= (**g_900)) != 0x94L) || (**p_135)) , (**g_85)) <= 4294967288UL) ^ l_2291) <= p_133), l_2110[7])) , l_2292[5]) >= (*g_895)) < l_2293[3][2])), l_2294)))) , (void*)0)) , 0xAAFAL), 0xAD92L));
                    for (g_977 = 26; (g_977 <= 55); g_977++)
                    { /* block id: 1088 */
                        int32_t *l_2297 = (void*)0;
                        int32_t *l_2298 = &l_2292[5];
                        int32_t *l_2299 = &g_103;
                        int32_t *l_2300 = &g_100;
                        int32_t *l_2301 = &l_2109[0][0];
                        int32_t *l_2302 = (void*)0;
                        int32_t *l_2303[2][4][10] = {{{&l_2109[7][1],&l_2109[4][2],&l_2109[6][5],(void*)0,&l_2290,(void*)0,(void*)0,&l_2290,(void*)0,&l_2109[6][5]},{&l_2290,&l_2290,&l_2110[7],&g_88,&l_2108,&g_100,(void*)0,(void*)0,(void*)0,&g_88},{&g_88,&g_739,&l_2109[7][1],(void*)0,&l_2292[5],&l_2109[6][5],(void*)0,&g_103,&l_2109[6][5],&l_2292[5]},{&l_2290,&l_2290,&g_2163[7],&l_2290,&g_88,&g_88,(void*)0,(void*)0,(void*)0,&g_88}},{{&l_2290,&l_2109[4][2],&l_2292[5],&l_2109[4][2],&l_2290,&g_2163[3],&l_2290,(void*)0,&l_2109[4][2],(void*)0},{&l_2109[7][1],&l_2110[7],(void*)0,&g_2163[7],&l_2110[7],&l_2292[5],&g_88,&g_100,&l_2294,(void*)0},{&g_2163[7],&g_2163[7],&l_2294,&l_2292[4],&g_103,(void*)0,&g_2163[7],&g_88,&g_267,&g_267},{&g_739,&l_2109[6][5],&g_88,(void*)0,(void*)0,&g_88,&l_2109[6][5],&g_739,&l_2109[4][2],&g_88}}};
                        uint16_t l_2307 = 2UL;
                        uint32_t *l_2310[6] = {&g_1997,(void*)0,(void*)0,&g_1997,(void*)0,(void*)0};
                        int i, j, k;
                        (*g_79) = (void*)0;
                        l_2307--;
                        (*l_2301) = (((l_2305[0][0] = p_132) , ((((p_136++) , (((p_135 != p_135) != l_2306[1]) || l_2313)) , (((l_2314[0] = l_2314[0]) != ((safe_sub_func_int64_t_s_s((safe_mod_func_uint16_t_u_u(l_2292[5], (safe_add_func_int64_t_s_s(l_2109[4][2], g_88)))), g_2321)) , l_2322)) , l_2292[1])) | l_2110[7])) < l_2306[0]);
                    }
                    (*g_79) = func_38((*g_85), (**g_900));
                    (*g_1329) ^= 0x1E24EB76L;
                }
                else
                { /* block id: 1098 */
                    int32_t *l_2323 = &l_2294;
                    int32_t *l_2324 = &g_103;
                    int32_t *l_2325 = &l_2109[4][2];
                    int32_t *l_2326 = &l_2110[6];
                    int32_t *l_2327 = &l_2292[5];
                    int32_t *l_2328 = (void*)0;
                    int32_t *l_2329[6] = {&l_2110[4],&l_2110[4],&l_2110[4],&l_2110[4],&l_2110[4],&l_2110[4]};
                    int8_t l_2330 = 0xB1L;
                    int i;
                    for (g_1055 = 3; (g_1055 >= 0); g_1055 -= 1)
                    { /* block id: 1101 */
                        if ((*g_1329))
                            break;
                    }
                    l_2331[0]--;
                    return l_2334;
                }
            }
        }
        l_2371 = func_38((((safe_add_func_uint64_t_u_u((((safe_add_func_int64_t_s_s((safe_mul_func_int8_t_s_s(((*l_2262) = (*l_2371)), p_136)), (((*g_871) &= ((safe_lshift_func_int16_t_s_u((p_136 == ((((void*)0 == (**g_2130)) == ((l_2526 == &g_2132) == (*l_2371))) != ((**l_2248)++))), 3)) != ((*l_2476) = (!(**l_2334))))) , (**l_2334)))) >= 0xC6L) == (*l_2371)), (*l_2371))) != (**l_2334)) , &l_2109[2][3]), p_133);
        (*g_79) = func_38((g_2533 = ((*g_85) = (*g_85))), ((((*l_2395) = (safe_sub_func_uint64_t_u_u((((((((**l_2260) = (((0x78L || (safe_lshift_func_uint8_t_u_u((((void*)0 == l_2262) && ((*l_2476) = (safe_div_func_int16_t_s_s((&l_2107 != l_2395), (safe_mod_func_uint8_t_u_u(p_136, ((((**l_2334) != (0x019EF7956898F95ALL | 0xAC41975945D36D09LL)) < l_2543[3][4][6]) , p_132))))))), (**g_894)))) , 4294967295UL) , l_2544)) , p_133) != (*l_2371)) | p_136) ^ 0xB738L) || p_132), (*l_2371)))) <= p_132) , p_133));
    }
    else
    { /* block id: 1228 */
        int32_t *****l_2557[2][5][8] = {{{&g_2554[1][2][2],&g_2554[0][7][0],&g_2554[7][1][1],&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[0][2][1],&g_2554[4][3][2],&g_2554[8][4][0]},{(void*)0,&g_2554[6][7][0],&g_2554[6][6][0],&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[6][6][0],&g_2554[6][7][0],(void*)0},{&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[7][1][1],&g_2554[6][7][0],&g_2554[8][6][1],&g_2554[0][4][2],&g_2554[2][7][2]},{&g_2554[1][2][2],&g_2554[5][0][1],&g_2554[8][4][0],&g_2554[2][2][1],&g_2554[7][1][1],&g_2554[8][6][1],&g_2554[6][7][0],&g_2554[6][7][0]},{&g_2554[4][3][2],&g_2554[6][7][0],&g_2554[4][5][1],&g_2554[0][6][2],&g_2554[0][7][2],&g_2554[6][6][0],&g_2554[0][6][2],&g_2554[2][2][1]}},{{&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[5][0][1],&g_2554[6][7][0],(void*)0,&g_2554[0][2][1],&g_2554[0][7][0],&g_2554[4][3][2]},{&g_2554[0][7][2],&g_2554[0][7][0],&g_2554[8][4][0],&g_2554[6][7][0],&g_2554[8][4][0],&g_2554[0][7][0],&g_2554[0][7][2],&g_2554[4][1][0]},{&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[3][3][0],(void*)0,&g_2554[2][2][1],&g_2554[6][7][0],&g_2554[6][7][0],&g_2554[2][2][1]},{(void*)0,&g_2554[0][7][2],&g_2554[0][4][2],(void*)0,&g_2554[2][2][1],(void*)0,&g_2554[4][1][0],&g_2554[6][7][0]},{&g_2554[6][7][0],&g_2554[8][6][1],&g_2554[7][1][1],&g_2554[2][2][1],&g_2554[8][4][0],&g_2554[5][0][1],&g_2554[1][2][2],&g_2554[8][6][1]}}};
        int32_t l_2564[1];
        int32_t *l_2629 = &l_2564[0];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2564[i] = (-1L);
        for (g_739 = 0; (g_739 <= 0); g_739 += 1)
        { /* block id: 1231 */
            uint32_t l_2550 = 4294967291UL;
            uint32_t **l_2561[5][5] = {{&g_901[2],&g_901[2],&g_901[2],&g_901[2],&g_901[2]},{(void*)0,&g_901[2],(void*)0,(void*)0,&g_901[2]},{&g_901[2],(void*)0,(void*)0,&g_901[2],(void*)0},{&g_901[2],&g_901[2],&g_901[2],&g_901[2],&g_901[2]},{(void*)0,&g_901[2],(void*)0,(void*)0,&g_901[2]}};
            uint32_t l_2563 = 0x3FD032C7L;
            int32_t l_2567 = 0xB8471116L;
            int32_t l_2568 = 6L;
            int32_t l_2573[7];
            int32_t l_2575[1];
            uint32_t l_2620 = 1UL;
            uint32_t l_2624[1][3][2] = {{{0x20364223L,0x6B4C2A5CL},{0x20364223L,0x20364223L},{0x6B4C2A5CL,0x20364223L}}};
            int64_t *l_2630 = &g_2487;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_2573[i] = 0xC88BA12CL;
            for (i = 0; i < 1; i++)
                l_2575[i] = 1L;
            if (g_2[g_739])
            { /* block id: 1232 */
                int32_t *l_2545 = &g_100;
                int32_t *l_2546 = &l_2110[9];
                int32_t *l_2547 = &g_100;
                int32_t *l_2548 = &g_2163[7];
                int32_t *l_2549[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int64_t l_2599 = 0L;
                uint64_t l_2600 = 0xC29A3562F081EF1BLL;
                int i;
                l_2550++;
                for (g_103 = 0; (g_103 <= 1); g_103 += 1)
                { /* block id: 1236 */
                    int64_t *l_2558 = &g_104[0];
                    uint32_t l_2560 = 0xF0D0E128L;
                    int32_t l_2565 = 0x8A45DB5CL;
                    int32_t l_2570 = 0L;
                    int32_t l_2571 = 0x077E6660L;
                    int32_t l_2574 = 0x512EEAC1L;
                    int32_t l_2576 = 0x87050726L;
                    int32_t l_2577[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_2577[i] = 1L;
                    (*l_2548) = (g_2[g_739] == (((((*l_2558) = ((g_2553 = g_2553) != ((safe_rshift_func_uint8_t_u_u(0UL, 3)) , l_2557[0][3][6]))) | (l_2550 != (+(l_2560 || (l_2561[1][2] == (**l_2322)))))) | (~p_132)) , g_112[4][2]));
                    for (g_267 = 0; (g_267 <= 1); g_267 += 1)
                    { /* block id: 1242 */
                        int32_t l_2566 = 1L;
                        int32_t l_2569 = (-1L);
                        int32_t l_2572 = 5L;
                        int32_t l_2578 = 0xF55851CCL;
                        int32_t l_2579 = (-2L);
                        int32_t l_2580 = (-5L);
                        int32_t l_2581 = 0x6FB2C722L;
                        int i, j, k;
                        (*l_2548) = l_2563;
                        (*l_2547) = l_2560;
                        --g_2582;
                    }
                    for (g_977 = 0; (g_977 <= 1); g_977 += 1)
                    { /* block id: 1249 */
                        int32_t ******l_2596[7] = {&l_2557[1][3][6],&l_2557[1][3][6],&g_2553,&l_2557[1][3][6],&l_2557[1][3][6],&g_2553,&l_2557[1][3][6]};
                        int32_t l_2597 = 6L;
                        int32_t l_2598[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2598[i] = 0xCFAC44B0L;
                        (**g_1328) = (safe_rshift_func_uint8_t_u_s((safe_mul_func_int8_t_s_s((((~(((1UL || (((**l_2248) = (0xB0B8L != p_132)) ^ (-4L))) , (((l_2560 | g_1908) >= (safe_div_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s((*l_2371), (0xE7BC1A00L <= ((l_2557[0][0][3] = l_2557[0][3][6]) != (void*)0)))) , 1L), l_2564[0]))) <= p_133)) , l_2597)) || p_133) & 0x244F5741L), 0x1EL)), l_2573[2]));
                        l_2600++;
                    }
                }
            }
            else
            { /* block id: 1256 */
                uint64_t * const l_2615 = (void*)0;
                int32_t l_2621 = 0xEA8C4918L;
                int32_t *l_2622 = &l_2567;
                int32_t *l_2623[7][2] = {{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]},{&l_2109[4][2],&l_2109[4][2]}};
                int i, j;
                (*g_85) = &l_2110[0];
                (*g_1329) = ((((safe_unary_minus_func_uint8_t_u((safe_div_func_uint16_t_u_u(((l_2573[6] = 0UL) , (safe_unary_minus_func_int16_t_s((safe_div_func_int32_t_s_s((-1L), (safe_div_func_int16_t_s_s((p_136 > (safe_mul_func_int8_t_s_s(p_132, (((**l_2248) = (safe_mul_func_uint8_t_u_u(((((p_133 , l_2615) != (g_461 , l_2615)) != (((((safe_add_func_uint64_t_u_u(((*l_2261)++), (l_2573[6] = ((((*l_2262) = ((l_2564[0] , 0x184F10F6L) <= l_2620)) != l_2621) != p_133)))) , p_136) , &g_2450) == (void*)0) , p_132)) ^ (*l_2371)), l_2567))) && p_136)))), (-8L)))))))), l_2550)))) <= g_520) <= l_2621) || 1L);
                l_2624[0][0][1]++;
            }
            (*g_1329) &= ((void*)0 == l_2627);
            (*p_135) = (p_132 , l_2629);
            for (g_100 = 0; (g_100 <= 1); g_100 += 1)
            { /* block id: 1270 */
                int16_t l_2651 = 0L;
                int32_t l_2653 = 0xEBB0ECB0L;
                int32_t l_2658 = 0x130C3EF0L;
                int32_t l_2663[6];
                int i;
                for (i = 0; i < 6; i++)
                    l_2663[i] = (-1L);
                (**g_79) ^= (-1L);
                for (g_194 = 0; (g_194 <= 1); g_194 += 1)
                { /* block id: 1274 */
                    uint32_t l_2631[1][6][2] = {{{0xEA435054L,0xDCFD4324L},{0xEA435054L,0xDCFD4324L},{0xEA435054L,0xDCFD4324L},{0xEA435054L,0xDCFD4324L},{0xEA435054L,0xDCFD4324L},{0xEA435054L,0xDCFD4324L}}};
                    int i, j, k;
                    (*l_2371) ^= ((void*)0 != l_2630);
                    for (l_2106 = 1; (l_2106 >= 0); l_2106 -= 1)
                    { /* block id: 1278 */
                        uint64_t l_2642 = 0x8AE8F5BAD54A63EFLL;
                        uint8_t *** const * const **l_2648 = &g_2646;
                        int i, j, k;
                        if (l_2550)
                            break;
                        ++l_2631[0][1][0];
                        (*g_1329) |= (((*l_2630) = (((safe_div_func_int32_t_s_s((((((*l_2261) = p_132) != (0x99E8L <= 5UL)) >= (safe_add_func_uint32_t_u_u(((safe_mul_func_int32_t_s_s(0xDB915152L, (safe_rshift_func_int16_t_s_s(0L, l_2642)))) | (*g_871)), (((((safe_lshift_func_int8_t_s_u((!(((*l_2648) = g_2646) != &g_2647)), (*l_2629))) , g_287[(l_2106 + 8)][g_194][(g_739 + 4)]) == (void*)0) <= (*l_2371)) >= l_2642)))) != (*l_2629)), 1UL)) , l_2624[0][0][1]) || 18446744073709551614UL)) == 18446744073709551615UL);
                        (*l_2629) = l_2642;
                    }
                }
                for (g_1847 = 0; (g_1847 <= 1); g_1847 += 1)
                { /* block id: 1290 */
                    int64_t l_2652 = 0x7E703B9314465E9DLL;
                    int32_t l_2654 = 0x94B41FA5L;
                    int32_t l_2655 = 0xF857443DL;
                    int32_t l_2656 = 0xF2CA31A0L;
                    int32_t l_2657 = 0x3D57967BL;
                    int32_t l_2659 = (-1L);
                    int32_t l_2660 = 0L;
                    int32_t l_2662[9][10][1] = {{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}},{{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L},{0xE1EF74E5L},{0x6DE4B489L}}};
                    int i, j, k;
                    for (l_2198 = 0; (l_2198 <= 1); l_2198 += 1)
                    { /* block id: 1293 */
                        int32_t *l_2649 = &l_2109[5][3];
                        int32_t *l_2650[5][8] = {{&l_2108,&g_103,&l_2573[4],&g_103,&l_2108,&g_103,&l_2573[4],&g_103},{&l_2108,&g_103,&l_2573[4],&g_103,&l_2108,&g_103,&l_2573[4],&g_103},{&l_2108,&g_103,&l_2573[4],&g_103,&l_2108,&g_103,&l_2573[4],&g_103},{&l_2108,&g_103,&l_2573[4],&g_103,&l_2108,&g_103,&l_2573[4],&g_103},{&l_2108,&g_103,&l_2573[4],&g_103,&l_2108,&g_103,&l_2573[4],&g_103}};
                        int8_t l_2661[5][9][3] = {{{0L,0x5BL,0x48L},{0L,0L,0x5BL},{0xEAL,0x5BL,0x5BL},{0x5BL,0x60L,0x48L},{0xEAL,0x60L,0xEAL},{0L,0x5BL,0x48L},{0L,0L,0x5BL},{0xEAL,0x5BL,0x5BL},{0x5BL,0x60L,0x48L}},{{0xEAL,0x60L,0xEAL},{0L,0x5BL,0x48L},{0L,0L,0x5BL},{0xEAL,0x5BL,0x5BL},{0x5BL,0x60L,0x48L},{0xEAL,0x60L,0xEAL},{0L,0x5BL,0x48L},{0L,0L,0x5BL},{0xEAL,0x5BL,0x5BL}},{{0x5BL,0x60L,0x48L},{0xEAL,0L,0x48L},{0x5BL,0xEAL,0x60L},{0x5BL,0x5BL,0xEAL},{0x48L,0xEAL,0xEAL},{0xEAL,0L,0x60L},{0x48L,0L,0x48L},{0x5BL,0xEAL,0x60L},{0x5BL,0x5BL,0xEAL}},{{0x48L,0xEAL,0xEAL},{0xEAL,0L,0x60L},{0x48L,0L,0x48L},{0x5BL,0xEAL,0x60L},{0x5BL,0x5BL,0xEAL},{0x48L,0xEAL,0xEAL},{0xEAL,0L,0x60L},{0x48L,0L,0x48L},{0x5BL,0xEAL,0x60L}},{{0x5BL,0x5BL,0xEAL},{0x48L,0xEAL,0xEAL},{0xEAL,0L,0x60L},{0x48L,0L,0x48L},{0x5BL,0xEAL,0x60L},{0x5BL,0x5BL,0xEAL},{0x48L,0xEAL,0xEAL},{0xEAL,0L,0x60L},{0x48L,0L,0x48L}}};
                        uint64_t l_2664 = 3UL;
                        int i, j, k;
                        if ((**p_135))
                            break;
                        l_2664--;
                        if ((**g_79))
                            break;
                        (*l_2649) = (*g_956);
                    }
                    for (l_2654 = 0; (l_2654 <= 1); l_2654 += 1)
                    { /* block id: 1301 */
                        (*g_85) = (void*)0;
                    }
                }
            }
        }
        (*g_956) ^= (**p_135);
    }
    return &g_80;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t ** func_139(int32_t  p_140)
{ /* block id: 27 */
    int32_t *l_141 = &g_100;
    int32_t l_377 = 0x19D033DBL;
    int32_t **l_378 = (void*)0;
    int32_t **l_379 = &g_80;
    uint64_t l_380 = 0xB59A7F48A360B774LL;
    int16_t *l_381 = &g_83;
    uint32_t l_1015 = 0x46736EBDL;
    int32_t l_1017[6][7] = {{0L,5L,(-1L),5L,0L,0L,5L},{0xB4371289L,0xA648CB4DL,0xB4371289L,0x648947B8L,3L,(-1L),0x9DEAB061L},{5L,0x571CE424L,(-1L),(-1L),0x571CE424L,5L,0x571CE424L},{0xB4371289L,0x648947B8L,3L,(-1L),0x9DEAB061L,(-1L),3L},{0L,0L,5L,(-1L),5L,0L,0L},{(-1L),0x648947B8L,0x2FF26A04L,0x648947B8L,(-1L),0x0CB5B2C7L,3L}};
    int32_t l_1018 = 0xEC97946AL;
    int16_t l_1019 = 0x1909L;
    int8_t l_1020[2][2] = {{1L,1L},{1L,1L}};
    int32_t l_1023 = 0x1E7ED799L;
    int64_t l_1024 = 0L;
    uint32_t l_1026 = 1UL;
    int32_t * const l_1054 = &g_1055;
    int32_t * const *l_1053 = &l_1054;
    int32_t * const **l_1052 = &l_1053;
    int32_t * const ***l_1051 = &l_1052;
    int64_t l_1062 = (-1L);
    uint8_t l_1065 = 0x65L;
    int16_t l_1070 = 0xA24CL;
    int16_t l_1088[6][9] = {{(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L)},{3L,0xA8E0L,3L,4L,0x527FL,4L,3L,0xA8E0L,3L},{(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L)},{3L,0xA8E0L,3L,4L,0x527FL,4L,3L,0xA8E0L,3L},{(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L),(-1L),0x00A2L,(-1L)},{3L,0xA8E0L,3L,4L,0x527FL,4L,3L,0xA8E0L,3L}};
    uint32_t l_1118[10] = {9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL};
    uint64_t *l_1211[2];
    uint64_t ** const l_1210 = &l_1211[0];
    uint32_t ** const l_1233 = &g_901[2];
    uint32_t ** const *l_1232 = &l_1233;
    uint32_t **l_1506 = &g_901[1];
    uint8_t *l_1562 = &g_279[8][2];
    int64_t l_1563 = (-1L);
    int32_t l_1610 = 0L;
    const int32_t *l_1641 = (void*)0;
    uint8_t *l_1644 = &l_1065;
    uint8_t l_1666 = 0x41L;
    int8_t l_1669 = 0L;
    int64_t l_1691 = 0xBDF8E686AFB0C46BLL;
    uint16_t **l_1722[9][7][4] = {{{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295}},{{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,(void*)0,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,(void*)0,(void*)0,(void*)0},{&g_1295,&g_1295,&g_1295,&g_1295}},{{&g_1295,&g_1295,(void*)0,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,(void*)0,&g_1295}},{{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,(void*)0},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295}},{{&g_1295,&g_1295,&g_1295,(void*)0},{&g_1295,&g_1295,&g_1295,(void*)0},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,(void*)0,&g_1295}},{{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,(void*)0,(void*)0},{&g_1295,&g_1295,&g_1295,&g_1295}},{{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,(void*)0,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295}},{{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,&g_1295,&g_1295,&g_1295},{&g_1295,(void*)0,&g_1295,&g_1295}}};
    uint16_t *l_1740 = &g_341[0][4];
    uint8_t l_1754 = 0x48L;
    int32_t l_1780[9] = {0L,0L,0x3CC90EC0L,0L,0L,0x3CC90EC0L,0L,0L,0x3CC90EC0L};
    int64_t l_1910 = (-3L);
    uint32_t l_1968 = 0x55D4A540L;
    int32_t *l_1969 = &g_267;
    int32_t l_1987[6][5] = {{0x4AB4DE35L,0x43C6991FL,0x43C6991FL,0x4AB4DE35L,0x65614FCCL},{1L,0x4AB4DE35L,0x2510D0E0L,0x5EC7FD4BL,0xFE77F054L},{1L,0x2510D0E0L,0x65614FCCL,0x2510D0E0L,1L},{0x4AB4DE35L,0x00F46D33L,5L,0x5EC7FD4BL,0x43C6991FL},{5L,0x00F46D33L,0x4AB4DE35L,0x4AB4DE35L,0x00F46D33L},{0x65614FCCL,0x2510D0E0L,1L,0x00F46D33L,0x43C6991FL}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1211[i] = &g_178[0][1];
    return &g_80;
}


/* ------------------------------------------ */
/* 
 * reads : g_85 g_339 g_104 g_103 g_83 g_4 g_106 g_105 g_2 g_341 g_45 g_80 g_86 g_285 g_286 g_107 g_290 g_46 g_194 g_279 g_100 g_112 g_520 g_528 g_79 g_178 g_558 g_88 g_568 g_596 g_393 g_3 g_288 g_267 g_727 g_739 g_756 g_461 g_828 g_870 g_569 g_168 g_893 g_900 g_895 g_871 g_894 g_901 g_956 g_977
 * writes: g_86 g_339 g_178 g_393 g_112 g_105 g_103 g_194 g_83 g_106 g_104 g_2 g_279 g_461 g_466 g_341 g_46 g_290 g_528 g_100 g_80 g_168 g_568 g_107 g_267 g_739 g_727 g_828 g_88 g_894 g_977
 */
static int16_t  func_145(int32_t * p_146, int16_t * p_147)
{ /* block id: 147 */
    int32_t *l_382 = &g_103;
    uint64_t l_407 = 0UL;
    uint8_t l_437 = 0x49L;
    int32_t l_539 = 0xF3D35504L;
    int32_t l_614 = 0x51ECAB5BL;
    int32_t l_615 = 1L;
    int32_t l_616 = 1L;
    int32_t l_617 = 0xD6E67917L;
    int32_t l_618 = 0xFE72E0D1L;
    int32_t l_619[5][9] = {{(-10L),(-10L),(-8L),(-10L),(-10L),(-8L),(-10L),(-10L),(-8L)},{1L,1L,5L,1L,1L,5L,1L,1L,5L},{(-10L),(-10L),(-8L),(-10L),(-10L),(-8L),(-10L),(-10L),(-8L)},{1L,1L,5L,1L,1L,5L,1L,1L,5L},{(-10L),(-10L),(-8L),(-10L),(-10L),(-8L),(-10L),(-10L),(-8L)}};
    int32_t ***l_638[4][5][10] = {{{(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,(void*)0},{&g_569,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569},{(void*)0,(void*)0,(void*)0,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569},{&g_569,&g_569,(void*)0,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569},{(void*)0,(void*)0,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569}},{{&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569},{&g_569,&g_569,(void*)0,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569},{&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569,(void*)0,(void*)0},{&g_569,&g_569,&g_569,(void*)0,(void*)0,(void*)0,&g_569,&g_569,&g_569,(void*)0},{&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569}},{{&g_569,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,(void*)0,&g_569,&g_569},{(void*)0,(void*)0,&g_569,(void*)0,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569},{(void*)0,&g_569,(void*)0,&g_569,&g_569,&g_569,(void*)0,(void*)0,&g_569,&g_569},{&g_569,(void*)0,(void*)0,(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569},{(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569}},{{(void*)0,(void*)0,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,(void*)0},{&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,(void*)0,&g_569},{(void*)0,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569,&g_569,&g_569,&g_569},{(void*)0,&g_569,(void*)0,(void*)0,&g_569,(void*)0,(void*)0,&g_569,&g_569,(void*)0},{&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,&g_569,(void*)0,&g_569,&g_569}}};
    int16_t l_698 = 0xC434L;
    uint8_t l_791[2][3];
    int16_t l_817 = 0x0E0FL;
    int8_t *l_827 = &g_107[2];
    uint64_t l_835[4] = {0xEFFCA07465493E4CLL,0xEFFCA07465493E4CLL,0xEFFCA07465493E4CLL,0xEFFCA07465493E4CLL};
    const int32_t *l_887[4];
    uint8_t *l_890 = &g_279[3][6];
    uint8_t **l_889 = &l_890;
    uint32_t **l_902[2][10] = {{&g_901[0],&g_901[1],&g_901[0],&g_901[2],&g_901[2],&g_901[0],&g_901[1],&g_901[0],&g_901[0],&g_901[0]},{&g_901[2],&g_901[1],&g_901[2],&g_901[2],&g_901[2],&g_901[1],&g_901[2],&g_901[2],&g_901[2],&g_901[2]}};
    uint8_t l_964 = 0x42L;
    uint64_t l_967 = 0xDF66205A3C076E69LL;
    int8_t l_1004 = 0L;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
            l_791[i][j] = 0xEBL;
    }
    for (i = 0; i < 4; i++)
        l_887[i] = &g_4;
lbl_426:
    (*g_85) = l_382;
    for (g_339 = 0; (g_339 <= 2); g_339 += 1)
    { /* block id: 151 */
        uint64_t *l_391 = &g_178[0][1];
        uint64_t *l_392 = &g_393;
        int8_t *l_408[2][3];
        uint64_t *l_409 = &l_407;
        int8_t l_410 = (-7L);
        int32_t **l_465 = &l_382;
        int32_t **l_472[2][4] = {{&g_168,&g_168,&g_168,&g_168},{&g_168,&g_168,&g_168,&g_168}};
        int32_t *l_543 = &g_103;
        int32_t *l_609 = &l_539;
        int32_t *l_610 = &l_539;
        int32_t *l_611 = &g_103;
        int32_t l_612 = 0xF9877452L;
        int32_t *l_613[7] = {&l_539,(void*)0,(void*)0,&l_539,(void*)0,(void*)0,&l_539};
        uint16_t l_620 = 0UL;
        int8_t l_790 = 1L;
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 3; j++)
                l_408[i][j] = &g_107[1];
        }
        if (((((((safe_sub_func_int32_t_s_s((safe_div_func_uint64_t_u_u(((*l_392) = ((*l_391) = (safe_add_func_int16_t_s_s((safe_div_func_int8_t_s_s(g_104[g_339], (*l_382))), g_104[g_339])))), (((0x3C32E632L | (safe_sub_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(g_104[g_339], ((*l_409) = ((0x2EC2ADC4L < g_104[0]) == (g_112[6][1] = ((((((safe_sub_func_uint8_t_u_u(((((~(safe_mod_func_uint64_t_u_u(((safe_mod_func_int8_t_s_s(((safe_add_func_uint16_t_u_u((g_103 , 65530UL), (*p_147))) > (*l_382)), g_339)) | g_4), (*l_382)))) != g_104[g_339]) || (*l_382)) , g_106), l_407)) > 0xD55FL) && 0UL) , g_104[g_339]) == (*l_382)) < (*p_147))))))), l_410))) || (*l_382)) && g_104[g_339]))), g_105)) , g_104[g_339]) < 0x3FL) ^ 0xFD78L) , (*l_382)) > (*l_382)))
        { /* block id: 156 */
            uint8_t *l_412 = &g_279[3][5];
            int32_t l_413[10] = {1L,0x525A970CL,1L,0x525A970CL,1L,0x525A970CL,1L,0x525A970CL,1L,0x525A970CL};
            int32_t l_423 = 0x7AD08F7DL;
            uint64_t l_474 = 0UL;
            uint8_t l_485 = 0x61L;
            int i;
            for (g_105 = 0; (g_105 >= 0); g_105 -= 1)
            { /* block id: 159 */
                uint16_t l_411 = 0xBFE9L;
                int32_t l_460[10][6][4] = {{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}},{{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L},{1L,6L,1L,6L}}};
                int16_t *l_536 = (void*)0;
                int i, j, k;
                (*l_382) &= l_411;
                for (g_194 = 0; (g_194 <= 2); g_194 += 1)
                { /* block id: 163 */
                    int32_t l_420 = 1L;
                    int32_t l_457 = 0x8412BE08L;
                    int32_t l_458[2][9][7] = {{{0xAC34FAF2L,6L,4L,(-1L),0x44E3C0BBL,(-5L),0x88E0F0D3L},{1L,(-8L),1L,0x3EBFB3FFL,(-1L),0x45990CAAL,0L},{4L,0x3EBFB3FFL,0x88E0F0D3L,(-1L),1L,1L,(-1L)},{0xD2D97CD9L,0L,0xD2D97CD9L,(-5L),1L,0x7A7F3AA6L,0xAC34FAF2L},{(-8L),0x45990CAAL,8L,0L,(-1L),6L,0x422DF22BL},{0L,8L,0x45990CAAL,(-8L),0x44E3C0BBL,0x7A7F3AA6L,0x7A7F3AA6L},{(-5L),0xD2D97CD9L,0L,0xD2D97CD9L,(-5L),1L,0x7A7F3AA6L},{(-1L),0x88E0F0D3L,0x3EBFB3FFL,4L,0x7A7F3AA6L,0x45990CAAL,0x422DF22BL},{0x3EBFB3FFL,1L,(-8L),1L,1L,(-5L),0xAC34FAF2L}},{{(-1L),4L,6L,0xAC34FAF2L,6L,4L,(-1L)},{(-5L),4L,1L,0x7A7F3AA6L,0xD2D97CD9L,(-1L),0L},{0L,1L,5L,1L,0xAC34FAF2L,0x422DF22BL,0x88E0F0D3L},{(-8L),0x88E0F0D3L,1L,0x9F8F8C14L,4L,0x9F8F8C14L,1L},{0xD2D97CD9L,0xD2D97CD9L,6L,0x9F8F8C14L,8L,0x3EBFB3FFL,1L},{4L,8L,(-8L),1L,0L,0x88E0F0D3L,1L},{1L,0x45990CAAL,0x3EBFB3FFL,0x7A7F3AA6L,8L,(-1L),8L},{0xAC34FAF2L,0L,0L,0xAC34FAF2L,4L,(-1L),5L},{0x7A7F3AA6L,0x3EBFB3FFL,0x45990CAAL,1L,0xAC34FAF2L,0x88E0F0D3L,0x9F8F8C14L}}};
                    uint16_t *l_459[2][6][7] = {{{&g_194,&g_194,&g_194,&l_411,&g_341[0][0],(void*)0,&g_339},{&g_194,&g_339,(void*)0,&g_341[0][0],&g_339,&g_339,&g_341[0][0]},{&g_341[0][4],&g_339,&l_411,&g_194,&g_339,&g_341[0][0],&g_341[0][2]},{&g_341[0][0],&g_194,&g_194,(void*)0,&g_341[0][3],&g_341[0][3],(void*)0},{&g_341[0][0],&g_339,&g_341[0][0],&g_339,&g_194,&g_339,&g_194},{&g_341[0][4],&g_194,&g_339,&g_341[0][3],&g_194,&g_341[0][0],&g_341[0][0]}},{{&g_194,&g_194,&g_341[0][2],&g_341[0][0],&g_341[0][0],&g_339,&l_411},{&g_339,&l_411,&g_339,&g_194,&g_341[0][0],&g_341[0][3],&g_194},{&g_341[0][0],&l_411,&g_194,&g_194,&l_411,&g_341[0][0],&g_341[0][0]},{&g_341[0][0],&g_341[0][0],&g_339,&g_341[0][0],&g_339,&g_339,&g_194},{&g_341[0][0],(void*)0,&g_341[0][0],&g_341[0][3],(void*)0,&g_341[0][0],&g_339},{&g_194,&g_341[0][0],(void*)0,&g_339,&g_339,&g_341[0][2],(void*)0}}};
                    int i, j, k;
                    if (((g_112[5][0] = (l_412 == &g_279[8][2])) | g_2[g_105]))
                    { /* block id: 165 */
                        uint16_t *l_424 = &l_411;
                        int32_t **l_425[9][3][3] = {{{(void*)0,&g_168,&g_168},{&g_168,&g_168,&g_168},{(void*)0,(void*)0,&g_168}},{{&g_168,&g_168,&g_168},{&g_168,(void*)0,&g_168},{&g_168,&g_168,&g_168}},{{(void*)0,&g_168,&g_168},{&g_168,&g_168,&g_168},{(void*)0,(void*)0,&g_168}},{{&g_168,&g_168,&g_168},{&g_168,(void*)0,&g_168},{&g_168,&g_168,&g_168}},{{(void*)0,&g_168,&g_168},{&g_168,&g_168,&g_168},{(void*)0,(void*)0,&g_168}},{{&g_168,&g_168,&g_168},{&g_168,(void*)0,&g_168},{&g_168,&g_168,&g_168}},{{(void*)0,&g_168,&g_168},{&g_168,&g_168,&g_168},{(void*)0,(void*)0,&g_168}},{{&g_168,&g_168,&g_168},{&g_168,(void*)0,&g_168},{&g_168,&g_168,&g_168}},{{(void*)0,&g_168,&g_168},{&g_168,&g_168,&g_168},{(void*)0,(void*)0,&g_168}}};
                        int i, j, k;
                        g_2[g_105] = ((*l_382) = (((g_2[g_105] || ((((g_104[g_339] ^= ((l_413[8] = g_341[g_105][(g_105 + 2)]) >= (0xE1C7L & ((*l_424) = (l_410 >= ((((safe_sub_func_int16_t_s_s((safe_mod_func_uint16_t_u_u((((((-1L) > g_45) == (((((g_106 = (safe_rshift_func_uint8_t_u_s(l_420, ((*l_382) && (safe_rshift_func_uint8_t_u_s(((((*p_147) = l_420) <= 9UL) , 0x5CL), 1)))))) , (*g_80)) >= (**g_85)) ^ l_420) | 0x1FF3L)) || l_411) > 0L), g_341[0][3])), l_411)) , 0x33L) != l_423) & 1L)))))) , (*g_285)) != l_425[4][2][0]) , (*l_382))) || l_411) , 0x4F6E2DEAL));
                        if (l_407)
                            goto lbl_426;
                    }
                    else
                    { /* block id: 174 */
                        int32_t *l_427 = &g_100;
                        int32_t *l_428 = &l_413[7];
                        int32_t *l_429 = &l_413[0];
                        int32_t *l_430 = &l_423;
                        int32_t *l_431 = &l_413[8];
                        int32_t *l_432 = &l_423;
                        int32_t *l_433 = (void*)0;
                        int32_t *l_434 = (void*)0;
                        int32_t *l_435 = (void*)0;
                        int32_t *l_436[9][7] = {{(void*)0,&g_4,&l_423,(void*)0,(void*)0,&l_423,&g_4},{(void*)0,&g_103,&l_413[5],(void*)0,&g_103,&g_103,(void*)0},{&l_413[5],&g_4,&l_413[5],&g_103,&g_4,&g_103,&g_103},{&g_4,(void*)0,&l_423,(void*)0,&g_4,&l_423,(void*)0},{(void*)0,&g_103,&g_103,(void*)0,&g_100,&l_423,&l_413[5]},{(void*)0,&l_413[5],&l_423,&g_100,&l_413[5],&g_100,&l_423},{&l_413[5],&l_413[5],(void*)0,&g_103,&g_103,(void*)0,&g_103},{&g_103,&l_423,&l_423,&g_103,&g_100,(void*)0,&g_103},{(void*)0,&g_103,&g_100,&g_100,&g_103,(void*)0,&l_423}};
                        int i, j;
                        l_437++;
                        return l_411;
                    }
                    (*l_382) ^= (safe_mul_func_int16_t_s_s((((g_461 = (safe_mod_func_uint16_t_u_u(l_420, (l_460[6][0][1] ^= ((!(safe_mod_func_int32_t_s_s((l_411 || (safe_sub_func_uint8_t_u_u((safe_add_func_int16_t_s_s((+((l_423 == ((((l_411 , (!(g_104[0] >= (((l_413[4] &= l_411) , ((*p_147) > (g_106 = (safe_rshift_func_uint8_t_u_s(((*l_412) = g_104[g_339]), 3))))) == (safe_add_func_uint8_t_u_u((l_458[1][1][3] = ((l_457 = ((*p_147) , 4294967288UL)) ^ 1L)), g_107[1])))))) > 0x8BL) | l_411) , 1L)) ^ l_411)), 0xC231L)), g_290))), 5UL))) > 0x2A388BEC4CC8821ALL))))) ^ 2L) <= 65529UL), g_2[0]));
                    return l_423;
                }
                if (l_413[4])
                { /* block id: 188 */
                    uint32_t l_469 = 4UL;
                    int32_t ***l_478 = &l_472[1][3];
                    int16_t *l_488 = (void*)0;
                    int16_t *l_489[8] = {&g_290,&g_290,&g_290,&g_290,&g_290,&g_290,&g_290,&g_290};
                    uint16_t *l_503 = &l_411;
                    uint16_t *l_504[5];
                    int i, j;
                    for (i = 0; i < 5; i++)
                        l_504[i] = &g_194;
                    (*g_85) = (*g_85);
                    if (((safe_mod_func_uint64_t_u_u((g_393 = ((+(((l_465 == (g_466 = &g_86)) , ((*l_412) = ((&g_286 != (void*)0) , (**l_465)))) , (safe_mul_func_int8_t_s_s(l_469, (safe_mul_func_int8_t_s_s((l_472[1][3] != (*g_285)), (g_112[6][1] = ((**l_465) == 0UL)))))))) == (*l_382))), l_460[6][3][3])) == 1L))
                    { /* block id: 194 */
                        const int8_t l_473[9][10] = {{7L,0L,0x8CL,0x05L,0x32L,(-6L),(-1L),0L,0xA5L,0x0EL},{0x7EL,0xEDL,0xAEL,0L,0x32L,0xAEL,0xDAL,0xE3L,0x96L,0xE3L},{0x32L,(-1L),0x05L,(-7L),0x05L,(-1L),0x32L,7L,0x0EL,0x32L},{0xA5L,0x95L,(-6L),0x05L,0x95L,0x0EL,(-1L),0x7EL,0x8CL,7L},{0xDAL,0x95L,0xAEL,0xE3L,0xEDL,1L,0x32L,0x32L,1L,0xEDL},{(-1L),(-1L),(-1L),(-1L),3L,7L,0xDAL,0xA5L,(-6L),(-1L)},{0xA5L,0xEDL,0x0EL,3L,0xDAL,(-1L),(-1L),0xDAL,(-6L),7L},{(-7L),0L,1L,(-1L),0x7EL,0xAEL,0x7EL,(-1L),1L,0L},{0x95L,(-1L),7L,0xE3L,0x05L,3L,0xE3L,0xA5L,0x8CL,0x95L}};
                        int i, j;
                        if (l_473[6][3])
                            break;
                        if (l_474)
                            continue;
                    }
                    else
                    { /* block id: 197 */
                        uint64_t l_475 = 18446744073709551608UL;
                        (*g_85) = (*g_85);
                        l_475++;
                        if (l_475)
                            continue;
                    }
                    if (((g_46 = ((((void*)0 == l_478) <= l_474) , (safe_mul_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s((**l_465), l_485)), 0)) , (g_194 &= (safe_lshift_func_int16_t_s_u((g_106 = ((*p_147) = (-1L))), (l_413[8] ^= ((*l_503) = (((safe_sub_func_uint64_t_u_u(((*l_391) = ((*l_382) = ((*l_409) = (**l_465)))), ((safe_rshift_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((!(safe_rshift_func_int16_t_s_u(0L, ((safe_div_func_uint16_t_u_u((--g_341[g_105][g_105]), g_46)) != g_2[0])))), 0L)) || 0xAC9A1FC3L), 7)) == l_485))) >= l_485) ^ 0L))))))), g_279[8][0])))) > 3L))
                    { /* block id: 212 */
                        return (*p_147);
                    }
                    else
                    { /* block id: 214 */
                        int16_t l_513 = 3L;
                        int32_t l_521 = 0L;
                        (**l_465) = (safe_mod_func_int16_t_s_s((0xDCC9L != (g_100 < ((safe_mod_func_uint8_t_u_u(((((safe_sub_func_int64_t_s_s(((g_290 |= 0x4BC8L) & (safe_mul_func_int8_t_s_s((**l_465), (((l_513 = (-1L)) == (safe_mul_func_uint16_t_u_u(((*p_147) && (safe_mod_func_uint16_t_u_u(l_411, g_112[6][1]))), (safe_div_func_uint16_t_u_u((0L && l_413[8]), (*p_147)))))) == g_520)))), (-1L))) == 1UL) <= l_411) , l_469), l_521)) == (*l_382)))), g_104[0]));
                    }
                }
                else
                { /* block id: 219 */
                    int32_t l_538 = 0x9BF58223L;
                    for (l_410 = 0; (l_410 <= 2); l_410 += 1)
                    { /* block id: 222 */
                        uint8_t *l_526 = (void*)0;
                        uint8_t *l_527[7][9][4] = {{{&l_485,&l_485,&l_437,&l_485},{&l_485,&l_485,(void*)0,&l_485},{&l_437,(void*)0,&l_485,&l_437},{&l_437,(void*)0,&l_485,(void*)0},{&l_485,(void*)0,&l_485,&l_437},{&l_485,(void*)0,&l_485,&l_485},{&l_437,&l_485,&l_437,&l_485},{&l_485,&l_485,&l_437,&l_485},{(void*)0,&l_485,&l_437,&l_437}},{{&l_485,&l_437,&l_437,&l_485},{&l_437,&l_437,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_437,&l_485,&l_485,&l_485},{&l_437,&l_437,(void*)0,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_437,&l_485,&l_437,(void*)0},{&l_437,&l_437,&l_485,(void*)0}},{{&l_485,(void*)0,&l_485,&l_485},{&l_437,&l_485,(void*)0,&l_485},{&l_485,&l_485,&l_437,&l_437},{(void*)0,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_437,(void*)0,&l_485,(void*)0},{&l_437,&l_437,&l_437,(void*)0},{&l_485,&l_485,&l_437,&l_485},{&l_437,&l_485,&l_485,(void*)0}},{{&l_437,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{(void*)0,&l_485,&l_437,&l_485},{&l_485,&l_485,(void*)0,&l_485},{&l_437,&l_485,&l_485,(void*)0},{&l_485,&l_485,&l_485,&l_485},{&l_437,&l_485,&l_437,(void*)0},{&l_437,&l_437,&l_485,(void*)0},{&l_485,(void*)0,&l_485,&l_485}},{{&l_437,&l_485,(void*)0,&l_485},{&l_485,&l_485,&l_437,&l_437},{(void*)0,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_437,(void*)0,&l_485,(void*)0},{&l_437,&l_437,&l_437,(void*)0},{&l_485,&l_485,&l_437,&l_485},{&l_437,&l_485,&l_485,(void*)0},{&l_437,&l_485,&l_485,&l_485}},{{&l_485,&l_485,&l_485,&l_485},{(void*)0,&l_485,&l_437,&l_485},{&l_485,&l_485,(void*)0,&l_485},{&l_437,&l_485,&l_485,(void*)0},{&l_485,&l_485,&l_485,&l_485},{&l_437,&l_485,&l_437,(void*)0},{&l_437,&l_437,&l_485,(void*)0},{&l_485,(void*)0,&l_485,&l_485},{&l_437,&l_485,(void*)0,&l_485}},{{&l_485,&l_485,&l_437,&l_437},{(void*)0,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485},{&l_437,(void*)0,&l_485,(void*)0},{&l_437,&l_437,&l_437,(void*)0},{&l_485,&l_485,&l_437,&l_485},{&l_437,&l_485,&l_485,(void*)0},{&l_437,&l_485,&l_485,&l_485},{&l_485,&l_485,&l_485,&l_485}}};
                        uint32_t l_533[5];
                        int16_t *l_537 = &g_106;
                        int32_t *l_540 = (void*)0;
                        int32_t l_541 = 1L;
                        int i, j, k;
                        for (i = 0; i < 5; i++)
                            l_533[i] = 0UL;
                        g_100 = ((((*l_409) ^= (l_413[1] | ((((safe_div_func_uint8_t_u_u(((safe_div_func_uint64_t_u_u((((((g_528 ^= (l_460[6][0][1] |= ((*l_412) &= l_413[8]))) >= 0x72L) , (((safe_add_func_uint8_t_u_u(0x0BL, ((!((!0x5A90446446AF94CBLL) ^ (((((*l_537) ^= (l_533[1] <= (((safe_sub_func_uint16_t_u_u(((((*l_382) = (-10L)) , l_536) != &g_106), (*p_147))) , 0L) ^ l_413[8]))) && (*p_147)) || 0x4EL) <= l_538))) > 0x57B1C7FEL))) <= l_411) , l_460[6][0][1])) == 18446744073709551615UL) , l_460[9][2][2]), 1L)) , l_460[3][2][3]), 0x81L)) <= l_423) == g_104[1]) , 1UL))) >= g_105) , 0x4E167334L);
                        (*g_85) = func_38((*g_85), l_539);
                        (*l_382) &= 0x4EE99C37L;
                        l_541 &= ((**l_465) = (&l_485 == (l_413[8] , l_526)));
                    }
                    (*g_79) = func_38((*g_79), g_178[1][1]);
                }
                (**l_465) = (**g_85);
            }
            if ((**l_465))
                break;
        }
        else
        { /* block id: 240 */
            uint32_t l_542 = 0UL;
            int32_t *l_555[4] = {&g_105,&g_105,&g_105,&g_105};
            int32_t l_608 = (-7L);
            int i;
            if ((**l_465))
            { /* block id: 241 */
                uint64_t **l_560[1];
                int32_t l_562 = 0xEB4C5A0FL;
                int i;
                for (i = 0; i < 1; i++)
                    l_560[i] = &l_392;
                for (g_83 = 0; (g_83 <= 2); g_83 += 1)
                { /* block id: 244 */
                    int32_t l_561[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
                    int i;
                    (*l_382) |= l_542;
                    (*l_382) = 1L;
                    for (g_461 = 0; (g_461 <= 2); g_461 += 1)
                    { /* block id: 249 */
                        if ((**g_85))
                            break;
                        (*g_85) = l_543;
                    }
                    if ((l_561[8] = ((**l_465) = (safe_mod_func_int32_t_s_s((*g_80), (safe_mod_func_int16_t_s_s(((((g_279[0][5] <= 18446744073709551615UL) && ((+((safe_div_func_int32_t_s_s((*l_382), ((((safe_mul_func_uint8_t_u_u(((((g_104[g_83] &= (safe_mul_func_uint8_t_u_u((0x86A6AA8DL > ((g_168 = l_555[2]) != (void*)0)), (safe_lshift_func_int16_t_s_u((*p_147), 3))))) & (g_558[0][0] != l_560[0])) == (-5L)) & (*p_147)), g_88)) ^ l_561[8]) < 0L) | 0xF67FL))) == 0UL)) != (*l_382))) > g_279[4][7]) == l_542), g_339)))))))
                    { /* block id: 257 */
                        uint32_t *l_563 = &g_528;
                        (*g_85) = func_38(func_38(func_38(p_146, l_562), g_105), ((*l_563)++));
                    }
                    else
                    { /* block id: 260 */
                        int32_t ****l_570 = &g_568;
                        int32_t l_601 = 0xF54FC083L;
                        (*g_79) = func_38(func_38((*g_85), l_542), (safe_sub_func_int64_t_s_s((((*l_570) = g_568) != (void*)0), (safe_div_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_s(0x907DL, ((-1L) >= (safe_lshift_func_int8_t_s_u((safe_div_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s(g_103, (safe_rshift_func_uint16_t_u_u((g_104[g_83] != 0x3CL), 15)))) , 0L), l_562)), l_561[8])), l_562))))) >= (*l_382)), g_45)), 0xE6L)), l_542)), (*l_382))))));
                        if (l_562)
                            continue;
                        l_608 &= (safe_sub_func_uint16_t_u_u((((safe_unary_minus_func_uint8_t_u((((((((safe_mod_func_int16_t_s_s((g_596 ^ (*l_543)), (safe_mod_func_int64_t_s_s(((void*)0 != p_146), (safe_sub_func_int8_t_s_s(l_562, l_601)))))) | g_107[2]) , 0x58BC244DL) ^ (safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((safe_rshift_func_int16_t_s_u((l_562 < 0xF9L), 3)), (*p_147))), g_279[8][7]))) >= l_562) ^ (**l_465)) , 0x35L))) & l_561[8]) & l_542), 1UL));
                    }
                }
                return g_112[6][1];
            }
            else
            { /* block id: 268 */
                return (*p_147);
            }
        }
        l_620--;
        for (g_528 = 1; (g_528 <= 6); g_528 += 1)
        { /* block id: 275 */
            uint8_t l_626 = 0x64L;
            int16_t l_637 = 6L;
            int32_t **l_650 = &g_168;
            int32_t * const *l_651 = (void*)0;
            int32_t l_681 = 1L;
            int64_t l_682 = 0x84E1E6BFC4E54378LL;
            uint64_t *l_707 = &l_407;
            uint64_t l_708 = 0xCEDF65FED4551096LL;
            int32_t **l_730 = &l_609;
            uint32_t *l_740 = &g_727;
            for (g_393 = 2; (g_393 <= 7); g_393 += 1)
            { /* block id: 278 */
                int32_t ****l_639 = &g_568;
                int32_t l_645 = 5L;
                for (l_410 = 1; (l_410 <= 7); l_410 += 1)
                { /* block id: 281 */
                    int i;
                    (*l_609) = ((*l_611) = (g_107[(g_339 + 1)] && (!(((safe_mod_func_int32_t_s_s((l_626 >= (((safe_lshift_func_int16_t_s_u((g_341[0][0] ^ (safe_rshift_func_int8_t_s_u((((safe_sub_func_uint16_t_u_u(0x416FL, ((safe_add_func_int8_t_s_s((&g_86 == (void*)0), (((((*l_409) = (l_626 < ((*l_382) ^ ((safe_mul_func_int8_t_s_s((**l_465), g_107[2])) >= (*l_382))))) , l_637) & l_626) & g_3))) > 1UL))) >= g_88) > 1UL), (*l_382)))), 6)) || (-3L)) >= (*l_382))), (*l_382))) > 0L) || 0x52L))));
                    if ((**g_79))
                        break;
                }
                (*l_609) = (((*l_382) = (((*l_639) = l_638[3][1][7]) == &l_472[0][2])) , (safe_sub_func_int8_t_s_s((!((((~((~(*p_147)) && g_290)) < ((((*l_382) ^ ((l_645 | (safe_rshift_func_int8_t_s_s(g_104[0], (safe_mod_func_uint32_t_u_u(((l_650 = ((*l_382) , &g_168)) != l_651), (*l_382)))))) & g_520)) <= l_637) < 4294967291UL)) , 1UL) <= g_178[0][2])), g_105)));
                return (*p_147);
            }
            if ((((*l_611) , (*l_611)) == ((((safe_mod_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((0xB4L == (**l_465)) & g_596), (safe_div_func_int8_t_s_s(((((*l_391) = 1UL) > (safe_add_func_int16_t_s_s(((*p_147) &= (((&l_472[1][3] != (void*)0) < ((0xA6CE2C10394931B5LL && 18446744073709551615UL) != 9L)) && (*l_609))), 0x1E8BL))) , (**l_465)), 1L)))), g_279[8][2])), 0xE7B11C59L)) == (*l_382)) && (-1L)) & (*l_382))))
            { /* block id: 295 */
                int32_t ***l_679[5];
                const int32_t l_691 = 0x7F7864C5L;
                int i;
                for (i = 0; i < 5; i++)
                    l_679[i] = &l_472[1][1];
                for (l_637 = 2; (l_637 <= 6); l_637 += 1)
                { /* block id: 298 */
                    int32_t **l_662 = (void*)0;
                    int64_t *l_680[2];
                    uint16_t *l_683 = &g_341[0][0];
                    int32_t l_684[3][7][1] = {{{9L},{(-6L)},{9L},{9L},{(-6L)},{9L},{9L}},{{(-6L)},{9L},{9L},{(-6L)},{9L},{9L},{(-6L)}},{{9L},{9L},{(-6L)},{9L},{9L},{(-6L)},{9L}}};
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                        l_680[i] = &g_104[g_339];
                    if (((*g_79) == (((((l_662 != ((safe_sub_func_int8_t_s_s((((safe_add_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((*l_382), (g_279[(g_528 + 1)][(g_339 + 3)] = ((safe_add_func_uint16_t_u_u(((*l_683) = (safe_lshift_func_int16_t_s_u(((((l_681 = (1L != (((((safe_lshift_func_int8_t_s_u((safe_lshift_func_int8_t_s_u((g_107[2] = (-1L)), 2)), 7)) , (g_112[5][2] = ((safe_add_func_uint64_t_u_u(18446744073709551615UL, ((*l_391) = 18446744073709551611UL))) ^ l_626))) , ((g_4 , l_679[2]) == (void*)0)) , g_194) || (*p_147)))) , 0x8910L) | 0xC50FL) , l_682), (*l_382)))), l_684[0][0][0])) > l_637)))), l_626)) , (*p_147)) , 0x43L), 0x34L)) , (*g_285))) , (*l_382)) & (*l_610)) & l_637) , (void*)0)))
                    { /* block id: 305 */
                        return l_684[1][5][0];
                    }
                    else
                    { /* block id: 307 */
                        l_684[0][0][0] |= (*g_86);
                        (*l_611) ^= (**g_79);
                    }
                    if ((((safe_mod_func_int16_t_s_s(((*p_147) = (safe_lshift_func_uint8_t_u_u((g_290 < l_637), 0))), g_288)) != (l_681 ^ g_100)) , ((*l_611) = ((*l_609) = ((safe_sub_func_int16_t_s_s(0x66DEL, l_691)) > ((safe_div_func_uint16_t_u_u(((((safe_add_func_int64_t_s_s(g_88, 18446744073709551612UL)) > l_626) && l_626) != 1UL), g_83)) , l_691))))))
                    { /* block id: 314 */
                        return g_279[(g_528 + 1)][(g_339 + 3)];
                    }
                    else
                    { /* block id: 316 */
                        uint8_t *l_697 = (void*)0;
                        uint8_t **l_696 = &l_697;
                        l_681 &= (**g_85);
                        l_698 = ((g_279[(g_528 + 1)][(g_339 + 3)] , ((*l_543) &= 0x5F836058B7B3C79BLL)) < (0xEF718796EB5DE969LL ^ ((l_684[1][0][0] == l_691) | (((*l_696) = &l_437) == &g_279[8][2]))));
                        if ((**g_85))
                            continue;
                        if ((*l_382))
                            continue;
                    }
                    return g_105;
                }
                if ((*g_86))
                    continue;
                (*l_610) = (l_691 && (safe_mul_func_uint16_t_u_u(0x90D7L, (safe_lshift_func_int8_t_s_s(((*l_382) ^= g_83), (g_46 <= g_393))))));
            }
            else
            { /* block id: 329 */
                int8_t l_705[5] = {0xBDL,0xBDL,0xBDL,0xBDL,0xBDL};
                uint16_t *l_726 = &g_339;
                int i;
                for (l_437 = 0; (l_437 <= 6); l_437 += 1)
                { /* block id: 332 */
                    (*l_609) = (*g_80);
                }
                (*l_609) = ((*l_382) = (safe_rshift_func_int8_t_s_s(l_705[2], 6)));
                for (g_46 = 0; (g_46 <= 1); g_46 += 1)
                { /* block id: 339 */
                    uint32_t l_706 = 0UL;
                    (*l_610) = l_681;
                    for (g_267 = 1; (g_267 >= 0); g_267 -= 1)
                    { /* block id: 343 */
                        int i;
                        l_613[(g_267 + 3)] = func_38((*g_85), l_706);
                    }
                    if ((l_707 == l_409))
                    { /* block id: 346 */
                        uint8_t *l_719 = &g_279[7][5];
                        (*l_543) = ((l_708 != (((safe_mul_func_int8_t_s_s(0x71L, (safe_lshift_func_int16_t_s_u(((*l_382) ^ (safe_sub_func_int32_t_s_s((((safe_mul_func_uint8_t_u_u(g_528, 0x1AL)) | 0x0B88D4948A77B1D8LL) || ((*p_147) , ((-1L) == ((*l_719) |= (l_681 & 0x2F9DL))))), (*g_86)))), g_88)))) , (*l_610)) , g_194)) ^ 18446744073709551615UL);
                        (*l_610) ^= (((0xE8L != ((l_706 == ((void*)0 != p_147)) | ((safe_add_func_uint16_t_u_u((g_341[0][2] > (l_726 != l_726)), 0x9FC9L)) , (*l_382)))) , g_88) | l_705[2]);
                    }
                    else
                    { /* block id: 350 */
                        return g_727;
                    }
                }
            }
            (*l_610) = ((((((safe_sub_func_uint32_t_u_u(((void*)0 == l_730), ((((((((((((*l_707) ^= (safe_mod_func_uint64_t_u_u((((safe_div_func_uint32_t_u_u((!(*l_382)), (*g_86))) != (0x2FF21F11F1EE8281LL < (((*p_147) , func_57(p_146, ((*l_740) &= ((l_681 &= (g_739 |= ((~(safe_sub_func_uint16_t_u_u(1UL, ((**l_465) , 0xA411L)))) && (**l_730)))) > (**l_730))), (**l_730))) != (void*)0))) && (**l_465)), (**l_730)))) , (**l_730)) < 249UL) <= (*l_382)) & (**l_730)) , (*l_543)) , &g_727) != l_740) || (*l_543)) , 1L) != (*l_382)))) , 0L) & 0x9E71L) , g_739) ^ (**l_730)) > (*l_382));
        }
        for (g_106 = 3; (g_106 == (-22)); g_106 = safe_sub_func_int16_t_s_s(g_106, 4))
        { /* block id: 363 */
            int32_t ***l_754 = &g_569;
            int32_t l_757 = 0x052FBB94L;
            int8_t *l_775 = &g_112[6][1];
            uint64_t l_804 = 0xB28463F0DD86A1E0LL;
        }
    }
    for (g_103 = 3; (g_103 >= 0); g_103 -= 1)
    { /* block id: 415 */
        int64_t *l_824 = (void*)0;
        int64_t *l_825 = (void*)0;
        int64_t *l_826 = (void*)0;
        int32_t l_829 = 0x1AF014FCL;
        uint32_t l_830 = 4294967292UL;
        uint16_t *l_831 = &g_341[0][0];
        int32_t l_832 = 3L;
        uint8_t *l_848 = (void*)0;
        int8_t *l_854 = &g_112[6][1];
        uint64_t l_920 = 0UL;
        uint8_t l_949 = 0x2EL;
        int32_t l_962 = 0xE4364C6EL;
        int32_t l_963[5];
        int32_t l_1001 = 1L;
        int32_t l_1003 = 1L;
        uint32_t **l_1005[6][5] = {{&g_901[2],(void*)0,(void*)0,&g_901[1],(void*)0},{&g_901[2],(void*)0,&g_901[1],&g_901[1],(void*)0},{&g_901[2],(void*)0,&g_901[1],&g_901[1],(void*)0},{&g_901[2],(void*)0,(void*)0,&g_901[1],(void*)0},{&g_901[2],(void*)0,&g_901[1],&g_901[1],(void*)0},{&g_901[2],(void*)0,&g_901[1],&g_901[1],(void*)0}};
        int i, j;
        for (i = 0; i < 5; i++)
            l_963[i] = 0x7CDE79B6L;
        if ((((g_178[0][2] ^ (((safe_rshift_func_int16_t_s_s((((l_829 = (safe_lshift_func_int8_t_s_s((((*l_831) = ((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(((-9L) | 0x66FD03C9L), (l_817 , ((safe_div_func_int16_t_s_s((g_106 = (((safe_mod_func_int16_t_s_s(((l_830 = ((((g_528 | (safe_lshift_func_int16_t_s_u(((((*l_382) <= (g_104[2] = (*l_382))) & ((((g_828 = l_827) == (void*)0) , l_829) | 0x2D6DBA76FC7F06DELL)) , 0xF2F2L), g_756))) , 0x0122L) && (*l_382)) & 0x81F42D50L)) > 0xB1CF757EL), 0x5296L)) , (void*)0) == p_147)), l_829)) | l_829)))), g_393)), 12)) , (*l_382))) >= 0x6D5EL), 2))) , 9L) == l_832), g_4)) , &g_290) == (void*)0)) && (-9L)) != g_279[4][1]))
        { /* block id: 422 */
            int32_t *l_833 = &g_461;
            int32_t *l_834[9] = {&l_829,(void*)0,&l_829,(void*)0,&l_829,(void*)0,&l_829,(void*)0,&l_829};
            uint8_t **l_849 = &l_848;
            int i;
            ++l_835[0];
            g_739 &= (safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((*p_147) <= (((safe_sub_func_int64_t_s_s(((((safe_mod_func_uint32_t_u_u((((*l_849) = l_848) != (void*)0), ((((-1L) ^ l_829) | ((g_279[6][4] = l_832) , (safe_mod_func_int16_t_s_s((((*l_833) = (g_88 &= ((safe_add_func_int64_t_s_s(((g_341[0][1] , (g_106 |= ((l_854 != (void*)0) & (*l_382)))) , g_520), (*l_833))) >= (*g_828)))) , (*l_382)), l_829)))) ^ g_194))) , (*g_828)) && g_46) == (*l_382)), (-9L))) | (-2L)) , 0xA116L)), (*p_147))), 0x3DL)), (*l_382)));
            if ((*g_80))
                continue;
        }
        else
        { /* block id: 431 */
            uint64_t l_856 = 0x2FB9CC8F7758FE24LL;
            const int32_t *l_864 = &g_103;
            int32_t *l_872 = (void*)0;
            int32_t l_922[10][10][2] = {{{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL},{0x4DF7A7CDL,2L},{(-7L),(-1L)},{0x042BE963L,(-7L)},{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL}},{{0x042BE963L,0x4DF7A7CDL},{0x4DF7A7CDL,2L},{(-7L),(-1L)},{0x042BE963L,(-7L)},{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL}},{{0x4DF7A7CDL,2L},{(-7L),(-1L)},{0x042BE963L,(-7L)},{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL},{0x4DF7A7CDL,2L}},{{(-7L),(-1L)},{0x042BE963L,(-7L)},{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL},{0x4DF7A7CDL,2L},{(-7L),(-1L)}},{{0x042BE963L,(-7L)},{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL},{0x4DF7A7CDL,2L},{(-7L),(-1L)},{0x042BE963L,(-7L)}},{{(-1L),2L},{(-1L),(-7L)},{0x042BE963L,(-1L)},{(-7L),2L},{0x4DF7A7CDL,0x4DF7A7CDL},{0x042BE963L,0x4DF7A7CDL},{0x042BE963L,0x1FAA84D5L},{2L,0xC95B5688L},{(-8L),2L},{0xC95B5688L,0x1FAA84D5L}},{{0xC95B5688L,2L},{(-8L),0xC95B5688L},{2L,0x1FAA84D5L},{0x042BE963L,0x042BE963L},{(-8L),0x042BE963L},{0x042BE963L,0x1FAA84D5L},{2L,0xC95B5688L},{(-8L),2L},{0xC95B5688L,0x1FAA84D5L},{0xC95B5688L,2L}},{{(-8L),0xC95B5688L},{2L,0x1FAA84D5L},{0x042BE963L,0x042BE963L},{(-8L),0x042BE963L},{0x042BE963L,0x1FAA84D5L},{2L,0xC95B5688L},{(-8L),2L},{0xC95B5688L,0x1FAA84D5L},{0xC95B5688L,2L},{(-8L),0xC95B5688L}},{{2L,0x1FAA84D5L},{0x042BE963L,0x042BE963L},{(-8L),0x042BE963L},{0x042BE963L,0x1FAA84D5L},{2L,0xC95B5688L},{(-8L),2L},{0xC95B5688L,0x1FAA84D5L},{0xC95B5688L,2L},{(-8L),0xC95B5688L},{2L,0x1FAA84D5L}},{{0x042BE963L,0x042BE963L},{(-8L),0x042BE963L},{0x042BE963L,0x1FAA84D5L},{2L,0xC95B5688L},{(-8L),2L},{0xC95B5688L,0x1FAA84D5L},{0xC95B5688L,2L},{(-8L),0xC95B5688L},{2L,0x1FAA84D5L},{0x042BE963L,0x042BE963L}}};
            int32_t l_923 = 0L;
            uint64_t l_938 = 0x9ABDF2FABD5F37DELL;
            uint64_t *l_945 = (void*)0;
            uint64_t *l_946[9][7] = {{&l_835[2],&l_835[2],&g_393,&l_856,&g_393,&l_835[2],&l_835[2]},{&l_835[0],&l_938,&g_178[0][1],&l_938,&l_835[0],&l_835[0],&l_938},{&l_920,&l_920,&l_920,&g_393,&g_393,&l_920,&l_920},{&l_938,&l_407,&g_178[0][1],&g_178[0][1],&l_407,&l_938,&l_407},{&l_920,&g_393,&g_393,&l_920,&l_920,&l_920,&g_393},{&l_835[0],&l_835[0],&l_938,&g_178[0][1],&l_938,&l_835[0],&l_835[0]},{&l_835[2],&g_393,&l_856,&g_393,&l_835[2],&l_835[2],&g_393},{&l_920,&l_407,&l_920,&l_938,&l_938,&l_920,&l_407},{&g_393,&l_920,&l_856,&l_856,&l_920,&g_393,&l_920}};
            uint16_t *l_950 = &g_339;
            int i, j, k;
            for (g_339 = 0; (g_339 <= 3); g_339 += 1)
            { /* block id: 434 */
                uint8_t l_855 = 0xF9L;
                int32_t l_873[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_873[i] = 0x3BDCE4A7L;
                if (l_855)
                    break;
                (*g_79) = (*g_79);
                for (l_614 = 0; (l_614 <= 3); l_614 += 1)
                { /* block id: 439 */
                    uint64_t l_884 = 0x43EEB25BD8254261LL;
                    for (g_461 = 0; (g_461 <= 3); g_461 += 1)
                    { /* block id: 442 */
                        int16_t l_874 = 0L;
                        int32_t *l_875 = &l_619[0][8];
                        int32_t *l_876 = &g_100;
                        int32_t *l_877 = (void*)0;
                        int32_t *l_878 = &g_267;
                        int32_t *l_879 = (void*)0;
                        int32_t *l_880 = (void*)0;
                        int32_t *l_881 = &l_619[4][8];
                        int32_t *l_882 = (void*)0;
                        int32_t *l_883 = &g_739;
                        if (l_856)
                            break;
                        l_873[0] &= (safe_lshift_func_uint16_t_u_s((!((safe_rshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u((((l_872 = func_38(l_864, ((safe_unary_minus_func_uint8_t_u((safe_rshift_func_int16_t_s_s(((safe_sub_func_int64_t_s_s((((*g_80) < (p_147 != ((l_829 = ((g_112[9][0] , (void*)0) != ((0xEB44C80FL & 0xA6A72248L) , g_870[0][2]))) , (void*)0))) , l_829), 0x1506253C3ADDF96ALL)) & 0x055FL), l_855)))) ^ 0x1AL))) != (**g_568)) & 0x7349DE6748BC6336LL), 14)), (*g_828))) & 0x05CAEF96L)), 1));
                        l_884--;
                    }
                }
            }
            if ((*g_80))
                break;
            for (g_105 = 0; (g_105 <= 3); g_105 += 1)
            { /* block id: 454 */
                int64_t l_888 = 1L;
                uint32_t ***l_903 = &l_902[1][8];
                int32_t *l_908[2];
                uint32_t l_921 = 0x1927BEC5L;
                int64_t l_942 = 7L;
                int i;
                for (i = 0; i < 2; i++)
                    l_908[i] = &l_618;
                (*g_85) = ((*g_79) = func_38(l_887[0], l_888));
                (*g_893) = l_889;
                for (l_829 = 0; l_829 < 4; l_829 += 1)
                {
                    g_107[l_829] = 0xEFL;
                }
                l_922[3][0][0] = ((safe_div_func_int32_t_s_s(((((safe_mod_func_uint16_t_u_u(((g_900 == ((*l_903) = l_902[1][6])) == (((0x1736L ^ ((*l_831)--)) & (*g_895)) > (safe_add_func_int32_t_s_s((l_908[0] == ((*g_85) = l_872)), (g_739 = ((safe_add_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_u(((((*l_864) ^ (((safe_div_func_uint8_t_u_u(((0x998AL < ((safe_lshift_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((+(*g_871)), 7)), (*l_864))) , (*l_382))) , l_920), 0x4BL)) == l_920) , (*g_828))) , l_829) , 65535UL), g_104[0])) , (*g_80)), 0xDC90F7C7L)) == 0x36L)))))), 0x4F54L)) != l_921) , (*l_864)) ^ g_461), (*l_864))) | l_830);
                for (g_290 = 3; (g_290 >= 0); g_290 -= 1)
                { /* block id: 466 */
                    int16_t *l_939 = &g_106;
                    int32_t l_940 = 1L;
                    int32_t l_941 = 6L;
                    g_88 = ((l_923 || (safe_lshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((l_922[3][0][0] = 0xCD007C0FL) , (l_941 ^= (((0x27BAL >= (safe_add_func_uint16_t_u_u((safe_add_func_int16_t_s_s((*p_147), (safe_mod_func_int8_t_s_s((((((((*l_939) = ((((*l_864) && (l_938 = (safe_rshift_func_int16_t_s_s(((*g_828) , (safe_mul_func_int8_t_s_s((l_922[3][0][0] ^= (*l_864)), (*g_828)))), (*g_871))))) ^ (*g_895)) && l_830)) , 0L) & (*l_864)) || (**g_894)) & l_940) || l_830), (*l_382))))), 0x2A99L))) == 18446744073709551613UL) ^ (*p_147)))), l_942)), 7))) || l_941);
                    (*g_79) = func_38((*g_79), (**g_900));
                }
            }
            if ((safe_sub_func_uint16_t_u_u(((*l_950) |= ((((l_832 = (*l_864)) < (&g_568 == (void*)0)) || (g_341[0][4] <= (l_832 & (*l_864)))) || (l_830 , (((safe_mul_func_uint8_t_u_u(1UL, (((l_949 = ((*g_828) <= l_829)) < g_100) , 0x19L))) >= 0xEF27L) , g_520)))), 0xEBCEL)))
            { /* block id: 479 */
                const int32_t *l_954[3];
                const int32_t **l_953[6][8] = {{&l_954[1],&l_954[0],&l_954[0],(void*)0,&l_954[0],&l_954[0],&l_954[1],&l_954[0]},{(void*)0,&l_954[1],(void*)0,&l_954[1],(void*)0,&l_954[0],&l_954[0],&l_954[0]},{&l_954[2],&l_954[0],&l_954[1],&l_954[0],&l_954[1],&l_954[1],&l_954[0],&l_954[1]},{&l_954[0],&l_954[0],&l_954[1],&l_954[1],&l_954[0],&l_954[0],&l_954[0],&l_954[2]},{&l_954[1],&l_954[0],(void*)0,&l_954[0],(void*)0,&l_954[0],&l_954[1],(void*)0},{&l_954[1],&l_954[1],(void*)0,&l_954[0],&l_954[0],&l_954[1],&l_954[1],&l_954[0]}};
                const int32_t ***l_952[7][8] = {{&l_953[0][1],(void*)0,(void*)0,&l_953[0][1],&l_953[0][1],(void*)0,&l_953[3][0],(void*)0},{&l_953[0][1],(void*)0,(void*)0,&l_953[0][1],&l_953[0][7],&l_953[0][1],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&l_953[0][0],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_953[3][0],&l_953[3][0],(void*)0,(void*)0,(void*)0,&l_953[0][7]},{&l_953[3][0],&l_953[3][0],(void*)0,(void*)0,(void*)0,&l_953[0][1],(void*)0,(void*)0},{(void*)0,&l_953[0][1],(void*)0,(void*)0,(void*)0,&l_953[3][0],&l_953[3][0],&l_953[0][7]},{(void*)0,(void*)0,(void*)0,&l_953[3][0],&l_953[3][0],(void*)0,(void*)0,(void*)0}};
                const int32_t ****l_951 = &l_952[3][4];
                int32_t *l_957 = &l_617;
                int32_t *l_958 = &l_619[0][8];
                int32_t *l_959 = &l_619[0][8];
                int32_t *l_960 = &l_615;
                int32_t *l_961[5];
                int i, j;
                for (i = 0; i < 3; i++)
                    l_954[i] = &g_955;
                for (i = 0; i < 5; i++)
                    l_961[i] = &g_267;
                (*g_956) = (((*l_951) = (void*)0) == (void*)0);
                l_964--;
                --l_967;
            }
            else
            { /* block id: 484 */
                l_864 = func_38(p_146, (*l_382));
            }
        }
        for (g_727 = 0; (g_727 <= 3); g_727 += 1)
        { /* block id: 490 */
            int32_t *l_970 = &l_829;
            int32_t *l_971 = &g_88;
            int32_t *l_972 = &g_739;
            int32_t *l_973[7][10][3] = {{{&l_617,&g_461,&g_739},{&g_100,&l_619[0][4],&g_4},{&l_619[2][6],&l_616,&l_829},{&l_615,&l_539,&g_4},{&l_539,&l_614,(void*)0},{&g_100,&l_618,&g_267},{(void*)0,&l_963[3],(void*)0},{&l_619[0][4],&l_963[0],&l_963[4]},{&l_619[0][8],&l_617,&l_619[0][8]},{(void*)0,&l_963[0],&l_618}},{{(void*)0,&l_615,&l_617},{&l_832,&l_616,(void*)0},{(void*)0,&g_267,&g_739},{&l_832,&l_619[2][8],&g_739},{(void*)0,&g_739,(void*)0},{(void*)0,(void*)0,&l_829},{&l_619[0][8],(void*)0,(void*)0},{&l_619[0][4],&g_100,&l_963[3]},{(void*)0,(void*)0,&g_739},{&g_100,&g_4,(void*)0}},{{&l_539,&g_739,&l_963[3]},{&l_615,&l_615,&l_832},{&l_619[2][6],&l_619[2][6],&l_539},{&g_100,&l_829,(void*)0},{&l_617,(void*)0,&l_615},{(void*)0,&l_619[0][7],&l_963[0]},{&l_616,&l_617,&l_615},{(void*)0,&l_963[3],(void*)0},{&l_829,(void*)0,&l_539},{&l_616,&l_829,&l_832}},{{&l_615,&l_615,&l_963[3]},{&g_461,&g_100,(void*)0},{&l_963[1],&g_739,&g_739},{(void*)0,&g_267,&l_963[3]},{&l_963[1],(void*)0,(void*)0},{&l_963[3],&l_829,&l_829},{&l_616,(void*)0,(void*)0},{&l_963[4],(void*)0,&g_739},{&g_461,&g_739,&g_739},{&l_829,&g_4,(void*)0}},{{(void*)0,&g_739,&l_617},{&l_616,(void*)0,&l_618},{(void*)0,&l_539,&l_617},{&g_88,&l_963[3],&l_963[0]},{(void*)0,(void*)0,&l_614},{(void*)0,&g_4,(void*)0},{(void*)0,&l_618,&l_962},{&l_539,(void*)0,&g_267},{&l_539,&g_461,&l_615},{&l_616,&g_100,&l_616}},{{(void*)0,&g_739,&l_618},{(void*)0,&l_832,&g_100},{(void*)0,&g_739,&l_829},{(void*)0,&l_615,&l_618},{(void*)0,(void*)0,&g_88},{(void*)0,(void*)0,&l_616},{(void*)0,&l_539,&l_615},{&l_616,&l_616,(void*)0},{&l_539,(void*)0,&l_619[0][3]},{&l_539,&g_267,&g_100}},{{(void*)0,&l_614,(void*)0},{(void*)0,&l_963[1],(void*)0},{(void*)0,&g_739,(void*)0},{&g_88,&g_88,(void*)0},{(void*)0,&l_963[1],&l_539},{&l_829,&l_539,(void*)0},{&l_829,(void*)0,&g_739},{&l_963[3],&l_829,(void*)0},{(void*)0,&l_619[0][3],&l_539},{&l_963[0],&l_962,(void*)0}}};
            int16_t l_974 = 0x1DFCL;
            int64_t l_976 = 0xD44180948B379CEALL;
            uint16_t *l_1002 = &g_339;
            uint32_t * const *l_1006 = &g_901[1];
            int i, j, k;
            g_977--;
            (*g_85) = p_146;
            l_619[4][8] = (~(safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s((safe_div_func_int64_t_s_s((l_1003 ^= (safe_add_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u(l_832, ((*l_1002) = (safe_lshift_func_uint16_t_u_s(((*l_831) = l_920), (safe_sub_func_uint8_t_u_u(4UL, ((((*l_970) , ((p_147 == ((safe_rshift_func_int8_t_s_s((*g_828), ((*l_854) = (safe_add_func_int32_t_s_s((*g_956), (safe_add_func_uint32_t_u_u(l_963[3], (l_962 = (((0x8D40L <= g_461) || l_1001) & (*l_972)))))))))) , (void*)0)) & 0L)) , 0x7B46L) , 0x30L)))))))), 65535UL))), 18446744073709551615UL)), (*l_972))), l_1004)));
            for (g_977 = 0; (g_977 <= 3); g_977 += 1)
            { /* block id: 501 */
                const uint8_t l_1009 = 246UL;
                int64_t *l_1010 = (void*)0;
                int64_t *l_1011 = &l_976;
                (*l_970) = (((l_1005[3][3] == l_1006) ^ 0UL) ^ 9UL);
                (*l_972) = ((-3L) && ((l_1009 , &l_949) != ((0xB5F9E601L > 0L) , (((((*l_1011) = 0x2AE61F74DFE50C66LL) == ((safe_mul_func_uint16_t_u_u((l_1009 > ((~(*l_971)) >= ((*g_828) , (*l_382)))), l_1009)) | (**g_900))) <= 0x53L) , (void*)0))));
            }
        }
    }
    return (*p_147);
}


/* ------------------------------------------ */
/* 
 * reads : g_80 g_85 g_4 g_106 g_88 g_178 g_112 g_3 g_79 g_100 g_2 g_108 g_86 g_267 g_104 g_279 g_285 g_103 g_194 g_45 g_46 g_288 g_341 g_286 g_287 g_105
 * writes: g_86 g_168 g_106 g_178 g_100 g_194 g_108 g_279 g_290 g_103 g_88 g_80 g_267 g_339 g_341 g_46 g_105
 */
static int32_t  func_156(int32_t  p_157, uint64_t  p_158, int32_t ** const  p_159, int32_t ** p_160)
{ /* block id: 29 */
    int8_t l_161 = 0x02L;
    int32_t *l_167 = &g_105;
    int32_t **l_166[5][5][2] = {{{&l_167,&l_167},{&l_167,&l_167},{(void*)0,&l_167},{&l_167,&l_167},{&l_167,&l_167}},{{&l_167,&l_167},{&l_167,&l_167},{(void*)0,&l_167},{&l_167,&l_167},{&l_167,&l_167}},{{&l_167,&l_167},{&l_167,&l_167},{(void*)0,&l_167},{&l_167,&l_167},{&l_167,&l_167}},{{&l_167,&l_167},{&l_167,&l_167},{(void*)0,&l_167},{&l_167,&l_167},{&l_167,&l_167}},{{&l_167,&l_167},{&l_167,&l_167},{(void*)0,&l_167},{&l_167,&l_167},{&l_167,&l_167}}};
    int16_t *l_169 = (void*)0;
    int16_t *l_170 = &g_106;
    int32_t l_175 = (-1L);
    uint64_t *l_176 = (void*)0;
    uint64_t *l_177 = &g_178[0][1];
    int32_t l_211[6][10] = {{0L,(-2L),0L,0x8CFB8BCEL,0L,6L,0L,1L,(-4L),1L},{0L,0xAA039AB0L,(-4L),5L,(-4L),0xAA039AB0L,0L,1L,(-7L),(-2L)},{(-7L),1L,0L,0xAA039AB0L,(-4L),5L,(-4L),0xAA039AB0L,0L,1L},{(-4L),1L,0L,6L,0L,0x8CFB8BCEL,0L,(-2L),0L,0x8CFB8BCEL},{2L,0xAA039AB0L,0L,0xAA039AB0L,2L,0x8CFB8BCEL,0L,5L,(-7L),6L},{(-4L),(-2L),0L,5L,(-2L),5L,0L,0xAC587C63L,(-2L),(-2L)}};
    uint8_t l_343 = 0xDBL;
    const int32_t *l_344[10][6][4] = {{{&g_105,&g_105,&g_105,&g_105},{(void*)0,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105}},{{(void*)0,(void*)0,(void*)0,&g_105},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,&g_105}},{{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,&g_105},{&g_105,&g_105,&g_105,(void*)0},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105}},{{&g_105,&g_105,&g_105,&g_105},{&g_105,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,(void*)0},{&g_105,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,(void*)0}},{{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,(void*)0,(void*)0,(void*)0},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,(void*)0}},{{&g_105,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,(void*)0},{&g_105,&g_105,(void*)0,&g_105},{(void*)0,(void*)0,&g_105,(void*)0},{&g_105,&g_105,&g_105,&g_105}},{{&g_105,&g_105,&g_105,&g_105},{&g_105,(void*)0,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,&g_105},{&g_105,&g_105,(void*)0,(void*)0},{&g_105,&g_105,&g_105,&g_105}},{{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,(void*)0}},{{&g_105,&g_105,&g_105,&g_105},{&g_105,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,&g_105},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105}},{{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105},{&g_105,&g_105,(void*)0,(void*)0},{(void*)0,&g_105,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105}}};
    const uint64_t *l_357 = &g_178[3][1];
    uint32_t l_374 = 4294967293UL;
    int i, j, k;
    if ((((*p_160) != ((*p_159) = func_38(((*g_85) = (*p_159)), l_161))) , (0x36CF2371L | (safe_mod_func_int32_t_s_s(((*g_80) && (((((*l_170) &= ((g_168 = &g_105) == &g_105)) , ((*l_177) |= (safe_rshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((((g_88 && g_106) && 0UL) && l_175) != p_158), 0)), 5)))) ^ g_112[8][1]) < l_161)), g_3)))))
    { /* block id: 35 */
        int32_t l_182 = 0x56F8BEA3L;
        (*g_85) = func_38((*g_79), l_161);
        for (g_100 = (-28); (g_100 == (-13)); g_100 = safe_add_func_int64_t_s_s(g_100, 6))
        { /* block id: 39 */
            int32_t *l_181[1][1][6];
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 6; k++)
                        l_181[i][j][k] = (void*)0;
                }
            }
            l_182 = (*g_80);
        }
        for (p_157 = (-2); (p_157 >= (-23)); p_157 = safe_sub_func_int16_t_s_s(p_157, 8))
        { /* block id: 44 */
            int32_t **l_185 = &l_167;
            int32_t ***l_186 = &l_166[4][4][0];
            int32_t l_187 = 0xA523A445L;
            l_187 &= (p_157 < (((*l_186) = l_185) != (void*)0));
        }
    }
    else
    { /* block id: 48 */
        uint16_t *l_191 = (void*)0;
        uint16_t *l_192 = (void*)0;
        uint16_t *l_193 = &g_194;
        int32_t * const *l_204 = &g_168;
        int32_t **l_205[4];
        int32_t l_212 = 0x03CE56EDL;
        int32_t l_213 = (-1L);
        int32_t l_214 = 0xFBABA671L;
        int32_t l_215 = 0L;
        int32_t l_216 = 0L;
        int32_t l_217 = 0x3694979DL;
        int64_t l_218 = 0x654A653397D4F8AALL;
        int32_t l_219 = 4L;
        int32_t l_220 = 0x3E7098F6L;
        int32_t l_221 = 0x76A42D7DL;
        int32_t l_222 = 0xD5100AA5L;
        uint32_t l_223 = 1UL;
        int64_t l_247[6] = {0x2D4CAE694BD96751LL,0x2D4CAE694BD96751LL,0L,0x2D4CAE694BD96751LL,0x2D4CAE694BD96751LL,0L};
        int16_t *l_324 = &g_106;
        int i;
        for (i = 0; i < 4; i++)
            l_205[i] = &g_168;
        if ((safe_sub_func_int64_t_s_s((~((p_158 , l_161) != ((*l_193) = g_178[0][1]))), (((l_170 == l_193) != ((safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u(((+(safe_rshift_func_uint16_t_u_u(((l_175 != (l_204 == (l_166[3][3][1] = l_205[3]))) ^ g_3), 1))) < 0L), 0x15693BE2L)), p_158)) < l_161)) == p_157))))
        { /* block id: 51 */
            int32_t *l_206 = &l_175;
            int32_t *l_207 = &g_88;
            int32_t *l_208 = &l_175;
            int32_t *l_209 = &g_103;
            int32_t *l_210[6] = {&g_88,&g_88,&g_100,&g_88,&g_88,&g_100};
            int64_t l_248 = 8L;
            int32_t l_254[9] = {0xCC06EC84L,0xCC06EC84L,(-9L),0xCC06EC84L,0xCC06EC84L,(-9L),0xCC06EC84L,0xCC06EC84L,(-9L)};
            int32_t ***l_289 = &l_205[3];
            int32_t l_299 = (-1L);
            int i;
            l_223++;
            if ((safe_add_func_uint32_t_u_u(((safe_mod_func_uint64_t_u_u(0UL, (safe_sub_func_uint8_t_u_u((g_2[0] , l_219), l_218)))) | (((**p_159) , (~(1L < g_108))) ^ (((safe_div_func_uint16_t_u_u(((*l_207) > ((safe_rshift_func_int16_t_s_s((l_219 , p_157), 9)) <= (*l_208))), 0x001AL)) > l_215) != 0xFEL))), (**g_85))))
            { /* block id: 53 */
                int32_t l_246 = 0x3696682BL;
                int32_t l_249 = 0L;
                int32_t l_251 = (-8L);
                int32_t l_253 = 0x5D2826EAL;
                uint64_t l_256 = 18446744073709551611UL;
                if (((l_222 = ((safe_lshift_func_uint16_t_u_s((safe_add_func_int8_t_s_s((safe_mul_func_int16_t_s_s((((safe_unary_minus_func_int16_t_s(g_4)) && (((*l_170) = l_213) ^ p_157)) <= ((&l_167 != &l_167) > (0L | ((l_175 , (**g_79)) <= p_157)))), g_178[2][0])), (-6L))), p_157)) | 0x5FD6FEA0L)) > l_219))
                { /* block id: 56 */
                    int32_t l_250[1];
                    int32_t l_252 = 0x56879814L;
                    int32_t l_255[3][2][10] = {{{0xE6BA0D8FL,(-1L),(-1L),0xE6BA0D8FL,0xA21B0A5AL,0x7B5881AEL,0xA21B0A5AL,0xE6BA0D8FL,(-1L),(-1L)},{0xA21B0A5AL,(-1L),0x8D032AA6L,(-7L),(-7L),0x8D032AA6L,(-1L),0xA21B0A5AL,(-1L),0x8D032AA6L}},{{0x7B5881AEL,0xE6BA0D8FL,(-7L),0xE6BA0D8FL,0x7B5881AEL,0x8D032AA6L,0x8D032AA6L,0x7B5881AEL,0xE6BA0D8FL,(-7L)},{0xA21B0A5AL,0xA21B0A5AL,(-7L),0x7B5881AEL,0x6D39F524L,0x7B5881AEL,(-7L),0xA21B0A5AL,0xA21B0A5AL,(-7L)}},{{0xE6BA0D8FL,0x7B5881AEL,0x8D032AA6L,0x8D032AA6L,0x7B5881AEL,0xE6BA0D8FL,(-7L),0xE6BA0D8FL,0x7B5881AEL,0x8D032AA6L},{(-1L),0xA21B0A5AL,(-1L),0x8D032AA6L,(-7L),(-7L),0x8D032AA6L,(-1L),0xA21B0A5AL,(-1L)}}};
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_250[i] = 1L;
                    --l_256;
                    (*p_159) = (*p_160);
                    for (l_212 = (-15); (l_212 == 12); l_212 = safe_add_func_int8_t_s_s(l_212, 3))
                    { /* block id: 61 */
                        uint8_t l_261 = 250UL;
                        l_261++;
                        (*l_208) &= (p_157 & (safe_mul_func_uint16_t_u_u((((~(-9L)) , ((((void*)0 == (*g_79)) , (g_267 & ((((void*)0 == &g_168) , ((*l_177) |= (p_157 == ((~(0x2585733F8B939B4CLL & 0L)) == l_261)))) <= 0xE1CEA7703A36901CLL))) == l_255[2][1][2])) | p_157), p_158)));
                    }
                    (*g_85) = (*p_159);
                }
                else
                { /* block id: 67 */
                    uint32_t l_271 = 1UL;
                    --l_271;
                }
            }
            else
            { /* block id: 70 */
                int32_t * const l_306 = &l_211[1][5];
                for (g_108 = 0; (g_108 <= 2); g_108 += 1)
                { /* block id: 73 */
                    uint8_t *l_278[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_278[i] = &g_279[8][2];
                    (*l_209) = (((safe_lshift_func_uint8_t_u_s((g_279[8][2] |= (safe_sub_func_int64_t_s_s((-1L), (g_104[g_108] & p_157)))), 5)) == p_157) == ((safe_add_func_uint8_t_u_u((g_290 = (safe_mod_func_int32_t_s_s(((~(g_285 == l_289)) , 0x3917A0F0L), ((*l_208) ^= (**p_159))))), (safe_sub_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u(255UL, 0x69L)) , g_108), 5L)))) || g_104[g_108]));
                    for (g_88 = 2; (g_88 >= 0); g_88 -= 1)
                    { /* block id: 80 */
                        int i, j;
                        (*l_208) |= (safe_add_func_uint16_t_u_u(65533UL, g_178[(g_88 + 1)][g_108]));
                    }
                    (*p_160) = (void*)0;
                    if ((*g_86))
                        continue;
                    for (g_100 = 0; (g_100 <= 2); g_100 += 1)
                    { /* block id: 87 */
                        int i, j;
                        if (g_178[g_108][g_100])
                            break;
                        (*l_207) = ((p_158 <= (safe_rshift_func_uint8_t_u_s(l_161, 7))) > g_112[7][0]);
                        (*l_209) = g_178[g_108][g_100];
                    }
                }
                l_299 ^= ((*l_206) &= (*l_209));
                for (p_158 = (-23); (p_158 > 58); p_158 = safe_add_func_uint16_t_u_u(p_158, 4))
                { /* block id: 97 */
                    for (l_175 = 0; (l_175 > (-4)); l_175--)
                    { /* block id: 100 */
                        uint32_t l_309 = 0x459A02BFL;
                        int8_t *l_316 = &l_161;
                        (*l_207) = ((safe_lshift_func_int16_t_s_s((((l_306 == ((p_157 ^ g_2[0]) , (void*)0)) > (safe_add_func_uint64_t_u_u(l_309, (4294967295UL <= (((*l_316) = (((safe_sub_func_int32_t_s_s((**g_85), (safe_rshift_func_int16_t_s_u(((((*l_289) == &g_168) , 0x1236BC38D9B2E33ALL) ^ (-4L)), 1)))) | g_194) , g_178[2][0])) == g_100))))) & p_158), l_175)) , 0x3CD140C1L);
                        (*p_159) = (*g_79);
                    }
                    (*p_159) = &l_254[4];
                }
            }
        }
        else
        { /* block id: 108 */
            int16_t *l_323 = &g_290;
            int32_t l_330 = 9L;
            int32_t ***l_356[6] = {&l_166[3][3][1],&l_166[3][3][1],&l_166[3][3][1],&l_166[3][3][1],&l_166[3][3][1],&l_166[3][3][1]};
            const uint64_t **l_358 = &l_357;
            int i;
            for (l_213 = 0; (l_213 != 10); l_213 = safe_add_func_int16_t_s_s(l_213, 1))
            { /* block id: 111 */
                uint8_t *l_329 = &g_279[6][2];
                int32_t *l_331 = (void*)0;
                int32_t *l_332[8] = {&l_220,&l_220,&l_214,&l_220,&l_220,&l_214,&l_220,&l_220};
                uint16_t *l_338 = &g_339;
                uint16_t *l_340 = &g_341[0][0];
                int i;
                g_267 &= (g_88 |= (safe_lshift_func_int8_t_s_s(g_45, (l_330 = ((((1L & (safe_mod_func_int32_t_s_s((((l_324 = l_323) != (void*)0) || (safe_sub_func_uint64_t_u_u((safe_mul_func_int8_t_s_s(l_215, ((*l_329) = (p_158 , ((((((*l_193) = g_46) , g_100) || p_157) < 0L) >= 0x2DL))))), 0x6107686EA3173BE6LL))), l_161))) | 0x06F44EE2L) || p_158) == l_211[3][2])))));
                l_343 = ((p_157 = (g_288 >= ((safe_mod_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u(((((safe_unary_minus_func_uint32_t_u((l_193 == (void*)0))) & 1L) != ((*l_340) |= ((*l_338) = ((*l_193) = l_211[2][3])))) > ((*l_177) = (1L < (p_157 < ((p_158 <= ((+(g_112[6][1] == p_158)) && 1L)) , l_211[3][2]))))), 10)) || 0x2BCE109FL), 0x37F4F738L)) == g_104[0]))) || 0xF01E2568L);
                if ((**g_79))
                    break;
                l_211[3][4] ^= (*g_80);
            }
            g_88 &= (((l_344[0][5][2] != (*g_286)) != (safe_lshift_func_uint8_t_u_s((((*l_358) = (((safe_lshift_func_int8_t_s_s((+(g_108 || 0x03L)), (((void*)0 == (*g_85)) , ((safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(p_157, 3)), (l_356[2] != &l_166[2][3][0]))), 1)) >= g_279[8][2])))) != 1UL) , l_357)) != &p_158), 3))) && 1UL);
        }
    }
    for (p_158 = 15; (p_158 != 47); p_158 = safe_add_func_uint8_t_u_u(p_158, 6))
    { /* block id: 133 */
        uint32_t *l_367 = &g_46;
        p_157 |= ((safe_sub_func_int8_t_s_s(0x53L, l_343)) ^ ((*l_367) = (((safe_mod_func_int32_t_s_s((g_267 = (0x30L | 0xF6L)), 0x2FD1AF3AL)) | ((safe_rshift_func_int16_t_s_u(0x790CL, p_158)) || l_343)) || g_279[8][2])));
    }
    for (g_105 = (-27); (g_105 == 10); g_105 = safe_add_func_uint16_t_u_u(g_105, 2))
    { /* block id: 140 */
        int32_t *l_372[8] = {&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103};
        int16_t l_373[7][1];
        int i, j;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 1; j++)
                l_373[i][j] = 0x6B92L;
        }
        l_175 ^= (((**g_85) || (safe_sub_func_int64_t_s_s(l_343, p_157))) != l_211[2][3]);
        l_374--;
    }
    return l_161;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_107[i], "g_107[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_108, "g_108", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_112[i][j], "g_112[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_178[i][j], "g_178[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_194, "g_194", print_hash_value);
    transparent_crc(g_267, "g_267", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_279[i][j], "g_279[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_288, "g_288", print_hash_value);
    transparent_crc(g_290, "g_290", print_hash_value);
    transparent_crc(g_339, "g_339", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_341[i][j], "g_341[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_393, "g_393", print_hash_value);
    transparent_crc(g_461, "g_461", print_hash_value);
    transparent_crc(g_520, "g_520", print_hash_value);
    transparent_crc(g_528, "g_528", print_hash_value);
    transparent_crc(g_596, "g_596", print_hash_value);
    transparent_crc(g_727, "g_727", print_hash_value);
    transparent_crc(g_739, "g_739", print_hash_value);
    transparent_crc(g_756, "g_756", print_hash_value);
    transparent_crc(g_955, "g_955", print_hash_value);
    transparent_crc(g_975, "g_975", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_1025, "g_1025", print_hash_value);
    transparent_crc(g_1055, "g_1055", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1433[i], "g_1433[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1567, "g_1567", print_hash_value);
    transparent_crc(g_1847, "g_1847", print_hash_value);
    transparent_crc(g_1908, "g_1908", print_hash_value);
    transparent_crc(g_1997, "g_1997", print_hash_value);
    transparent_crc(g_2030, "g_2030", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2163[i], "g_2163[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2200[i][j][k], "g_2200[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2321, "g_2321", print_hash_value);
    transparent_crc(g_2487, "g_2487", print_hash_value);
    transparent_crc(g_2497, "g_2497", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2532[i], "g_2532[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2534, "g_2534", print_hash_value);
    transparent_crc(g_2582, "g_2582", print_hash_value);
    transparent_crc(g_2725, "g_2725", print_hash_value);
    transparent_crc(g_2826, "g_2826", print_hash_value);
    transparent_crc(g_2837, "g_2837", print_hash_value);
    transparent_crc(g_2905, "g_2905", print_hash_value);
    transparent_crc(g_2940, "g_2940", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 742
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 241
   depth: 2, occurrence: 60
   depth: 3, occurrence: 11
   depth: 4, occurrence: 7
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 4
   depth: 17, occurrence: 3
   depth: 18, occurrence: 4
   depth: 19, occurrence: 2
   depth: 20, occurrence: 2
   depth: 21, occurrence: 2
   depth: 22, occurrence: 4
   depth: 23, occurrence: 3
   depth: 25, occurrence: 1
   depth: 26, occurrence: 3
   depth: 27, occurrence: 3
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 31, occurrence: 2
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 36, occurrence: 4
   depth: 40, occurrence: 1
   depth: 44, occurrence: 1

XXX total number of pointers: 619

XXX times a variable address is taken: 1901
XXX times a pointer is dereferenced on RHS: 537
breakdown:
   depth: 1, occurrence: 354
   depth: 2, occurrence: 151
   depth: 3, occurrence: 32
XXX times a pointer is dereferenced on LHS: 464
breakdown:
   depth: 1, occurrence: 423
   depth: 2, occurrence: 39
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 60
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 24
XXX times a pointer is qualified to be dereferenced: 12581

XXX max dereference level: 7
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1696
   level: 2, occurrence: 695
   level: 3, occurrence: 140
   level: 4, occurrence: 9
   level: 5, occurrence: 9
   level: 6, occurrence: 1
   level: 7, occurrence: 1
XXX number of pointers point to pointers: 248
XXX number of pointers point to scalars: 371
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.4
XXX average alias set size: 1.41

XXX times a non-volatile is read: 2882
XXX times a non-volatile is write: 1303
XXX times a volatile is read: 129
XXX    times read thru a pointer: 38
XXX times a volatile is write: 77
XXX    times written thru a pointer: 41
XXX times a volatile is available for access: 2.69e+03
XXX percentage of non-volatile access: 95.3

XXX forward jumps: 0
XXX backward jumps: 10

XXX stmts: 249
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 23
   depth: 2, occurrence: 36
   depth: 3, occurrence: 49
   depth: 4, occurrence: 53
   depth: 5, occurrence: 63

XXX percentage a fresh-made variable is used: 14.6
XXX percentage an existing variable is used: 85.4
********************* end of statistics **********************/

