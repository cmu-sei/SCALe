/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3135559630
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 0x8C45CDBEL;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0x6F9B2CFBL;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0x8D581621L;/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0x99FB023EL;
static int32_t g_46[9] = {1L,0L,1L,1L,0L,1L,1L,0L,1L};
static int32_t g_95 = 0xBDD559FEL;
static int32_t *g_101 = (void*)0;
static uint64_t g_106 = 0xCB6E384D564CE3E2LL;
static int8_t g_120[4] = {0x07L,0x07L,0x07L,0x07L};
static const int32_t g_125 = 0xB90C34EFL;
static const int32_t g_127 = (-5L);
static int32_t g_153 = 0x40B19067L;
static uint32_t g_167 = 0xF22FF882L;
static int16_t g_170 = 1L;
static int16_t g_173 = 0x0287L;
static int32_t g_174 = 0x1D116AA0L;
static uint16_t g_183 = 0xF15CL;
static volatile int8_t g_226 = (-1L);/* VOLATILE GLOBAL g_226 */
static volatile int8_t * volatile g_225[1] = {&g_226};
static volatile int8_t * volatile g_227 = (void*)0;/* VOLATILE GLOBAL g_227 */
static volatile int8_t g_229 = 1L;/* VOLATILE GLOBAL g_229 */
static volatile int8_t *g_228 = &g_229;
static volatile int8_t * volatile *g_224[2][4][9] = {{{&g_228,(void*)0,&g_228,&g_228,(void*)0,&g_228,(void*)0,&g_228,&g_228},{(void*)0,&g_228,(void*)0,&g_225[0],&g_228,&g_228,&g_228,&g_228,&g_228},{&g_228,&g_227,&g_227,&g_228,&g_225[0],&g_228,&g_228,&g_228,&g_228},{&g_225[0],(void*)0,&g_228,(void*)0,&g_227,(void*)0,&g_228,&g_228,&g_228}},{{&g_228,(void*)0,&g_228,&g_228,&g_227,&g_228,&g_228,(void*)0,&g_228},{&g_228,&g_227,&g_228,(void*)0,&g_228,&g_228,(void*)0,(void*)0,&g_228},{&g_228,&g_228,&g_228,(void*)0,&g_228,&g_228,&g_228,&g_228,&g_228},{&g_228,&g_228,(void*)0,&g_228,&g_228,&g_228,(void*)0,&g_228,&g_228}}};
static uint32_t g_255[7][8][4] = {{{18446744073709551615UL,0xFF06D840L,1UL,1UL},{0xBCDBC604L,18446744073709551615UL,0UL,0UL},{18446744073709551608UL,0x6B34544CL,0x6C627A45L,0UL},{3UL,18446744073709551610UL,0xEE4FC8B5L,18446744073709551611UL},{0UL,0x33BA4A93L,1UL,18446744073709551615UL},{0x0133C602L,0UL,3UL,0xC162CA8FL},{0x0C404CD8L,0xAC38EDBDL,18446744073709551615UL,18446744073709551615UL},{0x1F0ACE29L,0x2B5224E5L,0UL,18446744073709551613UL}},{{18446744073709551610UL,18446744073709551611UL,0xB420BBD9L,0x5ADDF4B6L},{18446744073709551615UL,0xBE9DCC00L,3UL,0x2604FD5BL},{3UL,0UL,0x1848D0E2L,1UL},{0x842C4B80L,18446744073709551615UL,0UL,0x6E3D5B6DL},{0xE2ED7CCDL,0x512A262BL,0x55C6A8F6L,18446744073709551615UL},{0xF6DD3D46L,0x6B29E6F0L,18446744073709551611UL,3UL},{18446744073709551615UL,0UL,18446744073709551608UL,0x0F418198L},{18446744073709551607UL,0xE2ED7CCDL,0UL,0x6635AC33L}},{{1UL,0x36F43DDEL,0x3F6A8D8BL,18446744073709551615UL},{0x05C9A852L,0x04B5586EL,0xB59D55D0L,6UL},{3UL,0x1AC1D684L,2UL,2UL},{1UL,1UL,0x89994865L,0x0464180AL},{0xBE9DCC00L,18446744073709551615UL,1UL,1UL},{0x1848D0E2L,0xBB745841L,0xC162CA8FL,1UL},{0xFF06D840L,0xBB745841L,18446744073709551611UL,1UL},{0xBB745841L,18446744073709551615UL,0x36F43DDEL,0x0464180AL}},{{0x10735DB4L,1UL,18446744073709551615UL,2UL},{0xCA5432B5L,0x1AC1D684L,3UL,6UL},{0UL,0x04B5586EL,0x1E260467L,18446744073709551615UL},{0x0F418198L,0x36F43DDEL,18446744073709551615UL,0x6635AC33L},{2UL,0xE2ED7CCDL,0x05C9A852L,0x0F418198L},{0xEE4FC8B5L,0UL,0xA2DDA9A1L,3UL},{1UL,0x6B29E6F0L,0x6F46DC24L,18446744073709551615UL},{0x0464180AL,0x512A262BL,0UL,0x6E3D5B6DL}},{{0x6F46DC24L,18446744073709551615UL,18446744073709551613UL,1UL},{0xA383889FL,0UL,0UL,0x2604FD5BL},{18446744073709551607UL,0xBE9DCC00L,0x9C3CA289L,0x5ADDF4B6L},{0x6B34544CL,18446744073709551611UL,0x1F0ACE29L,18446744073709551613UL},{0UL,0x2B5224E5L,0x512A262BL,18446744073709551615UL},{0UL,0xAC38EDBDL,0x7EFCA105L,1UL},{0UL,0xBCDBC604L,0xCAC7D101L,0x842C4B80L},{3UL,0xEE4FC8B5L,0xA2DDA9A1L,1UL}},{{0UL,0xA2DDA9A1L,0x6B29E6F0L,1UL},{0x842C4B80L,0xA383889FL,0UL,0UL},{0x1848D0E2L,0UL,0xB420BBD9L,18446744073709551615UL},{0x0C404CD8L,0xCAC7D101L,1UL,0xBB745841L},{0x0464180AL,0xB59D55D0L,0x89994865L,0xB59D55D0L},{0x1D7D2F74L,18446744073709551613UL,0xC162CA8FL,0x0C404CD8L},{3UL,1UL,0UL,0UL},{0x6B29E6F0L,18446744073709551615UL,0x8F450C6EL,2UL}},{{0x6B29E6F0L,0x9C3CA289L,0UL,1UL},{3UL,2UL,0xC162CA8FL,0x8F5A50C0L},{0x1D7D2F74L,0xE2ED7CCDL,0x89994865L,0xB420BBD9L},{0x0464180AL,0x33BA4A93L,1UL,0x2B5224E5L},{0x0C404CD8L,0x5C0FEA65L,0xB420BBD9L,0x2676FA98L},{0x1848D0E2L,0x2071BF11L,0UL,0UL},{0x842C4B80L,1UL,0x6B29E6F0L,0x512A262BL},{0UL,0x5ADDF4B6L,0xA2DDA9A1L,0xFD0E00C2L}}};
static int32_t g_278[2] = {0xE7F85673L,0xE7F85673L};
static uint16_t g_313[6][10] = {{0x64CAL,9UL,5UL,5UL,9UL,0x64CAL,0x96FCL,9UL,0x96FCL,0x64CAL},{65526UL,9UL,1UL,9UL,65526UL,1UL,0x1127L,0x1127L,1UL,65526UL},{65526UL,0x96FCL,0x96FCL,65526UL,5UL,0x64CAL,65526UL,0x64CAL,5UL,65526UL},{0x64CAL,65526UL,0x64CAL,5UL,65526UL,0x96FCL,0x96FCL,65526UL,5UL,0x64CAL},{0x1127L,0x1127L,1UL,65526UL,9UL,1UL,9UL,65526UL,1UL,0x1127L},{9UL,0x96FCL,0x64CAL,9UL,5UL,5UL,9UL,0x64CAL,0x96FCL,9UL}};
static int32_t g_323 = 0x8A2A92A3L;
static uint8_t g_359 = 0x97L;
static uint8_t g_372 = 4UL;
static uint8_t g_379 = 251UL;
static int32_t **g_388 = &g_101;
static const int32_t *g_415 = (void*)0;
static const int32_t * volatile *g_414 = &g_415;
static const int32_t * volatile * volatile *g_413 = &g_414;
static int16_t **g_420 = (void*)0;
static int16_t g_465[5] = {0x203DL,0x203DL,0x203DL,0x203DL,0x203DL};
static uint32_t g_470 = 6UL;
static volatile uint64_t g_496[8] = {8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL};
static volatile uint64_t *g_495 = &g_496[2];
static volatile uint64_t **g_494 = &g_495;
static uint32_t g_534 = 0x6160E245L;
static const uint16_t *g_583 = (void*)0;
static const uint16_t * const *g_582[9] = {&g_583,&g_583,&g_583,&g_583,&g_583,&g_583,&g_583,&g_583,&g_583};
static const uint16_t g_586 = 0x91AEL;
static const uint16_t g_587 = 0x0F9FL;
static uint16_t g_606 = 0xD2AAL;
static int64_t g_652 = 0x0BF3F6AEC69DAE28LL;
static int64_t *g_651 = &g_652;
static int32_t g_724[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
static int64_t g_795 = 0xBF4AE3CBEDB3009DLL;
static const volatile uint32_t **g_837[1] = {(void*)0};
static const volatile uint32_t ***g_836 = &g_837[0];
static int16_t **g_845 = (void*)0;
static const int32_t g_946 = 0x2687E478L;
static const int32_t *g_972 = (void*)0;
static const int32_t *g_973 = &g_46[1];
static uint16_t *g_977[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static uint16_t **g_976[6][8][2] = {{{&g_977[1],&g_977[2]},{&g_977[2],&g_977[1]},{&g_977[2],(void*)0},{&g_977[2],&g_977[1]},{&g_977[2],&g_977[2]},{&g_977[1],&g_977[2]},{(void*)0,&g_977[2]},{&g_977[1],&g_977[2]}},{{&g_977[2],&g_977[1]},{&g_977[2],(void*)0},{&g_977[1],(void*)0},{&g_977[2],&g_977[2]},{(void*)0,&g_977[1]},{&g_977[2],&g_977[1]},{(void*)0,&g_977[2]},{&g_977[2],(void*)0}},{{&g_977[1],&g_977[2]},{&g_977[1],(void*)0},{&g_977[2],&g_977[2]},{(void*)0,&g_977[1]},{&g_977[2],&g_977[1]},{(void*)0,&g_977[2]},{&g_977[2],(void*)0},{&g_977[1],&g_977[2]}},{{&g_977[1],(void*)0},{&g_977[2],&g_977[2]},{(void*)0,&g_977[1]},{&g_977[2],&g_977[1]},{(void*)0,&g_977[2]},{&g_977[2],(void*)0},{&g_977[1],&g_977[2]},{&g_977[1],(void*)0}},{{&g_977[2],&g_977[2]},{(void*)0,&g_977[1]},{&g_977[2],&g_977[1]},{(void*)0,&g_977[2]},{&g_977[2],(void*)0},{&g_977[1],&g_977[2]},{&g_977[1],(void*)0},{&g_977[2],&g_977[2]}},{{(void*)0,&g_977[1]},{&g_977[2],&g_977[1]},{(void*)0,&g_977[2]},{&g_977[2],(void*)0},{&g_977[1],&g_977[2]},{&g_977[1],(void*)0},{&g_977[2],&g_977[2]},{(void*)0,&g_977[1]}}};
static int32_t g_1019 = 1L;
static uint32_t g_1060 = 0x25CA054EL;
static uint32_t g_1062 = 0xBAAA59E2L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint64_t  func_8(int32_t * p_9, uint64_t  p_10, int32_t  p_11);
static int32_t  func_20(int16_t  p_21, uint32_t  p_22, int16_t  p_23, int32_t * p_24, const int32_t * p_25);
static uint32_t  func_26(uint16_t  p_27, uint64_t  p_28);
static uint16_t  func_37(int32_t * p_38, uint32_t  p_39, int32_t * const  p_40, uint32_t  p_41, uint32_t  p_42);
static int8_t  func_53(int32_t  p_54, int32_t * const  p_55);
static int32_t * func_57(uint32_t  p_58, uint32_t  p_59, const uint32_t  p_60, int32_t * p_61, uint8_t  p_62);
static uint32_t  func_63(const int8_t  p_64);
static int64_t  func_65(uint32_t  p_66, int32_t * p_67, int32_t * p_68, uint32_t  p_69, uint32_t  p_70);
static uint8_t  func_73(int32_t * p_74, uint32_t  p_75);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_5 g_46 g_95 g_127 g_120 g_167 g_173 g_170 g_183 g_153 g_106 g_174 g_125 g_278 g_101 g_323 g_359 g_313 g_255 g_413 g_372 g_470 g_494 g_534 g_388 g_582 g_465 g_606 g_414 g_415 g_651 g_652 g_495 g_496 g_836 g_845 g_226 g_946 g_724 g_976 g_379 g_587 g_1060 g_1062 g_228 g_229
 * writes: g_6 g_46 g_153 g_255 g_95 g_174 g_101 g_183 g_313 g_278 g_120 g_170 g_323 g_359 g_372 g_379 g_388 g_173 g_106 g_420 g_470 g_534 g_606 g_652 g_415 g_465 g_845 g_795 g_167 g_972 g_973 g_1060 g_1062
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[1];
    int32_t * const l_43[7][6][1] = {{{&g_6},{&g_6},{&l_2[0]},{&g_6},{&g_6},{&l_2[0]}},{{&l_2[0]},{(void*)0},{&l_2[0]},{&l_2[0]},{&g_6},{&g_6}},{{&l_2[0]},{&g_6},{&g_6},{&l_2[0]},{&l_2[0]},{(void*)0}},{{&l_2[0]},{&l_2[0]},{&g_6},{&g_6},{&l_2[0]},{&g_6}},{{&g_6},{&l_2[0]},{&l_2[0]},{(void*)0},{&l_2[0]},{&l_2[0]}},{{&g_6},{&g_6},{&l_2[0]},{&g_6},{&g_6},{&l_2[0]}},{{&l_2[0]},{(void*)0},{&l_2[0]},{&l_2[0]},{&g_6},{&g_6}}};
    const int32_t * volatile l_1072[4][6][3] = {{{&g_127,(void*)0,&g_153},{&g_127,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_46[3],(void*)0,&g_323},{&g_125,(void*)0,&g_125},{(void*)0,(void*)0,&l_2[0]}},{{&g_127,(void*)0,&g_153},{&g_127,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_46[3],(void*)0,&g_323},{&g_125,(void*)0,&g_125},{(void*)0,(void*)0,&l_2[0]}},{{&g_127,(void*)0,&g_153},{&g_127,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_46[3],(void*)0,&g_323},{&g_125,(void*)0,&g_125},{(void*)0,(void*)0,&l_2[0]}},{{&g_127,(void*)0,&g_153},{&g_127,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_46[3],(void*)0,&g_323},{&g_125,(void*)0,&g_125},{(void*)0,(void*)0,&l_2[0]}}};
    int32_t l_1075 = 1L;
    uint64_t l_1078[8][5][6] = {{{0x5BB9681513D85ACELL,1UL,0x198A198BEC17CAF4LL,18446744073709551610UL,0UL,18446744073709551611UL},{18446744073709551615UL,0x83BD45725F8BE925LL,18446744073709551610UL,0xC1DBC9B9FB119644LL,0UL,0x7CC74A1E5AC342E8LL},{0UL,0x34CA5E4789536D3ALL,0x42737388B04441C2LL,7UL,0x86BA20602EBE76ACLL,0x1BDE1A6986BF721ALL},{0x45EC853587010731LL,0x86E1B525243C60CCLL,0xFC38AAD8F32F20D2LL,0xC527D89CE96485F0LL,18446744073709551612UL,0x39A84EF61234692DLL},{0x331018A31901196ELL,0x198A198BEC17CAF4LL,0x9ABE2C92A7105761LL,0xFBF4C2A9C8551028LL,4UL,0xEDF642B396733712LL}},{{0xF38CB04FB69368AELL,0x54B48581C729C326LL,0x8AD1FD51A3222D67LL,18446744073709551611UL,0UL,4UL},{0x377492D5A19DDCD8LL,0xC818CFB403708FD4LL,18446744073709551610UL,18446744073709551615UL,18446744073709551615UL,0x7CC74A1E5AC342E8LL},{0x555033D0D0AED4EALL,1UL,0x54B48581C729C326LL,0x793CFC0846205869LL,0xC1DBC9B9FB119644LL,0xC0D8BBD777149F52LL},{0xFBF4C2A9C8551028LL,0x90A303FA9D866CB7LL,0x8C3A6E068A083932LL,8UL,0x3E32A05C2D387047LL,9UL},{9UL,0x8AD1FD51A3222D67LL,0x097AEA5AAE23DD3DLL,0x45EC853587010731LL,1UL,0x6374F58EC8A075F9LL}},{{1UL,0x42737388B04441C2LL,18446744073709551608UL,2UL,0UL,18446744073709551615UL},{18446744073709551615UL,0xB92276EB685F8C55LL,18446744073709551611UL,18446744073709551610UL,18446744073709551615UL,18446744073709551615UL},{1UL,0x1BDE1A6986BF721ALL,1UL,0xCDFCC7B2A7D99AA9LL,5UL,0UL},{0xC1DBC9B9FB119644LL,0x86E1B525243C60CCLL,0x793CFC0846205869LL,0xAA17A00D9ACD7218LL,1UL,18446744073709551615UL},{0x34CA5E4789536D3ALL,18446744073709551608UL,2UL,0x45EC853587010731LL,0x1FB68B1A9D31D95BLL,1UL}},{{1UL,1UL,0UL,18446744073709551610UL,0UL,0xFF15B3F3729EFB20LL},{18446744073709551615UL,0x1B35476A8C0D3C72LL,0x2461FF7CE96C4A27LL,18446744073709551615UL,18446744073709551608UL,18446744073709551610UL},{0x555033D0D0AED4EALL,1UL,7UL,0x6A271FF07A554F35LL,7UL,1UL},{18446744073709551615UL,18446744073709551612UL,0x793CFC0846205869LL,2UL,0xD73691B792A14C85LL,0x86BA20602EBE76ACLL},{1UL,0UL,0xC527D89CE96485F0LL,0xFBF4C2A9C8551028LL,0x331018A31901196ELL,1UL}},{{18446744073709551610UL,0UL,1UL,1UL,0xD73691B792A14C85LL,18446744073709551615UL},{0x199925630FA8EDAELL,18446744073709551612UL,1UL,18446744073709551608UL,7UL,0x199925630FA8EDAELL},{0UL,1UL,0xFBF4C2A9C8551028LL,0x4BEC61D804AD5AF1LL,18446744073709551608UL,0x555033D0D0AED4EALL},{18446744073709551610UL,0x1B35476A8C0D3C72LL,0x8C3A6E068A083932LL,0x0A2310B890619626LL,0UL,1UL},{18446744073709551607UL,1UL,0x0A2310B890619626LL,0xC1DBC9B9FB119644LL,0x1FB68B1A9D31D95BLL,1UL}},{{2UL,18446744073709551608UL,0x42737388B04441C2LL,1UL,1UL,4UL},{0x199925630FA8EDAELL,0x86E1B525243C60CCLL,18446744073709551615UL,1UL,5UL,1UL},{0x331018A31901196ELL,0x1BDE1A6986BF721ALL,0x5BB9681513D85ACELL,0x097AEA5AAE23DD3DLL,18446744073709551615UL,0xEDF642B396733712LL},{18446744073709551615UL,0xB92276EB685F8C55LL,0xFC38AAD8F32F20D2LL,2UL,0UL,0x198A198BEC17CAF4LL},{4UL,0x42737388B04441C2LL,8UL,18446744073709551615UL,1UL,1UL}},{{18446744073709551611UL,0x8AD1FD51A3222D67LL,0x54B48581C729C326LL,0xF38CB04FB69368AELL,0x3E32A05C2D387047LL,18446744073709551611UL},{18446744073709551615UL,0x90A303FA9D866CB7LL,4UL,0x42737388B04441C2LL,0xC1DBC9B9FB119644LL,18446744073709551611UL},{0xC1DBC9B9FB119644LL,0x198A198BEC17CAF4LL,2UL,18446744073709551615UL,18446744073709551610UL,18446744073709551608UL},{0x639D8A7CAB1BDDA8LL,0UL,0xD73691B792A14C85LL,0xB92276EB685F8C55LL,0xFEF81D744E746448LL,18446744073709551615UL},{0xFBF4C2A9C8551028LL,18446744073709551615UL,0x1B35476A8C0D3C72LL,0x1B61F031EF7338E4LL,0x39A84EF61234692DLL,0x198A198BEC17CAF4LL}},{{0xFC38AAD8F32F20D2LL,0xFF15B3F3729EFB20LL,18446744073709551615UL,0x06E949C0D8718280LL,4UL,0x0A2310B890619626LL},{0x097AEA5AAE23DD3DLL,0UL,8UL,18446744073709551610UL,18446744073709551610UL,8UL},{18446744073709551607UL,18446744073709551607UL,0x26478DB9B7D408B9LL,18446744073709551615UL,0x199925630FA8EDAELL,0x8AD1FD51A3222D67LL},{18446744073709551615UL,9UL,18446744073709551611UL,7UL,1UL,0x26478DB9B7D408B9LL},{0x86BA20602EBE76ACLL,18446744073709551615UL,18446744073709551611UL,18446744073709551610UL,18446744073709551607UL,0x8AD1FD51A3222D67LL}}};
    int16_t ***l_1079[1];
    int8_t *l_1080 = (void*)0;
    uint64_t *l_1081 = (void*)0;
    int32_t l_1085 = 0L;
    uint8_t l_1086 = 0x58L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2[i] = 1L;
    for (i = 0; i < 1; i++)
        l_1079[i] = &g_845;
    for (g_6 = 0; (g_6 >= 0); g_6 -= 1)
    { /* block id: 3 */
        int32_t *l_12 = (void*)0;
        uint32_t *l_1059 = &g_1060;
        uint32_t *l_1061 = &g_1062;
        uint64_t l_1067 = 18446744073709551615UL;
        int i;
        (**g_413) = ((~(0x8E1B8814L || (0xC5D9B4E94F934F54LL <= func_8(l_12, ((((safe_add_func_uint64_t_u_u((~(safe_add_func_int16_t_s_s((safe_add_func_uint64_t_u_u(18446744073709551613UL, (func_20(l_2[g_6], ((*l_1061) |= ((g_5 || (((*l_1059) |= func_26((safe_add_func_int64_t_s_s(l_2[0], ((safe_rshift_func_int8_t_s_u((safe_div_func_int32_t_s_s((safe_sub_func_int64_t_s_s((((g_5 >= (func_37(&l_2[0], g_6, l_43[2][4][0], g_6, g_6) >= g_6)) < 1L) == 6L), 0L)), g_6)), 4)) > g_6))), g_6)) , g_255[6][5][0])) > 0UL)), g_724[6], &l_2[g_6], &l_2[g_6]) || l_2[g_6]))), g_724[7]))), l_1067)) , 4294967288UL) >= l_1067) >= g_127), g_724[6])))) , (**g_413));
        l_1072[0][1][0] = (**g_413);
    }
    g_153 = (safe_div_func_uint64_t_u_u(((g_323 = (l_1075 , (g_46[2] = ((((((safe_rshift_func_int8_t_s_s((*g_228), (g_120[2] = (l_1078[5][4][3] != (l_1079[0] != &g_845))))) || g_127) < (g_106--)) || g_652) & (g_652 & ((safe_unary_minus_func_int8_t_s((&g_494 == &g_494))) || g_946))) , l_1085)))) , (**g_494)), 9UL));
    return l_1086;
}


/* ------------------------------------------ */
/* 
 * reads : g_652 g_323
 * writes: g_652 g_323
 */
static uint64_t  func_8(int32_t * p_9, uint64_t  p_10, int32_t  p_11)
{ /* block id: 502 */
    int8_t l_1070[3][10] = {{0L,0x3AL,0x3AL,0L,0x3AL,0x3AL,0L,0x3AL,0x3AL,0L},{0x3AL,0L,0x3AL,0x3AL,0L,0x3AL,0x3AL,0L,0x3AL,0x3AL},{0L,0L,0xEAL,0L,0L,0xEAL,0L,0L,0xEAL,0L}};
    int i, j;
    for (g_652 = 0; (g_652 != (-2)); g_652 = safe_sub_func_int16_t_s_s(g_652, 5))
    { /* block id: 505 */
        int32_t *l_1071 = &g_323;
        (*l_1071) |= l_1070[2][2];
    }
    return l_1070[1][6];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_20(int16_t  p_21, uint32_t  p_22, int16_t  p_23, int32_t * p_24, const int32_t * p_25)
{ /* block id: 498 */
    int64_t l_1065 = 9L;
    int32_t l_1066 = 6L;
    l_1066 = ((safe_add_func_uint64_t_u_u(p_23, l_1065)) > ((*p_24) |= l_1065));
    return l_1065;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_46 g_95 g_127 g_120 g_167 g_173 g_170 g_183 g_153 g_106 g_174 g_125 g_278 g_101 g_323 g_359 g_313 g_255 g_413 g_372 g_470 g_494 g_534 g_388 g_582 g_465 g_606 g_414 g_415 g_651 g_652 g_495 g_496 g_836 g_845 g_226 g_946 g_724 g_976 g_379 g_587
 * writes: g_46 g_153 g_255 g_95 g_174 g_101 g_183 g_313 g_278 g_120 g_170 g_323 g_359 g_372 g_379 g_388 g_173 g_106 g_420 g_470 g_534 g_606 g_652 g_415 g_465 g_845 g_795 g_167 g_972 g_973
 */
static uint32_t  func_26(uint16_t  p_27, uint64_t  p_28)
{ /* block id: 7 */
    int16_t l_982 = 0x126DL;
    int32_t l_999[6][4] = {{0x1043D0A9L,0x98FB3DAEL,0x98FB3DAEL,0x1043D0A9L},{0x98FB3DAEL,0x1043D0A9L,0x98FB3DAEL,0x98FB3DAEL},{0x1043D0A9L,0x1043D0A9L,0L,0x1043D0A9L},{0x1043D0A9L,0x98FB3DAEL,0x98FB3DAEL,0x1043D0A9L},{0x98FB3DAEL,0x1043D0A9L,0x98FB3DAEL,0x98FB3DAEL},{0x1043D0A9L,0x1043D0A9L,0L,0x1043D0A9L}};
    int i, j;
    for (p_27 = 0; (p_27 < 11); p_27 = safe_add_func_int8_t_s_s(p_27, 9))
    { /* block id: 10 */
        uint32_t *l_985 = &g_255[1][2][1];
        int32_t l_994 = 0x97FAEB40L;
        int32_t l_1015 = 0x76C5D233L;
        int32_t l_1016 = 3L;
        int32_t l_1017 = 0L;
        int32_t l_1018[9][4] = {{0xD0822F0DL,(-1L),0xE3B7D46FL,0xD0822F0DL},{0xE3B7D46FL,0xD0822F0DL,1L,1L},{(-1L),(-1L),(-10L),1L},{(-1L),(-1L),1L,(-1L)},{0xE3B7D46FL,1L,0xE3B7D46FL,1L},{0xD0822F0DL,1L,(-10L),(-1L)},{1L,(-1L),(-1L),1L},{0xE3B7D46FL,(-1L),(-1L),1L},{1L,0xD0822F0DL,(-10L),0xD0822F0DL}};
        int i, j;
        for (p_28 = 0; (p_28 == 58); ++p_28)
        { /* block id: 13 */
            int32_t * const l_56 = &g_46[2];
            uint16_t **l_978[2][4] = {{(void*)0,&g_977[2],&g_977[2],(void*)0},{&g_977[2],(void*)0,&g_977[2],&g_977[2]}};
            int32_t l_1008 = 9L;
            int32_t l_1011 = 0x51D5F519L;
            int32_t l_1012 = (-1L);
            int32_t l_1013 = 1L;
            int32_t l_1014[2][6] = {{0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL},{0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL,0x230E877DL}};
            uint32_t l_1056 = 18446744073709551615UL;
            int i, j;
            if ((((&g_5 != &g_3) && (safe_lshift_func_int16_t_s_s(((func_53(p_27, l_56) && (g_724[5] & ((safe_div_func_int32_t_s_s(((*l_56) = (g_323 , ((l_978[1][3] = g_976[5][3][0]) == (void*)0))), 4294967294UL)) & 0xA6598B79L))) , 0L), p_28))) || g_167))
            { /* block id: 467 */
                int8_t l_997[6] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
                uint32_t *l_998 = &g_255[1][7][3];
                int i;
                l_999[4][1] &= (~((&p_27 != ((safe_sub_func_int16_t_s_s(l_982, (((safe_lshift_func_uint8_t_u_u((((l_985 = (void*)0) != ((safe_mul_func_int8_t_s_s(((((safe_rshift_func_int8_t_s_u((((*l_56) = (safe_lshift_func_uint8_t_u_u((p_27 >= p_27), (safe_lshift_func_int16_t_s_u(l_982, l_994))))) | (((0L == (safe_rshift_func_int8_t_s_s(0xB5L, 6))) < p_27) , 0UL)), g_724[6])) || p_28) , p_27) != l_997[3]), 0x0EL)) , l_998)) | p_27), g_465[1])) != l_994) > 0x82A09B89L))) , (void*)0)) == 4294967292UL));
                return g_496[2];
            }
            else
            { /* block id: 472 */
                int32_t *l_1000 = (void*)0;
                int32_t *l_1001 = &g_95;
                int32_t *l_1002 = &g_46[8];
                int32_t *l_1003 = (void*)0;
                int32_t *l_1004 = (void*)0;
                int32_t *l_1005 = &g_323;
                int32_t *l_1006 = &g_46[7];
                int32_t *l_1007 = (void*)0;
                int32_t *l_1009 = &g_46[2];
                int32_t *l_1010[4][10] = {{(void*)0,&g_46[2],&g_6,&g_153,&l_999[4][1],&g_153,&g_6,&g_46[2],(void*)0,(void*)0},{(void*)0,&l_1008,&l_1008,&g_6,&g_153,(void*)0,(void*)0,&g_153,&g_6,&l_1008},{(void*)0,(void*)0,&g_153,&g_6,&l_1008,&l_1008,(void*)0,&g_6,&g_6,&l_999[4][0]},{&l_1008,(void*)0,(void*)0,(void*)0,&l_1008,&l_1008,&g_6,&g_153,(void*)0,(void*)0}};
                int64_t l_1020 = 0xA06ED3F85A353852LL;
                uint8_t l_1021 = 255UL;
                uint8_t l_1045 = 8UL;
                int i, j;
                l_1021--;
                for (g_323 = (-29); (g_323 < 25); g_323 = safe_add_func_uint8_t_u_u(g_323, 3))
                { /* block id: 476 */
                    int16_t l_1030 = 0L;
                    uint8_t *l_1031 = &g_379;
                    uint64_t *l_1034[6][6][1] = {{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}},{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}},{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}},{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}},{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}},{{&g_106},{&g_106},{&g_106},{&g_106},{&g_106},{&g_106}}};
                    int32_t l_1052 = 0x9B3AC549L;
                    int32_t l_1053 = 0xDC86AFD7L;
                    int32_t l_1055[4];
                    int i, j, k;
                    for (i = 0; i < 4; i++)
                        l_1055[i] = (-1L);
                    if ((((*l_56) == l_982) >= (safe_mul_func_uint8_t_u_u((((4L || p_28) ^ (safe_mod_func_int8_t_s_s(p_28, ((*l_1031)++)))) && ((l_1015 ^= 18446744073709551615UL) < (*l_56))), ((safe_mul_func_uint64_t_u_u((safe_unary_minus_func_int8_t_s((-1L))), ((safe_mod_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(((safe_unary_minus_func_uint8_t_u((((--l_1045) >= (safe_rshift_func_int8_t_s_s((g_120[0] = (safe_add_func_uint32_t_u_u((((*l_56) ^ 65534UL) >= 252UL), p_27))), 7))) | 0UL))) , p_28), p_27)), 7)) == 0x15L), l_999[4][1])) == g_587))) || 8UL)))))
                    { /* block id: 481 */
                        (*g_388) = &l_1016;
                    }
                    else
                    { /* block id: 483 */
                        int16_t l_1054 = (-1L);
                        l_1056++;
                        if (p_27)
                            break;
                        if (p_27)
                            continue;
                    }
                    (*l_1006) = l_1055[3];
                }
                if (p_27)
                    continue;
                return g_534;
            }
        }
    }
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_46
 */
static uint16_t  func_37(int32_t * p_38, uint32_t  p_39, int32_t * const  p_40, uint32_t  p_41, uint32_t  p_42)
{ /* block id: 4 */
    uint8_t l_44 = 255UL;
    int32_t *l_45 = &g_46[2];
    (*l_45) = l_44;
    return p_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_46 g_95 g_127 g_120 g_167 g_173 g_170 g_183 g_153 g_174 g_106 g_125 g_278 g_101 g_323 g_359 g_313 g_255 g_413 g_372 g_470 g_494 g_534 g_388 g_582 g_465 g_606 g_414 g_415 g_651 g_652 g_495 g_496 g_836 g_845 g_226 g_379 g_795 g_946
 * writes: g_46 g_153 g_255 g_95 g_174 g_101 g_183 g_313 g_278 g_120 g_170 g_323 g_359 g_372 g_379 g_388 g_173 g_106 g_420 g_470 g_534 g_606 g_652 g_415 g_465 g_845 g_795 g_167 g_972 g_973
 */
static int8_t  func_53(int32_t  p_54, int32_t * const  p_55)
{ /* block id: 14 */
    int32_t *l_76[10] = {&g_46[2],&g_46[2],&g_46[2],&g_6,&g_46[2],&g_46[2],&g_46[2],&g_46[2],&g_6,&g_46[2]};
    uint32_t *l_254 = &g_255[1][2][1];
    int32_t *l_256 = &g_95;
    int64_t l_259 = (-1L);
    const int32_t **l_969 = &g_415;
    const int32_t *l_971[1];
    const int32_t **l_970[3][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_971[0],&l_971[0],&l_971[0],&l_971[0],&l_971[0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    int i, j;
    for (i = 0; i < 1; i++)
        l_971[i] = (void*)0;
    (*g_414) = func_57(g_5, func_63(((func_65(((*l_254) = (safe_lshift_func_int8_t_s_u(g_6, func_73(l_76[7], g_46[5])))), l_256, l_256, g_167, ((l_254 != &g_167) < (-7L))) , l_259) & (*l_256))), g_465[1], &g_6, p_54);
    g_973 = (g_972 = ((*l_969) = (((*l_256) == (safe_lshift_func_uint8_t_u_s((~((safe_rshift_func_int16_t_s_s((0xF8L <= ((((((safe_unary_minus_func_int32_t_s((safe_mul_func_int16_t_s_s((((safe_mod_func_uint8_t_u_u(g_153, ((safe_mul_func_uint8_t_u_u(p_54, p_54)) || (safe_add_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u(0xE6D9L, 2)) != (safe_lshift_func_int8_t_s_u((~p_54), 1))), ((safe_lshift_func_int16_t_s_u(0x9AFAL, 9)) , 0L)))))) <= (*l_256)) && p_54), (*l_256))))) > (*l_256)) ^ 0UL) , 0x597908D8281C1227LL) | 1L) > p_54)), p_54)) , (*l_256))), 5))) , (void*)0)));
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_606 g_6 g_167 g_323 g_413 g_414 g_415 g_651 g_652 g_494 g_495 g_496 g_183 g_836 g_106 g_845 g_226 g_153 g_465 g_388 g_379 g_795 g_946 g_255 g_372
 * writes: g_606 g_372 g_323 g_652 g_415 g_465 g_534 g_845 g_313 g_153 g_795 g_101 g_174 g_167 g_120 g_106 g_379 g_170
 */
static int32_t * func_57(uint32_t  p_58, uint32_t  p_59, const uint32_t  p_60, int32_t * p_61, uint8_t  p_62)
{ /* block id: 293 */
    int32_t *l_598 = (void*)0;
    int32_t *l_599 = &g_153;
    int32_t l_600 = 0xBE16657AL;
    int32_t *l_601 = (void*)0;
    int32_t l_602 = 0L;
    int32_t l_603 = (-1L);
    int32_t *l_604[3];
    int32_t l_605 = 0xF33A9448L;
    const uint32_t *l_667 = &g_167;
    const uint32_t **l_666 = &l_667;
    int32_t ***l_701[4][6][8] = {{{(void*)0,(void*)0,&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388},{&g_388,(void*)0,&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388},{(void*)0,&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388,(void*)0},{&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388},{(void*)0,&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388,&g_388}},{{&g_388,&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388},{(void*)0,&g_388,&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,(void*)0},{&g_388,(void*)0,(void*)0,&g_388,(void*)0,(void*)0,&g_388,&g_388},{&g_388,(void*)0,&g_388,&g_388,(void*)0,&g_388,&g_388,&g_388}},{{&g_388,&g_388,&g_388,(void*)0,(void*)0,&g_388,&g_388,&g_388},{&g_388,&g_388,(void*)0,&g_388,(void*)0,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,(void*)0,&g_388},{&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,(void*)0},{&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,(void*)0,&g_388}},{{(void*)0,&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388},{&g_388,&g_388,&g_388,&g_388,(void*)0,&g_388,&g_388,(void*)0},{&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388},{&g_388,(void*)0,&g_388,&g_388,&g_388,&g_388,&g_388,&g_388},{(void*)0,(void*)0,&g_388,(void*)0,(void*)0,&g_388,&g_388,&g_388}}};
    int8_t l_770 = 0xF8L;
    uint8_t l_882 = 7UL;
    int64_t *l_905 = &g_795;
    int64_t *l_909 = &g_652;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_604[i] = &g_323;
lbl_628:
    ++g_606;
    for (g_372 = 0; (g_372 <= 1); g_372 += 1)
    { /* block id: 297 */
        uint64_t *l_620 = &g_106;
        int32_t l_624[7][5][3] = {{{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L}},{{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L}},{{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L}},{{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L}},{{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L}},{{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L}},{{1L,(-1L),0x36D49BB8L},{1L,7L,1L},{1L,0L,0L},{1L,(-1L),0x36D49BB8L},{1L,7L,1L}}};
        uint32_t l_634 = 4294967295UL;
        int8_t *l_640[3][6] = {{&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0]},{&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0]},{&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0],&g_120[0]}};
        int8_t **l_639 = &l_640[2][2];
        int32_t **l_644 = (void*)0;
        int16_t *l_650[8][9] = {{&g_173,&g_465[0],&g_173,&g_170,(void*)0,&g_170,&g_173,&g_465[0],&g_173},{&g_465[0],&g_170,&g_465[1],&g_465[1],&g_170,&g_465[0],&g_465[1],&g_170,&g_465[0]},{&g_173,&g_465[0],&g_173,&g_170,&g_170,&g_170,&g_173,&g_465[0],&g_173},{&g_465[0],&g_170,&g_465[1],&g_465[0],&g_170,&g_465[1],&g_465[1],&g_170,&g_465[0]},{&g_173,&g_465[0],&g_173,&g_170,(void*)0,&g_170,&g_173,&g_465[0],&g_173},{&g_465[0],&g_170,&g_465[1],&g_465[1],&g_170,&g_465[0],&g_465[1],&g_170,&g_465[0]},{&g_173,&g_465[0],&g_173,&g_170,&g_170,&g_170,&g_173,&g_465[0],&g_173},{&g_465[0],&g_170,&g_465[1],&g_465[0],&g_170,&g_465[1],&g_465[1],&g_170,&g_465[0]}};
        int16_t l_726 = 0xA17CL;
        const int32_t l_751 = 1L;
        uint32_t l_865 = 0UL;
        uint64_t l_884[7];
        int16_t l_892 = 1L;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_884[i] = 18446744073709551615UL;
        for (g_323 = 0; (g_323 <= 1); g_323 += 1)
        { /* block id: 300 */
            int16_t *l_625 = (void*)0;
            int32_t l_626 = 0x5A2BE47EL;
            int32_t l_630[3][2];
            int8_t l_670 = (-6L);
            uint32_t l_771[9];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_630[i][j] = (-1L);
            }
            for (i = 0; i < 9; i++)
                l_771[i] = 4294967295UL;
        }
        if ((*p_61))
            break;
        for (l_603 = 5; (l_603 >= 0); l_603 -= 1)
        { /* block id: 375 */
            uint32_t l_830[4][8][8] = {{{4UL,1UL,1UL,1UL,1UL,4UL,0UL,0xD7DF77C9L},{0xD7DF77C9L,0xB8E21185L,4294967295UL,5UL,0x15397CAFL,0x8BD0FF61L,0UL,8UL},{9UL,0xA2B88B22L,0x440E5B34L,5UL,0xD33143F9L,5UL,9UL,0xD7DF77C9L},{9UL,0xD33143F9L,0x03D21087L,1UL,0x844DEE9EL,0x80D03F07L,4294967295UL,0x433C6620L},{5UL,0x4B5D0CBDL,4294967293UL,0x844DEE9EL,0x8BD0FF61L,4294967293UL,0UL,0x62A482E6L},{1UL,5UL,5UL,0x433C6620L,0xD33143F9L,0UL,0x8BF31E33L,0xC5FBD0B0L},{4294967295UL,0UL,0x1FE4FB6DL,0x4B5D0CBDL,0x433C6620L,0x4B5D0CBDL,0x1FE4FB6DL,0UL},{0xD7DF77C9L,0x62A482E6L,0xB8E21185L,1UL,9UL,4294967293UL,0xD33143F9L,0x1FE4FB6DL}},{{0UL,0UL,0UL,0xD33143F9L,0xD7DF77C9L,1UL,0xD33143F9L,0x844DEE9EL},{8UL,0xD33143F9L,0xB8E21185L,4294967293UL,0xB30C376EL,4294967290UL,0x1FE4FB6DL,9UL},{0xB30C376EL,4294967290UL,0x1FE4FB6DL,9UL,0x03D21087L,0x8BD0FF61L,0x8BF31E33L,4294967295UL},{0xA2B88B22L,0xC5FBD0B0L,5UL,2UL,0x186C0376L,0xC91B5A5FL,0UL,0x844DEE9EL},{0UL,1UL,4294967293UL,8UL,0xAA320B04L,4294967295UL,4294967295UL,0xAA320B04L},{1UL,0x03D21087L,0x03D21087L,1UL,4294967295UL,8UL,9UL,4294967295UL},{4294967295UL,8UL,9UL,4UL,0x1FE4FB6DL,0UL,0x15397CAFL,0x4B5D0CBDL},{5UL,8UL,0UL,0x440E5B34L,4294967290UL,0xA4EA115BL,1UL,0UL}},{{4294967295UL,0x81258F92L,5UL,1UL,4294967290UL,0x6743E314L,8UL,0x440E5B34L},{0x15397CAFL,0x03D21087L,0xA2B88B22L,4294967290UL,0x03D21087L,0x433C6620L,0x80D03F07L,4294967293UL},{4294967290UL,0x4B5D0CBDL,0UL,1UL,8UL,0x9EE9E7C8L,4294967295UL,4294967295UL},{0x62A482E6L,0x47236EB1L,0xA4EA115BL,0UL,0xA4EA115BL,0x47236EB1L,0x62A482E6L,4294967290UL},{0x03D21087L,4294967295UL,0xAA320B04L,4294967290UL,1UL,2UL,0xB8E21185L,8UL},{1UL,4UL,0x2790B62BL,0x9EE9E7C8L,1UL,0x2790B62BL,0xC91B5A5FL,0UL},{0x03D21087L,1UL,0x47236EB1L,8UL,0xA4EA115BL,0xC91B5A5FL,0x1FE4FB6DL,0UL},{0x62A482E6L,0x15397CAFL,0x844DEE9EL,4UL,8UL,0UL,0x8BD0FF61L,0x15397CAFL}},{{4294967290UL,0UL,0UL,1UL,0x03D21087L,0x2790B62BL,0xA4EA115BL,0x8BD0FF61L},{0x15397CAFL,0xC91B5A5FL,0x9EE9E7C8L,4294967295UL,4294967290UL,4294967290UL,4294967295UL,0x9EE9E7C8L},{4294967295UL,4294967295UL,0UL,9UL,4294967290UL,0x186C0376L,0x8BD0FF61L,0x62A482E6L},{5UL,4294967295UL,0UL,0UL,0x1FE4FB6DL,0x9EE9E7C8L,0x81258F92L,0x62A482E6L},{4294967295UL,0UL,0x47236EB1L,9UL,0x6743E314L,4294967295UL,4UL,0x9EE9E7C8L},{0x80D03F07L,0x03D21087L,1UL,4294967295UL,0x8BD0FF61L,0xC5FBD0B0L,0xB8E21185L,0x8BD0FF61L},{1UL,0x1FE4FB6DL,0x81258F92L,1UL,0xB8E21185L,0xA4EA115BL,0UL,0x15397CAFL},{4294967295UL,0x440E5B34L,0xA4EA115BL,4UL,0x81258F92L,0UL,0x15397CAFL,0UL}}};
            int16_t **l_844 = &l_650[2][8];
            int64_t *l_849[9][1][6] = {{{&g_795,&g_795,&g_652,&g_652,&g_795,&g_795}},{{&g_652,&g_795,&g_795,(void*)0,&g_652,&g_652}},{{&g_652,&g_652,&g_652,&g_652,&g_652,&g_795}},{{&g_652,&g_652,&g_652,(void*)0,&g_795,&g_795}},{{&g_652,&g_652,&g_652,&g_652,&g_652,&g_795}},{{&g_795,&g_795,&g_652,&g_795,(void*)0,&g_795}},{{&g_652,&g_652,&g_652,&g_652,(void*)0,&g_652}},{{&g_652,&g_795,&g_795,&g_795,&g_795,&g_652}},{{&g_652,&g_652,&g_652,&g_795,&g_652,&g_652}}};
            int32_t l_864 = 1L;
            int32_t l_866 = 0x70C5CDE1L;
            int64_t **l_906[3];
            uint16_t *l_912 = &g_606;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_906[i] = &g_651;
            for (g_652 = 4; (g_652 >= 0); g_652 -= 1)
            { /* block id: 378 */
                int32_t l_832 = 0L;
                const int32_t *l_851[1][10] = {{&g_323,&g_95,&g_323,&g_95,&g_323,&g_95,&g_323,&g_95,&g_323,&g_95}};
                int8_t *l_880[3][3][9] = {{{&l_770,&g_120[2],&l_770,&g_120[0],&l_770,&g_120[2],&l_770,&g_120[2],&g_120[1]},{&l_770,&g_120[2],&g_120[3],&l_770,&g_120[2],&g_120[2],(void*)0,(void*)0,&g_120[3]},{&g_120[0],&g_120[3],&g_120[2],&g_120[2],&g_120[1],&g_120[2],&g_120[3],&g_120[2],&g_120[2]}},{{&g_120[0],(void*)0,&g_120[2],&g_120[2],(void*)0,&g_120[3],&g_120[2],&l_770,&l_770},{&l_770,(void*)0,&g_120[2],&l_770,(void*)0,(void*)0,&l_770,&g_120[2],(void*)0},{&l_770,&l_770,&g_120[3],(void*)0,&g_120[1],(void*)0,&g_120[2],&g_120[2],(void*)0}},{{(void*)0,&g_120[2],&l_770,&g_120[2],&g_120[2],&l_770,&g_120[3],&g_120[3],&l_770},{&g_120[3],&l_770,&g_120[2],&g_120[2],&l_770,&g_120[2],(void*)0,&l_770,&g_120[2]},{&g_120[2],(void*)0,&g_120[1],(void*)0,&g_120[3],&l_770,&l_770,&l_770,&g_120[3]}}};
                int32_t l_886 = 0x07440188L;
                int i, j, k;
                if (((g_167 >= g_323) , (*p_61)))
                { /* block id: 379 */
                    int32_t l_811 = (-3L);
                    int32_t l_831[2];
                    uint32_t *l_833 = &g_534;
                    int8_t **l_863 = &l_640[0][5];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_831[i] = (-1L);
                    for (l_605 = 4; (l_605 >= 0); l_605 -= 1)
                    { /* block id: 382 */
                        (*g_414) = (**g_413);
                    }
                    if ((safe_mul_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u((0x3AL | (safe_lshift_func_uint16_t_u_u(((*g_651) , ((safe_mod_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u((safe_mul_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u((0x82CE0EEBL <= l_811), p_62)) & (((*l_833) = ((safe_rshift_func_int8_t_s_s((safe_div_func_int32_t_s_s((safe_rshift_func_int16_t_s_u((safe_mod_func_int64_t_s_s((((p_58 < 0x21L) > (((safe_sub_func_int32_t_s_s((((g_465[1] = (safe_lshift_func_int16_t_s_s(0x8E28L, ((l_831[1] = ((((((safe_mul_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(((252UL & 255UL) != l_830[3][5][3]), (**g_494))), 65535UL)) , 0L) , p_58) & (-7L)) , p_58) & p_60)) , 0L)))) >= p_60) <= l_830[1][2][0]), 0x2D39F38DL)) == g_183) < (*p_61))) & p_59), (*g_651))), l_830[0][4][4])), (*p_61))), 6)) , l_832)) > (*p_61))), p_58)), 5)), p_62)) , 65527UL)), p_60))), p_62)), l_832)))
                    { /* block id: 388 */
                        int16_t ***l_846 = &g_420;
                        int16_t ***l_847[5][1][6] = {{{(void*)0,&g_420,&g_420,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_844,(void*)0,(void*)0,&g_420}},{{(void*)0,(void*)0,&g_420,&g_420,(void*)0,(void*)0}},{{&g_420,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_420,&g_420,&l_844,&l_844,&g_420}}};
                        int16_t l_848 = 0L;
                        int i, j, k;
                        if (p_58)
                            goto lbl_628;
                        (**g_413) = (*g_414);
                        (*l_599) ^= ((safe_add_func_int64_t_s_s((0x30F0AC8FL != ((g_836 == &g_837[0]) , 5L)), (((safe_div_func_int32_t_s_s((p_59 | ((g_313[l_603][(g_652 + 2)] = ((safe_mod_func_int16_t_s_s(g_106, 65528UL)) == (l_844 != (g_845 = g_845)))) >= l_848)), 1UL)) , (void*)0) != l_849[8][0][3]))) & g_226);
                        if (p_62)
                            goto lbl_628;
                    }
                    else
                    { /* block id: 395 */
                        const int32_t *l_850[5][3] = {{(void*)0,&g_95,&g_95},{&g_125,&l_811,&l_811},{(void*)0,&g_95,&g_95},{&g_125,&l_811,&l_811},{(void*)0,&g_95,&g_95}};
                        int i, j;
                        l_851[0][3] = l_850[4][1];
                        l_866 = (((safe_sub_func_int64_t_s_s((((l_831[1] || ((safe_div_func_int32_t_s_s(((((g_795 = (p_59 , (*g_651))) <= ((((((safe_mul_func_int16_t_s_s((p_62 != ((void*)0 != &g_224[1][3][7])), (((safe_add_func_int64_t_s_s((p_59 >= ((safe_rshift_func_int16_t_s_s((l_864 &= (safe_unary_minus_func_int32_t_s(((l_831[1] , &g_225[0]) != l_863)))), l_811)) >= (-1L))), 1UL)) <= 0xF872D41921DD13E4LL) , l_830[0][0][2]))) < 6UL) == 65535UL) , p_58) < 0x7A6BD1FDL) , 0xA4A3F2A4B1467B08LL)) , l_864) > l_830[3][5][3]), 4294967295UL)) < p_59)) , (*g_651)) || (*g_651)), p_59)) , 0x057AL) & l_865);
                        if (p_58)
                            goto lbl_628;
                    }
                }
                else
                { /* block id: 402 */
                    uint8_t l_874 = 0xD7L;
                    int8_t *l_875 = &l_770;
                    uint32_t l_881 = 0x4CAC18F1L;
                    uint8_t l_883 = 0xB6L;
                    int32_t l_885 = (-1L);
                    l_885 |= (((!g_496[2]) , (safe_add_func_uint64_t_u_u(18446744073709551607UL, ((l_866 = (((*l_599) , 0xCCL) || ((((*l_875) = (safe_mul_func_int16_t_s_s((((l_874 , l_875) == l_875) != (((safe_mul_func_uint8_t_u_u(((((**g_494) < (((safe_rshift_func_int16_t_s_u(((void*)0 == l_880[2][0][8]), l_881)) ^ l_882) != 0x278354BE006DB834LL)) && l_883) & (*g_651)), g_465[1])) < l_624[6][0][2]) == 0x95L)), l_866))) , l_884[6]) > (*p_61)))) <= 0x975EL)))) & p_59);
                    (*g_388) = p_61;
                }
                for (p_59 = 0; (p_59 <= 0); p_59 += 1)
                { /* block id: 410 */
                    return p_61;
                }
                (*l_599) &= l_886;
            }
            for (l_770 = 0; (l_770 <= 0); l_770 += 1)
            { /* block id: 417 */
                uint64_t *l_898 = &l_884[3];
                int32_t l_899 = 0x55E4055DL;
                for (g_174 = 0; (g_174 >= 0); g_174 -= 1)
                { /* block id: 420 */
                    for (g_606 = 0; (g_606 <= 0); g_606 += 1)
                    { /* block id: 423 */
                        uint16_t *l_891[9][4] = {{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183},{&g_313[2][1],&g_183,&g_313[2][1],&g_183}};
                        int32_t l_893[9][10][2] = {{{0L,0L},{0xE40ED594L,0x829EB76CL},{0xA4123BA6L,1L},{(-1L),0L},{0x46CA77A7L,(-1L)},{0xD7D6D483L,0L},{0x8B4A6378L,0x6FFC6498L},{(-8L),3L},{0x6FFC6498L,0x8884AEAEL},{0L,0x82AC15FFL}},{{0x23049D76L,(-5L)},{(-2L),0x6D695BEEL},{0x6494EC52L,0x58178E8FL},{0L,0x8B4A6378L},{0x9B6D4910L,(-1L)},{0x0DF61D94L,(-1L)},{0x6D695BEEL,0x94A5AEBAL},{1L,0x94A5AEBAL},{0x6D695BEEL,(-1L)},{0x0DF61D94L,(-1L)}},{{0x9B6D4910L,0x8B4A6378L},{0L,0x58178E8FL},{0x6494EC52L,0x6D695BEEL},{(-2L),(-5L)},{0x23049D76L,0x82AC15FFL},{0L,0x8884AEAEL},{0x6FFC6498L,3L},{(-8L),0x6FFC6498L},{0x8B4A6378L,0L},{0xD7D6D483L,0L}},{{(-8L),1L},{0L,0x8884AEAEL},{0xF5D8637AL,0x0DF61D94L},{0x23049D76L,(-2L)},{(-5L),0x6D695BEEL},{0x47770C97L,1L},{0L,0xD7D6D483L},{0xEE5C0E0FL,(-1L)},{0x82AC15FFL,9L},{0x6D695BEEL,(-4L)}},{{(-1L),0x94A5AEBAL},{0x5BA6E1DCL,9L},{0x0DF61D94L,1L},{0xEE5C0E0FL,0x8B4A6378L},{0x4845F9F3L,1L},{0x6494EC52L,0x5BA6E1DCL},{(-5L),(-5L)},{0L,0x0DF61D94L},{0L,(-7L)},{0L,3L}},{{(-1L),0L},{0x8B4A6378L,8L},{0x8B4A6378L,0L},{(-1L),3L},{0L,(-7L)},{0L,0x0DF61D94L},{0L,(-5L)},{(-5L),0x5BA6E1DCL},{0x6494EC52L,1L},{0x4845F9F3L,0x8B4A6378L}},{{0xEE5C0E0FL,1L},{0x0DF61D94L,9L},{0x5BA6E1DCL,0x94A5AEBAL},{(-1L),(-4L)},{0x6D695BEEL,9L},{0x82AC15FFL,(-1L)},{0xEE5C0E0FL,0xD7D6D483L},{0L,1L},{0x47770C97L,0x6D695BEEL},{(-5L),(-2L)}},{{0x23049D76L,0x0DF61D94L},{0xF5D8637AL,0x8884AEAEL},{0L,1L},{(-8L),0L},{0xD7D6D483L,0L},{0x8B4A6378L,0x6FFC6498L},{(-8L),3L},{0x6FFC6498L,0x8884AEAEL},{0L,0x82AC15FFL},{0x23049D76L,(-5L)}},{{(-2L),0x6D695BEEL},{0x6494EC52L,0x58178E8FL},{0L,0x8B4A6378L},{0x9B6D4910L,(-1L)},{0x0DF61D94L,(-1L)},{0x6D695BEEL,0x94A5AEBAL},{1L,0x94A5AEBAL},{0x6D695BEEL,(-1L)},{0x0DF61D94L,(-1L)},{0x9B6D4910L,0x8B4A6378L}}};
                        int32_t l_900[6] = {0xD34C061CL,0x10C7D955L,0x10C7D955L,0xD34C061CL,0x10C7D955L,0x10C7D955L};
                        int i, j, k;
                        g_323 = (p_62 || (safe_add_func_int32_t_s_s((safe_mod_func_int8_t_s_s(((p_62 < (((g_313[2][1] = 0x4A39L) , ((((((g_167 |= (l_892 , l_893[1][9][0])) , ((*l_599) = ((safe_rshift_func_int16_t_s_s(((safe_div_func_uint8_t_u_u(((((void*)0 == l_898) == (*p_61)) || ((l_830[3][4][5] , (*p_61)) < l_893[1][9][0])), l_830[3][5][3])) && l_899), p_58)) , (*p_61)))) <= l_900[0]) , p_58) || (**g_494)) >= l_900[0])) != 0xB77ED5434289EBCELL)) | p_59), 3UL)), (*p_61))));
                    }
                    (*l_599) |= l_899;
                    if (p_60)
                        goto lbl_628;
                }
            }
            (**g_413) = ((((safe_mod_func_int16_t_s_s((safe_sub_func_int8_t_s_s(((**l_639) = ((l_905 = l_905) != (l_909 = ((0x1D56L && (safe_rshift_func_int8_t_s_s(p_59, p_58))) , l_909)))), (l_830[3][3][7] | (safe_rshift_func_uint8_t_u_u((((0xD2ABL | (l_864 = (g_465[1] = (l_650[0][7] == l_912)))) & p_58) , g_183), 1))))), (-1L))) <= (**g_494)) , p_62) , p_61);
        }
    }
    for (g_106 = (-18); (g_106 > 40); g_106 = safe_add_func_uint32_t_u_u(g_106, 2))
    { /* block id: 443 */
        const int32_t *l_915 = &g_46[2];
        (**g_413) = l_915;
    }
    for (g_379 = 0; (g_379 != 44); g_379 = safe_add_func_uint32_t_u_u(g_379, 6))
    { /* block id: 448 */
        uint16_t l_924[6][5][4] = {{{0x9625L,0x81D5L,0UL,3UL},{0x9C40L,0UL,6UL,0x81D5L},{0xE38BL,0UL,6UL,65534UL},{0x9C40L,0x9AD2L,0UL,0x7766L},{6UL,0x2BD1L,0x81D5L,0xE38BL}},{{0x81D5L,0xE38BL,0x2199L,0x9AD2L},{0x173FL,0x3548L,0x3548L,0x173FL},{3UL,0x4F86L,6UL,0UL},{0x329DL,0x2199L,0x173FL,0x2BD1L},{1UL,1UL,0xE38BL,0x2BD1L}},{{0UL,0x2199L,65526UL,0UL},{0x3548L,0x4F86L,0UL,0x173FL},{1UL,0x3548L,65535UL,0x9AD2L},{0x9625L,0xE38BL,65526UL,0xE38BL},{0xA3D0L,0x2BD1L,1UL,0x7766L}},{{65534UL,0UL,0x7766L,0x3548L},{0x9AD2L,0x9625L,0x2BD1L,1UL},{0x9AD2L,1UL,0x7766L,65534UL},{65534UL,1UL,1UL,1UL},{0xA3D0L,0x56AEL,65526UL,6UL}},{{0x9625L,65526UL,65535UL,65535UL},{1UL,1UL,0UL,0UL},{0x3548L,0x81D5L,65526UL,0x4F86L},{0UL,0x329DL,0xE38BL,65526UL},{1UL,0x329DL,0x173FL,0x4F86L}},{{0x329DL,0x81D5L,6UL,0UL},{3UL,1UL,0x3548L,65535UL},{0x173FL,65526UL,0x2199L,6UL},{0x81D5L,0x56AEL,0x81D5L,1UL},{6UL,1UL,0x9625L,65534UL}}};
        int16_t *l_945 = &g_170;
        int32_t l_947 = (-1L);
        int i, j, k;
        for (g_795 = 8; (g_795 < 3); g_795 = safe_sub_func_int8_t_s_s(g_795, 3))
        { /* block id: 451 */
            int64_t l_920[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            (*l_599) &= ((g_170 = l_920[6]) < (safe_sub_func_uint8_t_u_u((safe_unary_minus_func_int64_t_s(p_58)), 0L)));
            return &g_46[2];
        }
        l_924[1][2][0]++;
        l_947 ^= (safe_add_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u((((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_s(0x49L, p_62)), p_59)) >= (safe_div_func_uint8_t_u_u(((65535UL == (safe_div_func_int32_t_s_s(l_924[2][3][0], (safe_lshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((p_60 & ((void*)0 == l_945)), (0x8505E2D9L & g_946))), 8)), 2))))) != 0x0EL), g_255[1][2][1]))) ^ 0L), 6)), l_924[4][1][0]));
    }
    return p_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_106 g_127 g_174 g_170 g_183 g_46 g_125 g_120 g_95 g_278 g_101 g_323 g_153 g_359 g_313 g_6 g_255 g_173 g_413 g_372 g_470 g_167 g_494 g_534 g_388 g_582
 * writes: g_95 g_174 g_101 g_183 g_313 g_278 g_120 g_170 g_46 g_323 g_359 g_372 g_379 g_388 g_173 g_106 g_153 g_420 g_470 g_534
 */
static uint32_t  func_63(const int8_t  p_64)
{ /* block id: 106 */
    int64_t l_271 = (-6L);
    int32_t l_272 = 0x1685AF8AL;
    int32_t l_274 = 0x39C704BBL;
    int32_t l_279 = 0x4657D04DL;
    int32_t l_280 = 0x1DC0C745L;
    int32_t l_281 = 0xAEB905F6L;
    int32_t l_282 = 0x5AF26B09L;
    int32_t l_283 = 0x2CB2800CL;
    int32_t l_284 = 0L;
    int32_t l_285 = 0L;
    int32_t l_286 = 0x9A290CDDL;
    int32_t l_287 = 0x219075D6L;
    int32_t l_288[6] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
    uint32_t l_290 = 1UL;
    uint32_t *l_375 = &l_290;
    uint32_t * const *l_374 = &l_375;
    int64_t l_376 = 0L;
    const int32_t **l_380 = (void*)0;
    uint8_t l_383 = 0x59L;
    int32_t **l_389 = &g_101;
    int32_t ***l_390 = &l_389;
    int16_t *l_395 = (void*)0;
    int16_t *l_396 = &g_173;
    uint64_t *l_404[8][5] = {{&g_106,&g_106,&g_106,&g_106,&g_106},{&g_106,&g_106,&g_106,(void*)0,(void*)0},{&g_106,&g_106,&g_106,&g_106,(void*)0},{&g_106,(void*)0,(void*)0,&g_106,&g_106},{&g_106,&g_106,&g_106,(void*)0,&g_106},{&g_106,&g_106,&g_106,&g_106,&g_106},{&g_106,&g_106,&g_106,(void*)0,(void*)0},{&g_106,&g_106,&g_106,&g_106,&g_106}};
    uint8_t *l_405 = (void*)0;
    const int32_t l_406[6][6] = {{0xFFC98CE2L,0xFFC98CE2L,(-2L),0L,3L,0L},{0xC85D9A51L,0xFFC98CE2L,0xC85D9A51L,0L,(-2L),(-2L)},{1L,0xC85D9A51L,0xC85D9A51L,1L,0xFFC98CE2L,0L},{0L,1L,(-2L),1L,0L,0L},{1L,0L,0L,0L,0L,0xC85D9A51L},{0L,0xC85D9A51L,3L,0L,3L,0xC85D9A51L}};
    uint16_t *l_407 = &g_313[2][1];
    int16_t *l_408[9][5] = {{&g_170,&g_170,&g_170,&g_170,&g_170},{&g_170,&g_170,&g_170,(void*)0,&g_170},{(void*)0,&g_170,(void*)0,&g_170,&g_170},{&g_170,&g_170,&g_170,&g_170,&g_170},{(void*)0,&g_170,&g_170,&g_170,&g_170},{&g_170,(void*)0,&g_170,&g_170,&g_170},{&g_170,&g_170,&g_170,&g_170,&g_170},{(void*)0,(void*)0,&g_170,&g_170,&g_170},{(void*)0,&g_170,&g_170,&g_170,(void*)0}};
    uint64_t l_409 = 2UL;
    int8_t *l_410[6] = {(void*)0,(void*)0,&g_120[2],(void*)0,(void*)0,&g_120[2]};
    const uint32_t l_516 = 18446744073709551615UL;
    int i, j;
lbl_424:
    for (g_95 = 0; (g_95 >= 20); g_95++)
    { /* block id: 109 */
        int32_t *l_262 = &g_153;
        int32_t *l_263 = &g_46[2];
        int32_t *l_264[9][7][1] = {{{(void*)0},{(void*)0},{&g_6},{&g_153},{&g_6},{(void*)0},{(void*)0}},{{&g_95},{&g_153},{&g_95},{(void*)0},{(void*)0},{&g_6},{&g_153}},{{&g_6},{(void*)0},{(void*)0},{&g_95},{&g_153},{&g_95},{(void*)0}},{{(void*)0},{&g_6},{&g_153},{&g_6},{(void*)0},{(void*)0},{&g_95}},{{&g_153},{&g_95},{(void*)0},{(void*)0},{&g_6},{&g_153},{&g_6}},{{(void*)0},{(void*)0},{&g_95},{&g_153},{&g_95},{(void*)0},{(void*)0}},{{&g_6},{&g_153},{&g_6},{(void*)0},{(void*)0},{&g_95},{&g_153}},{{&g_95},{(void*)0},{(void*)0},{&g_6},{&g_153},{&g_6},{(void*)0}},{{(void*)0},{&g_95},{&g_153},{&g_95},{(void*)0},{(void*)0},{&g_6}}};
        uint32_t l_265 = 3UL;
        int i, j, k;
        --l_265;
    }
    for (g_174 = 16; (g_174 != 10); g_174--)
    { /* block id: 114 */
        int32_t **l_270 = &g_101;
        int32_t *l_273 = (void*)0;
        int32_t *l_275 = (void*)0;
        int32_t *l_276 = (void*)0;
        int32_t *l_277[4];
        int32_t l_289 = 3L;
        int16_t *l_305 = &g_170;
        uint16_t *l_308 = &g_183;
        uint16_t *l_311 = (void*)0;
        uint16_t *l_312 = &g_313[2][1];
        int32_t *l_322 = &g_278[0];
        int i;
        for (i = 0; i < 4; i++)
            l_277[i] = &l_274;
        if (p_64)
            break;
        (*l_270) = &g_46[2];
        --l_290;
        g_323 |= ((*g_101) = (g_106 < ((*l_305) = (((safe_mod_func_int16_t_s_s((((((((((safe_sub_func_int64_t_s_s(g_127, ((safe_mul_func_uint8_t_u_u(((l_282 = ((safe_mul_func_uint8_t_u_u((((l_284 |= ((g_120[2] |= ((safe_div_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(((g_174 , l_305) != ((safe_mod_func_uint16_t_u_u(((*l_312) = ((g_170 || g_106) , (--(*l_308)))), 1L)) , l_308)), ((safe_sub_func_uint16_t_u_u(((((*l_322) = (safe_lshift_func_uint16_t_u_u(((safe_mod_func_int64_t_s_s((safe_mul_func_int8_t_s_s(0xB9L, 250UL)), (-1L))) , g_46[8]), p_64))) , 4294967295UL) , 65535UL), 1L)) , p_64))), l_279)) ^ g_125)) , 1UL)) < g_170) != p_64), g_95)) && g_46[3])) , g_125), g_46[2])) , g_120[2]))) && g_278[0]) != g_125) < 0xA48C5682L) && p_64) , 0x00AAD98337A895C0LL) , (-1L)) , &g_228) == &g_228), g_46[1])) | p_64) >= l_279))));
    }
    for (l_290 = 0; (l_290 <= 57); l_290 = safe_add_func_int64_t_s_s(l_290, 8))
    { /* block id: 130 */
        uint8_t *l_358 = &g_359;
        uint16_t *l_362[2];
        uint16_t *l_364 = &g_183;
        uint16_t **l_363 = &l_364;
        uint32_t **l_373 = (void*)0;
        int32_t l_377 = 0L;
        uint8_t *l_378 = &g_379;
        int32_t **l_381 = (void*)0;
        int8_t *l_382 = &g_120[0];
        int32_t *l_384[10] = {&l_280,(void*)0,&l_280,(void*)0,&l_280,(void*)0,&l_280,(void*)0,&l_280,(void*)0};
        int i;
        for (i = 0; i < 2; i++)
            l_362[i] = &g_183;
        l_281 = (safe_sub_func_int32_t_s_s((((!(g_174 , (((((*l_382) = (safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((g_46[2] == (safe_lshift_func_uint8_t_u_s(255UL, 3))) , ((((((safe_lshift_func_uint8_t_u_s(((*l_378) = (!(safe_mul_func_uint8_t_u_u(g_153, (safe_sub_func_uint32_t_u_u(((safe_mod_func_int32_t_s_s(((((+((safe_add_func_int8_t_s_s(((safe_mod_func_int16_t_s_s(((((+(((safe_mul_func_int16_t_s_s(((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(0x3AF4L, ((((*l_358)--) , l_362[1]) != ((*l_363) = l_362[1])))), (((safe_mod_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((((!(safe_sub_func_int8_t_s_s(((g_372 = g_313[1][2]) ^ (((l_373 == l_374) != g_6) == g_278[0])), 0xFFL))) >= g_183) >= l_376), 6)), p_64)) > 0x5BD3L) <= 65527UL))) && l_377), 0x453DL)) || 4294967295UL) == 0x91L)) , g_120[0]) , l_377) <= l_377), 65529UL)) && p_64), 0xACL)) != l_377)) , g_255[1][2][1]) < 0xF7FF7380DA34F26FLL) , l_377), p_64)) > g_255[0][5][3]), g_313[2][6])))))), 5)) >= g_183) && p_64) , l_380) != l_381) >= g_323)), (-4L))), g_173)), 0x66E6B32DL))) > g_278[0]) , &g_167) != (*l_374)))) <= p_64) && l_383), (-10L)));
    }
    if ((((l_287 = (((((safe_mul_func_uint8_t_u_u(p_64, (((+(p_64 , ((g_388 = &g_101) == ((*l_390) = l_389)))) , (l_409 = (safe_lshift_func_uint8_t_u_s((safe_sub_func_int16_t_s_s(((*l_396) ^= 0xEDCDL), ((*l_407) = (safe_div_func_uint8_t_u_u(0x59L, (((safe_mod_func_uint16_t_u_u((((+((g_359 &= ((((g_106 = (safe_sub_func_int16_t_s_s((((0UL || ((0x996438B3L || ((g_255[4][6][2] < p_64) , p_64)) || p_64)) | 4L) <= g_313[2][1]), p_64))) == g_278[0]) ^ g_125) > p_64)) || g_125)) != p_64) || g_278[0]), l_406[1][3])) > 249UL) && p_64)))))), 6)))) , g_313[2][1]))) != p_64) ^ 0x2F83595FL) ^ 0xD4L) & g_6)) ^ g_46[2]) | p_64))
    { /* block id: 146 */
        int8_t l_423 = (-1L);
        int32_t l_443[5][6] = {{0xAD22CCE8L,0x9BDEC7DBL,0x17CCD04CL,0x17CCD04CL,0x9BDEC7DBL,0xAD22CCE8L},{0x6EEC3FB8L,0xAD22CCE8L,0x17CCD04CL,0xAD22CCE8L,0x6EEC3FB8L,0x6EEC3FB8L},{0xAF5E4E25L,0xAD22CCE8L,0xAD22CCE8L,0xAF5E4E25L,0x9BDEC7DBL,0xAF5E4E25L},{0xAF5E4E25L,0x9BDEC7DBL,0xAF5E4E25L,0xAD22CCE8L,0xAD22CCE8L,0xAF5E4E25L},{0x6EEC3FB8L,0x6EEC3FB8L,0xAD22CCE8L,0x17CCD04CL,0xAD22CCE8L,0x6EEC3FB8L}};
        uint32_t *l_447 = &l_290;
        int32_t l_459 = 0L;
        int32_t l_466[1];
        int32_t l_485 = 0x23EB383CL;
        int32_t l_486 = 2L;
        volatile uint64_t **l_498 = &g_495;
        int i, j;
        for (i = 0; i < 1; i++)
            l_466[i] = 0x4C694B76L;
        for (g_153 = 0; (g_153 < (-8)); g_153 = safe_sub_func_int32_t_s_s(g_153, 6))
        { /* block id: 149 */
            int32_t *l_416 = &g_323;
            int16_t **l_419 = &l_396;
            int16_t ***l_418[3];
            int32_t l_442[5][5] = {{0xDF06D251L,0x672B21F5L,0x672B21F5L,0xDF06D251L,0x672B21F5L},{0xDF06D251L,0xDF06D251L,0L,0xDF06D251L,0xDF06D251L},{0x672B21F5L,0xDF06D251L,0x672B21F5L,0x672B21F5L,0xDF06D251L},{0xDF06D251L,0x672B21F5L,0x672B21F5L,0xDF06D251L,0x672B21F5L},{0xDF06D251L,0xDF06D251L,0L,0xDF06D251L,0xDF06D251L}};
            uint32_t l_444 = 9UL;
            uint32_t l_487 = 9UL;
            volatile uint64_t ***l_497[8][9][1] = {{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{(void*)0},{&g_494},{&g_494}},{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494}},{{&g_494},{&g_494},{(void*)0},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494}},{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{(void*)0},{&g_494}},{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494}},{{&g_494},{&g_494},{&g_494},{(void*)0},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494}},{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{(void*)0}},{{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494},{&g_494}}};
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_418[i] = &l_419;
            (*l_416) = ((void*)0 != g_413);
            if ((((((**l_374) = (safe_unary_minus_func_int8_t_s((&l_395 != (g_420 = &l_408[0][0]))))) > ((((p_64 , ((g_372 > (((~p_64) , (safe_unary_minus_func_int16_t_s((*l_416)))) , (g_170 ^= ((**l_419) = l_423)))) != g_278[0])) || p_64) ^ 0x6CEAL) != p_64)) ^ g_6) >= 7UL))
            { /* block id: 155 */
                if (g_170)
                    goto lbl_424;
                for (l_423 = 0; (l_423 >= 5); l_423 = safe_add_func_uint32_t_u_u(l_423, 6))
                { /* block id: 159 */
                    if (p_64)
                        break;
                }
            }
            else
            { /* block id: 162 */
                int16_t l_427[7] = {8L,8L,8L,8L,8L,8L,8L};
                int32_t l_440[10] = {0xAF36EF52L,0xAF36EF52L,0x37FD78E8L,0xAF36EF52L,0xAF36EF52L,0x37FD78E8L,0xAF36EF52L,0xAF36EF52L,0x37FD78E8L,0xAF36EF52L};
                uint32_t l_460[1];
                int32_t *l_478[2][3];
                int i, j;
                for (i = 0; i < 1; i++)
                    l_460[i] = 0xD9670A18L;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_478[i][j] = &g_95;
                }
                if (l_427[1])
                { /* block id: 163 */
                    uint32_t l_430 = 18446744073709551615UL;
                    int32_t l_441 = 0x37553275L;
                    for (l_272 = 6; (l_272 == 17); ++l_272)
                    { /* block id: 166 */
                        int32_t *l_433 = &l_279;
                        int32_t *l_434 = &g_46[2];
                        int32_t *l_435 = &l_288[4];
                        int32_t *l_436 = &l_281;
                        int32_t *l_437 = (void*)0;
                        int32_t *l_438 = &g_46[5];
                        int32_t *l_439[1];
                        int32_t l_448 = 0L;
                        int i;
                        for (i = 0; i < 1; i++)
                            l_439[i] = &l_285;
                        --l_430;
                        ++l_444;
                        l_448 &= (l_447 != (void*)0);
                        if (l_443[2][1])
                            break;
                    }
                    (*l_389) = &l_442[4][3];
                }
                else
                { /* block id: 173 */
                    int32_t l_451[5];
                    int32_t *l_452 = &l_288[3];
                    int32_t *l_453 = &l_281;
                    int32_t *l_454 = &g_323;
                    int32_t *l_455 = &l_451[1];
                    int32_t *l_456 = &l_443[1][4];
                    int32_t *l_457 = &l_285;
                    int32_t *l_458[8][5][3] = {{{&l_440[6],&g_323,&l_280},{(void*)0,(void*)0,(void*)0},{&l_443[1][0],&l_279,&l_288[4]},{&l_279,&g_95,(void*)0},{&l_280,&l_282,&l_280}},{{&g_95,&g_6,&l_274},{&l_443[1][0],&l_282,&l_284},{&g_95,&g_95,&l_442[1][0]},{&l_440[6],&l_279,&l_280},{&g_95,(void*)0,&g_6}},{{&l_443[1][0],&g_323,&l_288[4]},{&g_95,&g_95,&g_6},{&l_280,&l_440[6],&l_280},{&l_279,&g_6,&l_442[1][0]},{&l_443[1][0],&l_440[6],&l_284}},{{(void*)0,&g_95,&l_274},{&l_440[6],&g_323,&l_280},{(void*)0,(void*)0,(void*)0},{&l_443[1][0],&l_279,&l_288[4]},{&l_279,&g_95,(void*)0}},{{&l_280,&l_282,&l_280},{&g_95,&g_6,&l_274},{&l_443[1][0],&l_282,&l_284},{&g_95,&g_95,&l_442[1][0]},{&l_440[6],&l_279,&l_280}},{{&g_95,(void*)0,&g_6},{&l_443[1][0],&g_323,&l_288[4]},{&g_95,&g_95,&g_6},{&l_280,&l_440[6],&l_280},{&l_279,&g_6,&l_442[1][0]}},{{&l_443[1][0],&l_440[6],&l_284},{(void*)0,&g_95,&l_274},{&l_440[6],&g_323,&l_280},{(void*)0,(void*)0,(void*)0},{&l_443[1][0],&l_279,&l_288[4]}},{{&l_279,&g_95,(void*)0},{&l_280,&l_282,&l_280},{&g_95,&g_6,&l_274},{&l_443[1][0],&l_282,&l_284},{&g_95,&g_95,&l_442[1][0]}}};
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_451[i] = (-8L);
                    if (p_64)
                        break;
                    for (g_323 = 0; (g_323 >= 7); g_323 = safe_add_func_int8_t_s_s(g_323, 2))
                    { /* block id: 177 */
                        if (p_64)
                            break;
                        if (l_451[3])
                            break;
                    }
                    --l_460[0];
                    for (l_286 = (-5); (l_286 >= (-18)); l_286 = safe_sub_func_uint32_t_u_u(l_286, 9))
                    { /* block id: 184 */
                        int16_t l_467 = 0xE148L;
                        int32_t l_468 = 0x2693A10AL;
                        int32_t l_469[3][10][3] = {{{0xBADC442CL,1L,0x893BD8DBL},{0x613C404AL,0x613C404AL,0x893BD8DBL},{1L,0xBADC442CL,(-8L)},{(-4L),0x613C404AL,(-4L)},{(-4L),1L,0x613C404AL},{1L,(-4L),(-4L)},{0x613C404AL,(-4L),(-8L)},{0xBADC442CL,1L,0x893BD8DBL},{0x613C404AL,0x613C404AL,0x893BD8DBL},{1L,0xBADC442CL,(-8L)}},{{(-4L),0x613C404AL,(-4L)},{(-4L),1L,0x613C404AL},{1L,(-4L),(-4L)},{0x613C404AL,(-4L),(-8L)},{0xBADC442CL,1L,0x893BD8DBL},{0x613C404AL,0x613C404AL,0x893BD8DBL},{1L,0xBADC442CL,(-8L)},{(-4L),0x613C404AL,(-4L)},{(-4L),1L,0x613C404AL},{1L,(-4L),(-4L)}},{{0x613C404AL,(-4L),(-8L)},{0xBADC442CL,1L,0x893BD8DBL},{0x613C404AL,0x613C404AL,0x893BD8DBL},{1L,0xBADC442CL,(-8L)},{(-4L),0x613C404AL,(-4L)},{(-4L),1L,0x613C404AL},{1L,(-4L),(-4L)},{0x613C404AL,(-4L),(-8L)},{0xBADC442CL,1L,0x893BD8DBL},{0x613C404AL,0x613C404AL,0x893BD8DBL}}};
                        int i, j, k;
                        (*l_454) |= p_64;
                        g_470++;
                        return g_153;
                    }
                }
                l_442[1][0] |= (g_323 , (safe_sub_func_uint16_t_u_u(((*l_407)++), (p_64 ^ (safe_unary_minus_func_int16_t_s(((*l_396) &= ((void*)0 != l_416))))))));
                for (l_271 = 0; (l_271 < 27); l_271++)
                { /* block id: 195 */
                    int32_t l_481 = (-2L);
                    int16_t l_482 = 0x0158L;
                    int32_t l_483 = 0L;
                    int32_t l_484[5][2] = {{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}};
                    int i, j;
                    l_481 = p_64;
                    ++l_487;
                    for (l_383 = 0; (l_383 < 31); l_383++)
                    { /* block id: 200 */
                        (*l_416) &= (g_167 | (safe_lshift_func_int16_t_s_s(p_64, (&l_460[0] != (void*)0))));
                    }
                }
            }
            if (p_64)
                continue;
            l_498 = g_494;
        }
    }
    else
    { /* block id: 208 */
        const uint64_t l_507 = 18446744073709551615UL;
        int32_t l_519[9] = {0x72EDA093L,0L,0x72EDA093L,0L,0x72EDA093L,0L,0x72EDA093L,0L,0x72EDA093L};
        int32_t l_523 = (-1L);
        int16_t *l_575 = &g_465[3];
        int i;
        for (g_323 = 7; (g_323 >= 0); g_323 -= 1)
        { /* block id: 211 */
            int64_t *l_517[5][1][5] = {{{&l_271,&l_271,&l_271,&l_271,&l_271}},{{&l_271,&l_271,&l_271,&l_271,&l_271}},{{&l_271,&l_271,&l_271,&l_271,&l_271}},{{&l_271,&l_271,&l_271,&l_271,&l_271}},{{&l_271,&l_271,&l_271,&l_271,&l_271}}};
            int32_t l_518 = 0L;
            int32_t l_529 = (-3L);
            int32_t l_530 = 0x98217C87L;
            int32_t l_531 = 1L;
            int32_t l_532 = 0xBDA6B83AL;
            int32_t l_533[10][5][1] = {{{0L},{(-1L)},{(-10L)},{(-1L)},{0L}},{{1L},{(-1L)},{(-10L)},{(-1L)},{1L}},{{0L},{(-1L)},{(-10L)},{(-1L)},{0L}},{{1L},{(-1L)},{(-10L)},{(-1L)},{1L}},{{0L},{(-1L)},{(-10L)},{(-1L)},{0L}},{{1L},{(-1L)},{(-10L)},{(-1L)},{1L}},{{0L},{(-1L)},{(-10L)},{(-1L)},{0L}},{{1L},{(-1L)},{(-10L)},{(-1L)},{1L}},{{0L},{(-1L)},{(-10L)},{(-1L)},{2L}},{{1L},{(-10L)},{1L},{(-10L)},{1L}}};
            int32_t *l_537[6] = {&l_519[1],&l_519[1],&l_519[1],&l_519[1],&l_519[1],&l_519[1]};
            uint16_t l_548[5];
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_548[i] = 0xF9CBL;
            if ((((g_46[(g_323 + 1)] , (l_519[1] ^= (safe_rshift_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((g_46[g_323] || g_46[1]), (safe_rshift_func_int16_t_s_u(p_64, ((safe_div_func_uint16_t_u_u((l_507 | ((((((**l_374) = g_46[3]) != g_46[(g_323 + 1)]) ^ (l_518 ^= ((++g_359) , (safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((((*l_396) = g_46[g_323]) & ((*l_407) &= (safe_mul_func_int16_t_s_s(p_64, l_516)))), p_64)), 0x576D3139L))))) , p_64) >= g_6)), 0x876FL)) != p_64))))), 4)))) < p_64) <= g_46[g_323]))
            { /* block id: 218 */
                int32_t *l_520[10][6] = {{&l_279,(void*)0,&g_153,&g_46[g_323],&l_283,&g_46[2]},{&l_284,&g_6,&l_279,&l_284,&l_284,&l_284},{&l_283,&g_46[g_323],&l_283,&g_153,&g_153,&l_283},{&l_283,&l_519[1],&l_288[4],(void*)0,(void*)0,&g_6},{&l_519[1],&g_153,&l_284,(void*)0,&l_518,&g_153},{&l_283,&l_279,&l_284,&g_153,&g_153,&l_284},{&l_283,&l_283,&l_284,&l_284,&l_285,&l_519[1]},{&l_284,&l_288[4],&l_285,&g_46[g_323],&l_284,&l_284},{&l_279,&l_284,&l_285,&l_284,&l_283,&l_519[1]},{&g_46[2],&l_284,&l_284,(void*)0,&l_284,&l_284}};
                int i, j;
                g_46[(g_323 + 1)] &= 0x981B59CCL;
                for (g_95 = 5; (g_95 >= 1); g_95 -= 1)
                { /* block id: 222 */
                    int8_t l_521[2][7][9] = {{{0xAAL,0xAAL,0L,0x1EL,0L,0xAAL,0xAAL,0L,0x1EL},{0xE3L,0xDEL,0xE3L,1L,1L,0xE3L,0xDEL,0xE3L,1L},{(-2L),0L,0L,(-2L),0L,(-2L),0L,0L,(-2L)},{(-3L),1L,6L,1L,(-3L),(-3L),1L,6L,1L},{0L,0L,0x1EL,0x1EL,0L,0L,0L,0x1EL,0x1EL},{(-3L),(-3L),1L,6L,1L,(-3L),(-3L),1L,6L},{(-2L),0L,(-2L),0L,0L,(-2L),0L,(-2L),0L}},{{0xE3L,1L,1L,0xE3L,0xDEL,0xE3L,1L,1L,0xE3L},{0xAAL,0L,0x1EL,0L,0xAAL,0xAAL,0L,0x1EL,0L},{1L,0xDEL,6L,6L,0xDEL,1L,0xDEL,6L,6L},{0xAAL,0xAAL,0L,0x1EL,0L,0xAAL,0xAAL,0L,0x1EL},{0xE3L,0xDEL,0xE3L,1L,1L,0xE3L,0xDEL,0xE3L,1L},{(-2L),0L,0L,(-2L),0L,(-2L),0L,0L,(-2L)},{(-3L),0xE3L,0xDEL,0xE3L,1L,1L,0xE3L,0xDEL,0xE3L}}};
                    int32_t l_522 = 1L;
                    int32_t l_524 = 0x228FCCAEL;
                    int32_t l_525 = (-10L);
                    int32_t l_526 = 0xCB07EB74L;
                    int8_t l_527 = 6L;
                    int32_t l_528[1][1][9];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 1; j++)
                        {
                            for (k = 0; k < 9; k++)
                                l_528[i][j][k] = (-6L);
                        }
                    }
                    --g_534;
                    l_520[4][5] = &l_529;
                    for (l_284 = 5; (l_284 >= 1); l_284 -= 1)
                    { /* block id: 227 */
                        int16_t l_538 = 0x8049L;
                        l_537[3] = ((*g_388) = &l_525);
                        (*g_101) ^= l_538;
                    }
                }
                if (p_64)
                    break;
                for (l_283 = 3; (l_283 >= 0); l_283 -= 1)
                { /* block id: 236 */
                    uint8_t l_539 = 0x06L;
                    uint8_t *l_540 = (void*)0;
                    uint8_t *l_541 = &g_372;
                    int32_t l_544 = (-1L);
                    l_539 = (p_64 || ((*l_396) = 2L));
                    g_46[2] = (((*l_541) = 0x9FL) || ((void*)0 != l_520[6][5]));
                    for (g_174 = 3; (g_174 >= 0); g_174 -= 1)
                    { /* block id: 243 */
                        int32_t l_545 = 0x4D1698D6L;
                        int32_t l_546 = 0x5DA97EC9L;
                        int32_t l_547 = (-1L);
                        l_519[1] = (safe_rshift_func_uint8_t_u_u(255UL, 5));
                        l_548[1]++;
                        if (p_64)
                            break;
                    }
                    if (p_64)
                        break;
                    for (g_470 = 1; (g_470 <= 5); g_470 += 1)
                    { /* block id: 251 */
                        (*g_388) = (void*)0;
                    }
                }
            }
            else
            { /* block id: 255 */
                int16_t *l_574 = &g_170;
                int32_t l_577 = 0x28A392D0L;
                l_523 &= p_64;
                if (p_64)
                { /* block id: 257 */
                    uint32_t l_551 = 0x3639B090L;
                    int32_t l_594 = 0x04FB2B8CL;
                    int32_t l_595 = (-3L);
                    for (g_153 = 0; (g_153 <= 3); g_153 += 1)
                    { /* block id: 260 */
                        int32_t l_576[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_576[i] = 0xC52208D6L;
                        l_551++;
                        if (p_64)
                            break;
                        l_576[0] = ((((safe_div_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_s((safe_sub_func_int8_t_s_s((4294967293UL <= ((((l_551 < (safe_add_func_int16_t_s_s((((safe_mul_func_uint8_t_u_u((g_167 , p_64), (safe_lshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_mul_func_int16_t_s_s(((l_519[6] = ((((*l_375) = l_551) ^ (g_255[3][1][2] < ((g_183 >= ((l_574 != l_575) & l_551)) >= l_576[0]))) ^ p_64)) || 1UL), 1L)) , 0xC5L), 5)), p_64)), p_64)), l_523)))) <= 0x8DE8D97EL) || (-1L)), p_64))) <= l_577) | g_183) , g_153)), p_64)), g_170)) ^ p_64), p_64)) , 1L) || 1UL) <= g_278[1]);
                        l_576[0] ^= (-7L);
                    }
                    for (l_518 = 3; (l_518 >= 0); l_518 -= 1)
                    { /* block id: 270 */
                        const uint16_t * const l_585[9] = {&g_587,&g_587,&g_587,&g_587,&g_587,&g_587,&g_587,&g_587,&g_587};
                        const uint16_t * const *l_584 = &l_585[6];
                        int32_t l_590 = 0L;
                        uint8_t *l_592 = &g_359;
                        int32_t l_593 = 9L;
                        int i;
                        l_595 &= (((safe_add_func_int32_t_s_s(p_64, (((l_594 = (((((safe_sub_func_int16_t_s_s((((l_593 &= (((-1L) | ((((l_519[1] , &l_407) == (l_584 = g_582[3])) , g_278[0]) >= ((g_174 = l_551) , (safe_sub_func_int64_t_s_s(((l_590 >= ((safe_unary_minus_func_uint8_t_u(((*l_592) = p_64))) , 8L)) , 0L), p_64))))) | 0xE3L)) , 0x3EL) > l_590), 65535UL)) ^ p_64) , l_577) ^ p_64) == l_577)) , 5UL) , p_64))) == p_64) <= p_64);
                    }
                    return p_64;
                }
                else
                { /* block id: 279 */
                    return p_64;
                }
            }
            for (l_285 = 3; (l_285 >= 0); l_285 -= 1)
            { /* block id: 285 */
                int32_t **l_596 = &l_537[3];
                int8_t l_597 = 0x33L;
                (*l_596) = ((*g_388) = &l_523);
                return l_597;
            }
        }
    }
    return p_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static int64_t  func_65(uint32_t  p_66, int32_t * p_67, int32_t * p_68, uint32_t  p_69, uint32_t  p_70)
{ /* block id: 103 */
    const int32_t *l_258 = &g_95;
    const int32_t **l_257 = &l_258;
    (*l_257) = &g_127;
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_46 g_95 g_127 g_120 g_167 g_173 g_170 g_183 g_153
 * writes: g_46 g_153
 */
static uint8_t  func_73(int32_t * p_74, uint32_t  p_75)
{ /* block id: 15 */
    int32_t *l_77[8][9] = {{&g_46[8],&g_6,&g_46[2],&g_46[2],&g_46[2],&g_46[1],&g_46[1],&g_46[2],&g_46[2]},{&g_46[8],&g_46[2],&g_46[8],&g_46[2],&g_6,(void*)0,&g_46[1],&g_6,&g_46[2]},{&g_46[8],&g_6,&g_46[2],&g_46[2],&g_6,&g_46[2],&g_46[1],&g_6,&g_46[2]},{&g_46[8],&g_6,&g_46[2],&g_46[2],&g_46[2],&g_46[1],&g_46[1],&g_46[2],&g_46[2]},{&g_46[8],&g_46[2],&g_46[8],&g_46[2],&g_6,(void*)0,&g_46[1],&g_6,&g_46[2]},{&g_46[8],&g_6,&g_46[2],&g_46[2],&g_6,&g_46[2],&g_46[1],&g_6,&g_46[2]},{&g_46[8],&g_6,&g_46[2],&g_46[2],&g_46[2],&g_46[1],&g_46[1],&g_46[2],&g_46[2]},{&g_46[8],&g_46[2],&g_46[8],&g_46[2],&g_6,(void*)0,&g_46[1],&g_6,&g_46[2]}};
    int32_t **l_87 = &l_77[4][6];
    int32_t **l_88 = (void*)0;
    int32_t **l_89 = (void*)0;
    int32_t *l_91 = &g_46[4];
    int32_t **l_90 = &l_91;
    int32_t *l_92 = &g_46[2];
    int8_t *l_144 = &g_120[2];
    int16_t *l_217 = &g_170;
    int64_t l_236 = 0xCDB2E776E5D696A6LL;
    uint16_t l_245 = 0xCD3FL;
    int i, j;
    g_46[2] = 0x6DDF936BL;
    if (((*l_92) = ((safe_mul_func_uint16_t_u_u((((*p_74) > (safe_rshift_func_uint8_t_u_u(1UL, 4))) > (&g_46[2] != p_74)), (~(safe_div_func_uint16_t_u_u(p_75, (g_46[2] | p_75)))))) & (safe_sub_func_int8_t_s_s((((*l_87) = (void*)0) != ((*l_90) = (void*)0)), (-1L))))))
    { /* block id: 20 */
        p_74 = &g_6;
    }
    else
    { /* block id: 22 */
        int8_t l_102 = 0xC7L;
        const int32_t *l_126 = &g_127;
        int32_t l_128 = (-10L);
        int32_t l_154 = 0xFD2558CDL;
        int8_t **l_162 = &l_144;
        uint16_t l_189 = 0UL;
        int32_t l_208 = 0x9F7BF7F2L;
        int16_t *l_221 = &g_170;
        for (p_75 = (-28); (p_75 > 50); p_75 = safe_add_func_uint8_t_u_u(p_75, 2))
        { /* block id: 25 */
            uint8_t l_118[1][6][5] = {{{0x34L,255UL,0xBAL,250UL,0x03L},{0xBAL,255UL,0x34L,0x34L,255UL},{1UL,0x10L,0xBAL,255UL,0x03L},{0x10L,0x34L,0xBAL,0x92L,0xBAL},{0x03L,0x03L,0x34L,1UL,0x5DL},{0x10L,0x5DL,0xBAL,1UL,1UL}}};
            int32_t l_131[7][9][4] = {{{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L}},{{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x0BAEA442L,(-1L),0xE9A70309L,0x0BAEA442L},{0x0BAEA442L,(-1L),(-1L),0x0BAEA442L}},{{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL}},{{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL}},{{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL}},{{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL}},{{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL},{(-10L),(-1L),0xE9A70309L,(-10L)},{0x8CE927CFL,(-1L),(-1L),0x8CE927CFL},{0x8CE927CFL,0xE9A70309L,0xE9A70309L,0x8CE927CFL}}};
            int8_t *l_147[10] = {&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2],&g_120[2]};
            int64_t l_171 = 0xFF29F3A5184A0F19LL;
            int32_t ** const l_188 = &l_77[5][6];
            int32_t *l_193[6][10] = {{&l_131[5][4][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]},{&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]},{&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]},{&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]},{&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]},{&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0],&l_131[6][2][0],&l_154,&l_131[6][2][0],&l_131[5][4][0],&l_131[5][4][0]}};
            uint32_t l_231 = 0xCCDFA724L;
            int i, j, k;
        }
        return g_95;
    }
    g_153 = ((((*p_74) & ((safe_lshift_func_uint8_t_u_u(l_236, 1)) == (safe_div_func_int64_t_s_s((((safe_mul_func_int8_t_s_s(g_127, (((safe_sub_func_int64_t_s_s((*l_92), (safe_mod_func_int8_t_s_s(g_95, l_245)))) , (g_120[2] | (safe_rshift_func_uint8_t_u_s(((safe_rshift_func_int8_t_s_s(0x1AL, (safe_rshift_func_int16_t_s_u(((safe_mod_func_int32_t_s_s(g_167, 0x584DEB07L)) > g_120[2]), g_173)))) , 0x97L), 2)))) >= g_170))) , g_183) | (-1L)), g_153)))) > p_75) == 0xC8L);
    return p_75;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_46[i], "g_46[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_120[i], "g_120[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_167, "g_167", print_hash_value);
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_173, "g_173", print_hash_value);
    transparent_crc(g_174, "g_174", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    transparent_crc(g_226, "g_226", print_hash_value);
    transparent_crc(g_229, "g_229", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_255[i][j][k], "g_255[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_278[i], "g_278[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_313[i][j], "g_313[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_323, "g_323", print_hash_value);
    transparent_crc(g_359, "g_359", print_hash_value);
    transparent_crc(g_372, "g_372", print_hash_value);
    transparent_crc(g_379, "g_379", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_465[i], "g_465[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_470, "g_470", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_496[i], "g_496[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_534, "g_534", print_hash_value);
    transparent_crc(g_586, "g_586", print_hash_value);
    transparent_crc(g_587, "g_587", print_hash_value);
    transparent_crc(g_606, "g_606", print_hash_value);
    transparent_crc(g_652, "g_652", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_724[i], "g_724[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_795, "g_795", print_hash_value);
    transparent_crc(g_946, "g_946", print_hash_value);
    transparent_crc(g_1019, "g_1019", print_hash_value);
    transparent_crc(g_1060, "g_1060", print_hash_value);
    transparent_crc(g_1062, "g_1062", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 260
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 58
breakdown:
   depth: 1, occurrence: 148
   depth: 2, occurrence: 42
   depth: 3, occurrence: 2
   depth: 4, occurrence: 4
   depth: 7, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 4
   depth: 27, occurrence: 1
   depth: 29, occurrence: 1
   depth: 31, occurrence: 1
   depth: 34, occurrence: 1
   depth: 40, occurrence: 2
   depth: 41, occurrence: 1
   depth: 47, occurrence: 1
   depth: 58, occurrence: 1

XXX total number of pointers: 211

XXX times a variable address is taken: 525
XXX times a pointer is dereferenced on RHS: 59
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 11
XXX times a pointer is dereferenced on LHS: 95
breakdown:
   depth: 1, occurrence: 84
   depth: 2, occurrence: 11
XXX times a pointer is compared with null: 19
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 7
XXX times a pointer is qualified to be dereferenced: 3649

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 508
   level: 2, occurrence: 155
   level: 3, occurrence: 28
XXX number of pointers point to pointers: 57
XXX number of pointers point to scalars: 154
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 37.4
XXX average alias set size: 1.63

XXX times a non-volatile is read: 709
XXX times a non-volatile is write: 365
XXX times a volatile is read: 26
XXX    times read thru a pointer: 18
XXX times a volatile is write: 14
XXX    times written thru a pointer: 13
XXX times a volatile is available for access: 269
XXX percentage of non-volatile access: 96.4

XXX forward jumps: 0
XXX backward jumps: 7

XXX stmts: 153
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 22
   depth: 2, occurrence: 12
   depth: 3, occurrence: 23
   depth: 4, occurrence: 32
   depth: 5, occurrence: 34

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
********************* end of statistics **********************/

