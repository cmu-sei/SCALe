/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2896785277
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   uint8_t  f0;
   uint32_t  f1;
   uint32_t  f2;
   volatile uint16_t  f3;
   int8_t  f4;
   uint64_t  f5;
};
#pragma pack(pop)

union U1 {
   int32_t  f0;
   int8_t * f1;
   int32_t  f2;
   volatile int32_t  f3;
   const uint8_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x0BE39E3CL;
static struct S0 g_5 = {4UL,0x6F1860ECL,0x1E6E2BFBL,1UL,0xB5L,0x008CF5A8B060D2F3LL};/* VOLATILE GLOBAL g_5 */
static int8_t *g_38 = &g_5.f4;
static struct S0 g_44 = {255UL,0x3F0E26A2L,4294967295UL,1UL,0x90L,0x7D93CBFB41CE094BLL};/* VOLATILE GLOBAL g_44 */
static int32_t * const  volatile g_45 = (void*)0;/* VOLATILE GLOBAL g_45 */
static int32_t * volatile g_46 = &g_2;/* VOLATILE GLOBAL g_46 */
static int32_t * volatile g_47 = &g_2;/* VOLATILE GLOBAL g_47 */
static struct S0 g_52 = {1UL,2UL,0x47BEBA6EL,65535UL,-6L,18446744073709551615UL};/* VOLATILE GLOBAL g_52 */
static int32_t g_73[6] = {2L,2L,2L,2L,2L,2L};
static int8_t g_74 = 0L;
static volatile uint16_t g_75 = 65527UL;/* VOLATILE GLOBAL g_75 */
static volatile union U1 *g_82 = (void*)0;
static volatile union U1 ** volatile g_83 = (void*)0;/* VOLATILE GLOBAL g_83 */
static volatile union U1 ** volatile g_84 = &g_82;/* VOLATILE GLOBAL g_84 */
static const volatile struct S0 g_105 = {0x5BL,0x510901DBL,4294967295UL,0xD3F5L,0x1BL,18446744073709551610UL};/* VOLATILE GLOBAL g_105 */
static volatile struct S0 g_107[4] = {{250UL,0x80774EDEL,0xB14B258EL,3UL,-6L,0UL},{250UL,0x80774EDEL,0xB14B258EL,3UL,-6L,0UL},{250UL,0x80774EDEL,0xB14B258EL,3UL,-6L,0UL},{250UL,0x80774EDEL,0xB14B258EL,3UL,-6L,0UL}};
static int32_t g_111 = (-1L);
static int8_t g_117 = 0x0FL;
static union U1 g_128 = {0L};/* VOLATILE GLOBAL g_128 */
static int64_t g_137 = 0xF60A75A90C89A788LL;
static union U1 g_138[5] = {{0x24AF6D02L},{0x24AF6D02L},{0x24AF6D02L},{0x24AF6D02L},{0x24AF6D02L}};
static volatile int32_t g_156 = 0x01E95282L;/* VOLATILE GLOBAL g_156 */
static uint32_t g_157 = 0UL;
static volatile uint32_t ** volatile * volatile g_165 = (void*)0;/* VOLATILE GLOBAL g_165 */
static uint32_t *g_169 = (void*)0;
static uint64_t g_183 = 0xBBA4A270C91F9636LL;
static uint16_t g_185[5][5][7] = {{{0xE0F3L,0xAD85L,0x85E6L,65535UL,65531UL,65533UL,0x0057L},{65529UL,0UL,0x0BDDL,0x94C1L,0xEB4EL,0xCD8DL,1UL},{0UL,65535UL,0x7329L,65535UL,0x7329L,65535UL,0UL},{0x0181L,1UL,3UL,0UL,0x79F0L,65535UL,0x0BDDL},{3UL,65535UL,0xCD65L,0xC85EL,3UL,65535UL,4UL}},{{0xCD8DL,0x0181L,0x3BD1L,0x3BD1L,0x0181L,0xCD8DL,65535UL},{1UL,0xC2A3L,3UL,65535UL,0UL,65535UL,3UL},{1UL,1UL,1UL,0x4C46L,65529UL,0x0BDDL,1UL},{0xE0F3L,0xC2A3L,0x0057L,0xC2A3L,0xE0F3L,65533UL,0xCD65L},{8UL,0x0181L,0x59F4L,0x94C1L,0xCD8DL,65535UL,0xFDB9L}},{{3UL,65535UL,65526UL,0xAD85L,0UL,0xC85EL,0UL},{8UL,0x94C1L,0x94C1L,8UL,0x79F0L,0x59F4L,1UL},{0xE0F3L,0x4A21L,0xCD65L,65535UL,3UL,0x4A21L,65530UL},{1UL,65529UL,0x3BD1L,0x94C1L,0UL,1UL,1UL},{1UL,0xF0D2L,1UL,0xC85EL,3UL,65535UL,0UL}},{{0xCD8DL,0xFDB9L,0x0335L,0x4C46L,0x0181L,1UL,0xFDB9L},{1UL,0xC2A3L,0xCD65L,65535UL,8UL,65535UL,0xCD65L},{0UL,0UL,1UL,0x3BD1L,0xCD8DL,1UL,1UL},{0x7329L,0xC85EL,65526UL,0xC2A3L,0x7329L,0x4A21L,3UL},{8UL,0xFDB9L,3UL,65529UL,0xCD8DL,0x59F4L,65535UL}},{{3UL,65535UL,0x0057L,65535UL,8UL,0xC85EL,4UL},{65535UL,65529UL,0x94C1L,3UL,0x0181L,65535UL,1UL},{0x7329L,65533UL,3UL,65535UL,3UL,65533UL,0x7329L},{1UL,0x94C1L,0x0335L,65529UL,0UL,0x0BDDL,0x94C1L},{1UL,0xF0D2L,0x85E6L,0xC2A3L,3UL,65535UL,4UL}}};
static uint16_t g_187 = 0x8BE3L;
static uint32_t **g_207 = (void*)0;
static int32_t *g_214 = &g_111;
static int32_t ** volatile g_213 = &g_214;/* VOLATILE GLOBAL g_213 */
static struct S0 g_247 = {0UL,2UL,0x3D50A5C8L,8UL,1L,0x77A41760703F90AALL};/* VOLATILE GLOBAL g_247 */
static int16_t g_253 = 0x2748L;
static uint32_t g_255 = 0xD3D2653FL;
static struct S0 g_266 = {253UL,0x95469C6DL,0x04B7867BL,65535UL,-1L,0x80768C82B81AD9B4LL};/* VOLATILE GLOBAL g_266 */
static struct S0 *g_283 = &g_44;
static volatile union U1 g_295 = {0x51A1F884L};/* VOLATILE GLOBAL g_295 */
static struct S0 g_330 = {0x25L,0x16218FCEL,3UL,65527UL,0x1FL,18446744073709551608UL};/* VOLATILE GLOBAL g_330 */
static int8_t g_332 = 0xEDL;
static volatile uint64_t g_333 = 0x3D50FF0D4A56B307LL;/* VOLATILE GLOBAL g_333 */
static volatile union U1 g_351 = {1L};/* VOLATILE GLOBAL g_351 */
static union U1 g_361 = {0xB416169CL};/* VOLATILE GLOBAL g_361 */
static struct S0 g_402 = {247UL,0x58054032L,0x59FE71D0L,0x711AL,0L,5UL};/* VOLATILE GLOBAL g_402 */
static union U1 g_407[8] = {{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L}};
static const union U1 g_420 = {0x25A4937AL};/* VOLATILE GLOBAL g_420 */
static union U1 g_463 = {-3L};/* VOLATILE GLOBAL g_463 */
static volatile struct S0 g_489 = {0x28L,0x1A2BCB8EL,4294967295UL,0UL,0xDAL,18446744073709551608UL};/* VOLATILE GLOBAL g_489 */
static struct S0 g_503 = {1UL,18446744073709551606UL,0xB382801FL,0x295FL,0x00L,0x331221698A5A4341LL};/* VOLATILE GLOBAL g_503 */
static struct S0 * volatile g_504 = &g_330;/* VOLATILE GLOBAL g_504 */
static int32_t ** volatile g_506[1] = {&g_214};
static union U1 g_511[3][6] = {{{0L},{0L},{0x72235E69L},{5L},{0x72235E69L},{0L}},{{0x72235E69L},{-9L},{5L},{5L},{-9L},{0x72235E69L}},{{0L},{0x72235E69L},{5L},{0x72235E69L},{0L},{0L}}};
static volatile int8_t g_531 = 1L;/* VOLATILE GLOBAL g_531 */
static int32_t ** volatile g_618[8][7][4] = {{{&g_214,&g_214,(void*)0,(void*)0},{&g_214,&g_214,(void*)0,&g_214},{(void*)0,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,(void*)0,&g_214},{(void*)0,&g_214,&g_214,&g_214},{(void*)0,(void*)0,&g_214,&g_214}},{{&g_214,&g_214,&g_214,&g_214},{(void*)0,(void*)0,&g_214,&g_214},{(void*)0,(void*)0,&g_214,&g_214},{(void*)0,&g_214,(void*)0,&g_214},{&g_214,(void*)0,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214}},{{&g_214,&g_214,&g_214,(void*)0},{(void*)0,(void*)0,&g_214,(void*)0},{&g_214,(void*)0,(void*)0,&g_214},{(void*)0,(void*)0,&g_214,(void*)0},{&g_214,&g_214,(void*)0,&g_214},{(void*)0,&g_214,&g_214,(void*)0},{(void*)0,&g_214,&g_214,&g_214}},{{&g_214,&g_214,(void*)0,&g_214},{&g_214,(void*)0,&g_214,&g_214},{&g_214,(void*)0,&g_214,&g_214},{&g_214,(void*)0,&g_214,(void*)0},{&g_214,&g_214,&g_214,(void*)0},{&g_214,&g_214,&g_214,(void*)0},{&g_214,(void*)0,&g_214,&g_214}},{{&g_214,&g_214,&g_214,(void*)0},{&g_214,(void*)0,&g_214,(void*)0},{&g_214,&g_214,(void*)0,&g_214},{&g_214,&g_214,&g_214,(void*)0},{(void*)0,(void*)0,&g_214,(void*)0},{(void*)0,&g_214,(void*)0,&g_214},{&g_214,&g_214,&g_214,(void*)0}},{{(void*)0,&g_214,(void*)0,(void*)0},{&g_214,(void*)0,&g_214,&g_214},{(void*)0,&g_214,&g_214,(void*)0},{&g_214,(void*)0,&g_214,&g_214},{&g_214,(void*)0,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,(void*)0,&g_214}},{{(void*)0,&g_214,&g_214,(void*)0},{(void*)0,&g_214,&g_214,(void*)0},{(void*)0,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{(void*)0,&g_214,&g_214,&g_214},{(void*)0,(void*)0,&g_214,&g_214},{&g_214,(void*)0,&g_214,(void*)0}},{{(void*)0,&g_214,&g_214,&g_214},{(void*)0,(void*)0,&g_214,(void*)0},{&g_214,&g_214,&g_214,(void*)0},{(void*)0,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214}}};
static volatile struct S0 g_630 = {0x4FL,0UL,1UL,0xD580L,0xCBL,1UL};/* VOLATILE GLOBAL g_630 */
static union U1 g_637 = {-5L};/* VOLATILE GLOBAL g_637 */
static struct S0 g_656 = {0x31L,9UL,0xD1BC1759L,0UL,0x28L,0x31C3065EA106DAE3LL};/* VOLATILE GLOBAL g_656 */
static volatile uint32_t g_664[1] = {0UL};
static int32_t ** volatile g_722 = &g_214;/* VOLATILE GLOBAL g_722 */
static volatile union U1 g_723 = {0x089D4AFAL};/* VOLATILE GLOBAL g_723 */
static const union U1 g_742 = {0x2A5EA375L};/* VOLATILE GLOBAL g_742 */
static struct S0 g_776[4] = {{5UL,0xCC9656FDL,0x0F0D664EL,1UL,0xD8L,0x78786AA34C36F626LL},{5UL,0xCC9656FDL,0x0F0D664EL,1UL,0xD8L,0x78786AA34C36F626LL},{5UL,0xCC9656FDL,0x0F0D664EL,1UL,0xD8L,0x78786AA34C36F626LL},{5UL,0xCC9656FDL,0x0F0D664EL,1UL,0xD8L,0x78786AA34C36F626LL}};
static uint16_t * volatile g_815 = &g_187;/* VOLATILE GLOBAL g_815 */
static uint16_t * volatile * volatile g_814[5] = {&g_815,&g_815,&g_815,&g_815,&g_815};
static uint16_t * volatile * volatile * volatile g_816 = &g_814[3];/* VOLATILE GLOBAL g_816 */
static union U1 g_824[9] = {{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL},{0xE389501AL}};
static union U1 g_830[2] = {{0L},{0L}};
static const union U1 *g_832 = (void*)0;
static volatile struct S0 g_847 = {0xEDL,1UL,0UL,0xE9ACL,0x32L,0x546FA785E4A52F4ELL};/* VOLATILE GLOBAL g_847 */
static struct S0 g_851[4][3][4] = {{{{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{0UL,18446744073709551609UL,4294967295UL,0x3EABL,0x5CL,0UL},{1UL,0x5EFD74DDL,8UL,0x5BB3L,0L,18446744073709551613UL}},{{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL},{248UL,0x381753A2L,1UL,1UL,0L,18446744073709551609UL},{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL},{1UL,0x5EFD74DDL,8UL,0x5BB3L,0L,18446744073709551613UL}},{{0UL,18446744073709551609UL,4294967295UL,0x3EABL,0x5CL,0UL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{1UL,0xB0E8C8A8L,3UL,1UL,0L,0x0E4BB135F2B272E0LL}}},{{{246UL,4UL,0UL,0UL,-7L,0x201BF7DE4513DFBBLL},{249UL,0x057F57DAL,0x40501505L,0x709FL,2L,0x26CB8D9BA3865130LL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL}},{{0x88L,0UL,0x66BDF6E2L,0xC432L,-1L,0x6210A38E803AAF55LL},{0x88L,0UL,0x66BDF6E2L,0xC432L,-1L,0x6210A38E803AAF55LL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL}},{{246UL,4UL,0UL,0UL,-7L,0x201BF7DE4513DFBBLL},{7UL,0xB24F95FEL,8UL,0xBA03L,1L,0xD69999852B17F3ABLL},{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{249UL,0x057F57DAL,0x40501505L,0x709FL,2L,0x26CB8D9BA3865130LL}}},{{{0UL,18446744073709551609UL,4294967295UL,0x3EABL,0x5CL,0UL},{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL},{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL}},{{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL},{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{0UL,18446744073709551609UL,4294967295UL,0x3EABL,0x5CL,0UL},{249UL,0x057F57DAL,0x40501505L,0x709FL,2L,0x26CB8D9BA3865130LL}},{{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{7UL,0xB24F95FEL,8UL,0xBA03L,1L,0xD69999852B17F3ABLL},{246UL,4UL,0UL,0UL,-7L,0x201BF7DE4513DFBBLL},{0x95L,18446744073709551615UL,0UL,7UL,0xEAL,0x6DAA3947388DCBAFLL}}},{{{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{0x88L,0UL,0x66BDF6E2L,0xC432L,-1L,0x6210A38E803AAF55LL},{0x88L,0UL,0x66BDF6E2L,0xC432L,-1L,0x6210A38E803AAF55LL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL}},{{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{249UL,0x057F57DAL,0x40501505L,0x709FL,2L,0x26CB8D9BA3865130LL},{246UL,4UL,0UL,0UL,-7L,0x201BF7DE4513DFBBLL},{1UL,0xB0E8C8A8L,3UL,1UL,0L,0x0E4BB135F2B272E0LL}},{{247UL,0UL,0xEE0EF8F1L,0xB5E0L,-9L,0x66889D30F996F893LL},{255UL,0x50B3416DL,0xCC5A45EEL,0x4889L,0x3CL,2UL},{0UL,18446744073709551609UL,4294967295UL,0x3EABL,0x5CL,0UL},{1UL,0x5EFD74DDL,8UL,0x5BB3L,0L,18446744073709551613UL}}}};
static struct S0 **g_877 = &g_283;
static struct S0 ***g_876 = &g_877;
static union U1 g_885[1][9][6] = {{{{0x0953AA16L},{0xF939911FL},{0xF939911FL},{0x0953AA16L},{0xFED8164AL},{0x5973245FL}},{{0x3BB5A1A2L},{1L},{-1L},{0x5973245FL},{0x5357FDDAL},{-9L}},{{0x5357FDDAL},{0xFED8164AL},{0xC74C1995L},{0xFED8164AL},{0x5357FDDAL},{0x14EEF485L}},{{-9L},{1L},{0L},{0x991E846AL},{0xFED8164AL},{-1L}},{{-1L},{0xF939911FL},{1L},{1L},{0xF939911FL},{-1L}},{{0x991E846AL},{0x5973245FL},{0L},{0x5357FDDAL},{-1L},{0x14EEF485L}},{{0xF939911FL},{-9L},{0xC74C1995L},{-1L},{0xC74C1995L},{-9L}},{{0xF939911FL},{0x14EEF485L},{-1L},{0x5357FDDAL},{0L},{0x5973245FL}},{{0x991E846AL},{-1L},{0xF939911FL},{1L},{1L},{0xF939911FL}}}};
static int32_t g_903[2] = {0x657515F4L,0x657515F4L};
static union U1 g_904 = {-9L};/* VOLATILE GLOBAL g_904 */
static uint8_t g_911 = 0x07L;
static volatile uint32_t g_954 = 0x630879F3L;/* VOLATILE GLOBAL g_954 */
static int32_t ** volatile g_958 = (void*)0;/* VOLATILE GLOBAL g_958 */
static const int64_t g_1019 = 0x0434BCC80471D9AELL;
static const int64_t g_1021 = 0x4AE3BEA30522CB58LL;
static volatile uint16_t g_1028 = 65530UL;/* VOLATILE GLOBAL g_1028 */
static int32_t ** volatile g_1031 = (void*)0;/* VOLATILE GLOBAL g_1031 */
static volatile int8_t g_1048[4][9][1] = {{{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L}},{{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L}},{{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L}},{{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L},{7L},{0xA1L}}};
static volatile struct S0 g_1089 = {0x1DL,0UL,4294967292UL,0x66A8L,0x87L,0xD82F93E7121EF335LL};/* VOLATILE GLOBAL g_1089 */
static union U1 g_1123 = {-1L};/* VOLATILE GLOBAL g_1123 */
static volatile uint8_t g_1135 = 1UL;/* VOLATILE GLOBAL g_1135 */
static volatile union U1 g_1164 = {8L};/* VOLATILE GLOBAL g_1164 */
static volatile struct S0 g_1174 = {0x0CL,0UL,0x26F7AD33L,0x6BF0L,1L,18446744073709551608UL};/* VOLATILE GLOBAL g_1174 */
static union U1 g_1180 = {0L};/* VOLATILE GLOBAL g_1180 */
static union U1 *g_1179 = &g_1180;
static int32_t ** volatile g_1209 = &g_214;/* VOLATILE GLOBAL g_1209 */
static int32_t * volatile g_1214 = (void*)0;/* VOLATILE GLOBAL g_1214 */
static int32_t *g_1258 = (void*)0;
static int32_t ** volatile g_1257 = &g_1258;/* VOLATILE GLOBAL g_1257 */
static uint8_t g_1286 = 0xB1L;
static int32_t ** volatile g_1291 = &g_214;/* VOLATILE GLOBAL g_1291 */
static int32_t * volatile * volatile g_1292 = &g_214;/* VOLATILE GLOBAL g_1292 */
static volatile int32_t g_1308 = (-1L);/* VOLATILE GLOBAL g_1308 */
static volatile union U1 g_1333 = {0xE93F9A69L};/* VOLATILE GLOBAL g_1333 */
static int32_t g_1338 = 0x52D1379AL;
static const int32_t *g_1352 = &g_407[1].f2;
static const int32_t **g_1351[7][8] = {{&g_1352,(void*)0,(void*)0,&g_1352,&g_1352,&g_1352,(void*)0,(void*)0},{(void*)0,&g_1352,&g_1352,&g_1352,&g_1352,(void*)0,&g_1352,&g_1352},{&g_1352,(void*)0,&g_1352,&g_1352,&g_1352,&g_1352,(void*)0,&g_1352},{(void*)0,&g_1352,&g_1352,&g_1352,(void*)0,(void*)0,&g_1352,&g_1352},{(void*)0,(void*)0,&g_1352,&g_1352,&g_1352,(void*)0,(void*)0,&g_1352},{&g_1352,&g_1352,&g_1352,&g_1352,(void*)0,&g_1352,&g_1352,&g_1352},{&g_1352,(void*)0,&g_1352,&g_1352,(void*)0,&g_1352,(void*)0,&g_1352}};
static struct S0 g_1364[10] = {{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x93L,0xE7331E54L,4294967295UL,0x24F3L,0x00L,5UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x93L,0xE7331E54L,4294967295UL,0x24F3L,0x00L,5UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL},{0x93L,0xE7331E54L,4294967295UL,0x24F3L,0x00L,5UL},{0x32L,0x6B52705FL,0x8C7AA491L,0UL,-1L,0UL}};
static int64_t g_1404 = 5L;
static struct S0 g_1424[6] = {{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL},{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL},{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL},{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL},{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL},{0xB8L,0x1BE1AF82L,0x347588B1L,65530UL,0xFFL,0x7DEB8C0B03716A8DLL}};
static struct S0 ****g_1452 = &g_876;
static uint64_t *g_1489 = &g_247.f5;
static volatile union U1 g_1551 = {0x9BEFB0B1L};/* VOLATILE GLOBAL g_1551 */
static struct S0 g_1561 = {7UL,0x1268D73BL,4294967288UL,65535UL,1L,0x13C3443C620A3C84LL};/* VOLATILE GLOBAL g_1561 */
static int16_t g_1609 = 0x4A9AL;
static int16_t g_1611 = 0L;
static volatile uint8_t * volatile g_1660[5] = {&g_489.f0,&g_489.f0,&g_489.f0,&g_489.f0,&g_489.f0};
static volatile uint8_t * volatile *g_1659 = &g_1660[2];
static uint16_t g_1666 = 1UL;
static union U1 g_1695 = {8L};/* VOLATILE GLOBAL g_1695 */
static union U1 g_1696 = {0x7870FBF6L};/* VOLATILE GLOBAL g_1696 */
static const volatile struct S0 g_1736 = {0UL,18446744073709551606UL,0x39D54EAFL,6UL,5L,0x2D22A4532B5D198FLL};/* VOLATILE GLOBAL g_1736 */
static const struct S0 g_1743 = {249UL,18446744073709551615UL,8UL,6UL,-1L,18446744073709551613UL};/* VOLATILE GLOBAL g_1743 */
static int32_t ** volatile g_1784 = (void*)0;/* VOLATILE GLOBAL g_1784 */
static int32_t *g_1808 = &g_361.f0;
static int32_t **g_1837 = &g_214;
static volatile union U1 g_1874 = {1L};/* VOLATILE GLOBAL g_1874 */
static volatile struct S0 g_1880 = {0x20L,0x8D76643CL,0x284E5745L,3UL,0x72L,0xF8A345A290A37692LL};/* VOLATILE GLOBAL g_1880 */
static struct S0 g_1924 = {251UL,1UL,2UL,0xAEC8L,0x9BL,18446744073709551615UL};/* VOLATILE GLOBAL g_1924 */
static volatile union U1 g_1954 = {0x2C8CA830L};/* VOLATILE GLOBAL g_1954 */
static const uint64_t g_1963[2] = {0UL,0UL};
static volatile union U1 g_2029 = {-7L};/* VOLATILE GLOBAL g_2029 */
static struct S0 g_2088 = {1UL,0xC3E4E9F7L,4294967292UL,0x6EE1L,0xFAL,0UL};/* VOLATILE GLOBAL g_2088 */
static struct S0 g_2121 = {8UL,0x5D407F0BL,6UL,65535UL,0x46L,18446744073709551614UL};/* VOLATILE GLOBAL g_2121 */
static volatile struct S0 g_2123 = {1UL,0x99FB023EL,0x15DE05DAL,1UL,0x0DL,1UL};/* VOLATILE GLOBAL g_2123 */
static volatile struct S0 g_2124 = {0x94L,0x934F545EL,0x28FDEB77L,0x78FAL,-1L,0xA3CFCE2949F4FFCFLL};/* VOLATILE GLOBAL g_2124 */
static struct S0 * volatile *** volatile **g_2126[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static volatile union U1 g_2147 = {0xC444C9CAL};/* VOLATILE GLOBAL g_2147 */
static struct S0 g_2157 = {0x1DL,0x1A4AC155L,0xA0D0A060L,0x7BADL,0xE3L,0UL};/* VOLATILE GLOBAL g_2157 */
static uint64_t g_2183 = 0x247421FA51574812LL;
static volatile union U1 g_2242 = {1L};/* VOLATILE GLOBAL g_2242 */
static uint16_t *g_2260 = &g_185[3][2][1];
static uint16_t **g_2259[1] = {&g_2260};
static int32_t g_2265[6][7][2] = {{{1L,4L},{1L,(-1L)},{0x46FF5760L,1L},{(-1L),4L},{0L,0L},{0x46FF5760L,0L},{0L,4L}},{{(-1L),1L},{0x46FF5760L,(-1L)},{1L,4L},{1L,(-1L)},{0x46FF5760L,1L},{(-1L),4L},{0L,0L}},{{0x46FF5760L,0L},{0L,4L},{(-1L),1L},{0x46FF5760L,(-1L)},{1L,4L},{1L,(-1L)},{0x46FF5760L,1L}},{{(-1L),4L},{0L,0L},{0x46FF5760L,0L},{0L,4L},{(-1L),1L},{0x46FF5760L,(-1L)},{1L,4L}},{{1L,(-1L)},{0x46FF5760L,1L},{(-1L),4L},{0L,0L},{0x46FF5760L,0L},{0L,4L},{(-1L),1L}},{{0x46FF5760L,(-1L)},{1L,4L},{1L,(-1L)},{0x46FF5760L,1L},{(-1L),4L},{0L,0L},{0x46FF5760L,0L}}};
static const volatile struct S0 g_2283 = {0UL,0xF58C2DD4L,0xFCA488ADL,65535UL,0x56L,0UL};/* VOLATILE GLOBAL g_2283 */
static volatile struct S0 g_2284 = {0x6BL,0x574CE793L,4294967286UL,1UL,1L,0xA15C97F00F2E9F4ELL};/* VOLATILE GLOBAL g_2284 */
static volatile union U1 g_2302 = {0L};/* VOLATILE GLOBAL g_2302 */
static volatile struct S0 g_2316 = {0xC0L,1UL,0UL,0x9AC9L,5L,0x99A8B86CE1C01A14LL};/* VOLATILE GLOBAL g_2316 */
static volatile union U1 g_2416 = {-8L};/* VOLATILE GLOBAL g_2416 */
static int8_t g_2447 = 0xBAL;
static struct S0 ** volatile g_2492[6] = {&g_283,&g_283,&g_283,&g_283,&g_283,&g_283};
static struct S0 ** volatile g_2493 = &g_283;/* VOLATILE GLOBAL g_2493 */
static struct S0 g_2514 = {1UL,1UL,1UL,6UL,0L,0x926A2B88B223FCA0LL};/* VOLATILE GLOBAL g_2514 */
static int32_t ** volatile g_2545[7][6] = {{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214},{&g_214,&g_214,&g_214,&g_214,&g_214,&g_214}};
static const struct S0 g_2561 = {0x2BL,0xF5C47780L,0UL,1UL,0xFBL,0UL};/* VOLATILE GLOBAL g_2561 */
static int64_t g_2624 = 6L;
static int32_t * volatile g_2677 = &g_138[3].f2;/* VOLATILE GLOBAL g_2677 */
static volatile int32_t *g_2729 = &g_824[2].f3;
static volatile int32_t **g_2728 = &g_2729;
static volatile int32_t ** volatile *g_2727 = &g_2728;
static volatile int32_t ** volatile ** volatile g_2726 = &g_2727;/* VOLATILE GLOBAL g_2726 */
static union U1 g_2747 = {-9L};/* VOLATILE GLOBAL g_2747 */
static volatile int16_t g_2774 = 1L;/* VOLATILE GLOBAL g_2774 */
static struct S0 g_2783 = {0xEEL,0x1E22ECD7L,1UL,0x76BBL,0xBAL,0xA5C445A99F789552LL};/* VOLATILE GLOBAL g_2783 */
static int8_t g_2801[1][7][7] = {{{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}}};
static uint32_t g_2803 = 1UL;
static const uint32_t * volatile g_2815 = (void*)0;/* VOLATILE GLOBAL g_2815 */
static volatile uint32_t **g_2870 = (void*)0;
static volatile uint32_t ***g_2869 = &g_2870;
static union U1 g_2882 = {1L};/* VOLATILE GLOBAL g_2882 */
static union U1 g_2885 = {1L};/* VOLATILE GLOBAL g_2885 */
static volatile struct S0 g_2918 = {1UL,7UL,1UL,0xD5E1L,0x5BL,0UL};/* VOLATILE GLOBAL g_2918 */
static struct S0 g_2919 = {252UL,0x0F21ADFFL,0xAC89CE75L,0x46ADL,7L,1UL};/* VOLATILE GLOBAL g_2919 */
static struct S0 g_2920 = {0x21L,0xC5566EEEL,1UL,65535UL,0x9CL,7UL};/* VOLATILE GLOBAL g_2920 */
static union U1 g_2951 = {0x74DDF756L};/* VOLATILE GLOBAL g_2951 */
static const uint32_t *g_2952[9][6][4] = {{{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2},{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2},{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2}},{{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2},{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2},{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2}},{{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2},{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2},{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2}},{{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2},{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2},{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2}},{{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2},{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1924.f2,&g_503.f2,&g_1424[3].f2},{&g_52.f2,&g_52.f2,&g_52.f2,&g_1364[3].f2}},{{&g_52.f2,&g_1364[3].f2,&g_503.f2,&g_2121.f2},{(void*)0,&g_1364[3].f2,&g_402.f2,&g_1364[3].f2},{&g_503.f2,&g_52.f2,&g_402.f2,&g_1424[3].f2},{(void*)0,&g_1364[3].f2,&g_52.f2,&g_52.f2},{&g_402.f2,&g_1924.f2,&g_402.f2,&g_2121.f2},{&g_402.f2,&g_2121.f2,&g_52.f2,&g_1424[3].f2}},{{&g_503.f2,&g_2121.f2,&g_2919.f2,&g_2121.f2},{&g_52.f2,&g_1924.f2,&g_2919.f2,&g_52.f2},{&g_503.f2,&g_1364[3].f2,&g_52.f2,&g_52.f2},{&g_402.f2,&g_1924.f2,&g_402.f2,&g_2121.f2},{&g_402.f2,&g_2121.f2,&g_52.f2,&g_1424[3].f2},{&g_503.f2,&g_2121.f2,&g_2919.f2,&g_2121.f2}},{{&g_52.f2,&g_1924.f2,&g_2919.f2,&g_52.f2},{&g_503.f2,&g_1364[3].f2,&g_52.f2,&g_52.f2},{&g_402.f2,&g_1924.f2,&g_402.f2,&g_2121.f2},{&g_402.f2,&g_2121.f2,&g_52.f2,&g_1424[3].f2},{&g_503.f2,&g_2121.f2,&g_2919.f2,&g_2121.f2},{&g_52.f2,&g_1924.f2,&g_2919.f2,&g_52.f2}},{{&g_503.f2,&g_1364[3].f2,&g_52.f2,&g_52.f2},{&g_402.f2,&g_1924.f2,&g_402.f2,&g_2121.f2},{&g_402.f2,&g_2121.f2,&g_52.f2,&g_1424[3].f2},{&g_503.f2,&g_2121.f2,&g_2919.f2,&g_2121.f2},{&g_52.f2,&g_1924.f2,&g_2919.f2,&g_52.f2},{&g_503.f2,&g_1364[3].f2,&g_52.f2,&g_52.f2}}};
static const int64_t *g_2956 = &g_2624;
static const int64_t **g_2955 = &g_2956;
static uint8_t *g_2984[3][6] = {{&g_330.f0,(void*)0,&g_2919.f0,&g_2919.f0,(void*)0,&g_330.f0},{&g_266.f0,&g_330.f0,&g_266.f0,(void*)0,&g_266.f0,&g_330.f0},{&g_266.f0,&g_266.f0,&g_2919.f0,(void*)0,(void*)0,&g_2919.f0}};
static uint8_t **g_2983 = &g_2984[1][3];
static uint8_t *** const  volatile g_2982 = &g_2983;/* VOLATILE GLOBAL g_2982 */
static volatile union U1 g_3000 = {0x40D01F80L};/* VOLATILE GLOBAL g_3000 */
static volatile struct S0 g_3033[10] = {{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{0xC5L,1UL,1UL,1UL,2L,0x6A448A3ED7601453LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{0xC5L,1UL,1UL,1UL,2L,0x6A448A3ED7601453LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{0xC5L,1UL,1UL,1UL,2L,0x6A448A3ED7601453LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL},{1UL,0UL,2UL,4UL,1L,0x36DF57511CB8AEB1LL}};
static struct S0 g_3049 = {255UL,0x7EA0C955L,0x2FA83AB0L,0xD63DL,3L,3UL};/* VOLATILE GLOBAL g_3049 */
static struct S0 g_3060 = {6UL,0x3ED85806L,0x948A7E33L,65530UL,0x83L,1UL};/* VOLATILE GLOBAL g_3060 */
static struct S0 g_3064 = {248UL,18446744073709551608UL,0x8A1752FBL,65526UL,0xB2L,0x9D7824D64AFAC43ELL};/* VOLATILE GLOBAL g_3064 */
static volatile union U1 g_3065 = {-1L};/* VOLATILE GLOBAL g_3065 */
static struct S0 g_3084 = {0x0DL,0xAEFA98C8L,0xAD772548L,0x3282L,0x58L,0x0EDA3E5799740981LL};/* VOLATILE GLOBAL g_3084 */
static volatile int8_t g_3102[2] = {0x55L,0x55L};
static volatile int32_t g_3106 = 1L;/* VOLATILE GLOBAL g_3106 */
static struct S0 g_3123 = {1UL,0x037EF226L,0x9D8EEA02L,0xFF95L,0x7CL,0UL};/* VOLATILE GLOBAL g_3123 */
static struct S0 g_3131 = {4UL,0x5E69FAE2L,0x5AFCEB47L,0x9B71L,-1L,1UL};/* VOLATILE GLOBAL g_3131 */
static int32_t *g_3178 = &g_885[0][7][3].f2;
static int32_t ** volatile g_3177 = &g_3178;/* VOLATILE GLOBAL g_3177 */
static struct S0 g_3216 = {0x93L,18446744073709551615UL,0x1DD1F13AL,0xE3E3L,0x89L,0x01C3CDD1F5F956DELL};/* VOLATILE GLOBAL g_3216 */
static struct S0 g_3217 = {255UL,18446744073709551615UL,0x2885525AL,0x8563L,1L,0xFC60C8DE20457565LL};/* VOLATILE GLOBAL g_3217 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int8_t  func_13(uint32_t  p_14);
static int8_t * func_15(uint8_t  p_16, int8_t * p_17, int8_t  p_18, int8_t * const  p_19);
static int8_t * func_21(int8_t * p_22, uint32_t  p_23, uint64_t  p_24, int16_t  p_25, const uint32_t  p_26);
static int64_t  func_34(int8_t * p_35, uint64_t  p_36, uint32_t  p_37);
static uint64_t  func_39(int8_t * p_40);
static int8_t * func_53(uint16_t  p_54, int8_t  p_55, uint32_t * p_56);
static int8_t  func_59(int16_t  p_60, const int8_t * p_61);
static int8_t * func_62(uint64_t  p_63, int64_t  p_64, uint16_t  p_65, const int64_t  p_66);
static struct S0  func_85(int32_t * p_86, int8_t * p_87, int64_t  p_88);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3217
 * writes: g_2 g_5.f2 g_2121.f2
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int32_t l_20 = 4L;
    int8_t *l_27[9][9] = {{(void*)0,&g_5.f4,(void*)0,&g_5.f4,&g_5.f4,&g_5.f4,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,&g_5.f4,&g_5.f4,&g_5.f4,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,&g_5.f4,&g_5.f4,&g_5.f4,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,&g_5.f4,&g_5.f4,&g_5.f4,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0,(void*)0,&g_5.f4,(void*)0},{(void*)0,&g_5.f4,(void*)0,&g_5.f4,&g_5.f4,&g_5.f4,&g_5.f4,&g_5.f4,&g_5.f4}};
    int32_t l_2688 = 1L;
    int32_t l_2689 = (-5L);
    int32_t l_2690[5][3][3] = {{{0xBD605447L,1L,0x833AC28FL},{0xBD605447L,(-9L),0xBD605447L},{0xBD605447L,0L,0x64A89827L}},{{0xBD605447L,1L,0x833AC28FL},{0xBD605447L,(-9L),0xBD605447L},{0xBD605447L,0L,0x64A89827L}},{{0xBD605447L,1L,0x833AC28FL},{0xBD605447L,(-9L),0xBD605447L},{0xBD605447L,0L,0x64A89827L}},{{0xBD605447L,1L,0x833AC28FL},{0xBD605447L,(-9L),0xBD605447L},{0xBD605447L,0L,0x64A89827L}},{{0xBD605447L,1L,0x833AC28FL},{0xBD605447L,(-9L),0xBD605447L},{0xBD605447L,0L,0x64A89827L}}};
    uint32_t l_2708 = 3UL;
    uint32_t *l_2742 = &g_656.f1;
    uint32_t **l_2741[9][8] = {{&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742},{(void*)0,&l_2742,&l_2742,(void*)0,&l_2742,(void*)0,&l_2742,&l_2742},{&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742},{(void*)0,&l_2742,(void*)0,&l_2742,&l_2742,(void*)0,&l_2742,(void*)0},{&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742},{&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742},{(void*)0,&l_2742,&l_2742,(void*)0,&l_2742,(void*)0,&l_2742,&l_2742},{&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742,&l_2742},{(void*)0,&l_2742,(void*)0,&l_2742,&l_2742,(void*)0,&l_2742,(void*)0}};
    int32_t ** const *l_2799 = &g_1837;
    int32_t ** const **l_2798 = &l_2799;
    int32_t *l_2847 = &g_73[3];
    int16_t l_2861 = 0xF780L;
    int8_t * const l_2877 = &g_1364[3].f4;
    int64_t l_2884 = (-2L);
    int32_t l_2886 = 0x80B54A18L;
    int64_t l_2905[3];
    const uint16_t *l_2917 = &g_187;
    int8_t l_3008 = 0x5AL;
    struct S0 *l_3010 = &g_851[0][0][3];
    uint16_t l_3035 = 65526UL;
    int16_t *l_3091[8][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0}};
    int16_t **l_3090 = &l_3091[1][2];
    int32_t l_3112 = 0x82DAD3AFL;
    int32_t l_3190 = (-10L);
    int64_t l_3191[8][1][7] = {{{(-1L),0L,0x47A886370318DA8ELL,0x47A886370318DA8ELL,0L,(-1L),1L}},{{8L,0x843113DAAB835E00LL,(-1L),0xE0784904EE234EFELL,1L,(-5L),0L}},{{0x76AEA1DE81EFBC85LL,0L,0x843113DAAB835E00LL,(-8L),(-1L),0x059E4475FA75DED5LL,(-1L)}},{{0x88974F47B709EA0ELL,0x843113DAAB835E00LL,(-1L),(-1L),0L,0L,(-1L)}},{{0xE0784904EE234EFELL,0L,0xE0784904EE234EFELL,(-1L),0L,0xACDB2DA4D36F7C44LL,0L}},{{(-1L),1L,(-7L),(-8L),(-10L),(-1L),1L}},{{(-1L),(-1L),0L,0xE0784904EE234EFELL,0x88974F47B709EA0ELL,(-7L),0xACDB2DA4D36F7C44LL}},{{0L,(-1L),0xE0784904EE234EFELL,0L,0xE0784904EE234EFELL,(-1L),0L}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2905[i] = 0x45D52058B42D90C0LL;
    for (g_2 = (-21); (g_2 >= (-21)); --g_2)
    { /* block id: 3 */
        return g_5;
    }
lbl_2678:
    for (g_5.f2 = (-23); (g_5.f2 >= 7); g_5.f2 = safe_add_func_uint64_t_u_u(g_5.f2, 9))
    { /* block id: 8 */
        int32_t l_8 = 2L;
        uint32_t *l_41 = &g_5.f1;
        int8_t * const l_2330 = &g_74;
        if (l_8)
            break;
        if (g_5.f4)
            goto lbl_2678;
    }
    for (g_2121.f2 = 0; (g_2121.f2 < 25); g_2121.f2 = safe_add_func_uint8_t_u_u(g_2121.f2, 3))
    { /* block id: 1388 */
        int32_t *l_2681 = &g_903[1];
        int32_t l_2682 = 9L;
        int32_t *l_2683 = &l_2682;
        int32_t *l_2684 = &g_2;
        int32_t *l_2685 = &g_2;
        int32_t *l_2686 = &g_824[2].f2;
        int32_t *l_2687[10][7][3] = {{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0}},{{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,(void*)0,(void*)0},{&g_637.f2,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20}},{{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20},{(void*)0,&l_20,&l_20}}};
        uint16_t l_2691[4][7][9] = {{{1UL,65527UL,0x9187L,9UL,0x919FL,65530UL,0x828AL,65535UL,0x28E0L},{65530UL,0UL,0x6F08L,1UL,0xEE07L,65535UL,0x0178L,1UL,0x9187L},{65526UL,0UL,0x6F08L,0xD428L,0x2C8DL,6UL,0x919FL,0x2ED2L,0x06B6L},{0xE58DL,0x4C5DL,0x9187L,0x2ED2L,0x358EL,0xD96AL,65535UL,0xD96AL,0x358EL},{0x044CL,1UL,1UL,0x044CL,1UL,65534UL,1UL,0x7E46L,0x9BFDL},{0x06B6L,0x78A9L,0x9BFDL,0x9C58L,0x28E0L,65530UL,0x1B55L,6UL,0x0178L},{65534UL,0UL,0x1B55L,0x49ADL,1UL,0x7E46L,65535UL,65535UL,0x4CB6L}},{{0x828AL,0x64CCL,0xEE5CL,65526UL,0x358EL,0xB4A9L,8UL,0x8D2EL,0x7A69L},{0x4C5DL,65534UL,0x49ADL,65533UL,0x2C8DL,0x7A69L,65530UL,0xB4A9L,0x4064L},{65535UL,0x7A69L,65534UL,0x2C8DL,0xEE07L,8UL,65530UL,0x044CL,0xE58DL},{0x1990L,1UL,0xB4A9L,0x828AL,0x919FL,0x78A9L,8UL,0x6F08L,0xD96AL},{0x2C8DL,65535UL,0UL,6UL,6UL,0UL,65535UL,0x2C8DL,0UL},{6UL,0x9C58L,1UL,0x8D2EL,0x64CCL,0UL,0x1B55L,1UL,65526UL},{0UL,65534UL,65529UL,0x358EL,0x6866L,0x8D2EL,1UL,0xEE07L,0UL}},{{0x8172L,65533UL,0x6866L,0UL,0x7E46L,0xE58DL,65535UL,65535UL,0xD96AL},{0x1B55L,65535UL,0x06B6L,0xB4A9L,0x179FL,1UL,0x919FL,65534UL,0xE58DL},{65527UL,0x4CB6L,0x1990L,65534UL,0x9BFDL,65533UL,0x0178L,0x5A1BL,0x4064L},{0x28E0L,0x4CB6L,0x7E46L,65534UL,0x044CL,1UL,0x828AL,0x9BFDL,1UL},{0x1990L,65529UL,0UL,65534UL,0xB4A9L,1UL,1UL,0xB4A9L,65534UL},{0x919FL,0x9187L,0x919FL,0UL,0x4C5DL,0x5A1BL,65534UL,65527UL,0x1990L},{1UL,65530UL,0xD96AL,0xFEAEL,6UL,0x28E0L,65535UL,0x7A69L,0xE58DL}},{{0x9C58L,0UL,65533UL,0UL,0x28E0L,0xD96AL,0x49ADL,0UL,0xEE07L},{0x4CB6L,1UL,0xEE5CL,65534UL,0x179FL,65526UL,0x2ED2L,0UL,0UL},{0x5A1BL,65535UL,0xB4A9L,0x2ED2L,1UL,0x828AL,0x358EL,0x64CCL,65535UL},{65530UL,1UL,0x78A9L,65530UL,65534UL,0x828AL,0xFEAEL,0x6F08L,0UL},{1UL,0x2ED2L,1UL,65530UL,0x044CL,65526UL,0xE58DL,0UL,0UL},{0x179FL,0xD96AL,0x1990L,1UL,0x1990L,0xD96AL,0x179FL,0xFEAEL,0x6866L},{0x06B6L,0x7E46L,0xFEAEL,0xEE07L,1UL,0x28E0L,0UL,0x179FL,0x4CB6L}}};
        uint8_t *l_2699[10] = {&g_247.f0,(void*)0,&g_247.f0,(void*)0,&g_247.f0,(void*)0,&g_247.f0,(void*)0,&g_247.f0,(void*)0};
        int32_t l_2739 = 0xAF60E8F0L;
        uint32_t **l_2740 = (void*)0;
        int64_t l_2779 = 0xEA22187547CC2F7CLL;
        int i, j, k;
        ++l_2691[1][6][3];
    }
    return g_3217;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_13(uint32_t  p_14)
{ /* block id: 1381 */
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_5.f4 g_463.f2 g_2260 g_1489 g_247.f5 g_74 g_5.f0 g_656.f0 g_2157 g_283 g_503.f5 g_2284.f0 g_824.f4 g_266.f2 g_1695.f4 g_420.f0
 * writes: g_5.f4 g_463.f2 g_185 g_44.f0 g_74 g_5.f0 g_656.f0 g_44 g_503.f5 g_1424.f2 g_266.f2 g_1404
 */
static int8_t * func_15(uint8_t  p_16, int8_t * p_17, int8_t  p_18, int8_t * const  p_19)
{ /* block id: 1202 */
    uint64_t l_2331 = 0UL;
    int32_t l_2368 = 0x1D73B07FL;
    int32_t l_2369 = 5L;
    uint16_t **l_2385 = (void*)0;
    uint32_t l_2386 = 0xD70112BEL;
    int32_t l_2421 = (-8L);
    int32_t l_2422 = (-8L);
    int32_t l_2426[1][6] = {{0x79D8EDF3L,0x79D8EDF3L,0x79D8EDF3L,0x79D8EDF3L,0x79D8EDF3L,0x79D8EDF3L}};
    int16_t l_2427[7][5] = {{0xE46DL,(-4L),(-4L),0xE46DL,0x4B35L},{1L,(-4L),(-1L),(-1L),(-4L)},{0x4B35L,(-4L),0x33C2L,7L,7L},{0x2F18L,(-1L),0x2F18L,(-1L),2L},{0L,0xE46DL,7L,0xE46DL,0L},{0x2F18L,1L,(-1L),(-4L),(-1L)},{0x4B35L,0x4B35L,7L,0L,1L}};
    int32_t l_2428 = 0xD67F7A28L;
    int32_t l_2429 = 0xF517A737L;
    int32_t l_2431 = (-8L);
    int32_t l_2446[4] = {(-8L),(-8L),(-8L),(-8L)};
    uint64_t l_2518 = 0x76AA320B04B2790BLL;
    uint8_t *l_2537 = &g_503.f0;
    uint8_t **l_2536 = &l_2537;
    int8_t *l_2576[7][10][3] = {{{(void*)0,&g_503.f4,(void*)0},{(void*)0,&g_330.f4,&g_656.f4},{&g_1424[3].f4,&g_2157.f4,(void*)0},{&g_851[0][0][3].f4,&g_266.f4,&g_1424[3].f4},{&g_247.f4,&g_503.f4,&g_776[2].f4},{&g_851[0][0][3].f4,&g_2121.f4,&g_330.f4},{&g_1424[3].f4,&g_656.f4,&g_656.f4},{(void*)0,&g_1424[3].f4,(void*)0},{(void*)0,&g_656.f4,(void*)0},{&g_1424[3].f4,(void*)0,&g_2157.f4}},{{(void*)0,&g_503.f4,(void*)0},{(void*)0,&g_247.f4,(void*)0},{&g_1424[3].f4,&g_2514.f4,&g_247.f4},{&g_851[0][0][3].f4,&g_330.f4,(void*)0},{&g_247.f4,(void*)0,&g_247.f4},{&g_776[2].f4,&g_5.f4,&g_776[2].f4},{&g_266.f4,(void*)0,&g_117},{&g_266.f4,(void*)0,&g_247.f4},{&g_2447,(void*)0,&g_776[2].f4},{&g_2157.f4,(void*)0,&g_2157.f4}},{{&g_2447,&g_266.f4,&g_52.f4},{&g_266.f4,&g_1424[3].f4,&g_776[2].f4},{&g_266.f4,&g_247.f4,&g_2121.f4},{&g_776[2].f4,&g_330.f4,&g_247.f4},{&g_776[2].f4,(void*)0,&g_44.f4},{&g_776[2].f4,(void*)0,&g_776[2].f4},{&g_266.f4,&g_503.f4,&g_402.f4},{&g_266.f4,(void*)0,&g_2157.f4},{&g_2447,(void*)0,&g_2121.f4},{&g_2157.f4,&g_74,&g_117}},{{&g_2447,(void*)0,&g_2447},{&g_266.f4,&g_851[0][0][3].f4,&g_2157.f4},{&g_266.f4,(void*)0,&g_776[2].f4},{&g_776[2].f4,&g_1424[3].f4,&g_2157.f4},{&g_776[2].f4,&g_1424[3].f4,&g_117},{&g_776[2].f4,&g_74,&g_247.f4},{&g_266.f4,(void*)0,&g_44.f4},{&g_266.f4,&g_1424[3].f4,&g_1561.f4},{&g_2447,&g_503.f4,&g_776[2].f4},{&g_2157.f4,&g_5.f4,&g_776[2].f4}},{{&g_2447,&g_1424[3].f4,&g_402.f4},{&g_266.f4,&g_330.f4,&g_117},{&g_266.f4,&g_247.f4,&g_776[2].f4},{&g_776[2].f4,&g_851[0][0][3].f4,&g_1561.f4},{&g_776[2].f4,&g_266.f4,&g_402.f4},{&g_776[2].f4,&g_5.f4,&g_776[2].f4},{&g_266.f4,(void*)0,&g_117},{&g_266.f4,(void*)0,&g_247.f4},{&g_2447,(void*)0,&g_776[2].f4},{&g_2157.f4,(void*)0,&g_2157.f4}},{{&g_2447,&g_266.f4,&g_52.f4},{&g_266.f4,&g_1424[3].f4,&g_776[2].f4},{&g_266.f4,&g_247.f4,&g_2121.f4},{&g_776[2].f4,&g_330.f4,&g_247.f4},{&g_776[2].f4,(void*)0,&g_44.f4},{&g_776[2].f4,(void*)0,&g_776[2].f4},{&g_266.f4,&g_503.f4,&g_402.f4},{&g_266.f4,(void*)0,&g_2157.f4},{&g_2447,(void*)0,&g_2121.f4},{&g_2157.f4,&g_74,&g_117}},{{&g_2447,(void*)0,&g_2447},{&g_266.f4,&g_851[0][0][3].f4,&g_2157.f4},{&g_266.f4,(void*)0,&g_776[2].f4},{&g_776[2].f4,&g_1424[3].f4,&g_2157.f4},{&g_776[2].f4,&g_1424[3].f4,&g_117},{&g_776[2].f4,&g_74,&g_247.f4},{&g_266.f4,(void*)0,&g_44.f4},{&g_266.f4,&g_1424[3].f4,&g_1561.f4},{&g_2447,&g_503.f4,&g_776[2].f4},{&g_2157.f4,&g_5.f4,&g_776[2].f4}}};
    int64_t *l_2586 = &g_1404;
    const struct S0 *l_2614 = &g_2157;
    const struct S0 **l_2613 = &l_2614;
    const struct S0 ***l_2612[8][3];
    const struct S0 ****l_2611 = &l_2612[5][0];
    const struct S0 *****l_2610 = &l_2611;
    const struct S0 ****** const l_2609[1] = {&l_2610};
    const struct S0 ****** const *l_2608 = &l_2609[0];
    int32_t * const *l_2622 = (void*)0;
    int32_t * const **l_2621 = &l_2622;
    uint32_t l_2632 = 0x457AEB04L;
    uint64_t *l_2641 = &g_503.f5;
    uint32_t *l_2652 = (void*)0;
    uint32_t *l_2653 = &g_1424[3].f2;
    uint32_t *l_2668 = &g_330.f1;
    uint32_t **l_2667 = &l_2668;
    uint32_t *l_2669 = &g_266.f2;
    uint32_t *l_2670[8] = {&g_2157.f2,&g_776[2].f2,&g_2157.f2,&g_776[2].f2,&g_2157.f2,&g_776[2].f2,&g_2157.f2,&g_776[2].f2};
    int32_t l_2671 = 0x0BAD1EC3L;
    int32_t l_2672 = 0L;
    int8_t l_2673 = 0x7AL;
    const int16_t l_2674 = 9L;
    int32_t *l_2675[3];
    uint16_t l_2676 = 0x79FEL;
    int i, j, k;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
            l_2612[i][j] = &l_2613;
    }
    for (i = 0; i < 3; i++)
        l_2675[i] = &g_1180.f2;
    if ((l_2331 < p_16))
    { /* block id: 1203 */
        struct S0 *****l_2337[2];
        struct S0 ******l_2336[5][5][6] = {{{(void*)0,(void*)0,(void*)0,&l_2337[1],&l_2337[0],&l_2337[1]},{&l_2337[0],&l_2337[0],&l_2337[0],(void*)0,&l_2337[1],&l_2337[0]},{(void*)0,(void*)0,&l_2337[1],(void*)0,&l_2337[0],(void*)0},{&l_2337[1],(void*)0,(void*)0,(void*)0,&l_2337[0],&l_2337[1]},{(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[1],(void*)0}},{{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1],(void*)0},{(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[0],&l_2337[1]},{(void*)0,(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1]}},{{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1]},{(void*)0,&l_2337[1],(void*)0,(void*)0,(void*)0,(void*)0},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,(void*)0,&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1],(void*)0},{&l_2337[1],(void*)0,(void*)0,(void*)0,&l_2337[0],&l_2337[1]}},{{(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[1],(void*)0},{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1],(void*)0},{(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[0],&l_2337[1]},{(void*)0,(void*)0,&l_2337[1],(void*)0,&l_2337[1],&l_2337[1]}},{{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1]},{(void*)0,&l_2337[1],(void*)0,(void*)0,(void*)0,(void*)0},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,(void*)0,&l_2337[1]},{&l_2337[1],&l_2337[1],&l_2337[1],(void*)0,&l_2337[1],(void*)0}}};
        int32_t l_2338[10] = {0x15F2161BL,(-1L),0x15F2161BL,0x15F2161BL,(-1L),0x15F2161BL,0x15F2161BL,(-1L),0x15F2161BL,0x15F2161BL};
        int32_t *l_2339 = &g_463.f2;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2337[i] = &g_1452;
        if (((*l_2339) = ((safe_mul_func_int8_t_s_s(((*g_38) |= (safe_mod_func_uint8_t_u_u(((void*)0 != l_2336[2][4][5]), p_16))), (l_2338[5] || 0x88L))) != l_2338[4])))
        { /* block id: 1206 */
            uint16_t l_2352 = 65527UL;
            int32_t l_2353 = (-9L);
            uint8_t *l_2354 = &g_44.f0;
            int32_t l_2370 = 0x41C40E2BL;
            l_2370 = (safe_lshift_func_int8_t_s_s((safe_sub_func_int8_t_s_s((*l_2339), (safe_rshift_func_uint16_t_u_s((safe_add_func_int32_t_s_s(((safe_add_func_int8_t_s_s(((safe_add_func_int8_t_s_s((l_2353 |= (((*g_2260) = p_16) >= l_2352)), ((*p_19) = (p_18 != ((*l_2354) = (*l_2339)))))) || ((safe_mod_func_uint16_t_u_u((((*g_1489) & (safe_mul_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s((*l_2339), ((!(((0xDE1099E2L ^ (safe_mod_func_uint64_t_u_u((l_2369 = (((safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(0xACE3L, l_2352)), l_2368)) == 1L) | 0xD57CL)), 7L))) <= p_16) >= 0UL)) , 0x8CL))), 0xAAL))) , p_18), 0x7E9FL)) < (*p_19))), 0L)) != p_16), l_2368)), 6)))), l_2352));
        }
        else
        { /* block id: 1213 */
            for (g_5.f0 = (-7); (g_5.f0 > 7); ++g_5.f0)
            { /* block id: 1216 */
                return &g_74;
            }
        }
        (*l_2339) |= 2L;
    }
    else
    { /* block id: 1221 */
        uint64_t *l_2375 = &g_503.f5;
        int64_t *l_2378[8][5][4] = {{{&g_1404,(void*)0,&g_137,&g_1404},{&g_137,&g_137,&g_137,&g_137},{&g_1404,&g_1404,&g_1404,&g_1404},{&g_137,&g_1404,&g_1404,&g_1404},{&g_1404,&g_1404,&g_137,&g_1404}},{{&g_137,&g_1404,(void*)0,&g_1404},{&g_137,&g_1404,&g_1404,&g_137},{(void*)0,&g_137,&g_1404,&g_1404},{(void*)0,(void*)0,&g_1404,&g_1404},{&g_137,&g_1404,(void*)0,&g_1404}},{{&g_137,&g_137,&g_137,(void*)0},{&g_1404,&g_137,&g_1404,&g_1404},{&g_1404,&g_137,&g_137,&g_1404},{&g_1404,&g_1404,&g_137,&g_137},{(void*)0,&g_137,&g_137,(void*)0}},{{&g_1404,&g_1404,&g_137,&g_1404},{&g_1404,&g_1404,&g_1404,&g_137},{&g_1404,&g_137,&g_137,&g_137},{&g_137,&g_1404,&g_1404,&g_1404},{&g_1404,&g_1404,&g_137,(void*)0}},{{&g_1404,&g_137,&g_137,&g_137},{&g_1404,&g_1404,&g_137,&g_1404},{&g_1404,&g_137,&g_1404,&g_1404},{&g_137,&g_1404,&g_137,&g_1404},{&g_1404,&g_1404,&g_1404,&g_1404}},{{&g_1404,&g_137,&g_137,&g_1404},{&g_1404,&g_1404,&g_137,&g_137},{(void*)0,&g_137,&g_137,(void*)0},{&g_1404,&g_1404,&g_137,&g_1404},{&g_1404,&g_1404,&g_1404,&g_137}},{{&g_1404,&g_137,&g_137,&g_137},{&g_137,&g_1404,&g_1404,&g_1404},{&g_1404,&g_1404,&g_137,(void*)0},{&g_1404,&g_137,&g_137,&g_137},{&g_1404,&g_1404,&g_137,&g_1404}},{{&g_1404,&g_137,&g_1404,&g_1404},{&g_137,&g_1404,&g_137,&g_1404},{&g_1404,&g_1404,&g_1404,&g_1404},{&g_1404,&g_137,&g_137,&g_1404},{&g_1404,&g_1404,&g_137,&g_137}}};
        int32_t l_2381 = (-8L);
        int32_t *l_2398 = (void*)0;
        uint16_t **l_2402 = &g_2260;
        int32_t *l_2424 = &g_128.f2;
        int32_t *l_2425[4][8][6] = {{{&g_1695.f2,&g_463.f2,&g_1695.f2,&g_407[1].f2,&g_407[1].f2,&g_1695.f2},{&g_904.f2,&g_904.f2,&g_1695.f2,&g_885[0][7][3].f2,&l_2369,&g_463.f2},{&g_903[1],&l_2422,(void*)0,&g_463.f2,&l_2369,&g_1695.f2},{&g_111,&g_903[1],(void*)0,&g_1180.f2,&g_904.f2,&g_463.f2},{&g_885[0][7][3].f2,&g_1180.f2,&g_1695.f2,&g_463.f2,(void*)0,&g_1695.f2},{&g_463.f2,(void*)0,&g_1695.f2,&g_463.f2,&g_1695.f2,&g_904.f2},{&g_904.f2,&g_361.f2,(void*)0,&g_903[0],&g_885[0][7][3].f2,&g_361.f2},{&g_885[0][7][3].f2,&g_128.f2,&g_830[1].f2,&g_904.f2,&g_830[1].f2,&g_128.f2}},{{&g_407[1].f2,&g_903[0],&g_830[1].f2,(void*)0,&g_2265[3][0][1],&g_1696.f2},{&g_1695.f2,&g_824[2].f2,&l_2421,&g_1695.f2,&g_903[1],&g_1180.f2},{&g_361.f2,&g_824[2].f2,&g_407[1].f2,(void*)0,&g_2265[3][0][1],&g_885[0][7][3].f2},{&g_1695.f2,&g_903[0],&g_904.f2,&g_830[1].f2,&g_830[1].f2,&l_2421},{&g_463.f2,&g_128.f2,&g_361.f2,&g_824[2].f2,&g_885[0][7][3].f2,&g_830[1].f2},{&g_830[1].f2,&l_2369,&l_2381,&g_1180.f2,&g_903[0],&g_1695.f2},{(void*)0,&g_1695.f2,(void*)0,(void*)0,&g_1695.f2,(void*)0},{&g_1180.f2,&l_2421,&l_2369,&g_1696.f2,&g_1695.f2,&l_2369}},{{&g_361.f2,&g_1695.f2,&g_885[0][7][3].f2,&g_463.f2,&g_407[1].f2,&g_885[0][7][3].f2},{&g_361.f2,&g_128.f2,&g_463.f2,&g_1696.f2,&g_830[1].f2,&g_1695.f2},{&g_1180.f2,&g_1695.f2,&g_463.f2,(void*)0,&g_1695.f2,&g_463.f2},{(void*)0,&g_830[1].f2,&g_2265[3][0][1],&g_1180.f2,&g_885[0][7][3].f2,&l_2422},{&g_830[1].f2,&g_463.f2,&g_1180.f2,(void*)0,&g_1180.f2,&g_830[1].f2},{(void*)0,&g_824[2].f2,&g_1180.f2,&g_824[2].f2,(void*)0,&g_463.f2},{&g_1696.f2,&g_904.f2,&g_1695.f2,&g_1695.f2,(void*)0,&l_2369},{&g_885[0][7][3].f2,&g_830[1].f2,&l_2421,&g_904.f2,&l_2369,&l_2369}},{{&g_903[0],&g_2265[3][0][1],&g_1695.f2,&l_2381,&g_128.f2,&g_463.f2},{&l_2369,&g_1695.f2,&g_1180.f2,&l_2422,&g_2265[3][0][1],&g_830[1].f2},{&g_903[1],&g_1696.f2,&g_1180.f2,(void*)0,&g_885[0][7][3].f2,&l_2422},{&l_2422,&g_904.f2,&g_2265[3][0][1],&g_111,&g_463.f2,&g_463.f2},{&g_2265[3][0][1],&g_463.f2,&g_463.f2,&g_2265[3][0][1],&g_463.f2,&g_1695.f2},{(void*)0,&g_903[0],&g_463.f2,&l_2421,&g_1696.f2,&g_885[0][7][3].f2},{&g_463.f2,&g_903[1],&g_885[0][7][3].f2,(void*)0,&g_1696.f2,&l_2369},{&g_1695.f2,&g_903[0],&l_2369,&g_903[1],&g_463.f2,(void*)0}}};
        int8_t l_2430 = (-5L);
        int32_t l_2432 = 1L;
        uint32_t l_2433 = 0x142A539DL;
        int16_t *l_2519 = &g_1609;
        int32_t *l_2528 = &g_903[1];
        struct S0 **** const *l_2574 = &g_1452;
        struct S0 **** const **l_2573 = &l_2574;
        struct S0 **** const ***l_2572 = &l_2573;
        int i, j, k;
    }
    for (g_656.f0 = 0; (g_656.f0 == 24); g_656.f0 = safe_add_func_uint16_t_u_u(g_656.f0, 2))
    { /* block id: 1368 */
        int32_t *l_2629 = &g_903[0];
        int32_t *l_2630 = &l_2431;
        int32_t *l_2631[6];
        int i;
        for (i = 0; i < 6; i++)
            l_2631[i] = &g_830[1].f2;
        (*g_283) = (**l_2613);
        --l_2632;
        if (p_18)
            continue;
    }
    l_2676 ^= (safe_add_func_int32_t_s_s(l_2431, (safe_sub_func_uint32_t_u_u(((safe_sub_func_int64_t_s_s((((*l_2641) |= (*g_1489)) <= ((safe_lshift_func_int16_t_s_s(l_2422, 9)) ^ (((safe_add_func_uint32_t_u_u((((safe_lshift_func_uint8_t_u_u((((safe_mod_func_int8_t_s_s((((void*)0 == &l_2427[5][1]) >= (((((p_16 & (((*l_2586) = (l_2369 == ((safe_add_func_uint32_t_u_u(((*l_2653) = 0x767AEB8DL), (+((safe_lshift_func_int16_t_s_u((((safe_sub_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((l_2671 = ((*l_2669) ^= (safe_mod_func_int16_t_s_s((safe_mod_func_int64_t_s_s(((safe_mul_func_uint16_t_u_u((l_2667 == &l_2668), g_2284.f0)) == (*g_1489)), (*g_1489))), g_824[2].f4)))), l_2421)), p_16)) , (void*)0) != (*l_2608)), p_16)) >= g_1695.f4)))) > l_2672))) >= g_2157.f0)) ^ 0x6CL) ^ 0xC5L) == p_18) & g_420.f0)), l_2673)) ^ p_16) || p_16), p_18)) & l_2446[0]) , p_16), l_2674)) < 0x2D3E1F39L) && (*g_38)))), p_18)) < p_18), 1L))));
    return &g_117;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t * func_21(int8_t * p_22, uint32_t  p_23, uint64_t  p_24, int16_t  p_25, const uint32_t  p_26)
{ /* block id: 1200 */
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_46 g_38 g_47 g_5.f5 g_52 g_5.f4 g_2 g_75 g_5.f2 g_504 g_330 g_213 g_214 g_911 g_503.f1 g_1048 g_877 g_283 g_1089 g_138.f2 g_656.f2 g_5.f0 g_169 g_138.f0 g_266.f0 g_1135 g_742.f0 g_1164 g_185 g_503.f5 g_1174 g_361.f2 g_111 g_1352 g_407.f2 g_815 g_1695.f4 g_1291 g_1424.f1 g_1180.f2 g_1257 g_1659 g_1660 g_489.f0 g_247.f0 g_1743.f0 g_904.f4 g_816 g_814 g_407.f0 g_1424.f0 g_1489 g_1561.f5 g_904.f2 g_1561.f4 g_253 g_137 g_656.f3 g_128.f0 g_1743.f5 g_105 g_247 g_183 g_1209 g_1837 g_1924.f1 g_903 g_2265 g_5.f1
 * writes: g_5.f1 g_2 g_75 g_52.f1 g_187 g_266.f0 g_52.f0 g_253 g_44.f4 g_107 g_214 g_911 g_503.f1 g_283 g_330 g_169 g_138.f2 g_656.f5 g_1135 g_185 g_776.f0 g_44 g_1258 g_1808 g_137 g_247.f0 g_1837 g_1424.f0 g_247.f5 g_904.f2 g_1561.f4 g_52.f5 g_183 g_1924.f1 g_903
 */
static int64_t  func_34(int8_t * p_35, uint64_t  p_36, uint32_t  p_37)
{ /* block id: 13 */
    int32_t *l_1785 = &g_1180.f2;
    uint16_t *l_1795 = &g_185[1][3][2];
    int32_t **l_1807[1];
    int64_t *l_1821 = &g_137;
    union U1 **l_1822 = &g_1179;
    int16_t *l_1823 = &g_253;
    uint8_t *l_1824[6][8] = {{&g_44.f0,&g_5.f0,&g_1364[3].f0,&g_330.f0,(void*)0,&g_503.f0,&g_1424[3].f0,&g_776[2].f0},{&g_776[2].f0,&g_5.f0,(void*)0,&g_247.f0,&g_1364[3].f0,(void*)0,&g_1364[3].f0,&g_247.f0},{&g_52.f0,&g_330.f0,&g_52.f0,(void*)0,&g_1364[3].f0,&g_247.f0,&g_1561.f0,&g_1364[3].f0},{&g_503.f0,&g_1364[3].f0,&g_44.f0,&g_911,&g_330.f0,&g_52.f0,&g_1364[3].f0,&g_5.f0},{&g_503.f0,(void*)0,&g_52.f0,&g_851[0][0][3].f0,&g_1364[3].f0,&g_1364[3].f0,&g_851[0][0][3].f0,&g_52.f0},{&g_52.f0,&g_52.f0,&g_503.f0,(void*)0,&g_1364[3].f0,(void*)0,&g_330.f0,&g_776[2].f0}};
    int32_t l_1850 = 1L;
    int8_t l_1894[9][4][1] = {{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}},{{(-2L)},{9L},{0x3DL},{9L}}};
    int32_t l_1950[2];
    uint16_t l_1958 = 0x331EL;
    const uint64_t *l_1962 = &g_1963[0];
    int32_t * volatile l_2189 = &g_2;/* VOLATILE GLOBAL l_2189 */
    uint32_t l_2210 = 0x4264CA55L;
    int32_t l_2255 = 0xC366FA33L;
    uint64_t l_2261 = 0UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1807[i] = &g_1258;
    for (i = 0; i < 2; i++)
        l_1950[i] = 0xAFBA748EL;
lbl_1857:
    for (g_5.f1 = 0; (g_5.f1 <= 27); ++g_5.f1)
    { /* block id: 16 */
        int16_t *l_1071 = &g_253;
        uint32_t *l_1782 = &g_1424[3].f1;
        int32_t **l_1783 = &g_214;
        (*g_46) = (p_36 >= ((g_44 , p_36) >= 0x81E16845L));
        (*g_47) = (0x83A5C25CL && (((void*)0 != g_38) & 0UL));
        l_1785 = ((*l_1783) = ((safe_div_func_int32_t_s_s((g_5.f5 >= (safe_sub_func_int64_t_s_s(((((g_52 , func_39(func_53(p_36, (*p_35), (((safe_rshift_func_int8_t_s_u(func_59(((*l_1071) = func_39(func_62(p_37, g_52.f0, g_44.f5, g_52.f4))), p_35), 3)) , p_36) , l_1782)))) & p_37) <= 0UL) ^ 0x43E7FE84L), (-1L)))), 0x49052FE9L)) , l_1782));
    }
lbl_1953:
    if ((safe_mul_func_int16_t_s_s(((((((safe_mul_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_mod_func_int16_t_s_s((!((*l_1785) & ((--(*l_1795)) == (((p_37 <= (!(safe_mod_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u((g_247.f0 |= (((*l_1823) = (((safe_sub_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((l_1795 == ((*l_1785) , &g_1609)), (((((*g_1257) = l_1785) != (g_1808 = &g_73[3])) | ((((*l_1821) = ((safe_mod_func_uint32_t_u_u(((safe_mod_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(((safe_div_func_int32_t_s_s((safe_add_func_uint32_t_u_u((*l_1785), (((p_37 <= 0xE59CL) , 0x3AL) > (*p_35)))), p_37)) <= (*p_35)), 8UL)), 248UL)), 18446744073709551615UL)) <= (*l_1785)), 0x95A970EBL)) != (*l_1785))) , &g_1179) == l_1822)) , (**g_1659)))), (*l_1785))) < 0L) > 1L)) != p_36)), 0x2CL)) != g_361.f2), (*l_1785))))) == 18446744073709551615UL) < p_36)))), g_1743.f0)), (*l_1785))), g_904.f4)) != 0x8BD5L) , (*g_816)) != &l_1795) > (*p_35)) <= (*l_1785)), (*l_1785))))
    { /* block id: 947 */
        int32_t l_1833 = 1L;
        const uint16_t l_1845[9][10] = {{0xDE5FL,0UL,0UL,0xDE5FL,0UL,6UL,0x57E5L,65533UL,0UL,1UL},{0UL,1UL,0UL,0x4C13L,0xAC75L,0UL,0UL,0x57E5L,0UL,0UL},{1UL,0xDE5FL,65535UL,0xDE5FL,1UL,1UL,0xBAF9L,1UL,1UL,0xAC75L},{0x57E5L,0UL,0x4C13L,1UL,65535UL,6UL,0xAC75L,0UL,0UL,0xAC75L},{65533UL,1UL,0UL,0UL,1UL,65533UL,0x4C13L,0xDE5FL,6UL,0UL},{1UL,0x57E5L,0xA569L,0xBAF9L,0xAC75L,65535UL,0xBAF9L,1UL,1UL,1UL},{1UL,65533UL,0UL,1UL,0UL,65533UL,1UL,0UL,65533UL,0x57E5L},{65533UL,1UL,0UL,65533UL,0x57E5L,6UL,0UL,0xDE5FL,0UL,0UL},{0x57E5L,1UL,1UL,0xAC75L,0xAC75L,1UL,1UL,0x57E5L,0xA569L,0xBAF9L}};
        int32_t l_1851 = (-8L);
        int32_t l_1892 = 0x2D4936A9L;
        int32_t **l_1895 = (void*)0;
        int i, j;
        if (p_37)
        { /* block id: 948 */
            int8_t l_1829 = 0x2AL;
            int32_t **l_1836 = &g_214;
            int32_t ***l_1838 = &l_1836;
            g_904.f2 ^= ((((safe_div_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(0x0BA11487L, (((l_1829 | (safe_sub_func_int32_t_s_s((((+p_36) != ((p_37 || g_407[1].f0) , l_1833)) , (safe_mul_func_int16_t_s_s((((*l_1838) = (g_1837 = l_1836)) != (void*)0), (safe_add_func_uint32_t_u_u(((safe_div_func_uint64_t_u_u(((*g_1489) = (((--g_1424[3].f0) <= 0xC5L) <= 0x56L)), p_37)) > 1L), 0xC165A27CL))))), l_1845[4][4]))) , (-1L)) & g_330.f3))), g_1561.f5)) || (**l_1836)) , (***l_1838)) > g_185[3][4][5]);
            (**l_1838) = (**l_1838);
        }
        else
        { /* block id: 955 */
            int32_t *l_1846 = &g_2;
            int32_t *l_1847 = &g_361.f2;
            int32_t *l_1848 = &g_407[1].f2;
            int32_t *l_1849[4][7][9] = {{{&g_824[2].f2,&g_1180.f2,&g_138[3].f2,&g_903[1],&g_1180.f2,(void*)0,&g_2,&g_1696.f2,&g_361.f2},{(void*)0,&g_1695.f2,(void*)0,(void*)0,&g_1696.f2,&g_1696.f2,(void*)0,(void*)0,&g_1695.f2},{(void*)0,&g_407[1].f2,&g_361.f2,&g_138[3].f2,&g_830[1].f2,&g_1696.f2,&g_138[3].f2,&g_903[0],&g_111},{&g_1695.f2,&g_407[1].f2,&g_1180.f2,&g_903[1],&g_138[3].f2,&g_138[3].f2,(void*)0,(void*)0,(void*)0},{&g_1696.f2,&g_407[1].f2,&g_903[1],(void*)0,(void*)0,&g_885[0][7][3].f2,&g_1695.f2,&g_1180.f2,&g_903[1]},{(void*)0,&g_1695.f2,&g_138[3].f2,&g_128.f2,&g_407[1].f2,&g_1695.f2,(void*)0,&g_904.f2,(void*)0},{&g_1180.f2,&g_1180.f2,&g_361.f2,&g_903[1],&g_903[1],&g_361.f2,&g_1180.f2,&g_1180.f2,&g_1695.f2}},{{&g_407[1].f2,&g_463.f2,&g_903[1],&g_2,&g_361.f2,&g_637.f2,(void*)0,&g_138[3].f2,(void*)0},{&g_903[1],(void*)0,&g_824[2].f2,(void*)0,&g_637.f2,&g_138[3].f2,&g_1696.f2,&g_2,&g_1695.f2},{&g_903[1],&g_128.f2,&g_903[1],(void*)0,&g_904.f2,&g_903[1],&g_903[1],&g_637.f2,(void*)0},{(void*)0,(void*)0,&g_111,&g_885[0][7][3].f2,&g_903[1],&g_885[0][7][3].f2,(void*)0,&g_138[3].f2,(void*)0},{&g_903[1],&g_407[1].f2,&g_903[1],&g_903[1],&g_407[1].f2,&g_903[1],&g_903[1],(void*)0,&g_904.f2},{&g_830[1].f2,&g_824[2].f2,&g_903[1],&g_1180.f2,&g_111,(void*)0,&g_361.f2,&g_128.f2,&g_885[0][7][3].f2},{&g_2,&g_407[1].f2,(void*)0,&g_138[3].f2,&g_128.f2,&g_1695.f2,&g_903[1],(void*)0,&g_904.f2}},{{(void*)0,&g_128.f2,(void*)0,&g_830[1].f2,&g_637.f2,&g_361.f2,(void*)0,(void*)0,&g_903[1]},{&g_824[2].f2,&g_903[1],&g_2,&g_463.f2,(void*)0,&g_637.f2,(void*)0,&g_637.f2,(void*)0},{(void*)0,&g_830[1].f2,&g_830[1].f2,(void*)0,&g_138[3].f2,&g_903[1],(void*)0,&g_885[0][7][3].f2,(void*)0},{&g_128.f2,&g_903[1],(void*)0,&g_637.f2,&g_903[1],(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_111,(void*)0,&g_1180.f2,&g_138[3].f2,&g_885[0][7][3].f2,&g_830[1].f2,&g_407[1].f2,&g_1696.f2},{&g_2,(void*)0,&g_361.f2,&g_2,(void*)0,(void*)0,(void*)0,&g_138[3].f2,&g_2},{&g_885[0][7][3].f2,&g_361.f2,&g_1695.f2,&g_111,&g_637.f2,&g_1696.f2,&g_637.f2,&g_111,&g_1695.f2}},{{&g_138[3].f2,&g_138[3].f2,(void*)0,(void*)0,&g_128.f2,&g_903[1],&g_2,(void*)0,&g_1180.f2},{&g_1180.f2,&g_903[1],&g_1696.f2,&g_361.f2,&g_111,&g_138[3].f2,&g_1180.f2,&g_903[0],&g_1695.f2},{&g_138[3].f2,&g_361.f2,(void*)0,(void*)0,&g_407[1].f2,&g_824[2].f2,&g_2,&g_903[1],&g_138[3].f2},{(void*)0,&g_885[0][7][3].f2,&g_1695.f2,&g_1180.f2,&g_903[1],(void*)0,&g_361.f2,(void*)0,&g_824[2].f2},{&g_1695.f2,&g_2,&g_361.f2,&g_1696.f2,&g_138[3].f2,&g_1696.f2,&g_361.f2,&g_2,&g_1695.f2},{&g_361.f2,&g_903[0],(void*)0,&g_830[1].f2,&g_1180.f2,&g_903[1],&g_830[1].f2,&g_903[1],&g_885[0][7][3].f2},{&g_463.f2,&g_903[1],(void*)0,&g_138[3].f2,(void*)0,&g_637.f2,&g_2,&g_1695.f2,&g_903[1]}}};
            uint8_t l_1852 = 0xB0L;
            int64_t l_1863 = 0xB7214E5F36A41D32LL;
            uint16_t * const *l_1902 = &l_1795;
            uint16_t * const **l_1901[1];
            int8_t l_1905[10] = {8L,6L,6L,8L,6L,6L,8L,6L,6L,8L};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_1901[i] = &l_1902;
            --l_1852;
            for (g_1561.f4 = 13; (g_1561.f4 > (-15)); g_1561.f4 = safe_sub_func_uint64_t_u_u(g_1561.f4, 8))
            { /* block id: 959 */
                int64_t *l_1866 = &l_1863;
                int32_t l_1869 = 0x7547D7EDL;
                uint16_t ** const l_1904 = &l_1795;
                uint16_t ** const *l_1903 = &l_1904;
                int64_t l_1906[4][3][5] = {{{(-4L),(-1L),0x975722E35D009ACALL,0xA9473BC6F2F16EEDLL,0x7EC9364BD1CAEE62LL},{0x14B9BDC45070A9E1LL,0x79354B38E0A9A546LL,0x975722E35D009ACALL,0x79354B38E0A9A546LL,0x14B9BDC45070A9E1LL},{(-8L),0xF83AA578A74FFEACLL,0xA9473BC6F2F16EEDLL,5L,(-1L)}},{{0x79354B38E0A9A546LL,(-6L),0xC67FEA166C7F97DALL,0xCE51D3C5FAF0EB21LL,8L},{(-6L),0xC38DE2F5C27F6838LL,0xA28744BEFA34DEECLL,0x003ADAEB891B0858LL,5L},{(-3L),0xC38DE2F5C27F6838LL,(-1L),5L,0xA9473BC6F2F16EEDLL}},{{5L,0L,(-8L),(-5L),0xE74BFFE2FAEBBDDALL},{0xA28744BEFA34DEECLL,0L,0L,0xA28744BEFA34DEECLL,0x79354B38E0A9A546LL},{0xC67FEA166C7F97DALL,0xC38DE2F5C27F6838LL,0xA9473BC6F2F16EEDLL,(-3L),8L}},{{0x14B9BDC45070A9E1LL,8L,0x906A5AF32D4FCBC1LL,0xB6DEBEF6734B23DELL,(-8L)},{(-5L),0x975722E35D009ACALL,0xE74BFFE2FAEBBDDALL,(-3L),0x906A5AF32D4FCBC1LL},{0L,0x003ADAEB891B0858LL,0x14B9BDC45070A9E1LL,0xA28744BEFA34DEECLL,0xF83AA578A74FFEACLL}}};
                int i, j, k;
                if (g_656.f2)
                    goto lbl_1857;
                if (g_5.f4)
                    goto lbl_1953;
            }
        }
        (*g_283) = func_85(&l_1850, func_62(((*g_1489) = ((0xD49DC84C23506186LL || (safe_add_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((l_1845[4][4] >= (l_1892 &= ((safe_add_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u((safe_add_func_int8_t_s_s(l_1845[5][3], (safe_div_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((safe_sub_func_int64_t_s_s(((*l_1821) &= ((((*l_1785) & ((~(safe_lshift_func_uint8_t_u_s((safe_sub_func_int16_t_s_s(((*l_1823) ^= (((((void*)0 != &l_1845[8][3]) | (*p_35)) > (safe_mod_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(l_1950[1], 0x3FL)), p_36))) | 0x66L)), p_37)), 2))) ^ p_36)) != 1L) || 0xD675EDB0L)), p_36)), p_36)), g_656.f3)))), g_1561.f5)), p_36)) <= 0x00A1FDBFL))), 4)), g_128.f0))) != p_37)), g_52.f2, p_36, g_1743.f5), (*l_1785));
    }
    else
    { /* block id: 997 */
        for (g_183 = 0; (g_183 < 30); g_183 = safe_add_func_uint8_t_u_u(g_183, 7))
        { /* block id: 1000 */
        }
        (*g_1837) = (*g_1209);
    }
    for (g_1924.f1 = 0; (g_1924.f1 <= 0); g_1924.f1 += 1)
    { /* block id: 1008 */
        int16_t l_1957[1][6][3] = {{{0xD8E5L,7L,0xD8E5L},{0xD8E5L,7L,0xD8E5L},{0xD8E5L,7L,0xD8E5L},{0xD8E5L,7L,0xD8E5L},{0xD8E5L,7L,0xD8E5L},{0xD8E5L,7L,0xD8E5L}}};
        int16_t l_2038 = 0L;
        uint32_t *l_2135 = (void*)0;
        int16_t l_2156 = (-2L);
        int32_t l_2170 = 1L;
        int32_t l_2171 = 0xBAF9C35CL;
        int32_t l_2172 = 4L;
        int32_t l_2173 = 0L;
        int32_t l_2175 = (-1L);
        int32_t l_2176 = 1L;
        int32_t l_2181 = 0x4E3A6584L;
        int32_t l_2206 = 2L;
        int32_t l_2207 = (-6L);
        int32_t l_2209[2];
        uint16_t **l_2258 = &l_1795;
        uint32_t l_2262 = 7UL;
        uint32_t l_2266 = 0x3558F219L;
        struct S0 * const **l_2304 = (void*)0;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2209[i] = 0L;
        g_903[g_1924.f1] |= 0x90FD90CDL;
        if (g_903[g_1924.f1])
            continue;
    }
    return g_2265[5][3][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_5.f2
 * writes:
 */
static uint64_t  func_39(int8_t * p_40)
{ /* block id: 10 */
    return g_5.f2;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t * func_53(uint16_t  p_54, int8_t  p_55, uint32_t * p_56)
{ /* block id: 936 */
    return &g_74;
}


/* ------------------------------------------ */
/* 
 * reads : g_44.f4 g_504 g_330 g_52.f1 g_213 g_214 g_911 g_503.f1 g_1048 g_877 g_283 g_1089 g_138.f2 g_656.f2 g_5.f2 g_5.f0 g_169 g_138.f0 g_266.f0 g_5.f4 g_656.f5 g_46 g_2 g_1135 g_742.f0 g_1164 g_185 g_503.f5 g_1174 g_44 g_361.f2 g_111 g_1352 g_407.f2 g_815 g_1695.f4 g_1291
 * writes: g_44.f4 g_107 g_214 g_52.f1 g_911 g_503.f1 g_283 g_330 g_169 g_138.f2 g_656.f5 g_266.f0 g_1135 g_185 g_776.f0 g_44 g_253 g_187
 */
static int8_t  func_59(int16_t  p_60, const int8_t * p_61)
{ /* block id: 587 */
    int32_t **l_1072 = (void*)0;
    int32_t *l_1073 = (void*)0;
    int32_t l_1078[10] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
    uint64_t l_1079 = 0x6D7C993B7BA43D4BLL;
    uint8_t l_1085 = 0UL;
    int32_t l_1109 = 1L;
    int8_t l_1125 = 0L;
    uint32_t l_1190 = 0UL;
    const struct S0 *l_1193 = &g_851[1][1][0];
    const struct S0 **l_1192 = &l_1193;
    const struct S0 ***l_1191[1][1];
    uint16_t l_1201[5][3][1] = {{{65526UL},{65527UL},{0xAB4CL}},{{65527UL},{65526UL},{0x34D5L}},{{65526UL},{65527UL},{0xAB4CL}},{{65527UL},{65526UL},{0x34D5L}},{{65526UL},{65527UL},{0xAB4CL}}};
    uint32_t ** const l_1212 = &g_169;
    int32_t l_1336 = 0x65986EB6L;
    int32_t l_1358 = 1L;
    union U1 *l_1407[1];
    int8_t l_1413 = 0x0EL;
    int32_t **l_1595 = &g_1258;
    uint32_t l_1639 = 0x2B9FB61FL;
    const struct S0 ****l_1651[3];
    const struct S0 *****l_1650 = &l_1651[1];
    uint16_t l_1778[7] = {65533UL,65533UL,0UL,65533UL,65533UL,0UL,65533UL};
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_1191[i][j] = &l_1192;
    }
    for (i = 0; i < 1; i++)
        l_1407[i] = &g_1123;
    for (i = 0; i < 3; i++)
        l_1651[i] = &l_1191[0][0];
    l_1073 = (void*)0;
    for (g_44.f4 = 3; (g_44.f4 >= 0); g_44.f4 -= 1)
    { /* block id: 591 */
        int32_t * const l_1074 = &g_138[3].f2;
        int32_t **l_1075 = (void*)0;
        int32_t **l_1076[4] = {&g_214,&g_214,&g_214,&g_214};
        int32_t **l_1077 = &g_214;
        int i;
        g_107[g_44.f4] = (*g_504);
        (*l_1077) = l_1074;
        l_1079--;
        for (g_52.f1 = 0; (g_52.f1 <= 0); g_52.f1 += 1)
        { /* block id: 597 */
            int32_t *l_1082 = (void*)0;
            int32_t l_1083 = 2L;
            int32_t l_1084 = 1L;
            uint8_t *l_1115 = (void*)0;
            uint8_t **l_1114 = &l_1115;
            (*l_1077) = (*g_213);
            (*l_1077) = l_1082;
            if (p_60)
            { /* block id: 600 */
                volatile uint64_t l_1088 = 0xB3DF67D09271CEC3LL;/* VOLATILE GLOBAL l_1088 */
                uint32_t *l_1099[9] = {&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1,&g_776[2].f1};
                uint32_t **l_1098 = &l_1099[4];
                uint32_t **l_1107 = &g_169;
                int32_t l_1108[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_1108[i] = 2L;
                ++l_1085;
                for (g_911 = 0; (g_911 <= 0); g_911 += 1)
                { /* block id: 604 */
                    for (g_503.f1 = 0; (g_503.f1 <= 0); g_503.f1 += 1)
                    { /* block id: 607 */
                        int i, j, k;
                        l_1088 = g_1048[(g_52.f1 + 1)][g_911][g_503.f1];
                    }
                    (*g_877) = (*g_877);
                    (*g_504) = g_1089;
                    (*l_1077) = (void*)0;
                }
                if ((l_1088 , (safe_mul_func_int8_t_s_s(((safe_add_func_uint32_t_u_u((safe_sub_func_int32_t_s_s((((0x52L == (((safe_div_func_int8_t_s_s(((void*)0 != l_1098), (l_1083 = (+l_1088)))) > (*l_1074)) != ((((safe_div_func_int16_t_s_s((((*l_1107) = (((safe_rshift_func_uint16_t_u_u(g_656.f2, 14)) > ((((g_5.f2 || g_5.f0) && p_60) || p_60) == p_60)) , g_169)) == l_1073), g_138[3].f0)) & 18446744073709551607UL) <= 4294967295UL) | l_1108[5]))) , p_60) || l_1109), 0x2765E6EAL)), l_1108[5])) , l_1108[5]), 1UL))))
                { /* block id: 616 */
                    uint16_t l_1119 = 65534UL;
                    union U1 *l_1122 = &g_1123;
                    int32_t *l_1124[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1124[i] = &g_904.f2;
                    if (l_1108[4])
                        break;
                    (*l_1074) = 1L;
                    if ((safe_sub_func_int32_t_s_s((p_60 > (((safe_mod_func_int64_t_s_s(p_60, g_1089.f4)) && ((void*)0 != l_1114)) | 0UL)), ((safe_mul_func_uint8_t_u_u(0x30L, ((l_1108[5] |= (l_1119 ^= (l_1084 = (safe_unary_minus_func_int32_t_s(((p_60 && (0x2C1DL | g_266.f0)) | 0x58F241A0AD9C19FBLL)))))) != 0x95L))) >= 18446744073709551609UL))))
                    { /* block id: 622 */
                        union U1 *l_1121 = &g_885[0][7][3];
                        union U1 **l_1120[9][7][4] = {{{&l_1121,(void*)0,&l_1121,&l_1121},{&l_1121,&l_1121,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,&l_1121,&l_1121},{&l_1121,&l_1121,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,&l_1121,&l_1121,&l_1121}},{{&l_1121,(void*)0,(void*)0,&l_1121},{(void*)0,&l_1121,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,(void*)0,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,(void*)0},{(void*)0,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,(void*)0},{(void*)0,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,(void*)0,(void*)0},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,&l_1121,(void*)0},{&l_1121,(void*)0,(void*)0,&l_1121}},{{&l_1121,&l_1121,&l_1121,(void*)0},{&l_1121,&l_1121,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121}},{{&l_1121,(void*)0,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,&l_1121,&l_1121}},{{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,(void*)0},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,(void*)0}},{{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121}},{{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,(void*)0,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,&l_1121,&l_1121,&l_1121}},{{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,(void*)0,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,&l_1121},{(void*)0,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,&l_1121,(void*)0},{&l_1121,&l_1121,&l_1121,&l_1121},{&l_1121,&l_1121,(void*)0,&l_1121}}};
                        int i, j, k;
                        (*l_1074) = ((l_1122 = &g_138[1]) != (void*)0);
                        return (*p_61);
                    }
                    else
                    { /* block id: 626 */
                        (*l_1077) = l_1124[0];
                    }
                    return l_1125;
                }
                else
                { /* block id: 630 */
                    (*l_1074) |= (safe_lshift_func_int8_t_s_s((&l_1098 == (void*)0), (*p_61)));
                    for (g_656.f5 = (-20); (g_656.f5 <= 32); g_656.f5 = safe_add_func_int32_t_s_s(g_656.f5, 8))
                    { /* block id: 634 */
                        return (*p_61);
                    }
                }
            }
            else
            { /* block id: 638 */
                uint32_t l_1130[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_1130[i] = 0x68B550EDL;
                return l_1130[3];
            }
            if ((*g_46))
                continue;
        }
    }
    for (g_266.f0 = 0; (g_266.f0 <= 2); g_266.f0 += 1)
    { /* block id: 646 */
        int32_t *l_1131 = &g_904.f2;
        int32_t *l_1132 = &g_904.f2;
        int32_t *l_1133 = &l_1078[8];
        int32_t *l_1134[8][6][5] = {{{&g_463.f2,(void*)0,&l_1078[8],&g_511[2][3].f2,(void*)0},{&g_903[1],&g_407[1].f2,&g_824[2].f2,&l_1078[8],&g_830[1].f2},{&g_637.f2,&g_407[1].f2,&l_1078[1],(void*)0,(void*)0},{&g_407[1].f2,&l_1078[8],&g_407[1].f2,&l_1078[5],&g_111},{(void*)0,&l_1078[2],&g_511[2][3].f2,(void*)0,(void*)0},{(void*)0,&g_830[1].f2,(void*)0,&l_1078[8],&g_830[1].f2}},{{&g_830[1].f2,&g_511[2][3].f2,&g_904.f2,&g_903[1],(void*)0},{&g_1123.f2,&g_824[2].f2,&l_1078[8],&l_1078[5],&g_138[3].f2},{&l_1078[2],(void*)0,(void*)0,&g_511[2][3].f2,&l_1078[2]},{&g_407[1].f2,&g_138[3].f2,(void*)0,&g_128.f2,&l_1078[0]},{&l_1078[2],&l_1078[1],&l_1078[1],&l_1078[2],&g_903[1]},{&g_1123.f2,&g_407[1].f2,&g_128.f2,&g_138[3].f2,&g_407[1].f2}},{{&g_830[1].f2,&l_1078[2],(void*)0,&g_904.f2,&l_1078[2]},{&l_1078[0],&g_824[2].f2,&g_904.f2,&g_138[3].f2,&g_904.f2},{&g_463.f2,&g_824[2].f2,(void*)0,&l_1078[2],(void*)0},{&l_1078[8],&l_1078[5],&g_138[3].f2,&g_128.f2,&g_1123.f2},{(void*)0,&l_1078[4],(void*)0,&g_511[2][3].f2,&g_903[1]},{&g_824[2].f2,&l_1078[5],(void*)0,&l_1078[5],&g_824[2].f2}},{{&g_830[1].f2,&g_824[2].f2,&l_1078[1],&g_903[1],&g_463.f2},{&g_138[3].f2,&g_824[2].f2,(void*)0,&g_407[1].f2,&g_138[3].f2},{(void*)0,&l_1078[2],(void*)0,&g_824[2].f2,&g_463.f2},{&g_407[1].f2,&g_407[1].f2,&g_407[1].f2,&g_128.f2,&g_824[2].f2},{&g_463.f2,&l_1078[1],&g_904.f2,&g_463.f2,&g_903[1]},{&g_407[1].f2,&g_138[3].f2,&g_128.f2,&g_407[1].f2,&g_1123.f2}},{{&g_830[1].f2,(void*)0,&g_904.f2,&g_904.f2,(void*)0},{&g_830[1].f2,&g_824[2].f2,&g_407[1].f2,&l_1078[5],&g_904.f2},{&l_1078[2],&g_511[2][3].f2,(void*)0,(void*)0,&l_1078[2]},{&l_1078[8],&g_138[3].f2,(void*)0,&g_128.f2,&g_407[1].f2},{&l_1078[2],&l_1078[4],&l_1078[1],&l_1078[8],&g_903[1]},{&g_830[1].f2,&g_407[1].f2,(void*)0,&g_138[3].f2,&l_1078[0]}},{{&g_830[1].f2,&l_1078[8],(void*)0,&g_903[1],&l_1078[2]},{&g_407[1].f2,&g_824[2].f2,&g_138[3].f2,&g_138[3].f2,&g_138[3].f2},{&g_463.f2,&g_463.f2,(void*)0,&l_1078[8],(void*)0},{&g_407[1].f2,&l_1078[5],&g_904.f2,&g_128.f2,&g_830[1].f2},{(void*)0,&l_1078[1],(void*)0,(void*)0,&g_903[1]},{&g_138[3].f2,&l_1078[5],&g_128.f2,&l_1078[5],&g_138[3].f2}},{{&g_830[1].f2,&g_463.f2,&l_1078[1],&g_904.f2,&g_463.f2},{&g_824[2].f2,&g_824[2].f2,(void*)0,&g_407[1].f2,&g_904.f2},{(void*)0,&l_1078[8],(void*)0,&g_463.f2,&g_463.f2},{&l_1078[8],&g_407[1].f2,&l_1078[8],&g_128.f2,&g_138[3].f2},{&g_463.f2,&l_1078[4],&g_904.f2,&g_824[2].f2,&g_903[1]},{&l_1078[0],&g_138[3].f2,(void*)0,&g_407[1].f2,&g_830[1].f2}},{{&g_830[1].f2,&g_511[2][3].f2,&g_904.f2,&g_903[1],(void*)0},{&g_1123.f2,&g_824[2].f2,&l_1078[8],&l_1078[5],&g_111},{&l_1078[4],&g_903[1],&g_824[2].f2,&g_904.f2,&l_1078[4]},{&g_138[3].f2,&g_111,(void*)0,&l_1078[8],&g_407[1].f2},{&l_1078[4],(void*)0,(void*)0,&l_1078[4],(void*)0},{&g_138[3].f2,&g_824[2].f2,&g_407[1].f2,&g_111,&l_1078[8]}}};
        int i, j, k;
        g_1135++;
        for (g_330.f5 = 0; (g_330.f5 <= 3); g_330.f5 += 1)
        { /* block id: 650 */
            return (*p_61);
        }
    }
    if ((*g_46))
    { /* block id: 654 */
        int8_t l_1154 = 0x6AL;
        int32_t ***l_1167[1][2];
        uint16_t *l_1168 = &g_185[3][2][1];
        uint8_t *l_1173 = &g_776[2].f0;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_1167[i][j] = &l_1072;
        }
        l_1078[8] = ((safe_div_func_int64_t_s_s((((safe_lshift_func_uint8_t_u_u((!(safe_mod_func_int16_t_s_s((safe_add_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((+p_60) < l_1154), ((safe_rshift_func_uint16_t_u_u((((!g_742.f0) , (safe_rshift_func_uint8_t_u_s(0x50L, 7))) != (l_1154 | (safe_mod_func_uint32_t_u_u((safe_div_func_uint8_t_u_u((g_1164 , ((safe_mul_func_uint8_t_u_u(((*l_1173) = (((*l_1168) |= ((l_1072 = &g_214) != &l_1073)) ^ (safe_div_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_u((-7L), 4)) == p_60), g_330.f0)))), l_1079)) && (*p_61))), (*p_61))), 0xA03F5F15L)))), p_60)) , (*p_61)))), p_60)), (-6L))), (*p_61))), g_503.f5))), 3)) >= (-8L)) ^ 0x09DE6E83L), 0xA13AEF96F7BA3AADLL)) != p_60);
        (*l_1072) = (*l_1072);
    }
    else
    { /* block id: 660 */
        uint32_t l_1184[8] = {0x28BB64D9L,0x28BB64D9L,0x28BB64D9L,0x28BB64D9L,0x28BB64D9L,0x28BB64D9L,0x28BB64D9L,0x28BB64D9L};
        int32_t l_1195 = 0x891390CAL;
        int32_t l_1229 = 0x071ED957L;
        int32_t l_1231[5];
        int32_t *l_1289[5][10][5] = {{{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]},{&g_1180.f2,&l_1229,&g_1180.f2,&g_1123.f2,&g_637.f2},{&g_904.f2,&l_1078[1],&g_830[1].f2,&l_1231[4],&g_1123.f2},{&g_1180.f2,&l_1229,&g_361.f2,&g_637.f2,&g_637.f2},{&g_830[1].f2,&l_1231[0],&g_830[1].f2,&g_138[3].f2,&l_1231[0]},{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]},{&g_1180.f2,&l_1229,&g_1180.f2,&g_1123.f2,&g_637.f2},{&g_904.f2,&l_1078[1],&g_830[1].f2,&l_1231[4],&g_1123.f2}},{{&g_1180.f2,&l_1229,&g_361.f2,&g_637.f2,&g_637.f2},{&g_830[1].f2,&l_1231[0],&g_830[1].f2,&g_138[3].f2,&l_1231[0]},{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]},{&g_1180.f2,&l_1229,&g_1180.f2,&g_1123.f2,&g_637.f2},{&g_904.f2,&l_1078[1],&g_830[1].f2,&l_1231[4],&g_1123.f2},{&g_1180.f2,&l_1229,&g_361.f2,&g_637.f2,&g_637.f2},{&g_830[1].f2,&l_1231[0],&g_830[1].f2,&g_138[3].f2,&l_1231[0]},{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]}},{{&g_1180.f2,&l_1229,&g_1180.f2,&g_1123.f2,&g_637.f2},{&g_904.f2,&l_1078[1],&g_830[1].f2,&l_1231[4],&g_1123.f2},{&g_1180.f2,&l_1229,&g_361.f2,&g_637.f2,&g_637.f2},{&g_830[1].f2,&l_1231[0],&g_830[1].f2,&g_138[3].f2,&l_1231[0]},{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]},{&g_1180.f2,&l_1229,&g_1180.f2,&g_1123.f2,&g_637.f2},{&g_904.f2,&l_1078[1],&g_830[1].f2,&l_1231[4],&g_1123.f2},{&g_1180.f2,&l_1229,&g_361.f2,&g_637.f2,&g_637.f2},{&g_830[1].f2,&l_1231[0],&g_830[1].f2,&g_138[3].f2,&l_1231[0]}},{{&g_1180.f2,&g_885[0][7][3].f2,&g_1180.f2,&g_637.f2,&g_1123.f2},{&g_904.f2,&l_1231[0],&l_1195,&l_1231[4],&l_1231[0]},{&g_1180.f2,&l_1229,&g_111,&g_361.f2,&g_1180.f2},{&g_111,&l_1078[4],&l_1078[1],&g_637.f2,&l_1195},{&g_903[0],&l_1231[4],&l_1229,&g_1180.f2,&g_1180.f2},{&l_1078[1],&g_511[2][3].f2,&l_1078[1],(void*)0,&g_830[1].f2},{&g_903[0],&l_1231[0],&g_111,&g_1180.f2,&g_361.f2},{&g_111,&g_511[2][3].f2,&l_1195,&g_637.f2,&g_830[1].f2},{&g_111,&l_1231[4],&g_111,&g_361.f2,&g_1180.f2},{&g_111,&l_1078[4],&l_1078[1],&g_637.f2,&l_1195}},{{&g_903[0],&l_1231[4],&l_1229,&g_1180.f2,&g_1180.f2},{&l_1078[1],&g_511[2][3].f2,&l_1078[1],(void*)0,&g_830[1].f2},{&g_903[0],&l_1231[0],&g_111,&g_1180.f2,&g_361.f2},{&g_111,&g_511[2][3].f2,&l_1195,&g_637.f2,&g_830[1].f2},{&g_111,&l_1231[4],&g_111,&g_361.f2,&g_1180.f2},{&g_111,&l_1078[4],&l_1078[1],&g_637.f2,&l_1195},{&g_903[0],&l_1231[4],&l_1229,&g_1180.f2,&g_1180.f2},{&l_1078[1],&g_511[2][3].f2,&l_1078[1],(void*)0,&g_830[1].f2},{&g_903[0],&l_1231[0],&g_111,&g_1180.f2,&g_361.f2},{&g_111,&g_511[2][3].f2,&l_1195,&g_637.f2,&g_830[1].f2}}};
        const int32_t l_1326 = 0x3560256BL;
        union U1 **l_1444 = (void*)0;
        uint32_t l_1476[1][4] = {{0UL,0UL,0UL,0UL}};
        uint64_t *l_1486 = &g_1364[3].f5;
        int32_t l_1531[10][1][5] = {{{0L,(-1L),0x3B30A273L,7L,0x3B30A273L}},{{7L,7L,4L,(-7L),0L}},{{(-1L),(-7L),4L,1L,0L}},{{1L,4L,0x3B30A273L,4L,1L}},{{(-7L),(-7L),0L,1L,7L}},{{(-7L),7L,0L,(-1L),(-1L)}},{{1L,(-1L),1L,(-7L),7L}},{{(-1L),(-1L),7L,(-7L),1L}},{{7L,0L,(-1L),(-1L),0L}},{{0L,0L,7L,1L,0L}}};
        struct S0 ** const l_1546 = &g_283;
        uint32_t **l_1566 = (void*)0;
        int64_t l_1581 = 0L;
        int64_t l_1649 = 0xFDA85708304DFE5ELL;
        struct S0 ** const *l_1726[7] = {&l_1546,&l_1546,&l_1546,&l_1546,&l_1546,&l_1546,&l_1546};
        struct S0 ** const **l_1725[1];
        struct S0 ** const ***l_1724 = &l_1725[0];
        int32_t **l_1734 = (void*)0;
        int16_t *l_1774 = (void*)0;
        int16_t *l_1775 = &g_253;
        uint16_t *l_1776 = (void*)0;
        uint16_t *l_1777[4][8][2] = {{{&l_1201[3][0][0],&l_1201[3][0][0]},{&l_1201[1][0][0],&g_185[4][2][0]},{(void*)0,&g_185[3][2][1]},{(void*)0,&l_1201[1][0][0]},{&l_1201[3][0][0],(void*)0},{&l_1201[3][0][0],(void*)0},{&l_1201[3][0][0],(void*)0},{&l_1201[3][0][0],&l_1201[1][0][0]}},{{(void*)0,&g_185[3][2][1]},{(void*)0,&g_185[4][2][0]},{&l_1201[1][0][0],&l_1201[3][0][0]},{&l_1201[3][0][0],&l_1201[3][0][0]},{&l_1201[1][0][0],&g_185[4][2][0]},{(void*)0,&g_185[3][2][1]},{(void*)0,&l_1201[1][0][0]},{&l_1201[3][0][0],(void*)0}},{{&l_1201[3][0][0],(void*)0},{&l_1201[3][0][0],(void*)0},{&l_1201[3][0][0],&l_1201[1][0][0]},{(void*)0,&g_185[3][2][1]},{(void*)0,&g_185[4][2][0]},{&l_1201[3][0][0],&g_185[3][2][1]},{&g_185[3][2][1],&g_185[3][2][1]},{&l_1201[3][0][0],&l_1201[1][0][0]}},{{&l_1201[3][0][0],&l_1201[3][0][0]},{(void*)0,&l_1201[3][0][0]},{(void*)0,(void*)0},{&g_185[4][2][0],&g_1666},{&g_185[4][2][0],(void*)0},{(void*)0,&l_1201[3][0][0]},{(void*)0,&l_1201[3][0][0]},{&l_1201[3][0][0],&l_1201[1][0][0]}}};
        int8_t *l_1779[2];
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_1231[i] = 0xF3C2C022L;
        for (i = 0; i < 1; i++)
            l_1725[i] = &l_1726[3];
        for (i = 0; i < 2; i++)
            l_1779[i] = &g_332;
        for (l_1079 = 0; (l_1079 <= 0); l_1079 += 1)
        { /* block id: 663 */
            union U1 **l_1181 = &g_1179;
            int32_t l_1189 = 0x6DF833E4L;
            uint16_t *l_1194 = &g_185[3][4][5];
            int32_t l_1200 = 0x5DABA607L;
            const int64_t *l_1206 = (void*)0;
            const int64_t **l_1205 = &l_1206;
            uint32_t **l_1213 = &g_169;
            int32_t l_1232 = (-2L);
            int32_t * const  volatile *l_1261 = &l_1073;
            uint32_t l_1329 = 0xE2B188E8L;
            uint64_t l_1340[5] = {3UL,3UL,3UL,3UL,3UL};
            struct S0 ***l_1357 = (void*)0;
            uint16_t l_1384 = 65532UL;
            uint32_t l_1405 = 0x408C2D3DL;
            int32_t l_1412 = 0x1B8337D6L;
            int64_t l_1414 = 0x17CD547671672C8BLL;
            int32_t l_1415[6];
            int32_t l_1423 = 0x0333AEF0L;
            int32_t *l_1500 = &g_824[2].f2;
            int32_t **l_1654 = (void*)0;
            int64_t l_1665 = 0xFCD9C296343CD280LL;
            int32_t *l_1698 = &g_463.f0;
            uint16_t l_1755 = 5UL;
            int i;
            for (i = 0; i < 6; i++)
                l_1415[i] = (-10L);
            (*g_283) = g_1174;
        }
        l_1073 = ((0x665A34A9F83B15FDLL != (safe_rshift_func_uint16_t_u_s((l_1078[8] = (!(safe_add_func_int32_t_s_s(p_60, (((*l_1212) == (void*)0) | (g_330.f4 &= ((l_1778[1] = (safe_sub_func_uint8_t_u_u(((p_60 < (((safe_rshift_func_uint16_t_u_u(((*g_815) = ((((*g_283) , &g_169) == l_1212) <= (safe_add_func_int16_t_s_s(((*l_1775) = ((safe_div_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u(g_361.f2, g_111)) || (*g_1352)), p_60)) , 0x29C8L)), 0UL)))), 0)) || (-2L)) & 2UL)) , p_60), (*p_61)))) ^ g_1695.f4))))))), p_60))) , (*g_1291));
        for (l_1358 = 0; (l_1358 == 28); l_1358 = safe_add_func_uint8_t_u_u(l_1358, 6))
        { /* block id: 931 */
            return (*p_61);
        }
    }
    return (*p_61);
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_75 g_187 g_266.f0 g_52.f0
 * writes: g_2 g_75 g_52.f1 g_187 g_266.f0 g_52.f0
 */
static int8_t * func_62(uint64_t  p_63, int64_t  p_64, uint16_t  p_65, const int64_t  p_66)
{ /* block id: 19 */
    int32_t *l_67 = &g_2;
    int32_t *l_68 = &g_2;
    int32_t *l_69 = &g_2;
    int32_t *l_70 = &g_2;
    int32_t *l_71 = &g_2;
    int32_t *l_72[5][4][2] = {{{&g_2,&g_2},{&g_2,(void*)0},{&g_2,&g_2},{&g_2,(void*)0}},{{&g_2,&g_2},{&g_2,(void*)0},{&g_2,&g_2},{&g_2,(void*)0}},{{&g_2,&g_2},{&g_2,(void*)0},{&g_2,&g_2},{&g_2,(void*)0}},{{&g_2,&g_2},{&g_2,(void*)0},{&g_2,&g_2},{&g_2,(void*)0}},{{&g_2,&g_2},{&g_2,(void*)0},{&g_2,&g_2},{&g_2,(void*)0}}};
    int8_t *l_373 = &g_117;
    uint32_t ** const l_514 = (void*)0;
    uint32_t *l_517 = &g_247.f1;
    uint32_t **l_516 = &l_517;
    int32_t l_583[3];
    int32_t *l_642[5][1];
    int32_t **l_641[5][3] = {{&l_642[0][0],(void*)0,(void*)0},{&l_642[1][0],&l_642[0][0],&l_642[0][0]},{&l_642[0][0],(void*)0,(void*)0},{&l_642[1][0],&l_642[0][0],&l_642[0][0]},{&l_642[0][0],(void*)0,(void*)0}};
    uint64_t l_682 = 9UL;
    int8_t l_696 = 0x6DL;
    int32_t l_715 = 0L;
    struct S0 **l_852[1];
    int16_t *l_855 = (void*)0;
    uint8_t l_902 = 0x4DL;
    uint8_t *l_976 = &g_266.f0;
    uint8_t **l_975[2][9][1] = {{{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976}},{{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976},{&l_976}}};
    struct S0 ****l_1008 = (void*)0;
    int32_t l_1051 = 0xB725892CL;
    int16_t l_1053 = 0x09F0L;
    int16_t l_1063 = 1L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_583[i] = 0xD47C8427L;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
            l_642[i][j] = &g_511[2][3].f0;
    }
    for (i = 0; i < 1; i++)
        l_852[i] = &g_283;
    (*l_67) ^= p_66;
    g_75--;
    for (p_65 = 0; (p_65 <= 12); p_65 = safe_add_func_uint64_t_u_u(p_65, 8))
    { /* block id: 24 */
        const uint64_t l_80 = 7UL;
        uint32_t *l_81[4] = {&g_5.f1,&g_5.f1,&g_5.f1,&g_5.f1};
        uint32_t l_340 = 0x24753F2DL;
        int8_t *l_357 = &g_117;
        uint64_t l_380 = 0x234BA660FA898323LL;
        uint64_t *l_452 = &g_52.f5;
        int32_t l_462 = 4L;
        int32_t l_498 = 0xF4CA6417L;
        int32_t l_499 = 0x01C832B4L;
        int32_t l_536 = 0L;
        int64_t l_537 = 0xCA872A3EACA42A7CLL;
        int32_t l_538[8];
        uint16_t l_539 = 0UL;
        int32_t l_616 = 0L;
        int8_t *l_621 = &g_247.f4;
        uint32_t l_644 = 0UL;
        int i;
        for (i = 0; i < 8; i++)
            l_538[i] = 0x8DB30259L;
        (*l_68) ^= l_80;
        for (g_52.f1 = 0; (g_52.f1 <= 5); g_52.f1 += 1)
        { /* block id: 28 */
            uint64_t * const l_377[4] = {&g_247.f5,&g_247.f5,&g_247.f5,&g_247.f5};
            int32_t l_408 = (-2L);
            uint32_t *l_443 = &g_52.f2;
            uint8_t *l_447 = (void*)0;
            int i;
        }
    }
    for (g_187 = 26; (g_187 <= 11); --g_187)
    { /* block id: 392 */
        int16_t l_688[3];
        int32_t l_712 = 0x35744856L;
        int32_t l_714[4];
        int64_t *l_724 = (void*)0;
        uint8_t *l_754 = (void*)0;
        uint32_t *l_765 = &g_44.f1;
        uint32_t l_808 = 2UL;
        uint32_t l_811[8][9][3] = {{{0x2C869F85L,0x128A2510L,1UL},{4294967295UL,4294967287UL,4294967287UL},{0x804ABEEDL,0xE45038DFL,4294967295UL},{4294967293UL,0x23C5A9E2L,4294967295UL},{6UL,4294967295UL,4294967287UL},{0UL,0x96F3929AL,4294967292UL},{4294967288UL,4294967295UL,3UL},{4294967294UL,0x23C5A9E2L,0xF4DAF803L},{0x9F5A3E31L,0xE45038DFL,0UL}},{{0x96F3929AL,4294967287UL,0x5843053EL},{0x128A2510L,0x128A2510L,0x804ABEEDL},{0x5B14C267L,4294967292UL,0x16BFDF82L},{0x804ABEEDL,0xFAA22C8EL,0x91443463L},{9UL,0UL,4294967295UL},{1UL,0x804ABEEDL,0x91443463L},{8UL,0x96F3929AL,0x16BFDF82L},{4294967290UL,3UL,0x804ABEEDL},{4294967294UL,5UL,0x5843053EL}},{{0UL,3UL,0UL},{0xBA3C4165L,0xDC79D1B4L,0xF4DAF803L},{1UL,0x128A2510L,3UL},{4294967286UL,4294967294UL,4294967292UL},{0x804ABEEDL,1UL,4294967287UL},{4294967286UL,0xCD3CB295L,4294967295UL},{1UL,0xB94AA1C2L,4294967295UL},{0xBA3C4165L,0x96F3929AL,4294967287UL},{0UL,1UL,1UL}},{{4294967294UL,0xBA3C4165L,0xCD3CB295L},{0x91443463L,1UL,4294967287UL},{4294967292UL,4294967286UL,0x9502E9C7L},{4294967295UL,0x804ABEEDL,4294967290UL},{6UL,4294967286UL,0x5B14C267L},{4294967288UL,1UL,1UL},{0xF4DAF803L,0xBA3C4165L,4294967295UL},{0x804ABEEDL,0UL,3UL},{4294967294UL,4294967294UL,9UL}},{{0x08CB09D6L,4294967290UL,0x55128414L},{9UL,8UL,0x23C5A9E2L},{4294967295UL,1UL,4294967287UL},{0x16BFDF82L,9UL,0x23C5A9E2L},{0xB94AA1C2L,0x804ABEEDL,0x55128414L},{4294967295UL,0x5B14C267L,9UL},{4294967288UL,0x128A2510L,3UL},{4294967295UL,0x96F3929AL,4294967295UL},{3UL,0x9F5A3E31L,1UL}},{{4294967287UL,4294967294UL,0x5B14C267L},{4294967295UL,4294967288UL,4294967290UL},{9UL,0UL,0x9502E9C7L},{4294967295UL,6UL,4294967287UL},{4294967287UL,4294967293UL,0xCD3CB295L},{3UL,0x804ABEEDL,0UL},{4294967295UL,4294967295UL,4294967295UL},{4294967288UL,0x2C869F85L,0xFAA22C8EL},{4294967295UL,0x5E793CE4L,4294967295UL}},{{0xB94AA1C2L,0x55128414L,0xE45038DFL},{0x16BFDF82L,4294967294UL,4294967293UL},{4294967295UL,0x55128414L,0x9F5A3E31L},{9UL,0x5E793CE4L,0UL},{0x08CB09D6L,0x2C869F85L,4294967287UL},{4294967294UL,4294967295UL,5UL},{0x804ABEEDL,0x804ABEEDL,4294967288UL},{0xF4DAF803L,4294967293UL,4294967286UL},{4294967288UL,6UL,9UL}},{{6UL,0UL,4294967295UL},{4294967295UL,4294967288UL,9UL},{4294967292UL,4294967294UL,4294967286UL},{0x91443463L,0x9F5A3E31L,4294967288UL},{9UL,0x96F3929AL,5UL},{4294967287UL,0x128A2510L,4294967287UL},{0xDC79D1B4L,0x5B14C267L,0UL},{1UL,0x804ABEEDL,0x9F5A3E31L},{0x5843053EL,9UL,4294967293UL}}};
        union U1 *l_829 = &g_830[1];
        struct S0 **l_844 = &g_283;
        int32_t l_858 = 1L;
        uint8_t l_941 = 0x71L;
        uint16_t l_942 = 0x7F43L;
        int32_t *l_959[8][8][4] = {{{&l_714[0],&g_128.f2,&l_714[0],&l_583[1]},{&l_714[0],&l_583[0],&l_714[1],&g_904.f2},{&g_2,&l_583[1],&l_715,&g_128.f2},{&g_824[2].f2,&g_885[0][7][3].f2,&g_128.f2,&g_128.f2},{&g_830[1].f2,&l_583[0],(void*)0,&g_885[0][7][3].f2},{&l_715,&l_583[0],&g_904.f2,(void*)0},{&g_903[0],&g_885[0][7][3].f2,&g_128.f2,&g_361.f2},{&l_714[0],&g_904.f2,(void*)0,&g_361.f2}},{{&g_2,&g_885[0][7][3].f2,&g_138[3].f2,(void*)0},{&l_714[0],&l_583[0],&l_714[0],&g_885[0][7][3].f2},{&l_714[2],&l_583[0],&g_904.f2,&g_128.f2},{&g_2,&g_885[0][7][3].f2,&g_2,&g_128.f2},{&g_2,&l_583[1],&g_128.f2,&g_904.f2},{&g_824[2].f2,&l_583[0],&g_885[0][7][3].f2,&l_583[1]},{&l_715,&l_715,&g_128.f2,&g_128.f2},{&g_885[0][7][3].f2,(void*)0,&l_714[0],&g_128.f2}},{{&g_138[3].f2,&g_128.f2,&g_637.f2,&g_111},{&g_637.f2,&g_111,&g_885[0][7][3].f2,&g_128.f2},{(void*)0,&g_2,&l_714[0],&l_583[0]},{&l_715,(void*)0,&g_111,(void*)0},{&g_637.f2,&l_583[0],&g_904.f2,&g_2},{&l_714[1],&l_583[0],&l_714[0],(void*)0},{(void*)0,(void*)0,&l_714[0],&l_583[0]},{&g_830[1].f2,&g_2,&l_712,&g_128.f2}},{{&g_904.f2,&g_111,&l_714[0],&g_111},{&g_904.f2,&g_128.f2,&g_830[1].f2,&g_128.f2},{&g_637.f2,(void*)0,(void*)0,&g_128.f2},{&g_2,&l_715,&l_714[0],&g_904.f2},{&g_2,(void*)0,(void*)0,&g_2},{&g_637.f2,&g_904.f2,&g_830[1].f2,&g_2},{&g_904.f2,&g_407[1].f2,&l_714[0],&l_715},{&g_904.f2,(void*)0,&l_712,&g_407[1].f2}},{{&g_830[1].f2,(void*)0,&l_714[0],&g_128.f2},{(void*)0,&g_128.f2,&l_714[0],(void*)0},{&l_714[1],&g_128.f2,&g_904.f2,(void*)0},{&g_637.f2,&g_128.f2,&g_111,&g_128.f2},{&l_715,(void*)0,&l_714[0],&g_407[1].f2},{(void*)0,(void*)0,&g_885[0][7][3].f2,&l_715},{&g_637.f2,&g_407[1].f2,&g_637.f2,&g_2},{&g_138[3].f2,&g_904.f2,&l_714[0],&g_2}},{{&g_885[0][7][3].f2,(void*)0,&g_128.f2,&g_904.f2},{&g_830[1].f2,&l_715,&g_128.f2,&g_128.f2},{&g_885[0][7][3].f2,(void*)0,&l_714[0],&g_128.f2},{&g_138[3].f2,&g_128.f2,&g_637.f2,&g_111},{&g_637.f2,&g_111,&g_885[0][7][3].f2,&g_128.f2},{(void*)0,&g_2,&l_714[0],&l_583[0]},{&l_715,(void*)0,&g_111,(void*)0},{&g_637.f2,&l_583[0],&g_904.f2,&g_2}},{{&l_714[1],&l_583[0],&l_714[0],(void*)0},{(void*)0,(void*)0,&l_714[0],&l_583[0]},{&g_830[1].f2,&g_2,&l_712,&g_128.f2},{&g_904.f2,&g_111,&l_714[0],&g_111},{&g_904.f2,&g_128.f2,&g_830[1].f2,&g_128.f2},{&g_637.f2,(void*)0,(void*)0,&g_128.f2},{&g_2,&l_715,&l_714[0],&g_904.f2},{&g_2,(void*)0,(void*)0,&g_2}},{{&g_637.f2,&g_904.f2,&g_830[1].f2,&g_2},{&g_904.f2,&g_407[1].f2,&l_714[0],&l_715},{&g_904.f2,(void*)0,&l_712,&g_407[1].f2},{&g_830[1].f2,(void*)0,&l_714[0],&g_128.f2},{(void*)0,&g_128.f2,&l_714[0],(void*)0},{&l_714[1],&g_128.f2,&g_904.f2,(void*)0},{&g_824[2].f2,&g_2,&g_903[0],&g_885[0][7][3].f2},{&g_830[1].f2,&g_128.f2,&l_715,&g_128.f2}}};
        const int64_t *l_1020 = &g_1021;
        int32_t l_1023 = 0x948828C9L;
        int32_t *l_1045 = &g_511[2][3].f0;
        int32_t l_1065[3];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_688[i] = 0L;
        for (i = 0; i < 4; i++)
            l_714[i] = 0xDA4A66EBL;
        for (i = 0; i < 3; i++)
            l_1065[i] = 0xC7B3D8E8L;
        for (g_266.f0 = (-23); (g_266.f0 <= 2); ++g_266.f0)
        { /* block id: 395 */
            int8_t l_681 = (-1L);
            int64_t *l_683 = &g_137;
            const struct S0 **l_763 = (void*)0;
            int32_t l_768 = (-1L);
            int32_t *l_777 = &l_712;
            uint8_t *l_784 = &g_247.f0;
            struct S0 * const l_850 = &g_851[0][0][3];
            struct S0 * const *l_849[4][4] = {{(void*)0,&l_850,&l_850,(void*)0},{&l_850,(void*)0,&l_850,&l_850},{(void*)0,(void*)0,&l_850,(void*)0},{(void*)0,&l_850,&l_850,(void*)0}};
            struct S0 * const **l_848 = &l_849[0][1];
            struct S0 ***l_853 = (void*)0;
            struct S0 ***l_854 = &l_852[0];
            uint64_t *l_859 = &g_503.f5;
            int32_t l_909[7] = {0x9A06BEF8L,0x9A06BEF8L,0x9A06BEF8L,0x9A06BEF8L,0x9A06BEF8L,0x9A06BEF8L,0x9A06BEF8L};
            int i, j;
            if (p_65)
                break;
        }
        for (g_52.f0 = 0; (g_52.f0 == 11); g_52.f0 = safe_add_func_uint16_t_u_u(g_52.f0, 5))
        { /* block id: 535 */
            const int32_t ** const *l_971 = (void*)0;
            int8_t *l_972 = &g_266.f4;
            int32_t l_980[8][10] = {{0L,0L,0x75B5EF6BL,0x75B5EF6BL,0L,0L,(-1L),(-1L),(-1L),(-1L)},{0xF40BB93FL,0x75B5EF6BL,(-1L),(-1L),(-1L),0x75B5EF6BL,0xF40BB93FL,(-1L),0x34A80DE4L,0x34A80DE4L},{0xF40BB93FL,0x34A80DE4L,0L,0xCE3AD54CL,0xCE3AD54CL,0L,0x34A80DE4L,0xF40BB93FL,0L,(-1L)},{0L,0x34A80DE4L,0xF40BB93FL,0L,(-1L),0L,0xF40BB93FL,0x34A80DE4L,0L,0xCE3AD54CL},{(-1L),0x75B5EF6BL,0xF40BB93FL,(-1L),0x34A80DE4L,0x34A80DE4L,(-1L),0xF40BB93FL,0x75B5EF6BL,(-1L)},{0x75B5EF6BL,0L,0L,(-1L),(-1L),(-1L),(-1L),(-1L),0L,0L},{0xCE3AD54CL,0xF40BB93FL,(-1L),0L,(-1L),(-1L),(-1L),(-1L),0L,(-1L)},{(-1L),(-1L),0x75B5EF6BL,0xCE3AD54CL,0x34A80DE4L,(-1L),0L,(-1L),0x34A80DE4L,0xCE3AD54CL}};
            int32_t l_981 = 0x78D1EC0EL;
            const uint32_t *l_1014 = (void*)0;
            int32_t *l_1043 = &l_858;
            uint8_t l_1066 = 0UL;
            int32_t **l_1069 = &g_214;
            int32_t **l_1070 = &l_69;
            int i, j;
        }
    }
    return &g_117;
}


/* ------------------------------------------ */
/* 
 * reads : g_105 g_52.f5 g_44.f1 g_2 g_44.f4 g_213 g_187 g_247 g_361.f2 g_407.f2 g_1424.f1 g_111 g_1695.f2 g_903 g_138.f2
 * writes: g_107 g_52.f5 g_44.f1 g_44.f4 g_214 g_187
 */
static struct S0  func_85(int32_t * p_86, int8_t * p_87, int64_t  p_88)
{ /* block id: 41 */
    const int16_t l_104 = 0xA0E7L;
    int32_t *l_110[4][3] = {{&g_111,&g_111,&g_111},{(void*)0,&g_111,(void*)0},{&g_111,&g_111,&g_111},{(void*)0,&g_111,(void*)0}};
    int16_t l_122 = (-1L);
    uint32_t *l_140 = &g_5.f1;
    uint32_t **l_139 = &l_140;
    uint32_t ***l_164 = &l_139;
    struct S0 *l_246 = &g_247;
    int i, j;
    if (l_104)
    { /* block id: 42 */
        volatile struct S0 *l_106 = &g_107[3];
        int32_t *l_109[1][4][7] = {{{&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2},{&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2},{&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2},{&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2}}};
        int32_t **l_108[6] = {&l_109[0][0][2],&l_109[0][0][2],&l_109[0][0][2],&l_109[0][0][2],&l_109[0][0][2],&l_109[0][0][2]};
        int i, j, k;
        (*l_106) = g_105;
        l_110[2][1] = &g_2;
        for (g_52.f5 = 0; (g_52.f5 > 10); g_52.f5++)
        { /* block id: 47 */
            uint16_t l_114 = 0x4A54L;
            int32_t l_115 = 0xDF5CE337L;
            int32_t *l_123[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
            int8_t l_205 = 1L;
            int i;
            l_115 = l_114;
        }
        for (g_44.f1 = 0; (g_44.f1 == 28); g_44.f1++)
        { /* block id: 122 */
            int32_t l_212 = 0xB200F8A8L;
            if ((*p_86))
                break;
            for (g_44.f4 = 0; (g_44.f4 <= 16); ++g_44.f4)
            { /* block id: 126 */
                l_212 ^= (*p_86);
            }
        }
    }
    else
    { /* block id: 130 */
        int8_t l_254 = 0x63L;
        int32_t l_257[3];
        uint32_t l_260 = 0x3054315FL;
        struct S0 **l_305 = &g_283;
        uint16_t l_307 = 0xC7EEL;
        uint8_t l_309 = 5UL;
        int32_t *l_337 = (void*)0;
        int32_t **l_336 = &l_337;
        int i;
        for (i = 0; i < 3; i++)
            l_257[i] = 0x9DC52A56L;
        (*g_213) = p_86;
        for (g_187 = 0; (g_187 == 32); g_187++)
        { /* block id: 134 */
            uint64_t l_221 = 0x83AFEF4EC5B960CALL;
            uint8_t l_222 = 249UL;
            uint32_t *l_223 = &g_52.f2;
            uint32_t *l_224 = &g_44.f2;
            uint32_t l_232 = 0xDCA988B8L;
            uint8_t *l_235 = (void*)0;
            int32_t l_238[7][7][5] = {{{8L,0xD9746557L,8L,1L,1L},{0x67EFAB82L,0x62BA02E1L,0x1D28F4E3L,(-4L),0x98C11E5EL},{0x5DAA7FC3L,(-1L),0xFB33DBD0L,(-1L),0x5287A03EL},{0xBD227151L,0L,0x020E3752L,0xB6A064B6L,0x67EFAB82L},{1L,1L,0L,5L,0xD9E19FCCL},{0xB6B8BDBBL,9L,(-4L),0L,(-1L)},{0xC7E432CEL,0L,0xCFF7C256L,0xB9E7D250L,8L}},{{1L,1L,4L,1L,1L},{0L,0xC6794A24L,8L,0xD9E19FCCL,4L},{7L,1L,0x4D414897L,0xBD227151L,1L},{1L,3L,0xAD5C0386L,0xC6794A24L,4L},{(-5L),0xBD227151L,0x7CEA8F37L,4L,1L},{4L,0L,3L,1L,8L},{(-6L),9L,(-3L),0xB6B8BDBBL,(-1L)}},{{1L,5L,0xB98A7DEDL,0L,0L},{0x07505B71L,(-9L),0x020E3752L,0x1D28F4E3L,4L},{0x6523478FL,0xD9E19FCCL,0x90D848C7L,(-1L),0x90D848C7L},{1L,1L,(-10L),(-3L),0x67EFAB82L},{(-1L),8L,0xDACA1AAFL,0xEA4A7731L,0xAD5C0386L},{0x4D414897L,(-6L),(-9L),(-1L),4L},{0L,8L,0xADCA7809L,0L,0x276F2A36L}},{{0xB42CD97AL,1L,0L,(-1L),1L},{(-2L),0xD9E19FCCL,1L,(-1L),(-1L)},{0x62BA02E1L,(-9L),1L,(-5L),0x7CEA8F37L},{0x5DAA7FC3L,5L,1L,8L,0L},{0x5BDEF914L,9L,0x07505B71L,0xA1B0B828L,0x160A19EDL},{1L,0L,0L,1L,(-1L)},{0x1D28F4E3L,0xBD227151L,0x6E8ED6D0L,4L,0x07505B71L}},{{0xB98A7DEDL,3L,0xFB33DBD0L,0x930EC5A8L,(-1L)},{0x67EFAB82L,1L,0L,4L,0xB6A064B6L},{0xE83EF03DL,0xC6794A24L,0xEA4A7731L,1L,(-1L)},{(-1L),1L,0L,0xA1B0B828L,0xBD227151L},{0xB22930BFL,0L,(-1L),8L,(-3L)},{0x7CEA8F37L,0x6E8ED6D0L,4L,(-5L),(-1L)},{0L,0xAD5C0386L,8L,(-1L),0x321761CEL}},{{0xE5084947L,0x020E3752L,(-1L),(-1L),0x020E3752L},{0xAD5C0386L,(-2L),0x8A206926L,0L,0xC6794A24L},{(-1L),0xE5084947L,(-4L),(-1L),(-1L)},{0x5287A03EL,0x930EC5A8L,1L,0xEA4A7731L,1L},{(-1L),0x160A19EDL,0x98C11E5EL,(-3L),(-5L)},{0xAD5C0386L,1L,0x5287A03EL,(-1L),0x9C2A5C2EL},{0xE5084947L,0x5BDEF914L,0x67EFAB82L,0x1D28F4E3L,0xB42CD97AL}},{{0L,8L,0xD9E19FCCL,0L,0x8A206926L},{0x7CEA8F37L,(-3L),(-6L),0xB6B8BDBBL,(-1L)},{0x5DAA7FC3L,0x5287A03EL,8L,5L,5L},{1L,(-4L),1L,0x7CEA8F37L,0L},{0xB22930BFL,1L,4L,0xB9E7D250L,0L},{4L,1L,1L,9L,4L},{0x8A206926L,5L,4L,0L,0xB98A7DEDL}}};
            int16_t *l_298 = &l_122;
            int i, j, k;
        }
        l_257[1] ^= (((*l_336) = (void*)0) != ((safe_mul_func_uint16_t_u_u(p_88, p_88)) , &g_73[4]));
    }
    return (*l_246);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5.f0, "g_5.f0", print_hash_value);
    transparent_crc(g_5.f1, "g_5.f1", print_hash_value);
    transparent_crc(g_5.f2, "g_5.f2", print_hash_value);
    transparent_crc(g_5.f3, "g_5.f3", print_hash_value);
    transparent_crc(g_5.f4, "g_5.f4", print_hash_value);
    transparent_crc(g_5.f5, "g_5.f5", print_hash_value);
    transparent_crc(g_44.f0, "g_44.f0", print_hash_value);
    transparent_crc(g_44.f1, "g_44.f1", print_hash_value);
    transparent_crc(g_44.f2, "g_44.f2", print_hash_value);
    transparent_crc(g_44.f3, "g_44.f3", print_hash_value);
    transparent_crc(g_44.f4, "g_44.f4", print_hash_value);
    transparent_crc(g_44.f5, "g_44.f5", print_hash_value);
    transparent_crc(g_52.f0, "g_52.f0", print_hash_value);
    transparent_crc(g_52.f1, "g_52.f1", print_hash_value);
    transparent_crc(g_52.f2, "g_52.f2", print_hash_value);
    transparent_crc(g_52.f3, "g_52.f3", print_hash_value);
    transparent_crc(g_52.f4, "g_52.f4", print_hash_value);
    transparent_crc(g_52.f5, "g_52.f5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_73[i], "g_73[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_105.f0, "g_105.f0", print_hash_value);
    transparent_crc(g_105.f1, "g_105.f1", print_hash_value);
    transparent_crc(g_105.f2, "g_105.f2", print_hash_value);
    transparent_crc(g_105.f3, "g_105.f3", print_hash_value);
    transparent_crc(g_105.f4, "g_105.f4", print_hash_value);
    transparent_crc(g_105.f5, "g_105.f5", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_107[i].f0, "g_107[i].f0", print_hash_value);
        transparent_crc(g_107[i].f1, "g_107[i].f1", print_hash_value);
        transparent_crc(g_107[i].f2, "g_107[i].f2", print_hash_value);
        transparent_crc(g_107[i].f3, "g_107[i].f3", print_hash_value);
        transparent_crc(g_107[i].f4, "g_107[i].f4", print_hash_value);
        transparent_crc(g_107[i].f5, "g_107[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_185[i][j][k], "g_185[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_187, "g_187", print_hash_value);
    transparent_crc(g_247.f0, "g_247.f0", print_hash_value);
    transparent_crc(g_247.f1, "g_247.f1", print_hash_value);
    transparent_crc(g_247.f2, "g_247.f2", print_hash_value);
    transparent_crc(g_247.f3, "g_247.f3", print_hash_value);
    transparent_crc(g_247.f4, "g_247.f4", print_hash_value);
    transparent_crc(g_247.f5, "g_247.f5", print_hash_value);
    transparent_crc(g_253, "g_253", print_hash_value);
    transparent_crc(g_255, "g_255", print_hash_value);
    transparent_crc(g_266.f0, "g_266.f0", print_hash_value);
    transparent_crc(g_266.f1, "g_266.f1", print_hash_value);
    transparent_crc(g_266.f2, "g_266.f2", print_hash_value);
    transparent_crc(g_266.f3, "g_266.f3", print_hash_value);
    transparent_crc(g_266.f4, "g_266.f4", print_hash_value);
    transparent_crc(g_266.f5, "g_266.f5", print_hash_value);
    transparent_crc(g_330.f0, "g_330.f0", print_hash_value);
    transparent_crc(g_330.f1, "g_330.f1", print_hash_value);
    transparent_crc(g_330.f2, "g_330.f2", print_hash_value);
    transparent_crc(g_330.f3, "g_330.f3", print_hash_value);
    transparent_crc(g_330.f4, "g_330.f4", print_hash_value);
    transparent_crc(g_330.f5, "g_330.f5", print_hash_value);
    transparent_crc(g_332, "g_332", print_hash_value);
    transparent_crc(g_333, "g_333", print_hash_value);
    transparent_crc(g_402.f0, "g_402.f0", print_hash_value);
    transparent_crc(g_402.f1, "g_402.f1", print_hash_value);
    transparent_crc(g_402.f2, "g_402.f2", print_hash_value);
    transparent_crc(g_402.f3, "g_402.f3", print_hash_value);
    transparent_crc(g_402.f4, "g_402.f4", print_hash_value);
    transparent_crc(g_402.f5, "g_402.f5", print_hash_value);
    transparent_crc(g_489.f0, "g_489.f0", print_hash_value);
    transparent_crc(g_489.f1, "g_489.f1", print_hash_value);
    transparent_crc(g_489.f2, "g_489.f2", print_hash_value);
    transparent_crc(g_489.f3, "g_489.f3", print_hash_value);
    transparent_crc(g_489.f4, "g_489.f4", print_hash_value);
    transparent_crc(g_489.f5, "g_489.f5", print_hash_value);
    transparent_crc(g_503.f0, "g_503.f0", print_hash_value);
    transparent_crc(g_503.f1, "g_503.f1", print_hash_value);
    transparent_crc(g_503.f2, "g_503.f2", print_hash_value);
    transparent_crc(g_503.f3, "g_503.f3", print_hash_value);
    transparent_crc(g_503.f4, "g_503.f4", print_hash_value);
    transparent_crc(g_503.f5, "g_503.f5", print_hash_value);
    transparent_crc(g_531, "g_531", print_hash_value);
    transparent_crc(g_630.f0, "g_630.f0", print_hash_value);
    transparent_crc(g_630.f1, "g_630.f1", print_hash_value);
    transparent_crc(g_630.f2, "g_630.f2", print_hash_value);
    transparent_crc(g_630.f3, "g_630.f3", print_hash_value);
    transparent_crc(g_630.f4, "g_630.f4", print_hash_value);
    transparent_crc(g_630.f5, "g_630.f5", print_hash_value);
    transparent_crc(g_656.f0, "g_656.f0", print_hash_value);
    transparent_crc(g_656.f1, "g_656.f1", print_hash_value);
    transparent_crc(g_656.f2, "g_656.f2", print_hash_value);
    transparent_crc(g_656.f3, "g_656.f3", print_hash_value);
    transparent_crc(g_656.f4, "g_656.f4", print_hash_value);
    transparent_crc(g_656.f5, "g_656.f5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_664[i], "g_664[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_776[i].f0, "g_776[i].f0", print_hash_value);
        transparent_crc(g_776[i].f1, "g_776[i].f1", print_hash_value);
        transparent_crc(g_776[i].f2, "g_776[i].f2", print_hash_value);
        transparent_crc(g_776[i].f3, "g_776[i].f3", print_hash_value);
        transparent_crc(g_776[i].f4, "g_776[i].f4", print_hash_value);
        transparent_crc(g_776[i].f5, "g_776[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_847.f0, "g_847.f0", print_hash_value);
    transparent_crc(g_847.f1, "g_847.f1", print_hash_value);
    transparent_crc(g_847.f2, "g_847.f2", print_hash_value);
    transparent_crc(g_847.f3, "g_847.f3", print_hash_value);
    transparent_crc(g_847.f4, "g_847.f4", print_hash_value);
    transparent_crc(g_847.f5, "g_847.f5", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_851[i][j][k].f0, "g_851[i][j][k].f0", print_hash_value);
                transparent_crc(g_851[i][j][k].f1, "g_851[i][j][k].f1", print_hash_value);
                transparent_crc(g_851[i][j][k].f2, "g_851[i][j][k].f2", print_hash_value);
                transparent_crc(g_851[i][j][k].f3, "g_851[i][j][k].f3", print_hash_value);
                transparent_crc(g_851[i][j][k].f4, "g_851[i][j][k].f4", print_hash_value);
                transparent_crc(g_851[i][j][k].f5, "g_851[i][j][k].f5", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_903[i], "g_903[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_911, "g_911", print_hash_value);
    transparent_crc(g_954, "g_954", print_hash_value);
    transparent_crc(g_1019, "g_1019", print_hash_value);
    transparent_crc(g_1021, "g_1021", print_hash_value);
    transparent_crc(g_1028, "g_1028", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1048[i][j][k], "g_1048[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1089.f0, "g_1089.f0", print_hash_value);
    transparent_crc(g_1089.f1, "g_1089.f1", print_hash_value);
    transparent_crc(g_1089.f2, "g_1089.f2", print_hash_value);
    transparent_crc(g_1089.f3, "g_1089.f3", print_hash_value);
    transparent_crc(g_1089.f4, "g_1089.f4", print_hash_value);
    transparent_crc(g_1089.f5, "g_1089.f5", print_hash_value);
    transparent_crc(g_1135, "g_1135", print_hash_value);
    transparent_crc(g_1174.f0, "g_1174.f0", print_hash_value);
    transparent_crc(g_1174.f1, "g_1174.f1", print_hash_value);
    transparent_crc(g_1174.f2, "g_1174.f2", print_hash_value);
    transparent_crc(g_1174.f3, "g_1174.f3", print_hash_value);
    transparent_crc(g_1174.f4, "g_1174.f4", print_hash_value);
    transparent_crc(g_1174.f5, "g_1174.f5", print_hash_value);
    transparent_crc(g_1286, "g_1286", print_hash_value);
    transparent_crc(g_1308, "g_1308", print_hash_value);
    transparent_crc(g_1338, "g_1338", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1364[i].f0, "g_1364[i].f0", print_hash_value);
        transparent_crc(g_1364[i].f1, "g_1364[i].f1", print_hash_value);
        transparent_crc(g_1364[i].f2, "g_1364[i].f2", print_hash_value);
        transparent_crc(g_1364[i].f3, "g_1364[i].f3", print_hash_value);
        transparent_crc(g_1364[i].f4, "g_1364[i].f4", print_hash_value);
        transparent_crc(g_1364[i].f5, "g_1364[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1404, "g_1404", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1424[i].f0, "g_1424[i].f0", print_hash_value);
        transparent_crc(g_1424[i].f1, "g_1424[i].f1", print_hash_value);
        transparent_crc(g_1424[i].f2, "g_1424[i].f2", print_hash_value);
        transparent_crc(g_1424[i].f3, "g_1424[i].f3", print_hash_value);
        transparent_crc(g_1424[i].f4, "g_1424[i].f4", print_hash_value);
        transparent_crc(g_1424[i].f5, "g_1424[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1561.f0, "g_1561.f0", print_hash_value);
    transparent_crc(g_1561.f1, "g_1561.f1", print_hash_value);
    transparent_crc(g_1561.f2, "g_1561.f2", print_hash_value);
    transparent_crc(g_1561.f3, "g_1561.f3", print_hash_value);
    transparent_crc(g_1561.f4, "g_1561.f4", print_hash_value);
    transparent_crc(g_1561.f5, "g_1561.f5", print_hash_value);
    transparent_crc(g_1609, "g_1609", print_hash_value);
    transparent_crc(g_1611, "g_1611", print_hash_value);
    transparent_crc(g_1666, "g_1666", print_hash_value);
    transparent_crc(g_1736.f0, "g_1736.f0", print_hash_value);
    transparent_crc(g_1736.f1, "g_1736.f1", print_hash_value);
    transparent_crc(g_1736.f2, "g_1736.f2", print_hash_value);
    transparent_crc(g_1736.f3, "g_1736.f3", print_hash_value);
    transparent_crc(g_1736.f4, "g_1736.f4", print_hash_value);
    transparent_crc(g_1736.f5, "g_1736.f5", print_hash_value);
    transparent_crc(g_1743.f0, "g_1743.f0", print_hash_value);
    transparent_crc(g_1743.f1, "g_1743.f1", print_hash_value);
    transparent_crc(g_1743.f2, "g_1743.f2", print_hash_value);
    transparent_crc(g_1743.f3, "g_1743.f3", print_hash_value);
    transparent_crc(g_1743.f4, "g_1743.f4", print_hash_value);
    transparent_crc(g_1743.f5, "g_1743.f5", print_hash_value);
    transparent_crc(g_1880.f0, "g_1880.f0", print_hash_value);
    transparent_crc(g_1880.f1, "g_1880.f1", print_hash_value);
    transparent_crc(g_1880.f2, "g_1880.f2", print_hash_value);
    transparent_crc(g_1880.f3, "g_1880.f3", print_hash_value);
    transparent_crc(g_1880.f4, "g_1880.f4", print_hash_value);
    transparent_crc(g_1880.f5, "g_1880.f5", print_hash_value);
    transparent_crc(g_1924.f0, "g_1924.f0", print_hash_value);
    transparent_crc(g_1924.f1, "g_1924.f1", print_hash_value);
    transparent_crc(g_1924.f2, "g_1924.f2", print_hash_value);
    transparent_crc(g_1924.f3, "g_1924.f3", print_hash_value);
    transparent_crc(g_1924.f4, "g_1924.f4", print_hash_value);
    transparent_crc(g_1924.f5, "g_1924.f5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1963[i], "g_1963[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2088.f0, "g_2088.f0", print_hash_value);
    transparent_crc(g_2088.f1, "g_2088.f1", print_hash_value);
    transparent_crc(g_2088.f2, "g_2088.f2", print_hash_value);
    transparent_crc(g_2088.f3, "g_2088.f3", print_hash_value);
    transparent_crc(g_2088.f4, "g_2088.f4", print_hash_value);
    transparent_crc(g_2088.f5, "g_2088.f5", print_hash_value);
    transparent_crc(g_2121.f0, "g_2121.f0", print_hash_value);
    transparent_crc(g_2121.f1, "g_2121.f1", print_hash_value);
    transparent_crc(g_2121.f2, "g_2121.f2", print_hash_value);
    transparent_crc(g_2121.f3, "g_2121.f3", print_hash_value);
    transparent_crc(g_2121.f4, "g_2121.f4", print_hash_value);
    transparent_crc(g_2121.f5, "g_2121.f5", print_hash_value);
    transparent_crc(g_2123.f0, "g_2123.f0", print_hash_value);
    transparent_crc(g_2123.f1, "g_2123.f1", print_hash_value);
    transparent_crc(g_2123.f2, "g_2123.f2", print_hash_value);
    transparent_crc(g_2123.f3, "g_2123.f3", print_hash_value);
    transparent_crc(g_2123.f4, "g_2123.f4", print_hash_value);
    transparent_crc(g_2123.f5, "g_2123.f5", print_hash_value);
    transparent_crc(g_2124.f0, "g_2124.f0", print_hash_value);
    transparent_crc(g_2124.f1, "g_2124.f1", print_hash_value);
    transparent_crc(g_2124.f2, "g_2124.f2", print_hash_value);
    transparent_crc(g_2124.f3, "g_2124.f3", print_hash_value);
    transparent_crc(g_2124.f4, "g_2124.f4", print_hash_value);
    transparent_crc(g_2124.f5, "g_2124.f5", print_hash_value);
    transparent_crc(g_2157.f0, "g_2157.f0", print_hash_value);
    transparent_crc(g_2157.f1, "g_2157.f1", print_hash_value);
    transparent_crc(g_2157.f2, "g_2157.f2", print_hash_value);
    transparent_crc(g_2157.f3, "g_2157.f3", print_hash_value);
    transparent_crc(g_2157.f4, "g_2157.f4", print_hash_value);
    transparent_crc(g_2157.f5, "g_2157.f5", print_hash_value);
    transparent_crc(g_2183, "g_2183", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2265[i][j][k], "g_2265[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2283.f0, "g_2283.f0", print_hash_value);
    transparent_crc(g_2283.f1, "g_2283.f1", print_hash_value);
    transparent_crc(g_2283.f2, "g_2283.f2", print_hash_value);
    transparent_crc(g_2283.f3, "g_2283.f3", print_hash_value);
    transparent_crc(g_2283.f4, "g_2283.f4", print_hash_value);
    transparent_crc(g_2283.f5, "g_2283.f5", print_hash_value);
    transparent_crc(g_2284.f0, "g_2284.f0", print_hash_value);
    transparent_crc(g_2284.f1, "g_2284.f1", print_hash_value);
    transparent_crc(g_2284.f2, "g_2284.f2", print_hash_value);
    transparent_crc(g_2284.f3, "g_2284.f3", print_hash_value);
    transparent_crc(g_2284.f4, "g_2284.f4", print_hash_value);
    transparent_crc(g_2284.f5, "g_2284.f5", print_hash_value);
    transparent_crc(g_2316.f0, "g_2316.f0", print_hash_value);
    transparent_crc(g_2316.f1, "g_2316.f1", print_hash_value);
    transparent_crc(g_2316.f2, "g_2316.f2", print_hash_value);
    transparent_crc(g_2316.f3, "g_2316.f3", print_hash_value);
    transparent_crc(g_2316.f4, "g_2316.f4", print_hash_value);
    transparent_crc(g_2316.f5, "g_2316.f5", print_hash_value);
    transparent_crc(g_2447, "g_2447", print_hash_value);
    transparent_crc(g_2514.f0, "g_2514.f0", print_hash_value);
    transparent_crc(g_2514.f1, "g_2514.f1", print_hash_value);
    transparent_crc(g_2514.f2, "g_2514.f2", print_hash_value);
    transparent_crc(g_2514.f3, "g_2514.f3", print_hash_value);
    transparent_crc(g_2514.f4, "g_2514.f4", print_hash_value);
    transparent_crc(g_2514.f5, "g_2514.f5", print_hash_value);
    transparent_crc(g_2561.f0, "g_2561.f0", print_hash_value);
    transparent_crc(g_2561.f1, "g_2561.f1", print_hash_value);
    transparent_crc(g_2561.f2, "g_2561.f2", print_hash_value);
    transparent_crc(g_2561.f3, "g_2561.f3", print_hash_value);
    transparent_crc(g_2561.f4, "g_2561.f4", print_hash_value);
    transparent_crc(g_2561.f5, "g_2561.f5", print_hash_value);
    transparent_crc(g_2624, "g_2624", print_hash_value);
    transparent_crc(g_2774, "g_2774", print_hash_value);
    transparent_crc(g_2783.f0, "g_2783.f0", print_hash_value);
    transparent_crc(g_2783.f1, "g_2783.f1", print_hash_value);
    transparent_crc(g_2783.f2, "g_2783.f2", print_hash_value);
    transparent_crc(g_2783.f3, "g_2783.f3", print_hash_value);
    transparent_crc(g_2783.f4, "g_2783.f4", print_hash_value);
    transparent_crc(g_2783.f5, "g_2783.f5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2801[i][j][k], "g_2801[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2803, "g_2803", print_hash_value);
    transparent_crc(g_2918.f0, "g_2918.f0", print_hash_value);
    transparent_crc(g_2918.f1, "g_2918.f1", print_hash_value);
    transparent_crc(g_2918.f2, "g_2918.f2", print_hash_value);
    transparent_crc(g_2918.f3, "g_2918.f3", print_hash_value);
    transparent_crc(g_2918.f4, "g_2918.f4", print_hash_value);
    transparent_crc(g_2918.f5, "g_2918.f5", print_hash_value);
    transparent_crc(g_2919.f0, "g_2919.f0", print_hash_value);
    transparent_crc(g_2919.f1, "g_2919.f1", print_hash_value);
    transparent_crc(g_2919.f2, "g_2919.f2", print_hash_value);
    transparent_crc(g_2919.f3, "g_2919.f3", print_hash_value);
    transparent_crc(g_2919.f4, "g_2919.f4", print_hash_value);
    transparent_crc(g_2919.f5, "g_2919.f5", print_hash_value);
    transparent_crc(g_2920.f0, "g_2920.f0", print_hash_value);
    transparent_crc(g_2920.f1, "g_2920.f1", print_hash_value);
    transparent_crc(g_2920.f2, "g_2920.f2", print_hash_value);
    transparent_crc(g_2920.f3, "g_2920.f3", print_hash_value);
    transparent_crc(g_2920.f4, "g_2920.f4", print_hash_value);
    transparent_crc(g_2920.f5, "g_2920.f5", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_3033[i].f0, "g_3033[i].f0", print_hash_value);
        transparent_crc(g_3033[i].f1, "g_3033[i].f1", print_hash_value);
        transparent_crc(g_3033[i].f2, "g_3033[i].f2", print_hash_value);
        transparent_crc(g_3033[i].f3, "g_3033[i].f3", print_hash_value);
        transparent_crc(g_3033[i].f4, "g_3033[i].f4", print_hash_value);
        transparent_crc(g_3033[i].f5, "g_3033[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3049.f0, "g_3049.f0", print_hash_value);
    transparent_crc(g_3049.f1, "g_3049.f1", print_hash_value);
    transparent_crc(g_3049.f2, "g_3049.f2", print_hash_value);
    transparent_crc(g_3049.f3, "g_3049.f3", print_hash_value);
    transparent_crc(g_3049.f4, "g_3049.f4", print_hash_value);
    transparent_crc(g_3049.f5, "g_3049.f5", print_hash_value);
    transparent_crc(g_3060.f0, "g_3060.f0", print_hash_value);
    transparent_crc(g_3060.f1, "g_3060.f1", print_hash_value);
    transparent_crc(g_3060.f2, "g_3060.f2", print_hash_value);
    transparent_crc(g_3060.f3, "g_3060.f3", print_hash_value);
    transparent_crc(g_3060.f4, "g_3060.f4", print_hash_value);
    transparent_crc(g_3060.f5, "g_3060.f5", print_hash_value);
    transparent_crc(g_3064.f0, "g_3064.f0", print_hash_value);
    transparent_crc(g_3064.f1, "g_3064.f1", print_hash_value);
    transparent_crc(g_3064.f2, "g_3064.f2", print_hash_value);
    transparent_crc(g_3064.f3, "g_3064.f3", print_hash_value);
    transparent_crc(g_3064.f4, "g_3064.f4", print_hash_value);
    transparent_crc(g_3064.f5, "g_3064.f5", print_hash_value);
    transparent_crc(g_3084.f0, "g_3084.f0", print_hash_value);
    transparent_crc(g_3084.f1, "g_3084.f1", print_hash_value);
    transparent_crc(g_3084.f2, "g_3084.f2", print_hash_value);
    transparent_crc(g_3084.f3, "g_3084.f3", print_hash_value);
    transparent_crc(g_3084.f4, "g_3084.f4", print_hash_value);
    transparent_crc(g_3084.f5, "g_3084.f5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3102[i], "g_3102[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3106, "g_3106", print_hash_value);
    transparent_crc(g_3123.f0, "g_3123.f0", print_hash_value);
    transparent_crc(g_3123.f1, "g_3123.f1", print_hash_value);
    transparent_crc(g_3123.f2, "g_3123.f2", print_hash_value);
    transparent_crc(g_3123.f3, "g_3123.f3", print_hash_value);
    transparent_crc(g_3123.f4, "g_3123.f4", print_hash_value);
    transparent_crc(g_3123.f5, "g_3123.f5", print_hash_value);
    transparent_crc(g_3131.f0, "g_3131.f0", print_hash_value);
    transparent_crc(g_3131.f1, "g_3131.f1", print_hash_value);
    transparent_crc(g_3131.f2, "g_3131.f2", print_hash_value);
    transparent_crc(g_3131.f3, "g_3131.f3", print_hash_value);
    transparent_crc(g_3131.f4, "g_3131.f4", print_hash_value);
    transparent_crc(g_3131.f5, "g_3131.f5", print_hash_value);
    transparent_crc(g_3216.f0, "g_3216.f0", print_hash_value);
    transparent_crc(g_3216.f1, "g_3216.f1", print_hash_value);
    transparent_crc(g_3216.f2, "g_3216.f2", print_hash_value);
    transparent_crc(g_3216.f3, "g_3216.f3", print_hash_value);
    transparent_crc(g_3216.f4, "g_3216.f4", print_hash_value);
    transparent_crc(g_3216.f5, "g_3216.f5", print_hash_value);
    transparent_crc(g_3217.f0, "g_3217.f0", print_hash_value);
    transparent_crc(g_3217.f1, "g_3217.f1", print_hash_value);
    transparent_crc(g_3217.f2, "g_3217.f2", print_hash_value);
    transparent_crc(g_3217.f3, "g_3217.f3", print_hash_value);
    transparent_crc(g_3217.f4, "g_3217.f4", print_hash_value);
    transparent_crc(g_3217.f5, "g_3217.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 804
   depth: 1, occurrence: 45
XXX total union variables: 32

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 48
breakdown:
   depth: 1, occurrence: 108
   depth: 2, occurrence: 28
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1
   depth: 16, occurrence: 1
   depth: 25, occurrence: 2
   depth: 27, occurrence: 2
   depth: 31, occurrence: 2
   depth: 36, occurrence: 1
   depth: 44, occurrence: 1
   depth: 48, occurrence: 1

XXX total number of pointers: 672

XXX times a variable address is taken: 1949
XXX times a pointer is dereferenced on RHS: 419
breakdown:
   depth: 1, occurrence: 350
   depth: 2, occurrence: 36
   depth: 3, occurrence: 20
   depth: 4, occurrence: 13
XXX times a pointer is dereferenced on LHS: 449
breakdown:
   depth: 1, occurrence: 411
   depth: 2, occurrence: 21
   depth: 3, occurrence: 10
   depth: 4, occurrence: 7
XXX times a pointer is compared with null: 68
XXX times a pointer is compared with address of another variable: 13
XXX times a pointer is compared with another pointer: 22
XXX times a pointer is qualified to be dereferenced: 12304

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1867
   level: 2, occurrence: 233
   level: 3, occurrence: 110
   level: 4, occurrence: 44
   level: 5, occurrence: 1
   level: 6, occurrence: 1
XXX number of pointers point to pointers: 240
XXX number of pointers point to scalars: 408
XXX number of pointers point to structs: 11
XXX percent of pointers has null in alias set: 31.2
XXX average alias set size: 1.95

XXX times a non-volatile is read: 2527
XXX times a non-volatile is write: 1355
XXX times a volatile is read: 200
XXX    times read thru a pointer: 30
XXX times a volatile is write: 62
XXX    times written thru a pointer: 16
XXX times a volatile is available for access: 9.95e+03
XXX percentage of non-volatile access: 93.7

XXX forward jumps: 2
XXX backward jumps: 15

XXX stmts: 108
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 40
   depth: 2, occurrence: 17
   depth: 3, occurrence: 8
   depth: 4, occurrence: 10
   depth: 5, occurrence: 5

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
********************* end of statistics **********************/

