/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3019785151
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const uint32_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x490C4D8EL;
static uint16_t g_6 = 0x2E31L;
static uint64_t g_35 = 0x664087A912E75507LL;
static int32_t *g_73 = &g_3;
static int32_t **g_72[5] = {&g_73,&g_73,&g_73,&g_73,&g_73};
static uint8_t g_86[2] = {0xD5L,0xD5L};
static int16_t g_93 = (-4L);
static uint16_t g_96 = 65535UL;
static uint8_t g_98 = 0x01L;
static uint32_t g_100 = 1UL;
static uint8_t g_103 = 3UL;
static int32_t g_105 = 1L;
static int32_t * volatile g_104 = &g_105;/* VOLATILE GLOBAL g_104 */
static uint32_t g_133 = 0xD4517DE8L;
static int8_t g_137 = 0x7AL;
static int32_t g_139 = 0xA476D206L;
static int32_t * volatile g_138 = &g_139;/* VOLATILE GLOBAL g_138 */
static int8_t g_181[3][5] = {{0x63L,0x63L,0x63L,0x63L,0x63L},{0x63L,0x63L,0x63L,0x63L,0x63L},{0x63L,0x63L,0x63L,0x63L,0x63L}};
static struct S0 g_183 = {0UL};
static int8_t g_201 = 0x16L;
static int64_t g_238 = (-2L);
static const int32_t g_256 = 0xDB0985CDL;
static int32_t *g_289 = &g_3;
static volatile uint16_t g_311 = 0x16E1L;/* VOLATILE GLOBAL g_311 */
static struct S0 g_362 = {18446744073709551609UL};
static struct S0 *g_361 = &g_362;
static int16_t *** volatile g_433 = (void*)0;/* VOLATILE GLOBAL g_433 */
static int64_t g_467 = 5L;
static uint64_t g_517[10] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static volatile uint32_t g_537 = 0x322E2172L;/* VOLATILE GLOBAL g_537 */
static int64_t g_556 = 0xBC4754B4CDC9302ALL;
static uint16_t g_560[1] = {0UL};
static uint8_t g_567[7][9] = {{0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL},{0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL},{0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL},{0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL},{0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL},{0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL,0x3DL},{0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL,0UL,0x2CL}};
static volatile uint32_t *g_571 = &g_537;
static volatile uint32_t ** volatile g_570 = &g_571;/* VOLATILE GLOBAL g_570 */
static volatile uint32_t ** volatile * volatile g_572 = &g_570;/* VOLATILE GLOBAL g_572 */
static int32_t ** volatile g_573 = &g_289;/* VOLATILE GLOBAL g_573 */
static int32_t ** const  volatile g_574[8][9][3] = {{{(void*)0,(void*)0,&g_289},{&g_289,(void*)0,&g_73},{&g_73,&g_73,&g_73},{&g_73,&g_73,&g_73},{(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289},{(void*)0,(void*)0,(void*)0},{&g_289,&g_73,&g_289},{(void*)0,&g_289,&g_73}},{{&g_73,&g_73,&g_73},{&g_73,&g_73,(void*)0},{&g_289,&g_289,&g_73},{(void*)0,(void*)0,(void*)0},{&g_73,&g_289,&g_289},{&g_289,(void*)0,(void*)0},{&g_289,&g_73,&g_73},{(void*)0,&g_73,(void*)0},{&g_289,&g_289,&g_73}},{{&g_289,(void*)0,&g_73},{&g_289,&g_73,&g_289},{&g_73,(void*)0,(void*)0},{&g_73,&g_289,&g_289},{&g_73,(void*)0,(void*)0},{&g_289,&g_73,&g_73},{&g_289,(void*)0,&g_73},{&g_73,&g_289,&g_73},{&g_289,&g_73,&g_289}},{{&g_289,&g_73,(void*)0},{&g_73,(void*)0,(void*)0},{&g_289,&g_289,&g_289},{&g_73,(void*)0,(void*)0},{&g_289,&g_289,&g_289},{&g_289,&g_73,&g_73},{&g_73,&g_73,&g_73},{&g_289,&g_289,(void*)0},{&g_289,&g_73,(void*)0}},{{&g_73,(void*)0,&g_73},{&g_73,&g_289,(void*)0},{&g_73,(void*)0,(void*)0},{&g_289,&g_73,&g_73},{&g_289,&g_73,&g_73},{&g_289,(void*)0,&g_289},{(void*)0,(void*)0,(void*)0},{&g_289,&g_289,&g_289},{&g_289,&g_73,(void*)0}},{{&g_73,&g_289,(void*)0},{(void*)0,(void*)0,&g_289},{&g_73,&g_289,&g_73},{&g_289,(void*)0,&g_289},{&g_289,&g_289,&g_73},{&g_289,(void*)0,(void*)0},{&g_73,&g_289,&g_73},{(void*)0,(void*)0,(void*)0},{&g_73,&g_289,&g_73}},{{&g_289,&g_289,&g_73},{&g_289,&g_289,(void*)0},{&g_289,&g_289,&g_73},{&g_73,&g_289,&g_289},{(void*)0,(void*)0,&g_289},{(void*)0,(void*)0,&g_289},{&g_289,(void*)0,&g_289},{&g_73,&g_73,&g_289},{(void*)0,&g_73,&g_73}},{{(void*)0,&g_73,(void*)0},{(void*)0,&g_73,&g_73},{(void*)0,&g_289,&g_73},{&g_73,&g_289,(void*)0},{&g_73,&g_289,&g_73},{(void*)0,&g_289,(void*)0},{&g_289,&g_289,&g_73},{&g_73,&g_73,&g_289},{&g_73,&g_73,&g_73}}};
static int32_t ** volatile g_575 = &g_289;/* VOLATILE GLOBAL g_575 */
static const int32_t g_597 = (-10L);
static uint32_t g_618 = 0x56174DCCL;
static uint64_t *g_634 = &g_517[2];
static uint64_t **g_633 = &g_634;
static uint64_t *** volatile g_632 = &g_633;/* VOLATILE GLOBAL g_632 */
static int8_t g_637 = 0x73L;
static int16_t *g_647 = &g_93;
static int16_t **g_646 = &g_647;
static volatile int32_t g_666 = (-1L);/* VOLATILE GLOBAL g_666 */
static volatile int32_t g_756 = 0L;/* VOLATILE GLOBAL g_756 */
static volatile int32_t * volatile g_755 = &g_756;/* VOLATILE GLOBAL g_755 */
static volatile int32_t * volatile *g_754 = &g_755;
static volatile int32_t * volatile **g_753 = &g_754;
static volatile int32_t * volatile ** volatile *g_752[1][4][5] = {{{&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753},{&g_753,&g_753,&g_753,&g_753,&g_753}}};
static int32_t ** volatile g_863 = &g_289;/* VOLATILE GLOBAL g_863 */
static int32_t g_883 = (-3L);
static int32_t g_892 = (-8L);
static int16_t g_909 = (-10L);
static uint32_t ***g_920 = (void*)0;
static uint32_t g_962 = 0x1A9BD555L;
static int64_t g_1030 = 0x8E71592EC6E3ABE8LL;
static uint8_t *** volatile g_1076 = (void*)0;/* VOLATILE GLOBAL g_1076 */
static uint8_t *g_1080 = &g_86[1];
static uint8_t **g_1079 = &g_1080;
static uint8_t *** volatile g_1078 = &g_1079;/* VOLATILE GLOBAL g_1078 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_9(uint8_t  p_10, int32_t  p_11, const uint32_t  p_12, int32_t  p_13);
static int8_t  func_16(uint8_t  p_17, int64_t  p_18, int32_t * const  p_19, int16_t  p_20);
static uint8_t  func_23(int16_t  p_24, uint16_t  p_25, int16_t  p_26, int32_t * p_27);
static int32_t * func_31(uint64_t  p_32, uint16_t  p_33);
static int64_t  func_39(uint64_t  p_40);
static int32_t * func_41(uint64_t * p_42, uint8_t  p_43, uint64_t  p_44);
static uint64_t * func_45(const int32_t * p_46);
static int32_t * func_48(uint64_t * p_49, uint32_t  p_50);
static int32_t * func_52(int32_t * p_53, int32_t * p_54, uint64_t  p_55, uint64_t  p_56, int8_t  p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_3 g_35 g_72 g_86 g_104 g_105 g_133 g_100 g_137 g_103 g_138 g_139 g_73 g_181 g_98 g_183 g_238 g_201 g_96 g_289 g_256 g_311 g_361 g_362 g_93 g_517 g_467 g_537 g_560 g_567 g_570 g_572 g_573 g_575 g_556 g_597 g_637 g_646 g_647 g_634 g_863 g_892 g_571 g_633 g_618 g_920 g_753 g_754 g_755 g_1078 g_1079 g_1080
 * writes: g_6 g_35 g_72 g_86 g_93 g_96 g_98 g_100 g_103 g_105 g_73 g_133 g_137 g_139 g_181 g_201 g_361 g_238 g_467 g_556 g_560 g_567 g_570 g_289 g_517 g_892 g_909 g_3 g_920 g_756
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3;
    int32_t *l_4 = &g_3;
    int32_t *l_5 = &g_3;
    int64_t l_28 = 0xEF889A278C007C7BLL;
    uint64_t *l_34 = &g_35;
    int32_t *l_891 = &g_892;
    struct S0 l_913 = {0x3C3E60A8L};
    uint32_t *l_918[10];
    uint32_t **l_917[3];
    uint32_t ***l_916 = &l_917[2];
    uint64_t *l_930 = (void*)0;
    uint32_t *l_931 = (void*)0;
    int32_t l_971 = 9L;
    int32_t * const *l_997 = &g_289;
    int32_t l_1022 = 0xC355F3B8L;
    int32_t l_1031 = (-3L);
    uint64_t l_1034 = 0x3B07AC8549936B45LL;
    int32_t l_1089 = (-9L);
    int32_t l_1090 = 0xFF8151A3L;
    int64_t l_1098[7];
    int32_t l_1100 = (-1L);
    int32_t l_1104 = 4L;
    uint64_t l_1105 = 0x0ECE0B20E8760E91LL;
    int8_t l_1132 = 8L;
    uint32_t l_1135[2];
    int i;
    for (i = 0; i < 10; i++)
        l_918[i] = &g_100;
    for (i = 0; i < 3; i++)
        l_917[i] = &l_918[7];
    for (i = 0; i < 7; i++)
        l_1098[i] = 2L;
    for (i = 0; i < 2; i++)
        l_1135[i] = 4294967295UL;
    --g_6;
    (*l_891) |= (func_9((safe_mod_func_uint8_t_u_u((*l_4), func_16((safe_div_func_uint8_t_u_u(func_23(l_28, (((safe_rshift_func_uint8_t_u_s(0x1DL, 5)) == g_3) , ((65531UL && 0x3F15L) , 65530UL)), g_3, func_31(((*l_34)++), (g_3 ^ (*l_4)))), g_517[5])), g_517[5], &g_3, (*l_5)))), g_637, g_517[1], g_597) >= (*l_4));
    for (g_105 = (-21); (g_105 < (-5)); g_105++)
    { /* block id: 397 */
        int16_t l_910 = 8L;
        uint32_t ****l_919[8] = {&l_916,(void*)0,(void*)0,&l_916,(void*)0,(void*)0,&l_916,(void*)0};
        int i;
        for (g_103 = 11; (g_103 >= 11); g_103 = safe_add_func_int16_t_s_s(g_103, 3))
        { /* block id: 400 */
            int8_t l_907 = 0L;
            int16_t *l_908 = &g_909;
            uint16_t *l_911 = (void*)0;
            uint16_t *l_912[6][3] = {{&g_96,&g_96,&g_96},{&g_560[0],(void*)0,&g_560[0]},{&g_96,&g_96,&g_96},{&g_560[0],(void*)0,&g_560[0]},{&g_96,&g_96,&g_96},{&g_560[0],(void*)0,&g_560[0]}};
            int i, j;
            (*l_891) |= ((**g_570) , (safe_lshift_func_int16_t_s_u((**g_646), ((*l_2) = (safe_rshift_func_int16_t_s_u((*l_2), ((((safe_rshift_func_int16_t_s_u((((**g_646) , (((((safe_add_func_int32_t_s_s(((**g_633) , ((*g_634) != (safe_mul_func_int16_t_s_s(((*l_908) = l_907), (*l_5))))), (0x69L & g_618))) < l_910) , 0xA8L) == g_567[3][4]) ^ l_907)) != l_907), 10)) , (*l_2)) ^ 0xE9L) && l_910)))))));
        }
        (***g_753) = (((l_913 , ((safe_add_func_uint16_t_u_u(((((((g_920 = l_916) != ((safe_rshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((safe_rshift_func_int8_t_s_s((-1L), (safe_lshift_func_int16_t_s_s((**g_646), 6)))), 0x0347153E8B7ADFF5LL)), 4)) , ((~l_910) , &l_917[2]))) && ((l_931 = (g_6 , ((**l_916) = (**g_920)))) == (**g_572))) != g_560[0]) || g_6) != g_556), 0x627FL)) , 0x2A400C80L)) > 4294967295UL) >= g_560[0]);
    }
    for (g_3 = 1; (g_3 <= 6); g_3 += 1)
    { /* block id: 412 */
        uint64_t l_932 = 18446744073709551615UL;
        int32_t *l_935 = &g_105;
        int32_t l_1028 = (-5L);
        int32_t l_1029 = 0xA4264701L;
        int32_t ***l_1052 = &g_72[3];
        int32_t ****l_1051 = &l_1052;
        int32_t l_1091 = 0x1A41FAD9L;
        int32_t l_1092 = 1L;
        int32_t l_1093 = (-5L);
        int32_t l_1096 = 1L;
        int32_t l_1102 = 0L;
        uint64_t *l_1158 = &l_932;
        l_932++;
        for (g_103 = 0; (g_103 <= 6); g_103 += 1)
        { /* block id: 416 */
            int32_t l_961 = 0xC97C928AL;
            int64_t l_1020 = 7L;
            int32_t l_1027 = (-1L);
            uint16_t l_1037 = 65532UL;
            uint64_t *l_1061 = &l_1034;
            const uint32_t *l_1069[10];
            const uint32_t ** const l_1068 = &l_1069[9];
            const uint32_t ** const * const l_1067 = &l_1068;
            uint8_t **l_1074 = (void*)0;
            int16_t l_1081 = 0L;
            int32_t l_1094 = 0x7DD4E3AAL;
            int32_t l_1097 = 0x67CA3E35L;
            struct S0 l_1151 = {18446744073709551610UL};
            int i, j;
            for (i = 0; i < 10; i++)
                l_1069[i] = (void*)0;
            (***g_753) = g_567[g_3][g_103];
        }
    }
    return (***g_1078);
}


/* ------------------------------------------ */
/* 
 * reads : g_646 g_647 g_181 g_201 g_133 g_139 g_362.f0 g_575 g_289 g_86 g_634 g_6 g_104 g_863 g_35
 * writes: g_93 g_181 g_133 g_289 g_517 g_6 g_105 g_35 g_139 g_73
 */
static int16_t  func_9(uint8_t  p_10, int32_t  p_11, const uint32_t  p_12, int32_t  p_13)
{ /* block id: 358 */
    int16_t ***l_778 = &g_646;
    int32_t l_779 = 0x58E735FEL;
    uint16_t l_787 = 0x1CD7L;
    int8_t l_807 = 0xE2L;
    int8_t *l_808 = &g_181[2][3];
    uint32_t *l_809 = (void*)0;
    uint32_t *l_810 = &g_133;
    int64_t l_811 = 0xB827B0CE913468F6LL;
    int32_t l_815 = 1L;
    int32_t l_816[3];
    uint32_t l_817[1][2][10] = {{{0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L},{0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L,0x38A1D402L}}};
    uint32_t l_872 = 0x9380CECDL;
    int16_t l_890 = 0x9485L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_816[i] = 9L;
    l_779 = (l_778 == (void*)0);
    if ((safe_mul_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(1L, ((**g_646) = (safe_add_func_uint64_t_u_u(l_779, 2UL))))), (p_12 <= ((l_787 = (~l_779)) >= ((!(safe_div_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u((p_12 < ((((safe_div_func_uint32_t_u_u(p_13, ((*l_810) |= ((p_10 , (safe_sub_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((safe_div_func_int8_t_s_s(((*l_808) |= (((safe_mod_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u((&g_618 != &p_12), p_11)) >= p_12), 2L)) , (-4L)) , 8UL), (-1L))) | l_779) || l_807)), p_10)), 0xF262L)) & 0x58BB74E8CB2176E8LL), g_201))) ^ 5L)))) , 0x8FBEFC4C29337F8FLL) > l_779) | l_807)), 8)) & 0x8AE1D2F976A37444LL), g_139))) & l_811))))))
    { /* block id: 364 */
        int32_t *l_812 = &g_139;
        int32_t l_813 = (-1L);
        int32_t *l_814[4][2] = {{&g_3,&l_813},{&l_813,&g_3},{&l_813,&l_813},{&g_3,&l_813}};
        int i, j;
        --l_817[0][1][9];
    }
    else
    { /* block id: 366 */
        int64_t l_824 = 0x882B903B59A96A25LL;
        int16_t *** const * const l_827 = &l_778;
        int32_t l_853 = 4L;
        int32_t l_854 = 7L;
        int32_t *l_864 = &l_853;
        int32_t *l_865 = &l_816[1];
        int32_t *l_866 = &l_854;
        int32_t *l_867 = &l_815;
        int32_t *l_868 = &l_816[1];
        int32_t *l_869[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t l_870 = 0x3921AC56L;
        int32_t l_871 = 1L;
        int32_t *l_875 = &l_815;
        uint32_t l_884 = 18446744073709551615UL;
        int i;
        if ((safe_add_func_int32_t_s_s(((safe_sub_func_int64_t_s_s(9L, (((l_824 & ((safe_lshift_func_uint16_t_u_u(0xD655L, 12)) , l_824)) , &l_778) != l_827))) && p_11), g_362.f0)))
        { /* block id: 367 */
            int32_t **l_828 = &g_289;
            (*l_828) = (*g_575);
            (*g_104) = ((safe_unary_minus_func_int32_t_s((**l_828))) < (safe_rshift_func_uint16_t_u_s((l_817[0][1][9] , (l_854 = (g_6 |= ((l_853 = (safe_lshift_func_uint8_t_u_u((~(-10L)), (+(g_86[0] != ((safe_div_func_int8_t_s_s((p_11 , (safe_mul_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u(((*g_634) = (safe_div_func_uint64_t_u_u((((safe_mul_func_uint8_t_u_u(0x6EL, (safe_rshift_func_int16_t_s_u((!0xCBE3L), ((void*)0 != &g_362))))) < (**l_828)) <= 0UL), 0x7478BA7789184E4CLL))), l_816[1])), 0xA3153476A5921FC8LL)), l_824))), 3UL)) >= (-1L))))))) , l_779)))), l_811)));
        }
        else
        { /* block id: 374 */
            uint8_t *l_857 = &g_86[1];
            int32_t l_862[8];
            int i;
            for (i = 0; i < 8; i++)
                l_862[i] = 1L;
            (*g_863) = &l_854;
        }
        ++l_872;
        for (g_35 = 0; (g_35 <= 1); g_35 += 1)
        { /* block id: 381 */
            int32_t **l_876 = &l_865;
            int32_t **l_877 = &l_867;
            int32_t l_878 = 0L;
            int32_t l_879 = (-10L);
            int32_t l_880 = 0xAADB060BL;
            int32_t l_881[4][4][2] = {{{0x0350C4A8L,0x1B8B3A6CL},{0xDC597EFFL,(-1L)},{1L,0xDC597EFFL},{(-1L),0x1B8B3A6CL}},{{(-1L),0xDC597EFFL},{1L,(-1L)},{0xDC597EFFL,0x1B8B3A6CL},{0x0350C4A8L,0x0350C4A8L}},{{1L,0x0350C4A8L},{0x0350C4A8L,0x1B8B3A6CL},{0xDC597EFFL,(-1L)},{1L,0xDC597EFFL}},{{(-1L),0x1B8B3A6CL},{(-1L),0xDC597EFFL},{1L,(-1L)},{0xDC597EFFL,0x1B8B3A6CL}}};
            int32_t l_882[5][10][3] = {{{1L,(-6L),0L},{1L,(-1L),1L},{6L,1L,0x8F243202L},{1L,0x354FC485L,9L},{6L,6L,0L},{1L,0xD6CAC951L,0xE6FD7D03L},{1L,6L,1L},{1L,0x354FC485L,0xA6AF6142L},{1L,1L,1L},{0xA6AF6142L,(-1L),0xE6FD7D03L}},{{0x88D21B24L,1L,0L},{0xA6AF6142L,0xA2172EBDL,9L},{1L,0x88D21B24L,0x8F243202L},{1L,0xA2172EBDL,1L},{1L,1L,6L},{1L,(-1L),1L},{6L,1L,0x8F243202L},{1L,0x354FC485L,9L},{6L,6L,0L},{1L,0xD6CAC951L,0xE6FD7D03L}},{{1L,6L,1L},{1L,0x354FC485L,0xA6AF6142L},{1L,1L,1L},{0xA6AF6142L,(-1L),0xE6FD7D03L},{0x88D21B24L,1L,0L},{0xA6AF6142L,0xA2172EBDL,9L},{1L,0x88D21B24L,0x8F243202L},{1L,0xA2172EBDL,1L},{1L,1L,6L},{1L,(-1L),1L}},{{6L,1L,0x8F243202L},{1L,0x354FC485L,9L},{6L,6L,0L},{1L,0xD6CAC951L,0xE6FD7D03L},{1L,6L,1L},{1L,0x354FC485L,0xA6AF6142L},{1L,1L,1L},{0xA6AF6142L,(-1L),0xE6FD7D03L},{0x88D21B24L,1L,0L},{0xA6AF6142L,0xA2172EBDL,9L}},{{1L,0x88D21B24L,0x8F243202L},{1L,0xA2172EBDL,1L},{1L,1L,6L},{1L,(-1L),1L},{6L,1L,0x8F243202L},{1L,0x354FC485L,9L},{6L,6L,0L},{1L,0xD6CAC951L,0xE6FD7D03L},{1L,6L,1L},{1L,0x354FC485L,0xA6AF6142L}}};
            int i, j, k;
            (*l_877) = ((*l_876) = l_875);
            l_884++;
        }
    }
    for (g_139 = 0; (g_139 != (-29)); g_139--)
    { /* block id: 389 */
        int32_t **l_889 = &g_73;
        (*l_889) = &l_816[1];
        return l_787;
    }
    return l_890;
}


/* ------------------------------------------ */
/* 
 * reads : g_556
 * writes: g_556
 */
static int8_t  func_16(uint8_t  p_17, int64_t  p_18, int32_t * const  p_19, int16_t  p_20)
{ /* block id: 253 */
    uint8_t l_612 = 3UL;
    uint64_t ***l_640 = &g_633;
    int16_t *l_644 = &g_93;
    int16_t **l_643 = &l_644;
    const uint32_t *l_656 = &g_183.f0;
    const uint32_t **l_655[8][4][2] = {{{(void*)0,&l_656},{&l_656,(void*)0},{&l_656,&l_656},{(void*)0,&l_656}},{{&l_656,&l_656},{(void*)0,&l_656},{&l_656,&l_656},{&l_656,&l_656}},{{&l_656,&l_656},{(void*)0,&l_656},{&l_656,&l_656},{(void*)0,&l_656}},{{&l_656,(void*)0},{&l_656,&l_656},{(void*)0,&l_656},{&l_656,&l_656}},{{(void*)0,&l_656},{&l_656,&l_656},{&l_656,&l_656},{&l_656,&l_656}},{{(void*)0,&l_656},{&l_656,&l_656},{(void*)0,(void*)0},{&l_656,&l_656}},{{&l_656,(void*)0},{(void*)0,&l_656},{(void*)0,(void*)0},{&l_656,&l_656}},{{&l_656,&l_656},{&l_656,&l_656},{&l_656,&l_656},{&l_656,(void*)0}}};
    int32_t l_672 = (-6L);
    int32_t l_674[1][6] = {{0x3BEB0F70L,0xFDC8B9CCL,0xFDC8B9CCL,0x3BEB0F70L,0xFDC8B9CCL,0xFDC8B9CCL}};
    int64_t l_759 = 0x09ABDAAB7056F124LL;
    int32_t l_763 = (-2L);
    int32_t *l_774[6] = {(void*)0,&g_3,&g_3,(void*)0,&g_3,&g_3};
    uint64_t l_775 = 0x1C7CAB9F8A33FF00LL;
    int i, j, k;
    for (g_556 = 1; (g_556 >= 0); g_556 -= 1)
    { /* block id: 256 */
        uint64_t *l_607 = &g_517[4];
        uint32_t *l_615 = (void*)0;
        uint32_t *l_616 = (void*)0;
        uint32_t *l_617 = &g_618;
        uint16_t *l_623 = (void*)0;
        uint16_t *l_624 = &g_6;
        uint16_t *l_625 = &g_96;
        uint32_t *l_627 = &g_100;
        uint32_t **l_626 = &l_627;
        uint8_t *l_628 = &g_567[3][4];
        int32_t *l_636 = &g_139;
        int32_t l_664 = 0L;
        int32_t l_665 = 0x4763C835L;
        int32_t l_671 = 0xA6F34E8AL;
        int32_t l_673 = (-1L);
        int32_t l_675[3][9][7] = {{{0xE3BE37EDL,0x62AA79FEL,6L,6L,0x62AA79FEL,0xE3BE37EDL,0xF3A2DF6FL},{(-5L),(-1L),0x46FA573AL,0x37E1A0D4L,0xD831448AL,0xF366717BL,0x28C5C7BDL},{5L,0x2F5D1299L,0x1D8E352BL,0x758CB12FL,(-5L),(-1L),0xFE555FA0L},{0L,(-1L),0xB7960796L,(-7L),0xB7960796L,(-1L),0L},{4L,0x62AA79FEL,0xFE555FA0L,0xF3A2DF6FL,0x083A75AFL,0x25C6A472L,0xFB597DC9L},{0xAED0E7FAL,(-1L),(-6L),(-1L),0L,0xF366717BL,0x1DC618D6L},{(-1L),0L,0xFE555FA0L,5L,5L,0xFE555FA0L,0L},{7L,(-7L),0xB7960796L,(-8L),0L,(-7L),1L},{0x25C6A472L,(-1L),0x1D8E352BL,0xA029BDC3L,0x25C6A472L,0x62AA79FEL,0xFB597DC9L}},{{(-1L),0xF366717BL,0x46FA573AL,(-8L),0x28C5C7BDL,(-8L),0x46FA573AL},{0x083A75AFL,0xFB597DC9L,6L,5L,0L,(-1L),0xFE555FA0L},{(-6L),(-8L),(-1L),(-1L),0xC4BB0553L,0xCF175268L,0L},{0x25C6A472L,4L,0xA029BDC3L,0xF3A2DF6FL,0L,0L,0xF3A2DF6FL},{0L,(-1L),0L,(-7L),0x28C5C7BDL,0x5D7CD699L,(-1L)},{(-1L),6L,(-1L),0x758CB12FL,0x25C6A472L,6L,0xA029BDC3L},{(-1L),(-8L),(-6L),0x37E1A0D4L,0L,0x5D7CD699L,0L},{4L,0x083A75AFL,0xFB597DC9L,6L,5L,0L,(-1L)},{0x46FA573AL,0xF366717BL,(-1L),0L,0L,0xCF175268L,0xD831448AL}},{{5L,0xA029BDC3L,(-1L),0x62AA79FEL,0x083A75AFL,(-1L),(-1L)},{0xB7960796L,(-7L),7L,(-7L),0xB7960796L,(-8L),0L},{0xE3BE37EDL,0L,0xA029BDC3L,0x46D20084L,(-5L),0x62AA79FEL,0xA029BDC3L},{(-6L),(-1L),0xAED0E7FAL,0L,0xD831448AL,(-7L),(-1L)},{0xE3BE37EDL,0x46D20084L,6L,4L,0x62AA79FEL,0x1D8E352BL,0L},{(-6L),(-1L),0x06509E05L,0xF366717BL,0xB7960796L,0x5D7CD699L,(-8L)},{0x62AA79FEL,(-5L),0x46D20084L,0xA029BDC3L,0L,0xE3BE37EDL,0x1D8E352BL},{0x764571DBL,(-1L),(-1L),(-7L),(-1L),(-1L),0x764571DBL},{0x083A75AFL,6L,0x1D8E352BL,0L,0x758CB12FL,0xFE555FA0L,(-1L)}}};
        int8_t l_677[6];
        struct S0 l_768[9] = {{0xEB4A07ABL},{0xFC044FB4L},{0xFC044FB4L},{0xEB4A07ABL},{0xFC044FB4L},{0xFC044FB4L},{0xEB4A07ABL},{0xFC044FB4L},{0xFC044FB4L}};
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_677[i] = 0xD7L;
    }
    l_775--;
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_575 g_289 g_560
 * writes: g_139
 */
static uint8_t  func_23(int16_t  p_24, uint16_t  p_25, int16_t  p_26, int32_t * p_27)
{ /* block id: 250 */
    int32_t *l_602[2][1];
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_602[i][j] = (void*)0;
    }
    (*g_289) = (l_602[1][0] == (*g_575));
    return g_560[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_6 g_3 g_72 g_86 g_104 g_105 g_133 g_100 g_137 g_103 g_138 g_139 g_73 g_181 g_98 g_183 g_238 g_201 g_96 g_289 g_256 g_311 g_361 g_362 g_93 g_517 g_467 g_537 g_560 g_567 g_570 g_572 g_573 g_575 g_556 g_597
 * writes: g_35 g_72 g_86 g_93 g_96 g_98 g_100 g_103 g_105 g_73 g_133 g_137 g_139 g_181 g_201 g_361 g_238 g_467 g_556 g_560 g_567 g_570 g_289
 */
static int32_t * func_31(uint64_t  p_32, uint16_t  p_33)
{ /* block id: 3 */
    uint32_t l_38 = 0xA5BED857L;
    int64_t *l_581[3][6][6] = {{{(void*)0,(void*)0,(void*)0,(void*)0,&g_238,&g_467},{&g_238,&g_238,&g_238,&g_467,&g_238,(void*)0},{&g_238,&g_238,(void*)0,&g_238,&g_238,&g_467},{(void*)0,&g_238,(void*)0,(void*)0,&g_238,&g_238},{&g_238,(void*)0,&g_238,&g_238,(void*)0,&g_238},{(void*)0,&g_467,(void*)0,&g_238,&g_238,&g_467}},{{(void*)0,(void*)0,(void*)0,&g_238,(void*)0,(void*)0},{(void*)0,&g_467,&g_238,&g_238,(void*)0,&g_467},{(void*)0,&g_238,(void*)0,&g_238,&g_238,(void*)0},{&g_238,&g_238,&g_238,(void*)0,(void*)0,&g_238},{(void*)0,&g_467,&g_238,&g_238,(void*)0,&g_238},{&g_238,(void*)0,&g_238,&g_467,&g_238,&g_238}},{{&g_238,&g_467,&g_238,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,&g_238,&g_467},{&g_238,&g_238,&g_238,&g_467,&g_238,(void*)0},{&g_238,&g_238,(void*)0,&g_238,&g_238,&g_467},{(void*)0,&g_238,(void*)0,(void*)0,&g_238,&g_238},{&g_238,(void*)0,&g_238,&g_238,(void*)0,&g_238}}};
    int32_t l_582 = 9L;
    int32_t l_583 = 0x94421173L;
    uint32_t *l_598 = &g_133;
    uint64_t *l_599[1];
    int32_t *l_600[8][8][1] = {{{&g_105},{&l_582},{&l_583},{&l_583},{&l_582},{&g_105},{(void*)0},{&g_3}},{{&l_582},{(void*)0},{&l_582},{&g_3},{(void*)0},{&g_105},{&l_582},{&l_583}},{{&l_583},{&l_582},{&g_105},{(void*)0},{&g_3},{&l_582},{(void*)0},{&l_582}},{{&g_3},{(void*)0},{&g_105},{&l_582},{&l_583},{&l_583},{&l_582},{&g_105}},{{(void*)0},{&g_3},{&l_582},{(void*)0},{&l_582},{&g_3},{(void*)0},{&g_105}},{{&l_582},{&l_583},{&l_583},{&l_582},{&l_582},{(void*)0},{&l_583},{&g_105}},{{&g_3},{&g_105},{&l_583},{(void*)0},{&l_582},{&g_105},{&l_582},{&l_582}},{{&g_105},{&l_582},{(void*)0},{&l_583},{&g_105},{&g_3},{&g_105},{&l_583}}};
    int32_t l_601 = 0L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_599[i] = (void*)0;
    (*g_104) = ((((l_38 ^ (l_582 = func_39(g_35))) , l_38) != (l_583 = p_32)) , (l_601 = ((g_35 &= (((*l_598) &= (g_556 || (safe_add_func_int32_t_s_s(((*g_289) = (safe_div_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(((safe_add_func_int32_t_s_s(((~((safe_add_func_uint8_t_u_u(((((*g_104) <= ((safe_mul_func_uint16_t_u_u((0xB1L | ((((l_38 | 0xDB4B22A6328E51A6LL) ^ l_583) || 0xAF39L) & g_93)), 0xA849L)) & g_139)) > 4L) > 0x53F4L), g_597)) ^ l_582)) || p_32), g_137)) & 7L), p_33)), l_38))), p_33)))) , p_33)) & g_201)));
    return (*g_573);
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_3 g_35 g_72 g_86 g_104 g_105 g_133 g_100 g_137 g_103 g_138 g_139 g_73 g_181 g_98 g_183 g_238 g_201 g_96 g_289 g_256 g_311 g_361 g_362 g_93 g_517 g_467 g_537 g_560 g_567 g_570 g_572 g_573 g_575
 * writes: g_35 g_72 g_86 g_93 g_96 g_98 g_100 g_103 g_105 g_73 g_133 g_137 g_139 g_181 g_201 g_361 g_238 g_467 g_556 g_560 g_567 g_570 g_289
 */
static int64_t  func_39(uint64_t  p_40)
{ /* block id: 4 */
    const int32_t *l_47 = &g_3;
    int64_t *l_555 = &g_556;
    uint16_t *l_559 = &g_560[0];
    int16_t *l_578 = &g_93;
    uint8_t *l_579[4][7] = {{&g_86[0],&g_103,&g_86[0],&g_86[0],&g_103,&g_86[0],&g_86[0]},{&g_103,&g_103,&g_567[3][4],&g_103,&g_103,&g_567[3][4],&g_103},{&g_103,&g_86[0],&g_86[0],&g_103,&g_86[0],&g_86[0],&g_103},{&g_86[0],&g_103,&g_86[0],&g_86[0],&g_103,&g_86[0],&g_86[0]}};
    uint8_t **l_580 = &l_579[3][6];
    int i, j;
    (*g_575) = func_41(func_45(l_47), (((((((-1L) & (safe_mul_func_uint8_t_u_u((*l_47), (safe_mod_func_int8_t_s_s((p_40 && (safe_add_func_int16_t_s_s((~0x1F6AL), (((*l_555) = p_40) , (*l_47))))), (((safe_mul_func_uint16_t_u_u(((*l_559)--), (safe_mul_func_int8_t_s_s((g_567[3][4] ^= (safe_add_func_uint16_t_u_u((g_256 > 0xAB01L), (*l_47)))), 0x42L)))) || 65535UL) && g_256)))))) , g_3) >= p_40) & g_183.f0) == p_40) , p_40), g_517[1]);
    (*g_289) &= (((*l_578) = (*l_47)) ^ (&g_86[1] == ((*l_580) = l_579[0][0])));
    return (*l_47);
}


/* ------------------------------------------ */
/* 
 * reads : g_467 g_570 g_572 g_573
 * writes: g_139 g_467 g_570 g_289
 */
static int32_t * func_41(uint64_t * p_42, uint8_t  p_43, uint64_t  p_44)
{ /* block id: 228 */
    uint16_t l_568[5][10] = {{65531UL,0xBE67L,65531UL,65531UL,65531UL,65531UL,0xBE67L,65531UL,0xDEF4L,0xBE67L},{65531UL,0UL,0x1DCEL,0xBE67L,0UL,0UL,0xBE67L,0x1DCEL,0UL,65531UL},{0UL,0xBE67L,0x1DCEL,0UL,65531UL,0x1DCEL,0x1DCEL,65531UL,0UL,0x1DCEL},{65531UL,65531UL,65531UL,0xBE67L,65531UL,0xDEF4L,0xBE67L,0xBE67L,0xDEF4L,65531UL},{65531UL,0x1DCEL,0x1DCEL,65531UL,0UL,0x1DCEL,0xBE67L,0UL,0UL,0xBE67L}};
    int32_t *l_569 = &g_139;
    int i, j;
    (*l_569) = (l_568[1][1] > 0xCD2CL);
    for (g_467 = 0; (g_467 <= 0); g_467 += 1)
    { /* block id: 232 */
        (*g_572) = g_570;
        (*g_573) = l_569;
    }
    return l_569;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_3 g_35 g_72 g_86 g_104 g_105 g_133 g_100 g_137 g_103 g_138 g_139 g_73 g_181 g_98 g_183 g_238 g_201 g_96 g_289 g_256 g_311 g_361 g_362 g_93 g_517 g_467 g_537
 * writes: g_35 g_72 g_86 g_93 g_96 g_98 g_100 g_103 g_105 g_73 g_133 g_137 g_139 g_181 g_201 g_361 g_238 g_467
 */
static uint64_t * func_45(const int32_t * p_46)
{ /* block id: 5 */
    uint64_t *l_51[8] = {&g_35,&g_35,&g_35,&g_35,&g_35,&g_35,&g_35,&g_35};
    int32_t *l_59 = &g_3;
    int32_t **l_58 = &l_59;
    const int32_t l_60 = 0x2F34C933L;
    int32_t **l_148 = &g_73;
    int32_t **l_149 = &g_73;
    int32_t **l_150 = &g_73;
    int32_t **l_151[7][6] = {{&g_73,&g_73,&g_73,&g_73,&g_73,&g_73},{&g_73,&g_73,(void*)0,(void*)0,&g_73,&g_73},{(void*)0,&g_73,&g_73,&g_73,&g_73,&g_73},{&g_73,&g_73,&g_73,&g_73,&g_73,&g_73},{&g_73,(void*)0,&g_73,&g_73,&g_73,&g_73},{(void*)0,&g_73,&g_73,(void*)0,&g_73,&g_73},{&g_73,&g_73,&g_73,&g_73,&g_73,&g_73}};
    int32_t *l_152[9] = {&g_105,&g_3,&g_3,&g_105,&g_3,&g_3,&g_105,&g_3,&g_3};
    uint32_t *l_153 = &g_100;
    int8_t *l_483 = &g_181[0][1];
    uint32_t l_488[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    uint8_t *l_489 = &g_98;
    uint16_t l_490 = 0UL;
    struct S0 l_493[4][5][6] = {{{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}}},{{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}}},{{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}}},{{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}},{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}}}};
    uint64_t l_496 = 0UL;
    uint8_t l_514 = 246UL;
    int i, j, k;
    p_46 = func_48(l_51[7], ((*l_153) = (((l_152[4] = ((*l_58) = func_52(&g_3, ((*l_58) = &g_3), (g_6 == 0xD832CB81L), ((l_60 & 0x7672L) , l_60), ((((safe_rshift_func_int8_t_s_s((1UL >= 0xB5C1L), l_60)) || g_3) > g_35) || g_6)))) == (void*)0) , 0xF0331C24L)));
    if ((safe_unary_minus_func_uint32_t_u((((((*l_483) = g_35) | (safe_lshift_func_int8_t_s_u((g_311 ^ ((safe_add_func_int32_t_s_s((**l_58), ((((g_86[1] >= (((*l_489) = (l_488[5] == (-3L))) < l_490)) ^ ((safe_add_func_uint16_t_u_u((((l_51[1] == ((0x45L == 0L) , l_51[7])) , l_493[3][3][2]) , g_3), g_362.f0)) != 6UL)) > g_105) >= g_105))) >= g_35)), g_93))) , (**l_58)) > 0x0DL))))
    { /* block id: 202 */
        uint16_t l_497[3];
        struct S0 l_506 = {0xB8C142B4L};
        int16_t l_512 = 0L;
        int32_t l_513 = 0xCC486F09L;
        int32_t l_515[3][1][1];
        int32_t *l_516 = &g_105;
        uint16_t l_519 = 0UL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_497[i] = 1UL;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 1; k++)
                    l_515[i][j][k] = (-2L);
            }
        }
        l_515[0][0][0] |= ((safe_mod_func_int32_t_s_s((l_497[1] = ((l_496 , p_46) == (void*)0)), (safe_lshift_func_int16_t_s_s(0x18A4L, ((safe_rshift_func_int8_t_s_u((safe_mod_func_uint32_t_u_u(0x98C40F06L, 0xF4D6524EL)), ((((safe_sub_func_int16_t_s_s(((l_506 , ((safe_mul_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u(((((*l_153) = 0x4877CFFDL) , ((safe_mod_func_uint8_t_u_u((l_506 , g_183.f0), l_506.f0)) < l_506.f0)) > l_512))), l_513)) | (-1L))) == l_512), g_181[2][2])) , 0x88FFL) , l_514) ^ l_512))) , (-8L)))))) | l_506.f0);
        l_513 = l_506.f0;
        (*l_150) = func_52((l_516 = ((*l_150) = &l_513)), &l_515[1][0][0], g_517[1], g_467, ((*l_483) &= (safe_unary_minus_func_uint8_t_u(0x03L))));
        l_519++;
    }
    else
    { /* block id: 212 */
        uint64_t l_522[3];
        int i;
        for (i = 0; i < 3; i++)
            l_522[i] = 0x06569B85AA3731C6LL;
        --l_522[2];
    }
    for (g_139 = 0; (g_139 >= 9); g_139 = safe_add_func_int8_t_s_s(g_139, 1))
    { /* block id: 217 */
        uint8_t *l_531 = &l_514;
        int32_t l_536[2];
        int i;
        for (i = 0; i < 2; i++)
            l_536[i] = 0xE82302C5L;
        (*g_104) = ((((safe_lshift_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(((*l_531) = ((*l_489) = 0xE3L)), (l_493[3][3][2] , (((*l_483) = (safe_div_func_int64_t_s_s(l_536[1], g_537))) ^ ((safe_div_func_int64_t_s_s((safe_add_func_int16_t_s_s(g_137, (safe_lshift_func_uint8_t_u_s((((safe_mod_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((((g_86[1] = g_139) , g_467) , l_536[0]), l_536[0])), 255UL)) && g_137) < g_137), 3)))), g_35)) <= 4UL))))), 11)) & l_536[1]) | g_467) && (-1L));
    }
    return &g_517[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_103 g_86 g_3 g_35 g_137 g_181 g_98 g_138 g_183 g_133 g_105 g_139 g_100 g_238 g_201 g_104 g_96 g_72 g_289 g_256 g_311 g_6 g_361 g_362 g_93 g_73
 * writes: g_96 g_86 g_181 g_139 g_201 g_103 g_137 g_93 g_105 g_35 g_73 g_98 g_361 g_133 g_238 g_467
 */
static int32_t * func_48(uint64_t * p_49, uint32_t  p_50)
{ /* block id: 40 */
    uint32_t l_156 = 4294967295UL;
    uint16_t *l_157 = &g_96;
    struct S0 l_162 = {0xC36B5704L};
    uint8_t *l_167 = (void*)0;
    int32_t l_168 = 0x22FE436BL;
    uint8_t *l_169 = (void*)0;
    uint8_t *l_170[5][10][3] = {{{&g_86[1],(void*)0,&g_103},{&g_98,(void*)0,&g_103},{&g_98,&g_103,&g_98},{&g_98,(void*)0,&g_86[1]},{&g_86[1],(void*)0,&g_98},{&g_103,&g_98,&g_86[1]},{&g_98,(void*)0,&g_86[1]},{&g_98,(void*)0,&g_103},{(void*)0,&g_98,&g_98},{(void*)0,&g_98,&g_86[1]}},{{(void*)0,&g_103,&g_98},{(void*)0,&g_86[1],&g_86[0]},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_86[1]},{&g_103,&g_86[0],&g_86[1]},{&g_86[1],&g_86[1],&g_86[1]},{&g_98,&g_98,&g_98},{&g_98,&g_86[1],&g_86[1]},{&g_98,&g_98,&g_86[1]},{&g_86[1],&g_103,&g_86[1]}},{{(void*)0,(void*)0,&g_98},{&g_98,&g_98,&g_86[0]},{&g_86[1],&g_86[0],&g_98},{&g_86[1],&g_86[1],&g_86[1]},{&g_86[0],&g_86[1],&g_98},{&g_86[1],&g_86[0],&g_103},{&g_86[1],&g_98,&g_86[1]},{&g_86[1],(void*)0,&g_86[1]},{&g_103,&g_103,&g_98},{(void*)0,&g_98,&g_86[1]}},{{&g_86[0],&g_86[1],&g_98},{&g_103,&g_98,&g_98},{(void*)0,&g_103,&g_86[1]},{&g_98,&g_86[0],&g_86[1]},{&g_98,&g_86[1],&g_98},{&g_103,&g_98,&g_86[0]},{&g_86[1],&g_98,&g_98},{&g_98,&g_98,&g_86[1]},{&g_103,&g_98,&g_86[1]},{&g_98,&g_86[1],&g_98}},{{&g_86[1],&g_86[1],&g_86[0]},{&g_98,&g_98,&g_98},{&g_86[1],&g_103,&g_86[1]},{&g_103,&g_86[1],&g_86[1]},{&g_103,(void*)0,&g_98},{&g_86[1],&g_103,(void*)0},{(void*)0,(void*)0,&g_98},{&g_86[0],&g_86[1],&g_86[1]},{&g_103,&g_103,&g_103},{&g_86[1],&g_98,&g_86[1]}}};
    int32_t l_171 = (-10L);
    uint16_t l_178[10][9][2] = {{{65535UL,65528UL},{65535UL,65526UL},{0UL,65529UL},{65526UL,65535UL},{65532UL,0x9E39L},{0UL,0x07DEL},{0x07DEL,0x502DL},{65535UL,0xD825L},{65530UL,65535UL}},{{0x502DL,6UL},{0xADE5L,65532UL},{1UL,0UL},{1UL,65530UL},{0x59F5L,65533UL},{65527UL,1UL},{6UL,65526UL},{0xD825L,65526UL},{6UL,1UL}},{{65527UL,65533UL},{0x59F5L,65530UL},{1UL,0UL},{1UL,65532UL},{0xADE5L,6UL},{0x502DL,65535UL},{65530UL,0xD825L},{65535UL,0x502DL},{0x07DEL,0x07DEL}},{{0UL,0x9E39L},{65532UL,65535UL},{65526UL,65529UL},{0UL,65526UL},{65535UL,65528UL},{65535UL,65526UL},{0UL,65529UL},{65526UL,65535UL},{65532UL,0x9E39L}},{{0UL,0x07DEL},{0x07DEL,0x502DL},{65535UL,0xD825L},{65530UL,65535UL},{0x502DL,6UL},{0xADE5L,65532UL},{1UL,0UL},{1UL,65530UL},{0x59F5L,65533UL}},{{65527UL,1UL},{6UL,65526UL},{0xD825L,65526UL},{6UL,1UL},{65527UL,65533UL},{0x59F5L,65530UL},{1UL,0UL},{1UL,65532UL},{0xADE5L,6UL}},{{0x502DL,65535UL},{65530UL,0xD825L},{65535UL,0x502DL},{0x07DEL,0x07DEL},{0UL,0x9E39L},{65532UL,65535UL},{65526UL,65529UL},{0UL,65526UL},{65535UL,65528UL}},{{65535UL,65526UL},{0UL,65529UL},{65526UL,65535UL},{65532UL,0x9E39L},{0UL,0x07DEL},{0x3F03L,65529UL},{0x502DL,0UL},{6UL,65526UL},{65529UL,0xD825L}},{{65527UL,65535UL},{0x848AL,0x59F5L},{65535UL,6UL},{65535UL,0UL},{0UL,65535UL},{0xD825L,65532UL},{0UL,65532UL},{0xD825L,65535UL},{0UL,0UL}},{{65535UL,6UL},{65535UL,0x59F5L},{0x848AL,65535UL},{65527UL,0xD825L},{65529UL,65526UL},{6UL,0UL},{0x502DL,65529UL},{0x3F03L,0x3F03L},{65533UL,0UL}}};
    int8_t *l_179[1][3][2];
    uint32_t l_180 = 0UL;
    int32_t *l_182[3][6][8] = {{{&g_139,(void*)0,&g_139,&g_105,&g_3,&g_139,&g_139,(void*)0},{&g_105,&g_3,&g_105,&g_105,&g_139,(void*)0,&g_3,&g_139},{&g_105,&g_139,(void*)0,(void*)0,&g_3,&g_3,(void*)0,(void*)0},{(void*)0,(void*)0,&g_105,(void*)0,&g_139,&g_105,&g_3,&g_3},{(void*)0,&g_139,&g_3,&g_105,(void*)0,&g_3,&g_139,&g_3},{&g_139,&g_139,&g_139,(void*)0,&g_3,&g_3,&g_3,(void*)0}},{{&g_105,&g_3,(void*)0,(void*)0,&g_105,&g_139,(void*)0,&g_139},{(void*)0,&g_3,&g_3,&g_105,&g_3,(void*)0,&g_3,(void*)0},{&g_139,&g_105,&g_3,&g_105,(void*)0,&g_139,&g_139,&g_139},{(void*)0,&g_3,&g_139,&g_139,(void*)0,&g_3,&g_139,&g_105},{&g_3,&g_139,&g_139,&g_105,&g_3,&g_105,&g_3,&g_139},{(void*)0,(void*)0,&g_139,&g_139,&g_3,&g_139,&g_139,(void*)0}},{{&g_3,&g_139,&g_3,&g_3,&g_139,&g_3,&g_105,(void*)0},{&g_3,&g_139,(void*)0,&g_3,&g_3,&g_3,&g_105,&g_3},{&g_139,&g_3,&g_3,&g_3,&g_105,&g_3,&g_139,&g_139},{&g_105,&g_3,&g_139,&g_139,&g_139,&g_139,&g_3,(void*)0},{&g_3,&g_139,&g_139,&g_3,(void*)0,(void*)0,&g_139,&g_139},{(void*)0,&g_3,&g_139,&g_139,&g_3,&g_3,&g_139,&g_3}}};
    uint16_t l_200 = 0x5A76L;
    uint16_t l_217 = 0x32D3L;
    uint16_t l_325 = 0xFAFCL;
    uint64_t l_418[1];
    int32_t *l_438[8][5] = {{&g_105,&g_3,&g_3,&g_3,&g_3},{&l_168,&l_168,&g_3,&l_168,&l_168},{&g_3,&g_3,&g_3,&g_3,&g_3},{&l_168,&g_105,&g_105,&l_168,&g_105},{&g_3,&g_3,&g_105,&g_3,&g_3},{&g_105,&l_168,&g_105,&g_105,&l_168},{&g_3,&g_3,&g_3,&g_3,&g_3},{&l_168,&l_168,&g_3,&l_168,&l_168}};
    int16_t *l_444[5];
    int16_t **l_443[1][1][10] = {{{&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1],&l_444[1]}}};
    int16_t ***l_442 = &l_443[0][0][3];
    int16_t *** const *l_470 = &l_442;
    int32_t *l_480[8] = {&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3};
    int32_t *l_481 = (void*)0;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 2; k++)
                l_179[i][j][k] = &g_137;
        }
    }
    for (i = 0; i < 1; i++)
        l_418[i] = 1UL;
    for (i = 0; i < 5; i++)
        l_444[i] = (void*)0;
lbl_379:
    (*g_138) = ((g_181[0][1] &= (safe_sub_func_uint16_t_u_u(((*l_157) = l_156), (((l_171 = (7L | (safe_div_func_uint8_t_u_u(((l_156 >= (safe_add_func_uint64_t_u_u(((l_157 != (l_162 , ((l_168 = (((safe_rshift_func_int16_t_s_s(g_103, 2)) > 0x7396L) , ((l_156 , (safe_mod_func_uint16_t_u_u((((--g_86[1]) >= (l_180 = (safe_mod_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((l_167 != (void*)0), 0x0A34L)) >= l_178[7][4][1]), l_178[0][7][1])))) & g_3), l_168))) < 0xB5DF624FECDA2E41LL))) , &l_178[7][2][1]))) , (*p_49)), g_35))) ^ l_156), g_137)))) <= p_50) || 18446744073709551615UL)))) || g_98);
lbl_383:
    l_182[0][4][0] = (g_183 , &l_171);
    for (l_180 = (-6); (l_180 != 33); l_180++)
    { /* block id: 51 */
        int16_t l_197 = 0xFFEAL;
        int32_t l_204[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int32_t ***l_224 = &g_72[3];
        uint8_t *l_236 = &g_103;
        uint32_t *l_247 = &l_156;
        int32_t *l_294 = &g_105;
        int16_t l_295 = 5L;
        int32_t l_312 = 0xD507D950L;
        uint16_t *l_322 = &g_6;
        const int8_t l_350 = 0x27L;
        uint64_t *l_351 = &g_35;
        uint8_t l_430 = 0x43L;
        int32_t *l_435[5][8] = {{&l_204[1],&l_312,&g_105,(void*)0,&l_204[1],&l_204[6],&l_204[0],&l_204[6]},{&l_204[1],&l_312,&l_171,&l_312,&l_204[1],&g_105,&g_3,&l_204[1]},{&g_105,&l_204[1],&l_204[1],&g_139,&g_3,&g_105,&l_312,&l_312},{&l_204[0],&l_168,&l_204[1],&l_204[1],&l_168,&l_204[0],&g_3,&g_3},{&g_3,&l_204[6],&l_171,&l_204[1],&l_312,&g_139,&l_204[0],&g_105}};
        int32_t *l_439 = &g_105;
        int16_t ***l_446[6][2][8] = {{{&l_443[0][0][3],&l_443[0][0][3],&l_443[0][0][0],&l_443[0][0][7],&l_443[0][0][0],&l_443[0][0][3],&l_443[0][0][3],&l_443[0][0][0]},{(void*)0,&l_443[0][0][0],&l_443[0][0][3],(void*)0,&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][3],(void*)0}},{{&l_443[0][0][7],(void*)0,&l_443[0][0][2],&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][2],(void*)0,&l_443[0][0][7]},{(void*)0,&l_443[0][0][7],&l_443[0][0][3],(void*)0,&l_443[0][0][0],(void*)0,&l_443[0][0][3],&l_443[0][0][4]}},{{&l_443[0][0][3],(void*)0,&l_443[0][0][8],(void*)0,(void*)0,(void*)0,&l_443[0][0][8],(void*)0},{&l_443[0][0][0],&l_443[0][0][7],&l_443[0][0][4],&l_443[0][0][5],(void*)0,&l_443[0][0][2],&l_443[0][0][0],&l_443[0][0][8]}},{{(void*)0,(void*)0,&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][0]},{&l_443[0][0][0],&l_443[0][0][0],&l_443[0][0][4],&l_443[0][0][2],(void*)0,&l_443[0][0][3],&l_443[0][0][8],&l_443[0][0][3]}},{{(void*)0,&l_443[0][0][3],&l_443[0][0][8],&l_443[0][0][3],&l_443[0][0][3],&l_443[0][0][0],&l_443[0][0][3],&l_443[0][0][3]},{&l_443[0][0][3],&l_443[0][0][4],&l_443[0][0][3],&l_443[0][0][2],&l_443[0][0][3],(void*)0,(void*)0,&l_443[0][0][0]}},{{&l_443[0][0][5],(void*)0,&l_443[0][0][2],&l_443[0][0][0],&l_443[0][0][8],&l_443[0][0][4],&l_443[0][0][4],&l_443[0][0][0]},{&l_443[0][0][0],&l_443[0][0][8],&l_443[0][0][8],&l_443[0][0][0],&l_443[0][0][4],&l_443[0][0][3],&l_443[0][0][7],(void*)0}}};
        int i, j, k;
        if ((g_133 , (safe_add_func_int8_t_s_s(((safe_rshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u((safe_sub_func_int8_t_s_s(g_105, ((void*)0 == &g_133))), (~(p_50 & (safe_sub_func_int16_t_s_s(l_197, ((l_197 ^ (18446744073709551615UL <= (safe_lshift_func_int8_t_s_u(p_50, g_133)))) , g_86[1]))))))), l_197)) & l_200), g_86[1]))))
        { /* block id: 52 */
            int32_t l_202 = 0x11EB18ADL;
            int32_t l_203 = 0L;
            int32_t l_205 = 0x51C6119FL;
            int32_t l_206 = 0x4598823AL;
            int32_t l_207 = 1L;
            int32_t l_208 = 1L;
            int32_t l_209 = 1L;
            int32_t l_210 = 0xBD2F6D19L;
            int32_t l_211 = 4L;
            int32_t l_212 = 0xC9BFAB43L;
            int32_t l_213 = (-1L);
            int32_t l_214 = (-1L);
            int32_t l_215[2][2][7] = {{{0L,0xB268F716L,0xB268F716L,0L,0L,0xB268F716L,0xB268F716L},{0xF195CB6CL,(-1L),0xF195CB6CL,(-1L),0xF195CB6CL,(-1L),0xF195CB6CL}},{{0L,0L,0xB268F716L,0xB268F716L,0L,0L,0xB268F716L},{0x05E2F4CBL,(-1L),0x05E2F4CBL,(-1L),0x05E2F4CBL,(-1L),0x05E2F4CBL}}};
            int32_t l_216 = 0x6652B50CL;
            int i, j, k;
            g_201 = (g_103 != p_50);
            ++l_217;
        }
        else
        { /* block id: 55 */
            uint64_t l_220 = 0x8940EEDF8BB0FE6DLL;
            int32_t l_283 = 1L;
            uint32_t l_284 = 0x300FD3E3L;
            int32_t l_296 = 2L;
            int32_t l_298[6];
            int i;
            for (i = 0; i < 6; i++)
                l_298[i] = 0x2EAB5B3BL;
            ++l_220;
            for (g_103 = 0; (g_103 <= 2); g_103 += 1)
            { /* block id: 59 */
                int8_t l_246[8] = {2L,2L,2L,2L,2L,2L,2L,2L};
                int32_t l_248[3][7] = {{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)},{0x9EF966E7L,0x9EF966E7L,0x9EF966E7L,0x9EF966E7L,0x9EF966E7L,0x9EF966E7L,0x9EF966E7L},{(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)}};
                int32_t *l_288 = &l_248[1][3];
                int16_t l_297 = 2L;
                int i, j;
                l_204[4] ^= (safe_unary_minus_func_int8_t_s(((void*)0 == l_224)));
                for (l_220 = 0; (l_220 <= 2); l_220 += 1)
                { /* block id: 63 */
                    uint64_t l_239[10] = {1UL,1UL,0x8E2BD8798FFAE7A3LL,1UL,1UL,1UL,1UL,0x8E2BD8798FFAE7A3LL,1UL,1UL};
                    int i;
                    for (l_171 = 2; (l_171 >= 0); l_171 -= 1)
                    { /* block id: 66 */
                        int64_t *l_237[3][3][1] = {{{&g_238},{(void*)0},{&g_238}},{{(void*)0},{&g_238},{(void*)0}},{{&g_238},{(void*)0},{&g_238}}};
                        int32_t ***l_245 = &g_72[0];
                        int16_t *l_253 = &g_93;
                        int i, j, k;
                        l_248[1][3] = ((*g_138) = (((((!0x1ACEE5EC71239F26LL) == (*p_49)) & (((safe_mod_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((safe_div_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u(((void*)0 != &g_93), (l_239[2] = ((void*)0 != l_236)))) <= g_133), ((((!(safe_add_func_uint32_t_u_u((5UL > ((g_137 = ((void*)0 != l_245)) > g_103)), l_246[1]))) == g_139) ^ (*g_138)) , l_246[0]))) != g_133), 0x54L)), p_50)) , l_247) == &l_156)) && g_100) != 0xFCA1375911E98489LL));
                        (*g_104) = ((safe_add_func_int32_t_s_s(0L, (safe_rshift_func_uint8_t_u_u((((*l_253) = g_238) == (p_50 , g_201)), 3)))) >= p_50);
                        if ((*g_104))
                            break;
                    }
                }
                if (p_50)
                    break;
                for (g_93 = 0; (g_93 <= 2); g_93 += 1)
                { /* block id: 79 */
                    int16_t l_259 = (-1L);
                    int8_t l_260 = 1L;
                    int32_t l_286[8] = {0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L,0xDE3DAA31L};
                    int i;
                    for (l_168 = 2; (l_168 >= 0); l_168 -= 1)
                    { /* block id: 82 */
                        const int32_t *l_255 = &g_256;
                        const int32_t **l_254 = &l_255;
                        const int32_t *l_258 = (void*)0;
                        const int32_t **l_257 = &l_258;
                        int i, j, k;
                        (*l_257) = ((*l_254) = (void*)0);
                        if ((*g_138))
                            continue;
                        l_259 ^= p_50;
                        l_260 |= 0x01A16205L;
                    }
                    for (l_260 = 0; (l_260 < 23); l_260 = safe_add_func_uint16_t_u_u(l_260, 7))
                    { /* block id: 91 */
                        int16_t *l_285 = (void*)0;
                        int32_t *l_287 = &l_171;
                        (**l_224) = ((l_248[1][3] | (((safe_div_func_int64_t_s_s(((safe_unary_minus_func_int64_t_s(((safe_mod_func_uint16_t_u_u(((*l_157) = (safe_mod_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u((g_139 ^ (+g_86[1])), g_103)) || (((3UL >= 0L) == (safe_rshift_func_uint16_t_u_u((((*p_49) = ((safe_mod_func_int16_t_s_s((safe_div_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((l_286[6] &= ((g_139 && (((*p_49) & (((l_283 = (safe_div_func_uint8_t_u_u(p_50, p_50))) <= (*g_104)) || l_220)) > l_284)) & 4UL)), p_50)), l_260)), p_50)) ^ p_50)) > g_183.f0), 12))) | p_50)), g_96))), 0xCB23L)) == p_50))) >= p_50), g_86[1])) >= 0xB7L) , l_248[1][3])) , l_287);
                        return g_289;
                    }
                    if ((((safe_mod_func_int16_t_s_s((~((g_256 > p_50) > g_105)), ((*l_157) = 0xE62AL))) || g_137) , 0x3E8F8233L))
                    { /* block id: 100 */
                        int32_t *l_293 = &l_286[6];
                        return l_294;
                    }
                    else
                    { /* block id: 102 */
                        uint64_t l_299 = 0xC6EB257A66F0E9A3LL;
                        if (p_50)
                            break;
                        --l_299;
                    }
                    if (l_260)
                        break;
                }
            }
            l_283 ^= ((safe_mul_func_int16_t_s_s(((g_139 < p_50) || ((((((((l_298[5] = (+l_298[2])) ^ (((safe_mul_func_uint8_t_u_u(((5UL | 6UL) >= 255UL), ((void*)0 == &l_283))) > ((((((safe_div_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((l_162 , g_311), l_312)), 1UL)) > l_284) <= p_50) && 0UL) > l_296) < l_284)) | 0x7D7708A6B27E0EBBLL)) && (*g_104)) , &g_181[2][3]) != l_179[0][1][1]) && 0x67D236D1L) >= (*p_49)) != p_50)), g_103)) & p_50);
            (*l_294) = 0xE16D2C66L;
        }
        if (((safe_mul_func_int16_t_s_s(((+((*l_294) >= (g_96 , (p_50 >= ((p_50 <= (safe_mul_func_int16_t_s_s(((*l_294) >= (((p_50 & ((safe_add_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(p_50, (l_322 != &l_178[7][4][1]))), 65535UL)) == g_201)) && p_50) < p_50)), p_50))) & g_238))))) && p_50), g_6)) & g_181[0][1]))
        { /* block id: 113 */
            int8_t l_323 = (-1L);
            int32_t l_324[5] = {2L,2L,2L,2L,2L};
            int i;
            ++l_325;
        }
        else
        { /* block id: 115 */
            uint32_t l_352 = 9UL;
            int32_t *l_373 = &l_204[6];
            uint8_t *l_374[8][5][6] = {{{&g_86[1],&g_103,&g_98,&g_86[1],&g_86[1],&g_86[1]},{&g_86[0],&g_98,&g_103,(void*)0,&g_98,&g_86[1]},{&g_103,(void*)0,&g_98,&g_98,&g_98,&g_98},{(void*)0,&g_103,&g_98,&g_86[1],&g_98,(void*)0},{&g_103,&g_98,(void*)0,&g_86[1],&g_86[1],&g_98}},{{&g_103,&g_86[1],&g_103,(void*)0,&g_86[1],&g_103},{&g_98,&g_86[1],&g_103,(void*)0,(void*)0,&g_103},{&g_98,&g_98,&g_86[1],&g_98,&g_86[0],(void*)0},{&g_98,&g_86[1],&g_86[0],&g_86[1],&g_98,&g_86[1]},{&g_103,&g_98,&g_86[0],&g_98,&g_98,(void*)0}},{{(void*)0,&g_98,&g_86[1],&g_86[1],&g_86[1],&g_103},{&g_86[1],&g_86[1],&g_103,&g_103,(void*)0,&g_103},{&g_86[0],&g_86[1],&g_103,&g_103,&g_98,&g_98},{&g_98,(void*)0,(void*)0,&g_86[1],&g_98,(void*)0},{&g_86[1],&g_98,&g_98,(void*)0,&g_86[1],&g_98}},{{&g_86[1],(void*)0,&g_86[1],&g_86[1],&g_98,&g_86[1]},{&g_98,&g_86[1],&g_86[1],&g_98,&g_86[0],&g_103},{&g_103,&g_86[0],&g_103,&g_98,&g_86[1],(void*)0},{(void*)0,&g_86[1],&g_98,&g_86[1],&g_86[1],&g_98},{&g_86[1],(void*)0,&g_103,(void*)0,&g_103,(void*)0}},{{&g_86[0],&g_86[1],&g_98,&g_86[1],&g_86[1],&g_86[1]},{&g_86[1],&g_103,&g_98,&g_86[1],&g_86[1],&g_86[1]},{(void*)0,&g_103,&g_98,&g_98,&g_86[1],&g_103},{&g_86[1],&g_86[1],&g_86[1],&g_103,&g_103,(void*)0},{&g_103,(void*)0,&g_103,&g_86[1],&g_86[1],&g_98}},{{(void*)0,&g_86[1],(void*)0,&g_98,&g_86[1],&g_86[0]},{&g_98,&g_86[0],(void*)0,(void*)0,&g_86[0],(void*)0},{&g_86[0],&g_86[1],&g_86[1],&g_98,&g_98,&g_98},{(void*)0,(void*)0,&g_103,&g_86[1],&g_98,&g_86[1]},{(void*)0,&g_103,(void*)0,&g_86[1],&g_98,&g_98}},{{&g_103,(void*)0,(void*)0,&g_98,&g_103,&g_86[1]},{&g_86[1],&g_103,&g_103,(void*)0,&g_86[1],&g_86[1]},{&g_103,(void*)0,&g_98,&g_98,(void*)0,&g_103},{(void*)0,(void*)0,&g_86[1],(void*)0,&g_103,&g_86[1]},{&g_103,&g_86[1],&g_86[1],&g_103,&g_103,&g_86[1]}},{{&g_103,&g_86[1],&g_103,(void*)0,&g_103,&g_86[1]},{(void*)0,&g_103,(void*)0,&g_98,&g_103,&g_98},{&g_103,&g_86[1],&g_86[1],(void*)0,&g_86[0],(void*)0},{&g_86[1],&g_98,&g_103,&g_98,(void*)0,&g_98},{&g_103,&g_86[1],(void*)0,&g_86[1],&g_86[1],&g_103}}};
            int32_t *l_377 = &l_171;
            int32_t l_384 = 0L;
            int32_t l_385 = (-1L);
            int16_t *l_432 = &l_295;
            int16_t **l_431[1];
            int32_t ***l_471[1][5] = {{&g_72[1],&g_72[1],&g_72[1],&g_72[1],&g_72[1]}};
            int64_t *l_478[9] = {(void*)0,&g_467,(void*)0,(void*)0,&g_467,(void*)0,(void*)0,&g_467,(void*)0};
            const int32_t l_479 = 8L;
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_431[i] = &l_432;
            if ((safe_mod_func_int8_t_s_s(g_137, (g_98 ^= ((*l_236)--)))))
            { /* block id: 118 */
                int32_t ***l_353 = (void*)0;
                int32_t *l_375 = &l_204[1];
                uint32_t l_387 = 0x52955BC8L;
                int32_t l_393 = 0xFFF122EDL;
                if ((*g_138))
                { /* block id: 119 */
                    int8_t l_354[6];
                    int32_t *l_378 = &g_139;
                    int i;
                    for (i = 0; i < 6; i++)
                        l_354[i] = 0xB4L;
                    (*l_294) = ((safe_mod_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s((((l_350 , l_351) == (void*)0) > l_352), g_137)) == (l_353 == (void*)0)), (l_352 & 1UL))), 12)), g_133)), l_354[0])) || 0x8FL) , p_50), 246UL)), 2)), p_50)) ^ (*p_49));
                    (*l_294) = (safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(g_96, g_133)), 0xEEL));
                    for (g_96 = (-24); (g_96 == 1); g_96 = safe_add_func_uint32_t_u_u(g_96, 9))
                    { /* block id: 124 */
                        g_361 = &g_183;
                    }
                    if ((&g_86[1] == ((&l_352 == ((safe_rshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u(0x92L, (((*g_361) , 18446744073709551611UL) < (safe_rshift_func_uint16_t_u_s((safe_add_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u(g_3, g_133)), g_3)), 3))))), 12)) , &g_100)) , l_374[6][0][5])))
                    { /* block id: 127 */
                        int32_t *l_376[4] = {&g_139,&g_139,&g_139,&g_139};
                        int i;
                        (**l_224) = l_375;
                        return l_378;
                    }
                    else
                    { /* block id: 130 */
                        if (p_50)
                            break;
                        if (l_180)
                            goto lbl_379;
                    }
                }
                else
                { /* block id: 134 */
                    int32_t *l_380 = &l_204[1];
                    int32_t l_386 = 0x16620879L;
                    int16_t *l_392 = &l_197;
                    l_182[0][4][0] = l_380;
                    for (l_156 = (-4); (l_156 < 33); l_156++)
                    { /* block id: 138 */
                        (*l_377) = p_50;
                        if (g_133)
                            goto lbl_383;
                        --l_387;
                        (**l_224) = &l_386;
                    }
                    if (p_50)
                        break;
                    if (((*l_373) || (safe_mul_func_int16_t_s_s(((*l_392) = ((*l_373) ^ g_96)), (p_49 == &g_238)))))
                    { /* block id: 146 */
                        uint32_t l_394 = 0x930D0B3FL;
                        l_394++;
                        (**l_224) = &l_168;
                        (*l_373) &= (&l_156 == l_375);
                        (*l_294) = (safe_div_func_int8_t_s_s((g_137 = l_394), (++(*l_236))));
                    }
                    else
                    { /* block id: 153 */
                        int8_t l_410 = 0x37L;
                        (*l_294) = (0x72C1985A28A2CF34LL > (((safe_lshift_func_int16_t_s_s(((*l_375) > g_133), (p_50 & 6L))) != (-6L)) > (safe_lshift_func_int8_t_s_u(((1L && (safe_mul_func_int8_t_s_s(p_50, (~((safe_mul_func_uint8_t_u_u(((g_362.f0 != g_201) , p_50), g_183.f0)) , 0x7BEB07EF6A7FF8C5LL))))) ^ l_410), 4))));
                    }
                }
                for (l_387 = 0; (l_387 >= 43); l_387 = safe_add_func_int64_t_s_s(l_387, 4))
                { /* block id: 159 */
                    uint8_t l_415 = 246UL;
                    for (g_93 = 20; (g_93 != 21); g_93 = safe_add_func_int8_t_s_s(g_93, 1))
                    { /* block id: 162 */
                        ++l_415;
                    }
                }
                (**l_224) = &l_384;
                l_418[0]--;
            }
            else
            { /* block id: 168 */
                int16_t *l_429[9][3] = {{&l_197,&l_295,(void*)0},{&l_295,&l_295,(void*)0},{&l_295,&l_197,(void*)0},{&l_197,&l_295,(void*)0},{&l_295,&l_295,(void*)0},{&l_295,&l_197,(void*)0},{&l_197,&l_295,(void*)0},{&l_295,&l_295,&l_295},{&l_197,&g_93,&l_295}};
                int32_t *l_437 = &l_204[1];
                int16_t ****l_445[3];
                struct S0 l_451 = {0x413A9A04L};
                int64_t *l_465 = &g_238;
                int64_t *l_466[7][1][6] = {{{&g_467,&g_467,(void*)0,&g_467,&g_467,(void*)0}},{{&g_467,&g_467,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_467,&g_467,(void*)0}},{{&g_467,&g_467,(void*)0,&g_467,&g_467,(void*)0}},{{&g_467,&g_467,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_467,&g_467,(void*)0}},{{&g_467,&g_467,(void*)0,&g_467,&g_467,(void*)0}}};
                int32_t l_468 = 0L;
                int32_t ****l_472 = &l_471[0][2];
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_445[i] = &l_442;
                if ((safe_add_func_int32_t_s_s((((((*l_373) = p_50) && ((safe_lshift_func_uint16_t_u_u((p_50 <= (safe_lshift_func_uint16_t_u_s(g_181[0][3], (g_93 |= (safe_sub_func_int8_t_s_s((*l_373), 1L)))))), (g_86[1] | (l_162 , p_50)))) != (l_430 , 7UL))) > g_103) || g_133), (*l_294))))
                { /* block id: 171 */
                    int16_t ***l_434 = &l_431[0];
                    int32_t *l_436 = &l_204[1];
                    (*l_434) = l_431[0];
                    return l_439;
                }
                else
                { /* block id: 174 */
                    for (g_133 = (-15); (g_133 <= 44); g_133++)
                    { /* block id: 177 */
                        if (l_197)
                            goto lbl_379;
                    }
                }
                if (p_50)
                    continue;
                (**l_224) = &l_168;
                (***l_224) ^= (safe_div_func_int8_t_s_s(((*l_373) ^= g_362.f0), (safe_lshift_func_int8_t_s_u((((+((*p_49) && (l_468 = ((*l_465) = p_50)))) , 0x4E7ED143L) , (safe_unary_minus_func_uint16_t_u(p_50))), (((((void*)0 != l_470) , ((((*l_472) = l_471[0][2]) == &g_72[1]) , (-5L))) & 1L) , 0x6EL)))));
            }
            (*l_373) &= (((safe_add_func_uint8_t_u_u((((***l_224) = (g_238 && 0x7FA4L)) != ((((-1L) < (g_467 = ((safe_add_func_uint8_t_u_u((*l_294), p_50)) && (+g_98)))) != (((*l_294) , (g_362.f0 == l_479)) , p_50)) || p_50)), p_50)) || p_50) | p_50);
        }
        (*g_138) ^= (*l_439);
    }
    return l_481;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_72 g_86 g_104 g_105 g_3 g_133 g_6 g_100 g_137 g_103 g_138 g_139 g_73
 * writes: g_35 g_72 g_86 g_93 g_96 g_98 g_100 g_103 g_105 g_73 g_133 g_137 g_139
 */
static int32_t * func_52(int32_t * p_53, int32_t * p_54, uint64_t  p_55, uint64_t  p_56, int8_t  p_57)
{ /* block id: 7 */
    int32_t l_91 = 0xB84C81E2L;
    int32_t l_94 = 0xCC22523FL;
    uint8_t *l_136 = &g_86[0];
    uint32_t *l_142 = &g_133;
    int64_t l_147[4];
    int i;
    for (i = 0; i < 4; i++)
        l_147[i] = 0x9D4D995C899AE76DLL;
    for (g_35 = (-16); (g_35 == 1); g_35 = safe_add_func_uint32_t_u_u(g_35, 9))
    { /* block id: 10 */
        int8_t l_65[10] = {0x67L,0x67L,0x79L,0x67L,0x67L,0x79L,0x67L,0x67L,0x79L,0x67L};
        uint64_t *l_87 = &g_35;
        uint64_t *l_90[4] = {&g_35,&g_35,&g_35,&g_35};
        int32_t l_95 = 0x0C48983CL;
        int i;
        for (p_56 = 0; (p_56 <= 9); p_56 += 1)
        { /* block id: 13 */
            int32_t ***l_74 = (void*)0;
            int32_t ***l_75 = &g_72[1];
            uint8_t *l_84 = (void*)0;
            uint8_t *l_85 = &g_86[1];
            uint64_t **l_88 = (void*)0;
            uint64_t **l_89 = &l_87;
            int16_t *l_92 = &g_93;
            uint8_t *l_97 = &g_98;
            uint32_t *l_99 = &g_100;
            uint8_t *l_101 = (void*)0;
            uint8_t *l_102 = &g_103;
            uint32_t *l_132 = &g_133;
            (*g_104) |= (1UL != (((safe_rshift_func_int16_t_s_u(l_65[7], (safe_mul_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_s((((*l_75) = g_72[3]) != &g_73), (((l_65[4] >= ((((*l_102) = (((((*l_99) = (safe_lshift_func_int8_t_s_s((safe_div_func_uint32_t_u_u(((((*l_97) = (g_96 = (l_95 ^= ((l_94 = ((*l_92) = (safe_div_func_int8_t_s_s((((*l_85) = 0UL) , (g_35 & (((*l_89) = l_87) == l_90[0]))), l_91)))) ^ 0x0F8CL)))) , &g_73) != (void*)0), p_55)), l_65[0]))) , l_95) > 0x11C0E03A8461A3ECLL) <= p_57)) >= 9L) != p_55)) <= p_57) && 0xF9B05D12CBED49F2LL))) <= p_57) , g_86[0]), 0xDF8BL)))) , 0UL) <= 0x63326EEDADEE2DE5LL));
            (**l_75) = &l_94;
            (*g_138) ^= ((safe_mul_func_uint16_t_u_u(((0xDDC7CBFABE471A24LL < ((safe_div_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_lshift_func_int16_t_s_u((((safe_add_func_uint8_t_u_u(((g_137 &= (safe_mul_func_int16_t_s_s((((((((**l_75) = &l_94) != &l_94) ^ (((((safe_div_func_int64_t_s_s((((g_3 , (safe_div_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((((safe_rshift_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(l_91, (p_57 && ((((*l_132) &= p_56) && (*p_54)) && (safe_mul_func_int8_t_s_s(((p_56 && g_6) != 0xD04770596CDBACE3LL), l_91)))))) , l_95), 15)) | (-1L)) , l_94), (*p_54))), g_35))) && 0x67ACL) & g_100), g_86[1])) <= p_55) == 1L) , (void*)0) != l_136)) , 0x16L) , 0xC4L) >= l_94), p_56))) > l_95), 0xBBL)) >= 18446744073709551615UL) | l_94), l_95)), g_103)), l_91)), p_56)) <= g_105)) == 0x35L), p_56)) , l_91);
        }
        if ((*g_73))
            continue;
    }
    (*g_104) = ((safe_div_func_uint32_t_u_u((++(*l_142)), (safe_rshift_func_int16_t_s_u((p_56 >= l_147[0]), 15)))) <= p_56);
    (*g_104) = 0xB5F6EBE0L;
    return p_54;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_86[i], "g_86[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_181[i][j], "g_181[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_183.f0, "g_183.f0", print_hash_value);
    transparent_crc(g_201, "g_201", print_hash_value);
    transparent_crc(g_238, "g_238", print_hash_value);
    transparent_crc(g_256, "g_256", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    transparent_crc(g_362.f0, "g_362.f0", print_hash_value);
    transparent_crc(g_467, "g_467", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_517[i], "g_517[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_537, "g_537", print_hash_value);
    transparent_crc(g_556, "g_556", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_560[i], "g_560[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_567[i][j], "g_567[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_597, "g_597", print_hash_value);
    transparent_crc(g_618, "g_618", print_hash_value);
    transparent_crc(g_637, "g_637", print_hash_value);
    transparent_crc(g_666, "g_666", print_hash_value);
    transparent_crc(g_756, "g_756", print_hash_value);
    transparent_crc(g_883, "g_883", print_hash_value);
    transparent_crc(g_892, "g_892", print_hash_value);
    transparent_crc(g_909, "g_909", print_hash_value);
    transparent_crc(g_962, "g_962", print_hash_value);
    transparent_crc(g_1030, "g_1030", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 272
   depth: 1, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 44
breakdown:
   depth: 1, occurrence: 138
   depth: 2, occurrence: 32
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 2
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 18, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 23, occurrence: 3
   depth: 24, occurrence: 1
   depth: 25, occurrence: 3
   depth: 27, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1
   depth: 44, occurrence: 1

XXX total number of pointers: 247

XXX times a variable address is taken: 670
XXX times a pointer is dereferenced on RHS: 128
breakdown:
   depth: 1, occurrence: 95
   depth: 2, occurrence: 27
   depth: 3, occurrence: 6
XXX times a pointer is dereferenced on LHS: 173
breakdown:
   depth: 1, occurrence: 144
   depth: 2, occurrence: 20
   depth: 3, occurrence: 9
XXX times a pointer is compared with null: 27
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 4
XXX times a pointer is qualified to be dereferenced: 4634

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 639
   level: 2, occurrence: 124
   level: 3, occurrence: 64
   level: 4, occurrence: 7
XXX number of pointers point to pointers: 80
XXX number of pointers point to scalars: 166
XXX number of pointers point to structs: 1
XXX percent of pointers has null in alias set: 25.9
XXX average alias set size: 1.49

XXX times a non-volatile is read: 867
XXX times a non-volatile is write: 477
XXX times a volatile is read: 38
XXX    times read thru a pointer: 8
XXX times a volatile is write: 37
XXX    times written thru a pointer: 19
XXX times a volatile is available for access: 711
XXX percentage of non-volatile access: 94.7

XXX forward jumps: 0
XXX backward jumps: 3

XXX stmts: 133
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 23
   depth: 2, occurrence: 19
   depth: 3, occurrence: 12
   depth: 4, occurrence: 17
   depth: 5, occurrence: 28

XXX percentage a fresh-made variable is used: 13.8
XXX percentage an existing variable is used: 86.2
********************* end of statistics **********************/

