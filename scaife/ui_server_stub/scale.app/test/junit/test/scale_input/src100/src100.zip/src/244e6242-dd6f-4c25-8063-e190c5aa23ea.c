/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3103363446
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   volatile signed f0 : 9;
   int32_t  f1;
   uint32_t  f2;
   volatile int32_t  f3;
   volatile uint8_t  f4;
   int64_t  f5;
};
#pragma pack(pop)

/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_26 = 65535UL;/* VOLATILE GLOBAL g_26 */
static uint8_t g_33[6][8] = {{0x40L,0UL,0xD5L,0xD5L,0UL,0x40L,0UL,0xD5L},{0xFEL,0UL,0xFEL,0x40L,0x40L,0xFEL,0UL,0xFEL},{0x5DL,0x40L,0xD5L,0x40L,0x5DL,0x5DL,0x40L,0xD5L},{0x5DL,0x5DL,0x40L,0xD5L,0x40L,0x5DL,0x5DL,0x40L},{0xFEL,0x40L,0x40L,0xFEL,0UL,0xFEL,0x40L,0x40L},{0x40L,0UL,0xD5L,0xD5L,0UL,0x40L,0x5DL,0UL}};
static int32_t g_41 = 0xC38DB075L;
static int32_t g_54 = 1L;
static uint32_t g_57 = 6UL;
static int32_t g_96 = 0xB0A97542L;
static uint32_t g_98 = 0xF1A95A07L;
static int32_t g_114 = 0x783C2309L;
static uint16_t g_117 = 0UL;
static uint8_t g_134 = 1UL;
static uint32_t g_160 = 0UL;
static uint32_t *g_165 = (void*)0;
static uint64_t g_195 = 18446744073709551615UL;
static int8_t g_198[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static const uint32_t *g_204[7][2] = {{(void*)0,&g_160},{(void*)0,&g_160},{(void*)0,&g_160},{(void*)0,&g_160},{(void*)0,&g_160},{(void*)0,&g_160},{(void*)0,&g_160}};
static const uint32_t **g_203 = &g_204[2][0];
static uint16_t g_233 = 0x985DL;
static int32_t *g_238[6][2] = {{&g_54,&g_54},{&g_54,&g_54},{&g_54,(void*)0},{&g_54,(void*)0},{&g_54,&g_54},{&g_54,&g_54}};
static uint16_t g_259[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
static int16_t g_305[1] = {0x3C68L};
static int16_t g_308 = 0xE66CL;
static int16_t *g_307 = &g_308;
static int64_t g_325 = 0xE402519024F5588DLL;
static const int16_t g_388[6] = {0x6CD3L,0x6CD3L,0x6CD3L,0x6CD3L,0x6CD3L,0x6CD3L};
static uint32_t **g_397[2][7][1] = {{{(void*)0},{(void*)0},{&g_165},{(void*)0},{(void*)0},{&g_165},{(void*)0}},{{(void*)0},{&g_165},{(void*)0},{(void*)0},{&g_165},{(void*)0},{(void*)0}}};
static uint32_t ***g_396[7][3][7] = {{{&g_397[1][3][0],&g_397[1][2][0],&g_397[1][1][0],&g_397[1][2][0],(void*)0,(void*)0,&g_397[1][2][0]},{&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][1][0],(void*)0,&g_397[1][2][0],(void*)0},{&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][0][0],&g_397[0][4][0]}},{{&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][6][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0]},{&g_397[1][2][0],&g_397[1][2][0],&g_397[1][4][0],&g_397[1][2][0],&g_397[1][4][0],(void*)0,&g_397[1][2][0]},{&g_397[1][2][0],(void*)0,&g_397[1][2][0],&g_397[1][0][0],&g_397[0][5][0],&g_397[1][2][0],&g_397[1][2][0]}},{{(void*)0,&g_397[1][2][0],&g_397[1][2][0],&g_397[0][1][0],&g_397[1][1][0],(void*)0,&g_397[1][4][0]},{&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][1][0],&g_397[0][5][0],(void*)0},{&g_397[1][2][0],&g_397[1][0][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[0][5][0],&g_397[1][2][0],&g_397[1][2][0]}},{{&g_397[1][2][0],&g_397[1][6][0],&g_397[1][2][0],&g_397[1][4][0],&g_397[1][4][0],&g_397[1][2][0],&g_397[1][6][0]},{&g_397[1][1][0],(void*)0,&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][1][0],&g_397[1][2][0]},{(void*)0,&g_397[1][2][0],&g_397[1][2][0],&g_397[0][5][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][4][0]}},{{(void*)0,&g_397[1][2][0],(void*)0,&g_397[1][2][0],(void*)0,&g_397[1][1][0],&g_397[1][2][0]},{&g_397[1][2][0],&g_397[1][4][0],&g_397[1][2][0],&g_397[1][4][0],(void*)0,&g_397[1][2][0],(void*)0},{(void*)0,(void*)0,&g_397[1][2][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[1][0][0],(void*)0}},{{&g_397[1][2][0],(void*)0,(void*)0,&g_397[1][2][0],&g_397[1][2][0],(void*)0,(void*)0},{&g_397[1][2][0],&g_397[1][2][0],(void*)0,&g_397[0][1][0],&g_397[1][2][0],&g_397[1][2][0],&g_397[0][4][0]},{&g_397[1][2][0],&g_397[0][4][0],&g_397[1][2][0],&g_397[1][0][0],&g_397[1][1][0],&g_397[1][2][0],&g_397[1][2][0]}},{{&g_397[1][2][0],&g_397[1][4][0],&g_397[1][2][0],&g_397[1][4][0],(void*)0,&g_397[1][2][0],&g_397[1][3][0]},{&g_397[1][2][0],&g_397[0][1][0],&g_397[1][1][0],&g_397[1][2][0],(void*)0,(void*)0,&g_397[1][2][0]},{(void*)0,&g_397[1][2][0],(void*)0,(void*)0,&g_397[1][2][0],&g_397[1][1][0],&g_397[1][2][0]}}};
static int8_t g_411[9][7][4] = {{{1L,(-1L),0xF2L,1L},{0x28L,0L,0x82L,0L},{0L,0xE4L,0L,0L},{(-1L),(-9L),0x14L,2L},{0x89L,0L,0L,0x14L},{0x50L,0xC8L,0xA5L,0x87L},{0L,0xE4L,4L,2L}},{{(-10L),(-1L),1L,9L},{(-1L),0xE4L,9L,0xD7L},{4L,0x1CL,0xC8L,1L},{0xB3L,0L,0xB5L,(-9L)},{(-6L),(-3L),0x58L,0L},{(-2L),(-1L),2L,0x8FL},{0x89L,(-1L),8L,0x28L}},{{0x98L,0x65L,1L,(-1L)},{0x0AL,1L,0L,0x23L},{1L,(-1L),8L,0x50L},{0xB6L,1L,4L,0x14L},{(-2L),0x87L,1L,0x96L},{1L,0x7AL,0xB5L,(-2L)},{(-10L),0xE8L,(-10L),0L}},{{4L,(-6L),0x6DL,0x6DL},{0x1CL,0x1CL,1L,0x28L},{0xC5L,9L,(-2L),0x33L},{0L,0xB6L,0x58L,(-2L)},{(-2L),0xB6L,0L,0x33L},{0xB6L,9L,0xF2L,0x28L},{(-1L),0x1CL,0xE4L,0x6DL}},{{0xECL,(-6L),0x82L,0L},{1L,0xE8L,(-10L),(-2L)},{1L,0x7AL,2L,0x96L},{0x50L,0x87L,(-4L),0x14L},{(-1L),1L,(-2L),0x50L},{0xC8L,(-1L),(-10L),0x23L},{0L,1L,0x76L,(-1L)}},{{(-1L),0x65L,0xC8L,0x28L},{0xC8L,(-1L),0x65L,0x8FL},{1L,(-1L),(-4L),0L},{(-2L),(-3L),(-2L),(-9L)},{1L,0L,0x14L,1L},{0x98L,0x1CL,0x82L,0xD7L},{9L,0xE4L,1L,9L}},{{(-1L),(-1L),(-10L),2L},{1L,0xF2L,(-1L),1L},{9L,6L,0xC4L,(-3L)},{0x0CL,(-10L),1L,0x37L},{4L,0x9DL,0x89L,(-2L)},{0x96L,0xB4L,0x83L,1L},{0x0CL,0x96L,0x15L,(-1L)}},{{(-2L),0L,0x87L,1L},{0x0AL,(-1L),0L,(-10L)},{9L,0x7CL,9L,0x14L},{1L,0xE4L,0xCCL,0x3CL},{0xE8L,1L,0xB4L,0xE4L},{0L,0x0AL,0xB4L,0x09L},{0xE8L,0x9DL,0xCCL,0x6DL}},{{1L,8L,9L,0L},{9L,0L,0L,0x15L},{0x0AL,(-10L),0x87L,9L},{(-2L),0x6AL,0x15L,4L},{0x0CL,0xABL,0x83L,(-1L)},{0x96L,0xC8L,0x89L,0x3CL},{4L,0x82L,1L,1L}}};
static int8_t g_493[5][7] = {{0x45L,1L,4L,1L,4L,1L,0x45L},{3L,0xD9L,1L,0xF2L,1L,(-1L),0x45L},{1L,0x45L,0x7FL,0x7FL,0x45L,1L,3L},{1L,0x7FL,1L,3L,0xDBL,1L,1L},{0xF2L,0xDBL,4L,0xDBL,0xF2L,(-1L),1L}};
static int32_t *g_525 = &g_114;
static struct S0 g_534 = {-7,0x59A7E1DFL,6UL,-1L,0x3AL,0xAAC76E4D17AA2CE7LL};/* VOLATILE GLOBAL g_534 */
static int32_t g_642 = (-10L);
static uint32_t g_660 = 18446744073709551607UL;
static int64_t *g_666[1][6] = {{&g_534.f5,&g_534.f5,&g_534.f5,&g_534.f5,&g_534.f5,&g_534.f5}};
static int64_t **g_665 = &g_666[0][3];
static uint8_t g_765 = 0UL;
static uint64_t *g_833[1][6][7] = {{{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195},{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195},{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195},{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195},{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195},{&g_195,&g_195,&g_195,&g_195,&g_195,&g_195,&g_195}}};
static uint64_t **g_832 = &g_833[0][3][5];
static const struct S0 g_837 = {-10,0x60B08FE5L,0x49A7B920L,0xA39A81E1L,0x98L,0xD738D4D86F9D1742LL};/* VOLATILE GLOBAL g_837 */
static int16_t **g_846 = &g_307;
static int16_t ** const *g_845[4][1][5] = {{{(void*)0,(void*)0,(void*)0,&g_846,&g_846}},{{(void*)0,&g_846,&g_846,(void*)0,(void*)0}},{{(void*)0,&g_846,&g_846,&g_846,&g_846}},{{(void*)0,&g_846,&g_846,(void*)0,(void*)0}}};
static int16_t ***g_850 = &g_846;
static const uint8_t g_942 = 1UL;
static struct S0 g_965[2] = {{20,-1L,0x142C345CL,0x5448E243L,0xF9L,-1L},{20,-1L,0x142C345CL,0x5448E243L,0xF9L,-1L}};
static uint8_t *g_1112 = &g_134;
static uint8_t * const *g_1111 = &g_1112;
static int8_t *g_1132 = &g_411[3][5][1];
static struct S0 g_1160 = {7,-8L,2UL,0x62910DFCL,0x4FL,0L};/* VOLATILE GLOBAL g_1160 */
static int64_t g_1231 = 0x78880E80FBB04ECDLL;
static volatile uint16_t g_1302 = 0x098DL;/* VOLATILE GLOBAL g_1302 */
static volatile uint16_t g_1303 = 1UL;/* VOLATILE GLOBAL g_1303 */
static volatile uint16_t g_1304 = 0x3610L;/* VOLATILE GLOBAL g_1304 */
static volatile uint16_t g_1305 = 0x31B6L;/* VOLATILE GLOBAL g_1305 */
static volatile uint16_t g_1306 = 65527UL;/* VOLATILE GLOBAL g_1306 */
static volatile uint16_t g_1307 = 3UL;/* VOLATILE GLOBAL g_1307 */
static volatile uint16_t g_1308 = 65528UL;/* VOLATILE GLOBAL g_1308 */
static volatile uint16_t g_1309 = 65535UL;/* VOLATILE GLOBAL g_1309 */
static volatile uint16_t g_1310 = 0UL;/* VOLATILE GLOBAL g_1310 */
static volatile uint16_t g_1311 = 0x7770L;/* VOLATILE GLOBAL g_1311 */
static volatile uint16_t g_1312 = 0x3521L;/* VOLATILE GLOBAL g_1312 */
static volatile uint16_t g_1313 = 0x85BEL;/* VOLATILE GLOBAL g_1313 */
static volatile uint16_t g_1314 = 65535UL;/* VOLATILE GLOBAL g_1314 */
static volatile uint16_t g_1315 = 0x8F03L;/* VOLATILE GLOBAL g_1315 */
static volatile uint16_t g_1316 = 0xB9F3L;/* VOLATILE GLOBAL g_1316 */
static volatile uint16_t g_1317 = 65535UL;/* VOLATILE GLOBAL g_1317 */
static volatile uint16_t g_1318[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static volatile uint16_t g_1319 = 0UL;/* VOLATILE GLOBAL g_1319 */
static volatile uint16_t g_1320[7][9][3] = {{{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL}},{{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L}},{{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL}},{{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL}},{{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL}},{{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L}},{{65535UL,0UL,0x98FCL},{0x70C2L,1UL,0x3F9DL},{65535UL,0x9CDAL,0x9CDAL},{0x830FL,1UL,0x4FD0L},{0xD6A4L,0UL,0x9CDAL},{0x70C2L,0x9080L,0x3F9DL},{0xD6A4L,0x9CDAL,0x98FCL},{0x830FL,0x9080L,0x4FD0L},{65535UL,0UL,0x98FCL}}};
static volatile uint16_t g_1321 = 0x4092L;/* VOLATILE GLOBAL g_1321 */
static volatile uint16_t g_1322 = 0x8547L;/* VOLATILE GLOBAL g_1322 */
static volatile uint16_t g_1323 = 0x8061L;/* VOLATILE GLOBAL g_1323 */
static volatile uint16_t g_1324 = 65530UL;/* VOLATILE GLOBAL g_1324 */
static volatile uint16_t g_1325[7] = {0x9017L,1UL,1UL,0x9017L,1UL,1UL,0x9017L};
static volatile uint16_t g_1326 = 65535UL;/* VOLATILE GLOBAL g_1326 */
static volatile uint16_t g_1327 = 6UL;/* VOLATILE GLOBAL g_1327 */
static volatile uint16_t g_1328 = 0UL;/* VOLATILE GLOBAL g_1328 */
static volatile uint16_t g_1329 = 0x1839L;/* VOLATILE GLOBAL g_1329 */
static volatile uint16_t g_1330 = 65535UL;/* VOLATILE GLOBAL g_1330 */
static volatile uint16_t g_1331 = 0x9EC2L;/* VOLATILE GLOBAL g_1331 */
static volatile uint16_t g_1332 = 0x3ED2L;/* VOLATILE GLOBAL g_1332 */
static volatile uint16_t g_1333[8][5] = {{0x9DEDL,0x2118L,0x9DEDL,0x9DEDL,0x2118L},{1UL,65535UL,0x3456L,65532UL,0x3456L},{0x2118L,0x2118L,5UL,0x2118L,0x2118L},{0x3456L,65532UL,0x3456L,65535UL,1UL},{0x2118L,0x9DEDL,0x9DEDL,0x2118L,0x9DEDL},{1UL,65532UL,65535UL,65532UL,1UL},{0x9DEDL,0x2118L,0x9DEDL,0x9DEDL,0x2118L},{1UL,65535UL,0x3456L,65532UL,0x3456L}};
static volatile uint16_t g_1334 = 65535UL;/* VOLATILE GLOBAL g_1334 */
static volatile uint16_t *g_1301[8][3][9] = {{{&g_1313,&g_1313,&g_1331,&g_1333[7][3],&g_1318[3],(void*)0,&g_1309,&g_1313,(void*)0},{&g_1311,&g_1307,&g_1319,&g_1315,(void*)0,&g_1329,&g_1311,&g_1311,&g_1329},{&g_1333[7][3],&g_1322,&g_1331,&g_1322,&g_1333[7][3],&g_1326,&g_1304,&g_1333[7][3],(void*)0}},{{&g_1311,(void*)0,&g_1334,(void*)0,&g_1325[5],&g_1314,(void*)0,&g_1311,&g_1319},{&g_1313,&g_1328,&g_1326,&g_1309,&g_1309,&g_1326,&g_1328,&g_1313,&g_1316},{&g_1307,&g_1315,(void*)0,(void*)0,&g_1315,&g_1329,&g_1325[5],&g_1307,&g_1305}},{{&g_1322,&g_1328,&g_1316,&g_1322,&g_1313,(void*)0,&g_1313,&g_1322,&g_1316},{(void*)0,(void*)0,&g_1314,&g_1315,&g_1302,&g_1305,&g_1325[5],(void*)0,&g_1319},{&g_1328,&g_1322,(void*)0,&g_1333[7][3],&g_1313,(void*)0,&g_1328,&g_1328,(void*)0}},{{&g_1315,&g_1307,&g_1314,&g_1307,&g_1315,(void*)0,(void*)0,&g_1315,&g_1329},{&g_1328,&g_1313,&g_1316,&g_1304,&g_1309,&g_1331,&g_1304,&g_1328,(void*)0},{(void*)0,&g_1311,(void*)0,&g_1325[5],&g_1325[5],(void*)0,&g_1311,(void*)0,&g_1334}},{{&g_1322,&g_1333[7][3],&g_1326,&g_1304,&g_1333[7][3],(void*)0,&g_1309,&g_1322,(void*)0},{&g_1307,&g_1311,&g_1334,&g_1307,(void*)0,&g_1305,(void*)0,&g_1307,&g_1334},{&g_1313,&g_1313,&g_1331,&g_1333[7][3],&g_1318[3],(void*)0,&g_1309,&g_1313,(void*)0}},{{&g_1311,&g_1307,&g_1319,&g_1315,(void*)0,&g_1329,&g_1311,&g_1311,&g_1329},{(void*)0,&g_1306,&g_1313,&g_1306,(void*)0,&g_1309,&g_1320[0][8][1],(void*)0,&g_1328},{&g_1327,&g_1312,&g_1315,&g_1303,&g_1308,(void*)0,&g_1303,&g_1327,&g_1302}},{{&g_1330,&g_1310,&g_1309,&g_1324,&g_1324,&g_1309,&g_1310,&g_1330,&g_1333[7][3]},{&g_1321,&g_1332,&g_1325[5],&g_1303,&g_1332,&g_1311,&g_1308,&g_1321,(void*)0},{&g_1306,&g_1310,&g_1333[7][3],&g_1306,&g_1330,&g_1304,&g_1330,&g_1306,&g_1333[7][3]}},{{&g_1312,&g_1312,(void*)0,&g_1332,&g_1317,(void*)0,&g_1308,&g_1312,&g_1302},{&g_1310,&g_1306,&g_1318[3],(void*)0,&g_1330,&g_1328,&g_1310,&g_1310,&g_1328},{&g_1332,&g_1321,(void*)0,&g_1321,&g_1332,&g_1325[5],&g_1303,&g_1332,&g_1311}}};
static volatile uint16_t * volatile *g_1300 = &g_1301[1][0][3];
static uint16_t g_1361 = 8UL;
static struct S0 g_1390[9] = {{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-15,-1L,0x862C9BD7L,2L,0xC8L,1L},{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-15,-1L,0x862C9BD7L,2L,0xC8L,1L},{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-17,0L,0xF2FFA4DAL,0L,0x2BL,0xB313C4526EA1CB43LL},{-15,-1L,0x862C9BD7L,2L,0xC8L,1L}};
static struct S0 *g_1389 = &g_1390[5];
static int16_t g_1406 = 0x6392L;
static uint32_t g_1418 = 0x1F6B749AL;
static struct S0 g_1422 = {4,-9L,0xF8BF1853L,0x182CCE38L,0xF7L,-2L};/* VOLATILE GLOBAL g_1422 */
static struct S0 g_1424 = {1,0x9AEC4BD4L,0x248A0A71L,0xF1C59771L,1UL,2L};/* VOLATILE GLOBAL g_1424 */
static int32_t *g_1459 = &g_114;
static uint8_t g_1465 = 0x01L;
static uint32_t *g_1516 = &g_965[0].f2;
static uint32_t **g_1515 = &g_1516;
static const uint32_t ***g_1527 = (void*)0;
static const uint32_t ****g_1526 = &g_1527;
static const uint32_t *****g_1525 = &g_1526;
static uint32_t ****g_1532 = &g_396[0][0][4];
static uint32_t *****g_1531[1] = {&g_1532};
static int8_t g_1584 = 0xD7L;
static volatile struct S0 g_1609 = {-8,5L,0x3D1BF8FBL,9L,5UL,0xB3CCB37688F67CCALL};/* VOLATILE GLOBAL g_1609 */
static uint64_t g_1617[5] = {6UL,6UL,6UL,6UL,6UL};
static uint64_t g_1622[7] = {0UL,0UL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL};
static int32_t ** volatile g_1639 = &g_238[2][1];/* VOLATILE GLOBAL g_1639 */
static int32_t ** volatile g_1662 = (void*)0;/* VOLATILE GLOBAL g_1662 */
static int32_t ** const  volatile g_1663 = &g_238[1][1];/* VOLATILE GLOBAL g_1663 */
static volatile struct S0 g_1700 = {7,-7L,0x22A7453FL,2L,255UL,0x7A2BDD244ADBB753LL};/* VOLATILE GLOBAL g_1700 */
static const int32_t * volatile g_1779 = &g_96;/* VOLATILE GLOBAL g_1779 */
static const int32_t * volatile * volatile g_1778 = &g_1779;/* VOLATILE GLOBAL g_1778 */
static const int32_t * volatile * volatile *g_1777 = &g_1778;
static const struct S0 g_1780 = {9,0xD6C2B625L,5UL,0xE191B4E7L,5UL,0x24E020AD4B8468C3LL};/* VOLATILE GLOBAL g_1780 */
static int32_t ** volatile g_1782 = &g_238[4][1];/* VOLATILE GLOBAL g_1782 */
static int32_t ** const  volatile g_1785 = &g_238[2][1];/* VOLATILE GLOBAL g_1785 */
static uint8_t **g_1826 = &g_1112;
static uint8_t **g_1827 = &g_1112;
static int32_t * volatile g_1831 = &g_54;/* VOLATILE GLOBAL g_1831 */
static volatile struct S0 *g_1911[1] = {&g_1609};
static volatile struct S0 ** const g_1910 = &g_1911[0];
static volatile uint32_t g_1958[6] = {1UL,18446744073709551614UL,1UL,1UL,18446744073709551614UL,1UL};
static const struct S0 g_1973 = {14,0x619922C0L,0x1EBD92B4L,0L,0x7BL,6L};/* VOLATILE GLOBAL g_1973 */
static int32_t ** volatile g_1974 = (void*)0;/* VOLATILE GLOBAL g_1974 */
static const struct S0 g_1976 = {8,1L,18446744073709551615UL,0x82BEFDE7L,0xCCL,0xB198C38F3EE79716LL};/* VOLATILE GLOBAL g_1976 */
static int32_t **g_2009[10][10][2] = {{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}},{{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459},{&g_1459,&g_1459}}};
static int32_t ***g_2008 = &g_2009[4][8][1];
static struct S0 g_2137 = {-21,0x81E47C3BL,0xB054D5AEL,1L,0x29L,0x2F2095BB4BA9301DLL};/* VOLATILE GLOBAL g_2137 */
static uint32_t g_2150 = 0UL;
static volatile struct S0 g_2166 = {-8,1L,0xD4B502B8L,-4L,253UL,0L};/* VOLATILE GLOBAL g_2166 */
static uint32_t ******g_2196 = &g_1531[0];
static int16_t g_2216 = 1L;
static volatile struct S0 g_2243 = {12,-9L,0xEFE1C965L,-1L,0x1BL,0x070C43D71BEEEF6BLL};/* VOLATILE GLOBAL g_2243 */
static int32_t g_2259[8] = {0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L,0x3AE02CE9L};
static int8_t g_2380 = 1L;
static struct S0 g_2382 = {13,9L,9UL,-2L,0x4AL,0xE19E9892A02D06E4LL};/* VOLATILE GLOBAL g_2382 */
static volatile struct S0 g_2400[6] = {{-15,-1L,0UL,9L,0xF0L,1L},{-15,-1L,0UL,9L,0xF0L,1L},{-15,-1L,0UL,9L,0xF0L,1L},{-15,-1L,0UL,9L,0xF0L,1L},{-15,-1L,0UL,9L,0xF0L,1L},{-15,-1L,0UL,9L,0xF0L,1L}};
static volatile uint32_t * volatile * volatile *g_2402 = (void*)0;
static volatile uint32_t * volatile * volatile * volatile * volatile g_2401 = &g_2402;/* VOLATILE GLOBAL g_2401 */
static uint8_t g_2460 = 0xF9L;
static uint64_t *g_2540 = (void*)0;
static volatile int64_t g_2638[7] = {0L,0L,0L,0L,0L,0L,0L};
static int32_t **g_2650 = &g_238[4][0];
static int32_t *** volatile g_2649 = &g_2650;/* VOLATILE GLOBAL g_2649 */
static uint8_t g_2685[4] = {255UL,255UL,255UL,255UL};
static int32_t g_2732 = 1L;
static volatile uint16_t g_2742 = 0UL;/* VOLATILE GLOBAL g_2742 */
static uint32_t *g_2752 = (void*)0;
static uint32_t ** const g_2751 = &g_2752;
static uint32_t ** const *g_2750 = &g_2751;
static struct S0 g_2799 = {-1,0x7F2AF577L,0UL,0x3B5ACFBAL,0xE8L,6L};/* VOLATILE GLOBAL g_2799 */
static struct S0 g_2804 = {2,0x4AD4DC78L,18446744073709551615UL,1L,0x8BL,0xFE84E1DFFD33DCD6LL};/* VOLATILE GLOBAL g_2804 */
static const uint32_t *g_2825 = &g_1973.f2;
static const uint32_t **g_2824[9][8] = {{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825},{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825},{&g_2825,&g_2825,(void*)0,&g_2825,&g_2825,(void*)0,&g_2825,&g_2825},{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825},{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825},{&g_2825,&g_2825,(void*)0,&g_2825,&g_2825,(void*)0,&g_2825,&g_2825},{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825},{&g_2825,(void*)0,(void*)0,&g_2825,(void*)0,(void*)0,&g_2825,(void*)0},{&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825,&g_2825}};
static const uint32_t ***g_2823 = &g_2824[2][0];
static volatile struct S0 g_2838 = {-15,-1L,0x69016A66L,-4L,0x8CL,0x991EF035144CBC0ELL};/* VOLATILE GLOBAL g_2838 */
static volatile uint32_t g_2861 = 1UL;/* VOLATILE GLOBAL g_2861 */
static const struct S0 g_2880 = {8,9L,0x7570FE7DL,-1L,255UL,1L};/* VOLATILE GLOBAL g_2880 */
static int32_t g_2930 = 5L;
static int32_t g_2937 = (-4L);
static uint16_t *g_2961 = &g_259[5];
static uint16_t **g_2960[2] = {&g_2961,&g_2961};
static int32_t g_2990 = 7L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t * func_3(int32_t * p_4, int32_t * p_5, const int32_t * p_6, uint8_t  p_7);
static int32_t * func_8(int32_t * p_9, uint8_t  p_10);
static int32_t * func_11(uint64_t  p_12);
static const struct S0  func_13(int64_t  p_14, int32_t * p_15, uint16_t  p_16, int32_t * p_17);
static int64_t  func_18(const int8_t  p_19, uint32_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t * p_23);
static uint16_t  func_34(int32_t * const  p_35, uint32_t  p_36, int8_t  p_37, int32_t * p_38, const uint64_t  p_39);
static uint32_t  func_42(uint32_t  p_43, int8_t  p_44, int32_t * p_45, const int32_t * p_46, int32_t * p_47);
static uint16_t  func_49(uint32_t  p_50);
static uint16_t  func_62(int16_t  p_63, int32_t  p_64, uint32_t * p_65, int8_t  p_66, uint32_t  p_67);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_26 g_33 g_41 g_57 g_54 g_98 g_134 g_114 g_160 g_96 g_198 g_117 g_203 g_195 g_204 g_259 g_307 g_305 g_308 g_325 g_765 g_837.f2 g_534.f1 g_665 g_666 g_534.f5 g_846 g_493 g_965.f1 g_832 g_833 g_642 g_965.f5 g_388 g_850 g_1111 g_1112 g_1132 g_411 g_1160.f1 g_1418 g_1515 g_1516 g_965.f2 g_1609 g_1617 g_1622 g_1639 g_1300 g_1301 g_1525 g_1526 g_1663 g_1389 g_1390 g_660 g_1700 g_1459 g_1361 g_1958 g_1422.f1 g_1826 g_1424.f1 g_1827 g_1831 g_2137 g_2150 g_1910 g_1911 g_2166 g_2216 g_1160.f2 g_2460 g_1584 g_2196 g_1531 g_1532 g_1465 g_2382.f2 g_2259 g_2382.f1 g_2742 g_396 g_2804 g_2649 g_2650 g_2961 g_2750 g_2751
 * writes: g_54 g_57 g_98 g_114 g_117 g_134 g_160 g_165 g_195 g_198 g_233 g_238 g_259 g_305 g_307 g_325 g_308 g_765 g_642 g_204 g_534.f1 g_534.f5 g_1111 g_1132 g_411 g_846 g_525 g_41 g_965.f2 g_1617 g_1622 g_1160.f2 g_1424.f5 g_1418 g_1465 g_33 g_660 g_1361 g_1422.f1 g_666 g_2008 g_1424.f1 g_1329 g_1527 g_2137.f1 g_1390 g_2196 g_1422.f2 g_2150 g_1160.f1 g_965.f1 g_1584 g_2460 g_2382.f2 g_2540 g_2382.f1 g_1389 g_2732 g_2685 g_2750 g_2752 g_2804.f1 g_2216
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2[8][10][3] = {{{0xE7L,1L,(-1L)},{0xD3L,0L,0xC3L},{0x54L,0xBAL,(-1L)},{(-2L),0L,5L},{(-9L),1L,0L},{0x6BL,0x9CL,0xA7L},{(-2L),0xC3L,(-1L)},{(-8L),6L,0x78L},{(-1L),0x32L,0x3DL},{0xE7L,0x32L,5L}},{{0x38L,6L,(-9L)},{0x59L,0xC3L,0x14L},{4L,0x9CL,(-1L)},{(-8L),1L,0L},{(-1L),0L,0x14L},{0x56L,0xBAL,(-2L)},{0x8CL,0L,0xBAL},{0x6BL,1L,0x3DL},{(-1L),0x9CL,0L},{0x8CL,0xC3L,1L}},{{0x54L,6L,0xA7L},{1L,0x32L,0x68L},{(-8L),0x32L,0xBAL},{0x76L,6L,(-1L)},{0x3FL,0xC3L,(-9L)},{0x38L,0x9CL,0L},{0x93L,1L,(-10L)},{1L,0L,(-9L)},{(-8L),0xBAL,(-9L)},{0x72L,0L,0x2DL}},{{(-1L),1L,0x68L},{(-9L),0x9CL,0x78L},{0x72L,0xC3L,(-1L)},{0x56L,6L,0L},{0xD3L,0x32L,0L},{0x93L,0x32L,0x2DL},{4L,6L,(-2L)},{0x49L,0xC3L,0xC3L},{0x76L,0x9CL,(-10L)},{0xE7L,1L,(-1L)}},{{0xD3L,0L,0xC3L},{0x54L,0xBAL,(-1L)},{(-2L),0L,5L},{(-9L),1L,0L},{0x6BL,0x9CL,0xA7L},{(-2L),0xC3L,(-1L)},{(-8L),6L,0x78L},{(-1L),0x32L,0x3DL},{0xE7L,0x32L,5L},{0x38L,6L,(-9L)}},{{0x59L,0xC3L,0x14L},{4L,0x9CL,(-1L)},{(-8L),1L,0L},{(-1L),0L,0x14L},{0x56L,0xBAL,(-2L)},{0x8CL,0L,0xBAL},{0x6BL,1L,0x3DL},{(-1L),0x37L,0x35L},{0xBAL,1L,1L},{(-1L),0xC0L,0xD6L}},{{(-2L),(-7L),(-7L)},{0x78L,(-7L),1L},{6L,0xC0L,0x19L},{(-10L),1L,0x13L},{(-9L),0x37L,0x2FL},{0L,1L,(-1L)},{(-2L),0x2FL,0x13L},{1L,1L,0L},{5L,0x2FL,(-9L)},{7L,1L,(-7L)}},{{0x2EL,0x37L,0x30L},{5L,1L,1L},{(-1L),0xC0L,0x35L},{0x32L,(-7L),0xB6L},{0L,(-7L),(-9L)},{0xFBL,0xC0L,0x1AL},{0L,1L,1L},{6L,0x37L,(-1L)},{0xA7L,1L,0x9FL},{0x32L,0x2FL,1L}}};
    int32_t * const l_40 = &g_41;
    int16_t l_48[8][10][3] = {{{(-1L),0x5E8EL,0x23A2L},{0L,0x37B1L,0L},{(-1L),0x879CL,0xF6F7L},{(-10L),(-10L),2L},{1L,0xF6F7L,(-1L)},{(-10L),(-8L),0L},{(-4L),0L,1L},{1L,(-10L),0L},{(-1L),(-1L),(-1L)},{1L,(-8L),2L}},{{0x37B1L,0x2B50L,0xF6F7L},{0x414EL,1L,0L},{0x0280L,0xBFE1L,0x23A2L},{2L,0x8E49L,0x879CL},{1L,(-1L),0xE40DL},{0xAA4BL,0x6051L,0x22F7L},{1L,0L,0x7DFFL},{1L,(-1L),1L},{0xAA4BL,2L,(-1L)},{1L,1L,0x6F84L}},{{2L,0xFF79L,1L},{0x0280L,0x5992L,(-4L)},{0x414EL,0x1C74L,0x1C74L},{0x37B1L,1L,1L},{1L,1L,0x5992L},{(-1L),0xE40DL,0x6051L},{1L,(-1L),(-10L)},{(-4L),0xE40DL,1L},{(-10L),1L,0xECB5L},{1L,1L,(-8L)}},{{(-10L),0x1C74L,0L},{(-1L),0x5992L,1L},{0L,0xFF79L,0x414EL},{(-1L),1L,9L},{1L,2L,0x0280L},{8L,(-1L),(-6L)},{0xBFE1L,0L,(-6L)},{(-1L),0x6051L,0x0280L},{(-10L),(-1L),9L},{0x5E8EL,0x8E49L,0x414EL}},{{(-10L),0xBFE1L,0x879CL},{9L,0x6051L,1L},{0xECB5L,1L,0xECB5L},{0xE40DL,0xECB5L,(-1L)},{1L,0x3506L,0x13D7L},{1L,0L,0L},{0x8E49L,0xE40DL,9L},{1L,(-10L),0x33A5L},{1L,(-1L),1L},{0xE40DL,0xF6F7L,5L}},{{0xECB5L,(-1L),1L},{9L,1L,(-1L)},{(-8L),0L,3L},{0L,0x37B1L,0xFF79L},{0L,1L,0x0280L},{(-10L),(-1L),0x8E49L},{0xDA2DL,(-1L),0x23A2L},{0xAA4BL,1L,1L},{0x22F7L,0x37B1L,(-1L)},{0x3506L,0L,0L}},{{(-6L),1L,0x37B1L},{8L,(-1L),(-1L)},{0xF6F7L,0xF6F7L,0xBFE1L},{0x879CL,(-1L),(-10L)},{0L,(-10L),(-6L)},{1L,0xE40DL,1L},{0x13D7L,0L,(-6L)},{0x2B50L,0x3506L,(-10L)},{1L,0xECB5L,0xBFE1L},{1L,1L,(-1L)}},{{0x7DFFL,0x6051L,0x37B1L},{0x5E8EL,0xDA2DL,0L},{0xBFE1L,(-1L),(-1L)},{0x0280L,8L,1L},{1L,9L,0x23A2L},{(-10L),1L,0x8E49L},{(-10L),0xFF79L,0x0280L},{1L,0xBFE1L,0xFF79L},{0x0280L,1L,3L},{0xBFE1L,8L,(-1L)}}};
    int32_t *l_53 = &g_54;
    uint16_t l_55 = 0xD54FL;
    uint32_t *l_56 = &g_57;
    uint32_t l_1204[1];
    int32_t **l_1205 = &l_53;
    int32_t *l_1206 = &g_1160.f1;
    uint16_t *l_1597 = &g_117;
    int64_t l_1598[5];
    int32_t *l_1749 = &g_1422.f1;
    uint64_t l_2190[10][1][9] = {{{0xE9290C33F6E182C2LL,8UL,0x0AC04964A796C2BDLL,18446744073709551608UL,0x0AC04964A796C2BDLL,8UL,0xE9290C33F6E182C2LL,0x3CA57AB0056FF5D9LL,8UL}},{{0xFF3A179528426E3DLL,0xB271CD3BAAFAC800LL,0x01C4FEF083A2ACB5LL,0x463F883CDFFAEF7FLL,0UL,0xCBB01D6D5307476DLL,0xBDC53853FFC6B342LL,0UL,0xB271CD3BAAFAC800LL}},{{0xE9290C33F6E182C2LL,0x0AC04964A796C2BDLL,0x3CA57AB0056FF5D9LL,0x96FC6144927E531CLL,0xB9E9FDBCB32F92E8LL,0xB9E9FDBCB32F92E8LL,0x96FC6144927E531CLL,0x3CA57AB0056FF5D9LL,0x0AC04964A796C2BDLL}},{{18446744073709551606UL,0xFF32140F2EF08826LL,0xCBB01D6D5307476DLL,0UL,0x01C4FEF083A2ACB5LL,0xCBB01D6D5307476DLL,0xCB2D42C6F2A109CALL,0xC8B96EADECEB3674LL,0xFF32140F2EF08826LL}},{{1UL,1UL,9UL,0x96FC6144927E531CLL,1UL,8UL,0UL,8UL,1UL}},{{0x463F883CDFFAEF7FLL,0xFF32140F2EF08826LL,0xFF32140F2EF08826LL,0x463F883CDFFAEF7FLL,0xC8B96EADECEB3674LL,0UL,18446744073709551606UL,0xB271CD3BAAFAC800LL,0xFF32140F2EF08826LL}},{{0xF6BC4B9AF4104674LL,0x0AC04964A796C2BDLL,0xB9E9FDBCB32F92E8LL,18446744073709551608UL,18446744073709551615UL,1UL,0UL,0x0AC04964A796C2BDLL,0x0AC04964A796C2BDLL}},{{0xCB2D42C6F2A109CALL,0xB271CD3BAAFAC800LL,0xC8B96EADECEB3674LL,0xFF3A179528426E3DLL,0xC8B96EADECEB3674LL,0xB271CD3BAAFAC800LL,0xCB2D42C6F2A109CALL,0xFF32140F2EF08826LL,0xB271CD3BAAFAC800LL}},{{18446744073709551608UL,1UL,6UL,0x3CA57AB0056FF5D9LL,0xADB38F34A4E74DD1LL,0xDBD7DB346B708DADLL,0xB9E9FDBCB32F92E8LL,0xADB38F34A4E74DD1LL,1UL}},{{0UL,0x9DBB2FAE316DF838LL,0xFA40C47958C2288FLL,0x01C4FEF083A2ACB5LL,18446744073709551615UL,18446744073709551615UL,0x01C4FEF083A2ACB5LL,0xFA40C47958C2288FLL,0x9DBB2FAE316DF838LL}}};
    int8_t l_2231[7] = {0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL,0x8AL};
    int32_t l_2241 = 0xDDD7AF38L;
    struct S0 ** const l_2251 = &g_1389;
    int32_t l_2258 = 0L;
    uint32_t ****l_2261[10] = {&g_396[0][0][4],&g_396[2][0][5],&g_396[0][0][4],&g_396[0][0][4],&g_396[2][0][5],&g_396[0][0][4],&g_396[0][0][4],&g_396[2][0][5],&g_396[0][0][4],&g_396[0][0][4]};
    int8_t **l_2271 = &g_1132;
    uint32_t l_2338 = 0UL;
    uint64_t l_2356 = 6UL;
    const uint32_t *l_2376 = &g_660;
    const uint32_t **l_2375 = &l_2376;
    const uint32_t ***l_2374 = &l_2375;
    const int16_t *l_2406 = &g_388[2];
    const int16_t **l_2405 = &l_2406;
    const int8_t l_2419 = 0x36L;
    uint16_t *l_2426[8][2][3] = {{{&g_259[5],&g_1361,&g_233},{&g_117,&g_117,&g_117}},{{&g_117,&g_117,&g_1361},{&g_259[5],&g_259[3],(void*)0}},{{&g_1361,(void*)0,&g_259[5]},{&g_259[5],&g_259[5],(void*)0}},{{&g_1361,&g_259[0],&g_1361},{&g_117,&g_259[5],&g_117}},{{&g_259[5],&g_259[5],&g_233},{&g_233,&g_259[0],(void*)0}},{{&g_259[5],&g_259[5],&g_117},{&g_1361,(void*)0,&g_259[5]}},{{&g_259[5],&g_259[3],&g_1361},{&g_233,&g_117,&g_117}},{{&g_259[5],&g_117,&g_117},{&g_117,&g_1361,&g_1361}}};
    int32_t *l_2442 = &g_1422.f1;
    uint32_t l_2451 = 6UL;
    int32_t ***l_2494 = &g_2009[4][8][1];
    int32_t l_2541 = (-6L);
    int32_t l_2543 = (-7L);
    int16_t **l_2556 = &g_307;
    uint16_t l_2606 = 0x57E5L;
    int32_t l_2634 = 0xCCCC4B02L;
    const uint32_t **l_2692 = (void*)0;
    uint32_t *******l_2697 = &g_2196;
    uint32_t l_2717 = 0x6EEAA0BBL;
    uint64_t l_2754 = 18446744073709551615UL;
    uint64_t *l_2860 = &l_2356;
    int32_t l_2939 = 5L;
    int32_t l_2944 = 0xC205E852L;
    uint16_t l_2953[5][3][3] = {{{65535UL,65535UL,0xD6ADL},{65528UL,65528UL,4UL},{65535UL,65535UL,0xD6ADL}},{{65528UL,65528UL,4UL},{65535UL,65535UL,0xD6ADL},{65528UL,65528UL,4UL}},{{65535UL,65535UL,0xD6ADL},{65528UL,65528UL,4UL},{65535UL,65535UL,0xD6ADL}},{{65528UL,65528UL,4UL},{65535UL,65535UL,0xD6ADL},{65528UL,65528UL,4UL}},{{65535UL,65535UL,0xD6ADL},{65528UL,65528UL,4UL},{65535UL,65535UL,0xD6ADL}}};
    const uint8_t l_2974[5][3] = {{0x83L,0x20L,0x83L},{0x83L,6UL,0x20L},{6UL,0x83L,0x83L},{0x20L,0x83L,1UL},{0x08L,6UL,0UL}};
    int32_t l_2991 = 0xE1F281B2L;
    int8_t l_3075[10] = {0x9EL,0x7CL,0x9EL,0x7CL,0x9EL,0x7CL,0x9EL,0x7CL,0x9EL,0x7CL};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1204[i] = 0xDD0CAC5BL;
    for (i = 0; i < 5; i++)
        l_1598[i] = 0L;
    (*l_1205) = (l_2[3][4][1] , func_3(func_8(func_11(((*l_40) = (func_13(func_18((safe_rshift_func_int16_t_s_s((-4L), (g_26 != (((*l_1597) = (safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_s(((((safe_add_func_uint8_t_u_u(g_33[5][7], (func_34(l_40, ((*l_56) = func_42((((*l_1205) = ((l_48[1][5][2] <= (((*l_40) == func_49(((*l_56) &= ((safe_mul_func_int16_t_s_s((*l_40), ((((*l_53) = g_33[2][7]) || l_55) != (*l_40)))) >= 18446744073709551607UL)))) < l_1204[0])) , &g_41)) == l_1206), g_388[0], &g_41, &g_41, &g_41)), (*l_1206), &g_41, (*l_40)) != 0x6C6FL))) && (*l_53)) == (*l_1206)) , (**g_846)), 15)), g_1418))) , 0x5CB1L)))), (**g_1515), g_33[3][7], l_1598[2], g_1516), g_1459, (*l_1206), l_1749) , (*l_40)))), l_2190[1][0][3]), g_1516, l_1206, g_2216));
lbl_2756:
    for (g_1422.f2 = 7; (g_1422.f2 < 30); ++g_1422.f2)
    { /* block id: 1032 */
        int8_t l_2219 = 0L;
        uint16_t *l_2224 = &l_55;
        uint32_t l_2229 = 8UL;
        uint8_t l_2233 = 252UL;
        int32_t *l_2236 = &g_1424.f1;
        uint32_t l_2242 = 0x00733AB7L;
        int64_t *l_2277 = &g_965[0].f5;
        uint8_t l_2282 = 0UL;
        int32_t l_2289 = 0x10EF53E6L;
        for (g_2137.f1 = 0; (g_2137.f1 <= 2); g_2137.f1 += 1)
        { /* block id: 1035 */
            uint16_t *l_2222 = (void*)0;
            uint16_t **l_2223 = &l_1597;
            int32_t l_2230 = 0L;
            int64_t l_2245 = (-1L);
            l_2219 |= (*l_1206);
            (*l_40) = ((safe_rshift_func_int8_t_s_s(((((*l_2223) = ((*l_53) , l_2222)) != l_2224) ^ ((safe_sub_func_int16_t_s_s((((((l_2230 &= ((safe_rshift_func_int16_t_s_s(((***g_850) = (*l_53)), l_2229)) , 0xDF5DB9CAL)) <= 5L) , ((0x0685L < (-8L)) != 4294967295UL)) ^ 0x1893L) && l_2231[3]), (*l_1206))) && 0x1B9C869EL)), 4)) == 0x8A688B9EL);
            for (g_2150 = 0; (g_2150 <= 2); g_2150 += 1)
            { /* block id: 1043 */
                int32_t *l_2232 = &g_965[0].f1;
                int32_t *l_2244[8][9] = {{&g_1422.f1,&g_965[0].f1,&l_2230,&l_2230,&g_965[0].f1,&g_1422.f1,&g_1422.f1,&g_1422.f1,&g_965[0].f1},{&l_2230,&g_54,&g_54,&l_2230,(void*)0,(void*)0,(void*)0,&l_2230,&g_54},{&l_2230,&l_2230,&g_1422.f1,&g_965[0].f1,&g_2137.f1,&g_965[0].f1,&g_1422.f1,&l_2230,&l_2230},{&g_54,&l_2230,(void*)0,(void*)0,(void*)0,&l_2230,&g_54,&g_54,&l_2230},{&g_965[0].f1,&g_1422.f1,&g_1422.f1,&g_41,&l_2230,&g_1422.f1,&g_1422.f1,&l_2230,&g_41},{(void*)0,&l_2241,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_2241},{&g_2137.f1,&g_965[0].f1,&g_1422.f1,&l_2230,&l_2230,&g_1422.f1,&g_965[0].f1,&g_2137.f1,&g_965[0].f1},{&g_54,(void*)0,(void*)0,(void*)0,(void*)0,&g_54,(void*)0,&g_54,(void*)0}};
                int i, j, k;
                l_2233++;
                (*l_1205) = l_2232;
                if ((*l_2236))
                    continue;
            }
        }
        for (g_308 = 1; (g_308 >= 6); ++g_308)
        { /* block id: 1055 */
            int32_t *l_2248 = &g_2137.f1;
            struct S0 **l_2252 = &g_1389;
            uint32_t ***l_2257 = &g_1515;
            int64_t *l_2260[3];
            int8_t **l_2270 = (void*)0;
            int32_t l_2361 = (-4L);
            int32_t l_2362[7];
            uint64_t l_2371 = 0xF41B4F0FEAB4A1B1LL;
            int16_t l_2381 = 0xB062L;
            int16_t l_2399 = (-1L);
            int i;
            for (i = 0; i < 3; i++)
                l_2260[i] = &g_1424.f5;
            for (i = 0; i < 7; i++)
                l_2362[i] = 0x18FCBDBCL;
            for (g_41 = 0; (g_41 <= 0); g_41 += 1)
            { /* block id: 1058 */
                (*l_1205) = l_2248;
                if ((*l_2236))
                    break;
            }
            (*l_1206) = (safe_lshift_func_uint8_t_u_s(((**g_1910) , (*g_1112)), 2));
        }
        for (l_2233 = 0; (l_2233 > 45); l_2233++)
        { /* block id: 1129 */
            (*g_1389) = (*g_1389);
            if ((*l_2236))
                break;
        }
    }
    if ((safe_rshift_func_uint16_t_u_u((g_117 = 0x6D00L), 5)))
    { /* block id: 1135 */
        int64_t l_2431 = 0xDD045B7375129211LL;
        int32_t *l_2439 = &g_41;
        int32_t l_2454 = 0x64F8C480L;
        uint64_t l_2513 = 18446744073709551615UL;
        int16_t **l_2558 = &g_307;
        uint64_t l_2586 = 7UL;
        int32_t l_2657 = 8L;
        int32_t l_2658 = 0xBEB99C01L;
        int32_t l_2659 = 0x4F5258DDL;
        int32_t l_2660 = 0xC537F45EL;
        int64_t l_2674 = 0L;
        uint32_t **l_2694[10] = {&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56,&l_56};
        int8_t l_2715 = 0x5AL;
        int32_t ****l_2737 = &l_2494;
        int i;
        (*l_1205) = (*l_1205);
        (*l_1749) = (l_2431 |= (safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_s((((*g_1132) <= 0xFAL) & (*l_1749)), 7)), 4)));
        for (l_2338 = 0; (l_2338 == 34); l_2338++)
        { /* block id: 1141 */
            const uint16_t l_2436 = 0x85D2L;
            for (g_1160.f2 = (-28); (g_1160.f2 != 18); g_1160.f2++)
            { /* block id: 1144 */
                return (*l_40);
            }
            if (l_2436)
                continue;
        }
        if (((*l_53) = 0x643251BAL))
        { /* block id: 1150 */
            int8_t l_2445 = 1L;
            uint64_t l_2450 = 18446744073709551615UL;
            for (g_660 = 0; (g_660 == 20); ++g_660)
            { /* block id: 1153 */
                (*l_1205) = l_2439;
                (*l_2439) = (safe_rshift_func_int16_t_s_s((l_2442 == (void*)0), (((**g_832) = (safe_mul_func_int8_t_s_s((l_2445 = ((void*)0 == (**l_2374))), (safe_rshift_func_uint16_t_u_s((safe_mod_func_uint16_t_u_u((l_2450 ^= 0x7BDFL), (*l_2439))), (***g_850)))))) , (*l_2439))));
                (*l_2442) &= l_2445;
            }
        }
        else
        { /* block id: 1161 */
            int16_t l_2455 = (-1L);
            int16_t l_2466 = (-1L);
            uint32_t ***l_2473 = &g_1515;
            uint32_t ****l_2472[9] = {&l_2473,&l_2473,&l_2473,&l_2473,&l_2473,&l_2473,&l_2473,&l_2473,&l_2473};
            int32_t l_2481 = (-1L);
            int32_t l_2482 = (-5L);
            int32_t l_2483 = 0xA38642ABL;
            int32_t l_2484 = 3L;
            int32_t l_2485 = (-8L);
            uint32_t *l_2520 = &g_98;
            int16_t **l_2557[10][3] = {{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307},{&g_307,&g_307,&g_307}};
            int32_t l_2587[7][6] = {{8L,0xD190E412L,(-5L),8L,0L,0xC94CFDBAL},{0xC94CFDBAL,0x81687773L,(-9L),8L,0xA59501DCL,0x1AA31A50L},{8L,0xA59501DCL,0x1AA31A50L,0x1AA31A50L,0xA59501DCL,8L},{(-5L),0x81687773L,0x0AFBBA7AL,0xC94CFDBAL,0L,8L},{0x0AFBBA7AL,0xD190E412L,0x1AA31A50L,(-9L),(-1L),0x1AA31A50L},{0x0AFBBA7AL,0L,(-9L),0xC94CFDBAL,1L,0xC94CFDBAL},{(-5L),0L,(-5L),0x1AA31A50L,(-1L),(-9L)}};
            uint64_t l_2608[2];
            uint32_t ******l_2624 = (void*)0;
            const uint32_t **l_2693 = &g_204[2][0];
            int32_t *l_2708 = &l_2541;
            const int32_t ** const *l_2736 = (void*)0;
            const int32_t ** const **l_2735 = &l_2736;
            int i, j;
            for (i = 0; i < 2; i++)
                l_2608[i] = 1UL;
            if ((l_2451 , ((*g_1132) | (safe_mod_func_uint32_t_u_u((l_2455 = (l_2454 ^= (*l_2439))), (safe_lshift_func_uint16_t_u_s((*l_53), (((**g_665) |= (-1L)) && (safe_mod_func_int64_t_s_s(g_2460, 0x8B76982A5B3295A6LL))))))))))
            { /* block id: 1165 */
                int32_t l_2461 = (-1L);
                (*l_1206) = l_2461;
lbl_2469:
                for (g_1584 = 4; (g_1584 >= 26); g_1584++)
                { /* block id: 1169 */
                    for (g_1422.f1 = 0; (g_1422.f1 > 4); ++g_1422.f1)
                    { /* block id: 1172 */
                        (*l_53) ^= ((*l_1206) = l_2466);
                    }
                }
                for (g_2460 = 0; (g_2460 == 39); ++g_2460)
                { /* block id: 1179 */
                    if (g_2137.f1)
                        goto lbl_2469;
                }
            }
            else
            { /* block id: 1182 */
                int32_t l_2479[9][3] = {{1L,8L,1L},{0x3CE51F71L,8L,0xD2B8E7F4L},{0x3CE51F71L,0x3CE51F71L,8L},{1L,8L,8L},{8L,8L,0xD2B8E7F4L},{1L,8L,1L},{0x3CE51F71L,8L,0xD2B8E7F4L},{0x3CE51F71L,0x3CE51F71L,8L},{1L,8L,8L}};
                int8_t l_2480 = 2L;
                uint32_t l_2486 = 0UL;
                struct S0 **l_2489 = &g_1389;
                uint32_t ****l_2498 = &g_396[0][0][4];
                uint8_t l_2503 = 0x72L;
                int32_t *l_2504 = &l_2479[4][1];
                uint8_t *l_2505 = (void*)0;
                uint8_t *l_2506 = &g_1465;
                int8_t l_2529 = (-1L);
                int i, j;
                (*l_1206) ^= ((((safe_mul_func_uint16_t_u_u(l_2466, ((((l_2472[5] == &l_2473) & (&l_2251 == &g_1910)) <= (((--(*l_56)) & (+(((0xBFL ^ ((safe_add_func_uint64_t_u_u(((**g_832) ^= (((--l_2486) >= (&g_1389 == (l_2489 = &g_1389))) || (safe_add_func_int32_t_s_s(((safe_mul_func_int16_t_s_s((((((7UL || 1UL) , &g_1778) == l_2494) , (*l_2439)) < l_2479[7][0]), (*l_2439))) > (-6L)), 0L)))), l_2479[5][1])) == (*g_1132))) , (**l_1205)) <= 8L))) | 4294967294UL)) && (*l_2439)))) & l_2483) | (*l_2439)) && 0x940352DB6423D90CLL);
                if ((((((**g_832) = (((((l_2482 > ((((safe_unary_minus_func_int8_t_s((safe_div_func_int16_t_s_s(((((*l_2506) &= (((**g_2196) == l_2498) , ((((((**g_665) < ((*g_1831) | 0xCFA47DA0L)) , ((safe_div_func_uint16_t_u_u((((((1L ^ (safe_lshift_func_uint8_t_u_u(((**l_2489) , 252UL), (**g_1111)))) , (**g_846)) && (**g_846)) , 0x4C695394B45AB3DCLL) == (**g_832)), 0x3DBEL)) < 0x22A7L)) | (*l_1749)) , &g_1584) == &g_493[0][2]))) <= (*l_2504)) > 0x904FA73BL), (*l_2439))))) , (void*)0) == &g_54) , (*l_2504))) , l_2482) < (**g_665)) < 0x3882866AL) , l_2482)) != (*l_2504)) > (**g_1827)) , 0x5FD9A6B6L))
                { /* block id: 1190 */
                    int32_t *l_2507 = &l_2485;
                    int32_t *l_2508 = &g_1424.f1;
                    int32_t *l_2509 = &g_2259[5];
                    int32_t *l_2510 = &g_2382.f1;
                    int32_t *l_2511 = &l_2483;
                    int32_t *l_2512[6][8][2] = {{{&g_2259[3],(void*)0},{&g_2259[0],&l_2241},{&l_2479[5][1],&g_1160.f1},{(void*)0,(void*)0},{&g_1390[5].f1,(void*)0},{&g_1422.f1,&l_2484},{&g_41,(void*)0},{(void*)0,&g_1160.f1}},{{&l_2454,&g_1422.f1},{(void*)0,&g_1422.f1},{&g_2259[0],&g_2382.f1},{&g_1424.f1,&g_41},{&g_2259[5],(void*)0},{&g_534.f1,&l_2454},{&g_1160.f1,&l_2479[5][1]},{&g_41,(void*)0}},{{&l_2485,&l_2483},{&g_1422.f1,&g_2259[0]},{&l_2479[5][1],&l_2479[5][1]},{&l_2482,&g_2137.f1},{&g_41,&l_2479[5][1]},{&l_2241,(void*)0},{&g_1424.f1,&l_2241},{&g_1422.f1,&g_534.f1}},{{&g_1422.f1,&l_2241},{&g_1424.f1,(void*)0},{&l_2241,&l_2479[5][1]},{&g_41,&g_2137.f1},{&g_2382.f1,&g_1160.f1},{&g_1160.f1,&l_2483},{&g_41,&l_2482},{(void*)0,&g_2259[3]}},{{&g_2259[5],&l_2454},{&l_2485,&g_41},{(void*)0,(void*)0},{&g_1390[5].f1,&l_2241},{&g_2382.f1,&g_1160.f1},{&l_2483,&g_1160.f1},{&g_2259[3],&g_41},{&g_534.f1,&l_2479[5][1]}},{{&l_2482,&g_41},{(void*)0,&g_1422.f1},{&g_1160.f1,&l_2482},{(void*)0,&g_1422.f1},{&g_1424.f1,&g_2259[0]},{&l_2454,(void*)0},{&g_534.f1,&l_2479[5][1]},{&g_965[0].f1,&l_2479[5][1]}}};
                    int i, j, k;
                    l_2513++;
                    for (g_2382.f2 = 6; (g_2382.f2 == 19); g_2382.f2 = safe_add_func_uint16_t_u_u(g_2382.f2, 5))
                    { /* block id: 1194 */
                        uint32_t l_2521 = 0x267B2EF0L;
                        int32_t *l_2522 = &g_534.f1;
                        uint64_t *l_2539 = &l_2190[1][0][3];
                        uint64_t **l_2538[2];
                        uint64_t l_2542[1][9];
                        int i, j;
                        for (i = 0; i < 2; i++)
                            l_2538[i] = &l_2539;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_2542[i][j] = 0xBD3695E9F00C55EFLL;
                        }
                        (*l_2504) = ((6UL < (*l_2504)) , (l_2482 > (*g_1831)));
                        (*l_1205) = func_8(((*l_1205) = (l_2522 = (((safe_mul_func_int8_t_s_s(l_2455, (((**g_832) = (*l_2439)) && (((*l_2439) & ((void*)0 == l_2520)) , (*l_53))))) || (*l_1206)) , func_8(func_8(func_8((l_2521 , func_3(&l_2481, &l_2454, (*l_1205), (*l_2511))), (*l_2507)), (**g_1826)), (*l_2509))))), l_2521);
                        (*l_2508) |= (safe_div_func_int8_t_s_s((safe_add_func_uint32_t_u_u(((*l_2520) |= ((~(((+((((void*)0 == &g_1301[6][0][5]) , (((l_2529 & ((*l_2522) >= (safe_rshift_func_int8_t_s_s((*g_1132), (safe_sub_func_int64_t_s_s(((**g_665) = (safe_div_func_uint16_t_u_u((*l_1206), (((--(**g_832)) == (((*l_1206) ^ 1L) != (((g_2540 = (*g_832)) != (void*)0) | 0x70766A9BL))) && (**g_832))))), l_2483)))))) | (*l_1749)) > l_2541)) , (*g_1831))) > (**g_846)) >= 255UL)) >= l_2542[0][6])), 0x9F146B13L)), (*g_1112)));
                        return l_2543;
                    }
                }
                else
                { /* block id: 1207 */
                    uint32_t l_2546 = 5UL;
                    for (g_534.f5 = (-18); (g_534.f5 <= 1); g_534.f5 = safe_add_func_uint16_t_u_u(g_534.f5, 8))
                    { /* block id: 1210 */
                        return l_2546;
                    }
                    (*l_1749) &= (*l_2504);
                }
                for (g_2382.f1 = 0; (g_2382.f1 <= 24); g_2382.f1 = safe_add_func_uint8_t_u_u(g_2382.f1, 8))
                { /* block id: 1217 */
                    for (l_2543 = 0; (l_2543 > 23); l_2543 = safe_add_func_uint16_t_u_u(l_2543, 9))
                    { /* block id: 1220 */
                        (*l_53) ^= (+(*g_1132));
                    }
                    return (*l_2439);
                }
                for (g_660 = (-18); (g_660 <= 31); g_660++)
                { /* block id: 1227 */
                    return l_2483;
                }
            }
            if (((safe_lshift_func_int8_t_s_s(((l_2557[9][1] = l_2556) == ((*g_850) = l_2558)), (safe_mul_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(((*g_1112) = (safe_add_func_int64_t_s_s((safe_div_func_uint32_t_u_u((~((safe_sub_func_uint64_t_u_u((0x2A153C9B17DC58FELL && (((safe_div_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint32_t_u_u((*l_2442), (++(*l_56)))) <= (l_2482 = ((*l_1206) = ((safe_lshift_func_int16_t_s_s((safe_sub_func_int64_t_s_s(0xDE4153A71BBEFB91LL, (((~(~((*l_2439) = (&g_850 == (void*)0)))) , l_2466) | 0xEE01L))), l_2586)) , l_2484)))), 2)), l_2455)) && (*l_2439)) && (*l_2439))), (**g_665))) | (*l_1749))), 4294967290UL)), 0x20B897F2814B9CAFLL))), (*g_1132))), (*l_1749))) > 1L) , l_2587[4][3]), (**l_1205))))) & 0xEE1B15768B528E5CLL))
            { /* block id: 1238 */
                uint32_t l_2607 = 0x03897CACL;
                int32_t *l_2628 = (void*)0;
                uint64_t **l_2629 = (void*)0;
                int32_t l_2656 = 0xA9D242ECL;
                int32_t l_2707 = 1L;
                uint8_t l_2724 = 0x01L;
                for (g_41 = 1; (g_41 <= 5); g_41 += 1)
                { /* block id: 1241 */
                    uint16_t l_2601[3][10][4] = {{{1UL,2UL,0x1F9FL,0xC955L},{65530UL,0xAC49L,0x3B2FL,9UL},{65535UL,0xB435L,0xC955L,0x0388L},{65533UL,0x42CBL,65533UL,0xC955L},{0x5D6DL,0xA6A1L,0x8ABCL,0x6366L},{0x3CA6L,0xCF81L,1UL,0xA6A1L},{0xBA2FL,0xAC49L,1UL,0x1F9FL},{0x3CA6L,65535UL,0x8ABCL,0xFA77L},{0x5D6DL,0xD04FL,65533UL,2UL},{65533UL,2UL,0xC955L,0x1F65L}},{{65535UL,65530UL,0x3B2FL,0xA6A1L},{65530UL,0xD04FL,0x1F9FL,0x0388L},{1UL,0x3CA6L,0xBA2FL,0x1F9FL},{0x5D6DL,0x42CBL,0xCFB4L,65530UL},{65532UL,0xCF81L,0xCF81L,65532UL},{1UL,65530UL,1UL,0xC955L},{0xA6A1L,0x2E37L,0x3B2FL,0xFA77L},{65535UL,0xB435L,0xBA2FL,0xFA77L},{65533UL,0x2E37L,0x1F65L,0xC955L},{0x6366L,65530UL,0x8ABCL,65532UL}},{{65535UL,0xCF81L,0x1F9FL,65530UL},{0xBA2FL,0x42CBL,8UL,0x1F9FL},{65535UL,0x3CA6L,0x8ABCL,0x0388L},{65532UL,0xD04FL,0x3EFEL,0xA6A1L},{65533UL,65530UL,0xCF81L,0x1F65L},{0x3CA6L,2UL,0x3B2FL,2UL},{2UL,0xD04FL,8UL,0xFA77L},{1UL,65535UL,0xC955L,0x1F9FL},{0x6366L,0xAC49L,0xCFB4L,0xA6A1L},{0x6366L,0xCF81L,0xC955L,0x6366L}}};
                    uint64_t *l_2615 = (void*)0;
                    int32_t l_2647[10][10] = {{0x598737A3L,1L,0x9EED08E1L,0L,0x598737A3L,0L,0x9EED08E1L,1L,0x598737A3L,1L},{0x522452A2L,0L,0x503AE568L,0x39956A21L,0x503AE568L,0L,0x522452A2L,0x39956A21L,0x522452A2L,0L},{0x598737A3L,0x39956A21L,0x3AFD4703L,0x39956A21L,0x598737A3L,6L,0x3AFD4703L,6L,0x598737A3L,0x39956A21L},{0x503AE568L,0x39956A21L,0x503AE568L,0L,0x522452A2L,0x39956A21L,0x522452A2L,0L,0x503AE568L,0x39956A21L},{0x598737A3L,0L,0x9EED08E1L,1L,0x598737A3L,1L,0x9EED08E1L,0L,0x598737A3L,0L},{0x522452A2L,1L,0x503AE568L,6L,0x503AE568L,1L,0x522452A2L,6L,0x522452A2L,1L},{0x598737A3L,6L,0x3AFD4703L,6L,0x598737A3L,0x39956A21L,0x3AFD4703L,0x39956A21L,0x598737A3L,6L},{0x503AE568L,6L,0x503AE568L,1L,0x522452A2L,6L,0x522452A2L,1L,0x503AE568L,6L},{0x598737A3L,1L,0x9EED08E1L,0L,0x598737A3L,0L,0x9EED08E1L,1L,0x598737A3L,1L},{0x522452A2L,0L,0x503AE568L,0x39956A21L,0x503AE568L,0L,0x522452A2L,0x39956A21L,0x522452A2L,0L}};
                    int32_t **l_2648 = &l_1749;
                    int32_t *l_2651 = (void*)0;
                    int32_t *l_2652 = &g_2259[0];
                    int32_t *l_2653 = &g_54;
                    int32_t *l_2654 = &g_2259[0];
                    int32_t *l_2655[7][1] = {{(void*)0},{(void*)0},{&g_1424.f1},{(void*)0},{(void*)0},{&g_1424.f1},{(void*)0}};
                    uint32_t l_2661 = 0xAD7A227BL;
                    int16_t l_2684 = 1L;
                    uint64_t l_2686[1][6] = {{0x35D61FA6E79906C8LL,0xA02F9331570527DFLL,0xA02F9331570527DFLL,0x35D61FA6E79906C8LL,0xA02F9331570527DFLL,0xA02F9331570527DFLL}};
                    int i, j, k;
                    for (l_2484 = 5; (l_2484 >= 0); l_2484 -= 1)
                    { /* block id: 1244 */
                        int i, j;
                        (*l_1206) |= l_2587[(l_2484 + 1)][g_41];
                        if (l_2587[(g_41 + 1)][l_2484])
                            break;
                        (*l_2251) = &g_1390[(g_41 + 1)];
                        (*l_1205) = &l_2587[(l_2484 + 1)][g_41];
                    }
                }
                (*l_1749) &= (safe_add_func_int16_t_s_s((*l_2439), (((*l_1206) = ((*g_1831) & (l_2707 = ((((safe_add_func_uint32_t_u_u(((l_2483 = (((safe_unary_minus_func_int8_t_s(((*l_2439) == ((l_2693 = l_2692) != (l_2694[5] = l_2694[5]))))) & (((safe_rshift_func_uint8_t_u_s((((l_2697 == (((~((*l_2439) ^ (((((**g_832) = ((safe_sub_func_int16_t_s_s(((**g_846) &= (safe_lshift_func_int8_t_s_s((safe_add_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u((**g_1826), ((*g_1132) = (l_2481 , (*g_1132))))) , (*g_1132)), 1L)), g_1390[5].f2))), l_2587[4][3])) , (*l_53))) , (**g_665)) != 0xAC100996282F370ALL) | 1UL))) & (*l_2439)) , &g_2196)) & l_2608[0]) > (*g_1112)), 4)) & 0x12L) , 0x3505L)) <= (*l_2439))) == 1UL), 1UL)) , 0L) <= 0L) , (*l_2439))))) > 0x7E93FE2A04F454AELL)));
                for (g_1361 = 0; (g_1361 <= 2); g_1361 += 1)
                { /* block id: 1300 */
                    int64_t l_2709[1][3][7] = {{{1L,3L,(-8L),1L,(-8L),3L,1L},{0x0905539D5B4B6D27LL,1L,3L,(-8L),1L,(-8L),3L},{1L,1L,3L,0xC82D11AB7CBE333CLL,0xA882E7CA327EC856LL,3L,0xA882E7CA327EC856LL}}};
                    int i, j, k;
                    l_2708 = &l_2656;
                    for (l_2483 = 1; (l_2483 <= 5); l_2483 += 1)
                    { /* block id: 1304 */
                        return l_2709[0][0][0];
                    }
                }
                for (l_2481 = 0; (l_2481 >= (-15)); l_2481--)
                { /* block id: 1310 */
                    struct S0 **l_2738 = &g_1389;
                    for (l_2482 = 9; (l_2482 != 19); ++l_2482)
                    { /* block id: 1313 */
                        uint32_t l_2714 = 0xE51C69C4L;
                        int32_t *l_2716[5][1][4] = {{{&l_2454,(void*)0,&g_41,&g_41}},{{&l_2485,&l_2485,&l_2454,&g_41}},{{(void*)0,(void*)0,(void*)0,&l_2454}},{{(void*)0,&l_2454,&l_2454,(void*)0}},{{&l_2485,&l_2454,&g_41,&l_2454}}};
                        int i, j, k;
                        if ((*l_2439))
                            break;
                        if (l_2714)
                            break;
                        l_2717++;
                    }
                    for (l_2659 = 25; (l_2659 != (-4)); l_2659--)
                    { /* block id: 1320 */
                        uint32_t l_2725 = 0x042DA0BFL;
                        uint8_t *l_2739 = &g_2685[2];
                        (*l_2439) ^= ((safe_mod_func_int32_t_s_s(l_2724, l_2725)) >= (safe_mod_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((**g_1827), ((safe_lshift_func_uint8_t_u_s(((g_2732 = (*g_1831)) | ((*l_2708) = (((*l_2739) = ((((((((void*)0 == &g_833[0][3][5]) && ((*g_1132) , ((((safe_rshift_func_uint8_t_u_u((((0x6FL ^ (0x1173BA9BL >= 1UL)) , 0L) || l_2725), 7)) && 0xCB77L) & l_2725) >= l_2725))) , l_2735) != l_2737) , l_2738) != (void*)0) > 0xF917L)) | 7UL))), 3)) & 0xC23DFB74L))), 0x72E1157108DF259CLL)));
                        if (l_2725)
                            continue;
                        (*g_1663) = func_8((*l_1205), ((**g_1910) , (**g_1827)));
                    }
                }
            }
            else
            { /* block id: 1329 */
                uint32_t * const **l_2753 = (void*)0;
                int64_t l_2755 = (-2L);
                (*l_2708) = (((*l_1206) = (((((safe_div_func_uint16_t_u_u((&g_666[0][3] != &g_666[0][3]), g_2742)) , 0xA3A7D8D9L) || ((safe_lshift_func_int8_t_s_u((~(safe_mul_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(((g_2750 = (***g_2196)) != l_2753), 0L)) | (*l_2439)), (((*g_1831) >= 0x52AAD255L) || l_2754)))), 1)) != l_2755)) <= (**g_832)) && l_2755)) ^ 4294967286UL);
            }
        }
    }
    else
    { /* block id: 1335 */
        const int32_t l_2772 = 1L;
        int32_t l_2773 = (-7L);
        int32_t l_2802 = 0x701ECD67L;
        uint8_t *l_2828 = &g_33[5][7];
        uint32_t l_2853 = 1UL;
        uint32_t l_2859 = 0x5FC7A70CL;
        uint32_t ****l_2867 = (void*)0;
        uint16_t **l_2879 = (void*)0;
        uint16_t ***l_2878[4][4] = {{(void*)0,&l_2879,(void*)0,&l_2879},{(void*)0,&l_2879,(void*)0,&l_2879},{(void*)0,&l_2879,(void*)0,&l_2879},{(void*)0,&l_2879,(void*)0,&l_2879}};
        uint8_t l_2910 = 0x8CL;
        int32_t l_2915 = 1L;
        int32_t l_2931 = 0L;
        int32_t l_2934 = 1L;
        int32_t l_2940 = 7L;
        int32_t l_2941[10][8] = {{0L,0xCD58F4E8L,5L,8L,0L,(-1L),0L,8L},{5L,0xB96FF82AL,5L,0xD02FFBD4L,0x6A639E34L,0xF280FFB0L,1L,0xCD58F4E8L},{0L,0xB96FF82AL,0x6A639E34L,(-1L),(-8L),(-1L),0x6A639E34L,0xB96FF82AL},{0L,0xCD58F4E8L,1L,0xF280FFB0L,0x6A639E34L,0xD02FFBD4L,5L,0xB96FF82AL},{5L,8L,0L,0xD02FFBD4L,(-8L),0xCD58F4E8L,(-3L),(-1L)},{5L,0xD02FFBD4L,0x6A639E34L,0xF280FFB0L,1L,0xCD58F4E8L,0L,0xCD58F4E8L},{1L,0xCD58F4E8L,0L,0xCD58F4E8L,1L,0xF280FFB0L,0x6A639E34L,0xD02FFBD4L},{5L,(-1L),(-3L),0xCD58F4E8L,(-8L),0xD02FFBD4L,(-8L),0xCD58F4E8L},{(-3L),3L,(-3L),0xF280FFB0L,0L,0xB96FF82AL,0x6A639E34L,(-1L)},{(-8L),3L,0L,0xD02FFBD4L,0L,0xD02FFBD4L,0L,3L}};
        int8_t *l_2956[8];
        uint32_t l_2992 = 4294967295UL;
        uint64_t l_3010 = 0UL;
        uint32_t *l_3066 = &l_2853;
        int i, j;
        for (i = 0; i < 8; i++)
            l_2956[i] = &g_1584;
        if (g_2137.f5)
            goto lbl_2756;
        (*l_1749) = (*l_1749);
        (*l_40) &= (safe_mul_func_int8_t_s_s((+((safe_mod_func_int16_t_s_s(((safe_add_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((&l_2426[5][1][0] != &g_1301[1][0][3]) , (safe_mod_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(l_2772, 9L)) < (((*l_1206) |= (((l_2773 |= (((void*)0 != &l_1598[2]) > (&g_845[3][0][0] == &g_850))) <= ((safe_mod_func_int64_t_s_s(((0x5ECFL || 0x3A15L) || l_2772), 1L)) == l_2772)) != (**l_1205))) , 0L)), (*g_1132)))), (-2L))), l_2772)), (*g_1112))) > l_2772), (*l_1749))) , l_2773)), 0xF6L));
        if (((*g_1132) != (*g_1132)))
        { /* block id: 1341 */
            int64_t l_2800 = (-7L);
            int32_t l_2805 = 7L;
            const uint32_t ****l_2808 = &g_1527;
            uint32_t *****l_2849 = (void*)0;
            int32_t *l_2900 = &g_96;
            int32_t l_2943 = (-1L);
            int8_t *l_2957 = &g_411[3][5][1];
            for (l_2543 = 20; (l_2543 >= (-24)); l_2543--)
            { /* block id: 1344 */
                const int8_t l_2801 = 0x68L;
                int32_t *l_2803 = &g_2259[0];
                uint32_t *** const l_2827[10] = {&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515};
                int16_t l_2834 = 0x1F5AL;
                int32_t *l_2866 = (void*)0;
                uint8_t l_2908 = 255UL;
                int32_t l_2932 = 0xC532FDA1L;
                int32_t l_2933 = 0L;
                int8_t l_2942 = 0x5EL;
                uint64_t l_2946[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_2946[i] = 18446744073709551613UL;
                l_2805 ^= ((&g_1525 != ((g_2804 , (*l_2803)) , (void*)0)) ^ l_2772);
            }
            l_2943 ^= (**l_1205);
        }
        else
        { /* block id: 1398 */
            uint32_t *****l_2967[7];
            int32_t l_2975[10][10] = {{0x55623179L,0xBA6C47DAL,(-1L),0xBA6C47DAL,0x55623179L,1L,(-9L),4L,(-1L),1L},{(-9L),0x104F90FBL,1L,1L,(-1L),0x4923ABA9L,0x4923ABA9L,(-1L),1L,1L},{1L,1L,0x6CCFBDCCL,1L,0x55623179L,3L,(-1L),(-1L),0x7354F742L,(-1L)},{(-1L),1L,(-1L),(-1L),0xBA6C47DAL,(-1L),(-1L),1L,(-1L),1L},{0x104F90FBL,1L,0x7354F742L,0x55623179L,(-1L),0xACF303C4L,0x4923ABA9L,0xBA6C47DAL,0xBA6C47DAL,0x4923ABA9L},{1L,0x104F90FBL,0x55623179L,0x55623179L,0x104F90FBL,1L,(-9L),0xACF303C4L,(-1L),3L},{3L,0xBA6C47DAL,1L,(-1L),0x7354F742L,0x6CCFBDCCL,1L,0x6CCFBDCCL,0x7354F742L,(-1L)},{3L,0x6CCFBDCCL,3L,1L,0x4923ABA9L,1L,(-1L),(-1L),1L,0xACF303C4L},{1L,(-1L),(-1L),1L,0xACF303C4L,0xACF303C4L,1L,(-1L),(-1L),1L},{0x104F90FBL,4L,3L,0xBA6C47DAL,1L,(-1L),0x7354F742L,0x6CCFBDCCL,1L,0x6CCFBDCCL}};
            uint8_t l_3054 = 0UL;
            uint64_t l_3055 = 0xE7523E8FD4E309ECLL;
            uint32_t *l_3065 = &l_1204[0];
            int i, j;
            for (i = 0; i < 7; i++)
                l_2967[i] = &l_2867;
            for (l_2934 = (-25); (l_2934 >= 22); l_2934 = safe_add_func_int32_t_s_s(l_2934, 4))
            { /* block id: 1401 */
                int16_t l_2964 = 0x3A49L;
                int32_t l_2981 = 2L;
                int32_t l_2985[7] = {0x887DB7EBL,0x887DB7EBL,0x887DB7EBL,0x887DB7EBL,0x887DB7EBL,0x887DB7EBL,0x887DB7EBL};
                int8_t l_2996 = 0xEEL;
                uint32_t l_3040 = 0x18AA77CBL;
                int i;
            }
            for (g_134 = 0; (g_134 >= 37); g_134 = safe_add_func_int16_t_s_s(g_134, 1))
            { /* block id: 1441 */
                uint32_t ******l_3045 = &g_1531[0];
                int32_t l_3050 = (-1L);
                int16_t l_3053 = (-8L);
                l_3055 ^= (((((0xC551902C896BE7CBLL ^ (&g_1531[0] == ((*l_1206) , l_3045))) && (*l_2442)) && (248UL | ((((((**g_832) &= (safe_rshift_func_uint16_t_u_u(((*g_2961) = ((((((safe_mod_func_uint64_t_u_u((l_3050 | ((**g_846) & (safe_lshift_func_int16_t_s_u(((*g_2649) == (void*)0), (*l_1206))))), 0xC09766265B6BB652LL)) ^ l_3050) ^ l_3050) >= l_2975[8][3]) | l_2859) != (**g_665))), l_3053))) , (**l_2697)) != (**l_2697)) ^ l_2934) != l_3054))) > 0L) == l_3054);
                if (l_3053)
                    continue;
                (*l_1206) = (0xD41BEF0C2259AF4BLL > (((~((((((((((+(*l_1749)) <= (safe_unary_minus_func_int8_t_s(((*l_40) , ((*g_1132) = 1L))))) , (safe_sub_func_uint64_t_u_u((((**g_2750) = &l_2992) == (l_3066 = ((**l_2251) , (l_3065 = func_8(&l_3050, ((safe_mod_func_int64_t_s_s((safe_rshift_func_int8_t_s_u((*g_1132), 0)), (*l_1749))) == l_2931)))))), 0xEF11FB9D49C21720LL))) || (*l_2442)) == 1L) || l_3050) , l_2941[0][3]) , (-1L)) , (*l_53)) >= (*l_1749))) >= 0x7DL) == l_2992));
            }
            for (g_134 = (-29); (g_134 < 30); g_134++)
            { /* block id: 1454 */
                int32_t l_3076 = 9L;
                int32_t l_3077 = 0L;
                int32_t l_3078 = 1L;
                int32_t l_3079 = 7L;
                uint64_t l_3081[1][3];
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_3081[i][j] = 1UL;
                }
                for (g_2804.f1 = 0; (g_2804.f1 > 17); ++g_2804.f1)
                { /* block id: 1457 */
                    int32_t *l_3071 = (void*)0;
                    int32_t *l_3072 = &l_2939;
                    int32_t *l_3073 = &l_2975[5][6];
                    int32_t *l_3074[4] = {&g_1390[5].f1,&g_1390[5].f1,&g_1390[5].f1,&g_1390[5].f1};
                    int16_t l_3080 = (-7L);
                    int i;
                    ++l_3081[0][0];
                    for (g_2216 = 22; (g_2216 > 23); g_2216 = safe_add_func_uint64_t_u_u(g_2216, 9))
                    { /* block id: 1461 */
                        l_3071 = &l_2975[3][7];
                    }
                    (*l_53) = l_3054;
                    (*l_1205) = &l_2975[8][3];
                }
                return (**g_832);
            }
            (*g_2650) = (*l_1205);
        }
    }
    return (*l_1749);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_3(int32_t * p_4, int32_t * p_5, const int32_t * p_6, uint8_t  p_7)
{ /* block id: 1027 */
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_665 g_666 g_1132 g_411 g_54 g_534.f1 g_1424.f1 g_2137.f1 g_965.f1 g_965.f2
 * writes: g_2196 g_534.f5 g_534.f1
 */
static int32_t * func_8(int32_t * p_9, uint8_t  p_10)
{ /* block id: 1020 */
    uint32_t ******l_2193 = &g_1531[0];
    uint32_t ******l_2195 = &g_1531[0];
    uint32_t *******l_2194[3][5][5] = {{{&l_2195,&l_2193,&l_2195,&l_2195,&l_2193},{&l_2193,&l_2193,&l_2195,(void*)0,&l_2193},{&l_2195,&l_2195,&l_2195,&l_2195,&l_2195},{&l_2195,&l_2193,&l_2193,&l_2193,&l_2195},{&l_2195,&l_2195,&l_2195,&l_2193,&l_2195}},{{(void*)0,&l_2195,&l_2193,&l_2193,&l_2195},{&l_2195,&l_2193,&l_2193,&l_2195,&l_2195},{&l_2195,&l_2193,&l_2193,(void*)0,&l_2195},{&l_2195,&l_2193,&l_2195,&l_2195,&l_2195},{&l_2195,&l_2195,&l_2195,(void*)0,&l_2193}},{{&l_2195,&l_2195,&l_2195,&l_2195,&l_2195},{&l_2195,&l_2193,(void*)0,&l_2193,(void*)0},{&l_2195,&l_2195,&l_2195,&l_2195,&l_2195},{&l_2195,&l_2195,&l_2195,&l_2193,(void*)0},{&l_2195,&l_2195,&l_2195,&l_2195,&l_2195}}};
    int32_t l_2208[3];
    int32_t l_2209 = 0xA0666193L;
    int32_t l_2214 = 0L;
    int32_t *l_2215 = &g_534.f1;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2208[i] = (-1L);
    (*l_2215) |= (((safe_sub_func_int32_t_s_s(((((((l_2193 == (g_2196 = l_2193)) , ((~(safe_lshift_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((((l_2208[1] = (safe_add_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(0x18L, 1L)), (p_10 || l_2208[0])))) , ((**g_665) = ((l_2209 |= l_2208[0]) <= (safe_mod_func_int32_t_s_s((safe_sub_func_uint64_t_u_u(((((0L <= l_2208[1]) > l_2208[0]) >= 1UL) > l_2208[1]), 0L)), l_2208[0]))))) & l_2214), 1)), (*g_1132))), 5))) , (*p_9))) , l_2208[0]) < l_2214) && (-1L)) , l_2208[2]), p_10)) && 0x13L) , (*p_9));
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_1132 g_411 g_2166 g_1910 g_1911 g_1609 g_1389 g_2137.f1 g_1111 g_1112 g_134
 * writes: g_2137.f1 g_1390
 */
static int32_t * func_11(uint64_t  p_12)
{ /* block id: 1013 */
    uint32_t l_2165 = 18446744073709551615UL;
    int32_t *l_2167 = &g_2137.f1;
    int32_t ** const * const *l_2168[5];
    int32_t *l_2171[2];
    int32_t l_2174 = 0xC7DB3BC6L;
    int64_t *l_2175 = &g_325;
    int16_t l_2176[3];
    const uint8_t *l_2187 = &g_765;
    const uint8_t **l_2186 = &l_2187;
    const uint8_t ***l_2185 = &l_2186;
    uint64_t l_2188 = 1UL;
    int32_t *l_2189 = &g_54;
    int i;
    for (i = 0; i < 5; i++)
        l_2168[i] = (void*)0;
    for (i = 0; i < 2; i++)
        l_2171[i] = &g_965[0].f1;
    for (i = 0; i < 3; i++)
        l_2176[i] = 0x9F8BL;
    (*l_2167) = (safe_div_func_int16_t_s_s(0x0D87L, (safe_div_func_int16_t_s_s((safe_add_func_int64_t_s_s(p_12, 4L)), ((safe_lshift_func_int8_t_s_s((*g_1132), ((l_2165 == (p_12 & (g_2166 , (l_2165 , p_12)))) || l_2165))) || l_2165)))));
    (*g_1389) = (**g_1910);
    (*l_2167) = (((safe_mod_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((*l_2167) | 0xBC1838ADL), ((**g_1111) , (safe_rshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s((0UL != (((*l_2167) , (p_12 , l_2185)) != &l_2186)), p_12)), 14))))), 1UL)) <= l_2188) <= p_12);
    return l_2189;
}


/* ------------------------------------------ */
/* 
 * reads : g_660 g_1361 g_1958 g_114 g_33 g_665 g_666 g_1422.f1 g_198 g_832 g_833 g_534.f5 g_1826 g_1112 g_134 g_1132 g_1390 g_850 g_846 g_307 g_1617 g_1424.f1 g_411 g_1827 g_195 g_1831 g_54 g_2137 g_1525 g_1526 g_305 g_308 g_965.f2 g_2150 g_1910 g_1911 g_1609 g_1406 g_2259 g_493
 * writes: g_660 g_1361 g_114 g_1422.f1 g_534.f5 g_1418 g_1132 g_198 g_666 g_2008 g_195 g_134 g_411 g_765 g_1424.f1 g_1329 g_1424.f5 g_1527 g_54 g_2259
 */
static const struct S0  func_13(int64_t  p_14, int32_t * p_15, uint16_t  p_16, int32_t * p_17)
{ /* block id: 823 */
    int32_t *l_1784 = (void*)0;
    uint32_t ***l_1804 = &g_397[0][5][0];
    int64_t *** const l_1860 = &g_665;
    const int32_t l_1863 = 0L;
    int32_t l_1871 = 0xD3FD0E7EL;
    uint16_t l_1896 = 65532UL;
    int32_t l_1897 = (-4L);
    uint64_t l_1905 = 0xBBCB1ACCEB598529LL;
    int64_t l_2012 = (-1L);
    const int16_t *l_2051 = (void*)0;
    uint8_t **l_2054 = &g_1112;
    uint32_t l_2069 = 0x40A23699L;
    int32_t l_2085[3];
    struct S0 **l_2138[7][5][7] = {{{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,(void*)0,&g_1389,(void*)0,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,(void*)0,&g_1389,(void*)0,(void*)0,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389}},{{&g_1389,(void*)0,(void*)0,&g_1389,(void*)0,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,(void*)0,&g_1389,(void*)0,&g_1389,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{(void*)0,(void*)0,&g_1389,&g_1389,(void*)0,(void*)0,(void*)0}},{{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,(void*)0,&g_1389,(void*)0,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,(void*)0,&g_1389,(void*)0,(void*)0,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389}},{{&g_1389,(void*)0,(void*)0,&g_1389,(void*)0,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,(void*)0,&g_1389,(void*)0,&g_1389,&g_1389,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{(void*)0,(void*)0,&g_1389,&g_1389,(void*)0,(void*)0,(void*)0}},{{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{(void*)0,(void*)0,&g_1389,(void*)0,&g_1389,(void*)0,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389}},{{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{(void*)0,&g_1389,(void*)0,&g_1389,(void*)0,(void*)0,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,(void*)0,(void*)0,&g_1389,&g_1389,&g_1389}},{{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{(void*)0,(void*)0,&g_1389,(void*)0,&g_1389,(void*)0,(void*)0},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389},{&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389,&g_1389}}};
    uint16_t l_2154 = 3UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_2085[i] = (-4L);
    for (g_660 = 13; (g_660 <= 19); g_660 = safe_add_func_int64_t_s_s(g_660, 8))
    { /* block id: 826 */
        uint16_t *l_1752 = &g_1361;
        int32_t l_1783 = 1L;
        uint16_t l_1812 = 0xFB34L;
        int8_t l_1881[6][6][2] = {{{(-6L),(-1L)},{0x1FL,1L},{(-1L),(-1L)},{1L,0x59L},{1L,(-1L)},{(-1L),1L}},{{0x1FL,(-1L)},{(-6L),0x59L},{(-6L),(-1L)},{0x1FL,1L},{(-1L),(-1L)},{1L,0x59L}},{{1L,(-1L)},{(-1L),1L},{0x1FL,(-1L)},{(-6L),0x59L},{(-6L),(-1L)},{0x1FL,1L}},{{(-1L),(-1L)},{1L,0x59L},{1L,(-1L)},{(-1L),1L},{0x1FL,(-1L)},{(-6L),0x59L}},{{(-6L),(-1L)},{0x1FL,1L},{(-1L),(-1L)},{1L,0x59L},{1L,(-1L)},{(-1L),1L}},{{0x1FL,(-1L)},{(-6L),0x59L},{(-6L),(-1L)},{0x1FL,1L},{(-1L),(-1L)},{1L,0x59L}}};
        uint32_t l_1922 = 0UL;
        int32_t **l_2005 = &g_525;
        int32_t ***l_2004 = &l_2005;
        uint8_t **l_2072 = &g_1112;
        int32_t l_2086 = 0xE712663BL;
        int32_t l_2088 = 0x495A0C8AL;
        uint32_t * const *l_2109 = (void*)0;
        uint32_t * const ** const l_2108[4] = {&l_2109,&l_2109,&l_2109,&l_2109};
        int32_t l_2122 = 0xA72ECAB7L;
        int i, j, k;
        (*p_17) = ((*p_15) = ((++(*l_1752)) > p_16));
        for (g_534.f5 = (-11); (g_534.f5 == (-21)); g_534.f5 = safe_sub_func_uint16_t_u_u(g_534.f5, 4))
        { /* block id: 832 */
            uint32_t l_1770 = 3UL;
            struct S0 **l_1912 = (void*)0;
            uint64_t l_1925[3];
            int32_t l_1963 = (-1L);
            const uint64_t l_2036 = 8UL;
            int8_t *l_2075 = &g_198[6];
            int8_t **l_2074 = &l_2075;
            int32_t l_2084 = (-1L);
            int32_t l_2120 = 0L;
            int32_t l_2121 = 0xD00880D8L;
            int16_t ** const l_2149[8] = {&g_307,&g_307,&g_307,&g_307,&g_307,&g_307,&g_307,&g_307};
            int i;
            for (i = 0; i < 3; i++)
                l_1925[i] = 0x0F95F83B6BDAD64ELL;
            for (g_1418 = 20; (g_1418 != 30); g_1418 = safe_add_func_uint16_t_u_u(g_1418, 9))
            { /* block id: 835 */
                uint64_t l_1759[2][2][10] = {{{0xAAEF3D9637C71560LL,0xAAEF3D9637C71560LL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL,0x2AA273EC050FEDBDLL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL,0x2AA273EC050FEDBDLL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL},{0x2AA273EC050FEDBDLL,0UL,0UL,0x2AA273EC050FEDBDLL,0UL,0UL,0x2AA273EC050FEDBDLL,0UL,0UL,0x2AA273EC050FEDBDLL}},{{0UL,0x2AA273EC050FEDBDLL,0UL,0UL,0x2AA273EC050FEDBDLL,0UL,0UL,0x2AA273EC050FEDBDLL,0UL,0UL},{0x2AA273EC050FEDBDLL,0x2AA273EC050FEDBDLL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL,0x2AA273EC050FEDBDLL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL,0x2AA273EC050FEDBDLL,0xAAEF3D9637C71560LL,0x2AA273EC050FEDBDLL}}};
                int8_t **l_1773 = &g_1132;
                int32_t l_1794[4][5][7] = {{{3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL,3L},{0xA4B1191EL,3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL},{3L,3L,0x7A038C0CL,3L,(-7L),0x7A038C0CL,(-7L)},{3L,0x1C99714DL,0x1C99714DL,3L,(-4L),0xA4B1191EL,3L},{0xA4B1191EL,(-7L),(-4L),(-4L),(-7L),0xA4B1191EL,0x1C99714DL}},{{(-7L),3L,0x7A038C0CL,3L,3L,0x7A038C0CL,3L},{(-7L),0x1C99714DL,0xA4B1191EL,(-7L),(-4L),(-4L),(-7L)},{0xA4B1191EL,3L,0xA4B1191EL,(-4L),3L,0x1C99714DL,0x1C99714DL},{3L,(-7L),0x7A038C0CL,(-7L),3L,0x7A038C0CL,3L},{3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL,3L}},{{0xA4B1191EL,3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL},{3L,3L,0x7A038C0CL,3L,(-7L),0x7A038C0CL,(-7L)},{3L,0x1C99714DL,0x1C99714DL,3L,(-4L),0xA4B1191EL,3L},{0xA4B1191EL,(-7L),(-4L),(-4L),(-7L),0xA4B1191EL,0x1C99714DL},{(-7L),3L,0x7A038C0CL,3L,3L,0x7A038C0CL,3L}},{{(-7L),0x1C99714DL,0xA4B1191EL,(-7L),(-4L),(-4L),(-7L)},{0xA4B1191EL,3L,0xA4B1191EL,(-4L),3L,0x1C99714DL,0x1C99714DL},{3L,(-7L),0x7A038C0CL,(-7L),3L,0x7A038C0CL,3L},{3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL,3L},{0xA4B1191EL,3L,0x1C99714DL,(-4L),3L,(-4L),0x1C99714DL}}};
                int32_t **l_1848 = &g_1459;
                int32_t ***l_1847 = &l_1848;
                uint32_t *l_1870 = &g_57;
                int32_t *l_1872 = (void*)0;
                int32_t *l_1873 = &g_1160.f1;
                uint32_t ***l_1913[3][10] = {{&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515},{&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515},{&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515,&g_1515}};
                int i, j, k;
            }
            for (g_114 = 0; (g_114 <= 5); g_114 += 1)
            { /* block id: 941 */
                struct S0 **l_2019[10];
                int32_t l_2038 = 0L;
                uint8_t **l_2055 = &g_1112;
                uint16_t *l_2056 = &l_1812;
                int32_t *l_2057 = &g_1424.f1;
                uint8_t ***l_2073 = &l_2055;
                int i, j;
                for (i = 0; i < 10; i++)
                    l_2019[i] = &g_1389;
                for (p_14 = 0; (p_14 <= 0); p_14 += 1)
                { /* block id: 944 */
                    int8_t **l_1999 = &g_1132;
                    int32_t ****l_2006 = (void*)0;
                    int32_t ****l_2007[6] = {(void*)0,(void*)0,&l_2004,(void*)0,(void*)0,&l_2004};
                    struct S0 **l_2017 = &g_1389;
                    struct S0 ***l_2018 = &l_1912;
                    const uint32_t l_2035 = 0x568C995AL;
                    int64_t *l_2037[3];
                    uint8_t *l_2039 = &g_765;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_2037[i] = &g_965[0].f5;
                    (*p_17) ^= ((((safe_add_func_int8_t_s_s((((*l_1999) = &g_411[1][5][1]) != (void*)0), (safe_sub_func_int8_t_s_s((g_198[(p_14 + 4)] = 0x0CL), (safe_add_func_uint32_t_u_u(g_1958[(p_14 + 3)], ((g_33[g_114][(p_14 + 6)] > (((((**l_1860) = (**l_1860)) == (void*)0) , (g_2008 = l_2004)) == (void*)0)) == 18446744073709551614UL))))))) == 1UL) >= g_33[g_114][(g_114 + 2)]) || 0xFCL);
                    (*p_17) &= (safe_div_func_uint16_t_u_u((g_33[g_114][(p_14 + 2)] ^ (((**g_832) = g_198[(g_114 + 1)]) == ((**g_665) >= ((((*l_2039) = (((l_2012 && (++(**g_1826))) <= ((9L > (((((*l_2018) = l_2017) == l_2019[9]) , ((l_2038 &= ((safe_lshift_func_int8_t_s_u((6L | ((((safe_add_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((*g_1132) = ((safe_unary_minus_func_uint32_t_u((((safe_div_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s((safe_mod_func_int8_t_s_s(l_2035, 0x4FL)), 0x25F0L)) , 65527UL), 0xF668L)) || l_2036) , g_198[(g_114 + 1)]))) , 0x1DL)), 1UL)), p_14)) || 0L), p_16)) >= 0x702CL) <= p_16) | l_1783)), 0)) , p_14)) || l_1922)) > p_16)) <= 0x12L)) == p_14)) , (-10L)) | 0xE98CFE25A6104EA5LL)))), p_16));
                }
                (*l_2057) ^= ((*p_17) = ((((safe_mul_func_uint16_t_u_u((g_1390[g_114] , ((*l_2056) = (safe_sub_func_uint8_t_u_u((((safe_mod_func_uint16_t_u_u((++(*l_1752)), (7L || ((~g_1958[g_114]) | (safe_div_func_int16_t_s_s(g_33[g_114][(g_114 + 2)], 0xDC00L)))))) || (l_2051 != (**g_850))) || ((g_1958[g_114] <= (((safe_lshift_func_uint8_t_u_s(((l_2054 != l_2055) && g_1617[1]), 3)) ^ p_14) > p_16)) != 0x49L)), 0xDCL)))), 8UL)) , (void*)0) != (void*)0) && 9UL));
                if ((safe_sub_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((0x6D01L != (safe_mod_func_int32_t_s_s((safe_add_func_uint16_t_u_u(1UL, (safe_mul_func_uint8_t_u_u(((+((0UL && (*g_1132)) & l_2069)) == (safe_lshift_func_int16_t_s_u((&g_1112 == ((*l_2073) = l_2072)), 5))), ((*l_2057) || (((((l_2074 = &g_1132) != &l_2075) && (*l_2057)) , (*g_1827)) != l_2075)))))), 4294967287UL))) >= 1UL), (-1L))), l_1925[0])))
                { /* block id: 964 */
                    int8_t l_2087 = 5L;
                    int32_t l_2089 = 3L;
                    int32_t l_2090 = 9L;
                    uint64_t l_2091[1][5];
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 5; j++)
                            l_2091[i][j] = 0x5ABFDD06AE7EDC9FLL;
                    }
                    for (g_134 = 0; (g_134 <= 8); g_134 += 1)
                    { /* block id: 967 */
                        int32_t *l_2076 = (void*)0;
                        int32_t *l_2077 = &l_1783;
                        int32_t *l_2078 = &g_534.f1;
                        int32_t *l_2079 = (void*)0;
                        int32_t *l_2080 = &g_41;
                        int32_t *l_2081 = &l_1871;
                        int32_t *l_2082 = (void*)0;
                        int32_t *l_2083[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        l_2091[0][2]++;
                    }
                }
                else
                { /* block id: 970 */
                    int32_t **l_2094 = (void*)0;
                    int32_t **l_2095 = (void*)0;
                    int32_t **l_2096 = &l_1784;
                    for (l_2069 = 0; (l_2069 <= 8); l_2069 += 1)
                    { /* block id: 973 */
                        (*l_2057) |= l_2036;
                    }
                    for (g_1329 = 0; g_1329 < 3; g_1329 += 1)
                    {
                        l_1925[g_1329] = 0UL;
                    }
                    (*p_17) ^= (((*l_2096) = p_17) != p_17);
                }
                (*p_17) |= (-10L);
            }
            (*p_15) &= (*p_17);
            if (l_1812)
            { /* block id: 983 */
                uint32_t l_2123 = 6UL;
                for (g_1424.f5 = 0; (g_1424.f5 >= 0); g_1424.f5 -= 1)
                { /* block id: 986 */
                    uint8_t l_2097 = 0x2AL;
                    int32_t l_2119[4][5][3] = {{{(-1L),1L,1L},{1L,0x30B5D2B4L,0x21603F5CL},{(-1L),0x30B5D2B4L,(-1L)},{(-4L),1L,0x21603F5CL},{(-4L),(-4L),1L}},{{(-1L),1L,1L},{1L,0x30B5D2B4L,0x21603F5CL},{(-1L),0x30B5D2B4L,(-1L)},{(-4L),1L,0x21603F5CL},{(-4L),(-4L),1L}},{{(-1L),1L,1L},{1L,0x30B5D2B4L,0x21603F5CL},{(-1L),0x30B5D2B4L,(-1L)},{(-4L),1L,0x21603F5CL},{(-4L),(-4L),1L}},{{(-1L),1L,1L},{1L,0x30B5D2B4L,0x21603F5CL},{(-1L),0x30B5D2B4L,(-1L)},{(-4L),1L,0x21603F5CL},{(-4L),(-4L),1L}}};
                    int i, j, k;
                    for (l_2084 = 0; (l_2084 >= 0); l_2084 -= 1)
                    { /* block id: 989 */
                        uint32_t l_2107 = 0UL;
                        int32_t *l_2114 = &g_54;
                        int32_t *l_2115 = (void*)0;
                        int32_t *l_2116 = &l_2086;
                        int32_t *l_2117 = &g_54;
                        int32_t *l_2118[4] = {&g_1424.f1,&g_1424.f1,&g_1424.f1,&g_1424.f1};
                        int i, j, k;
                        l_2097--;
                        (*p_15) &= (safe_sub_func_int64_t_s_s(p_14, (safe_mod_func_int64_t_s_s(((+((((1L < (l_2107 , (((((l_1812 , l_2108[3]) == (void*)0) || ((safe_mul_func_uint8_t_u_u((**g_1827), (safe_mod_func_int8_t_s_s(((**g_832) && ((void*)0 == &g_666[0][3])), p_16)))) || l_2088)) , p_16) != p_16))) , p_16) ^ p_14) != p_14)) >= p_16), p_14))));
                        l_2123--;
                    }
                    (*p_17) = (+(((safe_rshift_func_uint8_t_u_u(l_2123, 2)) , (~((((safe_unary_minus_func_uint16_t_u((safe_div_func_int16_t_s_s(l_2119[0][0][1], l_2123)))) == (*g_1831)) , (safe_add_func_int32_t_s_s(((*p_15) = l_1770), (*p_17)))) < (l_1922 , ((*l_1752) = 0xE043L))))) , (((0x62L ^ p_16) && (-5L)) <= 0UL)));
                }
                if (l_2121)
                    break;
            }
            else
            { /* block id: 999 */
                for (p_16 = 0; (p_16 <= 9); p_16++)
                { /* block id: 1002 */
                    uint32_t ***l_2141 = &g_397[1][4][0];
                    const uint32_t ***l_2142 = &g_203;
                    uint16_t l_2151 = 5UL;
                    int32_t *l_2152 = &l_2086;
                    int32_t *l_2153[8][7] = {{&l_2121,&l_2085[0],&l_2121,&g_2137.f1,(void*)0,(void*)0,&g_2137.f1},{&l_2086,&l_2084,&l_2086,&g_41,(void*)0,(void*)0,&g_41},{&l_2121,&l_2085[0],&l_2121,&g_2137.f1,(void*)0,(void*)0,&g_2137.f1},{&l_2086,&l_2084,&l_2086,&g_41,(void*)0,(void*)0,&g_41},{&l_2121,&l_2085[0],&l_2121,&g_2137.f1,(void*)0,(void*)0,&g_2137.f1},{&l_2086,&l_2084,&l_2086,&g_41,(void*)0,(void*)0,&g_41},{&l_2121,&l_2085[0],&l_2121,&g_2137.f1,(void*)0,(void*)0,&g_2137.f1},{&l_2086,&l_2084,&l_2086,&g_41,(void*)0,(void*)0,&g_41}};
                    int i, j;
                    (*p_17) ^= ((g_2137 , 8L) >= (((void*)0 != l_2138[1][4][4]) > ((safe_mod_func_int8_t_s_s(((((l_2141 == ((**g_1525) = l_2142)) & (**g_846)) != (safe_add_func_uint8_t_u_u(0xEEL, ((((safe_sub_func_uint32_t_u_u((~((*p_15) &= ((((((((((safe_unary_minus_func_int64_t_s((l_2084 <= p_14))) || (*g_1132)) >= 0x1DAC35D4L) , &l_2051) == l_2149[1]) > 0xDBFD3A7943BC249FLL) >= 0xED8BL) & g_965[0].f2) & g_2150) != l_2086))), l_1812)) || l_2151) || l_1925[0]) == l_1922)))) , 0L), 0xD4L)) , 0x4A2F0A0BL)));
                    --l_2154;
                }
            }
        }
    }
    return (**g_1910);
}


/* ------------------------------------------ */
/* 
 * reads : g_965.f2 g_98 g_534.f1 g_134 g_411 g_832 g_833 g_1609 g_850 g_846 g_307 g_305 g_308 g_1617 g_1622 g_1132 g_665 g_666 g_534.f5 g_1639 g_1300 g_1301 g_1112 g_1525 g_1526 g_1663 g_1389 g_1390 g_660 g_1111 g_117 g_642 g_1418 g_1700
 * writes: g_965.f2 g_98 g_534.f1 g_134 g_238 g_195 g_1617 g_1622 g_1160.f2 g_1424.f5 g_54 g_411 g_642 g_1418 g_534.f5 g_1465 g_33 g_308
 */
static int64_t  func_18(const int8_t  p_19, uint32_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t * p_23)
{ /* block id: 711 */
    int32_t *l_1599 = (void*)0;
    int32_t l_1600 = (-8L);
    int32_t *l_1601[4][8] = {{(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1},{(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1},{(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1},{(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1,(void*)0,&g_1390[5].f1}};
    uint16_t l_1602 = 0UL;
    int8_t l_1659[1];
    int16_t l_1660 = 9L;
    int32_t **l_1683 = &g_1459;
    int32_t l_1705[7][6] = {{(-10L),(-8L),9L,0xDCDE082BL,9L,(-8L)},{(-10L),(-8L),9L,0xDCDE082BL,0x8A9E70A3L,0x147449A6L},{9L,0x147449A6L,0x8A9E70A3L,(-8L),0x8A9E70A3L,0x147449A6L},{9L,0x147449A6L,0x8A9E70A3L,(-8L),0x8A9E70A3L,0x147449A6L},{9L,0x147449A6L,0x8A9E70A3L,(-8L),0x8A9E70A3L,0x147449A6L},{9L,0x147449A6L,0x8A9E70A3L,(-8L),0x8A9E70A3L,0x147449A6L},{9L,0x147449A6L,0x8A9E70A3L,(-8L),0x8A9E70A3L,0x147449A6L}};
    int i, j;
    for (i = 0; i < 1; i++)
        l_1659[i] = 0xBBL;
    (*p_23) ^= 1L;
    l_1602++;
    for (g_98 = 0; (g_98 != 48); g_98++)
    { /* block id: 716 */
        int32_t l_1614 = 0x68DB871AL;
        int32_t l_1636 = (-3L);
        struct S0 *l_1638 = &g_965[0];
        for (g_534.f1 = 0; (g_534.f1 <= 3); g_534.f1 += 1)
        { /* block id: 719 */
            int32_t *l_1608 = (void*)0;
            int32_t *l_1637 = &g_1160.f1;
            for (g_134 = 0; (g_134 <= 0); g_134 += 1)
            { /* block id: 722 */
                int64_t l_1618 = 0x487CC847FBD6F2B9LL;
                g_238[5][0] = p_23;
                for (l_1600 = 0; (l_1600 >= 0); l_1600 -= 1)
                { /* block id: 726 */
                    int32_t **l_1607 = &g_238[2][1];
                    int i, j, k;
                    (*l_1607) = (void*)0;
                    if (g_411[g_134][(g_534.f1 + 1)][(l_1600 + 1)])
                    { /* block id: 728 */
                        int i, j, k;
                        return g_411[(g_134 + 3)][g_534.f1][(g_134 + 1)];
                    }
                    else
                    { /* block id: 730 */
                        uint64_t *l_1616 = &g_1617[2];
                        uint64_t *l_1619 = (void*)0;
                        uint64_t *l_1620 = (void*)0;
                        uint64_t *l_1621 = &g_1622[2];
                        int32_t l_1625 = 0x57904FFAL;
                        int i, j, k;
                        (*p_23) = (((((**g_832) = (l_1608 == p_23)) < (g_1609 , ((*l_1621) ^= (safe_add_func_uint64_t_u_u(((*l_1616) ^= ((0x1CBD785BL != (safe_add_func_uint32_t_u_u(p_21, l_1614))) == (safe_unary_minus_func_int16_t_s((***g_850))))), l_1618))))) == p_21) || 0UL);
                        if (l_1614)
                            break;
                        l_1636 = (((safe_add_func_int8_t_s_s((0UL >= ((l_1625 = p_21) > (((safe_mod_func_uint64_t_u_u(((p_21 && ((*g_1132) != (safe_mod_func_int8_t_s_s(((((((*p_23) = (*p_23)) && g_411[g_134][(g_534.f1 + 1)][(l_1600 + 1)]) , (((0L | (safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u(p_22, ((safe_mod_func_int32_t_s_s(1L, 0x1A581993L)) != p_19))), p_20))) & l_1614) <= 4L)) ^ p_20) & 0UL), l_1618)))) | 0L), 0xC561072DCE93D20ALL)) , (**g_665)) , p_19))), p_21)) , &g_1531[0]) != &g_1531[g_134]);
                    }
                    if ((*p_23))
                        continue;
                }
                l_1637 = p_23;
                l_1638 = l_1638;
            }
            for (g_1160.f2 = 0; (g_1160.f2 <= 0); g_1160.f2 += 1)
            { /* block id: 747 */
                (*g_1639) = &l_1600;
            }
        }
        return (**g_665);
    }
    for (g_98 = 0; (g_98 <= 0); g_98 += 1)
    { /* block id: 755 */
        int32_t l_1640[10][2][6] = {{{1L,0x4552B6A4L,0x4216815AL,0xFB14C508L,(-8L),0xCD5D811EL},{1L,(-1L),1L,0x2A3D8D25L,0xECE3A67CL,0x2A3D8D25L}},{{0x90CDA57CL,0xFB14C508L,0x90CDA57CL,0x3600189DL,0x4216815AL,(-8L)},{(-8L),0x016C07F9L,0xCF529714L,0x3425EA62L,0x8D0EDAB9L,(-1L)}},{{0x016C07F9L,0x4216815AL,1L,0x3425EA62L,4L,0x3600189DL},{(-8L),1L,0xECE3A67CL,0x3600189DL,0x3600189DL,0xECE3A67CL}},{{0x90CDA57CL,0x90CDA57CL,0x6F8F62D2L,0x2A3D8D25L,0x2DFCCC87L,0x016C07F9L},{1L,0xCF529714L,0x2DFCCC87L,0xFB14C508L,1L,0x6F8F62D2L}},{{1L,1L,0x2DFCCC87L,0xECE3A67CL,0x90CDA57CL,0x016C07F9L},{0xCD5D811EL,0xECE3A67CL,0x6F8F62D2L,0x8D0EDAB9L,0x6F8F62D2L,0xECE3A67CL}},{{0x8D0EDAB9L,0x6F8F62D2L,0xECE3A67CL,0xCD5D811EL,(-1L),0x3600189DL},{0xECE3A67CL,0x2DFCCC87L,1L,1L,0xFB14C508L,(-1L)}},{{0xFB14C508L,0x2DFCCC87L,0xCF529714L,1L,(-1L),(-8L)},{0x2A3D8D25L,0x6F8F62D2L,0x90CDA57CL,0x90CDA57CL,0x6F8F62D2L,0x2A3D8D25L}},{{0x3600189DL,0xECE3A67CL,1L,(-8L),0x90CDA57CL,0xCD5D811EL},{0x3425EA62L,1L,0x4216815AL,0x016C07F9L,1L,0xCF529714L}},{{0x3425EA62L,0xCF529714L,0x016C07F9L,(-8L),0x2DFCCC87L,1L},{0x3600189DL,0x90CDA57CL,0xFB14C508L,0x90CDA57CL,0x3600189DL,0x4216815AL}},{{0x2A3D8D25L,1L,(-1L),1L,4L,4L},{0xFB14C508L,0x4216815AL,0x4552B6A4L,1L,0x8D0EDAB9L,4L}}};
        uint32_t **** const l_1661 = (void*)0;
        int32_t l_1684 = 1L;
        uint64_t l_1710 = 0x12A6CBDF873F70A2LL;
        int16_t l_1725 = 0xBBE4L;
        uint32_t l_1746 = 1UL;
        struct S0 *l_1747 = &g_1390[5];
        int i, j, k;
        (*p_23) = (*p_23);
        if ((*p_23))
            continue;
        if (l_1640[6][1][2])
            break;
        for (g_1424.f5 = 0; (g_1424.f5 >= 0); g_1424.f5 -= 1)
        { /* block id: 761 */
            uint64_t l_1644 = 18446744073709551612UL;
            uint16_t l_1685 = 1UL;
            const int64_t l_1707 = 0x847293495CF97187LL;
            uint32_t **l_1748 = &g_1516;
            int i;
            if (((+(*p_23)) , ((safe_sub_func_int64_t_s_s(l_1644, (((*g_1300) == (l_1644 , (*g_1300))) , ((((safe_sub_func_uint16_t_u_u((safe_div_func_uint32_t_u_u(((*g_1112) ^ (*g_1132)), (safe_rshift_func_uint16_t_u_u(((((safe_sub_func_int32_t_s_s(((safe_sub_func_int8_t_s_s((safe_mod_func_int32_t_s_s(l_1640[6][1][4], (safe_mod_func_int32_t_s_s((*p_23), l_1644)))), (*g_1132))) <= 0x8C574817L), p_22)) & 0x56585AADL) & l_1659[0]) != p_19), p_19)))), p_20)) , l_1660) ^ p_21) & 0xA4L)))) == 65535UL)))
            { /* block id: 762 */
                (*p_23) |= (l_1661 != (*g_1525));
            }
            else
            { /* block id: 764 */
                uint64_t l_1666[1][4] = {{0x3B07ADE072A4021DLL,0x3B07ADE072A4021DLL,0x3B07ADE072A4021DLL,0x3B07ADE072A4021DLL}};
                int i, j;
                if ((*p_23))
                    break;
                for (g_54 = 0; (g_54 >= 0); g_54 -= 1)
                { /* block id: 768 */
                    (*g_1663) = p_23;
                    (*p_23) ^= 0x05B6A967L;
                }
                l_1666[0][1] &= ((*p_23) = (p_19 , (safe_lshift_func_int8_t_s_u((*g_1132), 5))));
            }
            for (l_1644 = 0; (l_1644 <= 0); l_1644 += 1)
            { /* block id: 777 */
                int16_t l_1668 = 1L;
                int32_t * const *l_1680 = &g_525;
                int32_t * const **l_1681 = &l_1680;
                int32_t **l_1682 = &g_525;
                int i, j, k;
                l_1684 = (((~p_21) >= l_1668) , ((+(((safe_mod_func_uint8_t_u_u((((*g_1132) |= ((*p_23) | (safe_lshift_func_int16_t_s_u(((safe_mod_func_uint64_t_u_u(((**g_832) = ((l_1640[9][1][4] = ((*g_1389) , l_1668)) & 0x5AD9348FL)), ((((l_1644 <= (((safe_mul_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((((*l_1681) = l_1680) == (l_1683 = ((&p_20 == l_1601[2][3]) , l_1682))), p_22)), p_21)) == p_21) ^ 0x5794B647L)) < 0x66L) < l_1644) & g_660))) , p_19), p_19)))) < (**g_1111)), g_117)) , p_19) , (-1L))) , 0L));
                l_1640[6][1][2] &= ((*p_23) = (*p_23));
                (*p_23) ^= l_1685;
                for (g_642 = 0; (g_642 >= 0); g_642 -= 1)
                { /* block id: 789 */
                    uint16_t *l_1694 = &l_1685;
                    uint32_t l_1699 = 4294967290UL;
                    uint8_t *l_1706 = &g_1465;
                    uint8_t *l_1708 = &g_33[5][7];
                    int32_t l_1709 = 0x20FC3F0CL;
                    for (g_1418 = 0; (g_1418 <= 0); g_1418 += 1)
                    { /* block id: 792 */
                        (*p_23) |= 0x1CEF92ADL;
                    }
                    l_1709 &= (((p_20 <= ((safe_lshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u((l_1684 &= ((*l_1708) = ((((safe_sub_func_int64_t_s_s(((**g_665) = p_22), 0UL)) || (safe_div_func_uint16_t_u_u(((*l_1694) |= 0x0881L), (safe_lshift_func_uint8_t_u_s(3UL, 4))))) == (p_22 ^ (((*l_1706) = (safe_div_func_uint64_t_u_u(((l_1699 ^ (((*p_23) = (g_1700 , (((++(*g_1112)) > ((safe_div_func_int64_t_s_s(((l_1644 >= l_1699) <= (*g_1132)), 18446744073709551615UL)) , p_19)) || p_22))) > p_22)) , l_1699), l_1705[2][1]))) & 0x72L))) | l_1707))), l_1668)), 12)) , p_21)) , l_1640[1][0][5]) >= p_20);
                    for (g_134 = 0; (g_134 <= 0); g_134 += 1)
                    { /* block id: 805 */
                        ++l_1710;
                        (*p_23) ^= (safe_rshift_func_int8_t_s_u(0x07L, 1));
                    }
                }
            }
            for (g_308 = 0; (g_308 >= 0); g_308 -= 1)
            { /* block id: 813 */
                int8_t ** const l_1734[6][8][4] = {{{&g_1132,(void*)0,&g_1132,&g_1132},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_1132,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,&g_1132},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_1132},{&g_1132,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0},{(void*)0,&g_1132,(void*)0,&g_1132}},{{(void*)0,&g_1132,(void*)0,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132}},{{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0},{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,(void*)0,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,(void*)0,&g_1132}},{{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0},{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,(void*)0,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0}},{{&g_1132,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,(void*)0,&g_1132},{(void*)0,&g_1132,&g_1132,&g_1132},{&g_1132,(void*)0,&g_1132,&g_1132},{&g_1132,&g_1132,&g_1132,(void*)0},{&g_1132,&g_1132,&g_1132,(void*)0}}};
                int32_t l_1745[6][2];
                int i, j, k;
                for (i = 0; i < 6; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_1745[i][j] = (-9L);
                }
                l_1745[2][1] = (l_1684 ^= (safe_div_func_int64_t_s_s((safe_div_func_int64_t_s_s((((safe_sub_func_uint64_t_u_u(l_1644, p_20)) ^ (safe_lshift_func_int8_t_s_u((*g_1132), 5))) || ((((*g_1132) = (((((((l_1725 || ((safe_mod_func_uint64_t_u_u(((**g_832) = (safe_sub_func_int64_t_s_s(((safe_add_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u((l_1734[4][7][0] != &g_1132), (((*p_23) = (safe_lshift_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(((((safe_sub_func_uint32_t_u_u(0x5B099CABL, l_1710)) > ((safe_mod_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(0xE5870B96L, 0x4AAB054AL)), 0xDCL)) & l_1745[1][1])) | 4294967290UL) == 1L), (*g_1132))), l_1745[0][0]))) || p_22))) || 0UL), l_1746)) ^ p_21), p_20))), l_1745[1][1])) > l_1685)) < (***g_850)) == p_20) , 0x1F18CA73B854B9FFLL) , (void*)0) != l_1747) , 0xEEL)) , &g_1516) == l_1748)), 0xB4947B1F3F0C6524LL)), p_19)));
            }
        }
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_1132 g_832 g_833 g_195 g_41 g_160 g_388
 * writes: g_411 g_525 g_41 g_160
 */
static uint16_t  func_34(int32_t * const  p_35, uint32_t  p_36, int8_t  p_37, int32_t * p_38, const uint64_t  p_39)
{ /* block id: 525 */
    int16_t l_1211 = 0x2167L;
    int32_t l_1212[5][4] = {{0x4C5B123AL,(-4L),(-4L),0x4C5B123AL},{0x09F770A6L,(-4L),(-1L),(-4L)},{(-4L),0xB1DDBBF4L,(-1L),(-1L)},{0x09F770A6L,0x09F770A6L,(-4L),(-1L)},{0x4C5B123AL,0xB1DDBBF4L,0x4C5B123AL,(-4L)}};
    uint8_t **l_1217[8][2] = {{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112},{&g_1112,&g_1112}};
    int32_t *l_1226 = &g_41;
    int16_t ***l_1268 = (void*)0;
    int32_t l_1415 = (-5L);
    int16_t l_1416[7][9][4] = {{{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL}},{{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L}},{{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L}},{{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L}},{{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL}},{{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L}},{{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L},{0x052DL,0x721AL,(-1L),1L},{(-1L),1L,(-1L),0x721AL},{0x052DL,0x78E0L,(-1L),9L},{(-1L),9L,(-1L),0x78E0L}}};
    struct S0 *l_1421 = &g_1422;
    uint64_t *l_1431 = &g_195;
    uint64_t l_1583 = 18446744073709551615UL;
    uint64_t l_1594[4];
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1594[i] = 0UL;
    l_1212[4][2] |= l_1211;
    if (((safe_lshift_func_int8_t_s_s(((*g_1132) = l_1212[1][2]), 4)) , (safe_div_func_int8_t_s_s(((l_1217[7][1] == ((safe_lshift_func_uint16_t_u_u(p_36, (((safe_add_func_uint16_t_u_u(l_1212[4][2], 65527UL)) , (**g_832)) || (~l_1212[4][1])))) , l_1217[7][1])) >= (!0UL)), p_37))))
    { /* block id: 528 */
        int32_t **l_1225 = &g_525;
        (*p_38) &= (~(((*l_1225) = p_38) != &g_114));
    }
    else
    { /* block id: 531 */
        int32_t *l_1229 = &g_54;
        uint32_t l_1297 = 0xD5C6D8A9L;
        uint16_t * const l_1360 = &g_1361;
        uint16_t * const *l_1359[8][2] = {{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360},{&l_1360,&l_1360}};
        uint64_t *l_1363 = &g_195;
        int32_t l_1409 = (-1L);
        int32_t l_1411 = 0xD2401E6AL;
        int8_t l_1412 = 0x13L;
        int32_t l_1413 = 7L;
        int32_t l_1414[6] = {1L,1L,0x3A9F797EL,1L,1L,0x3A9F797EL};
        int32_t l_1417 = 0xA20AEB76L;
        int16_t l_1430 = 0xD48EL;
        const uint32_t l_1462[4] = {0x589E186AL,0x589E186AL,0x589E186AL,0x589E186AL};
        uint64_t l_1484[9][1][7] = {{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}},{{0xCA918E0259148F49LL,0xB06066DB05D7E669LL,1UL,1UL,0xB06066DB05D7E669LL,0xCA918E0259148F49LL,0xFC87EC0A1F60D83DLL}}};
        uint16_t l_1513 = 0x9887L;
        int32_t l_1544 = 0x37656AD3L;
        const uint32_t l_1562[3][10][8] = {{{0UL,0xCE2F5D82L,0UL,18446744073709551609UL,0UL,18446744073709551615UL,0xA15201F4L,0xD32BCC76L},{18446744073709551610UL,0x054B4E21L,0x900FA26EL,0x5D32959DL,0x054B4E21L,0xD9772063L,18446744073709551615UL,18446744073709551615UL},{0UL,18446744073709551615UL,0xE0400A78L,0x2DF9DE8FL,0xA15201F4L,0x04AA2876L,18446744073709551608UL,0UL},{0xAE88CE72L,0x49FD5852L,1UL,0xD9B43229L,1UL,0x49FD5852L,0xAE88CE72L,0UL},{0x054B4E21L,0UL,18446744073709551615UL,0x5D32959DL,18446744073709551609UL,18446744073709551610UL,1UL,1UL},{18446744073709551614UL,18446744073709551608UL,0xC5D90E2EL,0x900FA26EL,0UL,0xC5D90E2EL,0xD9772063L,0x89E0F234L},{0xCE2F5D82L,18446744073709551614UL,0UL,1UL,0x3C87C95AL,0xD9772063L,0xCB3A1BEFL,0x5A59473DL},{0x2DF9DE8FL,0xD32BCC76L,18446744073709551609UL,18446744073709551608UL,1UL,18446744073709551610UL,0x04AA2876L,0xD32BCC76L},{0xFF109647L,0x89E0F234L,0x5A59473DL,18446744073709551610UL,0xCE2F5D82L,0xC5D90E2EL,0x3C87C95AL,0x04AA2876L},{0xD32BCC76L,0xD9772063L,0x900FA26EL,0xE0400A78L,0xFF109647L,0xFF109647L,0xE0400A78L,0x900FA26EL}},{{0xE0400A78L,0xE0400A78L,0xD47AFC95L,0x780950D1L,0x49FD5852L,0x7B7EF785L,0x04AA2876L,0x2DF9DE8FL},{0x0A8EE112L,18446744073709551615UL,0x139B9550L,0xF1C37964L,0xCB3A1BEFL,0x900FA26EL,0UL,0x2DF9DE8FL},{18446744073709551615UL,0x5A59473DL,0UL,0x780950D1L,0x0B557EA8L,18446744073709551615UL,18446744073709551608UL,0x900FA26EL},{0UL,0xCE2F5D82L,0x054B4E21L,0xE0400A78L,0x04AA2876L,18446744073709551615UL,1UL,0x04AA2876L},{18446744073709551610UL,0xCB3A1BEFL,0UL,18446744073709551610UL,1UL,0x3C87C95AL,0xF1C37964L,0xD32BCC76L},{18446744073709551615UL,0x05157E62L,0x3C87C95AL,18446744073709551608UL,0UL,0x5A59473DL,0xD32BCC76L,0x5A59473DL},{0x49FD5852L,1UL,0xD9B43229L,1UL,0x49FD5852L,0xAE88CE72L,0UL,0x89E0F234L},{0x3C87C95AL,0xCB3A1BEFL,0x0A8EE112L,0x900FA26EL,18446744073709551606UL,0x0B557EA8L,0x05157E62L,1UL},{0xD32BCC76L,18446744073709551615UL,0x0A8EE112L,0x49FD5852L,18446744073709551615UL,18446744073709551615UL,0UL,0xFF109647L},{18446744073709551606UL,18446744073709551606UL,0xD9B43229L,0x89E0F234L,1UL,0x5D32959DL,0xD32BCC76L,0xE0400A78L}},{{0xF1C37964L,18446744073709551615UL,0x3C87C95AL,18446744073709551614UL,0xE0400A78L,0UL,0xF1C37964L,18446744073709551606UL},{0xCE2F5D82L,0x3C87C95AL,0UL,0x49FD5852L,0x900FA26EL,0xFF109647L,1UL,0x05157E62L},{0x89E0F234L,18446744073709551608UL,0x054B4E21L,0UL,0UL,0x054B4E21L,18446744073709551608UL,0x89E0F234L},{18446744073709551615UL,0x89E0F234L,0UL,0x05157E62L,0xE0400A78L,0xD9772063L,0UL,18446744073709551606UL},{0x2DF9DE8FL,18446744073709551615UL,0x139B9550L,18446744073709551608UL,0x05157E62L,0xD9772063L,0x04AA2876L,18446744073709551615UL},{18446744073709551606UL,0x89E0F234L,0xD47AFC95L,0UL,0xCE2F5D82L,0x054B4E21L,0xE0400A78L,0x04AA2876L},{18446744073709551615UL,18446744073709551608UL,0x900FA26EL,0x3C87C95AL,18446744073709551606UL,0xFF109647L,0x3C87C95AL,0UL},{0xE0400A78L,0x3C87C95AL,0x5A59473DL,0x780950D1L,0x0A8EE112L,0UL,0x04AA2876L,0xF1C37964L},{0x49FD5852L,18446744073709551615UL,18446744073709551609UL,0x2DF9DE8FL,0xCB3A1BEFL,0x49FD5852L,0x139B9550L,18446744073709551614UL},{18446744073709551615UL,0xD9772063L,18446744073709551615UL,6UL,0x5A59473DL,0UL,0xA15201F4L,0x0A8EE112L}}};
        int32_t *l_1586 = &l_1417;
        int32_t *l_1587 = (void*)0;
        int32_t *l_1588 = (void*)0;
        int32_t *l_1589 = &l_1544;
        int32_t *l_1590 = &l_1413;
        int32_t *l_1591 = &g_1422.f1;
        int32_t *l_1592[3][2][2] = {{{&g_965[0].f1,&g_965[0].f1},{&g_965[0].f1,&g_965[0].f1}},{{&g_965[0].f1,&g_965[0].f1},{&g_965[0].f1,&g_965[0].f1}},{{&g_965[0].f1,&g_965[0].f1},{&g_965[0].f1,&g_965[0].f1}}};
        int8_t l_1593[5][9] = {{(-1L),0x98L,0xF4L,0x98L,(-1L),(-1L),0x98L,0xF4L,0x98L},{1L,2L,1L,0L,0x7DL,0x13L,0x7DL,0L,1L},{(-1L),(-1L),0x98L,0xF4L,0x98L,(-1L),(-1L),0x98L,0xF4L},{0xB2L,2L,0xB2L,0x13L,1L,0xA7L,0x7DL,0xA7L,1L},{(-1L),0x98L,0x98L,(-1L),1L,(-1L),0x98L,0x98L,(-1L)}};
        int i, j, k;
        l_1226 = p_35;
        for (g_160 = 0; (g_160 <= 4); g_160 += 1)
        { /* block id: 535 */
            uint16_t l_1248 = 0x5A8BL;
            int32_t l_1299 = 0xC01A050BL;
            uint16_t * const l_1358[6][7] = {{&l_1248,&g_259[3],&g_233,&g_259[5],&g_259[4],&g_259[4],&g_259[5]},{&g_259[5],&l_1248,&g_259[5],&g_259[3],&g_259[5],&g_259[5],&l_1248},{&g_259[5],&l_1248,&g_117,&g_259[5],&l_1248,(void*)0,&l_1248},{(void*)0,&g_259[3],&g_259[3],(void*)0,&l_1248,&g_259[5],&g_259[5]},{&g_259[4],&l_1248,&g_259[3],&g_233,&g_259[5],&g_259[4],&g_259[4]},{&l_1248,&g_259[5],&g_117,&g_259[5],&l_1248,&g_259[1],&g_259[5]}};
            uint16_t * const *l_1357 = &l_1358[2][6];
            int32_t *l_1410[5];
            int16_t l_1426 = 0xEAA3L;
            int32_t l_1543 = 1L;
            uint8_t l_1548 = 255UL;
            uint32_t l_1580 = 0x08736A47L;
            int i, j;
            for (i = 0; i < 5; i++)
                l_1410[i] = &g_54;
        }
        l_1594[2]++;
    }
    return g_388[5];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_42(uint32_t  p_43, int8_t  p_44, int32_t * p_45, const int32_t * p_46, int32_t * p_47)
{ /* block id: 521 */
    int32_t *l_1207[5] = {&g_534.f1,&g_534.f1,&g_534.f1,&g_534.f1,&g_534.f1};
    uint64_t l_1208 = 0UL;
    int i;
    l_1208--;
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_54 g_57 g_41 g_98 g_134 g_114 g_160 g_96 g_198 g_117 g_203 g_195 g_204 g_259 g_307 g_305 g_308 g_325 g_837.f2 g_534.f1 g_665 g_666 g_534.f5 g_846 g_493 g_965.f1 g_832 g_833 g_642 g_965.f5 g_388 g_850 g_1111 g_1112 g_1132 g_411 g_765
 * writes: g_98 g_54 g_57 g_114 g_117 g_134 g_160 g_165 g_195 g_198 g_233 g_238 g_259 g_305 g_307 g_325 g_308 g_765 g_642 g_204 g_534.f1 g_534.f5 g_1111 g_1132 g_411 g_846
 */
static uint16_t  func_49(uint32_t  p_50)
{ /* block id: 3 */
    int64_t l_74 = 0xBE831782E4D72E8FLL;
    int32_t *l_88 = (void*)0;
    int32_t l_89 = (-3L);
    int64_t *l_90 = (void*)0;
    int64_t *l_91 = &l_74;
    uint32_t l_92[2];
    uint32_t *l_111 = (void*)0;
    uint32_t *l_112 = &g_57;
    uint32_t *l_113 = &l_92[1];
    int32_t l_178[8][9] = {{0L,0x6ACBFB42L,0xB0C0EAC7L,0x6ACBFB42L,0L,0L,0L,0L,0x6ACBFB42L},{1L,0x2281F5AFL,1L,1L,0x5C62FD6AL,0x5C62FD6AL,1L,1L,0x2281F5AFL},{0x24F2121EL,0xDFDE9DF1L,0L,0xB0C0EAC7L,0xB0C0EAC7L,0L,0xDFDE9DF1L,0x24F2121EL,0xDFDE9DF1L},{0xA89C1657L,(-9L),1L,1L,(-9L),0xA89C1657L,0x5C62FD6AL,0xA89C1657L,(-9L)},{0x6ACBFB42L,0xDFDE9DF1L,0xDFDE9DF1L,0x6ACBFB42L,0x24F2121EL,0L,0x24F2121EL,0x6ACBFB42L,0xDFDE9DF1L},{0x2281F5AFL,0x2281F5AFL,0x5C62FD6AL,(-9L),0x9225C9EAL,(-9L),0x5C62FD6AL,0x2281F5AFL,0x2281F5AFL},{0xDFDE9DF1L,0x6ACBFB42L,0x24F2121EL,0L,0x24F2121EL,0x6ACBFB42L,0xDFDE9DF1L,0xDFDE9DF1L,0x6ACBFB42L},{(-9L),0xA89C1657L,0x5C62FD6AL,0xA89C1657L,(-9L),1L,1L,(-9L),0xA89C1657L}};
    int16_t l_196[5];
    uint64_t l_306 = 0x22B9E36AF4DD5B9CLL;
    uint16_t *l_313 = (void*)0;
    uint32_t ** const l_335[3][9][1] = {{{&l_113},{(void*)0},{&l_113},{&l_112},{&l_113},{(void*)0},{&l_113},{&l_112},{&l_113}},{{(void*)0},{&l_113},{&l_112},{&l_113},{(void*)0},{&l_113},{&l_112},{&l_113},{(void*)0}},{{&l_113},{&l_112},{&l_113},{(void*)0},{&l_113},{&l_112},{&l_113},{(void*)0},{&l_113}}};
    uint32_t *l_366 = &l_92[0];
    int32_t l_410 = 0x2E83A3F0L;
    uint16_t l_413 = 0x3B81L;
    uint8_t l_563[7] = {0xB6L,0xB6L,0xA8L,0xB6L,0xB6L,0xA8L,0xB6L};
    int64_t **l_668 = &g_666[0][3];
    int32_t l_733 = 0x0EDE54D4L;
    int16_t **l_794 = &g_307;
    uint32_t ****l_1056[8][4][8] = {{{&g_396[0][0][4],&g_396[0][0][4],&g_396[3][0][5],&g_396[4][2][5],&g_396[4][1][1],&g_396[2][2][1],&g_396[4][0][4],&g_396[5][2][5]},{&g_396[0][0][4],&g_396[4][2][5],(void*)0,&g_396[0][0][4],(void*)0,(void*)0,(void*)0,&g_396[0][0][4]},{(void*)0,(void*)0,(void*)0,&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],(void*)0,&g_396[5][1][1]},{&g_396[0][0][4],(void*)0,&g_396[0][0][4],&g_396[0][0][4],(void*)0,&g_396[1][1][4],&g_396[6][1][0],&g_396[4][0][2]}},{{&g_396[0][0][4],&g_396[5][1][1],&g_396[2][1][0],&g_396[5][2][5],&g_396[2][0][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[6][2][3]},{&g_396[1][1][4],&g_396[3][2][2],&g_396[6][1][3],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][0][2],&g_396[4][0][2],&g_396[0][0][4]},{&g_396[6][1][3],&g_396[0][0][4],&g_396[0][0][4],&g_396[6][1][3],&g_396[0][0][4],&g_396[0][0][4],&g_396[1][1][4],&g_396[2][1][2]},{(void*)0,&g_396[5][2][5],&g_396[0][0][4],&g_396[0][0][4],&g_396[5][1][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[2][2][1]}},{{&g_396[1][2][2],&g_396[5][2][5],(void*)0,&g_396[2][2][2],&g_396[4][0][2],&g_396[0][0][4],&g_396[5][1][3],&g_396[0][0][4]},{&g_396[0][1][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[1][0][3],&g_396[5][1][1],&g_396[4][0][2],&g_396[0][0][4],&g_396[4][1][1]},{&g_396[0][0][4],&g_396[3][2][2],&g_396[2][0][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4]},{&g_396[4][2][4],&g_396[5][1][1],&g_396[0][0][4],(void*)0,&g_396[4][0][4],&g_396[1][1][4],&g_396[2][1][0],&g_396[0][0][4]}},{{&g_396[0][0][4],(void*)0,&g_396[0][0][4],&g_396[5][1][1],&g_396[6][2][3],&g_396[0][0][4],&g_396[3][2][2],&g_396[2][1][0]},{(void*)0,(void*)0,&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],(void*)0,(void*)0,&g_396[6][0][4]},{(void*)0,&g_396[4][2][5],&g_396[4][2][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[2][2][1],&g_396[0][0][4],&g_396[2][0][1]},{&g_396[0][0][4],&g_396[0][0][4],&g_396[2][1][2],(void*)0,&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4]}},{{(void*)0,&g_396[0][0][4],&g_396[5][1][1],&g_396[2][0][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][2][6],&g_396[5][1][3]},{(void*)0,&g_396[0][0][4],&g_396[0][0][4],&g_396[1][2][5],&g_396[6][2][3],&g_396[0][0][4],&g_396[0][0][4],(void*)0},{&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][0][4],&g_396[0][0][4],&g_396[0][0][4],&g_396[1][0][3]},{&g_396[4][2][4],&g_396[2][1][2],(void*)0,&g_396[6][1][0],&g_396[0][0][4],(void*)0,&g_396[0][0][4],&g_396[0][0][4]}},{{&g_396[0][0][4],&g_396[0][0][4],&g_396[2][2][2],&g_396[5][1][1],&g_396[6][0][4],&g_396[6][0][4],&g_396[5][1][1],&g_396[2][2][2]},{&g_396[4][2][5],&g_396[4][2][5],&g_396[0][0][4],&g_396[6][0][6],&g_396[0][0][4],&g_396[6][1][3],&g_396[0][0][4],&g_396[0][0][4]},{&g_396[1][2][5],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][1][3],&g_396[2][2][2],(void*)0,&g_396[6][1][0],&g_396[0][0][4]},{&g_396[0][0][4],&g_396[2][1][0],&g_396[0][0][4],&g_396[6][0][6],&g_396[3][2][2],&g_396[0][0][4],(void*)0,&g_396[2][2][2]}},{{&g_396[0][0][4],&g_396[2][1][2],&g_396[4][1][1],&g_396[5][1][1],&g_396[0][0][4],&g_396[3][0][5],&g_396[0][0][4],&g_396[0][0][4]},{&g_396[0][0][4],&g_396[4][1][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][2][4],&g_396[0][0][4],&g_396[3][2][2],&g_396[5][2][5]},{&g_396[6][0][6],&g_396[3][0][5],(void*)0,&g_396[0][0][4],&g_396[2][0][1],&g_396[0][0][4],&g_396[0][0][4],&g_396[4][1][3]},{(void*)0,&g_396[4][2][6],&g_396[0][0][4],(void*)0,&g_396[0][0][4],&g_396[1][2][2],&g_396[0][0][4],&g_396[1][2][2]}},{{&g_396[4][0][2],&g_396[4][2][4],(void*)0,&g_396[4][2][4],&g_396[4][0][2],&g_396[5][2][5],&g_396[6][1][3],(void*)0},{&g_396[3][0][5],&g_396[4][0][4],&g_396[1][2][2],&g_396[4][0][2],(void*)0,&g_396[2][2][1],&g_396[2][2][2],&g_396[4][2][4]},{&g_396[0][0][4],&g_396[5][1][1],&g_396[1][2][2],&g_396[0][0][4],&g_396[0][0][4],(void*)0,&g_396[6][1][3],&g_396[0][0][4]},{(void*)0,&g_396[0][0][4],(void*)0,(void*)0,(void*)0,&g_396[0][0][4],&g_396[0][0][4],&g_396[0][0][4]}}};
    int64_t l_1083 = (-1L);
    uint32_t l_1084[3][2];
    uint8_t *l_1107[5][4][8] = {{{&g_33[5][7],(void*)0,&g_134,&g_134,(void*)0,&g_765,&g_33[5][7],&g_134},{(void*)0,&g_134,&g_765,&l_563[4],&g_134,&g_765,&g_134,&g_765},{&g_33[0][4],(void*)0,(void*)0,(void*)0,&g_33[0][4],&g_33[0][4],&l_563[4],&g_33[0][4]},{&g_765,&g_134,&g_33[5][7],&g_765,(void*)0,&g_134,&g_134,(void*)0}},{{&g_134,&g_134,&g_33[5][7],&l_563[4],&g_765,&g_765,&l_563[4],&g_33[5][7]},{(void*)0,(void*)0,(void*)0,&g_33[0][4],&g_33[5][1],&g_33[3][2],&g_134,(void*)0},{&g_134,&g_134,&g_765,&g_765,&g_134,&g_765,&g_33[5][7],(void*)0},{&g_134,&g_765,&g_134,&g_33[0][4],&g_134,&g_765,&g_134,&g_33[5][7]}},{{(void*)0,&g_33[0][4],&g_33[0][4],&l_563[4],&g_33[0][4],&l_563[0],&g_134,(void*)0},{&g_134,(void*)0,&g_765,&g_765,&g_33[0][4],&g_765,&g_765,&g_33[0][4]},{(void*)0,&g_33[5][7],&g_33[5][7],(void*)0,&g_134,&g_134,(void*)0,&g_765},{&g_134,(void*)0,&g_765,&l_563[4],&g_134,(void*)0,&g_765,&g_134}},{{&l_563[3],&l_563[4],&l_563[4],&g_33[0][4],&g_765,&g_33[0][4],&l_563[4],&l_563[4]},{&l_563[4],&g_33[3][2],(void*)0,&g_134,&l_563[4],(void*)0,&g_134,&l_563[3]},{&g_134,&g_33[5][7],&g_33[5][1],&g_765,&l_563[4],&g_134,&g_134,&g_134},{&g_765,&g_765,(void*)0,(void*)0,&g_765,&g_765,&l_563[4],&g_33[5][7]}},{{&g_765,&g_765,&l_563[4],&g_33[5][7],&g_33[0][4],(void*)0,&g_765,&g_33[0][4]},{&g_33[5][7],&g_134,&g_33[0][4],&g_33[5][7],&l_563[4],&l_563[4],&l_563[4],&g_33[5][7]},{&g_33[3][2],&l_563[4],&g_33[3][2],(void*)0,&g_134,&l_563[4],(void*)0,&g_134},{&l_563[4],&l_563[3],&l_563[4],&g_765,&l_563[0],&g_33[0][4],&g_134,&l_563[3]}}};
    uint8_t **l_1106 = &l_1107[2][2][3];
    struct S0 *l_1159 = &g_1160;
    struct S0 ** const l_1158 = &l_1159;
    int16_t l_1163 = 1L;
    uint16_t l_1200[9][2] = {{0x395DL,0x2B8DL},{0x395DL,0x395DL},{0x395DL,0x2B8DL},{0x395DL,0x395DL},{0x395DL,0x2B8DL},{0x395DL,0x395DL},{0x395DL,0x2B8DL},{0x395DL,0x395DL},{0x395DL,0x2B8DL}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_92[i] = 0x82D785ABL;
    for (i = 0; i < 5; i++)
        l_196[i] = 0x08B9L;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
            l_1084[i][j] = 1UL;
    }
lbl_365:
    g_54 = (safe_sub_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(0x5532CF2DL, g_33[5][5])), func_62(((safe_mod_func_int8_t_s_s((g_54 > (safe_rshift_func_int16_t_s_s(((safe_lshift_func_int16_t_s_s(l_74, 8)) , (((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(g_57, 0)), (((*l_91) = (safe_lshift_func_int8_t_s_s((((safe_div_func_uint64_t_u_u(((p_50 ^ g_41) , (((safe_lshift_func_uint8_t_u_u(g_33[5][7], (safe_div_func_int32_t_s_s((l_89 ^= (((!g_57) == g_33[5][7]) < 5L)), g_41)))) ^ p_50) < 1L)), g_57)) <= (-10L)) >= p_50), g_57))) > 0xE8548DC0916D66C2LL))) < g_57) != l_92[1])), 7))), p_50)) , 0x266FL), g_33[5][7], &l_92[0], g_33[0][0], l_92[1])));
    if ((safe_div_func_uint32_t_u_u(p_50, (((safe_mul_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((7UL || (g_117 = ((safe_rshift_func_int8_t_s_u((g_114 = (((*l_113) = ((*l_112) = 0x4C769F55L)) && ((void*)0 != &g_41))), (((((void*)0 != &l_89) || (g_33[5][7] , ((safe_div_func_uint8_t_u_u(0x68L, p_50)) > l_74))) | p_50) >= (-9L)))) != g_33[0][1]))) >= 0x4E6C56EA18D89BD0LL), 1L)), (-1L))) < g_54) & 0x2242FA0DL))))
    { /* block id: 14 */
        int16_t l_135 = 0x24E1L;
        int32_t l_136 = 2L;
        uint8_t *l_139 = &g_33[0][3];
        uint8_t *l_140 = &g_33[0][4];
        uint32_t l_190 = 0x42C4FA89L;
        const uint32_t **l_262 = &g_204[2][0];
        const int32_t * const *l_362 = (void*)0;
        int32_t *l_364 = &l_178[0][4];
        uint32_t *l_367 = &g_160;
        uint32_t *l_368 = &g_160;
        uint64_t *l_375 = &g_195;
        int32_t *l_382 = (void*)0;
        int32_t *l_383 = &g_96;
        int32_t l_399[8][4] = {{0x8E21C28BL,0xEB784779L,0x8E21C28BL,(-7L)},{0x8E21C28BL,(-7L),(-7L),0x8E21C28BL},{0x18430E8CL,(-7L),0x7F163C79L,(-7L)},{(-7L),0xEB784779L,0x7F163C79L,0x7F163C79L},{0x18430E8CL,0x18430E8CL,(-7L),0x7F163C79L},{0x8E21C28BL,0xEB784779L,0x8E21C28BL,(-7L)},{0x8E21C28BL,(-7L),(-7L),0x8E21C28BL},{0x18430E8CL,(-7L),0x7F163C79L,(-7L)}};
        int32_t l_403 = 0L;
        int32_t l_406 = 0xC4CEC06EL;
        int32_t l_408 = 0x31476D01L;
        int32_t l_492 = 1L;
        int64_t l_530 = (-1L);
        struct S0 *l_533 = &g_534;
        int16_t l_636[9][3][2] = {{{1L,(-10L)},{9L,1L},{0L,0L}},{{(-5L),1L},{9L,0x39F6L},{1L,(-10L)}},{{(-1L),1L},{0L,(-5L)},{0L,1L}},{{(-1L),(-10L)},{1L,0x39F6L},{9L,1L}},{{(-5L),0L},{0L,1L},{9L,(-10L)}},{{1L,(-10L)},{9L,1L},{0L,0L}},{{(-5L),1L},{9L,0x39F6L},{1L,(-10L)}},{{(-1L),1L},{0L,(-5L)},{0L,1L}},{{(-1L),(-10L)},{1L,0x39F6L},{9L,1L}}};
        uint32_t ****l_648[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t l_658 = (-1L);
        int32_t l_659[4];
        int64_t **l_687 = &g_666[0][2];
        uint16_t *l_708 = &g_259[5];
        int32_t l_752 = 0x0BD6704BL;
        uint8_t l_758[6][5] = {{246UL,246UL,0UL,246UL,246UL},{0x45L,0xE6L,0x45L,0x45L,0xE6L},{246UL,247UL,247UL,246UL,0UL},{0x45L,0x45L,0xE6L,0x45L,0x45L},{0UL,247UL,0UL,0UL,247UL},{0x45L,6UL,6UL,0x45L,6UL}};
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_659[i] = 5L;
        for (g_114 = 25; (g_114 != (-16)); g_114 = safe_sub_func_uint64_t_u_u(g_114, 2))
        { /* block id: 17 */
            uint32_t l_120 = 0xC145740FL;
            uint32_t l_121 = 0x2621F7AEL;
            uint16_t l_141 = 65535UL;
            int32_t l_158[5][3][5] = {{{0xAF5BD103L,0xA856C88DL,0x048C16D0L,(-6L),0x048C16D0L},{0L,0L,0x5B3D2223L,0x2DCCA579L,1L},{0xAF5BD103L,0x1E146C4CL,1L,0x4804F9BFL,0x4804F9BFL}},{{0x2DCCA579L,0xDE492F91L,0x2DCCA579L,0x03C77F6BL,0xF6D5B129L},{1L,0x1E146C4CL,0xAF5BD103L,(-4L),(-1L)},{0x5B3D2223L,0L,0L,0x5B3D2223L,0x2DCCA579L}},{{0x048C16D0L,0xA856C88DL,0xAF5BD103L,(-1L),0x1E146C4CL},{(-5L),0x3F0835FFL,0x2DCCA579L,0x3F0835FFL,(-5L)},{0xA856C88DL,(-4L),1L,(-1L),1L}},{{(-1L),(-10L),0x5B3D2223L,0x5B3D2223L,(-10L)},{0x4804F9BFL,0xAF5BD103L,0x048C16D0L,(-4L),1L},{0x3F0835FFL,0x5B3D2223L,(-5L),0x03C77F6BL,(-5L)}},{{1L,1L,0xA856C88DL,0x4804F9BFL,0x1E146C4CL},{0x3F0835FFL,1L,(-1L),0x2DCCA579L,0x2DCCA579L},{0x4804F9BFL,0x2B244983L,0x4804F9BFL,(-6L),(-1L)}}};
            uint32_t **l_200 = &l_112;
            uint32_t l_302[3][8];
            uint32_t l_322 = 0UL;
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 8; j++)
                    l_302[i][j] = 0xB462A510L;
            }
            if (l_120)
            { /* block id: 18 */
                uint32_t l_130 = 18446744073709551612UL;
                uint8_t *l_133[2];
                int32_t *l_142 = (void*)0;
                int32_t *l_143 = &l_89;
                int i;
                for (i = 0; i < 2; i++)
                    l_133[i] = &g_134;
                if (((*l_143) = (((18446744073709551613UL >= (l_121 == ((safe_add_func_uint32_t_u_u(p_50, (0UL | ((safe_add_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((safe_lshift_func_int16_t_s_s((l_130 & (safe_add_func_int16_t_s_s(((p_50 , 0x65BCB3CAL) , (p_50 <= (((g_134++) | (l_139 != l_140)) | 5UL))), l_141))), 4)) & p_50), p_50)), 0UL)) & 0L)))) <= l_135))) <= l_120) > p_50)))
                { /* block id: 21 */
                    return g_114;
                }
                else
                { /* block id: 23 */
                    for (g_117 = (-9); (g_117 != 13); ++g_117)
                    { /* block id: 26 */
                        uint16_t l_146 = 5UL;
                        --l_146;
                        return p_50;
                    }
                }
                for (l_141 = 16; (l_141 <= 44); l_141++)
                { /* block id: 33 */
                    for (g_134 = (-28); (g_134 >= 1); g_134 = safe_add_func_uint32_t_u_u(g_134, 7))
                    { /* block id: 36 */
                        return g_54;
                    }
                }
            }
            else
            { /* block id: 40 */
                uint32_t l_179 = 0x8EAF9065L;
                uint8_t *l_194 = &g_134;
                int8_t *l_197 = &g_198[6];
                uint32_t **l_199 = &l_112;
                int32_t **l_201 = (void*)0;
                int32_t **l_202 = &l_88;
                for (l_89 = 0; (l_89 <= (-22)); --l_89)
                { /* block id: 43 */
                    int16_t l_159 = 0x8701L;
                    uint32_t *l_166 = &l_121;
                    uint8_t *l_169 = &g_33[5][7];
                    int32_t l_175 = 1L;
                    int32_t *l_176 = &l_158[2][0][1];
                    int32_t *l_177[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_177[i] = &g_54;
                    for (l_121 = (-6); (l_121 > 33); l_121 = safe_add_func_int8_t_s_s(l_121, 6))
                    { /* block id: 46 */
                        int32_t *l_157[2][5] = {{&g_41,&l_136,&l_136,&l_136,&g_41},{&g_41,&l_136,&l_136,&l_136,&g_41}};
                        uint32_t **l_167 = (void*)0;
                        uint32_t **l_168 = &l_111;
                        uint32_t *l_174 = &l_120;
                        int i, j;
                        g_160--;
                        g_54 = p_50;
                        g_54 = (safe_mod_func_uint8_t_u_u(((((((((g_165 = &g_98) != (((void*)0 == l_166) , ((*l_168) = &g_160))) < 9L) , g_54) <= (l_175 |= (l_169 != (((*l_174) = (safe_rshift_func_uint8_t_u_u(255UL, (safe_sub_func_int32_t_s_s(((5L && g_33[5][7]) < p_50), l_158[2][0][1]))))) , (void*)0)))) , l_120) < g_54) & g_33[5][7]), g_33[1][7]));
                    }
                    l_179--;
                }
                l_178[0][7] ^= (safe_sub_func_int8_t_s_s(p_50, (g_160 != ((g_117 = ((l_135 , ((((((safe_sub_func_int8_t_s_s(((*l_197) ^= (safe_mod_func_uint32_t_u_u((l_190 || (((g_195 = (safe_mod_func_int16_t_s_s((1UL && ((0xCA140F99L & ((*l_113) = (((((((*l_194) = ((safe_unary_minus_func_uint32_t_u((g_57 > (((&l_89 != (l_158[4][2][4] , (void*)0)) & 0UL) , p_50)))) == p_50)) , (-1L)) || g_114) ^ p_50) == 0L) == p_50))) | 0UL)), g_96))) , (void*)0) == l_194)), l_196[0]))), p_50)) , (-1L)) <= 1L) > 0x1AC59717L) , l_199) != l_200)) && g_54)) || p_50))));
                (*l_202) = &l_158[2][0][1];
            }
            for (g_117 = 0; (g_117 <= 6); g_117 += 1)
            { /* block id: 67 */
                const uint32_t **l_206 = &g_204[3][1];
                int32_t l_215 = 0x09440013L;
                uint32_t **l_332 = &l_112;
                int i;
                for (p_50 = 0; (p_50 <= 7); p_50 += 1)
                { /* block id: 70 */
                    const uint32_t ***l_205[5];
                    uint64_t *l_216 = &g_195;
                    int16_t *l_219 = &l_196[0];
                    uint8_t *l_236[6][7][2] = {{{(void*)0,(void*)0},{&g_134,(void*)0},{(void*)0,&g_33[5][7]},{&g_33[1][6],&g_33[1][4]},{&g_33[0][3],&g_33[0][3]},{&g_33[5][7],&g_134},{&g_134,(void*)0}},{{&g_33[4][3],(void*)0},{&g_33[5][7],&g_33[4][3]},{&g_33[5][7],(void*)0},{&g_33[5][7],&g_33[4][3]},{&g_33[5][7],(void*)0},{&g_33[4][3],(void*)0},{&g_134,&g_134}},{{&g_33[5][7],&g_33[0][3]},{&g_33[0][3],&g_33[1][4]},{&g_33[1][6],&g_33[5][7]},{(void*)0,(void*)0},{&g_134,(void*)0},{(void*)0,&g_33[5][7]},{&g_33[1][6],&g_33[1][4]}},{{&g_33[0][3],&g_33[0][3]},{&g_33[5][7],&g_134},{&g_134,(void*)0},{&g_33[4][3],(void*)0},{&g_33[5][7],&g_33[4][3]},{&g_33[5][7],(void*)0},{&g_33[5][7],&g_33[4][3]}},{{&g_33[5][7],(void*)0},{&g_33[4][3],(void*)0},{&g_134,&g_134},{&g_33[5][7],&g_33[0][3]},{&g_33[0][3],&g_33[1][4]},{&g_33[1][6],&g_33[5][7]},{(void*)0,(void*)0}},{{&g_134,(void*)0},{(void*)0,&g_33[5][7]},{&g_33[1][6],&g_33[1][4]},{&g_33[0][3],&g_33[0][3]},{&g_33[5][7],&g_134},{&g_134,(void*)0},{&g_33[4][3],(void*)0}}};
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_205[i] = &g_203;
                    if (((g_198[g_117] , ((((g_198[g_117] , (((((l_206 = g_203) != &g_165) , g_98) >= ((*l_219) |= (safe_sub_func_uint64_t_u_u(((safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((safe_add_func_int32_t_s_s(l_215, 0x68F5B907L)), l_215)), (++(*l_216)))) & p_50), 0L)))) != p_50)) <= g_98) >= p_50) || p_50)) <= 0x4F61B098L))
                    { /* block id: 74 */
                        int32_t *l_230 = &l_158[2][0][1];
                        uint16_t *l_231 = &l_141;
                        uint16_t *l_232 = &g_233;
                        int32_t **l_237 = (void*)0;
                        int i, j;
                        l_178[(g_117 + 1)][g_117] |= (((-1L) && (safe_div_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u((l_136 = ((-1L) && (safe_div_func_uint32_t_u_u(((safe_add_func_uint64_t_u_u((g_41 & ((*l_232) = (g_195 , ((*l_231) = ((void*)0 == l_230))))), ((safe_rshift_func_int8_t_s_u(((((l_236[5][0][1] == &g_33[5][1]) > (g_204[5][1] != g_204[2][0])) && 9UL) && (*l_230)), g_195)) == (-6L)))) | g_198[g_117]), (-1L))))), p_50)) && l_141), p_50)) , g_198[1]), 0x2399L))) != l_158[1][2][0]);
                        if (p_50)
                            break;
                        g_238[2][1] = &l_136;
                    }
                    else
                    { /* block id: 81 */
                        uint64_t *l_257 = (void*)0;
                        uint64_t *l_258 = (void*)0;
                        uint16_t *l_281 = &g_259[4];
                        int32_t **l_282 = &g_238[2][1];
                        int i, j;
                        l_178[g_117][g_117] = (safe_unary_minus_func_uint8_t_u((((safe_lshift_func_uint16_t_u_s((((((safe_rshift_func_int16_t_s_s((&l_141 != (void*)0), 2)) & (safe_div_func_uint64_t_u_u((((safe_lshift_func_int8_t_s_u((g_195 , g_195), (((*l_113) &= ((safe_div_func_uint16_t_u_u(p_50, (p_50 || (((&g_203 == (void*)0) & (!(safe_sub_func_int64_t_s_s(((safe_mod_func_int16_t_s_s((safe_mul_func_int16_t_s_s((((g_259[5]++) <= (0x94L || p_50)) < p_50), g_117)), 0xD354L)) != p_50), g_57)))) > g_198[6])))) && 0x64L)) || 4294967295UL))) , (void*)0) != l_262), p_50))) ^ g_160) != 0L) , 0x9876L), l_215)) | 0x2478DB60L) ^ l_136)));
                        l_178[p_50][g_117] = (safe_div_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((g_57 == (((safe_mul_func_uint8_t_u_u(l_178[g_117][g_117], ((safe_add_func_uint16_t_u_u(((g_198[g_117] = ((safe_add_func_uint8_t_u_u(((safe_unary_minus_func_uint8_t_u((((safe_sub_func_int32_t_s_s(p_50, (safe_unary_minus_func_int16_t_s((p_50 != (safe_mod_func_int8_t_s_s(l_190, g_57))))))) , l_158[2][0][1]) < 0L))) & ((((*l_281) = (safe_div_func_uint64_t_u_u((p_50 , 0xEFCB6989C77487F0LL), 0xF87E3A3C11C24DCELL))) >= l_92[0]) ^ l_135)), g_160)) ^ p_50)) , g_259[1]), (-10L))) >= p_50))) , 65528UL) || g_41)), p_50)), g_41));
                        (*l_282) = &g_54;
                    }
                    for (l_120 = 0; (l_120 <= 1); l_120 += 1)
                    { /* block id: 92 */
                        uint16_t *l_287 = &g_259[5];
                        uint8_t **l_295 = &l_236[5][0][1];
                        int32_t l_296 = (-10L);
                        int16_t *l_303 = &l_135;
                        int16_t *l_304 = &g_305[0];
                        int32_t **l_309 = &l_88;
                        int32_t **l_310 = &g_238[2][0];
                        int i, j, k;
                        l_158[(l_120 + 2)][l_120][l_120] = ((g_307 = ((safe_div_func_uint8_t_u_u((safe_div_func_int16_t_s_s((((*l_287)++) || ((*l_219) &= (&l_92[l_120] != &l_92[l_120]))), l_92[l_120])), (0x7DL && (safe_mul_func_int8_t_s_s((0x7CL && (l_296 &= (safe_lshift_func_int16_t_s_u((!(l_139 == ((*l_295) = (void*)0))), 8)))), (l_200 == (((safe_add_func_uint8_t_u_u((((+((*l_304) = ((*l_303) |= ((((safe_lshift_func_int16_t_s_s(l_302[2][7], 10)) && 0L) && p_50) >= 0L)))) != g_198[g_117]) , p_50), g_114)) & l_306) , &g_204[1][1]))))))) , &g_305[0])) == &g_308);
                        (*l_310) = ((*l_309) = &l_215);
                        (*l_310) = &g_41;
                    }
                }
                if (g_198[g_117])
                    continue;
                if (l_89)
                    continue;
                for (l_74 = 1; (l_74 <= 7); l_74 += 1)
                { /* block id: 110 */
                    int32_t l_342 = 6L;
                    int i, j;
                    if ((l_178[g_117][(l_74 + 1)] = (8UL == (safe_add_func_uint16_t_u_u((l_158[4][1][3] = (l_313 != (void*)0)), (*g_307))))))
                    { /* block id: 113 */
                        g_238[2][1] = &g_54;
                        if (p_50)
                            break;
                    }
                    else
                    { /* block id: 116 */
                        uint16_t l_314 = 0x3C85L;
                        int64_t *l_323 = (void*)0;
                        int64_t *l_324 = &g_325;
                        int32_t *l_326 = &l_178[2][2];
                        (*l_326) = (0x3B589A2E28897AFALL | ((*l_324) &= (((((0x95L <= l_314) | ((((safe_add_func_uint8_t_u_u(l_190, (+l_178[g_117][(l_74 + 1)]))) , &g_33[5][5]) != &g_134) & (((l_158[2][0][1] |= (((safe_mod_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((((((p_50 == 0xEE27L) ^ 0UL) <= p_50) , l_178[g_117][(l_74 + 1)]) <= l_322) , l_215), 7L)) < l_135), 255UL)) || p_50) != g_198[g_117])) , g_198[4]) < 0xFEC25883E4B16275LL))) , g_98) & 9UL) > p_50)));
                    }
                    if (p_50)
                        break;
                    for (l_136 = 0; (l_136 <= 6); l_136 += 1)
                    { /* block id: 124 */
                        uint32_t ***l_333 = (void*)0;
                        uint32_t ***l_334 = &l_200;
                        int32_t *l_339 = (void*)0;
                        int32_t *l_340 = (void*)0;
                        int32_t *l_341 = &l_178[3][1];
                        int32_t *l_343 = &l_158[0][2][0];
                        int32_t **l_363[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_363[i] = &l_341;
                        (*l_343) |= (+(((((!g_98) > (((~((void*)0 != &g_165)) , (-1L)) | (safe_rshift_func_int16_t_s_s(((((*l_334) = l_332) == l_335[2][5][0]) == (!(*g_307))), 10)))) > (((g_305[0] != (((*l_341) = (safe_rshift_func_int8_t_s_u(0x15L, l_322))) && 1UL)) , g_134) != p_50)) & l_342) < l_136));
                        (*l_341) |= ((251UL == (safe_sub_func_uint64_t_u_u(((((safe_unary_minus_func_int16_t_s(((*g_307) = (((safe_mul_func_int16_t_s_s((((((p_50 >= ((((~((safe_mul_func_uint16_t_u_u((g_233 = (((safe_lshift_func_int16_t_s_u((safe_lshift_func_int16_t_s_u((((!1UL) > ((~g_114) > (g_134 , l_121))) && p_50), 7)), p_50)) ^ (safe_mod_func_int8_t_s_s((safe_mod_func_uint64_t_u_u(0x6E7CEAEE16C9F1E6LL, p_50)), p_50))) || 0xEE2D881AE1F2AC80LL)), 0xD9C8L)) ^ g_33[5][7])) <= p_50) , l_362) != &l_88)) , 0x5AD5DDD99CC41A13LL) , 0x832EL) | 0x07DBL) , g_198[g_117]), 65535UL)) && l_120) , 1L)))) >= p_50) | p_50) ^ g_259[3]), g_114))) >= l_342);
                        l_364 = &l_89;
                    }
                }
            }
            if (l_74)
                goto lbl_365;
            if (p_50)
                break;
        }
    }
    else
    { /* block id: 394 */
        uint8_t l_922 = 5UL;
        int16_t l_933[3];
        int32_t l_935 = 0xA9BB40B8L;
        uint32_t l_937 = 18446744073709551612UL;
        const uint8_t *l_941 = &g_942;
        const uint8_t **l_940 = &l_941;
        int64_t ***l_955[9] = {&l_668,&l_668,&l_668,&l_668,&l_668,&l_668,&l_668,&l_668,&l_668};
        uint16_t *l_956[1];
        uint32_t * const **l_1001 = (void*)0;
        uint32_t * const *** const l_1000 = &l_1001;
        uint64_t *l_1014 = &g_195;
        const int64_t l_1060 = 0x4B8F835BC5F33692LL;
        uint16_t l_1105[7];
        int64_t l_1110 = 0x58FA191B240F7E46LL;
        int16_t l_1172 = 0xEFA3L;
        uint64_t l_1178[8] = {18446744073709551615UL,18446744073709551609UL,18446744073709551615UL,18446744073709551609UL,18446744073709551615UL,18446744073709551609UL,18446744073709551615UL,18446744073709551609UL};
        int32_t l_1184[3];
        int i;
        for (i = 0; i < 3; i++)
            l_933[i] = 0xD068L;
        for (i = 0; i < 1; i++)
            l_956[i] = &g_117;
        for (i = 0; i < 7; i++)
            l_1105[i] = 65535UL;
        for (i = 0; i < 3; i++)
            l_1184[i] = 6L;
        for (g_765 = 0; (g_765 > 43); ++g_765)
        { /* block id: 397 */
            int32_t * const l_906 = (void*)0;
            int32_t *l_936[2][2] = {{&l_410,&l_410},{&l_410,&l_410}};
            int i, j;
            for (g_642 = 27; (g_642 >= (-25)); --g_642)
            { /* block id: 400 */
                int32_t **l_907 = &g_238[4][1];
                if (p_50)
                    break;
                (*l_907) = l_906;
                for (g_98 = 4; (g_98 >= 15); ++g_98)
                { /* block id: 405 */
                    uint8_t *l_914 = &l_563[4];
                    int32_t *l_917 = &l_178[1][1];
                    (*l_917) |= (p_50 > (safe_rshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_u(((++(*l_914)) ^ (g_195 | 0xDAL)), 2)), 11)));
                    if (((*l_917) = p_50))
                    { /* block id: 409 */
                        int8_t l_930[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_930[i] = (-1L);
                        l_410 = ((((safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_u(g_54, g_259[3])), l_922)) < ((~(safe_mod_func_int32_t_s_s(((((safe_sub_func_int64_t_s_s((safe_mul_func_int8_t_s_s(g_160, p_50)), (((p_50 | l_930[0]) , 0UL) <= (safe_mod_func_int32_t_s_s(1L, 0x8CA5863DL))))) , g_837.f2) > l_563[1]) <= p_50), l_933[2]))) | 0x8FL)) == p_50) | 0xE3L);
                        (*l_907) = &g_54;
                    }
                    else
                    { /* block id: 412 */
                        uint64_t l_934 = 18446744073709551615UL;
                        l_934 |= p_50;
                        if (l_934)
                            goto lbl_957;
                        (*l_917) ^= p_50;
                        (*l_907) = l_917;
                    }
                }
                if (p_50)
                    break;
            }
            for (l_733 = 0; l_733 < 7; l_733 += 1)
            {
                for (g_160 = 0; g_160 < 2; g_160 += 1)
                {
                    g_204[l_733][g_160] = &l_92[1];
                }
            }
            --l_937;
        }
lbl_957:
        l_935 |= ((((((-1L) ^ p_50) , &g_33[2][0]) != ((*l_940) = &g_33[5][7])) || (safe_mul_func_uint16_t_u_u((((safe_lshift_func_int8_t_s_u(0x69L, (g_534.f1 || ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((((((g_259[5] = (safe_mod_func_int64_t_s_s((safe_sub_func_int8_t_s_s(((void*)0 == l_955[3]), ((g_198[2] , 1UL) > (-10L)))), (**g_665)))) | 65526UL) && 65535UL) , (-2L)) && 4UL), (**g_846))), 1)) <= p_50)))) != 0x02L) < (**g_665)), p_50))) < l_922);
lbl_987:
        if (g_57)
            goto lbl_365;
        for (g_57 = 0; (g_57 >= 54); ++g_57)
        { /* block id: 430 */
            int32_t l_960 = 0x51BEE7ABL;
            int32_t *l_961 = &g_534.f1;
            struct S0 *l_964 = &g_965[0];
            uint8_t l_966 = 3UL;
            int32_t l_1008 = 0xE270F21FL;
            int16_t **l_1039 = &g_307;
            uint32_t l_1057 = 18446744073709551615UL;
            int32_t l_1089 = 0L;
            int32_t l_1090 = 0xA9C6CF90L;
            uint32_t l_1093 = 0x859FEDD5L;
            int64_t **l_1130 = &g_666[0][0];
            uint32_t l_1162 = 0x198786CDL;
            int64_t l_1187[8][9] = {{0L,3L,6L,3L,0L,3L,6L,3L,0L},{0xFE7991FDF539AC5CLL,0x4FDE3E2D78C820B7LL,0xAB7B581BEF165242LL,(-7L),(-7L),0xAB7B581BEF165242LL,0x4FDE3E2D78C820B7LL,0xFE7991FDF539AC5CLL,0xFE7991FDF539AC5CLL},{1L,3L,1L,(-9L),1L,3L,1L,(-9L),1L},{0xFE7991FDF539AC5CLL,(-7L),0x4FDE3E2D78C820B7LL,0x4FDE3E2D78C820B7LL,(-7L),0xFE7991FDF539AC5CLL,0xAB7B581BEF165242LL,0xAB7B581BEF165242LL,0xFE7991FDF539AC5CLL},{0L,(-9L),6L,(-9L),0L,(-9L),6L,(-9L),0L},{(-7L),0x4FDE3E2D78C820B7LL,0x4FDE3E2D78C820B7LL,(-7L),0xFE7991FDF539AC5CLL,0xAB7B581BEF165242LL,0xAB7B581BEF165242LL,0xFE7991FDF539AC5CLL,(-7L)},{1L,(-9L),1L,3L,1L,(-9L),1L,3L,1L},{(-7L),(-7L),0xAB7B581BEF165242LL,0x4FDE3E2D78C820B7LL,0xFE7991FDF539AC5CLL,0xFE7991FDF539AC5CLL,0x4FDE3E2D78C820B7LL,0xAB7B581BEF165242LL,(-7L)}};
            int32_t l_1198 = 0L;
            int32_t l_1199 = 0x6254880CL;
            int i, j;
            (*l_961) |= l_960;
            for (g_233 = 0; (g_233 <= 17); g_233++)
            { /* block id: 434 */
                l_964 = l_964;
                return (*l_961);
            }
            if ((l_966 <= (safe_mod_func_uint32_t_u_u(((*g_307) < ((((safe_lshift_func_int8_t_s_s(l_933[2], g_493[0][1])) , (safe_div_func_uint64_t_u_u(((safe_mod_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(0x45EAL, (-2L))) > 0x381688F9L), ((((safe_mul_func_uint16_t_u_u(g_837.f2, (((*l_91) &= (safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((~((safe_rshift_func_uint8_t_u_s(((safe_unary_minus_func_uint8_t_u((((*l_961) <= 0xEB89L) , p_50))) || l_935), g_965[0].f1)) & p_50)), (-1L))), 1UL))) & (-1L)))) != 18446744073709551613UL) | 18446744073709551615UL) , p_50))) == p_50), (**g_665)))) , (**g_665)) & p_50)), 0x2E6FE414L))))
            { /* block id: 439 */
                int32_t ** const *l_992 = (void*)0;
                uint32_t ****l_1002 = (void*)0;
                if (g_195)
                    goto lbl_987;
                if (l_937)
                { /* block id: 441 */
                    for (p_50 = 0; (p_50 <= 2); p_50 += 1)
                    { /* block id: 444 */
                        int i;
                        return l_933[p_50];
                    }
                    (*l_961) = (safe_add_func_uint64_t_u_u(((safe_div_func_int16_t_s_s(((void*)0 != l_992), 65535UL)) <= 255UL), p_50));
                }
                else
                { /* block id: 448 */
                    for (l_413 = 0; (l_413 > 6); l_413 = safe_add_func_uint64_t_u_u(l_413, 5))
                    { /* block id: 451 */
                        uint32_t *****l_1003 = &l_1002;
                        const int32_t l_1012[9] = {0L,(-4L),(-4L),0L,(-4L),(-4L),0L,(-4L),(-4L)};
                        int32_t *l_1013 = &l_935;
                        int i;
                        (*l_1013) = ((safe_mod_func_uint64_t_u_u((((**l_668) = (p_50 && ((~(*g_307)) == ((*l_961) = ((**g_832) = p_50))))) == (0x54051E63L == (0xCA740393L ^ (safe_rshift_func_uint8_t_u_s(((l_1000 == ((*l_1003) = l_1002)) && (safe_sub_func_int64_t_s_s((safe_div_func_int64_t_s_s((l_1008 != (+(~(((~0x025DDD8EFEBCE407LL) <= 0UL) != l_1012[3])))), p_50)), p_50))), g_642))))), 0x663A5436E7CDDB56LL)) == p_50);
                        (*l_1013) = (((*l_961) ^ ((void*)0 == l_1014)) & (((((--(**g_832)) > (safe_rshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u(0xEE9DL, (((**l_794) |= (&l_1014 == &l_1014)) , (((*l_1013) || (((*l_113) = 0x90D373DBL) , 0xE1L)) > 0x9E9B7832L)))), 4))) < 0xBC69L) & (*l_961)) , 0x6ECF9D9EFBAEBC60LL));
                        (*l_1013) = (safe_sub_func_uint16_t_u_u(((1L >= (safe_rshift_func_uint8_t_u_u((((((safe_mul_func_int8_t_s_s(0x07L, l_933[2])) >= ((safe_add_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(g_965[0].f5, p_50)), (**g_665))) != (safe_lshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((g_388[0] && (g_96 , ((safe_lshift_func_int16_t_s_s((safe_lshift_func_int8_t_s_s((p_50 != 4L), 1)), 7)) == 65533UL))) == 0x55L) & (*l_961)), 0xE6L)), 12)))) , l_1039) != (void*)0) != 0x2CB0L), 5))) > p_50), p_50));
                        return p_50;
                    }
                }
                (*l_961) = ((p_50 != (safe_mul_func_int8_t_s_s(p_50, 0UL))) >= 0x3C88L);
            }
            else
            { /* block id: 466 */
                uint16_t l_1085 = 65534UL;
                int32_t l_1091 = 0xDDDF7648L;
                int32_t l_1092 = 0x955044B2L;
                int64_t **l_1129 = &l_90;
                uint32_t *l_1145 = &l_1084[0][0];
                int32_t l_1188[3];
                int32_t **l_1203 = &g_238[1][1];
                int i;
                for (i = 0; i < 3; i++)
                    l_1188[i] = (-1L);
                if (((((((safe_div_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_u(((p_50 <= (safe_mod_func_int8_t_s_s(p_50, 8UL))) > ((***g_850) = (safe_mul_func_int16_t_s_s(p_50, (safe_add_func_uint64_t_u_u((*l_961), (((safe_rshift_func_uint8_t_u_s(p_50, 0)) , (safe_rshift_func_uint16_t_u_u((((void*)0 == l_1056[5][2][3]) <= l_933[2]), 5))) > g_305[0]))))))), 4)) , p_50), p_50)) != 0L) >= l_1057) , 4294967295UL) < l_935) || (**g_665)))
                { /* block id: 468 */
                    int32_t *l_1086 = &l_178[3][2];
                    int32_t *l_1087 = &l_733;
                    int32_t *l_1088[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    for (g_114 = 0; (g_114 < (-29)); g_114 = safe_sub_func_int16_t_s_s(g_114, 6))
                    { /* block id: 471 */
                        uint16_t **l_1073 = &l_313;
                        int32_t l_1080 = (-5L);
                        g_238[2][1] = &g_54;
                        if (p_50)
                            continue;
                        (*l_961) = (l_1060 ^ l_922);
                        l_935 |= (((safe_mod_func_uint8_t_u_u((((p_50 == ((**g_846) = (safe_div_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_u(g_305[0], 14)) , (safe_mul_func_int8_t_s_s(((p_50 > (safe_mul_func_int16_t_s_s((((((safe_rshift_func_uint16_t_u_s((((*l_1073) = (void*)0) != (void*)0), 13)) < ((safe_lshift_func_int16_t_s_s((safe_div_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((l_1080 , ((((1L | (((safe_mul_func_int16_t_s_s(p_50, (((void*)0 == &g_233) < l_1083))) && 0x8CL) , 0L)) , (void*)0) == (void*)0) & 1L)), g_33[5][7])), p_50)), 4)) != p_50)) | 0xB32AF807F48CACA6LL) < 0x67DDFDB51B1A83FBLL) ^ l_1084[1][1]), p_50))) ^ 0xB4B635CAL), l_933[2]))), l_1085)))) , g_305[0]) || g_308), (*l_961))) , 0x43EFL) >= (-1L));
                    }
                    l_1093++;
                }
                else
                { /* block id: 480 */
                    uint8_t * const **l_1113 = (void*)0;
                    uint8_t * const **l_1114 = &g_1111;
                    int32_t l_1115 = 0L;
                    int32_t l_1116 = 1L;
                    l_1116 |= (l_935 = (((***g_850) >= (safe_div_func_uint8_t_u_u((safe_unary_minus_func_int8_t_s(0x5FL)), (-1L)))) , ((((p_50++) <= (safe_mul_func_uint8_t_u_u((((*l_961) |= (((safe_add_func_uint8_t_u_u((l_1105[1] || ((((l_1106 == (((safe_mul_func_int8_t_s_s(l_1110, l_1085)) , l_1085) , ((*l_1114) = g_1111))) == 0L) | l_1085) && l_1115)), l_1115)) != l_933[1]) <= l_1115)) & (**g_832)), g_33[4][5]))) , &l_941) == (void*)0)));
                }
                for (l_1057 = 0; (l_1057 >= 19); ++l_1057)
                { /* block id: 489 */
                    int64_t **l_1131[6][8][5] = {{{&g_666[0][4],&g_666[0][4],&l_91,&g_666[0][4],&g_666[0][3]},{(void*)0,&l_91,&g_666[0][3],&g_666[0][3],&g_666[0][0]},{&g_666[0][4],&l_90,&g_666[0][3],&g_666[0][4],&g_666[0][3]},{&l_90,&g_666[0][2],&g_666[0][0],&l_90,&l_90},{(void*)0,&g_666[0][3],&l_90,&g_666[0][3],&l_90},{&l_91,&l_91,&l_90,(void*)0,&l_91},{&g_666[0][3],&g_666[0][3],&l_90,&g_666[0][0],&g_666[0][4]},{&g_666[0][4],&g_666[0][3],&g_666[0][2],&g_666[0][0],(void*)0}},{{(void*)0,&g_666[0][3],&g_666[0][3],&g_666[0][4],&g_666[0][2]},{&g_666[0][3],&l_91,&g_666[0][3],&l_91,(void*)0},{&g_666[0][3],&g_666[0][3],&g_666[0][4],&l_90,&g_666[0][3]},{(void*)0,&g_666[0][2],&g_666[0][2],&g_666[0][3],&g_666[0][4]},{&g_666[0][0],&l_90,(void*)0,&g_666[0][4],(void*)0},{&l_90,&l_91,&l_91,&g_666[0][3],&g_666[0][3]},{&g_666[0][2],&g_666[0][4],&g_666[0][4],&l_91,&g_666[0][3]},{&l_91,&g_666[0][4],&l_90,(void*)0,&g_666[0][3]}},{{&l_91,&l_90,&g_666[0][3],&g_666[0][3],&g_666[0][3]},{&l_90,&g_666[0][3],&g_666[0][0],(void*)0,&g_666[0][2]},{&g_666[0][4],&g_666[0][3],&g_666[0][3],&l_90,&l_91},{&g_666[0][4],(void*)0,&g_666[0][3],&l_91,&l_90},{&g_666[0][4],(void*)0,(void*)0,&g_666[0][3],&g_666[0][0]},{&g_666[0][3],&g_666[0][3],&l_91,&g_666[0][3],&g_666[0][3]},{&l_90,&l_91,(void*)0,&l_91,&g_666[0][4]},{(void*)0,&g_666[0][3],&l_90,&g_666[0][3],(void*)0}},{{(void*)0,&g_666[0][3],&g_666[0][3],&l_91,&g_666[0][4]},{&l_90,&g_666[0][3],&g_666[0][3],&g_666[0][0],&g_666[0][3]},{&g_666[0][4],&g_666[0][3],&l_90,(void*)0,&g_666[0][0]},{(void*)0,&g_666[0][0],&l_90,&g_666[0][3],&l_90},{&g_666[0][3],(void*)0,&g_666[0][3],&g_666[0][2],&l_91},{&l_91,&l_91,&l_90,&g_666[0][2],&g_666[0][2]},{&l_90,&g_666[0][3],&l_90,&l_91,&g_666[0][3]},{(void*)0,&g_666[0][0],&l_90,(void*)0,&l_90}},{{&l_91,(void*)0,&g_666[0][0],(void*)0,&g_666[0][5]},{&l_91,&g_666[0][0],&g_666[0][3],&l_91,(void*)0},{&l_90,&g_666[0][4],&g_666[0][3],&g_666[0][2],(void*)0},{&g_666[0][3],&g_666[0][3],&l_90,&g_666[0][2],(void*)0},{&g_666[0][4],&l_90,&g_666[0][4],&g_666[0][3],&l_90},{&g_666[0][3],&l_90,&l_90,(void*)0,(void*)0},{&g_666[0][0],&l_90,&g_666[0][0],&g_666[0][0],&l_90},{&g_666[0][3],&l_91,&g_666[0][4],&l_91,&l_91}},{{&l_90,&l_91,(void*)0,&g_666[0][3],&g_666[0][3]},{&l_90,&l_90,&g_666[0][4],&l_91,&g_666[0][0]},{&g_666[0][2],&l_91,&g_666[0][0],&g_666[0][3],&g_666[0][3]},{&l_91,(void*)0,&l_90,&g_666[0][3],&g_666[0][3]},{&g_666[0][3],(void*)0,&g_666[0][4],&l_91,&g_666[0][3]},{&g_666[0][3],(void*)0,&l_90,&l_90,&g_666[0][4]},{&l_90,&l_91,&g_666[0][3],(void*)0,&l_91},{(void*)0,&g_666[0][3],&g_666[0][3],&l_90,&l_90}}};
                    uint32_t *l_1146 = &g_98;
                    int32_t l_1153 = 8L;
                    uint16_t l_1161 = 1UL;
                    int32_t l_1185 = 0x24B4B21CL;
                    int32_t l_1186[2][1][5];
                    uint16_t l_1189 = 0x52C0L;
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 1; j++)
                        {
                            for (k = 0; k < 5; k++)
                                l_1186[i][j][k] = 0x96D4EC18L;
                        }
                    }
                    if ((safe_lshift_func_int16_t_s_s((0x56B61013F891B487LL >= (-1L)), (safe_mod_func_int32_t_s_s((safe_sub_func_int64_t_s_s(((safe_sub_func_int64_t_s_s(p_50, (safe_lshift_func_int16_t_s_s((((l_1130 = l_1129) != l_1131[0][5][1]) && g_259[5]), (((((((((&g_411[3][5][1] == (g_1132 = &g_411[3][5][1])) , (((-8L) || p_50) & 4L)) | 0x64BBL) || 0xCAD9E544L) > p_50) <= (*g_1112)) || (-1L)) || (*l_961)) || 0x2510EE8567FEAF0BLL))))) && 0xD8E6DF21L), 0L)), (-1L))))))
                    { /* block id: 492 */
                        int32_t **l_1133 = &g_238[2][1];
                        (*l_1133) = &l_935;
                        l_733 |= ((((safe_div_func_int16_t_s_s((~(safe_sub_func_int16_t_s_s((safe_div_func_int16_t_s_s(1L, (safe_mul_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(((l_1145 = &p_50) != l_1146), ((((safe_mod_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((((**l_668) = ((safe_mul_func_int16_t_s_s((**g_846), l_1153)) || (((p_50 & ((((((*g_1132) = l_1153) >= ((((p_50 < ((**g_1111) = (l_1158 != &l_964))) , l_1153) , 8L) || 0x8BF7L)) & 0x66D41496AE992849LL) , (*l_961)) >= 0xA22B8BD4L)) < l_1161) || l_935))) && l_1085), l_1162)), p_50)) && 2L) | p_50) || p_50))) | 0xA1EFL), (*l_961))))), 1UL))), 7L)) & l_922) || 0xEC33CD16A24945F6LL) , l_1163);
                        if (l_933[2])
                            continue;
                    }
                    else
                    { /* block id: 500 */
                        int64_t l_1164 = 0xC1B5F165519AA088LL;
                        return l_1164;
                    }
                    if (p_50)
                    { /* block id: 503 */
                        uint16_t *l_1181[1][1][7];
                        int32_t l_1182 = 1L;
                        int32_t *l_1183[5][9][5] = {{{&g_41,&g_41,(void*)0,&g_534.f1,(void*)0},{&g_41,(void*)0,&l_178[0][4],&g_1160.f1,(void*)0},{&l_178[0][4],&g_534.f1,&g_41,&l_733,(void*)0},{(void*)0,&l_1092,&l_1092,&l_1092,(void*)0},{&l_1089,(void*)0,&l_1089,&g_41,(void*)0},{&g_965[0].f1,&l_410,&g_41,(void*)0,(void*)0},{&g_54,&l_733,&g_54,(void*)0,(void*)0},{&l_1089,&g_965[0].f1,&l_178[7][2],(void*)0,(void*)0},{&l_1092,&l_1090,&l_410,&l_1090,&l_1092}},{{&g_1160.f1,&l_1090,&l_1153,&l_1091,(void*)0},{(void*)0,&l_1091,&g_1160.f1,(void*)0,&l_1092},{&l_410,(void*)0,(void*)0,&l_1090,(void*)0},{&g_534.f1,(void*)0,&l_1182,&g_534.f1,&l_1092},{(void*)0,(void*)0,&l_89,(void*)0,(void*)0},{(void*)0,&l_1091,&l_410,&l_1091,&l_1092},{(void*)0,&l_1091,&l_1091,&g_965[0].f1,(void*)0},{&g_41,&g_534.f1,&l_1092,&l_1091,&l_1092},{&l_1092,&g_965[0].f1,&l_178[7][2],(void*)0,(void*)0}},{{&l_1092,&l_1090,&l_410,&l_1090,&l_1092},{&g_1160.f1,&l_1090,&l_1153,&l_1091,(void*)0},{(void*)0,&l_1091,&g_1160.f1,(void*)0,&l_1092},{&l_410,(void*)0,(void*)0,&l_1090,(void*)0},{&g_534.f1,(void*)0,&l_1182,&g_534.f1,&l_1092},{(void*)0,(void*)0,&l_89,(void*)0,(void*)0},{(void*)0,&l_1091,&l_410,&l_1091,&l_1092},{(void*)0,&l_1091,&l_1091,&g_965[0].f1,(void*)0},{&g_41,&g_534.f1,&l_1092,&l_1091,&l_1092}},{{&l_1092,&g_965[0].f1,&l_178[7][2],(void*)0,(void*)0},{&l_1092,&l_1090,&l_410,&l_1090,&l_1092},{&g_1160.f1,&l_1090,&l_1153,&l_1091,(void*)0},{(void*)0,&l_1091,&g_1160.f1,(void*)0,&l_1092},{&l_410,(void*)0,(void*)0,&l_1090,(void*)0},{&g_534.f1,(void*)0,&l_1182,&g_534.f1,&l_1092},{(void*)0,(void*)0,&l_89,(void*)0,(void*)0},{(void*)0,&l_1091,&l_410,&l_1091,&l_1092},{(void*)0,&l_1091,&l_1091,&g_965[0].f1,(void*)0}},{{&g_41,&g_534.f1,&l_1092,&l_1091,&l_1092},{&l_1092,&g_965[0].f1,&l_178[7][2],(void*)0,(void*)0},{&l_1092,&l_1090,&l_410,&l_1090,&l_1092},{&g_1160.f1,&l_1090,&l_1153,&l_1091,(void*)0},{(void*)0,&l_1091,&g_1160.f1,(void*)0,&l_1092},{&l_410,(void*)0,(void*)0,&l_1090,(void*)0},{&g_534.f1,(void*)0,&l_1182,&g_534.f1,&l_1092},{(void*)0,(void*)0,&l_89,(void*)0,(void*)0},{(void*)0,&l_1091,&l_410,&l_1091,&l_1092}}};
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 1; j++)
                            {
                                for (k = 0; k < 7; k++)
                                    l_1181[i][j][k] = &g_117;
                            }
                        }
                        l_1178[5] |= (safe_mod_func_uint64_t_u_u((safe_add_func_int16_t_s_s((p_50 < ((((safe_mul_func_uint8_t_u_u(0xF4L, ((!l_1172) | (l_1153 | ((safe_div_func_uint32_t_u_u(0x90A6B65AL, (safe_mul_func_uint16_t_u_u(((~0x138E1EAB4C4AD47BLL) <= 0xB6L), ((0x6DL > (*l_961)) >= p_50))))) == p_50))))) >= l_1105[2]) && (*g_1132)) <= p_50)), l_1085)), l_1110));
                        l_1182 = (safe_add_func_uint8_t_u_u((&g_233 != l_1181[0][0][3]), p_50));
                        if (p_50)
                            continue;
                        ++l_1189;
                    }
                    else
                    { /* block id: 508 */
                        int32_t *l_1192 = &l_935;
                        int32_t *l_1193 = &g_54;
                        int32_t *l_1194 = &l_178[0][4];
                        int32_t *l_1195 = &l_178[0][4];
                        int32_t *l_1196 = &l_178[0][4];
                        int32_t *l_1197[6][6] = {{&l_178[0][4],&l_89,&l_1184[0],&g_965[0].f1,&l_89,&l_89},{&l_1089,&g_965[0].f1,&g_965[0].f1,&l_1089,&l_178[0][4],&l_1089},{&l_1089,&l_178[0][4],&l_1089,&g_965[0].f1,&g_965[0].f1,&l_1089},{&l_89,&l_89,&g_965[0].f1,&l_1184[0],&g_965[0].f1,&l_89},{&g_965[0].f1,&l_178[0][4],&l_1184[0],&l_1184[0],&l_178[0][4],&g_965[0].f1},{&l_89,&g_965[0].f1,&l_1184[0],&g_965[0].f1,&l_89,&l_89}};
                        int i, j;
                        if (p_50)
                            break;
                        l_1200[2][1]++;
                        (*l_961) ^= p_50;
                    }
                }
                (*l_1203) = &g_54;
            }
        }
    }
    (*g_850) = l_794;
    return g_642;
}


/* ------------------------------------------ */
/* 
 * reads : g_98
 * writes: g_98
 */
static uint16_t  func_62(int16_t  p_63, int32_t  p_64, uint32_t * p_65, int8_t  p_66, uint32_t  p_67)
{ /* block id: 6 */
    int32_t *l_93 = &g_54;
    int32_t *l_94 = (void*)0;
    int32_t *l_95[2];
    int16_t l_97[10] = {0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL,0xF69DL};
    int i;
    for (i = 0; i < 2; i++)
        l_95[i] = (void*)0;
    --g_98;
    return p_66;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_26, "g_26", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_33[i][j], "g_33[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_198[i], "g_198[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_233, "g_233", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_259[i], "g_259[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_305[i], "g_305[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_308, "g_308", print_hash_value);
    transparent_crc(g_325, "g_325", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_388[i], "g_388[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_411[i][j][k], "g_411[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_493[i][j], "g_493[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_534.f0, "g_534.f0", print_hash_value);
    transparent_crc(g_534.f1, "g_534.f1", print_hash_value);
    transparent_crc(g_534.f2, "g_534.f2", print_hash_value);
    transparent_crc(g_534.f3, "g_534.f3", print_hash_value);
    transparent_crc(g_534.f4, "g_534.f4", print_hash_value);
    transparent_crc(g_534.f5, "g_534.f5", print_hash_value);
    transparent_crc(g_642, "g_642", print_hash_value);
    transparent_crc(g_660, "g_660", print_hash_value);
    transparent_crc(g_765, "g_765", print_hash_value);
    transparent_crc(g_837.f0, "g_837.f0", print_hash_value);
    transparent_crc(g_837.f1, "g_837.f1", print_hash_value);
    transparent_crc(g_837.f2, "g_837.f2", print_hash_value);
    transparent_crc(g_837.f3, "g_837.f3", print_hash_value);
    transparent_crc(g_837.f4, "g_837.f4", print_hash_value);
    transparent_crc(g_837.f5, "g_837.f5", print_hash_value);
    transparent_crc(g_942, "g_942", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_965[i].f0, "g_965[i].f0", print_hash_value);
        transparent_crc(g_965[i].f1, "g_965[i].f1", print_hash_value);
        transparent_crc(g_965[i].f2, "g_965[i].f2", print_hash_value);
        transparent_crc(g_965[i].f3, "g_965[i].f3", print_hash_value);
        transparent_crc(g_965[i].f4, "g_965[i].f4", print_hash_value);
        transparent_crc(g_965[i].f5, "g_965[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1160.f0, "g_1160.f0", print_hash_value);
    transparent_crc(g_1160.f1, "g_1160.f1", print_hash_value);
    transparent_crc(g_1160.f2, "g_1160.f2", print_hash_value);
    transparent_crc(g_1160.f3, "g_1160.f3", print_hash_value);
    transparent_crc(g_1160.f4, "g_1160.f4", print_hash_value);
    transparent_crc(g_1160.f5, "g_1160.f5", print_hash_value);
    transparent_crc(g_1231, "g_1231", print_hash_value);
    transparent_crc(g_1302, "g_1302", print_hash_value);
    transparent_crc(g_1303, "g_1303", print_hash_value);
    transparent_crc(g_1304, "g_1304", print_hash_value);
    transparent_crc(g_1305, "g_1305", print_hash_value);
    transparent_crc(g_1306, "g_1306", print_hash_value);
    transparent_crc(g_1307, "g_1307", print_hash_value);
    transparent_crc(g_1308, "g_1308", print_hash_value);
    transparent_crc(g_1309, "g_1309", print_hash_value);
    transparent_crc(g_1310, "g_1310", print_hash_value);
    transparent_crc(g_1311, "g_1311", print_hash_value);
    transparent_crc(g_1312, "g_1312", print_hash_value);
    transparent_crc(g_1313, "g_1313", print_hash_value);
    transparent_crc(g_1314, "g_1314", print_hash_value);
    transparent_crc(g_1315, "g_1315", print_hash_value);
    transparent_crc(g_1316, "g_1316", print_hash_value);
    transparent_crc(g_1317, "g_1317", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1318[i], "g_1318[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1319, "g_1319", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1320[i][j][k], "g_1320[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1321, "g_1321", print_hash_value);
    transparent_crc(g_1322, "g_1322", print_hash_value);
    transparent_crc(g_1323, "g_1323", print_hash_value);
    transparent_crc(g_1324, "g_1324", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1325[i], "g_1325[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1326, "g_1326", print_hash_value);
    transparent_crc(g_1327, "g_1327", print_hash_value);
    transparent_crc(g_1328, "g_1328", print_hash_value);
    transparent_crc(g_1329, "g_1329", print_hash_value);
    transparent_crc(g_1330, "g_1330", print_hash_value);
    transparent_crc(g_1331, "g_1331", print_hash_value);
    transparent_crc(g_1332, "g_1332", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1333[i][j], "g_1333[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1334, "g_1334", print_hash_value);
    transparent_crc(g_1361, "g_1361", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1390[i].f0, "g_1390[i].f0", print_hash_value);
        transparent_crc(g_1390[i].f1, "g_1390[i].f1", print_hash_value);
        transparent_crc(g_1390[i].f2, "g_1390[i].f2", print_hash_value);
        transparent_crc(g_1390[i].f3, "g_1390[i].f3", print_hash_value);
        transparent_crc(g_1390[i].f4, "g_1390[i].f4", print_hash_value);
        transparent_crc(g_1390[i].f5, "g_1390[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1406, "g_1406", print_hash_value);
    transparent_crc(g_1418, "g_1418", print_hash_value);
    transparent_crc(g_1422.f0, "g_1422.f0", print_hash_value);
    transparent_crc(g_1422.f1, "g_1422.f1", print_hash_value);
    transparent_crc(g_1422.f2, "g_1422.f2", print_hash_value);
    transparent_crc(g_1422.f3, "g_1422.f3", print_hash_value);
    transparent_crc(g_1422.f4, "g_1422.f4", print_hash_value);
    transparent_crc(g_1422.f5, "g_1422.f5", print_hash_value);
    transparent_crc(g_1424.f0, "g_1424.f0", print_hash_value);
    transparent_crc(g_1424.f1, "g_1424.f1", print_hash_value);
    transparent_crc(g_1424.f2, "g_1424.f2", print_hash_value);
    transparent_crc(g_1424.f3, "g_1424.f3", print_hash_value);
    transparent_crc(g_1424.f4, "g_1424.f4", print_hash_value);
    transparent_crc(g_1424.f5, "g_1424.f5", print_hash_value);
    transparent_crc(g_1465, "g_1465", print_hash_value);
    transparent_crc(g_1584, "g_1584", print_hash_value);
    transparent_crc(g_1609.f0, "g_1609.f0", print_hash_value);
    transparent_crc(g_1609.f1, "g_1609.f1", print_hash_value);
    transparent_crc(g_1609.f2, "g_1609.f2", print_hash_value);
    transparent_crc(g_1609.f3, "g_1609.f3", print_hash_value);
    transparent_crc(g_1609.f4, "g_1609.f4", print_hash_value);
    transparent_crc(g_1609.f5, "g_1609.f5", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1617[i], "g_1617[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1622[i], "g_1622[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1700.f0, "g_1700.f0", print_hash_value);
    transparent_crc(g_1700.f1, "g_1700.f1", print_hash_value);
    transparent_crc(g_1700.f2, "g_1700.f2", print_hash_value);
    transparent_crc(g_1700.f3, "g_1700.f3", print_hash_value);
    transparent_crc(g_1700.f4, "g_1700.f4", print_hash_value);
    transparent_crc(g_1700.f5, "g_1700.f5", print_hash_value);
    transparent_crc(g_1780.f0, "g_1780.f0", print_hash_value);
    transparent_crc(g_1780.f1, "g_1780.f1", print_hash_value);
    transparent_crc(g_1780.f2, "g_1780.f2", print_hash_value);
    transparent_crc(g_1780.f3, "g_1780.f3", print_hash_value);
    transparent_crc(g_1780.f4, "g_1780.f4", print_hash_value);
    transparent_crc(g_1780.f5, "g_1780.f5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1958[i], "g_1958[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1973.f0, "g_1973.f0", print_hash_value);
    transparent_crc(g_1973.f1, "g_1973.f1", print_hash_value);
    transparent_crc(g_1973.f2, "g_1973.f2", print_hash_value);
    transparent_crc(g_1973.f3, "g_1973.f3", print_hash_value);
    transparent_crc(g_1973.f4, "g_1973.f4", print_hash_value);
    transparent_crc(g_1973.f5, "g_1973.f5", print_hash_value);
    transparent_crc(g_1976.f0, "g_1976.f0", print_hash_value);
    transparent_crc(g_1976.f1, "g_1976.f1", print_hash_value);
    transparent_crc(g_1976.f2, "g_1976.f2", print_hash_value);
    transparent_crc(g_1976.f3, "g_1976.f3", print_hash_value);
    transparent_crc(g_1976.f4, "g_1976.f4", print_hash_value);
    transparent_crc(g_1976.f5, "g_1976.f5", print_hash_value);
    transparent_crc(g_2137.f0, "g_2137.f0", print_hash_value);
    transparent_crc(g_2137.f1, "g_2137.f1", print_hash_value);
    transparent_crc(g_2137.f2, "g_2137.f2", print_hash_value);
    transparent_crc(g_2137.f3, "g_2137.f3", print_hash_value);
    transparent_crc(g_2137.f4, "g_2137.f4", print_hash_value);
    transparent_crc(g_2137.f5, "g_2137.f5", print_hash_value);
    transparent_crc(g_2150, "g_2150", print_hash_value);
    transparent_crc(g_2166.f0, "g_2166.f0", print_hash_value);
    transparent_crc(g_2166.f1, "g_2166.f1", print_hash_value);
    transparent_crc(g_2166.f2, "g_2166.f2", print_hash_value);
    transparent_crc(g_2166.f3, "g_2166.f3", print_hash_value);
    transparent_crc(g_2166.f4, "g_2166.f4", print_hash_value);
    transparent_crc(g_2166.f5, "g_2166.f5", print_hash_value);
    transparent_crc(g_2216, "g_2216", print_hash_value);
    transparent_crc(g_2243.f0, "g_2243.f0", print_hash_value);
    transparent_crc(g_2243.f1, "g_2243.f1", print_hash_value);
    transparent_crc(g_2243.f2, "g_2243.f2", print_hash_value);
    transparent_crc(g_2243.f3, "g_2243.f3", print_hash_value);
    transparent_crc(g_2243.f4, "g_2243.f4", print_hash_value);
    transparent_crc(g_2243.f5, "g_2243.f5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2259[i], "g_2259[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2380, "g_2380", print_hash_value);
    transparent_crc(g_2382.f0, "g_2382.f0", print_hash_value);
    transparent_crc(g_2382.f1, "g_2382.f1", print_hash_value);
    transparent_crc(g_2382.f2, "g_2382.f2", print_hash_value);
    transparent_crc(g_2382.f3, "g_2382.f3", print_hash_value);
    transparent_crc(g_2382.f4, "g_2382.f4", print_hash_value);
    transparent_crc(g_2382.f5, "g_2382.f5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2400[i].f0, "g_2400[i].f0", print_hash_value);
        transparent_crc(g_2400[i].f1, "g_2400[i].f1", print_hash_value);
        transparent_crc(g_2400[i].f2, "g_2400[i].f2", print_hash_value);
        transparent_crc(g_2400[i].f3, "g_2400[i].f3", print_hash_value);
        transparent_crc(g_2400[i].f4, "g_2400[i].f4", print_hash_value);
        transparent_crc(g_2400[i].f5, "g_2400[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2460, "g_2460", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2638[i], "g_2638[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2685[i], "g_2685[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2732, "g_2732", print_hash_value);
    transparent_crc(g_2742, "g_2742", print_hash_value);
    transparent_crc(g_2799.f0, "g_2799.f0", print_hash_value);
    transparent_crc(g_2799.f1, "g_2799.f1", print_hash_value);
    transparent_crc(g_2799.f2, "g_2799.f2", print_hash_value);
    transparent_crc(g_2799.f3, "g_2799.f3", print_hash_value);
    transparent_crc(g_2799.f4, "g_2799.f4", print_hash_value);
    transparent_crc(g_2799.f5, "g_2799.f5", print_hash_value);
    transparent_crc(g_2804.f0, "g_2804.f0", print_hash_value);
    transparent_crc(g_2804.f1, "g_2804.f1", print_hash_value);
    transparent_crc(g_2804.f2, "g_2804.f2", print_hash_value);
    transparent_crc(g_2804.f3, "g_2804.f3", print_hash_value);
    transparent_crc(g_2804.f4, "g_2804.f4", print_hash_value);
    transparent_crc(g_2804.f5, "g_2804.f5", print_hash_value);
    transparent_crc(g_2838.f0, "g_2838.f0", print_hash_value);
    transparent_crc(g_2838.f1, "g_2838.f1", print_hash_value);
    transparent_crc(g_2838.f2, "g_2838.f2", print_hash_value);
    transparent_crc(g_2838.f3, "g_2838.f3", print_hash_value);
    transparent_crc(g_2838.f4, "g_2838.f4", print_hash_value);
    transparent_crc(g_2838.f5, "g_2838.f5", print_hash_value);
    transparent_crc(g_2861, "g_2861", print_hash_value);
    transparent_crc(g_2880.f0, "g_2880.f0", print_hash_value);
    transparent_crc(g_2880.f1, "g_2880.f1", print_hash_value);
    transparent_crc(g_2880.f2, "g_2880.f2", print_hash_value);
    transparent_crc(g_2880.f3, "g_2880.f3", print_hash_value);
    transparent_crc(g_2880.f4, "g_2880.f4", print_hash_value);
    transparent_crc(g_2880.f5, "g_2880.f5", print_hash_value);
    transparent_crc(g_2930, "g_2930", print_hash_value);
    transparent_crc(g_2937, "g_2937", print_hash_value);
    transparent_crc(g_2990, "g_2990", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 667
   depth: 1, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 33
breakdown:
   indirect level: 0, occurrence: 14
   indirect level: 1, occurrence: 9
   indirect level: 2, occurrence: 10
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 12
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 16
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 55
breakdown:
   depth: 1, occurrence: 282
   depth: 2, occurrence: 83
   depth: 3, occurrence: 5
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 12, occurrence: 1
   depth: 13, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 3
   depth: 19, occurrence: 3
   depth: 20, occurrence: 2
   depth: 21, occurrence: 2
   depth: 22, occurrence: 1
   depth: 23, occurrence: 4
   depth: 24, occurrence: 4
   depth: 25, occurrence: 3
   depth: 26, occurrence: 6
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 2
   depth: 33, occurrence: 3
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 36, occurrence: 2
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 55, occurrence: 1

XXX total number of pointers: 626

XXX times a variable address is taken: 1427
XXX times a pointer is dereferenced on RHS: 548
breakdown:
   depth: 1, occurrence: 404
   depth: 2, occurrence: 134
   depth: 3, occurrence: 10
XXX times a pointer is dereferenced on LHS: 476
breakdown:
   depth: 1, occurrence: 407
   depth: 2, occurrence: 63
   depth: 3, occurrence: 6
XXX times a pointer is compared with null: 51
XXX times a pointer is compared with address of another variable: 19
XXX times a pointer is compared with another pointer: 23
XXX times a pointer is qualified to be dereferenced: 7347

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2500
   level: 2, occurrence: 699
   level: 3, occurrence: 56
   level: 4, occurrence: 24
   level: 5, occurrence: 6
   level: 6, occurrence: 15
XXX number of pointers point to pointers: 256
XXX number of pointers point to scalars: 358
XXX number of pointers point to structs: 12
XXX percent of pointers has null in alias set: 28.4
XXX average alias set size: 1.54

XXX times a non-volatile is read: 2770
XXX times a non-volatile is write: 1375
XXX times a volatile is read: 41
XXX    times read thru a pointer: 13
XXX times a volatile is write: 10
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2.8e+03
XXX percentage of non-volatile access: 98.8

XXX forward jumps: 1
XXX backward jumps: 9

XXX stmts: 297
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 28
   depth: 2, occurrence: 37
   depth: 3, occurrence: 69
   depth: 4, occurrence: 56
   depth: 5, occurrence: 78

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

