/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2023702945
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile int64_t  f0;
};

union U1 {
   volatile uint32_t  f0;
   const int32_t  f1;
   signed f2 : 17;
};

union U2 {
   unsigned f0 : 15;
   volatile uint8_t  f1;
   uint32_t  f2;
   uint8_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static const uint16_t g_12 = 65535UL;
static int8_t g_63 = 0L;
static int32_t g_68 = (-9L);
static int8_t g_73 = (-1L);
static volatile union U2 g_95 = {4294967294UL};/* VOLATILE GLOBAL g_95 */
static uint8_t g_96 = 250UL;
static int32_t *g_101[3] = {&g_68,&g_68,&g_68};
static uint16_t g_104 = 0xDDC8L;
static union U0 g_106[7][1] = {{{0x88BF30E8C00D659ELL}},{{1L}},{{0x88BF30E8C00D659ELL}},{{1L}},{{0x88BF30E8C00D659ELL}},{{1L}},{{0x88BF30E8C00D659ELL}}};
static volatile union U1 g_152[2] = {{0x1318B2E7L},{0x1318B2E7L}};
static union U0 *g_162 = (void*)0;
static union U0 **g_161 = &g_162;
static volatile union U0 g_168 = {0L};/* VOLATILE GLOBAL g_168 */
static uint32_t g_171 = 0xA1B8C437L;
static int32_t g_203 = 0L;
static int32_t * const  volatile g_202[1][8][4] = {{{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_203}}};
static int32_t * volatile g_204 = &g_203;/* VOLATILE GLOBAL g_204 */
static uint64_t g_216 = 0x04CDBB5A92DE4622LL;
static int16_t g_218 = (-1L);
static uint32_t g_225 = 0xABEE0694L;
static int32_t * volatile g_239 = (void*)0;/* VOLATILE GLOBAL g_239 */
static volatile union U2 g_263 = {4294967295UL};/* VOLATILE GLOBAL g_263 */
static volatile union U0 g_269 = {0L};/* VOLATILE GLOBAL g_269 */
static const int32_t g_330 = 0x6CBC4111L;
static const int32_t *g_329 = &g_330;
static const int32_t **g_328 = &g_329;
static const int32_t **g_331 = &g_329;
static uint8_t *g_341 = (void*)0;
static int32_t ***g_370 = (void*)0;
static int64_t g_375 = 0x37B481374B149FC8LL;
static int32_t g_377 = (-1L);
static int32_t g_379 = 4L;
static volatile uint32_t *g_398 = &g_152[1].f0;
static volatile uint32_t ** volatile g_397 = &g_398;/* VOLATILE GLOBAL g_397 */
static volatile uint32_t ** volatile * volatile g_399 = &g_397;/* VOLATILE GLOBAL g_399 */
static volatile union U1 g_410 = {0xED8611DEL};/* VOLATILE GLOBAL g_410 */
static int16_t *g_411[3] = {&g_218,&g_218,&g_218};
static uint8_t g_421 = 0UL;
static volatile union U2 g_460 = {0x783E3658L};/* VOLATILE GLOBAL g_460 */
static union U1 g_475 = {4294967295UL};/* VOLATILE GLOBAL g_475 */
static const int32_t g_493 = 1L;
static volatile int32_t g_504 = (-1L);/* VOLATILE GLOBAL g_504 */
static volatile union U2 g_525[1][2][10] = {{{{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L}},{{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L},{0x240FA2D9L}}}};
static union U1 g_547[4] = {{0xE5C0685FL},{0xE5C0685FL},{0xE5C0685FL},{0xE5C0685FL}};
static volatile union U0 g_557 = {0L};/* VOLATILE GLOBAL g_557 */
static uint32_t ** const *g_576 = (void*)0;
static union U1 g_581 = {0UL};/* VOLATILE GLOBAL g_581 */
static union U1 g_586 = {0x3446A833L};/* VOLATILE GLOBAL g_586 */
static union U0 g_610 = {0x42E92513A9E9EC50LL};/* VOLATILE GLOBAL g_610 */
static volatile union U0 g_618 = {0L};/* VOLATILE GLOBAL g_618 */
static volatile union U2 g_627[1][9][3] = {{{{0x715CC3E3L},{0UL},{0x5E37722AL}},{{4294967293UL},{4294967293UL},{0x015E4CC7L}},{{0UL},{0UL},{0UL}},{{0x015E4CC7L},{0x3D21832EL},{4294967288UL}},{{0UL},{0x15FF63ABL},{0UL}},{{4294967293UL},{0x015E4CC7L},{4294967288UL}},{{0x715CC3E3L},{0x715CC3E3L},{0UL}},{{0xC30B2CFCL},{0x015E4CC7L},{0x015E4CC7L}},{{0UL},{0x15FF63ABL},{0x5E37722AL}}}};
static union U1 g_671 = {1UL};/* VOLATILE GLOBAL g_671 */
static volatile int8_t g_688 = (-1L);/* VOLATILE GLOBAL g_688 */
static volatile union U0 g_704 = {0x803905729EFDE755LL};/* VOLATILE GLOBAL g_704 */
static union U2 g_745 = {5UL};/* VOLATILE GLOBAL g_745 */
static union U1 g_754 = {9UL};/* VOLATILE GLOBAL g_754 */
static int32_t **g_765 = &g_101[0];
static int32_t ***g_764[3][10][2] = {{{&g_765,&g_765},{&g_765,&g_765},{&g_765,&g_765},{(void*)0,&g_765},{&g_765,&g_765},{&g_765,&g_765},{&g_765,(void*)0},{&g_765,&g_765},{&g_765,&g_765},{&g_765,&g_765}},{{(void*)0,&g_765},{&g_765,&g_765},{&g_765,&g_765},{&g_765,(void*)0},{&g_765,&g_765},{&g_765,&g_765},{&g_765,&g_765},{(void*)0,&g_765},{&g_765,&g_765},{&g_765,&g_765}},{{&g_765,(void*)0},{&g_765,&g_765},{&g_765,&g_765},{&g_765,&g_765},{(void*)0,&g_765},{&g_765,&g_765},{&g_765,&g_765},{&g_765,(void*)0},{&g_765,&g_765},{&g_765,&g_765}}};
static int64_t * volatile g_802 = (void*)0;/* VOLATILE GLOBAL g_802 */
static int64_t * volatile * const g_801 = &g_802;
static int64_t * volatile * const * volatile g_800[9][8] = {{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801},{&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801,&g_801}};
static int16_t g_852 = 1L;
static uint8_t g_855[4][8] = {{0x61L,0UL,0xB3L,0xB3L,0UL,0x61L,0UL,0UL},{0xB3L,0x33L,0xB3L,0x53L,0x53L,0xB3L,0x33L,0xB3L},{0x61L,0x53L,0UL,0x53L,0x61L,0x61L,0x53L,0UL},{0x61L,0x61L,0x53L,0UL,0x53L,0x61L,0x61L,0x53L}};
static const union U1 g_862 = {4294967295UL};/* VOLATILE GLOBAL g_862 */
static uint32_t g_929 = 0xE7191C6DL;
static union U1 g_945 = {4UL};/* VOLATILE GLOBAL g_945 */
static union U0 g_950[1] = {{-6L}};
static int8_t *g_1008[1][5][10] = {{{&g_63,&g_63,&g_63,&g_73,&g_73,&g_63,&g_63,&g_63,&g_73,&g_73},{&g_63,&g_63,&g_63,&g_73,&g_73,&g_63,&g_63,&g_63,&g_73,&g_73},{&g_63,&g_63,&g_63,&g_73,&g_73,&g_63,&g_63,&g_63,&g_73,&g_73},{&g_63,&g_63,&g_63,&g_73,&g_73,&g_63,&g_63,&g_63,&g_73,&g_73},{&g_63,&g_63,&g_63,&g_73,&g_73,&g_63,&g_63,&g_63,&g_73,&g_73}}};
static int8_t *g_1009 = (void*)0;
static uint8_t * volatile * const g_1026 = &g_341;
static uint8_t * volatile * const *g_1025 = &g_1026;
static volatile int64_t *g_1050 = &g_950[0].f0;
static union U1 g_1058 = {0x9148E8CDL};/* VOLATILE GLOBAL g_1058 */
static union U0 ** volatile g_1063 = (void*)0;/* VOLATILE GLOBAL g_1063 */
static union U0 *g_1065 = &g_106[5][0];
static union U0 ** volatile g_1064[8][9] = {{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065}};
static union U0 ** volatile g_1066 = &g_1065;/* VOLATILE GLOBAL g_1066 */
static union U0 g_1067 = {-8L};/* VOLATILE GLOBAL g_1067 */
static const uint32_t g_1099 = 0xFDFD3AC7L;
static volatile int32_t g_1149[8] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
static volatile union U2 g_1153 = {3UL};/* VOLATILE GLOBAL g_1153 */
static volatile union U0 g_1167 = {1L};/* VOLATILE GLOBAL g_1167 */
static union U2 g_1184 = {4294967295UL};/* VOLATILE GLOBAL g_1184 */
static union U1 g_1198 = {7UL};/* VOLATILE GLOBAL g_1198 */
static union U2 * volatile g_1207[8] = {&g_745,(void*)0,&g_745,&g_745,(void*)0,&g_745,&g_745,(void*)0};
static union U2 * volatile *g_1206 = &g_1207[5];
static union U2 g_1236 = {5UL};/* VOLATILE GLOBAL g_1236 */
static union U2 g_1237 = {0UL};/* VOLATILE GLOBAL g_1237 */
static union U2 g_1238 = {0x05D8B85DL};/* VOLATILE GLOBAL g_1238 */
static volatile union U0 g_1242 = {8L};/* VOLATILE GLOBAL g_1242 */
static union U1 g_1273 = {0xD9C55040L};/* VOLATILE GLOBAL g_1273 */
static int8_t g_1303 = (-7L);
static const union U0 g_1320 = {0xC1181C8813C5B96BLL};/* VOLATILE GLOBAL g_1320 */
static union U0 g_1325 = {1L};/* VOLATILE GLOBAL g_1325 */
static uint16_t g_1343[7][4] = {{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL},{0xE1DFL,0xE1DFL,0xE1DFL,0xE1DFL}};
static int64_t *g_1364 = &g_375;
static int64_t **g_1363 = &g_1364;
static union U0 g_1390 = {0xBC11BD694AE5A78FLL};/* VOLATILE GLOBAL g_1390 */
static int64_t g_1407 = 0x4FDE36B28B21B76DLL;
static uint32_t *g_1443[10][2][4] = {{{&g_929,&g_171,&g_171,&g_171},{&g_929,&g_929,&g_929,&g_171}},{{(void*)0,&g_929,&g_171,&g_929},{(void*)0,&g_929,&g_929,&g_929}},{{&g_929,&g_929,&g_171,&g_171},{&g_929,&g_171,&g_929,&g_171}},{{&g_929,&g_929,&g_171,&g_929},{&g_929,&g_929,&g_929,&g_171}},{{&g_929,&g_171,&g_929,&g_171},{&g_929,&g_929,&g_929,&g_929}},{{&g_171,&g_929,&g_171,&g_929},{&g_171,&g_929,&g_171,&g_171}},{{&g_171,&g_929,&g_929,&g_171},{&g_929,&g_171,&g_929,&g_171}},{{&g_929,&g_171,&g_929,&g_929},{&g_929,(void*)0,&g_171,&g_929}},{{&g_929,&g_171,&g_929,&g_171},{&g_929,&g_171,&g_171,&g_171}},{{&g_929,&g_929,&g_929,&g_171},{(void*)0,&g_929,&g_171,&g_929}}};
static uint32_t *g_1445 = &g_171;
static uint8_t g_1453 = 0UL;
static union U2 g_1482 = {4UL};/* VOLATILE GLOBAL g_1482 */
static const int32_t ** volatile g_1484 = &g_329;/* VOLATILE GLOBAL g_1484 */
static volatile union U0 g_1491[10][9] = {{{-6L},{0x2F56CE48308F51A9LL},{0L},{-6L},{0L},{0x2F56CE48308F51A9LL},{-6L},{0L},{0L}},{{0xB42DE8089579E43BLL},{0x27BAE973F6EBA264LL},{0x863CDE036841406DLL},{0xB42DE8089579E43BLL},{0x863CDE036841406DLL},{0x27BAE973F6EBA264LL},{0xB42DE8089579E43BLL},{5L},{5L}},{{-6L},{0x2F56CE48308F51A9LL},{0L},{-6L},{0L},{0x2F56CE48308F51A9LL},{-6L},{0L},{0L}},{{0xB42DE8089579E43BLL},{0x27BAE973F6EBA264LL},{0x863CDE036841406DLL},{0xB42DE8089579E43BLL},{0x863CDE036841406DLL},{0x27BAE973F6EBA264LL},{0xB42DE8089579E43BLL},{5L},{5L}},{{-6L},{0x2F56CE48308F51A9LL},{0L},{-6L},{0L},{0x2F56CE48308F51A9LL},{-6L},{0L},{0L}},{{0xB42DE8089579E43BLL},{0x27BAE973F6EBA264LL},{0x863CDE036841406DLL},{0xB42DE8089579E43BLL},{0x863CDE036841406DLL},{0x27BAE973F6EBA264LL},{0xB42DE8089579E43BLL},{5L},{5L}},{{-6L},{0x2F56CE48308F51A9LL},{0L},{-6L},{0L},{0x2F56CE48308F51A9LL},{-6L},{0L},{0L}},{{0xB42DE8089579E43BLL},{0x27BAE973F6EBA264LL},{0x863CDE036841406DLL},{0xB42DE8089579E43BLL},{0x863CDE036841406DLL},{0x27BAE973F6EBA264LL},{0xB42DE8089579E43BLL},{5L},{5L}},{{-6L},{0x2F56CE48308F51A9LL},{0L},{-6L},{0L},{0x2F56CE48308F51A9LL},{-6L},{0L},{0L}},{{0xB42DE8089579E43BLL},{0x27BAE973F6EBA264LL},{0x863CDE036841406DLL},{0xB42DE8089579E43BLL},{0x863CDE036841406DLL},{0x27BAE973F6EBA264LL},{0xB42DE8089579E43BLL},{5L},{5L}}};
static int32_t ** const  volatile g_1504 = &g_101[0];/* VOLATILE GLOBAL g_1504 */
static union U0 g_1528[7][7][5] = {{{{0xAD0507C6D0A895E5LL},{0x9B51939C5CE8130FLL},{-7L},{-10L},{0L}},{{1L},{0xF172FEF1E13A0DA2LL},{8L},{0L},{1L}},{{0x6A1146026AB487C1LL},{0x00B5A209C8EB7E4BLL},{0L},{0x982C769E924682BBLL},{-5L}},{{9L},{0x9B51939C5CE8130FLL},{-6L},{9L},{0x23AACB1C255D1F6DLL}},{{0x4A68F52AAC51CE9DLL},{0L},{8L},{1L},{-2L}},{{-1L},{-1L},{0x51119CB0896542B3LL},{-7L},{0xA6C3F248AD1792B7LL}},{{0xEDAD5E0BAE8589AELL},{0x6CBD13428DC76C6ELL},{1L},{0x50FF9F209FB6F976LL},{1L}}},{{{0L},{0xA328996EB4360962LL},{0x099ABB39D7A2AEBDLL},{0xE9B87B099081C24ELL},{0x2518AAD7209332F5LL}},{{0x163B73C4A4295E5BLL},{-2L},{0xB676D4D0867A899CLL},{0x23AACB1C255D1F6DLL},{0xD25C92C6366F7D9ELL}},{{0xEBD9BF304C1D2E96LL},{2L},{1L},{0xFAA5B93C8D71592BLL},{-7L}},{{0xEBD9BF304C1D2E96LL},{3L},{0xE88FBF6604C80B5DLL},{0x9B51939C5CE8130FLL},{0L}},{{0x163B73C4A4295E5BLL},{0x3F836CBED9A4BCD6LL},{0x6A3E5873C27878AFLL},{0xBA4E993A37373EB0LL},{0x982C769E924682BBLL}},{{0L},{-7L},{0L},{8L},{0x6A3E5873C27878AFLL}},{{0xEDAD5E0BAE8589AELL},{0xAD99405B5E6CBA09LL},{1L},{0L},{0x2448358088C72ECALL}}},{{{-1L},{0x7919FC191C1B87ABLL},{0x6CBD13428DC76C6ELL},{0x6A3E5873C27878AFLL},{-1L}},{{0x4A68F52AAC51CE9DLL},{2L},{3L},{-2L},{0x6D593BAE58A6CDFALL}},{{-5L},{0x2448358088C72ECALL},{0xE88FBF6604C80B5DLL},{0xE9B87B099081C24ELL},{0x6A1146026AB487C1LL}},{{1L},{0x9B51939C5CE8130FLL},{0xB3FA090BE4EB181DLL},{0x5EA4CE35A3855708LL},{-2L}},{{0x2518AAD7209332F5LL},{0L},{0x6D593BAE58A6CDFALL},{3L},{0x6D593BAE58A6CDFALL}},{{3L},{3L},{0x099ABB39D7A2AEBDLL},{0x50FF9F209FB6F976LL},{-5L}},{{0x1B729939A4B05E99LL},{8L},{0x23AACB1C255D1F6DLL},{-1L},{0xAD99405B5E6CBA09LL}}},{{{-7L},{1L},{0xB676D4D0867A899CLL},{0x803D0ADB30CF342DLL},{0x6A3E5873C27878AFLL}},{{0x50FF9F209FB6F976LL},{8L},{8L},{-7L},{0xEDAD5E0BAE8589AELL}},{{0xC138494EF80BC755LL},{3L},{0xF0489E8B33ABE74CLL},{0xD786498EC9F95957LL},{-6L}},{{0xD25C92C6366F7D9ELL},{0L},{3L},{0xA328996EB4360962LL},{-7L}},{{0L},{0x9B51939C5CE8130FLL},{1L},{0x57DD02A04174FEECLL},{0xFAA5B93C8D71592BLL}},{{0L},{0x2448358088C72ECALL},{0x21440078A3B14723LL},{0xD786498EC9F95957LL},{0x2448358088C72ECALL}},{{0x2518AAD7209332F5LL},{2L},{-7L},{0xFAA5B93C8D71592BLL},{1L}}},{{{-1L},{0x7919FC191C1B87ABLL},{-10L},{-2L},{-1L}},{{3L},{0xAD99405B5E6CBA09LL},{-3L},{-1L},{0x803D0ADB30CF342DLL}},{{0x3F836CBED9A4BCD6LL},{-7L},{0xB3FA090BE4EB181DLL},{1L},{0x23AACB1C255D1F6DLL}},{{0x2448358088C72ECALL},{0x3F836CBED9A4BCD6LL},{0xA0F28F1B7D885B50LL},{0x982C769E924682BBLL},{0x5ED47FD31011CCE0LL}},{{0L},{3L},{1L},{0x5EA4CE35A3855708LL},{-1L}},{{0x1D7D05017598E998LL},{2L},{1L},{0xAD2FF1DCF024F2B7LL},{-3L}},{{-7L},{-2L},{0xA0F28F1B7D885B50LL},{0x6A1146026AB487C1LL},{0xFAA5B93C8D71592BLL}}},{{{0xC138494EF80BC755LL},{0xA328996EB4360962LL},{0xB3FA090BE4EB181DLL},{0x6A3E5873C27878AFLL},{0xEDAD5E0BAE8589AELL}},{{0xEBD9BF304C1D2E96LL},{0x6CBD13428DC76C6ELL},{-3L},{-6L},{0xD786498EC9F95957LL}},{{0xFAA5B93C8D71592BLL},{-1L},{-10L},{0xA328996EB4360962LL},{0x982C769E924682BBLL}},{{0x1B729939A4B05E99LL},{0L},{-7L},{0xBA4E993A37373EB0LL},{-7L}},{{0x982C769E924682BBLL},{0xF0489E8B33ABE74CLL},{0x21440078A3B14723LL},{0L},{-3L}},{{0x2448358088C72ECALL},{0x9692721B5761C5E1LL},{1L},{-7L},{0xA5A969E7EC2B5906LL}},{{1L},{0x7919FC191C1B87ABLL},{3L},{0x23AACB1C255D1F6DLL},{0xA6C3F248AD1792B7LL}}},{{{0x6CBD13428DC76C6ELL},{0xAD0507C6D0A895E5LL},{0xAD0507C6D0A895E5LL},{0x6CBD13428DC76C6ELL},{1L}},{{0x5EA4CE35A3855708LL},{0xF0489E8B33ABE74CLL},{0xA6C3F248AD1792B7LL},{0x87FBDAF41964C8EBLL},{1L}},{{0x81D6F74EA61D1E86LL},{-9L},{-8L},{1L},{-1L}},{{-1L},{0x099ABB39D7A2AEBDLL},{1L},{0x87FBDAF41964C8EBLL},{0xDDECDB7C40DC0107LL}},{{0x163B73C4A4295E5BLL},{0L},{-1L},{0x6CBD13428DC76C6ELL},{-1L}},{{0L},{0xC5E5343C28E50254LL},{0L},{1L},{0xD786498EC9F95957LL}},{{0xBA4E993A37373EB0LL},{-1L},{8L},{0xD786498EC9F95957LL},{1L}}}};
static union U0 * const g_1530[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U0 * const *g_1529[2] = {&g_1530[3],&g_1530[3]};
static volatile union U2 g_1531[5] = {{0x62B272F6L},{0x62B272F6L},{0x62B272F6L},{0x62B272F6L},{0x62B272F6L}};
static uint8_t g_1568 = 255UL;
static int32_t ****g_1585 = &g_764[1][6][1];
static int32_t *****g_1584 = &g_1585;
static int32_t g_1604 = 0L;
static const int32_t * const g_1643 = (void*)0;
static const int32_t * const *g_1642 = &g_1643;
static const int32_t * const **g_1641 = &g_1642;
static const int32_t * const ***g_1640 = &g_1641;
static uint32_t g_1669 = 0x0446D0B2L;
static uint32_t g_1696 = 0UL;
static volatile uint32_t g_1772[8] = {0xE72282FDL,0xE72282FDL,0xE72282FDL,0xE72282FDL,0xE72282FDL,0xE72282FDL,0xE72282FDL,0xE72282FDL};
static uint64_t g_1799 = 0UL;
static const uint32_t *g_1811 = &g_929;
static const uint32_t **g_1810[3][2] = {{&g_1811,&g_1811},{&g_1811,&g_1811},{&g_1811,&g_1811}};
static const uint32_t ***g_1809 = &g_1810[0][1];
static const uint32_t ****g_1808[3] = {&g_1809,&g_1809,&g_1809};
static volatile int16_t g_1839 = 0xB992L;/* VOLATILE GLOBAL g_1839 */
static union U2 g_1843 = {7UL};/* VOLATILE GLOBAL g_1843 */
static int32_t *g_1850 = &g_1604;
static int32_t ** const g_1849[4] = {&g_1850,&g_1850,&g_1850,&g_1850};
static int32_t ** const *g_1848 = &g_1849[2];
static volatile union U2 g_1851 = {0xB0E83C50L};/* VOLATILE GLOBAL g_1851 */
static const union U1 g_1852 = {4294967295UL};/* VOLATILE GLOBAL g_1852 */
static int16_t **g_1867[6][3][4] = {{{&g_411[2],&g_411[1],&g_411[2],&g_411[2]},{&g_411[0],&g_411[2],&g_411[2],&g_411[2]},{&g_411[2],(void*)0,&g_411[2],&g_411[0]}},{{&g_411[2],&g_411[2],&g_411[0],&g_411[2]},{&g_411[1],&g_411[2],&g_411[2],&g_411[2]},{&g_411[1],&g_411[2],&g_411[0],&g_411[0]}},{{&g_411[2],&g_411[2],&g_411[2],&g_411[2]},{&g_411[2],&g_411[2],&g_411[2],(void*)0},{&g_411[0],&g_411[2],&g_411[2],&g_411[2]}},{{&g_411[2],&g_411[2],&g_411[2],(void*)0},{&g_411[2],&g_411[2],&g_411[2],&g_411[2]},{&g_411[2],&g_411[2],&g_411[2],&g_411[0]}},{{&g_411[0],&g_411[2],&g_411[2],&g_411[2]},{(void*)0,&g_411[2],&g_411[2],&g_411[2]},{&g_411[0],&g_411[2],&g_411[2],&g_411[0]}},{{&g_411[2],(void*)0,&g_411[2],&g_411[2]},{&g_411[2],&g_411[2],&g_411[2],&g_411[2]},{&g_411[2],&g_411[1],&g_411[2],&g_411[2]}}};
static union U2 g_1875 = {0x8E568416L};/* VOLATILE GLOBAL g_1875 */
static const int64_t g_1887 = 1L;
static volatile union U1 g_1906 = {4294967295UL};/* VOLATILE GLOBAL g_1906 */
static volatile union U1 g_1980 = {1UL};/* VOLATILE GLOBAL g_1980 */
static union U2 g_2034 = {0x5654A137L};/* VOLATILE GLOBAL g_2034 */
static volatile uint32_t g_2053 = 0xBDADCC66L;/* VOLATILE GLOBAL g_2053 */
static volatile uint16_t g_2177 = 65535UL;/* VOLATILE GLOBAL g_2177 */
static volatile uint16_t *g_2176 = &g_2177;
static volatile uint16_t **g_2175 = &g_2176;
static volatile uint64_t g_2218 = 18446744073709551614UL;/* VOLATILE GLOBAL g_2218 */
static volatile uint64_t *g_2217 = &g_2218;
static volatile uint64_t * volatile * volatile g_2216 = &g_2217;/* VOLATILE GLOBAL g_2216 */
static uint64_t *g_2239[7] = {&g_1799,&g_1799,&g_216,&g_1799,&g_1799,&g_216,&g_1799};
static uint64_t **g_2238 = &g_2239[3];
static uint64_t ***g_2237[6][4][9] = {{{(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{(void*)0,&g_2238,&g_2238,(void*)0,&g_2238,&g_2238,&g_2238,(void*)0,&g_2238},{&g_2238,&g_2238,(void*)0,(void*)0,&g_2238,&g_2238,(void*)0,&g_2238,&g_2238}},{{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,(void*)0},{(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,(void*)0,&g_2238},{&g_2238,(void*)0,(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238}},{{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,(void*)0},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,(void*)0},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238}},{{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238}},{{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,(void*)0,&g_2238},{&g_2238,(void*)0,&g_2238,&g_2238,&g_2238,(void*)0,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,(void*)0,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,(void*)0,&g_2238,(void*)0,(void*)0,&g_2238,(void*)0,&g_2238,&g_2238}},{{&g_2238,(void*)0,&g_2238,(void*)0,&g_2238,(void*)0,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238},{&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238,&g_2238}}};
static const union U2 *g_2284 = &g_745;
static const union U2 ** volatile g_2283 = &g_2284;/* VOLATILE GLOBAL g_2283 */
static volatile int16_t g_2295 = (-3L);/* VOLATILE GLOBAL g_2295 */
static volatile union U0 g_2328 = {0x55AF744EF900D369LL};/* VOLATILE GLOBAL g_2328 */
static union U2 *g_2341[9] = {&g_745,&g_745,&g_745,&g_745,&g_745,&g_745,&g_745,&g_745,&g_745};
static volatile union U0 g_2352 = {-1L};/* VOLATILE GLOBAL g_2352 */
static volatile union U1 g_2357 = {0UL};/* VOLATILE GLOBAL g_2357 */
static volatile union U0 g_2379 = {4L};/* VOLATILE GLOBAL g_2379 */
static uint64_t g_2397 = 0x98CB08543CEF214CLL;
static volatile uint8_t g_2435[2] = {0UL,0UL};
static union U1 ** volatile g_2446 = (void*)0;/* VOLATILE GLOBAL g_2446 */
static union U1 *g_2448[6] = {&g_754,&g_754,&g_754,&g_754,&g_754,&g_754};
static union U1 ** const  volatile g_2447 = &g_2448[5];/* VOLATILE GLOBAL g_2447 */
static volatile union U0 g_2459[5][7] = {{{0x42CE47DB1E2ACA16LL},{4L},{4L},{0x42CE47DB1E2ACA16LL},{5L},{0x42CE47DB1E2ACA16LL},{4L}},{{-1L},{-1L},{4L},{0x0588701BE0649A8FLL},{4L},{-1L},{-1L}},{{-1L},{4L},{0x0588701BE0649A8FLL},{4L},{-1L},{-1L},{4L}},{{0x42CE47DB1E2ACA16LL},{5L},{0x42CE47DB1E2ACA16LL},{4L},{4L},{0x42CE47DB1E2ACA16LL},{5L}},{{4L},{5L},{0x0588701BE0649A8FLL},{0x0588701BE0649A8FLL},{5L},{4L},{5L}}};
static uint8_t g_2478 = 0x51L;
static const volatile union U2 g_2504 = {4294967291UL};/* VOLATILE GLOBAL g_2504 */
static uint64_t ****g_2574 = &g_2237[3][1][4];
static uint32_t g_2585 = 18446744073709551615UL;
static volatile int8_t g_2600 = 0x48L;/* VOLATILE GLOBAL g_2600 */
static volatile uint16_t ***g_2606 = &g_2175;
static const volatile union U0 g_2607[4] = {{0L},{0L},{0L},{0L}};
static int64_t g_2640 = 0x0CEACB13D7889DF5LL;
static union U0 g_2659 = {0x18FAFCB658777982LL};/* VOLATILE GLOBAL g_2659 */
static uint32_t g_2673 = 18446744073709551607UL;
static volatile uint32_t g_2704 = 0x6A8EBE8AL;/* VOLATILE GLOBAL g_2704 */
static volatile union U1 g_2710 = {4294967295UL};/* VOLATILE GLOBAL g_2710 */
static const volatile union U0 g_2726[8] = {{0L},{0L},{0L},{0L},{0L},{0L},{0L},{0L}};
static union U1 g_2768[1][6] = {{{0xFB1BAA7AL},{0xFB1BAA7AL},{0xFB1BAA7AL},{0xFB1BAA7AL},{0xFB1BAA7AL},{0xFB1BAA7AL}}};
static uint8_t **g_2773 = &g_341;
static uint8_t ***g_2772 = &g_2773;
static uint8_t ****g_2771 = &g_2772;
static int32_t *g_2788 = (void*)0;
static int32_t **g_2787 = &g_2788;
static uint32_t g_2789 = 0xCD406E11L;
static volatile union U1 g_2790 = {0x3947690DL};/* VOLATILE GLOBAL g_2790 */
static const uint64_t g_2807 = 18446744073709551615UL;
static union U1 g_2816 = {0x4BDF7BFFL};/* VOLATILE GLOBAL g_2816 */
static volatile union U1 g_2841 = {0UL};/* VOLATILE GLOBAL g_2841 */
static union U2 g_2899 = {0x4798463EL};/* VOLATILE GLOBAL g_2899 */
static int32_t g_2900 = (-1L);
static uint16_t *g_2917 = &g_1343[2][0];
static volatile union U2 g_2931 = {0xD452230AL};/* VOLATILE GLOBAL g_2931 */
static volatile union U0 g_2941[8] = {{0x1E4DBD7F4A7D83C2LL},{-5L},{0x1E4DBD7F4A7D83C2LL},{0x1E4DBD7F4A7D83C2LL},{-5L},{0x1E4DBD7F4A7D83C2LL},{0x1E4DBD7F4A7D83C2LL},{-5L}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_2(int64_t  p_3, uint8_t  p_4);
static int8_t  func_8(const int32_t  p_9, uint16_t  p_10, uint64_t  p_11);
static uint16_t  func_13(uint32_t  p_14, const int16_t  p_15);
static uint16_t  func_20(int32_t  p_21, const int32_t  p_22);
static union U0  func_23(int32_t  p_24, int16_t  p_25, uint16_t  p_26, uint32_t  p_27, int8_t  p_28);
static uint16_t  func_32(uint8_t  p_33, uint32_t  p_34, uint64_t  p_35, int64_t  p_36);
static union U1  func_37(uint32_t  p_38);
static int32_t * func_41(int8_t  p_42);
static int8_t  func_43(int64_t  p_44, uint8_t  p_45, int32_t * p_46, int32_t * p_47);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_73 g_68 g_95 g_63 g_104 g_152 g_161 g_168 g_162 g_96 g_106.f0 g_171 g_204 g_203 g_216 g_218 g_152.f1 g_263 g_269 g_95.f0 g_225 g_370 g_379 g_397 g_399 g_410 g_377 g_269.f0 g_330 g_801 g_493 g_398 g_152.f0 g_754.f1 g_862.f2 g_929 g_1025 g_671.f2 g_1050 g_152.f2 g_421 g_671.f1 g_1058 g_1066 g_1026 g_341 g_1067 g_263.f0 g_1009 g_855 g_745 g_329 g_765 g_1153 g_1167 g_1184 g_547.f1 g_1184.f0 g_1198 g_671 g_1206 g_1242 g_586.f1 g_1273 g_410.f1 g_862.f1 g_1320 g_1058.f1 g_1325 g_1237.f3 g_862 g_1343 g_618.f0 g_1363 g_1325.f0 g_1390 g_1407 g_1364 g_375 g_475.f1 g_1453 g_1482 g_547 g_1484 g_1482.f3 g_1236.f2 g_1491 g_1504 g_1008 g_745.f3 g_1531 g_410.f0 g_1445 g_1584 g_475.f2 g_1669 g_764 g_525.f0 g_754.f2 g_1273.f2 g_1696 g_2640 g_1207 g_586.f2 g_2606 g_2175 g_1848 g_1849 g_1850 g_1604 g_2397 g_2176 g_2177 g_2673 g_2704 g_2710 g_1809 g_1810 g_1811 g_2726 g_2726.f0 g_2217 g_2218 g_2768 g_2771 g_2787 g_2789 g_2790 g_950.f0 g_2816 g_2216 g_2341 g_2841 g_2899 g_1273.f1 g_2900 g_2917 g_2931 g_2941
 * writes: g_63 g_73 g_96 g_68 g_101 g_104 g_161 g_171 g_162 g_203 g_216 g_218 g_225 g_204 g_328 g_331 g_341 g_370 g_375 g_377 g_379 g_397 g_411 g_421 g_1008 g_1009 g_1065 g_745.f3 g_1303 g_1237.f3 g_1363 g_1443 g_1445 g_1453 g_329 g_929 g_1482.f3 g_1236.f2 g_1207 g_855 g_1529 g_1568 g_1343 g_1584 g_1640 g_1585 g_1669 g_1696 g_1604 g_2673 g_2704 g_2771 g_2789 g_1850 g_2397
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_5 = 18446744073709551615UL;
    uint8_t l_1322 = 8UL;
    const uint16_t l_1326 = 0x67B3L;
    int32_t *l_1683 = &g_203;
    const uint32_t l_1684 = 0UL;
    uint8_t *l_2666 = &g_1568;
    int16_t l_2954 = 0L;
    int32_t *l_2955[10] = {&g_68,&g_1604,&g_68,&g_1604,&g_68,&g_1604,&g_68,&g_1604,&g_68,&g_1604};
    uint32_t l_2956[2];
    uint16_t l_2959 = 1UL;
    int i;
    for (i = 0; i < 2; i++)
        l_2956[i] = 0UL;
    l_2954 ^= (((8UL == (func_2(l_5, ((*l_2666) = ((safe_lshift_func_int8_t_s_s(func_8(g_12, func_13(((((0x6968939F5FA31871LL && (0x3563L && (safe_mod_func_uint32_t_u_u(1UL, ((*l_1683) = (safe_mul_func_uint16_t_u_u(func_20(((g_12 , func_23(l_5, (safe_unary_minus_func_int32_t_s((safe_lshift_func_uint8_t_u_u((func_32(l_5, g_12, g_12, g_12) <= g_1058.f1), 4)))), g_586.f1, g_754.f1, l_1322)) , l_1322), l_1326), g_754.f2))))))) ^ g_754.f1) <= g_1273.f2) , (*l_1683)), l_1684), g_2640), g_2397)) && (***g_2606)))) & 0xF3L)) , (*l_1683)) || (*l_1683));
    ++l_2956[1];
    return l_2959;
}


/* ------------------------------------------ */
/* 
 * reads : g_2673 g_104 g_1850 g_1604 g_2704 g_1453 g_2710 g_1848 g_1849 g_1809 g_1810 g_1811 g_929 g_2175 g_2176 g_2177 g_2726 g_855 g_2726.f0 g_1325 g_2217 g_2218 g_2768 g_2771 g_2787 g_2789 g_2790 g_1050 g_950.f0 g_2816 g_2216 g_2341 g_745 g_2841 g_1364 g_375 g_2606 g_2899 g_1273.f1 g_2900 g_2917 g_1343 g_765 g_2931 g_204 g_2941 g_1445
 * writes: g_2673 g_104 g_1604 g_2704 g_1453 g_855 g_2771 g_2789 g_1850 g_375 g_2397 g_101 g_203 g_216 g_171
 */
static uint8_t  func_2(int64_t  p_3, uint8_t  p_4)
{ /* block id: 1196 */
    int32_t l_2667 = 0x287CA743L;
    int32_t l_2668 = (-4L);
    int32_t *l_2669 = &l_2668;
    int32_t *l_2670 = (void*)0;
    int32_t *l_2671 = (void*)0;
    int32_t *l_2672[3];
    int16_t ***l_2676[10] = {(void*)0,&g_1867[1][2][2],(void*)0,&g_1867[1][2][2],(void*)0,&g_1867[1][2][2],(void*)0,&g_1867[1][2][2],(void*)0,&g_1867[1][2][2]};
    uint32_t l_2681 = 0x20170636L;
    union U2 **l_2764 = &g_2341[0];
    uint8_t ****l_2775 = &g_2772;
    int64_t * const *l_2780 = &g_1364;
    int32_t l_2852 = 0x3EF09272L;
    uint32_t ****l_2889 = (void*)0;
    int32_t *** const **l_2918 = (void*)0;
    uint8_t l_2920 = 0x22L;
    int i;
    for (i = 0; i < 3; i++)
        l_2672[i] = &g_203;
    g_2673--;
    if (((void*)0 != l_2676[0]))
    { /* block id: 1198 */
        int8_t l_2686 = (-10L);
        uint16_t *l_2687 = &g_104;
        int32_t l_2690 = (-1L);
        int32_t l_2696 = 0x2B71FAEAL;
        int32_t l_2697 = 0x168EB2C8L;
        uint16_t l_2703 = 0x33A6L;
        uint32_t **l_2718 = &g_1443[7][1][3];
        int32_t ** const l_2834 = &l_2669;
        int64_t l_2851 = 9L;
        uint64_t l_2865 = 0UL;
        int32_t *****l_2867 = (void*)0;
        const union U1 *l_2888 = &g_2768[0][4];
        const union U1 **l_2887 = &l_2888;
        uint32_t l_2923 = 0xCC742B81L;
        l_2703 = ((*l_2669) == (safe_rshift_func_int8_t_s_s(((9UL || (safe_sub_func_int64_t_s_s(((l_2681 == ((safe_rshift_func_int8_t_s_s(((((l_2690 ^= (safe_mul_func_int16_t_s_s(l_2686, ((*l_2687)--)))) | ((safe_mul_func_int16_t_s_s((-8L), (+(safe_rshift_func_uint16_t_u_u((0x126B1745L > (l_2697 ^= (l_2696 = (p_3 , l_2686)))), 15))))) && ((*g_1850) |= (+((((safe_add_func_int16_t_s_s((safe_add_func_uint8_t_u_u(l_2696, p_4)), (-3L))) , p_3) <= 0x0DBCD00AL) >= p_3))))) || 0x05L) && p_3), 6)) < l_2686)) & p_3), l_2686))) >= p_3), 2)));
        ++g_2704;
        for (g_1453 = 0; (g_1453 == 10); g_1453++)
        { /* block id: 1208 */
            int64_t ***l_2709 = &g_1363;
            uint32_t **l_2717 = &g_1445;
            int32_t l_2722 = 1L;
            uint32_t l_2749 = 0UL;
            int64_t l_2752 = 0x6863FC3727092949LL;
            uint64_t **l_2808 = &g_2239[2];
            int16_t *l_2863 = (void*)0;
            int64_t *l_2886[3];
            int32_t l_2919 = 0L;
            int i;
            for (i = 0; i < 3; i++)
                l_2886[i] = &l_2851;
            if (((l_2709 != (void*)0) | (((g_2710 , (safe_div_func_uint16_t_u_u(((*l_2687) = (safe_sub_func_uint16_t_u_u((l_2696 , (safe_lshift_func_int16_t_s_u(0x7FD6L, 2))), ((l_2717 != (l_2718 = &g_1445)) > (safe_unary_minus_func_uint8_t_u((safe_sub_func_uint32_t_u_u((((((***g_1848) = (((void*)0 != &g_1363) , l_2722)) ^ 7L) && (***g_1809)) >= l_2722), p_4)))))))), p_3))) , l_2696) , 3UL)))
            { /* block id: 1212 */
                uint16_t l_2746[10][4][6] = {{{65535UL,65526UL,0xA3B6L,0xC600L,0x456EL,0xE051L},{0xA3B6L,1UL,1UL,1UL,0xA3B6L,65531UL},{0x6EF3L,1UL,0x06FCL,0x456EL,0xE7EDL,0x7B04L},{1UL,1UL,0x433CL,1UL,0xC600L,0x7B04L}},{{1UL,0xB098L,0x06FCL,0x3192L,0xA8C3L,65531UL},{0xC600L,65535UL,1UL,1UL,65531UL,0xE051L},{0xBAABL,0x3742L,0xA3B6L,0x9B38L,1UL,0x75B9L},{0x2F95L,65531UL,1UL,0xE051L,0xBAABL,0x06FCL}},{{65531UL,0x52B6L,0xBAABL,0xBAABL,0x52B6L,65531UL},{65526UL,0x77F0L,0x75B9L,9UL,0x021CL,1UL},{0x3742L,1UL,0x52B6L,0xE7EDL,0x2F95L,0x9B38L},{0x3742L,0x06FCL,0xE7EDL,9UL,1UL,1UL}},{{65526UL,0x021CL,0x95BAL,0xBAABL,0x75B9L,0x1F6FL},{65531UL,9UL,0x3192L,0xE051L,1UL,0x3742L},{0x2F95L,0x3192L,0xC600L,0x9B38L,9UL,1UL},{0xBAABL,0xA8C3L,1UL,1UL,1UL,0xA8C3L}},{{0xC600L,1UL,1UL,0x3192L,0xB098L,0x6EF3L},{1UL,0xC232L,0x7B04L,1UL,65531UL,0UL},{0xA8C3L,0xC600L,0x433CL,0x021CL,0xC232L,0x1257L},{0x7B04L,0x9B38L,0x77F0L,0x52B6L,0x3742L,0x1F6FL}},{{0x456EL,0UL,0xE7EDL,0xBAABL,1UL,0UL},{0UL,1UL,0xE425L,1UL,0x2F95L,0xB098L},{0UL,0xB098L,65526UL,65531UL,65531UL,65526UL},{9UL,9UL,1UL,0xA8C3L,0x9B38L,1UL}},{{0x3742L,0x6EF3L,0x06FCL,0xC600L,65526UL,1UL},{65526UL,0x3742L,0x06FCL,0xE7EDL,9UL,1UL},{9UL,0xE7EDL,1UL,0xA3B6L,0x1257L,65526UL},{0xA3B6L,0x1257L,65526UL,0x456EL,1UL,0xB098L}},{{0x433CL,1UL,0xE425L,0x6EF3L,0x75B9L,0UL},{0x75B9L,0x95BAL,0xE7EDL,0x1F6FL,1UL,0x1F6FL},{0x77F0L,0UL,0x77F0L,0x7B04L,0UL,0x1257L},{0x1F6FL,0xC232L,0x433CL,9UL,0xBAABL,0xA3B6L}},{{1UL,0xE051L,0x3192L,9UL,65531UL,0x7B04L},{0x1F6FL,0x2F95L,0xE051L,0x7B04L,0x456EL,0UL},{0x77F0L,0x52B6L,0x3742L,0x1F6FL,0x021CL,0x2F95L},{0x75B9L,1UL,0xBAABL,0x6EF3L,0x7B04L,0x95BAL}},{{0x433CL,65526UL,1UL,0x456EL,1UL,1UL},{0xA3B6L,0x1F6FL,0x1F6FL,0xA3B6L,0x3192L,0x433CL},{9UL,0xBAABL,65531UL,0xE7EDL,0xB098L,1UL},{65526UL,0x7B04L,0x1257L,0xC600L,0xB098L,0xE425L}}};
                int32_t l_2747 = 1L;
                int32_t *l_2751 = (void*)0;
                int32_t **l_2750 = &l_2751;
                uint64_t l_2753 = 0UL;
                int i, j, k;
                if ((0x3BFFL | (**g_2175)))
                { /* block id: 1213 */
                    return p_4;
                }
                else
                { /* block id: 1215 */
                    uint8_t *l_2733 = &g_1843.f3;
                    uint8_t *l_2734 = (void*)0;
                    uint8_t *l_2735 = &g_855[0][1];
                    int32_t l_2748 = 0xF4B13417L;
                    uint64_t l_2767[8][2][7] = {{{3UL,0xA43CBBF44C2A1944LL,0x0A10E92E24C3CB2DLL,0x9470E42AD5935DFFLL,1UL,18446744073709551614UL,18446744073709551615UL},{1UL,5UL,1UL,0x0B0EBBBBC09C8B41LL,18446744073709551611UL,1UL,18446744073709551611UL}},{{0UL,1UL,1UL,0UL,3UL,1UL,0x90AD60A9A98F2B42LL},{0x0B0EBBBBC09C8B41LL,1UL,5UL,1UL,0xCE00E0F9A649531CLL,0xC3C8154669B318A0LL,0xFFFF730B86839C62LL}},{{0x9470E42AD5935DFFLL,0x0A10E92E24C3CB2DLL,0xA43CBBF44C2A1944LL,3UL,18446744073709551612UL,0x0E17046C7CE9F89ELL,0x90AD60A9A98F2B42LL},{0xFFFF730B86839C62LL,3UL,18446744073709551613UL,18446744073709551613UL,3UL,0xFFFF730B86839C62LL,18446744073709551611UL}},{{1UL,0x9470E42AD5935DFFLL,18446744073709551614UL,0x0A10E92E24C3CB2DLL,1UL,0x2E56E5A1D7CBAC2FLL,18446744073709551615UL},{0x84D8DC7DA887BA4ALL,0x8530F2E251EB3815LL,18446744073709551615UL,0x526B5D7E716594E9LL,0x0B0EBBBBC09C8B41LL,0UL,0x2E6E035B02DFFE06LL}},{{0xBC48B835E4A84740LL,0x9470E42AD5935DFFLL,3UL,0x0E17046C7CE9F89ELL,0x0E17046C7CE9F89ELL,1UL,0x39B6A1A5C4940B8ALL},{5UL,0x8530F2E251EB3815LL,0x526B5D7E716594E9LL,5UL,1UL,1UL,18446744073709551615UL}},{{1UL,0xBC48B835E4A84740LL,0x5B414035EAE069D4LL,18446744073709551614UL,3UL,0x0A10E92E24C3CB2DLL,0x49023C2EED67B591LL},{0x526B5D7E716594E9LL,0xC3C8154669B318A0LL,18446744073709551615UL,5UL,3UL,3UL,5UL}},{{1UL,0x49023C2EED67B591LL,1UL,0x0E17046C7CE9F89ELL,0x5B414035EAE069D4LL,0x9470E42AD5935DFFLL,0x2E56E5A1D7CBAC2FLL},{0x0B0EBBBBC09C8B41LL,18446744073709551606UL,0xFFFF730B86839C62LL,1UL,0UL,0x8530F2E251EB3815LL,18446744073709551611UL}},{{0x49023C2EED67B591LL,1UL,0x0A10E92E24C3CB2DLL,0xBC48B835E4A84740LL,1UL,0x9470E42AD5935DFFLL,0x9470E42AD5935DFFLL},{1UL,4UL,1UL,4UL,1UL,3UL,0x84D8DC7DA887BA4ALL}}};
                    int i, j, k;
                    (*g_1850) &= (((((safe_sub_func_uint16_t_u_u(p_4, 0x57E2L)) <= (safe_unary_minus_func_int64_t_s((p_3 = (g_2726[6] , (safe_rshift_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((++(*l_2735)), (safe_mod_func_uint64_t_u_u((((safe_mod_func_uint16_t_u_u(((*l_2687) = (safe_mul_func_int8_t_s_s(0L, (((func_23(g_2726[6].f0, (l_2747 = (safe_mod_func_int8_t_s_s(((((l_2722 <= 4294967288UL) ^ (l_2722 == 18446744073709551615UL)) , l_2746[5][3][0]) & 0xA6L), 0xAAL))), l_2748, p_4, l_2749) , l_2750) != &l_2751) , 0x68L)))), l_2748)) && l_2752) , (*g_2217)), p_3)))), 1UL)), 11))))))) || p_3) , p_4) || p_4);
                    --l_2753;
                    (*g_1850) = ((safe_div_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((((((((l_2690 = l_2748) , l_2764) == (void*)0) || (safe_add_func_uint16_t_u_u(l_2767[6][0][0], 0L))) ^ p_4) >= (g_2768[0][0] , (l_2767[5][1][0] >= (0x28L < (*l_2669))))) , p_4), 9UL)), l_2767[1][0][0])), p_4)), p_4)) && (-1L));
                }
            }
            else
            { /* block id: 1225 */
                uint8_t *****l_2774 = &g_2771;
                int32_t *l_2786 = (void*)0;
                int32_t * const *l_2785 = &l_2786;
                int32_t l_2825 = 0x91B05564L;
                int32_t l_2835 = 5L;
                int32_t l_2836 = 0xFDD568CEL;
                int8_t *l_2878[4][5] = {{&g_73,&g_1303,&g_1303,&g_1303,&g_1303},{&g_73,&g_1303,&g_1303,&g_1303,&g_1303},{&g_73,&g_1303,&g_1303,&g_1303,&g_1303},{&g_73,&g_1303,&g_1303,&g_1303,&g_1303}};
                int i, j;
                if ((safe_lshift_func_int16_t_s_s(((((((*l_2774) = g_2771) == l_2775) , ((safe_mod_func_int64_t_s_s(p_3, (safe_add_func_int64_t_s_s(((l_2780 == (void*)0) < ((((safe_mul_func_int16_t_s_s((g_2789 &= ((safe_lshift_func_int8_t_s_u(0x32L, 7)) || (l_2785 != g_2787))), ((g_2790 , (void*)0) != (*l_2785)))) || 0L) < 7UL) > l_2703)), 0x5B704A81277D9A1FLL)))) , p_4)) <= 0x39755B99L) , l_2686), 11)))
                { /* block id: 1228 */
                    uint64_t l_2791 = 0x22E8BFAE29399C8DLL;
                    int32_t l_2815 = (-6L);
                    int16_t *l_2864 = &g_218;
                    uint8_t l_2871 = 0UL;
                    int32_t l_2915 = 0xE9A8B554L;
                    int64_t l_2916[4][5][4] = {{{(-2L),0xA8FAAC4B83CA26FELL,0x56D23721FBC1DD27LL,1L},{0x31C5B948C26F65E9LL,0xD3E1366A4CF73EBCLL,(-1L),1L},{(-1L),1L,0L,2L},{0x9FAF291E16D1F3C5LL,(-1L),(-1L),1L},{1L,(-2L),2L,1L}},{{0x45D56CA661B0745ALL,0x9FAF291E16D1F3C5LL,0xF95C4CFB841C3E52LL,0xF95C4CFB841C3E52LL},{1L,1L,0xE8D92C647BFD7818LL,(-2L)},{1L,0xF95C4CFB841C3E52LL,0x45D56CA661B0745ALL,0xA8FAAC4B83CA26FELL},{0x472B0617FF24FE42LL,0x31C5B948C26F65E9LL,0L,0x45D56CA661B0745ALL},{1L,0x31C5B948C26F65E9LL,(-1L),0xA8FAAC4B83CA26FELL}},{{0x31C5B948C26F65E9LL,0xF95C4CFB841C3E52LL,0x969CC07D30BC29CCLL,(-2L)},{0x70E7F11BEDDF7199LL,1L,0x472B0617FF24FE42LL,0xF95C4CFB841C3E52LL},{1L,0x9FAF291E16D1F3C5LL,(-7L),1L},{(-2L),(-2L),0x969CC07D30BC29CCLL,1L},{0xEF07BE6B2D6B2EECLL,(-1L),(-1L),2L}},{{1L,1L,0x63EF855E39DFBEBCLL,1L},{0x9FAF291E16D1F3C5LL,0xD3E1366A4CF73EBCLL,0x45D56CA661B0745ALL,1L},{0x15D0EE769718067FLL,0xA8FAAC4B83CA26FELL,2L,0xF3DFFB4C034E7A27LL},{1L,0x9FAF291E16D1F3C5LL,0L,8L},{1L,0x45D56CA661B0745ALL,2L,(-2L)}}};
                    int i, j, k;
                    if (l_2791)
                    { /* block id: 1229 */
                        uint64_t l_2798 = 0x402758BA651E672ELL;
                        int32_t l_2799 = 1L;
                        const uint64_t **l_2800 = (void*)0;
                        const uint64_t ***l_2801 = (void*)0;
                        const uint64_t ***l_2802 = &l_2800;
                        const uint64_t ***l_2803 = (void*)0;
                        const uint64_t *l_2806 = &g_2807;
                        const uint64_t **l_2805 = &l_2806;
                        const uint64_t ***l_2804 = &l_2805;
                        l_2815 = ((*g_1850) = (safe_lshift_func_uint8_t_u_s((((safe_mul_func_int8_t_s_s((((*l_2687) = (safe_lshift_func_uint8_t_u_u(l_2798, 1))) ^ (l_2799 = ((void*)0 != &g_73))), (l_2690 < (*g_1050)))) < (((*l_2804) = ((*l_2802) = l_2800)) == l_2808)) != (safe_sub_func_int32_t_s_s(((((p_4 , ((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(l_2791, l_2752)), p_3)) && p_4)) || p_3) >= 0xAA7483A6EE2A5386LL) , p_3), 0x58198600L))), p_3)));
                        (*l_2669) = (g_2816 , (safe_sub_func_int16_t_s_s((safe_add_func_int16_t_s_s((((safe_div_func_int32_t_s_s(0xA31A2EFAL, (safe_sub_func_uint64_t_u_u(((((p_4 || (l_2825 ^= p_4)) , p_3) , 0x2314L) >= (safe_rshift_func_int8_t_s_s((l_2835 = (l_2799 | (safe_mod_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(((safe_mod_func_uint32_t_u_u(((p_4 , &l_2672[0]) == l_2834), l_2835)) || l_2749), (**l_2834))), l_2815)))), (**l_2834)))), l_2749)))) | (**g_2216)) && 9UL), 0UL)), l_2836)));
                        (**l_2834) = (*g_1850);
                    }
                    else
                    { /* block id: 1240 */
                        uint64_t *l_2844[4][1][6] = {{{&g_1799,&g_1799,&g_1799,&g_216,&g_216,&g_216}},{{&g_1799,&g_1799,&g_1799,&g_216,&g_216,&g_216}},{{&g_1799,&g_1799,&g_1799,&g_216,&g_216,&g_216}},{{&g_1799,&g_1799,&g_1799,&g_216,&g_216,&g_216}}};
                        int32_t l_2845 = 0x85B1E049L;
                        uint8_t l_2850 = 0x68L;
                        int i, j, k;
                        (**g_1848) = &l_2668;
                        (***g_1848) = (safe_mul_func_int8_t_s_s(((p_3 , ((**l_2764) , (safe_rshift_func_int8_t_s_u((g_2841 , p_3), 2)))) | (safe_sub_func_uint64_t_u_u((l_2845 &= (l_2749 , 1UL)), l_2791))), (safe_add_func_uint32_t_u_u(p_4, (safe_rshift_func_uint16_t_u_u(((l_2850 = ((*g_1364) ^= (((p_3 == l_2825) , (*l_2834)) != &l_2668))) > l_2851), p_4))))));
                        return p_3;
                    }
                    if (((l_2852 ^ (l_2752 <= ((safe_mul_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u(p_3, l_2752)) || (l_2722 = (safe_div_func_uint8_t_u_u(((1L || ((l_2722 >= (safe_sub_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((l_2863 == (l_2864 = l_2864)), 0x25508559L)), p_3))) || (***g_1848))) , l_2752), l_2865)))), 0xD8D1L)) < 0UL))) , p_4))
                    { /* block id: 1250 */
                        const int32_t *****l_2866[1][4];
                        int32_t l_2868 = 1L;
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 4; j++)
                                l_2866[i][j] = (void*)0;
                        }
                        l_2868 = ((l_2866[0][3] != l_2867) == (**l_2834));
                    }
                    else
                    { /* block id: 1252 */
                        int64_t l_2869 = 0x3F17121ED21114C8LL;
                        int32_t l_2870 = (-10L);
                        int64_t **l_2885[9] = {&g_1364,&g_1364,&g_1364,&g_1364,&g_1364,&g_1364,&g_1364,&g_1364,&g_1364};
                        uint64_t *l_2890 = &g_2397;
                        int i;
                        l_2871--;
                        l_2870 ^= ((*l_2669) &= (((-6L) | ((*l_2890) = (p_4 >= (safe_rshift_func_uint8_t_u_s(6UL, (((void*)0 != l_2878[0][2]) == ((((*g_1850) = (safe_sub_func_uint8_t_u_u((((p_4 && (safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((&p_3 != (l_2886[1] = &p_3)), (((((*g_1364) = l_2825) , (void*)0) != l_2887) >= l_2791))), 0x70L))) , l_2889) == (void*)0), 247UL))) && 0xE1E2DD0DL) & 0xA2077CA37641A783LL))))))) || p_4));
                        l_2835 = ((**l_2834) |= ((void*)0 != l_2718));
                        (**l_2834) = ((((((p_4 == (safe_lshift_func_uint8_t_u_s((safe_sub_func_int64_t_s_s((l_2815 >= l_2722), (((((&g_2175 == &g_2175) , (safe_rshift_func_int8_t_s_u(0x6EL, ((**g_2606) == (((safe_div_func_int16_t_s_s((g_2899 , (p_4 | p_4)), g_1273.f1)) && l_2815) , (void*)0))))) && p_4) || 0UL) && p_3))), g_2900))) ^ p_3) && p_4) > 5L) , p_4) , l_2836);
                    }
                    if (l_2791)
                        break;
                    (*g_1850) |= (safe_sub_func_uint32_t_u_u(((((*l_2687) = (*g_2176)) & ((p_4 != 0x95D342F9A3D66E1BLL) || (0xA67A2916L != (**l_2834)))) | 0x2F08EB77L), (((safe_lshift_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((((safe_lshift_func_int16_t_s_s((p_4 ^ 0L), ((safe_div_func_int16_t_s_s((safe_mod_func_int8_t_s_s(((safe_add_func_int32_t_s_s((((p_3 , p_3) < p_4) , p_4), 0x10511EB3L)) || l_2915), l_2916[0][1][0])), g_855[0][5])) || 1UL))) , (void*)0) == g_2917), l_2815)) ^ 0xC8374038B126C247LL), (*g_2917))) , l_2918) == (void*)0)));
                }
                else
                { /* block id: 1267 */
                    (*g_765) = (void*)0;
                }
                ++l_2920;
                l_2923--;
            }
        }
    }
    else
    { /* block id: 1274 */
        const int32_t *l_2930[7][9] = {{&g_203,&g_1198.f1,&g_203,&l_2667,&g_203,&g_2768[0][0].f1,&g_1604,&g_2768[0][0].f1,&g_203},{&g_2768[0][0].f1,&g_203,&g_203,&g_2768[0][0].f1,&g_1604,&g_2768[0][0].f1,&g_203,&g_203,&g_2768[0][0].f1},{&l_2667,&g_203,&g_1198.f1,&g_203,&l_2667,&l_2667,&g_203,&g_1198.f1,&g_203},{&g_203,&g_1604,&g_1198.f1,&g_1198.f1,&g_1604,&g_203,&g_1604,&g_1198.f1,&g_1198.f1},{&l_2667,&l_2667,&g_203,&g_1198.f1,&g_203,&l_2667,&l_2667,&g_203,&g_1198.f1},{&g_2768[0][0].f1,&g_1604,&g_2768[0][0].f1,&g_203,&g_203,&g_2768[0][0].f1,&g_1604,&g_2768[0][0].f1,&g_203},{&g_2768[0][0].f1,&g_203,&g_203,&g_2768[0][0].f1,&g_1604,&g_2768[0][0].f1,&g_203,&g_203,&g_2768[0][0].f1}};
        const int8_t *l_2932 = &g_63;
        int8_t *l_2933 = (void*)0;
        int8_t **l_2934 = &l_2933;
        int32_t l_2937 = 0x80E59F93L;
        uint64_t *l_2938 = &g_216;
        uint8_t *l_2944 = &g_855[0][5];
        int64_t l_2949 = (-1L);
        int i, j;
        (*g_204) = ((((safe_sub_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(p_4, (l_2930[1][3] != &l_2667))), 0xF8L)) , g_2931) , l_2932) == ((*l_2934) = l_2933));
        (***g_1848) ^= ((safe_mod_func_int8_t_s_s((((((*l_2938) = (l_2937 = p_3)) > 0L) <= p_3) && ((safe_div_func_uint32_t_u_u(((*g_1445) = ((g_2941[3] , (safe_mul_func_int8_t_s_s((l_2937 ^= p_4), (--(*l_2944))))) & (safe_sub_func_uint8_t_u_u(l_2949, p_3)))), (safe_rshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_u((-6L), 11)), 4)))) <= p_3)), 0x3BL)) , 0x35F83483L);
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_1206 g_1207 g_586.f2 g_171 g_1343 g_2606 g_2175 g_1364 g_375 g_1848 g_1849 g_1850 g_1604
 * writes: g_1343 g_1604
 */
static int8_t  func_8(const int32_t  p_9, uint16_t  p_10, uint64_t  p_11)
{ /* block id: 1188 */
    uint8_t l_2657 = 0xFBL;
    union U0 *l_2658 = &g_2659;
    int16_t *l_2660[1][2];
    int32_t l_2661[2];
    int32_t l_2662 = 0x450A989EL;
    uint16_t *l_2663 = &g_1343[6][1];
    uint64_t *l_2664[5] = {&g_216,&g_216,&g_216,&g_216,&g_216};
    int32_t l_2665 = (-8L);
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_2660[i][j] = &g_218;
    }
    for (i = 0; i < 2; i++)
        l_2661[i] = 1L;
    (***g_1848) ^= (safe_sub_func_uint32_t_u_u(((void*)0 != (*g_1206)), ((p_10 , (l_2665 = ((((safe_sub_func_uint8_t_u_u(((((safe_sub_func_uint64_t_u_u((((safe_div_func_uint8_t_u_u((((0x4AL == (0xC4L & (g_586.f2 || ((*l_2663) |= ((safe_lshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((l_2662 = (l_2661[1] &= ((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u(l_2657, g_171)), 1)) < ((((((-3L) != l_2657) == (-1L)) , l_2657) , l_2658) == (void*)0)))), 15)), p_9)) , p_9))))) , l_2662) != l_2657), l_2657)) == l_2657) != l_2657), 0xCF8BC0770472E8EALL)) , l_2661[1]) , &l_2663) == (*g_2606)), 0x54L)) , (*g_1364)) && 18446744073709551615UL) , l_2661[0]))) > l_2657)));
    return l_2662;
}


/* ------------------------------------------ */
/* 
 * reads : g_1696
 * writes: g_203 g_1696
 */
static uint16_t  func_13(uint32_t  p_14, const int16_t  p_15)
{ /* block id: 778 */
    int32_t l_1694 = 0xBB643A24L;
    int32_t l_1695 = 0x7E01C27BL;
    const uint32_t l_1701 = 0x2BB2DFC3L;
    uint8_t *l_1703 = &g_1238.f3;
    int32_t l_1716 = (-6L);
    int32_t l_1717 = 0x4F422446L;
    int32_t l_1722 = (-1L);
    int32_t l_1723 = 0xB07F558AL;
    int32_t l_1724 = (-4L);
    int32_t l_1725[6] = {0xA354F054L,0x196D45E0L,0x196D45E0L,0xA354F054L,0x196D45E0L,0x196D45E0L};
    int32_t l_1727[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    int32_t l_1788[3][3][7] = {{{0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL},{9L,9L,9L,9L,9L,9L,9L},{0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL}},{{9L,9L,9L,9L,9L,9L,9L},{0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL},{9L,9L,9L,9L,9L,9L,9L}},{{0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL},{9L,9L,9L,9L,9L,9L,9L},{0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL,(-1L),0xBCB5354FL}}};
    int32_t l_1797 = 0x984A4777L;
    const int16_t l_1815 = (-6L);
    int64_t l_1838[2][9][2] = {{{(-5L),(-5L)},{(-1L),(-5L)},{(-5L),1L},{0xC8789ED91849C8D5LL,(-1L)},{(-1L),0xC8789ED91849C8D5LL},{(-1L),1L},{(-1L),0xC8789ED91849C8D5LL},{(-1L),(-1L)},{0xC8789ED91849C8D5LL,1L}},{{(-5L),(-5L)},{(-1L),(-5L)},{(-5L),1L},{0xC8789ED91849C8D5LL,(-1L)},{(-1L),0xC8789ED91849C8D5LL},{(-1L),1L},{(-1L),0xC8789ED91849C8D5LL},{(-1L),(-1L)},{0xC8789ED91849C8D5LL,1L}}};
    int64_t l_1882 = 0xC883D02739638E27LL;
    union U0 ***l_1902 = (void*)0;
    int8_t l_1912 = 0xC0L;
    uint32_t *l_1966 = (void*)0;
    uint32_t l_2145[3][8][2] = {{{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL}},{{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL}},{{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL},{0x27FFFBBCL,0x27FFFBBCL}}};
    int32_t l_2223 = 0x7D21DF0AL;
    uint64_t *l_2232[1][5];
    uint64_t * const *l_2231[9][7] = {{&l_2232[0][0],&l_2232[0][0],&l_2232[0][3],(void*)0,(void*)0,&l_2232[0][2],(void*)0},{&l_2232[0][1],&l_2232[0][2],&l_2232[0][2],&l_2232[0][3],&l_2232[0][2],&l_2232[0][2],&l_2232[0][0]},{(void*)0,&l_2232[0][2],&l_2232[0][1],&l_2232[0][2],(void*)0,&l_2232[0][2],&l_2232[0][0]},{&l_2232[0][1],&l_2232[0][4],&l_2232[0][2],(void*)0,&l_2232[0][2],(void*)0,(void*)0},{(void*)0,&l_2232[0][2],&l_2232[0][2],&l_2232[0][2],(void*)0,&l_2232[0][0],&l_2232[0][2]},{&l_2232[0][4],(void*)0,&l_2232[0][1],&l_2232[0][1],&l_2232[0][2],&l_2232[0][0],&l_2232[0][2]},{&l_2232[0][2],&l_2232[0][3],&l_2232[0][2],&l_2232[0][1],(void*)0,(void*)0,&l_2232[0][2]},{&l_2232[0][4],&l_2232[0][1],&l_2232[0][3],&l_2232[0][4],&l_2232[0][2],(void*)0,&l_2232[0][4]},{(void*)0,&l_2232[0][2],(void*)0,&l_2232[0][2],&l_2232[0][2],(void*)0,&l_2232[0][2]}};
    uint64_t * const * const *l_2230 = &l_2231[2][2];
    union U2 *l_2440 = &g_1237;
    union U1 *l_2445[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t *l_2509 = &g_1604;
    int32_t l_2515 = 0L;
    uint16_t *l_2628[3];
    uint32_t l_2629[4] = {0x00FB36C8L,0x00FB36C8L,0x00FB36C8L,0x00FB36C8L};
    uint16_t l_2630[10][10][2] = {{{0x8092L,0xDEEAL},{0x4B79L,0xD27BL},{0UL,1UL},{0x8492L,0UL},{65535UL,0UL},{65527UL,0xD747L},{0x8492L,0x84FCL},{0xD747L,0xD27BL},{0x7315L,0xE7FCL},{0x8092L,0xD2CCL}},{{0x4DB0L,0x2322L},{65530UL,65535UL},{65529UL,65527UL},{1UL,8UL},{0xDEEAL,0xCC18L},{0x2322L,1UL},{8UL,0xAC44L},{1UL,0xCC18L},{0xE7FCL,0xA655L},{1UL,65535UL}},{{0UL,65535UL},{1UL,1UL},{0x4DB0L,0x4DB0L},{0x6E51L,0xE7FCL},{0x4B79L,65529UL},{0xD747L,1UL},{0x7280L,0xD747L},{65535UL,65535UL},{65535UL,0xD747L},{0x7280L,1UL}},{{0xD747L,65529UL},{0x4B79L,0xE7FCL},{0x6E51L,0x4DB0L},{0x4DB0L,1UL},{1UL,65535UL},{0UL,65535UL},{1UL,0xA655L},{0xE7FCL,0xCC18L},{1UL,0xAC44L},{8UL,1UL}},{{0x2322L,0xCC18L},{0xDEEAL,8UL},{65527UL,0xCEC1L},{0xD2CCL,65535UL},{0x5815L,65531UL},{0x6EE9L,1UL},{0xA655L,1UL},{65535UL,1UL},{0xC7C3L,0x20CAL},{1UL,0xC7C3L}},{{0xCEC1L,0x7280L},{0x6E51L,1UL},{1UL,0UL},{1UL,1UL},{0x84FCL,0xC1A4L},{0xA655L,0x6EE9L},{1UL,65531UL},{65531UL,7UL},{0xD2CCL,0x6E51L},{65526UL,65529UL}},{{1UL,2UL},{65531UL,0x5E45L},{65535UL,0x5E45L},{65531UL,2UL},{1UL,65529UL},{65526UL,0x6E51L},{0xD2CCL,7UL},{65531UL,65531UL},{1UL,0x6EE9L},{0xA655L,0xC1A4L}},{{0x84FCL,1UL},{1UL,0UL},{1UL,1UL},{0x6E51L,0x7280L},{0xCEC1L,0xC7C3L},{1UL,0x20CAL},{0xC7C3L,1UL},{65535UL,1UL},{0xA655L,1UL},{0x6EE9L,65531UL}},{{0x5815L,65535UL},{0xD2CCL,0xCEC1L},{65527UL,65529UL},{0xC1A4L,0UL},{65531UL,0xA573L},{65529UL,0x5E45L},{0xDF41L,0UL},{1UL,65535UL},{65527UL,0x6E51L},{65535UL,65535UL}},{{65531UL,0xDF41L},{0x6EE9L,0x6EE9L},{8UL,1UL},{0x84FCL,2UL},{0xC7C3L,0UL},{0x60A0L,0xC7C3L},{0x6E51L,65535UL},{0x6E51L,0xC7C3L},{0x60A0L,0UL},{0xC7C3L,2UL}}};
    uint32_t l_2635[10];
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
            l_2232[i][j] = (void*)0;
    }
    for (i = 0; i < 3; i++)
        l_2628[i] = &g_1343[0][1];
    for (i = 0; i < 10; i++)
        l_2635[i] = 0x7F8B6245L;
    for (g_203 = 0; (g_203 >= (-21)); g_203 = safe_sub_func_int64_t_s_s(g_203, 4))
    { /* block id: 781 */
        int8_t l_1687 = 1L;
        int32_t *l_1688 = &g_68;
        int32_t l_1689 = 0xFE4CBBB7L;
        int32_t *l_1690 = &l_1689;
        int32_t *l_1691 = &g_68;
        int32_t *l_1692 = &g_1604;
        int32_t *l_1693[7][7][5] = {{{&l_1689,(void*)0,&g_1604,&g_203,&l_1689},{&g_203,&g_1604,&g_203,&g_203,&g_203},{(void*)0,(void*)0,&g_203,&l_1689,&l_1689},{(void*)0,&g_1604,&g_203,&g_203,&g_203},{&g_203,&l_1689,&g_68,&g_203,&l_1689},{&g_203,&g_1604,&g_1604,&g_203,&l_1689},{&g_68,(void*)0,&g_203,(void*)0,(void*)0}},{{&g_203,&g_1604,(void*)0,&g_1604,&g_203},{(void*)0,(void*)0,&g_1604,&l_1689,(void*)0},{&g_203,&g_1604,&l_1689,&g_203,&g_68},{&g_203,(void*)0,&l_1689,(void*)0,(void*)0},{(void*)0,&g_203,(void*)0,(void*)0,&g_203},{(void*)0,&g_203,&g_68,(void*)0,(void*)0},{&g_203,&l_1689,&g_203,&g_68,&l_1689}},{{&l_1689,&g_203,&g_1604,(void*)0,&g_203},{&g_203,&l_1689,(void*)0,&g_68,&g_1604},{&l_1689,&g_1604,&g_1604,&g_203,&g_203},{&g_203,&g_203,&g_203,&g_1604,&g_68},{(void*)0,&g_203,&g_203,&g_1604,&g_68},{&g_1604,&g_203,(void*)0,&l_1689,&g_203},{&l_1689,&g_1604,(void*)0,(void*)0,(void*)0}},{{&g_1604,&g_1604,&g_203,&l_1689,&g_1604},{&l_1689,(void*)0,&g_1604,(void*)0,&l_1689},{&g_1604,(void*)0,(void*)0,&g_68,(void*)0},{(void*)0,&l_1689,&l_1689,(void*)0,&l_1689},{&g_203,&g_68,&l_1689,&g_203,&g_1604},{&l_1689,&l_1689,&g_203,&g_1604,(void*)0},{&g_203,&g_203,&g_68,&g_203,&g_203}},{{&g_68,&g_203,&g_1604,(void*)0,&g_203},{&g_203,&g_1604,&g_68,&g_68,&g_68},{&l_1689,&l_1689,&g_1604,(void*)0,&g_203},{&g_1604,&g_203,&g_68,&l_1689,&g_1604},{(void*)0,(void*)0,&g_1604,(void*)0,&g_68},{&g_68,&g_203,&l_1689,&l_1689,&g_203},{&l_1689,&l_1689,(void*)0,&g_1604,(void*)0}},{{&g_68,&g_1604,(void*)0,&g_1604,&g_68},{&l_1689,&g_203,&l_1689,&g_203,&l_1689},{&g_68,&g_203,&g_203,&g_68,&g_203},{&g_68,&l_1689,&l_1689,&g_203,&l_1689},{&g_1604,&g_68,(void*)0,&g_203,&g_68},{&l_1689,&l_1689,&g_1604,(void*)0,(void*)0},{&g_203,(void*)0,&g_203,&g_203,&g_203}},{{&g_203,(void*)0,&g_1604,&g_203,&g_68},{&g_203,&g_1604,(void*)0,(void*)0,&g_1604},{&l_1689,&g_1604,&g_1604,&g_203,&g_203},{&g_203,&g_203,&g_203,&l_1689,&g_68},{&g_68,&g_203,&g_1604,&g_1604,&g_203},{&g_1604,&g_203,(void*)0,&g_1604,&g_203},{&l_1689,&g_1604,&l_1689,(void*)0,(void*)0}}};
        int i, j, k;
        ++g_1696;
    }
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_96 g_1237.f3 g_855 g_862 g_1343 g_397 g_398 g_152.f0 g_618.f0 g_203 g_1363 g_204 g_1325.f0 g_171 g_1390 g_1407 g_329 g_330 g_754.f1 g_1364 g_375 g_63 g_104 g_475.f1 g_1453 g_218 g_152.f1 g_765 g_671.f2 g_1482 g_547 g_1484 g_161 g_1482.f3 g_1236.f2 g_1491 g_1206 g_1504 g_1008 g_745.f3 g_929 g_1531 g_410.f0 g_1445 g_225 g_1584 g_493 g_475.f2 g_379 g_1669 g_764 g_525.f0 g_399 g_12
 * writes: g_96 g_1237.f3 g_104 g_171 g_1363 g_203 g_63 g_1443 g_1445 g_1453 g_375 g_218 g_101 g_329 g_929 g_162 g_1482.f3 g_1236.f2 g_1207 g_745.f3 g_73 g_855 g_1529 g_225 g_1568 g_1343 g_1584 g_216 g_1640 g_1585 g_1669
 */
static uint16_t  func_20(int32_t  p_21, const int32_t  p_22)
{ /* block id: 593 */
    uint16_t l_1344 = 65534UL;
    int64_t **l_1365 = &g_1364;
    int32_t l_1378 = 0xED63C4F9L;
    int32_t l_1380 = 0x9C1DCBF8L;
    const int32_t l_1412 = (-1L);
    int32_t l_1449 = 0x71B0189EL;
    int32_t l_1450 = 3L;
    int32_t l_1452[4][9][7] = {{{2L,0x4975740CL,(-1L),0x457A2D2CL,1L,0x642E6518L,6L},{0x3AD84BD9L,(-5L),0L,0L,0L,0xB3AE33EBL,0L},{(-1L),(-1L),0x5CA963A3L,(-3L),0L,(-1L),0x5CA963A3L},{0xB2840402L,0x68FA2201L,0x4A9EA3ECL,0L,0x4A9EA3ECL,0x68FA2201L,0xB2840402L},{0L,(-1L),2L,0x7E9CF2B3L,(-1L),(-1L),0L},{0x774C7A20L,6L,2L,0x3F8A32E4L,(-1L),0xB504DA95L,0xEDC21358L},{1L,(-9L),2L,0L,0L,0x69CE620CL,0x92D35C26L},{0x4975740CL,0L,0x4A9EA3ECL,0x87C750A5L,0x7AB58004L,0x7E9CF2B3L,(-10L)},{0x457A2D2CL,0x2F632D5DL,0x94BE9CFCL,(-1L),(-5L),1L,0x1075BD5EL}},{{(-1L),7L,0x774C7A20L,0x57AB385DL,0xEDC21358L,(-1L),6L},{1L,2L,0x5CA963A3L,0xC5CA5B0BL,(-1L),0x2C6B3B2FL,7L},{1L,3L,(-9L),0x775E5483L,2L,(-2L),1L},{0xE6555E0AL,1L,0xA247DF5BL,9L,0x69CE620CL,0xC4D3756BL,0L},{0L,1L,(-2L),6L,1L,(-9L),0xC4D3756BL},{0xA828E43BL,3L,0xEFBA8561L,0xAE970EEDL,(-10L),0x457A2D2CL,0xA3C6A137L},{0xB3AE33EBL,2L,0xFCA330EDL,(-1L),8L,(-10L),0x3F8A32E4L},{(-1L),7L,(-9L),0xA247DF5BL,3L,0x3AD84BD9L,6L},{7L,0x2F632D5DL,(-1L),0x6A197DEFL,0xA247DF5BL,0xA443B59EL,0xA443B59EL}},{{2L,0L,(-1L),0L,2L,0xFCA330EDL,(-1L)},{3L,(-9L),0xEDC21358L,(-1L),0x7E9CF2B3L,0xC5CA5B0BL,3L},{0xFCA330EDL,6L,0xC4D3756BL,5L,0x2F632D5DL,6L,0xD99BF8ADL},{3L,(-1L),6L,(-1L),0L,(-1L),0xBE38A828L},{2L,0x68FA2201L,(-1L),3L,0x13FA8CFBL,0L,0x4975740CL},{7L,2L,(-1L),8L,0xFCA330EDL,0x88219E27L,1L},{(-1L),(-1L),(-3L),0xFCA330EDL,(-2L),0L,0xA247DF5BL},{0xB3AE33EBL,0L,0L,0x92D35C26L,0xA443B59EL,(-1L),0x57AB385DL},{0xA828E43BL,0xBE38A828L,(-1L),0x4A9EA3ECL,3L,(-10L),1L}},{{0L,3L,0x3F8A32E4L,(-1L),0x23092BBCL,3L,1L},{0xE6555E0AL,(-1L),0x2F632D5DL,0xC4D3756BL,1L,0xA4D35342L,0x57AB385DL},{1L,(-1L),0xE6555E0AL,0xEFBA8561L,(-1L),0L,0xA247DF5BL},{1L,1L,0x675BA4E9L,1L,0xB2840402L,6L,(-5L)},{(-10L),(-10L),0x9269A22CL,0xD037177BL,0x7E9CF2B3L,1L,0L},{0xB3AE33EBL,0xA247DF5BL,0x775E5483L,(-1L),0x457A2D2CL,0x457A2D2CL,(-1L)},{0L,0x642E6518L,0L,0L,9L,0x13FA8CFBL,0xC5CA5B0BL},{1L,(-1L),2L,0xA3C6A137L,0x4A9EA3ECL,0L,(-1L)},{2L,0x3F8A32E4L,(-1L),0xB504DA95L,0xEDC21358L,0x13FA8CFBL,3L}}};
    union U0 *l_1485[9] = {(void*)0,&g_610,(void*)0,&g_610,(void*)0,&g_610,(void*)0,&g_610,(void*)0};
    union U0 * const *l_1524 = (void*)0;
    uint64_t l_1554 = 0xB44CA8FD3E05800CLL;
    int32_t *****l_1587[7][4][9] = {{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,(void*)0,&g_1585,(void*)0}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{(void*)0,&g_1585,(void*)0,&g_1585,&g_1585,&g_1585,(void*)0,&g_1585,(void*)0}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{(void*)0,&g_1585,(void*)0,&g_1585,&g_1585,&g_1585,(void*)0,&g_1585,(void*)0}},{{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585,&g_1585},{(void*)0,&g_1585,(void*)0,&g_1585,&g_1585,&g_1585,(void*)0,&g_1585,(void*)0}}};
    uint32_t l_1618 = 1UL;
    int i, j, k;
    for (g_96 = 0; (g_96 <= 3); g_96 += 1)
    { /* block id: 596 */
        int32_t l_1339[5][7][7] = {{{0x211D0094L,1L,0xC031A4E3L,(-9L),0xBD601896L,(-7L),1L},{0x9BEA33BCL,(-1L),(-1L),5L,0x6EC6CC88L,(-1L),0x6EC6CC88L},{1L,0xE730F855L,0xE730F855L,1L,1L,0L,0x9BEA33BCL},{(-7L),(-4L),(-9L),0x7D53A60DL,0xE730F855L,8L,0xA1565C70L},{0xDCCD55DCL,(-1L),(-5L),0L,1L,0L,0x9BEA33BCL},{(-1L),0x3C0BF383L,0x211D0094L,(-9L),0x678D1AEFL,1L,0x6EC6CC88L},{0x7D6AA89EL,0x099F6243L,0xBBE29D84L,(-2L),0xDA3DB781L,(-1L),1L}},{{0x023BAC12L,0x7D6AA89EL,0xE730F855L,0xF6E2815FL,(-1L),(-1L),0x7D6AA89EL},{8L,0L,0x7D6AA89EL,(-5L),0L,(-4L),0x7357A5CFL},{8L,(-1L),0xD822E696L,0x7D6AA89EL,(-4L),(-1L),0xE730F855L},{0x023BAC12L,0xE44BE3D5L,0L,0xBD601896L,0x7D6AA89EL,(-7L),0L},{0x7D6AA89EL,0L,0L,0L,0xA1565C70L,1L,(-4L)},{(-2L),(-1L),0xC031A4E3L,5L,(-1L),0xBBE29D84L,1L},{(-1L),(-1L),4L,1L,0xF6E2815FL,0L,0L}},{{0xBD601896L,(-1L),1L,(-7L),(-1L),0L,0xF6E2815FL},{(-1L),0xA1565C70L,0x7D53A60DL,0x91528B02L,(-1L),3L,0xDCCD55DCL},{0x211D0094L,0L,1L,0x099F6243L,0xA1565C70L,1L,1L},{(-3L),0x023BAC12L,0xF6E2815FL,3L,1L,0L,0x211D0094L},{0L,0L,0xF6E2815FL,1L,4L,(-1L),(-1L)},{(-9L),1L,1L,0L,0x678D1AEFL,0xE730F855L,0x023BAC12L},{5L,1L,0x7D53A60DL,(-1L),(-1L),0x7D53A60DL,1L}},{{1L,1L,1L,(-1L),(-4L),(-7L),(-4L)},{0x7D53A60DL,0x023BAC12L,4L,0xBBE29D84L,(-7L),(-2L),1L},{0L,1L,0xC031A4E3L,(-1L),1L,0L,0x2B3C720BL},{(-9L),1L,0L,(-1L),0x2B3C720BL,(-9L),0L},{(-2L),8L,0xD822E696L,0L,(-1L),0xBBE29D84L,1L},{0xF6E2815FL,(-1L),0x946A7036L,1L,0L,0L,0x7357A5CFL},{(-5L),(-1L),1L,3L,0L,(-2L),0xF6E2815FL}},{{0x7D6AA89EL,0x2B3C720BL,1L,0x099F6243L,(-1L),1L,0xBD601896L},{0xBD601896L,(-7L),1L,0x91528B02L,0x2B3C720BL,0x2B3C720BL,0x91528B02L},{(-3L),0x7357A5CFL,(-3L),(-7L),1L,0L,0xDCCD55DCL},{0x023BAC12L,1L,(-1L),1L,(-7L),(-1L),0L},{0xBBE29D84L,1L,(-1L),5L,(-4L),0L,0x023BAC12L},{0L,(-9L),1L,0L,(-1L),0x2B3C720BL,(-9L)},{0x2B3C720BL,0L,1L,0xF6E2815FL,0x678D1AEFL,1L,0L}}};
        int32_t l_1342 = 4L;
        int32_t l_1345[3];
        int64_t **l_1366[7][3] = {{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364},{&g_1364,&g_1364,&g_1364}};
        uint64_t l_1375 = 18446744073709551615UL;
        uint8_t l_1420 = 2UL;
        int32_t *l_1471[10] = {&l_1449,&l_1449,&l_1345[0],&l_1345[1],&l_1345[1],&l_1345[0],&l_1345[0],&l_1345[1],&l_1345[1],&l_1345[1]};
        uint32_t l_1472 = 0xEFEDDF23L;
        int8_t **l_1477[8] = {&g_1009,&g_1009,&g_1009,&g_1009,&g_1009,&g_1009,&g_1009,&g_1009};
        int8_t **l_1479 = &g_1008[0][3][9];
        int8_t ***l_1478 = &l_1479;
        union U0 **l_1483 = &g_162;
        uint32_t l_1519 = 0x93BDD7FFL;
        int32_t ****l_1647 = &g_764[1][9][1];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1345[i] = 0x4214EEFAL;
        for (g_1237.f3 = 1; (g_1237.f3 <= 7); g_1237.f3 += 1)
        { /* block id: 599 */
            union U2 *l_1327 = (void*)0;
            uint16_t *l_1340 = &g_104;
            uint16_t *l_1341 = (void*)0;
            uint32_t *l_1346 = &g_171;
            int64_t *l_1361 = (void*)0;
            int64_t **l_1360 = &l_1361;
            int32_t l_1379 = 0x2E97E658L;
            int32_t l_1414 = 0xE7F06EBBL;
            int32_t l_1415[3][5];
            int16_t l_1448 = (-1L);
            int32_t l_1451 = 0x9D319FC4L;
            uint16_t *l_1464 = &g_1343[0][1];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                    l_1415[i][j] = 7L;
            }
            if (g_855[g_96][g_1237.f3])
                break;
            if ((((g_862 , (((void*)0 == l_1327) > (((*l_1346) = (((l_1345[1] = (safe_sub_func_int32_t_s_s((&g_399 != (void*)0), ((((l_1342 = ((safe_add_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(g_855[g_96][g_96], (((*l_1340) = (p_22 <= (safe_sub_func_uint16_t_u_u((+((((((safe_rshift_func_int16_t_s_u((9L >= l_1339[4][0][1]), 11)) , p_21) ^ p_21) & p_21) , g_855[g_96][g_96]) & 0xFBA2L)), 0x7DC3L)))) , 0x2CL))), p_21)) && g_855[g_96][g_1237.f3])) | p_21) , g_1343[0][0]) != l_1344)))) > p_22) < 0x9588L)) ^ l_1344))) == l_1344) > (-6L)))
            { /* block id: 605 */
                int64_t ***l_1362[7] = {&l_1360,(void*)0,(void*)0,&l_1360,(void*)0,(void*)0,&l_1360};
                int32_t l_1410 = (-9L);
                int32_t l_1411 = 0x0F3B216FL;
                int32_t l_1416 = 0x8BE91CA9L;
                int32_t l_1417 = 0x9DA2D903L;
                int32_t l_1418 = (-1L);
                int32_t l_1419[2][9] = {{0L,0xCC6268A4L,0L,0L,0xCC6268A4L,0L,0L,0xCC6268A4L,0L},{0L,0xCC6268A4L,0L,0L,0xCC6268A4L,0L,0L,0xCC6268A4L,0L}};
                int i, j;
                if (((safe_add_func_int64_t_s_s(l_1345[1], (safe_sub_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((!((safe_add_func_int16_t_s_s(((l_1365 = (g_1363 = l_1360)) == l_1366[0][1]), (2UL < 0xD3AED06EAD9C9513LL))) == ((safe_mod_func_int16_t_s_s((safe_sub_func_int32_t_s_s(p_21, ((**g_397) , ((safe_rshift_func_uint16_t_u_s(g_618.f0, 8)) & (safe_lshift_func_uint16_t_u_s(g_203, p_21)))))), (-1L))) == p_21))), l_1375)), 15)), p_22)) | l_1375), p_22)))) < 0x2E742782L))
                { /* block id: 608 */
                    (*g_204) |= (+(((*g_1363) = (*g_1363)) != (void*)0));
                    return g_1325.f0;
                }
                else
                { /* block id: 612 */
                    uint32_t l_1381 = 0x97047150L;
                    int32_t l_1413[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
                    int32_t *l_1446 = &l_1415[2][4];
                    int32_t *l_1447[5] = {&l_1417,&l_1417,&l_1417,&l_1417,&l_1417};
                    int i;
                    for (l_1344 = 0; (l_1344 <= 2); l_1344 += 1)
                    { /* block id: 615 */
                        int32_t *l_1377[10][1] = {{&l_1345[0]},{&g_68},{&l_1345[0]},{&g_68},{&l_1345[0]},{&g_68},{&l_1345[0]},{&g_68},{&l_1345[0]},{&g_68}};
                        int i, j;
                        l_1381--;
                        if (g_1343[g_96][g_96])
                            break;
                        l_1378 &= ((++(*l_1346)) <= ((((safe_lshift_func_int8_t_s_u(((((void*)0 == &g_1008[0][1][9]) , (((safe_mul_func_int16_t_s_s(((g_1390 , (safe_lshift_func_uint8_t_u_u(((((p_21 && p_21) < (p_22 != ((safe_rshift_func_int16_t_s_s((((safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s(65535UL, 13)), (safe_mul_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_add_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((l_1410 = (g_1407 ^ (safe_lshift_func_uint8_t_u_u(p_21, p_21)))), g_203)), (*g_329))), 0xABL)), 0x720EL)))) ^ l_1411) || p_21), p_21)) != 0x748FL))) , (void*)0) == &g_63), 3))) >= l_1380), g_754.f1)) , (*g_1364)) >= 0xA76A5202EC08FB7ALL)) , p_22), l_1375)) , l_1380) < l_1412) , p_21));
                        --l_1420;
                    }
                    if (l_1342)
                    { /* block id: 623 */
                        int32_t *l_1423 = (void*)0;
                        int32_t l_1424 = 1L;
                        if (p_21)
                            break;
                        l_1411 = l_1419[0][3];
                        l_1424 ^= 1L;
                    }
                    else
                    { /* block id: 627 */
                        uint32_t l_1427 = 0xE12B40C3L;
                        int8_t *l_1428 = &g_63;
                        int32_t l_1441[6];
                        uint32_t *l_1442 = &g_929;
                        uint32_t **l_1444[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        for (i = 0; i < 6; i++)
                            l_1441[i] = 0x5774BCBFL;
                        l_1380 &= ((((safe_mod_func_int64_t_s_s(((l_1419[0][3] && ((*l_1428) ^= (l_1427 = l_1420))) & ((safe_mod_func_uint64_t_u_u((((((((safe_div_func_int64_t_s_s((l_1416 = (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s((p_21 ^ (0xFBEFL && ((safe_div_func_uint8_t_u_u(((1UL && ((safe_rshift_func_int8_t_s_u(l_1441[2], ((g_1443[7][1][1] = l_1442) != (g_1445 = l_1346)))) >= g_104)) == 0x10139497E6F743DCLL), l_1339[4][5][4])) < p_22))), 12)), l_1416))), 0xCAB134DCCA64C22FLL)) , p_21) ^ l_1381) < p_21) <= 1UL) != p_21) || l_1378), g_1407)) >= l_1414)), g_475.f1)) , &l_1444[1]) != &l_1444[1]) | p_22);
                    }
                    if (l_1410)
                        break;
                    g_1453--;
                }
                for (g_171 = 0; (g_171 <= 2); g_171 += 1)
                { /* block id: 640 */
                    const uint16_t *l_1465 = &l_1344;
                    const int8_t l_1468 = 1L;
                    for (g_375 = 3; (g_375 >= 0); g_375 -= 1)
                    { /* block id: 643 */
                        int64_t **l_1463[7] = {&l_1361,&l_1361,&l_1361,&l_1361,&l_1361,&l_1361,&l_1361};
                        int16_t *l_1469 = &g_218;
                        int32_t *l_1470 = &l_1380;
                        int i, j, k;
                        (*l_1470) ^= (((0x05L >= (((*l_1469) |= (!(safe_mul_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((l_1360 = &g_1364) == (g_1363 = (l_1463[1] = &g_1364))), 1)), ((l_1464 == l_1465) & l_1452[g_375][g_1237.f3][(g_375 + 3)]))) & 0xF0L), (g_855[g_375][(g_171 + 1)] == (safe_mod_func_int8_t_s_s(l_1379, l_1468))))))) > 0x1820L)) , (-6L)) && l_1468);
                    }
                    for (g_203 = 5; (g_203 >= 0); g_203 -= 1)
                    { /* block id: 652 */
                        return g_152[1].f1;
                    }
                }
            }
            else
            { /* block id: 656 */
                l_1471[0] = &l_1345[1];
            }
            (*g_765) = (p_21 , (void*)0);
        }
        l_1472++;
        l_1452[0][8][6] = ((((safe_lshift_func_int16_t_s_u((((l_1477[2] != ((*l_1478) = &g_1008[0][4][6])) || ((*g_1364) = (p_21 , (safe_div_func_uint16_t_u_u(g_671.f2, p_21))))) ^ (g_1482 , 1L)), 5)) , p_21) , (((g_547[2] , l_1483) == (void*)0) >= p_22)) , l_1344);
        (*g_1484) = &p_22;
        for (g_929 = 0; (g_929 <= 3); g_929 += 1)
        { /* block id: 668 */
            int16_t l_1490[10][10][2] = {{{1L,0xA25AL},{0x5079L,0x5079L},{(-9L),0x8732L},{0xEE0AL,(-10L)},{(-1L),0L},{(-1L),(-1L)},{0L,0xFFE2L},{0L,(-1L)},{(-1L),0L},{(-1L),(-10L)}},{{0xEE0AL,0x8732L},{(-9L),0x5079L},{0x5079L,0xA25AL},{1L,0x080DL},{(-10L),0L},{0x8B23L,0xF820L},{0x8732L,0x7F55L},{0xA25AL,0xD53AL},{0xF820L,0xD53AL},{0xA25AL,0x7F55L}},{{0x8732L,0xF820L},{0x8B23L,0L},{(-10L),0x080DL},{1L,0xA25AL},{0x5079L,0x5079L},{(-9L),0x8732L},{0xEE0AL,(-10L)},{(-1L),0L},{(-1L),(-1L)},{0L,0xFFE2L}},{{0L,(-1L)},{(-1L),0L},{(-1L),(-10L)},{0xEE0AL,0x8732L},{(-9L),0x5079L},{0x5079L,0xA25AL},{1L,0x080DL},{(-10L),0L},{0x8B23L,0xF820L},{0x8732L,0x7F55L}},{{0xA25AL,0xD53AL},{0xF820L,0xD53AL},{0xA25AL,0x7F55L},{0x8732L,0xF820L},{0x8B23L,0L},{(-10L),0x080DL},{1L,0xA25AL},{0x5079L,0x5079L},{(-9L),0x8732L},{0xEE0AL,(-10L)}},{{(-1L),0L},{(-1L),(-1L)},{0L,0xFFE2L},{0L,(-1L)},{(-1L),0L},{(-1L),(-10L)},{0L,0xA25AL},{0xF820L,0x2531L},{0x2531L,0x9859L},{2L,0xFFE2L}},{{0x5079L,(-9L)},{0L,(-10L)},{0xA25AL,(-10L)},{0x9859L,0x080DL},{(-10L),0x080DL},{0x9859L,(-10L)},{0xA25AL,(-10L)},{0L,(-9L)},{0x5079L,0xFFE2L},{2L,0x9859L}},{{0x2531L,0x2531L},{0xF820L,0xA25AL},{0L,0xD53AL},{0x8B23L,(-1L)},{1L,0x8B23L},{(-9L),(-1L)},{(-9L),0x8B23L},{1L,(-1L)},{0x8B23L,0xD53AL},{0L,0xA25AL}},{{0xF820L,0x2531L},{0x2531L,0x9859L},{2L,0xFFE2L},{0x5079L,(-9L)},{0L,(-10L)},{0xA25AL,(-10L)},{0x9859L,0x080DL},{(-10L),0x080DL},{0x9859L,(-10L)},{0xA25AL,(-10L)}},{{0L,(-9L)},{0x5079L,0xFFE2L},{2L,0x9859L},{0x2531L,0x2531L},{0xF820L,0xA25AL},{0L,0xD53AL},{0x8B23L,(-1L)},{1L,0x8B23L},{(-9L),(-1L)},{(-9L),0x8B23L}}};
            uint32_t ** const l_1496 = &g_1443[0][1][0];
            int32_t l_1521 = 0xE92B00DDL;
            int32_t *l_1532 = &l_1339[3][0][3];
            int32_t l_1539 = 0x2A620400L;
            int32_t l_1543 = 0xC5CFFE76L;
            int32_t l_1550 = 3L;
            int32_t l_1552 = 0xE98F2DE9L;
            int32_t l_1553 = (-1L);
            uint32_t *l_1560 = (void*)0;
            uint32_t *l_1561 = &g_1238.f2;
            uint32_t *l_1562 = &g_745.f2;
            uint32_t *l_1563[4][2] = {{&g_225,&g_225},{&g_225,&g_225},{&g_225,&g_225},{&g_225,&g_225}};
            int16_t *l_1566 = &l_1490[7][2][1];
            uint32_t l_1567 = 0UL;
            uint16_t *l_1577[9] = {&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0],&g_1343[0][0]};
            const int64_t *l_1636 = &g_375;
            const int64_t **l_1635[5] = {&l_1636,&l_1636,&l_1636,&l_1636,&l_1636};
            const int64_t ***l_1634 = &l_1635[3];
            int32_t *l_1672 = &l_1521;
            int i, j, k;
            (*g_161) = l_1485[0];
            for (g_1482.f3 = 0; (g_1482.f3 <= 3); g_1482.f3 += 1)
            { /* block id: 672 */
                uint32_t l_1499 = 18446744073709551615UL;
                int32_t l_1513 = 1L;
                union U0 *l_1536 = &g_1528[1][0][2];
                int32_t l_1538 = 0xF319DB87L;
                int32_t l_1540 = 0L;
                int32_t l_1544 = 0x40EEF793L;
                int16_t l_1551 = 0x5EACL;
                for (l_1472 = 0; (l_1472 <= 3); l_1472 += 1)
                { /* block id: 675 */
                    int32_t * const l_1502[3][9] = {{&l_1452[3][8][5],&l_1380,&l_1345[0],&l_1380,&l_1452[3][8][5],&l_1345[0],&g_68,&g_68,&l_1345[0]},{&l_1452[3][8][5],&l_1380,&l_1345[0],&l_1380,&l_1452[3][8][5],&l_1345[0],&g_68,&g_68,&l_1345[0]},{&l_1452[3][8][5],&l_1380,&l_1345[0],&l_1380,&l_1452[3][8][5],&l_1345[0],&g_68,&g_68,&l_1345[0]}};
                    int32_t **l_1503[4][1];
                    int i, j;
                    for (i = 0; i < 4; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_1503[i][j] = &g_101[2];
                    }
                    for (g_1236.f2 = 0; (g_1236.f2 <= 3); g_1236.f2 += 1)
                    { /* block id: 678 */
                        int i, j;
                        return g_855[g_1482.f3][(g_1236.f2 + 1)];
                    }
                    for (l_1449 = 0; (l_1449 <= 2); l_1449 += 1)
                    { /* block id: 683 */
                        uint16_t l_1500 = 65535UL;
                        int32_t l_1501[1][7] = {{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}};
                        int i, j;
                        l_1501[0][6] &= (&g_1207[5] == ((safe_mod_func_uint32_t_u_u((((safe_mod_func_int8_t_s_s((((l_1490[7][2][1] || (((g_1491[2][6] , &g_1026) != (void*)0) & l_1452[3][2][5])) & (safe_div_func_uint32_t_u_u((((safe_rshift_func_uint16_t_u_u((l_1496 == ((safe_div_func_uint16_t_u_u(((l_1499 != l_1490[8][7][0]) & 0xB7D1L), g_1453)) , l_1496)), 7)) < p_22) > 3UL), p_22))) & l_1499), l_1500)) < 1L) | p_21), p_22)) , &g_1207[5]));
                        (*g_1206) = (void*)0;
                        if (p_22)
                            break;
                        (*g_1484) = &p_22;
                    }
                    (*g_1504) = l_1502[2][8];
                }
                for (g_745.f3 = 0; (g_745.f3 <= 3); g_745.f3 += 1)
                { /* block id: 693 */
                    uint8_t *l_1514 = &g_1184.f3;
                    uint8_t *l_1515 = &g_1184.f3;
                    uint8_t *l_1516 = &g_1237.f3;
                    int32_t l_1520 = 1L;
                    union U0 * const l_1527 = &g_1528[1][0][2];
                    union U0 * const *l_1526 = &l_1527;
                    union U0 * const **l_1525 = &l_1526;
                    int32_t **l_1533 = &l_1532;
                    int32_t *l_1535 = &l_1339[4][0][1];
                    int32_t **l_1534 = &l_1535;
                    int64_t l_1542 = 1L;
                    int32_t l_1545 = 0x8CCB877CL;
                    int32_t l_1546 = 0xD2A5A1C5L;
                    int32_t l_1547 = (-1L);
                    int32_t l_1548[10];
                    int i, j;
                    for (i = 0; i < 10; i++)
                        l_1548[i] = 1L;
                    if (p_21)
                        break;
                    l_1521 = (safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(((**l_1479) = 0x6FL), 4)), (1UL != ((safe_add_func_uint8_t_u_u((++g_855[g_745.f3][(g_929 + 3)]), p_22)) & ((--(*l_1516)) | (l_1520 = (l_1519 = l_1490[5][7][1])))))));
                    if ((safe_div_func_int32_t_s_s(p_21, ((((((((g_855[g_745.f3][(g_929 + 3)] && ((g_1529[1] = ((*l_1525) = (l_1524 = l_1483))) != l_1483)) < (((((**l_1479) = 0x3EL) != p_22) < (((((*l_1534) = ((*l_1533) = (g_1531[2] , l_1532))) == &p_21) < (*g_1364)) ^ l_1412)) , g_410.f0)) , (*g_1364)) < p_22) & (-3L)) , p_22) || p_22) && 7L))))
                    { /* block id: 707 */
                        int32_t l_1537 = 8L;
                        int32_t l_1541[6] = {0L,0L,0L,0L,0L,0L};
                        int32_t l_1549 = 8L;
                        int i;
                        (*l_1483) = l_1536;
                        l_1554--;
                    }
                    else
                    { /* block id: 710 */
                        uint8_t l_1557 = 0x2AL;
                        if (p_22)
                            break;
                        l_1557 = 4L;
                    }
                }
            }
            if ((((g_1343[6][2] = ((*g_1445) , (((l_1378 = (((((1UL == (safe_mul_func_int16_t_s_s(((g_225 &= 0x583C2246L) , (safe_mod_func_int16_t_s_s(((*l_1566) |= l_1378), p_21))), (9L == (g_1568 = l_1567))))) ^ ((safe_mod_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((safe_mod_func_uint8_t_u_u(((((safe_rshift_func_uint8_t_u_u(p_21, p_22)) , 1UL) > p_21) , l_1450), p_22)), 9)), 0x7EC8L)) , 0x0BFCL)) <= 0x76D879FC89C8AC37LL) != 0x9EF40CDDL) < p_21)) && (-5L)) || 0xCEB9L))) >= 65526UL) || p_21))
            { /* block id: 721 */
                uint8_t l_1581 = 9UL;
                int32_t l_1596 = (-4L);
                int32_t l_1607 = 0xBF3ED682L;
                int32_t l_1610 = 0x65AB7011L;
                int32_t l_1614 = 0x31F7CEF5L;
                int32_t l_1616[9] = {3L,3L,3L,3L,3L,3L,3L,3L,3L};
                int i;
                for (l_1342 = 3; (l_1342 >= 0); l_1342 -= 1)
                { /* block id: 724 */
                    int32_t l_1578 = 1L;
                    int32_t ******l_1586 = &g_1584;
                    uint64_t *l_1594[10] = {&l_1375,&g_216,&l_1375,(void*)0,(void*)0,&l_1375,&g_216,&l_1375,(void*)0,(void*)0};
                    int32_t l_1597 = 9L;
                    int32_t l_1605 = 0x228AD2EEL;
                    int32_t l_1606 = 0xD57C5B22L;
                    int32_t l_1609 = 0xCE28787BL;
                    int32_t l_1611 = 0x3EEE8756L;
                    int32_t l_1612 = (-1L);
                    int32_t l_1613 = 3L;
                    int32_t l_1617 = 0x42BD521CL;
                    int i;
                    if (((l_1578 ^ (((safe_add_func_uint64_t_u_u(0xD99B59F76B493749LL, (l_1581 <= 255UL))) | ((g_216 = ((+((safe_unary_minus_func_int64_t_s((((*l_1586) = g_1584) != (l_1587[0][2][1] = (void*)0)))) ^ ((((safe_mul_func_int16_t_s_s(((p_21 <= (safe_div_func_int16_t_s_s((p_22 != (p_22 <= l_1412)), (-3L)))) <= p_22), l_1450)) > p_22) <= p_21) || l_1581))) > l_1581)) > p_21)) , 7L)) > 0xEC307811BBD94C04LL))
                    { /* block id: 728 */
                        int32_t l_1595[2][8] = {{(-1L),1L,(-1L),0x95FD28A6L,0x95FD28A6L,(-1L),1L,(-1L)},{1L,0x95FD28A6L,0xF9CD0CD8L,0x95FD28A6L,1L,1L,0x95FD28A6L,0xF9CD0CD8L}};
                        int i, j;
                        l_1596 |= l_1595[0][2];
                        l_1597 = (l_1550 = 1L);
                        l_1521 = (safe_lshift_func_int16_t_s_u((safe_div_func_uint32_t_u_u(p_22, 1L)), 9));
                        if (p_22)
                            continue;
                    }
                    else
                    { /* block id: 734 */
                        int16_t l_1602 = 0xA20AL;
                        int32_t l_1603 = 0L;
                        int32_t l_1608 = 0xF9747567L;
                        int32_t l_1615 = 7L;
                        const int32_t * const ***l_1639 = (void*)0;
                        const int32_t * const ****l_1644 = &l_1639;
                        const int32_t * const ***l_1646 = &g_1641;
                        const int32_t * const ****l_1645 = &l_1646;
                        int64_t *** const l_1648[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        l_1618--;
                        l_1596 = (l_1607 | (safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_u((((*g_1445) = (safe_rshift_func_uint8_t_u_u(p_22, 1))) | 0x219616CCL), 4)) , (safe_add_func_uint32_t_u_u(((*g_1445)++), 0x8ED3E26BL))), 15)));
                        l_1603 &= (~(safe_add_func_uint32_t_u_u(p_22, (l_1634 != &g_1363))));
                        l_1606 = ((((*l_1566) ^= ((((*l_1645) = ((*l_1644) = (g_1640 = l_1639))) == ((*g_1584) = l_1647)) == 8UL)) && 5L) && ((void*)0 != l_1648[0]));
                    }
                    return g_493;
                }
                return p_21;
            }
            else
            { /* block id: 750 */
                int64_t l_1665[7] = {0xF7D236CB95DA3C0BLL,(-1L),(-1L),0xFD88F6BFE6DDC38ELL,(-1L),(-1L),0xFD88F6BFE6DDC38ELL};
                int32_t l_1682 = 0x210FF711L;
                int i;
                for (l_1519 = 0; (l_1519 <= 3); l_1519 += 1)
                { /* block id: 753 */
                    int32_t l_1650 = 4L;
                    int32_t l_1664 = 0xA907ABA5L;
                    if (p_21)
                        break;
                    for (p_21 = 8; (p_21 >= 3); p_21 -= 1)
                    { /* block id: 757 */
                        int16_t l_1649 = (-1L);
                        return l_1649;
                    }
                    if (l_1650)
                    { /* block id: 760 */
                        uint16_t l_1655[3][2];
                        int64_t l_1666[2];
                        int32_t l_1667 = 1L;
                        int32_t l_1668 = 0x8C4B6894L;
                        int i, j;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 2; j++)
                                l_1655[i][j] = 0UL;
                        }
                        for (i = 0; i < 2; i++)
                            l_1666[i] = 0xE9245986DF3BD6ADLL;
                        l_1664 = (safe_lshift_func_int8_t_s_s((safe_add_func_uint8_t_u_u((((*g_1445) = (((((void*)0 == l_1647) , (*g_398)) <= (l_1655[0][0] || (safe_div_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((safe_add_func_uint8_t_u_u(l_1567, (g_855[l_1519][(l_1519 + 1)] |= ((l_1655[2][0] || (p_22 ^ (safe_mul_func_int8_t_s_s(l_1655[1][0], ((0x9D66L >= g_475.f2) > 65531UL))))) , 0xCFL)))), l_1553)), g_379)))) == 65528UL)) , 0x79L), p_22)), 1));
                        g_1669--;
                        l_1672 = &l_1553;
                        l_1682 = (safe_add_func_int16_t_s_s(p_21, (safe_div_func_int8_t_s_s((safe_sub_func_int32_t_s_s((((void*)0 != (*l_1647)) < (g_525[0][1][9].f0 & l_1665[3])), (l_1665[4] <= (safe_div_func_uint64_t_u_u((!p_22), (p_22 || l_1665[5])))))), (*l_1672)))));
                    }
                    else
                    { /* block id: 767 */
                        (*l_1672) |= ((***g_399) , p_21);
                    }
                }
            }
        }
    }
    (*g_1484) = ((*g_1504) = (void*)0);
    return g_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_1325
 * writes:
 */
static union U0  func_23(int32_t  p_24, int16_t  p_25, uint16_t  p_26, uint32_t  p_27, int8_t  p_28)
{ /* block id: 590 */
    union U1 *l_1323 = (void*)0;
    union U1 **l_1324 = &l_1323;
    (*l_1324) = l_1323;
    return g_1325;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_73 g_68 g_95 g_63 g_104 g_152 g_161 g_168 g_162 g_96 g_106.f0 g_171 g_204 g_203 g_216 g_218 g_152.f1 g_263 g_269 g_95.f0 g_225 g_370 g_379 g_397 g_399 g_410 g_377 g_269.f0 g_330 g_801 g_493 g_398 g_152.f0 g_754.f1 g_862.f2 g_929 g_1025 g_671.f2 g_1050 g_152.f2 g_421 g_671.f1 g_1058 g_1066 g_1026 g_341 g_1067 g_263.f0 g_1009 g_855 g_745 g_329 g_765 g_1153 g_1167 g_1184 g_547.f1 g_1184.f0 g_1198 g_671 g_1206 g_1242 g_586.f1 g_1273 g_410.f1 g_862.f1 g_1320
 * writes: g_63 g_73 g_96 g_68 g_101 g_104 g_161 g_171 g_162 g_203 g_216 g_218 g_225 g_204 g_328 g_331 g_341 g_370 g_375 g_377 g_379 g_397 g_411 g_421 g_1008 g_1009 g_1065 g_745.f3 g_1303
 */
static uint16_t  func_32(uint8_t  p_33, uint32_t  p_34, uint64_t  p_35, int64_t  p_36)
{ /* block id: 1 */
    int32_t l_1274 = 0x8409FEAAL;
    uint16_t *l_1275[10][6] = {{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,(void*)0,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104},{&g_104,(void*)0,&g_104,&g_104,&g_104,&g_104},{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}};
    int32_t l_1285 = 0x822D01FBL;
    uint32_t l_1304 = 4294967291UL;
    int32_t *l_1305 = &g_203;
    int32_t *l_1306 = &l_1274;
    int16_t *l_1316 = &g_218;
    int32_t ***l_1317 = &g_765;
    int8_t l_1321 = 0x33L;
    int i, j;
    (*l_1305) = (func_37(p_36) , ((g_104 |= l_1274) > (safe_mul_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u(g_410.f1)), ((l_1274 <= ((safe_lshift_func_int8_t_s_u(l_1274, (safe_lshift_func_int8_t_s_s(p_35, (safe_rshift_func_uint16_t_u_u(((l_1285 = 0x95DC8F16L) ^ (safe_rshift_func_uint16_t_u_u((g_1303 = (safe_sub_func_int32_t_s_s((safe_add_func_int32_t_s_s((safe_lshift_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(((((((safe_div_func_int64_t_s_s((safe_mod_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((~(l_1274 , l_1274)), l_1274)), g_379)), l_1274)) != p_35) == l_1274) && 0x5EB0E3F94B0D3CEELL) || l_1274) > p_33), 4294967293UL)), 14)), 9UL)), p_33))), 15))), 12)))))) ^ l_1304)) || l_1285)))));
    l_1306 = &l_1285;
    (*l_1305) = (safe_add_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_u((*l_1306), 5)) < ((+(*l_1306)) ^ g_862.f1)), (((*g_398) , ((((*l_1316) = p_36) != p_34) , ((&g_331 != l_1317) > (safe_lshift_func_uint8_t_u_s((g_1320 , 0x4DL), p_34))))) < (*l_1305)))), l_1321)), p_33));
    return g_218;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_73 g_68 g_95 g_63 g_104 g_152 g_161 g_168 g_162 g_96 g_106.f0 g_171 g_204 g_203 g_216 g_218 g_152.f1 g_263 g_269 g_95.f0 g_225 g_370 g_379 g_397 g_399 g_410 g_377 g_269.f0 g_330 g_801 g_493 g_398 g_152.f0 g_754.f1 g_862.f2 g_929 g_1025 g_671.f2 g_1050 g_152.f2 g_421 g_671.f1 g_1058 g_1066 g_1026 g_341 g_1067 g_263.f0 g_1009 g_855 g_745 g_329 g_765 g_1153 g_1167 g_1184 g_547.f1 g_1184.f0 g_1198 g_671 g_1206 g_1242 g_586.f1 g_1273
 * writes: g_63 g_73 g_96 g_68 g_101 g_104 g_161 g_171 g_162 g_203 g_216 g_218 g_225 g_204 g_328 g_331 g_341 g_370 g_375 g_377 g_379 g_397 g_411 g_421 g_1008 g_1009 g_1065 g_745.f3
 */
static union U1  func_37(uint32_t  p_38)
{ /* block id: 2 */
    const uint8_t l_59[9][4][2] = {{{0UL,1UL},{0x32L,0xCCL},{1UL,0x51L},{0x23L,1UL}},{{0x84L,0x97L},{0x97L,0x32L},{250UL,0x32L},{0x97L,0x97L}},{{0x84L,1UL},{0x23L,0x51L},{1UL,0xCCL},{0x32L,1UL}},{{0UL,0x59L},{0UL,1UL},{0x32L,0xCCL},{1UL,0x51L}},{{0x23L,1UL},{0x84L,0x97L},{0x97L,0x32L},{250UL,0x32L}},{{0x97L,0x97L},{0x84L,1UL},{0x23L,0x51L},{1UL,0xCCL}},{{0x32L,1UL},{0UL,0x59L},{0UL,1UL},{0x32L,0xCCL}},{{1UL,0x51L},{0x23L,1UL},{0x84L,0x97L},{0x97L,0x32L}},{{250UL,0x32L},{0x97L,0x97L},{0x84L,1UL},{0x23L,0x51L}}};
    int32_t *l_71 = (void*)0;
    union U0 **l_354 = &g_162;
    int32_t l_382 = 0xC83C4126L;
    int32_t l_385 = 0x83E0FD2EL;
    int32_t l_386 = 0L;
    uint8_t ** const l_406[6][4][9] = {{{&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341,&g_341},{(void*)0,&g_341,(void*)0,&g_341,(void*)0,&g_341,&g_341,(void*)0,&g_341},{&g_341,(void*)0,&g_341,(void*)0,(void*)0,(void*)0,(void*)0,&g_341,(void*)0},{(void*)0,(void*)0,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341}},{{&g_341,(void*)0,(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0},{(void*)0,(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341},{(void*)0,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341,&g_341,(void*)0},{(void*)0,(void*)0,(void*)0,&g_341,(void*)0,&g_341,&g_341,&g_341,&g_341}},{{(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341},{&g_341,(void*)0,(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341},{&g_341,(void*)0,&g_341,(void*)0,&g_341,&g_341,(void*)0,(void*)0,&g_341},{&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,(void*)0}},{{&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341},{&g_341,(void*)0,(void*)0,(void*)0,(void*)0,&g_341,(void*)0,&g_341,&g_341},{&g_341,(void*)0,&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341},{(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0,(void*)0,&g_341}},{{(void*)0,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341,&g_341,&g_341},{(void*)0,(void*)0,&g_341,&g_341,&g_341,&g_341,(void*)0,(void*)0,&g_341},{&g_341,(void*)0,(void*)0,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341},{&g_341,&g_341,&g_341,(void*)0,&g_341,(void*)0,&g_341,&g_341,&g_341}},{{&g_341,(void*)0,&g_341,&g_341,&g_341,(void*)0,(void*)0,&g_341,&g_341},{&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341},{&g_341,&g_341,(void*)0,(void*)0,&g_341,&g_341,&g_341,(void*)0,&g_341},{&g_341,&g_341,&g_341,&g_341,&g_341,(void*)0,&g_341,&g_341,&g_341}}};
    int16_t *l_413[5][6][1] = {{{&g_218},{(void*)0},{&g_218},{&g_218},{&g_218},{&g_218}},{{&g_218},{&g_218},{&g_218},{&g_218},{&g_218},{&g_218}},{{&g_218},{&g_218},{&g_218},{(void*)0},{&g_218},{&g_218}},{{&g_218},{&g_218},{&g_218},{&g_218},{&g_218},{&g_218}},{{&g_218},{&g_218},{&g_218},{&g_218},{&g_218},{(void*)0}}};
    int16_t **l_412 = &l_413[3][2][0];
    int32_t l_418 = 0L;
    uint32_t *l_419 = &g_171;
    uint32_t *l_444 = (void*)0;
    const int32_t *l_492[10][7][3] = {{{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,(void*)0,&g_493},{&g_493,(void*)0,(void*)0},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493}},{{&g_493,&g_493,&g_493},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,&g_493,(void*)0},{&g_493,(void*)0,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493}},{{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{&g_493,&g_493,(void*)0},{&g_493,&g_493,&g_493},{(void*)0,&g_493,(void*)0},{&g_493,&g_493,(void*)0}},{{&g_493,&g_493,&g_493},{&g_493,(void*)0,&g_493},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{&g_493,(void*)0,&g_493}},{{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{(void*)0,(void*)0,&g_493},{(void*)0,&g_493,&g_493}},{{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,(void*)0,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0}},{{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{&g_493,(void*)0,&g_493},{(void*)0,&g_493,(void*)0}},{{&g_493,(void*)0,(void*)0},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0}},{{&g_493,&g_493,&g_493},{(void*)0,&g_493,&g_493},{&g_493,&g_493,&g_493},{(void*)0,(void*)0,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0},{&g_493,&g_493,&g_493}},{{&g_493,&g_493,&g_493},{(void*)0,&g_493,(void*)0},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,&g_493},{&g_493,&g_493,(void*)0}}};
    uint16_t l_505 = 1UL;
    int32_t l_559 = 0x0CACFB8CL;
    int8_t l_670 = 0xABL;
    int8_t l_672[8] = {(-1L),0x96L,(-1L),0x96L,(-1L),0x96L,(-1L),0x96L};
    int32_t ****l_699 = &g_370;
    int32_t l_789 = 0x4FBF8906L;
    int32_t l_790 = 0xB8888DD5L;
    int32_t l_791 = (-2L);
    int32_t l_794[8][7][4] = {{{0x15AA8A82L,0xC2E7E796L,0xFC1B3777L,0x5A33BB05L},{0xC58BF5FDL,0x0A150735L,0xFC1B3777L,0L},{0x15AA8A82L,0xA5B9D50EL,0xC2E7E796L,(-10L)},{(-1L),0x44BE36DEL,(-2L),1L},{(-2L),1L,1L,(-2L)},{3L,0xADC21B3AL,(-10L),0xC2E7E796L},{0xC58BF5FDL,1L,0L,0xFC1B3777L}},{{0x6D45EF2FL,0xA5B9D50EL,0x5A33BB05L,0xFC1B3777L},{0xB504B497L,1L,(-2L),0xC2E7E796L},{0x0B92E66FL,0xADC21B3AL,0xC58BF5FDL,(-2L)},{0xA5B9D50EL,1L,0x84A06906L,1L},{0xC58BF5FDL,0x44BE36DEL,0x63EF1937L,(-10L)},{0xA28D5785L,0xA5B9D50EL,0xADC21B3AL,0L},{1L,0x0A150735L,(-2L),0x5A33BB05L}},{{1L,0xC2E7E796L,0xADC21B3AL,(-2L)},{0xA28D5785L,0x5A33BB05L,0x63EF1937L,0xC58BF5FDL},{0xC58BF5FDL,0x5915D91CL,0x84A06906L,0x84A06906L},{0xA5B9D50EL,0xA5B9D50EL,0xC58BF5FDL,0x63EF1937L},{0x0B92E66FL,(-5L),(-2L),0xADC21B3AL},{0xB504B497L,0xC58BF5FDL,0x5A33BB05L,(-2L)},{0x6D45EF2FL,0xC58BF5FDL,0L,0xADC21B3AL}},{{0xC58BF5FDL,(-5L),(-10L),0x63EF1937L},{3L,0xA5B9D50EL,1L,0x84A06906L},{(-2L),0x5915D91CL,(-2L),0xC58BF5FDL},{(-1L),0x5A33BB05L,0xC2E7E796L,(-2L)},{0x15AA8A82L,0xC2E7E796L,0xFC1B3777L,0x5A33BB05L},{0xC58BF5FDL,0x0A150735L,0xFC1B3777L,0L},{0x15AA8A82L,0xA5B9D50EL,0xC2E7E796L,(-10L)}},{{(-1L),0x44BE36DEL,(-2L),1L},{(-2L),1L,1L,(-2L)},{3L,0xADC21B3AL,(-10L),0xC2E7E796L},{0xC58BF5FDL,1L,0L,0xFC1B3777L},{0x6D45EF2FL,0xA5B9D50EL,0x5A33BB05L,0xFC1B3777L},{0xB504B497L,1L,(-2L),0xC2E7E796L},{0x0B92E66FL,0xADC21B3AL,0xC58BF5FDL,(-2L)}},{{0xA5B9D50EL,1L,0x84A06906L,1L},{0xC58BF5FDL,0x44BE36DEL,0x63EF1937L,(-10L)},{0xA28D5785L,0xA5B9D50EL,0xADC21B3AL,0L},{1L,0x0A150735L,(-2L),0x5A33BB05L},{1L,0xC2E7E796L,0xADC21B3AL,(-2L)},{0xA28D5785L,0x0B92E66FL,1L,1L},{1L,0xA5B9D50EL,0x5915D91CL,0x5915D91CL}},{{0xC58BF5FDL,0xC58BF5FDL,1L,1L},{0L,0xA28D5785L,0xFC1B3777L,(-1L)},{0x84A06906L,1L,0x0B92E66FL,0xFC1B3777L},{0xC2E7E796L,1L,(-5L),(-1L)},{1L,0xA28D5785L,0x0A150735L,1L},{0xADC21B3AL,0xC58BF5FDL,(-2L),0x5915D91CL},{0xFC1B3777L,0xA5B9D50EL,0xFC1B3777L,1L}},{{(-10L),0x0B92E66FL,0xB504B497L,0xFC1B3777L},{0x5A33BB05L,0xB504B497L,0x44BE36DEL,0x0B92E66FL},{1L,0x6D45EF2FL,0x44BE36DEL,(-5L)},{0x5A33BB05L,0xC58BF5FDL,0xB504B497L,0x0A150735L},{(-10L),3L,0xFC1B3777L,(-2L)},{0xFC1B3777L,(-2L),(-2L),0xFC1B3777L},{0xADC21B3AL,(-1L),0x0A150735L,0xB504B497L}}};
    uint32_t l_824 = 1UL;
    int16_t l_854 = 0xA3A5L;
    uint32_t l_898 = 18446744073709551615UL;
    int64_t l_979 = 1L;
    uint8_t l_987 = 253UL;
    int8_t *l_1007 = &g_73;
    int8_t **l_1006[2][5] = {{&l_1007,&l_1007,&l_1007,&l_1007,&l_1007},{&l_1007,&l_1007,&l_1007,&l_1007,&l_1007}};
    int32_t *l_1014 = &l_789;
    int32_t *l_1015[2][4][6] = {{{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791}},{{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791},{&l_794[6][3][1],&l_791,&l_791,&l_794[6][3][1],&l_791,&l_791}}};
    uint8_t l_1016 = 7UL;
    uint32_t l_1092 = 0xB44F719EL;
    int64_t **l_1125 = (void*)0;
    int32_t l_1144[5][8] = {{1L,2L,1L,0x431CD0D8L,0x431CD0D8L,1L,2L,1L},{1L,0x431CD0D8L,(-1L),0x431CD0D8L,1L,1L,0x431CD0D8L,(-1L)},{1L,1L,0x431CD0D8L,(-1L),0x431CD0D8L,1L,1L,0x431CD0D8L},{1L,0x431CD0D8L,0x431CD0D8L,1L,2L,1L,0x431CD0D8L,0x431CD0D8L},{0x431CD0D8L,2L,(-1L),(-1L),2L,0x431CD0D8L,2L,(-1L)}};
    uint16_t l_1150 = 65530UL;
    int16_t l_1193 = 0xD35FL;
    uint32_t l_1219 = 0x25EE768CL;
    union U2 *l_1235[9][3] = {{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238},{&g_1238,&g_1236,&g_1238}};
    uint16_t *l_1268 = &l_1150;
    int i, j, k;
lbl_409:
    for (p_38 = 0; (p_38 >= 5); ++p_38)
    { /* block id: 5 */
        int8_t *l_62 = &g_63;
        int32_t * const l_67 = &g_68;
        int8_t *l_72 = &g_73;
        int32_t *l_74[5][1] = {{&g_68},{&g_68},{&g_68},{&g_68},{&g_68}};
        int32_t **l_344 = &l_71;
        uint64_t **l_349 = (void*)0;
        uint64_t l_387 = 18446744073709551610UL;
        int i, j;
        (*l_344) = func_41(func_43((safe_mod_func_uint64_t_u_u((safe_mod_func_int32_t_s_s(((safe_lshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((((!(((safe_div_func_int16_t_s_s(l_59[8][3][0], ((safe_rshift_func_uint8_t_u_s(255UL, ((*l_62) = 0x06L))) ^ (!(((*l_72) |= (0L >= (g_12 ^ ((safe_add_func_uint32_t_u_u((l_67 == &g_68), (safe_div_func_int16_t_s_s(((0x0509L > ((l_67 == l_71) && 0L)) ^ p_38), p_38)))) != p_38)))) > 8UL))))) | 0x5464L) == l_59[8][3][0])) | g_68) <= p_38), (*l_67))), 3)) > p_38), (*l_67))), 2L)), g_68, l_71, l_74[0][0]));
        (*l_344) = (void*)0;
        for (g_68 = 0; (g_68 <= 0); g_68 += 1)
        { /* block id: 117 */
            uint32_t l_345 = 0x17A759BEL;
            int32_t l_346[8][2][7] = {{{(-1L),0xB1439799L,0xEA9A48CDL,0x42EC95E6L,3L,(-10L),0x43C1946BL},{0x0B8F0D8EL,0x60723701L,3L,5L,0x5EDB7C5DL,0x0B8F0D8EL,0L}},{{0x61ADA33EL,0xB421E8FCL,0xB8FEC5AEL,1L,(-1L),0x5CFE5E80L,(-1L)},{0x65BF24F8L,(-7L),0x42EC95E6L,(-10L),(-1L),0x61ADA33EL,7L}},{{0x61F2527AL,0x9061F160L,1L,(-10L),0L,5L,0L},{3L,0x5EDB7C5DL,7L,1L,0xB1439799L,0L,0xB1439799L}},{{5L,(-1L),(-1L),5L,0L,1L,(-10L)},{0xA7034FD7L,0x5CFE5E80L,7L,0x42EC95E6L,1L,0L,0x5CFE5E80L}},{{0x65BF24F8L,0xB8FEC5AEL,5L,0x60723701L,(-7L),0xD656DAAFL,(-10L)},{1L,0L,0xA1AD5220L,0xB8FEC5AEL,0L,(-7L),0xB1439799L}},{{7L,3L,1L,0x3DE0F676L,0x51620DA1L,0x60723701L,0L},{0x6698BAAAL,(-1L),3L,0xA1AD5220L,3L,(-1L),7L}},{{0L,(-1L),3L,0xEA9A48CDL,0x60723701L,0L,(-1L)},{0x61ADA33EL,3L,1L,0L,0x5CFE5E80L,0x5CFE5E80L,0L}},{{0xA1AD5220L,0xF2D127F7L,0xA1AD5220L,(-10L),0L,1L,0x43C1946BL},{0xB8FEC5AEL,0x9061F160L,5L,0x56BE708EL,1L,3L,0L}}};
            uint64_t l_403 = 4UL;
            uint8_t **l_407 = &g_341;
            int i, j, k;
            for (g_225 = 0; (g_225 <= 0); g_225 += 1)
            { /* block id: 120 */
                union U0 ***l_352 = (void*)0;
                union U0 ***l_353[8];
                uint64_t *l_357 = &g_216;
                int32_t l_380 = 0x263AD6D1L;
                int32_t l_391[2];
                int i;
                for (i = 0; i < 8; i++)
                    l_353[i] = &g_161;
                for (i = 0; i < 2; i++)
                    l_391[i] = 0xB15A7122L;
                if (((l_346[1][1][2] ^= l_345) != (((((safe_rshift_func_int8_t_s_u(0x88L, ((void*)0 == l_349))) , ((*l_357) = ((((safe_rshift_func_uint8_t_u_s((((g_161 = (l_354 = &g_162)) == (void*)0) & (g_96 ^= ((safe_div_func_int64_t_s_s(((((p_38 , 0xC8310920L) , (void*)0) != (void*)0) ^ 0xF5L), p_38)) > l_345))), l_59[5][3][0])) != (-1L)) ^ (-9L)) , 18446744073709551614UL))) || p_38) == 5UL) , g_152[1].f1)))
                { /* block id: 126 */
                    int16_t l_381 = 0L;
                    int32_t l_390 = (-1L);
                    int32_t l_400 = (-10L);
                    int32_t l_401 = 0L;
                    int32_t l_402 = 3L;
                    for (g_218 = 0; (g_218 <= 0); g_218 += 1)
                    { /* block id: 129 */
                        int32_t ****l_371 = &g_370;
                        int64_t *l_372 = (void*)0;
                        int64_t *l_373 = (void*)0;
                        int64_t *l_374 = &g_375;
                        int32_t *l_376 = &g_377;
                        int32_t *l_378 = &g_379;
                        if (p_38)
                            break;
                        (*g_204) = ((0x18FA3EEE94800F81LL ^ (safe_add_func_uint16_t_u_u(p_38, ((*l_67) , 0xBD4EL)))) , (p_38 | ((safe_mul_func_int16_t_s_s(((&g_341 == (((*l_378) ^= ((*l_376) = (safe_lshift_func_int16_t_s_s((0xCED175345269AC79LL <= ((*l_374) = ((((safe_div_func_int32_t_s_s((((*l_371) = g_370) == &g_328), 0xF72D38E3L)) , 3UL) > 0UL) != p_38))), 4)))) , &g_341)) & 5UL), 0UL)) , 0UL)));
                        if (g_96)
                            goto lbl_409;
                        l_381 = (l_380 = l_380);
                    }
                    for (l_381 = 0; (l_381 <= 0); l_381 += 1)
                    { /* block id: 141 */
                        int32_t l_383 = (-7L);
                        int32_t l_384[7][1][5] = {{{0x9B219FC2L,0L,0xB1F27604L,0x6B189446L,(-1L)}},{{2L,0x27A12609L,0x9B219FC2L,0x9B219FC2L,0x27A12609L}},{{0xA5C97E8FL,0x74753AF2L,(-9L),(-1L),0x27A12609L}},{{0L,0xB843FA7BL,0L,0x63A894B2L,(-1L)}},{{0x74753AF2L,0x63A894B2L,0L,(-10L),(-10L)}},{{0L,(-9L),0L,0L,0x88A9712EL}},{{0xA5C97E8FL,(-9L),0x6B189446L,0x74753AF2L,0xB843FA7BL}}};
                        uint64_t l_392[4];
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_392[i] = 0xAC043ED244688A73LL;
                        --l_387;
                        l_392[3]--;
                        l_382 ^= 1L;
                    }
                    if ((*g_204))
                    { /* block id: 146 */
                        (*g_204) &= (safe_mod_func_int64_t_s_s(g_73, 0x4B730C5E3A8EF332LL));
                        return g_152[1];
                    }
                    else
                    { /* block id: 149 */
                        (*g_399) = g_397;
                    }
                    --l_403;
                }
                else
                { /* block id: 153 */
                    uint32_t l_408[8] = {0xF8A7F073L,0xF8A7F073L,0xF8A7F073L,0xF8A7F073L,0xF8A7F073L,0xF8A7F073L,0xF8A7F073L,0xF8A7F073L};
                    int i;
                    l_408[2] |= (l_406[5][3][1] == l_407);
                }
            }
        }
        if ((*g_204))
            continue;
    }
lbl_1059:
    if (((0xA669B465L > ((g_410 , (((g_411[2] = &g_218) == ((*l_412) = &g_218)) & 4294967294UL)) ^ ((((safe_mul_func_int16_t_s_s(g_218, (safe_div_func_uint32_t_u_u((g_421 = ((0x41C1L || (((*l_419) = l_418) == (+((p_38 | 0UL) >= g_377)))) != g_68)), p_38)))) | p_38) != l_59[8][3][0]) , l_59[8][3][0]))) || p_38))
    { /* block id: 165 */
        union U0 **l_426 = &g_162;
        int32_t l_429 = (-1L);
        int32_t l_464 = (-8L);
        int32_t l_469 = 0x518AC3DCL;
        int32_t l_470 = 0x94C2EA7FL;
        int32_t l_471[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
        uint32_t **l_575 = &l_419;
        uint32_t ***l_574 = &l_575;
        uint16_t * const l_580 = &g_104;
        int32_t *l_635 = &l_471[3];
        int32_t **l_643[7];
        int32_t l_658 = 9L;
        uint64_t l_821 = 18446744073709551615UL;
        int32_t l_954 = 0x72D57E49L;
        int8_t *l_961 = &l_672[1];
        int i;
        for (i = 0; i < 7; i++)
            l_643[i] = &l_635;
    }
    else
    { /* block id: 440 */
        int8_t *l_962 = &l_670;
        int64_t *l_970 = &g_375;
        int64_t **l_969[2];
        int32_t l_975 = 1L;
        int8_t *l_976[2];
        const int32_t l_977 = 0x7FF2B480L;
        int32_t *l_978[2];
        int i;
        for (i = 0; i < 2; i++)
            l_969[i] = &l_970;
        for (i = 0; i < 2; i++)
            l_976[i] = &l_672[1];
        for (i = 0; i < 2; i++)
            l_978[i] = (void*)0;
        if (((((*l_962) = g_269.f0) & (g_330 , 1L)) > ((safe_div_func_int64_t_s_s((((safe_sub_func_int64_t_s_s((safe_lshift_func_int8_t_s_u(((((g_801 == l_969[0]) , (l_979 ^= ((g_73 > (safe_mod_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((l_975 = (((((*l_970) = l_975) != ((((l_975 , (-1L)) || l_975) | p_38) <= p_38)) , g_225) > 0xCFL)), p_38)), p_38))) > l_977))) || p_38) , g_493), p_38)), p_38)) || p_38) & p_38), p_38)) & l_386)))
        { /* block id: 445 */
            if (p_38)
                goto lbl_409;
            for (l_854 = (-18); (l_854 < 21); l_854 = safe_add_func_uint8_t_u_u(l_854, 8))
            { /* block id: 449 */
                uint8_t l_982 = 255UL;
                l_982++;
                if (l_982)
                    continue;
                if (p_38)
                    continue;
            }
        }
        else
        { /* block id: 454 */
            uint32_t l_988[7] = {0x41850869L,0x41850869L,18446744073709551615UL,0x41850869L,0x41850869L,18446744073709551615UL,0x41850869L};
            int32_t l_989 = (-1L);
            int i;
            l_987 = (safe_rshift_func_int8_t_s_u(0xD6L, 5));
            l_989 &= (l_988[1] = 0xC40CBA59L);
        }
    }
    if ((safe_div_func_uint16_t_u_u((((((l_382 &= (l_385 = (safe_add_func_uint32_t_u_u(((*l_419)--), (*g_398))))) >= (safe_sub_func_int64_t_s_s(((((l_1016 = ((*l_1014) = (g_754.f1 != (((safe_div_func_uint32_t_u_u(p_38, p_38)) ^ (safe_rshift_func_uint16_t_u_u((((g_12 < ((g_1009 = ((safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_u(0L, 5)), 10)) , (g_1008[0][3][9] = &g_63))) == &g_73)) && ((~((~(safe_rshift_func_int16_t_s_u(((*g_161) == (*l_354)), g_862.f2))) < p_38)) , 1UL)) , 0xFD90L), 0))) >= p_38)))) >= p_38) , (-1L)) , p_38), g_929))) <= p_38) <= 0L) , 65534UL), p_38)))
    { /* block id: 467 */
        uint8_t *l_1021 = &g_96;
        uint8_t *l_1022 = &l_1016;
        uint16_t *l_1029 = (void*)0;
        uint16_t *l_1030 = &l_505;
        int32_t l_1031[7][3][7] = {{{0x2FEA77BAL,(-1L),(-1L),0x0390DED8L,(-1L),(-1L),0x2FEA77BAL},{(-1L),(-7L),(-1L),0x8D20A8D6L,0xC56F0160L,(-1L),0xC56F0160L},{(-1L),0xC56F0160L,0xC56F0160L,0xC56F0160L,(-7L),(-1L),0x2FEA77BAL}},{{(-1L),(-1L),0x9451AE3DL,(-7L),(-7L),0x9451AE3DL,(-1L)},{(-7L),(-1L),(-1L),(-1L),0x0390DED8L,0x2FEA77BAL,0x2FEA77BAL},{(-1L),(-1L),(-7L),(-1L),(-1L),(-1L),0x0390DED8L}},{{0x9451AE3DL,(-1L),(-1L),(-1L),1L,(-1L),(-1L)},{0x0390DED8L,0x0390DED8L,0xC56F0160L,(-7L),(-1L),0x2FEA77BAL,0x9451AE3DL},{0x9451AE3DL,(-1L),0xC56F0160L,0xC56F0160L,(-1L),0x9451AE3DL,1L}},{{(-1L),0xC56F0160L,(-1L),1L,(-1L),(-1L),1L},{(-7L),0x8D20A8D6L,(-7L),0x2FEA77BAL,1L,(-1L),0x9451AE3DL},{(-1L),0xC56F0160L,(-1L),0x2FEA77BAL,(-1L),0xC56F0160L,(-1L)}},{{0xC56F0160L,(-1L),0x9451AE3DL,1L,0x0390DED8L,(-1L),0x0390DED8L},{0xC56F0160L,0x0390DED8L,0x0390DED8L,0xC56F0160L,(-7L),(-1L),0x2FEA77BAL},{(-1L),(-1L),0x9451AE3DL,(-7L),(-7L),0x9451AE3DL,(-1L)}},{{(-7L),(-1L),(-1L),(-1L),0x0390DED8L,0x2FEA77BAL,0x2FEA77BAL},{(-1L),(-1L),(-7L),(-1L),(-1L),(-1L),0x0390DED8L},{0x9451AE3DL,(-1L),(-1L),(-1L),1L,(-1L),(-1L)}},{{0x0390DED8L,0x0390DED8L,0xC56F0160L,(-7L),(-1L),0x2FEA77BAL,0x9451AE3DL},{0x9451AE3DL,(-1L),0xC56F0160L,0xC56F0160L,(-1L),0x9451AE3DL,1L},{(-1L),0xC56F0160L,(-1L),1L,(-1L),(-1L),1L}}};
        uint64_t *l_1032 = &g_216;
        int32_t l_1033 = 0xC6A75862L;
        int i, j, k;
        l_1033 ^= (safe_sub_func_int32_t_s_s((((*l_1032) &= (safe_sub_func_int32_t_s_s(p_38, (((l_1021 = &g_96) != l_1022) || (safe_add_func_uint8_t_u_u((g_1025 != &l_406[1][0][7]), ((0x84CE8C90L <= p_38) >= (&g_801 != ((((*l_1030) = (0L && (*l_1014))) == l_1031[5][0][3]) , (void*)0))))))))) || p_38), p_38));
    }
    else
    { /* block id: 472 */
        int32_t l_1040 = 0xC80F70FCL;
        int32_t l_1060 = (-10L);
        int32_t l_1061 = 1L;
        const uint32_t *l_1097[8] = {&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929,&g_929};
        int64_t l_1126 = 0x7F32CF06AD621579LL;
        int32_t l_1132 = (-1L);
        int32_t l_1133 = 0x3373679BL;
        int32_t l_1134 = 0L;
        int32_t l_1136 = (-1L);
        int32_t l_1137 = 2L;
        int32_t l_1138 = 0x80DE1D7DL;
        int32_t l_1139 = 1L;
        int32_t l_1141 = 0xD1554E2CL;
        int32_t l_1142[5] = {1L,1L,1L,1L,1L};
        int64_t l_1143 = 0L;
        uint8_t **l_1155 = (void*)0;
        uint8_t ***l_1154[7][1] = {{&l_1155},{&l_1155},{&l_1155},{&l_1155},{&l_1155},{&l_1155},{&l_1155}};
        uint8_t ****l_1156 = &l_1154[4][0];
        uint32_t l_1174 = 0x4526366BL;
        uint32_t **l_1203 = &l_444;
        uint32_t ***l_1202 = &l_1203;
        uint16_t *l_1243 = &g_104;
        int i, j;
        for (l_790 = 0; (l_790 <= 2); l_790 += 1)
        { /* block id: 475 */
            uint64_t *l_1047[1];
            int32_t l_1057[8][6];
            int32_t l_1093 = (-1L);
            int32_t *l_1100 = (void*)0;
            uint16_t l_1145 = 0xC9D0L;
            int i, j;
            for (i = 0; i < 1; i++)
                l_1047[i] = &g_216;
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 6; j++)
                    l_1057[i][j] = 0x940ED0CFL;
            }
            if (p_38)
                break;
            for (g_68 = 2; (g_68 >= 0); g_68 -= 1)
            { /* block id: 479 */
                uint8_t l_1038 = 0x89L;
                int32_t l_1039[4][4][3] = {{{0xA89DE787L,0x6B6129EBL,0x6B6129EBL},{1L,0x6B6129EBL,(-1L)},{(-1L),0xA89DE787L,0xDBBF2409L},{1L,1L,0xDBBF2409L}},{{0xA89DE787L,(-1L),(-1L)},{0x6B6129EBL,1L,0x6B6129EBL},{0x6B6129EBL,0xA89DE787L,1L},{0xA89DE787L,0x6B6129EBL,0x6B6129EBL}},{{1L,0x6B6129EBL,(-1L)},{(-1L),0xA89DE787L,0xDBBF2409L},{1L,1L,0xDBBF2409L},{0xA89DE787L,(-1L),(-1L)}},{{0x6B6129EBL,1L,0x6B6129EBL},{0x6B6129EBL,0xA89DE787L,8L},{0x6B6129EBL,(-1L),(-1L)},{8L,(-1L),0xDBBF2409L}}};
                int32_t l_1128[2][3] = {{6L,6L,6L},{0xE518B05EL,0xE518B05EL,0xE518B05EL}};
                int i, j, k;
                l_1040 &= ((*l_1014) |= (safe_mul_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u(l_1038, 5)), (l_1039[1][3][1] = 0xB173L))));
                if (((safe_rshift_func_int16_t_s_u((safe_rshift_func_int16_t_s_u(((safe_sub_func_uint16_t_u_u((g_671.f2 <= (&g_216 != l_1047[0])), (18446744073709551615UL ^ ((void*)0 == g_1050)))) <= p_38), ((safe_add_func_uint16_t_u_u((((((safe_mod_func_int8_t_s_s(((-1L) ^ ((safe_div_func_int32_t_s_s((p_38 > g_152[1].f2), l_1040)) | p_38)), 0xEDL)) >= g_421) , 0xA5B9844D801BDF7FLL) | l_1040) && l_1039[2][1][2]), l_1057[1][0])) && 65535UL))), g_671.f1)) <= 0x8C229520L))
                { /* block id: 483 */
                    for (l_382 = 2; (l_382 >= 0); l_382 -= 1)
                    { /* block id: 486 */
                        return g_1058;
                    }
                    if (l_789)
                        goto lbl_1059;
                    if (g_493)
                        goto lbl_1059;
                }
                else
                { /* block id: 491 */
                    l_1061 &= (l_1060 = p_38);
                }
                if (p_38)
                { /* block id: 495 */
                    union U0 *l_1062 = (void*)0;
                    union U0 ***l_1078 = &g_161;
                    uint16_t *l_1090 = &g_104;
                    int32_t l_1091 = (-1L);
                    (*g_1066) = ((*l_354) = l_1062);
                    l_1093 = (((l_1060 , ((((void*)0 == (*g_1026)) , (g_1067 , 0x7A62E785L)) , (safe_sub_func_int8_t_s_s((safe_div_func_uint8_t_u_u(((l_1057[1][0] = (safe_mod_func_uint8_t_u_u((((safe_sub_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u((((*l_1078) = &g_162) == ((((((safe_rshift_func_uint16_t_u_s(g_263.f0, (l_1091 = (safe_mod_func_int8_t_s_s((((((((safe_mod_func_int8_t_s_s(((~(safe_mul_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(((*l_1090) = ((void*)0 != &l_1039[0][1][2])), 0xD542L)), l_1061))) , l_1091), l_1039[2][0][2])) < p_38) != p_38) <= p_38) , g_862.f2) != l_1057[1][0]) != 0x5A7042FAB52B21BDLL), l_1091))))) & l_1039[3][0][1]) < l_1092) || l_1040) || 0x34C1BC01E1FCA00FLL) , (void*)0)), 0xD9CBL)), l_1040)) <= (-4L)) < l_1039[1][3][1]), 0xC6L))) >= l_1093), p_38)), (*g_1009))))) , g_203) || p_38);
                    for (g_745.f3 = 0; (g_745.f3 <= 2); g_745.f3 += 1)
                    { /* block id: 505 */
                        if (p_38)
                            break;
                        if (p_38)
                            continue;
                    }
                    if ((*g_204))
                        continue;
                }
                else
                { /* block id: 510 */
                    const uint32_t *l_1098 = &g_1099;
                    int32_t l_1123 = 0x74CDAA60L;
                    int32_t l_1135 = 1L;
                    int32_t l_1140[4][4][9] = {{{0x22227880L,0xEDC4E3C1L,(-1L),0x8565D343L,(-1L),(-1L),0xEEF6DD5AL,0xBBBBD75EL,0x0589908EL},{1L,7L,0xF166F7BCL,0x9C4F13C1L,0xF6C61826L,0xF166F7BCL,0L,0x393ACC55L,0L},{(-7L),0L,(-1L),0x3D6A59A9L,0x3D6A59A9L,(-1L),0L,(-7L),0x0589908EL},{0x393ACC55L,0L,0xF166F7BCL,0xF6C61826L,0x9C4F13C1L,0xF166F7BCL,7L,1L,0L}},{{0xBBBBD75EL,0xEEF6DD5AL,(-1L),(-1L),0x8565D343L,(-1L),0xEDC4E3C1L,0x22227880L,0x0589908EL},{0xB2738BBCL,0x02AC2D84L,0xF166F7BCL,0L,0L,0xF166F7BCL,0x02AC2D84L,0xB2738BBCL,0L},{0x22227880L,0xEDC4E3C1L,(-1L),0x8565D343L,(-1L),(-1L),0xEEF6DD5AL,0xBBBBD75EL,0x0589908EL},{1L,7L,0xF166F7BCL,0x9C4F13C1L,0xF6C61826L,0xF166F7BCL,0L,0x393ACC55L,0L}},{{(-7L),0L,(-1L),0x3D6A59A9L,0x3D6A59A9L,(-1L),0L,(-7L),0x0589908EL},{0x393ACC55L,0L,0xF166F7BCL,0xF6C61826L,0x9C4F13C1L,0xF166F7BCL,7L,1L,0L},{0xBBBBD75EL,0xEEF6DD5AL,(-1L),(-1L),0x8565D343L,(-1L),0xEDC4E3C1L,0x22227880L,0x0589908EL},{0xB2738BBCL,0x02AC2D84L,0xF166F7BCL,0L,0L,0xF166F7BCL,0x02AC2D84L,0xB2738BBCL,0L}},{{0x22227880L,0xEDC4E3C1L,(-1L),0x8565D343L,(-1L),(-1L),0xEEF6DD5AL,0xBBBBD75EL,0x0589908EL},{1L,7L,0xF166F7BCL,0x9C4F13C1L,0xF6C61826L,0xF166F7BCL,0L,0x393ACC55L,0L},{(-7L),0L,(-1L),0x3D6A59A9L,0x3D6A59A9L,(-1L),0L,(-7L),0x0589908EL},{0x393ACC55L,0L,0xF166F7BCL,0xF6C61826L,0x9C4F13C1L,0xF166F7BCL,7L,1L,0L}}};
                    int16_t **l_1148 = &l_413[4][4][0];
                    int i, j, k;
                    if (((!g_855[0][0]) > ((l_1098 = l_1097[4]) == (void*)0)))
                    { /* block id: 512 */
                        int64_t *l_1124 = &l_979;
                        int32_t l_1127 = (-2L);
                        int64_t *l_1129 = &l_1126;
                        int32_t l_1130 = 0x67B6D0A3L;
                        int32_t l_1131[3][9][3] = {{{0L,0x12D0569AL,0xF741950EL},{9L,1L,2L},{5L,0x12D0569AL,0xC257FD4BL},{0xC257FD4BL,8L,5L},{0xD8AE7888L,0x6A507741L,5L},{0L,0xC257FD4BL,0xD089219AL},{1L,9L,0xF249BD01L},{7L,0x12D0569AL,0xF249BD01L},{0xB58FE649L,0x16AEFECAL,0xD089219AL}},{{5L,0L,5L},{0x1515F3B6L,0xB58FE649L,5L},{0xC257FD4BL,0x99FA8476L,3L},{0xDE1E697AL,3L,0x2637C8FFL},{1L,0x1515F3B6L,0L},{0xDE1E697AL,7L,5L},{0xC257FD4BL,1L,0x7C9E3F61L},{0x99FA8476L,0x5E632668L,3L},{0x1D5F222AL,5L,0x3933DC1EL}},{{5L,1L,0x16AEFECAL},{0xDE1E697AL,1L,0xF741950EL},{2L,5L,0L},{0x5E632668L,0x5E632668L,7L},{(-1L),1L,0x2637C8FFL},{3L,7L,0x16AEFECAL},{0x1D5F222AL,0x1515F3B6L,0xDE1E697AL},{0xC257FD4BL,3L,0x16AEFECAL},{0x5E632668L,0x99FA8476L,0x2637C8FFL}}};
                        int i, j, k;
                        l_1100 = &l_1061;
                        (*l_1014) &= (safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((l_1060 = ((*l_1100) = ((safe_mod_func_int32_t_s_s((l_1039[3][1][0] = (((*l_1129) = (safe_rshift_func_uint16_t_u_u((((*g_1009) ^= (safe_lshift_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((0x3A6D85AFL <= (safe_mod_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(p_38, (safe_div_func_uint64_t_u_u(6UL, (safe_unary_minus_func_uint8_t_u(((g_745 , 1UL) & (!((((((*l_419) = (safe_sub_func_uint8_t_u_u((((((*l_1124) ^= l_1123) , l_1125) != (void*)0) & ((p_38 > l_1126) & (-10L))), 0xC4L))) && (*g_329)) , p_38) ^ 0xEF0E7E3B83E2D20FLL) | l_1127))))))))), l_1039[3][0][2]))) & (-4L)), 1L)), l_1128[1][1]))) | 0x18L), 1))) || (*l_1100))), p_38)) <= p_38))), 10)), 4L));
                        ++l_1145;
                    }
                    else
                    { /* block id: 523 */
                        (*g_765) = &l_1039[1][3][1];
                        l_1039[0][1][0] &= ((**g_397) | (l_1133 < (&g_411[2] != l_1148)));
                        if (l_1038)
                            break;
                    }
                }
            }
        }
        --l_1150;
        if ((g_1153 , ((((*l_1156) = l_1154[4][0]) == &g_1026) , ((safe_mod_func_int16_t_s_s((safe_div_func_uint16_t_u_u(0UL, (safe_lshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(0x8668C2E885EBB045LL, ((safe_mod_func_uint16_t_u_u((g_1167 , 9UL), (p_38 & (l_1133 |= (safe_mul_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u(((l_1126 != 0L) && 0xFAL), p_38)) | 0x5DL), 1UL)))))) && p_38))), l_1137)))), l_1138)) , l_1174))))
        { /* block id: 534 */
            uint16_t l_1177 = 0UL;
            uint32_t **l_1200 = (void*)0;
            uint32_t ***l_1199 = &l_1200;
            uint32_t ****l_1201 = &l_1199;
            uint16_t *l_1217 = &g_104;
            uint32_t l_1218 = 4294967295UL;
            int32_t l_1241[4][3] = {{(-2L),(-2L),1L},{(-2L),(-2L),1L},{(-2L),(-2L),1L},{(-2L),(-2L),1L}};
            int i, j;
            for (l_1092 = 0; (l_1092 > 41); l_1092 = safe_add_func_int32_t_s_s(l_1092, 9))
            { /* block id: 537 */
                int32_t l_1194 = (-1L);
                int32_t *l_1197 = &l_1142[4];
                l_1177 = p_38;
                if (((safe_sub_func_int64_t_s_s(((((l_1177 & (safe_div_func_uint64_t_u_u(18446744073709551615UL, (safe_mul_func_int8_t_s_s((g_1184 , (*g_1009)), (safe_sub_func_int32_t_s_s((safe_add_func_uint16_t_u_u((((((safe_add_func_uint16_t_u_u(0x2DCBL, l_1137)) == ((safe_rshift_func_int8_t_s_u(((*l_1007) = (*g_1009)), 6)) < l_1177)) ^ ((l_1193 && g_547[1].f1) && p_38)) > l_1194) > 5L), g_1184.f0)), l_1177))))))) , 0x90DF9C0825D6B2A0LL) && (-1L)) <= 0xE9L), 0UL)) >= l_1194))
                { /* block id: 540 */
                    (*l_1014) = 1L;
                    for (l_1177 = 0; (l_1177 != 50); ++l_1177)
                    { /* block id: 544 */
                        if (p_38)
                            break;
                        (*g_765) = (l_1197 = l_1197);
                    }
                }
                else
                { /* block id: 549 */
                    return g_1198;
                }
            }
            l_1132 ^= ((((((*l_1201) = l_1199) == (g_671 , l_1202)) , (safe_mod_func_int32_t_s_s(((void*)0 == g_1206), (safe_sub_func_uint64_t_u_u(p_38, (safe_mul_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((1UL & (!l_1139)), ((*l_1217) ^= p_38))), 0xF9L)), 0x47L))))))) , l_1218) , l_1219);
            for (l_1141 = 0; (l_1141 <= 18); l_1141 = safe_add_func_int8_t_s_s(l_1141, 1))
            { /* block id: 558 */
                const int8_t l_1232[1] = {1L};
                uint64_t *l_1239 = (void*)0;
                uint64_t *l_1240 = &g_216;
                union U0 **l_1246 = &g_162;
                int32_t l_1255[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
                int16_t **l_1256 = &g_411[2];
                int i;
                l_1241[2][2] = (safe_lshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s(7L, p_38)), (!(((*l_1217) = p_38) & ((((*l_1240) = (((*g_398) != ((safe_add_func_uint64_t_u_u(18446744073709551612UL, ((~(safe_add_func_uint32_t_u_u(l_1232[0], l_1232[0]))) > ((p_38 && (((safe_mod_func_int8_t_s_s((((void*)0 == l_1235[8][0]) <= 0x2917L), p_38)) | p_38) <= p_38)) && 4294967292UL)))) , l_1232[0])) < p_38)) >= l_1136) < 0xC145L)))));
                (*g_765) = ((((0xC4C55D43939FA258LL > ((*l_1240) ^= (((*l_1007) = (((g_1242 , p_38) , l_1243) == ((safe_lshift_func_uint16_t_u_u(((&l_413[2][3][0] == (((((void*)0 != l_1246) < ((((safe_sub_func_uint64_t_u_u((l_1255[0] = (safe_mod_func_uint8_t_u_u(p_38, ((safe_add_func_uint8_t_u_u((safe_div_func_int16_t_s_s((l_1126 <= l_1174), (-1L))), 7UL)) , p_38)))), 18446744073709551612UL)) || 0x399605C5L) && l_1232[0]) , 0x3FE4F03728F62894LL)) ^ l_1232[0]) , l_1256)) , l_1241[1][2]), g_104)) , &g_12))) | l_1177))) || 0xB72AA0D8L) , g_586.f1) , (void*)0);
            }
            (*g_765) = &l_1241[2][2];
        }
        else
        { /* block id: 568 */
            return g_152[1];
        }
        (*g_765) = &l_1139;
    }
    if ((safe_mul_func_int8_t_s_s((safe_div_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s(((*l_1268) = ((+0x44FC77170961206FLL) || (safe_mod_func_int16_t_s_s(p_38, (safe_mod_func_int64_t_s_s(p_38, (g_216 = 18446744073709551609UL))))))), p_38)), (***g_399))), ((*l_1007) = (*l_1014)))))
    { /* block id: 576 */
        return g_152[1];
    }
    else
    { /* block id: 578 */
        int8_t l_1271 = 0xEEL;
        int32_t *l_1272 = &l_794[1][6][1];
        l_1272 = func_41((safe_mul_func_int8_t_s_s(l_1271, 0x72L)));
    }
    return g_1273;
}


/* ------------------------------------------ */
/* 
 * reads : g_68 g_152 g_161 g_168 g_104 g_63 g_162 g_96 g_106.f0 g_12 g_171 g_204 g_203 g_216 g_218 g_152.f1 g_73 g_263 g_269 g_95.f0 g_225 g_1065
 * writes: g_68 g_63 g_161 g_171 g_104 g_162 g_203 g_216 g_218 g_225 g_204 g_73 g_101 g_328 g_331 g_341 g_1065
 */
static int32_t * func_41(int8_t  p_42)
{ /* block id: 20 */
    int8_t l_114 = 1L;
    int32_t l_125 = 0x5B4FB637L;
    int32_t l_129 = (-6L);
    int32_t l_130 = (-7L);
    int32_t l_131 = (-1L);
    int32_t l_133 = 0xB73D745DL;
    int32_t l_134 = (-1L);
    int32_t l_135 = (-8L);
    int32_t l_141 = 1L;
    int32_t l_144 = 0x039D6A31L;
    int32_t **l_169 = (void*)0;
    union U0 *l_187[3][10][5] = {{{&g_106[3][0],(void*)0,(void*)0,&g_106[0][0],&g_106[0][0]},{&g_106[0][0],&g_106[3][0],&g_106[0][0],&g_106[1][0],(void*)0},{&g_106[2][0],&g_106[6][0],&g_106[5][0],&g_106[5][0],&g_106[5][0]},{(void*)0,&g_106[5][0],&g_106[5][0],(void*)0,&g_106[3][0]},{&g_106[5][0],&g_106[3][0],&g_106[5][0],&g_106[5][0],&g_106[4][0]},{&g_106[5][0],&g_106[5][0],&g_106[0][0],&g_106[5][0],(void*)0},{&g_106[2][0],&g_106[5][0],(void*)0,&g_106[5][0],(void*)0},{&g_106[5][0],(void*)0,&g_106[5][0],&g_106[5][0],&g_106[0][0]},{(void*)0,(void*)0,&g_106[5][0],(void*)0,&g_106[5][0]},{&g_106[5][0],&g_106[2][0],&g_106[6][0],&g_106[5][0],&g_106[2][0]}},{{&g_106[0][0],&g_106[2][0],&g_106[5][0],&g_106[5][0],&g_106[3][0]},{(void*)0,(void*)0,&g_106[5][0],&g_106[2][0],&g_106[6][0]},{&g_106[5][0],(void*)0,&g_106[5][0],&g_106[2][0],&g_106[3][0]},{&g_106[5][0],&g_106[5][0],&g_106[1][0],&g_106[1][0],&g_106[5][0]},{&g_106[3][0],&g_106[5][0],(void*)0,(void*)0,&g_106[5][0]},{(void*)0,&g_106[3][0],&g_106[5][0],&g_106[5][0],(void*)0},{&g_106[0][0],&g_106[5][0],&g_106[5][0],&g_106[0][0],&g_106[2][0]},{(void*)0,&g_106[6][0],(void*)0,(void*)0,(void*)0},{&g_106[3][0],&g_106[3][0],&g_106[6][0],&g_106[2][0],&g_106[4][0]},{&g_106[5][0],(void*)0,&g_106[0][0],&g_106[0][0],&g_106[3][0]}},{{&g_106[5][0],&g_106[1][0],&g_106[1][0],&g_106[5][0],&g_106[5][0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_106[0][0],&g_106[3][0],&g_106[6][0],&g_106[1][0],(void*)0},{&g_106[5][0],&g_106[6][0],&g_106[5][0],&g_106[5][0],&g_106[5][0]},{(void*)0,&g_106[5][0],&g_106[5][0],&g_106[5][0],&g_106[3][0]},{&g_106[3][0],&g_106[4][0],&g_106[5][0],&g_106[3][0],&g_106[5][0]},{&g_106[5][0],(void*)0,(void*)0,&g_106[5][0],(void*)0},{&g_106[6][0],&g_106[5][0],&g_106[0][0],&g_106[5][0],(void*)0},{&g_106[3][0],&g_106[1][0],&g_106[5][0],&g_106[5][0],(void*)0},{&g_106[0][0],&g_106[5][0],&g_106[5][0],&g_106[5][0],&g_106[5][0]}}};
    uint32_t *l_226 = (void*)0;
    int32_t *l_244 = (void*)0;
    int32_t **l_324 = &g_101[0];
    const int32_t *l_326 = &l_125;
    const int32_t **l_325 = &l_326;
    const int32_t ***l_327[5];
    const int8_t l_337 = 0L;
    uint16_t *l_338 = &g_104;
    uint8_t *l_339 = (void*)0;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_327[i] = &l_325;
    for (g_68 = 0; (g_68 != 3); g_68 = safe_add_func_uint32_t_u_u(g_68, 8))
    { /* block id: 23 */
        int32_t l_121 = 0x0C79A429L;
        int32_t l_124 = 1L;
        int32_t l_126 = 0x2E691EA7L;
        int32_t l_127 = 0x6BF143A6L;
        int32_t l_128 = (-4L);
        int32_t l_132 = 0xCADF514AL;
        int32_t l_136 = 0x5F86E748L;
        int32_t l_137 = 0xAC14BEF0L;
        int32_t l_138 = 8L;
        int8_t l_139[4][4][2];
        int32_t l_140 = 7L;
        int32_t l_142 = 0x2D19084CL;
        int32_t l_143[3];
        union U0 ***l_163 = &g_161;
        union U0 **l_165 = &g_162;
        union U0 ***l_164 = &l_165;
        uint32_t *l_170 = &g_171;
        uint8_t l_172 = 0xA8L;
        uint16_t *l_173 = &g_104;
        uint64_t l_198 = 0xD5445E50017F8393LL;
        int32_t l_305 = (-1L);
        int i, j, k;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 4; j++)
            {
                for (k = 0; k < 2; k++)
                    l_139[i][j][k] = 0L;
            }
        }
        for (i = 0; i < 3; i++)
            l_143[i] = (-6L);
        for (g_63 = 0; (g_63 < 15); g_63 = safe_add_func_uint64_t_u_u(g_63, 7))
        { /* block id: 26 */
            int32_t l_112 = 0x32BC3581L;
            int32_t *l_113 = (void*)0;
            int32_t *l_115 = &l_112;
            int32_t *l_116 = (void*)0;
            int32_t *l_117 = &l_112;
            int32_t *l_118 = (void*)0;
            int32_t *l_119 = (void*)0;
            int32_t *l_120 = (void*)0;
            int32_t *l_122 = &l_112;
            int32_t *l_123[9][1][3] = {{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}},{{&g_68,&g_68,&l_112}}};
            uint64_t l_145 = 18446744073709551615UL;
            int i, j, k;
            l_145--;
        }
        if (l_128)
            continue;
        if (l_133)
            break;
        if ((p_42 , (safe_rshift_func_int16_t_s_s((safe_div_func_uint64_t_u_u((g_152[1] , (safe_mod_func_int32_t_s_s(p_42, (safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(0xE5L, ((safe_sub_func_uint32_t_u_u(((((*l_163) = g_161) != ((*l_164) = &g_162)) & ((*l_173) &= (safe_mod_func_uint32_t_u_u(((*l_170) = (((g_168 , (void*)0) == l_169) > 1UL)), l_172)))), 0x9AD7F266L)) && 0xAC2E06E0E4DEADDELL))), 0x3CL))))), 0xFD8839424BF6E064LL)), 1))))
        { /* block id: 35 */
            uint8_t *l_178 = &l_172;
            union U0 *l_188 = &g_106[5][0];
            uint32_t l_232[1][8][3] = {{{0x50E478B0L,0x0E12FE73L,0x0E12FE73L},{1UL,0UL,8UL},{0x50E478B0L,1UL,0x50E478B0L},{1UL,1UL,8UL},{4294967292UL,4294967292UL,0x0E12FE73L},{0xD2CFA96FL,1UL,1UL},{0x0E12FE73L,1UL,1UL},{0xD2CFA96FL,0UL,0xD2CFA96FL}}};
            int32_t l_233 = 0xE931A32EL;
            int i, j, k;
            l_130 ^= ((safe_div_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(((((*l_178) = g_68) <= (-1L)) && (p_42 >= (safe_mod_func_uint32_t_u_u((((g_63 != ((safe_add_func_uint32_t_u_u((((safe_lshift_func_uint16_t_u_s(p_42, 15)) && (safe_mul_func_int16_t_s_s(((((*g_161) = (**l_164)) == (l_188 = l_187[1][3][2])) || (safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s((+(safe_mul_func_int8_t_s_s(((((safe_rshift_func_uint8_t_u_u(l_140, g_96)) >= l_137) | l_198) > 0xFAA3ACFEL), p_42))), 0x0B8A5674ED491631LL)), p_42))), g_106[5][0].f0))) , g_12), l_137)) | p_42)) , p_42) , 4294967294UL), p_42)))), g_171)), 0x60L)) < 0L);
            for (l_140 = 0; (l_140 <= 2); l_140 += 1)
            { /* block id: 42 */
                int32_t *l_201 = (void*)0;
                int32_t **l_245 = &l_201;
                (*g_204) &= (safe_rshift_func_uint16_t_u_u(7UL, 15));
                if ((((void*)0 != &g_161) >= (&g_104 == (void*)0)))
                { /* block id: 44 */
                    int16_t *l_217 = &g_218;
                    uint64_t *l_230 = &l_198;
                    const int32_t l_231 = 0xE32BAB41L;
                    l_233 ^= (safe_sub_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((+(((safe_mod_func_uint16_t_u_u((g_104 = ((safe_div_func_uint64_t_u_u((((safe_mod_func_uint8_t_u_u((((*l_217) &= (g_216 &= p_42)) && l_124), ((safe_rshift_func_int8_t_s_u(2L, (safe_rshift_func_int16_t_s_s(g_203, (safe_mod_func_int64_t_s_s((g_225 = p_42), ((*l_230) = (p_42 ^ (((l_226 != (void*)0) == (~(safe_div_func_int64_t_s_s(1L, 7UL)))) , g_12))))))))) && l_231))) <= g_104) <= 0L), l_231)) | g_152[1].f1)), g_73)) || 0x10L) , l_232[0][4][0])), g_96)), 0x5F7CL));
                }
                else
                { /* block id: 51 */
                    int8_t *l_238 = &l_139[0][1][0];
                    uint64_t *l_242 = &g_216;
                    uint64_t **l_241 = &l_242;
                    if (p_42)
                    { /* block id: 52 */
                        int32_t *l_240 = &l_233;
                        uint64_t ***l_243 = &l_241;
                        g_204 = &g_203;
                        (*l_240) = (safe_sub_func_int16_t_s_s((safe_div_func_uint32_t_u_u(((0x2A22L > l_132) == ((l_238 == &p_42) , ((-1L) >= (&l_114 == &p_42)))), ((((((**l_164) = (*g_161)) == (void*)0) < g_12) , g_152[1].f1) && 0x89D8L))), 0x22D6L));
                        (*l_243) = l_241;
                        (*l_240) = (6UL & (((void*)0 == &g_162) >= ((**l_241) = p_42)));
                    }
                    else
                    { /* block id: 59 */
                        (*g_204) ^= p_42;
                    }
                }
                (*l_245) = (l_244 = &g_68);
                for (l_127 = 2; (l_127 >= 0); l_127 -= 1)
                { /* block id: 67 */
                    int16_t *l_253[2][8] = {{&g_218,(void*)0,&g_218,(void*)0,&g_218,(void*)0,&g_218,(void*)0},{&g_218,(void*)0,&g_218,(void*)0,&g_218,(void*)0,&g_218,(void*)0}};
                    int8_t *l_262 = &g_73;
                    uint64_t *l_264 = &l_198;
                    int32_t l_265 = (-8L);
                    int32_t l_268[4][10][1] = {{{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}},{{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}},{{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}},{{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L},{1L}}};
                    int i, j, k;
                    (*g_204) = (g_216 <= (safe_add_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s((-6L), (safe_unary_minus_func_uint16_t_u((((*l_264) = ((g_218 = (safe_lshift_func_int8_t_s_s(0x96L, 3))) || (safe_mul_func_uint16_t_u_u((p_42 != (((void*)0 == &p_42) , g_218)), ((safe_add_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(p_42, 13)), (((safe_div_func_int8_t_s_s(((*l_262) = p_42), (**l_245))) , g_263) , 1L))) , p_42))))) && l_172))))) & l_265), (*l_201))));
                    if ((1L & 0x46L))
                    { /* block id: 72 */
                        (*l_245) = &g_68;
                        l_268[0][5][0] ^= (safe_mul_func_uint8_t_u_u(l_265, 248UL));
                    }
                    else
                    { /* block id: 75 */
                        int32_t l_304 = 0xF8042BDCL;
                        int i, j, k;
                        l_305 |= (((g_269 , (safe_sub_func_uint8_t_u_u(((*l_178) = (safe_lshift_func_int8_t_s_s((l_265 != (((safe_rshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((~0x78L), (safe_rshift_func_int16_t_s_s((safe_add_func_uint16_t_u_u(((((safe_sub_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((**l_245), 2)), ((safe_div_func_int64_t_s_s(((((safe_lshift_func_uint16_t_u_s(l_268[1][9][0], 12)) , ((((safe_mod_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_rshift_func_uint16_t_u_s((0x26347CD1DC50AA39LL < (p_42 , (+(l_232[0][0][1] < (safe_lshift_func_uint8_t_u_u(g_95.f0, g_216)))))), (*l_244))) >= 0x6B983BC1L), p_42)), 0x4D18DC95L)) < g_218), 1)), 255UL)) != p_42) | (*l_244)) == l_304)) | 0x12L) == p_42), g_225)) >= g_225))) >= g_73) ^ 0x450EA62709E712BCLL) ^ g_63), l_198)), 5)))), 5)) && 4UL) < l_265)), 1))), (*l_244)))) == 0x00E44F06L) & l_233);
                    }
                }
            }
        }
        else
        { /* block id: 81 */
            uint32_t l_319 = 1UL;
            int16_t *l_321 = &g_218;
            for (l_114 = 0; (l_114 <= (-23)); --l_114)
            { /* block id: 84 */
                for (l_125 = (-9); (l_125 <= (-8)); ++l_125)
                { /* block id: 87 */
                    int32_t *l_323 = &l_124;
                    for (p_42 = 2; (p_42 >= 0); p_42 -= 1)
                    { /* block id: 90 */
                        int8_t *l_320 = &g_63;
                        int32_t *l_322 = &l_141;
                        int i;
                        (*l_322) ^= (!(7L != ((safe_mod_func_uint64_t_u_u((p_42 >= (((safe_mul_func_uint8_t_u_u(0x2DL, ((*l_320) |= (((safe_add_func_int8_t_s_s(((((p_42 <= (0xBDD3L > 0x4192L)) | (l_319 < 0x07L)) == (p_42 | p_42)) > g_96), 0x9BL)) != p_42) < p_42)))) , &g_218) != l_321)), 0x7D721A587B83316ELL)) & g_225)));
                        g_101[p_42] = l_323;
                    }
                    if (p_42)
                        break;
                }
            }
            l_136 = l_140;
        }
    }
    (*l_324) = (void*)0;
    g_331 = (g_328 = l_325);
    for (l_130 = 2; (l_130 < 1); --l_130)
    { /* block id: 106 */
        uint8_t **l_340[2];
        int32_t *l_342 = &l_131;
        int32_t *l_343[7] = {&g_68,&g_68,&g_68,&g_68,&g_68,&g_68,&g_68};
        int i;
        for (i = 0; i < 2; i++)
            l_340[i] = &l_339;
        (*g_204) = (safe_mod_func_uint64_t_u_u((((~l_337) & (&g_104 == l_338)) , (((g_341 = l_339) == l_339) < ((*l_342) = (*l_326)))), p_42));
        if (p_42)
            break;
    }
    return &g_68;
}


/* ------------------------------------------ */
/* 
 * reads : g_68 g_95 g_63 g_73 g_12 g_104
 * writes: g_96 g_68 g_101 g_104
 */
static int8_t  func_43(int64_t  p_44, uint8_t  p_45, int32_t * p_46, int32_t * p_47)
{ /* block id: 8 */
    int32_t *l_75 = &g_68;
    int32_t *l_76 = (void*)0;
    int32_t *l_77 = (void*)0;
    int32_t *l_78[1];
    uint64_t l_79 = 0x3EEFD7F9B64A4744LL;
    int8_t *l_90 = &g_73;
    int32_t l_97 = 0x01266394L;
    uint64_t *l_98 = &l_79;
    int16_t l_99 = 0x3C5CL;
    int32_t **l_100 = &l_75;
    int16_t *l_102 = (void*)0;
    int16_t *l_103 = &l_99;
    union U0 *l_105 = &g_106[5][0];
    union U0 **l_107 = &l_105;
    int i;
    for (i = 0; i < 1; i++)
        l_78[i] = &g_68;
    --l_79;
    (*p_47) = (safe_rshift_func_uint8_t_u_s((((safe_div_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_u((safe_div_func_int64_t_s_s(((((l_90 != (g_68 , (g_68 , l_90))) > ((safe_rshift_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u(253UL, (((*l_98) = ((g_96 = (g_95 , ((void*)0 == l_90))) < ((g_68 <= 0UL) >= l_97))) > l_99))) && p_44), g_63)) >= p_45)) > p_45) | g_73), g_12)), g_12)) > p_45), (*l_75))) , 0UL) , g_73), g_68));
    g_104 &= ((*p_47) &= (((*l_103) = (((*l_100) = l_78[0]) == (g_101[0] = &g_68))) | (g_95 , ((p_44 , p_45) , ((0xC17BCF7A535ACB96LL != 1UL) , (p_45 , p_45))))));
    (*l_107) = l_105;
    return p_44;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_95.f0, "g_95.f0", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_106[i][j].f0, "g_106[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_152[i].f0, "g_152[i].f0", print_hash_value);
        transparent_crc(g_152[i].f1, "g_152[i].f1", print_hash_value);
        transparent_crc(g_152[i].f2, "g_152[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_168.f0, "g_168.f0", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_203, "g_203", print_hash_value);
    transparent_crc(g_216, "g_216", print_hash_value);
    transparent_crc(g_218, "g_218", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_263.f0, "g_263.f0", print_hash_value);
    transparent_crc(g_269.f0, "g_269.f0", print_hash_value);
    transparent_crc(g_330, "g_330", print_hash_value);
    transparent_crc(g_375, "g_375", print_hash_value);
    transparent_crc(g_377, "g_377", print_hash_value);
    transparent_crc(g_379, "g_379", print_hash_value);
    transparent_crc(g_410.f0, "g_410.f0", print_hash_value);
    transparent_crc(g_410.f1, "g_410.f1", print_hash_value);
    transparent_crc(g_410.f2, "g_410.f2", print_hash_value);
    transparent_crc(g_421, "g_421", print_hash_value);
    transparent_crc(g_460.f0, "g_460.f0", print_hash_value);
    transparent_crc(g_475.f0, "g_475.f0", print_hash_value);
    transparent_crc(g_475.f1, "g_475.f1", print_hash_value);
    transparent_crc(g_475.f2, "g_475.f2", print_hash_value);
    transparent_crc(g_493, "g_493", print_hash_value);
    transparent_crc(g_504, "g_504", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_525[i][j][k].f0, "g_525[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_547[i].f0, "g_547[i].f0", print_hash_value);
        transparent_crc(g_547[i].f1, "g_547[i].f1", print_hash_value);
        transparent_crc(g_547[i].f2, "g_547[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_557.f0, "g_557.f0", print_hash_value);
    transparent_crc(g_581.f0, "g_581.f0", print_hash_value);
    transparent_crc(g_581.f1, "g_581.f1", print_hash_value);
    transparent_crc(g_581.f2, "g_581.f2", print_hash_value);
    transparent_crc(g_586.f0, "g_586.f0", print_hash_value);
    transparent_crc(g_586.f1, "g_586.f1", print_hash_value);
    transparent_crc(g_586.f2, "g_586.f2", print_hash_value);
    transparent_crc(g_610.f0, "g_610.f0", print_hash_value);
    transparent_crc(g_618.f0, "g_618.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_627[i][j][k].f0, "g_627[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_671.f0, "g_671.f0", print_hash_value);
    transparent_crc(g_671.f1, "g_671.f1", print_hash_value);
    transparent_crc(g_671.f2, "g_671.f2", print_hash_value);
    transparent_crc(g_688, "g_688", print_hash_value);
    transparent_crc(g_704.f0, "g_704.f0", print_hash_value);
    transparent_crc(g_754.f0, "g_754.f0", print_hash_value);
    transparent_crc(g_754.f1, "g_754.f1", print_hash_value);
    transparent_crc(g_754.f2, "g_754.f2", print_hash_value);
    transparent_crc(g_852, "g_852", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_855[i][j], "g_855[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_862.f0, "g_862.f0", print_hash_value);
    transparent_crc(g_862.f1, "g_862.f1", print_hash_value);
    transparent_crc(g_862.f2, "g_862.f2", print_hash_value);
    transparent_crc(g_929, "g_929", print_hash_value);
    transparent_crc(g_945.f0, "g_945.f0", print_hash_value);
    transparent_crc(g_945.f1, "g_945.f1", print_hash_value);
    transparent_crc(g_945.f2, "g_945.f2", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_950[i].f0, "g_950[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1058.f0, "g_1058.f0", print_hash_value);
    transparent_crc(g_1058.f1, "g_1058.f1", print_hash_value);
    transparent_crc(g_1058.f2, "g_1058.f2", print_hash_value);
    transparent_crc(g_1067.f0, "g_1067.f0", print_hash_value);
    transparent_crc(g_1099, "g_1099", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1149[i], "g_1149[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1153.f0, "g_1153.f0", print_hash_value);
    transparent_crc(g_1167.f0, "g_1167.f0", print_hash_value);
    transparent_crc(g_1184.f0, "g_1184.f0", print_hash_value);
    transparent_crc(g_1198.f0, "g_1198.f0", print_hash_value);
    transparent_crc(g_1198.f1, "g_1198.f1", print_hash_value);
    transparent_crc(g_1198.f2, "g_1198.f2", print_hash_value);
    transparent_crc(g_1236.f0, "g_1236.f0", print_hash_value);
    transparent_crc(g_1238.f0, "g_1238.f0", print_hash_value);
    transparent_crc(g_1242.f0, "g_1242.f0", print_hash_value);
    transparent_crc(g_1273.f0, "g_1273.f0", print_hash_value);
    transparent_crc(g_1273.f1, "g_1273.f1", print_hash_value);
    transparent_crc(g_1273.f2, "g_1273.f2", print_hash_value);
    transparent_crc(g_1303, "g_1303", print_hash_value);
    transparent_crc(g_1320.f0, "g_1320.f0", print_hash_value);
    transparent_crc(g_1325.f0, "g_1325.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1343[i][j], "g_1343[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1390.f0, "g_1390.f0", print_hash_value);
    transparent_crc(g_1407, "g_1407", print_hash_value);
    transparent_crc(g_1453, "g_1453", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1491[i][j].f0, "g_1491[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1528[i][j][k].f0, "g_1528[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1531[i].f0, "g_1531[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1568, "g_1568", print_hash_value);
    transparent_crc(g_1604, "g_1604", print_hash_value);
    transparent_crc(g_1669, "g_1669", print_hash_value);
    transparent_crc(g_1696, "g_1696", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1772[i], "g_1772[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1799, "g_1799", print_hash_value);
    transparent_crc(g_1839, "g_1839", print_hash_value);
    transparent_crc(g_1843.f0, "g_1843.f0", print_hash_value);
    transparent_crc(g_1851.f0, "g_1851.f0", print_hash_value);
    transparent_crc(g_1852.f0, "g_1852.f0", print_hash_value);
    transparent_crc(g_1852.f1, "g_1852.f1", print_hash_value);
    transparent_crc(g_1852.f2, "g_1852.f2", print_hash_value);
    transparent_crc(g_1875.f0, "g_1875.f0", print_hash_value);
    transparent_crc(g_1887, "g_1887", print_hash_value);
    transparent_crc(g_1906.f0, "g_1906.f0", print_hash_value);
    transparent_crc(g_1906.f1, "g_1906.f1", print_hash_value);
    transparent_crc(g_1906.f2, "g_1906.f2", print_hash_value);
    transparent_crc(g_1980.f0, "g_1980.f0", print_hash_value);
    transparent_crc(g_1980.f1, "g_1980.f1", print_hash_value);
    transparent_crc(g_1980.f2, "g_1980.f2", print_hash_value);
    transparent_crc(g_2034.f0, "g_2034.f0", print_hash_value);
    transparent_crc(g_2053, "g_2053", print_hash_value);
    transparent_crc(g_2177, "g_2177", print_hash_value);
    transparent_crc(g_2218, "g_2218", print_hash_value);
    transparent_crc(g_2295, "g_2295", print_hash_value);
    transparent_crc(g_2328.f0, "g_2328.f0", print_hash_value);
    transparent_crc(g_2352.f0, "g_2352.f0", print_hash_value);
    transparent_crc(g_2357.f0, "g_2357.f0", print_hash_value);
    transparent_crc(g_2357.f1, "g_2357.f1", print_hash_value);
    transparent_crc(g_2357.f2, "g_2357.f2", print_hash_value);
    transparent_crc(g_2379.f0, "g_2379.f0", print_hash_value);
    transparent_crc(g_2397, "g_2397", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2435[i], "g_2435[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_2459[i][j].f0, "g_2459[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2478, "g_2478", print_hash_value);
    transparent_crc(g_2504.f0, "g_2504.f0", print_hash_value);
    transparent_crc(g_2585, "g_2585", print_hash_value);
    transparent_crc(g_2600, "g_2600", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2607[i].f0, "g_2607[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2640, "g_2640", print_hash_value);
    transparent_crc(g_2659.f0, "g_2659.f0", print_hash_value);
    transparent_crc(g_2673, "g_2673", print_hash_value);
    transparent_crc(g_2704, "g_2704", print_hash_value);
    transparent_crc(g_2710.f0, "g_2710.f0", print_hash_value);
    transparent_crc(g_2710.f1, "g_2710.f1", print_hash_value);
    transparent_crc(g_2710.f2, "g_2710.f2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2726[i].f0, "g_2726[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_2768[i][j].f0, "g_2768[i][j].f0", print_hash_value);
            transparent_crc(g_2768[i][j].f1, "g_2768[i][j].f1", print_hash_value);
            transparent_crc(g_2768[i][j].f2, "g_2768[i][j].f2", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2789, "g_2789", print_hash_value);
    transparent_crc(g_2790.f0, "g_2790.f0", print_hash_value);
    transparent_crc(g_2790.f1, "g_2790.f1", print_hash_value);
    transparent_crc(g_2790.f2, "g_2790.f2", print_hash_value);
    transparent_crc(g_2807, "g_2807", print_hash_value);
    transparent_crc(g_2816.f0, "g_2816.f0", print_hash_value);
    transparent_crc(g_2816.f1, "g_2816.f1", print_hash_value);
    transparent_crc(g_2816.f2, "g_2816.f2", print_hash_value);
    transparent_crc(g_2841.f0, "g_2841.f0", print_hash_value);
    transparent_crc(g_2841.f1, "g_2841.f1", print_hash_value);
    transparent_crc(g_2841.f2, "g_2841.f2", print_hash_value);
    transparent_crc(g_2899.f0, "g_2899.f0", print_hash_value);
    transparent_crc(g_2900, "g_2900", print_hash_value);
    transparent_crc(g_2931.f0, "g_2931.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2941[i].f0, "g_2941[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 853
XXX total union variables: 59

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 51
breakdown:
   indirect level: 0, occurrence: 38
   indirect level: 1, occurrence: 10
   indirect level: 2, occurrence: 3
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 16
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 53
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 35

XXX max expression depth: 39
breakdown:
   depth: 1, occurrence: 238
   depth: 2, occurrence: 57
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 3
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 18, occurrence: 3
   depth: 19, occurrence: 2
   depth: 20, occurrence: 3
   depth: 21, occurrence: 6
   depth: 22, occurrence: 6
   depth: 23, occurrence: 2
   depth: 24, occurrence: 2
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 5
   depth: 31, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 3
   depth: 36, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 2

XXX total number of pointers: 550

XXX times a variable address is taken: 1541
XXX times a pointer is dereferenced on RHS: 160
breakdown:
   depth: 1, occurrence: 121
   depth: 2, occurrence: 24
   depth: 3, occurrence: 15
XXX times a pointer is dereferenced on LHS: 343
breakdown:
   depth: 1, occurrence: 317
   depth: 2, occurrence: 15
   depth: 3, occurrence: 11
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 12921

XXX max dereference level: 6
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2425
   level: 2, occurrence: 409
   level: 3, occurrence: 137
   level: 4, occurrence: 102
   level: 5, occurrence: 58
   level: 6, occurrence: 9
XXX number of pointers point to pointers: 225
XXX number of pointers point to scalars: 296
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.9
XXX average alias set size: 1.37

XXX times a non-volatile is read: 1876
XXX times a non-volatile is write: 1088
XXX times a volatile is read: 147
XXX    times read thru a pointer: 38
XXX times a volatile is write: 33
XXX    times written thru a pointer: 5
XXX times a volatile is available for access: 9.62e+03
XXX percentage of non-volatile access: 94.3

XXX forward jumps: 2
XXX backward jumps: 13

XXX stmts: 241
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 29
   depth: 2, occurrence: 24
   depth: 3, occurrence: 28
   depth: 4, occurrence: 51
   depth: 5, occurrence: 75

XXX percentage a fresh-made variable is used: 16.8
XXX percentage an existing variable is used: 83.2
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

