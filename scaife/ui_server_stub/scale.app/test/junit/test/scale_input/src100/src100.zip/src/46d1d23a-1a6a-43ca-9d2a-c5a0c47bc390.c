/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1693740899
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int32_t  f0;
   uint32_t  f1;
};

union U1 {
   uint64_t  f0;
   unsigned f1 : 30;
   const uint32_t  f2;
   const uint16_t  f3;
};

union U2 {
   int32_t  f0;
   int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_7 = (-1L);
static int32_t g_9[7] = {1L,1L,1L,1L,1L,1L,1L};
static int32_t g_11 = 8L;
static union U0 *g_39 = (void*)0;
static int16_t g_48 = 0xC6DAL;
static int8_t g_62 = 0x21L;
static const int16_t g_107 = 0x34A1L;
static int16_t g_110 = 0L;
static int16_t *g_109[6][2] = {{&g_110,&g_110},{&g_110,&g_110},{&g_110,&g_110},{&g_110,&g_110},{&g_110,&g_110},{&g_110,&g_110}};
static uint8_t g_115 = 4UL;
static uint16_t g_136 = 0xC886L;
static uint16_t g_138 = 5UL;
static int8_t g_139 = (-5L);
static uint8_t g_140 = 0xA2L;
static uint8_t g_153[3][7] = {{0UL,250UL,247UL,247UL,250UL,0UL,0UL},{0UL,250UL,247UL,247UL,250UL,0UL,0UL},{0UL,250UL,247UL,247UL,250UL,0UL,0UL}};
static union U0 ** volatile g_155 = (void*)0;/* VOLATILE GLOBAL g_155 */
static uint32_t g_161 = 0x85A69067L;
static int64_t *g_184[6][2][1] = {{{(void*)0},{(void*)0}},{{(void*)0},{(void*)0}},{{(void*)0},{(void*)0}},{{(void*)0},{(void*)0}},{{(void*)0},{(void*)0}},{{(void*)0},{(void*)0}}};
static int64_t **g_183 = &g_184[5][0][0];
static int64_t *** volatile g_182[10] = {&g_183,&g_183,&g_183,&g_183,&g_183,&g_183,&g_183,&g_183,&g_183,&g_183};
static int64_t g_186 = (-2L);
static int64_t g_187 = (-8L);
static volatile int32_t g_188 = 0xB8AA76C0L;/* VOLATILE GLOBAL g_188 */
static volatile uint16_t g_190 = 0x9CCFL;/* VOLATILE GLOBAL g_190 */
static const union U1 g_197 = {0x7FD118F9F8067CD4LL};
static const union U1 *g_196[5][7] = {{&g_197,&g_197,&g_197,&g_197,&g_197,&g_197,&g_197},{&g_197,&g_197,&g_197,(void*)0,&g_197,(void*)0,&g_197},{&g_197,&g_197,&g_197,&g_197,&g_197,&g_197,&g_197},{&g_197,(void*)0,&g_197,&g_197,&g_197,(void*)0,&g_197},{&g_197,&g_197,&g_197,&g_197,&g_197,&g_197,&g_197}};
static const union U1 ** volatile g_195 = &g_196[3][3];/* VOLATILE GLOBAL g_195 */
static uint64_t g_200 = 1UL;
static volatile int32_t *g_206 = &g_188;
static union U1 g_214 = {0UL};
static union U0 g_217[6][10][4] = {{{{2L},{0xB7ECD135L},{4L},{0xB7ECD135L}},{{0xDF134357L},{0xD63770DEL},{0x5FB00830L},{4L}},{{0xB7ECD135L},{0xD63770DEL},{0xD63770DEL},{0xB7ECD135L}},{{0xD63770DEL},{0xB7ECD135L},{0xDF134357L},{2L}},{{0xD63770DEL},{0xDF134357L},{0xD63770DEL},{0x5FB00830L}},{{0xB7ECD135L},{2L},{0x5FB00830L},{0x5FB00830L}},{{0xDF134357L},{0xDF134357L},{4L},{2L}},{{2L},{0xB7ECD135L},{4L},{0xB7ECD135L}},{{0xDF134357L},{0xD63770DEL},{0x5FB00830L},{4L}},{{0xB7ECD135L},{0xD63770DEL},{0xD63770DEL},{0xB7ECD135L}}},{{{0xD63770DEL},{0xB7ECD135L},{0xDF134357L},{2L}},{{0xD63770DEL},{0xDF134357L},{0xD63770DEL},{0x5FB00830L}},{{0xB7ECD135L},{2L},{0x5FB00830L},{0x5FB00830L}},{{0xDF134357L},{0xDF134357L},{4L},{2L}},{{2L},{0xB7ECD135L},{4L},{0xB7ECD135L}},{{0xDF134357L},{0xD63770DEL},{0x5FB00830L},{4L}},{{0xB7ECD135L},{0xD63770DEL},{0xD63770DEL},{0xB7ECD135L}},{{0xD63770DEL},{0xB7ECD135L},{0xDF134357L},{2L}},{{0xD63770DEL},{0xDF134357L},{0xD63770DEL},{0x5FB00830L}},{{0xB7ECD135L},{2L},{0x5FB00830L},{0x5FB00830L}}},{{{0xDF134357L},{0xDF134357L},{4L},{2L}},{{2L},{0xB7ECD135L},{4L},{0xB7ECD135L}},{{0xDF134357L},{0xD63770DEL},{0x5FB00830L},{4L}},{{0xB7ECD135L},{0xD63770DEL},{0xD63770DEL},{0xB7ECD135L}},{{0xD63770DEL},{0xB7ECD135L},{0xDF134357L},{2L}},{{0xD63770DEL},{0xDF134357L},{0xD63770DEL},{0x5FB00830L}},{{0xB7ECD135L},{2L},{0x5FB00830L},{0x5FB00830L}},{{0xDF134357L},{0xDF134357L},{4L},{2L}},{{2L},{0xB7ECD135L},{4L},{0xB7ECD135L}},{{0xDF134357L},{0xD63770DEL},{0x5FB00830L},{4L}}},{{{0xB7ECD135L},{0xD63770DEL},{0xD63770DEL},{0xB7ECD135L}},{{0xD63770DEL},{0xB7ECD135L},{0xDF134357L},{2L}},{{0xD63770DEL},{0xDF134357L},{0xD63770DEL},{0x5FB00830L}},{{0xB7ECD135L},{2L},{0x5FB00830L},{0x5FB00830L}},{{0xDF134357L},{0xDF134357L},{4L},{2L}},{{0x5FB00830L},{0xD63770DEL},{0xDF134357L},{0xD63770DEL}},{{-1L},{2L},{4L},{0xDF134357L}},{{0xD63770DEL},{2L},{2L},{0xD63770DEL}},{{2L},{0xD63770DEL},{-1L},{0x5FB00830L}},{{2L},{-1L},{2L},{4L}}},{{{0xD63770DEL},{0x5FB00830L},{4L},{4L}},{{-1L},{-1L},{0xDF134357L},{0x5FB00830L}},{{0x5FB00830L},{0xD63770DEL},{0xDF134357L},{0xD63770DEL}},{{-1L},{2L},{4L},{0xDF134357L}},{{0xD63770DEL},{2L},{2L},{0xD63770DEL}},{{2L},{0xD63770DEL},{-1L},{0x5FB00830L}},{{2L},{-1L},{2L},{4L}},{{0xD63770DEL},{0x5FB00830L},{4L},{4L}},{{-1L},{-1L},{0xDF134357L},{0x5FB00830L}},{{0x5FB00830L},{0xD63770DEL},{0xDF134357L},{0xD63770DEL}}},{{{-1L},{2L},{4L},{0xDF134357L}},{{0xD63770DEL},{2L},{2L},{0xD63770DEL}},{{2L},{0xD63770DEL},{-1L},{0x5FB00830L}},{{2L},{-1L},{2L},{4L}},{{0xD63770DEL},{0x5FB00830L},{4L},{4L}},{{-1L},{-1L},{0xDF134357L},{0x5FB00830L}},{{0x5FB00830L},{0xD63770DEL},{0xDF134357L},{0xD63770DEL}},{{-1L},{2L},{4L},{0xDF134357L}},{{0xD63770DEL},{2L},{2L},{0xD63770DEL}},{{2L},{0xD63770DEL},{-1L},{0x5FB00830L}}}};
static uint64_t g_227 = 1UL;
static const int32_t g_252 = 0xCEDE3C0EL;
static const int32_t g_255 = 0L;
static const int32_t g_257[5] = {0xA3B66FB3L,0xA3B66FB3L,0xA3B66FB3L,0xA3B66FB3L,0xA3B66FB3L};
static volatile union U2 g_263 = {0xA1156754L};/* VOLATILE GLOBAL g_263 */
static int32_t g_276 = 1L;
static union U2 g_316 = {8L};
static volatile uint16_t * volatile g_335 = &g_190;/* VOLATILE GLOBAL g_335 */
static volatile uint16_t * volatile *g_334 = &g_335;
static int32_t g_337[9] = {0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL,0x49B69DBAL};
static int32_t g_339 = (-8L);
static uint32_t g_385 = 4UL;
static int32_t *g_389 = &g_217[4][5][3].f0;
static int32_t ** volatile g_388 = &g_389;/* VOLATILE GLOBAL g_388 */
static int32_t ** volatile g_420 = &g_389;/* VOLATILE GLOBAL g_420 */
static int32_t ** volatile g_437 = (void*)0;/* VOLATILE GLOBAL g_437 */
static int32_t ** volatile g_438 = &g_389;/* VOLATILE GLOBAL g_438 */
static int32_t ** volatile g_463 = (void*)0;/* VOLATILE GLOBAL g_463 */
static int32_t ** volatile g_464[1][3] = {{(void*)0,(void*)0,(void*)0}};
static int32_t ** volatile g_472 = (void*)0;/* VOLATILE GLOBAL g_472 */
static uint32_t g_498 = 0x4F3D4FC2L;
static union U2 *g_578 = &g_316;
static uint8_t g_588 = 0x42L;
static volatile int64_t g_634 = 1L;/* VOLATILE GLOBAL g_634 */
static int32_t ** volatile g_670 = &g_389;/* VOLATILE GLOBAL g_670 */
static int8_t g_762 = 1L;
static volatile uint16_t g_793 = 0xCA41L;/* VOLATILE GLOBAL g_793 */
static uint8_t g_841 = 8UL;
static const int8_t g_860[8][5][2] = {{{0xE5L,(-1L)},{0x9AL,0x01L},{0x9AL,(-1L)},{0xE5L,0xF4L},{(-1L),0x99L}},{{0xF3L,(-1L)},{0xF4L,0xE5L},{0xE5L,0xE5L},{0xF4L,(-1L)},{0xF3L,0x99L}},{{(-1L),0xF4L},{0xE5L,(-1L)},{0x9AL,0x01L},{0x9AL,(-1L)},{0xE5L,0xF4L}},{{(-1L),0x99L},{0xF3L,(-1L)},{0xF4L,0xE5L},{0xE5L,0xE5L},{0xF4L,(-1L)}},{{0xF3L,0x99L},{(-1L),0xF4L},{0xE5L,(-1L)},{0x9AL,0x01L},{0x9AL,(-1L)}},{{0xE5L,0xF4L},{(-1L),0x99L},{0xF3L,(-1L)},{0xF4L,0xE5L},{0xE5L,0xE5L}},{{0xF4L,(-1L)},{0xF3L,0x99L},{(-1L),0xF4L},{0xE5L,(-1L)},{0x9AL,0x01L}},{{0x9AL,(-1L)},{0xE5L,0xE5L},{0x01L,0xE5L},{0x9AL,0xF4L},{0xE5L,0xEAL}}};
static const int8_t *g_859 = &g_860[3][1][0];
static volatile int16_t g_871 = 0L;/* VOLATILE GLOBAL g_871 */
static volatile int16_t * const g_870 = &g_871;
static volatile int16_t * const  volatile * volatile g_869 = &g_870;/* VOLATILE GLOBAL g_869 */
static volatile int16_t * const  volatile * volatile * volatile g_868 = &g_869;/* VOLATILE GLOBAL g_868 */
static int16_t **g_873 = (void*)0;
static int16_t ***g_872 = &g_873;
static int32_t *g_875[5] = {&g_11,&g_11,&g_11,&g_11,&g_11};
static uint16_t *g_884 = (void*)0;
static uint16_t **g_883[5][2][9] = {{{(void*)0,&g_884,&g_884,&g_884,(void*)0,&g_884,(void*)0,&g_884,(void*)0},{&g_884,(void*)0,(void*)0,&g_884,(void*)0,&g_884,(void*)0,&g_884,(void*)0}},{{&g_884,&g_884,(void*)0,&g_884,&g_884,&g_884,(void*)0,&g_884,&g_884},{(void*)0,&g_884,(void*)0,&g_884,(void*)0,&g_884,(void*)0,(void*)0,&g_884}},{{(void*)0,&g_884,(void*)0,&g_884,(void*)0,&g_884,&g_884,&g_884,(void*)0},{(void*)0,(void*)0,(void*)0,&g_884,&g_884,&g_884,&g_884,(void*)0,(void*)0}},{{&g_884,&g_884,&g_884,&g_884,(void*)0,&g_884,&g_884,&g_884,&g_884},{&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884}},{{(void*)0,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884,&g_884},{(void*)0,(void*)0,&g_884,&g_884,&g_884,&g_884,&g_884,(void*)0,(void*)0}}};
static volatile int16_t g_1007 = (-7L);/* VOLATILE GLOBAL g_1007 */
static const union U1 ** volatile g_1027[4][7][7] = {{{&g_196[3][4],&g_196[3][5],&g_196[3][3],&g_196[3][4],&g_196[3][3],&g_196[3][1],&g_196[2][1]},{&g_196[1][4],&g_196[3][3],&g_196[3][3],&g_196[3][5],&g_196[3][4],&g_196[3][3],&g_196[3][3]},{&g_196[0][2],&g_196[3][3],&g_196[4][6],&g_196[0][6],(void*)0,&g_196[0][6],&g_196[3][3]},{&g_196[4][2],(void*)0,&g_196[3][3],(void*)0,(void*)0,&g_196[3][3],(void*)0},{&g_196[3][3],&g_196[0][6],&g_196[3][3],(void*)0,&g_196[3][3],&g_196[3][3],&g_196[3][3]},{&g_196[0][0],&g_196[0][4],&g_196[3][3],&g_196[0][6],&g_196[4][6],&g_196[3][4],&g_196[2][3]},{(void*)0,&g_196[3][3],&g_196[2][3],&g_196[3][5],&g_196[3][3],&g_196[4][2],&g_196[4][6]}},{{&g_196[3][5],&g_196[0][6],&g_196[3][3],&g_196[3][4],&g_196[3][3],(void*)0,&g_196[4][2]},{&g_196[3][3],&g_196[1][0],&g_196[3][3],&g_196[3][3],&g_196[1][0],&g_196[3][3],&g_196[1][4]},{&g_196[4][2],&g_196[3][6],&g_196[3][3],&g_196[1][4],&g_196[3][3],(void*)0,(void*)0},{&g_196[4][6],&g_196[0][4],&g_196[0][6],(void*)0,&g_196[0][1],&g_196[0][4],&g_196[1][4]},{&g_196[0][1],&g_196[3][6],&g_196[0][4],&g_196[1][4],&g_196[3][3],&g_196[3][3],&g_196[3][3]},{&g_196[3][4],&g_196[1][0],(void*)0,&g_196[4][2],(void*)0,&g_196[3][3],(void*)0},{&g_196[0][1],&g_196[3][5],&g_196[2][3],&g_196[3][3],(void*)0,&g_196[3][3],(void*)0}},{{&g_196[3][3],&g_196[3][5],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][5]},{&g_196[3][3],&g_196[2][3],&g_196[1][4],&g_196[0][2],&g_196[0][6],&g_196[4][2],&g_196[3][3]},{&g_196[2][3],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3]},{&g_196[3][3],(void*)0,&g_196[4][2],&g_196[3][1],&g_196[3][3],(void*)0,&g_196[3][5]},{&g_196[3][3],&g_196[3][3],(void*)0,&g_196[4][6],&g_196[3][3],&g_196[3][3],(void*)0},{&g_196[3][3],&g_196[3][3],(void*)0,&g_196[3][3],&g_196[3][3],&g_196[3][3],(void*)0},{(void*)0,(void*)0,&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3]}},{{&g_196[0][1],&g_196[0][1],&g_196[3][3],&g_196[0][2],&g_196[3][4],(void*)0,&g_196[0][0]},{&g_196[3][3],&g_196[3][3],&g_196[1][3],&g_196[0][4],&g_196[3][3],&g_196[3][3],(void*)0},{&g_196[3][3],&g_196[0][4],&g_196[0][6],&g_196[3][3],&g_196[3][4],&g_196[3][3],(void*)0},{&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[1][4],&g_196[3][3],(void*)0,&g_196[1][4]},{&g_196[2][3],&g_196[2][1],&g_196[3][3],&g_196[0][1],&g_196[3][3],&g_196[4][2],&g_196[3][3]},{&g_196[3][3],&g_196[0][4],(void*)0,&g_196[3][3],&g_196[3][3],&g_196[3][3],&g_196[3][3]},{&g_196[3][3],&g_196[3][3],(void*)0,&g_196[0][0],&g_196[3][3],&g_196[2][3],&g_196[0][2]}}};
static const union U1 ** volatile g_1028 = &g_196[3][3];/* VOLATILE GLOBAL g_1028 */
static volatile int8_t g_1062[10] = {0x04L,0x04L,0x04L,0x04L,0x04L,0x04L,0x04L,0x04L,0x04L,0x04L};
static uint8_t *g_1083 = (void*)0;
static uint8_t **g_1082 = &g_1083;
static volatile uint64_t * volatile g_1187 = (void*)0;/* VOLATILE GLOBAL g_1187 */
static volatile uint64_t * volatile *g_1186[5] = {&g_1187,&g_1187,&g_1187,&g_1187,&g_1187};
static union U2 ** volatile g_1210 = &g_578;/* VOLATILE GLOBAL g_1210 */
static union U1 *g_1221 = &g_214;
static union U1 **g_1220 = &g_1221;
static union U1 ***g_1219 = &g_1220;
static const uint64_t *g_1260 = &g_197.f0;
static const uint64_t **g_1259[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static const uint64_t ***g_1258 = &g_1259[0];
static int32_t ** volatile g_1277 = &g_875[3];/* VOLATILE GLOBAL g_1277 */
static uint16_t g_1313 = 0xF2C9L;
static const union U0 *g_1324[9][7][4] = {{{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3]},{(void*)0,&g_217[5][5][2],&g_217[5][4][0],(void*)0},{(void*)0,&g_217[2][3][3],&g_217[4][5][3],&g_217[5][4][0]},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],&g_217[4][5][3]},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3]},{(void*)0,(void*)0,&g_217[5][4][0],&g_217[4][5][3]}},{{&g_217[4][5][3],&g_217[4][5][3],(void*)0,&g_217[5][4][0]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3]},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3],&g_217[4][5][3]},{&g_217[5][4][0],(void*)0,&g_217[5][4][0],&g_217[4][5][3]},{(void*)0,(void*)0,&g_217[2][3][3],&g_217[5][4][0]},{&g_217[4][5][3],&g_217[2][3][3],&g_217[4][2][2],(void*)0}},{{&g_217[4][5][3],&g_217[5][5][2],&g_217[4][2][2],&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[2][3][3],&g_217[4][5][3]},{(void*)0,&g_217[4][5][3],&g_217[4][2][2],&g_217[5][4][0]},{&g_217[4][2][2],&g_217[5][4][0],&g_217[5][4][0],&g_217[4][2][2]},{&g_217[4][5][3],(void*)0,&g_217[5][5][2],&g_217[4][5][3]},{(void*)0,&g_217[4][5][3],(void*)0,&g_217[4][5][3]},{&g_217[2][3][3],&g_217[4][5][3],(void*)0,&g_217[4][5][3]}},{{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],&g_217[4][5][3]},{&g_217[4][5][3],(void*)0,(void*)0,&g_217[4][2][2]},{&g_217[4][5][3],&g_217[5][4][0],(void*)0,&g_217[5][4][0]},{(void*)0,&g_217[4][5][3],&g_217[4][5][3],&g_217[5][5][2]},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,(void*)0},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,&g_217[4][2][2]}},{{&g_217[4][5][3],(void*)0,&g_217[4][5][3],(void*)0},{(void*)0,&g_217[4][5][3],(void*)0,(void*)0},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],(void*)0,(void*)0,&g_217[4][2][2]},{&g_217[2][3][3],(void*)0,(void*)0,(void*)0},{(void*)0,&g_217[4][5][3],&g_217[5][5][2],&g_217[4][5][3]}},{{&g_217[4][5][3],&g_217[4][5][3],&g_217[5][4][0],(void*)0},{&g_217[4][2][2],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],&g_217[4][2][2]},{(void*)0,&g_217[4][5][3],&g_217[4][5][3],(void*)0},{(void*)0,&g_217[4][5][3],&g_217[4][5][3],(void*)0},{(void*)0,&g_217[4][5][3],&g_217[4][5][3],&g_217[5][5][2]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],&g_217[5][4][0]}},{{&g_217[4][2][2],&g_217[5][4][0],&g_217[5][4][0],&g_217[4][2][2]},{&g_217[4][5][3],(void*)0,&g_217[5][5][2],&g_217[4][5][3]},{(void*)0,&g_217[4][5][3],(void*)0,&g_217[4][5][3]},{&g_217[2][3][3],&g_217[4][5][3],(void*)0,&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],&g_217[4][5][3]},{&g_217[4][5][3],(void*)0,(void*)0,&g_217[4][2][2]},{&g_217[4][5][3],&g_217[5][4][0],(void*)0,&g_217[5][4][0]}},{{(void*)0,&g_217[4][5][3],&g_217[4][5][3],&g_217[5][5][2]},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,(void*)0},{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,&g_217[4][2][2]},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],(void*)0},{(void*)0,&g_217[4][5][3],(void*)0,(void*)0},{&g_217[4][5][3],&g_217[4][5][3],(void*)0,&g_217[4][5][3]}},{{&g_217[4][5][3],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],(void*)0,(void*)0,&g_217[4][2][2]},{&g_217[2][3][3],(void*)0,(void*)0,(void*)0},{(void*)0,&g_217[4][5][3],&g_217[5][5][2],&g_217[4][5][3]},{&g_217[4][5][3],&g_217[4][5][3],&g_217[5][4][0],(void*)0},{&g_217[4][2][2],&g_217[4][5][3],&g_217[4][2][2],(void*)0},{&g_217[4][5][3],(void*)0,&g_217[4][5][3],&g_217[4][2][2]}}};
static const union U0 **g_1323 = &g_1324[4][5][2];
static const union U0 ***g_1322 = &g_1323;
static uint32_t **g_1378 = (void*)0;
static uint32_t *** volatile g_1377 = &g_1378;/* VOLATILE GLOBAL g_1377 */
static volatile int32_t *g_1641[4][5] = {{&g_263.f0,&g_263.f0,&g_188,&g_263.f0,&g_263.f0},{(void*)0,&g_263.f0,&g_188,&g_263.f0,(void*)0},{&g_263.f0,(void*)0,&g_263.f0,(void*)0,&g_263.f0},{(void*)0,&g_263.f0,&g_188,&g_263.f0,(void*)0}};
static volatile int32_t ** volatile g_1642 = &g_1641[0][3];/* VOLATILE GLOBAL g_1642 */
static int32_t ** volatile g_1648[1][9][5] = {{{&g_875[3],&g_875[3],&g_875[3],&g_875[3],&g_875[3]},{&g_875[3],&g_875[3],(void*)0,&g_875[3],&g_875[3]},{&g_875[3],&g_875[3],&g_875[3],&g_875[3],&g_875[3]},{&g_875[3],&g_875[0],&g_875[0],&g_875[3],&g_875[0]},{&g_875[3],&g_875[3],&g_389,&g_875[3],&g_875[3]},{&g_875[0],&g_875[3],&g_875[0],&g_875[0],&g_875[3]},{&g_875[3],&g_875[3],&g_875[3],&g_875[3],&g_875[3]},{&g_875[3],&g_875[3],(void*)0,&g_875[3],&g_875[3]},{&g_875[3],&g_875[3],&g_875[3],&g_875[3],&g_875[3]}}};
static const volatile int8_t *g_1674[6][4][1] = {{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}},{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}},{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}},{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}},{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}},{{&g_1062[4]},{&g_263.f1},{&g_1062[4]},{&g_263.f1}}};
static const volatile int8_t ** volatile g_1673 = &g_1674[0][3][0];/* VOLATILE GLOBAL g_1673 */
static const volatile int8_t ** volatile * const g_1672 = &g_1673;
static int8_t g_1708 = 1L;
static const uint32_t g_1731 = 18446744073709551614UL;
static union U2 ** volatile g_1746 = &g_578;/* VOLATILE GLOBAL g_1746 */
static int8_t *g_1841 = &g_7;
static int8_t **g_1840 = &g_1841;
static int8_t ***g_1839 = &g_1840;
static uint64_t *g_1896[3][10] = {{&g_200,&g_200,&g_214.f0,(void*)0,&g_214.f0,&g_214.f0,&g_214.f0,(void*)0,&g_214.f0,&g_200},{&g_227,(void*)0,&g_214.f0,&g_200,&g_214.f0,&g_214.f0,&g_214.f0,&g_214.f0,&g_200,&g_214.f0},{&g_214.f0,&g_214.f0,&g_200,&g_227,(void*)0,&g_214.f0,&g_214.f0,&g_214.f0,(void*)0,&g_227}};
static uint64_t **g_1895 = &g_1896[0][8];
static uint64_t ***g_1894 = &g_1895;
static uint64_t ****g_1893 = &g_1894;
static int8_t ****g_2017 = (void*)0;
static uint8_t * volatile * volatile g_2038 = &g_1083;/* VOLATILE GLOBAL g_2038 */
static uint8_t * volatile * volatile *g_2037 = &g_2038;
static uint8_t * volatile * volatile ** volatile g_2036 = &g_2037;/* VOLATILE GLOBAL g_2036 */
static const uint8_t g_2091[2][10][3] = {{{0x03L,0x03L,251UL},{0x54L,249UL,0x68L},{0xC1L,2UL,247UL},{0xD4L,0x40L,3UL},{249UL,0xC1L,247UL},{0x78L,0UL,0x68L},{7UL,0x78L,251UL},{255UL,0xD4L,0xD4L},{255UL,251UL,0x78L},{7UL,0x68L,0UL}},{{0x78L,247UL,0xC1L},{249UL,3UL,0x40L},{0xD4L,247UL,2UL},{0xC1L,0x68L,249UL},{0x54L,251UL,0x03L},{0x03L,0xD4L,0x03L},{246UL,0x78L,249UL},{0xFDL,0UL,2UL},{1UL,0xC1L,0x40L},{0UL,0x40L,0xC1L}}};
static uint32_t g_2112 = 0x376772AFL;
static int32_t ** volatile g_2132 = (void*)0;/* VOLATILE GLOBAL g_2132 */
static uint8_t g_2138 = 0x56L;
static union U0 *** volatile g_2203 = (void*)0;/* VOLATILE GLOBAL g_2203 */
static union U0 *** volatile * volatile g_2202 = &g_2203;/* VOLATILE GLOBAL g_2202 */
static union U0 *** volatile * volatile * volatile g_2201[10][3] = {{&g_2202,&g_2202,&g_2202},{(void*)0,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{(void*)0,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202},{&g_2202,&g_2202,&g_2202}};
static volatile int8_t g_2328 = 0x80L;/* VOLATILE GLOBAL g_2328 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int64_t  func_4(int8_t  p_5, uint16_t  p_6);
static uint8_t  func_15(union U0  p_16);
static int32_t * func_19(int32_t * const  p_20);
static int32_t * func_21(int32_t ** p_22, int32_t * p_23, int32_t * p_24, int32_t ** p_25);
static int32_t ** func_26(int32_t * p_27);
static int32_t * func_28(union U0 * const  p_29);
static union U0 * func_30(int32_t ** p_31);
static int32_t ** func_32(int64_t  p_33, union U0  p_34);
static union U0  func_35(uint64_t  p_36, union U0 * p_37);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_9 g_39 g_48 g_62 g_388 g_334 g_335 g_190 g_139 g_337 g_161 g_206 g_188 g_389 g_420 g_197.f3 g_438 g_214.f3 g_276 g_214.f0 g_257 g_138 g_227 g_197.f1 g_1277 g_875 g_1219 g_1220 g_187 g_1377 g_1378 g_1641 g_1642 g_841 g_1313 g_1672 g_1260 g_197.f0 g_1746 g_859 g_860 g_110 g_1258 g_1259 g_1839 g_1840 g_1841 g_1893 g_1673 g_1674 g_11 g_1322 g_1323 g_140 g_2036 g_868 g_869 g_870 g_871 g_2091 g_339 g_1731 g_2112 g_498 g_670 g_1894 g_1895 g_1896 g_2037 g_2038 g_2201 g_186 g_136 g_1028 g_196 g_316.f1 g_2328
 * writes: g_9 g_48 g_62 g_389 g_139 g_161 g_188 g_214.f0 g_227 g_110 g_1313 g_1221 g_187 g_153 g_186 g_276 g_1641 g_841 g_578 g_138 g_762 g_1839 g_316.f1 g_875 g_1893 g_11 g_140 g_2017 g_883 g_588 g_2112 g_115 g_2138 g_498 g_337 g_200 g_7 g_1894 g_136 g_196 g_339
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_10 = &g_11;
    int32_t **l_12 = &l_10;
    union U0 l_17 = {0xBF68593FL};
    union U0 *l_18 = &l_17;
    int8_t l_2135 = 0x40L;
    uint8_t *l_2136 = &g_115;
    uint8_t *l_2137 = &g_2138;
    union U0 l_2139 = {0x65190E70L};
    int8_t ***l_2162 = &g_1840;
    union U1 l_2175 = {0xA0A5ABD8B400A94ALL};
    uint8_t l_2240 = 253UL;
    int16_t l_2269 = (-1L);
    int8_t l_2281 = 0xDEL;
    uint64_t ***l_2285 = &g_1895;
    const uint32_t l_2287 = 0x18FB1613L;
    if ((safe_mod_func_uint16_t_u_u((func_4(g_7, g_7) == (((((*l_12) = l_10) == (void*)0) && (safe_rshift_func_uint8_t_u_u(func_15(((*l_18) = l_17)), ((*l_2137) = ((*l_2136) = l_2135))))) > (l_2139 , l_2135))), 0x6C1FL)))
    { /* block id: 985 */
        int64_t l_2153 = 0x4B8DB84F2A5F7610LL;
        int8_t l_2157 = 0x34L;
        union U0 * const l_2158 = &g_217[2][3][1];
        uint64_t *l_2178 = &g_200;
        const union U1 l_2180[8] = {{0UL},{1UL},{1UL},{0UL},{1UL},{1UL},{0UL},{1UL}};
        int32_t l_2187 = 0x7C77F8F1L;
        uint64_t l_2194 = 0x7D0607FCC5ADFD7DLL;
        int64_t l_2198 = (-8L);
        int32_t l_2216 = 0xC2F8AEFCL;
        union U2 l_2225[1][7][5] = {{{{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L}},{{-1L},{-1L},{-1L},{-1L},{-1L}},{{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L}},{{-1L},{-1L},{-1L},{-1L},{-1L}},{{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L}},{{-1L},{-1L},{-1L},{-1L},{-1L}},{{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L},{0xE7345276L}}}};
        int32_t l_2247 = 0x42B03CFDL;
        int32_t *l_2271 = &g_11;
        int8_t l_2282 = 7L;
        int i, j, k;
        for (g_498 = 0; (g_498 != 48); g_498++)
        { /* block id: 988 */
            uint16_t l_2152 = 1UL;
            int32_t l_2154 = 0x0CBB2B50L;
            uint32_t l_2186[7];
            union U0 * const **l_2206[9];
            union U0 * const ***l_2205 = &l_2206[3];
            union U0 * const ****l_2204 = &l_2205;
            const uint64_t l_2215[10][6][4] = {{{0xD03F4879D23C0D81LL,0UL,18446744073709551606UL,0x01AFE7F203773B88LL},{1UL,0x38D1F01A44A4B080LL,0x6DDD18BA939D3E18LL,0xAB6EC9F72A92D6E2LL},{0x1D9C95290A3C8533LL,0x6DDD18BA939D3E18LL,0x6A46068BCC3F3949LL,0x6DDD18BA939D3E18LL},{0x01AFE7F203773B88LL,18446744073709551612UL,0xB573957DEBA7D998LL,9UL},{0xD47F7B9D4476A29BLL,0xB56E77CEEA620BF2LL,18446744073709551611UL,0x6A46068BCC3F3949LL},{18446744073709551606UL,0UL,0xD03F4879D23C0D81LL,0x04929BF38967EEF1LL}},{{18446744073709551606UL,0UL,18446744073709551611UL,18446744073709551615UL},{0xD47F7B9D4476A29BLL,0x04929BF38967EEF1LL,0xB573957DEBA7D998LL,0x3206E7069F1B75C7LL},{0x01AFE7F203773B88LL,0x02F4191A83F4B73FLL,0x6A46068BCC3F3949LL,18446744073709551613UL},{0x1D9C95290A3C8533LL,8UL,0x6DDD18BA939D3E18LL,4UL},{1UL,0x21178EC09F5A178ELL,18446744073709551606UL,0x04929BF38967EEF1LL},{0xD03F4879D23C0D81LL,0UL,0x04929BF38967EEF1LL,0x7FC2B63E0678FFEALL}},{{0xBADD14F1A5E73E8ALL,0x38D1F01A44A4B080LL,0UL,0UL},{18446744073709551607UL,18446744073709551612UL,0x6A46068BCC3F3949LL,0UL},{0xDA61322146068D38LL,0xD47F7B9D4476A29BLL,18446744073709551607UL,9UL},{1UL,1UL,1UL,0x01AFE7F203773B88LL},{18446744073709551606UL,0UL,0UL,18446744073709551606UL},{8UL,0UL,0xF07FCD342D46C6D6LL,2UL}},{{0x6DDD18BA939D3E18LL,0xE1FAAB5558DF00F4LL,0xB573957DEBA7D998LL,18446744073709551613UL},{0xDA61322146068D38LL,0x9A1DBC6D311E0355LL,0x01AFE7F203773B88LL,18446744073709551613UL},{1UL,0xE1FAAB5558DF00F4LL,1UL,2UL},{1UL,0UL,0x04929BF38967EEF1LL,18446744073709551606UL},{0x406929365FE2B2CALL,0UL,18446744073709551608UL,0x01AFE7F203773B88LL},{18446744073709551611UL,1UL,0UL,9UL}},{{0x1D9C95290A3C8533LL,0xD47F7B9D4476A29BLL,0x01AFE7F203773B88LL,0UL},{0x7FC2B63E0678FFEALL,18446744073709551612UL,1UL,0UL},{1UL,0x38D1F01A44A4B080LL,18446744073709551611UL,0x7FC2B63E0678FFEALL},{8UL,0UL,1UL,0x04929BF38967EEF1LL},{0x04929BF38967EEF1LL,0x21178EC09F5A178ELL,0xF07FCD342D46C6D6LL,4UL},{0xD47F7B9D4476A29BLL,8UL,18446744073709551607UL,18446744073709551613UL}},{{0x7FC2B63E0678FFEALL,0x02F4191A83F4B73FLL,0x7FC2B63E0678FFEALL,0x3206E7069F1B75C7LL},{1UL,0x04929BF38967EEF1LL,0x6DDD18BA939D3E18LL,18446744073709551615UL},{0xBADD14F1A5E73E8ALL,0UL,18446744073709551608UL,0x04929BF38967EEF1LL},{0UL,0UL,0UL,0x21178EC09F5A178ELL},{0x01AFE7F203773B88LL,18446744073709551607UL,4UL,0xE1FAAB5558DF00F4LL},{0xF07FCD342D46C6D6LL,0x9A1DBC6D311E0355LL,9UL,4UL}},{{9UL,4UL,1UL,18446744073709551608UL},{0x7F5B760065729E08LL,1UL,0x1C5965C8278260FELL,0xAB6EC9F72A92D6E2LL},{0xD03F4879D23C0D81LL,0UL,0x91B588C21DECECB7LL,0UL},{0UL,0x04929BF38967EEF1LL,0x7FC2B63E0678FFEALL,1UL},{18446744073709551609UL,0x406929365FE2B2CALL,0xF07FCD342D46C6D6LL,1UL},{9UL,18446744073709551615UL,0xAB6EC9F72A92D6E2LL,0UL}},{{18446744073709551611UL,0xD03F4879D23C0D81LL,0x02F4191A83F4B73FLL,18446744073709551607UL},{0x7FC2B63E0678FFEALL,8UL,0UL,0UL},{0x3206E7069F1B75C7LL,0x3206E7069F1B75C7LL,0xD03F4879D23C0D81LL,0x21178EC09F5A178ELL},{0x6A46068BCC3F3949LL,0x1D9C95290A3C8533LL,18446744073709551609UL,18446744073709551606UL},{0xF07FCD342D46C6D6LL,4UL,0xAB6EC9F72A92D6E2LL,18446744073709551609UL},{0UL,4UL,0xD20A703117913F10LL,18446744073709551606UL}},{{4UL,0x1D9C95290A3C8533LL,0x1C5965C8278260FELL,0x21178EC09F5A178ELL},{0UL,0x3206E7069F1B75C7LL,0UL,0UL},{1UL,8UL,0x6A46068BCC3F3949LL,18446744073709551607UL},{18446744073709551609UL,0xD03F4879D23C0D81LL,1UL,0UL},{0UL,18446744073709551615UL,0x21178EC09F5A178ELL,1UL},{1UL,0x406929365FE2B2CALL,0x02F4191A83F4B73FLL,1UL}},{{0x01AFE7F203773B88LL,0x04929BF38967EEF1LL,0xD03F4879D23C0D81LL,0UL},{18446744073709551613UL,0UL,1UL,0xAB6EC9F72A92D6E2LL},{0x6A46068BCC3F3949LL,1UL,4UL,18446744073709551608UL},{18446744073709551611UL,4UL,0x21178EC09F5A178ELL,4UL},{0xAB6EC9F72A92D6E2LL,0x9A1DBC6D311E0355LL,0xD20A703117913F10LL,0xE1FAAB5558DF00F4LL},{0x7F5B760065729E08LL,18446744073709551607UL,0x7FC2B63E0678FFEALL,0x21178EC09F5A178ELL}}};
            const uint8_t l_2241[8][3][8] = {{{0x38L,0x51L,0x4EL,0UL,9UL,0xC4L,8UL,8UL},{0x4EL,0x38L,4UL,4UL,0x38L,0x4EL,8UL,0x01L},{246UL,4UL,0x4EL,0xC4L,0UL,0x99L,0UL,0xC4L}},{{0UL,0x99L,0UL,0xC4L,0x4EL,4UL,246UL,0x01L},{8UL,0x4EL,0x38L,4UL,4UL,0x38L,0x4EL,8UL},{8UL,0xC4L,9UL,0UL,0x4EL,0x51L,0x38L,0x51L}},{{0UL,0UL,0x01L,0UL,0UL,0x51L,0x99L,0x4EL},{246UL,0xC4L,0UL,8UL,0x38L,0x38L,8UL,0UL},{0x4EL,0x4EL,0UL,8UL,9UL,4UL,0x99L,246UL}},{{0x38L,0x99L,0x01L,0x4EL,0x01L,0x99L,0x38L,246UL},{0x99L,4UL,9UL,8UL,0x99L,0UL,0UL,0x99L},{0x4EL,8UL,8UL,0x4EL,0x99L,0x51L,0UL,0UL}},{{8UL,9UL,4UL,0x99L,246UL,0x99L,4UL,9UL},{8UL,9UL,0UL,4UL,0x01L,0x51L,0xC4L,0xC4L},{0UL,8UL,0x38L,0x38L,8UL,0UL,0xC4L,246UL}},{{0UL,0x38L,0UL,0x51L,4UL,8UL,4UL,0x51L},{4UL,8UL,4UL,0x51L,0UL,0x38L,0UL,246UL},{0xC4L,0UL,8UL,0x38L,0x38L,8UL,0UL,0xC4L}},{{0xC4L,0x51L,0x01L,4UL,0UL,9UL,8UL,9UL},{4UL,0x99L,246UL,0x99L,4UL,9UL,8UL,0UL},{0UL,0x51L,0x99L,0x4EL,8UL,8UL,0x4EL,0x99L}},{{0UL,0UL,0x99L,0xC4L,0x01L,0x38L,8UL,0UL},{8UL,8UL,246UL,0UL,246UL,8UL,8UL,0UL},{8UL,0x38L,0x01L,0xC4L,0x99L,0UL,0UL,0x99L}}};
            int32_t l_2270[1];
            int32_t l_2283 = 0xFDF325F3L;
            int32_t *l_2284 = &l_2139.f0;
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_2186[i] = 4294967293UL;
            for (i = 0; i < 9; i++)
                l_2206[i] = (void*)0;
            for (i = 0; i < 1; i++)
                l_2270[i] = 1L;
            for (g_161 = 1; (g_161 <= 8); g_161 += 1)
            { /* block id: 991 */
                uint16_t l_2148 = 65530UL;
                int64_t **l_2149 = &g_184[1][1][0];
                int16_t *l_2155 = (void*)0;
                int16_t *l_2156[10][1][7] = {{{&g_48,(void*)0,&g_110,&g_110,&g_110,&g_110,&g_110}},{{(void*)0,&g_110,(void*)0,&g_110,(void*)0,&g_48,(void*)0}},{{&g_110,(void*)0,&g_48,&g_48,&g_48,(void*)0,&g_110}},{{&g_110,&g_48,(void*)0,(void*)0,&g_48,&g_48,&g_48}},{{(void*)0,&g_48,&g_48,(void*)0,&g_48,&g_110,&g_48}},{{&g_110,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_48,&g_110,&g_48,&g_48,&g_48,&g_48,&g_48}},{{&g_48,&g_110,(void*)0,&g_110,&g_48,&g_48,&g_48}},{{&g_110,&g_110,&g_110,&g_48,&g_110,&g_48,&g_110}},{{&g_48,&g_48,&g_110,(void*)0,(void*)0,&g_110,(void*)0}}};
                int32_t l_2183 = 0x0C0818C2L;
                int16_t l_2184 = 1L;
                int32_t l_2191 = 0x9371184BL;
                uint64_t l_2214 = 18446744073709551615UL;
                uint32_t l_2251 = 0x99C12719L;
                int64_t **l_2262 = &g_184[1][1][0];
                int i, j, k;
                if ((safe_sub_func_int16_t_s_s((l_2157 = (safe_mul_func_int16_t_s_s(((void*)0 != (*g_1219)), (safe_div_func_uint16_t_u_u((((l_2148 = 4294967295UL) , (g_337[g_161] , ((g_337[g_161] || (((((**l_12) == (l_2149 == ((safe_lshift_func_uint8_t_u_u((l_2152 = 7UL), (g_337[g_161] >= 0x55E1EFB666E4592DLL))) , (void*)0))) < l_2153) , 1UL) ^ l_2153)) && l_2152))) || (**g_869)), l_2154))))), l_2153)))
                { /* block id: 995 */
                    (*g_670) = func_28(l_2158);
                    (*g_420) = func_28(&g_217[2][4][1]);
                    (*l_10) &= (*g_206);
                }
                else
                { /* block id: 999 */
                    int8_t ***l_2161 = &g_1840;
                    int32_t *l_2179 = &g_337[0];
                    int32_t *l_2181 = (void*)0;
                    int32_t *l_2182 = &g_9[1];
                    int32_t *l_2185[3][8] = {{&g_276,&g_217[4][5][3].f0,&g_276,&g_276,&g_217[4][5][3].f0,&g_276,&l_2139.f0,&g_276},{&g_276,&g_276,&g_11,&g_217[4][5][3].f0,&g_276,&g_276,(void*)0,(void*)0},{&g_217[4][5][3].f0,(void*)0,&g_276,&g_276,&l_17.f0,&g_11,&g_11,&l_17.f0}};
                    uint8_t **l_2188 = &l_2137;
                    uint8_t ***l_2231 = &l_2188;
                    uint8_t ****l_2230 = &l_2231;
                    uint8_t ***l_2233 = (void*)0;
                    uint8_t ****l_2232 = &l_2233;
                    int64_t *l_2242 = &l_2153;
                    int64_t *l_2243 = &g_186;
                    int i, j;
                    if ((((safe_rshift_func_uint8_t_u_u(((((l_2162 = l_2161) != (void*)0) < ((safe_div_func_int8_t_s_s(((*l_10) > (safe_mul_func_uint16_t_u_u((((((safe_add_func_uint64_t_u_u((l_2154 = 18446744073709551615UL), (safe_lshift_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((*l_2178) = ((l_2186[6] = ((safe_sub_func_uint16_t_u_u((l_2175 , (safe_lshift_func_uint16_t_u_s((((((*l_2182) = ((((l_2178 != (***g_1893)) , (((*l_2179) = 0L) , l_2180[4])) , 0x6BL) != 7UL)) && l_2183) == (*g_206)) | l_2183), 11))), 65535UL)) >= l_2184)) == g_11)), l_2184)), l_2187)))) == (*l_10)) <= l_2157) > 0xAD1BL) , (*l_10)), (-7L)))), (-1L))) <= 0xB77FL)) < 0xDA90051D552A8F97LL), l_2148)) >= l_2152) || l_2186[6]))
                    { /* block id: 1006 */
                        (**l_12) |= (*g_206);
                    }
                    else
                    { /* block id: 1008 */
                        (*g_206) = (l_2188 != (*g_2037));
                    }
                    for (g_138 = 9; (g_138 < 20); ++g_138)
                    { /* block id: 1013 */
                        int64_t l_2192 = 0x5B2EAF8C538581BCLL;
                        int32_t l_2193 = 0x1B8B10F9L;
                        int16_t l_2197[4];
                        int i;
                        for (i = 0; i < 4; i++)
                            l_2197[i] = 0xE5EBL;
                        l_2194--;
                        (*g_206) = ((0xD5146EA9L <= 0x662F5510L) <= ((((l_2197[3] < l_2197[3]) == l_2198) < ((safe_mod_func_uint8_t_u_u((g_337[g_161] , ((18446744073709551615UL >= (g_2201[8][0] != l_2204)) || g_337[g_161])), (*g_859))) == l_2193)) , 0x76EFL));
                        l_2216 |= (safe_lshift_func_int8_t_s_u(((**l_12) | ((((safe_rshift_func_int8_t_s_u(0L, 5)) , ((void*)0 == (**g_1893))) || l_2180[4].f3) ^ (safe_add_func_uint8_t_u_u(l_2154, (((+l_2214) | (((*l_10) ^ ((*l_2178) = (l_2194 && (***g_868)))) == 65531UL)) , l_2215[6][4][2]))))), (**l_12)));
                    }
                    if ((((1UL || ((safe_sub_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((((*l_2243) |= ((*l_2242) &= (safe_lshift_func_int8_t_s_s((((**g_334) || (safe_div_func_uint64_t_u_u((l_2225[0][4][3] , ((*l_18) , (l_2191 = (safe_mod_func_int32_t_s_s((((*l_2178) = 0x5C545DF848EFDDABLL) != (safe_div_func_uint64_t_u_u(((((*l_2230) = &l_2188) != ((*l_2232) = &g_1082)) <= (safe_lshift_func_int16_t_s_s((0xDAE9L ^ (+((+((***g_1839) &= (safe_rshift_func_uint8_t_u_s((((**l_12) > 0UL) , 1UL), 2)))) <= 65535UL))), 7))), (*l_10)))), (*l_2182)))))), l_2240))) , l_2241[5][1][5]), 6)))) ^ (-6L)), 7UL)) & (**l_12)) != l_2186[4]), (*l_2182))) & (*l_2182))) , (-1L)) != l_2215[1][5][2]))
                    { /* block id: 1026 */
                        uint32_t l_2244 = 18446744073709551612UL;
                        uint8_t l_2248 = 0xD5L;
                        ++l_2244;
                        if ((*l_2182))
                            continue;
                        l_2248++;
                        (*l_2182) = (0x09A7L > 0x442CL);
                    }
                    else
                    { /* block id: 1031 */
                        (**l_12) = l_2251;
                        if (l_2251)
                            break;
                    }
                    if (l_2241[6][1][3])
                        break;
                }
                l_2270[0] ^= (safe_mul_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(0UL, 6)) != (safe_lshift_func_int8_t_s_u(((safe_mod_func_uint8_t_u_u(((*l_2136) = 0xBEL), ((***g_1839) = ((l_2216 &= (*l_10)) || (0L ^ ((safe_sub_func_uint8_t_u_u((((void*)0 != l_2262) | (***g_868)), (safe_add_func_uint64_t_u_u(((((*g_1841) & ((safe_mod_func_int32_t_s_s(((**l_12) &= (safe_sub_func_int8_t_s_s(((*g_1841) , (*g_859)), l_2154))), 0x0D0B993EL)) != l_2269)) , l_2154) >= l_2251), l_2186[1])))) >= 0xF73B9A5137B5A121LL)))))) >= l_2225[0][4][3].f0), 0))), l_2154));
                l_2225[0][4][3].f0 = l_2270[0];
            }
            (*l_12) = l_2271;
            (*l_2284) |= (safe_rshift_func_int16_t_s_u((l_2282 = (safe_add_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((*l_2271), (safe_lshift_func_uint8_t_u_s(((4294967293UL && (~(*l_2271))) == l_2281), 5)))), (***g_868)))), l_2283));
        }
    }
    else
    { /* block id: 1048 */
        uint16_t *l_2286 = &g_136;
        union U0 ***l_2289 = (void*)0;
        union U0 ****l_2288 = &l_2289;
        int32_t l_2296[2][4][8] = {{{1L,0x9201B347L,3L,(-2L),0xA35818E4L,0xA35818E4L,(-2L),3L},{1L,1L,2L,(-1L),1L,0x9201B347L,(-1L),0xF80EC286L},{0x7D92B2E5L,0L,0xA35818E4L,0x9201B347L,1L,0x0600A618L,0x4E1D7CEBL,0xF80EC286L},{0L,3L,0x167146D1L,(-1L),1L,(-1L),0x167146D1L,3L}},{{0xB04B00DEL,2L,1L,(-2L),0x9B8B89D7L,0x40F14374L,3L,0x0600A618L},{0x4E1D7CEBL,0xA35818E4L,0xF80EC286L,0x167146D1L,0xB04B00DEL,0L,3L,1L},{(-7L),0x167146D1L,1L,0x40F14374L,0x40F14374L,1L,0x167146D1L,(-7L)},{0x40F14374L,1L,0x167146D1L,(-7L),1L,(-2L),0x4E1D7CEBL,0x7D92B2E5L}}};
        uint32_t l_2300 = 18446744073709551609UL;
        int32_t l_2329 = 4L;
        int i, j, k;
        (*g_206) = (*l_10);
        for (l_2135 = 0; l_2135 < 9; l_2135 += 1)
        {
            g_337[l_2135] = 0x697DE586L;
        }
        if ((((*l_2286) |= (((*g_1893) = l_2285) == l_2285)) || ((*l_2286) |= (l_2287 | ((void*)0 == l_2288)))))
        { /* block id: 1054 */
            return (***g_1839);
        }
        else
        { /* block id: 1056 */
            const union U1 **l_2290 = &g_196[3][3];
            (*l_2290) = (*g_1028);
        }
        for (g_214.f0 = 0; (g_214.f0 <= 0); g_214.f0 += 1)
        { /* block id: 1061 */
            const uint64_t l_2297 = 0UL;
            for (g_339 = 0; (g_339 >= 0); g_339 -= 1)
            { /* block id: 1064 */
                int16_t l_2293 = 3L;
                int64_t *l_2298 = &g_186;
                int32_t **l_2299 = (void*)0;
                union U2 l_2305[3] = {{0x73EE0B14L},{0x73EE0B14L},{0x73EE0B14L}};
                int i;
                (*l_12) = &l_2296[1][0][4];
                l_2300--;
                for (g_316.f1 = 0; (g_316.f1 >= 0); g_316.f1 -= 1)
                { /* block id: 1070 */
                    union U0 l_2306 = {-9L};
                    int32_t *l_2307 = &l_2139.f0;
                    uint32_t *l_2313[4][6] = {{&l_17.f1,(void*)0,(void*)0,&g_385,(void*)0,(void*)0},{&l_17.f1,(void*)0,(void*)0,&g_385,(void*)0,(void*)0},{&l_17.f1,(void*)0,(void*)0,&g_385,(void*)0,(void*)0},{&l_17.f1,(void*)0,(void*)0,&g_385,(void*)0,(void*)0}};
                    int i, j;
                    for (g_498 = 0; (g_498 <= 0); g_498 += 1)
                    { /* block id: 1073 */
                        int i, j, k;
                    }
                    if ((*l_2307))
                        continue;
                    for (g_161 = 0; (g_161 <= 2); g_161 += 1)
                    { /* block id: 1082 */
                        (*l_2307) = ((*l_2307) == 5L);
                    }
                    for (l_17.f1 = (-12); (l_17.f1 >= 47); ++l_17.f1)
                    { /* block id: 1087 */
                        int16_t l_2312[8] = {0x835BL,0x23EEL,0x835BL,0x23EEL,0x835BL,0x23EEL,0x835BL,0x23EEL};
                        int i;
                        l_2329 ^= ((((safe_rshift_func_int8_t_s_s(l_2312[2], (**g_1840))) | ((&g_385 == l_2313[0][1]) ^ (safe_add_func_int8_t_s_s((((safe_sub_func_int64_t_s_s(((l_2297 & (safe_mul_func_uint8_t_u_u(255UL, ((((safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(l_2296[1][2][0], ((!(l_2297 ^ (safe_mod_func_uint32_t_u_u((!(*l_10)), (*l_2307))))) < 0x1736L))), g_2328)) != (*l_10)) || l_2296[1][2][0]) , 252UL)))) >= 8UL), (*l_10))) < (*l_10)) >= (*l_10)), 0x5DL)))) | l_2312[7]) ^ l_2300);
                        if (l_2312[2])
                            continue;
                    }
                }
            }
            for (g_136 = 0; (g_136 < 30); ++g_136)
            { /* block id: 1095 */
                if (l_2296[1][2][0])
                    break;
            }
            for (l_2240 = 0; (l_2240 <= 1); l_2240 += 1)
            { /* block id: 1100 */
                (*g_206) ^= (**l_12);
            }
        }
    }
    return l_2135;
}


/* ------------------------------------------ */
/* 
 * reads : g_9
 * writes: g_9
 */
static int64_t  func_4(int8_t  p_5, uint16_t  p_6)
{ /* block id: 1 */
    int32_t *l_8[7];
    int i;
    for (i = 0; i < 7; i++)
        l_8[i] = &g_9[1];
    g_9[1] &= p_5;
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_48 g_7 g_62 g_388 g_334 g_335 g_190 g_139 g_337 g_161 g_206 g_188 g_389 g_420 g_197.f3 g_438 g_214.f3 g_276 g_214.f0 g_257 g_138 g_227 g_197.f1 g_1277 g_875 g_1219 g_1220 g_187 g_1377 g_1378 g_1641 g_1642 g_841 g_1313 g_1672 g_1260 g_197.f0 g_1746 g_859 g_860 g_110 g_1258 g_1259 g_1839 g_1840 g_1841 g_1893 g_1673 g_1674 g_11 g_1322 g_1323 g_140 g_2036 g_868 g_869 g_870 g_871 g_2091 g_339 g_1731 g_2112
 * writes: g_48 g_62 g_389 g_139 g_161 g_188 g_214.f0 g_227 g_110 g_1313 g_1221 g_187 g_153 g_186 g_276 g_1641 g_841 g_578 g_138 g_762 g_1839 g_316.f1 g_875 g_1893 g_11 g_140 g_2017 g_883 g_588 g_2112
 */
static uint8_t  func_15(union U0  p_16)
{ /* block id: 6 */
    uint32_t l_38 = 0xBA5616D2L;
    int32_t *l_2072 = &g_217[4][5][3].f0;
    int32_t *l_2133 = (void*)0;
    int32_t **l_2134 = &l_2072;
    l_2133 = func_19(func_21(func_26(func_28(func_30(func_32(p_16.f1, func_35(l_38, g_39))))), (l_38 , l_2072), l_2072, &l_2072));
    (*l_2134) = l_2133;
    (*l_2134) = (*l_2134);
    return p_16.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_335 g_190 g_2091 g_276 g_161 g_339 g_1731 g_1220 g_62 g_859 g_860 g_870 g_871 g_2112 g_334 g_206 g_868 g_869 g_1840 g_1841 g_7 g_438 g_389
 * writes: g_161 g_1221 g_62 g_588 g_153 g_188 g_2112 g_276
 */
static int32_t * func_19(int32_t * const  p_20)
{ /* block id: 957 */
    int32_t *l_2076[4];
    int64_t l_2077[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint32_t l_2078 = 0UL;
    uint32_t *l_2082 = &g_161;
    uint32_t **l_2081 = &l_2082;
    int32_t l_2083 = 0x5604A185L;
    union U0 ***** const l_2089 = (void*)0;
    uint32_t l_2090 = 4294967289UL;
    int32_t l_2092 = (-1L);
    const int8_t l_2093 = 0xDBL;
    int32_t **l_2094 = &l_2076[1];
    uint64_t *****l_2104[4] = {&g_1893,&g_1893,&g_1893,&g_1893};
    union U2 l_2105 = {0x62B89924L};
    int8_t ***l_2108[10][3][7] = {{{&g_1840,&g_1840,&g_1840,(void*)0,&g_1840,&g_1840,&g_1840},{(void*)0,&g_1840,&g_1840,&g_1840,&g_1840,(void*)0,&g_1840},{&g_1840,&g_1840,(void*)0,&g_1840,(void*)0,&g_1840,&g_1840}},{{&g_1840,(void*)0,&g_1840,&g_1840,&g_1840,(void*)0,&g_1840},{&g_1840,&g_1840,(void*)0,&g_1840,&g_1840,(void*)0,&g_1840},{&g_1840,&g_1840,(void*)0,(void*)0,(void*)0,&g_1840,&g_1840}},{{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{(void*)0,&g_1840,&g_1840,(void*)0,&g_1840,&g_1840,(void*)0},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,(void*)0}},{{&g_1840,&g_1840,&g_1840,&g_1840,(void*)0,(void*)0,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,(void*)0,(void*)0,(void*)0,&g_1840,&g_1840,&g_1840}},{{&g_1840,&g_1840,(void*)0,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840}},{{&g_1840,&g_1840,&g_1840,&g_1840,(void*)0,&g_1840,(void*)0},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840}},{{(void*)0,(void*)0,&g_1840,&g_1840,&g_1840,(void*)0,(void*)0},{&g_1840,(void*)0,&g_1840,&g_1840,(void*)0,&g_1840,&g_1840},{(void*)0,&g_1840,(void*)0,&g_1840,&g_1840,(void*)0,&g_1840}},{{&g_1840,(void*)0,(void*)0,&g_1840,&g_1840,(void*)0,(void*)0},{&g_1840,(void*)0,&g_1840,(void*)0,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,(void*)0,&g_1840,(void*)0,&g_1840,(void*)0}},{{&g_1840,&g_1840,(void*)0,(void*)0,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,(void*)0}},{{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840,&g_1840},{&g_1840,&g_1840,&g_1840,&g_1840,(void*)0,&g_1840,(void*)0}}};
    union U1 l_2125[10] = {{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL},{0x21386D8F9DEAA75BLL}};
    uint8_t l_2129 = 0UL;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_2076[i] = &g_316.f0;
    l_2078--;
    (*l_2094) = func_21(&l_2076[0], ((*l_2094) = (((l_2081 != &l_2082) <= (((*g_335) == l_2083) == ((((0x4ABBE4CD0C3B02FFLL <= (((((**l_2081) &= (((-1L) >= (safe_lshift_func_uint16_t_u_s((!(safe_rshift_func_int16_t_s_u((l_2089 == (void*)0), l_2090))), g_2091[0][4][2]))) & (*p_20))) & (*p_20)) != g_339) == (*p_20))) , g_1731) , l_2092) | l_2093))) , (void*)0)), &g_276, l_2094);
    for (g_62 = 1; (g_62 >= 17); g_62 = safe_add_func_uint64_t_u_u(g_62, 5))
    { /* block id: 964 */
        uint64_t ******l_2100 = (void*)0;
        uint64_t *****l_2102 = &g_1893;
        uint64_t ******l_2101 = &l_2102;
        union U1 l_2103[8] = {{3UL},{3UL},{3UL},{3UL},{3UL},{3UL},{3UL},{3UL}};
        uint8_t *l_2109 = &g_588;
        uint8_t *l_2110 = (void*)0;
        uint8_t *l_2111 = &g_153[2][5];
        const int8_t **l_2118[10][9][2] = {{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{(void*)0,(void*)0},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,(void*)0},{&g_859,(void*)0},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,(void*)0},{&g_859,&g_859},{(void*)0,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{(void*)0,&g_859},{&g_859,(void*)0},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,(void*)0},{&g_859,&g_859},{(void*)0,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{(void*)0,&g_859},{&g_859,(void*)0},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}},{{&g_859,&g_859},{&g_859,(void*)0},{&g_859,&g_859},{(void*)0,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859},{&g_859,&g_859}}};
        int64_t *l_2128 = &l_2077[1];
        int i, j, k;
        (*g_206) = (safe_mod_func_uint16_t_u_u(((~((((*l_2101) = (void*)0) != (l_2103[1] , l_2104[1])) > ((((l_2105 , ((((safe_add_func_uint8_t_u_u(((*l_2109) = ((void*)0 == l_2108[9][1][2])), (l_2103[1].f1 <= ((*l_2111) = 2UL)))) | (l_2103[1].f3 & l_2103[1].f3)) >= 7L) == l_2103[1].f2)) <= (*g_859)) | (*g_870)) & g_2112))) , (**g_334)), l_2103[1].f3));
        for (g_2112 = (-25); (g_2112 <= 43); g_2112++)
        { /* block id: 971 */
            uint8_t l_2115 = 0UL;
            (*p_20) = l_2115;
        }
        (*p_20) = ((safe_rshift_func_uint8_t_u_s(((l_2118[7][4][0] == l_2118[7][4][0]) < (l_2103[1].f3 < 0x07D3DD64F9C2C93FLL)), 4)) > ((safe_mul_func_int8_t_s_s((((((***g_868) , (((*l_2128) = ((safe_rshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u(((l_2125[6] , g_860[3][1][0]) , l_2103[1].f2), ((safe_mul_func_int16_t_s_s(l_2103[1].f3, 65526UL)) != l_2103[1].f1))), 5)) < (**g_1840))) <= l_2103[1].f3)) | l_2103[1].f0) && 0x48171D36L) >= 0x3A9DBB09L), (*g_1841))) | 7UL));
    }
    --l_2129;
    return (*g_438);
}


/* ------------------------------------------ */
/* 
 * reads : g_1220
 * writes: g_1221
 */
static int32_t * func_21(int32_t ** p_22, int32_t * p_23, int32_t * p_24, int32_t ** p_25)
{ /* block id: 952 */
    union U1 *l_2073 = &g_214;
    union U1 **l_2074 = &l_2073;
    int32_t *l_2075 = &g_276;
    (*l_2074) = ((*g_1220) = l_2073);
    (*p_25) = l_2075;
    return (*p_25);
}


/* ------------------------------------------ */
/* 
 * reads : g_841 g_206 g_1313 g_1672 g_188 g_1260 g_197.f0 g_1746 g_138 g_859 g_860 g_110 g_139 g_161 g_1258 g_1259 g_1839 g_1840 g_1841 g_7 g_334 g_335 g_190 g_1377 g_1378 g_1641 g_1642 g_438 g_389 g_1893 g_1673 g_1674 g_875 g_11 g_1322 g_1323 g_62 g_140 g_1219 g_1220 g_2036 g_48 g_868 g_869 g_870 g_871
 * writes: g_841 g_389 g_188 g_1313 g_110 g_578 g_139 g_138 g_762 g_161 g_1839 g_1641 g_62 g_316.f1 g_875 g_1893 g_11 g_276 g_140 g_2017 g_227 g_1221 g_883 g_48
 */
static int32_t ** func_26(int32_t * p_27)
{ /* block id: 741 */
    uint32_t l_1644 = 0x806E879DL;
    int32_t l_1647 = 0x9B921C90L;
    union U0 **l_1658 = (void*)0;
    union U0 ***l_1657 = &l_1658;
    union U0 ****l_1656 = &l_1657;
    int32_t l_1685 = 0x3EB20F94L;
    int32_t l_1686 = (-6L);
    int32_t l_1688 = (-1L);
    int32_t l_1692[6][4][3] = {{{1L,0x94307BB4L,1L},{1L,1L,1L},{1L,0xA11F4AAFL,(-1L)},{1L,0xA11F4AAFL,(-1L)}},{{1L,1L,(-1L)},{1L,0x94307BB4L,1L},{1L,1L,1L},{1L,0xA11F4AAFL,(-1L)}},{{1L,0xA11F4AAFL,(-1L)},{1L,1L,(-1L)},{1L,0x94307BB4L,1L},{1L,1L,1L}},{{1L,0xA11F4AAFL,(-1L)},{1L,1L,0x9466386BL},{1L,0x518788EEL,3L},{1L,7L,0x518788EEL}},{{(-1L),0x518788EEL,0x518788EEL},{(-1L),1L,3L},{(-1L),1L,0x9466386BL},{1L,0x518788EEL,3L}},{{1L,7L,0x518788EEL},{(-1L),0x518788EEL,0x518788EEL},{(-1L),1L,3L},{(-1L),1L,0x9466386BL}}};
    int32_t **l_1703 = &g_389;
    int64_t l_1711[4] = {0x896F4A0CD17D5B2ELL,0x896F4A0CD17D5B2ELL,0x896F4A0CD17D5B2ELL,0x896F4A0CD17D5B2ELL};
    uint8_t l_1745 = 0xA2L;
    int32_t *l_1747[2];
    uint32_t l_1748 = 0x4FD2E11CL;
    union U1 l_1751 = {0xDC767AF8B6D6A869LL};
    uint8_t l_1752 = 255UL;
    const uint8_t *l_1755 = &g_588;
    const uint8_t **l_1754 = &l_1755;
    const uint8_t ***l_1753 = &l_1754;
    const uint8_t ****l_1756 = (void*)0;
    const uint8_t ****l_1757 = &l_1753;
    uint32_t l_1758 = 0x527C2369L;
    uint32_t l_1759 = 7UL;
    int64_t l_1762 = (-3L);
    int32_t l_1763[3];
    uint64_t l_1764 = 0xFB10726F5A6C269FLL;
    const int8_t l_1765 = 0x06L;
    int32_t l_1766 = (-6L);
    union U2 l_1767 = {0xAE8C0CC5L};
    uint16_t l_1768 = 65529UL;
    int8_t l_1816 = 0x44L;
    int64_t l_1817 = 3L;
    uint64_t ****l_1898[8] = {&g_1894,&g_1894,&g_1894,&g_1894,&g_1894,&g_1894,&g_1894,&g_1894};
    int16_t l_1961 = 0x6B3DL;
    uint32_t ***l_2048[3][4][6];
    int8_t l_2051 = 0L;
    int32_t l_2064[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int8_t **l_2067 = &g_1841;
    uint16_t l_2068 = 1UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1747[i] = &l_1692[3][1][1];
    for (i = 0; i < 3; i++)
        l_1763[i] = 0x0BF8D29EL;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
                l_2048[i][j][k] = &g_1378;
        }
    }
    if (l_1644)
    { /* block id: 742 */
        int32_t **l_1650 = (void*)0;
        int32_t l_1655 = 4L;
        int32_t l_1693 = 0x552933AFL;
        int32_t l_1696 = (-9L);
        int32_t l_1709 = 0x3D9795B6L;
        int32_t l_1710 = 0x7CB3F66FL;
        int64_t l_1712 = 0xC5007EE5AE190F35LL;
        int32_t l_1714 = 0x60CC1022L;
        int32_t l_1715 = 0xF8D89272L;
        int32_t l_1716 = 0L;
        int32_t l_1717 = 5L;
        int32_t l_1718 = 0x52CB9022L;
        int32_t l_1719 = 1L;
        int32_t l_1720[1][4] = {{(-3L),(-3L),(-3L),(-3L)}};
        union U2 l_1728 = {0xE0DD902AL};
        const uint32_t *l_1730 = &g_1731;
        const uint32_t **l_1729 = &l_1730;
        int16_t *l_1742 = &g_110;
        int i, j;
        for (g_841 = 0; (g_841 < 24); ++g_841)
        { /* block id: 745 */
            int32_t **l_1649 = &g_389;
            union U0 ****l_1662 = (void*)0;
            const int8_t *l_1668 = &g_316.f1;
            int8_t *l_1669 = (void*)0;
            int8_t l_1676 = 4L;
            int32_t l_1690 = 1L;
            int32_t l_1691 = 0xDCCDAFB0L;
            int32_t l_1695 = 0L;
            int32_t l_1707 = (-1L);
            int32_t l_1713[2];
            uint8_t l_1721 = 0xA6L;
            int i;
            for (i = 0; i < 2; i++)
                l_1713[i] = 0xE9FB086EL;
            l_1647 = 0x0687E500L;
            (*l_1649) = p_27;
            for (l_1647 = 1; (l_1647 >= 0); l_1647 -= 1)
            { /* block id: 750 */
                int64_t l_1654[2][2][7] = {{{0L,0L,1L,0x25A39E6E4297B226LL,1L,0L,0L},{0x25F59C07127DB0DBLL,0xD0E6048B2F95E35CLL,0L,0x099F1C105A7D16FDLL,0x25A39E6E4297B226LL,0x19F6153511E3A17BLL,0L}},{{0x25A39E6E4297B226LL,0L,0x3D158EF7F6A27AF6LL,0x3D158EF7F6A27AF6LL,0L,0x25A39E6E4297B226LL,0x25F59C07127DB0DBLL},{0L,0x3D158EF7F6A27AF6LL,0L,0x25F59C07127DB0DBLL,0x699863C6CB63D83ALL,0x25A39E6E4297B226LL,0x25A39E6E4297B226LL}}};
                int32_t l_1687 = 0L;
                int32_t l_1689 = (-2L);
                int32_t l_1694[4] = {0x5BC9F008L,0x5BC9F008L,0x5BC9F008L,0x5BC9F008L};
                uint8_t l_1697[6];
                int32_t *l_1704 = &l_1692[5][1][0];
                int32_t *l_1705 = &l_1691;
                int32_t *l_1706[2][4][3] = {{{(void*)0,(void*)0,&l_1689},{(void*)0,&l_1692[5][3][2],(void*)0},{&l_1688,(void*)0,&l_1688},{&l_1688,(void*)0,(void*)0}},{{(void*)0,&l_1688,&l_1688},{(void*)0,&l_1688,(void*)0},{&l_1692[5][3][2],(void*)0,&l_1689},{(void*)0,(void*)0,&l_1689}}};
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_1697[i] = 0x1DL;
                for (l_1644 = 0; (l_1644 <= 1); l_1644 += 1)
                { /* block id: 753 */
                    return l_1650;
                }
                if (((0x590EB8603AE00637LL && (safe_unary_minus_func_int64_t_s((safe_lshift_func_int8_t_s_u((0x15L & l_1654[0][1][1]), 4))))) , l_1655))
                { /* block id: 756 */
                    union U0 *****l_1659 = &l_1656;
                    union U0 ****l_1661[5] = {&l_1657,&l_1657,&l_1657,&l_1657,&l_1657};
                    union U0 *****l_1660[9][7] = {{&l_1661[0],(void*)0,&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[4]},{&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],(void*)0,(void*)0,&l_1661[1]},{&l_1661[0],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[0]},{(void*)0,&l_1661[1],&l_1661[0],&l_1661[1],&l_1661[1],&l_1661[0],&l_1661[1]},{&l_1661[1],&l_1661[1],&l_1661[3],&l_1661[0],&l_1661[1],&l_1661[4],(void*)0},{&l_1661[1],(void*)0,&l_1661[0],(void*)0,&l_1661[1],(void*)0,&l_1661[0]},{&l_1661[1],&l_1661[1],&l_1661[1],(void*)0,&l_1661[1],&l_1661[1],(void*)0},{&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[0],&l_1661[1],(void*)0,&l_1661[1]},{&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1],&l_1661[1]}};
                    int32_t l_1663[5][8] = {{0xEAC9C0CCL,0L,0L,0xEAC9C0CCL,1L,0xA2E5AA21L,0xA2E5AA21L,1L},{0xEAC9C0CCL,0L,0L,0xEAC9C0CCL,1L,0xA2E5AA21L,0xA2E5AA21L,1L},{0xEAC9C0CCL,0L,0L,0xEAC9C0CCL,1L,0xA2E5AA21L,0xA2E5AA21L,1L},{0xEAC9C0CCL,0L,0L,0xEAC9C0CCL,1L,0xA2E5AA21L,0xA2E5AA21L,1L},{0xEAC9C0CCL,0L,0L,0xEAC9C0CCL,1L,0xA2E5AA21L,0xA2E5AA21L,1L}};
                    int i, j;
                    l_1663[1][5] = ((l_1662 = ((*l_1659) = l_1656)) == &l_1657);
                    (*g_206) = (l_1647 | l_1663[1][5]);
                    for (g_1313 = 0; (g_1313 <= 4); g_1313 += 1)
                    { /* block id: 763 */
                        uint8_t *l_1675[5];
                        int32_t l_1683 = 0L;
                        int i;
                        for (i = 0; i < 5; i++)
                            l_1675[i] = &g_153[1][0];
                        (*g_206) ^= (safe_mod_func_int8_t_s_s((((((safe_mul_func_uint8_t_u_u((((l_1668 == l_1669) & ((safe_add_func_uint64_t_u_u(l_1654[0][0][0], ((void*)0 != g_1672))) , l_1644)) ^ l_1663[0][0]), (l_1676 |= l_1647))) < ((safe_rshift_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(0x752CL, 6)), 0x0BL)), l_1647)) > l_1654[0][1][1])) != l_1663[0][6]) < l_1683) < l_1654[0][1][1]), (-1L)));
                        if (l_1647)
                            continue;
                        if (l_1654[1][0][4])
                            continue;
                        if (l_1644)
                            continue;
                    }
                }
                else
                { /* block id: 770 */
                    int32_t *l_1684[3][8][5] = {{{&l_1655,&g_11,&g_276,&l_1647,&l_1655},{&g_316.f0,&l_1655,(void*)0,&l_1655,&g_316.f0},{&l_1655,&l_1655,&g_276,&l_1647,&l_1647},{&l_1647,&g_11,(void*)0,&l_1647,&l_1647},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_276,&l_1655,&l_1647},{&g_217[4][5][3].f0,&l_1647,&g_316.f0,&l_1647,&g_316.f0},{&l_1647,&g_217[4][5][3].f0,&g_316.f0,&g_276,&l_1655},{&l_1655,&g_11,&g_276,&l_1647,&l_1655}},{{&g_316.f0,&l_1655,(void*)0,&l_1655,&g_316.f0},{&l_1655,&l_1655,&g_276,&l_1647,&l_1647},{&l_1647,&g_11,(void*)0,&l_1647,&l_1647},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_276,&l_1655,&l_1647},{&g_217[4][5][3].f0,&l_1647,&g_316.f0,&l_1647,&g_316.f0},{&l_1647,&g_217[4][5][3].f0,&g_316.f0,&g_276,&l_1655},{&l_1655,&g_11,&g_276,&l_1647,&l_1655},{&g_316.f0,&l_1655,(void*)0,&l_1655,&g_316.f0}},{{&l_1655,&l_1655,&g_276,&l_1647,&l_1647},{&l_1647,&g_11,(void*)0,&l_1647,&l_1647},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_276,&l_1655,&l_1647},{&g_217[4][5][3].f0,&l_1647,&g_316.f0,&l_1647,&g_316.f0},{&l_1647,&g_217[4][5][3].f0,&g_316.f0,&g_276,&l_1655},{&l_1655,&g_11,&g_276,&l_1647,&l_1655},{&g_316.f0,&l_1655,(void*)0,&l_1655,&g_316.f0},{&l_1655,&l_1655,&g_276,&l_1647,&l_1647}}};
                    int i, j, k;
                    l_1697[5]--;
                    if ((l_1693 = l_1692[2][1][0]))
                    { /* block id: 773 */
                        uint8_t l_1700 = 253UL;
                        --l_1700;
                    }
                    else
                    { /* block id: 775 */
                        return l_1703;
                    }
                    return &g_875[0];
                }
                ++l_1721;
                for (l_1676 = 0; (l_1676 <= 1); l_1676 += 1)
                { /* block id: 783 */
                    for (l_1687 = 0; (l_1687 <= 1); l_1687 += 1)
                    { /* block id: 786 */
                        (*l_1704) = (-1L);
                    }
                }
            }
        }
        (*g_1746) = (((safe_add_func_uint16_t_u_u(l_1716, (l_1717 , (safe_sub_func_int64_t_s_s((((p_27 != (l_1728 , ((*l_1729) = &g_385))) || (safe_mod_func_int64_t_s_s((-7L), (safe_rshift_func_int8_t_s_u((l_1692[5][3][2] >= (safe_sub_func_int8_t_s_s(((safe_mul_func_int16_t_s_s(((safe_mod_func_int16_t_s_s(((*l_1742) = l_1688), (safe_mod_func_uint64_t_u_u((l_1685 & l_1644), l_1711[0])))) != l_1718), l_1745)) != (*g_1260)), 6UL))), l_1711[0]))))) & l_1710), l_1718))))) || l_1711[0]) , &l_1728);
        (*l_1703) = p_27;
    }
    else
    { /* block id: 796 */
lbl_1818:
        (*l_1703) = p_27;
    }
    l_1748--;
    (*g_206) = (*g_206);
    if (((l_1751 , (((l_1752 <= (((*l_1757) = l_1753) != (((((((l_1758 == ((l_1759 == ((g_138 , (*g_859)) , (safe_mod_func_uint32_t_u_u(0UL, ((l_1762 || (*g_1260)) , l_1763[1]))))) >= (-1L))) <= l_1764) , 65535UL) >= l_1765) <= 0x8EFFL) | 0x40L) , &g_1082))) && l_1766) , l_1767)) , l_1768))
    { /* block id: 802 */
        uint32_t l_1793 = 18446744073709551615UL;
        const uint16_t *l_1802 = (void*)0;
        const uint16_t **l_1801 = &l_1802;
        int32_t l_1827 = 1L;
        int32_t l_1845[9];
        int16_t l_1925[4][1][7] = {{{(-1L),0x6EA9L,0xFCABL,0x6EA9L,(-1L),(-1L),0x6EA9L}},{{1L,(-1L),1L,0L,0L,1L,(-1L)}},{{0x6EA9L,1L,0xFCABL,0xFCABL,1L,0x6EA9L,1L}},{{1L,0L,0L,1L,(-1L),1L,0L}}};
        uint16_t l_1933 = 65527UL;
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_1845[i] = (-9L);
lbl_1832:
        for (l_1647 = 0; (l_1647 > 29); l_1647 = safe_add_func_int16_t_s_s(l_1647, 8))
        { /* block id: 805 */
            int32_t l_1787 = 0xC75C7373L;
            union U1 ****l_1795[10] = {&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219};
            union U1 **** const *l_1794 = &l_1795[7];
            union U2 l_1800 = {0x3E1B3800L};
            int64_t *l_1812[10][2][10] = {{{&g_187,&l_1711[3],&g_186,&l_1711[0],&g_186,&l_1711[3],&l_1762,(void*)0,&l_1711[0],&g_186},{&l_1762,&g_186,&l_1711[0],&g_186,&l_1762,(void*)0,(void*)0,&g_186,(void*)0,(void*)0}},{{(void*)0,&l_1762,(void*)0,(void*)0,(void*)0,(void*)0,&l_1762,(void*)0,&l_1762,&g_186},{(void*)0,&l_1711[2],(void*)0,(void*)0,(void*)0,&g_187,&l_1762,(void*)0,&g_186,(void*)0}},{{&g_187,&g_186,(void*)0,(void*)0,(void*)0,(void*)0,&l_1762,(void*)0,(void*)0,&l_1711[0]},{&l_1711[2],&g_187,(void*)0,&g_186,&l_1711[2],&g_186,(void*)0,&g_186,&g_187,&l_1711[0]}},{{&g_186,(void*)0,&l_1711[0],&l_1711[0],&l_1711[2],&l_1711[0],&l_1711[0],(void*)0,&g_186,&g_186},{(void*)0,&g_187,&g_186,&g_187,&g_186,(void*)0,&g_186,(void*)0,(void*)0,&l_1711[2]}},{{&g_186,&g_186,(void*)0,&g_187,&g_187,&l_1762,&g_186,(void*)0,&g_186,&l_1711[0]},{&g_187,(void*)0,(void*)0,&l_1711[0],(void*)0,&g_186,&g_187,(void*)0,&g_187,&l_1711[2]}},{{&g_187,(void*)0,&l_1711[2],&g_186,&l_1762,&l_1762,&g_186,&l_1711[2],(void*)0,&g_187},{&l_1711[0],(void*)0,(void*)0,(void*)0,&g_186,&l_1762,&l_1711[3],&g_187,&g_186,&g_186}},{{&l_1711[3],(void*)0,&g_187,(void*)0,&g_186,&g_186,&g_186,&l_1711[0],&l_1762,&g_187},{&g_186,&l_1711[3],(void*)0,(void*)0,&l_1762,&g_187,(void*)0,&g_187,(void*)0,&l_1711[2]}},{{&l_1762,&l_1711[0],&l_1711[0],&g_186,(void*)0,(void*)0,(void*)0,&g_186,&l_1711[0],&l_1711[0]},{&l_1762,&g_186,(void*)0,&l_1711[0],&g_187,&g_186,(void*)0,&l_1762,(void*)0,&l_1711[2]}},{{&g_186,(void*)0,&l_1711[0],&g_186,&g_186,&g_186,(void*)0,&g_187,&l_1711[3],&g_186},{&l_1762,(void*)0,(void*)0,&g_187,&l_1711[2],(void*)0,(void*)0,&g_186,&g_186,&l_1711[0]}},{{&l_1762,(void*)0,&l_1711[0],(void*)0,&l_1711[2],&g_187,&g_187,&l_1711[2],(void*)0,&l_1711[0]},{&g_186,&g_186,(void*)0,&g_186,(void*)0,&l_1711[3],&g_187,&g_186,&l_1762,(void*)0}}};
            int32_t l_1813[3][2];
            int32_t l_1814 = 4L;
            int8_t *l_1819[5] = {&l_1767.f1,&l_1767.f1,&l_1767.f1,&l_1767.f1,&l_1767.f1};
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1813[i][j] = 0x306FE6DEL;
            }
            for (g_110 = (-6); (g_110 == (-17)); g_110 = safe_sub_func_int32_t_s_s(g_110, 1))
            { /* block id: 808 */
                uint16_t l_1781 = 0UL;
                int32_t l_1782 = 0x0BC5F5E3L;
                for (g_139 = 0; (g_139 < (-7)); g_139 = safe_sub_func_int32_t_s_s(g_139, 1))
                { /* block id: 811 */
                    uint16_t *l_1783 = &g_138;
                    uint16_t *l_1786 = &l_1768;
                    int32_t l_1788 = 0x85BB4F53L;
                    uint64_t l_1796 = 18446744073709551608UL;
                    l_1782 = (safe_mod_func_int32_t_s_s((((((safe_lshift_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(l_1781, (((*l_1786) = ((*l_1783)++)) & 1L))), 5)) && (l_1787 < (l_1782 && l_1788))) , l_1782) != (safe_rshift_func_uint16_t_u_s((5L <= ((safe_add_func_int32_t_s_s(l_1793, (l_1794 == &l_1795[9]))) ^ l_1788)), 6))) <= l_1796), 0x1CB1FBDEL));
                }
                (*g_206) = (-2L);
            }
            (*g_206) ^= ((l_1787 > (safe_mul_func_uint8_t_u_u((+l_1793), l_1793))) ^ (((l_1800 , l_1801) == &g_884) & (safe_div_func_uint64_t_u_u((+((safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s((0x2412L | ((l_1814 = (l_1813[1][0] = l_1800.f0)) < ((~(l_1800.f0 >= l_1816)) != l_1793))), l_1793)), l_1817)) == l_1793)), l_1787))));
            if (g_110)
                goto lbl_1818;
            (*g_206) = (((g_762 = ((void*)0 != &l_1753)) , 1UL) & (!(safe_mul_func_int16_t_s_s(((l_1793 , (0xD976E21BL <= ((safe_lshift_func_uint16_t_u_u((((l_1787 != (((((safe_div_func_int64_t_s_s((l_1814 = ((*g_206) >= ((l_1827 | (safe_mul_func_uint8_t_u_u(l_1813[1][0], 249UL))) < l_1793))), 0x029224F65EF5620BLL)) , 1L) , l_1787) == l_1800.f1) | l_1800.f0)) , l_1814) != l_1813[1][0]), l_1787)) , l_1813[2][0]))) , 0x88DAL), l_1813[0][1]))));
        }
        for (l_1767.f0 = 0; (l_1767.f0 >= (-13)); --l_1767.f0)
        { /* block id: 828 */
            uint64_t l_1881 = 18446744073709551607UL;
            int32_t **l_1884 = &g_875[3];
            uint8_t l_1957 = 0xB0L;
            int32_t l_1958[4] = {(-1L),(-1L),(-1L),(-1L)};
            int i;
            if (g_139)
                goto lbl_1832;
            for (l_1827 = (-11); (l_1827 <= 18); ++l_1827)
            { /* block id: 832 */
                uint64_t l_1835 = 0x53BAA3DE474ED2CELL;
                uint32_t *l_1838 = &g_161;
                int8_t ****l_1842 = &g_1839;
                union U2 l_1850 = {0xFB73A42DL};
                if ((((l_1835 , ((*l_1838) ^= (safe_add_func_uint64_t_u_u(l_1835, l_1835)))) ^ ((*g_859) & ((((void*)0 == (*g_1258)) || 0x8DL) >= (0xDCE797703973F53ELL ^ (((*l_1842) = g_1839) == &g_1840))))) ^ l_1835))
                { /* block id: 835 */
                    uint32_t l_1854 = 0xAB64F1C3L;
                    int32_t l_1861 = 1L;
                    uint8_t l_1862[8];
                    int i;
                    for (i = 0; i < 8; i++)
                        l_1862[i] = 0xE1L;
                    (*g_206) = (safe_add_func_int8_t_s_s((l_1793 , (l_1845[2] = 1L)), (safe_sub_func_int64_t_s_s(((safe_mod_func_int32_t_s_s((l_1850 , 0x83E1A908L), (safe_rshift_func_uint8_t_u_s(((!(l_1854 | ((safe_rshift_func_int8_t_s_s((**g_1840), ((safe_lshift_func_uint16_t_u_u((**g_334), 0)) & (safe_lshift_func_uint8_t_u_u(l_1854, 4))))) & (*g_1841)))) <= l_1854), 5)))) | 0x3EC86019L), 0xF298622777EDF3EALL))));
                    l_1862[2]++;
                }
                else
                { /* block id: 839 */
                    union U0 * const l_1865 = &g_217[4][5][3];
                    (*l_1703) = func_28(l_1865);
                }
                return &g_875[2];
            }
            if ((safe_sub_func_uint32_t_u_u(((safe_rshift_func_int8_t_s_u(0x7BL, 4)) <= l_1793), 0xF532BD87L)))
            { /* block id: 844 */
                int32_t **l_1870 = &g_875[3];
                return l_1870;
            }
            else
            { /* block id: 846 */
                int8_t l_1876 = 0x5BL;
                int32_t l_1880[8][10][2] = {{{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L}},{{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L}},{{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L}},{{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L}},{{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L}},{{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L}},{{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L}},{{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L},{0x7A5B804DL,9L},{0xE0478A33L,0xCAD9B7E6L},{0xE0478A33L,9L},{0x7A5B804DL,0x0A4CD7F3L},{1L,5L},{(-8L),5L},{1L,0x0A4CD7F3L}}};
                int32_t **l_1887[6];
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_1887[i] = &g_875[3];
                if ((~(l_1827 == ((+l_1845[3]) , (safe_rshift_func_int16_t_s_s((l_1845[2] , (+l_1876)), 12))))))
                { /* block id: 847 */
                    int32_t *l_1877 = &g_276;
                    (*l_1703) = l_1877;
                    for (g_62 = 27; (g_62 <= (-30)); g_62--)
                    { /* block id: 851 */
                        l_1881++;
                        return l_1884;
                    }
                    for (l_1647 = (-18); (l_1647 >= 4); l_1647 = safe_add_func_int8_t_s_s(l_1647, 9))
                    { /* block id: 857 */
                        return l_1887[5];
                    }
                }
                else
                { /* block id: 860 */
                    uint32_t l_1890 = 0x0FBEC31BL;
                    int32_t **l_1909 = &g_875[3];
                    for (g_316.f1 = (-5); (g_316.f1 == 15); g_316.f1 = safe_add_func_int32_t_s_s(g_316.f1, 4))
                    { /* block id: 863 */
                        uint64_t *****l_1897 = &g_1893;
                        uint64_t *****l_1899 = (void*)0;
                        uint64_t *****l_1900 = &l_1898[5];
                        uint64_t ****l_1902 = &g_1894;
                        uint64_t *****l_1901 = &l_1902;
                        int64_t l_1907 = 0x33FB1C7A984136BELL;
                        int32_t l_1908 = 0x442E5C38L;
                        (*l_1884) = func_28(&g_217[4][8][1]);
                        --l_1890;
                        l_1908 = ((((*l_1897) = g_1893) == ((*l_1901) = ((*l_1900) = l_1898[7]))) | (safe_add_func_int16_t_s_s(((safe_rshift_func_int16_t_s_u(((*g_1673) != (*g_1840)), 14)) & l_1907), l_1845[2])));
                    }
                    return l_1909;
                }
                if ((**l_1884))
                    break;
                for (g_1313 = 0; (g_1313 >= 43); g_1313 = safe_add_func_uint32_t_u_u(g_1313, 5))
                { /* block id: 876 */
                    uint8_t *l_1932 = &g_140;
                    int32_t l_1948 = 0L;
                    for (l_1816 = 28; (l_1816 == (-19)); l_1816--)
                    { /* block id: 879 */
                        uint32_t *l_1926 = &l_1644;
                        uint8_t *l_1931 = &g_115;
                        int32_t l_1934 = 0xE7222403L;
                        int8_t *l_1935 = &g_316.f1;
                        int8_t *l_1936 = &g_62;
                        int16_t *l_1937 = &l_1925[0][0][4];
                        int16_t *l_1955[8] = {&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6],&l_1925[1][0][6]};
                        uint16_t *l_1956 = &l_1933;
                        int i;
                        (**l_1884) ^= (safe_rshift_func_int16_t_s_s(((*l_1937) = ((((safe_sub_func_int8_t_s_s(l_1793, (safe_add_func_int32_t_s_s((safe_lshift_func_int8_t_s_s(((l_1793 != (*g_206)) >= (!l_1925[1][0][6])), 4)), ((*l_1926) = 4294967295UL))))) < ((((*l_1936) &= (safe_mul_func_int8_t_s_s((*g_1841), (((*l_1935) = (safe_mod_func_int16_t_s_s((l_1931 != l_1932), ((l_1933 = (((**l_1656) = &g_39) != (*g_1322))) | l_1934)))) , l_1845[5])))) > (*g_859)) != 65534UL)) >= l_1934) != l_1934)), l_1934));
                        l_1958[1] ^= (safe_lshift_func_int8_t_s_s((safe_add_func_uint16_t_u_u((((safe_add_func_uint8_t_u_u(254UL, (l_1845[2] = (safe_add_func_int64_t_s_s((**l_1884), (0x97F6L || (safe_mul_func_int8_t_s_s((((*l_1935) = l_1948) >= (safe_div_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(l_1925[1][0][6], l_1934)) | 0xF2L), ((*l_1956) |= ((((safe_mod_func_uint8_t_u_u(((((**l_1703) = ((void*)0 == (*g_1258))) || (*g_335)) & l_1845[2]), (**l_1884))) >= (**l_1884)) | l_1934) != (-1L)))))), 1L)))))))) & 0xE762L) != l_1957), (**l_1884))), 6));
                    }
                    for (l_1881 = 0; (l_1881 <= 2); l_1881 += 1)
                    { /* block id: 895 */
                        return l_1887[5];
                    }
                }
            }
        }
    }
    else
    { /* block id: 901 */
        int64_t *l_1970 = &l_1762;
        int32_t l_2020 = 0x24C59440L;
        int32_t l_2027 = 0x4A754320L;
        union U2 l_2045[8][3][2] = {{{{0L},{0xD9964374L}},{{0xFA8FAD74L},{0xD9964374L}},{{0L},{1L}}},{{{0L},{0xFA8FAD74L}},{{0L},{3L}},{{0L},{0xFA8FAD74L}}},{{{0L},{0L}},{{0xFA8FAD74L},{0L}},{{3L},{0L}}},{{{0xFA8FAD74L},{0L}},{{0L},{0xFA8FAD74L}},{{0L},{3L}}},{{{0L},{0xFA8FAD74L}},{{0L},{0L}},{{0xFA8FAD74L},{0L}}},{{{3L},{0L}},{{0xFA8FAD74L},{0L}},{{0L},{0xFA8FAD74L}}},{{{0L},{3L}},{{0L},{0xFA8FAD74L}},{{0L},{0L}}},{{{0xFA8FAD74L},{0L}},{{3L},{0L}},{{0xFA8FAD74L},{0L}}}};
        union U1 l_2054 = {1UL};
        int16_t *l_2069 = &g_48;
        int32_t l_2070 = (-1L);
        int i, j, k;
        for (l_1767.f0 = (-6); (l_1767.f0 == (-7)); l_1767.f0 = safe_sub_func_int16_t_s_s(l_1767.f0, 8))
        { /* block id: 904 */
            int16_t l_2023[7] = {(-5L),(-5L),8L,(-5L),(-5L),8L,(-5L)};
            union U1 *l_2029 = (void*)0;
            uint32_t ****l_2049 = &l_2048[0][3][5];
            int32_t l_2050 = 0xFCB06A9BL;
            int i;
            for (l_1748 = 0; (l_1748 <= 2); l_1748 += 1)
            { /* block id: 907 */
                int32_t l_2022[7];
                int64_t * const l_2028 = &l_1762;
                int i;
                for (i = 0; i < 7; i++)
                    l_2022[i] = 0x1284077BL;
                if (l_1766)
                    goto lbl_1818;
                if (l_1961)
                    continue;
                for (l_1759 = 0; (l_1759 <= 4); l_1759 += 1)
                { /* block id: 912 */
                    uint64_t *** const *l_1965 = &g_1894;
                    uint64_t *** const **l_1964 = &l_1965;
                    union U2 l_2013 = {0xCF7226CBL};
                    int32_t l_2021 = 0x3B02AB4FL;
                    uint16_t l_2025 = 65533UL;
                    for (l_1817 = 1; (l_1817 <= 4); l_1817 += 1)
                    { /* block id: 915 */
                        uint8_t *l_1975 = &g_140;
                        uint32_t *l_1982 = &l_1644;
                        uint8_t *l_1991[6] = {&g_588,(void*)0,(void*)0,&g_588,(void*)0,(void*)0};
                        uint8_t *l_1992 = &g_115;
                        uint8_t *l_1993[9] = {&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0],&g_153[1][0]};
                        uint8_t *l_1994 = (void*)0;
                        uint8_t *l_1995 = &l_1745;
                        uint8_t *l_1996 = &l_1745;
                        uint8_t *l_1997[10] = {(void*)0,&l_1745,&l_1745,&l_1745,(void*)0,(void*)0,&l_1745,&l_1745,&l_1745,(void*)0};
                        uint8_t *l_1998[9] = {&g_115,&g_841,&g_115,&g_115,&g_841,&g_115,&g_115,&g_841,&g_115};
                        uint8_t *l_1999 = &g_588;
                        uint8_t *l_2000 = (void*)0;
                        uint8_t *l_2001 = &l_1752;
                        uint8_t *l_2002 = &l_1752;
                        uint8_t *l_2003 = (void*)0;
                        uint8_t *l_2004 = &g_153[1][0];
                        uint8_t *l_2005 = &g_115;
                        uint8_t *l_2006 = (void*)0;
                        uint8_t *l_2007 = &l_1752;
                        uint8_t *l_2008[7][10] = {{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115},{(void*)0,&g_115,&l_1752,&l_1752,&g_115,(void*)0,&g_115,&l_1752,&l_1752,&g_115}};
                        uint8_t *l_2009 = (void*)0;
                        uint8_t *l_2010 = &l_1752;
                        uint8_t *l_2011[4][5][7] = {{{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588}},{{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745}},{{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588}},{{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745},{&g_588,&g_588,&g_588,&g_588,&g_588,&g_588,&g_588},{&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745,&l_1745}}};
                        uint8_t *l_2012 = &l_1752;
                        uint8_t ** const l_1990[9][8] = {{&l_1993[8],(void*)0,&l_1996,(void*)0,&l_2010,&l_2010,(void*)0,&l_1996},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_2010,(void*)0,&l_1996},{&l_1993[8],(void*)0,&l_1996,(void*)0,&l_2010,&l_2010,(void*)0,&l_1996},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_2010,(void*)0,&l_1996},{&l_1993[8],(void*)0,&l_1996,(void*)0,&l_2010,&l_2010,(void*)0,&l_1996},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_2010,(void*)0,&l_1996},{&l_1993[8],(void*)0,&l_1996,(void*)0,&l_2010,&l_2010,(void*)0,&l_1996},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_2010,(void*)0,&l_1996},{&l_1993[8],(void*)0,&l_1996,(void*)0,&l_2010,&l_2010,(void*)0,&l_1996}};
                        uint8_t ** const *l_1989 = &l_1990[4][3];
                        uint8_t ** const **l_1988 = &l_1989;
                        uint8_t ** const ***l_1987 = &l_1988;
                        union U2 *l_2014 = &l_2013;
                        int8_t ****l_2018 = &g_1839;
                        int16_t *l_2019 = &l_1961;
                        uint16_t *l_2024[4];
                        uint64_t *l_2026 = &l_1751.f0;
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                            l_2024[i] = &l_1768;
                        l_1692[(l_1817 + 1)][(l_1748 + 1)][l_1748] = ((l_1692[(l_1748 + 2)][(l_1748 + 1)][l_1748] , ((safe_sub_func_int16_t_s_s(((((void*)0 != l_1964) & (l_2021 = (safe_mod_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s(((((l_1970 != ((safe_lshift_func_uint8_t_u_s((((((safe_rshift_func_uint8_t_u_s((--(*l_1975)), 1)) != ((((safe_add_func_int16_t_s_s(((((l_1692[(l_1817 + 1)][l_1748][l_1748] && (safe_mul_func_int16_t_s_s((((*l_1982)--) , ((l_2020 = (((safe_rshift_func_uint16_t_u_s((((*l_1987) = (void*)0) == (void*)0), ((((*l_2014) = l_2013) , (safe_mod_func_uint32_t_u_u((l_2013.f0 = ((((*l_2019) = ((g_2017 = &g_1839) != l_2018)) >= 0xF381L) , l_2020)), l_2021))) ^ l_2022[5]))) > 0x9FC38681L) & l_2023[5])) || l_2025)), l_2022[6]))) , l_2022[0]) , l_2020) <= 65529UL), 0x6E6FL)) != l_2025) , (void*)0) != l_2026)) <= l_2027) <= l_2027) , l_2022[1]), 5)) , l_2028)) | l_2025) | 0x20L) , l_2020), 1)), l_1692[(l_1817 + 1)][l_1748][l_1748])))) , l_2022[3]), (**g_334))) >= l_2027)) , (-1L));
                        return &g_389;
                    }
                    for (g_227 = 0; (g_227 <= 4); g_227 += 1)
                    { /* block id: 930 */
                        union U1 **l_2030 = (void*)0;
                        union U1 **l_2031 = &l_2029;
                        (*l_2031) = ((**g_1219) = l_2029);
                        return &g_389;
                    }
                }
            }
            l_2027 |= (safe_lshift_func_int8_t_s_u(((safe_mul_func_uint16_t_u_u((((void*)0 == g_2036) , (safe_mul_func_uint8_t_u_u((7UL && 3L), (-2L)))), (safe_div_func_int8_t_s_s(0xC9L, (safe_mul_func_int8_t_s_s((l_2045[0][0][0] , (l_2050 = (safe_add_func_uint32_t_u_u((l_2045[0][0][0].f1 != (((*l_2049) = l_2048[0][3][5]) != (void*)0)), 0xC2FBF3F0L)))), l_2023[3])))))) || 4294967290UL), l_2023[5]));
            for (l_1759 = 0; l_1759 < 5; l_1759 += 1)
            {
                for (l_1768 = 0; l_1768 < 2; l_1768 += 1)
                {
                    for (l_1745 = 0; l_1745 < 9; l_1745 += 1)
                    {
                        g_883[l_1759][l_1768][l_1745] = &g_884;
                    }
                }
            }
        }
        l_2070 &= ((g_161--) | (l_2054 , (0x4F412F3AL || (!(((((*g_859) || (((((safe_mod_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s(((((*g_859) >= ((safe_lshift_func_int8_t_s_u(l_2045[0][0][0].f0, (l_2064[5] <= ((l_2054 , (((((safe_lshift_func_uint16_t_u_s((*g_335), 9)) == (((((*l_2069) ^= ((l_2067 != (*g_1839)) == l_2068)) && l_2020) ^ l_2054.f0) ^ 0xBEB8L)) > 0x1B84L) < l_2054.f2) & (-9L))) || (***g_868))))) ^ l_2054.f2)) , l_1970) == l_1970), 6)) ^ 0UL), l_2027)) >= l_2054.f0) && 0x5F52D295891F928DLL) == (*g_859)) | l_2045[0][0][0].f1)) && 0x311B8655L) > l_2054.f0) <= l_2045[0][0][0].f1)))));
        for (l_2068 = 0; (l_2068 <= 1); l_2068 += 1)
        { /* block id: 947 */
            int32_t **l_2071 = &l_1747[0];
            return &g_389;
        }
    }
    return &g_389;
}


/* ------------------------------------------ */
/* 
 * reads : g_206 g_335 g_190 g_1377 g_1378 g_1641 g_1642 g_438 g_389
 * writes: g_188 g_1641
 */
static int32_t * func_28(union U0 * const  p_29)
{ /* block id: 735 */
    int16_t l_1624 = 0x4749L;
    union U1 l_1627 = {9UL};
    union U0 l_1628 = {-9L};
    int32_t *l_1643[1][7][7] = {{{&g_316.f0,&g_11,&g_316.f0,&g_316.f0,&g_11,&g_316.f0,&g_316.f0},{&g_217[4][5][3].f0,&g_276,&g_217[4][5][3].f0,&g_276,&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0},{&g_11,&g_316.f0,&g_316.f0,&g_316.f0,(void*)0,(void*)0,&g_316.f0},{&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0},{&g_316.f0,&g_316.f0,&g_11,&g_316.f0,&g_316.f0,&g_11,&g_316.f0},{&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0,&g_11,&g_217[4][5][3].f0},{(void*)0,&g_316.f0,(void*)0,(void*)0,&g_316.f0,(void*)0,(void*)0}}};
    int i, j, k;
    (*g_206) = 4L;
    (*g_206) = (((0x18A9F5F0L > (safe_rshift_func_int8_t_s_s((l_1624 || (safe_lshift_func_int16_t_s_u((l_1627 , (l_1628 , 0x1B35L)), 15))), 4))) == ((safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((~l_1627.f0), ((safe_unary_minus_func_int64_t_s((safe_div_func_int32_t_s_s(l_1628.f0, l_1624)))) || (safe_div_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(l_1627.f2, l_1628.f1)), l_1628.f1))))), (-1L))) ^ l_1627.f2)) == (*g_335));
    (*g_206) = ((void*)0 == (*g_1377));
    (*g_1642) = g_1641[0][3];
    return (*g_438);
}


/* ------------------------------------------ */
/* 
 * reads : g_1377 g_1378 g_276 g_206
 * writes: g_186 g_276 g_161 g_188
 */
static union U0 * func_30(int32_t ** p_31)
{ /* block id: 727 */
    uint16_t l_1598 = 0UL;
    int32_t l_1599 = 0x80081E54L;
    int64_t *l_1610 = &g_186;
    int8_t *l_1611[4][8][1] = {{{(void*)0},{&g_7},{&g_316.f1},{&g_7},{(void*)0},{&g_7},{(void*)0},{&g_7}},{{&g_316.f1},{&g_7},{(void*)0},{&g_7},{(void*)0},{&g_7},{&g_316.f1},{&g_7}},{{(void*)0},{&g_7},{(void*)0},{&g_7},{&g_316.f1},{&g_7},{(void*)0},{&g_7}},{{(void*)0},{&g_7},{&g_316.f1},{&g_7},{(void*)0},{&g_7},{(void*)0},{&g_7}}};
    int32_t l_1612 = (-1L);
    int32_t *l_1619 = &g_276;
    uint32_t *l_1620 = &g_161;
    union U0 *l_1621[7] = {&g_217[4][2][3],&g_217[4][2][3],&g_217[4][2][3],&g_217[4][2][3],&g_217[4][2][3],&g_217[4][2][3],&g_217[4][2][3]};
    int i, j, k;
    l_1599 = l_1598;
    (*g_206) = ((l_1599 < ((safe_lshift_func_uint16_t_u_s((safe_mul_func_int16_t_s_s(((l_1599 || ((18446744073709551607UL ^ ((((*l_1620) = (safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((l_1612 ^= (((*l_1610) = (0x01CDL | l_1599)) != 0UL)) , l_1599), (safe_sub_func_int8_t_s_s(l_1599, (safe_add_func_int16_t_s_s((((*l_1619) = (safe_rshift_func_uint8_t_u_s(((void*)0 == (*g_1377)), l_1599))) == l_1598), l_1598)))))), 5))) || (*l_1619)) <= l_1598)) == l_1599)) , (*l_1619)), l_1598)), l_1598)) == 255UL)) != l_1599);
    return l_1621[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_257 g_138 g_206 g_188 g_197.f1 g_1277 g_875 g_1219 g_1220 g_187 g_438 g_389 g_227
 * writes: g_188 g_227 g_110 g_389 g_1313 g_1221 g_187 g_153
 */
static int32_t ** func_32(int64_t  p_33, union U0  p_34)
{ /* block id: 209 */
    uint32_t *l_474[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    union U0 **l_475 = &g_39;
    union U0 ***l_476[7] = {(void*)0,&l_475,&l_475,(void*)0,&l_475,&l_475,(void*)0};
    union U0 **l_477 = &g_39;
    int64_t **l_481[3][9][4] = {{{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0}},{{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0}},{{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0},{&g_184[4][0][0],(void*)0,&g_184[4][0][0],&g_184[4][0][0]},{(void*)0,(void*)0,&g_184[5][0][0],(void*)0},{(void*)0,&g_184[4][0][0],&g_184[4][0][0],(void*)0}}};
    int32_t l_494 = 0x2E0DD547L;
    int32_t l_495 = (-1L);
    int16_t l_496 = (-1L);
    union U1 l_507 = {1UL};
    uint32_t l_518 = 0x61CCBAB4L;
    int32_t l_526[3];
    int16_t ** const l_537 = &g_109[2][1];
    int32_t l_617 = 0xCEFE9934L;
    uint32_t l_655 = 0xB120FF75L;
    int32_t **l_672 = &g_389;
    int32_t l_678 = 0xFA5E1C01L;
    uint8_t l_685 = 0xFDL;
    int64_t l_709 = 0L;
    int16_t l_739 = (-10L);
    uint8_t l_766 = 1UL;
    uint8_t l_863 = 0xFAL;
    uint16_t *l_882 = &g_136;
    uint16_t **l_881 = &l_882;
    int32_t l_961 = 0x074A5219L;
    int32_t l_1022 = 0xAF151B2FL;
    const uint16_t *l_1037 = &g_136;
    const uint16_t **l_1036 = &l_1037;
    uint8_t *l_1081 = &g_153[1][3];
    uint8_t **l_1080 = &l_1081;
    int32_t l_1086 = 0x79CE9398L;
    uint32_t *l_1094[1][9];
    union U1 l_1134[4][10] = {{{5UL},{0x8480BB09C3A810E0LL},{18446744073709551612UL},{0xA6F7825EDE61CC1DLL},{0xA6F7825EDE61CC1DLL},{18446744073709551612UL},{0x8480BB09C3A810E0LL},{5UL},{18446744073709551615UL},{0x47F60372185BD513LL}},{{0xA966FF7614F31917LL},{4UL},{0x9B231F9FAF8D18E4LL},{5UL},{0x6399065DF5D49342LL},{0xA6F7825EDE61CC1DLL},{18446744073709551609UL},{0x47F60372185BD513LL},{18446744073709551609UL},{0xA6F7825EDE61CC1DLL}},{{0UL},{0x6399065DF5D49342LL},{0x9B231F9FAF8D18E4LL},{0x6399065DF5D49342LL},{0UL},{0x47F60372185BD513LL},{18446744073709551615UL},{5UL},{0x8480BB09C3A810E0LL},{18446744073709551612UL}},{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551612UL},{0x47F60372185BD513LL},{0x168D1A3ADC304885LL},{3UL},{3UL},{0x168D1A3ADC304885LL},{0x47F60372185BD513LL},{18446744073709551612UL}}};
    int16_t **l_1224 = &g_109[4][1];
    union U2 l_1250 = {-1L};
    uint32_t l_1263 = 0x5D55DB65L;
    int32_t l_1331 = (-3L);
    uint64_t *l_1340 = &g_200;
    uint64_t **l_1339[3];
    uint64_t ***l_1338 = &l_1339[0];
    int16_t l_1467 = 0L;
    int8_t l_1482 = 1L;
    int32_t l_1487[9] = {2L,2L,0x0C461ACAL,2L,2L,0x0C461ACAL,2L,2L,0x0C461ACAL};
    uint8_t l_1534 = 0x75L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_526[i] = 0xFE234898L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
            l_1094[i][j] = (void*)0;
    }
    for (i = 0; i < 3; i++)
        l_1339[i] = &l_1340;
    (*g_206) |= ((g_257[4] > (l_474[0] != (((l_477 = l_475) != &g_39) , l_474[3]))) < g_138);
lbl_901:
    for (g_227 = 0; (g_227 <= 2); g_227 += 1)
    { /* block id: 214 */
        int32_t *l_478[8][9][3] = {{{&g_11,&g_276,(void*)0},{&g_316.f0,&g_276,&g_11},{&g_276,&g_316.f0,(void*)0},{&g_217[4][5][3].f0,&g_276,&g_316.f0},{&g_217[4][5][3].f0,&g_316.f0,(void*)0},{&g_316.f0,(void*)0,(void*)0},{&g_316.f0,&g_316.f0,&g_217[4][5][3].f0},{&g_11,&g_11,&g_217[4][5][3].f0},{&g_11,&g_217[4][5][3].f0,&g_316.f0}},{{&g_316.f0,&g_11,&g_276},{&g_316.f0,&g_11,&g_217[4][5][3].f0},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_276},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_217[4][5][3].f0},{&g_276,(void*)0,&g_217[4][5][3].f0},{&g_316.f0,&g_11,&g_11},{&g_11,&g_217[4][5][3].f0,&g_316.f0},{&g_217[4][5][3].f0,&g_276,(void*)0},{&g_217[4][5][3].f0,(void*)0,(void*)0}},{{&g_217[4][5][3].f0,&g_11,(void*)0},{&g_316.f0,&g_316.f0,&g_217[4][5][3].f0},{(void*)0,&g_276,(void*)0},{&g_11,&g_276,&g_217[4][5][3].f0},{(void*)0,&g_276,&g_11},{&g_316.f0,&g_11,&g_217[4][5][3].f0},{&g_217[4][5][3].f0,&g_276,(void*)0},{&g_276,&g_217[4][5][3].f0,&g_217[4][5][3].f0},{&g_11,&g_276,(void*)0}},{{&g_217[4][5][3].f0,(void*)0,(void*)0},{&g_11,&g_276,(void*)0},{&g_276,&g_316.f0,&g_316.f0},{&g_276,(void*)0,&g_11},{&g_316.f0,&g_276,&g_217[4][5][3].f0},{&g_316.f0,&g_316.f0,&g_217[4][5][3].f0},{&g_276,&g_11,&g_276},{(void*)0,(void*)0,&g_217[4][5][3].f0},{(void*)0,&g_11,&g_276}},{{&g_217[4][5][3].f0,(void*)0,&g_316.f0},{&g_276,&g_276,&g_217[4][5][3].f0},{&g_217[4][5][3].f0,&g_276,&g_217[4][5][3].f0},{(void*)0,(void*)0,(void*)0},{&g_276,&g_11,(void*)0},{&g_276,(void*)0,&g_316.f0},{&g_276,&g_11,(void*)0},{&g_11,&g_316.f0,&g_11},{&g_316.f0,&g_276,(void*)0}},{{&g_316.f0,(void*)0,&g_217[4][5][3].f0},{(void*)0,&g_316.f0,&g_276},{&g_276,(void*)0,&g_11},{&g_276,(void*)0,(void*)0},{&g_276,&g_11,&g_276},{&g_276,&g_316.f0,(void*)0},{&g_217[4][5][3].f0,(void*)0,(void*)0},{(void*)0,&g_217[4][5][3].f0,&g_316.f0},{&g_316.f0,&g_316.f0,&g_276}},{{(void*)0,(void*)0,(void*)0},{&g_217[4][5][3].f0,(void*)0,&g_217[4][5][3].f0},{&g_276,(void*)0,&g_217[4][5][3].f0},{&g_276,&g_11,(void*)0},{&g_276,&g_11,(void*)0},{&g_11,(void*)0,(void*)0},{&g_276,&g_217[4][5][3].f0,&g_11},{(void*)0,(void*)0,&g_11},{&g_276,&g_276,&g_276}},{{&g_276,&g_11,&g_276},{&g_217[4][5][3].f0,&g_316.f0,&g_276},{&g_316.f0,&g_217[4][5][3].f0,&g_276},{&g_217[4][5][3].f0,&g_217[4][5][3].f0,&g_316.f0},{(void*)0,&g_217[4][5][3].f0,(void*)0},{&g_316.f0,&g_316.f0,(void*)0},{&g_276,&g_217[4][5][3].f0,&g_316.f0},{&g_276,&g_276,&g_276},{&g_11,&g_276,&g_276}}};
        uint16_t *** const l_517 = (void*)0;
        union U0 ***l_523[8][4] = {{&l_477,&l_477,&l_475,&l_477},{&l_475,&l_477,&l_475,&l_475},{&l_475,&l_475,&l_475,&l_475},{&l_477,&l_475,&l_477,&l_475},{&l_475,&l_477,&l_477,&l_477},{&l_477,&l_477,&l_475,&l_477},{&l_475,&l_477,&l_475,&l_475},{&l_475,&l_475,&l_475,&l_475}};
        int32_t l_524 = 0L;
        uint64_t l_528 = 0x4B1B1B573E327C05LL;
        int16_t **l_533 = &g_109[4][0];
        union U2 l_573 = {0x60AD6484L};
        uint64_t l_574[3];
        int32_t l_581 = 0xA01931ACL;
        int32_t l_653 = 0xBCF5CFF9L;
        uint16_t l_674 = 65535UL;
        uint32_t l_770 = 18446744073709551612UL;
        union U1 l_828 = {0x366D43F65346654DLL};
        const int8_t *l_857 = &g_62;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_574[i] = 0x0BFB7DD05B12A5F8LL;
    }
    if ((0xFE87F7CF2B5AD71ALL > (18446744073709551612UL | g_197.f1)))
    { /* block id: 389 */
        uint16_t l_912 = 0x7C10L;
        uint64_t *l_913[9][7] = {{&g_214.f0,&l_507.f0,&g_200,&g_200,&l_507.f0,&g_214.f0,(void*)0},{&g_200,&g_200,&g_200,(void*)0,&g_200,&g_214.f0,&g_214.f0},{(void*)0,&g_200,&g_200,&g_200,(void*)0,(void*)0,&g_200},{&g_214.f0,&g_200,&g_214.f0,(void*)0,(void*)0,&g_200,(void*)0},{(void*)0,&l_507.f0,&l_507.f0,(void*)0,&g_200,(void*)0,&g_214.f0},{&g_214.f0,(void*)0,&g_200,(void*)0,&l_507.f0,&l_507.f0,(void*)0},{(void*)0,&g_200,(void*)0,(void*)0,&g_214.f0,&g_200,&g_214.f0},{&g_200,(void*)0,(void*)0,&g_200,&g_200,&g_200,(void*)0},{&g_214.f0,&g_214.f0,&g_200,(void*)0,&g_200,&g_200,&g_200}};
        const uint16_t *l_935 = &g_197.f3;
        const uint16_t **l_934 = &l_935;
        const uint16_t ***l_933[10] = {(void*)0,&l_934,(void*)0,(void*)0,&l_934,(void*)0,(void*)0,&l_934,(void*)0,(void*)0};
        int16_t *l_942 = &l_496;
        int32_t l_952 = 0xBA718C97L;
        int32_t l_962 = 1L;
        int32_t l_963 = 0x8BB78A3CL;
        int32_t l_966 = 0L;
        int32_t l_971 = 0x0821DB03L;
        int32_t l_972 = (-1L);
        int32_t **l_992 = &g_875[4];
        int64_t l_999[4];
        uint8_t *l_1071 = (void*)0;
        int32_t l_1098 = 0x852C4E99L;
        int32_t l_1104 = 0xFE586296L;
        int32_t l_1106 = (-5L);
        int32_t l_1107 = (-1L);
        int32_t l_1110[10][6] = {{(-2L),0x7B741227L,0x49621F03L,0x7B741227L,(-2L),0x7B741227L},{0x21283F22L,1L,0x21283F22L,0x7B741227L,0x21283F22L,1L},{(-2L),1L,0x49621F03L,1L,(-2L),1L},{0x21283F22L,0x7B741227L,0x21283F22L,1L,0x21283F22L,0x7B741227L},{(-2L),0x7B741227L,0x49621F03L,0x7B741227L,(-2L),0x7B741227L},{0x21283F22L,1L,0x21283F22L,0x7B741227L,0x21283F22L,1L},{(-2L),1L,0x49621F03L,1L,(-2L),1L},{0x21283F22L,0x7B741227L,0x21283F22L,1L,0x21283F22L,0x7B741227L},{(-2L),0x7B741227L,0x49621F03L,0x7B741227L,(-2L),0x7B741227L},{0x21283F22L,1L,0x21283F22L,0x7B741227L,0x21283F22L,1L}};
        union U2 *l_1119 = &g_316;
        union U1 l_1129 = {18446744073709551615UL};
        int32_t * const * const l_1242 = &g_875[3];
        int16_t l_1375 = 0x3C7FL;
        union U1 ****l_1405[10][9] = {{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219},{&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219,&g_1219}};
        int64_t **l_1431 = &g_184[0][0][0];
        int16_t l_1445 = 0xFFE6L;
        uint64_t l_1489 = 0x788A3D44EA343C6FLL;
        int32_t l_1494 = 0L;
        int64_t l_1522 = 0x27373AE63D55A3F5LL;
        union U0 *l_1537 = &g_217[4][8][1];
        int i, j;
        for (i = 0; i < 4; i++)
            l_999[i] = 0L;
    }
    else
    { /* block id: 690 */
        uint16_t l_1585 = 0xF140L;
        int32_t *l_1597 = &l_494;
        for (l_739 = 0; (l_739 == 2); l_739++)
        { /* block id: 693 */
            int32_t *l_1575 = (void*)0;
            int32_t *l_1576 = &l_1487[3];
            int32_t *l_1577 = (void*)0;
            int32_t *l_1578 = &l_961;
            int32_t *l_1579 = &l_1250.f0;
            int32_t *l_1580 = &g_217[4][5][3].f0;
            int32_t *l_1581 = &g_276;
            int32_t *l_1582 = &l_526[2];
            int32_t *l_1583 = &l_1250.f0;
            int32_t *l_1584 = &g_276;
            union U1 *l_1594 = &l_1134[0][6];
            for (g_110 = (-21); (g_110 <= (-6)); ++g_110)
            { /* block id: 696 */
                (*l_672) = (*g_1277);
                return &g_875[3];
            }
            if (l_739)
                goto lbl_901;
            ++l_1585;
            for (g_1313 = 0; (g_1313 >= 16); g_1313++)
            { /* block id: 704 */
                if ((*g_206))
                    break;
                for (l_766 = 0; (l_766 != 54); ++l_766)
                { /* block id: 708 */
                    for (l_495 = 0; (l_495 < (-10)); l_495 = safe_sub_func_uint32_t_u_u(l_495, 2))
                    { /* block id: 711 */
                        (**g_1219) = l_1594;
                    }
                    for (g_187 = 0; (g_187 < 3); g_187 = safe_add_func_uint32_t_u_u(g_187, 9))
                    { /* block id: 716 */
                        if ((*l_1583))
                            break;
                    }
                    (*l_1579) &= ((0x874AD94AL ^ p_34.f1) == ((**l_1080) = 0x04L));
                }
            }
        }
        l_1597 = (*g_438);
    }
    return l_672;
}


/* ------------------------------------------ */
/* 
 * reads : g_48 g_7 g_62 g_388 g_334 g_335 g_190 g_139 g_337 g_161 g_206 g_188 g_389 g_420 g_197.f3 g_438 g_214.f3 g_276 g_214.f0
 * writes: g_48 g_62 g_389 g_139 g_161 g_188 g_214.f0
 */
static union U0  func_35(uint64_t  p_36, union U0 * p_37)
{ /* block id: 7 */
    int32_t *l_40[9];
    int16_t *l_47[6] = {(void*)0,(void*)0,&g_48,(void*)0,(void*)0,&g_48};
    int8_t *l_61[5];
    int64_t l_63[4][7][8] = {{{7L,(-1L),1L,0x5E415B52D1A88BB4LL,(-2L),7L,(-2L),0x5E415B52D1A88BB4LL},{0x1C9C8A038AA138A8LL,0x5E415B52D1A88BB4LL,0x1C9C8A038AA138A8LL,(-1L),1L,(-3L),2L,0x5E415B52D1A88BB4LL},{1L,(-3L),2L,0x5E415B52D1A88BB4LL,0x2DC2603458E53ADDLL,0x848AA25E9F1F6A35LL,1L,0x848AA25E9F1F6A35LL},{1L,0xC86549E1F9A5DE3BLL,1L,0xC86549E1F9A5DE3BLL,1L,7L,7L,(-1L)},{0x1C9C8A038AA138A8LL,0xC86549E1F9A5DE3BLL,0x2DC2603458E53ADDLL,(-1L),(-2L),0x848AA25E9F1F6A35LL,2L,0xC86549E1F9A5DE3BLL},{7L,(-3L),0x2DC2603458E53ADDLL,(-1L),0x2DC2603458E53ADDLL,(-3L),0x1C9C8A038AA138A8LL,(-1L)},{0x2DC2603458E53ADDLL,(-3L),7L,0x848AA25E9F1F6A35LL,0x1C9C8A038AA138A8LL,(-1L),2L,(-1L)}},{{(-10L),0x848AA25E9F1F6A35LL,1L,(-1L),0x1C9C8A038AA138A8LL,(-1L),1L,0x848AA25E9F1F6A35LL},{0x2DC2603458E53ADDLL,7L,(-10L),(-1L),0x2FFB46D8FEB948C0LL,(-1L),0x2DC2603458E53ADDLL,(-1L)},{0x1C9C8A038AA138A8LL,0x848AA25E9F1F6A35LL,7L,(-3L),0x2DC2603458E53ADDLL,(-1L),0x2DC2603458E53ADDLL,(-3L)},{(-10L),(-3L),(-10L),(-1L),2L,7L,1L,(-3L)},{2L,7L,1L,(-3L),0x2FFB46D8FEB948C0LL,(-1L),2L,(-1L)},{2L,(-1L),7L,(-1L),2L,(-1L),0x1C9C8A038AA138A8LL,0x848AA25E9F1F6A35LL},{(-10L),(-1L),0x2FFB46D8FEB948C0LL,(-1L),0x2DC2603458E53ADDLL,(-1L),1L,(-1L)}},{{0x1C9C8A038AA138A8LL,7L,0x2FFB46D8FEB948C0LL,0x848AA25E9F1F6A35LL,0x2FFB46D8FEB948C0LL,7L,0x1C9C8A038AA138A8LL,(-1L)},{0x2DC2603458E53ADDLL,(-3L),7L,0x848AA25E9F1F6A35LL,0x1C9C8A038AA138A8LL,(-1L),2L,(-1L)},{(-10L),0x848AA25E9F1F6A35LL,1L,(-1L),0x1C9C8A038AA138A8LL,(-1L),1L,0x848AA25E9F1F6A35LL},{0x2DC2603458E53ADDLL,7L,(-10L),(-1L),0x2FFB46D8FEB948C0LL,(-1L),0x2DC2603458E53ADDLL,(-1L)},{0x1C9C8A038AA138A8LL,0x848AA25E9F1F6A35LL,7L,(-3L),0x2DC2603458E53ADDLL,(-1L),0x2DC2603458E53ADDLL,(-3L)},{(-10L),(-3L),(-10L),(-1L),2L,7L,1L,(-3L)},{2L,7L,1L,(-3L),0x2FFB46D8FEB948C0LL,(-1L),2L,(-1L)}},{{2L,(-1L),7L,(-1L),2L,(-1L),0x1C9C8A038AA138A8LL,0x848AA25E9F1F6A35LL},{(-10L),(-1L),0x2FFB46D8FEB948C0LL,(-1L),0x2DC2603458E53ADDLL,(-1L),1L,(-1L)},{0x1C9C8A038AA138A8LL,7L,0x2FFB46D8FEB948C0LL,0x848AA25E9F1F6A35LL,0x2FFB46D8FEB948C0LL,7L,0x1C9C8A038AA138A8LL,(-1L)},{0x2DC2603458E53ADDLL,(-3L),7L,0x848AA25E9F1F6A35LL,0x1C9C8A038AA138A8LL,(-1L),2L,(-1L)},{(-10L),0x848AA25E9F1F6A35LL,1L,(-1L),0x1C9C8A038AA138A8LL,(-1L),1L,0x848AA25E9F1F6A35LL},{0x2DC2603458E53ADDLL,7L,(-10L),(-1L),0x2FFB46D8FEB948C0LL,(-1L),0x2DC2603458E53ADDLL,(-1L)},{0x1C9C8A038AA138A8LL,0x848AA25E9F1F6A35LL,7L,(-3L),0x2DC2603458E53ADDLL,(-1L),0x2DC2603458E53ADDLL,(-3L)}}};
    uint64_t l_104 = 0xE13564EE88CA977DLL;
    union U0 l_157 = {0L};
    const union U1 l_171 = {0x2591527C6EF0018BLL};
    union U1 *l_213[1];
    union U1 **l_212[1][7] = {{&l_213[0],&l_213[0],&l_213[0],&l_213[0],&l_213[0],&l_213[0],&l_213[0]}};
    union U0 ** const l_244 = &g_39;
    int16_t l_340 = 0xEAEEL;
    int64_t * const *l_361 = &g_184[4][1][0];
    uint8_t l_384 = 249UL;
    const int32_t l_394[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int64_t l_412 = 0x1902675DDC7E6054LL;
    int64_t *l_415[3];
    uint8_t l_416 = 0x0FL;
    uint32_t *l_417[9] = {&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161,&g_161};
    uint32_t l_418 = 0x82F9C2A6L;
    int32_t *l_461 = &g_11;
    int32_t *l_471 = (void*)0;
    int32_t **l_473 = &l_461;
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_40[i] = (void*)0;
    for (i = 0; i < 5; i++)
        l_61[i] = &g_62;
    for (i = 0; i < 1; i++)
        l_213[i] = &g_214;
    for (i = 0; i < 3; i++)
        l_415[i] = &g_186;
    if (((((void*)0 == l_40[8]) , 0xA4ABFF1EB7E59501LL) <= ((safe_sub_func_int64_t_s_s((safe_rshift_func_int16_t_s_s((g_48 |= (safe_mod_func_uint16_t_u_u(p_36, p_36))), 12)), (g_7 | ((l_63[1][3][5] = (safe_add_func_uint32_t_u_u(((safe_div_func_int16_t_s_s((((safe_sub_func_int64_t_s_s((((safe_rshift_func_int16_t_s_u((safe_sub_func_uint64_t_u_u(g_7, (((((safe_add_func_int32_t_s_s(p_36, ((p_36 <= (-1L)) < p_36))) & 0xE5E2L) && g_7) | p_36) || 0x6BC67156L))), p_36)) <= 3UL) > p_36), p_36)) == p_36) ^ p_36), 0x6534L)) , p_36), 1UL))) >= 1L)))) | 0x552485C7L)))
    { /* block id: 10 */
        uint32_t l_64 = 4294967295UL;
        l_64 = (-1L);
    }
    else
    { /* block id: 12 */
        int64_t l_93 = 2L;
        int32_t l_94 = 1L;
        int64_t l_116 = 8L;
        int32_t l_189 = 0xFD995B20L;
        union U0 l_329 = {0x1C7D144DL};
        l_94 = ((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s(g_48, 8)), p_36)) < (safe_sub_func_int8_t_s_s((p_36 < (safe_mul_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u(0xC60D0FB0L, g_7)) >= (safe_unary_minus_func_uint32_t_u(p_36))), 0x0093L))), (safe_lshift_func_uint16_t_u_s((safe_mul_func_int8_t_s_s((0xFDF942F0L | (((safe_unary_minus_func_uint64_t_u((safe_div_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((safe_div_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((l_93 <= 0xCDL), 0x9B51B9DCL)), 5L)), 1UL)), g_7)), p_36)), l_93)))) < 0xC6L) | l_93)), g_7)), 12)))));
        for (g_62 = (-11); (g_62 == 28); g_62 = safe_add_func_int8_t_s_s(g_62, 2))
        { /* block id: 16 */
            union U2 l_103 = {-1L};
            int16_t *l_108 = &g_48;
            uint32_t l_117 = 0x47886503L;
            int16_t l_164 = 0x5AC0L;
            const int32_t *l_253[3][1];
            const int32_t *l_254 = &g_255;
            union U0 l_328[1][10][1] = {{{{-6L}},{{-1L}},{{-6L}},{{-1L}},{{-6L}},{{-1L}},{{-6L}},{{-1L}},{{-6L}},{{-1L}}}};
            union U1 l_362 = {0xB5ABB7801C71FC3ALL};
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 1; j++)
                    l_253[i][j] = (void*)0;
            }
        }
    }
    (*g_388) = l_40[5];
    if ((((safe_mul_func_int8_t_s_s(((((safe_add_func_uint16_t_u_u((**g_334), l_394[3])) == p_36) , ((((safe_mod_func_uint32_t_u_u((g_161 &= (safe_lshift_func_uint16_t_u_u(p_36, ((safe_mod_func_uint8_t_u_u((((safe_lshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u((safe_sub_func_int64_t_s_s((l_416 = (((safe_rshift_func_uint16_t_u_u((*g_335), (safe_sub_func_int64_t_s_s(((~p_36) & l_412), (((safe_mul_func_int8_t_s_s((g_139 |= 0x3CL), ((p_36 >= 0x8D40L) || p_36))) ^ p_36) || 0L))))) < p_36) ^ p_36)), p_36)), 13)), 10)) & p_36) <= g_337[0]), p_36)) , (*g_335))))), p_36)) , l_418) || 4294967295UL) < p_36)) , (-9L)), 251UL)) , (void*)0) != &l_384))
    { /* block id: 167 */
        uint8_t l_457 = 0UL;
        int32_t **l_462 = &l_40[8];
        int32_t **l_465 = &g_389;
        union U2 l_466 = {0xFB0A0D7BL};
        uint16_t l_467 = 0xCCB6L;
        (*g_206) = ((void*)0 != &g_109[3][0]);
        for (g_161 = 0; (g_161 <= 0); g_161 += 1)
        { /* block id: 171 */
            uint64_t l_419 = 0xFFB42335244FC275LL;
            int16_t l_435[5];
            int32_t l_448 = (-1L);
            int32_t l_453 = 0xCA1EB8C3L;
            int32_t l_455 = (-2L);
            int i;
            for (i = 0; i < 5; i++)
                l_435[i] = (-3L);
            (*g_206) &= l_419;
            (*g_206) ^= 0x38E5EC04L;
            for (g_48 = 0; (g_48 >= 0); g_48 -= 1)
            { /* block id: 176 */
                int64_t l_421 = (-1L);
                int32_t l_452 = 0xD5665C42L;
                int32_t l_456 = 0xEDE2A583L;
                union U0 l_460 = {-5L};
                (*g_420) = (*g_388);
                if ((l_421 ^= p_36))
                { /* block id: 179 */
                    uint8_t *l_429 = &l_416;
                    (*g_438) = ((safe_div_func_uint64_t_u_u((safe_unary_minus_func_uint32_t_u(((((*l_429) ^= (safe_add_func_int64_t_s_s(0x496A3788666FD07ELL, (++p_36)))) , (!(safe_sub_func_uint8_t_u_u(0xF4L, (safe_rshift_func_uint16_t_u_s((**g_334), 7)))))) ^ l_435[2]))), ((~l_421) || g_197.f3))) , (*g_420));
                }
                else
                { /* block id: 183 */
                    uint64_t l_441 = 0x945E739C0E2FA64CLL;
                    int32_t l_450 = 0L;
                    for (l_157.f0 = 0; (l_157.f0 >= 0); l_157.f0 -= 1)
                    { /* block id: 186 */
                        int16_t l_449 = 0x026EL;
                        int32_t l_451 = (-8L);
                        int32_t l_454 = 0x74D873EAL;
                        (*g_206) = ((safe_div_func_int8_t_s_s((p_36 < (**g_334)), g_214.f3)) ^ ((++l_441) | (safe_div_func_int8_t_s_s(((safe_add_func_uint64_t_u_u(p_36, 3L)) ^ p_36), g_276))));
                        l_457--;
                        return l_460;
                    }
                }
                return l_460;
            }
        }
        (*l_465) = ((*l_462) = l_461);
        (*g_206) = (l_466 , (l_467 ^ (-1L)));
    }
    else
    { /* block id: 199 */
        union U0 l_470 = {0x04F4B403L};
        for (g_214.f0 = 14; (g_214.f0 == 19); ++g_214.f0)
        { /* block id: 202 */
            return l_470;
        }
        return l_470;
    }
    (*l_473) = l_471;
    return l_157;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_153[i][j], "g_153[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_186, "g_186", print_hash_value);
    transparent_crc(g_187, "g_187", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    transparent_crc(g_197.f0, "g_197.f0", print_hash_value);
    transparent_crc(g_197.f1, "g_197.f1", print_hash_value);
    transparent_crc(g_197.f2, "g_197.f2", print_hash_value);
    transparent_crc(g_197.f3, "g_197.f3", print_hash_value);
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_214.f0, "g_214.f0", print_hash_value);
    transparent_crc(g_214.f1, "g_214.f1", print_hash_value);
    transparent_crc(g_214.f2, "g_214.f2", print_hash_value);
    transparent_crc(g_214.f3, "g_214.f3", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_217[i][j][k].f0, "g_217[i][j][k].f0", print_hash_value);
                transparent_crc(g_217[i][j][k].f1, "g_217[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_227, "g_227", print_hash_value);
    transparent_crc(g_252, "g_252", print_hash_value);
    transparent_crc(g_255, "g_255", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_257[i], "g_257[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_263.f0, "g_263.f0", print_hash_value);
    transparent_crc(g_263.f1, "g_263.f1", print_hash_value);
    transparent_crc(g_276, "g_276", print_hash_value);
    transparent_crc(g_316.f1, "g_316.f1", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_337[i], "g_337[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_339, "g_339", print_hash_value);
    transparent_crc(g_385, "g_385", print_hash_value);
    transparent_crc(g_498, "g_498", print_hash_value);
    transparent_crc(g_588, "g_588", print_hash_value);
    transparent_crc(g_634, "g_634", print_hash_value);
    transparent_crc(g_762, "g_762", print_hash_value);
    transparent_crc(g_793, "g_793", print_hash_value);
    transparent_crc(g_841, "g_841", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_860[i][j][k], "g_860[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_871, "g_871", print_hash_value);
    transparent_crc(g_1007, "g_1007", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1062[i], "g_1062[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1313, "g_1313", print_hash_value);
    transparent_crc(g_1708, "g_1708", print_hash_value);
    transparent_crc(g_1731, "g_1731", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2091[i][j][k], "g_2091[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2112, "g_2112", print_hash_value);
    transparent_crc(g_2138, "g_2138", print_hash_value);
    transparent_crc(g_2328, "g_2328", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 667
XXX total union variables: 52

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 32
breakdown:
   indirect level: 0, occurrence: 19
   indirect level: 1, occurrence: 5
   indirect level: 2, occurrence: 4
   indirect level: 3, occurrence: 1
   indirect level: 4, occurrence: 2
   indirect level: 5, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 28
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 24
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 6

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 189
   depth: 2, occurrence: 63
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 3
   depth: 24, occurrence: 4
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 29, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 37, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 476

XXX times a variable address is taken: 1374
XXX times a pointer is dereferenced on RHS: 235
breakdown:
   depth: 1, occurrence: 175
   depth: 2, occurrence: 51
   depth: 3, occurrence: 9
XXX times a pointer is dereferenced on LHS: 289
breakdown:
   depth: 1, occurrence: 247
   depth: 2, occurrence: 39
   depth: 3, occurrence: 3
XXX times a pointer is compared with null: 40
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 15
XXX times a pointer is qualified to be dereferenced: 9070

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 928
   level: 2, occurrence: 479
   level: 3, occurrence: 80
   level: 4, occurrence: 10
XXX number of pointers point to pointers: 211
XXX number of pointers point to scalars: 235
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.5
XXX average alias set size: 1.58

XXX times a non-volatile is read: 1690
XXX times a non-volatile is write: 860
XXX times a volatile is read: 144
XXX    times read thru a pointer: 91
XXX times a volatile is write: 66
XXX    times written thru a pointer: 50
XXX times a volatile is available for access: 1.78e+03
XXX percentage of non-volatile access: 92.4

XXX forward jumps: 1
XXX backward jumps: 16

XXX stmts: 203
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 38
   depth: 1, occurrence: 28
   depth: 2, occurrence: 31
   depth: 3, occurrence: 30
   depth: 4, occurrence: 37
   depth: 5, occurrence: 39

XXX percentage a fresh-made variable is used: 16.1
XXX percentage an existing variable is used: 83.9
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

