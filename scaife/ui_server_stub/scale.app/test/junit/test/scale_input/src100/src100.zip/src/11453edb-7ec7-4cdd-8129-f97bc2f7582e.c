/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2317908101
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile int16_t  f0;
   const volatile uint16_t  f1;
   uint32_t  f2;
};

union U1 {
   uint16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint64_t g_24 = 0x17D0B0A3531F145BLL;
static uint32_t g_49 = 4UL;
static uint32_t g_50 = 0xED55C59CL;
static volatile int64_t g_53 = 0x8F3B1AD31FC53136LL;/* VOLATILE GLOBAL g_53 */
static int32_t g_54 = (-1L);
static union U1 g_55 = {0xA6CEL};
static int32_t g_57 = 7L;
static int32_t * volatile g_56 = &g_57;/* VOLATILE GLOBAL g_56 */
static int16_t g_65 = 0x094CL;
static union U0 g_70 = {0x19E2L};/* VOLATILE GLOBAL g_70 */
static const volatile int32_t g_71 = (-8L);/* VOLATILE GLOBAL g_71 */
static union U0 g_79[10] = {{3L},{3L},{3L},{3L},{3L},{3L},{3L},{3L},{3L},{3L}};
static uint8_t g_121 = 0x62L;
static int32_t g_126 = 0x65FABB59L;
static int16_t g_129 = 0x0725L;
static int16_t *g_128 = &g_129;
static int16_t *g_131 = &g_129;
static uint32_t g_132 = 0x235FF65EL;
static int16_t g_133 = 0L;
static int8_t g_145 = 0xA2L;
static uint16_t g_149 = 0xB47BL;
static volatile int16_t g_189 = 1L;/* VOLATILE GLOBAL g_189 */
static volatile int16_t *g_188 = &g_189;
static volatile int16_t **g_187 = &g_188;
static volatile int16_t ***g_186 = &g_187;
static int32_t g_227 = (-6L);
static uint32_t g_235 = 0xE062F4CFL;
static int32_t *g_241 = &g_57;
static int32_t ** const g_240 = &g_241;
static union U1 *g_262 = &g_55;
static int64_t g_282[5][5][5] = {{{0xB85D11EB61880405LL,3L,1L,0L,0x6DA28F9CFB4EE82FLL},{3L,7L,0xDB69F81DA031FE69LL,0x49283E14190088FALL,0x6DA28F9CFB4EE82FLL},{0xDB8598D3324805C1LL,0xBE12B37BC6C639F2LL,0x48B2F7F30CB5C31CLL,0xDA15CDC3111986F8LL,0xA35905E24F52A209LL},{0xB29476F6431E086ELL,0xDA15CDC3111986F8LL,0L,0xA35905E24F52A209LL,0L},{1L,1L,(-1L),0x622FC61834C53088LL,0xBBD49E831240E195LL}},{{1L,0x20A0EFF4E26B6B82LL,0xB29476F6431E086ELL,0xBE12B37BC6C639F2LL,0x5CCEA2FED3EB0AC4LL},{0xDA15CDC3111986F8LL,0x44A5D971EE67ACDCLL,(-5L),0L,0L},{4L,0L,0x6DA28F9CFB4EE82FLL,0xB85D11EB61880405LL,1L},{0xA35905E24F52A209LL,0x2B4910B4DC2EF21BLL,(-6L),(-1L),0xB85D11EB61880405LL},{0x49283E14190088FALL,0xB29476F6431E086ELL,4L,1L,0x5370F3B88300E0F4LL}},{{(-6L),3L,0x244AF00ECB8A3075LL,0L,0xBBD49E831240E195LL},{0xBBD49E831240E195LL,(-1L),0L,0L,0xA3FC10053953203DLL},{0x59ECB97538202512LL,0xDB8598D3324805C1LL,0x622FC61834C53088LL,1L,(-1L)},{3L,1L,(-1L),(-1L),1L},{(-2L),0x8E1CA114316DEF22LL,0L,0xB85D11EB61880405LL,0L}},{{0x622FC61834C53088LL,0xBBD49E831240E195LL,0x8E1CA114316DEF22LL,0x3E6784C590CC90E3LL,7L},{0x49283E14190088FALL,0xDB69F81DA031FE69LL,7L,3L,0L},{0x622FC61834C53088LL,0x59ECB97538202512LL,0x244AF00ECB8A3075LL,(-5L),0xCBBADCDCB93CD6F9LL},{(-2L),0x244AF00ECB8A3075LL,0x5CCEA2FED3EB0AC4LL,1L,0xA3FC10053953203DLL},{3L,0xA35905E24F52A209LL,0xDB8598D3324805C1LL,0xB29476F6431E086ELL,0L}},{{0x59ECB97538202512LL,1L,2L,0L,(-5L)},{0xBBD49E831240E195LL,0x44A5D971EE67ACDCLL,2L,0xB85D11EB61880405LL,4L},{(-6L),(-2L),0xDB8598D3324805C1LL,0x6DA28F9CFB4EE82FLL,(-10L)},{0x49283E14190088FALL,(-1L),0x5CCEA2FED3EB0AC4LL,(-1L),0x49283E14190088FALL},{0xA35905E24F52A209LL,0x20A0EFF4E26B6B82LL,0x244AF00ECB8A3075LL,0L,0x2B4910B4DC2EF21BLL}}};
static int64_t g_284 = 0x7E37214903B10FF5LL;
static const uint64_t g_295 = 0xA8A4F390B09115C2LL;
static int64_t g_310 = 0x546E646427B96491LL;
static int64_t g_311 = 9L;
static const int32_t *g_321 = &g_126;
static uint32_t g_326 = 1UL;
static union U0 g_332 = {-1L};/* VOLATILE GLOBAL g_332 */
static uint16_t g_334[8] = {0x6B18L,6UL,0x6B18L,6UL,0x6B18L,6UL,0x6B18L,6UL};
static union U0 *g_372 = (void*)0;
static union U0 g_374 = {0xB65DL};/* VOLATILE GLOBAL g_374 */
static union U0 ***g_386 = (void*)0;
static volatile int64_t g_393 = 0x3B9B7C93A240FA44LL;/* VOLATILE GLOBAL g_393 */
static volatile int64_t *g_392 = &g_393;
static volatile int64_t **g_391 = &g_392;
static int64_t *g_519 = (void*)0;
static int64_t **g_518 = &g_519;
static int64_t ***g_517 = &g_518;
static int16_t g_522 = (-10L);
static uint16_t g_524 = 0xC539L;
static uint8_t g_531 = 0xE3L;
static uint32_t g_538 = 0xFA00A9F9L;
static int32_t g_568 = 0xEBBA0133L;
static uint8_t g_574 = 0x47L;
static int32_t g_604 = (-2L);
static uint8_t g_605 = 255UL;
static int32_t * volatile g_650[5][8][6] = {{{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_54,&g_54,&g_568,(void*)0,&g_568,&g_54},{&g_568,&g_568,(void*)0,(void*)0,&g_568,&g_568},{&g_54,&g_568,(void*)0,&g_568,&g_54,&g_54},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_54,&g_54,&g_568,(void*)0,&g_568,&g_54},{&g_568,&g_568,(void*)0,(void*)0,&g_568,&g_568}},{{&g_54,&g_568,(void*)0,&g_568,&g_54,&g_54},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_54,&g_54,&g_568,(void*)0,&g_568,&g_54},{&g_568,&g_568,(void*)0,(void*)0,&g_568,&g_568},{&g_54,&g_568,(void*)0,&g_568,&g_54,&g_54},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,(void*)0}},{{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_54,&g_568,&g_568,&g_54,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568,(void*)0,&g_54,(void*)0},{(void*)0,&g_54,(void*)0,&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_54,&g_568,&g_568,&g_54,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568}},{{(void*)0,&g_568,&g_568,(void*)0,&g_54,(void*)0},{(void*)0,&g_54,(void*)0,&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_54,&g_568,&g_568,&g_54,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568,(void*)0,&g_54,(void*)0},{(void*)0,&g_54,(void*)0,&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568}},{{&g_568,&g_54,&g_568,&g_568,&g_54,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568,(void*)0,&g_54,(void*)0},{(void*)0,&g_54,(void*)0,&g_568,&g_568,(void*)0},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{&g_568,&g_54,&g_568,&g_568,&g_54,&g_568},{&g_568,&g_568,&g_568,&g_568,&g_568,&g_568},{(void*)0,&g_568,&g_568,(void*)0,&g_54,(void*)0}}};
static int32_t * volatile *g_649 = &g_650[1][2][1];
static int32_t g_706 = 1L;
static union U0 g_743 = {0x8622L};/* VOLATILE GLOBAL g_743 */
static const uint8_t * volatile g_745[1] = {&g_605};
static const uint8_t * volatile *g_744 = &g_745[0];
static int32_t g_766 = (-1L);
static int32_t g_768 = 0xB9F8CD92L;
static int32_t g_771 = 0x7846ABC3L;
static uint16_t g_783 = 1UL;
static int32_t *g_789 = &g_768;
static int32_t **g_788 = &g_789;
static int32_t * volatile * volatile g_794 = &g_56;/* VOLATILE GLOBAL g_794 */
static const union U0 g_962 = {-9L};/* VOLATILE GLOBAL g_962 */
static uint8_t g_973 = 0xD3L;
static int32_t g_984 = 0x2F8C3277L;
static volatile uint64_t g_985 = 0xBD3E356AFC90CCA8LL;/* VOLATILE GLOBAL g_985 */
static volatile union U0 g_994[10][6][4] = {{{{-1L},{-1L},{-8L},{-10L}},{{-1L},{0x059EL},{-1L},{-7L}},{{0x01A4L},{-10L},{-10L},{0x01A4L}},{{1L},{0x09F8L},{0x01A4L},{4L}},{{-8L},{-7L},{0x2F5DL},{-1L}},{{0x673BL},{0x69A2L},{0x9A4FL},{-1L}}},{{{0x09F8L},{-7L},{-1L},{4L}},{{0x059EL},{0x09F8L},{0x059EL},{0x01A4L}},{{0x9A4FL},{-10L},{-1L},{-7L}},{{-1L},{0x059EL},{4L},{-10L}},{{0x9F36L},{-1L},{4L},{0x2F5DL}},{{4L},{0x69A2L},{0x01A4L},{0x01A4L}}},{{{0x673BL},{0x673BL},{1L},{-10L}},{{1L},{-10L},{-8L},{-1L}},{{-1L},{0x9F36L},{0x673BL},{-8L}},{{0L},{0x9F36L},{0x09F8L},{-1L}},{{0x9F36L},{-10L},{0x059EL},{-10L}},{{-7L},{0x673BL},{0x9A4FL},{0x01A4L}}},{{{0x059EL},{0x69A2L},{-1L},{0x2F5DL}},{{0x01A4L},{-1L},{0x9F36L},{0x9A4FL}},{{0x01A4L},{1L},{-1L},{-1L}},{{0x059EL},{0x9A4FL},{0x9A4FL},{0x059EL}},{{-7L},{-1L},{0x059EL},{-1L}},{{0x9F36L},{-1L},{0x09F8L},{4L}}},{{{0L},{0x2F5DL},{0x673BL},{4L}},{{-1L},{-1L},{-8L},{-1L}},{{1L},{-1L},{1L},{0x059EL}},{{0x673BL},{0x9A4FL},{0x01A4L},{-1L}},{{4L},{1L},{-1L},{0x9A4FL}},{{-10L},{-1L},{-1L},{0x2F5DL}}},{{{4L},{0x69A2L},{0x01A4L},{0x01A4L}},{{0x673BL},{0x673BL},{1L},{-10L}},{{1L},{-10L},{-8L},{-1L}},{{-1L},{0x9F36L},{0x673BL},{-8L}},{{0L},{0x9F36L},{0x09F8L},{-1L}},{{0x9F36L},{-10L},{0x059EL},{-10L}}},{{{-7L},{0x673BL},{0x9A4FL},{0x01A4L}},{{0x059EL},{0x69A2L},{-1L},{0x2F5DL}},{{0x01A4L},{-1L},{0x9F36L},{0x9A4FL}},{{0x01A4L},{1L},{-1L},{-1L}},{{0x059EL},{0x9A4FL},{0x9A4FL},{0x059EL}},{{-7L},{-1L},{0x059EL},{-1L}}},{{{0x9F36L},{-1L},{0x09F8L},{4L}},{{0L},{0x2F5DL},{0x673BL},{4L}},{{-1L},{-1L},{-8L},{-1L}},{{1L},{-1L},{1L},{0x059EL}},{{0x673BL},{0x9A4FL},{0x01A4L},{-1L}},{{4L},{1L},{-1L},{0x9A4FL}}},{{{-10L},{-1L},{-1L},{0x2F5DL}},{{4L},{0x69A2L},{0x01A4L},{0x01A4L}},{{0x673BL},{0x673BL},{1L},{-10L}},{{1L},{-10L},{-8L},{-1L}},{{-1L},{0x9F36L},{0x673BL},{-8L}},{{0L},{0x9F36L},{0x09F8L},{-1L}}},{{{0x9F36L},{-10L},{0x059EL},{-10L}},{{-7L},{0x673BL},{0x9A4FL},{0x01A4L}},{{0x059EL},{0x69A2L},{-1L},{0x2F5DL}},{{0x01A4L},{-1L},{0x9F36L},{0x9A4FL}},{{0x01A4L},{1L},{4L},{-8L}},{{1L},{0x673BL},{0x673BL},{1L}}}};
static volatile uint32_t g_1000 = 4294967295UL;/* VOLATILE GLOBAL g_1000 */
static union U0 g_1006 = {0x155FL};/* VOLATILE GLOBAL g_1006 */
static uint8_t *g_1024 = (void*)0;
static uint8_t **g_1023 = &g_1024;
static volatile union U0 g_1026 = {0L};/* VOLATILE GLOBAL g_1026 */
static const union U1 *g_1066[9][7] = {{&g_55,&g_55,(void*)0,&g_55,(void*)0,(void*)0,(void*)0},{&g_55,&g_55,(void*)0,&g_55,&g_55,&g_55,&g_55},{&g_55,&g_55,&g_55,(void*)0,&g_55,(void*)0,&g_55},{(void*)0,&g_55,&g_55,(void*)0,(void*)0,&g_55,(void*)0},{&g_55,&g_55,(void*)0,&g_55,&g_55,(void*)0,&g_55},{&g_55,&g_55,(void*)0,&g_55,&g_55,&g_55,(void*)0},{&g_55,&g_55,&g_55,&g_55,&g_55,&g_55,&g_55},{&g_55,&g_55,&g_55,&g_55,&g_55,(void*)0,&g_55},{&g_55,&g_55,&g_55,&g_55,&g_55,&g_55,(void*)0}};
static const union U1 ** const  volatile g_1065 = &g_1066[8][6];/* VOLATILE GLOBAL g_1065 */
static union U0 g_1068[9] = {{-10L},{-10L},{-10L},{-10L},{-10L},{-10L},{-10L},{-10L},{-10L}};
static volatile union U0 g_1103 = {0x259CL};/* VOLATILE GLOBAL g_1103 */
static volatile union U0 g_1116 = {-1L};/* VOLATILE GLOBAL g_1116 */
static union U0 g_1141 = {-6L};/* VOLATILE GLOBAL g_1141 */
static volatile int64_t ** volatile * volatile *g_1159[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int64_t ** volatile * volatile * const *g_1158 = &g_1159[0];
static int32_t *g_1201[6][1][3] = {{{&g_54,&g_54,&g_54}},{{&g_54,&g_54,&g_54}},{{&g_54,&g_54,&g_54}},{{&g_54,&g_54,&g_54}},{{&g_54,&g_54,&g_54}},{{&g_54,&g_54,&g_54}}};
static int32_t **g_1200 = &g_1201[5][0][0];
static union U0 g_1233[4][7] = {{{1L},{0L},{1L},{-10L},{0L},{1L},{1L}},{{0L},{1L},{1L},{4L},{0xD7A8L},{4L},{1L}},{{0L},{0L},{4L},{0x35F9L},{-7L},{1L},{0L}},{{0x35F9L},{0L},{0x0F54L},{1L},{1L},{0x0F54L},{0L}}};
static union U0 g_1234 = {0xFAE9L};/* VOLATILE GLOBAL g_1234 */
static union U0 g_1235 = {9L};/* VOLATILE GLOBAL g_1235 */
static union U0 g_1236 = {6L};/* VOLATILE GLOBAL g_1236 */
static union U0 g_1237[3] = {{-5L},{-5L},{-5L}};
static union U0 g_1238[4][1][3] = {{{{-1L},{0xA64CL},{0x7BF2L}}},{{{5L},{0xA64CL},{5L}}},{{{0xF4A0L},{-1L},{0x7BF2L}}},{{{0xF4A0L},{0xF4A0L},{-1L}}}};
static union U0 g_1239 = {0x4CEDL};/* VOLATILE GLOBAL g_1239 */
static union U0 g_1240 = {0x6A4BL};/* VOLATILE GLOBAL g_1240 */
static union U0 g_1244 = {0L};/* VOLATILE GLOBAL g_1244 */
static const union U0 * const g_1243 = &g_1244;
static const union U0 * const *g_1242[8] = {&g_1243,&g_1243,&g_1243,&g_1243,&g_1243,&g_1243,&g_1243,&g_1243};
static const union U0 * const **g_1241 = &g_1242[3];
static uint32_t g_1258 = 2UL;
static union U0 g_1291 = {-1L};/* VOLATILE GLOBAL g_1291 */
static int8_t g_1301 = 0xAAL;
static volatile uint32_t g_1302 = 18446744073709551612UL;/* VOLATILE GLOBAL g_1302 */
static volatile int32_t g_1389 = 0x7370BF00L;/* VOLATILE GLOBAL g_1389 */
static volatile int32_t g_1456 = 0L;/* VOLATILE GLOBAL g_1456 */
static int8_t g_1459[3][4][4] = {{{(-1L),0xCDL,0xCDL,(-1L)},{9L,0x13L,0x00L,6L},{0x85L,0xE9L,6L,0x84L},{6L,0x84L,0L,0x84L}},{{0xCDL,0xE9L,1L,6L},{0xAAL,0x13L,0x84L,(-1L)},{1L,0xCDL,0x7EL,0x7EL},{1L,1L,0x84L,9L}},{{0xAAL,0x7EL,1L,0x13L},{0xCDL,0x85L,0L,0x84L},{0x7EL,9L,0x7EL,0xE9L},{9L,0xCDL,0L,0x13L}}};
static volatile uint32_t g_1460 = 0UL;/* VOLATILE GLOBAL g_1460 */
static const union U0 g_1515 = {0xAA8AL};/* VOLATILE GLOBAL g_1515 */
static int16_t g_1532 = 0x1B13L;
static uint64_t g_1537[1] = {0xA6AE1816AB7CEA8ELL};
static volatile union U0 g_1581 = {1L};/* VOLATILE GLOBAL g_1581 */
static int32_t * volatile g_1808 = &g_984;/* VOLATILE GLOBAL g_1808 */
static int32_t g_1824[7][7] = {{0L,(-1L),0L,0L,(-1L),0L,0L},{0x7FF548AAL,0x7FF548AAL,0xF98B7124L,0x7FF548AAL,0x7FF548AAL,0xF98B7124L,0x7FF548AAL},{(-1L),0L,0L,(-1L),0L,0L,(-1L)},{0x6CF11F13L,0x7FF548AAL,0x6CF11F13L,0x6CF11F13L,0x7FF548AAL,0x6CF11F13L,0x6CF11F13L},{(-1L),(-1L),(-4L),(-1L),(-1L),(-4L),(-1L)},{0x7FF548AAL,0x6CF11F13L,0x6CF11F13L,0x7FF548AAL,0x6CF11F13L,0x6CF11F13L,0x7FF548AAL},{0L,(-1L),0L,0L,(-1L),0L,0L}};
static int8_t *g_1847 = (void*)0;
static int8_t **g_1846[10][8][3] = {{{(void*)0,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,(void*)0},{&g_1847,&g_1847,&g_1847}},{{(void*)0,(void*)0,&g_1847},{&g_1847,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847}},{{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,(void*)0}},{{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847}},{{&g_1847,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847}},{{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{(void*)0,&g_1847,&g_1847}},{{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,(void*)0,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847}},{{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,(void*)0},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847}},{{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847}},{{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,(void*)0,&g_1847},{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847},{(void*)0,&g_1847,&g_1847},{&g_1847,&g_1847,&g_1847}}};
static int8_t ***g_1845 = &g_1846[7][4][1];
static int32_t *** const  volatile g_1885 = &g_1200;/* VOLATILE GLOBAL g_1885 */
static volatile union U0 g_1911 = {0xEAD8L};/* VOLATILE GLOBAL g_1911 */
static volatile uint32_t * volatile g_2043[8][5] = {{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460},{&g_1460,&g_1460,&g_1460,&g_1460,&g_1460}};
static volatile uint32_t * volatile *g_2042[2][4][6] = {{{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]}},{{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[5][4],&g_2043[3][2],&g_2043[3][2],&g_2043[5][4],&g_2043[3][2],&g_2043[3][2]},{&g_2043[3][2],&g_2043[5][4],&g_2043[5][4],&g_2043[3][2],&g_2043[5][4],&g_2043[5][4]}}};
static uint32_t *g_2045 = &g_538;
static uint32_t **g_2044 = &g_2045;
static uint64_t g_2088 = 0x89412565373D992BLL;
static uint32_t g_2122 = 0x3B59D833L;
static volatile int32_t g_2167 = 0xAA820DBFL;/* VOLATILE GLOBAL g_2167 */
static int32_t g_2234 = 0x057B62B3L;
static const int32_t *g_2311[4] = {&g_54,&g_54,&g_54,&g_54};
static const int32_t **g_2310 = &g_2311[3];
static const int32_t ***g_2309 = &g_2310;
static volatile int32_t g_2338 = 0x53555F85L;/* VOLATILE GLOBAL g_2338 */
static int16_t **g_2355 = &g_128;
static int16_t ***g_2354 = &g_2355;
static int16_t ****g_2353 = &g_2354;
static int16_t *****g_2352 = &g_2353;
static union U0 g_2376 = {-1L};/* VOLATILE GLOBAL g_2376 */
static union U0 g_2380 = {0xAE75L};/* VOLATILE GLOBAL g_2380 */
static const int64_t g_2551 = 0x7936CBA86939548CLL;
static int32_t *** volatile g_2589 = &g_788;/* VOLATILE GLOBAL g_2589 */
static uint8_t ***g_2592 = (void*)0;
static int32_t ** volatile g_2608 = &g_241;/* VOLATILE GLOBAL g_2608 */
static union U0 g_2610 = {-7L};/* VOLATILE GLOBAL g_2610 */
static union U0 **g_2622 = &g_372;
static union U0 *** volatile g_2621 = &g_2622;/* VOLATILE GLOBAL g_2621 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, uint16_t  p_5);
static uint8_t  func_9(int32_t  p_10);
static int16_t  func_13(uint32_t  p_14, int32_t  p_15, int32_t  p_16, uint64_t  p_17, union U1  p_18);
static uint8_t  func_19(uint32_t  p_20, uint16_t  p_21, int64_t  p_22, int32_t  p_23);
static uint8_t  func_28(int64_t  p_29, union U1  p_30, int32_t  p_31, uint32_t  p_32, uint32_t  p_33);
static int32_t * func_59(const int32_t  p_60, uint8_t  p_61);
static union U0  func_73(uint32_t  p_74);
static int64_t  func_89(uint32_t * p_90, int32_t ** p_91, int16_t * p_92, int32_t ** p_93, int32_t ** p_94);
static uint16_t  func_97(const int32_t ** p_98, uint8_t  p_99, uint32_t * p_100, int32_t * p_101);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_24 g_49 g_53 g_55 g_56 g_50 g_54 g_70 g_71 g_55.f0 g_57 g_79 g_65 g_1141.f2 g_604 g_241 g_79.f1 g_1023 g_1024 g_1241 g_984 g_334 g_133 g_788 g_1258 g_794 g_1243 g_1244 g_262 g_145 g_783 g_706 g_1291 g_240 g_1302 g_326 g_744 g_745 g_605 g_531 g_1103.f1 g_574 g_568 g_187 g_188 g_189 g_186 g_538 g_121 g_321 g_126 g_149 g_768 g_1581 g_70.f1 g_311 g_282 g_310 g_771 g_128 g_129 g_131 g_1233.f0 g_1065 g_1066 g_1532 g_284 g_1460 g_70.f2 g_391 g_392 g_393 g_1845 g_1459 g_1515.f1 g_1885 g_1808 g_766 g_1238.f1 g_1911 g_994.f1 g_235 g_1911.f0 g_1200 g_1201 g_1537 g_2234 g_70.f0 g_374.f1 g_973 g_2309 g_1242 g_1239.f2 g_2352 g_1244.f0 g_522 g_2376 g_2380 g_789 g_2355 g_2353 g_2354 g_743.f1 g_524 g_227 g_1581.f0 g_1158 g_1159 g_2380.f1 g_2122 g_1116.f1 g_2621 g_2589
 * writes: g_49 g_50 g_54 g_56 g_65 g_57 g_1141.f2 g_604 g_334 g_789 g_1258 g_145 g_783 g_1302 g_326 g_386 g_568 g_24 g_282 g_55 g_768 g_1537 g_1459 g_374.f2 g_129 g_133 g_241 g_605 g_126 g_70.f2 g_1200 g_984 g_766 g_149 g_1024 g_1235.f2 g_524 g_235 g_1239.f2 g_574 g_332.f2 g_2309 g_1066 g_1201 g_227 g_531 g_372 g_2088 g_1301 g_2234 g_2622
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_27 = 1L;
    int32_t l_1264 = 0x808924B2L;
    int32_t l_2382 = 0xD87E5537L;
    uint64_t *l_2393 = &g_1537[0];
    int32_t l_2395 = 0x8FCFC1DBL;
    const int32_t l_2396 = 0xAE483D51L;
    int32_t l_2400 = 7L;
    int32_t *l_2404 = &g_706;
    uint64_t l_2406 = 0UL;
    uint32_t l_2415 = 0x6FB9B711L;
    int16_t l_2452 = 0L;
    union U1 l_2518 = {65531UL};
    const int64_t *l_2544[3][9][8] = {{{&g_282[2][3][0],&g_284,&g_311,&g_282[4][2][0],&g_282[4][2][0],&g_311,&g_310,&g_284},{&g_311,&g_310,(void*)0,&g_282[4][2][0],&g_282[4][2][0],&g_310,&g_282[4][1][4],&l_27},{&l_27,&g_282[4][2][0],&g_284,&g_311,&g_284,&g_282[4][2][0],&g_282[4][3][4],(void*)0},{&g_284,&g_311,&g_282[4][2][0],&g_282[0][0][1],&l_27,&g_284,&g_284,(void*)0},{(void*)0,&g_282[4][2][0],&g_282[4][2][0],&g_284,(void*)0,&g_284,&g_282[4][2][0],&g_282[4][2][0]},{&g_284,&g_282[4][2][0],&g_284,&g_310,&l_27,&l_27,&g_311,&g_311},{&g_282[4][3][4],&g_284,&g_311,&g_311,&g_284,&g_282[4][2][0],&g_311,&g_282[4][2][0]},{&g_284,&g_311,&g_284,&l_27,(void*)0,&g_284,&g_282[4][2][0],&g_284},{(void*)0,&g_284,&g_282[4][2][0],&g_284,&g_282[4][1][4],&g_282[4][2][0],&g_284,&g_310}},{{(void*)0,(void*)0,&g_282[4][2][0],&g_282[2][3][0],&g_311,&g_282[4][3][4],&g_282[4][3][4],&g_311},{&g_284,&g_284,&g_284,&g_284,&g_282[4][2][0],&g_284,&g_282[4][1][4],(void*)0},{&g_310,&g_282[4][3][4],(void*)0,&g_310,(void*)0,&g_282[0][0][1],&g_310,&l_27},{&g_282[4][2][0],&g_282[4][3][4],&g_311,&g_282[4][2][0],&g_282[4][2][0],&g_284,&g_284,&g_284},{&g_282[4][2][0],&g_284,&g_311,&g_284,&g_282[4][2][0],&g_282[4][3][4],(void*)0,&g_284},{&g_284,(void*)0,&g_282[3][4][3],&g_282[4][3][4],(void*)0,&g_282[4][2][0],&g_284,&g_282[4][2][0]},{&g_311,&g_284,&g_310,(void*)0,&g_310,&g_284,&g_311,&g_282[3][4][3]},{&l_27,&g_311,&g_282[4][3][4],(void*)0,&g_311,&g_282[4][2][0],&g_284,&g_282[4][2][0]},{&g_311,&g_284,&g_282[4][2][0],&g_282[4][2][0],&g_311,&l_27,&g_282[4][2][0],(void*)0}},{{&l_27,&g_282[4][2][0],(void*)0,&g_282[4][2][0],&g_310,&g_284,(void*)0,&g_311},{&g_311,&g_282[4][2][0],(void*)0,&g_311,(void*)0,&g_284,&l_27,&g_310},{&g_284,&g_311,&g_310,(void*)0,&g_282[4][2][0],&g_282[4][2][0],(void*)0,&g_310},{&g_282[4][2][0],&g_282[4][2][0],&g_282[0][0][1],&g_282[4][3][4],&g_282[4][2][0],&g_310,&g_282[4][2][0],&g_282[4][1][4]},{&g_282[4][2][0],&g_310,&g_282[4][2][0],&g_311,(void*)0,&g_311,&g_282[4][2][0],&g_284},{&g_282[4][2][0],&g_311,(void*)0,&g_284,&g_310,&g_282[4][3][4],&l_27,&g_282[4][2][0]},{(void*)0,&g_284,&l_27,(void*)0,&g_310,&l_27,&g_310,&g_284},{&l_27,&g_282[4][2][0],&g_311,&g_311,&g_284,(void*)0,&g_282[4][2][0],(void*)0},{(void*)0,&g_282[4][2][0],&g_311,&g_282[4][2][0],(void*)0,&g_282[4][2][0],&g_310,&g_284}}};
    const int64_t **l_2543 = &l_2544[1][7][7];
    const int64_t ***l_2542 = &l_2543;
    const int64_t * const l_2550 = &g_2551;
    const int64_t * const *l_2549 = &l_2550;
    const int64_t * const **l_2548 = &l_2549;
    int32_t *l_2587 = (void*)0;
    int32_t l_2634 = 1L;
    int32_t l_2636[1];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2636[i] = 0x275BA9C8L;
    l_2382 &= func_2(((safe_mul_func_int8_t_s_s(((~((func_9(((safe_sub_func_int16_t_s_s(func_13(((func_19(g_24, (safe_rshift_func_uint16_t_u_s(l_27, 10)), g_24, g_24) ^ l_27) , (l_1264 &= (((func_73(l_27) , (safe_lshift_func_int16_t_s_u((g_24 | 0UL), 0))) ^ l_27) && 0UL))), l_27, l_27, l_27, (*g_262)), 0xD543L)) <= 1UL)) <= 0x57L) <= g_531)) , g_1103.f1), l_27)) | l_27), g_574, l_27);
lbl_2642:
    (*g_788) = ((safe_add_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((l_1264 , l_1264) , (g_1302 && (l_2382 & (safe_mul_func_uint8_t_u_u(((((((((l_2395 &= (safe_lshift_func_int16_t_s_u(l_1264, ((safe_sub_func_int16_t_s_s((((l_2393 == l_2393) >= g_24) & (~(((((((**g_2355) == (**g_2355)) , l_1264) ^ l_27) , g_149) & l_1264) > 3L))), (****g_2353))) ^ g_743.f1)))) < l_1264) & 3UL) , l_2395) && 0x10L) && 0x4AL) & l_2382) >= l_27), l_2396))))), 8L)), 0xD3C3A58A6BA49089LL)) , (*g_240));
    for (g_49 = 1; (g_49 <= 4); g_49 += 1)
    { /* block id: 1106 */
        int32_t *l_2397 = &g_227;
        union U1 l_2403 = {0x9EABL};
        int32_t **l_2405 = &l_2404;
        int32_t l_2408 = 0x91FF3D76L;
        int32_t l_2413 = 0xA8D89CB9L;
        int32_t l_2414 = (-10L);
        int32_t * volatile l_2418 = (void*)0;/* VOLATILE GLOBAL l_2418 */
        uint32_t **l_2519 = &g_2045;
        const int64_t * const *l_2546 = &l_2544[1][6][3];
        const int64_t * const **l_2545 = &l_2546;
        uint32_t l_2576[8] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL};
        uint32_t * const l_2611 = &g_235;
        int8_t l_2623 = 3L;
        uint32_t l_2639 = 18446744073709551609UL;
        int i;
        (*g_788) = l_2397;
        if (((l_2400 == ((safe_mod_func_uint32_t_u_u(((0x9F3E7924754EB277LL > g_524) < ((0xE0L <= ((l_1264 <= (((**g_1885) = (void*)0) != (l_2403 , ((*l_2405) = l_2404)))) && 0x61L)) || l_2406)), g_604)) && 0L)) ^ l_27))
        { /* block id: 1110 */
            uint64_t l_2422 = 0xCDB50E1D393F80E7LL;
            int32_t *l_2444 = &g_984;
            union U1 l_2447 = {0x6FC2L};
            int32_t l_2451 = 0x3B26D5D6L;
            const int16_t l_2453 = (-3L);
            int64_t *l_2500[8] = {&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2],&g_282[0][0][2]};
            uint64_t *l_2508 = &g_2088;
            uint64_t *l_2509 = &l_2406;
            int8_t **l_2517 = &g_1847;
            int8_t *l_2520 = (void*)0;
            int8_t *l_2521 = (void*)0;
            int8_t *l_2522 = &g_1301;
            int i;
            if (((**g_794) , ((**g_788) ^= 0x8EBE6EEFL)))
            { /* block id: 1112 */
                uint8_t l_2421 = 0xFDL;
                int64_t ****l_2448 = &g_517;
                int16_t **** const **l_2476 = (void*)0;
                for (g_374.f2 = 0; (g_374.f2 <= 0); g_374.f2 += 1)
                { /* block id: 1115 */
                    int32_t *l_2407 = &l_2400;
                    int32_t *l_2409 = &l_1264;
                    int32_t *l_2410 = &l_2400;
                    int32_t *l_2411 = &l_2382;
                    int32_t *l_2412[7][3] = {{&g_604,&g_984,(void*)0},{&g_984,&g_604,&g_604},{(void*)0,&g_604,&g_1824[1][6]},{(void*)0,&g_984,&l_2382},{(void*)0,(void*)0,&l_2382},{&g_984,(void*)0,&g_1824[1][6]},{&g_604,(void*)0,&g_604}};
                    int i, j;
                    l_2415++;
                    return (*l_2397);
                }
                l_2418 = (l_2415 , (*g_794));
                for (g_126 = 0; (g_126 <= 0); g_126 += 1)
                { /* block id: 1122 */
                    (*g_1065) = &g_55;
                }
                for (g_70.f2 = 0; (g_70.f2 <= 0); g_70.f2 += 1)
                { /* block id: 1127 */
                    uint32_t l_2427 = 0x12491E29L;
                    int32_t *l_2445 = (void*)0;
                    int i;
                    if ((safe_lshift_func_int8_t_s_u(l_2421, l_2422)))
                    { /* block id: 1128 */
                        (*g_240) = (*g_240);
                        return l_2421;
                    }
                    else
                    { /* block id: 1131 */
                        uint16_t *l_2428 = &g_783;
                        uint16_t *l_2429 = &l_2403.f0;
                        int32_t l_2449 = (-1L);
                        int8_t *l_2450 = &g_1459[2][1][2];
                        int32_t *l_2454 = (void*)0;
                        int32_t *l_2455[10] = {&l_2400,&l_2400,&g_604,&l_2400,&l_2400,&g_604,&l_2400,&l_2400,&g_604,&l_2400};
                        uint8_t *l_2477 = &g_531;
                        int i;
                        g_604 |= ((safe_mod_func_int16_t_s_s(l_2422, g_1581.f0)) <= (((((*l_2429) = ((*l_2428) = l_2427)) ^ ((((*l_2444) = (safe_lshift_func_uint8_t_u_u((((l_2395 ^= ((((safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u(0x3303L, (~((safe_div_func_uint32_t_u_u((((safe_sub_func_int8_t_s_s(0x64L, (l_2451 |= ((*l_2450) = (((+(((l_2444 == ((*g_788) = l_2445)) , (!6L)) || ((l_2447 , l_2448) == (*g_1158)))) , l_2449) , l_27))))) ^ (**g_2355)) | 4UL), (*l_2397))) == g_334[5])))), l_2452)), 4294967295UL)) , (****g_2353)) < 0x1589L) & 4UL)) ^ l_2421) == (*l_2397)), 1))) >= l_2427) && l_2453)) <= 0UL) <= 0xAF7CC73EE49CE570LL));
                        (*l_2397) = (safe_div_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u((!(safe_mul_func_uint8_t_u_u(0xEBL, ((*l_2477) = ((*l_2418) = (safe_mul_func_int16_t_s_s(((((*g_321) ^ (*g_56)) != ((((safe_mul_func_uint16_t_u_u((*l_2397), ((safe_rshift_func_uint16_t_u_s((safe_mul_func_int16_t_s_s((safe_unary_minus_func_uint64_t_u((l_2406 , ((void*)0 != &g_1024)))), (safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((**g_2355) = (*g_128)), ((g_771 <= 0x9C94L) | 0L))), 0xC3L)))), (*l_2397))) < (*l_2444)))) , &g_2352) != l_2476) , g_574)) ^ (-8L)), l_2421))))))), g_1532)), (*l_2444)));
                        return (*g_392);
                    }
                }
            }
            else
            { /* block id: 1147 */
                const int32_t l_2488 = 0x85266972L;
                int64_t *l_2489 = &g_282[1][1][0];
                union U0 *l_2501 = &g_374;
                g_372 = (((**g_788) &= (l_27 && (!(safe_add_func_int32_t_s_s((safe_rshift_func_uint16_t_u_s((*l_2444), 3)), (((!((*l_2393) &= (((safe_mul_func_int16_t_s_s((-1L), ((safe_lshift_func_int16_t_s_s(l_2488, (*l_2444))) ^ (l_2489 != ((((*l_2489) = ((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_u(((**g_2355) <= ((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(1UL, 5)), ((safe_rshift_func_uint16_t_u_u(2UL, g_2380.f1)) == l_2488))) != l_2488)), 15)), (**g_2355))) , l_2488)) == l_2488) , l_2500[2]))))) , g_2122) < 0x97C8249DL))) || (*g_128)) || g_1116.f1)))))) , l_2501);
            }
            (**g_788) = (((*l_2522) = (((*g_1200) = func_59((**g_794), (((*g_789) = (((safe_div_func_uint32_t_u_u(g_1537[0], 0x38C1355BL)) || (safe_div_func_int8_t_s_s(l_1264, (*l_2444)))) <= ((((safe_sub_func_uint64_t_u_u(((*l_2508) = g_706), (((*l_2509) &= g_574) , g_771))) ^ (safe_mul_func_int16_t_s_s((((+((safe_sub_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((l_2517 != (void*)0) || (*l_2397)) > (*l_2444)), g_334[7])), l_2395)) && l_2382)) , l_2518) , l_2396), (*l_2397)))) , l_2519) == (void*)0))) | 9UL))) != (void*)0)) >= 253UL);
        }
        else
        { /* block id: 1159 */
            uint8_t l_2523[5][10][5] = {{{4UL,0xB0L,4UL,0x42L,0x5AL},{2UL,0UL,4UL,0x5AL,4UL},{0xB1L,0xCFL,4UL,0xC9L,0x42L},{0xFDL,252UL,4UL,4UL,0xC9L},{1UL,255UL,4UL,0x1FL,0x1FL},{4UL,0xB0L,4UL,0x42L,0x5AL},{2UL,0UL,4UL,0x5AL,4UL},{0xB1L,0xCFL,4UL,0xC9L,0x42L},{0xFDL,252UL,4UL,4UL,0xC9L},{1UL,255UL,4UL,0x1FL,0x1FL}},{{4UL,0xB0L,4UL,0x42L,0x5AL},{2UL,0UL,4UL,0x5AL,4UL},{0xB1L,0xCFL,4UL,0xC9L,0x42L},{0xFDL,252UL,4UL,4UL,0xC9L},{1UL,255UL,4UL,0x1FL,0x1FL},{4UL,0xB0L,4UL,0x42L,0x5AL},{2UL,0UL,4UL,0x5AL,4UL},{0xB1L,0xCFL,4UL,0xC9L,0x42L},{0xFDL,252UL,4UL,4UL,0xC9L},{1UL,255UL,4UL,0x1FL,0x1FL}},{{4UL,0xB0L,4UL,0x42L,0x5AL},{2UL,0UL,4UL,0x5AL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL},{0UL,0x97L,0UL,0xB1L,1UL},{0xBCL,0UL,0UL,1UL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL}},{{0UL,0x97L,0UL,0xB1L,1UL},{0xBCL,0UL,0UL,1UL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL},{0UL,0x97L,0UL,0xB1L,1UL},{0xBCL,0UL,0UL,1UL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL}},{{0UL,0x97L,0UL,0xB1L,1UL},{0xBCL,0UL,0UL,1UL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL},{0UL,0x97L,0UL,0xB1L,1UL},{0xBCL,0UL,0UL,1UL,0xFDL},{255UL,255UL,0UL,2UL,0xB1L},{0x03L,0xDBL,0UL,0xFDL,2UL},{252UL,0x1AL,0UL,4UL,4UL}}};
            int32_t l_2565 = 7L;
            union U1 l_2577 = {65535UL};
            union U0 **l_2620 = &g_372;
            int32_t l_2635 = 4L;
            int32_t l_2637 = 0x945770A4L;
            int32_t l_2638[4][8] = {{0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL},{0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL},{0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL},{0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL,0x44C72F99L,0x571FBC6AL}};
            int i, j, k;
            (*l_2397) |= l_2523[4][1][3];
            for (g_2234 = 1; (g_2234 <= 4); g_2234 += 1)
            { /* block id: 1163 */
                int8_t ***l_2526 = &g_1846[7][4][1];
                uint32_t *l_2527 = (void*)0;
                uint32_t *l_2528 = &g_1235.f2;
                uint32_t *l_2529 = &g_374.f2;
                uint32_t *l_2530 = &g_1237[2].f2;
                uint32_t *l_2531 = (void*)0;
                uint32_t *l_2532 = &g_1234.f2;
                uint32_t *l_2533 = &g_332.f2;
                uint16_t *l_2540 = &g_334[1];
                int32_t l_2541 = (-8L);
                const int64_t * const ***l_2547 = (void*)0;
                const int64_t * const ***l_2552 = &l_2545;
                int8_t *l_2553 = &g_1459[2][1][2];
                int32_t *l_2554[2][1][1];
                uint64_t l_2586 = 0xB61F0D97DA6E296BLL;
                uint64_t l_2619 = 1UL;
                int i, j, k;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 1; k++)
                            l_2554[i][j][k] = &l_2382;
                    }
                }
            }
            if ((*l_2397))
            { /* block id: 1219 */
                (*g_2621) = l_2620;
            }
            else
            { /* block id: 1221 */
                int32_t *l_2624 = &l_2400;
                int32_t *l_2625 = &l_1264;
                int32_t *l_2626 = &g_768;
                int32_t *l_2627 = (void*)0;
                int32_t *l_2628 = &l_2382;
                int32_t *l_2629 = (void*)0;
                int32_t *l_2630[6];
                uint16_t l_2631[2][1][1];
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_2630[i] = &l_2408;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 1; k++)
                            l_2631[i][j][k] = 0xEB74L;
                    }
                }
                if ((***g_2589))
                    break;
                ++l_2631[0][0][0];
                (*g_788) = (void*)0;
                ++l_2639;
            }
        }
    }
    if (g_24)
        goto lbl_2642;
    return (**g_391);
}


/* ------------------------------------------ */
/* 
 * reads : g_568 g_24 g_187 g_188 g_189 g_334 g_604 g_79 g_57 g_65 g_241 g_79.f1 g_1023 g_1024 g_1241 g_984 g_133 g_788 g_1258 g_794 g_56 g_1243 g_1244 g_186 g_262 g_538 g_121 g_55.f0 g_321 g_126 g_149 g_768 g_240 g_1581 g_70.f1 g_311 g_50 g_282 g_310 g_771 g_128 g_129 g_131 g_1233.f0 g_55 g_1065 g_1066 g_605 g_1532 g_284 g_1460 g_70.f2 g_391 g_392 g_393 g_1845 g_1459 g_49 g_1515.f1 g_1885 g_1808 g_766 g_1238.f1 g_1911 g_994.f1 g_235 g_1911.f0 g_1200 g_1201 g_1537 g_2234 g_744 g_745 g_574 g_70.f0 g_374.f1 g_973 g_2309 g_1242 g_1239.f2 g_2352 g_1244.f0 g_522 g_2376 g_2380 g_789
 * writes: g_386 g_568 g_24 g_282 g_54 g_65 g_57 g_50 g_1141.f2 g_604 g_49 g_334 g_789 g_1258 g_55 g_768 g_1537 g_1459 g_374.f2 g_129 g_133 g_241 g_605 g_126 g_70.f2 g_1200 g_984 g_766 g_149 g_1024 g_1235.f2 g_524 g_235 g_1239.f2 g_574 g_332.f2 g_2309 g_1066
 */
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, uint16_t  p_5)
{ /* block id: 642 */
    union U0 **l_1310 = &g_372;
    union U0 ***l_1309 = &l_1310;
    union U0 ****l_1311[2];
    int32_t l_1366 = 0L;
    uint32_t l_1394[6];
    int32_t l_1448[3][8];
    const uint8_t l_1503 = 0xB7L;
    int32_t *l_1507 = &g_766;
    int64_t **l_1529 = &g_519;
    int32_t l_1535 = 0xA8DBFA37L;
    union U1 l_1630 = {65530UL};
    int16_t **l_1682 = (void*)0;
    int16_t ***l_1681[5];
    int8_t *l_1692 = (void*)0;
    int64_t l_1835 = 0x527C3E3745646DFFLL;
    union U1 **l_1883 = (void*)0;
    uint8_t l_1899 = 0x75L;
    uint32_t l_2105 = 9UL;
    int32_t ** const *l_2143 = &g_1200;
    int32_t l_2195 = 0xA0C14D0AL;
    uint16_t l_2226 = 1UL;
    int16_t l_2246 = 6L;
    uint8_t l_2252 = 255UL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_1311[i] = &g_386;
    for (i = 0; i < 6; i++)
        l_1394[i] = 4294967295UL;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
            l_1448[i][j] = 0xA3C67E5BL;
    }
    for (i = 0; i < 5; i++)
        l_1681[i] = &l_1682;
    if (((g_386 = l_1309) == (void*)0))
    { /* block id: 644 */
        int64_t l_1335 = 0x0283B20AAF837979LL;
        int64_t l_1355 = 0x6AD5D9868BAC8D2FLL;
        int32_t *l_1404 = (void*)0;
        int32_t l_1457 = (-2L);
        int32_t l_1458 = 0x52167AAFL;
        union U1 **l_1499[7][7] = {{&g_262,&g_262,&g_262,&g_262,(void*)0,(void*)0,(void*)0},{&g_262,&g_262,&g_262,&g_262,(void*)0,&g_262,&g_262},{&g_262,&g_262,&g_262,&g_262,&g_262,(void*)0,&g_262},{&g_262,&g_262,(void*)0,&g_262,&g_262,&g_262,&g_262},{&g_262,&g_262,&g_262,(void*)0,&g_262,&g_262,&g_262},{&g_262,(void*)0,(void*)0,(void*)0,(void*)0,&g_262,(void*)0},{&g_262,(void*)0,&g_262,&g_262,&g_262,&g_262,&g_262}};
        int32_t l_1533 = 0L;
        int32_t l_1536 = (-8L);
        int32_t * const l_1568 = &g_57;
        int i, j;
        for (g_568 = 7; (g_568 >= 0); g_568 -= 1)
        { /* block id: 647 */
            uint64_t *l_1312[7][5] = {{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24},{&g_24,&g_24,&g_24,&g_24,&g_24}};
            int8_t *l_1331 = &g_145;
            int8_t **l_1330 = &l_1331;
            int32_t l_1332[7][6] = {{1L,0x1F721679L,0x940DB1E5L,0L,0xE1D05D3FL,5L},{0xE1D05D3FL,7L,1L,7L,0xE1D05D3FL,(-1L)},{5L,0x1F721679L,0L,0xA26C7E84L,7L,0x940DB1E5L},{0x940DB1E5L,0x6F795256L,0x1F721679L,0x1F721679L,0x6F795256L,0x940DB1E5L},{0xA26C7E84L,0L,0L,0xE1D05D3FL,0x940DB1E5L,(-1L)},{0x6F795256L,5L,1L,0x940DB1E5L,1L,5L},{0x6F795256L,(-1L),0x940DB1E5L,0xE1D05D3FL,0L,0L}};
            int8_t *l_1333[10][4][2] = {{{&g_1301,(void*)0},{&g_145,&g_145},{&g_145,&g_145},{&g_145,(void*)0}},{{&g_1301,&g_1301},{&g_145,&g_145},{&g_1301,&g_145},{&g_1301,&g_145}},{{&g_1301,&g_145},{&g_1301,&g_145},{&g_145,&g_1301},{&g_1301,(void*)0}},{{&g_145,&g_145},{&g_145,&g_145},{&g_145,(void*)0},{&g_1301,&g_1301}},{{&g_145,&g_145},{&g_1301,&g_145},{&g_1301,&g_145},{&g_1301,&g_145}},{{&g_1301,&g_145},{&g_145,&g_1301},{&g_1301,(void*)0},{&g_145,&g_145}},{{&g_145,&g_145},{&g_145,(void*)0},{&g_1301,&g_1301},{&g_145,&g_145}},{{&g_1301,&g_145},{&g_1301,&g_145},{&g_1301,&g_145},{&g_1301,&g_145}},{{&g_145,&g_1301},{&g_1301,(void*)0},{&g_145,&g_145},{&g_145,&g_145}},{{&g_145,(void*)0},{&g_1301,&g_1301},{&g_145,&g_145},{&g_1301,&g_145}}};
            int64_t *l_1334 = &g_282[3][2][4];
            int32_t l_1336 = 0xCAAF5770L;
            int i, j, k;
            l_1336 &= (((g_24--) != (func_73((((safe_sub_func_int16_t_s_s((**g_187), g_334[1])) , (((safe_div_func_int64_t_s_s((-5L), ((safe_sub_func_uint8_t_u_u((p_5 != (safe_mul_func_int8_t_s_s((safe_div_func_int64_t_s_s(((*l_1334) = (((((l_1332[6][3] = (safe_rshift_func_uint16_t_u_s((p_3 == (&g_744 != &g_744)), ((safe_unary_minus_func_int32_t_s(((&g_1301 != ((*l_1330) = (void*)0)) <= 0L))) == l_1332[1][5])))) ^ 250UL) ^ g_604) != 0xC343F8313D40C91BLL) > 2UL)), l_1335)), p_3))), 0x72L)) ^ p_5))) , 6UL) , 0x0C8331A0305FA3B2LL)) != 18446744073709551615UL)) , 18446744073709551610UL)) & p_4);
        }
        for (p_5 = 0; (p_5 <= 7); p_5 += 1)
        { /* block id: 656 */
            union U1 l_1343 = {0x7A8AL};
            union U1 l_1350 = {0x7D2FL};
            int32_t l_1445 = 0x8C253FFBL;
            int32_t l_1449[10] = {2L,(-8L),(-3L),1L,(-8L),(-8L),1L,(-3L),1L,(-8L)};
            uint8_t l_1450 = 254UL;
            int32_t * const l_1491 = &g_568;
            uint64_t l_1665 = 0x67BF6C216D654078LL;
            int32_t l_1673[6];
            int i;
            for (i = 0; i < 6; i++)
                l_1673[i] = 0x5EB1C00DL;
            p_3 ^= (((safe_sub_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_div_func_int64_t_s_s(((***g_186) ^ (l_1343 , ((safe_add_func_int64_t_s_s((safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(p_4, (((*g_262) = l_1350) , ((((void*)0 == &g_334[1]) == 0x8AA5C65FL) , (safe_lshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(p_5, 5)), 5)))))), (g_538 == l_1343.f0))), l_1335)) , l_1355))), l_1335)), 0)), g_121)) <= l_1350.f0) | l_1355);
            for (g_768 = 7; (g_768 >= 0); g_768 -= 1)
            { /* block id: 661 */
                int8_t **l_1397 = (void*)0;
                int32_t l_1440 = 0x65ACFC6EL;
                int32_t l_1443 = 0xE4DAB059L;
                int32_t l_1444 = 9L;
                int32_t l_1446[4] = {0x3C39EF90L,0x3C39EF90L,0x3C39EF90L,0x3C39EF90L};
                int64_t l_1455 = 0L;
                union U1 **l_1498 = &g_262;
                uint32_t *l_1523 = &g_1244.f2;
                int32_t *l_1540 = &l_1449[9];
                union U0 *l_1562 = (void*)0;
                int32_t l_1567 = 0x77C02034L;
                int i;
                (*g_788) = &p_3;
            }
            for (g_55.f0 = 0; (g_55.f0 <= 7); g_55.f0 += 1)
            { /* block id: 735 */
                int32_t l_1570 = 0x26BBAFD5L;
                uint64_t *l_1579 = &g_1537[0];
                int32_t l_1584 = 4L;
                int8_t *l_1601 = (void*)0;
                int8_t *l_1602 = (void*)0;
                int8_t *l_1603 = &g_1459[2][1][2];
                uint32_t *l_1604 = &g_374.f2;
                int i;
                if ((*g_321))
                    break;
                (**g_240) = ((1L & p_5) > (((l_1450 > (((l_1570 && (safe_mod_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_u(l_1449[9], 4)), ((safe_lshift_func_int8_t_s_u(g_149, 7)) && ((*l_1579) = 0x671C4641EE9786CCLL)))), g_768))) , (p_5 ^ l_1449[9])) && 0x1CD180BED7F2B775LL)) > p_4) , g_24));
                p_3 = (~(((*l_1604) = ((g_1581 , ((safe_div_func_int8_t_s_s(((*l_1568) &= (l_1584 , g_70.f1)), (safe_mul_func_uint16_t_u_u(0x48F7L, ((safe_rshift_func_int8_t_s_u(((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s(((*l_1603) = (safe_mod_func_int32_t_s_s(((((0UL <= (((g_334[p_5] = ((((((safe_add_func_int32_t_s_s(l_1366, l_1584)) < (safe_sub_func_int64_t_s_s((safe_mod_func_uint32_t_u_u(g_604, ((((-1L) && l_1350.f0) >= 0xDBL) | p_3))), p_4))) >= 0xADEAD952598055F0LL) | (-1L)) <= l_1394[1]) > p_4)) >= 65533UL) < 0xB42EL)) , p_4) > p_4) & 1L), g_311))), l_1584)), 8)) , l_1570), 5)) > 0x944220081A73409BLL))))) == p_4)) ^ 0x570EAB31L)) == p_4));
                for (g_50 = 0; (g_50 <= 4); g_50 += 1)
                { /* block id: 746 */
                    uint16_t *l_1614[5][4][5] = {{{(void*)0,&g_524,&g_334[5],&g_783,&g_783},{&l_1343.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1343.f0,&g_524,&g_524,&g_783,&g_149},{&l_1343.f0,&l_1343.f0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_524,&g_334[5],&g_783,&g_783},{&l_1343.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1343.f0,&g_524,&g_524,&g_783,&g_149},{&l_1343.f0,&l_1343.f0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_524,&g_334[5],&g_783,&g_783},{&l_1343.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1343.f0,&g_524,&g_524,&g_783,&g_149},{&l_1343.f0,&l_1343.f0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_524,&g_334[5],&g_783,&g_783},{&l_1343.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1343.f0,&g_524,&g_524,&g_783,&g_149},{&l_1343.f0,&l_1343.f0,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_524,&g_334[5],&g_783,&g_783},{&l_1343.f0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1343.f0,&g_524,&g_524,&g_783,&g_149},{&l_1343.f0,&l_1343.f0,(void*)0,(void*)0,(void*)0}}};
                    int16_t *l_1624[8][3][1] = {{{&g_65},{&g_1532},{&g_65}},{{&g_1532},{&g_65},{&g_1532}},{{&g_65},{&g_1532},{&g_65}},{{&g_1532},{&g_65},{&g_1532}},{{&g_65},{&g_1532},{&g_65}},{{&g_1532},{&g_65},{&g_1532}},{{&g_65},{&g_1532},{&g_65}},{{&g_1532},{&g_65},{&g_1532}}};
                    int32_t * const *l_1659 = &g_789;
                    int i, j, k;
                    if (g_282[g_50][g_50][g_50])
                        break;
                    if (g_282[g_50][g_50][g_50])
                        break;
                    if (((!(safe_add_func_int8_t_s_s((safe_div_func_int64_t_s_s(l_1570, (((g_65 = (safe_mod_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u(((*l_1604) = ((l_1584 = l_1449[7]) & (g_133 |= (((*g_131) = ((+(safe_div_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((0x14267A03L != (((safe_div_func_int8_t_s_s(g_310, 255UL)) & (p_3 <= ((safe_div_func_int8_t_s_s(p_5, g_771)) && (*g_188)))) , g_282[4][2][0])), 14)), (*g_128)))) , (**g_187))) == l_1350.f0)))), p_3)) == 0x59F6E96EL), (**g_240)))) | g_604) , g_1233[1][1].f0))), l_1570))) && 0xBAE9L))
                    { /* block id: 754 */
                        int32_t *l_1625 = &l_1366;
                        int i, j;
                        (*l_1625) = ((*l_1568) = l_1394[3]);
                        (*g_240) = func_59(p_5, (safe_rshift_func_int16_t_s_s(((((*g_262) , &g_745[0]) == (void*)0) != (((safe_div_func_int64_t_s_s((l_1630 , ((safe_lshift_func_int8_t_s_u((1L >= (safe_lshift_func_int8_t_s_u((+(*g_321)), (((*l_1568) = ((safe_add_func_uint64_t_u_u((((*g_1065) != (void*)0) == p_3), 18446744073709551607UL)) , (-7L))) && g_334[1])))), 7)) == 0xFDL)), 18446744073709551610UL)) , p_3) != g_282[g_50][g_50][g_50])), 0)));
                        return (**g_794);
                    }
                    else
                    { /* block id: 760 */
                        uint64_t l_1652 = 0x445FC3484A347F39LL;
                        int32_t l_1670 = (-6L);
                        int32_t *l_1671 = &g_126;
                        int32_t *l_1672[10];
                        int i;
                        for (i = 0; i < 10; i++)
                            l_1672[i] = &l_1536;
                        (**g_240) = (g_1233[1][1].f0 <= ((safe_unary_minus_func_uint16_t_u(0x161BL)) == (((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint16_t_u(((safe_mod_func_int32_t_s_s(((l_1448[0][0] , ((safe_mod_func_uint8_t_u_u(((safe_sub_func_int64_t_s_s(((safe_rshift_func_uint8_t_u_u(((-3L) ^ (0xAC41D45BL == (-2L))), (g_605 ^= 0x9FL))) < (safe_add_func_int8_t_s_s(0L, (((g_1532 > 0L) && l_1448[2][3]) != g_984)))), p_3)) | p_3), g_284)) ^ p_3)) & p_5), g_282[1][0][2])) || p_3))), p_3)) , p_5) || l_1652)));
                        l_1673[0] &= ((safe_mul_func_int8_t_s_s(((((*l_1579) = ((((((safe_add_func_int8_t_s_s((l_1659 == (g_605 , &g_241)), (l_1445 &= 0x0DL))) ^ 4294967295UL) <= ((*l_1671) = ((+((safe_div_func_uint64_t_u_u(1UL, (safe_rshift_func_int8_t_s_u(((((l_1665 && (safe_mod_func_int8_t_s_s((safe_div_func_int32_t_s_s(((l_1670 = 0x0BFFL) | ((*l_1568) = ((*g_131) = l_1450))), (-1L))), (-1L)))) > p_5) ^ 0xECL) != p_3), p_3)))) | g_1460)) >= 4UL))) >= p_5) && l_1449[9]) >= 0x5DEAF9D4C6BFED79LL)) >= p_3) <= p_3), l_1584)) || (***g_186));
                    }
                    if (p_4)
                        continue;
                }
            }
        }
    }
    else
    { /* block id: 775 */
        uint32_t l_1675 = 0x77E234EDL;
        int16_t ***l_1683 = &l_1682;
        int8_t * const l_1693 = &g_1459[2][1][3];
        int16_t * const ***l_1697 = (void*)0;
        int32_t l_1723 = (-1L);
        const uint8_t l_1735[8] = {0xF1L,0UL,0xF1L,0UL,0xF1L,0UL,0xF1L,0UL};
        int64_t ****l_1751[4][3][6] = {{{&g_517,(void*)0,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517}},{{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,(void*)0,&g_517,&g_517,&g_517,&g_517}},{{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,(void*)0,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517}},{{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517},{&g_517,&g_517,&g_517,&g_517,&g_517,&g_517}}};
        int64_t *****l_1750[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t l_1768 = 0xF9447463L;
        int32_t l_1816 = (-8L);
        int32_t l_1821 = 4L;
        int32_t l_1823 = 0L;
        union U1 l_1864 = {0x17F4L};
        uint64_t l_1917 = 18446744073709551610UL;
        uint64_t l_1921[10] = {0x56FC12A899EDC84ALL,18446744073709551615UL,0x410504EEE339F076LL,0x410504EEE339F076LL,18446744073709551615UL,0x56FC12A899EDC84ALL,18446744073709551615UL,0x410504EEE339F076LL,0x410504EEE339F076LL,18446744073709551615UL};
        int i, j, k;
        if (((*g_241) &= (+l_1675)))
        { /* block id: 777 */
            int64_t l_1679 = 0xC7B559D87B137957LL;
            int32_t l_1680 = 0x246BAD34L;
            int16_t ****l_1684 = (void*)0;
            int16_t ****l_1685 = &l_1683;
            uint32_t l_1717 = 1UL;
            int32_t l_1725 = 1L;
            union U1 l_1794 = {0xECFEL};
            int64_t ***l_1802[4][9][5] = {{{&g_518,&l_1529,(void*)0,&g_518,&g_518},{&l_1529,&g_518,&g_518,&l_1529,&g_518},{&g_518,&l_1529,&l_1529,&l_1529,&g_518},{&g_518,&l_1529,&l_1529,&l_1529,&l_1529},{&l_1529,&l_1529,&g_518,&l_1529,&l_1529},{&g_518,&l_1529,&g_518,&l_1529,&g_518},{&l_1529,&g_518,&g_518,(void*)0,&g_518},{(void*)0,&l_1529,(void*)0,&l_1529,&l_1529},{&g_518,&l_1529,&g_518,&g_518,&g_518}},{{&g_518,&l_1529,&g_518,(void*)0,&g_518},{&g_518,&g_518,&g_518,&g_518,&l_1529},{(void*)0,&g_518,&g_518,&g_518,&l_1529},{&l_1529,&l_1529,&l_1529,&g_518,&g_518},{&g_518,&g_518,&l_1529,&g_518,&g_518},{&l_1529,(void*)0,&l_1529,&g_518,&g_518},{&l_1529,&g_518,&l_1529,&g_518,&g_518},{(void*)0,&g_518,(void*)0,(void*)0,&g_518},{&g_518,&l_1529,(void*)0,&g_518,(void*)0}},{{&l_1529,&g_518,(void*)0,&l_1529,&l_1529},{&g_518,&g_518,(void*)0,(void*)0,(void*)0},{(void*)0,&g_518,(void*)0,&l_1529,&l_1529},{&l_1529,&g_518,&l_1529,&l_1529,&g_518},{&g_518,(void*)0,&l_1529,&l_1529,&g_518},{(void*)0,&g_518,&l_1529,&l_1529,&l_1529},{&g_518,&g_518,&l_1529,&l_1529,&l_1529},{&g_518,(void*)0,&g_518,&g_518,&l_1529},{(void*)0,&g_518,&g_518,&g_518,&g_518}},{{&l_1529,&g_518,&g_518,&g_518,&g_518},{&l_1529,&g_518,&g_518,&l_1529,(void*)0},{&g_518,&g_518,(void*)0,&l_1529,&l_1529},{&g_518,&g_518,&l_1529,(void*)0,&g_518},{&g_518,&l_1529,&g_518,&g_518,(void*)0},{&l_1529,&l_1529,&g_518,&l_1529,(void*)0},{&g_518,&g_518,&g_518,&g_518,&l_1529},{&g_518,&l_1529,&g_518,(void*)0,&l_1529},{&l_1529,(void*)0,&l_1529,&l_1529,(void*)0}}};
            int32_t l_1817 = 0x0AA7DC7EL;
            int32_t l_1820 = 0x01828752L;
            int32_t l_1822 = 1L;
            uint8_t l_1828[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
            int i, j, k;
            (*g_241) = (safe_sub_func_int64_t_s_s(((+l_1679) || ((l_1680 = p_3) != (p_5 || (l_1681[2] == ((*l_1685) = l_1683))))), ((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(l_1503, (safe_add_func_int32_t_s_s((((*g_188) || (l_1692 != l_1693)) == 0x2DL), 0x6492E3CFL)))), 0x2D5CF57FL)) == p_3)));
            for (g_70.f2 = 1; (g_70.f2 <= 6); g_70.f2 += 1)
            { /* block id: 783 */
                union U1 l_1694 = {0x246BL};
                int16_t * const ****l_1698[8][9] = {{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,(void*)0,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,(void*)0,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,&l_1697},{&l_1697,&l_1697,&l_1697,&l_1697,&l_1697,(void*)0,&l_1697,&l_1697,&l_1697}};
                int32_t l_1720 = 0x7202168AL;
                int32_t l_1721 = 0xCDB5D616L;
                uint8_t l_1727 = 0x94L;
                const union U0 * const **l_1733[5];
                const int64_t *l_1749 = &g_284;
                const int64_t **l_1748 = &l_1749;
                const int64_t ***l_1747 = &l_1748;
                const int64_t ****l_1746 = &l_1747;
                const int64_t *****l_1745 = &l_1746;
                int i, j;
                for (i = 0; i < 5; i++)
                    l_1733[i] = (void*)0;
            }
        }
        else
        { /* block id: 854 */
            uint16_t l_1856 = 3UL;
            int32_t l_1876 = (-1L);
            int8_t l_1877 = 0x11L;
            uint16_t *l_1900 = (void*)0;
            uint16_t *l_1901 = &g_149;
            uint8_t *l_1902[7][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,&g_605},{&g_605,&g_531,&g_605,&g_531,&g_605},{(void*)0,&g_531,(void*)0,&g_605,(void*)0},{(void*)0,(void*)0,&g_605,&g_605,&g_605},{&g_531,(void*)0,(void*)0,&g_531,(void*)0},{&g_531,&g_605,(void*)0,(void*)0,&g_605},{(void*)0,(void*)0,(void*)0,&g_605,&g_605}};
            uint32_t *l_1903 = &g_1235.f2;
            int32_t *l_1904 = (void*)0;
            int i, j;
            for (g_768 = 0; (g_768 == 2); g_768++)
            { /* block id: 857 */
                int16_t **l_1838 = &g_131;
                int32_t l_1850 = 0x4EAF110FL;
                (*l_1683) = l_1838;
                (*g_241) &= ((-1L) < ((**g_391) , (safe_rshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_u((((((*l_1693) |= ((safe_mul_func_uint8_t_u_u(((((void*)0 != g_1845) ^ (safe_mul_func_int8_t_s_s((l_1850 && 0xA400CA6E7FE722FDLL), l_1448[0][6]))) , (((l_1394[1] != (safe_unary_minus_func_uint8_t_u(l_1735[5]))) , l_1850) > l_1394[4])), (-1L))) && l_1823)) <= 0x5BL) != 1L) < l_1723), 12)), 13))));
                for (g_49 = (-22); (g_49 > 2); g_49++)
                { /* block id: 863 */
                    uint32_t l_1878[2];
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1878[i] = 4294967290UL;
                    for (l_1823 = 0; (l_1823 <= (-19)); l_1823 = safe_sub_func_int64_t_s_s(l_1823, 1))
                    { /* block id: 866 */
                        int8_t l_1863 = 1L;
                        int32_t *l_1867 = &l_1816;
                        int32_t *l_1868 = (void*)0;
                        int32_t *l_1869 = &g_984;
                        int32_t *l_1870 = &g_1824[0][6];
                        int32_t *l_1871 = &g_1824[1][6];
                        int32_t *l_1872 = &g_126;
                        int32_t *l_1873 = &g_126;
                        int32_t *l_1874 = (void*)0;
                        int32_t *l_1875[8][1][7] = {{{&g_1824[6][0],&g_1824[6][0],(void*)0,&g_1824[6][0],&g_1824[6][0],(void*)0,&g_1824[6][0]}},{{&g_1824[6][0],&g_227,&g_227,&g_1824[6][0],&g_227,&g_227,&g_1824[6][0]}},{{&g_227,&g_1824[6][0],&g_227,&g_227,&g_1824[6][0],&g_227,&g_227}},{{&g_1824[6][0],&g_1824[6][0],(void*)0,&g_1824[6][0],&g_1824[6][0],(void*)0,&g_1824[6][0]}},{{&g_1824[6][0],&g_227,&g_227,&g_1824[6][0],&g_227,&g_227,&g_1824[6][0]}},{{&g_227,&g_1824[6][0],&g_227,&g_227,&g_1824[6][0],&g_227,&g_227}},{{&g_1824[6][0],&g_1824[6][0],(void*)0,&g_1824[6][0],&g_227,&g_1824[6][0],&g_227}},{{&g_227,(void*)0,(void*)0,&g_227,(void*)0,(void*)0,&g_227}}};
                        union U1 ***l_1884 = &l_1883;
                        int i, j, k;
                        (*g_241) ^= ((0x312C2A02C96A5959LL ^ (((l_1856 == ((p_5 > l_1856) == (safe_mul_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u(l_1448[0][0], (p_4 <= (safe_lshift_func_int16_t_s_u(l_1863, (l_1864 , (safe_div_func_uint64_t_u_u(0xEBD294DBCA1CA935LL, g_1515.f1)))))))) <= l_1448[0][0]), p_3)))) & p_3) <= p_5)) != p_5);
                        ++l_1878[0];
                        (*g_241) = (safe_rshift_func_int16_t_s_u(((-1L) && (((*l_1884) = l_1883) == &g_262)), 0));
                    }
                }
                (*g_1885) = &g_1201[5][0][0];
            }
            for (g_568 = 0; (g_568 <= 23); g_568 = safe_add_func_int8_t_s_s(g_568, 4))
            { /* block id: 877 */
                int32_t *l_1888[5][6] = {{&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2]},{&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2]},{&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2]},{&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2]},{&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2],&g_1824[2][2]}};
                int i, j;
                (**g_240) = ((*g_1808) |= (**g_240));
                for (l_1768 = 0; (l_1768 <= (-24)); l_1768--)
                { /* block id: 882 */
                    uint64_t l_1891 = 18446744073709551615UL;
                    --l_1891;
                    if (p_4)
                        break;
                    for (g_374.f2 = 0; g_374.f2 < 6; g_374.f2 += 1)
                    {
                        l_1394[g_374.f2] = 6UL;
                    }
                }
            }
            for (g_766 = 0; (g_766 > (-22)); g_766 = safe_sub_func_int8_t_s_s(g_766, 5))
            { /* block id: 890 */
                return p_3;
            }
            l_1448[1][0] |= (!((safe_mul_func_uint16_t_u_u((p_5 = ((*g_241) , ((*l_1901) = l_1899))), ((p_3 > ((((((*g_1023) = l_1902[3][4]) == &l_1503) >= (((((*l_1903) = ((void*)0 != &l_1683)) == ((l_1366 != ((l_1675 && l_1503) , 18446744073709551614UL)) <= l_1876)) , l_1823) > l_1768)) <= p_3) == 4L)) ^ g_1238[2][0][2].f1))) || 18446744073709551610UL));
        }
        if ((((safe_mod_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u(((l_1823 = (l_1503 | l_1816)) <= (safe_mul_func_int8_t_s_s((g_1911 , (p_3 & (safe_mod_func_uint64_t_u_u((((void*)0 == &g_186) <= (l_1864.f0 | (p_5 || 0xAD65F9E8L))), (**g_391))))), p_4))), l_1394[3])), g_284)) < p_5) <= l_1816))
        { /* block id: 900 */
            uint8_t *l_1916[1];
            int16_t l_1920 = (-2L);
            uint64_t *l_1922[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int32_t *l_1923 = &g_57;
            int i;
            for (i = 0; i < 1; i++)
                l_1916[i] = &g_121;
            l_1923 = func_59((l_1503 != (safe_div_func_int16_t_s_s((-1L), ((0L != ((l_1723 = ((void*)0 != &l_1899)) <= l_1917)) | ((l_1448[0][0] = (safe_add_func_uint32_t_u_u(l_1920, (l_1921[7] != (-9L))))) > l_1920))))), l_1768);
        }
        else
        { /* block id: 904 */
            uint64_t *l_1929[1];
            uint16_t *l_1932 = &g_55.f0;
            int16_t *l_1951[9] = {(void*)0,(void*)0,&g_1532,(void*)0,(void*)0,&g_1532,(void*)0,(void*)0,&g_1532};
            int32_t l_1954 = 0x548E2809L;
            uint16_t *l_1955 = &g_149;
            int i;
            for (i = 0; i < 1; i++)
                l_1929[i] = &l_1917;
            (*g_240) = func_59(p_4, ((((safe_lshift_func_uint16_t_u_u(65535UL, (g_524 = (safe_add_func_uint16_t_u_u((3L & (l_1366 |= (!(0x95L < 255UL)))), ((*l_1955) = (safe_div_func_uint32_t_u_u(((l_1768 = (((*l_1932)--) & (safe_sub_func_int64_t_s_s((l_1954 = (p_5 < (safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(((safe_mod_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((((((((safe_mod_func_int16_t_s_s((((safe_add_func_uint32_t_u_u(((l_1951[8] = l_1932) != (void*)0), (safe_mod_func_uint64_t_u_u(((g_994[8][4][2].f1 & l_1954) , 0x5A63B1C3B1552078LL), p_5)))) > p_5) & 0x79L), (*g_128))) , p_4) <= 18446744073709551615UL) || p_5) | p_5) | l_1835) || 4294967286UL), (*g_131))), (*g_128))), 4UL)) >= p_3), (**g_240))), 9L)))), g_334[1])))) != 0L), p_3)))))))) != (*g_131)) && p_4) && p_3));
        }
    }
    for (l_1366 = 2; (l_1366 >= 0); l_1366 -= 1)
    { /* block id: 917 */
        uint64_t l_1956 = 0x5856DEDF6C28BEADLL;
        int8_t ***l_2003 = (void*)0;
        int64_t *** const *l_2021 = &g_517;
        int64_t *** const **l_2020 = &l_2021;
        int32_t *l_2022 = &g_57;
        int32_t l_2031[2][5];
        const int16_t *l_2033 = &g_522;
        int8_t **l_2063 = (void*)0;
        int16_t ****l_2113 = &l_1681[2];
        int16_t *****l_2112 = &l_2113;
        const int32_t *l_2142 = &g_771;
        const int32_t **l_2141 = &l_2142;
        const int32_t ***l_2140 = &l_2141;
        uint32_t *l_2196 = (void*)0;
        uint32_t *l_2197 = (void*)0;
        uint32_t *l_2198 = (void*)0;
        uint32_t *l_2199 = (void*)0;
        uint32_t *l_2200 = &g_1141.f2;
        uint32_t *l_2201 = (void*)0;
        uint32_t *l_2202 = &g_235;
        union U1 l_2205 = {0x806BL};
        uint64_t *l_2216[2];
        int64_t l_2217 = 0xDA146C183B6CAD72LL;
        int32_t l_2245 = (-10L);
        int32_t ***l_2327 = &g_1200;
        int16_t * const ****l_2357 = (void*)0;
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 5; j++)
                l_2031[i][j] = 0xE89551B7L;
        }
        for (i = 0; i < 2; i++)
            l_2216[i] = &g_1537[0];
        if (l_1956)
            break;
        for (g_50 = 0; (g_50 <= 0); g_50 += 1)
        { /* block id: 921 */
            int16_t l_1970 = 0x4199L;
            int8_t *l_1976 = &g_1459[0][3][3];
            int32_t l_2011[8] = {0x28DD06E8L,0x16593770L,0x28DD06E8L,0x16593770L,0x28DD06E8L,0x16593770L,0x28DD06E8L,0x16593770L};
            union U1 **l_2075 = &g_262;
            int16_t ****l_2111 = (void*)0;
            int16_t *****l_2110 = &l_2111;
            int32_t *l_2146 = &g_766;
            int32_t ** const l_2145 = &l_2146;
            int32_t ** const *l_2144 = &l_2145;
            uint64_t l_2181 = 18446744073709551611UL;
            int i;
        }
        (*l_2022) |= (l_1503 || 0L);
        (*g_241) = (((((((*l_2020) == (*l_2020)) && p_5) & (--(*l_2202))) , ((g_1911.f0 , l_2205) , func_59((((l_2195 = ((p_4 >= ((safe_mod_func_int8_t_s_s(((safe_sub_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((p_5 | (((l_2217 &= 0x4FD1CC3799676860LL) , ((safe_mod_func_int16_t_s_s((-1L), (***g_186))) == p_3)) , (*l_2022))), p_5)), 0x998FL)), 0x1DL)), 1UL)) || (*l_2022)), 2UL)) >= 0x37L)) > (-8L))) > p_3) , (*g_56)), g_605))) == (**l_2143)) >= 0x66E5L);
        for (g_1239.f2 = 0; (g_1239.f2 <= 0); g_1239.f2 += 1)
        { /* block id: 1052 */
            int32_t l_2223 = 0x3AA976E4L;
            uint8_t ** const *l_2232 = &g_1023;
            uint8_t ** const **l_2233 = &l_2232;
            int32_t l_2237 = (-3L);
            int32_t l_2238 = 4L;
            int32_t l_2239 = (-10L);
            int32_t l_2240 = 1L;
            int32_t l_2241 = 6L;
            int32_t l_2242 = (-6L);
            int32_t l_2243[9][9][1] = {{{0x8F7C24EDL},{0xE1E2FCD5L},{0xA2D236D6L},{0x350F085AL},{0x350F085AL},{0xA2D236D6L},{0xE1E2FCD5L},{0x8F7C24EDL},{0L}},{{0x4ECD7BE7L},{9L},{0L},{0x30150344L},{0xA5E5D00DL},{0x0CFEF8CAL},{1L},{0L},{0L}},{{0x0894B4EDL},{7L},{0x0F27A464L},{1L},{0x6C66FA58L},{1L},{0x0F27A464L},{7L},{0x0894B4EDL}},{{0L},{0L},{1L},{0x0CFEF8CAL},{0xA5E5D00DL},{0x30150344L},{0L},{9L},{0x4ECD7BE7L}},{{0L},{0x8F7C24EDL},{0xE1E2FCD5L},{0xA2D236D6L},{0x350F085AL},{0x350F085AL},{0xA2D236D6L},{0xE1E2FCD5L},{0x8F7C24EDL}},{{0L},{0x4ECD7BE7L},{9L},{0L},{0x30150344L},{0xA5E5D00DL},{0x0CFEF8CAL},{1L},{0L}},{{0L},{0x0894B4EDL},{7L},{0x0F27A464L},{1L},{0x6C66FA58L},{1L},{0x0F27A464L},{7L}},{{0x0894B4EDL},{0L},{0L},{1L},{0x0CFEF8CAL},{0xA5E5D00DL},{0x30150344L},{0L},{9L}},{{0x4ECD7BE7L},{0L},{0x8F7C24EDL},{0xE1E2FCD5L},{0xA2D236D6L},{0x350F085AL},{0x350F085AL},{0xA2D236D6L},{0xE1E2FCD5L}}};
            int16_t l_2244 = 0x1220L;
            int16_t *l_2334 = &g_133;
            uint32_t l_2340 = 18446744073709551615UL;
            union U1 l_2345 = {0xFBFDL};
            uint8_t l_2363[4][2];
            uint16_t l_2368 = 1UL;
            int8_t *l_2381 = &g_1459[2][1][2];
            int i, j, k;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 2; j++)
                    l_2363[i][j] = 248UL;
            }
            (*g_788) = func_59((safe_lshift_func_uint8_t_u_u((((~((l_2223 > ((*l_2022) = (safe_add_func_uint64_t_u_u(0x91FA688BB4CDC51DLL, 18446744073709551614UL)))) == l_2226)) >= ((l_1448[0][0] = 18446744073709551615UL) , (g_1537[0] |= 0x77B9341F71746E40LL))) & ((safe_mul_func_int8_t_s_s((!(((safe_mod_func_int64_t_s_s(((0xCA9939D744B4B3EFLL || (((*l_2233) = l_2232) == (void*)0)) <= l_1535), 0xFB54625345822898LL)) || p_5) >= g_984)), l_1394[4])) , g_2234)), l_2223)), (**g_744));
            if (l_2223)
            { /* block id: 1058 */
                int32_t *l_2235 = &g_768;
                int32_t *l_2236[8][6][5] = {{{&l_1366,&l_2031[1][3],(void*)0,&l_1366,&g_227},{&g_227,&l_1448[0][0],(void*)0,&g_1824[1][6],&g_604},{&g_1824[1][6],&g_57,&g_768,(void*)0,&l_2031[1][3]},{&l_1448[0][0],&g_227,&g_126,&g_126,&g_227},{&g_57,&g_984,(void*)0,(void*)0,&g_126},{&g_57,&l_1448[0][0],&g_57,&g_227,&l_2031[1][3]}},{{&g_984,&g_227,(void*)0,&g_604,&g_768},{&g_57,(void*)0,(void*)0,(void*)0,&l_1448[0][0]},{&g_57,(void*)0,&l_2031[1][0],&l_2195,&l_1448[0][0]},{&l_1448[0][0],&l_1448[0][0],&l_1366,&l_2031[1][0],(void*)0},{(void*)0,&g_57,(void*)0,&l_1448[0][0],&l_2031[1][2]},{(void*)0,&l_1366,&g_227,&l_1448[0][0],&g_984}},{{&l_2223,(void*)0,&g_57,&l_2031[1][0],&g_604},{&g_984,&g_984,&l_2031[1][0],&l_1366,&l_2031[1][0]},{&g_984,&g_984,&g_227,&g_126,(void*)0},{&l_2031[1][0],&g_1824[1][6],&l_2031[1][2],&l_1366,(void*)0},{&g_984,&l_2031[1][3],(void*)0,&l_1448[0][0],&g_57},{(void*)0,&g_1824[1][6],(void*)0,(void*)0,(void*)0}},{{&g_604,&g_984,&g_768,&l_2031[1][2],&g_126},{(void*)0,&g_984,(void*)0,&g_984,&g_768},{(void*)0,(void*)0,&g_57,(void*)0,(void*)0},{&g_768,&l_1366,&l_1448[0][0],&l_2223,(void*)0},{&l_1448[0][0],&g_57,&l_2031[1][0],&l_1448[0][0],&g_768},{&l_1366,&l_1448[0][0],&g_227,&g_126,&g_126}},{{&g_984,(void*)0,&g_984,&g_57,(void*)0},{(void*)0,&l_1448[0][0],(void*)0,&l_1366,&g_57},{(void*)0,&l_1448[0][0],&g_1824[1][6],&g_984,(void*)0},{&l_2031[1][2],&l_1448[0][0],(void*)0,&g_57,(void*)0},{(void*)0,&l_1448[0][0],&g_984,&l_1448[0][0],&l_2031[1][0]},{(void*)0,(void*)0,&g_227,&g_984,&g_604}},{{(void*)0,&l_1448[0][0],&l_2031[1][0],&l_1448[0][0],&g_984},{&g_984,&l_2031[1][0],&l_1448[0][0],&g_126,&l_2031[1][2]},{&g_984,&g_1824[1][6],&g_57,&g_126,(void*)0},{(void*)0,(void*)0,(void*)0,&g_604,&l_1448[0][0]},{(void*)0,&g_768,&g_768,(void*)0,&g_227},{(void*)0,&g_984,(void*)0,(void*)0,&g_126}},{{&l_2031[1][2],&l_1448[0][0],(void*)0,(void*)0,&g_1824[1][6]},{(void*)0,&g_604,&l_2031[1][2],(void*)0,&g_604},{(void*)0,&l_1366,&g_227,(void*)0,(void*)0},{&g_984,&l_1448[0][0],&l_2031[1][0],&g_604,&g_1824[1][6]},{&l_1366,&g_604,&g_57,&g_126,&l_1366},{&l_1448[0][0],(void*)0,&g_227,&g_126,(void*)0}},{{&g_768,(void*)0,(void*)0,&l_1448[0][0],&l_1448[0][0]},{(void*)0,&g_604,&l_1366,&g_984,&g_768},{(void*)0,&l_1448[0][0],&l_2195,&l_1448[0][0],(void*)0},{&g_604,&l_1366,&g_984,&g_57,&g_984},{(void*)0,&g_604,&g_57,&g_984,(void*)0},{&g_984,&l_1448[0][0],&g_984,&l_2223,(void*)0}}};
                int32_t l_2247 = 0x20E62715L;
                int32_t l_2248 = 4L;
                uint8_t l_2249 = 0xF0L;
                int i, j, k;
                ++l_2249;
                l_2252++;
            }
            else
            { /* block id: 1061 */
                uint32_t l_2289[8] = {0x1966EA76L,0xB7FB87B7L,0x1966EA76L,0x1966EA76L,0xB7FB87B7L,0x1966EA76L,0x1966EA76L,0xB7FB87B7L};
                int32_t l_2337 = 1L;
                int32_t l_2339[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_2339[i] = 0xADA8843AL;
                for (l_2246 = 0; (l_2246 >= 0); l_2246 -= 1)
                { /* block id: 1064 */
                    int16_t l_2267 = 0x8CDFL;
                    int32_t ***l_2328[3][3][4] = {{{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200}},{{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200}},{{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200},{&g_1200,&g_1200,&g_1200,&g_1200}}};
                    int32_t l_2335 = (-4L);
                    int32_t *l_2336[1];
                    int16_t ******l_2356 = &l_2112;
                    int16_t * const *****l_2358 = &l_2357;
                    uint32_t **l_2367 = &l_2197;
                    uint16_t *l_2369 = &g_334[1];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_2336[i] = &g_227;
                    if (((*l_2022) &= 1L))
                    { /* block id: 1066 */
                        return p_5;
                    }
                    else
                    { /* block id: 1068 */
                        int8_t l_2268 = (-1L);
                        uint8_t *l_2283 = &g_574;
                        int32_t l_2302 = 0x69D4A095L;
                        const int32_t ****l_2312 = (void*)0;
                        const int32_t ****l_2313 = &g_2309;
                        int i, j, k;
                        l_2289[7] |= (safe_div_func_int64_t_s_s((safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(l_1835, 13)), (((safe_mul_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(1L, (safe_mod_func_uint64_t_u_u((g_24++), ((l_2223 | (0x58L < (safe_add_func_uint64_t_u_u((((safe_sub_func_uint32_t_u_u((l_2244 <= (safe_div_func_uint32_t_u_u(((safe_sub_func_int32_t_s_s(8L, (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(((((*g_131) = (***g_186)) > (l_2246 == ((*l_2283)--))) <= ((safe_mod_func_uint16_t_u_u((!0UL), l_2237)) <= (*l_2022))), 6)), p_4)))) || l_2252), 0x8F606B7EL))), 0x1B0CFD50L)) , p_3) , g_70.f0), 0xCF7C43BDCF23C4D0LL)))) && 0xE0E3L))))), 0x7DL)) , 1L) , l_2268))), (-3L)));
                        l_2302 = (safe_div_func_uint32_t_u_u(((*l_2202) = p_5), ((((l_2195 &= (((((*l_2200) = (safe_add_func_uint16_t_u_u(g_374.f1, p_4))) & ((safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(((p_5 | (p_3 && (safe_div_func_int16_t_s_s(6L, g_973)))) , (((((safe_sub_func_uint32_t_u_u((g_332.f2 = g_282[4][2][0]), g_50)) ^ 0x0CE0L) , (*g_131)) , p_4) <= 0x325C7D7A4FCAC5CDLL)), p_3)), l_2267)) && l_1448[0][0])) <= 0x7BL) != l_2289[7])) != l_2243[4][0][0]) ^ l_2289[7]) && p_5)));
                        (*g_240) = func_59(((safe_mod_func_uint32_t_u_u(((safe_mod_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((*l_2022) = (((*l_2313) = g_2309) == ((***g_1241) , &g_2310))), ((*l_2283)--))), (safe_sub_func_int64_t_s_s(((safe_div_func_int32_t_s_s((safe_div_func_int16_t_s_s(p_3, (safe_lshift_func_int8_t_s_s((+(safe_sub_func_uint8_t_u_u((((((g_1239.f2 , (l_2327 != l_2328[0][1][0])) && (((+l_2267) | (safe_lshift_func_int16_t_s_u(((*g_131) ^= (safe_div_func_uint64_t_u_u(((l_2334 = &l_2244) != (void*)0), 0xDD74DAFD355D3FF9LL))), 1))) >= l_2244)) ^ l_1394[4]) <= l_2242) | g_284), l_2267))), 0)))), p_5)) <= g_1239.f2), g_334[1])))) && (*l_2022)), p_4)) , p_4), p_3);
                    }
                    --l_2340;
                    (*g_240) = ((((*l_2369) &= ((safe_sub_func_int64_t_s_s((l_2345 , (((((*l_2367) = ((((p_4 = (safe_lshift_func_uint16_t_u_u((safe_div_func_int64_t_s_s((safe_sub_func_int8_t_s_s((((-1L) <= (((*l_2356) = g_2352) != ((*l_2358) = l_2357))) != ((safe_mul_func_int8_t_s_s((safe_mod_func_int8_t_s_s((1UL | p_4), l_2363[1][1])), ((~p_3) < (((safe_mod_func_int16_t_s_s((3UL != g_1244.f0), p_4)) >= p_3) || l_2337)))) & 0x8258FE5502524473LL)), p_3)), (*l_2022))), g_522))) >= (*g_241)) == l_2237) , &g_2122)) == &l_2105) != (*l_2022)) || l_2368)), g_574)) & l_1630.f0)) , (**g_187)) , (void*)0);
                }
            }
            (*g_240) = func_59((0x5EL <= (safe_sub_func_int32_t_s_s(0xDF3AED13L, ((*g_789) = ((safe_sub_func_uint32_t_u_u((safe_sub_func_int32_t_s_s((((g_2376 , (253UL <= (safe_add_func_uint8_t_u_u(p_5, ((*l_2381) = (!(0L <= (((g_2380 , 1L) != (-5L)) < 1L)))))))) , l_2240) ^ p_5), p_4)), p_4)) , p_4))))), p_3);
            (*g_1065) = &l_1630;
        }
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_145 g_783 g_706 g_1291 g_984 g_240 g_241 g_1302 g_326 g_744 g_745 g_605
 * writes: g_145 g_783 g_57 g_1302 g_326
 */
static uint8_t  func_9(int32_t  p_10)
{ /* block id: 616 */
    int64_t l_1271 = 0x78310D9DB085F7DBLL;
    uint8_t l_1292 = 0x53L;
    int32_t l_1295 = 0xEF00D7ACL;
    int32_t l_1299 = 0x56F8C6C1L;
    int32_t l_1300[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int i;
    for (g_145 = 0; (g_145 >= 5); g_145++)
    { /* block id: 619 */
        int64_t l_1272 = 0x2E6166F4C02E6F2FLL;
        uint32_t l_1293 = 0UL;
        for (g_783 = 13; (g_783 != 46); g_783++)
        { /* block id: 622 */
            const uint32_t *l_1276[9][4] = {{&g_235,&g_49,&g_49,&g_49},{&g_49,&g_235,&g_235,&g_49},{&g_49,&g_235,&g_235,&g_49},{&g_235,&g_49,&g_49,&g_235},{&g_235,&g_49,&g_235,&g_235},{&g_49,&g_235,&g_235,&g_235},{&g_49,&g_49,&g_49,&g_235},{&g_235,&g_49,&g_49,&g_49},{&g_49,&g_235,&g_235,&g_49}};
            int32_t l_1297[7] = {0x89097E66L,0x89097E66L,0x89097E66L,0x89097E66L,0x89097E66L,0x89097E66L,0x89097E66L};
            const int64_t ***l_1306 = (void*)0;
            const int64_t ****l_1305 = &l_1306;
            int i, j;
            if ((safe_mul_func_uint8_t_u_u(l_1271, l_1272)))
            { /* block id: 623 */
                int32_t l_1273 = (-1L);
                uint16_t *l_1294[6][7] = {{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]},{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]},{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]},{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]},{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]},{&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1],&g_334[1]}};
                int32_t l_1296 = (-1L);
                int i, j;
                if (l_1271)
                    break;
                if (l_1273)
                    break;
                (**g_240) = (l_1271 >= (0xE920L ^ (safe_add_func_uint16_t_u_u((((l_1276[2][1] != (void*)0) ^ 4294967295UL) < l_1273), ((safe_lshift_func_uint8_t_u_s(((safe_div_func_uint32_t_u_u(l_1271, ((((safe_add_func_int32_t_s_s((l_1296 = (safe_rshift_func_uint16_t_u_u((l_1295 = (safe_sub_func_int32_t_s_s(((safe_mod_func_int64_t_s_s((((safe_mod_func_int8_t_s_s(g_706, (g_1291 , l_1292))) & p_10) != l_1293), 0xFC9B2CBBB51BEC26LL)) , 0x4D501621L), l_1273))), p_10))), 0x96816E76L)) | g_984) , l_1293) , l_1272))) ^ l_1297[2]), p_10)) >= 0L)))));
            }
            else
            { /* block id: 629 */
                int32_t *l_1298[10][10][2] = {{{(void*)0,(void*)0},{&l_1297[0],&l_1297[2]},{&l_1295,&l_1297[2]},{&g_227,&l_1297[2]},{&g_604,(void*)0},{&l_1295,(void*)0},{&g_604,&l_1297[2]},{&g_227,&l_1297[2]},{&l_1295,&l_1297[2]},{&l_1297[0],(void*)0}},{{(void*)0,(void*)0},{&l_1297[0],&l_1297[2]},{&l_1295,&l_1297[2]},{&g_227,&l_1297[2]},{&g_604,(void*)0},{&l_1295,(void*)0},{&g_604,&l_1297[2]},{&g_227,&l_1297[2]},{&l_1295,&l_1297[2]},{&l_1297[0],(void*)0}},{{(void*)0,(void*)0},{&l_1297[0],&l_1297[2]},{&l_1295,&l_1297[2]},{&g_227,&l_1297[2]},{&g_604,(void*)0},{&l_1295,(void*)0},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}},{{&g_604,&l_1297[2]},{&g_57,&g_984},{(void*)0,&l_1297[2]},{&l_1295,&g_984},{&g_126,&l_1297[2]},{&l_1297[0],&l_1297[2]},{&g_126,&g_984},{&l_1295,&l_1297[2]},{(void*)0,&g_984},{&g_57,&l_1297[2]}}};
                int i, j, k;
                ++g_1302;
            }
            l_1295 = (l_1305 == (void*)0);
        }
    }
    (**g_240) = 0x90DD985EL;
    for (g_326 = (-10); (g_326 > 20); g_326++)
    { /* block id: 638 */
        return l_1295;
    }
    return (**g_744);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_13(uint32_t  p_14, int32_t  p_15, int32_t  p_16, uint64_t  p_17, union U1  p_18)
{ /* block id: 614 */
    return p_18.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_49 g_53 g_55 g_56 g_50 g_54 g_70 g_71 g_55.f0 g_57
 * writes: g_49 g_50 g_54 g_56 g_65 g_57
 */
static uint8_t  func_19(uint32_t  p_20, uint16_t  p_21, int64_t  p_22, int32_t  p_23)
{ /* block id: 1 */
    uint32_t l_40[9] = {4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL};
    uint64_t l_47 = 1UL;
    uint32_t *l_48 = &g_49;
    int32_t *l_72 = &g_57;
    int i;
    (*l_72) |= (func_28((65535UL || ((p_22 , (safe_div_func_uint32_t_u_u((g_54 = (safe_sub_func_uint8_t_u_u(((safe_add_func_int64_t_s_s(l_40[5], (((safe_mul_func_int8_t_s_s((safe_sub_func_int8_t_s_s((safe_mod_func_int64_t_s_s((g_24 || ((g_50 = (l_47 == (1L == ((*l_48) ^= g_24)))) >= (0x8D36L <= (safe_mul_func_int16_t_s_s((g_24 , p_20), 0xB9CBL))))), 0xEFC7127B1AA435C5LL)), g_24)), p_22)) >= 0xED994AD4L) & g_24))) >= p_23), g_53))), l_40[5]))) , l_40[5])), g_55, l_40[1], l_47, g_24) <= l_47);
    return g_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_50 g_54 g_24 g_70 g_71 g_55.f0
 * writes: g_56 g_65
 */
static uint8_t  func_28(int64_t  p_29, union U1  p_30, int32_t  p_31, uint32_t  p_32, uint32_t  p_33)
{ /* block id: 5 */
    int32_t * volatile *l_58[8][7] = {{&g_56,&g_56,&g_56,&g_56,(void*)0,&g_56,&g_56},{(void*)0,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56},{&g_56,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56},{&g_56,&g_56,&g_56,&g_56,(void*)0,&g_56,&g_56},{(void*)0,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56},{&g_56,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56},{&g_56,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56},{&g_56,&g_56,&g_56,&g_56,&g_56,&g_56,&g_56}};
    int16_t *l_64 = &g_65;
    uint32_t l_66[2];
    int i, j;
    for (i = 0; i < 2; i++)
        l_66[i] = 0UL;
    g_56 = g_56;
    g_56 = func_59(((safe_div_func_int32_t_s_s((((((p_33 == (((*l_64) = (-5L)) , ((*l_64) = ((g_50 || (-1L)) || l_66[1])))) ^ ((safe_mul_func_int16_t_s_s((+((void*)0 != &g_49)), (((((void*)0 == &p_31) , p_33) > g_54) > 1L))) , g_24)) , g_70) , g_71) , 0x553B787DL), 4294967293UL)) ^ 0x01L), g_54);
    return g_55.f0;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_59(const int32_t  p_60, uint8_t  p_61)
{ /* block id: 9 */
    return &g_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_79 g_65 g_50 g_1141.f2 g_604 g_57 g_241 g_79.f1 g_1023 g_1024 g_1241 g_984 g_334 g_133 g_788 g_1258 g_794 g_56 g_1243 g_1244
 * writes: g_54 g_65 g_57 g_50 g_1141.f2 g_604 g_49 g_334 g_789 g_1258
 */
static union U0  func_73(uint32_t  p_74)
{ /* block id: 15 */
    uint32_t *l_123 = &g_49;
    int32_t **l_784[4][7] = {{&g_241,&g_241,&g_241,&g_241,&g_241,&g_241,&g_241},{&g_241,&g_241,&g_241,&g_241,&g_241,&g_241,&g_241},{&g_241,&g_241,&g_241,&g_241,&g_241,&g_241,&g_241},{&g_241,&g_241,&g_241,&g_241,&g_241,&g_241,&g_241}};
    const uint8_t ** const l_1160[1] = {(void*)0};
    union U1 l_1168[6][2][2] = {{{{65531UL},{0UL}},{{0x6A8EL},{1UL}}},{{{0x6A8EL},{0UL}},{{65531UL},{0x6A8EL}}},{{{0UL},{1UL}},{{0xCF62L},{0xCF62L}}},{{{65531UL},{0xCF62L}},{{0xCF62L},{1UL}}},{{{0UL},{0x6A8EL}},{{65531UL},{0UL}}},{{{0x6A8EL},{1UL}},{{0x6A8EL},{0UL}}}};
    int64_t *l_1191 = &g_310;
    int32_t **l_1205 = &g_1201[5][0][0];
    uint32_t *l_1211 = &g_326;
    union U0 ** const l_1226 = &g_372;
    union U0 ** const *l_1225 = &l_1226;
    union U0 ** const **l_1227 = &l_1225;
    union U0 ** const *l_1229 = &l_1226;
    union U0 ** const **l_1228[4][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1229,(void*)0,(void*)0,&l_1229,&l_1229},{&l_1229,(void*)0,&l_1229,(void*)0,&l_1229},{&l_1229,&l_1229,(void*)0,(void*)0,&l_1229}};
    union U0 *l_1232[8][5] = {{(void*)0,&g_1237[2],(void*)0,(void*)0,(void*)0},{&g_1233[1][1],&g_1233[1][1],&g_1236,&g_1233[1][1],&g_1233[1][1]},{(void*)0,(void*)0,(void*)0,&g_1237[2],(void*)0},{&g_1233[1][1],(void*)0,(void*)0,&g_1233[1][1],(void*)0},{(void*)0,(void*)0,&g_1239,(void*)0,(void*)0},{(void*)0,&g_1233[1][1],(void*)0,(void*)0,&g_1233[1][1]},{(void*)0,&g_1237[2],(void*)0,(void*)0,(void*)0},{&g_1233[1][1],&g_1233[1][1],&g_1236,&g_1233[1][1],&g_1233[1][1]}};
    union U0 ** const l_1231 = &l_1232[6][3];
    union U0 ** const *l_1230 = &l_1231;
    const union U0 * const **l_1245 = &g_1242[3];
    uint16_t l_1250 = 65533UL;
    uint16_t *l_1257[8][4] = {{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0},{&g_55.f0,&g_55.f0,&g_55.f0,&g_55.f0}};
    int32_t l_1261[8][8][2] = {{{(-5L),0L},{0x1D73BE04L,0xA23CAC69L},{0x9DD73410L,(-7L)},{0L,0x76B9A19CL},{0xA23CAC69L,0xA23CAC69L},{5L,0x9DDF8246L},{(-5L),0x51FED7BBL},{(-9L),0xD1CAFBABL}},{{0x76B9A19CL,(-9L)},{0xF28D17D3L,0xB250CE45L},{0xF28D17D3L,(-9L)},{0x76B9A19CL,0xD1CAFBABL},{5L,0xCC5F4A92L},{0xA07F33EBL,(-3L)},{0L,0xB250CE45L},{0xB250CE45L,0x96396F30L}},{{0x9DD73410L,0x3F955C14L},{0x21F4D92AL,0xB250CE45L},{0L,0xBB89775CL},{0xA07F33EBL,0x76B9A19CL},{(-5L),0x9A171754L},{0x3F955C14L,(-5L)},{0x51FED7BBL,0x0F1F8915L},{0xC0586C84L,5L}},{{0x3F955C14L,0x73E37980L},{5L,0x76B9A19CL},{0x070E7B6DL,(-3L)},{0L,0x21F4D92AL},{0xB250CE45L,0x3F955C14L},{0L,0x3F955C14L},{0xB250CE45L,0x21F4D92AL},{0L,(-3L)}},{{0x070E7B6DL,0x76B9A19CL},{5L,0x73E37980L},{0x3F955C14L,5L},{0xC0586C84L,0x0F1F8915L},{0x51FED7BBL,(-5L)},{0x3F955C14L,0x9A171754L},{(-5L),0x76B9A19CL},{0xA07F33EBL,0xBB89775CL}},{{0L,0xB250CE45L},{0x21F4D92AL,0x3F955C14L},{0x9DD73410L,0x96396F30L},{0xB250CE45L,0xB250CE45L},{0L,(-3L)},{0xA07F33EBL,0xCC5F4A92L},{5L,0x9A171754L},{0x96396F30L,5L}},{{0x51FED7BBL,0xE0EECB7AL},{0x51FED7BBL,5L},{0x96396F30L,0x9A171754L},{5L,0xCC5F4A92L},{0xA07F33EBL,(-3L)},{0L,0xB250CE45L},{0xB250CE45L,0x96396F30L},{0x9DD73410L,0x3F955C14L}},{{0x21F4D92AL,0xB250CE45L},{0L,0xBB89775CL},{0xA07F33EBL,0x76B9A19CL},{(-5L),0x9A171754L},{0x3F955C14L,(-5L)},{0x51FED7BBL,0x0F1F8915L},{0xC0586C84L,5L},{0x3F955C14L,0x73E37980L}}};
    int i, j, k;
    if (p_74)
    { /* block id: 16 */
        for (p_74 = (-5); (p_74 > 27); p_74++)
        { /* block id: 19 */
            for (g_54 = (-11); (g_54 <= (-8)); g_54++)
            { /* block id: 22 */
                return g_79[4];
            }
        }
    }
    else
    { /* block id: 26 */
        int32_t *l_119 = &g_57;
        int16_t *l_787 = &g_65;
        int32_t **l_1135 = (void*)0;
        int32_t l_1176 = 0xA72D8796L;
        int32_t l_1186 = 0x27114375L;
        uint32_t *l_1208 = &g_538;
        for (g_65 = 0; (g_65 == (-20)); g_65 = safe_sub_func_uint16_t_u_u(g_65, 2))
        { /* block id: 29 */
            int32_t *l_82 = &g_57;
            int16_t *l_104[8][10][3] = {{{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{(void*)0,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65}},{{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{(void*)0,&g_65,(void*)0},{(void*)0,&g_65,&g_65},{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{(void*)0,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65}},{{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{(void*)0,&g_65,&g_65},{(void*)0,(void*)0,(void*)0},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,(void*)0},{&g_65,&g_65,&g_65}},{{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,(void*)0},{&g_65,&g_65,(void*)0},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{(void*)0,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65}},{{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65}},{{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{(void*)0,(void*)0,(void*)0},{&g_65,&g_65,(void*)0},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,(void*)0},{&g_65,&g_65,(void*)0},{&g_65,&g_65,&g_65}},{{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{(void*)0,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,&g_65,&g_65}},{{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{&g_65,(void*)0,&g_65},{&g_65,&g_65,&g_65},{(void*)0,&g_65,&g_65},{(void*)0,(void*)0,(void*)0},{&g_65,&g_65,(void*)0},{&g_65,&g_65,&g_65}}};
            int32_t *l_118 = &g_57;
            int32_t **l_785 = (void*)0;
            int16_t **l_1126 = &g_128;
            int16_t ***l_1125 = &l_1126;
            uint8_t **l_1151 = &g_1024;
            int i, j, k;
            (*l_82) = 0x9E7339AAL;
            for (g_50 = (-14); (g_50 <= 23); ++g_50)
            { /* block id: 33 */
                const int32_t *l_103 = &g_57;
                const int32_t **l_102 = &l_103;
                uint16_t *l_111 = &g_55.f0;
                uint8_t *l_120[4];
                int32_t l_122 = 0x205D52AEL;
                uint16_t *l_782 = &g_783;
                int32_t **l_786 = &l_82;
                int32_t *l_1134[7][3][10] = {{{&g_766,&g_766,&g_766,&g_766,(void*)0,&g_54,&g_568,(void*)0,&g_568,(void*)0},{(void*)0,&g_568,&g_706,(void*)0,&g_706,&g_568,(void*)0,(void*)0,&g_766,&g_766},{(void*)0,(void*)0,&g_766,&g_568,&g_568,(void*)0,&g_568,&g_568,&g_766,(void*)0}},{{&g_706,(void*)0,&g_706,&g_54,&g_706,&g_766,(void*)0,&g_706,&g_54,&g_54},{&g_568,(void*)0,&g_568,(void*)0,&g_568,&g_54,(void*)0,&g_766,&g_766,&g_766},{&g_771,&g_706,&g_706,&g_766,&g_766,&g_766,&g_706,&g_706,&g_771,&g_766}},{{&g_766,&g_766,(void*)0,&g_54,&g_568,(void*)0,&g_568,(void*)0,&g_568,&g_54},{&g_54,&g_706,&g_54,&g_54,&g_706,&g_766,&g_706,(void*)0,&g_771,(void*)0},{&g_568,(void*)0,&g_54,&g_766,&g_54,(void*)0,&g_568,(void*)0,&g_766,&g_706}},{{(void*)0,(void*)0,&g_54,(void*)0,&g_771,&g_766,&g_771,(void*)0,&g_54,(void*)0},{&g_54,(void*)0,(void*)0,&g_766,&g_568,&g_54,&g_568,&g_706,&g_568,&g_54},{&g_706,(void*)0,&g_706,(void*)0,&g_706,&g_54,&g_706,&g_766,(void*)0,&g_766}},{{&g_54,&g_706,&g_568,&g_766,(void*)0,&g_766,&g_568,&g_706,&g_54,&g_766},{(void*)0,&g_766,&g_706,&g_54,&g_706,(void*)0,&g_706,(void*)0,&g_706,&g_54},{&g_568,&g_706,&g_568,&g_54,&g_568,&g_766,(void*)0,(void*)0,&g_54,(void*)0}},{{&g_54,(void*)0,&g_771,&g_766,&g_771,(void*)0,&g_54,(void*)0,(void*)0,&g_706},{&g_766,(void*)0,&g_568,(void*)0,&g_54,&g_766,&g_54,(void*)0,&g_568,(void*)0},{&g_771,(void*)0,&g_706,&g_766,&g_706,&g_54,&g_54,&g_706,&g_54,&g_54}},{{&g_568,(void*)0,&g_568,(void*)0,&g_568,&g_54,(void*)0,&g_766,&g_766,&g_766},{&g_771,&g_706,&g_706,&g_766,&g_766,&g_766,&g_706,&g_706,&g_771,&g_766},{&g_766,&g_766,(void*)0,&g_54,&g_568,(void*)0,&g_568,(void*)0,&g_568,&g_54}}};
                int32_t **l_1133[4][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                int i, j, k;
                for (i = 0; i < 4; i++)
                    l_120[i] = &g_121;
            }
        }
        for (g_1141.f2 = 0; (g_1141.f2 > 14); g_1141.f2 = safe_add_func_uint32_t_u_u(g_1141.f2, 2))
        { /* block id: 572 */
            union U0 *l_1169[1];
            union U0 *l_1171 = &g_332;
            int32_t l_1183[6];
            uint8_t l_1218 = 0x44L;
            int i;
            for (i = 0; i < 1; i++)
                l_1169[i] = &g_1068[8];
            for (i = 0; i < 6; i++)
                l_1183[i] = 8L;
            for (g_54 = 0; (g_54 != 13); g_54 = safe_add_func_uint32_t_u_u(g_54, 9))
            { /* block id: 575 */
                int32_t l_1165 = 1L;
                int32_t l_1181 = 0xFFB57B0AL;
                int32_t l_1182[10][5][5] = {{{1L,0x9A0418C1L,(-10L),0L,(-1L)},{0xD00D79F0L,(-8L),0x85DBD533L,0xAE3BDC9BL,0x94917BADL},{0x5001F32FL,0xAD729F25L,0x174DA2D4L,0xAD729F25L,0x5001F32FL},{1L,0xE77AE725L,0L,(-10L),(-1L)},{(-8L),0x5B050A9FL,0xAAB6FB07L,0L,0xAD729F25L}},{{0xAAB6FB07L,0xF45E1A2EL,0x16F9CAA2L,0xE77AE725L,(-1L)},{0x2916E469L,0L,1L,2L,0x5001F32FL},{(-1L),0L,0xF45E1A2EL,0x5B050A9FL,0x94917BADL},{2L,(-1L),0x94917BADL,0xCDB2A1DAL,(-1L)},{0xF74B1E8BL,0xFC48D8ADL,2L,1L,(-8L)}},{{0xF74B1E8BL,(-10L),0x72E035BCL,(-1L),2L},{2L,(-10L),0xF2F0C359L,(-3L),0xF2F0C359L},{(-1L),(-1L),1L,0x94917BADL,0x85DBD533L},{0x2916E469L,0L,0x01A280DAL,1L,0x16F9CAA2L},{0xAAB6FB07L,2L,(-10L),(-1L),(-10L)}},{{(-8L),0L,0x9A0418C1L,0L,0xFFC4364BL},{1L,(-1L),0L,0xF45E1A2EL,0x5B050A9FL},{0x5001F32FL,(-10L),0xF74B1E8BL,0x72E035BCL,0xC920B55DL},{0xD00D79F0L,(-10L),1L,0x2916E469L,1L},{1L,0xFC48D8ADL,1L,0L,1L}},{{(-9L),(-1L),0xF74B1E8BL,1L,(-6L)},{(-1L),0L,0L,(-1L),0x2916E469L},{(-1L),0L,0x9A0418C1L,0x174DA2D4L,0xF74B1E8BL},{2L,0xF45E1A2EL,(-10L),0x3709CA5BL,(-3L)},{0x85DBD533L,0x5B050A9FL,0x01A280DAL,0x174DA2D4L,0xE77AE725L}},{{0xAD729F25L,0xE77AE725L,1L,(-1L),0x72E035BCL},{(-3L),0xAD729F25L,0xF2F0C359L,1L,0L},{0xCDB2A1DAL,(-8L),0x72E035BCL,0L,0x014D1B41L},{1L,0x9A0418C1L,2L,0x2916E469L,0x014D1B41L},{0L,0x16F9CAA2L,0x94917BADL,0x72E035BCL,0L}},{{0xA4B2096FL,0x72E035BCL,0xF45E1A2EL,0xF45E1A2EL,0x72E035BCL},{0x16F9CAA2L,0x5001F32FL,1L,0L,0xE77AE725L},{0xF45E1A2EL,0xA4B2096FL,0x16F9CAA2L,(-1L),(-3L)},{0x174DA2D4L,0x3709CA5BL,0xAAB6FB07L,1L,0xF74B1E8BL},{0xF45E1A2EL,(-6L),0L,0x94917BADL,0x2916E469L}},{{0x16F9CAA2L,0xAAB6FB07L,0x174DA2D4L,(-3L),(-6L)},{0xA4B2096FL,(-9L),0x85DBD533L,(-1L),0x94917BADL},{0x72E035BCL,0xC920B55DL,(-8L),0x94917BADL,0xFFC4364BL},{0xFFC4364BL,0xC920B55DL,(-1L),1L,0xAD729F25L},{1L,0x174DA2D4L,0x94917BADL,0xFC48D8ADL,0xFC48D8ADL}},{{0x5001F32FL,0x16F9CAA2L,0x5001F32FL,1L,0L},{0xCDB2A1DAL,1L,(-1L),0xAE3BDC9BL,(-8L)},{2L,(-1L),0xAD729F25L,(-1L),(-10L)},{1L,(-9L),(-1L),(-8L),2L},{0x3709CA5BL,0x01A280DAL,0x5001F32FL,0xCDB2A1DAL,(-6L)}},{{0x9A0418C1L,1L,0x94917BADL,0xAAB6FB07L,1L},{0x174DA2D4L,(-10L),(-1L),(-10L),2L},{(-1L),0xE77AE725L,(-8L),(-10L),1L},{0xA4B2096FL,2L,2L,0xAAB6FB07L,0xC920B55DL},{0x01A280DAL,0xCDB2A1DAL,0xF2F0C359L,0xCDB2A1DAL,0x01A280DAL}}};
                uint8_t l_1187 = 255UL;
                int32_t *l_1190 = &l_1182[0][0][0];
                int32_t **l_1204[9][8][3] = {{{&g_1201[1][0][1],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[1][0][1],&g_1201[2][0][2],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[4][0][1],&g_1201[5][0][0]},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[2][0][1],&g_1201[4][0][1],&g_1201[4][0][1]},{&g_1201[5][0][0],&g_1201[2][0][2],&g_1201[5][0][0]},{&g_1201[2][0][1],(void*)0,&g_1201[2][0][1]}},{{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[4][0][1]},{&g_1201[1][0][1],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[1][0][1],&g_1201[2][0][2],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[4][0][1],&g_1201[5][0][0]},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[2][0][1],&g_1201[4][0][1],&g_1201[4][0][1]}},{{&g_1201[5][0][0],&g_1201[2][0][2],&g_1201[5][0][0]},{&g_1201[2][0][1],(void*)0,&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[4][0][1]},{&g_1201[1][0][1],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[1][0][1],&g_1201[2][0][2],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[4][0][1],&g_1201[5][0][0]}},{{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[2][0][1],&g_1201[4][0][1],&g_1201[4][0][1]},{&g_1201[5][0][0],&g_1201[2][0][2],&g_1201[5][0][0]},{&g_1201[2][0][1],(void*)0,&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[4][0][1]},{&g_1201[1][0][1],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],(void*)0,&g_1201[5][0][0]}},{{&g_1201[1][0][1],&g_1201[2][0][2],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[4][0][1],&g_1201[5][0][0]},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[2][0][1],&g_1201[4][0][1],&g_1201[4][0][1]},{&g_1201[5][0][0],&g_1201[2][0][2],&g_1201[5][0][0]},{&g_1201[2][0][1],(void*)0,&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[4][0][1]}},{{&g_1201[1][0][1],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],(void*)0,(void*)0},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[2][0][1],(void*)0},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[2][0][1],&g_1201[2][0][1]},{&g_1201[1][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]}},{{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[4][0][1],&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[2][0][1],&g_1201[5][0][0],(void*)0},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[2][0][1],(void*)0},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[2][0][1],&g_1201[2][0][1]}},{{&g_1201[1][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[4][0][1],&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[2][0][1],&g_1201[5][0][0],(void*)0},{&g_1201[5][0][0],(void*)0,&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[2][0][1],(void*)0}},{{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[5][0][0],&g_1201[2][0][1],&g_1201[2][0][1]},{&g_1201[1][0][1],(void*)0,&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[5][0][0]},{&g_1201[4][0][1],&g_1201[4][0][1],&g_1201[2][0][1]},{&g_1201[5][0][0],&g_1201[5][0][0],&g_1201[1][0][1]},{&g_1201[2][0][1],&g_1201[5][0][0],(void*)0}}};
                int i, j, k;
                for (g_604 = 3; (g_604 >= 0); g_604 -= 1)
                { /* block id: 578 */
                    union U0 **l_1170 = &l_1169[0];
                    union U0 **l_1172 = &g_372;
                    int32_t l_1177 = 0x437A2D87L;
                    int32_t l_1184[7][3][3] = {{{0x79BBF5E6L,0xC5B32A1DL,0x79BBF5E6L},{0x79BBF5E6L,0x38A75613L,0xC5B32A1DL},{0x38A75613L,0x79BBF5E6L,0x79BBF5E6L}},{{0xC5B32A1DL,0x79BBF5E6L,0xB7605411L},{0x3CDA8A8EL,0x38A75613L,(-3L)},{0xC5B32A1DL,0xC5B32A1DL,(-3L)}},{{0x38A75613L,0x3CDA8A8EL,0xB7605411L},{0x79BBF5E6L,0xC5B32A1DL,0x79BBF5E6L},{0x79BBF5E6L,0x38A75613L,0xC5B32A1DL}},{{0x38A75613L,0x79BBF5E6L,0x79BBF5E6L},{0xC5B32A1DL,0x79BBF5E6L,0xB7605411L},{0x3CDA8A8EL,0x38A75613L,(-3L)}},{{0xC5B32A1DL,0xC5B32A1DL,(-3L)},{0x38A75613L,0x3CDA8A8EL,0xB7605411L},{0x79BBF5E6L,0xC5B32A1DL,0x79BBF5E6L}},{{0x79BBF5E6L,0x38A75613L,0xC5B32A1DL},{0x38A75613L,0x79BBF5E6L,0x79BBF5E6L},{0xC5B32A1DL,0x79BBF5E6L,0xB7605411L}},{{0x3CDA8A8EL,0x38A75613L,(-3L)},{0xC5B32A1DL,0xC5B32A1DL,(-3L)},{0x38A75613L,0x3CDA8A8EL,0xB7605411L}}};
                    int i, j, k;
                }
            }
            (*g_241) = (0x7BB305ACL && (safe_div_func_int32_t_s_s((*l_119), ((*l_123) = (safe_rshift_func_uint16_t_u_u(l_1218, g_65))))));
        }
    }
    (*g_788) = (((safe_mul_func_int8_t_s_s((g_79[4].f1 <= 0x54L), (safe_rshift_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((void*)0 != (*g_1023)), ((g_334[1] |= (((l_1230 = ((*l_1227) = l_1225)) == (l_1245 = g_1241)) >= (((safe_add_func_int16_t_s_s((safe_div_func_uint8_t_u_u(l_1250, (safe_add_func_int16_t_s_s((safe_div_func_uint32_t_u_u(p_74, (safe_add_func_uint16_t_u_u(g_984, (-1L))))), p_74)))), 1UL)) > 4L) < p_74))) , g_133))), 0)))) != p_74) , (void*)0);
    g_1258--;
    (**g_794) = l_1261[0][5][0];
    return (*g_1243);
}


/* ------------------------------------------ */
/* 
 * reads : g_522 g_604 g_24 g_650 g_794 g_391 g_392 g_393 g_57 g_788 g_789 g_768 g_538 g_766 g_743.f0 g_149 g_524 g_783 g_240 g_241 g_189 g_131 g_65 g_227 g_188 g_649 g_568 g_133 g_962 g_973 g_145 g_132 g_126 g_56 g_985 g_310 g_994 g_1000
 * writes: g_522 g_604 g_24 g_56 g_311 g_57 g_783 g_372 g_126 g_789 g_129 g_133 g_531 g_768 g_568 g_524 g_145 g_985 g_310 g_227 g_1000
 */
static int64_t  func_89(uint32_t * p_90, int32_t ** p_91, int16_t * p_92, int32_t ** p_93, int32_t ** p_94)
{ /* block id: 358 */
    uint16_t l_795[7] = {65535UL,65530UL,65530UL,65535UL,65530UL,65530UL,65535UL};
    union U0 **l_797 = &g_372;
    union U0 ***l_796 = &l_797;
    int32_t l_849[3][5] = {{0xCD9D28F1L,0xC8FD4D7DL,0xCD9D28F1L,0xCD9D28F1L,0xC8FD4D7DL},{0L,(-1L),(-1L),0L,(-1L)},{0xC8FD4D7DL,0xC8FD4D7DL,0L,0xC8FD4D7DL,0xC8FD4D7DL}};
    int32_t *l_983[6][9][4] = {{{&l_849[0][2],&g_126,(void*)0,&g_768},{&g_768,&g_604,(void*)0,&g_768},{&l_849[0][2],&g_227,&g_768,&l_849[2][0]},{&g_768,&g_227,&g_227,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768}},{{&g_227,&g_57,(void*)0,&l_849[0][2]},{&g_768,&g_57,&g_57,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_57,(void*)0,&l_849[0][2]},{&g_768,&g_57,&g_57,&g_768}},{{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_57,(void*)0,&l_849[0][2]},{&g_768,&g_57,&g_57,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]}},{{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_57,(void*)0,&l_849[0][2]},{&g_768,&g_57,&g_57,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604}},{{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_57,(void*)0,&l_849[0][2]},{&g_768,&g_57,&g_57,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_57,(void*)0,&l_849[0][2]}},{{&g_768,&g_57,&g_57,&g_768},{&g_768,&g_227,&g_227,&g_604},{&g_768,&g_227,&g_57,&l_849[2][0]},{&g_768,&g_768,(void*)0,&l_849[2][0]},{&g_227,&g_227,&g_126,&g_604},{&g_604,&g_227,&g_126,&g_768},{&g_227,&g_768,&g_126,&g_227},{&g_768,&g_768,&g_768,&g_768},{&g_604,&g_57,&g_604,&l_849[2][0]}}};
    union U1 **l_997 = (void*)0;
    int32_t * volatile l_1003 = &g_768;/* VOLATILE GLOBAL l_1003 */
    int i, j, k;
    for (g_522 = (-23); (g_522 == (-2)); g_522 = safe_add_func_uint8_t_u_u(g_522, 6))
    { /* block id: 361 */
        uint32_t l_818 = 0UL;
        int32_t l_882 = (-7L);
        int32_t l_925 = 0L;
        int32_t l_928 = 0xABF23F32L;
        int32_t *l_977 = (void*)0;
        int32_t *l_978 = &g_227;
        int32_t *l_979[8][3][6] = {{{&g_57,&g_57,&l_928,&l_849[0][3],&l_928,&g_57},{&l_928,&l_882,&l_849[0][3],&l_849[0][3],&l_882,&l_928},{&g_57,&l_928,&l_849[0][3],&l_928,&g_57,&g_57}},{{&l_925,&l_928,&l_928,&l_925,&l_882,&l_925},{&l_925,&l_882,&l_925,&l_928,&l_928,&l_925},{&g_57,&g_57,&l_928,&l_849[0][3],&l_928,&g_57}},{{&l_928,&l_882,&l_849[0][3],&l_849[0][3],&l_882,&l_928},{&g_57,&l_928,&l_849[0][3],&l_928,&g_57,&g_57},{&l_925,&l_928,&l_928,&l_925,&l_882,&l_925}},{{&l_925,&l_882,&l_925,&l_928,&l_928,&l_925},{&g_57,&g_57,&l_928,&l_849[0][3],&l_928,&g_57},{&l_928,&l_882,&l_849[0][3],&l_849[0][3],&l_882,&l_928}},{{&g_57,&l_928,&l_849[0][3],&l_928,&g_57,&g_57},{&l_925,&l_928,&l_928,&l_925,&l_882,&l_925},{&l_925,&l_882,&l_925,&l_928,&l_928,&l_925}},{{&g_57,&g_57,&l_928,&l_849[0][3],&l_928,&g_57},{&l_928,&l_882,&l_849[0][3],&l_849[0][3],&l_882,&l_928},{&g_57,&l_928,&l_849[0][3],&l_928,&g_57,&g_57}},{{&l_925,&l_928,&l_928,&l_925,&l_882,&l_925},{&l_925,&l_882,&l_925,&l_928,&l_928,&l_925},{&g_57,&g_57,&l_928,&l_849[0][3],&l_928,&g_57}},{{&l_928,&l_882,&l_849[0][3],&l_849[0][3],&l_882,&l_928},{&g_57,&l_928,&l_849[0][3],&l_928,&g_57,&g_57},{&l_925,&l_928,&l_928,&l_925,&l_882,&l_925}}};
        uint64_t l_980 = 18446744073709551610UL;
        int i, j, k;
        for (g_604 = 0; (g_604 > (-10)); g_604 = safe_sub_func_uint64_t_u_u(g_604, 2))
        { /* block id: 364 */
            int64_t *l_804[5] = {&g_282[4][2][0],&g_282[4][2][0],&g_282[4][2][0],&g_282[4][2][0],&g_282[4][2][0]};
            int32_t l_827 = (-1L);
            int32_t l_869 = (-10L);
            uint32_t l_883 = 0UL;
            uint8_t l_929 = 247UL;
            int i;
            for (g_24 = 0; (g_24 <= 4); g_24 += 1)
            { /* block id: 367 */
                int i, j, k;
                (*g_794) = g_650[g_24][g_24][g_24];
            }
            if (((l_795[2] ^ (g_522 < (**g_391))) , (((((l_796 != ((((((safe_rshift_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((9UL < (g_311 = 0xA8374A5911841823LL)), 5L)), (safe_lshift_func_int16_t_s_s((+((((safe_add_func_int32_t_s_s((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u((((l_818 > (safe_div_func_uint8_t_u_u((safe_mod_func_int32_t_s_s(((safe_add_func_uint32_t_u_u((--(*p_90)), 0L)) , (**g_788)), 6L)), l_827))) > g_604) <= l_818), g_538)) >= g_766) == 2UL), l_818)) && 0x3DL), l_795[6])), l_827)), g_743.f0)) ^ (-1L)) <= 0x9867DA03L) == 65535UL)), 4)))) & l_795[2]) && l_818), g_149)) <= (**g_788)) && (**p_91)) > g_24) , 0x27377AA3L) , (void*)0)) , g_524) > (**p_93)) < l_795[1]) < l_827)))
            { /* block id: 372 */
                int64_t l_853 = 0x4843CF09CFE6D502LL;
                int8_t l_881 = (-10L);
                for (g_783 = 0; (g_783 <= 10); g_783 = safe_add_func_int64_t_s_s(g_783, 6))
                { /* block id: 375 */
                    union U0 *l_830 = &g_332;
                    int32_t l_843[10][1][9] = {{{0xEE6E537AL,1L,0x1971561AL,0xEE6E537AL,0x1971561AL,1L,0xEE6E537AL,0x77343D08L,0x77343D08L}},{{0xAAE0F814L,0x6ACEE0B1L,1L,0xAAE0F814L,1L,0x6ACEE0B1L,0xAAE0F814L,0x4E90A43FL,0x4E90A43FL}},{{0xEE6E537AL,1L,0x1971561AL,0xEE6E537AL,0x1971561AL,1L,0xEE6E537AL,0x77343D08L,0x77343D08L}},{{0xAAE0F814L,0x6ACEE0B1L,1L,0xAAE0F814L,0xBC2CACE1L,0x613291DBL,0x4E90A43FL,0x0D0F366EL,0x0D0F366EL}},{{0x77343D08L,0xA8A370C2L,0x9447938CL,0x77343D08L,0x9447938CL,0xA8A370C2L,0x77343D08L,0xF426EF47L,0xF426EF47L}},{{0x4E90A43FL,0x613291DBL,0xBC2CACE1L,0x4E90A43FL,0xBC2CACE1L,0x613291DBL,0x4E90A43FL,0x0D0F366EL,0x0D0F366EL}},{{0x77343D08L,0xA8A370C2L,0x9447938CL,0x77343D08L,0x9447938CL,0xA8A370C2L,0x77343D08L,0xF426EF47L,0xF426EF47L}},{{0x4E90A43FL,0x613291DBL,0xBC2CACE1L,0x4E90A43FL,0xBC2CACE1L,0x613291DBL,0x4E90A43FL,0x0D0F366EL,0x0D0F366EL}},{{0x77343D08L,0xA8A370C2L,0x9447938CL,0x77343D08L,0x9447938CL,0xA8A370C2L,0x77343D08L,0xF426EF47L,0xF426EF47L}},{{0x4E90A43FL,0x613291DBL,0xBC2CACE1L,0x4E90A43FL,0xBC2CACE1L,0x613291DBL,0x4E90A43FL,0x0D0F366EL,0x0D0F366EL}}};
                    int8_t *l_870 = &g_145;
                    uint16_t *l_871 = &l_795[2];
                    int i, j, k;
                    (*l_797) = l_830;
                    for (g_126 = 12; (g_126 > (-14)); g_126 = safe_sub_func_uint32_t_u_u(g_126, 7))
                    { /* block id: 379 */
                        int64_t l_846 = 0xCC1E691C79B88C9ALL;
                        int16_t *l_847 = &g_133;
                        uint8_t *l_848 = &g_531;
                        int32_t *l_850 = &l_827;
                        int32_t *l_851 = (void*)0;
                        int32_t *l_852[1][9] = {{&g_768,&g_768,&g_768,&g_768,&g_768,&g_768,&g_768,&g_768,&g_768}};
                        uint16_t l_854 = 0xAEAAL;
                        int i, j;
                        (*p_93) = (*g_240);
                        (*p_91) = (void*)0;
                        (**g_788) = ((0x78D5E4D5L && 0x8B75B855L) & ((safe_div_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u((g_522 ^ 6UL), g_189)) && (((l_849[2][0] = (((((-2L) >= (safe_add_func_int32_t_s_s((safe_rshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(l_843[7][0][4], ((*l_848) = (((*l_847) = ((*g_131) = (l_846 |= (safe_mod_func_uint64_t_u_u(0xEB7921B04153DAF7LL, l_827))))) | (*p_92))))), 2)), g_227))) , l_843[7][0][4]) & 0x7C38F840A09781AELL) == (-3L))) != g_393) >= l_843[7][0][4])), 0xA59A6E03L)) < l_795[0]));
                        l_854++;
                    }
                }
            }
            else
            { /* block id: 406 */
                int64_t l_884[10][5][5] = {{{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL}},{{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)}},{{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL}},{{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L}},{{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL}},{{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)}},{{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL}},{{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L}},{{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL}},{{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)},{0xE6C682865D633182LL,0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL},{0L,0xF07AAF2D3B344311LL,0L,0xF07AAF2D3B344311LL,0L},{0xE6C682865D633182LL,0x50F41DCD71E622FBLL,0x50F41DCD71E622FBLL,0xE6C682865D633182LL,0xE6C682865D633182LL},{(-7L),0xF07AAF2D3B344311LL,(-7L),0xF07AAF2D3B344311LL,(-7L)}}};
                int32_t l_926[8];
                union U0 **l_946 = &g_372;
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_926[i] = 0x3869A9C3L;
                (**g_788) |= ((void*)0 == p_92);
                if (l_849[1][2])
                { /* block id: 408 */
                    return l_883;
                }
                else
                { /* block id: 410 */
                    uint32_t l_903 = 4294967293UL;
                    int32_t l_916 = 0L;
                    int32_t l_923 = 0xA31E2A14L;
                    int32_t l_924 = 0x590B22ECL;
                    int32_t l_927 = 3L;
                    if (l_884[7][1][3])
                    { /* block id: 411 */
                        uint64_t l_896[9][4] = {{18446744073709551608UL,18446744073709551608UL,0x78D6A0429D6158D1LL,0xA73CC5A61AC1945CLL},{0xA73CC5A61AC1945CLL,0xF79C9377111B2CA8LL,0x78D6A0429D6158D1LL,0xF79C9377111B2CA8LL},{18446744073709551608UL,0xB493EBA0C57CB7EELL,18446744073709551607UL,0x78D6A0429D6158D1LL},{0xF79C9377111B2CA8LL,0xB493EBA0C57CB7EELL,0xB493EBA0C57CB7EELL,0xF79C9377111B2CA8LL},{0xB493EBA0C57CB7EELL,0xF79C9377111B2CA8LL,18446744073709551608UL,0xA73CC5A61AC1945CLL},{0xB493EBA0C57CB7EELL,18446744073709551608UL,0xB493EBA0C57CB7EELL,18446744073709551607UL},{0xF79C9377111B2CA8LL,0xA73CC5A61AC1945CLL,18446744073709551607UL,18446744073709551607UL},{18446744073709551608UL,18446744073709551608UL,0x78D6A0429D6158D1LL,0xA73CC5A61AC1945CLL},{0xA73CC5A61AC1945CLL,0xF79C9377111B2CA8LL,0x78D6A0429D6158D1LL,0xF79C9377111B2CA8LL}};
                        int i, j;
                        (**g_240) = ((**p_93) = (safe_lshift_func_uint8_t_u_s((safe_unary_minus_func_int32_t_s((l_795[4] , ((safe_div_func_int16_t_s_s((*p_92), 0x0C33L)) , ((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(0x9AL, l_884[7][1][3])), l_869)), l_896[6][3])) || ((-5L) && (safe_div_func_int32_t_s_s(((l_818 <= (*g_188)) || l_818), (*g_789))))))))), l_849[2][0])));
                        (**p_94) &= (safe_sub_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u(l_882, 6)), (((4294967295UL != ((*g_649) != p_90)) > (g_766 <= (((l_903 < (safe_rshift_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((safe_add_func_int32_t_s_s((0x94D6CE4B69B6A34BLL ^ l_903), ((safe_mod_func_uint8_t_u_u(l_884[7][1][3], 0x20L)) || 1L))), (-4L))), l_849[0][3]))) != l_849[2][0]) & 0x3208L))) & (*p_92))));
                    }
                    else
                    { /* block id: 415 */
                        int32_t *l_912 = (void*)0;
                        int32_t *l_913 = &l_869;
                        int32_t *l_914 = &g_227;
                        int32_t *l_915 = &l_849[2][0];
                        int32_t *l_917 = &l_849[2][0];
                        int32_t *l_918 = &g_126;
                        int32_t *l_919 = &g_768;
                        int32_t *l_920 = &l_827;
                        int32_t *l_921 = &l_849[2][0];
                        int32_t *l_922[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_922[i] = &l_827;
                        --l_929;
                    }
                }
                for (g_568 = 0; (g_568 != (-10)); --g_568)
                { /* block id: 421 */
                    return (*g_392);
                }
                for (l_882 = 0; (l_882 <= 10); l_882 = safe_add_func_int64_t_s_s(l_882, 2))
                { /* block id: 426 */
                    uint32_t l_949[10][10] = {{0UL,0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL},{0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL,1UL},{0UL,0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL},{0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL,1UL},{0UL,0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL},{0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL,1UL},{0UL,0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL},{0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL,1UL},{0UL,0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL},{0UL,1UL,1UL,0UL,0UL,1UL,1UL,0UL,0UL,1UL}};
                    uint64_t *l_957 = &g_24;
                    uint16_t *l_965 = &g_524;
                    int64_t ** const * const *l_975 = (void*)0;
                    int64_t ** const * const **l_974 = &l_975;
                    int8_t *l_976 = &g_145;
                    int i, j;
                    l_849[2][0] = (safe_lshift_func_int8_t_s_s((((((void*)0 == &g_517) > l_869) && (((safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s((l_795[2] <= (safe_lshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u((((((**g_240) |= (**p_93)) ^ ((void*)0 != l_946)) , l_849[1][2]) | (safe_sub_func_int64_t_s_s(l_884[7][1][3], l_926[4]))), l_949[6][7])), 1))), 18446744073709551611UL)), g_133)) || g_604) == l_949[6][7])) , l_883), g_768));
                    g_126 &= ((**p_91) = (safe_sub_func_uint32_t_u_u((((((((~(l_869 & (&p_92 != &p_92))) >= 0L) < (((safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((((((*l_957)++) <= (safe_sub_func_int64_t_s_s((g_962 , (((((*l_976) = (((((*g_789) = ((safe_sub_func_uint16_t_u_u((((*l_965) = l_949[6][7]) | (+(safe_div_func_uint16_t_u_u((((((safe_rshift_func_int16_t_s_u((safe_mod_func_int8_t_s_s(l_869, g_973)), 14)) != (((((*l_974) = (void*)0) == &g_517) != (-1L)) <= (**p_91))) | l_926[6]) <= l_949[6][7]) ^ (*g_188)), 0xE639L)))), l_869)) ^ (**p_93))) ^ 4294967291UL) < g_522) , g_145)) , l_849[2][3]) == 8UL) , l_926[6])), l_869))) , 0UL) , (*g_188)) != (*p_92)), l_925)), 0xBD55L)) <= (*p_92)) ^ l_884[3][0][0])) > l_929) , g_132) & 1L) & l_818), (*g_241))));
                }
            }
            return (**g_391);
        }
        l_980++;
        return l_795[5];
    }
    (**p_93) |= (*g_56);
    g_985++;
    for (g_310 = 0; (g_310 <= 4); g_310 += 1)
    { /* block id: 447 */
        int16_t l_992 = (-1L);
        uint16_t *l_993 = &g_783;
        const union U1 *l_999 = &g_55;
        const union U1 * const *l_998[2];
        int16_t l_1005[6];
        const int64_t **l_1034 = (void*)0;
        const int64_t ***l_1033 = &l_1034;
        int32_t l_1044 = 0x351C3218L;
        int32_t *l_1055[9][9][2] = {{{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]}},{{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984}},{{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0}},{{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0}},{{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0}},{{&l_849[1][1],&g_984},{(void*)0,&g_984},{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{&l_849[1][1],&g_984},{(void*)0,&g_984}},{{&l_849[1][1],(void*)0},{(void*)0,&l_849[1][1]},{&g_984,(void*)0},{&g_984,&l_849[1][1]},{(void*)0,(void*)0},{(void*)0,&l_849[1][1]},{&g_768,&l_849[1][1]},{(void*)0,&l_1044},{&l_1044,(void*)0}},{{&l_849[1][1],&g_768},{&l_849[1][1],(void*)0},{&l_1044,&l_1044},{(void*)0,&l_849[1][1]},{&g_768,&l_849[1][1]},{(void*)0,&l_1044},{&l_1044,(void*)0},{&l_849[1][1],&g_768},{&l_849[1][1],(void*)0}},{{&l_1044,&l_1044},{(void*)0,&l_849[1][1]},{&g_768,&l_849[1][1]},{(void*)0,&l_1044},{&l_1044,(void*)0},{&l_849[1][1],&g_768},{&l_849[1][1],(void*)0},{&l_1044,&l_1044},{(void*)0,&l_849[1][1]}}};
        union U0 *l_1067 = &g_1068[8];
        int16_t l_1085 = 0L;
        const uint32_t l_1106[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_998[i] = &l_999;
        for (i = 0; i < 6; i++)
            l_1005[i] = 0x0AD9L;
        (**p_91) |= ((((((safe_mod_func_int16_t_s_s((*p_92), ((safe_add_func_uint16_t_u_u(((*l_993) = l_992), (l_992 ^ l_992))) & l_992))) , g_994[8][4][2]) , (((void*)0 == l_997) >= (l_998[1] == l_997))) , (**p_93)) != l_992) && g_522);
        for (g_227 = 0; (g_227 <= 4); g_227 += 1)
        { /* block id: 452 */
            union U0 *l_1007[3];
            int32_t l_1010[10][2] = {{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)}};
            const union U1 *l_1064 = &g_55;
            const int64_t *** const *l_1083 = &l_1033;
            const int64_t *** const ** const l_1082 = &l_1083;
            int i, j;
            for (i = 0; i < 3; i++)
                l_1007[i] = (void*)0;
            g_1000--;
            for (g_604 = 1; (g_604 <= 4); g_604 += 1)
            { /* block id: 456 */
                const uint16_t l_1004 = 9UL;
                int16_t **l_1012[8] = {&g_128,&g_128,&g_128,&g_128,&g_128,&g_128,&g_128,&g_128};
                int16_t ***l_1011 = &l_1012[3];
                int32_t *l_1042 = &l_849[2][0];
                int32_t l_1046 = (-1L);
                int32_t l_1047 = (-3L);
                int32_t l_1049 = 2L;
                int32_t l_1050 = 1L;
                int64_t **l_1095[2][4][9] = {{{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,(void*)0,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519}},{{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,(void*)0,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,(void*)0,&g_519,&g_519},{&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519,&g_519}}};
                int i, j, k;
            }
        }
        for (g_568 = (-10); (g_568 > 11); ++g_568)
        { /* block id: 543 */
            (**p_91) |= ((**p_94) = 1L);
        }
    }
    return (**g_391);
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_126 g_133 g_57 g_55.f0 g_49 g_129 g_132 g_131 g_145 g_54 g_227 g_65 g_241 g_295 g_240 g_50 g_326 g_334 g_149 g_372 g_121 g_386 g_391 g_282 g_321 g_262 g_311 g_235 g_187 g_188 g_310 g_524 g_531 g_538 g_574 g_605 g_649 g_24 g_522 g_568 g_284 g_706 g_744 g_332.f2
 * writes: g_126 g_128 g_131 g_132 g_133 g_70.f2 g_145 g_149 g_49 g_24 g_284 g_241 g_321 g_326 g_54 g_334 g_55.f0 g_121 g_310 g_129 g_227 g_332.f2 g_282 g_517 g_524 g_531 g_262 g_538 g_574 g_605 g_522 g_568 g_604
 */
static uint16_t  func_97(const int32_t ** p_98, uint8_t  p_99, uint32_t * p_100, int32_t * p_101)
{ /* block id: 46 */
    int16_t *l_124 = &g_65;
    int32_t *l_125[1][9] = {{&g_126,&g_126,&g_126,&g_126,&g_126,&g_126,&g_126,&g_126,&g_126}};
    int16_t **l_127[5][3][6] = {{{&l_124,&l_124,&l_124,(void*)0,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,(void*)0}},{{&l_124,&l_124,&l_124,(void*)0,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,(void*)0},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124}},{{&l_124,&l_124,&l_124,&l_124,(void*)0,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124}},{{&l_124,(void*)0,(void*)0,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124}},{{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124},{(void*)0,(void*)0,&l_124,&l_124,&l_124,&l_124},{&l_124,&l_124,&l_124,&l_124,&l_124,&l_124}}};
    int16_t *l_130 = &g_129;
    int32_t l_134 = (-8L);
    uint32_t *l_143 = &g_70.f2;
    int8_t *l_144[1];
    uint16_t *l_148 = &g_149;
    const int32_t l_225 = 0x096A69D1L;
    uint8_t l_258 = 8UL;
    const uint64_t *l_294 = &g_295;
    int64_t *l_299 = &g_282[1][2][4];
    int8_t l_302 = 0x52L;
    union U1 l_354[7][7][1] = {{{{0x2526L}},{{1UL}},{{0UL}},{{0UL}},{{0x5054L}},{{0x5054L}},{{0UL}}},{{{0UL}},{{1UL}},{{0x2526L}},{{0UL}},{{0xFC6AL}},{{5UL}},{{0xE474L}}},{{{1UL}},{{0xF561L}},{{1UL}},{{0xF561L}},{{1UL}},{{0xE474L}},{{5UL}}},{{{0xFC6AL}},{{0UL}},{{0x2526L}},{{1UL}},{{0UL}},{{0UL}},{{0x5054L}}},{{{0x5054L}},{{0UL}},{{0UL}},{{1UL}},{{0x2526L}},{{0UL}},{{0xFC6AL}}},{{{5UL}},{{0xE474L}},{{1UL}},{{0xF561L}},{{1UL}},{{0xF561L}},{{1UL}}},{{{0xE474L}},{{5UL}},{{0xFC6AL}},{{0UL}},{{0x2526L}},{{1UL}},{{0UL}}}};
    int64_t l_426 = 2L;
    const int64_t *l_515 = (void*)0;
    const int64_t **l_514[3];
    const int64_t ***l_513 = &l_514[1];
    int32_t l_597 = 0xD03B4629L;
    uint16_t l_619 = 5UL;
    uint16_t l_620 = 0xFAC7L;
    int8_t l_696[6][10] = {{1L,0xCBL,0x1FL,(-8L),(-3L),(-8L),0x1FL,0xCBL,1L,0xA5L},{1L,5L,0L,0x70L,(-8L),0xA5L,0xA5L,(-8L),0x70L,0L},{0xA5L,0xA5L,(-8L),0x70L,0L,5L,1L,0xF0L,1L,5L},{0x1FL,(-8L),(-3L),(-8L),0x1FL,0xCBL,1L,0xA5L,0L,0L},{0x70L,0xA5L,0x03L,5L,5L,0x03L,0xA5L,0x70L,(-3L),0L},{0xF0L,5L,0xA5L,0x22L,0x1FL,1L,0x1FL,0x22L,0xA5L,5L}};
    union U0 *l_742[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_144[i] = &g_145;
    for (i = 0; i < 3; i++)
        l_514[i] = &l_515;
    g_126 &= (l_124 == (g_55 , &g_65));
    g_133 ^= (g_132 = (g_126 = ((l_130 = (g_128 = (void*)0)) != (g_131 = &g_129))));
    if (((l_134 , func_59((**p_98), (g_55.f0 ^ (safe_sub_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((0x7BL && (g_145 = ((*p_100) & ((*l_143) = (safe_lshift_func_int16_t_s_s((g_129 , 0x996AL), 1)))))), (safe_rshift_func_uint16_t_u_s(((*l_148) = 1UL), 12)))), (safe_mod_func_uint64_t_u_u(p_99, g_132)))) > g_57), p_99))))) == (void*)0))
    { /* block id: 57 */
        int32_t **l_161 = &l_125[0][3];
        const int16_t *l_164 = (void*)0;
        const int16_t **l_163 = &l_164;
        int32_t l_205 = 3L;
        int32_t l_234[8] = {1L,0xB204B197L,1L,0xB204B197L,1L,0xB204B197L,1L,0xB204B197L};
        int32_t l_259 = (-10L);
        int64_t l_280 = (-1L);
        int i;
        if (((~(safe_mul_func_int8_t_s_s((((((p_99 | (safe_mul_func_uint8_t_u_u(g_49, (safe_lshift_func_uint8_t_u_u((((((((safe_add_func_int64_t_s_s(g_126, (0x38B5D02C25FA6A51LL ^ ((void*)0 != l_161)))) <= 6L) <= (p_99 || (-9L))) | g_133) && p_99) != 0x76E874D0L) ^ (*g_131)), 2))))) <= (*p_101)) , 0x129BBF80L) < g_57) <= 0L), 0x37L))) > 0x2BE5L))
        { /* block id: 58 */
            int8_t l_162 = 0xE1L;
            return l_162;
        }
        else
        { /* block id: 60 */
            const int16_t ***l_165 = &l_163;
            (*l_165) = l_163;
        }
        g_126 ^= (**p_98);
        (**l_161) = ((-8L) ^ 0xC6L);
        for (g_145 = 0; (g_145 > 23); g_145++)
        { /* block id: 67 */
            uint16_t l_185[10][8] = {{5UL,0x3B9AL,0x3B9AL,5UL,65529UL,5UL,0x3B9AL,0x3B9AL},{0x3B9AL,65529UL,65529UL,65529UL,0xAEF9L,5UL,0xAEF9L,65529UL},{0xF94CL,0xAEF9L,0xF94CL,5UL,5UL,0xF94CL,0xAEF9L,0xF94CL},{0x3B9AL,5UL,65529UL,5UL,0x3B9AL,0x3B9AL,5UL,65529UL},{0x3B9AL,0x3B9AL,5UL,65529UL,5UL,0x3B9AL,0x3B9AL,5UL},{0xF94CL,5UL,5UL,0xF94CL,0xAEF9L,0xF94CL,5UL,5UL},{5UL,0xAEF9L,65529UL,65529UL,0xAEF9L,5UL,0xAEF9L,65529UL},{0xF94CL,0xAEF9L,0xF94CL,5UL,5UL,0xF94CL,0xAEF9L,0xF94CL},{0x3B9AL,5UL,65529UL,5UL,0x3B9AL,0x3B9AL,5UL,65529UL},{0x3B9AL,0x3B9AL,5UL,65529UL,5UL,0x3B9AL,0x3B9AL,5UL}};
            int32_t **l_238 = &l_125[0][3];
            int32_t **l_239 = (void*)0;
            int32_t l_242 = 0x4DE94C89L;
            int i, j;
            for (g_133 = 0; (g_133 <= 0); g_133 += 1)
            { /* block id: 70 */
                uint8_t *l_178 = &g_121;
                uint32_t l_190 = 9UL;
                union U1 l_226 = {0UL};
                int i, j;
            }
            (*l_238) = (void*)0;
            g_126 |= (l_242 = ((+(((*p_100)--) , g_54)) != 1UL));
        }
    }
    else
    { /* block id: 117 */
        uint8_t *l_288[3][5] = {{&g_121,&l_258,&g_121,&g_121,&l_258},{&l_258,&g_121,&g_121,&l_258,&g_121},{&l_258,&l_258,&l_258,&l_258,&l_258}};
        int32_t l_289 = 7L;
        int64_t *l_301[4][2][7] = {{{&g_282[4][2][0],&g_284,&g_282[4][2][0],&g_282[4][2][0],&g_284,&g_282[4][2][0],&g_282[4][2][0]},{&g_284,(void*)0,&g_284,(void*)0,&g_284,&g_284,&g_284}},{{&g_284,&g_282[4][2][0],&g_282[4][2][0],&g_284,&g_282[4][2][0],&g_282[4][2][0],&g_282[3][4][0]},{&g_284,(void*)0,&g_284,(void*)0,&g_284,(void*)0,&g_284}},{{&g_284,&g_284,&g_284,&g_282[3][4][0],&g_284,&g_284,&g_282[3][4][0]},{&g_284,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_284}},{{&g_282[4][2][0],&g_282[3][4][0],&g_282[4][2][0],&g_282[4][2][0],&g_284,&g_282[4][2][0],&g_282[4][2][0]},{&g_284,(void*)0,&g_282[0][1][0],(void*)0,&g_284,&g_284,&g_284}}};
        int64_t **l_300 = &l_301[0][0][5];
        uint64_t *l_303 = (void*)0;
        uint64_t *l_304 = &g_24;
        int32_t l_305 = 0x7196CBE4L;
        const int32_t *l_320 = (void*)0;
        uint16_t *l_339 = &g_55.f0;
        int8_t l_377 = 0x57L;
        int8_t l_507[1];
        int32_t l_523[6][2][4] = {{{0x12040362L,0x9DDC78E9L,0x12040362L,0x4FC837D2L},{0x12040362L,0x4FC837D2L,0x4FC837D2L,0x12040362L}},{{0xD651E1EFL,0x4FC837D2L,(-9L),0x4FC837D2L},{0x4FC837D2L,0x9DDC78E9L,(-9L),(-9L)}},{{0xD651E1EFL,0xD651E1EFL,0x4FC837D2L,(-9L)},{0x12040362L,0x9DDC78E9L,0x12040362L,0x4FC837D2L}},{{0x12040362L,0x4FC837D2L,0x4FC837D2L,0x12040362L},{0xD651E1EFL,0x4FC837D2L,(-9L),0x4FC837D2L}},{{0x4FC837D2L,0x9DDC78E9L,(-9L),(-9L)},{0xD651E1EFL,0xD651E1EFL,0x4FC837D2L,(-9L)}},{{0x12040362L,0x9DDC78E9L,0x12040362L,0x4FC837D2L},{0x12040362L,0x4FC837D2L,0x4FC837D2L,0x12040362L}}};
        int32_t *l_544 = &g_54;
        uint32_t l_659 = 0x2816CE74L;
        uint16_t l_695[4];
        union U1 *l_781 = (void*)0;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_507[i] = 0x46L;
        for (i = 0; i < 4; i++)
            l_695[i] = 0UL;
lbl_660:
        l_305 &= (((++p_99) , p_99) | (safe_div_func_uint16_t_u_u(((l_294 = &g_24) == (l_289 , (void*)0)), (g_227 ^ (l_289 > (l_289 > (((*l_304) = ((((safe_unary_minus_func_uint16_t_u(((safe_lshift_func_int16_t_s_u(((l_299 == ((*l_300) = l_299)) , l_302), g_65)) > l_289))) && l_289) >= (*g_241)) , g_55.f0)) , g_295)))))));
        if ((0xE3B36A9DL | (safe_unary_minus_func_uint64_t_u(((g_126 = (*p_101)) != 0x756B02ECL)))))
        { /* block id: 124 */
            int32_t l_309 = (-2L);
            int32_t *l_319 = (void*)0;
            uint32_t l_371 = 6UL;
            int32_t l_378[9] = {0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L,0x8F4F5EA7L};
            int i;
            for (g_24 = 0; (g_24 > 13); ++g_24)
            { /* block id: 127 */
                uint32_t l_312[2][6][1] = {{{0x0B34B949L},{18446744073709551607UL},{0x0B34B949L},{18446744073709551607UL},{0x0B34B949L},{18446744073709551607UL}},{{0x0B34B949L},{18446744073709551607UL},{0x0B34B949L},{18446744073709551607UL},{0x0B34B949L},{18446744073709551607UL}}};
                int i, j, k;
                l_312[1][3][0]++;
                for (g_284 = (-10); (g_284 == 24); ++g_284)
                { /* block id: 131 */
                    for (l_134 = 15; (l_134 >= (-20)); l_134 = safe_sub_func_uint8_t_u_u(l_134, 7))
                    { /* block id: 134 */
                        if ((*p_101))
                            break;
                        if ((**g_240))
                            continue;
                        (*g_240) = (l_319 = (*g_240));
                    }
                    if ((*g_241))
                        continue;
                }
                l_320 = (*p_98);
            }
            for (l_289 = 0; (l_289 <= 4); l_289 += 1)
            { /* block id: 146 */
                int32_t l_324 = 0x1CFB4111L;
                g_321 = (*p_98);
                l_305 |= (g_50 != (safe_add_func_uint64_t_u_u(p_99, 0x34F45D0BD218EFC8LL)));
                for (g_24 = 1; (g_24 <= 4); g_24 += 1)
                { /* block id: 151 */
                    int16_t l_325 = 0x070FL;
                    const union U0 *l_331[7] = {&g_332,&g_332,&g_332,&g_332,&g_332,&g_332,&g_332};
                    const union U0 **l_330[7];
                    const union U0 ***l_329 = &l_330[1];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_330[i] = &l_331[0];
                    l_324 ^= 0x2587180BL;
                    g_326--;
                    (*l_329) = (void*)0;
                    for (g_54 = 0; (g_54 <= 4); g_54 += 1)
                    { /* block id: 157 */
                        int8_t l_333 = 0L;
                        g_334[1]++;
                    }
                    for (g_55.f0 = 0; (g_55.f0 <= 4); g_55.f0 += 1)
                    { /* block id: 162 */
                        uint16_t l_340 = 0xABF2L;
                        if ((*g_241))
                            break;
                        (*p_98) = func_59((safe_mul_func_uint16_t_u_u((l_339 == l_130), 0xFFD4L)), (l_340 || (safe_unary_minus_func_uint8_t_u((p_99 = (g_121 = p_99))))));
                        (*g_240) = func_59((&g_145 != ((((**p_98) && l_324) >= (safe_add_func_uint8_t_u_u((p_99 || (safe_mul_func_int16_t_s_s(((((safe_add_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_s(((*g_131) , 0x5EL), 7)) , (g_334[1] == (safe_sub_func_uint32_t_u_u(((l_324 ^ (p_99 || g_149)) && 65535UL), (-1L))))) & 0x0C199CFDA8591A7FLL), l_325)) ^ 4294967294UL) , 0x94B8L) | l_324), 0xDEABL))), 0xF4L))) , &l_302)), l_324);
                    }
                }
            }
            for (g_310 = 4; (g_310 == 14); g_310 = safe_add_func_uint32_t_u_u(g_310, 6))
            { /* block id: 173 */
                (*p_98) = (l_354[3][1][0] , (*p_98));
            }
            for (g_54 = 0; (g_54 != 28); g_54 = safe_add_func_int8_t_s_s(g_54, 4))
            { /* block id: 178 */
                union U0 *l_373[7][3] = {{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0},{(void*)0,&g_374,(void*)0}};
                int32_t l_375[3][9][6] = {{{0x6072BF6EL,0x29E2CB7DL,0xD97BF032L,0xEB6840F7L,0x201B4DF1L,0xBFB77E27L},{3L,6L,0x64EA6D07L,0xBFB77E27L,3L,0L},{0L,6L,0xAA11183EL,(-9L),0x201B4DF1L,(-9L)},{2L,0x29E2CB7DL,2L,6L,0x44838C9CL,1L},{0x5059EE49L,0xB0DD6536L,0xAA11183EL,0xEB6840F7L,0x6072BF6EL,0xB0DD6536L},{0x44838C9CL,0x43994B56L,0x64EA6D07L,0xEB6840F7L,(-1L),6L},{0x5059EE49L,6L,0xD97BF032L,6L,0x5059EE49L,0L},{2L,0xBFB77E27L,0x44838C9CL,(-9L),(-1L),1L},{0L,0x29E2CB7DL,0x08A3A49CL,0xBFB77E27L,0x6072BF6EL,1L}},{{3L,0L,0x44838C9CL,0xEB6840F7L,0x44838C9CL,0L},{0x6072BF6EL,0x43994B56L,0xD97BF032L,0x0C4930CAL,0x201B4DF1L,6L},{3L,0xBFB77E27L,0x64EA6D07L,6L,3L,0xB0DD6536L},{0L,0xBFB77E27L,0xAA11183EL,1L,0x201B4DF1L,1L},{2L,0x43994B56L,2L,0xBFB77E27L,0x44838C9CL,(-9L)},{0x5059EE49L,0L,0xAA11183EL,0x0C4930CAL,0x6072BF6EL,0L},{0x44838C9CL,0x29E2CB7DL,0x64EA6D07L,0x0C4930CAL,(-1L),0xBFB77E27L},{0x5059EE49L,0xBFB77E27L,0xD97BF032L,0xBFB77E27L,0x5059EE49L,0xB0DD6536L},{2L,6L,0x44838C9CL,1L,(-1L),(-9L)}},{{0L,0x43994B56L,0x08A3A49CL,6L,0x6072BF6EL,(-9L)},{3L,0xB0DD6536L,0x44838C9CL,0x0C4930CAL,0x44838C9CL,0xB0DD6536L},{0x6072BF6EL,0x29E2CB7DL,0xD97BF032L,0xEB6840F7L,0x201B4DF1L,0xBFB77E27L},{3L,6L,0x64EA6D07L,0xBFB77E27L,3L,0L},{0L,6L,0xAA11183EL,(-9L),0x201B4DF1L,(-9L)},{2L,0x29E2CB7DL,2L,6L,0x44838C9CL,0xEB6840F7L},{0x6072BF6EL,0xBFB77E27L,0x08A3A49CL,0x29E2CB7DL,0L,0xBFB77E27L},{2L,0L,(-1L),0x29E2CB7DL,3L,(-9L)},{0x6072BF6EL,(-9L),0xB2B4A36AL,(-9L),0x6072BF6EL,6L}}};
                int32_t l_376[6][5][1] = {{{0L},{(-7L)},{7L},{0L},{7L}},{{7L},{0L},{7L},{(-7L)},{0L}},{{(-7L)},{7L},{0L},{7L},{7L}},{{0L},{7L},{(-7L)},{0L},{(-7L)}},{{7L},{0L},{7L},{7L},{0L}},{{7L},{(-7L)},{0L},{(-7L)},{7L}}};
                int i, j, k;
                l_378[8] &= (safe_mod_func_int8_t_s_s(((0x09B90E5FE341C27FLL > (safe_rshift_func_int8_t_s_u((safe_mul_func_uint8_t_u_u((((*g_131) = p_99) == 0x2CA0L), ((g_54 , 0x532BE6095AE59C1DLL) | ((((safe_sub_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((safe_mul_func_int16_t_s_s((l_371 , (&l_127[3][2][5] == &g_187)), ((l_375[2][0][4] = (g_372 != l_373[0][0])) <= g_57))), g_49)), (*p_101))), l_376[4][0][0])) || l_377) < p_99) <= (*p_100))))), p_99))) >= 65530UL), 0x99L));
            }
        }
        else
        { /* block id: 183 */
            uint16_t l_381 = 0x2E9BL;
            int64_t **l_389[2][1];
            int64_t ***l_390 = &l_389[0][0];
            int32_t l_394 = 0L;
            union U0 **l_396 = &g_372;
            union U0 ***l_395 = &l_396;
            uint32_t l_427 = 0UL;
            uint8_t l_482 = 0x59L;
            int32_t l_530[6] = {4L,0L,4L,4L,0L,4L};
            int64_t l_556[10] = {0x3AD9857C1E255D05LL,0xCF350D01EACE100BLL,0x3AD9857C1E255D05LL,0xCF350D01EACE100BLL,0x3AD9857C1E255D05LL,0xCF350D01EACE100BLL,0x3AD9857C1E255D05LL,0xCF350D01EACE100BLL,0x3AD9857C1E255D05LL,0xCF350D01EACE100BLL};
            uint32_t l_598[7] = {0xA8139390L,0xA8139390L,0x984719CCL,0xA8139390L,0xA8139390L,0x984719CCL,0xA8139390L};
            uint16_t l_601 = 0xFDB7L;
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_389[i][j] = &l_299;
            }
            (*g_240) = (g_121 , func_59((*p_101), (0x87328B7BCCE4DE5CLL | ((*l_304) = g_57))));
            if (((safe_lshift_func_int16_t_s_u((l_381 >= (0L <= ((g_227 > ((void*)0 == g_386)) , (((((((g_121 = (safe_rshift_func_int8_t_s_s(((l_394 = (((*l_390) = l_389[0][0]) != g_391)) <= p_99), ((((*l_395) = &g_372) == (void*)0) , p_99)))) & l_381) && 0x2D61L) && p_99) || 0x93L) | 0x14C7L) >= g_282[2][0][0])))), l_381)) , 0xE3145CBEL))
            { /* block id: 190 */
                int32_t l_399[3];
                int32_t l_416 = 0x6BEBC717L;
                int i;
                for (i = 0; i < 3; i++)
                    l_399[i] = 0x228E07A7L;
                g_227 = (safe_div_func_int16_t_s_s(l_399[0], (safe_sub_func_uint16_t_u_u(p_99, ((*g_131) &= p_99)))));
                for (l_289 = (-13); (l_289 > 21); ++l_289)
                { /* block id: 195 */
                    uint8_t l_428[10][7] = {{0xA6L,8UL,0x64L,0x64L,8UL,0xA6L,1UL},{254UL,0x97L,1UL,1UL,0x97L,254UL,0x50L},{0xA6L,8UL,0x64L,0x64L,8UL,0xA6L,1UL},{254UL,0x97L,1UL,1UL,0x97L,254UL,0x50L},{0xA6L,8UL,0x64L,0x64L,8UL,0xA6L,1UL},{254UL,0x97L,1UL,1UL,0x97L,254UL,0x50L},{0xA6L,8UL,0x64L,0x64L,8UL,0xA6L,1UL},{254UL,0x97L,1UL,1UL,0x97L,254UL,0x50L},{0xA6L,8UL,0x64L,0x64L,8UL,0xA6L,1UL},{254UL,0x97L,1UL,1UL,0x97L,254UL,0x50L}};
                    int32_t l_429 = 0x9455F232L;
                    uint8_t **l_430 = &l_288[0][3];
                    uint8_t *l_449 = &l_258;
                    int32_t *l_450 = &g_54;
                    int i, j;
                    if ((*g_321))
                    { /* block id: 196 */
                        g_227 = (**p_98);
                    }
                    else
                    { /* block id: 198 */
                        uint32_t l_404 = 0x3DC19A49L;
                        uint32_t *l_413 = (void*)0;
                        uint32_t *l_414 = &g_79[4].f2;
                        uint32_t *l_415[1][8][3] = {{{&g_235,&g_235,&g_49},{&g_235,&g_235,&g_235},{&g_49,&g_235,&g_49},{(void*)0,(void*)0,(void*)0},{&g_374.f2,&g_235,&g_235},{(void*)0,&g_235,&g_49},{&g_374.f2,&g_235,&g_374.f2},{(void*)0,(void*)0,&g_49}}};
                        int32_t l_425[8][4] = {{0xE8AA48CAL,3L,0xABF22F9AL,1L},{1L,3L,3L,1L},{0xE8AA48CAL,3L,0xABF22F9AL,1L},{1L,3L,3L,1L},{0xE8AA48CAL,3L,0xABF22F9AL,1L},{1L,3L,3L,1L},{0xE8AA48CAL,3L,0xABF22F9AL,1L},{1L,3L,3L,1L}};
                        int i, j, k;
                        l_404--;
                        l_426 &= (l_305 = ((*g_262) , ((safe_div_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(g_227, 6)) < (((*p_100) <= ((l_416 |= ((safe_rshift_func_int16_t_s_s((g_133 = ((*g_131) = l_399[0])), 0)) != 0x5EAEFBCFB0B8F56ALL)) != ((safe_add_func_uint16_t_u_u(p_99, (safe_mul_func_uint16_t_u_u(((((l_425[4][3] = (l_394 = ((safe_mul_func_uint16_t_u_u(65535UL, 1L)) <= ((safe_div_func_int8_t_s_s(p_99, g_282[4][4][0])) < 0UL)))) , p_99) | g_55.f0) < 255UL), 0L)))) >= 0x96L))) , 4UL)), 65535UL)) ^ (-9L))));
                        if (l_427)
                            break;
                        return g_126;
                    }
                    if ((**g_240))
                        break;
                    l_429 = (l_428[4][4] &= (**p_98));
                    if ((((*l_430) = &p_99) == (((*l_450) = (((((((l_381 >= ((*p_100) < (safe_rshift_func_uint8_t_u_s(((safe_sub_func_int8_t_s_s((safe_rshift_func_int8_t_s_u((safe_lshift_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(g_282[4][2][0], (p_99 && (g_311 || p_99)))) , (((((l_394 <= ((~(((safe_rshift_func_uint8_t_u_s(((*l_449) &= ((((!(safe_lshift_func_uint8_t_u_u(l_381, 3))) && p_99) | 65531UL) , p_99)), 1)) & 65530UL) <= p_99)) == p_99)) == l_428[2][5]) < 0x6ED8L) > g_50) && (*p_101))), (*g_131))), l_416)), l_399[2])), g_235)) > 2L), p_99)))) <= 0x1425L) , g_132) | 0xB9L) | l_381) && 0xB9109006L) , 1L)) , (void*)0)))
                    { /* block id: 216 */
                        return g_326;
                    }
                    else
                    { /* block id: 218 */
                        int64_t l_451[7][2][9] = {{{0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL,0xFBCF9DDCB58361EALL,(-6L),(-6L),0xFBCF9DDCB58361EALL,0x361D35C9364D3CE2LL,(-9L)},{0xFBCF9DDCB58361EALL,2L,0x361D35C9364D3CE2LL,0x9BE04A1150663E61LL,2L,(-9L),2L,0x361D35C9364D3CE2LL,0x361D35C9364D3CE2LL}},{{0xEE7A006916F802E4LL,(-6L),(-9L),0x9BE04A1150663E61LL,(-9L),(-6L),0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL},{1L,2L,0xC001E61C222AE68FLL,0xFBCF9DDCB58361EALL,(-9L),0xC001E61C222AE68FLL,2L,0xC001E61C222AE68FLL,(-9L)}},{{1L,(-9L),(-9L),1L,2L,0xC001E61C222AE68FLL,0xFBCF9DDCB58361EALL,(-9L),0xC001E61C222AE68FLL},{0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL,0xFBCF9DDCB58361EALL,(-6L),(-6L),0xFBCF9DDCB58361EALL,0x361D35C9364D3CE2LL,(-9L)}},{{0xFBCF9DDCB58361EALL,2L,0x361D35C9364D3CE2LL,0x9BE04A1150663E61LL,2L,(-9L),2L,0x361D35C9364D3CE2LL,0x361D35C9364D3CE2LL},{0xEE7A006916F802E4LL,(-6L),(-9L),0x9BE04A1150663E61LL,(-9L),(-6L),0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL}},{{1L,2L,0xC001E61C222AE68FLL,0xFBCF9DDCB58361EALL,(-9L),0xC001E61C222AE68FLL,2L,0xC001E61C222AE68FLL,(-9L)},{1L,(-9L),(-9L),1L,2L,0xC001E61C222AE68FLL,0xFBCF9DDCB58361EALL,(-9L),0xC001E61C222AE68FLL}},{{0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL,0xFBCF9DDCB58361EALL,(-6L),(-6L),0xFBCF9DDCB58361EALL,0x361D35C9364D3CE2LL,(-9L)},{0xFBCF9DDCB58361EALL,2L,0x361D35C9364D3CE2LL,0x9BE04A1150663E61LL,2L,(-9L),2L,0x361D35C9364D3CE2LL,0x361D35C9364D3CE2LL}},{{0xEE7A006916F802E4LL,(-6L),(-9L),0x9BE04A1150663E61LL,(-9L),(-6L),0xEE7A006916F802E4LL,(-9L),0x361D35C9364D3CE2LL},{1L,2L,0xC001E61C222AE68FLL,0xFBCF9DDCB58361EALL,(-9L),0xC001E61C222AE68FLL,2L,0xC001E61C222AE68FLL,(-9L)}}};
                        int i, j, k;
                        g_227 = (0x21B8BF52L == (l_451[5][1][5] != (safe_lshift_func_int16_t_s_u((g_145 && p_99), 0))));
                    }
                }
                (*g_240) = (*g_240);
            }
            else
            { /* block id: 223 */
                int64_t l_481 = 0x48AC47CD2B59D192LL;
                uint64_t l_484 = 0xF2DE0FF5CEE79E77LL;
                int64_t ****l_516[10][4][6] = {{{&l_390,(void*)0,(void*)0,&l_390,&l_390,&l_390},{&l_390,&l_390,&l_390,&l_390,(void*)0,(void*)0},{&l_390,&l_390,&l_390,&l_390,(void*)0,&l_390},{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390}},{{(void*)0,(void*)0,(void*)0,&l_390,(void*)0,&l_390},{&l_390,&l_390,&l_390,(void*)0,&l_390,&l_390},{(void*)0,&l_390,&l_390,(void*)0,&l_390,(void*)0},{&l_390,&l_390,(void*)0,&l_390,&l_390,(void*)0}},{{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390},{&l_390,&l_390,&l_390,(void*)0,&l_390,&l_390},{&l_390,&l_390,(void*)0,&l_390,(void*)0,&l_390},{(void*)0,&l_390,&l_390,&l_390,(void*)0,&l_390}},{{(void*)0,&l_390,(void*)0,&l_390,(void*)0,&l_390},{(void*)0,&l_390,&l_390,&l_390,(void*)0,&l_390},{&l_390,&l_390,(void*)0,&l_390,(void*)0,&l_390},{(void*)0,&l_390,&l_390,&l_390,&l_390,&l_390}},{{&l_390,&l_390,(void*)0,(void*)0,&l_390,&l_390},{&l_390,(void*)0,(void*)0,&l_390,&l_390,&l_390},{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390},{(void*)0,&l_390,&l_390,(void*)0,&l_390,&l_390}},{{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390},{&l_390,(void*)0,&l_390,&l_390,&l_390,&l_390},{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390},{(void*)0,&l_390,(void*)0,&l_390,&l_390,&l_390}},{{&l_390,&l_390,(void*)0,&l_390,&l_390,(void*)0},{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390},{(void*)0,&l_390,(void*)0,&l_390,(void*)0,&l_390},{&l_390,&l_390,&l_390,&l_390,&l_390,&l_390}},{{&l_390,&l_390,&l_390,&l_390,&l_390,(void*)0},{&l_390,&l_390,(void*)0,(void*)0,&l_390,&l_390},{(void*)0,&l_390,&l_390,&l_390,&l_390,(void*)0},{&l_390,(void*)0,&l_390,&l_390,&l_390,&l_390}},{{&l_390,&l_390,&l_390,(void*)0,&l_390,&l_390},{&l_390,(void*)0,&l_390,&l_390,&l_390,(void*)0},{(void*)0,&l_390,(void*)0,&l_390,&l_390,&l_390},{&l_390,&l_390,&l_390,&l_390,(void*)0,&l_390}},{{(void*)0,&l_390,&l_390,&l_390,&l_390,&l_390},{(void*)0,&l_390,&l_390,&l_390,&l_390,(void*)0},{(void*)0,(void*)0,&l_390,&l_390,&l_390,(void*)0},{&l_390,&l_390,&l_390,(void*)0,&l_390,(void*)0}}};
                int32_t l_521 = 0x953C15ADL;
                int32_t l_528 = 5L;
                int32_t l_529 = (-1L);
                int32_t *l_543 = (void*)0;
                int32_t **l_542[1][2][4] = {{{&l_543,&l_543,&l_543,&l_543},{&l_543,&l_543,&l_543,&l_543}}};
                uint32_t l_559 = 0x2D48C362L;
                int i, j, k;
lbl_512:
                for (g_332.f2 = (-9); (g_332.f2 != 37); g_332.f2++)
                { /* block id: 226 */
                    uint32_t l_459 = 0xB1F44EBCL;
                    int32_t l_480 = (-8L);
                    int32_t l_483[10][2][8] = {{{(-1L),0x105DCE6AL,4L,0xC69D0EBEL,0x8FEAA43EL,0xE91322AAL,0xC69D0EBEL,(-1L)},{(-5L),0x105DCE6AL,0xC711A88EL,(-9L),(-1L),(-9L),0xC711A88EL,0x105DCE6AL}},{{0x105DCE6AL,0x49DD013BL,(-9L),0x8FEAA43EL,0xC711A88EL,(-9L),(-1L),(-5L)},{(-1L),(-8L),(-2L),0L,0x105DCE6AL,(-3L),(-1L),(-1L)}},{{0x96B93EB3L,0L,(-9L),(-9L),0L,0x96B93EB3L,0xC711A88EL,(-8L)},{0L,0x96B93EB3L,0xC711A88EL,(-8L),(-9L),(-9L),0xC69D0EBEL,(-9L)}},{{(-8L),(-1L),4L,(-8L),0x105DCE6AL,0L,0x105DCE6AL,(-8L)},{0x49DD013BL,0x105DCE6AL,0x49DD013BL,(-9L),0x8FEAA43EL,0xC711A88EL,(-9L),(-1L)}},{{0x105DCE6AL,(-5L),0xC711A88EL,0L,0x3EE4E511L,(-9L),0x8FEAA43EL,(-5L)},{0x105DCE6AL,(-1L),0x8B94E0BDL,0x8FEAA43EL,0x8FEAA43EL,0x8B94E0BDL,(-1L),0x105DCE6AL}},{{0x49DD013BL,(-8L),(-5L),(-9L),0x105DCE6AL,0x96B93EB3L,0x49DD013BL,(-1L)},{(-8L),(-9L),(-9L),0xC69D0EBEL,(-9L),0x96B93EB3L,0x8FEAA43EL,0x96B93EB3L}},{{0L,(-8L),0xE91322AAL,(-8L),0L,0x8B94E0BDL,0xC69D0EBEL,0L},{0x96B93EB3L,(-1L),0x49DD013BL,0x96B93EB3L,0x105DCE6AL,(-9L),(-5L),(-8L)}},{{(-1L),(-5L),0x49DD013BL,0xC69D0EBEL,0xC711A88EL,0xC711A88EL,0xC69D0EBEL,0x49DD013BL},{0x105DCE6AL,0x105DCE6AL,0xE91322AAL,0L,(-1L),0L,0x8FEAA43EL,0x105DCE6AL}},{{(-5L),(-1L),(-9L),0xC711A88EL,0x8FEAA43EL,(-9L),0x49DD013BL,0x105DCE6AL},{(-1L),0x96B93EB3L,(-5L),0L,(-5L),0x96B93EB3L,(-1L),0x49DD013BL}},{{(-8L),0L,0x8B94E0BDL,0xC69D0EBEL,0L,(-3L),0x8FEAA43EL,(-8L)},{(-9L),(-8L),0xC711A88EL,0x96B93EB3L,0L,(-9L),(-9L),0L}}};
                    int i, j, k;
                    l_483[3][1][5] = ((~((safe_mul_func_int16_t_s_s(((l_294 == ((l_459 < (safe_sub_func_int32_t_s_s((safe_lshift_func_uint8_t_u_u((((+((((safe_sub_func_int32_t_s_s((safe_rshift_func_int8_t_s_s((((***l_390) = g_326) & g_334[1]), 2)), (safe_mod_func_int16_t_s_s(((void*)0 == (*l_395)), (safe_rshift_func_int16_t_s_u(((((safe_lshift_func_uint16_t_u_s(((&g_392 != (void*)0) & (+((((safe_add_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_u((l_480 = 0x6E94L), g_326)) == g_334[1]) ^ l_459), l_481)) , (**p_98)) || g_65) == p_99))), l_482)) < p_99) >= g_55.f0) <= l_381), l_482)))))) , l_130) == (void*)0) > p_99)) & 1L) & l_459), 6)), l_381))) , l_303)) != l_381), (*g_131))) , p_99)) , 0x06BDCF93L);
                    l_484 &= (0x6692D8F7L < (-2L));
                    for (g_310 = 1; (g_310 >= 0); g_310 -= 1)
                    { /* block id: 233 */
                        (*p_98) = (*p_98);
                    }
                    for (l_377 = 0; (l_377 <= 7); l_377 += 1)
                    { /* block id: 238 */
                        int16_t *l_511 = &g_129;
                        int i;
                        (*g_240) = (*g_240);
                        if (g_129)
                            goto lbl_512;
                        g_126 = ((safe_sub_func_int32_t_s_s(0xE0C199E5L, ((((((safe_mod_func_int16_t_s_s((g_334[l_377] < (safe_add_func_uint8_t_u_u(((safe_add_func_int64_t_s_s((safe_sub_func_int8_t_s_s((g_282[1][3][0] & p_99), g_334[l_377])), p_99)) , (safe_lshift_func_int16_t_s_u(0xEBFEL, (safe_mul_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(((safe_mod_func_uint64_t_u_u((((((safe_lshift_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((l_480 > 0xE2L) && 0x95A35DB8D120CC5DLL), (-1L))), g_132)) != 0xC1C8L) | 0x74EF5C55755A7F1DLL) || p_99) , 0x9EC68B5FCE34533ALL), (-8L))) >= 0L), g_334[l_377])), p_99))))), 0UL))), g_334[l_377])) > l_481) || g_145) || (*g_131)) && 0xAFL) & 0xDB85L))) != l_507[0]);
                        g_126 ^= (g_334[l_377] <= ((g_133 < (((((*l_148) = (g_334[1] , g_54)) <= (*g_131)) > ((safe_unary_minus_func_int16_t_s((safe_div_func_uint64_t_u_u(((l_511 != ((g_282[4][2][0] | g_334[l_377]) , (p_99 , (*g_187)))) >= p_99), p_99)))) && 0UL)) , p_99)) && (*g_131)));
                    }
                }
                if ((l_513 != (g_517 = &l_389[1][0])))
                { /* block id: 247 */
                    int32_t l_520 = (-4L);
                    (*p_98) = (*g_240);
                    if (g_310)
                        goto lbl_527;
lbl_527:
                    ++g_524;
                    ++g_531;
                }
                else
                { /* block id: 252 */
                    union U1 *l_534 = &g_55;
                    int32_t l_536[1][9][10] = {{{0x1AA11F2EL,9L,(-4L),(-1L),(-9L),(-9L),(-1L),(-4L),9L,0x1AA11F2EL},{8L,0x0A9C5CDFL,0x69F7F0DFL,0x1AA11F2EL,9L,(-4L),(-1L),(-9L),(-9L),(-1L)},{(-9L),9L,0x0A9C5CDFL,0x0A9C5CDFL,9L,(-9L),(-4L),0x69F7F0DFL,8L,0x1AA11F2EL},{9L,(-1L),0x0A9C5CDFL,0x1AA11F2EL,(-9L),0x69F7F0DFL,0x69F7F0DFL,(-9L),0x1AA11F2EL,0x0A9C5CDFL},{9L,9L,0x69F7F0DFL,(-1L),8L,(-9L),0x0A9C5CDFL,(-4L),0x1AA11F2EL,0x1AA11F2EL},{(-9L),0x0A9C5CDFL,(-4L),0x1AA11F2EL,0x1AA11F2EL,(-4L),0x0A9C5CDFL,(-9L),8L,(-1L)},{8L,9L,(-1L),0x0A9C5CDFL,0x1AA11F2EL,(-9L),0x69F7F0DFL,0x69F7F0DFL,(-9L),0x1AA11F2EL},{0x1AA11F2EL,(-1L),(-1L),0x1AA11F2EL,8L,0x69F7F0DFL,(-4L),(-9L),9L,0x0A9C5CDFL},{0x1AA11F2EL,9L,(-4L),(-1L),(-9L),(-9L),(-1L),(-4L),9L,0x1AA11F2EL}}};
                    int i, j, k;
                    for (l_289 = 3; (l_289 >= 0); l_289 -= 1)
                    { /* block id: 255 */
                        union U1 **l_535 = &g_262;
                        int32_t l_537 = 0x9071B454L;
                        (*l_535) = l_534;
                        (*p_98) = (*p_98);
                        g_538++;
                    }
                }
                (*p_98) = (*p_98);
                if ((((safe_unary_minus_func_uint32_t_u(((l_484 != ((l_544 = (void*)0) == &g_54)) , l_521))) <= (((safe_lshift_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(0x8BD8L, ((safe_sub_func_int32_t_s_s((**g_240), (safe_mod_func_int8_t_s_s((g_145 &= (((safe_sub_func_uint64_t_u_u(((safe_unary_minus_func_uint32_t_u((*p_100))) != (((*g_131) ^= (l_556[8] > (((***l_390) ^= (safe_lshift_func_uint8_t_u_u((++l_559), 4))) , (((safe_sub_func_uint16_t_u_u(((*l_148) |= (g_132 || (**g_240))), p_99)) < 0L) > p_99)))) == p_99)), 0xEAEC2CFE2A1E0A9ELL)) , 18446744073709551607UL) || l_528)), 1L)))) == l_481))), 4)) && p_99) , l_481)) ^ p_99))
                { /* block id: 268 */
                    const uint64_t l_566 = 18446744073709551606UL;
                    int32_t l_567 = 0L;
                    if (l_566)
                    { /* block id: 269 */
                        (*p_98) = func_59((*g_321), g_334[0]);
                    }
                    else
                    { /* block id: 271 */
                        uint32_t l_569 = 0xCEF7C6C4L;
                        int32_t l_572 = (-10L);
                        int32_t l_573[3][10] = {{0x8A9A3251L,1L,1L,0x8A9A3251L,1L,1L,0x8A9A3251L,1L,1L,0x8A9A3251L},{1L,0x8A9A3251L,1L,1L,0x8A9A3251L,1L,1L,0x8A9A3251L,1L,1L},{0x8A9A3251L,0x8A9A3251L,8L,0x8A9A3251L,0x8A9A3251L,8L,0x8A9A3251L,0x8A9A3251L,8L,0x8A9A3251L}};
                        int i, j;
                        l_569++;
                        ++g_574;
                        l_598[5] &= (safe_div_func_uint32_t_u_u(0x830FE98DL, (((void*)0 != &l_572) || (safe_rshift_func_int8_t_s_u(((+(((safe_mod_func_uint8_t_u_u((p_99 | g_334[1]), 1L)) ^ (~((+((void*)0 == &g_54)) > (safe_mod_func_int64_t_s_s((safe_sub_func_int32_t_s_s((((*p_100) ^= (safe_rshift_func_uint16_t_u_s((safe_lshift_func_uint16_t_u_s((((+(safe_sub_func_int32_t_s_s(((((l_530[5] = (**g_240)) && l_559) | 4294967288UL) ^ l_597), (*g_241)))) <= p_99) == 0x3AL), p_99)), 11))) > 3L), l_556[8])), p_99))))) & 6UL)) >= g_145), l_559)))));
                    }
                    return l_528;
                }
                else
                { /* block id: 279 */
                    (*p_98) = (((safe_rshift_func_uint16_t_u_u(g_311, 4)) , g_524) , (*g_240));
                    ++l_601;
                }
            }
        }
        g_605--;
        for (l_289 = 0; (l_289 != 26); l_289 = safe_add_func_int16_t_s_s(l_289, 4))
        { /* block id: 288 */
            int64_t l_616 = 0xA7F64804271C0273LL;
            int16_t l_621 = 0L;
            union U1 l_634 = {0UL};
            uint64_t l_658 = 18446744073709551609UL;
            uint8_t **l_693 = &l_288[0][1];
            uint8_t l_694[8] = {0xA0L,0xA0L,0xA0L,0xA0L,0xA0L,0xA0L,0xA0L,0xA0L};
            uint16_t l_697 = 0x7AF0L;
            int32_t l_703 = 0L;
            int64_t l_734 = 1L;
            int32_t l_769 = 0L;
            int32_t l_772 = 0x893A0ACDL;
            uint16_t l_773 = 0x9C35L;
            int i;
            if ((((((*g_240) = func_59((**g_240), p_99)) == (void*)0) & (safe_rshift_func_int8_t_s_s((((0x7E0816CDA1DEB6DDLL | (safe_add_func_int8_t_s_s((l_523[3][0][1] = (((0x28L >= ((0x5821L == (((((((((*l_304) = (safe_add_func_uint16_t_u_u(l_616, ((safe_add_func_uint32_t_u_u(0xBB1A65B3L, l_616)) == 0xD211C9E42BA7C311LL)))) , g_524) , (*p_100)) >= l_619) || g_334[3]) < l_620) >= l_621) || (-10L))) | (*g_131))) && 1UL) & (*g_321))), l_621))) & p_99) || g_65), 1))) , l_621))
            { /* block id: 292 */
                (*p_98) = &l_289;
            }
            else
            { /* block id: 294 */
                int64_t l_630 = 0L;
                int32_t l_651 = 8L;
                int8_t l_661 = 2L;
                uint8_t **l_692[9][5] = {{&l_288[1][0],&l_288[0][1],&l_288[1][0],&l_288[1][2],&l_288[2][1]},{&l_288[0][1],(void*)0,&l_288[1][4],(void*)0,&l_288[2][1]},{&l_288[2][0],&l_288[0][1],&l_288[0][1],&l_288[2][0],&l_288[1][0]},{&l_288[0][1],&l_288[2][0],&l_288[1][4],&l_288[2][1],(void*)0},{&l_288[0][1],&l_288[1][4],&l_288[1][0],&l_288[1][4],&l_288[0][1]},{&l_288[2][0],(void*)0,&l_288[0][1],&l_288[2][1],&l_288[0][1]},{&l_288[0][1],(void*)0,&l_288[2][0],&l_288[2][0],(void*)0},{&l_288[1][0],&l_288[1][4],&l_288[0][1],(void*)0,&l_288[0][1]},{&l_288[1][4],&l_288[2][0],&l_288[0][1],&l_288[1][2],&l_288[0][1]}};
                int32_t l_704 = (-5L);
                int32_t l_705[1];
                int i, j;
                for (i = 0; i < 1; i++)
                    l_705[i] = 8L;
                if ((safe_add_func_int32_t_s_s((safe_div_func_uint8_t_u_u(((p_99 && (safe_rshift_func_int8_t_s_s((safe_add_func_uint32_t_u_u((l_630 , ((((safe_mod_func_uint16_t_u_u(((safe_unary_minus_func_uint32_t_u(((*l_143) = ((*p_100) = ((l_634 , (l_630 | (safe_div_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s((p_99 >= ((safe_div_func_int64_t_s_s(((safe_div_func_int16_t_s_s((l_305 &= ((safe_unary_minus_func_int8_t_s((((!(((g_522 |= (((l_651 = (safe_lshift_func_int16_t_s_u((g_649 != g_649), 1))) == (*g_131)) && (safe_rshift_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u(((safe_div_func_uint8_t_u_u((0xD259B0F809C14093LL < p_99), p_99)) ^ p_99), l_658)) , g_24), 2)))) | p_99) , p_99)) > 0UL) || 8UL))) , p_99)), 0x8962L)) <= 0x2E70L), l_634.f0)) | g_227)), (*g_131))), 1UL)))) , 4UL))))) != (*p_101)), (*g_131))) , p_99) && l_621) || l_659)), l_630)), p_99))) > g_129), 0xBDL)), 0xA1B6B4F1L)))
                { /* block id: 300 */
                    uint32_t l_662 = 0xC87BD04EL;
                    union U1 l_691 = {0x6070L};
                    for (g_568 = 0; (g_568 >= 0); g_568 -= 1)
                    { /* block id: 303 */
                        l_523[2][0][3] |= ((*g_131) >= p_99);
                        if ((*g_321))
                            break;
                        if (g_326)
                            goto lbl_660;
                        l_662++;
                    }
                    l_697 = (safe_sub_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u(((((safe_sub_func_int8_t_s_s((((safe_div_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(((+((safe_mod_func_int32_t_s_s(((((safe_sub_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(((l_651 = ((g_65 != l_616) ^ (safe_mod_func_uint64_t_u_u(((+(safe_mod_func_int32_t_s_s((((safe_add_func_uint64_t_u_u(0x92A4DDFE5F449BB4LL, (safe_mod_func_uint64_t_u_u((((*g_131) = p_99) == (l_354[6][6][0] , 0xC223L)), (l_691 , 0xB84E4BF5F36696C2LL))))) ^ ((l_692[5][0] != l_693) ^ l_662)) | 0UL), l_694[4]))) == 0x2CL), 0x9EB1BD8D86DC4C36LL)))) , l_695[1]), p_99)), (-1L))) == g_310) & p_99) , (*p_101)), (*p_100))) == g_538)) | (*g_241)), 0xAD6D2A4DL)), l_696[1][4])) & p_99) || g_568), 0UL)) , 255UL) != g_149) <= 0xA85FL), 2)), 7UL));
                    g_227 &= (safe_mod_func_int64_t_s_s(((void*)0 == (*g_187)), (safe_sub_func_int32_t_s_s(l_616, 1UL))));
                }
                else
                { /* block id: 313 */
                    uint8_t l_702 = 0UL;
                    if (l_702)
                        break;
                }
                if ((*g_241))
                { /* block id: 316 */
                    uint8_t l_707 = 1UL;
                    l_707++;
                    for (g_54 = 19; (g_54 >= (-13)); g_54--)
                    { /* block id: 320 */
                        l_305 = (-1L);
                    }
                }
                else
                { /* block id: 323 */
                    int32_t l_726 = 0x6137F00BL;
                    int64_t ***l_753 = &g_518;
                    uint32_t l_764 = 0x4A92E54AL;
                    int32_t l_770 = 0x17017F74L;
                    if ((**g_240))
                    { /* block id: 324 */
                        int32_t l_733 = 0x066BB52CL;
                        int32_t *l_735 = (void*)0;
                        int32_t *l_736[1];
                        int32_t *l_737 = &g_126;
                        int64_t ***l_752 = &g_518;
                        uint8_t **l_754 = &l_288[0][1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_736[i] = &l_597;
                        (*p_98) = func_59(((*l_737) &= (((safe_mod_func_uint32_t_u_u((safe_div_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(g_284, (safe_div_func_uint64_t_u_u(0xBF825F1D6685561DLL, ((safe_add_func_uint64_t_u_u(((safe_add_func_int32_t_s_s((safe_mod_func_uint8_t_u_u(((l_703 = (p_99 <= (g_145 ^= l_726))) && g_24), (l_523[2][0][1] = (g_706 && (safe_mul_func_uint16_t_u_u(((*l_148) = 0x5D83L), (((safe_add_func_int16_t_s_s(p_99, ((safe_rshift_func_uint16_t_u_s((((g_524 , l_621) , l_705[0]) >= l_697), l_694[4])) , 0xAD6AL))) , l_733) | 0x0CC6L))))))), l_733)) | 0xCDFB5200L), g_326)) , p_99))))) > p_99), p_99)), (*p_101))) , 0x8A9E4F12L) >= l_734)), l_630);
                        l_523[5][0][3] &= (g_227 ^= ((safe_mod_func_int64_t_s_s(((safe_rshift_func_int16_t_s_s(((void*)0 == l_742[4]), (p_99 | 0x37L))) > ((*l_299) |= ((*l_737) = ((g_744 != ((safe_add_func_int8_t_s_s((-7L), ((safe_div_func_uint8_t_u_u(0x22L, (+((+0xD712ACB60B3A69C4LL) , (l_752 == l_753))))) & 0x0BA4C51A58BBA93FLL))) , l_754)) , p_99)))), g_538)) == 0x84L));
                    }
                    else
                    { /* block id: 335 */
                        uint32_t l_763 = 0UL;
                        int32_t l_765 = 0x2A51061EL;
                        int32_t l_767[4][9][1];
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 9; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_767[i][j][k] = 1L;
                            }
                        }
                        g_604 = (!((((p_99 | (((p_99 < (safe_mul_func_uint16_t_u_u((((safe_add_func_int16_t_s_s((l_703 |= ((*g_131) = (&g_574 == &p_99))), g_295)) ^ (p_99 || (safe_lshift_func_uint16_t_u_s(g_282[4][2][0], (!(**p_98)))))) , ((*l_148) = ((*g_131) != 0x7E07L))), 0UL))) , p_99) < g_295)) == l_763) ^ l_764) > g_50));
                        l_773++;
                        l_523[2][0][3] = (*g_241);
                    }
                    for (g_145 = 0; (g_145 >= 9); g_145 = safe_add_func_int64_t_s_s(g_145, 9))
                    { /* block id: 345 */
                        uint32_t l_778 = 0x9AA39D5EL;
                        l_778++;
                    }
                }
            }
            l_781 = &l_634;
            l_125[0][4] = (p_101 = p_101);
            for (g_126 = 0; g_126 < 5; g_126 += 1)
            {
                for (g_227 = 0; g_227 < 5; g_227 += 1)
                {
                    for (l_377 = 0; l_377 < 5; l_377 += 1)
                    {
                        g_282[g_126][g_227][l_377] = 3L;
                    }
                }
            }
        }
    }
    return p_99;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_55.f0, "g_55.f0", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_70.f0, "g_70.f0", print_hash_value);
    transparent_crc(g_70.f1, "g_70.f1", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_79[i].f0, "g_79[i].f0", print_hash_value);
        transparent_crc(g_79[i].f1, "g_79[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_145, "g_145", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_189, "g_189", print_hash_value);
    transparent_crc(g_227, "g_227", print_hash_value);
    transparent_crc(g_235, "g_235", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_282[i][j][k], "g_282[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_284, "g_284", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    transparent_crc(g_310, "g_310", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    transparent_crc(g_326, "g_326", print_hash_value);
    transparent_crc(g_332.f0, "g_332.f0", print_hash_value);
    transparent_crc(g_332.f1, "g_332.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_334[i], "g_334[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_374.f0, "g_374.f0", print_hash_value);
    transparent_crc(g_374.f1, "g_374.f1", print_hash_value);
    transparent_crc(g_393, "g_393", print_hash_value);
    transparent_crc(g_522, "g_522", print_hash_value);
    transparent_crc(g_524, "g_524", print_hash_value);
    transparent_crc(g_531, "g_531", print_hash_value);
    transparent_crc(g_538, "g_538", print_hash_value);
    transparent_crc(g_568, "g_568", print_hash_value);
    transparent_crc(g_574, "g_574", print_hash_value);
    transparent_crc(g_604, "g_604", print_hash_value);
    transparent_crc(g_605, "g_605", print_hash_value);
    transparent_crc(g_706, "g_706", print_hash_value);
    transparent_crc(g_743.f0, "g_743.f0", print_hash_value);
    transparent_crc(g_743.f1, "g_743.f1", print_hash_value);
    transparent_crc(g_766, "g_766", print_hash_value);
    transparent_crc(g_768, "g_768", print_hash_value);
    transparent_crc(g_771, "g_771", print_hash_value);
    transparent_crc(g_783, "g_783", print_hash_value);
    transparent_crc(g_962.f0, "g_962.f0", print_hash_value);
    transparent_crc(g_962.f1, "g_962.f1", print_hash_value);
    transparent_crc(g_973, "g_973", print_hash_value);
    transparent_crc(g_984, "g_984", print_hash_value);
    transparent_crc(g_985, "g_985", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_994[i][j][k].f0, "g_994[i][j][k].f0", print_hash_value);
                transparent_crc(g_994[i][j][k].f1, "g_994[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1000, "g_1000", print_hash_value);
    transparent_crc(g_1006.f0, "g_1006.f0", print_hash_value);
    transparent_crc(g_1006.f1, "g_1006.f1", print_hash_value);
    transparent_crc(g_1026.f0, "g_1026.f0", print_hash_value);
    transparent_crc(g_1026.f1, "g_1026.f1", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1068[i].f0, "g_1068[i].f0", print_hash_value);
        transparent_crc(g_1068[i].f1, "g_1068[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1103.f0, "g_1103.f0", print_hash_value);
    transparent_crc(g_1103.f1, "g_1103.f1", print_hash_value);
    transparent_crc(g_1116.f0, "g_1116.f0", print_hash_value);
    transparent_crc(g_1116.f1, "g_1116.f1", print_hash_value);
    transparent_crc(g_1141.f0, "g_1141.f0", print_hash_value);
    transparent_crc(g_1141.f1, "g_1141.f1", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1233[i][j].f0, "g_1233[i][j].f0", print_hash_value);
            transparent_crc(g_1233[i][j].f1, "g_1233[i][j].f1", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1234.f0, "g_1234.f0", print_hash_value);
    transparent_crc(g_1234.f1, "g_1234.f1", print_hash_value);
    transparent_crc(g_1235.f0, "g_1235.f0", print_hash_value);
    transparent_crc(g_1235.f1, "g_1235.f1", print_hash_value);
    transparent_crc(g_1236.f0, "g_1236.f0", print_hash_value);
    transparent_crc(g_1236.f1, "g_1236.f1", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1237[i].f0, "g_1237[i].f0", print_hash_value);
        transparent_crc(g_1237[i].f1, "g_1237[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1238[i][j][k].f0, "g_1238[i][j][k].f0", print_hash_value);
                transparent_crc(g_1238[i][j][k].f1, "g_1238[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1239.f0, "g_1239.f0", print_hash_value);
    transparent_crc(g_1239.f1, "g_1239.f1", print_hash_value);
    transparent_crc(g_1240.f0, "g_1240.f0", print_hash_value);
    transparent_crc(g_1240.f1, "g_1240.f1", print_hash_value);
    transparent_crc(g_1244.f0, "g_1244.f0", print_hash_value);
    transparent_crc(g_1244.f1, "g_1244.f1", print_hash_value);
    transparent_crc(g_1258, "g_1258", print_hash_value);
    transparent_crc(g_1291.f0, "g_1291.f0", print_hash_value);
    transparent_crc(g_1291.f1, "g_1291.f1", print_hash_value);
    transparent_crc(g_1301, "g_1301", print_hash_value);
    transparent_crc(g_1302, "g_1302", print_hash_value);
    transparent_crc(g_1389, "g_1389", print_hash_value);
    transparent_crc(g_1456, "g_1456", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1459[i][j][k], "g_1459[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1460, "g_1460", print_hash_value);
    transparent_crc(g_1515.f0, "g_1515.f0", print_hash_value);
    transparent_crc(g_1515.f1, "g_1515.f1", print_hash_value);
    transparent_crc(g_1532, "g_1532", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1537[i], "g_1537[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1581.f0, "g_1581.f0", print_hash_value);
    transparent_crc(g_1581.f1, "g_1581.f1", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1824[i][j], "g_1824[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1911.f0, "g_1911.f0", print_hash_value);
    transparent_crc(g_1911.f1, "g_1911.f1", print_hash_value);
    transparent_crc(g_2088, "g_2088", print_hash_value);
    transparent_crc(g_2122, "g_2122", print_hash_value);
    transparent_crc(g_2167, "g_2167", print_hash_value);
    transparent_crc(g_2234, "g_2234", print_hash_value);
    transparent_crc(g_2338, "g_2338", print_hash_value);
    transparent_crc(g_2376.f0, "g_2376.f0", print_hash_value);
    transparent_crc(g_2376.f1, "g_2376.f1", print_hash_value);
    transparent_crc(g_2380.f0, "g_2380.f0", print_hash_value);
    transparent_crc(g_2380.f1, "g_2380.f1", print_hash_value);
    transparent_crc(g_2551, "g_2551", print_hash_value);
    transparent_crc(g_2610.f0, "g_2610.f0", print_hash_value);
    transparent_crc(g_2610.f1, "g_2610.f1", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 619
XXX total union variables: 38

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 269
   depth: 2, occurrence: 80
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 14, occurrence: 3
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 5
   depth: 20, occurrence: 2
   depth: 21, occurrence: 2
   depth: 22, occurrence: 5
   depth: 23, occurrence: 3
   depth: 24, occurrence: 2
   depth: 25, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 1
   depth: 29, occurrence: 4
   depth: 30, occurrence: 4
   depth: 31, occurrence: 2
   depth: 32, occurrence: 3
   depth: 35, occurrence: 1
   depth: 36, occurrence: 3
   depth: 37, occurrence: 1
   depth: 41, occurrence: 1
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 548

XXX times a variable address is taken: 1359
XXX times a pointer is dereferenced on RHS: 304
breakdown:
   depth: 1, occurrence: 210
   depth: 2, occurrence: 80
   depth: 3, occurrence: 10
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 358
breakdown:
   depth: 1, occurrence: 313
   depth: 2, occurrence: 43
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 44
XXX times a pointer is compared with address of another variable: 5
XXX times a pointer is compared with another pointer: 27
XXX times a pointer is qualified to be dereferenced: 6857

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1333
   level: 2, occurrence: 471
   level: 3, occurrence: 76
   level: 4, occurrence: 9
   level: 5, occurrence: 10
XXX number of pointers point to pointers: 224
XXX number of pointers point to scalars: 301
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.7
XXX average alias set size: 1.45

XXX times a non-volatile is read: 2099
XXX times a non-volatile is write: 1084
XXX times a volatile is read: 116
XXX    times read thru a pointer: 43
XXX times a volatile is write: 30
XXX    times written thru a pointer: 3
XXX times a volatile is available for access: 3.83e+03
XXX percentage of non-volatile access: 95.6

XXX forward jumps: 2
XXX backward jumps: 6

XXX stmts: 282
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 30
   depth: 2, occurrence: 49
   depth: 3, occurrence: 55
   depth: 4, occurrence: 54
   depth: 5, occurrence: 61

XXX percentage a fresh-made variable is used: 18.1
XXX percentage an existing variable is used: 81.9
********************* end of statistics **********************/

