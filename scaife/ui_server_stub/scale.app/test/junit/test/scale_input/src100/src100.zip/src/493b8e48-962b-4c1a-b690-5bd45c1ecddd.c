/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1875684033
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   const uint32_t  f0;
   int32_t  f1;
};

union U1 {
   int8_t * f0;
   int16_t  f1;
};

union U2 {
   int8_t  f0;
   uint32_t  f1;
};

union U3 {
   int32_t  f0;
};

union U4 {
   int8_t * f0;
   uint8_t  f1;
   volatile unsigned f2 : 1;
   int32_t  f3;
   volatile int8_t * f4;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_34 = 0xED38L;
static volatile union U2 g_35 = {1L};/* VOLATILE GLOBAL g_35 */
static int8_t g_37 = 1L;
static int8_t *g_36 = &g_37;
static uint32_t g_40 = 0UL;
static const uint16_t g_77 = 1UL;
static uint32_t g_108 = 6UL;
static int32_t g_110 = 1L;
static int64_t g_135 = 0xE1B6EB866B6F1F25LL;
static uint8_t g_144[2] = {252UL,252UL};
static uint16_t * volatile g_157 = &g_34;/* VOLATILE GLOBAL g_157 */
static uint16_t * volatile *g_156 = &g_157;
static int32_t g_177 = 0L;
static int8_t g_178 = 0x98L;
static uint32_t g_181 = 1UL;
static union U0 g_218 = {4294967291UL};
static const int8_t g_227[9] = {0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L};
static uint32_t g_230 = 0xCEB1106DL;
static const union U1 g_245 = {0};
static const union U1 g_247 = {0};
static uint32_t g_268 = 0xA33C6001L;
static union U2 g_274 = {0xE2L};
static union U3 g_277 = {0xB856E2F0L};
static uint64_t g_300 = 0xAAE73F2C4129FC67LL;
static int16_t g_310 = 0x470AL;
static uint64_t g_330 = 0x460C0EEEFFEA52EDLL;
static int32_t *g_335 = &g_177;
static int32_t ** const g_334 = &g_335;
static union U1 g_362 = {0};
static union U1 *g_365 = &g_362;
static volatile union U2 * volatile g_389 = (void*)0;/* VOLATILE GLOBAL g_389 */
static volatile union U2 * volatile *g_388 = &g_389;
static uint64_t g_404 = 0x8C0D651198E9E6E9LL;
static uint8_t g_407 = 248UL;
static volatile uint32_t g_475[7] = {18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL};
static volatile uint32_t *g_474 = &g_475[1];
static volatile uint32_t **g_473[10] = {&g_474,&g_474,&g_474,&g_474,&g_474,&g_474,&g_474,&g_474,&g_474,&g_474};
static uint16_t g_481 = 1UL;
static const union U1 *g_503 = &g_362;
static uint8_t g_526[10][9] = {{1UL,255UL,247UL,0UL,1UL,0xDEL,0xA0L,1UL,0x41L},{1UL,1UL,0UL,0xDEL,247UL,0xDEL,0UL,1UL,1UL},{0xB1L,247UL,247UL,255UL,7UL,0x41L,0xDEL,0xC1L,247UL},{255UL,0x06L,0xA0L,255UL,0x4CL,255UL,0x45L,0x5EL,255UL},{0xB1L,7UL,0xDEL,255UL,1UL,1UL,0UL,0xDEL,247UL},{255UL,0UL,0UL,1UL,1UL,0UL,0UL,255UL,0xDEL},{0xDAL,255UL,255UL,0UL,0x4CL,0xDAL,1UL,247UL,255UL},{0x41L,0xDEL,0xC1L,247UL,7UL,0UL,0xF5L,255UL,0xDEL},{0xF5L,0xFFL,0xA0L,0x5EL,0UL,255UL,0UL,247UL,247UL},{0xB1L,0x41L,0xF5L,0x5EL,0xF5L,0x41L,0xB1L,0xDEL,255UL}};
static uint32_t *g_541 = (void*)0;
static uint32_t **g_540 = &g_541;
static uint32_t ** const *g_539 = &g_540;
static int16_t g_546 = 0x1DB0L;
static uint8_t g_631 = 9UL;
static int32_t g_635 = 0x69530237L;
static int64_t g_638[8] = {0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL,0x99A8BA244C800CACLL};
static uint32_t g_640 = 0x255BFD89L;
static union U4 g_670 = {0};/* VOLATILE GLOBAL g_670 */
static uint64_t g_690 = 0x803727745DF2E280LL;
static volatile union U1 g_741[2] = {{0},{0}};
static volatile union U1 *g_740 = &g_741[0];
static volatile union U1 * volatile *g_739 = &g_740;
static volatile union U1 * volatile **g_738[3][9] = {{&g_739,&g_739,&g_739,&g_739,(void*)0,&g_739,&g_739,&g_739,&g_739},{&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739},{&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739,&g_739}};
static const union U4 *g_787 = (void*)0;
static const int32_t *g_808 = (void*)0;
static const int32_t ** volatile g_807 = &g_808;/* VOLATILE GLOBAL g_807 */
static int32_t *g_831 = &g_218.f1;
static const int32_t ** volatile g_833 = &g_808;/* VOLATILE GLOBAL g_833 */
static int64_t g_863[7][7] = {{0x735D2C42AD365A8FLL,5L,0x735D2C42AD365A8FLL,0xC651B043CD8C17B8LL,0x5615F762804F1F20LL,0x5615F762804F1F20LL,0xC651B043CD8C17B8LL},{(-4L),3L,(-4L),0x9CB7FB8CC385E6E7LL,0x747D28E3AE450B28LL,0x747D28E3AE450B28LL,0x9CB7FB8CC385E6E7LL},{0x735D2C42AD365A8FLL,5L,0x735D2C42AD365A8FLL,0xC651B043CD8C17B8LL,0x5615F762804F1F20LL,0x5615F762804F1F20LL,0xC651B043CD8C17B8LL},{(-4L),3L,(-4L),0x9CB7FB8CC385E6E7LL,0x747D28E3AE450B28LL,0x747D28E3AE450B28LL,0x9CB7FB8CC385E6E7LL},{0x735D2C42AD365A8FLL,5L,0x735D2C42AD365A8FLL,0xC651B043CD8C17B8LL,0x5615F762804F1F20LL,0x5615F762804F1F20LL,0xC651B043CD8C17B8LL},{(-4L),3L,(-4L),0x9CB7FB8CC385E6E7LL,0x747D28E3AE450B28LL,0x747D28E3AE450B28LL,0x9CB7FB8CC385E6E7LL},{0x735D2C42AD365A8FLL,5L,0x735D2C42AD365A8FLL,0xC651B043CD8C17B8LL,0x5615F762804F1F20LL,0x5615F762804F1F20LL,0xC651B043CD8C17B8LL}};
static uint16_t *g_895 = (void*)0;
static uint16_t **g_894 = &g_895;
static const union U4 ** volatile g_944 = &g_787;/* VOLATILE GLOBAL g_944 */
static union U4 g_972 = {0};/* VOLATILE GLOBAL g_972 */
static uint16_t g_1004 = 0x2BA2L;
static volatile union U4 g_1007 = {0};/* VOLATILE GLOBAL g_1007 */
static volatile int16_t g_1016 = 0L;/* VOLATILE GLOBAL g_1016 */
static volatile int16_t g_1017 = 1L;/* VOLATILE GLOBAL g_1017 */
static volatile uint64_t g_1018 = 0x5605C98D84FA7E1ALL;/* VOLATILE GLOBAL g_1018 */
static volatile uint32_t g_1052 = 0x9DA02E2CL;/* VOLATILE GLOBAL g_1052 */
static const union U3 *g_1099 = &g_277;
static const union U3 * volatile * volatile g_1098 = &g_1099;/* VOLATILE GLOBAL g_1098 */
static const union U3 * volatile * volatile *g_1097 = &g_1098;
static uint8_t g_1108 = 2UL;
static const int32_t ** volatile g_1114 = (void*)0;/* VOLATILE GLOBAL g_1114 */
static const int32_t ** volatile g_1115 = &g_808;/* VOLATILE GLOBAL g_1115 */
static volatile union U4 g_1118 = {0};/* VOLATILE GLOBAL g_1118 */
static union U1 **g_1154 = &g_365;
static volatile uint8_t g_1188 = 0x9DL;/* VOLATILE GLOBAL g_1188 */
static int32_t * volatile g_1239 = &g_635;/* VOLATILE GLOBAL g_1239 */
static union U2 *g_1266 = &g_274;
static union U2 **g_1265[8][8] = {{&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266},{&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266},{&g_1266,&g_1266,(void*)0,&g_1266,&g_1266,(void*)0,&g_1266,&g_1266},{&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266},{&g_1266,(void*)0,(void*)0,&g_1266,(void*)0,(void*)0,&g_1266,(void*)0},{&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266},{(void*)0,&g_1266,(void*)0,(void*)0,&g_1266,(void*)0,(void*)0,&g_1266},{&g_1266,(void*)0,(void*)0,&g_1266,(void*)0,(void*)0,&g_1266,(void*)0}};
static union U2 ***g_1264[6][10][4] = {{{&g_1265[1][7],&g_1265[0][5],(void*)0,&g_1265[6][4]},{(void*)0,&g_1265[7][4],(void*)0,(void*)0},{&g_1265[5][0],&g_1265[7][4],&g_1265[0][0],&g_1265[6][4]},{&g_1265[7][4],&g_1265[0][5],&g_1265[5][0],&g_1265[1][3]},{&g_1265[0][0],&g_1265[1][2],(void*)0,&g_1265[1][2]},{&g_1265[0][0],&g_1265[6][1],&g_1265[6][4],&g_1265[1][7]},{&g_1265[3][2],(void*)0,&g_1265[2][0],(void*)0},{(void*)0,(void*)0,&g_1265[0][0],&g_1265[5][0]},{(void*)0,&g_1265[0][0],&g_1265[2][0],&g_1265[7][4]},{&g_1265[3][2],&g_1265[5][0],&g_1265[6][4],&g_1265[0][0]}},{{&g_1265[0][0],(void*)0,(void*)0,&g_1265[0][0]},{&g_1265[0][0],&g_1265[6][4],&g_1265[5][0],&g_1265[3][2]},{&g_1265[7][4],&g_1265[2][0],&g_1265[0][0],(void*)0},{&g_1265[5][0],&g_1265[0][0],(void*)0,(void*)0},{(void*)0,&g_1265[2][0],(void*)0,&g_1265[3][2]},{&g_1265[1][7],&g_1265[6][4],&g_1265[6][1],&g_1265[0][0]},{&g_1265[1][2],(void*)0,&g_1265[1][2],&g_1265[0][0]},{&g_1265[1][3],&g_1265[5][0],&g_1265[0][5],&g_1265[7][4]},{&g_1265[6][4],&g_1265[0][0],&g_1265[7][4],&g_1265[5][0]},{(void*)0,(void*)0,&g_1265[7][4],(void*)0}},{{&g_1265[6][4],(void*)0,&g_1265[0][5],&g_1265[1][7]},{&g_1265[1][3],&g_1265[6][1],&g_1265[1][2],&g_1265[1][2]},{&g_1265[1][2],&g_1265[1][2],&g_1265[6][1],&g_1265[1][3]},{&g_1265[1][7],&g_1265[0][5],(void*)0,&g_1265[6][4]},{(void*)0,&g_1265[7][4],(void*)0,(void*)0},{&g_1265[5][0],&g_1265[7][4],&g_1265[0][0],&g_1265[6][4]},{&g_1265[7][4],&g_1265[0][5],&g_1265[5][0],&g_1265[1][3]},{&g_1265[0][0],&g_1265[1][2],(void*)0,&g_1265[1][2]},{&g_1265[0][0],&g_1265[6][1],&g_1265[6][4],&g_1265[1][7]},{&g_1265[3][2],(void*)0,&g_1265[2][0],(void*)0}},{{(void*)0,(void*)0,&g_1265[0][0],&g_1265[5][0]},{(void*)0,&g_1265[0][0],&g_1265[2][0],&g_1265[7][4]},{&g_1265[3][2],&g_1265[5][0],&g_1265[6][4],&g_1265[0][0]},{&g_1265[0][0],(void*)0,(void*)0,&g_1265[0][0]},{&g_1265[0][0],&g_1265[6][4],&g_1265[5][0],&g_1265[3][2]},{&g_1265[7][4],&g_1265[2][0],&g_1265[0][0],(void*)0},{&g_1265[5][0],&g_1265[0][0],(void*)0,(void*)0},{(void*)0,&g_1265[2][0],(void*)0,&g_1265[3][2]},{&g_1265[1][7],&g_1265[6][4],&g_1265[6][1],&g_1265[0][0]},{&g_1265[1][2],(void*)0,&g_1265[1][2],(void*)0}},{{&g_1265[1][2],&g_1265[0][0],(void*)0,&g_1265[3][2]},{(void*)0,&g_1265[1][3],&g_1265[3][2],&g_1265[0][0]},{&g_1265[0][5],&g_1265[6][1],&g_1265[3][2],&g_1265[0][0]},{(void*)0,&g_1265[0][5],(void*)0,&g_1265[2][0]},{&g_1265[1][2],&g_1265[0][0],(void*)0,(void*)0},{(void*)0,(void*)0,&g_1265[0][0],&g_1265[1][2]},{&g_1265[2][0],(void*)0,&g_1265[0][5],(void*)0},{&g_1265[0][0],&g_1265[3][2],&g_1265[6][1],&g_1265[0][5]},{&g_1265[0][0],&g_1265[3][2],&g_1265[1][3],(void*)0},{&g_1265[3][2],(void*)0,&g_1265[0][0],&g_1265[1][2]}},{{(void*)0,(void*)0,&g_1265[2][5],(void*)0},{&g_1265[0][0],&g_1265[0][0],(void*)0,&g_1265[2][0]},{&g_1265[5][0],&g_1265[0][5],&g_1265[7][4],&g_1265[0][0]},{&g_1265[2][5],&g_1265[6][1],(void*)0,&g_1265[0][0]},{&g_1265[2][5],&g_1265[1][3],&g_1265[7][4],&g_1265[3][2]},{&g_1265[5][0],&g_1265[0][0],(void*)0,(void*)0},{&g_1265[0][0],&g_1265[2][5],&g_1265[2][5],&g_1265[0][0]},{(void*)0,(void*)0,&g_1265[0][0],&g_1265[5][0]},{&g_1265[3][2],&g_1265[7][4],&g_1265[1][3],&g_1265[2][5]},{&g_1265[0][0],(void*)0,&g_1265[6][1],&g_1265[2][5]}}};
static uint16_t g_1281 = 65535UL;
static union U0 *g_1286 = &g_218;
static union U0 ** volatile g_1285[2] = {&g_1286,&g_1286};
static union U0 g_1289[1][10][3] = {{{{0x9425EDCCL},{0x91597920L},{0x9425EDCCL}},{{9UL},{1UL},{4294967294UL}},{{0x90DF7295L},{0x1EF0774CL},{4294967294UL}},{{4294967291UL},{0x90DF7295L},{0x9425EDCCL}},{{0x246FD20DL},{0x246FD20DL},{9UL}},{{4294967291UL},{9UL},{0x90DF7295L}},{{0x90DF7295L},{9UL},{4294967291UL}},{{9UL},{0x246FD20DL},{0x246FD20DL}},{{0x9425EDCCL},{0x90DF7295L},{4294967291UL}},{{4294967294UL},{0x1EF0774CL},{0x90DF7295L}}}};
static uint8_t g_1305 = 0UL;
static volatile union U4 g_1331 = {0};/* VOLATILE GLOBAL g_1331 */
static int32_t * volatile g_1341[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t * volatile g_1342 = &g_670.f3;/* VOLATILE GLOBAL g_1342 */
static int32_t * volatile g_1356 = (void*)0;/* VOLATILE GLOBAL g_1356 */
static int32_t * volatile g_1357[1][6] = {{&g_110,&g_110,&g_110,&g_110,&g_110,&g_110}};
static volatile uint16_t g_1373[4][3] = {{0xDF20L,0xDF20L,0xDF20L},{65527UL,0UL,65527UL},{0xDF20L,0xDF20L,0xDF20L},{65527UL,0UL,65527UL}};
static union U0 g_1377 = {0x87F0ED27L};
static int16_t *g_1477 = &g_362.f1;
static volatile uint16_t g_1485 = 0xF135L;/* VOLATILE GLOBAL g_1485 */
static volatile uint32_t g_1508 = 0x2E038924L;/* VOLATILE GLOBAL g_1508 */
static int8_t ** volatile g_1677[6][5] = {{&g_36,&g_36,&g_36,&g_36,&g_36},{&g_36,&g_36,&g_36,&g_36,&g_36},{&g_36,&g_36,&g_36,&g_36,&g_36},{&g_36,&g_36,&g_36,&g_36,&g_36},{&g_36,&g_36,&g_36,&g_36,&g_36},{&g_36,&g_36,&g_36,&g_36,&g_36}};
static int8_t ** volatile *g_1676 = &g_1677[0][3];
static union U3 *g_1681 = &g_277;
static union U3 **g_1680[4] = {&g_1681,&g_1681,&g_1681,&g_1681};
static union U3 ***g_1679 = &g_1680[2];
static volatile union U4 g_1692 = {0};/* VOLATILE GLOBAL g_1692 */
static uint64_t *g_1694 = &g_300;
static uint64_t * volatile * volatile g_1693 = &g_1694;/* VOLATILE GLOBAL g_1693 */
static const union U4 g_1873 = {0};/* VOLATILE GLOBAL g_1873 */
static uint8_t *g_1882[9][3] = {{&g_144[1],&g_631,&g_631},{&g_631,&g_144[1],&g_1108},{&g_144[1],&g_631,&g_631},{&g_631,&g_144[1],&g_1108},{&g_144[1],&g_631,&g_631},{&g_631,&g_144[1],&g_1108},{&g_144[1],&g_631,&g_631},{&g_631,&g_1305,&g_407},{&g_631,(void*)0,(void*)0}};
static int32_t ** volatile g_1887[2] = {(void*)0,(void*)0};
static volatile int8_t g_1914 = 0xE4L;/* VOLATILE GLOBAL g_1914 */
static volatile union U3 g_1998[4] = {{-10L},{-10L},{-10L},{-10L}};
static volatile union U3 * volatile g_1997 = &g_1998[0];/* VOLATILE GLOBAL g_1997 */
static volatile union U3 * volatile * const  volatile g_1996 = &g_1997;/* VOLATILE GLOBAL g_1996 */
static int8_t g_2001 = 0xF1L;
static const union U4 ** const  volatile g_2062[7] = {&g_787,&g_787,&g_787,&g_787,&g_787,&g_787,&g_787};
static const union U4 ** volatile g_2063 = &g_787;/* VOLATILE GLOBAL g_2063 */
static volatile union U4 g_2079 = {0};/* VOLATILE GLOBAL g_2079 */
static const union U4 g_2087 = {0};/* VOLATILE GLOBAL g_2087 */
static const uint32_t *g_2095 = (void*)0;
static const uint32_t **g_2094[6][7] = {{&g_2095,&g_2095,&g_2095,&g_2095,&g_2095,(void*)0,(void*)0},{&g_2095,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_2095,&g_2095,&g_2095,&g_2095,&g_2095,(void*)0,(void*)0},{&g_2095,&g_2095,(void*)0,&g_2095,&g_2095,(void*)0,&g_2095},{&g_2095,&g_2095,&g_2095,&g_2095,(void*)0,(void*)0,&g_2095},{(void*)0,&g_2095,&g_2095,(void*)0,&g_2095,(void*)0,&g_2095}};
static int32_t g_2283[3] = {0x70677142L,0x70677142L,0x70677142L};
static union U0 **g_2292 = &g_1286;
static const uint16_t *g_2303 = &g_77;
static const uint16_t **g_2302 = &g_2303;
static const int32_t g_2317 = 0x8B5A825DL;
static volatile uint32_t g_2336 = 18446744073709551615UL;/* VOLATILE GLOBAL g_2336 */
static int64_t ** volatile g_2385 = (void*)0;/* VOLATILE GLOBAL g_2385 */
static int64_t ** volatile *g_2384 = &g_2385;
static int32_t * volatile g_2395[1] = {&g_277.f0};
static int32_t * volatile g_2396 = &g_1289[0][0][2].f1;/* VOLATILE GLOBAL g_2396 */
static volatile int32_t g_2442 = (-7L);/* VOLATILE GLOBAL g_2442 */
static volatile int32_t *g_2441 = &g_2442;
static volatile int32_t **g_2440 = &g_2441;
static uint16_t **g_2532 = &g_895;
static uint64_t g_2597 = 1UL;
static union U4 g_2721 = {0};/* VOLATILE GLOBAL g_2721 */
static volatile union U4 g_2747[1][7] = {{{0},{0},{0},{0},{0},{0},{0}}};
static volatile int64_t g_2908[8][2][4] = {{{(-1L),0xA9EC9E55E217BEBALL,0x18ACD2512C9CC66DLL,(-4L)},{2L,0xDE79A634C5235FB3LL,(-1L),(-4L)}},{{0x00B9685FBB2A4EBFLL,0xA9EC9E55E217BEBALL,2L,0xA9EC9E55E217BEBALL},{0x3790CB32F4127E0ALL,1L,0x22A087789C42E18ELL,1L}},{{0x18ACD2512C9CC66DLL,0x4B9998859DBF21FDLL,0x00B9685FBB2A4EBFLL,0xFCE0E03FC564E5E4LL},{0xDE79A634C5235FB3LL,(-4L),0xFCE0E03FC564E5E4LL,0x18ACD2512C9CC66DLL}},{{0xDE79A634C5235FB3LL,0x04A2A40AB47427F0LL,0x00B9685FBB2A4EBFLL,0x00B9685FBB2A4EBFLL},{0x18ACD2512C9CC66DLL,0x18ACD2512C9CC66DLL,0x22A087789C42E18ELL,(-10L)}},{{0x3790CB32F4127E0ALL,0x22A087789C42E18ELL,2L,1L},{0x00B9685FBB2A4EBFLL,(-1L),(-1L),2L}},{{2L,(-1L),0x18ACD2512C9CC66DLL,1L},{(-1L),0x22A087789C42E18ELL,(-1L),(-10L)}},{{0x04A2A40AB47427F0LL,0x18ACD2512C9CC66DLL,0x4B9998859DBF21FDLL,0x00B9685FBB2A4EBFLL},{1L,0x04A2A40AB47427F0LL,(-10L),0x18ACD2512C9CC66DLL}},{{1L,(-4L),(-10L),0xFCE0E03FC564E5E4LL},{1L,0x4B9998859DBF21FDLL,0x4B9998859DBF21FDLL,1L}}};
static volatile int64_t * volatile g_2907[6] = {&g_2908[1][0][2],&g_2908[1][0][2],&g_2908[1][0][2],&g_2908[1][0][2],&g_2908[1][0][2],&g_2908[1][0][2]};
static volatile int64_t * volatile *g_2906 = &g_2907[5];
static volatile int32_t g_2936[6] = {(-3L),0x045B80AEL,(-3L),(-3L),0x045B80AEL,(-3L)};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_2(union U0  p_3, int16_t  p_4, int8_t * p_5, int32_t  p_6);
static union U0  func_7(union U0  p_8, int8_t * p_9, int8_t * p_10);
static union U0  func_11(uint32_t  p_12, int8_t  p_13, int8_t * p_14, uint8_t  p_15);
static union U0  func_19(int8_t * p_20, uint32_t  p_21, int16_t  p_22, const int8_t * p_23, int8_t * p_24);
static int8_t * func_25(int8_t * p_26, int64_t  p_27, int8_t * p_28);
static int8_t * func_29(int8_t * p_30, int32_t  p_31, const int8_t * p_32, int64_t  p_33);
static uint16_t  func_43(int32_t  p_44);
static int32_t  func_53(uint8_t  p_54, uint16_t * p_55, int16_t  p_56, int8_t * p_57);
static int8_t  func_58(int8_t * p_59, int8_t  p_60, int32_t  p_61, const uint16_t * p_62, uint16_t * p_63);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_34 g_35 g_36 g_37 g_77 g_108 g_110 g_135 g_156 g_181 g_144 g_178 g_218 g_218.f1 g_268 g_227 g_277 g_177 g_218.f0 g_230 g_274.f0 g_388 g_300 g_404 g_335 g_334 g_526 g_539 g_330 g_277.f0 g_310 g_546 g_631 g_640 g_638 g_481 g_474 g_1676 g_1677 g_1377.f1 g_1108 g_1873 g_1477 g_831 g_274.f1 g_894 g_895 g_1694 g_540 g_541 g_1018 g_1996 g_1097 g_1098 g_1099 g_2001 g_1679 g_1680 g_1681 g_944 g_787 g_2063 g_1289.f1 g_2079 g_635 g_2087 g_2094 g_1115 g_808 g_833 g_1305 g_1266 g_274 g_157 g_1485 g_1004 g_1052 g_1508 g_739 g_740 g_741 g_1188 g_2302 g_690 g_1693 g_2317 g_2336 g_2384 g_2396 g_2303 g_2283 g_2440 g_2385 g_40 g_2597 g_1286 g_407 g_1997 g_1998 g_2721 g_2292 g_365 g_362 g_2747 g_503 g_247 g_2906 g_2907 g_2908 g_1154
 * writes: g_40 g_108 g_37 g_110 g_135 g_144 g_156 g_181 g_178 g_177 g_230 g_218.f1 g_268 g_300 g_407 g_335 g_503 g_526 g_539 g_481 g_310 g_546 g_631 g_640 g_1108 g_362.f1 g_1882 g_274.f1 g_274.f0 g_787 g_1289.f1 g_635 g_2094 g_808 g_34 g_1305 g_1681 g_1004 g_1266 g_277.f0 g_2001 g_2292 g_2302 g_690 g_2336 g_2283 g_863 g_894 g_2532 g_404 g_2597 g_1680 g_1286 g_1188 g_1265 g_2721.f1 g_365
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_16 = 255UL;
    uint32_t *l_39 = &g_40;
    int8_t *l_662 = &g_178;
    int8_t *l_2000 = &g_2001;
    int8_t l_2884 = 0xC5L;
    (*g_831) = func_2(func_7(func_11(l_16, ((((((safe_sub_func_int32_t_s_s((func_19(func_25(func_29(((((g_34 | (((g_35 , g_36) == &g_37) <= 0x60L)) | (~((*l_39) = l_16))) != (safe_mod_func_uint16_t_u_u(func_43(l_16), l_16))) , l_662), g_638[4], l_662, g_77), g_1377.f1, g_36), g_1377.f1, g_227[7], &g_227[3], l_2000) , (-1L)), 0x2466DB6BL)) , l_16) && (**g_2302)) ^ l_16) == 0xF602L) == g_227[8]), g_36, g_77), l_2000, g_36), l_2884, &l_2884, l_2884);
    return l_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_2384 g_2385 g_1679 g_1680 g_1681 g_268 g_2906 g_1694 g_2907 g_2908 g_831 g_218.f1 g_2336 g_1154 g_300 g_110
 * writes: g_40 g_2721.f1 g_300 g_218.f1 g_365 g_110
 */
static int32_t  func_2(union U0  p_3, int16_t  p_4, int8_t * p_5, int32_t  p_6)
{ /* block id: 1302 */
    uint32_t l_2905 = 0x6F4701A0L;
    int64_t *l_2910 = &g_638[4];
    int64_t **l_2909 = &l_2910;
    union U3 l_2917 = {0xDEE2ECEEL};
    union U1 *l_2918[4][5] = {{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362},{&g_362,&g_362,(void*)0,&g_362,&g_362},{&g_362,&g_362,&g_362,&g_362,&g_362}};
    uint16_t ***l_2922 = &g_894;
    int32_t *l_2930 = &g_218.f1;
    int32_t *l_2931 = &g_972.f3;
    int32_t *l_2932 = &g_635;
    int32_t *l_2933 = &g_1377.f1;
    int32_t *l_2934 = &g_110;
    int32_t *l_2935[4];
    uint64_t l_2937[2][3];
    int i, j;
    for (i = 0; i < 4; i++)
        l_2935[i] = &g_218.f1;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
            l_2937[i][j] = 0xCD6B1DEE50E79A3BLL;
    }
    for (g_40 = (-20); (g_40 >= 10); ++g_40)
    { /* block id: 1305 */
        int64_t * const *l_2891 = (void*)0;
        union U3 *l_2896 = (void*)0;
        const union U1 l_2897 = {0};
        uint8_t *l_2898 = &g_2721.f1;
        int32_t l_2899 = 0L;
        const int32_t l_2904 = 2L;
        union U1 **l_2919 = &l_2918[1][0];
        uint16_t ****l_2923 = &l_2922;
        uint16_t ***l_2925 = (void*)0;
        uint16_t ****l_2924 = &l_2925;
        uint16_t ***l_2927 = &g_2532;
        uint16_t ****l_2926 = &l_2927;
        int32_t *l_2928 = &g_972.f3;
        int32_t *l_2929 = &g_110;
        (*g_831) |= ((safe_add_func_int32_t_s_s((((*g_1694) = (((safe_mod_func_int32_t_s_s(((*g_2384) == l_2891), (safe_mod_func_uint8_t_u_u((l_2899 ^= (safe_sub_func_int32_t_s_s((l_2896 != (l_2897 , (**g_1679))), g_268))), (safe_rshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_u(l_2904, 1)), 4)))))) & ((((*l_2898) = l_2905) , g_2906) != l_2909)) < p_3.f1)) && (**g_2906)), l_2905)) | p_3.f0);
        (*l_2929) &= ((l_2899 >= ((safe_div_func_int64_t_s_s((safe_mul_func_int16_t_s_s((g_2336 & ((safe_lshift_func_uint8_t_u_s(l_2899, ((*g_831) >= (((((*l_2919) = ((*g_1154) = (l_2917 , l_2918[1][0]))) == &l_2897) <= (((((safe_add_func_uint8_t_u_u((((*l_2923) = l_2922) == ((*l_2926) = ((*l_2924) = &g_894))), (*p_5))) & l_2905) >= 0UL) || l_2905) != l_2904)) <= 248UL)))) == 0x7E98L)), 1L)), (*g_1694))) | (*p_5))) == 0xBE55FBF8F3B270DDLL);
    }
    l_2937[1][2]--;
    return (*l_2930);
}


/* ------------------------------------------ */
/* 
 * reads : g_690 g_2292 g_1286 g_218
 * writes: g_690
 */
static union U0  func_7(union U0  p_8, int8_t * p_9, int8_t * p_10)
{ /* block id: 1295 */
    for (g_690 = 0; (g_690 > 10); g_690 = safe_add_func_uint32_t_u_u(g_690, 1))
    { /* block id: 1298 */
        return (**g_2292);
    }
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_831 g_218.f1 g_334 g_1289.f1 g_2283 g_2302 g_2303 g_77 g_37 g_156 g_157 g_2440 g_2384 g_2385 g_40 g_526 g_1477 g_1679 g_1680 g_1693 g_1694 g_300 g_36 g_631 g_178 g_404 g_2597 g_1286 g_218 g_1108 g_407 g_230 g_1997 g_1998 g_335 g_2721 g_2292 g_34 g_135 g_365 g_362 g_2747 g_503 g_247 g_310 g_739 g_740 g_741 g_833 g_808 g_268 g_177 g_546
 * writes: g_268 g_177 g_37 g_218.f1 g_1289.f1 g_335 g_2283 g_34 g_40 g_526 g_2292 g_362.f1 g_1681 g_894 g_2532 g_300 g_178 g_546 g_407 g_1108 g_404 g_2597 g_1680 g_135 g_2001 g_640 g_1286 g_1188 g_1265 g_310
 */
static union U0  func_11(uint32_t  p_12, int8_t  p_13, int8_t * p_14, uint8_t  p_15)
{ /* block id: 1095 */
    union U2 l_2405 = {0xEBL};
    int32_t *l_2406 = &g_1289[0][0][2].f1;
    uint32_t ***l_2431 = &g_540;
    uint32_t *** const *l_2430[9][7] = {{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,&l_2431,&l_2431,(void*)0,&l_2431,(void*)0,&l_2431},{(void*)0,(void*)0,&l_2431,&l_2431,&l_2431,(void*)0,(void*)0},{&l_2431,&l_2431,&l_2431,(void*)0,&l_2431,&l_2431,(void*)0},{&l_2431,(void*)0,&l_2431,(void*)0,(void*)0,&l_2431,(void*)0},{(void*)0,&l_2431,&l_2431,&l_2431,&l_2431,(void*)0,&l_2431},{&l_2431,(void*)0,(void*)0,&l_2431,(void*)0,&l_2431,(void*)0},{&l_2431,&l_2431,(void*)0,&l_2431,(void*)0,&l_2431,&l_2431},{&l_2431,(void*)0,&l_2431,(void*)0,&l_2431,&l_2431,(void*)0}};
    union U0 l_2460[10] = {{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L},{0x84E3A8A4L}};
    union U0 **l_2479 = &g_1286;
    int32_t l_2503 = 0x88069583L;
    int32_t l_2507 = (-4L);
    int32_t l_2511[8] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
    union U3 **l_2604 = &g_1681;
    const int8_t *l_2612[5][5][3] = {{{&g_178,&g_37,&g_178},{&g_227[1],&g_227[6],&l_2405.f0},{&g_227[3],&g_37,&g_37},{&l_2405.f0,&g_274.f0,&g_2001},{&g_227[3],(void*)0,&g_227[3]}},{{&g_227[1],&l_2405.f0,&g_2001},{&g_178,&g_178,&g_37},{&g_2001,&l_2405.f0,&l_2405.f0},{&g_37,(void*)0,&g_178},{&g_2001,&g_274.f0,&g_2001}},{{&g_178,&g_37,&g_178},{&g_227[1],&g_227[6],&l_2405.f0},{&g_227[3],&g_37,&g_37},{&l_2405.f0,&g_274.f0,&g_2001},{&g_227[3],(void*)0,&g_227[3]}},{{&g_227[1],&l_2405.f0,&g_2001},{&g_178,&g_178,&g_37},{&g_2001,&l_2405.f0,&l_2405.f0},{&g_37,(void*)0,&g_178},{&g_2001,&g_274.f0,&g_2001}},{{&g_178,&g_37,&g_178},{&g_227[1],&g_227[6],&l_2405.f0},{&g_227[3],&g_37,&g_37},{&l_2405.f0,&g_274.f0,&g_2001},{&g_227[3],(void*)0,&g_227[3]}}};
    const int8_t **l_2611 = &l_2612[0][4][2];
    union U2 *l_2645 = &l_2405;
    uint64_t l_2732 = 0x9C724748E8932516LL;
    int32_t l_2778[4][10][4] = {{{1L,0x71850E58L,0x02759C4DL,0x02759C4DL},{0x7DB5B27BL,0x7DB5B27BL,0L,1L},{0L,1L,0x0A830BBBL,0xBA0DC966L},{0xBA0DC966L,0xB12E33F7L,0x7DB5B27BL,0x0A830BBBL},{(-9L),0xB12E33F7L,0x7006EA01L,0xBA0DC966L},{0xB12E33F7L,1L,6L,1L},{0x792CE18CL,0x7DB5B27BL,0x395D112DL,0x02759C4DL},{6L,0x71850E58L,0xFB7C8001L,(-1L)},{0x02759C4DL,0xFB7C8001L,0xB12E33F7L,0x395D112DL},{0x02759C4DL,0L,0xFB7C8001L,1L}},{{6L,0x395D112DL,0x395D112DL,6L},{0x792CE18CL,0xBA0DC966L,6L,0xA94DCD17L},{0xB12E33F7L,1L,0x7006EA01L,1L},{(-9L),(-1L),0x7DB5B27BL,1L},{0xBA0DC966L,1L,0x0A830BBBL,0x02759C4DL},{0x792CE18CL,0xFB7C8001L,0x792CE18CL,0L},{(-9L),0x7DB5B27BL,6L,0x0A830BBBL},{0xA94DCD17L,0x792CE18CL,0x02759C4DL,0x7DB5B27BL},{0x395D112DL,1L,0x02759C4DL,0x7006EA01L},{0xA94DCD17L,(-1L),6L,6L}},{{(-9L),(-9L),0x792CE18CL,0x395D112DL},{0x792CE18CL,0x395D112DL,0xB12E33F7L,0xFB7C8001L},{0xFB7C8001L,1L,(-9L),0xB12E33F7L},{0x708AF41FL,1L,0xBA0DC966L,0xFB7C8001L},{1L,0x395D112DL,0L,0x395D112DL},{1L,(-9L),0x7DB5B27BL,6L},{0L,(-1L),1L,0x7006EA01L},{6L,1L,1L,0x7DB5B27BL},{6L,0x792CE18CL,1L,0x0A830BBBL},{0L,0x7DB5B27BL,0x7DB5B27BL,0L}},{{1L,0xFB7C8001L,0L,0x02759C4DL},{1L,0x0A830BBBL,0xBA0DC966L,0xA94DCD17L},{0x708AF41FL,0x7006EA01L,(-9L),0xA94DCD17L},{0xFB7C8001L,0x0A830BBBL,0xB12E33F7L,0x02759C4DL},{0x792CE18CL,0xFB7C8001L,0x792CE18CL,0L},{(-9L),0x7DB5B27BL,6L,0x0A830BBBL},{0xA94DCD17L,0x792CE18CL,0x02759C4DL,0x7DB5B27BL},{0x395D112DL,1L,0x02759C4DL,0x7006EA01L},{0xA94DCD17L,(-1L),6L,6L},{(-9L),(-9L),0x792CE18CL,0x395D112DL}}};
    int32_t l_2796[2];
    union U4 *l_2852 = &g_670;
    uint32_t l_2867[10];
    int32_t *l_2876 = &l_2507;
    int32_t *l_2877 = &g_635;
    int32_t *l_2878[10];
    uint16_t l_2879 = 0x13ACL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2796[i] = 0L;
    for (i = 0; i < 10; i++)
        l_2867[i] = 0x3DA074F9L;
    for (i = 0; i < 10; i++)
        l_2878[i] = &g_972.f3;
    if (((l_2405 , l_2406) == l_2406))
    { /* block id: 1096 */
        const int16_t l_2438 = 0x3DA3L;
        const int64_t *l_2450[2];
        const int64_t **l_2449 = &l_2450[1];
        int32_t l_2483 = 2L;
        int32_t l_2495 = 0x75080F99L;
        int32_t l_2496 = 0xFCD8576DL;
        union U0 l_2525[8][10][3] = {{{{5UL},{0UL},{4294967295UL}},{{0x41CF8C1AL},{0UL},{0x712C9317L}},{{0x52D410E2L},{4294967295UL},{0x52D410E2L}},{{4294967295UL},{4294967290UL},{1UL}},{{0UL},{0x14AF12A8L},{0x6992F1E5L}},{{4294967286UL},{0x52D410E2L},{3UL}},{{4294967291UL},{0x13BCF59FL},{0x4448110CL}},{{4294967286UL},{0xE178BC05L},{1UL}},{{0UL},{0x77B568BEL},{1UL}},{{4294967295UL},{0x66FE7D8AL},{0x14AF12A8L}}},{{{0x52D410E2L},{0xEA0D018DL},{0x66FE7D8AL}},{{0x41CF8C1AL},{0xADBFA8FFL},{0x5B3B9DA4L}},{{5UL},{0x52D410E2L},{0xD20578CCL}},{{0xD594D035L},{4294967295UL},{1UL}},{{0xA445A8CCL},{0UL},{4294967292UL}},{{0UL},{0x17E257CEL},{0x9D58DB9AL}},{{4294967293UL},{0UL},{8UL}},{{4294967295UL},{0x41CF8C1AL},{8UL}},{{0x41CF8C1AL},{4294967295UL},{0x6992F1E5L}},{{1UL},{0x4E2B79DCL},{4294967294UL}}},{{{0UL},{4294967290UL},{0UL}},{{0x66FE7D8AL},{0xF06E85FCL},{4294967290UL}},{{2UL},{0xA772304BL},{3UL}},{{4294967288UL},{9UL},{8UL}},{{0x6992F1E5L},{0xEA0D018DL},{5UL}},{{0UL},{0x2B1D2FE5L},{0x4E2B79DCL}},{{0UL},{0x2B1D2FE5L},{0xB13E5BADL}},{{0xA772304BL},{0xEA0D018DL},{4294967289UL}},{{0UL},{9UL},{0x0C672BD3L}},{{0x79DEE458L},{0xA772304BL},{1UL}}},{{{0xA9A98436L},{0x0BD2AB60L},{0x5367F554L}},{{0x3E32B136L},{4294967293UL},{1UL}},{{8UL},{4294967295UL},{4294967291UL}},{{1UL},{1UL},{0x11AD4EE3L}},{{4294967288UL},{0UL},{0xC2132456L}},{{1UL},{5UL},{1UL}},{{0x51EA66E5L},{7UL},{4294967295UL}},{{1UL},{4294967295UL},{2UL}},{{7UL},{8UL},{4294967295UL}},{{0x52D410E2L},{2UL},{1UL}}},{{{4294967295UL},{0x69919C44L},{0x11AD4EE3L}},{{4294967294UL},{0x2B1D2FE5L},{0UL}},{{0x28669B3AL},{0x28669B3AL},{9UL}},{{0x14AF12A8L},{0x9D58DB9AL},{4294967295UL}},{{2UL},{0xE5A945CBL},{7UL}},{{5UL},{0x35E1F6F0L},{4294967295UL}},{{4294967288UL},{2UL},{7UL}},{{1UL},{0x5367F554L},{4294967295UL}},{{0xBEB96916L},{4294967293UL},{9UL}},{{4294967293UL},{1UL},{0UL}}},{{{0xC2D621ECL},{0xB13E5BADL},{0x11AD4EE3L}},{{4294967291UL},{1UL},{1UL}},{{5UL},{0x14AF12A8L},{4294967295UL}},{{0x51EA66E5L},{4294967295UL},{2UL}},{{5UL},{0xD594D035L},{4294967295UL}},{{0x9D58DB9AL},{8UL},{1UL}},{{4294967295UL},{9UL},{0xC2132456L}},{{4294967293UL},{0xB7639305L},{0x11AD4EE3L}},{{0xA772304BL},{0xE5A945CBL},{4294967291UL}},{{7UL},{4294967295UL},{1UL}}},{{{0x14AF12A8L},{7UL},{0x5367F554L}},{{9UL},{0x77B568BEL},{1UL}},{{0xC0272A72L},{0x35E1F6F0L},{4294967286UL}},{{9UL},{9UL},{5UL}},{{0xC2D621ECL},{3UL},{4294967295UL}},{{0x3E32B136L},{4294967295UL},{4294967295UL}},{{0x3E32B136L},{0xADBFA8FFL},{9UL}},{{0xC2D621ECL},{1UL},{0UL}},{{9UL},{5UL},{0x0C672BD3L}},{{0xC0272A72L},{0x14AF12A8L},{1UL}}},{{{9UL},{1UL},{0x0244C3F4L}},{{0x14AF12A8L},{4294967295UL},{4294967295UL}},{{7UL},{0x0BD2AB60L},{0xA772304BL}},{{0xA772304BL},{0x51EA66E5L},{0xA6F9A4D9L}},{{4294967293UL},{0x69919C44L},{0UL}},{{4294967295UL},{0x77B568BEL},{0xDB7758B3L}},{{0x9D58DB9AL},{4294967295UL},{9UL}},{{5UL},{0x28669B3AL},{8UL}},{{0x51EA66E5L},{0xD20578CCL},{1UL}},{{5UL},{0x73AFC746L},{0x9FC0CB75L}}}};
        int8_t **l_2609 = &g_36;
        const union U2 *l_2646[9] = {(void*)0,&g_274,(void*)0,(void*)0,&g_274,(void*)0,(void*)0,&g_274,(void*)0};
        int32_t l_2652 = 0L;
        int32_t l_2653[10];
        int32_t l_2686 = (-4L);
        union U1 ***l_2701 = &g_1154;
        union U1 ****l_2700[2];
        uint32_t ****l_2709[8][5][5] = {{{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,(void*)0},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431}},{{&l_2431,&l_2431,(void*)0,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,(void*)0,(void*)0},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,&l_2431,(void*)0,&l_2431,(void*)0}},{{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,(void*)0,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431}},{{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,(void*)0,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,&l_2431,&l_2431,&l_2431,(void*)0}},{{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,(void*)0,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,(void*)0,&l_2431,(void*)0},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431}},{{&l_2431,&l_2431,(void*)0,(void*)0,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,(void*)0,&l_2431}},{{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,(void*)0,(void*)0},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431}},{{(void*)0,&l_2431,(void*)0,&l_2431,(void*)0},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{(void*)0,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,&l_2431,&l_2431,&l_2431},{&l_2431,&l_2431,(void*)0,&l_2431,&l_2431}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2450[i] = (void*)0;
        for (i = 0; i < 10; i++)
            l_2653[i] = (-2L);
        for (i = 0; i < 2; i++)
            l_2700[i] = &l_2701;
lbl_2659:
        for (g_268 = 0; (g_268 > 27); g_268++)
        { /* block id: 1099 */
            uint64_t l_2415[2];
            int32_t l_2423 = 0x0D9B0C25L;
            int32_t *l_2428 = (void*)0;
            int32_t *l_2429 = &g_2283[2];
            int32_t *l_2439 = &l_2423;
            union U3 **l_2452 = &g_1681;
            int32_t l_2505 = 1L;
            int32_t l_2508 = 1L;
            int32_t l_2510[4][2];
            uint32_t l_2513 = 1UL;
            int i, j;
            for (i = 0; i < 2; i++)
                l_2415[i] = 0xC9D9E9B28DD517F7LL;
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 2; j++)
                    l_2510[i][j] = 0xFF0001BDL;
            }
            for (g_177 = (-8); (g_177 == 6); g_177 = safe_add_func_int16_t_s_s(g_177, 4))
            { /* block id: 1102 */
                int16_t l_2420 = 5L;
                for (g_37 = 0; (g_37 < (-29)); g_37 = safe_sub_func_int64_t_s_s(g_37, 2))
                { /* block id: 1105 */
                    int32_t *l_2413 = &g_110;
                    int32_t *l_2414[1];
                    int i;
                    for (i = 0; i < 1; i++)
                        l_2414[i] = (void*)0;
                    (*g_831) &= 1L;
                    (*l_2406) = p_13;
                    l_2415[1]++;
                    if ((safe_mod_func_uint16_t_u_u(p_13, l_2420)))
                    { /* block id: 1109 */
                        if (l_2415[0])
                            break;
                        (*l_2406) = (-9L);
                        if (p_15)
                            break;
                    }
                    else
                    { /* block id: 1113 */
                        (*g_334) = l_2406;
                    }
                }
            }
            (*g_831) |= 0x1F5C71D9L;
            l_2423 |= (safe_lshift_func_uint8_t_u_s((*l_2406), 5));
            if (((safe_lshift_func_int16_t_s_u(((&g_539 != (((*l_2429) |= (safe_lshift_func_uint16_t_u_s((*l_2406), (*l_2406)))) , l_2430[6][0])) && 0x2CFD84FCL), (**g_2302))) , ((((*l_2439) |= ((*g_831) |= ((p_13 && ((**g_156) = ((safe_div_func_int64_t_s_s(((safe_mul_func_uint16_t_u_u(0x1CCBL, (safe_sub_func_uint32_t_u_u(((0x10L == l_2415[0]) > 0UL), 0x09E68AC2L)))) || (*l_2406)), l_2438)) >= (*p_14)))) && 1L))) > p_15) & p_13)))
            { /* block id: 1124 */
                uint32_t *l_2451[4][6][7] = {{{&g_181,&g_181,&g_181,(void*)0,&g_181,(void*)0,&g_181},{&g_181,(void*)0,&g_181,&g_181,(void*)0,&g_181,(void*)0},{&g_181,&g_181,&g_181,&g_181,&g_181,&g_181,&g_181},{&g_181,(void*)0,(void*)0,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,(void*)0,&g_181,&g_181,(void*)0,&g_181},{&g_181,&g_181,&g_181,&g_181,&g_181,(void*)0,&g_181}},{{(void*)0,(void*)0,&g_181,&g_181,&g_181,&g_181,&g_181},{&g_181,(void*)0,(void*)0,&g_181,&g_181,&g_181,(void*)0},{&g_181,&g_181,(void*)0,&g_181,(void*)0,&g_181,&g_181},{(void*)0,&g_181,&g_181,&g_181,&g_181,&g_181,(void*)0},{&g_181,&g_181,(void*)0,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,&g_181,&g_181,&g_181,&g_181,&g_181}},{{(void*)0,&g_181,(void*)0,(void*)0,&g_181,&g_181,&g_181},{(void*)0,&g_181,&g_181,&g_181,(void*)0,(void*)0,&g_181},{&g_181,&g_181,(void*)0,(void*)0,&g_181,&g_181,&g_181},{&g_181,&g_181,(void*)0,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,&g_181,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,&g_181,(void*)0,&g_181,&g_181,&g_181}},{{&g_181,&g_181,(void*)0,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,(void*)0,&g_181,&g_181,&g_181,&g_181},{(void*)0,&g_181,&g_181,&g_181,&g_181,&g_181,&g_181},{&g_181,&g_181,&g_181,&g_181,&g_181,(void*)0,&g_181},{(void*)0,&g_181,&g_181,&g_181,&g_181,(void*)0,&g_181},{&g_181,&g_181,&g_181,(void*)0,(void*)0,&g_181,(void*)0}}};
                int i, j, k;
                (*g_831) ^= p_13;
                (*l_2439) = (((*l_2429) = (g_2440 != (void*)0)) , ((((65535UL >= (((safe_lshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((**g_2302) <= ((*g_2384) == l_2449)), (l_2451[2][5][4] == l_2451[2][5][4]))), 6)) == 6UL) > (*p_14))) , 0x45C458F2L) , (void*)0) != l_2452));
            }
            else
            { /* block id: 1128 */
                uint32_t *l_2455 = &g_40;
                uint8_t *l_2467 = &g_526[8][5];
                int32_t l_2468 = 0xB44549EDL;
                int32_t l_2482 = 0L;
                uint64_t l_2497 = 0xD39CC3202E9D9378LL;
                int64_t l_2504 = 0L;
                int32_t l_2506 = 0x32F2A8B0L;
                int32_t l_2509 = 0xF3DADD34L;
                int32_t l_2512[8][8] = {{0L,(-6L),(-5L),0xE604D45BL,0x842E1337L,0L,0xE0B3C7AAL,0xB9A98B60L},{0x4FED0E03L,2L,(-5L),0xD63E56ACL,(-2L),0L,0L,(-2L)},{0x842E1337L,0x4FED0E03L,0x4FED0E03L,0x842E1337L,0x7E55D41AL,0x766F846AL,3L,0xE0B3C7AAL},{0xD63E56ACL,(-5L),2L,0x4FED0E03L,0x766F846AL,0x5C4CF929L,(-6L),0xE604D45BL},{0xE604D45BL,(-5L),(-6L),0L,2L,0x766F846AL,2L,0L},{0xB9A98B60L,0x4FED0E03L,0xB9A98B60L,0x2F601497L,0x5C4CF929L,(-10L),(-6L),0xE0B3C7AAL},{0x4FED0E03L,0xE0B3C7AAL,0L,0x2F601497L,(-1L),1L,0x5C4CF929L,0xD63E56ACL},{0x4FED0E03L,0L,1L,(-5L),0x5C4CF929L,0x5C4CF929L,(-5L),1L}};
                union U3 *l_2516 = &g_277;
                uint16_t **l_2528 = &g_895;
                uint16_t **l_2531 = &g_895;
                int i, j;
                if ((((*l_2455)--) && (((safe_mul_func_uint8_t_u_u((l_2468 = (l_2460[1] , (safe_sub_func_int8_t_s_s(((p_15 , (safe_sub_func_int32_t_s_s(0xC35C7AE5L, p_15))) && ((*l_2467) |= (safe_lshift_func_uint8_t_u_s((*l_2439), 2)))), 0x54L)))), (((+((safe_sub_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((l_2482 = (~((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((&g_1286 != (g_2292 = l_2479)) ^ ((*g_1477) = ((((((*l_2406) = (safe_mul_func_uint16_t_u_u(65533UL, 1UL))) < 3L) < p_12) <= 18446744073709551612UL) != 248UL))), l_2438)), p_15)) > 18446744073709551607UL))), l_2438)), 0x20B4L)) != 0L)) ^ (*l_2439)) | p_13))) == p_12) > (-1L))))
                { /* block id: 1136 */
                    int32_t *l_2484 = &l_2483;
                    int32_t *l_2485 = &l_2460[1].f1;
                    int32_t *l_2486 = &l_2423;
                    int32_t *l_2487 = &g_1377.f1;
                    int32_t *l_2488 = &g_110;
                    int32_t *l_2489 = (void*)0;
                    int32_t *l_2490 = &g_110;
                    int32_t *l_2491 = (void*)0;
                    int32_t *l_2492 = &g_1289[0][0][2].f1;
                    int32_t *l_2493 = (void*)0;
                    int32_t *l_2494[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_2494[i] = (void*)0;
                    ++l_2497;
                }
                else
                { /* block id: 1138 */
                    int32_t *l_2500 = &l_2423;
                    int32_t *l_2501 = (void*)0;
                    int32_t *l_2502[10] = {&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1,&g_1289[0][0][2].f1};
                    uint32_t * const *l_2562 = &g_541;
                    int i;
                    l_2513++;
                    (**g_1679) = l_2516;
                    for (g_177 = 0; (g_177 >= 0); g_177 -= 1)
                    { /* block id: 1143 */
                        uint16_t ***l_2529 = (void*)0;
                        uint16_t ***l_2530 = &g_894;
                        int8_t *l_2547 = &g_178;
                        (*g_831) |= (+((safe_mul_func_uint16_t_u_u(p_12, 0x5F26L)) > ((**g_1693) & ((0x4082FFA3L >= (*l_2406)) , (!0x23D45BF3L)))));
                        if (p_12)
                            break;
                        (*l_2439) &= (safe_rshift_func_int8_t_s_s((l_2525[7][8][2] , ((*l_2547) ^= (0x84B52DD8607F4707LL ^ ((safe_div_func_int8_t_s_s((((*g_36) , ((*l_2530) = l_2528)) != (g_2532 = l_2531)), 0x69L)) <= (safe_rshift_func_uint8_t_u_u(((--(*g_1694)) , (((safe_lshift_func_int8_t_s_s(((safe_rshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_s((**g_2302), 10)), 6)) , ((safe_lshift_func_int16_t_s_s(l_2438, 10)) != ((*g_1694) = (safe_sub_func_uint16_t_u_u(0x5D57L, (-1L)))))), (*p_14))) != l_2482) || g_631)), (*l_2406))))))), (*p_14)));
                        return l_2525[6][5][0];
                    }
                    for (l_2468 = 0; (l_2468 > 28); l_2468++)
                    { /* block id: 1156 */
                        (*g_831) &= (~(safe_mul_func_int64_t_s_s(((safe_unary_minus_func_int16_t_s(p_13)) || p_15), (0xA5L >= (safe_mod_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((safe_div_func_uint16_t_u_u((*g_2303), (((void*)0 == l_2562) ^ (*l_2439)))) & ((safe_mod_func_int8_t_s_s((safe_div_func_int8_t_s_s((*p_14), (safe_sub_func_int64_t_s_s((safe_mul_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u((((((**g_156) = ((void*)0 == &g_1882[5][1])) && 1UL) & l_2512[5][4]) < 0xCAL), 2)), (**g_2302))), l_2509)))), l_2438)) == (*l_2439))), 18446744073709551612UL)), (*l_2406)))))));
                        (*l_2406) = ((safe_sub_func_uint8_t_u_u(p_15, (1UL & l_2509))) , (safe_mul_func_int16_t_s_s(0x68ACL, (p_13 ^ (1UL ^ ((*l_2500) &= 1UL))))));
                    }
                }
            }
        }
        for (g_546 = (-5); (g_546 == 2); g_546 = safe_add_func_int64_t_s_s(g_546, 2))
        { /* block id: 1167 */
            int32_t l_2581 = 3L;
            uint8_t *l_2592 = &g_407;
            uint8_t *l_2593 = &g_1108;
            uint64_t *l_2594 = (void*)0;
            uint64_t *l_2595 = &g_404;
            uint8_t l_2621[10];
            int32_t l_2649 = 0L;
            int32_t l_2654 = (-1L);
            uint32_t l_2656 = 0xEC499DE0L;
            union U0 *l_2697 = &l_2460[1];
            uint16_t * const *l_2717[5];
            int32_t *l_2724 = &l_2507;
            int32_t *l_2725 = &g_110;
            int32_t *l_2726 = &g_972.f3;
            int32_t *l_2727 = &l_2511[3];
            int32_t *l_2728 = &g_1289[0][0][2].f1;
            int32_t *l_2729 = (void*)0;
            int32_t *l_2730[2];
            int32_t l_2731[9];
            int i;
            for (i = 0; i < 10; i++)
                l_2621[i] = 0xE6L;
            for (i = 0; i < 5; i++)
                l_2717[i] = (void*)0;
            for (i = 0; i < 2; i++)
                l_2730[i] = &l_2495;
            for (i = 0; i < 9; i++)
                l_2731[i] = 0xF107A54BL;
            if ((((((safe_lshift_func_uint8_t_u_u(l_2581, 1)) , (*g_2384)) != (void*)0) == (safe_add_func_int64_t_s_s((safe_add_func_uint64_t_u_u(18446744073709551613UL, (safe_mul_func_uint8_t_u_u(((*l_2406) = (l_2581 >= ((*l_2595) &= (safe_rshift_func_int16_t_s_s(((((*l_2593) = ((safe_mod_func_uint16_t_u_u((((((*l_2592) = ((l_2581 | 4294967290UL) > p_15)) >= l_2581) & (*g_1694)) , p_15), 4L)) == (-4L))) | l_2525[7][8][2].f0) , (*l_2406)), 8))))), 0xCCL)))), (*g_1694)))) | 0UL))
            { /* block id: 1172 */
                int32_t *l_2596[1];
                int8_t ***l_2610 = &l_2609;
                int i;
                for (i = 0; i < 1; i++)
                    l_2596[i] = &l_2525[7][8][2].f1;
                g_2597++;
                (*g_831) = (safe_sub_func_int64_t_s_s(0xD26586BC1AF31AB9LL, ((safe_div_func_uint64_t_u_u(0xA50E62F179D16154LL, (((((*l_2406) & (*l_2406)) == ((((*g_1679) = (*g_1679)) != l_2604) || (*p_14))) | (safe_lshift_func_uint8_t_u_s(l_2581, (safe_add_func_uint16_t_u_u((((((*l_2610) = l_2609) != l_2611) >= (-5L)) > 0xC9L), 0x4709L))))) , (*g_1694)))) , p_12)));
                (*l_2604) = (void*)0;
            }
            else
            { /* block id: 1178 */
                const int32_t l_2614[1] = {0x38E7D484L};
                int32_t l_2648 = (-2L);
                int32_t l_2651[10][1][5] = {{{6L,0xA53E6A3FL,0xE9E4B147L,0x87C4FD0CL,0x9A5F1CA1L}},{{6L,0x31A1128FL,0xBF6C9303L,0x87C4FD0CL,0x87C4FD0CL}},{{0xE9E4B147L,0x31A1128FL,0xE9E4B147L,0x9A5F1CA1L,0x87C4FD0CL}},{{6L,0xA53E6A3FL,0xE9E4B147L,0x87C4FD0CL,0x9A5F1CA1L}},{{6L,0x31A1128FL,0xBF6C9303L,0x87C4FD0CL,0x87C4FD0CL}},{{0xE9E4B147L,0x31A1128FL,0xE9E4B147L,0x9A5F1CA1L,0x87C4FD0CL}},{{6L,0xA53E6A3FL,0xE9E4B147L,0x87C4FD0CL,0x9A5F1CA1L}},{{6L,0x31A1128FL,0xBF6C9303L,0x87C4FD0CL,0x87C4FD0CL}},{{0xE9E4B147L,0x31A1128FL,0xE9E4B147L,0x9A5F1CA1L,0x87C4FD0CL}},{{6L,0xA53E6A3FL,0xE9E4B147L,0x87C4FD0CL,0x9A5F1CA1L}}};
                uint8_t l_2675 = 250UL;
                union U0 *l_2696 = &l_2525[7][8][2];
                uint32_t ** const **l_2710[3][9][5] = {{{&g_539,(void*)0,&g_539,&g_539,&g_539},{(void*)0,&g_539,&g_539,&g_539,(void*)0},{&g_539,(void*)0,&g_539,&g_539,&g_539},{(void*)0,&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,(void*)0,(void*)0},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,(void*)0,&g_539},{(void*)0,&g_539,&g_539,&g_539,&g_539}},{{&g_539,&g_539,&g_539,&g_539,&g_539},{(void*)0,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{(void*)0,(void*)0,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{(void*)0,&g_539,(void*)0,(void*)0,&g_539}},{{&g_539,&g_539,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,(void*)0},{(void*)0,&g_539,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,(void*)0,&g_539},{&g_539,&g_539,(void*)0,&g_539,&g_539}}};
                int64_t *l_2723 = &g_135;
                int i, j, k;
                for (g_34 = 0; (g_34 <= 2); g_34 += 1)
                { /* block id: 1181 */
                    int64_t *l_2613 = &g_135;
                    union U2 l_2622 = {0x29L};
                    union U2 **l_2624 = &g_1266;
                    union U2 **l_2625 = &g_1266;
                    union U2 **l_2626 = &g_1266;
                    union U2 **l_2627 = &g_1266;
                    union U2 **l_2628 = (void*)0;
                    union U2 **l_2629 = &g_1266;
                    union U2 **l_2630 = &g_1266;
                    union U2 **l_2631 = &g_1266;
                    union U2 **l_2632 = &g_1266;
                    union U2 **l_2633 = &g_1266;
                    union U2 **l_2634 = &g_1266;
                    union U2 **l_2635 = (void*)0;
                    union U2 **l_2636 = &g_1266;
                    union U2 **l_2637 = &g_1266;
                    union U2 **l_2638 = (void*)0;
                    union U2 **l_2639 = &g_1266;
                    union U2 **l_2640 = &g_1266;
                    union U2 **l_2641 = &g_1266;
                    union U2 **l_2642 = &g_1266;
                    union U2 **l_2643 = &g_1266;
                    union U2 **l_2644[6] = {&g_1266,&g_1266,&g_1266,&g_1266,&g_1266,&g_1266};
                    const uint16_t l_2647 = 0x0E34L;
                    int32_t l_2655[1][7][9] = {{{1L,0x5570B09EL,0x8373B84CL,(-1L),2L,0x8DF31DCFL,0x8DF31DCFL,2L,(-1L)},{0xB9547BAEL,0L,0xB9547BAEL,(-1L),0xBDA2652AL,(-1L),(-2L),0x7FB85FA9L,0x7FB85FA9L},{1L,1L,0L,0x8DF31DCFL,0L,1L,1L,2L,0x8373B84CL},{(-2L),(-1L),0xBDA2652AL,(-1L),0xB9547BAEL,0L,0xB9547BAEL,(-1L),0xBDA2652AL},{0x8DF31DCFL,0x8DF31DCFL,2L,(-1L),0x8373B84CL,0x5570B09EL,1L,2L,1L},{0xBDA2652AL,0L,(-1L),(-1L),0L,0xBDA2652AL,0xF7B260C6L,0x7FB85FA9L,7L},{2L,0x657F329DL,2L,0x5279336FL,1L,1L,0x5279336FL,2L,0x657F329DL}}};
                    int32_t l_2674 = (-1L);
                    int8_t *l_2695 = &g_2001;
                    union U3 l_2720 = {0x8045252AL};
                    int i, j, k;
                    if (((((*l_2613) = p_15) != l_2614[0]) , (safe_lshift_func_int8_t_s_u((1L > ((safe_lshift_func_int8_t_s_u((*p_14), (safe_div_func_int8_t_s_s(l_2621[0], ((-5L) && (l_2622 , (~((*l_2406) = (p_12 >= (((l_2645 = &l_2622) != l_2646[1]) , p_15)))))))))) <= l_2647)), 7))))
                    { /* block id: 1185 */
                        int32_t *l_2650[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i;
                        ++l_2656;
                        return (**l_2479);
                    }
                    else
                    { /* block id: 1188 */
                        int32_t *l_2664 = &g_218.f1;
                        int32_t *l_2665 = (void*)0;
                        int32_t *l_2666 = (void*)0;
                        int32_t *l_2667 = &l_2655[0][4][3];
                        int32_t *l_2668 = &g_1377.f1;
                        int32_t *l_2669 = (void*)0;
                        int32_t *l_2670 = &l_2511[7];
                        int32_t *l_2671 = &l_2655[0][4][4];
                        int32_t *l_2672 = &l_2649;
                        int32_t *l_2673[6] = {&l_2507,&l_2507,&l_2507,&l_2507,&l_2507,&l_2507};
                        int i;
                        if (l_2647)
                            goto lbl_2659;
                        (*g_334) = &l_2649;
                        (*g_831) = (safe_sub_func_uint8_t_u_u(p_15, (++(*l_2593))));
                        l_2675--;
                    }
                    if ((safe_mul_func_uint16_t_u_u((*g_2303), (safe_div_func_int8_t_s_s((safe_mod_func_int64_t_s_s((p_12 >= (((((((*l_2595) = ((**g_1693) &= (safe_mod_func_int32_t_s_s(l_2653[5], 4UL)))) & (((l_2686 ^ ((*l_2406) && (safe_sub_func_uint8_t_u_u((++(*l_2592)), (((safe_add_func_int32_t_s_s((*g_831), (-7L))) ^ ((((*l_2695) = ((*g_36) = ((((safe_div_func_int32_t_s_s(((*g_2303) <= p_12), g_230)) <= (**g_2302)) , p_13) ^ l_2581))) || (-1L)) <= l_2622.f0)) , l_2654))))) ^ l_2654) , l_2675)) , l_2696) != l_2697) == p_15) || p_12)), p_15)), l_2614[0])))))
                    { /* block id: 1200 */
                        uint32_t l_2711 = 8UL;
                        l_2525[7][8][2].f1 = l_2651[5][0][0];
                        (*g_335) = ((p_13 | (safe_sub_func_uint32_t_u_u(((((void*)0 != l_2700[0]) <= ((*g_1997) , ((safe_mod_func_int64_t_s_s(((*l_2697) , ((&g_831 != &g_2396) , (l_2674 != ((safe_add_func_int8_t_s_s((safe_sub_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u((l_2709[4][1][1] == l_2710[0][1][3]))), l_2621[3])), l_2674)) || l_2621[0])))), (*g_1694))) ^ l_2711))) > 4UL), p_15))) < p_15);
                    }
                    else
                    { /* block id: 1203 */
                        uint32_t *l_2722 = &g_640;
                        (*g_831) = ((((safe_sub_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((+p_13), (-1L))), p_15)) , l_2717[4]) == &g_157) > (((safe_mod_func_uint64_t_u_u(((0x087EB8CE4A9CA1E3LL >= ((l_2720 , 0xB2FE3C27L) != ((*l_2722) = ((g_2721 , (*l_2406)) , p_13)))) != 0xB3B9L), l_2621[3])) , l_2723) == l_2595));
                    }
                    (*l_2479) = (*g_2292);
                }
                if ((*l_2406))
                    break;
                for (g_1188 = 0; g_1188 < 8; g_1188 += 1)
                {
                    for (g_268 = 0; g_268 < 8; g_268 += 1)
                    {
                        g_1265[g_1188][g_268] = &g_1266;
                    }
                }
            }
            ++l_2732;
        }
    }
    else
    { /* block id: 1214 */
        uint8_t l_2735 = 249UL;
        union U1 l_2748 = {0};
        union U0 l_2749 = {0xBACF8998L};
        uint8_t **l_2751 = &g_1882[5][1];
        uint8_t ***l_2750[8][7] = {{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751},{&l_2751,&l_2751,&l_2751,(void*)0,&l_2751,(void*)0,&l_2751}};
        int32_t l_2767 = 0x58B087D6L;
        uint8_t l_2768 = 9UL;
        int32_t l_2792 = (-1L);
        int32_t l_2793 = 7L;
        int32_t l_2794 = 0x3C9A2DE6L;
        int32_t l_2795 = 0x82488655L;
        int32_t l_2797 = 0x25E2E8BDL;
        uint8_t l_2798 = 0xF8L;
        const int32_t *l_2818 = &g_110;
        int i, j;
        if (((*l_2406) == ((p_13 && l_2735) , ((*g_157) || p_12))))
        { /* block id: 1215 */
            union U1 **** const l_2739 = (void*)0;
            int32_t l_2740 = 0x1705E1A6L;
            int32_t l_2766[9] = {(-2L),(-2L),0x0EA0EF96L,(-2L),(-2L),0x0EA0EF96L,(-2L),(-2L),0x0EA0EF96L};
            int i;
            if ((((safe_mul_func_uint8_t_u_u(((!18446744073709551611UL) != ((void*)0 != l_2739)), (*p_14))) & g_135) && (((*l_2406) = (p_15 < l_2740)) ^ l_2511[3])))
            { /* block id: 1217 */
                (*g_831) |= (safe_div_func_int16_t_s_s(((safe_add_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((*l_2406), 4)), ((-8L) >= ((((*g_365) , (g_2747[0][5] , l_2748)) , (l_2749 , l_2750[6][3])) == (void*)0)))) || ((+((**g_156) = l_2740)) <= p_15)), (**g_2302)));
            }
            else
            { /* block id: 1220 */
                int32_t *l_2753 = &l_2460[1].f1;
                int32_t *l_2754 = &l_2511[7];
                int32_t *l_2755 = (void*)0;
                int32_t *l_2756 = (void*)0;
                int32_t *l_2757 = &g_670.f3;
                int32_t *l_2758 = &l_2749.f1;
                int32_t *l_2759 = &g_635;
                int32_t *l_2760 = &l_2460[1].f1;
                int32_t *l_2761 = (void*)0;
                int32_t *l_2762 = (void*)0;
                int32_t *l_2763 = &g_218.f1;
                int32_t *l_2764 = &l_2507;
                int32_t *l_2765[10][6][4] = {{{(void*)0,(void*)0,(void*)0,&l_2740},{&l_2503,&l_2749.f1,&l_2507,&g_1377.f1},{(void*)0,&l_2511[6],&l_2511[7],(void*)0},{&l_2740,&g_1377.f1,&g_1289[0][0][2].f1,&l_2740},{&g_110,&g_1377.f1,&l_2511[0],(void*)0},{&g_1377.f1,&g_110,(void*)0,&g_218.f1}},{{&l_2507,&g_1377.f1,&g_110,&g_110},{&g_277.f0,&l_2507,(void*)0,(void*)0},{&l_2511[7],(void*)0,&g_1377.f1,(void*)0},{&g_1377.f1,&l_2511[7],(void*)0,&l_2511[7]},{&g_1289[0][0][2].f1,&g_1377.f1,(void*)0,&l_2511[7]},{&g_1289[0][0][2].f1,&g_1377.f1,&g_1289[0][0][2].f1,(void*)0}},{{&l_2507,&l_2749.f1,&l_2740,&l_2503},{&l_2507,(void*)0,&g_1289[0][0][2].f1,&l_2503},{&g_1289[0][0][2].f1,&l_2503,(void*)0,&g_1377.f1},{&g_1289[0][0][2].f1,&l_2749.f1,(void*)0,&l_2460[1].f1},{&g_1377.f1,&l_2503,&g_1377.f1,&g_1377.f1},{&l_2511[7],&l_2511[7],(void*)0,&g_1289[0][0][2].f1}},{{&g_277.f0,&g_1289[0][0][2].f1,&g_110,&l_2503},{&l_2507,&g_1377.f1,(void*)0,(void*)0},{&g_1377.f1,&l_2511[7],(void*)0,(void*)0},{&g_1377.f1,&g_1377.f1,&l_2740,&l_2460[1].f1},{&l_2503,&g_277.f0,(void*)0,&g_1289[0][0][2].f1},{&l_2511[5],&l_2503,(void*)0,(void*)0}},{{(void*)0,(void*)0,&l_2511[6],&l_2503},{&g_1289[0][0][2].f1,&g_218.f1,&g_218.f1,&l_2749.f1},{&l_2507,&g_1377.f1,(void*)0,(void*)0},{&l_2511[0],&l_2460[1].f1,&l_2740,&l_2511[7]},{&l_2503,&g_110,&g_110,&l_2503},{&g_1377.f1,(void*)0,(void*)0,(void*)0}},{{&g_1289[0][0][2].f1,&g_110,&l_2749.f1,&g_110},{&l_2507,&l_2503,&l_2507,&g_110},{&g_110,&g_110,(void*)0,(void*)0},{&l_2507,(void*)0,&l_2511[7],&l_2503},{&g_1377.f1,&g_110,(void*)0,&l_2511[7]},{&g_1377.f1,&l_2460[1].f1,(void*)0,(void*)0}},{{(void*)0,&g_1377.f1,&l_2503,&l_2749.f1},{&l_2507,&g_218.f1,(void*)0,&l_2503},{(void*)0,(void*)0,&g_1289[0][0][2].f1,(void*)0},{(void*)0,&l_2503,&l_2503,&g_1289[0][0][2].f1},{&g_1289[0][0][2].f1,&g_277.f0,(void*)0,&l_2460[1].f1},{&l_2503,&g_1377.f1,&g_1377.f1,(void*)0}},{{&l_2507,&l_2511[7],&l_2740,(void*)0},{&g_277.f0,&g_1377.f1,&l_2507,&l_2503},{&g_635,&g_1289[0][0][2].f1,(void*)0,&g_1289[0][0][2].f1},{&g_1289[0][0][2].f1,&l_2511[7],(void*)0,&g_1377.f1},{&g_1377.f1,&l_2503,&g_110,&l_2460[1].f1},{(void*)0,&l_2749.f1,(void*)0,&g_1377.f1}},{{&l_2511[0],&l_2503,&g_635,&l_2503},{(void*)0,(void*)0,&g_218.f1,&l_2503},{&g_1377.f1,&l_2749.f1,&g_218.f1,(void*)0},{(void*)0,&g_1377.f1,&g_635,&l_2511[7]},{&l_2511[0],&g_177,&l_2511[6],(void*)0},{&l_2511[6],(void*)0,&l_2740,&l_2511[6]}},{{&g_1289[0][0][2].f1,&l_2511[5],&l_2749.f1,&g_110},{(void*)0,&l_2511[7],&g_1377.f1,&g_1377.f1},{&g_635,&g_1377.f1,&l_2740,&g_110},{(void*)0,&l_2507,&g_110,&g_110},{(void*)0,&g_1377.f1,&l_2507,&g_218.f1},{&l_2511[7],(void*)0,&g_635,&l_2740}}};
                uint8_t l_2771 = 0xF2L;
                int i, j, k;
                l_2768--;
                l_2749.f1 = l_2771;
                for (l_2405.f1 = (-14); (l_2405.f1 == 37); ++l_2405.f1)
                { /* block id: 1225 */
                    union U3 l_2782 = {0L};
                    for (g_37 = 0; (g_37 < (-18)); g_37--)
                    { /* block id: 1228 */
                        int16_t ***l_2779 = (void*)0;
                        int16_t **l_2781[3];
                        int16_t ***l_2780 = &l_2781[1];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2781[i] = (void*)0;
                        l_2766[3] |= (((((*l_2406) , ((((*g_1694)++) , (p_15 <= ((*g_503) , ((*l_2760) = ((l_2778[2][9][1] , (*l_2760)) > ((&g_1477 != ((*l_2780) = &g_1477)) | p_15)))))) , ((*l_2406) , l_2768))) < p_13) , l_2782) , p_13);
                    }
                    if (l_2735)
                        break;
                }
            }
            l_2740 |= p_15;
        }
        else
        { /* block id: 1238 */
            int32_t *l_2783 = &g_1289[0][0][2].f1;
            int32_t *l_2784 = &l_2507;
            int32_t *l_2785 = &l_2511[5];
            int32_t l_2786 = 0x8CF33F1CL;
            int32_t *l_2787 = &l_2786;
            int32_t *l_2788 = &l_2786;
            int32_t *l_2789 = &l_2778[1][1][1];
            int32_t *l_2790 = (void*)0;
            int32_t *l_2791[1][5] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            int i, j;
            --l_2798;
        }
        for (g_310 = 0; (g_310 > 12); g_310 = safe_add_func_uint16_t_u_u(g_310, 6))
        { /* block id: 1243 */
            uint8_t l_2815 = 255UL;
            if (p_13)
                break;
            for (g_640 = 21; (g_640 != 3); g_640 = safe_sub_func_int64_t_s_s(g_640, 4))
            { /* block id: 1247 */
                if (((**g_739) , p_12))
                { /* block id: 1248 */
                    int32_t *l_2805 = &g_635;
                    int32_t *l_2806 = &l_2778[2][9][1];
                    int32_t *l_2807 = &l_2778[1][9][3];
                    int32_t *l_2808 = &l_2795;
                    int32_t *l_2809 = &l_2795;
                    int32_t *l_2810 = &l_2767;
                    int32_t *l_2811 = &g_972.f3;
                    int32_t *l_2812 = &l_2796[0];
                    int32_t *l_2813 = &l_2795;
                    int32_t *l_2814[10] = {&l_2792,&g_110,&l_2511[2],&l_2511[2],&g_110,&l_2792,&g_110,&l_2511[2],&l_2511[2],&g_110};
                    int i;
                    l_2815++;
                }
                else
                { /* block id: 1250 */
                    return (**l_2479);
                }
                l_2818 = (*g_833);
                (*g_831) ^= (*l_2406);
            }
        }
    }
    for (l_2507 = 0; (l_2507 < (-28)); l_2507 = safe_sub_func_uint64_t_u_u(l_2507, 7))
    { /* block id: 1260 */
        int32_t *l_2821 = &l_2511[7];
        int32_t *l_2822 = (void*)0;
        int32_t *l_2823 = &l_2503;
        int32_t *l_2824 = &g_972.f3;
        int32_t *l_2825[5][7] = {{&g_218.f1,(void*)0,&l_2796[1],&l_2796[1],(void*)0,&g_218.f1,(void*)0},{&l_2507,&g_218.f1,&g_218.f1,&l_2507,(void*)0,&l_2507,&g_218.f1},{(void*)0,(void*)0,&g_218.f1,&l_2796[1],&g_218.f1,(void*)0,(void*)0},{(void*)0,&g_218.f1,&l_2796[1],&g_218.f1,(void*)0,(void*)0,&g_218.f1},{&l_2507,(void*)0,&l_2507,&g_218.f1,&g_218.f1,&l_2507,(void*)0}};
        uint64_t l_2826 = 18446744073709551613UL;
        union U1 l_2839 = {0};
        int i, j;
        l_2406 = l_2821;
        ++l_2826;
        for (g_34 = 23; (g_34 != 15); g_34--)
        { /* block id: 1265 */
            uint16_t l_2831 = 0xEF26L;
            int64_t l_2834 = (-10L);
            int16_t *l_2840 = &g_546;
            union U0 **l_2863 = &g_1286;
            (*g_831) = (*l_2406);
        }
    }
    l_2879--;
    return (**l_2479);
}


/* ------------------------------------------ */
/* 
 * reads : g_1097 g_1098 g_1099 g_277 g_2001 g_335 g_227 g_37 g_1679 g_1680 g_1681 g_831 g_218.f1 g_334 g_944 g_787 g_2063 g_1289.f1 g_2079 g_2087 g_2094 g_1115 g_808 g_833 g_177 g_277.f0 g_1676 g_1677 g_36 g_230 g_1266 g_274 g_157 g_34 g_631 g_1485 g_1004 g_1052 g_1305 g_1108 g_546 g_268 g_156 g_1508 g_739 g_740 g_741 g_108 g_144 g_1188 g_2302 g_690 g_1693 g_1694 g_300 g_2317 g_2336 g_310 g_218.f0 g_638 g_2384 g_481 g_2396 g_218 g_274.f1 g_635 g_178
 * writes: g_177 g_230 g_37 g_310 g_787 g_274.f1 g_218.f1 g_1289.f1 g_635 g_2094 g_808 g_34 g_1305 g_1681 g_631 g_1004 g_1266 g_277.f0 g_640 g_2001 g_300 g_178 g_335 g_2292 g_108 g_268 g_2302 g_690 g_2336 g_2283 g_863
 */
static union U0  func_19(int8_t * p_20, uint32_t  p_21, int16_t  p_22, const int8_t * p_23, int8_t * p_24)
{ /* block id: 893 */
    const union U1 l_2009[4][1] = {{{0}},{{0}},{{0}},{{0}}};
    int32_t l_2018 = 1L;
    uint32_t l_2019 = 4294967294UL;
    int32_t l_2026[1];
    uint64_t l_2027[7] = {0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL,0xC3C0C61B27D81FB8LL};
    uint16_t l_2028 = 65535UL;
    int16_t l_2048 = 6L;
    uint32_t l_2055 = 0x4F054107L;
    union U3 *l_2058 = &g_277;
    int8_t * const *l_2077 = &g_36;
    int8_t * const **l_2076 = &l_2077;
    union U0 *l_2092 = &g_218;
    uint64_t **l_2102 = &g_1694;
    uint64_t ***l_2101 = &l_2102;
    union U4 *l_2144[10][1];
    union U2 l_2153[6][4][2] = {{{{0L},{-1L}},{{0xDAL},{1L}},{{-1L},{0xDAL}},{{1L},{-1L}}},{{{1L},{0xDAL}},{{-1L},{1L}},{{0xDAL},{-1L}},{{0L},{0L}}},{{{-1L},{0L}},{{0L},{-1L}},{{0xDAL},{1L}},{{-1L},{0xDAL}}},{{{1L},{-1L}},{{1L},{0xDAL}},{{-1L},{1L}},{{0xDAL},{-1L}}},{{{0L},{0L}},{{-1L},{0L}},{{0L},{-1L}},{{0xDAL},{1L}}},{{{-1L},{0xDAL}},{{1L},{-1L}},{{1L},{0xDAL}},{{-1L},{1L}}}};
    int8_t l_2154[7][4][4] = {{{0x6AL,0xBBL,0xBBL,0x6AL},{8L,0x0DL,0xBBL,(-1L)},{0x6AL,0x6BL,0x1FL,0x6BL},{0x6BL,0xBBL,8L,0x6BL}},{{8L,0x6BL,(-1L),(-1L)},{0x0DL,0x0DL,0x1FL,0x6AL},{0x0DL,0xBBL,(-1L),0x0DL},{8L,0x6AL,8L,(-1L)}},{{0x6BL,0x6AL,0x1FL,0x0DL},{0x6AL,0xBBL,0xBBL,0x6AL},{8L,0x0DL,0xBBL,(-1L)},{0x6AL,0x6BL,0x1FL,0x6BL}},{{0x6BL,0xBBL,8L,(-1L)},{(-7L),(-1L),0xC0L,0xC0L},{8L,8L,0x0DL,0xBBL},{8L,0x1FL,0xC0L,8L}},{{(-7L),0xBBL,(-7L),0xC0L},{(-1L),0xBBL,0x0DL,8L},{0xBBL,0x1FL,0x1FL,0xBBL},{(-7L),8L,0x1FL,0xC0L}},{{0xBBL,(-1L),0x0DL,(-1L)},{(-1L),0x1FL,(-7L),(-1L)},{(-7L),(-1L),0xC0L,0xC0L},{8L,8L,0x0DL,0xBBL}},{{8L,0x1FL,0xC0L,8L},{(-7L),0xBBL,(-7L),0xC0L},{(-1L),0xBBL,0x0DL,8L},{0xBBL,0x1FL,0x1FL,0xBBL}}};
    int32_t ***l_2309 = (void*)0;
    union U0 l_2404 = {0x7EAEEEFDL};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_2026[i] = (-7L);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
            l_2144[i][j] = &g_972;
    }
lbl_2400:
    if ((safe_div_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u((~p_21), ((((l_2009[0][0] , (safe_add_func_uint32_t_u_u((safe_add_func_uint64_t_u_u((((safe_sub_func_uint8_t_u_u(p_21, (safe_lshift_func_int8_t_s_u((l_2018 = 0L), 6)))) & ((***g_1097) , 0xBE03ACF9L)) == l_2019), (((*g_335) = ((((safe_mod_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s((l_2019 ^ (safe_sub_func_int8_t_s_s(l_2019, 0x20L))), 14)) >= g_2001), 0x24BEC7E0L)) == p_21) || l_2019) && l_2026[0])) || l_2019))), l_2027[0]))) ^ 0xB6L) , l_2027[0]) >= p_22))), (*p_23))) && l_2027[4]), l_2028)))
    { /* block id: 896 */
        uint32_t *l_2031 = &g_230;
        union U3 ****l_2032 = &g_1679;
        int32_t l_2047 = (-9L);
        int32_t l_2049 = (-1L);
        int32_t l_2050 = 0xBB2460BDL;
        int32_t l_2051 = 0x32BB3498L;
        int32_t l_2052 = (-4L);
        int32_t l_2053 = 0x7FA9B2CBL;
        int32_t l_2054[7][8] = {{0x526F7EE0L,0x065C8023L,0x8A37B344L,0x065C8023L,0x526F7EE0L,0x526F7EE0L,0x065C8023L,0x8A37B344L},{0x526F7EE0L,0x526F7EE0L,0x065C8023L,0x8A37B344L,0x065C8023L,0x526F7EE0L,0x526F7EE0L,0x065C8023L},{(-3L),0x065C8023L,0x065C8023L,(-3L),0xE984DB7AL,(-3L),0x065C8023L,0x065C8023L},{0x065C8023L,0xE984DB7AL,0x8A37B344L,0x8A37B344L,0xE984DB7AL,0x065C8023L,0xE984DB7AL,0x8A37B344L},{(-3L),0xE984DB7AL,(-3L),0x065C8023L,0x065C8023L,(-3L),0xE984DB7AL,(-3L)},{0x526F7EE0L,0x065C8023L,0x8A37B344L,0x065C8023L,0x526F7EE0L,0x526F7EE0L,0x065C8023L,0x8A37B344L},{0x526F7EE0L,0x526F7EE0L,0x065C8023L,0x8A37B344L,0x065C8023L,0x526F7EE0L,0x526F7EE0L,0x065C8023L}};
        union U2 ** const l_2078 = (void*)0;
        int64_t l_2093 = 0x23486A8F16F2E278LL;
        int32_t *l_2109 = &g_1377.f1;
        uint16_t l_2124 = 9UL;
        int8_t l_2145[4];
        union U2 **l_2176 = &g_1266;
        int i, j;
        for (i = 0; i < 4; i++)
            l_2145[i] = (-1L);
        if ((safe_sub_func_int16_t_s_s((((*l_2031) = (0xBBL && (*p_20))) == l_2027[0]), (l_2032 != (void*)0))))
        { /* block id: 898 */
            int32_t *l_2033 = &g_1377.f1;
            int32_t *l_2034 = (void*)0;
            int32_t *l_2035 = &g_110;
            int32_t *l_2036 = (void*)0;
            int32_t *l_2037 = &g_177;
            int32_t *l_2038 = (void*)0;
            int32_t *l_2039 = &g_670.f3;
            int32_t *l_2040 = &g_1289[0][0][2].f1;
            int32_t l_2041 = 0x15EAEE3AL;
            int32_t *l_2042 = &g_218.f1;
            int32_t *l_2043 = (void*)0;
            int32_t l_2044 = 7L;
            int32_t l_2045 = (-10L);
            int32_t *l_2046[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int64_t l_2066 = (-6L);
            const uint32_t **l_2099 = &g_2095;
            int i;
            l_2055--;
            for (g_37 = 6; (g_37 >= 1); g_37 -= 1)
            { /* block id: 902 */
                uint8_t l_2059 = 0xF7L;
                l_2058 = (***l_2032);
                if ((*g_831))
                    continue;
                --l_2059;
                (**g_334) = (-9L);
                for (g_310 = 0; (g_310 <= 6); g_310 += 1)
                { /* block id: 909 */
                    (*g_2063) = (*g_944);
                }
            }
            for (g_274.f1 = 0; (g_274.f1 > 9); g_274.f1 = safe_add_func_int64_t_s_s(g_274.f1, 6))
            { /* block id: 915 */
                union U0 l_2075 = {4294967295UL};
                (*l_2040) &= (l_2066 |= ((*l_2042) = p_21));
                (**g_334) = p_21;
                (*l_2037) = (safe_add_func_int64_t_s_s(5L, (safe_mod_func_int8_t_s_s((safe_mod_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(((l_2075 , (l_2076 != &g_1677[0][3])) != ((((****l_2032) , l_2078) == (g_2079 , (void*)0)) & (p_21 == p_21))), l_2075.f1)), l_2075.f0)), l_2075.f0))));
            }
            for (g_635 = 10; (g_635 < 19); ++g_635)
            { /* block id: 924 */
                uint32_t l_2082 = 0xDFCB8C18L;
                const uint32_t ***l_2096 = &g_2094[4][3];
                const uint32_t ***l_2097 = (void*)0;
                const uint32_t ***l_2098 = (void*)0;
                l_2082++;
                if ((*l_2042))
                    break;
                (*g_831) |= (((safe_sub_func_uint64_t_u_u((g_2087 , (safe_sub_func_int8_t_s_s((safe_mod_func_int64_t_s_s(((void*)0 != l_2092), p_22)), (((l_2093 > (((*l_2096) = g_2094[4][3]) == (l_2099 = (void*)0))) != (l_2031 == &g_230)) == p_21)))), g_227[7])) < 0x96A8D3ECL) != (*p_23));
            }
        }
        else
        { /* block id: 931 */
            const int32_t **l_2100[1];
            const uint64_t *l_2105 = (void*)0;
            const uint64_t * const *l_2104 = &l_2105;
            const uint64_t * const **l_2103 = &l_2104;
            int32_t l_2117 = 0x2C3B7A71L;
            int32_t l_2118 = (-2L);
            int32_t l_2122 = 0x52C51D79L;
            int32_t l_2123 = (-1L);
            uint8_t **l_2135 = &g_1882[5][1];
            int8_t l_2165 = (-1L);
            union U2 l_2171 = {0xA4L};
            int i;
            for (i = 0; i < 1; i++)
                l_2100[i] = &g_808;
            (*g_833) = (*g_1115);
lbl_2108:
            (**g_334) |= (l_2101 == l_2103);
            for (g_34 = (-20); (g_34 >= 36); ++g_34)
            { /* block id: 936 */
                int8_t l_2115 = 6L;
                int32_t l_2119 = (-1L);
                union U3 *l_2146 = &g_277;
                if (g_277.f0)
                    goto lbl_2108;
                l_2109 = &l_2026[0];
                for (g_1305 = 20; (g_1305 > 14); g_1305 = safe_sub_func_int16_t_s_s(g_1305, 4))
                { /* block id: 941 */
                    int8_t l_2114 = 0x9EL;
                    int32_t l_2120 = (-8L);
                    int32_t l_2121[1][7];
                    uint64_t l_2136 = 1UL;
                    uint16_t *l_2168 = &g_1004;
                    int i, j;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_2121[i][j] = 0x9F37951DL;
                    }
                    for (l_2055 = (-9); (l_2055 < 59); l_2055 = safe_add_func_uint16_t_u_u(l_2055, 7))
                    { /* block id: 944 */
                        if (l_2093)
                            goto lbl_2108;
                        if (p_21)
                            break;
                        if (p_21)
                            break;
                    }
                    if (l_2114)
                    { /* block id: 949 */
                        (*g_335) = l_2115;
                    }
                    else
                    { /* block id: 951 */
                        int32_t *l_2116[7][9] = {{&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049},{&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0},{&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049},{&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0},{&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049},{&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0,&g_277.f0,&g_277.f0,(void*)0},{&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049,&l_2054[3][1],&l_2054[3][1],&l_2049}};
                        uint8_t *l_2163 = &g_631;
                        const uint32_t l_2164 = 18446744073709551615UL;
                        int i, j;
                        --l_2124;
                        if (g_268)
                            goto lbl_2400;
                        (*g_831) ^= (((**g_334) && ((safe_div_func_uint8_t_u_u((safe_mul_func_uint32_t_u_u(((safe_add_func_uint8_t_u_u(((void*)0 == l_2135), l_2136)) & (*l_2109)), ((safe_unary_minus_func_uint8_t_u((safe_rshift_func_int16_t_s_s(((((***g_1676) = ((p_21 , 65534UL) , ((safe_add_func_uint32_t_u_u((safe_sub_func_int8_t_s_s((p_22 < ((l_2144[4][0] != (void*)0) , 0x0DL)), l_2145[3])), p_21)) || l_2136))) > (*p_23)) , (-1L)), p_21)))) == 0x08FCD64BL))), (-2L))) <= 0xFDE3L)) && 0xA5013219L);
                        (**g_1679) = l_2146;
                        (*l_2109) = (safe_mul_func_int8_t_s_s((((*l_2031) &= 4294967295UL) != ((((p_22 < (safe_lshift_func_uint16_t_u_s(p_21, p_22))) , (*g_1266)) , (((safe_div_func_uint8_t_u_u(((l_2153[2][3][1] , l_2154[2][0][3]) > (safe_mul_func_int8_t_s_s((p_22 , (safe_mul_func_uint8_t_u_u(((*l_2163) &= (safe_div_func_int64_t_s_s((((safe_rshift_func_uint16_t_u_u(65528UL, (*g_157))) , &g_1305) == (void*)0), p_21))), (*p_24)))), (*p_24)))), (*p_23))) && g_1485) != 1L)) , l_2164)), l_2165));
                    }
                    (**g_334) = ((safe_add_func_uint16_t_u_u((l_2120 = (++(*l_2168))), (p_22 & (*l_2109)))) , (l_2171 , ((void*)0 != &g_1693)));
                }
            }
            (*g_335) &= (safe_rshift_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((l_2123 = 1L), 1UL)), 6));
        }
        l_2018 = l_2153[2][3][1].f0;
        (*l_2176) = &l_2153[1][0][0];
    }
    else
    { /* block id: 970 */
        union U0 l_2211 = {0xDE981006L};
        int32_t *l_2230 = &g_110;
        union U1 l_2232 = {0};
        int32_t l_2323 = 0xEF141A05L;
        uint64_t l_2324[7][1][4] = {{{9UL,9UL,3UL,18446744073709551615UL}},{{18446744073709551615UL,3UL,3UL,18446744073709551615UL}},{{3UL,18446744073709551615UL,3UL,3UL}},{{18446744073709551615UL,18446744073709551615UL,9UL,18446744073709551615UL}},{{18446744073709551615UL,3UL,3UL,18446744073709551615UL}},{{3UL,18446744073709551615UL,3UL,3UL}},{{18446744073709551615UL,18446744073709551615UL,9UL,18446744073709551615UL}}};
        int32_t l_2328 = (-9L);
        int32_t l_2330 = (-1L);
        int32_t l_2331 = (-1L);
        int32_t l_2332[7] = {1L,1L,1L,1L,1L,1L,1L};
        uint8_t **l_2346 = &g_1882[5][1];
        int i, j, k;
        for (g_277.f0 = 0; (g_277.f0 != 17); g_277.f0++)
        { /* block id: 973 */
            uint16_t l_2206 = 65535UL;
            int32_t l_2207 = (-10L);
            int32_t l_2210[1][9][8] = {{{2L,0L,(-6L),1L,(-6L),0L,2L,2L},{0L,1L,0x344FC8AAL,0x344FC8AAL,1L,0L,0xFD476C87L,0L},{1L,0L,0xFD476C87L,0L,1L,0x344FC8AAL,0x344FC8AAL,1L},{0L,2L,2L,0L,(-6L),1L,(-6L),0L},{2L,(-6L),2L,0x344FC8AAL,0xFD476C87L,0xFD476C87L,0x344FC8AAL,2L},{(-6L),(-6L),0xFD476C87L,1L,0xD44374B1L,1L,0xFD476C87L,(-6L)},{(-6L),2L,0x344FC8AAL,0xFD476C87L,0xFD476C87L,0x344FC8AAL,2L,(-6L)},{2L,0L,(-6L),1L,(-6L),0L,2L,2L},{0L,1L,0x344FC8AAL,0x344FC8AAL,1L,0L,0xFD476C87L,0L}}};
            int32_t l_2214 = 0x394E4137L;
            union U0 l_2226 = {0xC13AFFA5L};
            int8_t * const **l_2242 = &l_2077;
            union U2 *l_2245 = &l_2153[2][3][1];
            uint64_t l_2274[8] = {18446744073709551615UL,0xD4025D7DA034DF2DLL,18446744073709551615UL,18446744073709551615UL,0xD4025D7DA034DF2DLL,18446744073709551615UL,18446744073709551615UL,0xD4025D7DA034DF2DLL};
            int i, j, k;
            for (g_230 = 13; (g_230 == 32); g_230++)
            { /* block id: 976 */
                uint64_t l_2209 = 0UL;
                for (g_640 = (-3); (g_640 != 35); g_640 = safe_add_func_uint8_t_u_u(g_640, 3))
                { /* block id: 979 */
                    union U1 l_2205 = {0};
                    int32_t l_2208 = 1L;
                    (**g_334) = (safe_lshift_func_uint8_t_u_s(((((safe_mul_func_int16_t_s_s((((safe_add_func_int64_t_s_s((l_2207 = ((-3L) ^ (safe_lshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_s((safe_lshift_func_uint16_t_u_u((((l_2206 &= (((safe_rshift_func_uint8_t_u_s(p_22, 3)) && ((((**g_334) != g_1052) , (safe_lshift_func_int8_t_s_s((***g_1676), ((safe_div_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(((safe_rshift_func_int8_t_s_u((*p_24), 1)) & ((l_2205 , p_22) || l_2018)), g_1305)), g_1108)) , (*p_23))))) == 1L)) , 0x80L)) , p_21) != l_2207), 15)), 2)), l_2208)))), p_21)) < l_2209) ^ p_21), l_2210[0][0][1])) && (-2L)) ^ 0xE3E0ADE3L) >= 0x77763160F3599906LL), l_2208));
                    return l_2211;
                }
                for (g_274.f1 = (-28); (g_274.f1 != 30); g_274.f1 = safe_add_func_uint32_t_u_u(g_274.f1, 6))
                { /* block id: 987 */
                    union U1 ***l_2220 = &g_1154;
                    for (p_22 = 0; (p_22 <= 0); p_22 += 1)
                    { /* block id: 990 */
                        uint8_t l_2223 = 251UL;
                        (*g_831) = l_2214;
                        if (p_22)
                            break;
                        (*g_831) = (p_22 && ((safe_add_func_int16_t_s_s(((~l_2211.f1) , (((safe_lshift_func_uint16_t_u_s((((((void*)0 != l_2220) && (safe_sub_func_uint32_t_u_u(((l_2223 ^ g_546) == (1UL || 0x2AL)), (g_268 | (-1L))))) < p_21) < 0xBDL), l_2055)) , p_21) , 0xE650L)), p_22)) & p_21));
                    }
                    return l_2211;
                }
                for (g_2001 = (-22); (g_2001 > 11); ++g_2001)
                { /* block id: 999 */
                    return l_2226;
                }
                if (l_2209)
                    goto lbl_2400;
            }
            for (g_300 = 0; (g_300 < 42); g_300 = safe_add_func_int16_t_s_s(g_300, 3))
            { /* block id: 1005 */
                int32_t * const l_2229[4][9] = {{&l_2210[0][0][1],&g_218.f1,&l_2210[0][0][1],&g_635,&g_635,&l_2210[0][0][1],&g_218.f1,&l_2210[0][0][1],&g_635},{&l_2211.f1,&g_177,&g_177,&l_2211.f1,(void*)0,&l_2211.f1,&g_177,&g_177,&l_2211.f1},{&l_2210[0][3][4],&g_635,&g_277.f0,&g_635,&l_2210[0][3][4],&l_2210[0][3][4],&g_635,&g_277.f0,&g_635},{&g_177,(void*)0,(void*)0,(void*)0,(void*)0,&g_177,(void*)0,(void*)0,(void*)0}};
                int i, j;
                l_2230 = l_2229[0][2];
            }
            if ((~(l_2232 , (((safe_lshift_func_int16_t_s_s((p_22 , (safe_unary_minus_func_uint16_t_u((--(**g_156))))), 11)) < (l_2211.f1 = (safe_mod_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((l_2242 != l_2242), ((safe_rshift_func_int16_t_s_s(g_1289[0][0][2].f1, ((void*)0 == l_2245))) | (safe_lshift_func_uint8_t_u_s((safe_div_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s((p_22 != 6L), l_2028)), 0x01C9L)) | 0x7100617CDA3D77C4LL), p_22)), (*p_23)))))), l_2154[3][0][1])))) , 0UL))))
            { /* block id: 1010 */
                uint8_t *l_2270 = (void*)0;
                uint8_t *l_2271 = (void*)0;
                uint8_t *l_2272[1];
                int32_t l_2273 = 0x0F537A64L;
                int i;
                for (i = 0; i < 1; i++)
                    l_2272[i] = &g_144[0];
                (**g_334) = (safe_div_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s(l_2048, ((((((&l_2153[2][3][1] == &l_2153[4][3][1]) != ((((*p_20) = ((safe_rshift_func_uint16_t_u_u((safe_unary_minus_func_int32_t_s(((*g_831) = (+p_22)))), 14)) == g_1508)) && ((safe_rshift_func_int16_t_s_s((-5L), (p_22 | (1L | (safe_div_func_int32_t_s_s((safe_sub_func_uint8_t_u_u((l_2273 ^= 0x61L), l_2018)), g_277.f0)))))) && (-1L))) >= l_2153[2][3][1].f0)) & l_2274[7]) , l_2273) < l_2027[1]) , 1L))), (*p_24)));
            }
            else
            { /* block id: 1015 */
                union U0 l_2275 = {0x9B95B865L};
                return l_2275;
            }
        }
lbl_2318:
        for (g_178 = 0; (g_178 >= 5); ++g_178)
        { /* block id: 1021 */
            int32_t *l_2278[9][8][3] = {{{&l_2018,&g_110,&g_110},{&g_110,(void*)0,&g_1377.f1},{&l_2018,&l_2026[0],&g_110},{(void*)0,(void*)0,&g_277.f0},{&l_2018,&g_110,&g_110},{&g_110,(void*)0,&g_1377.f1},{&l_2018,&l_2026[0],&g_110},{(void*)0,(void*)0,&g_277.f0}},{{&l_2018,&g_110,&g_110},{&g_110,(void*)0,&g_1377.f1},{&l_2018,&l_2026[0],&g_110},{(void*)0,(void*)0,&g_277.f0},{&l_2018,&g_110,&g_110},{&g_110,(void*)0,&g_1377.f1},{&l_2018,&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}},{{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0},{&l_2026[0],(void*)0,(void*)0},{&g_1377.f1,(void*)0,&g_1377.f1},{&l_2026[0],&g_1289[0][0][2].f1,(void*)0},{&g_277.f0,(void*)0,(void*)0}}};
            int i, j, k;
            (*g_334) = l_2278[4][1][0];
        }
        for (g_300 = 15; (g_300 != 44); g_300++)
        { /* block id: 1026 */
            int32_t *l_2282 = &g_2283[2];
            int32_t **l_2281[2][9][5] = {{{&l_2282,&l_2282,&l_2282,&l_2282,&l_2282},{(void*)0,&l_2282,&l_2282,&l_2282,&l_2282},{&l_2282,&l_2282,(void*)0,&l_2282,&l_2282},{&l_2282,&l_2282,&l_2282,(void*)0,(void*)0},{(void*)0,(void*)0,&l_2282,&l_2282,(void*)0},{(void*)0,&l_2282,&l_2282,&l_2282,&l_2282},{&l_2282,(void*)0,&l_2282,(void*)0,&l_2282},{&l_2282,(void*)0,&l_2282,(void*)0,&l_2282},{&l_2282,&l_2282,&l_2282,(void*)0,&l_2282}},{{&l_2282,&l_2282,&l_2282,&l_2282,(void*)0},{&l_2282,&l_2282,(void*)0,&l_2282,&l_2282},{(void*)0,(void*)0,&l_2282,(void*)0,&l_2282},{(void*)0,&l_2282,(void*)0,(void*)0,&l_2282},{&l_2282,&l_2282,&l_2282,&l_2282,&l_2282},{&l_2282,&l_2282,&l_2282,&l_2282,&l_2282},{(void*)0,&l_2282,&l_2282,(void*)0,&l_2282},{&l_2282,&l_2282,(void*)0,(void*)0,&l_2282},{&l_2282,&l_2282,&l_2282,(void*)0,(void*)0}}};
            int32_t ***l_2284 = &l_2281[0][7][4];
            int32_t l_2316 = 0xF6E9B6D8L;
            int32_t l_2327 = 8L;
            int32_t l_2329 = 0xB4D81F79L;
            int32_t l_2333 = 0x58CDAA8AL;
            int32_t l_2334 = 0L;
            union U0 l_2362 = {7UL};
            uint16_t ** const l_2363 = &g_895;
            int32_t *l_2382[7];
            union U2 ****l_2393[6][4][5] = {{{&g_1264[5][9][0],&g_1264[4][5][0],&g_1264[5][9][0],&g_1264[4][3][0],(void*)0},{(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],(void*)0,&g_1264[5][9][0]},{&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][6][1],(void*)0,&g_1264[4][3][0]},{&g_1264[5][9][0],&g_1264[5][0][0],&g_1264[5][9][0],(void*)0,&g_1264[5][9][0]}},{{&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[4][3][0],(void*)0,&g_1264[5][6][1]},{&g_1264[4][7][2],(void*)0,&g_1264[5][9][0],(void*)0,&g_1264[5][9][0]},{&g_1264[5][9][0],&g_1264[4][3][0],(void*)0,&g_1264[4][3][0],&g_1264[5][9][0]},{&g_1264[5][9][0],(void*)0,&g_1264[0][0][3],&g_1264[0][5][0],(void*)0}},{{(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0]},{&g_1264[0][5][0],&g_1264[5][0][0],&g_1264[0][5][0],(void*)0,(void*)0},{(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0]},{(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0]}},{{&g_1264[5][9][0],&g_1264[4][5][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][6][1]},{&g_1264[5][0][0],(void*)0,&g_1264[0][5][0],&g_1264[5][9][0],&g_1264[5][9][0]},{(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],(void*)0,&g_1264[4][3][0]},{&g_1264[5][0][0],&g_1264[5][9][0],&g_1264[0][0][3],&g_1264[5][9][0],&g_1264[5][9][0]}},{{&g_1264[5][9][0],&g_1264[5][9][0],(void*)0,&g_1264[5][9][0],(void*)0},{(void*)0,(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[0][0][3]},{(void*)0,&g_1264[5][9][0],&g_1264[4][3][0],(void*)0,&g_1264[5][9][0]},{&g_1264[0][5][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[0][5][0]}},{{(void*)0,&g_1264[5][9][0],&g_1264[5][6][1],&g_1264[5][9][0],&g_1264[5][9][0]},{&g_1264[5][9][0],(void*)0,&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0]},{&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0],&g_1264[5][9][0]},{&g_1264[4][7][2],&g_1264[5][9][0],(void*)0,(void*)0,&g_1264[5][9][0]}}};
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_2382[i] = &g_218.f1;
            (*l_2284) = l_2281[0][0][1];
            (*g_831) = p_21;
            (*g_831) = 0x968D33B4L;
            for (l_2211.f1 = 0; (l_2211.f1 < (-2)); l_2211.f1 = safe_sub_func_int8_t_s_s(l_2211.f1, 5))
            { /* block id: 1032 */
                int16_t l_2287[4][6][1] = {{{0x6350L},{0x4244L},{0xD514L},{0L},{0xD0CCL},{0xBA6DL}},{{0xD0CCL},{0L},{0xD514L},{0x4244L},{0x6350L},{0x4244L}},{{0xD514L},{0L},{0xD0CCL},{0xBA6DL},{0xD0CCL},{0L}},{{0xD514L},{0x4244L},{0x6350L},{0x4244L},{0xD514L},{0L}}};
                int32_t l_2298 = 0x64B4ECBAL;
                int32_t l_2299 = 0xF080FCB6L;
                union U3 l_2308 = {-9L};
                int32_t l_2335 = 0xAC766EEFL;
                uint8_t *l_2341 = &g_1305;
                uint8_t ***l_2347 = &l_2346;
                int16_t *l_2364 = &g_310;
                int i, j, k;
                for (g_1004 = 0; (g_1004 <= 9); g_1004 += 1)
                { /* block id: 1035 */
                    uint32_t l_2294 = 0xC57CC572L;
                    int32_t *l_2319 = &g_110;
                    int32_t *l_2320 = &g_635;
                    int32_t *l_2321 = &g_972.f3;
                    int32_t *l_2322[4][10][5] = {{{&l_2308.f0,&l_2211.f1,&g_1289[0][0][2].f1,(void*)0,&l_2316},{&l_2211.f1,&g_635,&l_2299,&l_2299,(void*)0},{&l_2298,&l_2298,&l_2026[0],&g_218.f1,(void*)0},{(void*)0,&g_218.f1,&l_2298,&g_635,&g_277.f0},{&l_2308.f0,&l_2308.f0,&l_2298,(void*)0,&l_2308.f0},{&g_277.f0,&l_2308.f0,&l_2299,&l_2026[0],&g_1289[0][0][2].f1},{&l_2308.f0,&l_2026[0],&l_2299,&g_1289[0][0][2].f1,&l_2026[0]},{&g_1377.f1,(void*)0,&l_2298,&l_2026[0],&l_2308.f0},{&g_218.f1,(void*)0,&l_2298,&l_2211.f1,(void*)0},{&l_2211.f1,&l_2298,&l_2026[0],&l_2026[0],&g_1377.f1}},{{&l_2026[0],(void*)0,&l_2299,(void*)0,&g_1289[0][0][2].f1},{(void*)0,&g_277.f0,&g_1289[0][0][2].f1,(void*)0,(void*)0},{&l_2308.f0,&g_1289[0][0][2].f1,&l_2211.f1,(void*)0,&l_2211.f1},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_2308.f0,&l_2316,&g_1289[0][0][2].f1,&l_2298,&g_1377.f1},{(void*)0,(void*)0,&g_218.f1,&g_1289[0][0][2].f1,&g_177},{&l_2026[0],&l_2316,&g_277.f0,&l_2026[0],&l_2308.f0},{&g_1377.f1,(void*)0,&l_2316,&l_2299,(void*)0},{&l_2308.f0,&g_1289[0][0][2].f1,(void*)0,(void*)0,&l_2026[0]},{&l_2211.f1,&g_277.f0,(void*)0,(void*)0,&l_2308.f0}},{{&l_2299,(void*)0,(void*)0,&l_2211.f1,&l_2299},{(void*)0,&l_2298,&l_2211.f1,&l_2308.f0,(void*)0},{(void*)0,(void*)0,&l_2026[0],&l_2299,(void*)0},{&g_1289[0][0][2].f1,(void*)0,&l_2211.f1,&l_2211.f1,&g_635},{(void*)0,&l_2026[0],(void*)0,&l_2316,&l_2211.f1},{(void*)0,&l_2308.f0,&g_218.f1,(void*)0,&g_1289[0][0][2].f1},{&g_1289[0][0][2].f1,&l_2308.f0,&l_2299,&g_218.f1,&l_2211.f1},{(void*)0,&g_218.f1,&g_218.f1,&g_1377.f1,&l_2211.f1},{(void*)0,&l_2298,&g_1289[0][0][2].f1,(void*)0,&l_2308.f0},{&l_2299,&g_635,&g_218.f1,&g_218.f1,&l_2211.f1}},{{&l_2211.f1,&l_2211.f1,&l_2211.f1,&l_2316,&l_2211.f1},{&l_2308.f0,(void*)0,&l_2298,(void*)0,&l_2308.f0},{&g_1377.f1,&g_635,&l_2026[0],&g_177,(void*)0},{&g_177,(void*)0,&l_2026[0],&l_2211.f1,(void*)0},{&g_277.f0,(void*)0,&g_277.f0,&g_1377.f1,&l_2026[0]},{(void*)0,&l_2211.f1,&l_2299,&l_2211.f1,(void*)0},{&l_2026[0],&g_277.f0,&g_635,&l_2211.f1,&l_2026[0]},{&l_2211.f1,&l_2299,&g_635,&l_2211.f1,&l_2299},{&g_635,&l_2308.f0,&l_2299,&g_277.f0,&l_2211.f1},{(void*)0,&l_2298,&g_277.f0,(void*)0,&l_2299}}};
                    int i, j, k;
                    for (p_21 = 1; (p_21 <= 9); p_21 += 1)
                    { /* block id: 1038 */
                        const int32_t l_2293 = 0xC3930881L;
                        uint32_t *l_2295 = &g_268;
                        uint8_t *l_2296 = &g_972.f1;
                        uint8_t *l_2297[3];
                        const uint16_t ***l_2304[1][10][1];
                        uint64_t *l_2305 = &g_690;
                        int32_t ****l_2310 = &l_2284;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_2297[i] = &g_526[8][5];
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 10; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_2304[i][j][k] = &g_2302;
                            }
                        }
                        l_2299 = (((l_2287[3][1][0] , (**g_739)) , (l_2298 |= (((p_22 >= ((*g_831) |= 1L)) & ((*l_2295) = (safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((((g_2292 = &g_1286) != (void*)0) != ((g_108 &= (l_2293 && p_21)) >= p_22)), l_2294)), g_144[1])))) , l_2287[3][1][0]))) > p_21);
                        (*g_831) &= ((g_1188 , ((safe_sub_func_int64_t_s_s(((g_2302 = g_2302) == (void*)0), ((*l_2305) ^= l_2028))) & (safe_add_func_int8_t_s_s(((((*l_2295) = ((l_2308 , (l_2308 , ((((*l_2310) = l_2309) == &l_2281[0][0][1]) >= ((safe_unary_minus_func_uint32_t_u((safe_sub_func_int8_t_s_s(((**g_1693) != 0UL), (*p_24))))) == l_2316)))) , 0x2E1091BEL)) <= 0UL) == g_2317), 1L)))) || 0xA3DAC2BD945A3BAFLL);
                        if (g_1004)
                            goto lbl_2318;
                    }
                    l_2324[0][0][3]--;
                    (*g_334) = &l_2299;
                    g_2336++;
                }
                if ((safe_add_func_int64_t_s_s(((--(*l_2341)) ^ (1L >= (0xCCL || (&g_1882[6][2] != ((*l_2347) = l_2346))))), ((l_2308 , func_29(&l_2154[2][0][3], ((*l_2282) = ((safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s((((*l_2364) ^= (p_22 &= (safe_rshift_func_uint8_t_u_u((((safe_mul_func_int8_t_s_s(l_2287[3][1][0], (safe_add_func_uint32_t_u_u((safe_div_func_int32_t_s_s(l_2028, (safe_sub_func_uint8_t_u_u(((((l_2362 , l_2363) != (void*)0) , (void*)0) != &p_21), (*p_24))))), p_21)))) , l_2327) > l_2154[2][0][3]), l_2018)))) || (*g_157)), g_218.f0)), g_638[4])) , 0L)), &g_227[6], l_2308.f0)) == (void*)0))))
                { /* block id: 1061 */
                    int64_t *l_2383 = &g_863[1][2];
                    int32_t l_2394 = (-1L);
                    (*g_2396) = ((*g_831) ^= (safe_unary_minus_func_int64_t_s(((((safe_add_func_uint32_t_u_u((0xDF8DL | (safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s((safe_mod_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_u(((safe_add_func_int32_t_s_s(((p_22 > ((((*l_2383) = (safe_lshift_func_uint8_t_u_s(((l_2382[1] = &l_2331) != &l_2299), 7))) || ((void*)0 == g_2384)) ^ (((4UL ^ (safe_mod_func_uint8_t_u_u((l_2299 &= ((+p_22) && ((*l_2341) &= (safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_s((l_2393[0][2][0] == (void*)0), 2)), p_21))))), p_22))) >= (-8L)) <= (**g_1693)))) > l_2394), 0UL)) , 6UL), 15)) <= p_21) != p_22), 0xA585L)), 0x99L)), p_21))), g_481)) , &g_1887[1]) != &g_334) <= (*p_23)))));
                    (*g_334) = &l_2018;
                }
                else
                { /* block id: 1069 */
                    (*g_831) = (*g_2396);
                    for (l_2308.f0 = (-5); (l_2308.f0 == (-26)); l_2308.f0--)
                    { /* block id: 1073 */
                        union U0 l_2399 = {0xAAC9400BL};
                        return l_2399;
                    }
                }
                (*g_334) = &l_2335;
                if (l_2027[0])
                    break;
            }
        }
    }
    if ((l_2019 , ((*g_831) ^= (((~(safe_lshift_func_int16_t_s_s(p_22, 3))) > (l_2028 && l_2028)) == (-1L)))))
    { /* block id: 1085 */
        return (*l_2092);
    }
    else
    { /* block id: 1087 */
        for (g_300 = 0; (g_300 <= 0); g_300 += 1)
        { /* block id: 1090 */
            return l_2404;
        }
    }
    return (*l_2092);
}


/* ------------------------------------------ */
/* 
 * reads : g_1676 g_1677 g_36 g_1873 g_1477 g_277.f0 g_334 g_335 g_177 g_37 g_831 g_546 g_274.f1 g_135 g_300 g_894 g_895 g_1694 g_539 g_540 g_541 g_1018 g_274.f0 g_1996 g_1108
 * writes: g_1108 g_362.f1 g_1882 g_218.f1 g_177 g_335 g_546 g_274.f1 g_135 g_300 g_144 g_274.f0 g_37
 */
static int8_t * func_25(int8_t * p_26, int64_t  p_27, int8_t * p_28)
{ /* block id: 801 */
    int32_t *l_1866 = &g_277.f0;
    int32_t *l_1867[2][10][6] = {{{&g_1377.f1,&g_1377.f1,&g_218.f1,(void*)0,&g_218.f1,&g_110},{&g_218.f1,(void*)0,&g_177,&g_1289[0][0][2].f1,&g_177,&g_218.f1},{(void*)0,&g_218.f1,&g_177,&g_177,&g_1377.f1,&g_110},{&g_635,&g_177,&g_218.f1,(void*)0,&g_177,&g_635},{(void*)0,&g_177,&g_635,&g_635,&g_1377.f1,&g_177},{&g_177,&g_218.f1,&g_635,&g_218.f1,&g_177,&g_277.f0},{&g_177,(void*)0,&g_635,&g_635,&g_218.f1,&g_177},{(void*)0,&g_1377.f1,(void*)0,(void*)0,(void*)0,&g_177},{&g_635,&g_218.f1,&g_635,&g_177,&g_635,&g_277.f0},{(void*)0,&g_277.f0,&g_635,&g_1289[0][0][2].f1,&g_635,&g_177}},{{&g_218.f1,&g_218.f1,&g_635,(void*)0,(void*)0,&g_635},{&g_1377.f1,&g_1377.f1,&g_218.f1,(void*)0,&g_218.f1,&g_110},{&g_218.f1,(void*)0,&g_177,&g_1289[0][0][2].f1,&g_177,&g_218.f1},{(void*)0,&g_218.f1,&g_177,&g_177,&g_1377.f1,&g_110},{&g_635,&g_177,&g_218.f1,(void*)0,&g_177,&g_635},{(void*)0,&g_177,&g_635,&g_635,&g_1377.f1,&g_177},{&g_177,&g_218.f1,&g_635,&g_218.f1,&g_177,&g_277.f0},{&g_177,(void*)0,&g_635,&g_635,&g_218.f1,&g_177},{(void*)0,&g_1377.f1,(void*)0,(void*)0,(void*)0,&g_177},{&g_635,&g_218.f1,&g_635,&g_177,&g_635,&g_277.f0}}};
    uint32_t l_1868 = 0x6558F963L;
    uint8_t **l_1879 = (void*)0;
    uint8_t *l_1881 = &g_631;
    uint8_t **l_1880[4] = {&l_1881,&l_1881,&l_1881,&l_1881};
    union U2 **l_1900 = &g_1266;
    int16_t l_1906 = 0xF263L;
    uint64_t ** const l_1925 = &g_1694;
    uint64_t ** const *l_1924[6][5] = {{(void*)0,&l_1925,&l_1925,(void*)0,&l_1925},{&l_1925,(void*)0,&l_1925,(void*)0,&l_1925},{&l_1925,&l_1925,&l_1925,&l_1925,&l_1925},{&l_1925,&l_1925,&l_1925,&l_1925,&l_1925},{(void*)0,&l_1925,&l_1925,&l_1925,&l_1925},{&l_1925,&l_1925,&l_1925,&l_1925,&l_1925}};
    uint16_t *** const l_1928 = &g_894;
    union U3 l_1950 = {0x1C4371B6L};
    uint64_t l_1973 = 0xDC34CD670DFA9CA7LL;
    int i, j, k;
lbl_1999:
    ++l_1868;
    for (g_1108 = 0; (g_1108 < 40); g_1108 = safe_add_func_int32_t_s_s(g_1108, 6))
    { /* block id: 805 */
        return (**g_1676);
    }
    if ((g_1873 , (((**g_334) = ((*g_831) = ((safe_mul_func_uint16_t_u_u((+((*g_1477) = (0xD1C0L == 0x30E0L))), (safe_mul_func_int8_t_s_s(((g_1882[5][1] = &g_407) == &g_526[8][5]), (safe_lshift_func_int16_t_s_s((*l_1866), (((*l_1866) == (safe_div_func_int32_t_s_s((**g_334), p_27))) >= (*p_28)))))))) <= 0L))) <= (*l_1866))))
    { /* block id: 812 */
        int32_t *l_1888 = &g_1289[0][0][2].f1;
        l_1888 = ((*g_334) = (*g_334));
    }
    else
    { /* block id: 815 */
        union U0 **l_1894 = (void*)0;
        int32_t l_1895 = (-1L);
        int32_t l_1896 = 0x9B7B78D4L;
        int32_t l_1909[7];
        uint64_t l_1948 = 0x0B4B1D137F012C03LL;
        uint32_t *l_1986 = (void*)0;
        uint64_t l_1992 = 18446744073709551615UL;
        int i;
        for (i = 0; i < 7; i++)
            l_1909[i] = 0x66B4C077L;
        for (g_546 = (-12); (g_546 >= (-28)); --g_546)
        { /* block id: 818 */
            int64_t l_1891 = 0xC620385F612F3AC0LL;
            union U0 **l_1892[8] = {&g_1286,&g_1286,&g_1286,&g_1286,&g_1286,&g_1286,&g_1286,&g_1286};
            int i;
            for (g_274.f1 = 0; (g_274.f1 <= 1); g_274.f1 += 1)
            { /* block id: 821 */
                union U0 ***l_1893 = &l_1892[3];
                int i;
                if (l_1891)
                    break;
                l_1894 = ((*l_1893) = l_1892[3]);
                (**g_334) |= p_27;
            }
        }
        for (g_135 = 4; (g_135 >= 0); g_135 -= 1)
        { /* block id: 830 */
            union U2 l_1899 = {5L};
            union U2 **l_1901 = (void*)0;
            int64_t l_1907 = 0x48E2481B9A328345LL;
            int32_t l_1908 = 0x8F0A583CL;
            int32_t l_1910 = 0L;
            int32_t l_1911 = 6L;
            int32_t l_1912 = 0L;
            int32_t l_1913 = (-1L);
            int32_t l_1915 = 0xF56019BEL;
            int32_t l_1916 = (-8L);
            int64_t l_1917[10] = {0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL,0x7A7A2618F716DC37LL};
            int32_t l_1918 = 0xA1B36700L;
            int32_t l_1919 = 0L;
            int32_t l_1920[8];
            uint16_t l_1921 = 0xC9CAL;
            uint64_t **l_1929 = &g_1694;
            uint8_t *l_1934[4] = {&g_1108,&g_1108,&g_1108,&g_1108};
            uint8_t l_1949 = 0xE4L;
            int32_t l_1967 = 0L;
            int i;
            for (i = 0; i < 8; i++)
                l_1920[i] = 0x6B4733AFL;
            l_1896 ^= l_1895;
            l_1907 = ((l_1895 ^= ((safe_mul_func_int16_t_s_s(((l_1899 , l_1900) == l_1901), 1L)) ^ (p_27 , (safe_sub_func_uint32_t_u_u(1UL, 0x035D7B9DL))))) >= ((safe_mul_func_uint64_t_u_u(l_1899.f0, (((*p_26) , 0xD4D2EB212E8FB2A4LL) != l_1896))) , l_1906));
            l_1921--;
        }
        for (g_300 = 0; (g_300 <= 1); g_300 += 1)
        { /* block id: 878 */
            uint16_t *l_1989 = &g_1004;
            uint8_t **l_1990 = &g_1882[8][0];
            int32_t l_1991 = 0L;
            int i;
            l_1895 &= ((((safe_mod_func_uint8_t_u_u(((safe_add_func_uint64_t_u_u(p_27, ((((((*g_335) = (safe_add_func_int32_t_s_s(l_1909[3], (((((l_1986 != ((l_1896 = ((g_144[g_300] = ((((safe_mul_func_uint8_t_u_u((p_27 < (-1L)), (((*g_894) != (l_1950 , l_1989)) >= ((&g_1882[5][0] != l_1990) | 0x05DAL)))) , p_27) == (*g_1694)) & l_1991)) , 0UL)) , (**g_539))) >= 0xD039L) && l_1991) , (-8L)) <= (*g_1694))))) < p_27) >= p_27) ^ 0x53E66449L) || (***g_1676)))) >= 0L), p_27)) , 0x1B84C9E1L) , p_27) && g_1018);
            for (g_274.f0 = 1; (g_274.f0 >= 0); g_274.f0 -= 1)
            { /* block id: 885 */
                uint16_t ***l_1995 = &g_894;
                (**g_334) &= (l_1992 != ((l_1928 != (((((*p_26) = (*p_28)) , p_27) >= (p_27 , 1L)) , l_1995)) != ((void*)0 != g_1996)));
                if (g_177)
                    goto lbl_1999;
            }
        }
    }
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_1676 g_1677 g_36
 * writes:
 */
static int8_t * func_29(int8_t * p_30, int32_t  p_31, const int8_t * p_32, int64_t  p_33)
{ /* block id: 268 */
    int32_t l_665 = 0xC6FD1A9BL;
    union U4 *l_669 = &g_670;
    union U4 **l_668 = &l_669;
    union U4 **l_671[8][5] = {{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669},{&l_669,&l_669,&l_669,&l_669,&l_669}};
    uint32_t *l_675 = &g_274.f1;
    int16_t *l_682[2][9] = {{&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1,&g_362.f1},{&g_310,&g_310,&g_310,&g_310,&g_310,&g_310,&g_310,&g_310,&g_310}};
    int32_t l_683 = 4L;
    uint64_t **l_686 = (void*)0;
    union U1 **l_692 = &g_365;
    union U1 **l_695[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int8_t l_696 = (-5L);
    union U2 *l_702[3];
    union U2 **l_701[7][5] = {{&l_702[0],&l_702[0],&l_702[1],&l_702[1],&l_702[0]},{&l_702[1],(void*)0,&l_702[1],(void*)0,&l_702[1]},{&l_702[0],&l_702[1],&l_702[1],&l_702[0],&l_702[0]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_702[0],&l_702[0],&l_702[1],&l_702[1],&l_702[0]},{&l_702[1],(void*)0,&l_702[1],(void*)0,&l_702[1]},{&l_702[0],&l_702[1],&l_702[1],&l_702[0],&l_702[0]}};
    uint64_t l_829[9][9][3] = {{{18446744073709551606UL,0x9AB54990EBC1AB0FLL,0x5E5B5D7633DC1092LL},{0UL,0xE96AE41583ADF3B2LL,0x4FFD1C30F7778091LL},{7UL,18446744073709551615UL,18446744073709551615UL},{0xD25D56BD3C5D3973LL,0x6028E11A24B6F6DBLL,0xF719DC74B39C07E4LL},{18446744073709551615UL,1UL,0xF719DC74B39C07E4LL},{18446744073709551615UL,0UL,18446744073709551615UL},{0x8C109421A97FD727LL,0x50F1D76D61658231LL,0x4FFD1C30F7778091LL},{9UL,0UL,0x5E5B5D7633DC1092LL},{1UL,1UL,0x27722FE5094E5304LL}},{{0xE96AE41583ADF3B2LL,0x6028E11A24B6F6DBLL,9UL},{9UL,0xD25D56BD3C5D3973LL,0x7D2F04039A908082LL},{0x062CA0BC87CD3A29LL,1UL,9UL},{9UL,0x9AB54990EBC1AB0FLL,0x27722FE5094E5304LL},{18446744073709551615UL,18446744073709551615UL,0x5E5B5D7633DC1092LL},{18446744073709551615UL,1UL,0x4FFD1C30F7778091LL},{1UL,0UL,18446744073709551615UL},{0UL,4UL,0xF719DC74B39C07E4LL},{0xD2C5FB5C0432916CLL,1UL,0xF719DC74B39C07E4LL}},{{9UL,9UL,18446744073709551615UL},{18446744073709551615UL,0xC448CAF0FADB3EBCLL,0x4FFD1C30F7778091LL},{0UL,0UL,0x5E5B5D7633DC1092LL},{0xE96AE41583ADF3B2LL,18446744073709551615UL,0x27722FE5094E5304LL},{0x8A436A24A1891639LL,0xD3FD2B59B06E1165LL,1UL},{1UL,0xE93C7A49CFBF70BDLL,18446744073709551615UL},{0xFB50FD74C4A21610LL,0x5C013047E8551256LL,1UL},{2UL,0xA600E4C763C09B02LL,1UL},{0xF80ED8384204DDF6LL,1UL,1UL}},{{0x504678F421C64C17LL,0x5C013047E8551256LL,0xD2C5FB5C0432916CLL},{1UL,0x504678F421C64C17LL,7UL},{0xE93C7A49CFBF70BDLL,0x0BCB88AB51282271LL,0xD8110F0023B5CBDALL},{0x73CF955E697B05B1LL,0xD3CABE348F3D5633LL,0xD8110F0023B5CBDALL},{2UL,0x392EBD0365E00720LL,7UL},{0x56835F34C6B3CF3CLL,18446744073709551615UL,0xD2C5FB5C0432916CLL},{0x392EBD0365E00720LL,0x2F68161D00633545LL,1UL},{0x5C013047E8551256LL,18446744073709551606UL,1UL},{0x0D17EA0A0F2D54EELL,0x0BCB88AB51282271LL,1UL}},{{0x392EBD0365E00720LL,0xE5E30173DEC68DE5LL,18446744073709551615UL},{0x51C4F420878D71C6LL,18446744073709551612UL,1UL},{18446744073709551609UL,1UL,1UL},{0x73CF955E697B05B1LL,18446744073709551607UL,1UL},{0xE5E30173DEC68DE5LL,18446744073709551612UL,0xD2C5FB5C0432916CLL},{0x0A3448A4D6C4803CLL,0xE93C7A49CFBF70BDLL,7UL},{0x504678F421C64C17LL,0UL,0xD8110F0023B5CBDALL},{0xE5FA8D0232C451D0LL,18446744073709551606UL,0xD8110F0023B5CBDALL},{18446744073709551609UL,1UL,7UL}},{{0xFB50FD74C4A21610LL,0x01EC5E1EECC18756LL,0xD2C5FB5C0432916CLL},{0x2F68161D00633545LL,0x392EBD0365E00720LL,1UL},{0x0D17EA0A0F2D54EELL,18446744073709551615UL,1UL},{18446744073709551612UL,0UL,1UL},{0x2F68161D00633545LL,0x504678F421C64C17LL,18446744073709551615UL},{0x56835F34C6B3CF3CLL,0x0D17EA0A0F2D54EELL,1UL},{18446744073709551612UL,18446744073709551607UL,1UL},{0xE5FA8D0232C451D0LL,0xA600E4C763C09B02LL,1UL},{0xE93C7A49CFBF70BDLL,0x0D17EA0A0F2D54EELL,0xD2C5FB5C0432916CLL}},{{0xBE2722EB1247E888LL,0xE5E30173DEC68DE5LL,7UL},{0xE5E30173DEC68DE5LL,0xD3FD2B59B06E1165LL,0xD8110F0023B5CBDALL},{0xF80ED8384204DDF6LL,18446744073709551615UL,0xD8110F0023B5CBDALL},{18446744073709551612UL,0x2F68161D00633545LL,7UL},{0x51C4F420878D71C6LL,0x19424C8E7D989B0DLL,0xD2C5FB5C0432916CLL},{1UL,1UL,1UL},{18446744073709551612UL,0xD3CABE348F3D5633LL,1UL},{0x5C013047E8551256LL,0xD3FD2B59B06E1165LL,1UL},{1UL,0xE93C7A49CFBF70BDLL,18446744073709551615UL}},{{0xFB50FD74C4A21610LL,0x5C013047E8551256LL,1UL},{2UL,0xA600E4C763C09B02LL,1UL},{0xF80ED8384204DDF6LL,1UL,1UL},{0x504678F421C64C17LL,0x5C013047E8551256LL,0xD2C5FB5C0432916CLL},{1UL,0x504678F421C64C17LL,7UL},{0xE93C7A49CFBF70BDLL,0x0BCB88AB51282271LL,0xD8110F0023B5CBDALL},{0x73CF955E697B05B1LL,0xD3CABE348F3D5633LL,0xD8110F0023B5CBDALL},{2UL,0x392EBD0365E00720LL,7UL},{0x56835F34C6B3CF3CLL,18446744073709551615UL,0xD2C5FB5C0432916CLL}},{{0x392EBD0365E00720LL,0x2F68161D00633545LL,1UL},{0x5C013047E8551256LL,18446744073709551606UL,1UL},{0x0D17EA0A0F2D54EELL,0x0BCB88AB51282271LL,1UL},{0x392EBD0365E00720LL,0xE5E30173DEC68DE5LL,18446744073709551615UL},{0x51C4F420878D71C6LL,18446744073709551612UL,1UL},{18446744073709551609UL,1UL,1UL},{0x73CF955E697B05B1LL,18446744073709551607UL,1UL},{0xE5E30173DEC68DE5LL,18446744073709551612UL,0xD2C5FB5C0432916CLL},{0x0A3448A4D6C4803CLL,0xE93C7A49CFBF70BDLL,7UL}}};
    union U1 ***l_901 = &l_695[3];
    union U1 ****l_900 = &l_901;
    uint32_t * const *l_912 = &g_541;
    int8_t l_923[8][3][8];
    int32_t l_964 = 0xB97EED57L;
    int32_t l_1002 = 0x3222BAB8L;
    int32_t l_1003 = 1L;
    int32_t l_1010 = 0xDA715D45L;
    int32_t l_1013 = 0x2D2E754DL;
    int32_t l_1014[4][5][6] = {{{0x6BFEFD46L,0x7844BE36L,(-2L),0xB497284AL,(-2L),0x7844BE36L},{(-2L),0x6BFEFD46L,0L,0x3BA42C78L,0x3BA42C78L,0L},{(-2L),(-2L),0x3BA42C78L,0L,0x7844BE36L,0L},{0xB497284AL,0x526D45EFL,0xB497284AL,0x3BA42C78L,(-2L),(-2L)},{0x6BFEFD46L,0xB497284AL,0xB497284AL,0x6BFEFD46L,0x526D45EFL,0L}},{{0L,0x6BFEFD46L,(-2L),0x6BFEFD46L,0L,0x3BA42C78L},{0x6BFEFD46L,0L,0x3BA42C78L,0x3BA42C78L,0L,0x6BFEFD46L},{0xB497284AL,0x6BFEFD46L,0x526D45EFL,0L,0x526D45EFL,0x6BFEFD46L},{0x526D45EFL,0xB497284AL,0x3BA42C78L,(-2L),(-2L),0x3BA42C78L},{0x526D45EFL,0x526D45EFL,(-2L),0L,0x7844BE36L,0L}},{{0xB497284AL,0x526D45EFL,0xB497284AL,0x3BA42C78L,(-2L),(-2L)},{0x6BFEFD46L,0xB497284AL,0xB497284AL,0x6BFEFD46L,0x526D45EFL,0L},{0L,0x6BFEFD46L,(-2L),0x6BFEFD46L,0L,0x3BA42C78L},{0x6BFEFD46L,0L,0x3BA42C78L,0x3BA42C78L,0L,0x6BFEFD46L},{0xB497284AL,0x6BFEFD46L,0x526D45EFL,0L,0x526D45EFL,0x6BFEFD46L}},{{0x526D45EFL,0xB497284AL,0x3BA42C78L,(-2L),(-2L),0x3BA42C78L},{0x526D45EFL,0x526D45EFL,(-2L),0L,0x7844BE36L,0L},{0xB497284AL,0x526D45EFL,0xB497284AL,0x3BA42C78L,(-2L),(-2L)},{0x6BFEFD46L,0xB497284AL,0xB497284AL,0x6BFEFD46L,0x526D45EFL,0L},{0L,0x6BFEFD46L,(-2L),0x6BFEFD46L,0L,0x3BA42C78L}}};
    int32_t l_1133[9] = {0xE344CDA0L,0xE344CDA0L,(-7L),0xE344CDA0L,0xE344CDA0L,(-7L),0xE344CDA0L,0xE344CDA0L,(-7L)};
    uint32_t l_1229 = 0x3BE1051DL;
    union U0 *l_1288 = &g_1289[0][0][2];
    int64_t l_1340 = 0x321A21E6CE3BE01FLL;
    uint16_t ** const l_1359[8] = {&g_895,(void*)0,&g_895,(void*)0,&g_895,(void*)0,&g_895,(void*)0};
    uint32_t l_1416 = 0UL;
    const int64_t l_1455 = (-5L);
    uint64_t l_1478 = 3UL;
    union U2 *l_1500[9][9] = {{&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274},{(void*)0,(void*)0,&g_274,&g_274,(void*)0,(void*)0,&g_274,&g_274,&g_274},{&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274},{(void*)0,&g_274,&g_274,&g_274,(void*)0,&g_274,&g_274,(void*)0,(void*)0},{&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274},{(void*)0,(void*)0,&g_274,&g_274,&g_274,(void*)0,&g_274,&g_274,(void*)0},{&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274},{(void*)0,&g_274,&g_274,&g_274,(void*)0,&g_274,&g_274,(void*)0,&g_274},{&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274,&g_274}};
    int32_t l_1605[10] = {0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L,0x5A6D5A80L};
    union U0 **l_1790 = &g_1286;
    union U2 *l_1848 = &g_274;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_702[i] = &g_274;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
                l_923[i][j][k] = 0L;
        }
    }
    return (**g_1676);
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_34 g_77 g_108 g_110 g_135 g_36 g_156 g_181 g_144 g_178 g_218 g_218.f1 g_268 g_227 g_277 g_177 g_218.f0 g_230 g_274.f0 g_388 g_300 g_404 g_335 g_334 g_526 g_539 g_330 g_277.f0 g_310 g_546 g_631 g_640 g_638 g_481 g_474
 * writes: g_108 g_37 g_110 g_135 g_144 g_156 g_181 g_178 g_177 g_230 g_218.f1 g_268 g_300 g_407 g_335 g_503 g_526 g_539 g_481 g_310 g_546 g_631 g_640
 */
static uint16_t  func_43(int32_t  p_44)
{ /* block id: 2 */
    uint16_t l_48[10][7] = {{0x4E54L,65535UL,0x23FAL,1UL,1UL,0x23FAL,65535UL},{0x1729L,0xDFEEL,65528UL,0x4E54L,1UL,0UL,1UL},{65531UL,0xBAE0L,0xDFEEL,0x5E3AL,1UL,0xDEB9L,65528UL},{0x9C1CL,0UL,0x4E54L,0x4E54L,0UL,0x9C1CL,65531UL},{0xDFEEL,65528UL,0x4E54L,1UL,0UL,1UL,0UL},{1UL,1UL,0xDFEEL,0x9C1CL,0xB834L,0UL,0xB834L},{0UL,65528UL,65528UL,0UL,0xBAE0L,1UL,0xDEB9L},{0UL,0UL,0x23FAL,1UL,0x1729L,0x5E3AL,0x4E54L},{1UL,0xBAE0L,0xDEB9L,65531UL,0xDFEEL,65531UL,0xDEB9L},{0xDFEEL,0xDFEEL,65535UL,0x5924L,0x5E3AL,65531UL,0xB834L}};
    uint16_t *l_49[4];
    int32_t l_50[2];
    const uint16_t *l_76 = &g_77;
    const uint16_t **l_75 = &l_76;
    const uint32_t l_86 = 0UL;
    int64_t l_276[1][7] = {{0x68E0BF437BD5445ELL,1L,1L,0x68E0BF437BD5445ELL,1L,1L,0x68E0BF437BD5445ELL}};
    union U3 l_282[5][2] = {{{0L},{0x695C9EB6L}},{{0L},{0x695C9EB6L}},{{0L},{0x695C9EB6L}},{{0L},{0x695C9EB6L}},{{0L},{0x695C9EB6L}}};
    int8_t * const l_343 = &g_178;
    union U2 l_344 = {0xC6L};
    uint16_t l_358 = 0x67B0L;
    union U1 *l_361 = &g_362;
    union U0 l_390 = {4294967288UL};
    union U2 *l_500[2][2][4] = {{{&g_274,&l_344,&g_274,&l_344},{&g_274,&l_344,&g_274,&l_344}},{{&g_274,&l_344,&g_274,&l_344},{&g_274,&l_344,&g_274,&l_344}}};
    union U2 **l_499 = &l_500[0][0][3];
    int64_t l_511 = 0xB147AE82105391D0LL;
    int16_t l_536 = 0x6207L;
    const uint8_t l_561 = 0x4CL;
    int32_t *l_626 = (void*)0;
    union U3 **l_659 = (void*)0;
    union U3 *l_661 = &g_277;
    union U3 **l_660 = &l_661;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_49[i] = (void*)0;
    for (i = 0; i < 2; i++)
        l_50[i] = 0x7A832397L;
    if ((+(safe_rshift_func_uint16_t_u_s((l_50[1] = l_48[4][2]), (safe_mod_func_int32_t_s_s(func_53(p_44, (func_58(&g_37, (((safe_lshift_func_int8_t_s_u((!((safe_sub_func_uint64_t_u_u(p_44, (safe_mul_func_int16_t_s_s((((((safe_sub_func_int32_t_s_s((safe_add_func_int32_t_s_s((((*l_75) = &l_48[4][2]) != ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(0UL, ((&g_77 == &g_77) && 0UL))), 9)), p_44)), g_37)) , &g_34)), p_44)), l_48[4][2])) && g_37) ^ p_44) ^ 65535UL) > l_86), p_44)))) <= l_48[4][2])), g_34)) | 0L) | (-1L)), g_34, &g_34, &g_34) , &l_48[0][0]), g_77, g_36), p_44))))))
    { /* block id: 93 */
        int8_t l_285 = 0xDFL;
        union U2 l_286 = {9L};
        uint64_t *l_316 = &g_300;
        union U2 l_319[4][2][1] = {{{{-1L}},{{-4L}}},{{{-1L}},{{-4L}}},{{{-1L}},{{-4L}}},{{{-1L}},{{-4L}}}};
        int32_t l_336 = (-9L);
        int8_t l_406 = 0x5BL;
        int16_t l_470 = 0x14EBL;
        int32_t l_478 = 1L;
        int32_t l_522 = 0L;
        union U0 l_533 = {4294967295UL};
        uint32_t l_547 = 0x91AFECF8L;
        union U1 **l_553 = &l_361;
        union U1 ***l_552[4][2][9] = {{{&l_553,&l_553,(void*)0,(void*)0,&l_553,&l_553,&l_553,&l_553,(void*)0},{&l_553,&l_553,(void*)0,&l_553,&l_553,&l_553,&l_553,&l_553,(void*)0}},{{&l_553,&l_553,(void*)0,&l_553,&l_553,&l_553,&l_553,(void*)0,(void*)0},{&l_553,&l_553,(void*)0,(void*)0,&l_553,&l_553,&l_553,&l_553,(void*)0}},{{&l_553,&l_553,(void*)0,&l_553,&l_553,&l_553,&l_553,&l_553,(void*)0},{&l_553,&l_553,(void*)0,&l_553,&l_553,&l_553,&l_553,(void*)0,(void*)0}},{{&l_553,&l_553,(void*)0,&l_553,(void*)0,&l_553,&l_553,&l_553,&l_553},{&l_553,&l_553,&l_553,&l_553,&l_553,&l_553,&l_553,&l_553,&l_553}}};
        int16_t l_566 = 0xC1D4L;
        union U1 l_584[9][8] = {{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}},{{0},{0},{0},{0},{0},{0},{0},{0}}};
        int64_t l_627[6] = {5L,5L,5L,5L,5L,5L};
        int i, j, k;
        if (l_276[0][1])
        { /* block id: 94 */
            int32_t l_297 = (-1L);
            uint64_t *l_298 = (void*)0;
            uint64_t *l_299 = &g_300;
            int32_t *l_301 = &l_282[4][0].f0;
            int32_t *l_302 = &g_218.f1;
            union U1 *l_363 = &g_362;
            const union U2 *l_392[3][10][8] = {{{&l_319[3][1][0],&l_344,&g_274,&l_344,&l_286,&l_286,&l_344,&g_274},{&g_274,&g_274,&l_319[0][1][0],&l_344,&l_344,&l_319[3][0][0],&l_286,&l_286},{&l_319[0][1][0],(void*)0,&l_319[3][0][0],&l_344,&l_319[0][1][0],&l_319[3][1][0],(void*)0,&l_286},{(void*)0,(void*)0,&l_344,&l_344,&l_319[3][1][0],(void*)0,&l_319[3][0][0],&g_274},{&l_319[0][0][0],&g_274,&l_286,&l_344,&l_286,&g_274,&l_319[0][0][0],&l_319[0][1][0]},{&l_344,&l_286,(void*)0,&l_286,(void*)0,&l_319[3][1][0],&l_319[3][1][0],&l_319[3][0][0]},{&l_344,(void*)0,(void*)0,(void*)0,(void*)0,&g_274,&l_319[3][1][0],&l_344},{&l_344,&l_319[3][1][0],(void*)0,&l_319[3][0][0],&l_286,&l_286,&l_286,&l_286},{&l_319[0][0][0],(void*)0,(void*)0,&l_319[0][0][0],&l_319[3][1][0],&l_319[3][1][0],&l_286,(void*)0},{(void*)0,&l_286,&l_319[0][0][0],&l_319[3][1][0],&l_319[0][1][0],&l_319[0][1][0],&l_286,(void*)0}},{{&l_319[0][1][0],&l_286,&l_344,&l_319[3][1][0],&l_344,&l_319[3][1][0],&g_274,(void*)0},{&g_274,(void*)0,&l_319[0][1][0],&l_286,&l_286,&l_286,&l_319[0][1][0],(void*)0},{&l_319[3][1][0],&l_319[3][1][0],&g_274,&l_319[3][1][0],&l_344,&l_319[3][1][0],&l_344,&l_286},{&l_344,&l_344,(void*)0,(void*)0,&l_344,&l_286,&l_344,&l_319[0][0][0]},{(void*)0,(void*)0,&g_274,&l_319[3][1][0],&l_344,&l_319[0][1][0],&l_344,&l_344},{&l_344,&l_319[0][1][0],&l_344,&l_344,&l_319[0][1][0],&l_344,&l_319[3][1][0],&g_274},{&l_286,&l_286,&l_319[0][0][0],&l_344,&l_286,&l_344,(void*)0,(void*)0},{&g_274,&l_319[0][1][0],&l_286,&l_344,&l_319[3][1][0],&l_344,&l_319[3][1][0],&g_274},{&l_286,&l_319[3][1][0],&l_286,&l_344,&l_344,&l_319[3][1][0],&l_344,&l_344},{&l_286,&l_319[0][1][0],&l_286,&l_319[3][1][0],(void*)0,&l_319[3][1][0],&l_286,&l_319[0][0][0]}},{{&l_344,&g_274,&l_319[3][1][0],(void*)0,(void*)0,&l_344,(void*)0,&l_286},{&l_344,&l_344,&l_344,&l_319[3][1][0],(void*)0,&l_319[3][0][0],&l_286,&l_286},{&l_286,&l_344,&l_286,&l_344,&l_344,&l_286,&l_344,&l_286},{&l_286,&l_344,(void*)0,&l_286,&l_319[3][1][0],&l_319[0][1][0],&l_286,&l_319[3][1][0]},{&g_274,&g_274,&l_344,(void*)0,&l_286,&l_319[0][1][0],(void*)0,&l_344},{&l_286,&l_344,(void*)0,&l_286,&l_319[0][1][0],&l_286,(void*)0,&l_286},{&l_344,&l_344,&l_319[0][1][0],&l_344,&l_344,&l_319[3][0][0],&l_344,(void*)0},{(void*)0,&l_344,&l_319[3][1][0],&l_286,&l_344,&l_344,&l_319[0][0][0],&l_344},{&l_344,&g_274,&l_319[3][1][0],(void*)0,&l_344,&l_319[3][1][0],&l_344,(void*)0},{&l_344,&l_319[0][1][0],&l_319[0][1][0],(void*)0,&l_319[3][1][0],&l_319[3][1][0],(void*)0,&l_319[0][1][0]}}};
            const union U2 **l_391[5][7] = {{&l_392[2][3][1],&l_392[0][9][7],&l_392[0][0][3],&l_392[0][0][3],&l_392[0][9][7],&l_392[2][3][1],&l_392[2][3][1]},{&l_392[2][3][4],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][4],&l_392[2][2][0]},{&l_392[2][3][1],&l_392[0][9][7],&l_392[0][0][3],&l_392[0][0][3],&l_392[0][9][7],&l_392[2][3][1],&l_392[2][3][1]},{&l_392[2][3][4],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][1],&l_392[2][3][4],&l_392[2][2][0]},{&l_392[2][3][1],&l_392[0][9][7],&l_392[0][0][3],&l_392[0][0][3],&l_392[0][9][7],&l_392[2][3][1],&l_392[2][3][1]}};
            uint16_t ** const l_409 = &l_49[3];
            uint16_t ** const *l_408 = &l_409;
            int32_t l_436 = 0x8C609737L;
            uint32_t *l_488 = &g_181;
            uint32_t **l_487 = &l_488;
            uint32_t ***l_486 = &l_487;
            union U2 *l_497 = &l_286;
            union U2 **l_496[6] = {&l_497,&l_497,&l_497,&l_497,&l_497,&l_497};
            int32_t l_523[9][9][3] = {{{1L,0L,0xF701D9EAL},{0x55992B28L,0xB61277F7L,0L},{0xF701D9EAL,1L,5L},{2L,0xF471A302L,0x199373E1L},{0x5BD86FE0L,0x42941F78L,(-1L)},{1L,0xF8ABC9B1L,0xD0591874L},{(-2L),0x42941F78L,(-2L)},{0xDF23C8F3L,0xF471A302L,0x150C4598L},{2L,1L,(-2L)}},{{0x150C4598L,0x526B31F9L,0xD0591874L},{0x0235CB6FL,1L,(-1L)},{0x150C4598L,0L,0x199373E1L},{2L,1L,5L},{0xDF23C8F3L,0L,0xDF23C8F3L},{(-2L),1L,0x5BD86FE0L},{1L,0x526B31F9L,0xDF23C8F3L},{0x5BD86FE0L,1L,5L},{2L,0xF471A302L,0x199373E1L}},{{0x5BD86FE0L,0x42941F78L,(-1L)},{1L,0xF8ABC9B1L,0xD0591874L},{(-2L),0x42941F78L,(-2L)},{0xDF23C8F3L,0xF471A302L,0x150C4598L},{2L,1L,(-2L)},{0x150C4598L,0x526B31F9L,0xD0591874L},{0x0235CB6FL,1L,(-1L)},{0x150C4598L,0L,0x199373E1L},{2L,1L,5L}},{{0xDF23C8F3L,0L,0xDF23C8F3L},{(-2L),1L,0x5BD86FE0L},{1L,0x526B31F9L,0xDF23C8F3L},{0x5BD86FE0L,1L,5L},{2L,0xF471A302L,0x199373E1L},{0x5BD86FE0L,0x42941F78L,(-1L)},{1L,0xF8ABC9B1L,0xD0591874L},{(-2L),0x42941F78L,(-2L)},{0xDF23C8F3L,0xF471A302L,0x150C4598L}},{{2L,1L,(-2L)},{0x150C4598L,0x526B31F9L,0xD0591874L},{0x0235CB6FL,1L,(-1L)},{0x150C4598L,0L,0x199373E1L},{2L,1L,5L},{0xDF23C8F3L,0L,0xDF23C8F3L},{(-2L),1L,0x5BD86FE0L},{1L,0x526B31F9L,0xDF23C8F3L},{0x5BD86FE0L,1L,5L}},{{2L,0xF471A302L,0x199373E1L},{0x5BD86FE0L,0x42941F78L,(-1L)},{1L,0xF8ABC9B1L,0xD0591874L},{(-2L),0x42941F78L,(-2L)},{0xDF23C8F3L,0xF471A302L,0x150C4598L},{2L,1L,(-2L)},{0x150C4598L,0x526B31F9L,0xD0591874L},{0x0235CB6FL,1L,(-1L)},{0x150C4598L,0L,0x199373E1L}},{{2L,1L,5L},{0xDF23C8F3L,0L,0xDF23C8F3L},{(-2L),1L,0x5BD86FE0L},{1L,0x526B31F9L,0xDF23C8F3L},{0x5BD86FE0L,1L,5L},{2L,0xF471A302L,0x199373E1L},{0x5BD86FE0L,0x42941F78L,(-1L)},{1L,0xF8ABC9B1L,0xD0591874L},{(-2L),0x42941F78L,(-2L)}},{{0xDF23C8F3L,0xF471A302L,0x150C4598L},{2L,1L,(-2L)},{0x150C4598L,0x526B31F9L,0xD0591874L},{0x8D19CA9CL,(-2L),0xCDCEC3EDL},{0x6589F550L,0L,1L},{(-1L),5L,1L},{3L,0L,3L},{0xF4E7C8D3L,(-2L),0L},{0xB8690C51L,0x3AB32B63L,3L}},{{0L,0x0235CB6FL,1L},{0x5B21C627L,0xF659D80FL,1L},{0L,0x5A8706C0L,0xCDCEC3EDL},{0xB8690C51L,0xBD2F8E4DL,0x0B32F969L},{0xF4E7C8D3L,0x5A8706C0L,0xF4E7C8D3L},{3L,0xF659D80FL,0x6589F550L},{(-1L),0x0235CB6FL,0xF4E7C8D3L},{0x6589F550L,0x3AB32B63L,0x0B32F969L},{0x8D19CA9CL,(-2L),0xCDCEC3EDL}}};
            int i, j, k;
lbl_370:
            (*l_302) = (((0x0B8AL <= (((g_178 && (g_277 , ((*l_301) = (((((((((safe_mul_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((l_282[4][0] , ((safe_mul_func_int16_t_s_s((l_285 | (l_286 , ((*l_299) = (g_177 , (safe_rshift_func_int16_t_s_s((safe_mod_func_uint32_t_u_u(((safe_mod_func_uint64_t_u_u((0UL | (safe_lshift_func_int16_t_s_s(((((safe_lshift_func_uint8_t_u_s(((g_218.f0 , p_44) , l_286.f0), (*g_36))) & 0xE46226D1L) , 65527UL) ^ 2L), 7))), p_44)) <= l_297), 4294967295UL)), g_144[1])))))), l_297)) , l_286.f0)), g_230)), l_297)) & 0x44126BB138D89CA3LL) <= g_274.f0) < l_86) <= 1L) != l_297) > l_297) != p_44) ^ p_44)))) == g_144[0]) & p_44)) <= p_44) > g_230);
            if (((*l_301) = p_44))
            { /* block id: 99 */
                int32_t **l_333 = &l_301;
                union U4 *l_438 = (void*)0;
                union U3 l_465 = {-3L};
                uint64_t *l_476[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_476[i] = &g_300;
                for (l_297 = 5; (l_297 == (-22)); l_297 = safe_sub_func_uint32_t_u_u(l_297, 8))
                { /* block id: 102 */
                    int16_t l_309 = 0xE25FL;
                    uint32_t *l_312 = &g_181;
                    uint32_t **l_311 = &l_312;
                    uint64_t **l_315 = &l_299;
                    uint8_t *l_320 = &g_144[1];
                    int32_t l_321 = (-6L);
                    int32_t l_347 = 0x00678068L;
                    int32_t l_359 = 0L;
                    int16_t *l_360 = &g_310;
                }
                for (g_181 = 2; (g_181 > 10); g_181 = safe_add_func_int16_t_s_s(g_181, 3))
                { /* block id: 138 */
                    const union U2 ***l_393 = &l_391[4][4];
                    int32_t **l_405 = (void*)0;
                    for (l_285 = 0; (l_285 != (-27)); --l_285)
                    { /* block id: 141 */
                        union U2 *l_372 = &l_286;
                        union U2 **l_371 = &l_372;
                        union U2 **l_373 = (void*)0;
                        union U2 *l_375[8][4] = {{&l_286,(void*)0,&l_319[3][1][0],&l_319[2][1][0]},{&g_274,&l_344,&l_319[3][1][0],&l_319[3][1][0]},{&g_274,&l_319[3][1][0],&l_319[3][1][0],&g_274},{&l_286,&l_319[3][1][0],&l_319[2][1][0],&l_319[3][1][0]},{&l_319[3][1][0],&l_344,&l_286,&l_319[2][1][0]},{(void*)0,&l_286,&l_319[3][1][0],&l_319[2][1][0]},{&g_274,&l_344,&g_274,&l_319[3][1][0]},{&g_274,&l_319[3][1][0],&g_274,&g_274}};
                        union U2 **l_374 = &l_375[5][2];
                        int i, j;
                        if (g_218.f0)
                            goto lbl_370;
                        (**l_333) |= (((*l_371) = &g_274) != ((*l_374) = &g_274));
                    }
                    (*l_302) ^= (((((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s(248UL, 1)), ((**l_333) ^= (g_407 = (~(l_406 = ((safe_mul_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((+0x4AL), (safe_mod_func_int32_t_s_s((g_388 == ((*l_393) = ((l_390 , 0x84332C901CCD87E3LL) , l_391[4][4]))), (safe_lshift_func_uint8_t_u_u((((((g_300 && (safe_div_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((safe_add_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_s(g_404, 4)) == ((void*)0 != l_405)), p_44)), p_44)), 0x2CL))) , 0L) <= g_227[8]) > 0xF4C1L) , g_110), 0)))))), l_276[0][0])) | 0x79681BECC66A6F61LL))))))) ^ p_44) < p_44) , 0x699217A7L) && (*g_335));
                    for (g_135 = 0; (g_135 <= 6); g_135 += 1)
                    { /* block id: 154 */
                        int i, j;
                        (*l_302) ^= l_48[(g_135 + 2)][g_135];
                        (*l_302) &= l_48[(g_135 + 2)][g_135];
                        (*g_335) ^= ((*l_302) = ((l_408 != &l_75) < (((0x7906L && l_282[4][0].f0) || p_44) & 0xDA33L)));
                    }
                    if ((*g_335))
                        break;
                }
                for (g_108 = 17; (g_108 > 39); g_108++)
                { /* block id: 164 */
                    union U1 l_434 = {0};
                    int32_t l_437 = 0x480214DEL;
                    int32_t l_479 = 0x3C633B4AL;
                    int32_t l_480[6] = {0x6D8ECD15L,0xEE898A72L,0xEE898A72L,0x6D8ECD15L,0xEE898A72L,0xEE898A72L};
                    int32_t *l_494 = (void*)0;
                    int32_t *l_495 = &l_478;
                    union U2 ***l_498[5] = {&l_496[2],&l_496[2],&l_496[2],&l_496[2],&l_496[2]};
                    int i;
                }
                (*g_334) = ((p_44 & p_44) , (*g_334));
            }
            else
            { /* block id: 193 */
                const union U1 *l_502[9][7][4] = {{{(void*)0,(void*)0,&g_362,(void*)0},{(void*)0,&g_245,(void*)0,(void*)0},{&g_245,(void*)0,&g_245,&g_245},{(void*)0,(void*)0,&g_247,(void*)0},{(void*)0,&g_245,&g_245,(void*)0},{&g_362,(void*)0,(void*)0,&g_245},{(void*)0,(void*)0,&g_362,(void*)0}},{{(void*)0,&g_245,(void*)0,(void*)0},{&g_245,(void*)0,&g_245,&g_245},{(void*)0,(void*)0,&g_247,(void*)0},{(void*)0,&g_245,&g_245,(void*)0},{&g_362,(void*)0,(void*)0,&g_245},{(void*)0,(void*)0,&g_362,(void*)0},{(void*)0,&g_245,(void*)0,(void*)0}},{{&g_245,(void*)0,&g_245,&g_245},{(void*)0,(void*)0,&g_247,(void*)0},{(void*)0,&g_245,&g_245,(void*)0},{&g_362,(void*)0,(void*)0,&g_245},{(void*)0,(void*)0,&g_362,(void*)0},{(void*)0,&g_245,(void*)0,(void*)0},{&g_245,(void*)0,&g_245,&g_245}},{{(void*)0,(void*)0,&g_247,(void*)0},{(void*)0,&g_245,&g_245,(void*)0},{&g_362,(void*)0,(void*)0,&g_245},{(void*)0,(void*)0,&g_362,(void*)0},{(void*)0,&g_245,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245}},{{&g_245,&g_362,&g_362,&g_245},{&g_245,&g_245,&g_247,&g_245},{&g_245,&g_245,(void*)0,&g_245},{&g_362,&g_362,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245},{&g_245,&g_362,&g_362,&g_245}},{{&g_245,&g_245,&g_247,&g_245},{&g_245,&g_245,(void*)0,&g_245},{&g_362,&g_362,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245},{&g_245,&g_362,&g_362,&g_245},{&g_245,&g_245,&g_247,&g_245}},{{&g_245,&g_245,(void*)0,&g_245},{&g_362,&g_362,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245},{&g_245,&g_362,&g_362,&g_245},{&g_245,&g_245,&g_247,&g_245},{&g_245,&g_245,(void*)0,&g_245}},{{&g_362,&g_362,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245},{&g_245,&g_362,&g_362,&g_245},{&g_245,&g_245,&g_247,&g_245},{&g_245,&g_245,(void*)0,&g_245},{&g_362,&g_362,&g_247,&g_245}},{{&g_245,&g_245,&g_362,&g_245},{&g_362,&g_245,&g_362,&g_245},{&g_245,&g_362,&g_362,&g_245},{&g_245,&g_245,&g_247,&g_245},{&g_245,&g_245,(void*)0,&g_245},{&g_362,&g_362,&g_247,&g_245},{&g_245,&g_245,&g_362,&g_245}}};
                const union U1 **l_501[10] = {&l_502[8][0][1],&l_502[8][0][1],(void*)0,&l_502[8][0][1],&l_502[8][0][1],(void*)0,&l_502[8][0][1],&l_502[8][0][1],(void*)0,&l_502[8][0][1]};
                uint32_t *l_509[4] = {&g_230,&g_230,&g_230,&g_230};
                int64_t *l_510 = &l_276[0][1];
                int32_t l_520 = 0xD1403AEFL;
                int32_t l_521 = 0xF4AB8AB8L;
                int32_t l_524 = 6L;
                int32_t l_525 = 0x33753E39L;
                int i, j, k;
                g_503 = &g_247;
                (*l_302) = (((safe_lshift_func_uint8_t_u_u(p_44, p_44)) <= ((safe_lshift_func_int8_t_s_s(p_44, 4)) || ((~g_135) < l_406))) <= ((((((g_108 = p_44) , (-2L)) < ((*l_510) = (l_319[0][0][0] , (-1L)))) <= 255UL) <= (**g_334)) && l_511));
                for (g_108 = 0; (g_108 != 8); g_108++)
                { /* block id: 200 */
                    int32_t *l_514 = (void*)0;
                    int32_t *l_515 = &l_390.f1;
                    int32_t *l_516 = &l_436;
                    int32_t *l_517 = &l_282[4][0].f0;
                    int32_t *l_518 = (void*)0;
                    int32_t *l_519[8] = {&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0,&g_277.f0};
                    int i;
                    g_526[8][5]++;
                    return p_44;
                }
            }
            for (g_181 = 0; (g_181 <= 2); g_181 += 1)
            { /* block id: 207 */
                uint32_t ** const **l_542 = &g_539;
                int32_t l_543 = 4L;
                int32_t l_544 = 1L;
                int32_t *l_545[1][2][6] = {{{&l_336,(void*)0,(void*)0,&l_336,(void*)0,(void*)0},{&l_336,(void*)0,(void*)0,&l_336,(void*)0,(void*)0}}};
                int i, j, k;
                (*l_301) = ((*g_335) = ((safe_lshift_func_int16_t_s_s(p_44, ((l_543 &= (safe_rshift_func_uint16_t_u_s(((l_533 , ((*l_299) = (((*l_302) | ((*l_301) > (((safe_div_func_int16_t_s_s((l_536 < (l_50[0] = p_44)), (safe_div_func_int8_t_s_s(((((g_481 = (&l_487 != ((*l_542) = g_539))) > g_110) >= 2L) == (-3L)), 251UL)))) < p_44) <= p_44))) ^ p_44))) <= 18446744073709551615UL), g_330))) | 0xD5B6C910B192E7A0LL))) == l_544));
                ++l_547;
                return p_44;
            }
            (*l_301) ^= ((*l_302) , (safe_mul_func_uint8_t_u_u(p_44, p_44)));
        }
        else
        { /* block id: 219 */
            union U2 l_560 = {0x66L};
            uint32_t *l_567 = &g_230;
            uint32_t *l_570[4][9] = {{&g_268,(void*)0,&g_268,&l_547,&l_547,&g_268,(void*)0,&l_547,&g_268},{&g_108,(void*)0,(void*)0,&g_108,&l_547,&g_108,(void*)0,(void*)0,&g_108},{&l_547,&g_268,(void*)0,&g_268,&l_547,&l_547,&g_268,(void*)0,&g_268},{(void*)0,&l_547,&l_547,&l_547,&l_547,(void*)0,&l_547,&l_547,&l_547}};
            union U2 **l_581 = &l_500[0][1][0];
            int32_t l_588 = 0x48001EC9L;
            int32_t l_630 = 1L;
            int i, j;
            if (((**g_334) = ((l_552[2][1][3] == (void*)0) && (((safe_mul_func_uint16_t_u_u(l_286.f0, l_336)) <= l_533.f1) & (safe_rshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u((((l_560 , l_561) ^ (255UL & (safe_mul_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u((g_268 &= ((*l_567)--)), ((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u(((safe_mod_func_int32_t_s_s((((((safe_mod_func_uint8_t_u_u((((safe_mod_func_uint64_t_u_u((((void*)0 != l_581) != 0x2AC656B8B83E832DLL), g_277.f0)) & (-1L)) < 0L), l_286.f0)) > l_561) < p_44) != 0xE209F11EC0A0EC8BLL) != p_44), 0x421766DAL)) && l_358), 0UL)), l_560.f0)) & l_561))) != g_108), l_358)))) & p_44), p_44)), l_50[1]))))))
            { /* block id: 223 */
                return p_44;
            }
            else
            { /* block id: 225 */
                uint32_t l_597 = 0x6E0854C2L;
                int32_t l_629 = 0x76AF3242L;
                int64_t l_636 = 0L;
                int32_t l_637 = 0x9706261CL;
                int32_t l_639 = 0x94943814L;
                int8_t **l_655 = &g_36;
                for (l_344.f1 = 0; (l_344.f1 <= 0); l_344.f1 += 1)
                { /* block id: 228 */
                    int16_t *l_587 = &l_566;
                    int i;
                    (*g_335) = ((safe_div_func_uint16_t_u_u(((void*)0 == &g_365), (l_584[4][7] , ((*l_587) |= (safe_lshift_func_int8_t_s_u(0x60L, 4)))))) , l_50[(l_344.f1 + 1)]);
                    for (l_566 = 0; (l_566 >= 0); l_566 -= 1)
                    { /* block id: 233 */
                        int32_t *l_589 = &l_336;
                        int32_t *l_590 = (void*)0;
                        int32_t *l_591 = &g_218.f1;
                        int32_t *l_592 = &l_50[1];
                        int32_t *l_593 = &l_336;
                        int32_t l_594 = 0x78A14CACL;
                        int32_t *l_595 = &l_336;
                        int32_t *l_596[2][1];
                        union U2 *l_614 = &l_319[0][1][0];
                        int i, j;
                        for (i = 0; i < 2; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_596[i][j] = &g_218.f1;
                        }
                        l_597--;
                    }
                }
                for (g_310 = 1; (g_310 >= 0); g_310 -= 1)
                { /* block id: 241 */
                    int32_t l_628[10][5][5] = {{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0xF343B5F4L,0x4C242291L,0xDF1C3F2AL},{(-1L),0xF2616FFFL,0xDF1C3F2AL,0x0524EC3BL,0L},{(-8L),0xF2616FFFL,0x4AC6135AL,0xC1FD13DDL,0x4AC6135AL}},{{0xF2616FFFL,0xF2616FFFL,0x094D9E0DL,5L,0xF343B5F4L},{(-1L),0xF2616FFFL,0L,(-1L),0x094D9E0DL},{0x9E37ED42L,0xF2616FFFL,0x50E1917BL,0xB7B7BFCBL,0x2CF89BD3L},{0xF343B5F4L,0x094D9E0DL,0x2CF89BD3L,0x5B350D0EL,0x6E75292EL},{0L,0x094D9E0DL,0x1A3910B2L,(-2L),0x1A3910B2L}},{{0x094D9E0DL,0x094D9E0DL,0xB63A7AE3L,1L,0x50E1917BL},{0x4AC6135AL,0x094D9E0DL,0x6E75292EL,(-2L),0xB63A7AE3L},{0xDF1C3F2AL,0x094D9E0DL,0x50E1917BL,0xB7B7BFCBL,0x2CF89BD3L},{0xF343B5F4L,0x094D9E0DL,0x2CF89BD3L,0x5B350D0EL,0x6E75292EL},{0L,0x094D9E0DL,0x1A3910B2L,(-2L),0x1A3910B2L}},{{0x094D9E0DL,0x094D9E0DL,0xB63A7AE3L,1L,0x50E1917BL},{0x4AC6135AL,0x094D9E0DL,0x6E75292EL,(-2L),0xB63A7AE3L},{0xDF1C3F2AL,0x094D9E0DL,0x50E1917BL,0xB7B7BFCBL,0x2CF89BD3L},{0xF343B5F4L,0x094D9E0DL,0x2CF89BD3L,0x5B350D0EL,0x6E75292EL},{0L,0x094D9E0DL,0x1A3910B2L,(-2L),0x1A3910B2L}},{{0x094D9E0DL,0x094D9E0DL,0xB63A7AE3L,1L,0x50E1917BL},{0x4AC6135AL,0x094D9E0DL,0x6E75292EL,(-2L),0xB63A7AE3L},{0xDF1C3F2AL,0x094D9E0DL,0x50E1917BL,0xB7B7BFCBL,0x2CF89BD3L},{0xF343B5F4L,0x094D9E0DL,0x2CF89BD3L,0x5B350D0EL,0x6E75292EL},{0L,0x094D9E0DL,0x1A3910B2L,(-2L),0x1A3910B2L}}};
                    int i, j, k;
                    for (g_546 = 0; (g_546 <= 1); g_546 += 1)
                    { /* block id: 244 */
                        int32_t **l_623 = (void*)0;
                        int32_t *l_625 = &g_218.f1;
                        int32_t **l_624[8] = {&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625,&l_625};
                        int i;
                        l_50[g_546] ^= (((*g_334) = (*g_334)) != (l_626 = &g_177));
                        ++g_631;
                        if (l_50[g_546])
                            continue;
                    }
                    for (l_285 = 0; (l_285 >= 0); l_285 -= 1)
                    { /* block id: 253 */
                        int32_t *l_634[10] = {&l_629,(void*)0,(void*)0,&l_629,(void*)0,&l_629,(void*)0,(void*)0,&l_629,(void*)0};
                        int i;
                        g_640++;
                    }
                }
                (**g_334) = (0x85L & (safe_lshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(g_638[4], (l_629 = (safe_add_func_int32_t_s_s(((safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((((l_627[0] , (((void*)0 == l_655) & g_481)) < ((l_637 == (((((void*)0 != g_474) > g_181) , p_44) | 0x87E6ECF7L)) , 0L)) < p_44), 0)), 0x5D3AL)) == l_336), (*g_335)))))), l_406)), 0)));
                return l_637;
            }
        }
        return g_77;
    }
    else
    { /* block id: 263 */
        uint32_t l_656 = 0x809E43CDL;
        ++l_656;
    }
    (*l_660) = &l_282[4][0];
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_156 g_110 g_181 g_144 g_37 g_178 g_34 g_77 g_218 g_135 g_108 g_218.f1 g_268 g_227
 * writes: g_156 g_37 g_108 g_181 g_178 g_110 g_177 g_230 g_218.f1 g_268 g_135
 */
static int32_t  func_53(uint8_t  p_54, uint16_t * p_55, int16_t  p_56, int8_t * p_57)
{ /* block id: 32 */
    uint16_t * volatile **l_158[5] = {&g_156,&g_156,&g_156,&g_156,&g_156};
    int32_t *l_160 = &g_110;
    int32_t **l_159 = &l_160;
    int32_t l_176 = 0x48BAA0A5L;
    int32_t l_180 = 0x001A3C86L;
    const union U1 *l_244 = &g_245;
    uint8_t l_248[3];
    int32_t l_255 = 0x02E08C72L;
    union U2 *l_273[7][10][2] = {{{&g_274,&g_274},{&g_274,&g_274},{(void*)0,&g_274},{&g_274,(void*)0},{(void*)0,&g_274},{(void*)0,(void*)0},{&g_274,(void*)0},{&g_274,(void*)0},{&g_274,(void*)0},{&g_274,&g_274}},{{&g_274,&g_274},{(void*)0,(void*)0},{&g_274,&g_274},{(void*)0,&g_274},{(void*)0,&g_274},{(void*)0,&g_274},{&g_274,(void*)0},{(void*)0,&g_274},{&g_274,&g_274},{&g_274,(void*)0}},{{&g_274,(void*)0},{&g_274,(void*)0},{&g_274,(void*)0},{(void*)0,&g_274},{(void*)0,(void*)0},{&g_274,&g_274},{(void*)0,&g_274},{&g_274,&g_274},{&g_274,&g_274},{(void*)0,&g_274}},{{(void*)0,&g_274},{&g_274,&g_274},{&g_274,&g_274},{(void*)0,&g_274},{&g_274,(void*)0},{(void*)0,&g_274},{(void*)0,(void*)0},{&g_274,(void*)0},{&g_274,(void*)0},{&g_274,(void*)0}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_274},{&g_274,&g_274},{(void*)0,(void*)0},{&g_274,(void*)0},{(void*)0,&g_274},{&g_274,&g_274},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{&g_274,(void*)0},{&g_274,&g_274},{(void*)0,&g_274},{&g_274,&g_274},{&g_274,&g_274},{(void*)0,&g_274},{(void*)0,&g_274},{&g_274,&g_274},{(void*)0,&g_274}},{{(void*)0,&g_274},{(void*)0,&g_274},{(void*)0,&g_274},{&g_274,&g_274},{(void*)0,&g_274},{(void*)0,&g_274},{&g_274,&g_274},{&g_274,&g_274},{(void*)0,&g_274},{&g_274,(void*)0}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_248[i] = 0xE0L;
lbl_205:
    g_156 = g_156;
    (*l_159) = &g_110;
    for (g_37 = 0; (g_37 >= (-9)); --g_37)
    { /* block id: 37 */
        uint16_t *l_165 = (void*)0;
        uint16_t * const *l_164 = &l_165;
        uint16_t * const **l_163 = &l_164;
        uint32_t *l_166 = &g_108;
        int32_t l_175 = 0xCA8B6AEBL;
        union U2 l_222 = {0L};
        const union U1 *l_246 = &g_247;
        int16_t l_258[1][8][9] = {{{9L,0x8001L,9L,1L,0L,0xA62DL,(-1L),1L,0x17EAL},{0x8001L,8L,0xBF79L,0x17EAL,(-1L),0xCF02L,0x4E01L,0xCF02L,(-1L)},{1L,0x4E01L,0x4E01L,1L,8L,0xFB78L,0xCF02L,0x5A9DL,(-1L)},{0x5A9DL,9L,0L,0x4E01L,(-10L),0x17EAL,0L,0L,0x17EAL},{8L,1L,1L,1L,8L,0x5A9DL,9L,0L,0x4E01L},{8L,0xFB78L,0xCF02L,0x5A9DL,(-1L),9L,1L,0xA62DL,1L},{0x5A9DL,0L,0x776BL,0x776BL,0L,0x5A9DL,0x8001L,8L,0xBF79L},{1L,0L,0xA62DL,(-1L),1L,0x17EAL,0x776BL,1L,1L}}};
        int i, j, k;
        if (((l_163 == l_158[3]) > ((*l_166) = p_54)))
        { /* block id: 39 */
            int32_t l_179 = 0x135B92F1L;
            union U0 l_188 = {4294967295UL};
            int32_t l_200 = (-10L);
            int8_t l_240 = (-3L);
            uint32_t **l_259 = (void*)0;
            uint32_t *l_261 = &g_181;
            uint32_t **l_260 = &l_261;
            int32_t *l_262 = &g_218.f1;
            if ((**l_159))
            { /* block id: 40 */
                for (p_56 = 0; (p_56 < (-4)); p_56--)
                { /* block id: 43 */
                    int32_t *l_169 = &g_110;
                    int32_t *l_170 = &g_110;
                    int32_t *l_171 = &g_110;
                    int32_t *l_172 = &g_110;
                    int32_t *l_173 = &g_110;
                    int32_t *l_174[8][4] = {{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110},{&g_110,&g_110,&g_110,&g_110}};
                    int i, j;
                    (*l_159) = &g_110;
                    g_181++;
                }
            }
            else
            { /* block id: 47 */
                uint32_t *l_189 = &g_108;
                union U1 l_199 = {0};
                uint8_t l_203 = 0xF6L;
                uint32_t *l_243 = &g_181;
                for (g_181 = 21; (g_181 == 35); g_181 = safe_add_func_int16_t_s_s(g_181, 2))
                { /* block id: 50 */
                    int16_t *l_201 = (void*)0;
                    int16_t *l_202 = &l_199.f1;
                    int32_t l_204 = 0L;
                    (**l_159) = (safe_mod_func_uint64_t_u_u(((((g_144[0] , l_188) , (l_189 != l_166)) >= (((safe_div_func_uint8_t_u_u((1UL ^ (safe_sub_func_int8_t_s_s(0x69L, (safe_sub_func_int8_t_s_s((g_178 &= (safe_unary_minus_func_int32_t_s(((0x5D28L > (((safe_add_func_int16_t_s_s(((*l_202) = ((l_199 , (0xF5D31D5B22E30894LL || 0xC7289F41D23F08B2LL)) | l_200)), l_203)) & l_204) != g_37)) != p_54)))), 4L))))), p_54)) >= g_34) & g_77)) == 255UL), p_56));
                    g_177 = (-1L);
                    if (p_56)
                    { /* block id: 55 */
                        (*l_159) = (*l_159);
                        return l_188.f0;
                    }
                    else
                    { /* block id: 58 */
                        int32_t l_219 = (-9L);
                        const int8_t **l_223 = (void*)0;
                        const int8_t **l_224 = (void*)0;
                        const int8_t *l_226[5][3][2] = {{{&g_227[4],&g_227[4]},{&g_227[8],(void*)0},{&g_227[6],(void*)0}},{{&g_227[8],&g_227[4]},{&g_227[4],&g_227[8]},{(void*)0,&g_227[6]}},{{(void*)0,&g_227[8]},{&g_227[4],&g_227[4]},{&g_227[8],(void*)0}},{{&g_227[6],(void*)0},{&g_227[8],&g_227[4]},{&g_227[4],&g_227[8]}},{{(void*)0,&g_227[6]},{&g_227[8],&g_227[6]},{&g_227[4],&g_227[4]}}};
                        const int8_t **l_225 = &l_226[1][0][1];
                        const int8_t *l_229 = (void*)0;
                        const int8_t **l_228 = &l_229;
                        int i, j, k;
                        if (g_110)
                            goto lbl_205;
                        (*l_160) = (((safe_rshift_func_int16_t_s_u(((((safe_add_func_int64_t_s_s(p_54, (safe_add_func_uint64_t_u_u(((safe_mod_func_int16_t_s_s(((safe_add_func_int64_t_s_s((((safe_div_func_int32_t_s_s(p_56, (g_218 , (l_219 && (*l_160))))) != (safe_mul_func_uint16_t_u_u((g_230 = ((((*l_228) = ((l_201 == (l_222 , &g_34)) , ((*l_225) = &g_178))) == (void*)0) , 0xC7E8L)), l_219))) <= 0xC6410FA4C8627F26LL), l_222.f0)) >= 3L), 65535UL)) | p_56), 1UL)))) < (*l_160)) > g_135) >= p_56), (*p_55))) ^ 0L) && (*p_55));
                    }
                }
                if ((*l_160))
                    continue;
                if ((((safe_sub_func_int32_t_s_s((safe_unary_minus_func_int64_t_s((safe_add_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s((0L && (**l_159)), ((*l_189) ^= (safe_lshift_func_uint16_t_u_u(l_240, (((safe_rshift_func_uint16_t_u_u((((*l_243) = ((void*)0 != &g_110)) , 65535UL), 14)) , &g_156) != ((p_54 ^ (0x33EB71E6FE0F2E99LL || 0x187993A35CC15AF3LL)) , (void*)0))))))) > p_54), 65535UL)))), (**l_159))) == 0xA1B8C437L) || p_54))
                { /* block id: 69 */
                    return g_34;
                }
                else
                { /* block id: 71 */
                    return p_54;
                }
            }
            l_246 = l_244;
            (*l_262) ^= (((l_248[0] | (p_56 & (safe_mul_func_int16_t_s_s((**l_159), ((*l_160) >= p_56))))) != (safe_rshift_func_int16_t_s_s(((l_188.f1 ^= (safe_sub_func_int8_t_s_s(l_255, (safe_lshift_func_uint8_t_u_u(l_258[0][0][5], (&g_181 != ((*l_260) = &g_181))))))) || (*l_160)), 3))) , 0x36A9738CL);
        }
        else
        { /* block id: 79 */
            int32_t *l_263 = (void*)0;
            int32_t *l_264 = (void*)0;
            int32_t l_265 = (-4L);
            int32_t *l_266 = &l_265;
            int32_t *l_267 = &l_176;
            g_268--;
            if (g_37)
                break;
        }
    }
    for (g_181 = 0; (g_181 <= 2); g_181 += 1)
    { /* block id: 86 */
        int64_t *l_272 = &g_135;
        union U2 **l_275 = &l_273[2][5][1];
        (*l_160) = (!((*l_272) = p_56));
        if (p_54)
            break;
        (*l_275) = l_273[0][1][0];
    }
    return g_227[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_77 g_37 g_108 g_110 g_135 g_34 g_36
 * writes: g_108 g_37 g_110 g_135 g_144
 */
static int8_t  func_58(int8_t * p_59, int8_t  p_60, int32_t  p_61, const uint16_t * p_62, uint16_t * p_63)
{ /* block id: 5 */
    uint32_t l_87 = 0x17F6C077L;
    int8_t *l_104 = &g_37;
    uint32_t *l_105 = (void*)0;
    uint32_t *l_106 = (void*)0;
    uint32_t *l_107 = &g_108;
    int32_t *l_109 = &g_110;
    int32_t l_116 = 0xC9BF6A77L;
    int32_t *l_117 = &g_110;
    int32_t *l_118[5] = {&l_116,&l_116,&l_116,&l_116,&l_116};
    uint64_t l_119 = 0UL;
    const int32_t l_153 = 0x6F91BAA8L;
    int i;
lbl_114:
    (*l_109) &= (l_87 == ((*l_104) = (safe_mul_func_uint8_t_u_u(g_77, (((safe_sub_func_uint32_t_u_u(((*l_107) = (g_77 | ((l_87 != (((safe_div_func_int8_t_s_s((l_87 == (safe_sub_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((-7L), (safe_lshift_func_uint8_t_u_s((&p_62 == &p_63), 3)))), (safe_sub_func_int32_t_s_s((l_104 == (void*)0), (-1L))))) ^ p_60), 0x02A8L))), (*p_59))) | 0xFC20L) | 1L)) && g_37))), g_77)) && g_108) ^ l_87)))));
    if (l_87)
        goto lbl_122;
    if (p_61)
    { /* block id: 9 */
        int32_t l_113[6][7] = {{0x09720137L,0x09720137L,(-10L),(-10L),0x09720137L,0x09720137L,(-10L)},{0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L},{0x09720137L,(-10L),(-10L),0x09720137L,0x09720137L,(-10L),(-10L)},{0L,0x9F62D42CL,0L,0x9F62D42CL,0L,0x9F62D42CL,0L},{0x09720137L,0x09720137L,(-10L),(-10L),0x09720137L,0x09720137L,(-10L)},{0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L,0x9F62D42CL,0xCBDC27B9L}};
        int i, j;
        for (p_61 = 0; (p_61 < 7); p_61 = safe_add_func_int16_t_s_s(p_61, 1))
        { /* block id: 12 */
            l_113[1][2] = (l_105 == l_109);
        }
        if (g_108)
            goto lbl_115;
    }
    else
    { /* block id: 15 */
lbl_115:
        if (p_60)
            goto lbl_114;
lbl_122:
        l_119--;
        for (p_60 = 0; p_60 < 5; p_60 += 1)
        {
            l_118[p_60] = (void*)0;
        }
    }
    for (l_116 = 13; (l_116 != 13); l_116 = safe_add_func_uint32_t_u_u(l_116, 9))
    { /* block id: 24 */
        int32_t *l_132 = &g_110;
        int8_t *l_133 = &g_37;
        int64_t *l_134 = &g_135;
        uint8_t *l_143 = &g_144[1];
        int32_t l_154[5];
        int32_t l_155 = 0x057597B3L;
        int i;
        for (i = 0; i < 5; i++)
            l_154[i] = (-1L);
        l_155 &= (l_154[4] = (((safe_div_func_uint32_t_u_u((safe_unary_minus_func_int8_t_s(((((safe_rshift_func_int8_t_s_s((((((*l_134) &= (safe_sub_func_int16_t_s_s((l_132 == l_132), ((void*)0 == l_133)))) && (((safe_rshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s(((+(safe_div_func_uint8_t_u_u(((*l_143) = 1UL), 0x70L))) == ((*l_109) = (((safe_mul_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_s(((p_60 , g_37) && ((safe_mul_func_uint8_t_u_u(p_61, (*p_59))) == 1L)), (*p_59))) && p_61) == l_153), p_60)), (*p_63))) <= (-6L)) >= (*l_109)))), 0x2BCEL)), g_135)) == g_34) < p_61)) , 0x56DDL) == p_60), 7)) , l_143) != &p_60) == 0xE678B10BEF9B71F4LL))), 0x583FDF71L)) < 0xF0L) == g_34));
    }
    return (*g_36);
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_35.f0, "g_35.f0", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_144[i], "g_144[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_181, "g_181", print_hash_value);
    transparent_crc(g_218.f0, "g_218.f0", print_hash_value);
    transparent_crc(g_218.f1, "g_218.f1", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_227[i], "g_227[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_230, "g_230", print_hash_value);
    transparent_crc(g_268, "g_268", print_hash_value);
    transparent_crc(g_274.f0, "g_274.f0", print_hash_value);
    transparent_crc(g_277.f0, "g_277.f0", print_hash_value);
    transparent_crc(g_300, "g_300", print_hash_value);
    transparent_crc(g_310, "g_310", print_hash_value);
    transparent_crc(g_330, "g_330", print_hash_value);
    transparent_crc(g_404, "g_404", print_hash_value);
    transparent_crc(g_407, "g_407", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_475[i], "g_475[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_481, "g_481", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_526[i][j], "g_526[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_546, "g_546", print_hash_value);
    transparent_crc(g_631, "g_631", print_hash_value);
    transparent_crc(g_635, "g_635", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_638[i], "g_638[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_640, "g_640", print_hash_value);
    transparent_crc(g_690, "g_690", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_863[i][j], "g_863[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1004, "g_1004", print_hash_value);
    transparent_crc(g_1016, "g_1016", print_hash_value);
    transparent_crc(g_1017, "g_1017", print_hash_value);
    transparent_crc(g_1018, "g_1018", print_hash_value);
    transparent_crc(g_1052, "g_1052", print_hash_value);
    transparent_crc(g_1108, "g_1108", print_hash_value);
    transparent_crc(g_1188, "g_1188", print_hash_value);
    transparent_crc(g_1281, "g_1281", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1289[i][j][k].f0, "g_1289[i][j][k].f0", print_hash_value);
                transparent_crc(g_1289[i][j][k].f1, "g_1289[i][j][k].f1", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1305, "g_1305", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_1373[i][j], "g_1373[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1377.f0, "g_1377.f0", print_hash_value);
    transparent_crc(g_1377.f1, "g_1377.f1", print_hash_value);
    transparent_crc(g_1485, "g_1485", print_hash_value);
    transparent_crc(g_1508, "g_1508", print_hash_value);
    transparent_crc(g_1914, "g_1914", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1998[i].f0, "g_1998[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2001, "g_2001", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2283[i], "g_2283[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2317, "g_2317", print_hash_value);
    transparent_crc(g_2336, "g_2336", print_hash_value);
    transparent_crc(g_2442, "g_2442", print_hash_value);
    transparent_crc(g_2597, "g_2597", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2908[i][j][k], "g_2908[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2936[i], "g_2936[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 713
XXX total union variables: 75

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 20
breakdown:
   indirect level: 0, occurrence: 10
   indirect level: 1, occurrence: 8
   indirect level: 2, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 7
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 13
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 41
breakdown:
   depth: 1, occurrence: 279
   depth: 2, occurrence: 69
   depth: 3, occurrence: 5
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 3
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 3
   depth: 14, occurrence: 1
   depth: 15, occurrence: 3
   depth: 16, occurrence: 3
   depth: 17, occurrence: 3
   depth: 18, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 4
   depth: 23, occurrence: 2
   depth: 24, occurrence: 2
   depth: 25, occurrence: 2
   depth: 27, occurrence: 2
   depth: 30, occurrence: 1
   depth: 31, occurrence: 2
   depth: 32, occurrence: 2
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 2
   depth: 38, occurrence: 1
   depth: 41, occurrence: 1

XXX total number of pointers: 756

XXX times a variable address is taken: 1709
XXX times a pointer is dereferenced on RHS: 309
breakdown:
   depth: 1, occurrence: 242
   depth: 2, occurrence: 59
   depth: 3, occurrence: 6
   depth: 4, occurrence: 2
XXX times a pointer is dereferenced on LHS: 389
breakdown:
   depth: 1, occurrence: 334
   depth: 2, occurrence: 53
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 51
XXX times a pointer is compared with address of another variable: 14
XXX times a pointer is compared with another pointer: 16
XXX times a pointer is qualified to be dereferenced: 8960

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1404
   level: 2, occurrence: 389
   level: 3, occurrence: 49
   level: 4, occurrence: 7
XXX number of pointers point to pointers: 271
XXX number of pointers point to scalars: 430
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.6
XXX average alias set size: 1.43

XXX times a non-volatile is read: 2154
XXX times a non-volatile is write: 1125
XXX times a volatile is read: 87
XXX    times read thru a pointer: 35
XXX times a volatile is write: 35
XXX    times written thru a pointer: 11
XXX times a volatile is available for access: 6.24e+03
XXX percentage of non-volatile access: 96.4

XXX forward jumps: 4
XXX backward jumps: 12

XXX stmts: 280
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 36
   depth: 2, occurrence: 46
   depth: 3, occurrence: 66
   depth: 4, occurrence: 50
   depth: 5, occurrence: 50

XXX percentage a fresh-made variable is used: 18.6
XXX percentage an existing variable is used: 81.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

