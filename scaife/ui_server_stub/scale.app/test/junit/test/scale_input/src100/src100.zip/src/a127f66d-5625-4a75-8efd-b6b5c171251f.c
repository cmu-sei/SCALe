/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1714354970
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int16_t  f0;
   uint16_t  f1;
   uint32_t  f2;
   const int8_t  f3;
};

struct S1 {
   const uint64_t  f0;
   volatile int16_t  f1;
   int32_t  f2;
   volatile int16_t  f3;
   int32_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x952EAA29L;
static volatile int32_t g_4 = 0x2ABBF9ACL;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 0x79253A34L;
static int32_t g_6 = (-7L);
static int8_t g_42 = 8L;
static int16_t g_47[6][1] = {{6L},{4L},{4L},{6L},{4L},{4L}};
static uint32_t g_50[1][1] = {{0x11919B17L}};
static int8_t g_53 = (-10L);
static uint64_t g_73 = 18446744073709551615UL;
static uint32_t *g_76 = &g_50[0][0];
static uint16_t g_80 = 4UL;
static int32_t g_88 = (-10L);
static int32_t ** const  volatile g_92 = (void*)0;/* VOLATILE GLOBAL g_92 */
static int32_t *g_94 = &g_3;
static int32_t ** const  volatile g_93 = &g_94;/* VOLATILE GLOBAL g_93 */
static volatile struct S1 g_95 = {0x632B0D1CDFBE8482LL,0x3F39L,-1L,0L,0xA6B6A2D8L};/* VOLATILE GLOBAL g_95 */
static int32_t g_99[7] = {1L,1L,1L,1L,1L,1L,1L};
static const int32_t *g_124 = (void*)0;
static const int32_t **g_123 = &g_124;
static const int32_t *** volatile g_122 = &g_123;/* VOLATILE GLOBAL g_122 */
static uint32_t g_125 = 0xBA490F00L;
static int64_t g_150 = 9L;
static uint8_t g_157 = 8UL;
static uint32_t **g_254 = &g_76;
static uint32_t ***g_253 = &g_254;
static struct S0 *g_263 = (void*)0;
static struct S0 ** volatile g_264 = &g_263;/* VOLATILE GLOBAL g_264 */
static uint16_t g_278[4] = {0xF5B1L,0xF5B1L,0xF5B1L,0xF5B1L};
static uint8_t g_300 = 0xF4L;
static uint8_t g_305 = 0x24L;
static int16_t g_308 = (-1L);
static int64_t g_341 = 1L;
static const struct S0 g_343 = {0L,1UL,0x3586750CL,0L};
static uint32_t g_344 = 5UL;
static volatile int32_t * volatile g_347[10][4][6] = {{{&g_95.f4,&g_4,&g_95.f4,&g_95.f4,&g_95.f4,&g_4},{&g_95.f2,(void*)0,&g_95.f4,&g_4,&g_4,&g_95.f4},{&g_95.f4,(void*)0,&g_95.f2,&g_95.f4,(void*)0,&g_4},{&g_4,&g_95.f4,&g_4,&g_4,(void*)0,&g_95.f4}},{{&g_4,&g_95.f4,&g_95.f4,(void*)0,&g_4,&g_95.f4},{&g_4,&g_95.f4,(void*)0,&g_4,&g_4,&g_95.f2},{&g_95.f2,&g_95.f4,&g_95.f4,&g_95.f4,&g_95.f2,(void*)0},{&g_95.f2,&g_95.f4,&g_95.f4,&g_4,&g_95.f4,&g_4}},{{&g_4,&g_4,&g_4,&g_95.f2,(void*)0,&g_95.f2},{(void*)0,(void*)0,(void*)0,&g_95.f4,(void*)0,&g_95.f4},{&g_95.f2,&g_95.f4,&g_4,&g_95.f4,&g_4,&g_95.f2},{(void*)0,&g_95.f4,&g_95.f2,&g_95.f2,&g_95.f4,&g_95.f4}},{{&g_4,&g_95.f2,(void*)0,&g_4,(void*)0,(void*)0},{&g_95.f2,&g_4,(void*)0,&g_95.f4,&g_95.f4,(void*)0},{&g_95.f2,&g_95.f2,&g_95.f4,&g_4,&g_95.f2,(void*)0},{&g_4,&g_4,&g_95.f4,&g_95.f4,&g_4,(void*)0}},{{&g_95.f4,&g_95.f4,(void*)0,&g_95.f4,(void*)0,(void*)0},{&g_95.f4,(void*)0,(void*)0,&g_95.f4,&g_95.f2,&g_95.f4},{&g_95.f4,(void*)0,&g_95.f2,(void*)0,&g_95.f2,&g_95.f2},{(void*)0,&g_95.f2,&g_4,&g_4,&g_95.f4,&g_95.f4}},{{&g_4,&g_95.f2,(void*)0,(void*)0,&g_95.f2,&g_95.f2},{&g_95.f4,(void*)0,&g_4,(void*)0,&g_95.f2,&g_4},{(void*)0,(void*)0,&g_95.f4,&g_95.f4,(void*)0,(void*)0},{(void*)0,&g_95.f4,&g_95.f4,&g_95.f2,&g_4,&g_95.f2}},{{(void*)0,&g_4,(void*)0,&g_95.f2,&g_95.f2,&g_95.f4},{(void*)0,&g_95.f2,&g_95.f2,&g_95.f2,&g_95.f4,&g_4},{(void*)0,&g_4,&g_95.f4,&g_95.f4,(void*)0,(void*)0},{(void*)0,&g_95.f2,&g_95.f4,(void*)0,&g_95.f4,&g_95.f4}},{{&g_95.f4,&g_95.f4,(void*)0,(void*)0,&g_4,&g_95.f2},{&g_4,&g_95.f4,&g_4,&g_4,(void*)0,&g_95.f2},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_95.f4},{&g_95.f4,&g_4,&g_95.f4,&g_95.f4,&g_95.f4,(void*)0}},{{&g_95.f4,&g_95.f4,&g_95.f4,&g_95.f4,&g_95.f2,&g_4},{&g_95.f4,&g_95.f4,&g_95.f2,&g_95.f4,&g_4,&g_95.f4},{&g_4,&g_95.f4,(void*)0,&g_4,&g_4,&g_95.f2},{&g_95.f2,&g_95.f4,&g_95.f4,&g_95.f4,&g_95.f2,(void*)0}},{{&g_95.f2,&g_95.f4,&g_95.f4,&g_95.f4,&g_4,&g_95.f4},{&g_95.f4,&g_95.f4,&g_95.f4,(void*)0,&g_4,(void*)0},{(void*)0,&g_4,&g_95.f4,(void*)0,&g_95.f4,&g_95.f2},{(void*)0,&g_95.f4,&g_95.f4,(void*)0,(void*)0,(void*)0}}};
static volatile int32_t * volatile * volatile g_348 = &g_347[2][1][1];/* VOLATILE GLOBAL g_348 */
static int32_t g_398 = 8L;
static volatile struct S1 g_450 = {1UL,-1L,0x938989CFL,0L,0xA3AB3B1AL};/* VOLATILE GLOBAL g_450 */
static const uint8_t g_455 = 0x55L;
static struct S1 g_458 = {0x1AE8303B74AD4B72LL,0x300CL,0x9760BBB0L,0xFFD6L,-1L};/* VOLATILE GLOBAL g_458 */
static int32_t g_475 = 2L;
static struct S0 g_568 = {0x1866L,0xCF38L,4294967294UL,0x89L};
static uint64_t g_582 = 0x739ED8E9D62F20A3LL;
static int32_t * volatile g_621 = &g_475;/* VOLATILE GLOBAL g_621 */
static uint8_t * volatile g_655[7][6][6] = {{{&g_157,&g_305,&g_305,&g_157,&g_300,&g_305},{&g_305,&g_305,(void*)0,&g_157,&g_157,(void*)0},{&g_157,(void*)0,&g_300,&g_305,&g_300,&g_300},{&g_300,&g_300,(void*)0,&g_300,(void*)0,&g_157},{&g_157,&g_157,&g_300,(void*)0,(void*)0,&g_157},{&g_300,&g_305,&g_305,&g_305,&g_305,&g_300}},{{(void*)0,&g_305,&g_157,&g_305,&g_300,&g_157},{&g_300,&g_305,(void*)0,&g_305,&g_300,&g_157},{&g_300,&g_300,&g_305,&g_305,&g_157,&g_157},{(void*)0,&g_300,&g_300,&g_305,(void*)0,&g_305},{&g_300,&g_157,&g_300,(void*)0,&g_300,(void*)0},{&g_157,&g_305,(void*)0,&g_300,&g_157,&g_157}},{{&g_300,&g_300,(void*)0,&g_305,(void*)0,&g_157},{&g_157,(void*)0,&g_300,&g_157,&g_305,(void*)0},{&g_305,&g_157,&g_305,&g_157,&g_305,&g_300},{&g_157,&g_157,&g_157,&g_157,&g_157,(void*)0},{&g_305,&g_157,&g_300,(void*)0,(void*)0,&g_157},{&g_157,(void*)0,&g_300,&g_157,&g_157,&g_157}},{{&g_157,&g_305,&g_300,(void*)0,(void*)0,(void*)0},{&g_157,&g_300,&g_157,&g_300,(void*)0,&g_300},{(void*)0,&g_157,&g_305,&g_300,&g_300,(void*)0},{&g_157,&g_157,&g_300,(void*)0,&g_305,&g_157},{&g_300,&g_305,(void*)0,&g_157,&g_300,&g_157},{(void*)0,&g_300,(void*)0,(void*)0,&g_157,(void*)0}},{{&g_300,&g_157,&g_300,&g_300,&g_305,&g_305},{&g_300,&g_300,&g_300,&g_300,(void*)0,&g_157},{&g_305,&g_305,&g_305,&g_305,&g_305,&g_157},{&g_157,&g_300,(void*)0,&g_305,&g_305,&g_157},{&g_305,&g_157,(void*)0,&g_157,&g_157,(void*)0},{&g_157,&g_300,&g_300,&g_300,&g_157,(void*)0}},{{&g_300,&g_300,(void*)0,&g_305,&g_305,&g_157},{&g_157,&g_157,&g_157,(void*)0,&g_300,&g_157},{&g_157,&g_300,&g_305,(void*)0,&g_157,&g_157},{(void*)0,&g_157,&g_305,&g_305,&g_157,(void*)0},{&g_300,&g_157,&g_157,&g_300,&g_305,&g_300},{&g_157,&g_157,&g_157,&g_305,&g_157,&g_305}},{{&g_300,(void*)0,&g_300,&g_157,&g_305,&g_157},{&g_157,&g_300,(void*)0,&g_157,&g_300,&g_305},{&g_300,&g_157,&g_305,&g_305,&g_157,&g_157},{&g_157,&g_300,&g_157,&g_300,&g_157,&g_300},{&g_300,&g_305,(void*)0,&g_305,&g_305,&g_157},{(void*)0,&g_305,(void*)0,(void*)0,&g_300,&g_300}}};
static uint8_t * volatile *g_654 = &g_655[4][2][1];
static uint8_t *g_657[9] = {&g_157,&g_157,&g_157,&g_157,&g_157,&g_157,&g_157,&g_157,&g_157};
static uint8_t **g_656 = &g_657[4];
static int32_t * volatile g_659 = &g_458.f2;/* VOLATILE GLOBAL g_659 */
static int32_t * const  volatile g_662[2][5] = {{&g_99[3],&g_99[3],&g_99[3],&g_99[3],&g_99[3]},{&g_99[3],&g_99[3],&g_99[3],&g_99[3],&g_99[3]}};
static uint32_t g_686 = 0x0992977FL;
static const int64_t * const g_729 = &g_341;
static const int64_t * const  volatile * const  volatile g_728 = &g_729;/* VOLATILE GLOBAL g_728 */
static uint32_t * const  volatile *g_839 = (void*)0;
static int64_t *g_872 = &g_341;
static int64_t **g_871[5][5] = {{(void*)0,&g_872,&g_872,&g_872,(void*)0},{&g_872,&g_872,&g_872,(void*)0,&g_872},{(void*)0,&g_872,&g_872,(void*)0,(void*)0},{&g_872,(void*)0,&g_872,&g_872,&g_872},{&g_872,(void*)0,&g_872,(void*)0,(void*)0}};
static const struct S1 g_882 = {18446744073709551610UL,0xF28CL,0x4CD1EF77L,5L,0x65216555L};/* VOLATILE GLOBAL g_882 */
static volatile int8_t g_900 = 0x5BL;/* VOLATILE GLOBAL g_900 */
static volatile struct S1 g_935[2] = {{1UL,0x78BDL,0xA47D552CL,0x4220L,0xD3687036L},{1UL,0x78BDL,0xA47D552CL,0x4220L,0xD3687036L}};
static struct S0 g_979 = {1L,0xBC38L,0UL,-7L};
static struct S0 *g_978 = &g_979;
static struct S1 g_1032[1][10] = {{{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L},{0x9520D1BE7DB3EAC4LL,0x4578L,0L,7L,0x52551ED2L}}};
static struct S1 *g_1031 = &g_1032[0][3];
static uint64_t g_1061 = 0x6FE9639A5DD16BF7LL;
static volatile uint16_t g_1062[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static volatile struct S1 g_1126 = {3UL,-5L,0L,-1L,0xCD6E181FL};/* VOLATILE GLOBAL g_1126 */


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static uint64_t  func_7(uint64_t  p_8);
static int16_t  func_9(struct S0  p_10, int64_t  p_11, const uint8_t  p_12, int64_t  p_13);
static struct S0  func_14(uint64_t  p_15, int32_t  p_16, const uint16_t  p_17, uint32_t  p_18);
static uint64_t  func_19(int8_t  p_20, int32_t  p_21);
static int8_t  func_22(int16_t  p_23, int32_t  p_24, struct S0  p_25, uint16_t  p_26, uint64_t  p_27);
static int16_t  func_28(struct S0  p_29, uint64_t  p_30);
static struct S0  func_31(int8_t  p_32, int32_t  p_33);
static const int8_t  func_34(uint64_t  p_35, int8_t  p_36, const int8_t  p_37, uint32_t  p_38);
static int16_t  func_62(uint32_t * p_63);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_458.f4 g_93 g_94 g_123 g_95 g_99 g_839 g_582 g_6 g_5 g_125 g_568.f1 g_253 g_254 g_76 g_344 g_656 g_657 g_124 g_872 g_341 g_50 g_882 g_305 g_80 g_42 g_728 g_729 g_157 g_347 g_348 g_935 g_122 g_47 g_621 g_475 g_458.f0 g_343.f0 g_300 g_264 g_263 g_4 g_278 g_568.f3 g_343.f1 g_568.f2 g_659 g_398 g_458.f2 g_308 g_1061 g_1062 g_450.f0 g_979.f2 g_73 g_1126 g_978 g_979
 * writes: g_3 g_5 g_6 g_458.f4 g_344 g_341 g_124 g_582 g_50 g_157 g_73 g_871 g_47 g_42 g_53 g_347 g_80 g_278 g_978 g_568.f1 g_458.f2 g_150 g_1031 g_263 g_475 g_979.f1 g_94 g_1061
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2[5];
    int32_t l_780 = 0x952F7C59L;
    uint8_t *l_804 = &g_157;
    uint32_t l_821[4] = {0xCEACF8D9L,0xCEACF8D9L,0xCEACF8D9L,0xCEACF8D9L};
    uint32_t l_865 = 18446744073709551612UL;
    uint32_t ****l_881 = &g_253;
    int32_t l_897 = 0x42357264L;
    int32_t l_898 = (-10L);
    int32_t l_901 = 0x8D423210L;
    int32_t l_902 = 0x5DA738AFL;
    int32_t l_903[3][9] = {{0xA7E3D7DBL,0xA7E3D7DBL,0xEA342F25L,(-9L),0x138E33F2L,0x542AA2DEL,1L,0x542AA2DEL,0x138E33F2L},{0xEA342F25L,0xA7E3D7DBL,0xA7E3D7DBL,0xEA342F25L,(-9L),0x138E33F2L,0x542AA2DEL,1L,0x542AA2DEL},{1L,0xA549552FL,0xEA342F25L,0xEA342F25L,0xA549552FL,1L,0L,0xA7E3D7DBL,(-1L)}};
    uint8_t l_904 = 0xE5L;
    uint8_t l_913 = 7UL;
    uint8_t ***l_914 = &g_656;
    int8_t *l_915 = &g_53;
    int8_t *l_916 = &g_42;
    int64_t l_966 = 0x5665BA074C65677ALL;
    int8_t l_1021[9][9] = {{4L,4L,0L,0L,0L,4L,4L,0L,0L},{0xBFL,0x30L,0xBFL,0L,0L,0L,4L,0L,0xBFL},{0L,0xBFL,0xBFL,0L,4L,0L,0xBFL,0xBFL,0L},{0L,0xBFL,0x30L,0xBFL,0L,0L,0xBFL,0x30L,0xBFL},{0xBFL,4L,0x30L,0x30L,4L,0xBFL,4L,0x30L,0x30L},{0L,0L,0xBFL,0x30L,0xBFL,0L,0L,0xBFL,0x30L},{0L,4L,0L,0xBFL,0xBFL,0L,4L,0L,0xBFL},{0L,0xBFL,0xBFL,0L,4L,0L,0xBFL,0xBFL,0L},{0L,0xBFL,0x30L,0xBFL,0L,0L,0xBFL,0x30L,0xBFL}};
    int32_t **l_1093 = &g_94;
    struct S0 **l_1125 = &g_978;
    uint32_t *l_1138 = &l_865;
    uint32_t **l_1137[10] = {&l_1138,&l_1138,&l_1138,&l_1138,&l_1138,&l_1138,&l_1138,&l_1138,&l_1138,&l_1138};
    uint32_t **l_1139 = &l_1138;
    const uint16_t l_1140 = 0x9C23L;
    int i, j;
    for (i = 0; i < 5; i++)
        l_2[i] = 0x14B733C633843046LL;
    for (g_3 = 0; (g_3 <= 4); g_3 += 1)
    { /* block id: 3 */
        int8_t l_45[3][6] = {{1L,0x6CL,(-1L),(-1L),0x6CL,1L},{0x11L,1L,(-1L),1L,0x11L,0x11L},{0xC2L,1L,1L,0xC2L,0x6CL,0xC2L}};
        int32_t *l_756 = &g_5;
        int32_t l_893 = 0x7C00C6E1L;
        int32_t l_894 = 1L;
        int32_t l_895 = 0x2A66C338L;
        int32_t l_896 = (-2L);
        int32_t l_899[5][6] = {{0x7AEBB226L,0xB09990A9L,0xB09990A9L,0x7AEBB226L,0xB09990A9L,0xB09990A9L},{0x7AEBB226L,0xB09990A9L,0xB09990A9L,0x7AEBB226L,0xB09990A9L,0xB09990A9L},{0x7AEBB226L,0xB09990A9L,0xB09990A9L,0x7AEBB226L,0xB09990A9L,0xB09990A9L},{0x7AEBB226L,0xB09990A9L,0xB09990A9L,0x7AEBB226L,0xB09990A9L,0xB09990A9L},{0x7AEBB226L,0xB09990A9L,0xB09990A9L,0x7AEBB226L,0xB09990A9L,0xB09990A9L}};
        int i, j;
        for (g_5 = 0; (g_5 <= 4); g_5 += 1)
        { /* block id: 6 */
            uint32_t l_485[4][10][6] = {{{0x73D0F025L,1UL,0x43FCA100L,4294967295UL,4294967291UL,0x5CEB02AEL},{4294967286UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,0x111237BDL},{0x1CEB9166L,0UL,4294967295UL,0xDC921952L,6UL,0xDE55F1E7L},{4294967287UL,4294967286UL,0x069FBD8BL,0x73D0F025L,1UL,4294967295UL},{0xD192A7B3L,0xD44A4BE7L,1UL,4294967295UL,0UL,0x2EED8028L},{0x28252236L,1UL,0UL,0xD192A7B3L,0x406F6B22L,1UL},{1UL,1UL,0x28252236L,1UL,1UL,1UL},{1UL,4294967287UL,0x3531BF1DL,1UL,4294967295UL,4294967286UL},{4294967295UL,0xDC921952L,4294967288UL,4294967287UL,1UL,4294967286UL},{0x43FCA100L,0x9CD7F046L,0x3531BF1DL,0UL,4294967295UL,1UL}},{{1UL,0x2EED8028L,0x28252236L,1UL,0x3531BF1DL,1UL},{0UL,0x111237BDL,9UL,4294967287UL,0x5CEB02AEL,1UL},{0x5A988088L,1UL,0xDE55F1E7L,0x43FCA100L,1UL,4294967287UL},{4294967295UL,0xCEBF54FBL,4294967295UL,0x406F6B22L,0x5A988088L,4294967295UL},{4294967295UL,0UL,1UL,0x5A988088L,0x1E111848L,0x1E111848L},{4294967295UL,4294967287UL,4294967287UL,4294967295UL,0x28252236L,1UL},{0UL,4294967295UL,0x3531BF1DL,0x069FBD8BL,0xD44A4BE7L,0x406F6B22L},{0UL,1UL,0x111237BDL,1UL,0xD44A4BE7L,0x9CD7F046L},{0x2EED8028L,4294967295UL,4294967295UL,0UL,0x28252236L,0xA57A006AL},{1UL,4294967287UL,0UL,1UL,0x1E111848L,4294967295UL}},{{0x169A528DL,0UL,4294967295UL,0x111237BDL,0x5A988088L,1UL},{0xD44A4BE7L,0xCEBF54FBL,4294967288UL,0x1E111848L,1UL,4294967294UL},{4294967295UL,1UL,0x73D0F025L,4294967288UL,0x5CEB02AEL,0x2FA01861L},{4294967287UL,0x111237BDL,0x9CD7F046L,0xD192A7B3L,0UL,0xD192A7B3L},{5UL,1UL,5UL,0UL,0UL,1UL},{1UL,4294967295UL,0x5A988088L,0x2EED8028L,0x77C670D0L,1UL},{1UL,6UL,4294967295UL,0x2EED8028L,4294967287UL,0UL},{1UL,4294967286UL,0x1CEB9166L,0UL,0xDE55F1E7L,4294967295UL},{5UL,4294967295UL,4294967291UL,0xD192A7B3L,4294967295UL,4294967295UL},{4294967287UL,0xDC921952L,1UL,4294967288UL,9UL,0x28252236L}},{{4294967295UL,4294967295UL,4294967295UL,0x1E111848L,0x069FBD8BL,0xAB08EEBCL},{0xD44A4BE7L,4294967291UL,4294967294UL,0x111237BDL,4294967288UL,0x2EED8028L},{0x169A528DL,0xAB08EEBCL,4294967295UL,1UL,1UL,4294967295UL},{1UL,1UL,0x5CEB02AEL,0UL,0UL,0x1CEB9166L},{0x2EED8028L,0xDE55F1E7L,1UL,1UL,0UL,0x5CEB02AEL},{0UL,0x2EED8028L,1UL,0x069FBD8BL,1UL,0x1CEB9166L},{0UL,0x069FBD8BL,0x5CEB02AEL,4294967295UL,0x43FCA100L,4294967295UL},{4294967295UL,0x43FCA100L,4294967295UL,0x5A988088L,0xCEBF54FBL,0x2EED8028L},{4294967295UL,9UL,4294967294UL,0x406F6B22L,4294967295UL,0xAB08EEBCL},{4294967295UL,4294967294UL,4294967295UL,0x43FCA100L,1UL,0x28252236L}}};
            uint32_t l_793 = 4294967295UL;
            int32_t *l_797 = &g_458.f4;
            int32_t l_822 = 0xC264755BL;
            int i, j, k;
            for (g_6 = 0; (g_6 <= 4); g_6 += 1)
            { /* block id: 9 */
                int8_t *l_41 = &g_42;
                int16_t *l_46[9] = {&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0],&g_47[4][0]};
                int32_t l_48 = 0xEBB4EE00L;
                uint32_t *l_49[5];
                int32_t l_51 = 0xAC1DEA90L;
                int8_t *l_52[4] = {&g_53,&g_53,&g_53,&g_53};
                int8_t *l_54 = &g_53;
                int16_t l_57[3][1][6] = {{{1L,1L,1L,1L,1L,1L}},{{1L,1L,1L,1L,1L,1L}},{{1L,1L,1L,1L,1L,1L}}};
                int i, j, k;
                for (i = 0; i < 5; i++)
                    l_49[i] = &g_50[0][0];
            }
            (*l_797) = (*l_797);
        }
        (*l_756) = (safe_rshift_func_uint8_t_u_s(l_2[g_3], 0));
        for (g_344 = 0; (g_344 <= 0); g_344 += 1)
        { /* block id: 406 */
            int16_t l_841 = (-1L);
            int64_t **l_870 = (void*)0;
            int32_t *l_889 = &g_99[3];
            int32_t *l_890 = &g_5;
            int32_t *l_891[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int8_t l_892 = (-4L);
            int i;
            for (g_341 = 0; (g_341 <= 4); g_341 += 1)
            { /* block id: 409 */
                int8_t l_840[7][9] = {{(-4L),1L,(-4L),(-4L),1L,(-4L),(-4L),1L,(-4L)},{0x42L,(-3L),0x42L,0x5EL,0x77L,0x5EL,0x42L,(-3L),0x42L},{(-4L),1L,(-4L),(-4L),1L,(-4L),(-4L),1L,(-4L)},{0x42L,(-3L),0x42L,0x5EL,0x77L,0x5EL,0x42L,(-3L),0x42L},{(-4L),1L,(-4L),(-4L),1L,(-4L),(-4L),1L,(-4L)},{0x42L,(-3L),0x42L,0x5EL,0x77L,0x5EL,0x42L,(-3L),0x42L},{(-4L),1L,(-4L),(-4L),1L,(-4L),(-4L),1L,(-4L)}};
                uint64_t *l_842[2][10] = {{(void*)0,&g_582,(void*)0,&g_73,&g_73,(void*)0,&g_582,(void*)0,&g_73,&g_73},{(void*)0,&g_582,(void*)0,&g_73,&g_73,(void*)0,&g_582,(void*)0,&g_73,&g_73}};
                int32_t *l_843 = (void*)0;
                int8_t *l_855 = &l_45[1][4];
                struct S0 *l_868 = (void*)0;
                uint32_t l_885[4];
                int i, j;
                for (i = 0; i < 4; i++)
                    l_885[i] = 1UL;
                (*g_123) = (*g_93);
                g_458.f4 ^= (safe_mul_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(0x7EFCL, ((0x6EL || (safe_add_func_int32_t_s_s(((~(safe_sub_func_uint16_t_u_u(((((g_95 , (safe_rshift_func_uint8_t_u_u(1UL, (safe_sub_func_uint16_t_u_u(65532UL, 0xE75EL))))) , g_99[4]) ^ (g_582 &= (~(l_2[g_3] |= (((g_839 == (void*)0) <= l_840[5][0]) , l_841))))) != g_6), 0xCCFCL))) , (*l_756)), 0L))) & 4294967295UL))) , l_841), 255UL));
                if ((((((g_73 = (2L > ((g_125 > ((0x7966L < (~(safe_mul_func_uint16_t_u_u(g_568.f1, 0xEF4CL)))) | (safe_sub_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(((((safe_mul_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(((*l_855) = (-1L)), ((**g_656) = ((safe_add_func_int64_t_s_s((((***g_253) = 0xFB41A23BL) < (safe_sub_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((((safe_unary_minus_func_uint16_t_u((safe_mul_func_int8_t_s_s(l_821[0], ((*l_756) || 0xBBA7L))))) , l_865) >= l_841) <= 0x2F22L), g_6)), g_582))), l_841)) | g_95.f0)))), (*l_756))) ^ 0x0BCFFF9159908A87LL) , 0xB819L) && l_2[3]), 0)), l_2[g_3])))) , g_95.f3))) & 0xCB431275E1214615LL) > (*g_124)) & l_821[2]) != 0x7D59L))
                { /* block id: 418 */
                    uint16_t l_873 = 65535UL;
                    int32_t l_886[7] = {0x8787F88CL,1L,1L,0x8787F88CL,1L,1L,0x8787F88CL};
                    int i;
                    (*l_756) = (((safe_add_func_uint64_t_u_u(((void*)0 != l_868), ((l_841 , (((l_841 , l_843) != (((~((**g_253) == (((g_871[2][1] = l_870) != (void*)0) , (**g_253)))) >= l_840[5][0]) , (*g_123))) > 0UL)) , l_873))) > (*g_872)) > 0xFF3E13BFL);
                    l_886[5] = (l_821[2] ^ (safe_mul_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_u((safe_sub_func_uint32_t_u_u((safe_unary_minus_func_int8_t_s((((*g_76) && ((void*)0 == l_881)) > ((g_882 , (l_821[2] ^ (((safe_lshift_func_int16_t_s_s(g_95.f3, 8)) ^ ((l_841 != l_2[3]) , l_885[2])) < 4UL))) > l_821[2])))), 0xA78CE281L)), l_873)) && (*l_756)) <= g_305), l_873)));
                    if (l_841)
                        break;
                }
                else
                { /* block id: 423 */
                    int i, j;
                    (*l_756) = (safe_mul_func_int16_t_s_s((g_47[(g_3 + 1)][g_344] = l_841), g_80));
                }
            }
            l_904--;
            for (g_42 = 0; (g_42 >= 0); g_42 -= 1)
            { /* block id: 431 */
                int8_t *l_909 = &l_892;
                int32_t l_910 = (-1L);
                l_910 |= ((safe_lshift_func_int8_t_s_s(4L, ((*l_909) = 0xE6L))) <= (**g_728));
            }
        }
    }
    (*g_94) = (((*l_916) = ((*l_915) = ((((((&g_254 != (*l_881)) < l_780) >= (l_902 != (**g_93))) , l_903[0][5]) || l_821[2]) , (safe_lshift_func_int8_t_s_u(((l_913 , l_914) == (void*)0), l_913))))) | (**g_656));
    if (l_821[2])
    { /* block id: 440 */
        uint8_t **l_944[6] = {&g_657[4],&l_804,&g_657[4],&g_657[4],&l_804,&g_657[4]};
        int32_t l_960 = 0L;
        int32_t l_980 = 0xE6BF8834L;
        int8_t *l_997 = (void*)0;
        int32_t l_1014 = (-3L);
        int32_t l_1023 = (-1L);
        uint32_t l_1024 = 0x31072DEFL;
        uint64_t l_1063 = 1UL;
        int64_t *l_1070 = &g_150;
        int64_t * const l_1072 = (void*)0;
        uint16_t *l_1111 = &g_568.f1;
        int64_t l_1117 = 0L;
        struct S0 **l_1127 = &g_978;
        int16_t l_1136 = (-6L);
        int i;
        if (((safe_div_func_int64_t_s_s(0xE95D2F0330FFB3A3LL, g_458.f4)) >= l_902))
        { /* block id: 441 */
            const int16_t l_930 = 0xF2ACL;
            int32_t *l_1008[2];
            uint64_t l_1015[5][8] = {{0UL,0x025C2CEA80E4E971LL,0UL,0x69C21C712A978474LL,0x025C2CEA80E4E971LL,0xED47EFAC2A2D55D7LL,0xED47EFAC2A2D55D7LL,0x025C2CEA80E4E971LL},{0x025C2CEA80E4E971LL,0xED47EFAC2A2D55D7LL,0xED47EFAC2A2D55D7LL,0x025C2CEA80E4E971LL,0x69C21C712A978474LL,0UL,0x025C2CEA80E4E971LL,0UL},{0x025C2CEA80E4E971LL,18446744073709551612UL,3UL,18446744073709551612UL,0x025C2CEA80E4E971LL,3UL,0xA6E6EC2D6C45D408LL,0xA6E6EC2D6C45D408LL},{0UL,18446744073709551612UL,0x69C21C712A978474LL,0x69C21C712A978474LL,18446744073709551612UL,0UL,0xED47EFAC2A2D55D7LL,18446744073709551612UL},{0xA6E6EC2D6C45D408LL,0xED47EFAC2A2D55D7LL,0x69C21C712A978474LL,0xA6E6EC2D6C45D408LL,0x69C21C712A978474LL,0xED47EFAC2A2D55D7LL,0xA6E6EC2D6C45D408LL,0UL}};
            int16_t l_1022[7][4] = {{0x9BFFL,(-2L),(-1L),(-2L)},{(-2L),0L,(-1L),(-1L)},{0x9BFFL,0x9BFFL,(-2L),(-1L)},{1L,0L,1L,(-2L)},{1L,(-2L),(-2L),1L},{0x9BFFL,(-2L),(-1L),(-2L)},{(-2L),0L,(-1L),(-1L)}};
            int i, j;
            for (i = 0; i < 2; i++)
                l_1008[i] = &g_6;
            for (g_341 = 0; (g_341 >= (-5)); g_341--)
            { /* block id: 444 */
                int8_t l_925 = 4L;
                int32_t l_1010[6] = {0x91D8846EL,0x91D8846EL,0x91D8846EL,0x91D8846EL,0x91D8846EL,0x91D8846EL};
                uint8_t l_1012 = 255UL;
                struct S0 *l_1033 = (void*)0;
                int i;
                for (g_5 = 22; (g_5 <= 9); g_5--)
                { /* block id: 447 */
                    for (g_344 = 0; (g_344 <= 0); g_344 += 1)
                    { /* block id: 450 */
                        int i, j, k;
                        g_347[(g_344 + 5)][(g_344 + 1)][(g_344 + 4)] = g_347[(g_344 + 9)][(g_344 + 3)][(g_344 + 4)];
                        g_347[(g_344 + 4)][(g_344 + 1)][(g_344 + 3)] = (*g_348);
                        (*g_94) = ((void*)0 == (*g_656));
                    }
                    for (l_898 = 15; (l_898 >= (-25)); l_898 = safe_sub_func_int16_t_s_s(l_898, 1))
                    { /* block id: 457 */
                        (*g_94) = l_925;
                    }
                    for (l_897 = 12; (l_897 == (-9)); --l_897)
                    { /* block id: 462 */
                        (*g_94) = 0x7E866061L;
                    }
                    for (g_6 = (-12); (g_6 > (-29)); g_6 = safe_sub_func_int16_t_s_s(g_6, 4))
                    { /* block id: 467 */
                        return l_930;
                    }
                }
                for (g_80 = 0; (g_80 <= 0); g_80 += 1)
                { /* block id: 473 */
                    int32_t *l_936 = (void*)0;
                    int32_t l_939[5];
                    int32_t l_1009 = 2L;
                    int32_t l_1018 = (-1L);
                    int i, j;
                    for (i = 0; i < 5; i++)
                        l_939[i] = 6L;
                    if ((1UL == ((*g_94) = (safe_mod_func_int32_t_s_s(((safe_sub_func_uint8_t_u_u(((g_935[1] , (**g_122)) != l_936), ((((safe_lshift_func_uint16_t_u_s(g_47[(g_80 + 2)][g_80], 7)) & 1L) & 2UL) , l_939[2]))) != g_458.f4), 0xC385A6D1L)))))
                    { /* block id: 475 */
                        uint8_t * const *l_946 = (void*)0;
                        uint8_t * const **l_945 = &l_946;
                        int32_t l_961[1][3];
                        uint16_t *l_971 = (void*)0;
                        struct S0 *l_975 = &g_568;
                        struct S0 **l_974 = &l_975;
                        struct S0 *l_977 = &g_568;
                        struct S0 **l_976[6][9] = {{&g_263,&l_977,(void*)0,(void*)0,&l_977,&g_263,&l_977,(void*)0,(void*)0},{&g_263,&g_263,&l_977,(void*)0,&l_977,&g_263,&g_263,&l_977,(void*)0},{&g_263,&l_977,&g_263,&g_263,&g_263,&g_263,&l_977,&g_263,&g_263},{&l_977,&l_977,&l_977,&l_977,&l_977,&l_977,&l_977,&l_977,&l_977},{(void*)0,&g_263,(void*)0,&g_263,(void*)0,(void*)0,&g_263,(void*)0,&g_263},{&l_977,&l_977,(void*)0,(void*)0,&l_977,&l_977,&l_977,(void*)0,(void*)0}};
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_961[i][j] = 8L;
                        }
                        (*g_94) |= ((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((((l_930 , l_944[0]) == ((*l_945) = &g_657[6])) >= l_930), 5)), (+(safe_div_func_int64_t_s_s((safe_div_func_uint32_t_u_u(((*g_621) >= (((safe_add_func_int8_t_s_s((safe_mul_func_int16_t_s_s(g_458.f0, ((safe_mod_func_int64_t_s_s((((((*l_916) &= (((0x44L || g_5) , (safe_rshift_func_int8_t_s_s(l_901, 2))) != 0L)) || g_344) >= g_343.f0) | g_300), 0xF945469491467CA0LL)) > l_960))), 1L)) >= l_961[0][1]) <= g_50[0][0])), (***g_253))), (*g_729)))))) , 1L);
                        (*g_94) = ((safe_rshift_func_int16_t_s_u(((safe_add_func_uint8_t_u_u(l_966, (18446744073709551610UL | ((l_904 , ((*g_76) && l_925)) > (safe_mod_func_int64_t_s_s((((safe_sub_func_int32_t_s_s(((g_278[2] = ((**l_914) != (void*)0)) == (safe_mod_func_int32_t_s_s(((*g_264) == (g_978 = ((*l_974) = &g_568))), (*g_94)))), l_980)) < l_930) && l_913), 18446744073709551611UL)))))) | l_961[0][1]), l_925)) , l_961[0][0]);
                    }
                    else
                    { /* block id: 483 */
                        uint16_t *l_1011 = &g_568.f1;
                        int32_t l_1013 = 0x2D56E403L;
                        (*g_659) = ((l_939[2] & (safe_unary_minus_func_int32_t_s(((safe_rshift_func_uint16_t_u_s((((safe_unary_minus_func_uint64_t_u(((safe_mul_func_uint16_t_u_u(((g_4 == (safe_mul_func_int16_t_s_s((l_980 < (safe_mod_func_int8_t_s_s((safe_add_func_int16_t_s_s(l_903[2][7], (((((safe_div_func_uint16_t_u_u(0UL, ((*l_1011) |= (g_278[1] |= ((safe_sub_func_uint16_t_u_u((&g_42 == l_997), (((((safe_sub_func_int32_t_s_s(((safe_div_func_int8_t_s_s(((safe_div_func_uint32_t_u_u(((+(!(safe_lshift_func_uint8_t_u_u(1UL, (l_1008[1] == &l_939[2]))))) <= (*g_94)), l_1009)) >= 4UL), 254UL)) <= g_47[2][0]), (**g_254))) != g_458.f0) & l_925) >= l_1010[2]) <= l_1010[4]))) <= l_980))))) == 1L) , (**g_656)) > l_1012) > 254UL))), 0xA4L))), g_568.f3))) ^ (-8L)), (-1L))) ^ g_6))) , g_343.f1) != g_568.f2), 8)) & l_980)))) | 0xA739L);
                        l_1013 = ((*g_94) = 1L);
                        --l_1015[1][2];
                    }
                    for (g_568.f1 = 0; (g_568.f1 <= 0); g_568.f1 += 1)
                    { /* block id: 493 */
                        int32_t l_1019[6] = {0L,0x983E5E75L,0x983E5E75L,0L,0x983E5E75L,0x983E5E75L};
                        int32_t l_1020[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1020[i] = 0xC96D6E39L;
                        l_1024--;
                        return l_1019[0];
                    }
                    for (g_150 = 0; (g_150 <= 4); g_150 += 1)
                    { /* block id: 499 */
                        struct S1 *l_1028 = &g_458;
                        struct S1 **l_1027 = &l_1028;
                        struct S1 *l_1030 = &g_458;
                        struct S1 **l_1029[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1029[i] = &l_1030;
                        g_1031 = ((*l_1027) = &g_458);
                        (*g_264) = l_1033;
                    }
                    (*g_94) ^= (-5L);
                }
                return l_902;
            }
        }
        else
        { /* block id: 508 */
            int8_t l_1046 = 1L;
            int64_t *l_1052 = &g_150;
            int16_t *l_1053 = &g_47[4][0];
            uint16_t *l_1056[8];
            int32_t *l_1064 = (void*)0;
            int32_t *l_1065[4];
            int32_t ***l_1108 = &l_1093;
            uint8_t l_1112 = 0x88L;
            int i;
            for (i = 0; i < 8; i++)
                l_1056[i] = &g_80;
            for (i = 0; i < 4; i++)
                l_1065[i] = &l_898;
            (*g_621) = (safe_div_func_uint16_t_u_u(((void*)0 == &g_900), (safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s((safe_add_func_int16_t_s_s(((*l_1053) = (((((((safe_sub_func_uint32_t_u_u((safe_div_func_uint32_t_u_u(((**g_728) > ((l_980 , ((1L >= l_1046) , (((safe_mul_func_uint8_t_u_u((safe_add_func_int8_t_s_s((!0x94E53B2AL), (l_901 || ((((*l_1052) = 0L) && l_1021[4][3]) > (*g_94))))), l_1046)) < (-4L)) || g_398))) == g_6)), 0xA883344EL)), 0x637B231EL)) >= g_458.f2) <= l_913) ^ l_1046) , g_42) <= l_897) ^ g_308)), l_2[2])), l_904)), g_80))));
            if ((((safe_lshift_func_uint16_t_u_s((g_979.f1 = l_821[2]), 7)) , (safe_mod_func_uint32_t_u_u((l_897 = ((***g_253) = (g_300 < 0x26L))), ((g_6 ^= (0x2CBBL != (((safe_sub_func_int32_t_s_s((((*l_1052) = (0x84L ^ (g_3 <= 0xCEL))) && ((((l_903[0][5] , g_1061) && l_1014) ^ l_865) > g_1062[4])), 3L)) != l_1063) , (-9L)))) || l_1063)))) || 0x81C4C79680643E3BLL))
            { /* block id: 517 */
                const struct S0 **l_1074 = (void*)0;
                int32_t l_1096 = 0x41FB4C10L;
                for (g_6 = 24; (g_6 >= (-26)); g_6 = safe_sub_func_uint8_t_u_u(g_6, 4))
                { /* block id: 520 */
                    int64_t **l_1071 = &l_1070;
                    uint64_t *l_1073 = &g_73;
                    const struct S0 ***l_1075 = &l_1074;
                    int32_t l_1082 = (-1L);
                    int32_t ***l_1094 = &l_1093;
                    int16_t l_1095 = 0xA62BL;
                    if (((safe_sub_func_int64_t_s_s((((*l_1073) = (((*l_1071) = l_1070) == l_1072)) != (((*l_1075) = l_1074) == (void*)0)), ((*g_872) ^= (safe_mod_func_int32_t_s_s((safe_div_func_uint32_t_u_u((((((safe_add_func_int8_t_s_s(l_1082, (0L ^ ((safe_add_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s((((void*)0 != (*g_122)) & ((safe_rshift_func_int8_t_s_s(((g_568.f1 = (safe_mod_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((((*l_1094) = l_1093) != (void*)0), 3)), l_1082))) > l_1095), l_980)) ^ 0xA0CBL)), g_343.f0)) != 0xB2F2D8632B0695A1LL), 0xE99CL)) , g_450.f0)))) && (**l_1093)) == (*g_94)) | g_979.f2) > 0xF5816FD740C30A29LL), l_1096)), (*g_94)))))) > 0x18L))
                    { /* block id: 527 */
                        return l_1096;
                    }
                    else
                    { /* block id: 529 */
                        (*g_123) = &l_1096;
                        if ((*g_124))
                            continue;
                        return (**g_656);
                    }
                }
            }
            else
            { /* block id: 535 */
                int32_t **l_1097 = &l_1065[1];
                uint64_t *l_1103 = &g_1061;
                (*g_123) = (g_95.f3 , ((*l_1097) = ((*l_1093) = l_1065[2])));
                (***l_1108) = (((~(safe_sub_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(0x03ADL, (0x440C1B8C5FACF6A0LL ^ (g_582 &= ((*l_1103) = (**l_1093)))))), (((safe_rshift_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(g_73, ((l_1024 > ((((void*)0 != l_1108) > ((safe_add_func_int32_t_s_s(((*g_659) = (*g_621)), ((void*)0 == l_1111))) && (**l_1093))) <= (***l_1108))) & l_1112))), l_960)) >= g_882.f0) == (**l_1093))))) , (*g_621)) || 4294967291UL);
            }
        }
        for (g_6 = 0; (g_6 > (-21)); --g_6)
        { /* block id: 547 */
            uint64_t l_1115 = 18446744073709551606UL;
            if (l_1115)
            { /* block id: 548 */
                (*l_1093) = (*g_93);
            }
            else
            { /* block id: 550 */
                return l_1115;
            }
        }
        (*g_94) = (~(l_1117 & (safe_lshift_func_uint8_t_u_s((safe_div_func_uint64_t_u_u((~((safe_add_func_uint8_t_u_u((l_1125 == (g_1126 , l_1127)), ((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s(((safe_add_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_s(((*g_872) == ((*l_1070) = (**l_1093))), 13)) < (((g_582 , (((**g_656) != (**g_656)) & g_50[0][0])) > (**l_1093)) != l_1023)), (**l_1093))) >= l_1063), 6)), (*g_76))) , (-4L)))) ^ (-6L))), l_1136)), 4))));
    }
    else
    { /* block id: 556 */
        return (**g_656);
    }
    (*g_621) |= (((((**l_1125) , (l_1139 = l_1137[9])) == g_839) , (*l_881)) == (*l_881));
    return l_1140;
}


/* ------------------------------------------ */
/* 
 * reads : g_123 g_305 g_125 g_458.f4 g_568.f1 g_50 g_73 g_278 g_95.f0 g_254 g_76 g_99 g_458.f2 g_47 g_621 g_300 g_450.f1 g_654 g_656 g_124 g_659 g_157 g_398 g_122 g_475 g_95.f4 g_458.f0 g_657 g_5 g_728 g_94 g_3 g_582 g_729 g_341 g_308
 * writes: g_124 g_305 g_125 g_458.f4 g_568.f1 g_278 g_73 g_99 g_475 g_300 g_656 g_458.f2 g_157 g_398 g_150 g_582 g_568.f0 g_53 g_88
 */
static uint64_t  func_7(uint64_t  p_8)
{ /* block id: 278 */
    const int32_t *l_602 = &g_458.f2;
    int32_t l_619 = 0xCC3A9BB7L;
    int64_t *l_660[4][4][7] = {{{&g_341,&g_150,&g_341,&g_341,&g_150,&g_341,&g_341},{(void*)0,&g_341,&g_150,(void*)0,&g_341,&g_341,(void*)0},{&g_341,&g_341,&g_150,&g_341,&g_341,&g_150,&g_341},{&g_341,&g_341,&g_341,&g_341,&g_150,(void*)0,&g_150}},{{&g_341,&g_341,&g_341,&g_341,&g_341,&g_150,&g_150},{(void*)0,&g_341,&g_150,&g_341,&g_341,&g_150,&g_341},{&g_341,&g_150,(void*)0,&g_341,&g_341,(void*)0,(void*)0},{&g_341,&g_341,(void*)0,(void*)0,&g_341,&g_341,(void*)0}},{{&g_341,&g_341,&g_150,&g_341,&g_341,&g_150,&g_341},{&g_341,&g_150,&g_341,&g_150,(void*)0,&g_341,(void*)0},{&g_341,&g_341,&g_341,(void*)0,&g_341,(void*)0,&g_341},{&g_341,&g_341,&g_150,&g_341,&g_341,&g_150,&g_341}},{{&g_341,&g_150,&g_150,&g_341,&g_341,&g_341,&g_150},{&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341},{&g_341,&g_341,&g_150,&g_341,&g_341,&g_341,&g_150},{&g_341,&g_341,&g_341,&g_341,&g_341,&g_150,&g_341}}};
    struct S0 l_698 = {0x8027L,0UL,3UL,0xD4L};
    int i, j, k;
    (*g_123) = l_602;
    for (g_305 = 0; (g_305 <= 0); g_305 += 1)
    { /* block id: 282 */
        uint8_t l_661[8][9][3] = {{{0x8BL,0xF0L,0x8BL},{0x03L,0x2CL,0x03L},{0x8BL,0xF0L,0x8BL},{0x03L,0x2CL,0x03L},{0x8BL,0xF0L,0x8BL},{0x03L,0x2CL,0x03L},{0x8BL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL}},{{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL}},{{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL}},{{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL}},{{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL}},{{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL}},{{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL}},{{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{1UL,0x8BL,1UL},{9UL,0x03L,9UL},{0xF0L,1UL,0xF0L},{0x2CL,9UL,0x2CL}}};
        int32_t l_666 = 0xB863C9FAL;
        int16_t *l_671 = &g_47[1][0];
        int32_t l_672 = 0x9268A132L;
        uint32_t * const l_685 = &g_686;
        uint32_t * const *l_684[6][6] = {{&l_685,&l_685,&l_685,&l_685,&l_685,(void*)0},{&l_685,&l_685,&l_685,(void*)0,&l_685,&l_685},{&l_685,&l_685,&l_685,&l_685,&l_685,(void*)0},{&l_685,&l_685,&l_685,&l_685,&l_685,&l_685},{&l_685,&l_685,&l_685,(void*)0,&l_685,&l_685},{&l_685,&l_685,&l_685,&l_685,&l_685,&l_685}};
        uint32_t * const **l_683 = &l_684[5][3];
        uint32_t * const ***l_682 = &l_683;
        uint8_t ***l_699 = (void*)0;
        int i, j, k;
        for (g_125 = 0; (g_125 <= 3); g_125 += 1)
        { /* block id: 285 */
            int16_t l_639 = 1L;
            for (g_458.f4 = 0; (g_458.f4 <= 3); g_458.f4 += 1)
            { /* block id: 288 */
                int16_t l_617 = 0x6E70L;
                struct S0 l_653[4] = {{1L,65535UL,0x50F74BD9L,-1L},{1L,65535UL,0x50F74BD9L,-1L},{1L,65535UL,0x50F74BD9L,-1L},{1L,65535UL,0x50F74BD9L,-1L}};
                uint8_t ***l_658 = &g_656;
                int i;
                for (g_568.f1 = 0; (g_568.f1 <= 0); g_568.f1 += 1)
                { /* block id: 291 */
                    uint64_t *l_611 = &g_73;
                    uint32_t l_616 = 4294967295UL;
                    uint8_t *l_618[6][1][5] = {{{(void*)0,(void*)0,&g_157,(void*)0,(void*)0}},{{&g_305,(void*)0,&g_305,&g_305,(void*)0}},{{(void*)0,&g_305,&g_305,(void*)0,&g_305}},{{(void*)0,(void*)0,&g_157,(void*)0,(void*)0}},{{&g_305,(void*)0,&g_305,&g_305,(void*)0}},{{(void*)0,&g_305,&g_305,(void*)0,&g_305}}};
                    int32_t *l_620 = &g_99[0];
                    int i, j, k;
                    (*g_621) = (safe_rshift_func_uint8_t_u_u((((safe_add_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(g_50[g_568.f1][g_568.f1], (((((*l_620) |= (safe_lshift_func_uint8_t_u_u(((((g_278[(g_568.f1 + 1)] = (g_50[g_305][g_305] == g_50[g_305][g_568.f1])) | 2UL) , ((l_619 = (((--(*l_611)) || ((0xBB63L <= g_278[g_568.f1]) , 0x903C2F4B56175A06LL)) ^ (((((safe_add_func_uint8_t_u_u(((7L ^ (g_278[(g_305 + 1)] , 18446744073709551615UL)) > g_95.f0), p_8)) != (**g_254)) ^ l_616) , l_617) , p_8))) , &g_341)) == (void*)0), 6))) , (*l_602)) , 4L) && g_47[0][0]))), g_568.f1)) && p_8) > (*l_602)), p_8));
                    for (g_300 = 0; (g_300 <= 3); g_300 += 1)
                    { /* block id: 299 */
                        int32_t l_637 = 0xE265F0E6L;
                        int64_t l_638 = (-1L);
                        int i, j, k;
                        l_639 |= (3L >= (safe_add_func_int8_t_s_s((!(+g_50[0][0])), (safe_mod_func_uint8_t_u_u((func_14(p_8, p_8, (+((*l_611) &= ((((4L != (**g_254)) & (safe_div_func_uint16_t_u_u(g_95.f0, (((((((safe_div_func_uint32_t_u_u(4294967295UL, (safe_div_func_int8_t_s_s(((safe_mod_func_uint32_t_u_u(p_8, p_8)) || l_637), p_8)))) && p_8) == (*l_602)) , p_8) <= p_8) , p_8) , (*l_620))))) , (*l_620)) | 0x5AA4L))), l_638) , p_8), 7UL)))));
                        return (*l_620);
                    }
                    return l_639;
                }
                (*g_659) = (safe_div_func_int32_t_s_s((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s(g_450.f1, 12)), (p_8 || (((safe_lshift_func_uint8_t_u_s(((((safe_unary_minus_func_uint32_t_u(0xF7F99062L)) || (l_639 >= (safe_rshift_func_int16_t_s_s(9L, 8)))) >= 0xB9L) < (safe_rshift_func_int8_t_s_u(((l_653[2] , g_654) == ((*l_658) = g_656)), 0))), 2)) , (**g_123)) & 0x5E8E1167L)))), (-1L)));
                for (g_157 = 0; (g_157 <= 3); g_157 += 1)
                { /* block id: 310 */
                    int32_t l_663 = 0xBB256570L;
                    int i, j, k;
                    l_661[2][0][1] = (((void*)0 != l_660[1][0][0]) , 1L);
                    l_663 &= p_8;
                }
            }
        }
        for (g_398 = 0; (g_398 <= 3); g_398 += 1)
        { /* block id: 318 */
            uint32_t * const *l_680 = (void*)0;
            uint32_t * const **l_679 = &l_680;
            uint32_t * const ***l_678[4] = {&l_679,&l_679,&l_679,&l_679};
            uint8_t ** const * const l_700 = &g_656;
            int32_t l_701 = (-4L);
            int i, j;
            if (((g_50[g_305][g_305] || (safe_add_func_int64_t_s_s((l_666 &= g_50[g_305][g_305]), (l_672 = (safe_mod_func_uint16_t_u_u(g_568.f1, ((((safe_div_func_uint64_t_u_u(0x3230A96D45CAD8B4LL, 0x97C8B56383C2AD20LL)) && (((void*)0 != (*g_122)) > g_278[0])) != ((l_671 == (void*)0) , p_8)) , 1UL))))))) && g_99[3]))
            { /* block id: 321 */
                (*g_123) = (**g_122);
            }
            else
            { /* block id: 323 */
                int32_t *l_673 = (void*)0;
                int32_t *l_674 = (void*)0;
                int32_t *l_675 = &g_475;
                uint32_t * const ****l_681 = (void*)0;
                int32_t **l_724 = &l_674;
                (*l_675) |= p_8;
                l_619 &= (((g_95.f4 > (l_701 = ((((safe_lshift_func_uint8_t_u_s((0x2A39L & ((l_682 = l_678[0]) == &g_253)), 6)) , (p_8 && (safe_rshift_func_int8_t_s_s(g_50[g_305][g_305], (safe_add_func_int64_t_s_s((safe_sub_func_int8_t_s_s((safe_add_func_int64_t_s_s((safe_rshift_func_uint16_t_u_s(4UL, (+((l_698 , l_699) != l_700)))), 0x4C6CE82403BE5F6CLL)), p_8)), (*l_675))))))) , p_8) | g_458.f0))) == (*l_602)) > g_50[g_305][g_305]);
                for (l_666 = 0; (l_666 <= 3); l_666 += 1)
                { /* block id: 330 */
                    uint8_t *l_714[7][4][3] = {{{&g_305,&g_300,(void*)0},{&l_661[2][0][1],&l_661[2][0][1],&g_305},{&g_305,&g_305,&g_300},{&l_661[2][0][1],&g_305,&g_300}},{{&g_305,(void*)0,(void*)0},{&l_661[2][0][1],&l_661[2][0][1],&g_300},{&g_305,&g_305,&g_300},{(void*)0,&l_661[6][7][1],&g_305}},{{(void*)0,&l_661[5][4][0],(void*)0},{&g_305,&l_661[6][7][1],(void*)0},{&g_300,&g_305,&g_305},{&g_300,&l_661[2][0][1],&l_661[2][0][1]}},{{(void*)0,(void*)0,&g_305},{&g_300,&g_305,&l_661[2][0][1]},{&g_300,&g_305,&g_305},{&g_305,&l_661[2][0][1],&l_661[2][0][1]}},{{(void*)0,&g_300,&g_305},{(void*)0,&l_661[2][0][1],&l_661[2][0][1]},{&g_305,&g_305,&g_305},{&l_661[2][0][1],&l_661[6][2][0],&l_661[2][0][1]}},{{&g_305,&g_305,&g_305},{&l_661[2][0][1],&l_661[2][0][1],(void*)0},{&g_305,&g_300,(void*)0},{&l_661[2][0][1],&l_661[2][0][1],&g_305}},{{&g_305,&g_305,&g_300},{&l_661[2][0][1],&g_305,&g_300},{&g_305,(void*)0,(void*)0},{&l_661[2][0][1],&l_661[2][0][1],&g_300}}};
                    int32_t l_715 = 0x43E65F7BL;
                    int i, j, k;
                    if ((((*l_602) == ((safe_mul_func_uint8_t_u_u(((***l_700) = p_8), (l_715 |= (~((p_8 == (((l_672 = (0xA6120495EFF861C6LL <= g_5)) <= (safe_mod_func_int16_t_s_s(p_8, (((safe_mul_func_uint8_t_u_u((~(!p_8)), ((*l_602) | (!(0xEF0AL & 65526UL))))) , p_8) || 0x0C4C0A12L)))) , 0x6B1AL)) || 0x3BCAEB33L))))) <= 4294967294UL)) >= l_701))
                    { /* block id: 334 */
                        int8_t *l_718 = &g_42;
                        int32_t l_719 = (-1L);
                        l_719 &= (((safe_sub_func_uint64_t_u_u(0x314DE43E62DFBD50LL, p_8)) , l_718) == (void*)0);
                    }
                    else
                    { /* block id: 336 */
                        int32_t **l_723 = &g_94;
                        int32_t ***l_722[7][5] = {{&l_723,(void*)0,&l_723,&l_723,&l_723},{&l_723,&l_723,&l_723,&l_723,&l_723},{&l_723,&l_723,(void*)0,(void*)0,&l_723},{&l_723,&l_723,&l_723,&l_723,&l_723},{&l_723,(void*)0,(void*)0,&l_723,&l_723},{&l_723,&l_723,&l_723,&l_723,&l_723},{&l_723,&l_723,&l_723,(void*)0,&l_723}};
                        uint32_t *l_726 = &g_125;
                        uint32_t **l_725 = &l_726;
                        int64_t **l_727 = &l_660[1][0][0];
                        uint16_t *l_730[6][2][4] = {{{&g_80,&g_80,&g_278[0],&g_80},{&g_80,(void*)0,(void*)0,&g_80}},{{(void*)0,&g_80,(void*)0,(void*)0},{&g_80,&g_80,&g_278[0],&g_80}},{{&g_80,(void*)0,(void*)0,&g_80},{(void*)0,&g_80,(void*)0,(void*)0}},{{&g_80,&g_80,&g_278[0],&g_80},{&g_80,(void*)0,(void*)0,&g_80}},{{(void*)0,&g_80,(void*)0,(void*)0},{&g_80,&g_80,&g_278[0],&g_80}},{{&g_80,(void*)0,(void*)0,&g_80},{(void*)0,&g_80,(void*)0,(void*)0}}};
                        int i, j, k;
                        l_672 = (safe_sub_func_uint8_t_u_u(((l_724 = (void*)0) == &l_673), (((*l_725) = &g_125) == l_673)));
                        l_672 |= (((((g_568.f1 = (l_727 == g_728)) | p_8) & (0xDD4AL < (safe_div_func_int64_t_s_s(0xE6CDB911550D9789LL, (((g_150 = (**l_723)) , (((l_701 != ((((g_305 ^ (--(**g_656))) , ((*l_675) | p_8)) , (*g_124)) >= p_8)) != g_278[2]) >= 18446744073709551615UL)) | p_8))))) & 0x917868EA855EE3F7LL) > p_8);
                    }
                    for (g_582 = 0; (g_582 <= 3); g_582 += 1)
                    { /* block id: 347 */
                        int32_t l_735 = 0xC3B305DFL;
                        (*l_675) = p_8;
                        return l_735;
                    }
                }
            }
            for (g_568.f0 = 3; (g_568.f0 >= 0); g_568.f0 -= 1)
            { /* block id: 355 */
                int16_t l_736 = 0xC961L;
                uint16_t *l_737[4][7] = {{&g_278[0],(void*)0,&g_568.f1,(void*)0,&g_278[0],&l_698.f1,&l_698.f1},{(void*)0,&g_278[1],&g_568.f1,&g_278[1],(void*)0,&l_698.f1,&l_698.f1},{&g_278[0],(void*)0,&g_568.f1,(void*)0,&g_278[0],&l_698.f1,&l_698.f1},{(void*)0,&g_278[1],&g_568.f1,&g_278[1],(void*)0,&l_698.f1,&l_698.f1}};
                int32_t l_738 = (-1L);
                int32_t l_739[3];
                int8_t *l_745 = (void*)0;
                int32_t *l_748 = &l_739[1];
                int32_t *l_749 = &l_738;
                int i, j;
                for (i = 0; i < 3; i++)
                    l_739[i] = 0x93546B5CL;
                (*l_749) = ((*l_748) ^= (((*l_602) != (2UL ^ ((((((g_278[0]--) > ((l_701 ^= 9L) == (*g_729))) < (safe_unary_minus_func_int64_t_s(2L))) == (((safe_rshift_func_int8_t_s_s((g_53 = (-5L)), 0)) >= (safe_lshift_func_int8_t_s_s((((void*)0 == (*l_700)) || ((void*)0 == &g_729)), p_8))) , g_308)) | 0x3F65L) & l_736))) || g_125));
            }
            for (g_88 = 3; (g_88 >= 0); g_88 -= 1)
            { /* block id: 364 */
                int32_t l_750 = (-1L);
                int32_t *l_751 = &g_458.f2;
                int32_t *l_752[7] = {&g_6,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6};
                uint32_t l_753 = 0xAC7D0A68L;
                int i, j, k;
                l_753++;
            }
        }
    }
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_99
 * writes:
 */
static int16_t  func_9(struct S0  p_10, int64_t  p_11, const uint8_t  p_12, int64_t  p_13)
{ /* block id: 276 */
    return g_99[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_278
 * writes: g_278
 */
static struct S0  func_14(uint64_t  p_15, int32_t  p_16, const uint16_t  p_17, uint32_t  p_18)
{ /* block id: 269 */
    uint16_t l_591 = 1UL;
    int32_t *l_592[6][5][8] = {{{(void*)0,&g_99[3],&g_458.f2,&g_5,&g_6,&g_458.f2,&g_458.f2,&g_6},{&g_88,&g_6,&g_6,&g_88,&g_3,&g_458.f2,&g_6,&g_458.f4},{&g_6,(void*)0,&g_99[3],(void*)0,(void*)0,&g_6,(void*)0,&g_475},{&g_88,(void*)0,&g_5,&g_5,&g_475,&g_458.f2,(void*)0,&g_5},{&g_3,&g_6,(void*)0,(void*)0,&g_458.f4,&g_458.f2,&g_458.f4,(void*)0}},{{&g_458.f4,&g_99[3],(void*)0,&g_458.f4,&g_458.f2,&g_88,&g_3,&g_6},{&g_5,&g_475,&g_458.f4,&g_458.f2,&g_3,&g_458.f2,&g_475,&g_6},{&g_6,&g_458.f4,&g_5,&g_475,&g_3,&g_458.f2,&g_3,&g_475},{&g_458.f2,&g_458.f2,&g_458.f2,&g_6,&g_5,&g_88,(void*)0,&g_458.f2},{&g_475,&g_88,(void*)0,&g_6,&g_88,&g_475,&g_5,&g_475}},{{&g_475,&g_458.f4,&g_6,&g_5,&g_5,&g_88,&g_99[3],&g_475},{&g_458.f2,&g_6,&g_458.f2,&g_99[5],&g_3,&g_3,&g_6,&g_6},{&g_6,&g_3,&g_475,&g_3,&g_88,&g_88,&g_99[3],&g_3},{&g_88,&g_3,&g_5,&g_5,&g_458.f2,&g_475,&g_5,&g_475},{&g_458.f4,&g_99[3],&g_458.f2,&g_458.f2,&g_458.f2,&g_458.f2,&g_458.f2,&g_458.f2}},{{&g_6,&g_6,&g_99[3],&g_458.f4,&g_88,&g_6,(void*)0,&g_5},{&g_5,(void*)0,&g_99[5],&g_88,&g_475,(void*)0,&g_3,&g_5},{(void*)0,&g_458.f4,&g_3,&g_458.f4,&g_88,&g_458.f2,&g_458.f4,&g_458.f2},{&g_475,&g_458.f2,&g_6,&g_458.f2,&g_3,&g_5,&g_458.f2,&g_475},{&g_88,&g_3,&g_458.f4,&g_5,&g_475,&g_458.f4,&g_458.f2,&g_3}},{{(void*)0,&g_6,&g_99[3],&g_3,&g_88,(void*)0,&g_475,&g_3},{&g_6,&g_88,(void*)0,(void*)0,&g_458.f4,(void*)0,(void*)0,&g_88},{&g_99[5],&g_5,(void*)0,(void*)0,&g_458.f2,&g_5,&g_99[3],&g_3},{&g_475,&g_458.f2,(void*)0,&g_99[3],&g_99[5],&g_99[3],&g_99[3],&g_6},{&g_458.f4,&g_99[3],(void*)0,&g_5,&g_458.f4,&g_6,(void*)0,&g_99[3]}},{{&g_458.f4,&g_6,(void*)0,&g_99[3],&g_88,&g_458.f2,&g_475,(void*)0},{(void*)0,&g_3,&g_99[3],&g_5,&g_458.f4,&g_458.f4,&g_458.f2,&g_5},{&g_458.f2,&g_5,&g_458.f4,&g_458.f2,&g_475,&g_88,&g_458.f2,(void*)0},{&g_88,&g_458.f4,&g_6,&g_99[5],&g_99[5],&g_6,&g_458.f4,&g_88},{&g_6,&g_88,&g_3,&g_458.f2,&g_6,&g_458.f4,&g_3,&g_99[3]}}};
    uint8_t l_593 = 0xCBL;
    const uint32_t l_596 = 0UL;
    uint16_t *l_597[5];
    uint16_t l_600 = 0xD932L;
    struct S0 l_601 = {0x51EBL,7UL,0x61C57E80L,-1L};
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_597[i] = (void*)0;
    l_593 = (p_16 = (255UL < l_591));
    p_16 = (safe_mod_func_uint16_t_u_u(l_596, (l_600 = (--g_278[0]))));
    return l_601;
}


/* ------------------------------------------ */
/* 
 * reads : g_88 g_123 g_344 g_458.f4 g_95.f2 g_3 g_305 g_254 g_76 g_50 g_458.f0 g_343.f2 g_124 g_73 g_253 g_94 g_122 g_582
 * writes: g_88 g_124 g_344 g_450.f4 g_278 g_305 g_50 g_458.f4 g_73 g_582
 */
static uint64_t  func_19(int8_t  p_20, int32_t  p_21)
{ /* block id: 225 */
    uint32_t l_490 = 1UL;
    int32_t *l_493 = &g_3;
    int32_t l_523 = 0xFA4BF2A0L;
    int32_t l_524 = 9L;
    int32_t l_525 = 0x4F841F90L;
    int32_t l_526 = 1L;
    int32_t l_529 = 6L;
    int32_t l_534 = (-1L);
    int32_t l_538 = 1L;
    int32_t l_539 = 0L;
    int32_t l_540[5] = {0xE8251504L,0xE8251504L,0xE8251504L,0xE8251504L,0xE8251504L};
    int64_t * const l_588[5] = {&g_341,&g_341,&g_341,&g_341,&g_341};
    int64_t l_590[4];
    int i;
    for (i = 0; i < 4; i++)
        l_590[i] = 2L;
    for (g_88 = 1; (g_88 <= 6); g_88 += 1)
    { /* block id: 228 */
        int32_t *l_488 = &g_458.f4;
        int32_t *l_489[8][1] = {{&g_99[3]},{&g_99[3]},{&g_99[3]},{&g_99[3]},{&g_99[3]},{&g_99[3]},{&g_99[3]},{&g_99[3]}};
        int i, j;
        ++l_490;
    }
    (*g_123) = l_493;
    for (g_344 = 15; (g_344 < 12); g_344--)
    { /* block id: 234 */
        uint16_t *l_496 = &g_278[3];
        int32_t l_500 = 9L;
        struct S0 l_505 = {0x7DF7L,0xA328L,0x6FD95301L,0xEAL};
        uint8_t *l_509 = &g_305;
        int32_t l_527 = 1L;
        int32_t l_528 = (-2L);
        int32_t l_535[5][7] = {{1L,(-4L),7L,7L,(-4L),1L,0x9F175E27L},{1L,(-4L),7L,7L,(-4L),1L,0x9F175E27L},{1L,(-4L),7L,7L,(-4L),1L,0x9F175E27L},{1L,(-4L),7L,7L,(-4L),1L,0x9F175E27L},{1L,(-4L),7L,7L,7L,(-3L),1L}};
        uint32_t l_541 = 0x67D855E2L;
        int16_t *l_557[3];
        int32_t *l_558 = &l_525;
        int i, j;
        for (i = 0; i < 3; i++)
            l_557[i] = &g_47[5][0];
        for (g_450.f4 = 0; g_450.f4 < 4; g_450.f4 += 1)
        {
            g_278[g_450.f4] = 0xE5AEL;
        }
        if (((g_458.f4 || (((((void*)0 == l_496) , (safe_sub_func_uint16_t_u_u((!g_95.f2), (((l_500 ^ (safe_add_func_int16_t_s_s(((safe_add_func_uint64_t_u_u((*l_493), 0x229FF5A9C35DBBB7LL)) > (l_505 , ((*l_509) &= (((safe_mul_func_uint8_t_u_u((+p_20), l_500)) < (-1L)) && l_505.f3)))), (-1L)))) || (*l_493)) < 0x3E298ADBFD8D1D5FLL)))) <= 0UL) & p_21)) || l_505.f1))
        { /* block id: 237 */
            int32_t *l_510 = &g_99[3];
            int32_t *l_511 = (void*)0;
            int32_t *l_512 = &g_458.f4;
            int32_t *l_513 = (void*)0;
            int32_t *l_514 = &g_475;
            int32_t *l_515 = &g_458.f2;
            int32_t *l_516 = &l_500;
            int32_t *l_517 = &g_458.f2;
            int32_t *l_518 = &g_475;
            int32_t *l_519 = &g_458.f4;
            int32_t *l_520 = &g_99[6];
            int32_t *l_521 = &l_500;
            int32_t *l_522[10][10] = {{&g_6,&g_5,&g_88,&g_5,&g_6,(void*)0,&g_99[3],&g_5,&g_99[2],&g_99[2]},{(void*)0,&g_5,&g_3,&g_3,&g_3,&g_3,&g_5,(void*)0,&g_88,&g_99[2]},{&g_6,&g_3,&g_5,&g_88,&g_6,&g_99[3],&g_6,&g_88,&g_5,&g_3},{&g_3,(void*)0,&g_5,&g_6,(void*)0,&g_88,(void*)0,(void*)0,&g_88,(void*)0},{&g_99[2],&g_3,&g_3,&g_99[2],&g_5,&g_88,&g_6,&g_5,(void*)0,&g_5},{&g_3,&g_99[3],&g_88,&g_5,&g_88,&g_99[3],&g_3,&g_6,(void*)0,(void*)0},{&g_6,&g_88,&g_5,&g_99[2],&g_3,&g_3,&g_99[2],&g_5,&g_88,&g_6},{(void*)0,&g_88,(void*)0,&g_6,&g_5,(void*)0,&g_3,(void*)0,&g_5,&g_6},{&g_6,&g_99[3],&g_6,&g_88,&g_5,&g_3,&g_6,&g_88,&g_88,&g_6},{&g_5,&g_3,&g_3,&g_3,&g_3,&g_5,(void*)0,&g_88,&g_99[2],(void*)0}};
            uint16_t l_530 = 0x20D1L;
            int i, j;
            ++l_530;
        }
        else
        { /* block id: 239 */
            int32_t *l_533[8][4][5] = {{{&g_458.f4,&g_475,(void*)0,&g_458.f4,(void*)0},{(void*)0,(void*)0,&g_88,(void*)0,(void*)0},{(void*)0,&g_475,&g_6,&g_99[3],&g_99[3]},{(void*)0,(void*)0,(void*)0,&g_88,&g_99[3]}},{{(void*)0,&g_458.f4,&g_3,(void*)0,(void*)0},{&g_475,(void*)0,&g_475,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3,(void*)0,&g_88},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_6,(void*)0,(void*)0},{(void*)0,&g_475,&g_88,&g_3,&g_99[3]},{&g_475,(void*)0,(void*)0,(void*)0,&g_3},{(void*)0,(void*)0,&g_458.f4,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3,(void*)0,&g_5},{(void*)0,&g_475,&g_458.f2,(void*)0,(void*)0},{&g_458.f4,(void*)0,&g_88,&g_88,(void*)0}},{{(void*)0,(void*)0,&g_88,&g_99[3],&g_3},{&g_475,(void*)0,(void*)0,&g_3,(void*)0},{&g_6,(void*)0,&g_475,&g_458.f2,&g_88},{(void*)0,&g_458.f2,&l_524,&g_88,&l_524}},{{&g_5,&g_5,(void*)0,&g_88,&g_458.f4},{&g_458.f2,(void*)0,&g_99[3],&g_458.f2,&g_5},{(void*)0,&g_6,&g_458.f4,&g_3,&g_6},{&g_5,(void*)0,&g_99[3],(void*)0,(void*)0}},{{&g_99[3],&g_5,&g_99[3],&g_458.f4,(void*)0},{&g_88,&g_458.f2,&g_475,(void*)0,&g_6},{(void*)0,(void*)0,&g_88,&g_88,&g_5},{&l_524,&g_5,&g_475,&g_6,&g_458.f4}},{{(void*)0,&g_99[3],&g_99[3],(void*)0,&l_524},{(void*)0,&g_88,&g_99[3],&g_3,&g_88},{&l_524,(void*)0,&g_458.f4,&g_475,(void*)0},{(void*)0,&l_524,&g_99[3],&g_3,&g_475}}};
            int8_t l_536[4][6] = {{0xA4L,0x14L,0xBCL,(-5L),(-5L),0xBCL},{(-5L),(-5L),0xBCL,0x14L,0xA4L,0xBCL},{0x14L,0xA4L,0xBCL,0xA4L,0x14L,0xBCL},{0xA4L,0x14L,0xBCL,(-5L),(-5L),0xBCL}};
            int32_t l_537 = (-6L);
            int i, j, k;
            ++l_541;
        }
        (*l_558) &= (safe_lshift_func_int8_t_s_u(((void*)0 != &g_305), (l_505.f0 == (safe_mod_func_uint32_t_u_u(((safe_div_func_int16_t_s_s((l_523 = (((safe_rshift_func_uint8_t_u_u((p_21 && 4294967295UL), (+(safe_sub_func_uint16_t_u_u(p_21, (*l_493)))))) >= (((0x3D31L || (((++(**g_254)) | 9L) , g_458.f0)) > 8L) , g_343.f2)) , 0x2A9BL)), 65535UL)) || p_20), l_505.f2)))));
    }
    for (g_458.f4 = (-28); (g_458.f4 < (-24)); g_458.f4 = safe_add_func_uint16_t_u_u(g_458.f4, 3))
    { /* block id: 248 */
        int64_t l_561 = 6L;
        int16_t *l_564 = (void*)0;
        int32_t **l_572 = &l_493;
        uint32_t **l_585 = &g_76;
        int32_t *l_589 = &l_524;
        p_21 = (l_561 = (**g_123));
        for (g_73 = 0; (g_73 > 4); g_73 = safe_add_func_uint32_t_u_u(g_73, 9))
        { /* block id: 253 */
            struct S0 *l_567 = &g_568;
            int32_t l_571 = 0xA87C4510L;
            int64_t *l_577 = (void*)0;
            int32_t **l_578[8][7][4] = {{{&l_493,&g_94,&l_493,&l_493},{&g_94,&g_94,&l_493,&l_493},{&g_94,&g_94,&g_94,&g_94},{&l_493,(void*)0,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94},{&l_493,&g_94,&g_94,&l_493},{&g_94,&l_493,&g_94,&l_493}},{{&g_94,&g_94,&g_94,(void*)0},{&g_94,&g_94,&l_493,&l_493},{&g_94,&g_94,&l_493,&g_94},{&g_94,&l_493,&l_493,&l_493},{&g_94,&g_94,&g_94,&l_493},{&g_94,&g_94,&g_94,&l_493},{&g_94,&g_94,&g_94,&l_493}},{{&l_493,(void*)0,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&l_493,&g_94,&g_94,(void*)0},{&g_94,&l_493,&l_493,&g_94},{&g_94,&l_493,&l_493,(void*)0},{&l_493,&g_94,&l_493,&g_94},{&g_94,&g_94,&g_94,&g_94}},{{&g_94,(void*)0,(void*)0,&l_493},{&l_493,&g_94,&g_94,&l_493},{&l_493,&g_94,&g_94,(void*)0},{&l_493,&g_94,&g_94,&g_94},{&l_493,(void*)0,&l_493,&g_94},{&g_94,&l_493,&l_493,&g_94},{&l_493,&g_94,&g_94,&g_94}},{{&l_493,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,(void*)0},{&g_94,&g_94,&g_94,&l_493},{&g_94,&g_94,&g_94,&g_94},{&l_493,&g_94,&g_94,&l_493},{&g_94,&g_94,&l_493,&g_94},{&l_493,(void*)0,&g_94,&g_94}},{{(void*)0,&g_94,&g_94,&l_493},{&l_493,&g_94,&g_94,&g_94},{&l_493,&g_94,&l_493,&l_493},{&g_94,&g_94,&g_94,(void*)0},{&l_493,&g_94,(void*)0,&g_94},{&l_493,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94}},{{&g_94,&l_493,&l_493,&g_94},{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,(void*)0,(void*)0},{&l_493,&g_94,(void*)0,&g_94},{&l_493,&l_493,&g_94,&g_94},{&g_94,&g_94,&l_493,&l_493},{&l_493,&l_493,&g_94,&l_493}},{{&l_493,&l_493,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{&l_493,&g_94,&l_493,&g_94},{&g_94,&l_493,&g_94,&l_493},{&l_493,&l_493,&g_94,&l_493},{&g_94,&g_94,&g_94,&g_94},{&g_94,&l_493,(void*)0,&g_94}}};
            int i, j, k;
            if ((((*l_493) < p_21) && (((***g_253) = ((((void*)0 != l_564) , (((p_21 , (safe_mul_func_uint8_t_u_u(((l_567 = (void*)0) != (void*)0), ((safe_div_func_uint64_t_u_u(l_571, ((p_20 | 1UL) ^ (-2L)))) && 0x859A7A69L)))) , 6L) , p_21)) & 0UL)) || (*g_94))))
            { /* block id: 256 */
                if (l_561)
                    break;
            }
            else
            { /* block id: 258 */
                int32_t ***l_579 = &l_578[3][2][2];
                uint64_t *l_580 = (void*)0;
                uint64_t *l_581 = &g_582;
                p_21 &= (((void*)0 == l_572) != (safe_rshift_func_uint8_t_u_s(((safe_sub_func_uint32_t_u_u((((l_577 == (((((((*l_579) = l_578[7][6][2]) == (*g_122)) , ((*l_581)--)) & ((l_585 != (void*)0) != p_20)) , ((safe_div_func_uint8_t_u_u(0x53L, 0x70L)) , 1UL)) , l_588[3])) || (*l_493)) | 18446744073709551615UL), p_20)) , (**l_572)), 1)));
            }
            if ((**l_572))
                continue;
            (*g_123) = (*g_123);
        }
        (*l_589) = p_21;
    }
    return l_590[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_123
 * writes: g_124
 */
static int8_t  func_22(int16_t  p_23, int32_t  p_24, struct S0  p_25, uint16_t  p_26, uint64_t  p_27)
{ /* block id: 218 */
    for (p_24 = 0; (p_24 <= (-23)); p_24 = safe_sub_func_int64_t_s_s(p_24, 1))
    { /* block id: 221 */
        (*g_123) = (void*)0;
    }
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_28(struct S0  p_29, uint64_t  p_30)
{ /* block id: 216 */
    return p_29.f3;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_53 g_50 g_88 g_73 g_95.f1 g_99 g_3 g_47 g_343.f2 g_344 g_308 g_80 g_347 g_348 g_4 g_95 g_278 g_341 g_157 g_300 g_343.f3 g_76 g_94 g_398 g_450 g_458 g_254 g_5 g_455 g_475 g_343.f0
 * writes: g_42 g_53 g_88 g_73 g_150 g_80 g_341 g_344 g_308 g_347 g_278 g_50 g_398 g_47 g_305 g_475
 */
static struct S0  func_31(int8_t  p_32, int32_t  p_33)
{ /* block id: 17 */
    uint32_t *l_64 = &g_50[0][0];
    int32_t l_466 = 3L;
    int32_t *l_472 = (void*)0;
    int32_t *l_473 = (void*)0;
    int32_t *l_474 = &g_475;
    uint8_t *l_478 = &g_300;
    int32_t **l_483 = (void*)0;
    int32_t ***l_482[10][6][4] = {{{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,(void*)0},{(void*)0,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483},{(void*)0,&l_483,&l_483,&l_483},{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{(void*)0,&l_483,&l_483,&l_483},{&l_483,(void*)0,&l_483,(void*)0}},{{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{(void*)0,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483},{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0}},{{(void*)0,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{(void*)0,&l_483,&l_483,(void*)0},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{(void*)0,&l_483,&l_483,(void*)0},{(void*)0,&l_483,&l_483,&l_483},{&l_483,(void*)0,&l_483,(void*)0},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,&l_483,&l_483,&l_483},{(void*)0,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483}},{{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{&l_483,(void*)0,&l_483,&l_483},{&l_483,&l_483,&l_483,(void*)0},{(void*)0,&l_483,&l_483,&l_483}}};
    struct S0 l_484 = {0L,0x2D44L,4294967295UL,0xC8L};
    int i, j, k;
    (*l_474) &= (func_34((safe_mul_func_uint8_t_u_u((&g_47[4][0] != (void*)0), ((((safe_add_func_int16_t_s_s(func_62(l_64), ((~(safe_div_func_uint32_t_u_u((safe_add_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s(p_32, l_466)) == ((l_466 , (safe_lshift_func_uint8_t_u_u(p_33, (safe_sub_func_uint16_t_u_u((safe_unary_minus_func_int32_t_s((p_33 <= l_466))), l_466))))) ^ 1UL)), g_458.f0)), 1UL))) && 0x483BL))) ^ l_466) ^ 0x85L) ^ l_466))), p_32, l_466, g_3) & g_455);
    g_88 ^= ((safe_div_func_int32_t_s_s(((((void*)0 == l_478) < (*g_76)) != (g_99[1] <= (~((((p_33 || (((g_450.f1 , (safe_sub_func_int32_t_s_s((p_33 ^ g_343.f0), (p_32 >= p_33)))) , l_482[0][3][3]) != (void*)0)) & (*l_474)) , (void*)0) != (void*)0)))), 0x335AC5B7L)) || g_50[0][0]);
    return l_484;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static const int8_t  func_34(uint64_t  p_35, int8_t  p_36, const int8_t  p_37, uint32_t  p_38)
{ /* block id: 14 */
    int32_t *l_56[1][8][9] = {{{&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,&g_6,(void*)0,&g_6},{&g_5,&g_6,&g_6,&g_6,&g_6,&g_3,(void*)0,&g_6,&g_6},{(void*)0,(void*)0,&g_6,&g_6,&g_6,(void*)0,(void*)0,&g_6,(void*)0},{&g_5,&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_3,&g_5,&g_3,&g_6,&g_6,&g_5,&g_6,&g_6},{&g_6,(void*)0,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6,&g_6},{&g_6,&g_6,&g_6,(void*)0,(void*)0,&g_6,(void*)0,(void*)0,&g_6},{&g_6,&g_6,&g_3,(void*)0,&g_6,&g_6,(void*)0,&g_3,&g_6}}};
    int32_t **l_55 = &l_56[0][7][7];
    int i, j, k;
    (*l_55) = (void*)0;
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_53 g_50 g_88 g_73 g_95.f1 g_99 g_3 g_47 g_343.f2 g_344 g_308 g_80 g_347 g_348 g_4 g_95 g_278 g_341 g_157 g_300 g_343.f3 g_76 g_94 g_398 g_450 g_458 g_254 g_5
 * writes: g_42 g_53 g_88 g_73 g_150 g_80 g_341 g_344 g_308 g_347 g_278 g_50 g_398 g_47 g_305
 */
static int16_t  func_62(uint32_t * p_63)
{ /* block id: 18 */
    int32_t *l_65[1];
    uint32_t *l_70 = &g_50[0][0];
    const int32_t *l_120[5][2][4] = {{{&g_5,&g_99[3],&g_5,&g_6},{&g_99[4],&g_99[3],&g_5,&g_99[3]}},{{&g_99[4],&g_6,&g_5,&g_99[3]},{&g_5,&g_99[3],&g_5,&g_6}},{{&g_99[4],&g_99[3],&g_5,&g_99[3]},{&g_99[4],&g_6,&g_5,&g_99[3]}},{{&g_5,&g_99[3],&g_5,&g_6},{&g_99[4],&g_99[3],&g_5,&g_99[3]}},{{&g_99[4],&g_6,&g_5,&g_99[3]},{&g_5,&g_99[3],&g_5,&g_6}}};
    const int32_t **l_119[8] = {&l_120[4][0][3],&l_120[2][1][1],&l_120[4][0][3],&l_120[2][1][1],&l_120[4][0][3],&l_120[2][1][1],&l_120[4][0][3],&l_120[2][1][1]};
    const uint32_t *l_147 = &g_50[0][0];
    const uint32_t **l_146[2][1][8] = {{{&l_147,&l_147,&l_147,&l_147,&l_147,&l_147,&l_147,&l_147}},{{&l_147,&l_147,&l_147,&l_147,&l_147,&l_147,&l_147,&l_147}}};
    int32_t l_200 = 0x334360CAL;
    uint16_t l_380 = 65535UL;
    uint8_t l_383[1][6] = {{5UL,5UL,5UL,5UL,5UL,5UL}};
    const uint32_t l_410 = 1UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_65[i] = &g_5;
lbl_349:
    l_65[0] = l_65[0];
    for (g_42 = 0; (g_42 <= 0); g_42 += 1)
    { /* block id: 22 */
        uint32_t *l_68 = &g_50[0][0];
        uint16_t *l_83 = &g_80;
        const int32_t l_87[3][7][8] = {{{(-8L),0x7C2B18C8L,2L,0L,(-1L),0xB194E899L,1L,0x027EA7EAL},{1L,(-1L),1L,(-1L),1L,(-1L),1L,0L},{0x2E4B4840L,(-2L),(-1L),0x10B7D5E3L,(-8L),0xF426174FL,(-1L),0x2A635BD1L},{(-6L),0x613E184AL,0x6167B9C7L,(-8L),(-8L),0x4CF74835L,(-1L),(-1L)},{0x2E4B4840L,(-8L),0xAFC50B83L,0x2A635BD1L,1L,0x1A7339E9L,0x732ED884L,1L},{1L,0xAFC50B83L,0xDBA83BDBL,(-3L),(-1L),(-10L),6L,0x8A8B4E14L},{(-8L),1L,0x4D9C5E16L,0xF426174FL,(-2L),(-9L),1L,0xB194E899L}},{{0x90C02A0DL,0x2F9381BCL,0x608A7AA0L,3L,(-2L),0xDCF828E4L,(-8L),0x4D9C5E16L},{(-8L),0x6167B9C7L,0xB194E899L,(-3L),0x01DA63D7L,(-1L),0xDABF61A3L,(-1L)},{0xC91E5470L,0L,1L,0x732ED884L,0x4CF74835L,(-9L),1L,0x5EFDD839L},{0xB194E899L,0xD3C8015BL,0x10B7D5E3L,(-2L),(-2L),9L,0x613E184AL,0xA88EB8B4L},{(-9L),(-8L),1L,1L,(-8L),(-8L),1L,1L},{(-6L),(-6L),0x6167B9C7L,0x4D9C5E16L,(-10L),0x82F7292FL,0L,0x1A7339E9L},{(-3L),0x2F9381BCL,0xF426174FL,0L,0x732ED884L,0x7C2B18C8L,(-1L),0x1A7339E9L}},{{0x2F9381BCL,0x027EA7EAL,1L,0x4D9C5E16L,1L,1L,9L,1L},{1L,0xC4FF8C8FL,(-1L),1L,6L,1L,0xDF8BF216L,0xA88EB8B4L},{0xE4CDB194L,(-1L),(-1L),(-2L),0x027EA7EAL,1L,0xAFC50B83L,0x5EFDD839L},{1L,0xA88EB8B4L,(-3L),0x732ED884L,(-8L),0xB8780EC7L,6L,(-1L)},{1L,1L,(-1L),(-3L),1L,0xC91E5470L,(-8L),0x4D9C5E16L},{0xD3C8015BL,(-10L),1L,1L,(-1L),0x80BABE52L,0x2A635BD1L,(-1L)},{0x83983135L,0x608A7AA0L,0x9CAF05E3L,0xC4FF8C8FL,0x2F9381BCL,1L,1L,1L}}};
        int32_t l_100 = (-10L);
        int32_t l_102[5][8][6] = {{{0x3AB17D80L,0x3AB17D80L,0x05AE1FFEL,0x532EA630L,0x19A621B4L,0L},{0x532EA630L,0x19A621B4L,0L,1L,0x11454E63L,0x05AE1FFEL},{(-6L),0x532EA630L,0L,(-1L),0x3AB17D80L,0L},{2L,(-1L),0x05AE1FFEL,0x2C9DD34EL,(-6L),0L},{0x2C9DD34EL,(-6L),0L,(-6L),0x2C9DD34EL,0x05AE1FFEL},{0x19A621B4L,0x11454E63L,0L,0x3AB17D80L,(-1L),0L},{(-1L),2L,0x05AE1FFEL,0x11454E63L,1L,0L},{0x11454E63L,1L,0L,0x19A621B4L,0x532EA630L,0x05AE1FFEL}},{{1L,0x2C9DD34EL,0L,2L,2L,0L},{0x3AB17D80L,0x3AB17D80L,0x05AE1FFEL,0x532EA630L,0x19A621B4L,0L},{0x532EA630L,0x19A621B4L,0L,1L,0x11454E63L,0x05AE1FFEL},{(-6L),0x532EA630L,0L,(-1L),0x3AB17D80L,0L},{2L,(-1L),0x05AE1FFEL,0x2C9DD34EL,(-6L),0L},{0x2C9DD34EL,(-6L),0L,(-6L),0x2C9DD34EL,2L},{1L,(-9L),(-1L),0L,7L,(-1L)},{7L,0x02FE3867L,2L,(-9L),0L,(-1L)}},{{(-9L),0L,(-1L),1L,0L,2L},{0L,0x38C270E2L,(-1L),0x02FE3867L,0x02FE3867L,(-1L)},{0L,0L,2L,0L,1L,(-1L)},{0L,1L,(-1L),0L,(-9L),2L},{0L,0L,(-1L),7L,0L,(-1L)},{0x02FE3867L,7L,2L,0x38C270E2L,0L,(-1L)},{0x38C270E2L,0L,(-1L),0L,0x38C270E2L,2L},{1L,(-9L),(-1L),0L,7L,(-1L)}},{{7L,0x02FE3867L,2L,(-9L),0L,(-1L)},{(-9L),0L,(-1L),1L,0L,2L},{0L,0x38C270E2L,(-1L),0x02FE3867L,0x02FE3867L,(-1L)},{0L,0L,2L,0L,1L,(-1L)},{0L,1L,(-1L),0L,(-9L),2L},{0L,0L,(-1L),7L,0L,(-1L)},{0x02FE3867L,7L,2L,0x38C270E2L,0L,(-1L)},{0x38C270E2L,0L,(-1L),0L,0x38C270E2L,2L}},{{1L,(-9L),(-1L),0L,7L,(-1L)},{7L,0x02FE3867L,2L,(-9L),0L,(-1L)},{(-9L),0L,(-1L),1L,0L,2L},{0L,0x38C270E2L,(-1L),0x02FE3867L,0x02FE3867L,(-1L)},{0L,0L,2L,0L,1L,(-1L)},{0L,1L,(-1L),0L,(-9L),2L},{0L,0L,(-1L),7L,0L,(-1L)},{0x02FE3867L,7L,2L,0x38C270E2L,0L,(-1L)}}};
        int32_t *l_128 = &l_102[4][5][2];
        uint32_t **l_172 = &l_68;
        int32_t l_207 = 0L;
        int32_t *l_233[1][9] = {{&g_3,(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3,(void*)0,&g_3}};
        const int32_t *l_267 = &l_100;
        const uint64_t l_301 = 0UL;
        uint16_t l_309 = 0x6E84L;
        uint16_t l_397 = 0xFC8EL;
        int8_t l_432 = 0x5AL;
        uint16_t l_438[4];
        uint8_t *l_451 = &l_383[0][1];
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_438[i] = 65535UL;
        for (g_53 = 0; (g_53 >= 0); g_53 -= 1)
        { /* block id: 25 */
            int i, j;
            if (g_50[g_53][g_53])
                break;
        }
        for (g_53 = 0; (g_53 <= 0); g_53 += 1)
        { /* block id: 30 */
            uint32_t **l_69[6][1] = {{(void*)0},{&l_68},{(void*)0},{&l_68},{(void*)0},{&l_68}};
            uint16_t *l_79 = &g_80;
            int32_t l_89 = (-3L);
            int32_t l_90 = 1L;
            int32_t l_104 = 1L;
            int32_t l_105 = 0xC81C1E56L;
            int32_t l_106 = 0x5156C434L;
            int32_t l_107 = 0x63B9AFEEL;
            int32_t l_108 = 0xD86CB6A1L;
            int32_t l_109 = 0xC88D01BAL;
            int32_t l_110 = 0x4CE2B894L;
            uint32_t l_160 = 1UL;
            int64_t *l_196 = &g_150;
            int32_t *l_212[3][3][9] = {{{&l_108,&l_90,&g_88,(void*)0,&g_5,&g_88,&l_108,&l_90,&l_90},{(void*)0,&l_106,&g_88,&g_99[5],&g_99[5],&g_88,&l_106,(void*)0,&l_90},{&l_90,(void*)0,(void*)0,&g_99[3],&l_105,(void*)0,&g_3,&l_102[4][5][2],&g_5}},{{&l_102[4][5][2],&g_3,(void*)0,&l_105,&g_99[3],(void*)0,(void*)0,&l_109,&g_5},{&g_88,&l_89,(void*)0,&g_5,&g_5,(void*)0,&l_89,&g_88,&g_5},{&l_109,(void*)0,(void*)0,&g_99[3],&l_105,(void*)0,&g_3,&l_102[4][5][2],&g_5}},{{&l_102[4][5][2],&g_3,(void*)0,&l_105,&g_99[3],(void*)0,(void*)0,&l_109,&g_5},{&g_88,&l_89,(void*)0,&g_5,&g_5,(void*)0,&l_89,&g_88,&g_5},{&l_109,(void*)0,(void*)0,&g_99[3],&l_105,(void*)0,&g_3,&l_102[4][5][2],&g_5}}};
            int16_t l_261 = 0xB4F1L;
            const int32_t *l_266 = &l_108;
            int32_t l_271 = 0xAEBD4348L;
            int8_t l_275 = (-1L);
            int32_t l_303[8] = {0x69560D00L,0x69560D00L,0L,0x69560D00L,0x69560D00L,0L,0x69560D00L,0x69560D00L};
            int i, j, k;
            if (g_50[g_42][g_53])
                break;
        }
        ++l_309;
        (*l_128) = 0x4E7BD40FL;
        for (g_88 = 0; (g_88 <= 0); g_88 += 1)
        { /* block id: 155 */
            uint64_t *l_316 = &g_73;
            int8_t *l_319 = &g_42;
            int64_t *l_340[7] = {&g_341,&g_341,&g_341,&g_341,&g_341,&g_341,&g_341};
            const struct S0 *l_342[10][2][5] = {{{(void*)0,&g_343,&g_343,(void*)0,&g_343},{&g_343,&g_343,&g_343,(void*)0,(void*)0}},{{(void*)0,&g_343,&g_343,&g_343,(void*)0},{&g_343,&g_343,&g_343,&g_343,&g_343}},{{(void*)0,&g_343,&g_343,&g_343,(void*)0},{(void*)0,(void*)0,&g_343,&g_343,&g_343}},{{&g_343,(void*)0,&g_343,&g_343,(void*)0},{&g_343,&g_343,&g_343,&g_343,&g_343}},{{(void*)0,&g_343,&g_343,(void*)0,(void*)0},{(void*)0,&g_343,&g_343,&g_343,(void*)0}},{{&g_343,(void*)0,&g_343,&g_343,&g_343},{&g_343,(void*)0,&g_343,&g_343,&g_343}},{{&g_343,&g_343,&g_343,(void*)0,(void*)0},{&g_343,&g_343,&g_343,&g_343,(void*)0}},{{&g_343,&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343,&g_343}},{{&g_343,&g_343,&g_343,&g_343,&g_343},{(void*)0,&g_343,&g_343,&g_343,&g_343}},{{(void*)0,(void*)0,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,(void*)0,&g_343}}};
            int32_t l_381 = 6L;
            int32_t l_382 = 0xC73C10BFL;
            int32_t l_385 = 0x0F98DF71L;
            int32_t l_423 = 0x69E3CBB9L;
            int32_t l_424 = 0x9F73D431L;
            int32_t l_425 = (-6L);
            int32_t l_426[10][9] = {{1L,0xE41F998BL,0x3A8B1174L,0L,0xE8C1B522L,0xE8C1B522L,0L,0x3A8B1174L,0xE41F998BL},{0L,(-1L),0x3A8B1174L,8L,0xCE52C00EL,0xFA2BA1A4L,0xE8C1B522L,0x63E8492AL,0x63E8492AL},{0xE41F998BL,8L,0xFA2BA1A4L,(-1L),0xFA2BA1A4L,8L,0xE41F998BL,0xFA2BA1A4L,0x63E8492AL},{0x3A8B1174L,0xCE52C00EL,0x0F89DCA0L,0xA72B958CL,0xFA2BA1A4L,0x0F89DCA0L,0xE8C1B522L,0x0F89DCA0L,0xFA2BA1A4L},{0x3A8B1174L,0xFA2BA1A4L,0xFA2BA1A4L,0x3A8B1174L,0xCE52C00EL,0x0F89DCA0L,0xA72B958CL,0xFA2BA1A4L,0x0F89DCA0L},{0xE41F998BL,0xFA2BA1A4L,0x63E8492AL,0xA72B958CL,8L,8L,0xA72B958CL,0x63E8492AL,0xFA2BA1A4L},{0xA72B958CL,0xCE52C00EL,0x63E8492AL,(-1L),0xCE52C00EL,0xFA2BA1A4L,0xE8C1B522L,0x63E8492AL,0x63E8492AL},{0xE41F998BL,8L,0xFA2BA1A4L,(-1L),0xFA2BA1A4L,8L,0xE41F998BL,0xFA2BA1A4L,0x63E8492AL},{0x3A8B1174L,0xCE52C00EL,0x0F89DCA0L,0xA72B958CL,0xFA2BA1A4L,0x0F89DCA0L,0xE8C1B522L,0x0F89DCA0L,0xFA2BA1A4L},{0x3A8B1174L,0xFA2BA1A4L,0xFA2BA1A4L,0x3A8B1174L,0xCE52C00EL,0x0F89DCA0L,0xA72B958CL,0xFA2BA1A4L,0x0F89DCA0L}};
            int i, j, k;
            g_344 ^= (safe_rshift_func_int8_t_s_u((safe_div_func_uint64_t_u_u(((*l_316)++), ((l_319 == (g_50[g_88][g_88] , (((safe_add_func_int8_t_s_s((g_50[g_88][g_88] || (safe_mul_func_int16_t_s_s((safe_sub_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(65535UL, g_88)), (((safe_lshift_func_uint8_t_u_s((safe_sub_func_int64_t_s_s((g_150 = g_50[g_88][g_88]), (~(g_341 = ((*l_128) = ((g_95.f1 != (((*l_83) = g_50[g_88][g_88]) > (safe_sub_func_int8_t_s_s(((safe_add_func_int64_t_s_s((safe_lshift_func_int8_t_s_s(((+g_42) , g_50[g_88][g_88]), 4)), g_50[g_88][g_88])) , 0xC8L), g_99[3])))) >= g_3)))))), 0)) , l_342[2][0][1]) != &g_343))), g_47[2][0]))), g_50[g_88][g_88])) == 0L) , (void*)0))) | g_343.f2))), 7));
            for (g_308 = 0; (g_308 <= 0); g_308 += 1)
            { /* block id: 164 */
                int32_t *l_345 = &g_88;
                uint32_t l_396 = 1UL;
                const uint8_t l_399 = 249UL;
                int32_t l_421 = (-6L);
                int32_t l_427 = 0x576991DBL;
                int32_t l_430 = (-4L);
                int32_t l_431 = 0x5B7C3415L;
                int64_t l_435[8];
                int32_t l_436 = 0xB51DFA58L;
                int32_t l_437 = 0xEED9A085L;
                const uint8_t *l_454 = &g_455;
                int i;
                for (i = 0; i < 8; i++)
                    l_435[i] = 0x12FFA43271216119LL;
                for (g_80 = 0; (g_80 <= 0); g_80 += 1)
                { /* block id: 167 */
                    int32_t *l_346 = &g_99[4];
                    l_346 = l_345;
                    if (((*l_345) > (-1L)))
                    { /* block id: 169 */
                        (*g_348) = g_347[2][1][1];
                        return g_4;
                    }
                    else
                    { /* block id: 172 */
                        int8_t l_373 = 0x08L;
                        uint16_t *l_374 = (void*)0;
                        uint16_t *l_375 = (void*)0;
                        uint16_t *l_376 = &g_278[0];
                        int32_t l_377 = 0xB07585F6L;
                        int8_t *l_378 = (void*)0;
                        int8_t *l_379 = &g_53;
                        uint32_t l_384 = 0xE91A2BF8L;
                        uint16_t *l_390 = (void*)0;
                        uint16_t *l_391 = &l_380;
                        int i, j;
                        if (g_80)
                            goto lbl_349;
                        l_385 ^= (((safe_div_func_int32_t_s_s((((g_50[g_88][g_42] = (((g_95 , (l_382 = (((!(l_381 ^= (safe_sub_func_int16_t_s_s(((((*l_379) = (safe_div_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u(249UL, 4)) || ((*l_376) = (((*l_316) = ((~(((*p_63) <= ((*l_128) ^= (safe_sub_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((safe_add_func_uint16_t_u_u(65528UL, 65535UL)), (safe_mod_func_int64_t_s_s((l_373 &= (safe_unary_minus_func_int32_t_s((safe_add_func_int32_t_s_s((*l_346), 0x2DD229F5L))))), g_95.f3)))), (*l_267))))) && g_278[0])) , 0x7705E78ADEB62D90LL)) <= (*l_345)))), l_377))) & l_380) ^ (*l_346)), (*l_346))))) == (*p_63)) > (*l_345)))) && 0UL) > l_383[0][1])) | 0xC59360F6L) , l_384), 0xC35681CDL)) >= 0UL) , g_50[g_88][g_88]);
                        (*l_128) ^= ((safe_mul_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s((*l_345), ((((*l_391) &= g_278[0]) > (((((safe_mod_func_uint16_t_u_u(((*l_345) < (((void*)0 == &l_383[0][1]) > (g_398 = (+((0x12AFL | (~((*l_345) <= (l_396 , (*l_346))))) , l_397))))), l_381)) , g_341) >= (*l_345)) , (void*)0) == (void*)0)) & (*p_63)))) != l_399), 0L)) & g_157);
                        if (l_382)
                            break;
                    }
                    l_385 &= (g_99[3] > (safe_rshift_func_uint16_t_u_u((*l_345), ((((g_300 > (safe_div_func_int8_t_s_s(((l_382 = ((safe_lshift_func_uint8_t_u_u((g_95 , ((safe_mod_func_int64_t_s_s(g_343.f3, g_50[0][0])) && (safe_rshift_func_uint16_t_u_u(l_410, 8)))), 4)) != ((((safe_div_func_int32_t_s_s((g_50[g_88][g_88] & ((g_47[2][0] = (safe_add_func_int8_t_s_s((((safe_rshift_func_uint16_t_u_s(((*l_346) & g_99[3]), (*l_345))) <= (*l_345)) | 0xDB0BE6F6L), 9L))) , (*l_345))), (*g_76))) <= 0x09C7L) | (*g_94)) | (*p_63)))) , 0x5EL), 255UL))) > 0xC2L) || g_80) , g_99[3]))));
                }
                if ((*l_345))
                    continue;
                for (g_398 = 0; (g_398 <= 0); g_398 += 1)
                { /* block id: 195 */
                    int32_t l_420 = 1L;
                    int32_t l_422[2];
                    uint32_t l_441[1];
                    const uint8_t *l_453 = (void*)0;
                    const uint8_t **l_452[7][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_453},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_453,(void*)0}};
                    int i, j;
                    for (i = 0; i < 2; i++)
                        l_422[i] = (-1L);
                    for (i = 0; i < 1; i++)
                        l_441[i] = 4UL;
                    for (g_305 = 0; (g_305 <= 0); g_305 += 1)
                    { /* block id: 198 */
                        uint64_t l_417 = 18446744073709551615UL;
                        int32_t l_428 = 0x1923FF9EL;
                        int32_t l_429[6] = {0x0ED2A0CBL,0x0ED2A0CBL,0xDB2A84B3L,0x0ED2A0CBL,0x0ED2A0CBL,0xDB2A84B3L};
                        int64_t l_433 = 0xA823E3F5EADF96A1LL;
                        int64_t l_434[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_434[i] = 0x08BCBC31C008BFA1LL;
                        (*l_128) &= g_50[g_88][g_88];
                        l_417--;
                        ++l_438[3];
                        return l_441[0];
                    }
                    l_420 = (safe_sub_func_uint16_t_u_u(((g_95.f1 , ((safe_add_func_uint8_t_u_u(((safe_rshift_func_int8_t_s_u((((g_344 |= ((*l_345) && (safe_sub_func_int32_t_s_s(((l_426[9][5] , (((g_450 , l_451) != (l_454 = &g_305)) || (safe_sub_func_uint8_t_u_u((g_458 , g_278[0]), (((g_88 != l_382) , (*p_63)) != (*g_76)))))) < (*l_345)), g_50[g_88][g_88])))) || 0x16DC7B25L) ^ (**g_254)), g_5)) || l_423), 0xC8L)) & l_422[0])) && g_450.f4), g_157));
                }
            }
        }
    }
    if (g_343.f3)
        goto lbl_349;
    return g_398;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_47[i][j], "g_47[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_50[i][j], "g_50[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_95.f0, "g_95.f0", print_hash_value);
    transparent_crc(g_95.f1, "g_95.f1", print_hash_value);
    transparent_crc(g_95.f2, "g_95.f2", print_hash_value);
    transparent_crc(g_95.f3, "g_95.f3", print_hash_value);
    transparent_crc(g_95.f4, "g_95.f4", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_99[i], "g_99[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_278[i], "g_278[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_300, "g_300", print_hash_value);
    transparent_crc(g_305, "g_305", print_hash_value);
    transparent_crc(g_308, "g_308", print_hash_value);
    transparent_crc(g_341, "g_341", print_hash_value);
    transparent_crc(g_343.f0, "g_343.f0", print_hash_value);
    transparent_crc(g_343.f1, "g_343.f1", print_hash_value);
    transparent_crc(g_343.f2, "g_343.f2", print_hash_value);
    transparent_crc(g_343.f3, "g_343.f3", print_hash_value);
    transparent_crc(g_344, "g_344", print_hash_value);
    transparent_crc(g_398, "g_398", print_hash_value);
    transparent_crc(g_450.f0, "g_450.f0", print_hash_value);
    transparent_crc(g_450.f1, "g_450.f1", print_hash_value);
    transparent_crc(g_450.f2, "g_450.f2", print_hash_value);
    transparent_crc(g_450.f3, "g_450.f3", print_hash_value);
    transparent_crc(g_450.f4, "g_450.f4", print_hash_value);
    transparent_crc(g_455, "g_455", print_hash_value);
    transparent_crc(g_458.f0, "g_458.f0", print_hash_value);
    transparent_crc(g_458.f1, "g_458.f1", print_hash_value);
    transparent_crc(g_458.f2, "g_458.f2", print_hash_value);
    transparent_crc(g_458.f3, "g_458.f3", print_hash_value);
    transparent_crc(g_458.f4, "g_458.f4", print_hash_value);
    transparent_crc(g_475, "g_475", print_hash_value);
    transparent_crc(g_568.f0, "g_568.f0", print_hash_value);
    transparent_crc(g_568.f1, "g_568.f1", print_hash_value);
    transparent_crc(g_568.f2, "g_568.f2", print_hash_value);
    transparent_crc(g_568.f3, "g_568.f3", print_hash_value);
    transparent_crc(g_582, "g_582", print_hash_value);
    transparent_crc(g_686, "g_686", print_hash_value);
    transparent_crc(g_882.f0, "g_882.f0", print_hash_value);
    transparent_crc(g_882.f1, "g_882.f1", print_hash_value);
    transparent_crc(g_882.f2, "g_882.f2", print_hash_value);
    transparent_crc(g_882.f3, "g_882.f3", print_hash_value);
    transparent_crc(g_882.f4, "g_882.f4", print_hash_value);
    transparent_crc(g_900, "g_900", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_935[i].f0, "g_935[i].f0", print_hash_value);
        transparent_crc(g_935[i].f1, "g_935[i].f1", print_hash_value);
        transparent_crc(g_935[i].f2, "g_935[i].f2", print_hash_value);
        transparent_crc(g_935[i].f3, "g_935[i].f3", print_hash_value);
        transparent_crc(g_935[i].f4, "g_935[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_979.f0, "g_979.f0", print_hash_value);
    transparent_crc(g_979.f1, "g_979.f1", print_hash_value);
    transparent_crc(g_979.f2, "g_979.f2", print_hash_value);
    transparent_crc(g_979.f3, "g_979.f3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1032[i][j].f0, "g_1032[i][j].f0", print_hash_value);
            transparent_crc(g_1032[i][j].f1, "g_1032[i][j].f1", print_hash_value);
            transparent_crc(g_1032[i][j].f2, "g_1032[i][j].f2", print_hash_value);
            transparent_crc(g_1032[i][j].f3, "g_1032[i][j].f3", print_hash_value);
            transparent_crc(g_1032[i][j].f4, "g_1032[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1061, "g_1061", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1062[i], "g_1062[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1126.f0, "g_1126.f0", print_hash_value);
    transparent_crc(g_1126.f1, "g_1126.f1", print_hash_value);
    transparent_crc(g_1126.f2, "g_1126.f2", print_hash_value);
    transparent_crc(g_1126.f3, "g_1126.f3", print_hash_value);
    transparent_crc(g_1126.f4, "g_1126.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 290
   depth: 1, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 37
breakdown:
   depth: 1, occurrence: 144
   depth: 2, occurrence: 47
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 6, occurrence: 2
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 4
   depth: 21, occurrence: 4
   depth: 22, occurrence: 1
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 2
   depth: 28, occurrence: 2
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 2
   depth: 34, occurrence: 1
   depth: 37, occurrence: 1

XXX total number of pointers: 230

XXX times a variable address is taken: 807
XXX times a pointer is dereferenced on RHS: 154
breakdown:
   depth: 1, occurrence: 119
   depth: 2, occurrence: 33
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 135
breakdown:
   depth: 1, occurrence: 124
   depth: 2, occurrence: 6
   depth: 3, occurrence: 5
XXX times a pointer is compared with null: 27
XXX times a pointer is compared with address of another variable: 4
XXX times a pointer is compared with another pointer: 2
XXX times a pointer is qualified to be dereferenced: 4153

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 538
   level: 2, occurrence: 94
   level: 3, occurrence: 22
XXX number of pointers point to pointers: 70
XXX number of pointers point to scalars: 149
XXX number of pointers point to structs: 11
XXX percent of pointers has null in alias set: 34.3
XXX average alias set size: 1.57

XXX times a non-volatile is read: 892
XXX times a non-volatile is write: 437
XXX times a volatile is read: 61
XXX    times read thru a pointer: 5
XXX times a volatile is write: 18
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 2.38e+03
XXX percentage of non-volatile access: 94.4

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 160
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 22
   depth: 2, occurrence: 22
   depth: 3, occurrence: 26
   depth: 4, occurrence: 25
   depth: 5, occurrence: 36

XXX percentage a fresh-made variable is used: 17.7
XXX percentage an existing variable is used: 82.3
********************* end of statistics **********************/

