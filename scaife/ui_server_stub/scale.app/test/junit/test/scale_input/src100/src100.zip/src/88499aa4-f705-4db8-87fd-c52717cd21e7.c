/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      4229948974
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const int64_t g_2 = 0xD8C45CDBE8E56F9BLL;
static int32_t g_4 = (-5L);
static int32_t * volatile g_3 = &g_4;/* VOLATILE GLOBAL g_3 */
static uint32_t g_74 = 0UL;
static uint16_t g_95 = 0x66FFL;
static uint16_t g_98 = 0x5549L;
static uint16_t *g_97[7][4] = {{&g_98,&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98,(void*)0},{&g_98,&g_98,&g_98,&g_98},{&g_98,(void*)0,&g_98,&g_98},{&g_98,&g_98,&g_98,(void*)0},{(void*)0,&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98,&g_98}};
static int16_t g_101 = (-3L);
static int8_t g_104 = 1L;
static uint8_t g_107 = 252UL;
static const int16_t g_123 = (-3L);
static int16_t g_128 = (-1L);
static uint8_t g_157 = 255UL;
static int64_t g_188 = 0x791890F00B84BF07LL;
static int32_t g_211 = 0x02CC8EEDL;
static int32_t g_261 = 0xD101BBB7L;
static int64_t g_277 = (-1L);
static int16_t *g_282 = &g_128;
static int16_t **g_281 = &g_282;
static uint16_t g_294 = 0xDF46L;
static volatile int8_t g_317 = 1L;/* VOLATILE GLOBAL g_317 */
static volatile int8_t * volatile g_316 = &g_317;/* VOLATILE GLOBAL g_316 */
static volatile int8_t * volatile *g_315 = &g_316;
static volatile int8_t * volatile * volatile *g_314[7][2][7] = {{{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315},{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315}},{{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315},{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315}},{{&g_315,&g_315,(void*)0,&g_315,(void*)0,(void*)0,&g_315},{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315}},{{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315},{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315}},{{(void*)0,&g_315,&g_315,(void*)0,&g_315,(void*)0,(void*)0},{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315}},{{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315},{&g_315,&g_315,(void*)0,(void*)0,&g_315,&g_315,&g_315}},{{&g_315,&g_315,&g_315,&g_315,&g_315,&g_315,&g_315},{&g_315,(void*)0,&g_315,&g_315,&g_315,(void*)0,&g_315}}};
static volatile int8_t * volatile * volatile **g_313 = &g_314[0][0][2];
static int32_t *g_320[2][4] = {{&g_211,&g_4,&g_211,&g_211},{&g_4,&g_4,(void*)0,&g_4}};
static uint32_t g_345 = 4294967295UL;
static uint64_t g_353 = 0xDCA199E2A63C7AB3LL;
static volatile int64_t **g_386[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int8_t g_399 = 0xE0L;
static volatile uint8_t g_415 = 0xA0L;/* VOLATILE GLOBAL g_415 */
static volatile uint8_t * volatile g_414 = &g_415;/* VOLATILE GLOBAL g_414 */
static volatile uint8_t * volatile *g_413 = &g_414;
static int64_t *g_474 = &g_277;
static int64_t g_496[4][6] = {{0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L),0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L)},{0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L),0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L)},{0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L),0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L)},{0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L),0xEC91765399F3969ALL,0xEC91765399F3969ALL,(-1L)}};
static int16_t * volatile * volatile g_507 = &g_282;/* VOLATILE GLOBAL g_507 */
static int16_t * volatile * volatile *g_506 = &g_507;
static uint16_t g_513 = 1UL;
static const uint8_t g_576[7][5][4] = {{{0xBEL,6UL,255UL,0x49L},{6UL,0x11L,0x11L,6UL},{249UL,0x49L,0x11L,0xC6L},{6UL,0xBEL,255UL,0xBEL},{0xBEL,0x11L,249UL,0xBEL}},{{249UL,0xBEL,0xC6L,0xC6L},{0x49L,0x49L,255UL,6UL},{0x49L,0x11L,0xC6L,0x49L},{249UL,6UL,249UL,0xC6L},{0xBEL,6UL,255UL,0x49L}},{{6UL,0x11L,0x11L,6UL},{249UL,0x49L,0x11L,0xC6L},{6UL,0xBEL,255UL,0xBEL},{0xBEL,0x11L,249UL,0xBEL},{249UL,0xBEL,0xC6L,0xC6L}},{{0x49L,0x49L,255UL,6UL},{0x49L,0x11L,0xC6L,0x49L},{249UL,6UL,249UL,0x49L},{0xC6L,0x11L,0x49L,249UL},{0x11L,255UL,255UL,0x11L}},{{1UL,249UL,255UL,0x49L},{0x11L,0xC6L,0x49L,0xC6L},{0xC6L,255UL,1UL,0xC6L},{1UL,0xC6L,0x49L,0x49L},{249UL,249UL,0x49L,0x11L}},{{249UL,255UL,0x49L,249UL},{1UL,0x11L,1UL,0x49L},{0xC6L,0x11L,0x49L,249UL},{0x11L,255UL,255UL,0x11L},{1UL,249UL,255UL,0x49L}},{{0x11L,0xC6L,0x49L,0xC6L},{0xC6L,255UL,1UL,0xC6L},{1UL,0xC6L,0x49L,0x49L},{249UL,249UL,0x49L,0x11L},{249UL,255UL,0x49L,249UL}}};
static uint32_t *g_645 = &g_345;
static uint32_t **g_644 = &g_645;
static uint8_t * const *g_652 = (void*)0;
static int8_t g_670 = 1L;
static int32_t **g_739 = &g_320[1][3];
static uint32_t g_872 = 9UL;
static const int64_t *g_926 = &g_496[0][5];
static const int64_t **g_925[9] = {&g_926,&g_926,&g_926,&g_926,&g_926,&g_926,&g_926,&g_926,&g_926};
static const int64_t ***g_924 = &g_925[4];
static uint8_t g_946 = 0x09L;
static int16_t g_947 = (-1L);
static const uint16_t g_978 = 0x4D1EL;
static const uint16_t g_980 = 0UL;
static int32_t *g_984[10][4] = {{(void*)0,&g_261,&g_4,&g_4},{&g_261,&g_261,&g_261,&g_4},{&g_4,&g_261,&g_261,&g_261},{&g_4,(void*)0,&g_211,&g_4},{&g_4,&g_4,&g_4,&g_261},{&g_261,&g_4,&g_261,&g_4},{&g_261,&g_261,&g_4,&g_4},{&g_4,&g_4,&g_211,&g_211},{&g_4,&g_211,&g_261,(void*)0},{&g_4,(void*)0,&g_261,&g_261}};
static uint64_t g_1086 = 0xF3D140B282CCD542LL;
static uint8_t g_1107 = 0UL;
static const int32_t *g_1130 = &g_4;
static const int32_t ** volatile g_1129 = &g_1130;/* VOLATILE GLOBAL g_1129 */
static const int32_t ** volatile g_1148[8] = {&g_1130,&g_1130,(void*)0,&g_1130,&g_1130,(void*)0,&g_1130,&g_1130};
static int8_t *g_1300 = &g_670;
static int8_t **g_1299 = &g_1300;
static int8_t ***g_1298 = &g_1299;
static int8_t ****g_1297 = &g_1298;
static int8_t *****g_1296 = &g_1297;
static const uint32_t g_1367 = 18446744073709551615UL;
static uint32_t g_1457 = 0x5FF10995L;
static const uint64_t g_1470[10] = {0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL,0x3CECBCA1E9D0569BLL};
static int8_t g_1521 = (-1L);
static uint8_t g_1545 = 255UL;
static int8_t ***g_1564[8] = {&g_1299,&g_1299,&g_1299,&g_1299,&g_1299,&g_1299,&g_1299,&g_1299};
static int8_t **** const g_1563 = &g_1564[7];
static int8_t **** const *g_1562 = &g_1563;
static const int32_t ** volatile g_1568 = &g_1130;/* VOLATILE GLOBAL g_1568 */
static const int32_t ** volatile g_1570 = &g_1130;/* VOLATILE GLOBAL g_1570 */
static const int32_t ** volatile g_1711 = &g_1130;/* VOLATILE GLOBAL g_1711 */
static volatile uint16_t *g_1733 = (void*)0;
static volatile uint16_t * volatile *g_1732[4][9] = {{(void*)0,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,(void*)0,&g_1733},{&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733},{&g_1733,&g_1733,&g_1733,&g_1733,(void*)0,(void*)0,(void*)0,&g_1733,&g_1733},{(void*)0,(void*)0,&g_1733,&g_1733,&g_1733,&g_1733,&g_1733,(void*)0,(void*)0}};
static volatile uint16_t * volatile **g_1731[9][9][2] = {{{(void*)0,(void*)0},{(void*)0,&g_1732[1][5]},{&g_1732[0][4],(void*)0},{&g_1732[1][5],&g_1732[0][4]},{&g_1732[1][5],(void*)0},{&g_1732[0][2],(void*)0},{(void*)0,&g_1732[3][2]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],(void*)0}},{{&g_1732[0][0],(void*)0},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[3][2]},{(void*)0,(void*)0},{&g_1732[0][2],&g_1732[1][5]},{&g_1732[3][2],&g_1732[0][3]},{(void*)0,(void*)0},{&g_1732[0][3],&g_1732[1][5]},{&g_1732[3][1],&g_1732[3][1]}},{{&g_1732[0][0],&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],&g_1732[0][2]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[0][2]},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[1][5]}},{{&g_1732[0][0],&g_1732[3][1]},{&g_1732[3][1],&g_1732[1][5]},{&g_1732[0][3],(void*)0},{(void*)0,&g_1732[0][3]},{&g_1732[3][2],&g_1732[1][5]},{&g_1732[0][2],(void*)0},{(void*)0,&g_1732[3][2]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],(void*)0}},{{&g_1732[0][0],(void*)0},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[3][2]},{(void*)0,(void*)0},{&g_1732[0][2],&g_1732[1][5]},{&g_1732[3][2],&g_1732[0][3]},{(void*)0,(void*)0},{&g_1732[0][3],&g_1732[1][5]},{&g_1732[3][1],&g_1732[3][1]}},{{&g_1732[0][0],&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],&g_1732[0][2]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[0][2]},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[1][5]}},{{&g_1732[0][0],&g_1732[3][1]},{&g_1732[3][1],&g_1732[1][5]},{&g_1732[0][3],(void*)0},{(void*)0,&g_1732[0][3]},{&g_1732[3][2],&g_1732[1][5]},{&g_1732[0][2],(void*)0},{(void*)0,&g_1732[3][2]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],(void*)0}},{{&g_1732[0][0],(void*)0},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[3][2]},{(void*)0,(void*)0},{&g_1732[0][2],&g_1732[1][5]},{&g_1732[3][2],&g_1732[0][3]},{(void*)0,(void*)0},{&g_1732[0][3],&g_1732[1][5]},{&g_1732[3][1],&g_1732[3][1]}},{{&g_1732[0][0],&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{&g_1732[1][5],&g_1732[0][2]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[1][5]},{(void*)0,&g_1732[0][2]},{&g_1732[1][5],&g_1732[1][5]},{(void*)0,&g_1732[1][5]}}};
static volatile uint16_t * volatile *** const  volatile g_1730 = &g_1731[1][0][0];/* VOLATILE GLOBAL g_1730 */
static const int32_t **g_1796 = &g_1130;
static const int32_t ***g_1795[8] = {&g_1796,&g_1796,&g_1796,&g_1796,&g_1796,&g_1796,&g_1796,&g_1796};
static int32_t ***g_1818 = &g_739;
static uint32_t g_1823 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static const int32_t * func_5(uint8_t  p_6, uint64_t  p_7, int32_t * p_8, int32_t * p_9, int32_t * p_10);
static int8_t  func_12(uint16_t  p_13);
static uint16_t  func_14(uint16_t  p_15, uint16_t  p_16, int32_t  p_17, const int32_t * p_18);
static const uint8_t  func_22(int32_t * p_23, int32_t * p_24, int32_t  p_25, uint32_t  p_26);
static int32_t * func_28(uint32_t  p_29, uint16_t  p_30, int32_t  p_31, int16_t  p_32);
static uint8_t  func_37(uint64_t  p_38, int8_t  p_39, int32_t * const  p_40, const int32_t * p_41, int32_t  p_42);
static uint64_t  func_43(uint8_t  p_44);
static int8_t  func_55(uint8_t  p_56, uint32_t  p_57, int32_t  p_58, const int32_t  p_59, const int32_t * p_60);
static int8_t  func_62(uint32_t  p_63, int32_t * p_64, uint32_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_74 g_97 g_98 g_107 g_188 g_104 g_576 g_281 g_282 g_128 g_474 g_496 g_211 g_353 g_399 g_277 g_645 g_345 g_739 g_872 g_95 g_261 g_924 g_157 g_946 g_947 g_294 g_413 g_414 g_415 g_506 g_507 g_513 g_644 g_926 g_123 g_978 g_1086 g_315 g_316 g_317 g_670 g_1107 g_925 g_1711 g_1299 g_1300 g_1730 g_1470 g_1130 g_1297 g_1298 g_1795 g_1570 g_1823 g_1545 g_1818 g_1796
 * writes: g_4 g_74 g_95 g_107 g_188 g_320 g_98 g_104 g_157 g_281 g_739 g_294 g_353 g_474 g_211 g_399 g_101 g_128 g_277 g_496 g_872 g_261 g_924 g_946 g_984 g_345 g_1086 g_1107 g_947 g_1130 g_670 g_1795 g_1818 g_1545
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_19 = 65531UL;
    int32_t *l_27 = &g_4;
    int32_t **l_983[5];
    uint16_t l_1831 = 65535UL;
    int i;
    for (i = 0; i < 5; i++)
        l_983[i] = &g_320[0][2];
    (*g_3) = g_2;
    (*g_1796) = func_5((+func_12(func_14(l_19, l_19, ((safe_sub_func_int8_t_s_s((((func_22(l_27, &g_4, (*g_3), (l_27 != (g_984[5][1] = func_28((((safe_div_func_int8_t_s_s(0x10L, (safe_rshift_func_uint8_t_u_u(func_37(func_43(g_2), (*l_27), &g_4, l_27, g_2), (*l_27))))) | (-1L)) >= 6L), (*l_27), (*l_27), (*l_27))))) , (*l_27)) <= g_576[1][1][2]) >= g_123), 255UL)) , g_98), g_645))), l_1831, g_645, g_645, g_645);
    return (**g_281);
}


/* ------------------------------------------ */
/* 
 * reads : g_1107 g_1545 g_261 g_506 g_507 g_282 g_128 g_345 g_1818 g_739 g_1711 g_1130 g_1796 g_644 g_645
 * writes: g_1107 g_670 g_1545 g_345 g_320 g_1130 g_128 g_281
 */
static const int32_t * func_5(uint8_t  p_6, uint64_t  p_7, int32_t * p_8, int32_t * p_9, int32_t * p_10)
{ /* block id: 848 */
    uint32_t * const l_1852 = &g_1823;
    int32_t l_1853 = 0L;
    uint8_t l_1855 = 0x46L;
    int16_t * const *l_1861[5];
    int i;
    for (i = 0; i < 5; i++)
        l_1861[i] = &g_282;
    for (g_1107 = 15; (g_1107 > 51); g_1107++)
    { /* block id: 851 */
        uint8_t * const ** const l_1845 = &g_652;
        int32_t l_1854 = 0x73EB4008L;
        int32_t l_1858 = 0xA07975CBL;
        int16_t * const **l_1862 = &l_1861[2];
        int16_t ***l_1863 = &g_281;
        for (g_670 = 0; (g_670 != 29); ++g_670)
        { /* block id: 854 */
            uint8_t *l_1842 = &g_1545;
            (*p_10) ^= ((safe_div_func_uint64_t_u_u(3UL, (safe_rshift_func_uint16_t_u_s(((p_7 == (0xFEA7D226L > ((((*l_1842)++) <= (l_1845 != (void*)0)) , ((0x9FL < (0x3BB9L < ((safe_div_func_int16_t_s_s((safe_add_func_uint64_t_u_u(g_261, (safe_lshift_func_uint8_t_u_s(((l_1852 == (void*)0) != l_1853), l_1853)))), 0x18D3L)) , l_1853))) >= p_6)))) != 0x3ACEF17DL), (***g_506))))) != p_7);
            if (l_1853)
                continue;
        }
        (**g_1818) = p_8;
        (*g_1796) = (*g_1711);
        (*p_9) = ((((***g_506) = l_1854) > l_1855) == (((*p_8) && (l_1858 = (safe_lshift_func_int8_t_s_u(1L, 3)))) <= (safe_add_func_uint16_t_u_u((0x8ED51AF0L != (**g_644)), ((((*l_1862) = l_1861[2]) == ((*l_1863) = &g_282)) != p_7)))));
    }
    return (*g_1711);
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_1470 g_645 g_345 g_211 g_104 g_739 g_947 g_294 g_281 g_282 g_128 g_474 g_277 g_496 g_157 g_353 g_872 g_1130 g_4 g_507 g_1297 g_1298 g_1299 g_1300 g_644 g_414 g_415 g_1795 g_1570 g_315 g_316 g_317 g_1823 g_924 g_925 g_926
 * writes: g_74 g_320 g_211 g_277 g_496 g_128 g_670 g_946 g_1795 g_353 g_1818 g_947
 */
static int8_t  func_12(uint16_t  p_13)
{ /* block id: 813 */
    uint32_t l_1739 = 0x96920A0EL;
    int32_t l_1758 = (-1L);
    int32_t l_1761 = 1L;
    int32_t l_1762 = 2L;
    uint16_t **l_1773 = &g_97[4][3];
    uint16_t ***l_1772[7];
    int32_t l_1778 = 0x73BF2C96L;
    int32_t l_1779[9];
    uint64_t l_1809 = 1UL;
    int32_t ***l_1817 = &g_739;
    int16_t *l_1824 = (void*)0;
    int16_t *l_1825 = (void*)0;
    int16_t *l_1826 = &g_947;
    int64_t **l_1828[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t ***l_1827[2];
    const int16_t l_1829 = (-2L);
    int32_t *l_1830 = (void*)0;
    int i;
    for (i = 0; i < 7; i++)
        l_1772[i] = &l_1773;
    for (i = 0; i < 9; i++)
        l_1779[i] = 1L;
    for (i = 0; i < 2; i++)
        l_1827[i] = &l_1828[1];
    for (g_74 = 20; (g_74 == 42); ++g_74)
    { /* block id: 816 */
        int32_t *l_1737 = &g_211;
        int32_t *l_1738[2];
        int8_t ******l_1750 = &g_1296;
        uint16_t ***l_1774 = (void*)0;
        uint16_t l_1784 = 0xB397L;
        int i;
        for (i = 0; i < 2; i++)
            l_1738[i] = &g_261;
        --l_1739;
        if ((~p_13))
        { /* block id: 818 */
            int8_t ** const *l_1746 = &g_1299;
            int8_t ** const ** const l_1745[2] = {&l_1746,&l_1746};
            int8_t ** const ** const *l_1744 = &l_1745[0];
            int8_t ** const ** const **l_1743 = &l_1744;
            int8_t ** const ** const ***l_1747 = &l_1743;
            int8_t ** const ** const **l_1749 = (void*)0;
            int8_t ** const ** const ***l_1748 = &l_1749;
            int8_t *******l_1751 = &l_1750;
            uint16_t *l_1752[5][7] = {{&g_513,&g_95,&g_513,&g_294,&g_513,&g_95,&g_513},{&g_513,&g_95,&g_513,&g_294,&g_513,&g_95,&g_513},{&g_513,&g_95,&g_513,&g_294,&g_513,&g_513,&g_294},{&g_294,&g_513,&g_95,(void*)0,&g_95,&g_513,&g_294},{&g_294,&g_513,&g_95,(void*)0,&g_95,&g_513,&g_294}};
            int32_t l_1753 = (-3L);
            int i, j;
            (*g_739) = func_28(p_13, (l_1753 = (((*l_1748) = ((*l_1747) = l_1743)) != ((*l_1751) = l_1750))), g_1470[2], (safe_mul_func_uint16_t_u_u((l_1762 &= (l_1761 = ((safe_mul_func_int16_t_s_s(l_1758, (safe_div_func_uint8_t_u_u((l_1758 | (&g_313 != (void*)0)), (((*g_645) & (-10L)) , (*l_1737)))))) && 7UL))), 6L)));
        }
        else
        { /* block id: 826 */
            (*l_1737) = ((*l_1737) && p_13);
        }
        if ((*g_1130))
        { /* block id: 829 */
            uint8_t l_1765 = 255UL;
            int32_t l_1775 = (-1L);
            int32_t l_1776 = 0xA9FC77FCL;
            int32_t l_1777 = 0x54B14838L;
            int32_t l_1780 = (-1L);
            int32_t l_1781 = 1L;
            int32_t l_1782 = 8L;
            int32_t l_1783[6][7] = {{(-1L),(-1L),0xAE1D579EL,0x211D79FBL,0xA062A3D7L,0xA388897DL,(-1L)},{(-1L),6L,0xF7637D4EL,0xA062A3D7L,(-3L),(-3L),0xA062A3D7L},{0xED2413F5L,(-3L),0xED2413F5L,6L,0xA062A3D7L,0xED2413F5L,1L},{0xA062A3D7L,(-3L),4L,0x211D79FBL,(-3L),0xAE1D579EL,(-3L)},{1L,6L,6L,1L,1L,0xED2413F5L,0xA062A3D7L},{(-3L),(-1L),6L,0xF7637D4EL,0xA062A3D7L,(-3L),(-3L)}};
            uint8_t *l_1791 = (void*)0;
            uint8_t *l_1792[7][4] = {{&g_946,&g_946,(void*)0,&g_946},{&g_946,&g_946,&g_946,&g_946},{&g_946,&g_946,&g_946,&g_946},{&g_946,&g_946,(void*)0,&g_946},{&g_946,&g_946,&g_946,&g_946},{&g_946,&g_946,&g_946,&g_946},{&g_946,&g_946,(void*)0,&g_946}};
            const int32_t ***l_1798 = &g_1796;
            const int32_t ****l_1797 = &l_1798;
            uint64_t *l_1799 = &g_353;
            int i, j;
            (*l_1737) = (((**g_507) ^ (l_1765 = (+((((~l_1762) < ((****g_1297) = p_13)) , p_13) , (*l_1737))))) & ((safe_sub_func_int8_t_s_s((0x3FL == (0L < (((safe_mul_func_int16_t_s_s((l_1772[5] == l_1774), l_1775)) <= (**g_644)) != l_1775))), p_13)) , p_13));
            ++l_1784;
            (*l_1737) ^= (safe_mod_func_uint8_t_u_u((g_946 = (safe_lshift_func_uint8_t_u_u((*g_414), 2))), (safe_div_func_int64_t_s_s((((((((&g_739 == ((*l_1797) = (g_1795[5] = g_1795[5]))) != 0L) < (p_13 >= ((*l_1799)--))) < (safe_unary_minus_func_int64_t_s(0L))) | (safe_div_func_int64_t_s_s(p_13, (safe_lshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u((((void*)0 == &g_1296) == 255UL), 5)), 1))))) >= p_13) , l_1809), p_13))));
        }
        else
        { /* block id: 839 */
            int32_t *l_1810 = (void*)0;
            l_1810 = l_1737;
            if ((**g_1570))
                break;
        }
    }
    l_1779[0] ^= (~(((p_13 & l_1739) | (+((**g_315) == (((safe_sub_func_int64_t_s_s((safe_mod_func_uint64_t_u_u((g_128 > ((((g_1818 = l_1817) == (void*)0) , p_13) <= ((*l_1826) = (safe_sub_func_int64_t_s_s(p_13, (safe_mul_func_int8_t_s_s(p_13, g_1823))))))), (***g_924))), (-10L))) , l_1827[1]) == (void*)0)))) , l_1829));
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_128 g_978 g_345 g_1086 g_926 g_496 g_282 g_399 g_644 g_645 g_474 g_3 g_4 g_315 g_316 g_317 g_670 g_1107 g_739 g_946 g_353 g_924 g_925 g_1711 g_1299 g_1300 g_1730 g_104 g_947 g_211 g_294 g_281 g_277 g_157 g_872
 * writes: g_353 g_1086 g_104 g_277 g_496 g_4 g_946 g_1107 g_320 g_947 g_1130 g_211 g_128
 */
static uint16_t  func_14(uint16_t  p_15, uint16_t  p_16, int32_t  p_17, const int32_t * p_18)
{ /* block id: 482 */
    uint64_t *l_1080 = (void*)0;
    uint64_t *l_1081 = &g_353;
    uint32_t l_1082 = 0x400C6C5FL;
    uint64_t *l_1085 = &g_1086;
    int8_t * const **l_1091 = (void*)0;
    int32_t l_1095[10][10] = {{1L,(-1L),0x3A554310L,1L,3L,3L,1L,0x3A554310L,(-1L),1L},{0x3A554310L,0x5A08D4E7L,(-1L),3L,0x5A08D4E7L,3L,(-1L),0x5A08D4E7L,0x3A554310L,0x3A554310L},{1L,9L,0x09523B32L,0x5A08D4E7L,0x5A08D4E7L,0x09523B32L,9L,1L,0x09523B32L,1L},{0x5A08D4E7L,(-1L),3L,0x5A08D4E7L,3L,(-1L),0x5A08D4E7L,0x3A554310L,0x3A554310L,0x5A08D4E7L},{0x3A554310L,1L,3L,3L,1L,0x3A554310L,(-1L),1L,(-1L),0x3A554310L},{9L,1L,0x09523B32L,1L,9L,0x09523B32L,0x5A08D4E7L,0x5A08D4E7L,0x09523B32L,9L},{9L,(-1L),(-1L),9L,3L,0x3A554310L,9L,0x3A554310L,3L,9L},{0x3A554310L,9L,0x3A554310L,3L,9L,(-1L),(-1L),9L,3L,0x3A554310L},{0x5A08D4E7L,0x5A08D4E7L,0x09523B32L,9L,1L,0x09523B32L,1L,9L,0x09523B32L,0x5A08D4E7L},{1L,(-1L),0x3A554310L,1L,3L,3L,1L,0x3A554310L,(-1L),1L}};
    uint32_t l_1096 = 0x4B450833L;
    int64_t l_1097 = (-1L);
    int8_t *l_1098 = &g_104;
    int32_t *l_1099[7] = {(void*)0,&g_261,(void*)0,(void*)0,&g_261,&g_261,&g_261};
    uint8_t *l_1100 = &g_946;
    uint16_t l_1145 = 65529UL;
    const uint16_t l_1172 = 0x3A3DL;
    int16_t l_1173 = 0L;
    int32_t l_1179 = 0x33400BCBL;
    int32_t l_1191 = 0x27C92F1AL;
    uint16_t *** const l_1208 = (void*)0;
    uint64_t l_1275[10] = {0x6E28DA621C7FB4FDLL,0x6E28DA621C7FB4FDLL,0x0BE16E1CD2C2CC56LL,0x6E28DA621C7FB4FDLL,0x6E28DA621C7FB4FDLL,0x0BE16E1CD2C2CC56LL,0x6E28DA621C7FB4FDLL,0x6E28DA621C7FB4FDLL,0x0BE16E1CD2C2CC56LL,0x6E28DA621C7FB4FDLL};
    uint64_t l_1277 = 0x1B039BCDFA650268LL;
    int8_t *****l_1342[10][2] = {{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297},{&g_1297,&g_1297}};
    int64_t l_1358 = 0x31ECFB48BDDF6AB7LL;
    int16_t l_1438 = 0x8B2DL;
    int32_t **l_1444 = &g_320[1][2];
    uint64_t l_1459 = 18446744073709551615UL;
    uint32_t l_1714 = 0x6FE14BBDL;
    int64_t **l_1729 = &g_474;
    uint32_t l_1734[3][6] = {{0xEEF011EEL,4294967295UL,0xFF255158L,4294967295UL,0xEEF011EEL,0xEEF011EEL},{4294967292UL,4294967295UL,4294967295UL,4294967292UL,1UL,4294967292UL},{4294967292UL,1UL,4294967292UL,4294967295UL,4294967295UL,4294967292UL}};
    int i, j;
    if ((((safe_add_func_int8_t_s_s((safe_div_func_int8_t_s_s(((p_15 < ((*l_1100) = (((*g_3) ^= (safe_div_func_int8_t_s_s(((safe_sub_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(((safe_div_func_int8_t_s_s((g_128 && ((*g_474) = ((safe_sub_func_int64_t_s_s((safe_mul_func_int8_t_s_s((((*l_1081) = g_978) ^ (((*p_18) == (((l_1082 && (((((*l_1098) = (safe_sub_func_uint64_t_u_u((++(*l_1085)), ((safe_lshift_func_int16_t_s_u(((*g_926) | ((l_1082 , l_1091) == (((safe_mul_func_int8_t_s_s((((((l_1095[4][9] &= ((+0x62L) & 0x07L)) > l_1082) || l_1096) <= 0x7CL) & l_1097), 0x60L)) == (*g_282)) , (void*)0))), l_1097)) > l_1096)))) == 0x6CL) == g_399) , (**g_644))) , 4294967295UL) >= l_1097)) | p_16)), (-7L))), l_1097)) <= l_1082))), l_1082)) | 0xEE6EL), 0xEBDFL)), 8UL)) && p_17), 0xD2L))) < (*g_645)))) , (**g_315)), g_978)), p_17)) == p_15) <= g_670))
    { /* block id: 490 */
        uint32_t l_1101 = 18446744073709551615UL;
        int32_t l_1102 = 0x6056CDD7L;
        l_1102 &= ((*g_3) = (l_1101 = (*g_3)));
        g_1107 |= ((safe_rshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_u(1L, p_17)), 5)) == p_17);
    }
    else
    { /* block id: 495 */
        int32_t l_1108 = 0L;
        uint64_t l_1128 = 0xD73691B792A14C85LL;
        int32_t l_1133 = 9L;
        int32_t l_1134 = 0x41097AEAL;
        int32_t l_1135 = 0x1A3222D6L;
        int32_t l_1136[6][3] = {{0x8EC8A075L,0x8EC8A075L,0x1BDDA8DBL},{0L,0L,(-2L)},{0x8EC8A075L,0x8EC8A075L,0x1BDDA8DBL},{0L,0L,(-2L)},{0x8EC8A075L,0x8EC8A075L,0x1BDDA8DBL},{0L,0L,(-2L)}};
        uint16_t l_1194[10] = {65529UL,0x02FAL,65529UL,0x02FAL,65529UL,0x02FAL,65529UL,0x02FAL,65529UL,0x02FAL};
        int64_t l_1197 = 0x6151C7102D2B417CLL;
        uint8_t **l_1232 = &l_1100;
        const uint64_t l_1291 = 18446744073709551613UL;
        const int16_t *l_1341 = &l_1173;
        const int16_t **l_1340 = &l_1341;
        const int16_t ***l_1339 = &l_1340;
        uint16_t l_1378 = 0x4879L;
        int16_t l_1381 = 5L;
        int32_t **l_1456[6][10] = {{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0},{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0},{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0},{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0},{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0},{&l_1099[5],&g_984[0][3],&g_984[5][1],&g_984[5][2],&l_1099[2],&g_984[5][2],&g_984[5][1],&g_984[0][3],&l_1099[5],(void*)0}};
        int8_t ***l_1472 = (void*)0;
        int32_t l_1525 = 0xA802653DL;
        uint32_t l_1549 = 0xF1214166L;
        int16_t l_1550 = 0L;
        uint64_t l_1667 = 0x6487B181EB6209EFLL;
        int i, j;
        (*g_739) = &g_4;
    }
    for (g_946 = 0; (g_946 > 11); g_946++)
    { /* block id: 789 */
        uint32_t l_1710 = 0xCB01305DL;
        int8_t ******l_1715[9][3] = {{&l_1342[5][1],(void*)0,&g_1296},{&g_1296,(void*)0,&l_1342[7][1]},{&l_1342[8][1],(void*)0,(void*)0},{&l_1342[5][1],(void*)0,&g_1296},{&g_1296,(void*)0,&l_1342[7][1]},{&l_1342[8][1],(void*)0,(void*)0},{&l_1342[5][1],(void*)0,&g_1296},{&g_1296,(void*)0,&l_1342[7][1]},{&l_1342[8][1],(void*)0,(void*)0}};
        uint16_t **l_1718 = &g_97[4][3];
        uint16_t ***l_1717 = &l_1718;
        uint16_t **** const l_1716 = &l_1717;
        int64_t **l_1726 = &g_474;
        int64_t ***l_1725 = &l_1726;
        int64_t **l_1728 = &g_474;
        int64_t ***l_1727 = &l_1728;
        int i, j;
        for (g_947 = (-8); (g_947 == 12); g_947 = safe_add_func_int16_t_s_s(g_947, 8))
        { /* block id: 792 */
            (*l_1444) = (void*)0;
            for (g_4 = 1; (g_4 <= 8); g_4 += 1)
            { /* block id: 796 */
                for (g_353 = 0; (g_353 <= 6); g_353 += 1)
                { /* block id: 799 */
                    return p_16;
                }
            }
        }
        l_1710 ^= (safe_add_func_uint64_t_u_u(((*l_1081) ^= (safe_unary_minus_func_uint8_t_u(255UL))), ((void*)0 != (**g_924))));
        (*g_1711) = p_18;
        (*g_739) = func_28((l_1714 < ((&g_1563 != (l_1342[7][0] = l_1342[2][0])) > (l_1716 == (((safe_lshift_func_int8_t_s_s((safe_div_func_int32_t_s_s(l_1710, ((**g_1299) & 1L))), 5)) , ((((safe_div_func_uint8_t_u_u((((*l_1727) = ((*l_1725) = &g_474)) != l_1729), l_1710)) == (*g_926)) == 0x51A576FCC1BBE98ELL) ^ p_17)) , g_1730)))), p_15, l_1710, l_1734[2][2]);
    }
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_128 g_413 g_414 g_415 g_294 g_261 g_506 g_507 g_282 g_353 g_474 g_107 g_513 g_645 g_345 g_644 g_926 g_496 g_157 g_3
 * writes: g_4 g_128 g_294 g_261 g_353 g_277 g_496 g_107 g_345 g_157
 */
static const uint8_t  func_22(int32_t * p_23, int32_t * p_24, int32_t  p_25, uint32_t  p_26)
{ /* block id: 419 */
    int16_t l_987 = 1L;
    int32_t **l_988 = (void*)0;
    int32_t l_1016 = 3L;
    int32_t l_1018 = 0x14D7ABD2L;
    int32_t l_1019 = 0xB9B1F568L;
    int32_t l_1021[6];
    uint64_t l_1033 = 0UL;
    int i;
    for (i = 0; i < 6; i++)
        l_1021[i] = 0L;
    l_987 &= (safe_sub_func_int32_t_s_s((*p_23), 1L));
    (*p_23) |= (-1L);
    for (g_128 = 3; (g_128 >= 0); g_128 -= 1)
    { /* block id: 424 */
        const int16_t l_989 = 0x07FCL;
        int8_t l_1017[10];
        int32_t l_1023 = 0x9D5FFE5BL;
        int32_t l_1024[5][7][7] = {{{0x0CC4AB1FL,(-8L),9L,1L,0x3DAE249EL,0x3DAE249EL,1L},{(-1L),0L,(-1L),0xDBAC4A64L,0xF613F65DL,0x405DB9D7L,(-1L)},{0xE707AE58L,1L,0xD8109EC0L,0x0CC4AB1FL,(-5L),0x6EC8E9F7L,(-1L)},{0x5C27629BL,1L,0x8CEF3B5EL,2L,0xFE4A2315L,7L,0x8CEF3B5EL},{0L,(-8L),0x35DBC8A9L,0xD8109EC0L,(-1L),(-5L),0x6EC8E9F7L},{(-1L),0xDBAC4A64L,0L,0x405DB9D7L,(-1L),0xBC3126DFL,(-1L)},{1L,0xD8109EC0L,0x6EC8E9F7L,(-1L),0L,0xD50E2FA4L,0L}},{{7L,0xDBAC4A64L,0x1D0C8797L,0x70D5370FL,0xFE4A2315L,0x70D5370FL,0x1D0C8797L},{(-8L),(-8L),(-1L),0L,1L,(-5L),3L},{(-1L),8L,0x9C86E98FL,0x619892C8L,(-4L),8L,(-1L)},{0x8A29C58FL,0L,0x35DBC8A9L,0x8A29C58FL,1L,0x6EC8E9F7L,0xD50E2FA4L},{0xFE4A2315L,0x405DB9D7L,1L,0x405DB9D7L,0xFE4A2315L,2L,0x8CEF3B5EL},{0x3DAE249EL,0L,0xD8109EC0L,3L,0L,(-5L),9L},{(-4L),0x619892C8L,0x9C86E98FL,8L,(-1L),0x70D5370FL,(-4L)}},{{0x3DAE249EL,3L,0xAF666C7DL,(-1L),(-1L),0xAF666C7DL,3L},{0xFE4A2315L,0x70D5370FL,0x1D0C8797L,0xDBAC4A64L,7L,(-1L),0x58E21B55L},{0x8A29C58FL,(-8L),0xD50E2FA4L,0x35DBC8A9L,0x3DAE249EL,(-5L),0x35DBC8A9L},{(-1L),0x405DB9D7L,0L,0xDBAC4A64L,(-1L),0L,(-1L)},{(-8L),0x35DBC8A9L,0xD8109EC0L,(-1L),(-5L),0x6EC8E9F7L,0xAEB404B0L},{7L,1L,(-10L),8L,0xFE4A2315L,7L,(-10L)},{1L,(-8L),1L,3L,(-1L),(-5L),0xAEB404B0L}},{{(-1L),(-1L),0x9C86E98FL,0x405DB9D7L,0x9C86E98FL,(-1L),(-1L)},{0L,3L,0x6EC8E9F7L,0x8A29C58FL,(-8L),0xD50E2FA4L,0x35DBC8A9L},{0xFE4A2315L,0xDBAC4A64L,(-5L),0x619892C8L,0xFE4A2315L,5L,0x58E21B55L},{(-8L),0L,0x6EC8E9F7L,0L,0L,(-5L),3L},{0x9C86E98FL,1L,0x9C86E98FL,0x70D5370FL,(-1L),8L,(-4L)},{(-1L),0L,1L,(-1L),1L,(-1L),9L},{0xFE4A2315L,7L,(-10L),0x405DB9D7L,7L,8L,0x8CEF3B5EL}},{{(-5L),(-8L),0xD8109EC0L,0xD8109EC0L,(-8L),(-5L),0xD50E2FA4L},{(-1L),0x619892C8L,0L,1L,(-1L),5L,(-1L)},{0x3DAE249EL,0xD8109EC0L,0xD50E2FA4L,(-1L),0x8A29C58FL,0xD50E2FA4L,0xD8109EC0L},{0x5C27629BL,0x70D5370FL,(-5L),0xBC3126DFL,7L,0xBC3126DFL,(-5L)},{0x8A29C58FL,0L,9L,0x35DBC8A9L,(-5L),0x3DAE249EL,0x35DBC8A9L},{0x9C86E98FL,0L,0L,(-1L),0xF613F65DL,0L,(-4L)},{0xE707AE58L,0x35DBC8A9L,6L,0x0CC4AB1FL,(-5L),(-1L),(-1L)}}};
        uint8_t l_1025 = 247UL;
        const uint16_t *l_1043 = &g_98;
        const uint16_t **l_1042 = &l_1043;
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_1017[i] = 0x4EL;
        if (((void*)0 != l_988))
        { /* block id: 425 */
            return (**g_413);
        }
        else
        { /* block id: 427 */
            uint32_t l_991 = 4294967295UL;
            int32_t l_1015 = 0xE8617FA8L;
            int32_t l_1020 = 0x0CAA833AL;
            int32_t l_1022 = 0L;
            int16_t l_1032 = (-7L);
            uint16_t l_1055 = 0x7D3EL;
            int32_t l_1057 = 1L;
            int32_t l_1058 = 1L;
            int32_t l_1059 = (-10L);
            for (g_294 = 0; (g_294 <= 3); g_294 += 1)
            { /* block id: 430 */
                uint64_t *l_996 = &g_353;
                int32_t l_1003 = 0x8913130BL;
                uint8_t *l_1012 = &g_107;
                int32_t l_1013[8] = {0x603D5C64L,0x603D5C64L,0L,0x603D5C64L,0x603D5C64L,0L,0x603D5C64L,0x603D5C64L};
                int i;
                for (g_261 = 3; (g_261 >= 0); g_261 -= 1)
                { /* block id: 433 */
                    int i, j;
                    p_25 &= (*p_24);
                    return l_989;
                }
                (*p_24) = (safe_unary_minus_func_int16_t_s((l_1013[4] &= (((l_991 <= ((1UL ^ (***g_506)) ^ (safe_sub_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((++(*l_996)), ((*g_474) = (-4L)))), (safe_mul_func_int16_t_s_s(((safe_div_func_int32_t_s_s(l_1003, ((*g_645) ^= ((safe_div_func_int32_t_s_s((((safe_add_func_uint8_t_u_u(((0x9D3327A3D0D5E09BLL == (safe_mul_func_int8_t_s_s((safe_add_func_int64_t_s_s((-9L), l_991)), ((*l_1012) &= 2UL)))) < p_26), p_25)) < (-7L)) , (*p_24)), l_989)) != g_513)))) , p_26), (*g_282))))))) > 0xCB4A83F0258CAF21LL) < p_26))));
                for (p_25 = 1; (p_25 >= 0); p_25 -= 1)
                { /* block id: 445 */
                    int32_t *l_1014[9][4] = {{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]},{&g_261,&l_1013[6],&g_261,&l_1013[6]}};
                    int i, j;
                    ++l_1025;
                }
            }
            for (l_991 = 0; (l_991 <= 3); l_991 += 1)
            { /* block id: 451 */
                return l_1015;
            }
            for (l_1018 = 0; (l_1018 <= 3); l_1018 += 1)
            { /* block id: 456 */
                int32_t *l_1028 = &l_1015;
                int32_t *l_1029 = (void*)0;
                int32_t *l_1030 = (void*)0;
                int32_t *l_1031[6] = {&l_1024[2][6][2],(void*)0,&l_1024[2][6][2],&l_1024[2][6][2],(void*)0,&l_1024[2][6][2]};
                uint8_t l_1054 = 9UL;
                int i;
                l_1033++;
                for (l_1033 = 0; (l_1033 <= 3); l_1033 += 1)
                { /* block id: 460 */
                    uint8_t *l_1044 = &g_107;
                    uint8_t *l_1056 = &g_157;
                    int i, j;
                    if (((safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(0xB993L, 2)), 0xA6L)) != ((*l_1056) |= ((p_25 < ((safe_mul_func_int8_t_s_s((l_1042 == (((((*l_1028) |= ((((((((((*l_1044)--) != p_25) | ((safe_add_func_int32_t_s_s((*p_23), (!((safe_mod_func_int16_t_s_s((((254UL == (safe_div_func_int32_t_s_s((((**g_644) <= l_1024[2][6][2]) , l_1025), (*p_23)))) ^ p_25) & 0xDE5BL), l_1054)) <= 0UL)))) ^ (*g_926))) , p_26) , l_1055) , p_26) & 0x62L) && p_25) && 1L)) || 0xD23C2950L) != 0xD44D7C5CB7D0822FLL) , (void*)0)), (-1L))) , p_26)) && p_25))))
                    { /* block id: 464 */
                        uint16_t l_1060 = 0UL;
                        --l_1060;
                        (*p_24) = (0xE929L ^ (*g_282));
                    }
                    else
                    { /* block id: 467 */
                        uint64_t l_1063[4] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
                        int i;
                        (*l_1028) = (((*p_24) &= l_1063[2]) ^ 0xE116B733L);
                        (*p_24) = 1L;
                    }
                }
            }
        }
        for (g_261 = 0; (g_261 <= 3); g_261 += 1)
        { /* block id: 477 */
            (*p_24) = (*g_3);
        }
    }
    return (*g_414);
}


/* ------------------------------------------ */
/* 
 * reads : g_104 g_739 g_947 g_211 g_294 g_281 g_282 g_128 g_474 g_277 g_496 g_157 g_353 g_872
 * writes: g_320 g_211 g_277 g_496 g_128
 */
static int32_t * func_28(uint32_t  p_29, uint16_t  p_30, int32_t  p_31, int16_t  p_32)
{ /* block id: 405 */
    uint64_t l_951 = 0xB3C885342290D052LL;
    const uint16_t *l_979 = &g_980;
    if ((safe_unary_minus_func_int64_t_s((safe_sub_func_uint8_t_u_u(g_104, p_32)))))
    { /* block id: 406 */
        int32_t *l_952 = &g_211;
        l_951 ^= 0xFF4883CDL;
        (*g_739) = l_952;
        (*l_952) &= (0x2DL == g_947);
    }
    else
    { /* block id: 410 */
        int64_t l_953 = 0L;
        int64_t * const *l_966 = &g_474;
        int64_t * const **l_965[8] = {&l_966,&l_966,&l_966,&l_966,&l_966,&l_966,&l_966,&l_966};
        int64_t * const ***l_964 = &l_965[6];
        uint16_t l_975 = 65529UL;
        const uint16_t *l_977 = &g_978;
        const uint16_t **l_976[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t l_981 = 0x01629846L;
        int32_t l_982 = 0L;
        int i;
        l_982 ^= (((l_953 ^ p_29) | ((((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(p_29, 7)), ((**g_281) = ((((safe_div_func_int16_t_s_s(l_953, (safe_rshift_func_int8_t_s_s(g_294, (l_964 == ((safe_rshift_func_uint8_t_u_s((((((((p_32 = ((safe_div_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((**g_281), (safe_lshift_func_uint8_t_u_u((((((*g_474) ^= (l_975 && ((((l_979 = &p_30) == (void*)0) != p_31) | l_951))) >= 0xADA6708069037FB7LL) , (-8L)) < l_981), 0)))), p_30)) ^ l_975)) || 7L) , p_31) && l_953) & p_29) < g_157) , g_353), l_953)) , &l_965[6])))))) < p_30) <= (-1L)) || 0x7A30L)))), l_951)) > 0L) <= g_872) , g_104)) != p_30);
    }
    return &g_261;
}


/* ------------------------------------------ */
/* 
 * reads : g_872 g_95 g_4 g_107 g_104 g_474 g_261 g_739 g_924 g_399 g_277 g_496 g_157 g_946 g_947 g_128
 * writes: g_872 g_95 g_261 g_277 g_496 g_320 g_924 g_294 g_157 g_946
 */
static uint8_t  func_37(uint64_t  p_38, int8_t  p_39, int32_t * const  p_40, const int32_t * p_41, int32_t  p_42)
{ /* block id: 381 */
    int16_t l_870 = 0x1DF0L;
    int32_t l_871 = 3L;
    uint16_t *l_932 = &g_294;
    int32_t l_942 = (-3L);
    uint8_t *l_943 = &g_157;
    for (p_39 = 0; (p_39 < 22); p_39 = safe_add_func_uint16_t_u_u(p_39, 7))
    { /* block id: 384 */
        int32_t *l_866 = &g_261;
        int32_t *l_867 = (void*)0;
        int32_t *l_868[1];
        int32_t l_869 = 0xF913C151L;
        int32_t *l_879 = &l_869;
        int32_t *l_880 = &g_261;
        int32_t *l_881 = &l_869;
        int32_t *l_882[8][7] = {{&g_261,&g_211,&g_211,&g_211,&g_261,&g_261,&g_211},{&l_871,&l_871,&l_871,(void*)0,&l_869,&g_261,&g_4},{&g_211,&g_261,&g_211,&g_211,&g_261,&g_211,&g_261},{&l_871,(void*)0,&l_869,&g_261,&g_4,&g_261,&l_869},{&g_261,&g_261,&g_211,&g_211,&g_211,&g_261,&g_261},{&l_869,(void*)0,&g_211,(void*)0,&l_869,&l_869,&l_869},{&g_4,&g_261,&g_4,&g_211,&g_211,&g_4,&g_261},{&l_869,&l_871,&g_211,&g_4,&g_4,(void*)0,&g_4}};
        int32_t *l_883 = &g_261;
        int32_t *l_884 = &g_261;
        int32_t *l_885 = (void*)0;
        int32_t *l_886 = (void*)0;
        int32_t *l_887 = &l_869;
        int32_t *l_888 = &l_869;
        int32_t *l_889 = &l_869;
        int32_t *l_890 = &g_261;
        int32_t *l_891[9][10] = {{&l_871,&l_869,&g_4,&l_871,&g_4,&g_211,&g_211,&g_4,&g_261,&g_4},{&l_869,&l_871,&g_4,&g_4,&g_4,&l_871,&l_869,&l_869,&g_4,&l_869},{&l_869,&g_4,&l_869,&g_261,&l_869,&g_4,&g_261,&g_4,&g_261,&l_869},{&g_261,&g_4,&g_261,(void*)0,&g_4,&g_261,&l_869,&l_869,(void*)0,&g_4},{&g_4,(void*)0,&l_869,&g_211,&g_4,&g_4,&l_869,(void*)0,(void*)0,&l_869},{&g_4,&g_261,&g_4,&g_4,&g_261,&g_4,&g_211,&l_869,(void*)0,&g_261},{&l_869,&g_4,(void*)0,&l_871,&l_869,(void*)0,&g_4,&g_4,&g_261,&l_869},{&l_869,&g_4,(void*)0,&g_261,&l_869,&g_4,&l_869,&l_869,&g_211,&g_4},{&g_4,&l_869,&l_869,&g_211,&g_4,&g_4,(void*)0,&l_869,(void*)0,&g_4}};
        int32_t *l_892 = &l_871;
        int32_t *l_893 = &g_261;
        int32_t *l_894 = &g_261;
        int32_t *l_895 = (void*)0;
        int32_t *l_896 = (void*)0;
        int32_t *l_897 = &g_4;
        int32_t *l_898[4][5][8] = {{{(void*)0,&g_261,(void*)0,&g_261,&g_261,&g_261,(void*)0,&g_261},{(void*)0,(void*)0,&g_261,&g_261,&g_261,(void*)0,&g_211,&l_869},{(void*)0,&g_211,&g_261,&l_871,(void*)0,&g_4,&g_211,(void*)0},{&l_871,&l_871,&g_261,(void*)0,(void*)0,(void*)0,(void*)0,&g_261},{(void*)0,(void*)0,(void*)0,&g_261,&l_871,&l_871,(void*)0,&g_211}},{{&g_4,(void*)0,&l_871,&g_261,&g_211,(void*)0,&g_211,&g_211},{(void*)0,&g_261,&g_261,&g_261,(void*)0,(void*)0,(void*)0,&g_261},{&g_261,&g_261,&g_261,(void*)0,&g_261,(void*)0,&g_261,(void*)0},{&g_211,&g_211,&l_869,&l_871,(void*)0,&l_869,&g_261,&l_869},{&g_211,(void*)0,&g_211,&g_261,&g_261,(void*)0,(void*)0,&g_261}},{{&g_261,&g_211,&g_211,&g_261,(void*)0,(void*)0,&g_211,(void*)0},{(void*)0,&g_261,&g_211,&l_869,&g_211,(void*)0,&g_261,&g_261},{&g_4,&g_261,&g_261,&g_211,&l_871,(void*)0,&g_261,(void*)0},{(void*)0,&g_211,(void*)0,&g_211,(void*)0,(void*)0,&l_871,(void*)0},{&l_871,(void*)0,&g_261,&g_211,(void*)0,&l_869,(void*)0,&g_211}},{{(void*)0,&g_211,&g_261,&g_261,&g_261,(void*)0,&l_871,&l_871},{(void*)0,&g_261,(void*)0,(void*)0,&g_261,(void*)0,&g_261,&g_211},{(void*)0,&g_261,&g_261,&g_261,&g_4,&g_261,&l_871,&g_261},{&g_211,(void*)0,&g_261,(void*)0,(void*)0,&g_211,&g_4,&g_261},{&g_261,(void*)0,&g_261,&g_261,&g_261,(void*)0,&g_261,(void*)0}}};
        int32_t *l_899 = &g_211;
        int32_t *l_900[2];
        int32_t *l_901 = &l_869;
        int32_t ** const l_878[4][10][6] = {{{&l_900[0],&l_884,&l_899,&l_900[0],&l_886,&l_881},{&l_897,&l_884,(void*)0,&l_882[6][6],&l_893,&l_890},{&l_887,&l_899,&l_896,&l_879,&l_893,&l_893},{&l_891[8][2],&l_884,&l_884,&l_891[8][2],&l_886,(void*)0},{&l_889,&l_884,&l_886,&l_897,&l_893,&l_899},{&l_879,&l_899,&l_881,&l_894,&l_893,(void*)0},{&l_885,&l_884,&l_890,&l_885,&l_886,&l_896},{&l_882[6][6],&l_884,&l_893,&l_889,&l_893,&l_884},{&l_894,&l_899,(void*)0,&l_887,&l_893,&l_886},{&l_900[0],&l_884,&l_899,&l_900[0],&l_886,&l_881}},{{&l_897,&l_884,(void*)0,&l_882[6][6],&l_893,&l_890},{&l_887,&l_899,&l_896,&l_879,&l_893,&l_893},{&l_891[8][2],&l_884,&l_884,&l_891[8][2],&l_886,(void*)0},{&l_889,&l_884,&l_886,&l_897,&l_893,&l_899},{&l_879,&l_899,&l_881,&l_894,&l_893,(void*)0},{&l_885,&l_884,&l_890,&l_885,&l_886,&l_896},{&l_882[6][6],&l_884,&l_893,&l_889,&l_893,&l_884},{&l_894,&l_899,(void*)0,&l_887,&l_893,&l_886},{&l_900[0],&l_884,&l_899,&l_900[0],&l_886,&l_881},{&l_897,&l_884,(void*)0,&l_882[6][6],&l_893,&l_890}},{{&l_887,&l_899,&l_896,&l_879,&l_893,&l_893},{&l_891[8][2],&l_884,&l_884,&l_891[8][2],&l_886,(void*)0},{&l_889,&l_884,&l_886,&l_897,&l_893,&l_899},{&l_879,&l_899,&l_881,&l_894,&l_893,(void*)0},{&l_885,&l_884,&l_890,&l_885,&l_886,&l_896},{&l_882[6][6],&l_884,&l_893,&l_889,&l_893,&l_884},{&l_894,&l_899,(void*)0,&l_887,&l_893,&l_886},{&l_900[0],&l_884,&l_899,&l_900[0],&l_886,&l_881},{&l_897,&l_884,&l_901,&l_881,&l_892,(void*)0},{&l_886,&l_898[2][0][2],&l_895,(void*)0,&l_892,&l_892}},{{&l_890,&l_883,&l_883,&l_890,(void*)0,&l_888},{(void*)0,&l_883,(void*)0,&l_896,&l_892,&l_898[2][0][2]},{(void*)0,&l_898[2][0][2],&l_880,&l_893,&l_892,&l_901},{&l_884,&l_883,(void*)0,&l_884,(void*)0,&l_895},{&l_881,&l_883,&l_892,(void*)0,&l_892,&l_883},{&l_893,&l_898[2][0][2],&l_888,&l_886,&l_892,(void*)0},{&l_899,&l_883,&l_898[2][0][2],&l_899,(void*)0,&l_880},{&l_896,&l_883,&l_901,&l_881,&l_892,(void*)0},{&l_886,&l_898[2][0][2],&l_895,(void*)0,&l_892,&l_892},{&l_890,&l_883,&l_883,&l_890,(void*)0,&l_888}}};
        int32_t ** const *l_877[9];
        const int64_t ****l_927 = &g_924;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_868[i] = (void*)0;
        for (i = 0; i < 2; i++)
            l_900[i] = (void*)0;
        for (i = 0; i < 9; i++)
            l_877[i] = &l_878[3][7][5];
        g_872++;
        for (g_95 = (-17); (g_95 >= 35); ++g_95)
        { /* block id: 388 */
            (*l_866) = (&g_644 != &g_644);
            (*l_866) = (*p_40);
            (*g_739) = ((((((0x14L > (((((l_877[1] = &g_739) == (((safe_div_func_int64_t_s_s((safe_lshift_func_int8_t_s_u((safe_rshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_add_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s(g_107, (safe_lshift_func_int8_t_s_u(g_104, (safe_mod_func_uint32_t_u_u(((((0xBC3874AEL || 4294967288UL) || (safe_mod_func_uint8_t_u_u(((l_871 = (((*g_474) = p_38) | ((-1L) > (0x3EE083EA823BCB19LL != 18446744073709551612UL)))) < p_38), 0x8FL))) ^ 0x8FA8L) & p_38), (*p_40))))))), 1UL)), 252UL)), p_42)), 3)), p_42)), l_870)) ^ 0xF500415BA6E1DCAALL) , &g_739)) <= p_38) ^ (*p_41)) | (*p_41))) , (*l_890)) , l_871) > (*p_40)) > p_39) , (void*)0);
        }
        l_871 = (&g_386[6] == ((*l_927) = g_924));
    }
    l_942 |= (safe_div_func_uint8_t_u_u(p_42, (l_871 && (((*l_932) = (safe_rshift_func_uint8_t_u_u(p_38, 0))) <= ((safe_unary_minus_func_int16_t_s((safe_sub_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((g_399 == 8L), (safe_add_func_uint64_t_u_u(p_42, ((g_946 |= (safe_rshift_func_int8_t_s_u(((*g_474) && l_871), (--(*l_943))))) , g_947))))), 0x048B4A63L)))) || g_128)))));
    (*g_739) = &l_942;
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_74 g_97 g_98 g_107 g_188 g_104 g_576 g_281 g_282 g_128 g_474 g_496 g_211 g_353 g_399 g_277 g_645 g_345 g_739
 * writes: g_74 g_95 g_107 g_188 g_320 g_98 g_104 g_157 g_281 g_739 g_294 g_353 g_474 g_211 g_399 g_101 g_128 g_277 g_496
 */
static uint64_t  func_43(uint8_t  p_44)
{ /* block id: 2 */
    int8_t l_61 = 0xD4L;
    int32_t l_75 = 0xDED69B12L;
    int32_t l_76[7] = {0xC8E11F31L,8L,8L,0xC8E11F31L,8L,8L,0xC8E11F31L};
    int8_t l_81 = 8L;
    uint32_t l_753 = 0x60575F4BL;
    int32_t l_754 = (-1L);
    int64_t * const l_760 = &g_496[3][5];
    int32_t l_778 = (-10L);
    int16_t ***l_851 = &g_281;
    uint8_t l_863 = 0xC7L;
    int i;
    for (p_44 = 0; (p_44 >= 25); ++p_44)
    { /* block id: 5 */
        const int32_t *l_47 = &g_4;
        int32_t l_71[6][5] = {{0x704BAE91L,0x704BAE91L,0x531EAA47L,(-1L),0x531EAA47L},{9L,9L,0xF438361CL,0x05DE082AL,0xF438361CL},{0x704BAE91L,0x704BAE91L,0x531EAA47L,(-1L),0x531EAA47L},{9L,9L,0xF438361CL,0x05DE082AL,0xF438361CL},{0x704BAE91L,0x704BAE91L,0x531EAA47L,(-1L),0x531EAA47L},{9L,9L,0xF438361CL,0x05DE082AL,0xF438361CL}};
        int32_t **l_740 = &g_320[0][2];
        int i, j;
        if ((((void*)0 == l_47) || (0xF7E29192L || p_44)))
        { /* block id: 6 */
            int32_t l_48[1][4][1] = {{{0x7E294B58L},{8L},{0x7E294B58L},{8L}}};
            uint32_t *l_70 = (void*)0;
            uint32_t *l_72 = (void*)0;
            uint32_t *l_73[3][2];
            int32_t l_712 = 1L;
            int32_t *l_713 = &g_261;
            int32_t *l_714 = (void*)0;
            int32_t *l_715 = &l_71[4][4];
            int32_t *l_716 = &l_76[0];
            int32_t *l_717 = &l_71[4][0];
            int32_t *l_718 = &l_76[6];
            int32_t *l_719 = &l_71[4][4];
            int32_t *l_720[7][10][3] = {{{&l_71[5][2],&l_76[0],&l_75},{&l_76[0],(void*)0,&l_76[0]},{&l_76[1],&l_71[1][4],&l_76[0]},{(void*)0,&g_4,&g_4},{&l_75,&l_71[4][4],&l_71[3][4]},{(void*)0,&l_76[3],&l_76[0]},{&l_71[4][4],&l_76[4],&l_71[4][4]},{(void*)0,&l_76[0],(void*)0},{(void*)0,&l_76[4],&g_211},{&g_211,&l_76[3],(void*)0}},{{&g_4,&l_71[4][4],&l_76[0]},{(void*)0,&g_4,&l_75},{(void*)0,&l_71[1][4],&l_75},{&l_71[3][1],(void*)0,&l_75},{(void*)0,&l_76[0],&g_211},{&l_75,&g_261,&g_261},{&l_71[1][4],(void*)0,&l_71[5][2]},{&g_261,&l_75,&l_71[4][4]},{&l_71[4][4],&l_71[4][4],&l_712},{&l_76[0],&g_4,&g_4}},{{&l_76[0],&g_4,&l_76[1]},{&l_76[4],(void*)0,(void*)0},{&g_4,&l_76[0],&l_76[1]},{&l_71[4][4],&g_261,&g_4},{&l_712,&l_75,&l_712},{&l_76[3],&l_75,&l_71[4][4]},{&g_211,&l_71[2][3],&g_4},{&g_211,&g_4,&l_76[0]},{&g_4,(void*)0,&l_712},{&g_261,&l_75,(void*)0}},{{&l_76[0],&g_261,&g_4},{&g_4,&l_71[4][2],&g_211},{&l_75,&g_211,&l_75},{(void*)0,&l_76[0],&l_71[1][0]},{&g_211,&l_76[4],&g_4},{&g_4,&l_71[0][4],&l_71[4][2]},{&l_76[2],&l_712,&l_76[0]},{&g_4,&l_76[0],&l_71[0][0]},{&g_211,&l_71[5][2],&l_712},{(void*)0,&l_712,(void*)0}},{{&l_75,&l_71[2][3],&l_75},{&g_4,&g_261,&l_71[4][4]},{&l_76[0],&l_71[3][4],&l_76[1]},{&g_261,&l_71[4][4],&l_75},{&g_4,&g_261,&l_71[4][4]},{&g_211,(void*)0,&l_71[0][4]},{(void*)0,&g_211,&g_211},{&l_75,&l_712,(void*)0},{(void*)0,&l_76[1],&l_76[1]},{&l_712,&l_76[3],&l_76[0]}},{{&g_261,&l_71[4][4],(void*)0},{&l_71[3][1],&l_76[3],(void*)0},{&l_75,&l_76[1],&g_211},{&g_4,&l_712,&l_712},{(void*)0,&g_211,&l_76[0]},{&l_76[0],(void*)0,&l_76[0]},{&l_76[0],&g_261,&l_71[2][3]},{(void*)0,&l_71[4][4],&g_261},{&g_211,&l_71[3][4],&g_4},{(void*)0,&g_261,&g_261}},{{&g_4,&l_71[2][3],&l_71[4][4]},{&l_712,&l_712,&g_4},{&l_71[4][4],&l_71[5][2],&g_4},{&l_71[0][4],&l_76[0],&g_4},{&l_71[1][4],&l_712,&g_261},{&g_4,&l_71[0][4],&g_4},{&l_71[4][4],&l_76[4],&g_4},{&g_211,&l_76[0],&g_4},{&l_76[1],&g_211,&l_71[4][4]},{&g_261,&l_71[4][2],&g_261}}};
            uint32_t l_721 = 0x1B901ABDL;
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_73[i][j] = &g_74;
            }
            l_712 |= ((l_48[0][2][0] > (safe_rshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(0L, (safe_div_func_uint32_t_u_u((g_2 != l_48[0][3][0]), p_44)))), 10))) , (func_55(l_61, (*l_47), ((func_62((safe_div_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((g_2 || ((++g_74) , (((safe_lshift_func_uint16_t_u_u(l_81, g_74)) , &g_74) != &g_74))), l_61)), g_4)), &g_4, l_76[5]) > (*l_47)) || 0xDA293613319285C6LL), p_44, &g_211) || l_75));
            ++l_721;
            return p_44;
        }
        else
        { /* block id: 307 */
            int32_t **l_738 = &g_320[0][2];
            int32_t ***l_737[6][8] = {{(void*)0,&l_738,(void*)0,&l_738,(void*)0,&l_738,&l_738,&l_738},{&l_738,&l_738,&l_738,&l_738,&l_738,&l_738,(void*)0,(void*)0},{&l_738,&l_738,&l_738,&l_738,(void*)0,&l_738,&l_738,&l_738},{(void*)0,&l_738,&l_738,&l_738,(void*)0,&l_738,&l_738,(void*)0},{&l_738,(void*)0,(void*)0,&l_738,(void*)0,&l_738,&l_738,&l_738},{&l_738,&l_738,&l_738,&l_738,&l_738,&l_738,&l_738,(void*)0}};
            uint16_t *l_750 = &g_294;
            uint64_t *l_751 = (void*)0;
            uint64_t *l_752 = &g_353;
            int i, j;
            l_754 &= (l_75 &= ((safe_div_func_uint32_t_u_u((((~g_188) >= 4294967295UL) < (safe_sub_func_uint32_t_u_u(((safe_add_func_uint64_t_u_u(((*l_752) = ((safe_sub_func_uint16_t_u_u(((*l_750) = (safe_sub_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s(((l_76[0] = ((g_739 = &g_320[1][2]) != (l_740 = &g_320[0][1]))) || ((safe_div_func_uint64_t_u_u(((*l_47) ^ ((((safe_mul_func_int8_t_s_s((-7L), p_44)) || (+(safe_div_func_uint32_t_u_u((0x3A0DL && ((*l_47) >= 7UL)), 1L)))) , 0xBF2BD1D3L) , 0xD3B70AD0EE505720LL)), (*l_47))) | 8UL)), p_44)), p_44))), (*l_47))) > l_81)), p_44)) > p_44), (*l_47)))), 4294967295UL)) && l_753));
            l_71[4][4] = p_44;
        }
    }
    for (g_74 = 1; (g_74 <= 52); ++g_74)
    { /* block id: 320 */
        int64_t **l_759[9];
        int32_t l_763 = 0x1B4EB1F0L;
        uint32_t *l_779 = &l_753;
        int32_t *l_780[1][8][5] = {{{&l_763,(void*)0,&l_763,(void*)0,&l_763},{&l_754,&g_261,&l_763,&g_261,&l_754},{&l_763,(void*)0,&l_763,&g_4,(void*)0},{&g_261,&g_211,&l_754,&g_211,&g_261},{(void*)0,&g_4,&l_763,&g_4,(void*)0},{&g_261,&g_211,&l_754,&g_211,&g_261},{(void*)0,&g_4,&l_763,&g_4,(void*)0},{&g_261,&g_211,&l_754,&g_211,&g_261}}};
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_759[i] = &g_474;
        l_76[3] = (-4L);
        if (p_44)
            continue;
        l_76[2] = ((safe_lshift_func_int16_t_s_s(0x9AFDL, 15)) , (p_44 && ((((((g_474 = &g_496[3][1]) != l_760) || (safe_sub_func_int32_t_s_s(l_763, p_44))) , (safe_lshift_func_int8_t_s_s((+g_576[4][2][3]), 7))) || ((+0x439B2B2BL) == ((safe_div_func_uint16_t_u_u((((*l_779) = ((safe_div_func_int32_t_s_s(((((safe_div_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((p_44 > l_778), p_44)), 0x5DL)) > (**g_281)) ^ 0L) || 18446744073709551610UL), p_44)) | l_763)) , p_44), l_763)) || (*g_474)))) & p_44)));
        if (p_44)
            break;
    }
    for (g_211 = 1; (g_211 >= 0); g_211 -= 1)
    { /* block id: 330 */
        int32_t *l_781 = &l_76[3];
        int32_t *l_782[5];
        uint64_t l_783 = 0x5ADA78A02BC215F8LL;
        uint16_t **l_834 = &g_97[0][3];
        const int16_t *l_847 = &g_123;
        int i;
        for (i = 0; i < 5; i++)
            l_782[i] = &g_261;
        ++l_783;
        for (l_783 = 0; (l_783 <= 1); l_783 += 1)
        { /* block id: 334 */
            uint32_t l_792[3][9][3] = {{{0xC376E481L,18446744073709551615UL,18446744073709551615UL},{0xE8DE3926L,0xE8DE3926L,18446744073709551608UL},{0x03D21087L,0xEC4BEE34L,0x03D21087L},{0xE8DE3926L,0UL,0UL},{0xC376E481L,0xEC4BEE34L,18446744073709551615UL},{0xE87CC903L,0xE8DE3926L,0UL},{0x03D21087L,18446744073709551615UL,0x03D21087L},{0xE87CC903L,0UL,18446744073709551608UL},{0xC376E481L,18446744073709551615UL,18446744073709551615UL}},{{0xE8DE3926L,0xE8DE3926L,18446744073709551608UL},{0x03D21087L,0xEC4BEE34L,0x03D21087L},{0xE8DE3926L,0UL,0UL},{0xC376E481L,0xEC4BEE34L,18446744073709551615UL},{0xE87CC903L,0xE8DE3926L,0UL},{0x03D21087L,18446744073709551615UL,0x03D21087L},{0xE87CC903L,0UL,18446744073709551608UL},{0xC376E481L,18446744073709551615UL,18446744073709551615UL},{0xE8DE3926L,0xE8DE3926L,18446744073709551608UL}},{{0x03D21087L,0xEC4BEE34L,0x03D21087L},{0xE8DE3926L,0UL,0UL},{0xC376E481L,0xEC4BEE34L,18446744073709551615UL},{0xE87CC903L,0xE8DE3926L,0UL},{0x03D21087L,18446744073709551615UL,0x03D21087L},{0xE87CC903L,0UL,18446744073709551608UL},{0xC376E481L,18446744073709551615UL,18446744073709551615UL},{0xE8DE3926L,0xE8DE3926L,18446744073709551608UL},{0x03D21087L,0xEC4BEE34L,0x03D21087L}}};
            int32_t l_815 = 0xC2DFF35CL;
            uint16_t *l_836[8] = {&g_95,&g_95,&g_95,&g_95,&g_95,&g_95,&g_95,&g_95};
            int32_t l_841[2];
            int8_t l_862[9][3] = {{6L,6L,6L},{0x8AL,0x8AL,0x8AL},{6L,6L,6L},{0x8AL,0x8AL,0x8AL},{6L,6L,6L},{0x8AL,0x8AL,0x8AL},{6L,6L,6L},{0x8AL,0x8AL,0x8AL},{6L,6L,6L}};
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_841[i] = (-1L);
            for (l_778 = 1; (l_778 >= 0); l_778 -= 1)
            { /* block id: 337 */
                uint8_t *l_793 = &g_157;
                const int32_t l_794 = 0x3148E4F8L;
                int8_t *l_813[3];
                int64_t l_814[2];
                uint64_t *l_816 = &g_353;
                uint32_t *l_823 = &g_74;
                uint16_t ***l_835 = &l_834;
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_813[i] = &g_399;
                for (i = 0; i < 2; i++)
                    l_814[i] = (-9L);
                l_815 &= (((safe_lshift_func_int8_t_s_u(((p_44 <= ((safe_sub_func_int32_t_s_s(((safe_lshift_func_int8_t_s_s(8L, p_44)) , (((*l_793) = l_792[0][8][1]) == ((p_44 | l_794) > (((((safe_add_func_int16_t_s_s((**g_281), (g_101 = (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((g_399 ^= (safe_add_func_uint8_t_u_u(((((safe_mod_func_int8_t_s_s((safe_unary_minus_func_int64_t_s((~(p_44 > (safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(65535UL, l_75)), 4UL)))))), (*l_781))) < 5UL) != g_353) , l_794), g_496[2][4]))), l_778)), 65527UL)) || l_814[0]), (*g_474)))))) && p_44) <= l_792[0][8][1]) ^ p_44) || 4294967295UL)))), l_61)) || 247UL)) , g_104), p_44)) || l_75) , p_44);
                if ((((*l_816)--) | ((safe_lshift_func_int16_t_s_s((((safe_mod_func_int32_t_s_s((((*l_823)--) , (safe_lshift_func_int8_t_s_s(0x3FL, (safe_add_func_int8_t_s_s((((safe_add_func_int32_t_s_s((((safe_add_func_int64_t_s_s((((*l_835) = l_834) != (((void*)0 == &g_74) , (void*)0)), (*g_474))) , (l_836[0] == (**l_835))) > (((safe_add_func_int64_t_s_s((((*g_282) = (safe_add_func_uint32_t_u_u(l_778, p_44))) && (*g_282)), (*g_474))) | 7UL) >= l_814[0])), p_44)) > l_814[0]) & g_576[3][3][2]), 0xDBL))))), (*g_645))) & p_44) > p_44), 2)) , 18446744073709551615UL)))
                { /* block id: 346 */
                    for (l_815 = 1; (l_815 >= 0); l_815 -= 1)
                    { /* block id: 349 */
                        l_841[0] = (l_75 = p_44);
                        (*g_739) = &l_76[2];
                    }
                }
                else
                { /* block id: 354 */
                    uint16_t l_846 = 0x6B36L;
                    (*l_781) = (safe_unary_minus_func_uint16_t_u((safe_div_func_uint32_t_u_u((~((void*)0 == (*g_281))), 0x0A9A96EFL))));
                    for (g_74 = 0; (g_74 <= 1); g_74 += 1)
                    { /* block id: 358 */
                        l_846 = l_76[0];
                        return p_44;
                    }
                    if (p_44)
                        break;
                }
            }
            for (l_815 = 1; (l_815 >= 0); l_815 -= 1)
            { /* block id: 367 */
                uint32_t l_848[3];
                int16_t ****l_852 = &l_851;
                int i;
                for (i = 0; i < 3; i++)
                    l_848[i] = 0x28BD7717L;
                for (l_778 = 0; (l_778 <= 1); l_778 += 1)
                { /* block id: 370 */
                    (*l_781) &= (l_847 == (l_848[1] , l_847));
                }
                (*l_781) ^= (safe_div_func_uint8_t_u_u((p_44 < (((*g_282) = (((((*l_852) = l_851) == ((!(((safe_mul_func_int16_t_s_s((safe_add_func_int16_t_s_s((-10L), ((p_44 > p_44) ^ ((((*g_474) = (((safe_mod_func_int32_t_s_s(0L, (safe_rshift_func_int8_t_s_u((p_44 , ((1UL == l_848[1]) , p_44)), l_862[2][2])))) <= 0xB872L) == l_863)) >= l_81) < p_44)))), p_44)) > p_44) & 0x67BB3F872D41921DLL)) , (void*)0)) > l_848[1]) & 0L)) && (-2L))), (-1L)));
            }
        }
    }
    return l_75;
}


/* ------------------------------------------ */
/* 
 * reads : g_104
 * writes: g_104 g_157 g_281
 */
static int8_t  func_55(uint8_t  p_56, uint32_t  p_57, int32_t  p_58, const int32_t  p_59, const int32_t * p_60)
{ /* block id: 293 */
    int16_t l_688[9][4] = {{(-9L),2L,2L,(-9L)},{(-2L),2L,9L,2L},{2L,0xA3A0L,9L,9L},{(-2L),(-2L),2L,9L},{(-9L),0xA3A0L,(-9L),2L},{(-9L),2L,2L,(-9L)},{(-2L),2L,9L,2L},{2L,0xA3A0L,9L,9L},{(-2L),(-2L),2L,9L}};
    int64_t **l_691 = &g_474;
    int64_t ***l_690 = &l_691;
    int16_t **l_700[9];
    int32_t *l_708[1];
    uint16_t l_709[5][4] = {{0x3A25L,0x3A25L,2UL,0x3A25L},{0x3A25L,0xCEB6L,0xCEB6L,0x3A25L},{0xCEB6L,0x3A25L,0xCEB6L,2UL},{0xCEB6L,0xCEB6L,0x3A25L,0xCEB6L},{0xCEB6L,2UL,2UL,0xCEB6L}};
    int i, j;
    for (i = 0; i < 9; i++)
        l_700[i] = &g_282;
    for (i = 0; i < 1; i++)
        l_708[i] = &g_261;
    for (g_104 = 0; (g_104 <= 11); g_104 = safe_add_func_uint16_t_u_u(g_104, 7))
    { /* block id: 296 */
        int64_t l_687[4] = {0x6AA03C4133D63D84LL,0x6AA03C4133D63D84LL,0x6AA03C4133D63D84LL,0x6AA03C4133D63D84LL};
        uint8_t *l_689 = &g_157;
        int64_t ***l_692 = (void*)0;
        int16_t **l_699 = &g_282;
        int16_t ***l_701 = &l_700[1];
        uint64_t *l_706 = (void*)0;
        int32_t l_707 = 0x8400F9B0L;
        int i;
        l_707 = (((safe_unary_minus_func_int32_t_s(((l_687[3] > (((((*l_689) = l_688[1][2]) , l_690) != l_692) , (safe_rshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s(((l_699 != ((*l_701) = (g_281 = l_700[1]))) >= (!(~0UL))), ((safe_mul_func_int16_t_s_s(((l_688[6][0] || ((l_706 == l_706) , (-5L))) , 8L), 0x4E93L)) , p_57))), 5)))) , 9L))) && p_58) , l_688[1][1]);
    }
    --l_709[3][1];
    return p_56;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_97 g_98 g_74 g_107 g_4 g_188
 * writes: g_95 g_107 g_188 g_320 g_98
 */
static int8_t  func_62(uint32_t  p_63, int32_t * p_64, uint32_t  p_65)
{ /* block id: 8 */
    int16_t l_96 = 0x5474L;
    int32_t l_105 = (-1L);
    uint32_t *l_106 = &g_74;
    int8_t * const l_124 = &g_104;
    uint16_t *l_126[9];
    int16_t *l_145 = &g_101;
    int16_t * const *l_144[6] = {&l_145,&l_145,&l_145,&l_145,&l_145,&l_145};
    int32_t l_212 = (-1L);
    int8_t *l_234 = &g_104;
    int8_t **l_233 = &l_234;
    int32_t l_306 = 1L;
    int8_t ***l_312 = &l_233;
    int8_t ****l_311 = &l_312;
    uint64_t *l_363 = &g_353;
    uint16_t l_367 = 65535UL;
    const int32_t l_375 = (-1L);
    int32_t l_394[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint64_t l_484 = 0xCEE685037E9DCAC3LL;
    int16_t l_487 = 2L;
    int32_t l_498 = (-9L);
    int16_t l_580 = 9L;
    int16_t l_582 = 0xE182L;
    uint64_t l_583 = 4UL;
    int64_t **l_590 = &g_474;
    int32_t * const * const l_600 = &g_320[0][2];
    int16_t l_643 = (-1L);
    uint32_t l_676 = 18446744073709551610UL;
    int32_t **l_682[5][5] = {{&g_320[1][3],&g_320[0][2],&g_320[1][3],&g_320[0][0],&g_320[0][0]},{&g_320[0][2],&g_320[0][2],&g_320[0][2],&g_320[1][2],&g_320[1][2]},{&g_320[1][3],&g_320[0][2],&g_320[1][3],&g_320[0][0],&g_320[0][0]},{&g_320[0][2],&g_320[0][2],&g_320[0][2],&g_320[1][2],&g_320[1][2]},{&g_320[1][3],&g_320[0][2],&g_320[1][3],&g_320[0][0],&g_320[0][0]}};
    int32_t *l_683 = &l_105;
    int i, j;
    for (i = 0; i < 9; i++)
        l_126[i] = (void*)0;
lbl_675:
    for (p_65 = 0; (p_65 != 1); p_65 = safe_add_func_int32_t_s_s(p_65, 5))
    { /* block id: 11 */
        uint16_t *l_94[9][5][5] = {{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95}},{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95}},{{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95}},{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95}},{{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95}},{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,(void*)0,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95}},{{&g_95,&g_95,(void*)0,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,(void*)0,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95}},{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,(void*)0,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,(void*)0,&g_95,&g_95}},{{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,(void*)0,&g_95,&g_95}}};
        int16_t *l_99 = (void*)0;
        int16_t *l_100[1][10][7] = {{{&g_101,&g_101,&g_101,(void*)0,(void*)0,&g_101,&g_101},{(void*)0,&g_101,&g_101,&g_101,(void*)0,&g_101,&g_101},{(void*)0,(void*)0,&g_101,&g_101,&g_101,&g_101,&g_101},{&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101},{(void*)0,&g_101,&g_101,(void*)0,&g_101,&g_101,&g_101},{(void*)0,&g_101,&g_101,&g_101,(void*)0,&g_101,&g_101},{&g_101,(void*)0,&g_101,&g_101,(void*)0,&g_101,&g_101},{&g_101,&g_101,&g_101,&g_101,&g_101,&g_101,&g_101},{&g_101,&g_101,&g_101,(void*)0,(void*)0,&g_101,&g_101},{(void*)0,&g_101,&g_101,&g_101,(void*)0,&g_101,&g_101}}};
        int32_t l_102 = 9L;
        int8_t *l_103[5][1][10] = {{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}},{{&g_104,&g_104,(void*)0,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104,&g_104}}};
        uint16_t **l_118 = (void*)0;
        uint16_t **l_119 = (void*)0;
        uint16_t **l_120 = &g_97[5][2];
        const int16_t *l_122 = &g_123;
        const int16_t **l_121 = &l_122;
        int8_t **l_125 = &l_103[4][0][4];
        uint8_t *l_127[9][1] = {{(void*)0},{&g_107},{(void*)0},{&g_107},{(void*)0},{&g_107},{(void*)0},{&g_107},{(void*)0}};
        int32_t l_168 = 0xACD93D51L;
        int32_t l_190[2];
        uint64_t l_206[2];
        uint64_t l_365 = 8UL;
        int32_t l_393[7];
        uint32_t *l_417 = &g_345;
        uint32_t **l_416[2];
        int8_t l_465 = 1L;
        int64_t **l_486 = (void*)0;
        int64_t ***l_485 = &l_486;
        int8_t l_500 = 0xFCL;
        int16_t l_581 = (-10L);
        int32_t *l_589[4][2][1] = {{{&g_4},{(void*)0}},{{&g_4},{(void*)0}},{{&g_4},{(void*)0}},{{&g_4},{(void*)0}}};
        uint32_t l_618 = 4294967287UL;
        uint32_t **l_647 = &g_645;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_190[i] = 0x683B8F37L;
        for (i = 0; i < 2; i++)
            l_206[i] = 0xA27BBEFFA24A0073LL;
        for (i = 0; i < 7; i++)
            l_393[i] = 0L;
        for (i = 0; i < 2; i++)
            l_416[i] = &l_417;
        g_107 ^= (((((((l_105 ^= (safe_lshift_func_int8_t_s_s(8L, (safe_div_func_uint64_t_u_u(((((((8UL == (p_63 == 248UL)) || (safe_mod_func_uint8_t_u_u(p_63, ((l_102 ^= (((safe_add_func_uint16_t_u_u((l_96 = (g_95 = g_2)), ((((l_94[0][2][0] != g_97[4][3]) , (&g_98 == (void*)0)) & 0xE8BE9C2CL) > 5UL))) ^ p_65) , 0xCA02L)) , 0x3AL)))) != 0xF6L) , p_63) > g_98) | p_63), g_74))))) , p_63) , l_102) , &p_63) != l_106) | p_63) , 0x2A06A03DL);
    }
    for (g_107 = 0; (g_107 <= 46); g_107 = safe_add_func_uint64_t_u_u(g_107, 6))
    { /* block id: 276 */
        for (g_188 = 0; (g_188 < 13); ++g_188)
        { /* block id: 279 */
            int32_t **l_677 = &g_320[0][2];
            uint32_t l_678 = 0x34094D5DL;
            if (g_107)
                goto lbl_675;
            l_676 = (*p_64);
            (*l_677) = &g_261;
            l_678 = (*p_64);
        }
    }
    for (g_98 = 0; (g_98 > 28); ++g_98)
    { /* block id: 288 */
        int32_t *l_681 = &l_394[4];
        l_681 = p_64;
    }
    l_683 = &g_211;
    return g_4;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_211, "g_211", print_hash_value);
    transparent_crc(g_261, "g_261", print_hash_value);
    transparent_crc(g_277, "g_277", print_hash_value);
    transparent_crc(g_294, "g_294", print_hash_value);
    transparent_crc(g_317, "g_317", print_hash_value);
    transparent_crc(g_345, "g_345", print_hash_value);
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_399, "g_399", print_hash_value);
    transparent_crc(g_415, "g_415", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_496[i][j], "g_496[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_513, "g_513", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_576[i][j][k], "g_576[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_670, "g_670", print_hash_value);
    transparent_crc(g_872, "g_872", print_hash_value);
    transparent_crc(g_946, "g_946", print_hash_value);
    transparent_crc(g_947, "g_947", print_hash_value);
    transparent_crc(g_978, "g_978", print_hash_value);
    transparent_crc(g_980, "g_980", print_hash_value);
    transparent_crc(g_1086, "g_1086", print_hash_value);
    transparent_crc(g_1107, "g_1107", print_hash_value);
    transparent_crc(g_1367, "g_1367", print_hash_value);
    transparent_crc(g_1457, "g_1457", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1470[i], "g_1470[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1521, "g_1521", print_hash_value);
    transparent_crc(g_1545, "g_1545", print_hash_value);
    transparent_crc(g_1823, "g_1823", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 416
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 48
breakdown:
   depth: 1, occurrence: 122
   depth: 2, occurrence: 39
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 14, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 1
   depth: 20, occurrence: 2
   depth: 21, occurrence: 2
   depth: 22, occurrence: 1
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 36, occurrence: 1
   depth: 39, occurrence: 1
   depth: 48, occurrence: 1

XXX total number of pointers: 389

XXX times a variable address is taken: 951
XXX times a pointer is dereferenced on RHS: 236
breakdown:
   depth: 1, occurrence: 179
   depth: 2, occurrence: 41
   depth: 3, occurrence: 12
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
XXX times a pointer is dereferenced on LHS: 216
breakdown:
   depth: 1, occurrence: 187
   depth: 2, occurrence: 19
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
XXX times a pointer is compared with null: 30
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 15
XXX times a pointer is qualified to be dereferenced: 5199

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 764
   level: 2, occurrence: 238
   level: 3, occurrence: 55
   level: 4, occurrence: 14
   level: 5, occurrence: 8
XXX number of pointers point to pointers: 182
XXX number of pointers point to scalars: 207
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 25.7
XXX average alias set size: 1.48

XXX times a non-volatile is read: 1513
XXX times a non-volatile is write: 756
XXX times a volatile is read: 69
XXX    times read thru a pointer: 41
XXX times a volatile is write: 16
XXX    times written thru a pointer: 6
XXX times a volatile is available for access: 367
XXX percentage of non-volatile access: 96.4

XXX forward jumps: 0
XXX backward jumps: 6

XXX stmts: 126
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 34
   depth: 2, occurrence: 30
   depth: 3, occurrence: 11
   depth: 4, occurrence: 10
   depth: 5, occurrence: 8

XXX percentage a fresh-made variable is used: 16.8
XXX percentage an existing variable is used: 83.2
********************* end of statistics **********************/

