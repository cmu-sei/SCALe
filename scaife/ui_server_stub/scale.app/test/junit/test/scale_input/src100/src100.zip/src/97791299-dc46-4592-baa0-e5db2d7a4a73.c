/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2196158537
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_4[1][10][8] = {{{1UL,0UL,0x41FC9A57L,18446744073709551615UL,18446744073709551615UL,0x780EEC29L,1UL,0xDEEC5416L},{18446744073709551615UL,0x780EEC29L,1UL,0xDEEC5416L,0xBCD76CE4L,0xBCD76CE4L,0xDEEC5416L,1UL},{1UL,1UL,0xD0FA5166L,18446744073709551615UL,0xF5CD53BCL,0xE5C7A00FL,0x017779A7L,9UL},{0x41FC9A57L,0x5BF2D3F5L,1UL,1UL,18446744073709551615UL,18446744073709551615UL,0xCB5542AFL,9UL},{0x5BF2D3F5L,0xBCD76CE4L,0xAA0D7227L,18446744073709551615UL,1UL,0xAA0D7227L,0xF5CD53BCL,1UL},{0UL,18446744073709551615UL,0UL,0xDEEC5416L,1UL,0xE3051EBFL,18446744073709551615UL,0xBCD76CE4L},{0x47C4D145L,0x1D1B9849L,0x47C4D145L,6UL,0xBCD76CE4L,0UL,1UL,1UL},{1UL,0xD0FA5166L,0x1328F6C7L,0xCB5542AFL,0xD0FA5166L,1UL,0xBCD76CE4L,0xE5C7A00FL},{1UL,0x41FC9A57L,1UL,0x780EEC29L,0xBCD76CE4L,0UL,18446744073709551615UL,0x41FC9A57L},{0x47C4D145L,18446744073709551615UL,0UL,0xD0FA5166L,18446744073709551615UL,6UL,6UL,18446744073709551615UL}}};
static const int64_t g_6[9] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
static int8_t g_16 = 0xF0L;
static uint64_t g_18[8] = {18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL,0UL,18446744073709551615UL,0UL};
static uint8_t g_27 = 246UL;
static int64_t g_30 = 0xFD39EF5B506946CBLL;
static int32_t g_43[3][9] = {{0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L},{0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L},{0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L,0xAE54FD57L}};
static int32_t *g_42[3][9][3] = {{{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]}},{{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]}},{{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[2][4]}}};
static uint32_t g_79 = 0UL;
static uint64_t **g_95 = (void*)0;
static int32_t g_150[4][8][4] = {{{(-1L),0xCF28406AL,0xBEE6A4CBL,0xCF28406AL},{0xCF28406AL,0x3CB9137EL,1L,0xCF28406AL},{1L,0xCF28406AL,0x9E62AD52L,0x9E62AD52L},{0L,0L,0xBEE6A4CBL,(-1L)},{0L,0x3CB9137EL,0x9E62AD52L,0L},{1L,(-1L),1L,0x9E62AD52L},{0xCF28406AL,(-1L),0xBEE6A4CBL,0L},{(-1L),0x3CB9137EL,0x3CB9137EL,(-1L)}},{{0x086CD17EL,1L,0xBEE6A4CBL,0L},{0x3CB9137EL,0x9E62AD52L,0L,0x9E62AD52L},{0x9E62AD52L,0xBEE6A4CBL,0x086CD17EL,0x9E62AD52L},{0x086CD17EL,0x9E62AD52L,0L,0L},{1L,1L,0L,0x3CB9137EL},{1L,0xBEE6A4CBL,0L,1L},{0x086CD17EL,0x3CB9137EL,0x086CD17EL,0L},{0x9E62AD52L,0x3CB9137EL,0L,1L}},{{0x3CB9137EL,0xBEE6A4CBL,0xBEE6A4CBL,0x3CB9137EL},{0x086CD17EL,1L,0xBEE6A4CBL,0L},{0x3CB9137EL,0x9E62AD52L,0L,0x9E62AD52L},{0x9E62AD52L,0xBEE6A4CBL,0x086CD17EL,0x9E62AD52L},{0x086CD17EL,0x9E62AD52L,0L,0L},{1L,1L,0L,0x3CB9137EL},{1L,0xBEE6A4CBL,0L,1L},{0x086CD17EL,0x3CB9137EL,0x086CD17EL,0L}},{{0x9E62AD52L,0x3CB9137EL,0L,1L},{0x3CB9137EL,0xBEE6A4CBL,0xBEE6A4CBL,0x3CB9137EL},{0x086CD17EL,1L,0xBEE6A4CBL,0L},{0x3CB9137EL,0x9E62AD52L,0L,0x9E62AD52L},{0x9E62AD52L,0xBEE6A4CBL,0x086CD17EL,0x9E62AD52L},{0x086CD17EL,0x9E62AD52L,0L,0L},{1L,1L,0L,0x3CB9137EL},{1L,0xBEE6A4CBL,0L,1L}}};
static uint8_t g_180 = 1UL;
static uint16_t g_186[9] = {4UL,0x218DL,4UL,0x218DL,4UL,0x218DL,4UL,0x218DL,4UL};
static uint16_t *g_185[3] = {&g_186[5],&g_186[5],&g_186[5]};
static int16_t g_230 = 0xAEFFL;
static int16_t g_252 = 1L;
static uint16_t g_280[5][10][5] = {{{0x41C2L,9UL,1UL,65535UL,65530UL},{0xD128L,65529UL,0UL,0x7ABDL,0x7ABDL},{65530UL,1UL,65530UL,0x513AL,65535UL},{0x319BL,65531UL,65529UL,0UL,0xD128L},{0x5BDAL,0xE050L,0x836AL,0x37D8L,0x9BBEL},{0x659FL,0xAA35L,65529UL,0xD128L,0xAB8EL},{0xA9F3L,0x695AL,65530UL,0UL,0UL},{65535UL,4UL,0UL,0x319BL,65535UL},{0xDA83L,0UL,1UL,1UL,65529UL},{65529UL,65532UL,0x2C30L,0x659FL,0xD9FEL}},{{0xDA83L,2UL,0x41C2L,0UL,0UL},{65535UL,65531UL,65531UL,65535UL,0UL},{0xA9F3L,0x37D8L,6UL,9UL,65535UL},{0x659FL,0x2C30L,65532UL,65529UL,65527UL},{0x5BDAL,0UL,0x7F86L,9UL,1UL},{0x319BL,0UL,4UL,65535UL,4UL},{65530UL,0UL,0x836AL,0UL,0xA9F3L},{65529UL,65531UL,0x2C30L,0xD9FEL,8UL},{0x696BL,1UL,0UL,0x1E36L,0x41C2L},{65531UL,65531UL,65532UL,0xAA35L,4UL}},{{0xB3DBL,65528UL,0UL,65528UL,0xB3DBL},{65529UL,65531UL,0x7ABDL,65529UL,65535UL},{0x5BDAL,0UL,65528UL,0x513AL,0UL},{0x7ABDL,0xD128L,0xEB47L,65531UL,65535UL},{0x41C2L,0x513AL,0x5BDAL,0xA535L,0xB3DBL},{65535UL,0x5F20L,65535UL,65529UL,4UL},{0x7F86L,0xE050L,6UL,1UL,0x41C2L},{0x5F20L,4UL,0x659FL,0x7ABDL,8UL},{65535UL,9UL,6UL,0x37D8L,0xA9F3L},{1UL,0xA9A1L,65535UL,65535UL,0xA9A1L}},{{1UL,0xFC32L,0x5BDAL,0UL,65529UL},{0xD128L,0x2C30L,0xEB47L,0x5F20L,0UL},{6UL,0x695AL,65528UL,0x053CL,0x9BBEL},{0xD128L,65532UL,0x7ABDL,1UL,65531UL},{1UL,0x1E36L,0UL,0x4672L,0x5BDAL},{1UL,0x7ABDL,65532UL,0xD128L,65535UL},{65535UL,2UL,0UL,2UL,0UL},{0x5F20L,0xEB47L,0x2C30L,0xD128L,65527UL},{0x7F86L,1UL,0x836AL,0x4672L,0x836AL},{65535UL,65535UL,0xA9A1L,1UL,0xEB47L}},{{0x41C2L,2UL,0xDA83L,0x053CL,1UL},{0x7ABDL,0x659FL,4UL,0x5F20L,65529UL},{0x5BDAL,2UL,65535UL,0UL,0UL},{65529UL,65535UL,0x5F20L,65535UL,65529UL},{0xB3DBL,1UL,0x696BL,0x37D8L,1UL},{65531UL,0xEB47L,0xD128L,0x7ABDL,0x5F20L},{0x696BL,2UL,0xA9F3L,1UL,1UL},{65529UL,0x7ABDL,65531UL,65529UL,65529UL},{1UL,0x1E36L,1UL,0xA535L,0UL},{0xAA35L,65532UL,65531UL,65531UL,65529UL}}};
static int64_t g_282[5] = {0xC47F08E5E196648BLL,0xC47F08E5E196648BLL,0xC47F08E5E196648BLL,0xC47F08E5E196648BLL,0xC47F08E5E196648BLL};
static int64_t g_283 = 0xDBDDA58D9422DCE9LL;
static uint8_t g_284 = 0xB9L;
static int8_t * volatile *g_331 = (void*)0;
static const int32_t g_359[10] = {0x21888E1FL,1L,0x21888E1FL,0x21888E1FL,1L,0x21888E1FL,0x21888E1FL,1L,0x21888E1FL,0x21888E1FL};
static const int32_t g_361 = 0x6A4E0A7DL;
static uint32_t g_363 = 0x1A2E9158L;
static int32_t g_447 = 0x5710C9A3L;
static int64_t g_449 = 0x5DD34847E49756D0LL;
static int8_t *g_491 = &g_16;
static int8_t **g_490 = &g_491;
static int64_t g_511 = (-10L);
static uint16_t g_609 = 1UL;
static uint8_t * volatile g_624[9][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_284},{(void*)0,(void*)0},{&g_180,&g_284},{&g_284,&g_27},{(void*)0,(void*)0},{&g_180,(void*)0},{(void*)0,&g_27}};
static uint8_t * volatile *g_623[10] = {&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0],&g_624[7][0]};
static uint8_t *g_626 = &g_284;
static uint8_t **g_625 = &g_626;
static const int16_t g_673 = 0xABF2L;
static const int16_t *g_672 = &g_673;
static uint32_t g_734 = 1UL;
static int32_t g_737 = 5L;
static int32_t g_817 = 1L;
static const int32_t *g_820 = &g_737;
static int64_t g_829 = 1L;
static const uint32_t g_868 = 0x5C9DE7C2L;
static const int16_t g_1007 = 0xA0A5L;
static int8_t **g_1262 = &g_491;
static volatile int64_t * const  volatile *g_1275 = (void*)0;
static int64_t g_1386 = 0xC9DF0C9CAACC56C8LL;
static uint32_t *g_1439 = &g_79;
static uint32_t **g_1438 = &g_1439;
static uint8_t *g_1442[10] = {&g_27,&g_27,&g_27,&g_27,&g_27,&g_27,&g_27,&g_27,&g_27,&g_27};
static uint8_t **g_1441 = &g_1442[7];
static const uint64_t *g_1444 = (void*)0;
static const uint64_t **g_1443 = &g_1444;
static int16_t g_1558[6] = {0xE480L,0xE480L,0xE480L,0xE480L,0xE480L,0xE480L};
static uint16_t g_1594 = 0x3A73L;
static int64_t *g_1758 = &g_1386;
static int64_t **g_1757 = &g_1758;
static uint32_t **g_1830 = (void*)0;
static int8_t g_1850[3] = {0xE0L,0xE0L,0xE0L};
static int32_t * const *g_1890[3] = {&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]};
static int32_t * const **g_1889 = &g_1890[2];
static int64_t g_1959 = 0xFE33A7860E089CFALL;
static uint16_t **g_2087 = &g_185[1];
static uint16_t ***g_2086 = &g_2087;
static const uint64_t g_2101 = 18446744073709551607UL;
static uint32_t g_2147[2] = {6UL,6UL};
static uint64_t g_2181 = 0x79253A34C865B49DLL;
static uint32_t g_2232[4] = {1UL,1UL,1UL,1UL};
static int8_t ***g_2252[2][7] = {{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_1262,&g_1262,&g_1262,&g_1262,&g_1262,&g_1262,&g_1262}};
static int8_t ****g_2251 = &g_2252[1][5];
static const volatile uint8_t ** const  volatile * volatile g_2283 = (void*)0;/* VOLATILE GLOBAL g_2283 */
static const volatile uint8_t ** const  volatile * volatile * const  volatile g_2282 = &g_2283;/* VOLATILE GLOBAL g_2282 */
static uint8_t g_2316 = 246UL;
static volatile uint64_t g_2365 = 2UL;/* VOLATILE GLOBAL g_2365 */
static uint64_t ***g_2392 = &g_95;
static volatile uint64_t *g_2472 = (void*)0;
static volatile uint64_t **g_2471 = &g_2472;
static int32_t ** const  volatile g_2557 = (void*)0;/* VOLATILE GLOBAL g_2557 */
static int32_t ** volatile g_2558 = (void*)0;/* VOLATILE GLOBAL g_2558 */
static int32_t ** volatile g_2559 = &g_42[1][5][1];/* VOLATILE GLOBAL g_2559 */
static int32_t g_2650 = 0xAE3E8C83L;
static uint64_t *g_2667 = (void*)0;
static uint64_t ** const g_2666 = &g_2667;
static volatile int32_t g_2680 = (-9L);/* VOLATILE GLOBAL g_2680 */
static int32_t *g_2686 = &g_150[0][3][3];
static uint32_t g_2707 = 0x909CEC6FL;
static int32_t ** volatile g_2741 = &g_2686;/* VOLATILE GLOBAL g_2741 */
static volatile uint32_t g_2751 = 0xBCA02E52L;/* VOLATILE GLOBAL g_2751 */
static int64_t g_2774 = 7L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint32_t  func_7(uint8_t  p_8, const uint8_t  p_9, int64_t  p_10, int32_t  p_11);
static int64_t  func_31(int32_t  p_32, uint16_t  p_33, uint8_t * p_34, int8_t  p_35);
static int32_t  func_47(int8_t  p_48, uint64_t  p_49, int64_t * p_50);
static int64_t * func_51(uint32_t  p_52, const uint64_t ** p_53, int32_t * p_54, uint8_t * p_55, int32_t * p_56);
static uint64_t  func_61(uint64_t ** p_62, const int64_t * p_63, int8_t  p_64);
static int64_t * func_91(uint64_t ** p_92, int64_t  p_93, int64_t * p_94);
static uint8_t  func_111(int32_t  p_112, int32_t  p_113, uint64_t  p_114);
static int16_t  func_121(int16_t  p_122, int8_t  p_123, uint8_t  p_124);
static const uint8_t  func_132(int32_t  p_133, uint32_t  p_134);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_18 g_30 g_42 g_43 g_734 g_626 g_284 g_672 g_673 g_868 g_2087 g_185 g_186 g_1262 g_491 g_16 g_1438 g_1439 g_1889 g_1890 g_1757 g_1758 g_1386 g_2232 g_79 g_490 g_625 g_2251 g_2086 g_2282 g_829 g_1850 g_2147 g_2316 g_2365 g_737 g_363 g_1830 g_820 g_2471 g_95 g_282 g_609 g_27 g_2252 g_2559 g_252 g_2650 g_2392 g_2666 g_2680 g_2707 g_2741 g_2751 g_1558 g_2774 g_449
 * writes: g_16 g_27 g_30 g_42 g_43 g_734 g_79 g_284 g_820 g_230 g_1594 g_18 g_1558 g_2251 g_252 g_829 g_186 g_2392 g_737 g_363 g_1830 g_282 g_511 g_609 g_1386 g_2181 g_2650 g_2686 g_2751
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5 = 0xAB3CF81320F2D627LL;
    int8_t *l_15 = &g_16;
    uint64_t *l_17[7][6] = {{&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6]},{&g_18[7],&g_18[6],&g_18[6],&g_18[7],&g_18[6],&g_18[6]},{(void*)0,&g_18[6],&g_18[6],(void*)0,&g_18[6],&g_18[6]},{&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6]},{&g_18[7],&g_18[6],&g_18[6],&g_18[7],&g_18[6],&g_18[6]},{(void*)0,&g_18[6],&g_18[6],(void*)0,&g_18[6],&g_18[6]},{&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6],&g_18[6]}};
    int32_t l_19 = 1L;
    int32_t l_24 = 0L;
    uint8_t *l_25 = (void*)0;
    uint8_t *l_26 = &g_27;
    int32_t *l_2187[5][4][9] = {{{&g_43[1][2],&g_447,&g_447,&g_43[1][2],&l_19,&g_43[1][2],&g_447,&g_447,&g_43[1][2]},{(void*)0,&g_447,&g_447,&g_447,(void*)0,&g_43[2][4],&g_150[0][3][3],&g_447,&g_150[0][3][3]},{&g_447,&l_19,&g_43[2][4],&g_43[2][4],&l_19,&g_447,&l_19,&g_43[2][4],&g_43[2][4]},{(void*)0,&g_43[2][4],&g_150[0][3][3],&g_447,&g_150[0][3][3],&g_43[2][4],(void*)0,&g_447,&g_447}},{{&g_43[1][2],&l_19,&g_43[1][2],&g_447,&g_447,&g_43[1][2],&l_19,&g_43[1][2],&g_447},{&g_150[0][3][3],&g_447,&g_150[0][3][3],&g_737,&g_447,&g_737,&g_150[0][3][3],&g_447,&g_150[0][3][3]},{&g_447,&g_447,&g_43[2][4],&g_447,&g_447,&g_447,&g_447,&g_43[2][4],&g_447},{&g_150[0][3][3],(void*)0,&g_447,&g_447,&g_447,&g_447,&g_447,&g_447,&g_447}},{{&g_447,&g_447,&g_447,&g_43[2][4],&g_447,&g_447,&g_447,&g_447,&g_43[2][4]},{&g_150[0][3][3],(void*)0,&g_150[0][3][3],&g_447,&g_150[0][3][3],&g_737,(void*)0,&g_447,&g_150[0][3][3]},{&g_43[2][4],&g_43[1][2],&g_43[1][2],&g_43[2][4],&g_447,&g_43[2][4],&g_43[1][2],&g_43[1][2],&g_43[2][4]},{&g_150[0][3][3],&g_737,&g_447,&g_737,&g_150[0][3][3],&g_447,&g_150[0][3][3],(void*)0,&g_150[0][3][3]}},{{&g_43[1][2],&g_447,&l_19,&l_19,&g_447,&g_43[1][2],&g_447,&l_19,&l_19},{&g_150[0][3][3],&g_447,&g_150[0][3][3],(void*)0,&g_150[0][3][3],&g_447,&g_150[0][3][3],&g_737,&g_447},{&g_43[2][4],&g_447,&g_43[2][4],&g_43[1][2],&g_43[1][2],&g_43[2][4],&g_447,&g_43[2][4],&g_43[1][2]},{&g_447,&g_737,&g_150[0][3][3],&g_447,(void*)0,&g_447,&g_150[0][3][3],&g_737,&g_447}},{{&g_447,&g_43[1][2],&l_19,&g_43[1][2],&g_447,&g_447,&g_43[1][2],&l_19,&g_43[1][2]},{&g_150[0][3][3],&g_43[2][4],&g_447,(void*)0,(void*)0,&g_737,(void*)0,(void*)0,&g_447},{&g_447,&g_447,&g_43[1][2],&l_19,&g_43[1][2],&g_447,&g_447,&g_43[1][2],&l_19},{&g_447,&g_43[2][4],&g_447,&g_737,&g_150[0][3][3],&g_447,(void*)0,&g_447,&g_150[0][3][3]}}};
    int64_t l_2205 = 0xA84738BD3C8015B3LL;
    int64_t l_2234 = 2L;
    uint16_t **l_2261[1][3][1];
    int32_t l_2301 = 0L;
    int64_t l_2328[1][6][3] = {{{0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL},{0xBD563EC0E6E02986LL,0x575AA0C160E5AE00LL,0xBD563EC0E6E02986LL},{0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL},{0xBD563EC0E6E02986LL,0x575AA0C160E5AE00LL,0xBD563EC0E6E02986LL},{0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL,0x45B850C967FFD3E0LL},{0xBD563EC0E6E02986LL,0x575AA0C160E5AE00LL,0xBD563EC0E6E02986LL}}};
    int64_t l_2338 = 0xB6B0B1ACB79CAD0ALL;
    uint8_t * const *l_2361 = &l_25;
    uint8_t * const * const *l_2360[10][7] = {{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,(void*)0,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,&l_2361,&l_2361,(void*)0,&l_2361,&l_2361,&l_2361},{(void*)0,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,(void*)0},{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,(void*)0},{&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361,&l_2361},{&l_2361,&l_2361,&l_2361,&l_2361,(void*)0,&l_2361,(void*)0}};
    uint8_t * const * const **l_2359 = &l_2360[6][1];
    uint8_t * const * const ***l_2358 = &l_2359;
    uint32_t l_2386[9][5][5] = {{{0x10DF42E3L,0x565B0DABL,0x1CB93A08L,4294967295UL,0x231886F5L},{4294967295UL,0xB4ADB113L,4294967293UL,0x10E77FDFL,4294967294UL},{4294967294UL,4UL,4294967295UL,0x10DF42E3L,0x7C6F90B0L},{0x0B72B2D8L,0xB4ADB113L,0x0B72B2D8L,0xC2159E1CL,8UL},{4294967295UL,0x3F13D792L,0xB111E0D6L,4UL,0x3F13D792L}},{{4294967294UL,0xF16D85A1L,0xFB57526DL,0xDC7371E6L,4294967294UL},{0x3F13D792L,4294967295UL,0xB111E0D6L,1UL,4294967295UL},{8UL,4294967294UL,0x0B72B2D8L,0x2E17EA61L,0x0B72B2D8L},{0x7C6F90B0L,0x7C6F90B0L,4294967295UL,4294967295UL,4294967294UL},{0xE99EA02AL,0x2E17EA61L,4294967289UL,1UL,4294967294UL}},{{4294967295UL,0xB111E0D6L,0x5A223F37L,0x10DF42E3L,1UL},{0x08609201L,0x2E17EA61L,8UL,0xDC7371E6L,8UL},{0xC97EE696L,0x7C6F90B0L,0xD5373DBFL,0xB111E0D6L,0x10DF42E3L},{4294967294UL,4294967294UL,0xB6F34928L,0xF16D85A1L,0xE99EA02AL},{0x10DF42E3L,4294967295UL,0x218ACDD3L,0x10DF42E3L,4294967294UL}},{{0x1B938308L,0xF16D85A1L,0x0B72B2D8L,0x3F8348D2L,0x08609201L},{0x10DF42E3L,0x3F13D792L,0x5A223F37L,4294967295UL,0xD03867C6L},{4294967294UL,0xB4ADB113L,1UL,0xB4ADB113L,4294967294UL},{0xC97EE696L,4UL,0xE529CC8CL,1UL,0x7C6F90B0L},{0x08609201L,0x3F8348D2L,0x0B72B2D8L,0xF16D85A1L,0x1B938308L}},{{4294967295UL,0x7C6F90B0L,1UL,4UL,0x7C6F90B0L},{0xE99EA02AL,0xF16D85A1L,0xB6F34928L,4294967294UL,4294967294UL},{0x7C6F90B0L,0xD5373DBFL,0xB111E0D6L,0x10DF42E3L,0xD03867C6L},{8UL,0xDC7371E6L,8UL,0x2E17EA61L,0x08609201L},{0x3F13D792L,0x7C6F90B0L,0xE529CC8CL,0xD5373DBFL,4294967294UL}},{{4294967294UL,1UL,4294967289UL,0x2E17EA61L,0xE99EA02AL},{4294967295UL,4UL,0x3D750BC5L,0x10DF42E3L,0x10DF42E3L},{0x0B72B2D8L,0x2E17EA61L,0x0B72B2D8L,4294967294UL,8UL},{4294967294UL,0x3F13D792L,0xD5373DBFL,4UL,1UL},{4294967294UL,0xDC7371E6L,0xFB57526DL,0xF16D85A1L,4294967294UL}},{{1UL,4294967295UL,0xD5373DBFL,1UL,4294967294UL},{8UL,0xC2159E1CL,0x0B72B2D8L,0xB4ADB113L,0x0B72B2D8L},{0x10DF42E3L,0x7C6F90B0L,0x3D750BC5L,4294967295UL,4294967295UL},{0xE99EA02AL,0xB4ADB113L,4294967289UL,0x3F8348D2L,4294967294UL},{4294967294UL,0xB111E0D6L,0xE529CC8CL,0x10DF42E3L,0x3F13D792L}},{{0x08609201L,0xB4ADB113L,8UL,0xF16D85A1L,8UL},{0xD03867C6L,0x7C6F90B0L,0xB111E0D6L,0xB111E0D6L,0x7C6F90B0L},{4294967294UL,0xC2159E1CL,0xB6F34928L,0xDC7371E6L,0xE99EA02AL},{0x7C6F90B0L,4294967295UL,1UL,0x10DF42E3L,4294967295UL},{0x1B938308L,0xDC7371E6L,0x0B72B2D8L,1UL,0x08609201L}},{{0x3F13D792L,0x565B0DABL,4294967295UL,0xD5373DBFL,0UL},{0xE99EA02AL,1UL,4294967293UL,1UL,0xE99EA02AL},{0x231886F5L,0xB111E0D6L,0x3D750BC5L,0xDC3CB3B4L,1UL},{0x0B72B2D8L,4294967292UL,8UL,4294967294UL,1UL},{0xC97EE696L,0x3F13D792L,4294967295UL,0xB111E0D6L,1UL}}};
    uint64_t ***l_2391 = &g_95;
    const int8_t *l_2394 = &g_1850[2];
    const int8_t **l_2393[7][6] = {{&l_2394,&l_2394,&l_2394,&l_2394,&l_2394,&l_2394},{(void*)0,&l_2394,&l_2394,&l_2394,(void*)0,&l_2394},{&l_2394,&l_2394,&l_2394,(void*)0,&l_2394,(void*)0},{&l_2394,&l_2394,&l_2394,&l_2394,&l_2394,(void*)0},{(void*)0,&l_2394,&l_2394,&l_2394,&l_2394,&l_2394},{&l_2394,&l_2394,&l_2394,&l_2394,&l_2394,&l_2394},{(void*)0,&l_2394,&l_2394,&l_2394,(void*)0,&l_2394}};
    uint32_t l_2395 = 0xA49889C9L;
    const int16_t **l_2442 = &g_672;
    int16_t *l_2489 = &g_1558[5];
    uint32_t l_2491 = 0x5CEB63E8L;
    int32_t l_2492 = (-7L);
    int32_t l_2501 = 0xD9F8009DL;
    uint32_t l_2517 = 0x191E8FC6L;
    uint8_t l_2624 = 0x67L;
    const uint16_t l_2673 = 2UL;
    uint32_t l_2689 = 0xAF6576A8L;
    int16_t l_2735 = 0L;
    int8_t l_2765 = 1L;
    uint16_t l_2823 = 0xD13CL;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
                l_2261[i][j][k] = &g_185[0];
        }
    }
    if (((safe_add_func_uint32_t_u_u(g_4[0][0][0], l_5)) <= ((g_6[5] , 0x7D7C869BL) <= func_7(g_6[5], ((*l_26) = (((l_19 = (safe_sub_func_uint64_t_u_u(0UL, (+((*l_15) = g_6[5]))))) | g_6[5]) | (((safe_rshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s(l_5, l_5)), l_5)) >= l_24) , g_6[5]))), g_18[6], l_5))))
    { /* block id: 1034 */
        int32_t **l_2184[10][9][1] = {{{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]}},{{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0}},{{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]}},{{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0}},{{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]}},{{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0}},{{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]}},{{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0}},{{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]}},{{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{(void*)0},{&g_42[2][8][1]},{&g_42[2][8][1]},{&g_42[2][8][1]},{(void*)0}}};
        int64_t l_2207 = 1L;
        uint16_t l_2209 = 6UL;
        int8_t * const *l_2231 = (void*)0;
        int8_t * const **l_2230 = &l_2231;
        int64_t l_2233 = (-8L);
        int8_t *****l_2258 = &g_2251;
        uint8_t ****l_2279 = (void*)0;
        int32_t l_2368[3][3][4] = {{{0x0B7F6C10L,1L,0x8B240CD4L,0x0B7F6C10L},{0xC9084D83L,1L,(-10L),1L},{1L,0x8EF1BAC6L,(-3L),(-2L)}},{{0L,0xC9084D83L,0x8B240CD4L,(-3L)},{0xC9934A37L,1L,(-1L),1L},{0xC9934A37L,0x8B240CD4L,0x8B240CD4L,0xC9934A37L}},{{0L,1L,(-3L),0x8B240CD4L},{1L,1L,(-10L),(-2L)},{0xC9084D83L,0L,(-1L),0x8EF1BAC6L}}};
        int i, j, k;
        g_820 = (void*)0;
        for (l_19 = 0; (l_19 >= 22); ++l_19)
        { /* block id: 1038 */
            int16_t *l_2191 = &g_230;
            const int32_t l_2192[4] = {(-8L),(-8L),(-8L),(-8L)};
            uint16_t *l_2201 = (void*)0;
            uint16_t *l_2202 = &g_1594;
            int32_t l_2203 = (-1L);
            int32_t l_2204 = 0x9248679CL;
            int32_t l_2206 = 7L;
            int32_t l_2208[1][10] = {{(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L,(-1L),0L}};
            int i, j;
            l_2187[1][3][5] = (void*)0;
            l_2203 = (((safe_mul_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u((**g_2087))), (((*g_672) || ((*l_2191) = (*g_672))) & l_2192[3]))) ^ (safe_mod_func_uint32_t_u_u(((**g_1438) = (safe_div_func_int64_t_s_s(((((*g_626)--) < (l_2192[3] , (**g_1262))) > ((***g_1889) ^= ((**g_2087) >= ((*l_2202) = ((*g_1438) != (*g_1438)))))), (**g_1757)))), l_2192[2]))) < 0UL);
            l_2209++;
        }
        if ((safe_mod_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_s(4UL, 3)) <= (safe_div_func_int32_t_s_s((l_2234 &= ((((safe_rshift_func_int8_t_s_u(((safe_mul_func_uint64_t_u_u((--g_18[3]), ((safe_mod_func_uint16_t_u_u(0xA6FBL, (safe_lshift_func_uint16_t_u_s((0L | (safe_lshift_func_uint8_t_u_u((((g_1558[1] = ((((((*l_2230) = &g_491) != &g_491) >= 3L) >= (((((2UL || 0x466FL) , &g_1890[2]) == &l_2184[9][8][0]) || (***g_1889)) && g_2232[0])) > 0x2A70171CL)) ^ (*g_672)) == (*g_491)), l_2233))), 1)))) > (*g_672)))) || (*g_1439)), 7)) && (*g_672)) > 6L) == (**g_490))), 0x7B682B91L))), 0xC2L)))
        { /* block id: 1052 */
            int16_t l_2237 = 0xCDAEL;
            const int32_t ****l_2243 = (void*)0;
            uint32_t l_2255 = 0xD955504DL;
            int16_t l_2256 = 0x432AL;
            uint8_t ***l_2281[4];
            uint8_t ****l_2280 = &l_2281[3];
            int8_t l_2285 = 0x57L;
            int32_t l_2322 = 0xE3016BB0L;
            uint32_t l_2327 = 0x8FBECFEEL;
            int32_t l_2333 = 5L;
            uint64_t l_2335 = 0UL;
            int i;
            for (i = 0; i < 4; i++)
                l_2281[i] = &g_1441;
            for (l_5 = 0; (l_5 <= 16); l_5 = safe_add_func_int8_t_s_s(l_5, 7))
            { /* block id: 1055 */
                uint32_t l_2250 = 4294967295UL;
                int8_t *****l_2253 = (void*)0;
                int8_t *****l_2254 = &g_2251;
                int32_t *l_2257 = (void*)0;
                uint32_t *l_2266 = &l_2250;
                int16_t *l_2284 = &g_252;
                uint32_t l_2286 = 0xA6EC6CEEL;
                int32_t **l_2300 = &g_42[2][1][1];
                int32_t l_2303 = 0L;
                l_2257 = ((((((l_2237 != ((safe_div_func_int32_t_s_s(l_2237, (((((!(**g_1438)) , ((safe_rshift_func_uint16_t_u_s((((l_2243 == (((safe_rshift_func_int16_t_s_u((safe_sub_func_int8_t_s_s(((safe_add_func_int32_t_s_s(((((g_18[6] = (l_2250 != (**g_2087))) , (*g_625)) == (void*)0) , (((((((*l_2254) = g_2251) == (void*)0) <= 0UL) <= l_2255) , (*g_672)) >= (*g_672))), 0xDD735A8DL)) || (*g_1439)), 0x82L)), (***g_2086))) , (*g_672)) , &g_1889)) , (***g_1889)) == 0UL), (*g_672))) & (**g_1757))) , &g_2252[1][5]) == (void*)0) || (*g_626)))) || 0xCD254027L)) == (**g_2087)) , (***g_1889)) == l_2256) | (-1L)) , (void*)0);
                (***g_1889) = ((&g_2251 != l_2258) > (safe_rshift_func_int16_t_s_u((l_2250 , (*g_672)), (***g_2086))));
                if ((***g_1889))
                    break;
                if ((((((1L > ((void*)0 != l_2261[0][0][0])) != (((0x7C41L <= (*g_672)) && ((safe_sub_func_uint32_t_u_u((**g_1438), ((safe_lshift_func_uint16_t_u_s(((--(*l_2266)) , (safe_div_func_int32_t_s_s((safe_div_func_int16_t_s_s((*g_672), (((safe_lshift_func_int8_t_s_s((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(((*l_2284) = (((l_2280 = l_2279) == g_2282) && (***g_2086))), 1)), 0xD9L)), 4)) , (***g_2086)) && (*g_672)))), l_2255))), (*g_672))) ^ 0xDEDEL))) , l_2285)) && 0xF0B5294AB9F6C521LL)) != (*g_672)) && 0xF0F8L) <= l_2286))
                { /* block id: 1064 */
                    if ((***g_1889))
                        break;
                }
                else
                { /* block id: 1066 */
                    uint64_t l_2302 = 0x28ED0E527677E7D2LL;
                    uint8_t **l_2306[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint16_t *** const *l_2317[5][3][3] = {{{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086}},{{(void*)0,(void*)0,&g_2086},{&g_2086,(void*)0,&g_2086},{&g_2086,&g_2086,(void*)0}},{{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086}},{{(void*)0,&g_2086,&g_2086},{&g_2086,&g_2086,(void*)0},{&g_2086,&g_2086,&g_2086}},{{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086},{&g_2086,&g_2086,&g_2086}}};
                    uint32_t l_2325[9] = {4294967295UL,4294967295UL,4UL,4294967295UL,4294967295UL,4UL,4294967295UL,4294967295UL,4UL};
                    int8_t l_2326 = 0L;
                    int32_t l_2330[4] = {(-9L),(-9L),(-9L),(-9L)};
                    int i, j, k;
                    for (g_829 = 2; (g_829 >= 0); g_829 -= 1)
                    { /* block id: 1069 */
                        int32_t ***l_2299[3][4] = {{&l_2184[8][7][0],&l_2184[9][8][0],&l_2184[9][8][0],&l_2184[8][7][0]},{&l_2184[9][8][0],&l_2184[8][7][0],&l_2184[9][8][0],&l_2184[9][8][0]},{&l_2184[8][7][0],&l_2184[8][7][0],&l_2184[2][2][0],&l_2184[8][7][0]}};
                        int i, j;
                        (***g_1889) |= g_1850[g_829];
                        l_2303 &= (safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(((((safe_sub_func_int32_t_s_s((g_1850[g_829] >= ((safe_mul_func_int16_t_s_s(((*l_2284) = ((safe_mul_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u(((*g_626) = ((void*)0 != (*g_1757))), 1L)) == (&g_673 == (void*)0)), ((*g_1889) == (l_2300 = &l_2257)))) ^ l_2301)), (*g_672))) & l_2302)), l_2302)) , (void*)0) != (void*)0) && g_2147[1]), (*g_672))), 0UL));
                    }
                    (*l_2300) = &l_24;
                    if (((safe_rshift_func_int8_t_s_s(((l_2306[1] = (void*)0) == (((!(l_2327 |= (252UL != (safe_rshift_func_int8_t_s_u(((safe_add_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s((safe_add_func_int16_t_s_s(g_2316, (((void*)0 == l_2317[1][1][1]) <= ((**g_1438) = ((((*g_1439) ^ (safe_add_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u((((**g_2087) > (l_2322 = (**g_2087))) && (safe_sub_func_uint32_t_u_u((*g_1439), (***g_1889)))), (**g_490))) <= (*g_672)), l_2325[3]))) != (***g_2086)) > l_2325[3]))))), l_2326)) <= 18446744073709551612UL), l_2302)) == l_2326), (*g_626)))))) & (**g_1757)) , &g_1442[7])), 3)) , l_2328[0][0][2]))
                    { /* block id: 1081 */
                        int32_t l_2329 = 0L;
                        int32_t l_2331 = 4L;
                        int32_t l_2332 = 0xDE274A18L;
                        int32_t l_2334[6][3][9] = {{{1L,0xB4CE3853L,0x15561DD0L,9L,7L,1L,0xAFE0297EL,1L,(-9L)},{0xC74FFF7FL,0x221E11CBL,(-4L),0x10DAA97DL,0xFF7168CDL,0xC6893DEBL,0xFF7168CDL,0x10DAA97DL,(-4L)},{(-5L),(-5L),(-4L),(-1L),5L,0L,0x15561DD0L,9L,0xDE0B8B0CL}},{{0x51DF5627L,5L,(-5L),(-1L),0x9429CAD5L,0x07AE0362L,0xC7D314F9L,0xFFDDD559L,2L},{0x3BEED810L,0xDE0B8B0CL,(-4L),0x2584C562L,0L,(-5L),1L,0xF6C03773L,9L},{1L,6L,(-4L),0x07AE0362L,0x0C445DB1L,(-1L),(-1L),0x0C445DB1L,0x07AE0362L}},{{0x15561DD0L,0x40B8C9EBL,0x15561DD0L,(-6L),0x3BEED810L,0x754496E0L,1L,1L,7L},{0xBD6025C0L,0x10DAA97DL,0x1AD845FAL,(-1L),0x07AE0362L,3L,0xC6893DEBL,1L,0x177E3025L},{(-9L),0x15561DD0L,5L,(-6L),0xDE0B8B0CL,0x1A604053L,(-9L),0x9EFFC97FL,0L}},{{(-1L),3L,0x49AD811EL,0x07AE0362L,0xD4AE6948L,(-5L),(-4L),(-5L),0xD4AE6948L},{0x2584C562L,(-4L),(-4L),0x2584C562L,1L,(-9L),9L,(-7L),1L},{0x609271A8L,0x07AE0362L,0x51DF5627L,0x9429CAD5L,0x0C445DB1L,0x1AD845FAL,(-4L),0x248DD524L,(-1L)}},{{7L,0L,0x3BEED810L,0xF6C03773L,(-1L),0x15561DD0L,0xDE0B8B0CL,0x697AC61EL,0xD72D643CL},{0x51DF5627L,0xC6893DEBL,1L,3L,0x248DD524L,(-4L),0xB44A2E45L,0xB44A2E45L,(-4L)},{(-9L),1L,0x15561DD0L,1L,(-9L),(-4L),0xB4CE3853L,4L,0x40B8C9EBL}},{{3L,0xC74FFF7FL,0xBD6025C0L,0xFFDDD559L,0x609271A8L,(-5L),0xBFE8AFEDL,2L,0x51DF5627L},{4L,(-6L),(-9L),(-3L),9L,(-4L),1L,1L,0xB4CE3853L},{6L,0x10DAA97DL,(-1L),5L,0x1AD845FAL,(-4L),0xFFDDD559L,0x177E3025L,0xFFDDD559L}}};
                        int i, j, k;
                        ++l_2335;
                        if (l_2330[2])
                            break;
                    }
                    else
                    { /* block id: 1084 */
                        if ((***g_1889))
                            break;
                    }
                    return l_2338;
                }
            }
        }
        else
        { /* block id: 1090 */
            uint16_t l_2339[6][8][5] = {{{0x5530L,0x22F4L,0x53E8L,0x5441L,0UL},{3UL,0x9B30L,1UL,5UL,0x05E8L},{0x3385L,0xA64CL,0x53E8L,0UL,7UL},{0x0171L,8UL,0xC539L,0x4B2BL,8UL},{0xC5A0L,7UL,0xE2E4L,0xA64CL,0xC5A0L},{0x80B2L,0x9B30L,0x862EL,0xF5CDL,3UL},{0xC5A0L,1UL,1UL,0xC5A0L,0UL},{0x0171L,5UL,0x69FBL,0x9B30L,0xAFA0L}},{{0x3385L,0xC5A0L,0UL,0x53E8L,0xC5A0L},{3UL,8UL,0UL,0x9B30L,0UL},{0x5530L,0x5441L,0xE2E4L,0xC5A0L,7UL},{0xC539L,0x4B2BL,8UL,0xF5CDL,0x0171L},{7UL,0x22F4L,0UL,0xA64CL,0UL},{0xFB3BL,0x4B2BL,1UL,0x4B2BL,0xFB3BL},{0x3385L,0x5441L,1UL,0UL,0x5530L},{0UL,8UL,3UL,5UL,8UL}},{{7UL,0xC5A0L,0xE2E4L,0x5441L,0x5530L},{0x80B2L,5UL,0x80B2L,0xF5CDL,0xFB3BL},{0x5530L,1UL,0x53E8L,0x5530L,0UL},{0xAFA0L,0x9B30L,0x69FBL,5UL,0x0171L},{0x3385L,7UL,0x53E8L,0x53E8L,7UL},{0x05E8L,8UL,0x80B2L,0x4B2BL,0UL},{0xC5A0L,0xA64CL,0xE2E4L,7UL,0xC5A0L},{0xC539L,0x9B30L,3UL,0xF5CDL,0xAFA0L}},{{0xC5A0L,0x22F4L,1UL,0xA756L,0UL},{0x05E8L,5UL,1UL,0xE2C0L,0x80B2L},{1UL,1UL,0UL,65526UL,0x22F4L},{0xC539L,1UL,9UL,0xE2C0L,9UL},{0x3385L,0x3385L,0x5441L,1UL,0UL},{0xA046L,0xF5CDL,7UL,0xD666L,0UL},{0UL,0xE2E4L,0UL,0UL,65526UL},{3UL,0xF5CDL,0xAFA0L,0xF5CDL,3UL}},{{1UL,0x3385L,0xE2E4L,0x58BAL,0x3385L},{0x862EL,1UL,1UL,8UL,7UL},{0UL,1UL,0x5441L,0x3385L,0x3385L},{65533UL,8UL,65533UL,0xD666L,3UL},{0x3385L,0x4A14L,0x58BAL,0UL,65526UL},{0x80B2L,0xE2C0L,3UL,8UL,0UL},{1UL,0x53E8L,0x58BAL,65526UL,0UL},{8UL,1UL,65533UL,0xF5CDL,9UL}},{{0x22F4L,0UL,0x5441L,0x53E8L,0x22F4L},{0xA046L,0xE2C0L,1UL,0xD666L,0x80B2L},{0x22F4L,0xE2E4L,0xE2E4L,0x22F4L,65526UL},{8UL,8UL,0xAFA0L,0xE2C0L,0xC539L},{1UL,0x22F4L,0UL,0x58BAL,0x22F4L},{0x80B2L,1UL,7UL,0xE2C0L,7UL},{0x3385L,0UL,0x5441L,0x22F4L,0UL},{65533UL,0xF5CDL,9UL,0xD666L,8UL}}};
            uint8_t * const * const ****l_2362 = &l_2358;
            uint32_t l_2363 = 0x93F353EAL;
            uint32_t l_2364 = 0xEE4B08A4L;
            int32_t l_2366 = (-4L);
            int64_t l_2367[5];
            int32_t l_2369 = 0x48B68128L;
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_2367[i] = 0x5CA31306AB370156LL;
            l_2339[5][4][1]++;
            l_2369 = ((***g_1889) = ((safe_add_func_uint16_t_u_u((l_2367[3] = ((***g_2086) = ((l_2366 = (0xF3D0493BL || (((safe_add_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_s((**g_2087), (safe_rshift_func_uint8_t_u_s(((((((safe_mod_func_uint32_t_u_u((((safe_add_func_int64_t_s_s((-1L), ((safe_rshift_func_int16_t_s_s((0L | (0x23B12C97L ^ (&g_2282 == ((*l_2362) = l_2358)))), (*g_672))) < l_2363))) , (**g_1757)) >= (*g_1758)), l_2363)) , l_2363) | l_2364) == l_2339[5][4][1]) != l_2363) , 0UL), l_2339[5][4][1])))) & g_2365), 0x3D71F2716BCD6CC3LL)), l_2364)) == l_2339[0][7][0]) >= 0x9A494674L))) != g_284))), l_2368[1][0][3])) | 9L));
        }
    }
    else
    { /* block id: 1099 */
        int32_t l_2376[10] = {9L,9L,0x32BC1D89L,0x1DD35ECEL,0x32BC1D89L,9L,9L,0x32BC1D89L,0x1DD35ECEL,0x32BC1D89L};
        uint64_t ** const * const l_2377 = (void*)0;
        uint64_t ***l_2379 = &g_95;
        uint64_t ****l_2378 = &l_2379;
        uint32_t *l_2402 = (void*)0;
        int16_t *l_2403[6][2];
        int32_t l_2404 = 1L;
        uint32_t l_2405 = 0x62022A75L;
        uint32_t l_2462 = 0UL;
        uint16_t l_2490 = 0x80F8L;
        const uint8_t l_2497 = 0x75L;
        uint32_t l_2516 = 1UL;
        uint64_t ***l_2529 = &g_95;
        int64_t *l_2564 = (void*)0;
        uint16_t ***l_2643 = &l_2261[0][0][0];
        int32_t *l_2694 = &l_2376[2];
        int32_t **l_2824 = &l_2187[1][3][5];
        int i, j;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 2; j++)
                l_2403[i][j] = &g_1558[5];
        }
        l_2376[3] = (safe_rshift_func_uint16_t_u_s((safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(l_2376[7], ((l_2377 != ((*l_2378) = &g_95)) & ((***g_1889) ^= (((((*l_2361) != (void*)0) & (safe_sub_func_uint8_t_u_u((*g_626), (0xB7L <= (safe_lshift_func_uint16_t_u_u((((safe_add_func_int16_t_s_s((((((void*)0 != (*l_2359)) ^ 9UL) <= l_2386[7][0][0]) | 0xDF35L), 0x57E0L)) <= (**g_490)) <= 0x96CDE82CL), l_2376[6])))))) >= 0x46B1DC9098E91659LL) & 4UL))))), (*g_672))), (*g_672)));
        if ((safe_mod_func_int32_t_s_s(l_2376[7], (safe_sub_func_int16_t_s_s(((g_2392 = l_2391) != &g_1443), ((l_2393[2][4] != &l_15) , ((l_2395 , ((((safe_mul_func_int16_t_s_s((l_2404 |= (safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((18446744073709551611UL != (**g_1757)), (l_2187[4][0][4] != l_2402))), (*g_626)))), 65526UL)) ^ (***g_2086)) , 4294967289UL) & (*g_1439))) || (*g_672))))))))
        { /* block id: 1105 */
            (***g_1889) = l_2376[4];
lbl_2679:
            --l_2405;
        }
        else
        { /* block id: 1108 */
            int8_t l_2410 = 0x51L;
            int32_t l_2411 = (-1L);
            const int16_t **l_2440 = (void*)0;
            int32_t l_2461[8][4] = {{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)},{(-5L),0xE73F345EL,0xE73F345EL,(-5L)}};
            uint32_t l_2621 = 0x510273F7L;
            int32_t l_2655 = (-1L);
            int8_t l_2678 = (-1L);
            int i, j;
            if (l_2376[5])
            { /* block id: 1109 */
                int32_t l_2408 = 1L;
                int32_t l_2409 = 0x5A24B328L;
                int32_t l_2412 = 2L;
                uint16_t l_2413 = 65535UL;
                int32_t **l_2430 = (void*)0;
                int32_t ***l_2429 = &l_2430;
                int32_t ****l_2428 = &l_2429;
                const int16_t ***l_2441[2][10][8] = {{{&l_2440,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0},{&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440,(void*)0,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,(void*)0,&l_2440},{(void*)0,(void*)0,(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440},{(void*)0,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440}},{{&l_2440,&l_2440,(void*)0,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440},{(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440},{&l_2440,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0},{&l_2440,&l_2440,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440,&l_2440},{(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440},{(void*)0,&l_2440,(void*)0,&l_2440,(void*)0,&l_2440,(void*)0,&l_2440},{&l_2440,(void*)0,&l_2440,&l_2440,(void*)0,&l_2440,&l_2440,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0,&l_2440},{&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440},{&l_2440,(void*)0,&l_2440,&l_2440,&l_2440,&l_2440,&l_2440,(void*)0}}};
                int16_t l_2443 = 0x1BD2L;
                uint32_t ***l_2452 = &g_1830;
                int64_t *l_2457 = &g_282[1];
                int8_t *l_2458 = &l_2410;
                uint32_t l_2486 = 0x21FE7959L;
                int32_t *l_2498 = &l_24;
                uint16_t l_2542 = 0x3102L;
                int16_t l_2576 = 0x0C36L;
                int i, j, k;
                l_2413--;
                (***g_1889) = (safe_rshift_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u((*g_1439), (**g_1438))) > (safe_div_func_int8_t_s_s((safe_mod_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((l_2428 != &g_1889), ((safe_rshift_func_uint8_t_u_s((*g_626), 6)) | (safe_div_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(((+(((l_2442 = l_2440) != (void*)0) <= l_2443)) | (0x6731L < 0x6010L)), (*g_672))), 0x2CL))))), 0xF6C6BBA75F5F8E91LL)), l_2376[3])), l_2404))), l_2376[9]));
                for (g_737 = 1; (g_737 >= 0); g_737 -= 1)
                { /* block id: 1115 */
                    uint32_t l_2444 = 0xD615219DL;
                    if (l_2444)
                        break;
                    for (g_363 = 0; (g_363 <= 1); g_363 += 1)
                    { /* block id: 1119 */
                        return l_2404;
                    }
                }
                if (((*g_672) || ((((safe_lshift_func_uint8_t_u_u(((l_2376[7] & ((safe_sub_func_int64_t_s_s((*g_1758), (+0xD5L))) != (((*l_2452) = g_1830) != (void*)0))) < (safe_unary_minus_func_uint32_t_u((((*l_2458) ^= (((*l_2457) = (((!((***g_1889) = (l_2408 = (safe_div_func_int64_t_s_s(((18446744073709551615UL == ((void*)0 != &g_1757)) > (**g_2087)), l_2376[7]))))) ^ 7L) && (***g_1889))) , (**g_490))) & (**g_1262))))), 2)) | (*g_820)) & (**g_490)) , 0x54B5L)))
                { /* block id: 1128 */
                    int64_t l_2473[7][2] = {{2L,0x4797F2CDFCBCE401LL},{(-1L),0xC89455512B6A4CC6LL},{0x4797F2CDFCBCE401LL,0xC89455512B6A4CC6LL},{(-1L),0x4797F2CDFCBCE401LL},{2L,2L},{2L,0x4797F2CDFCBCE401LL},{(-1L),0xC89455512B6A4CC6LL}};
                    int64_t *l_2487 = &g_511;
                    int16_t *l_2488[10] = {&g_252,&g_252,&g_252,&g_252,&g_252,&g_252,&g_252,&g_252,&g_252,&g_252};
                    int32_t l_2493[6][7] = {{0xFD97C70FL,0x394B5E24L,(-9L),0xFD97C70FL,8L,0xDEC48159L,(-6L)},{0x543F78BDL,0x394B5E24L,0xC2775C39L,0x543F78BDL,8L,(-8L),8L},{0x543F78BDL,(-9L),(-9L),0x543F78BDL,(-6L),0xDEC48159L,8L},{0xFD97C70FL,0x394B5E24L,(-9L),0xFD97C70FL,8L,0xDEC48159L,(-6L)},{0x543F78BDL,0x394B5E24L,0xC2775C39L,0x543F78BDL,8L,(-8L),8L},{0x543F78BDL,(-9L),(-9L),0x543F78BDL,(-6L),0xDEC48159L,8L}};
                    int8_t ****l_2507 = (void*)0;
                    int8_t l_2524 = 0xCCL;
                    uint64_t l_2530 = 0x0A2F5C75FC565B87LL;
                    int i, j;
                    for (g_734 = 0; (g_734 < 50); g_734 = safe_add_func_uint64_t_u_u(g_734, 1))
                    { /* block id: 1131 */
                        uint32_t l_2467 = 0x1083F53FL;
                        --l_2462;
                        if ((*g_820))
                            continue;
                        (***g_1889) = (safe_lshift_func_int8_t_s_u((l_2467 == (6UL > 0UL)), ((*l_26) = 255UL)));
                    }
                    l_2493[2][6] = ((((((safe_lshift_func_uint16_t_u_s((**g_2087), ((!(((***g_1889) , g_2471) == (*l_2391))) == (l_2473[1][0] , (0xF0L | (l_2473[1][0] >= (l_2411 = (l_2461[7][3] ^= ((safe_sub_func_uint8_t_u_u(((safe_mod_func_int8_t_s_s((safe_div_func_int64_t_s_s(((*l_2457) |= (**g_1757)), (safe_div_func_uint32_t_u_u(((((*l_2487) = (safe_rshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(l_2486, l_2473[1][0])), (*g_672)))) , l_2488[2]) == l_2489), l_2490)))), 0xCAL)) > l_2491), l_2410)) & 18446744073709551615UL))))))))) != l_2410) | l_2492) < (*g_672)) , (***g_1889)) & l_2473[0][0]);
                    for (g_609 = (-1); (g_609 <= 53); g_609 = safe_add_func_uint64_t_u_u(g_609, 1))
                    { /* block id: 1144 */
                        int32_t l_2496 = 0x923B0886L;
                        if (l_2496)
                            break;
                        if (l_2497)
                            break;
                        g_42[2][8][1] = (l_2498 = &l_2461[5][2]);
                        (***g_1889) = 0xA80BB46DL;
                    }
                    if (((***g_1889) = (l_2501 <= (((~(safe_sub_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(l_2461[6][0], (((l_2507 == &g_2252[0][5]) > ((((safe_rshift_func_int8_t_s_s(((safe_mod_func_int16_t_s_s((safe_add_func_int32_t_s_s(((safe_mul_func_int16_t_s_s((g_230 = (*g_672)), ((void*)0 == &g_2086))) , ((-5L) <= (*l_2498))), (*g_820))), (***g_2086))) > l_2516), l_2411)) != l_2411) ^ l_2490) , (**g_1757))) == (*g_1758)))) < l_2473[1][0]), (*l_2498)))) | l_2517) > (*g_1439)))))
                    { /* block id: 1153 */
                        uint16_t l_2539 = 65535UL;
                        uint64_t * const *l_2550 = &l_17[2][3];
                        uint64_t * const * const *l_2549[7][4][1] = {{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}},{{&l_2550},{&l_2550},{&l_2550},{&l_2550}}};
                        uint64_t * const * const **l_2551 = &l_2549[4][1][0];
                        const int32_t **l_2556 = &g_820;
                        int i, j, k;
                        (***g_1889) &= ((+((void*)0 == (*g_2086))) , ((+(safe_sub_func_uint16_t_u_u((l_2539 |= (l_2493[2][6] = ((safe_add_func_uint64_t_u_u((--g_18[6]), (((*g_626) ^= ((*l_2378) == ((safe_sub_func_int64_t_s_s(0x487B3E5EAF0BA95ALL, 8UL)) , l_2529))) > l_2530))) <= (safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(((***g_2086) = ((safe_lshift_func_uint16_t_u_u(((--(*l_26)) < (((*g_672) >= ((**g_2251) != (void*)0)) , (**g_1262))), 0)) , l_2404)), 10)), 0x5A76E7F205E264A9LL))))), l_2405))) , 0x7D3280BEL));
                        (*l_2556) = ((9L && ((((safe_div_func_int16_t_s_s((*g_672), (l_2410 || l_2542))) != (((safe_mul_func_int8_t_s_s(((((safe_mod_func_uint16_t_u_u(((***g_2086) |= 1UL), ((safe_add_func_int16_t_s_s(((g_18[6] = (&g_2471 != ((*l_2551) = l_2549[4][1][0]))) > (safe_mod_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(65529UL, l_2539)), 249UL))), l_2524)) | 0x3DL))) > l_2405) , (void*)0) == &g_2251), 255UL)) || (**g_1757)) > (-1L))) && (*g_1758)) >= 1L)) , (void*)0);
                        (*g_2559) = (**g_1889);
                    }
                    else
                    { /* block id: 1166 */
                        (***g_1889) = l_2461[5][2];
                    }
                }
                else
                { /* block id: 1169 */
                    uint32_t l_2575 = 0xFE1B8627L;
                    (*g_2559) = (void*)0;
                    for (l_2491 = (-5); (l_2491 != 22); l_2491 = safe_add_func_uint8_t_u_u(l_2491, 7))
                    { /* block id: 1173 */
                        uint8_t l_2577 = 0x4DL;
                        (*l_2498) ^= (((*g_1758) ^ (((((*l_2489) = (-1L)) != ((safe_add_func_uint16_t_u_u((l_2564 == (*g_1757)), (--(**g_2087)))) > ((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s((**g_1262), (((((((0UL & (((safe_rshift_func_int16_t_s_s((g_252 ^= (safe_lshift_func_uint8_t_u_u((0xCCB5C9ECL & 0xB6A0BF4DL), 7))), (l_2575 | 0L))) | l_2376[4]) <= 0x9D9AE047A6F2C793LL)) & l_2410) , (-10L)) , (**g_1262)) || (**g_625)) & l_2575) , l_2575))), l_2576)) & l_2575))) > 9L) <= l_2575)) <= l_2577);
                    }
                }
            }
            else
            { /* block id: 1180 */
                int8_t l_2579[1];
                uint8_t l_2589[7][6][4] = {{{0xC4L,0x21L,0x76L,0x76L},{0x17L,0x17L,0x8AL,0x76L},{1UL,0x21L,1UL,0UL},{4UL,0xF6L,0x8AL,1UL},{0x89L,0xF6L,0x76L,0UL},{0xF6L,0x21L,0xF6L,0x76L}},{{0x89L,0x17L,0UL,0x76L},{4UL,0x21L,0UL,0UL},{1UL,0xF6L,0UL,1UL},{0x17L,0xF6L,0xF6L,0UL},{0xC4L,0x21L,0x76L,0x76L},{0x17L,0x17L,0x8AL,0x76L}},{{1UL,0x21L,1UL,0UL},{4UL,0xF6L,0x8AL,1UL},{0x89L,0xF6L,0x76L,0UL},{0xF6L,0x21L,0xF6L,0x76L},{0x89L,0x17L,0UL,0x76L},{4UL,0x21L,0UL,0UL}},{{1UL,0xF6L,0UL,1UL},{0x17L,0xF6L,0xF6L,0UL},{0xC4L,0x21L,0x76L,0x76L},{0x17L,0x17L,0x8AL,0x76L},{1UL,0x21L,1UL,0UL},{4UL,0xF6L,0x8AL,1UL}},{{0x89L,0xF6L,0x76L,0UL},{0xF6L,0x21L,0xF6L,0x76L},{0x89L,0x17L,0UL,0x76L},{4UL,0x21L,0UL,0UL},{1UL,0xF6L,0UL,1UL},{0x17L,0xF6L,0xF6L,0UL}},{{0xC4L,0x21L,0x76L,0x76L},{0x17L,0x17L,0x8AL,0x76L},{1UL,0x21L,1UL,0UL},{4UL,0xF6L,0x8AL,1UL},{0x89L,0xF6L,0x76L,0UL},{0xF6L,0x21L,0xF6L,0x76L}},{{0x89L,0x17L,0UL,0x76L},{4UL,0x21L,0UL,0UL},{1UL,0xF6L,0UL,1UL},{0x17L,0xF6L,0xF6L,0UL},{0xC4L,0x21L,0x76L,0x76L},{0xF6L,0xF6L,0UL,255UL}}};
                int32_t l_2623 = 0x8CA67CB4L;
                int32_t l_2687[7];
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_2579[i] = 0x24L;
                for (i = 0; i < 7; i++)
                    l_2687[i] = 0L;
                if ((safe_unary_minus_func_uint16_t_u((**g_2087))))
                { /* block id: 1181 */
                    uint64_t l_2580 = 0xC275228085194CEDLL;
                    int32_t l_2597 = (-1L);
                    if (l_2579[0])
                    { /* block id: 1182 */
                        int8_t l_2596 = 7L;
                        l_2597 |= ((l_2580 , (safe_sub_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(((((**g_1438) |= (0x45L >= 0x4AL)) ^ (((l_2580 | (((l_2461[1][2] < ((safe_mul_func_int16_t_s_s((*g_672), (l_2589[6][5][0] , 0x3F2FL))) | ((safe_div_func_uint32_t_u_u(((((safe_div_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_s((((**g_1757) = (*g_1758)) > l_2589[0][2][2]), l_2596)) , 65528UL), (-7L))) | 0x0F02L) >= 65535UL) <= 2UL), l_2497)) ^ 65535UL))) >= (**g_2559)) || (*g_820))) <= l_2376[7]) , l_2580)) > (**g_490)), l_2589[3][2][3])), l_2580)), (**g_625)))) || 0xA811L);
                    }
                    else
                    { /* block id: 1186 */
                        l_2411 = 0x9CD7F046L;
                        return l_2580;
                    }
                }
                else
                { /* block id: 1190 */
                    int8_t l_2622 = 0xF5L;
                    uint64_t l_2649 = 0x0FB7AA319BC4F5CCLL;
                    int32_t l_2651[9][6][4] = {{{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL},{0xA456414DL,0x13E665BCL,1L,0x13E665BCL}},{{0x55AADBD3L,4L,(-1L),1L},{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL}},{{0xA456414DL,0x13E665BCL,1L,0x13E665BCL},{0x55AADBD3L,4L,(-1L),1L},{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)}},{{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL},{0xA456414DL,0x13E665BCL,1L,0x13E665BCL},{0x55AADBD3L,4L,(-1L),1L},{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)}},{{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL},{0xA456414DL,0x13E665BCL,1L,0x13E665BCL},{0x55AADBD3L,4L,(-1L),1L},{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL}},{{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL},{0xA456414DL,0x13E665BCL,1L,0x13E665BCL},{0x55AADBD3L,4L,(-1L),1L},{0x13E665BCL,4L,4L,0x13E665BCL}},{{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,0xA456414DL},{0xA456414DL,0x13E665BCL,1L,0x13E665BCL},{0x55AADBD3L,4L,(-1L),1L}},{{0x13E665BCL,4L,4L,0x13E665BCL},{4L,0x13E665BCL,0x55AADBD3L,0xA456414DL},{4L,0x55AADBD3L,4L,(-1L)},{0x13E665BCL,0xA456414DL,(-1L),(-1L)},{0x55AADBD3L,0x55AADBD3L,1L,(-1L)},{(-1L),4L,0x55AADBD3L,4L}},{{0xBAEFC43FL,0xA456414DL,1L,0x55AADBD3L},{4L,0xA456414DL,0xA456414DL,4L},{0xA456414DL,4L,0xBAEFC43FL,(-1L)},{0xA456414DL,0xBAEFC43FL,0xA456414DL,1L},{4L,(-1L),1L,1L},{0xBAEFC43FL,0xBAEFC43FL,0x55AADBD3L,(-1L)}}};
                    int32_t l_2654 = 0xFCC2D968L;
                    int i, j, k;
                    if ((safe_lshift_func_uint8_t_u_u(((l_2490 | (((safe_sub_func_uint16_t_u_u(((**g_2087)--), (safe_sub_func_uint8_t_u_u((++(*g_626)), ((*g_1439) == (~(l_2410 , (l_2579[0] == l_2579[0])))))))) == (safe_lshift_func_int16_t_s_s(((0xB4F1ABF7L >= ((safe_add_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(65535UL, (safe_sub_func_uint16_t_u_u((l_2461[5][2] , ((g_2181 = ((((safe_add_func_int32_t_s_s(2L, l_2589[1][4][1])) && (**g_1438)) < 0x68E4L) || 3L)) == l_2621)), l_2405)))), (-10L))) && l_2622)) < 0UL), (*g_672)))) >= (*g_1439))) ^ l_2461[5][2]), l_2410)))
                    { /* block id: 1194 */
                        const int16_t l_2648 = 1L;
                        uint16_t l_2652 = 65533UL;
                        int32_t l_2653 = 0xD5BE09B2L;
                        --l_2624;
                        l_2655 |= ((l_2653 = ((((void*)0 == &g_624[7][0]) >= (safe_sub_func_uint64_t_u_u((l_2623 = (l_2651[5][5][0] = ((safe_mod_func_int32_t_s_s(((**g_2559) = (safe_div_func_uint64_t_u_u(((safe_div_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((0xF3CFL >= ((safe_sub_func_uint64_t_u_u(0UL, ((safe_mul_func_int8_t_s_s(((safe_add_func_uint16_t_u_u(((***g_2086) = (((void*)0 == l_2643) >= ((((safe_sub_func_uint32_t_u_u(((((safe_lshift_func_uint16_t_u_u((((l_2405 > (0x0DDC873C70657049LL & l_2648)) | l_2648) != l_2411), 8)) , l_2649) && (**g_2559)) , 0x3191A5F1L), l_2621)) <= (**g_2087)) ^ 0x813B63A4L) && (***g_1889)))), (*g_672))) != g_2650), 0xCBL)) < (*g_672)))) & 0x1FDDL)), 1L)), l_2461[5][2])) ^ 18446744073709551615UL), 0x84F187C4224D6D7FLL))), l_2622)) , 7UL))), (*g_1758)))) && l_2652)) < l_2654);
                        (***g_1889) = (-10L);
                    }
                    else
                    { /* block id: 1203 */
                        l_2654 ^= (-1L);
                    }
                }
                (***g_1889) = (l_2589[1][4][0] < ((safe_rshift_func_uint8_t_u_u(l_2376[7], 6)) , (safe_rshift_func_uint8_t_u_u(l_2376[7], ((0x339AL > ((l_2623 |= ((safe_mul_func_int8_t_s_s((((*g_1439)++) , (safe_sub_func_uint8_t_u_u(((*g_626) = ((*g_2392) == g_2666)), l_2462))), ((**g_490) = (**g_490)))) && ((0x6BL < 1L) > l_2376[7]))) && l_2579[0])) ^ 4294967295UL)))));
                if (((((safe_unary_minus_func_uint64_t_u((((((g_18[5] = (safe_mul_func_int16_t_s_s(l_2490, l_2589[6][2][2]))) >= (l_2655 & (((**g_1438) >= ((0x6FFBC804L & (safe_div_func_uint8_t_u_u(l_2673, (safe_unary_minus_func_int16_t_s(l_2490))))) < (safe_lshift_func_int16_t_s_u(((((*l_26) = l_2462) <= (+5UL)) | (*g_1439)), 9)))) < (**g_1757)))) >= l_2461[5][2]) > l_2678) & l_2376[7]))) > (*g_672)) == 0x0F27108703B937D2LL) & (*g_672)))
                { /* block id: 1214 */
                    uint32_t l_2681 = 0xA9FF5E8DL;
                    if (l_2490)
                        goto lbl_2679;
                    for (g_2650 = 0; (g_2650 >= 0); g_2650 -= 1)
                    { /* block id: 1218 */
                        (***g_1889) = g_2680;
                        return l_2681;
                    }
                    return l_2410;
                }
                else
                { /* block id: 1223 */
                    uint64_t l_2682 = 0xFEA6B8C3BB58AF02LL;
                    int32_t **l_2685[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int64_t l_2688[3][1];
                    int i, j;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_2688[i][j] = 0x8AD96C658E8D2FD6LL;
                    }
                    --l_2682;
                    g_2686 = &l_2623;
                    --l_2689;
                    for (l_2410 = 0; (l_2410 < (-18)); l_2410 = safe_sub_func_uint16_t_u_u(l_2410, 6))
                    { /* block id: 1229 */
                        l_2694 = &l_2411;
                    }
                }
            }
        }
        for (g_363 = (-14); (g_363 != 19); g_363 = safe_add_func_uint8_t_u_u(g_363, 1))
        { /* block id: 1237 */
            uint32_t *l_2703 = (void*)0;
            uint64_t **l_2704[4][8] = {{&g_2667,&g_2667,&l_17[4][3],&g_2667,&g_2667,&g_2667,&l_17[4][3],&g_2667},{&g_2667,&g_2667,&l_17[4][3],&g_2667,&g_2667,&g_2667,&l_17[4][3],&g_2667},{&g_2667,&g_2667,&l_17[4][3],&g_2667,&g_2667,&g_2667,&l_17[4][3],&g_2667},{&g_2667,&g_2667,&l_17[4][3],&g_2667,&g_2667,&g_2667,&l_17[4][3],&g_2667}};
            int32_t l_2705[9] = {0xC3F7B407L,0x43353A3FL,0xC3F7B407L,0x43353A3FL,0xC3F7B407L,0x43353A3FL,0xC3F7B407L,0x43353A3FL,0xC3F7B407L};
            int64_t *l_2706[2];
            int32_t l_2708 = 0xBA1D1603L;
            uint8_t ***l_2716 = &g_1441;
            uint8_t **** const l_2715 = &l_2716;
            int16_t l_2779 = 2L;
            int32_t l_2798[1];
            uint32_t **l_2821 = &g_1439;
            uint8_t l_2822 = 0x38L;
            int i, j;
            for (i = 0; i < 2; i++)
                l_2706[i] = &l_5;
            for (i = 0; i < 1; i++)
                l_2798[i] = 0L;
            if ((l_2708 ^= (safe_rshift_func_uint8_t_u_s(((g_282[1] |= ((*g_1758) < ((0x9527L || ((((safe_div_func_int8_t_s_s(0x73L, (safe_mod_func_uint16_t_u_u(((void*)0 == l_2703), (**g_2087))))) || ((l_2704[3][0] != (void*)0) && ((**g_1438) ^= (l_2705[2] >= l_2705[2])))) ^ l_2376[7]) || 0x9723L)) , l_2705[2]))) > g_2707), (**g_490)))))
            { /* block id: 1241 */
                int32_t l_2711 = 0L;
                uint32_t l_2712 = 0UL;
                int32_t l_2736 = (-10L);
                uint16_t l_2738 = 65534UL;
                for (l_5 = 0; (l_5 == (-24)); --l_5)
                { /* block id: 1244 */
                    l_2712 = l_2711;
                    l_2736 &= ((0xF0E3L ^ (safe_rshift_func_uint16_t_u_u(((void*)0 == l_2715), 3))) <= ((safe_lshift_func_uint8_t_u_u((((*g_1439)--) , ((safe_mul_func_uint16_t_u_u(((**g_2087) = (l_2705[2] < (((safe_add_func_int32_t_s_s(l_2711, ((l_2402 = ((((g_230 = (*g_672)) < (safe_unary_minus_func_int64_t_s((+0x26L)))) , (((safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(l_2708, (safe_lshift_func_uint8_t_u_u(l_2404, 2)))), (*g_491))), 5)) , (void*)0) != (*g_1438))) , l_2703)) == &g_734))) != 0x13L) || (*g_672)))), (*g_672))) < (*g_1758))), l_2735)) <= l_2705[2]));
                }
                for (g_609 = 0; (g_609 <= 1); g_609 += 1)
                { /* block id: 1254 */
                    int32_t l_2737 = (-1L);
                    for (g_737 = 9; (g_737 >= 0); g_737 -= 1)
                    { /* block id: 1257 */
                        ++l_2738;
                    }
                    (*g_2741) = &l_2404;
                }
                if (l_2705[2])
                    continue;
            }
            else
            { /* block id: 1263 */
                int64_t l_2742 = (-1L);
                return l_2742;
            }
            for (l_2490 = 0; (l_2490 > 14); l_2490++)
            { /* block id: 1268 */
                int32_t **l_2745 = &l_2694;
                int32_t l_2746 = 0xDA51166FL;
                int32_t l_2747 = 2L;
                int32_t l_2748 = (-9L);
                int32_t l_2749 = (-2L);
                int32_t l_2750[7][7] = {{0x0DEB827CL,(-4L),0L,0xBEFCCC60L,4L,(-1L),0xCF65D14EL},{1L,(-1L),0x521C0CF0L,(-4L),(-4L),0x521C0CF0L,(-1L)},{0xCF65D14EL,1L,0x4E591371L,1L,(-4L),0x67D855E2L,0L},{0xE465E764L,0x0DEB827CL,1L,(-1L),4L,0L,0x4E591371L},{0xBEFCCC60L,(-2L),1L,1L,(-2L),0xBEFCCC60L,0xE465E764L},{1L,0x4E591371L,1L,(-4L),0x67D855E2L,0L,(-2L)},{0L,4L,1L,0xBEFCCC60L,(-7L),(-2L),(-7L)}};
                uint16_t l_2756 = 9UL;
                int32_t *l_2782[1];
                uint16_t ****l_2787 = &l_2643;
                uint16_t l_2801 = 0xB95CL;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_2782[i] = &l_2301;
                (*l_2745) = &l_2705[2];
                g_2751--;
                for (l_24 = 0; (l_24 <= 14); ++l_24)
                { /* block id: 1273 */
                    return l_2756;
                }
                if (((safe_lshift_func_int16_t_s_s((((**g_1438)--) || (*g_1439)), ((*l_2489) &= (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s(0x1CL, 0)), l_2765))))) < (safe_mul_func_int16_t_s_s(((((((*l_2694) || ((((***g_2086) = (0xC8L >= (**l_2745))) != (safe_rshift_func_uint8_t_u_s(((**g_625) = (((safe_div_func_int8_t_s_s(0L, (safe_sub_func_uint64_t_u_u(g_2774, ((((safe_mul_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((((((**l_2745) < (*g_1758)) == (*l_2694)) && 0L) ^ 253UL), g_449)), l_2708)) ^ 8L) ^ 0xC1B2E708L) > (-9L)))))) < 0x89A3L) , 247UL)), (**l_2745)))) ^ 0xD434E952L)) || (*l_2694)) <= (*g_672)) ^ 0UL) , l_2779), (**l_2745)))))
                { /* block id: 1280 */
                    int32_t l_2780 = 0x83026C51L;
                    if ((*l_2694))
                    { /* block id: 1281 */
                        return l_2780;
                    }
                    else
                    { /* block id: 1283 */
                        int32_t *l_2781 = &l_2376[7];
                        (*l_2745) = l_2781;
                    }
                    l_2187[1][3][5] = l_2782[0];
                    (*l_2694) = ((safe_lshift_func_int8_t_s_s(((0x9DC12806C9A9F03DLL == (safe_sub_func_uint8_t_u_u(((((l_2708 |= (l_2705[2] ^= (l_2787 == (void*)0))) >= (+((**g_1438) , (((***g_2086) = 0x3F18L) & (safe_add_func_int64_t_s_s((safe_mul_func_int16_t_s_s((safe_div_func_int16_t_s_s((*g_672), 3UL)), ((l_2798[0] = ((((safe_mul_func_uint64_t_u_u((**l_2745), ((~(**g_1438)) != 0UL))) | 0x4CL) | l_2780) ^ l_2779)) || l_2779))), 0x0227CE1529773D4BLL)))))) < l_2779) == l_2779), 0x07L))) | (-1L)), (*g_491))) , 0x6766B138L);
                    for (g_16 = 0; (g_16 <= (-14)); g_16 = safe_sub_func_int32_t_s_s(g_16, 2))
                    { /* block id: 1294 */
                        (*l_2694) = l_2801;
                        return l_2779;
                    }
                }
                else
                { /* block id: 1298 */
                    int32_t *l_2802 = &l_2376[3];
                    (*l_2745) = l_2802;
                    l_2823 = (l_2822 ^= ((((***l_2643) = (***g_2086)) >= (*l_2694)) > (safe_add_func_int8_t_s_s((safe_sub_func_int32_t_s_s((*l_2802), (safe_div_func_int32_t_s_s((+(((*l_2802) >= 1UL) , (*l_2694))), (((safe_div_func_uint64_t_u_u(((safe_mod_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u((0xD769C012L <= (safe_mod_func_int32_t_s_s(((((safe_unary_minus_func_uint32_t_u((*l_2802))) & (((((safe_lshift_func_int16_t_s_s(((void*)0 != &l_2261[0][0][0]), 11)) ^ (**l_2745)) || 8L) , l_2821) != (void*)0)) ^ 0x779BL) && (**g_1438)), (**l_2745)))), (**g_490))), (*l_2694))) == (-7L)), (*l_2802))) < (*g_1758)) | 0xC0L))))), (*l_2694)))));
                }
            }
        }
        (*l_2824) = &l_2404;
    }
    return (*g_626);
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_30 g_42 g_43 g_734 g_626 g_284 g_672 g_673 g_868
 * writes: g_30 g_42 g_43 g_734 g_79 g_16 g_284
 */
static uint32_t  func_7(uint8_t  p_8, const uint8_t  p_9, int64_t  p_10, int32_t  p_11)
{ /* block id: 4 */
    int64_t *l_29 = &g_30;
    int32_t l_40 = 9L;
    uint8_t *l_41 = &g_27;
    uint64_t *l_1281 = &g_18[6];
    uint64_t **l_1280[7][4] = {{(void*)0,(void*)0,(void*)0,&l_1281},{(void*)0,&l_1281,&l_1281,(void*)0},{&l_1281,&l_1281,&l_1281,&l_1281},{&l_1281,(void*)0,&l_1281,&l_1281},{&l_1281,&l_1281,&l_1281,&l_1281},{(void*)0,(void*)0,(void*)0,&l_1281},{(void*)0,&l_1281,&l_1281,(void*)0}};
    uint64_t l_1290 = 0x307ADC391DFF26D1LL;
    int8_t ***l_1304 = &g_1262;
    uint32_t *l_1340[1];
    uint32_t **l_1339 = &l_1340[0];
    int32_t l_1341[2];
    uint8_t l_1369 = 0xC4L;
    int16_t l_1374 = 0xCEB8L;
    uint8_t l_1385[4][8] = {{0UL,3UL,3UL,0UL,3UL,3UL,0UL,3UL},{0UL,0UL,0xE4L,0UL,0UL,0xE4L,0UL,0UL},{3UL,0UL,3UL,3UL,0UL,3UL,3UL,0UL},{0UL,3UL,3UL,0UL,3UL,3UL,0UL,3UL}};
    int32_t l_1426 = 0x9C735472L;
    uint32_t *l_1468 = &g_734;
    uint32_t **l_1467 = &l_1468;
    const int16_t **l_1634 = &g_672;
    int16_t *l_1638 = &g_252;
    int16_t **l_1637[8][7][4] = {{{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638}},{{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638}},{{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638}},{{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638}},{{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638}},{{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0}},{{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638}},{{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,&l_1638},{&l_1638,(void*)0,&l_1638,&l_1638},{&l_1638,&l_1638,&l_1638,(void*)0}}};
    const int32_t *l_1728 = &g_447;
    uint32_t l_1741 = 0x39629229L;
    int64_t **l_1760 = (void*)0;
    int8_t l_1773[4] = {(-1L),(-1L),(-1L),(-1L)};
    uint64_t l_1783 = 0x72578C0307628DF0LL;
    uint32_t l_1888 = 0x0DA7D07EL;
    int32_t **l_1894[1];
    int32_t *** const l_1893[9] = {&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0],&l_1894[0]};
    const int32_t *l_1958 = &g_150[0][1][2];
    const uint32_t l_1977 = 0xDDF538D9L;
    int16_t l_1993 = 0x4F30L;
    uint8_t ***l_2107 = &g_625;
    uint8_t ****l_2106 = &l_2107;
    uint32_t l_2144 = 4294967287UL;
    uint8_t l_2162 = 0xD8L;
    uint64_t l_2182 = 1UL;
    int16_t l_2183[2];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1340[i] = &g_79;
    for (i = 0; i < 2; i++)
        l_1341[i] = (-5L);
    for (i = 0; i < 1; i++)
        l_1894[i] = &g_42[1][8][0];
    for (i = 0; i < 2; i++)
        l_2183[i] = 0x0CAAL;
    l_1280[4][1] = (((((safe_unary_minus_func_int64_t_s(((*l_29) &= g_18[6]))) == (&g_16 != (void*)0)) , ((*l_29) = func_31((((l_29 != (void*)0) , p_9) && (safe_mul_func_int16_t_s_s(((safe_lshift_func_int8_t_s_s(g_30, 2)) != 0x1501494D85D5FCA4LL), 65533UL))), l_40, l_41, p_9))) ^ 0x0D8AEB47AC7D66F7LL) , l_1280[1][2]);
    for (g_79 = 0; (g_79 != 46); g_79++)
    { /* block id: 600 */
        uint64_t l_1293 = 18446744073709551615UL;
        const uint8_t *l_1303 = &g_180;
        const uint8_t **l_1302 = &l_1303;
        const uint8_t ***l_1301 = &l_1302;
        int8_t ****l_1305 = &l_1304;
        uint16_t l_1310 = 0xF29DL;
        int32_t l_1311[6] = {0x959EDD53L,0x959EDD53L,0x959EDD53L,0x959EDD53L,0x959EDD53L,0x959EDD53L};
        int i;
        for (g_16 = 0; (g_16 > 9); g_16++)
        { /* block id: 603 */
            int32_t *l_1286 = (void*)0;
            int32_t *l_1287 = &l_40;
            int32_t *l_1288 = &g_43[2][5];
            int32_t *l_1289[10][10] = {{(void*)0,(void*)0,&g_737,&g_150[0][3][3],&g_43[2][4],&g_150[0][3][3],&g_737,(void*)0,(void*)0,&g_737},{&g_43[2][4],&g_150[0][3][3],&g_150[1][4][2],&g_150[1][4][2],&g_150[0][3][3],&g_43[2][4],&g_737,&g_43[2][4],&g_150[0][3][3],&g_150[1][4][2]},{(void*)0,(void*)0,(void*)0,&g_150[1][4][2],&g_737,&g_737,&g_150[1][4][2],(void*)0,(void*)0,(void*)0},{(void*)0,&g_43[2][4],(void*)0,&g_150[0][3][3],(void*)0,&g_43[2][4],(void*)0,(void*)0,&g_43[2][4],(void*)0},{&g_43[2][4],(void*)0,(void*)0,&g_43[2][4],(void*)0,&g_150[0][3][3],(void*)0,&g_43[2][4],(void*)0,(void*)0},{(void*)0,(void*)0,&g_150[1][4][2],&g_737,&g_737,&g_150[1][4][2],(void*)0,(void*)0,(void*)0,&g_150[1][4][2]},{&g_150[0][3][3],&g_43[2][4],&g_737,&g_43[2][4],&g_150[0][3][3],&g_150[1][4][2],&g_150[1][4][2],&g_150[0][3][3],&g_43[2][4],&g_737},{(void*)0,(void*)0,&g_737,&g_150[0][3][3],&g_43[2][4],&g_150[0][3][3],&g_737,(void*)0,(void*)0,&g_737},{&g_43[2][4],&g_150[0][3][3],&g_150[1][4][2],&g_150[1][4][2],&g_150[0][3][3],&g_43[2][4],&g_737,&g_43[2][4],&g_150[0][3][3],&g_150[1][4][2]},{(void*)0,(void*)0,(void*)0,&g_150[1][4][2],&g_737,&g_737,&g_150[1][4][2],(void*)0,(void*)0,(void*)0}};
            int i, j;
            ++l_1290;
            l_40 &= l_1293;
        }
        l_1311[3] = (safe_mul_func_int16_t_s_s(((safe_unary_minus_func_int32_t_s((l_1310 &= (safe_mod_func_uint32_t_u_u((safe_lshift_func_int8_t_s_u((l_1301 != &l_1302), ((((*g_626) &= 249UL) ^ (((*l_1305) = l_1304) == (void*)0)) , (safe_sub_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(0xDB19L, p_8)), (l_1290 <= ((l_40 ^= p_11) != (*g_672)))))))), g_868))))) , p_8), p_8));
        return g_868;
    }
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_30 g_43 g_734
 * writes: g_42 g_30 g_43 g_734
 */
static int64_t  func_31(int32_t  p_32, uint16_t  p_33, uint8_t * p_34, int8_t  p_35)
{ /* block id: 6 */
    int32_t **l_44 = &g_42[2][8][1];
    uint32_t *l_947 = &g_734;
    int16_t l_1000[2];
    uint16_t l_1033 = 9UL;
    int32_t l_1039 = 0x0F4B5293L;
    int32_t l_1049 = (-1L);
    int16_t l_1073 = (-7L);
    uint32_t l_1090 = 18446744073709551615UL;
    int32_t l_1193 = 0x7739E3B7L;
    uint32_t l_1230[5][2][1] = {{{0x35B9181FL},{0x1661C7C3L}},{{0x1661C7C3L},{0x35B9181FL}},{{18446744073709551615UL},{0x35B9181FL}},{{0x1661C7C3L},{0x1661C7C3L}},{{0x35B9181FL},{18446744073709551615UL}}};
    const int64_t l_1244[8] = {0x2F8EC180C7D96CB4LL,0xEEDB9805E9FB0603LL,0x2F8EC180C7D96CB4LL,0x2F8EC180C7D96CB4LL,0xEEDB9805E9FB0603LL,0x2F8EC180C7D96CB4LL,0x2F8EC180C7D96CB4LL,0xEEDB9805E9FB0603LL};
    uint16_t l_1245 = 0x79C6L;
    int64_t l_1255[10][1][4] = {{{0xB5F987239223B6ABLL,0xB5F987239223B6ABLL,0x140BEB822D2CC9CFLL,1L}},{{(-8L),1L,(-8L),0x140BEB822D2CC9CFLL}},{{(-8L),0x140BEB822D2CC9CFLL,0x140BEB822D2CC9CFLL,(-8L)}},{{0xB5F987239223B6ABLL,0x140BEB822D2CC9CFLL,1L,0x140BEB822D2CC9CFLL}},{{0x140BEB822D2CC9CFLL,1L,1L,1L}},{{0xB5F987239223B6ABLL,0xB5F987239223B6ABLL,0x140BEB822D2CC9CFLL,1L}},{{1L,0xB5F987239223B6ABLL,1L,(-8L)}},{{1L,(-8L),(-8L),1L}},{{0x140BEB822D2CC9CFLL,(-8L),1L,(-8L)}},{{(-8L),0xB5F987239223B6ABLL,1L,1L}}};
    int8_t **l_1263 = &g_491;
    uint32_t *l_1278 = &l_1230[4][0][0];
    uint64_t l_1279 = 0x82781D8610B9EA35LL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1000[i] = 0x8CBFL;
    (*l_44) = g_42[2][8][1];
    for (g_30 = 19; (g_30 == 13); g_30 = safe_sub_func_int64_t_s_s(g_30, 1))
    { /* block id: 10 */
        const uint64_t *l_58 = &g_18[6];
        const uint64_t **l_57[8];
        int32_t *l_59 = &g_43[1][7];
        int64_t *l_919 = (void*)0;
        int64_t **l_918 = &l_919;
        const int16_t l_961 = 0xD46BL;
        uint32_t l_962 = 0x8EFE25ACL;
        int32_t *l_969 = &g_447;
        uint8_t l_1001 = 0UL;
        int32_t l_1035 = 0L;
        int32_t l_1036 = (-5L);
        int32_t l_1038 = 0xD1087713L;
        int32_t l_1041 = 9L;
        int32_t l_1042 = (-4L);
        int32_t l_1044 = 0x481E1B12L;
        uint32_t l_1082 = 0UL;
        uint32_t l_1111[7];
        uint16_t *l_1163 = &g_609;
        uint16_t l_1191 = 65535UL;
        uint32_t l_1192 = 7UL;
        int i;
        for (i = 0; i < 8; i++)
            l_57[i] = &l_58;
        for (i = 0; i < 7; i++)
            l_1111[i] = 0xE7CBF665L;
    }
    (**l_44) ^= 0xDD576025L;
    l_1279 ^= (((*l_1278) ^= ((*l_947) &= 0xF08DF02AL)) , ((**l_44) ^ 0xB79BE903L));
    return g_734;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_820
 */
static int32_t  func_47(int8_t  p_48, uint64_t  p_49, int64_t * p_50)
{ /* block id: 428 */
    int32_t *l_920 = &g_150[1][1][3];
    int32_t **l_921 = (void*)0;
    g_820 = l_920;
    return p_49;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int64_t * func_51(uint32_t  p_52, const uint64_t ** p_53, int32_t * p_54, uint8_t * p_55, int32_t * p_56)
{ /* block id: 11 */
    uint32_t l_60 = 0xA8E8B88BL;
    uint64_t *l_66 = &g_18[6];
    uint64_t **l_65 = &l_66;
    int8_t *l_67[6] = {&g_16,&g_16,&g_16,&g_16,&g_16,&g_16};
    int32_t l_68 = 0x2B805D31L;
    uint32_t *l_77 = (void*)0;
    uint32_t *l_78 = &g_79;
    int32_t l_82 = 0x0922B85AL;
    int32_t l_783[2];
    uint8_t l_802 = 0UL;
    uint32_t l_807 = 0xEC3CB78EL;
    int64_t l_843[10] = {1L,1L,0x21CB4DF4D0874D15LL,0x21CB4DF4D0874D15LL,1L,1L,1L,0x21CB4DF4D0874D15LL,0x21CB4DF4D0874D15LL,1L};
    int32_t l_852 = 0x156EA3D7L;
    int16_t l_853 = 0xA226L;
    int32_t l_907 = 0x3F2E7BC1L;
    int32_t l_912 = 0x6D4A6130L;
    int i;
    for (i = 0; i < 2; i++)
        l_783[i] = 0x815BC4FDL;
    return &g_449;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint64_t  func_61(uint64_t ** p_62, const int64_t * p_63, int8_t  p_64)
{ /* block id: 13 */
    int32_t *l_69 = &g_43[2][4];
    int32_t *l_70 = &g_43[2][4];
    int32_t *l_71 = &g_43[0][1];
    int32_t l_72[6];
    int32_t *l_73[5][5] = {{&g_43[2][4],&l_72[4],&g_43[2][4],&g_43[1][4],&g_43[2][4]},{&l_72[4],&g_43[0][6],&g_43[2][4],&l_72[5],&g_43[2][4]},{&g_43[2][4],&g_43[2][4],&g_43[0][6],&g_43[2][4],&g_43[2][4]},{&l_72[4],&g_43[2][4],&g_43[2][4],&g_43[2][4],&g_43[2][4]},{&g_43[2][4],&g_43[2][7],&g_43[2][4],&l_72[5],&g_43[2][4]}};
    uint8_t l_74[4][3] = {{255UL,0x1FL,255UL},{0x55L,0x55L,0x55L},{255UL,0x1FL,255UL},{0x55L,0x55L,0x55L}};
    int i, j;
    for (i = 0; i < 6; i++)
        l_72[i] = (-1L);
    --l_74[2][2];
    return g_6[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_30 g_331 g_284 g_282 g_280 g_490 g_43 g_230 g_186 g_150 g_491 g_511 g_6 g_180 g_252 g_363 g_16 g_609 g_623 g_625 g_447 g_626 g_672 g_18 g_673 g_734
 * writes: g_16 g_252 g_284 g_490 g_230 g_511 g_280 g_150 g_27 g_447 g_185 g_79 g_672 g_42 g_449 g_625 g_18
 */
static int64_t * func_91(uint64_t ** p_92, int64_t  p_93, int64_t * p_94)
{ /* block id: 212 */
    uint16_t l_453[2];
    int32_t l_469 = 0L;
    int32_t *l_478 = &g_447;
    int32_t *l_479 = (void*)0;
    int8_t **l_493 = &g_491;
    uint16_t l_494 = 4UL;
    uint32_t *l_496[7] = {&g_363,&g_363,&g_363,&g_363,&g_363,&g_363,&g_363};
    uint32_t **l_495 = &l_496[3];
    int16_t *l_497 = &g_230;
    uint16_t *l_512 = &g_280[3][3][0];
    int32_t l_517 = 0x60BFFC7FL;
    int32_t l_518 = 0x7BA57F69L;
    int32_t l_519[2];
    uint32_t l_520 = 0x64998EAAL;
    int8_t ***l_555[7] = {&g_490,&l_493,&g_490,&g_490,&l_493,&g_490,&g_490};
    uint8_t *l_622[6][1];
    uint8_t **l_621[9] = {&l_622[3][0],&l_622[5][0],&l_622[3][0],&l_622[5][0],&l_622[3][0],&l_622[5][0],&l_622[3][0],&l_622[5][0],&l_622[3][0]};
    uint8_t **l_627 = &l_622[0][0];
    uint8_t l_630 = 0x4EL;
    uint64_t l_639 = 0x55328DF5CA00CAC5LL;
    int32_t l_645 = 0xAC9A27E1L;
    uint8_t l_664[6];
    int64_t l_712 = 1L;
    int i, j;
    for (i = 0; i < 2; i++)
        l_453[i] = 65535UL;
    for (i = 0; i < 2; i++)
        l_519[i] = 1L;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_622[i][j] = &g_284;
    }
    for (i = 0; i < 6; i++)
        l_664[i] = 0xB7L;
lbl_642:
    for (g_16 = 0; (g_16 > 25); g_16++)
    { /* block id: 215 */
        int32_t *l_452[9];
        int32_t **l_476 = &g_42[2][2][2];
        int32_t **l_477 = &g_42[1][3][0];
        uint8_t *l_488 = (void*)0;
        uint8_t *l_489[6];
        int8_t ***l_492[10][8] = {{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_490,(void*)0,(void*)0,&g_490,&g_490,&g_490,&g_490,&g_490},{(void*)0,&g_490,(void*)0,&g_490,&g_490,&g_490,&g_490,(void*)0},{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_490,(void*)0,&g_490,&g_490,&g_490,&g_490,(void*)0,&g_490},{(void*)0,&g_490,&g_490,&g_490,&g_490,&g_490,(void*)0,(void*)0},{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490,&g_490},{&g_490,(void*)0,(void*)0,&g_490,&g_490,&g_490,&g_490,&g_490}};
        int i, j;
        for (i = 0; i < 9; i++)
            l_452[i] = &g_447;
        for (i = 0; i < 6; i++)
            l_489[i] = &g_284;
        if (p_93)
            break;
        l_453[1] = 0L;
        l_469 = ((+(p_93 , 65532UL)) | (safe_div_func_int64_t_s_s(((safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((p_93 <= (g_252 = 0xE350L)), (safe_add_func_uint16_t_u_u((((safe_sub_func_int16_t_s_s(((safe_div_func_int16_t_s_s(p_93, g_27)) > ((p_93 != (safe_rshift_func_uint8_t_u_s(p_93, (0x8613EF29L >= p_93)))) , 0x10F4B3BEL)), p_93)) | g_30) , p_93), p_93)))), 2UL)) , (*p_94)), l_453[1])));
        l_469 ^= (+(safe_mul_func_int16_t_s_s(((((((!(((&g_16 == &g_16) , (g_331 != (g_490 = (l_493 = ((safe_div_func_int64_t_s_s(((l_453[1] || ((l_478 = (void*)0) == l_479)) && ((-1L) < (safe_rshift_func_uint8_t_u_u(((g_284 = ((safe_mul_func_uint8_t_u_u((g_284 && (safe_div_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((247UL <= g_282[3]), p_93)), p_93))), 0x66L)) || g_280[3][3][0])) , 0x91L), p_93)))), (*p_94))) , g_490))))) < p_93)) & l_453[1]) ^ p_93) , p_93) <= 0xA783L) == l_494), g_43[1][3])));
    }
    if ((((*l_497) ^= (0x009ED551L == (l_495 != &l_496[2]))) <= ((*l_512) = ((safe_rshift_func_int8_t_s_u(0xCAL, 2)) , (((safe_lshift_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_u((+(safe_mul_func_int8_t_s_s((((void*)0 == &l_469) == ((g_511 ^= (safe_rshift_func_int8_t_s_s((0x0C62F082L || (safe_rshift_func_uint8_t_u_u(g_186[5], 1))), ((**l_493) = (((void*)0 == &l_478) == g_150[1][1][2]))))) >= 0xDBL)), 0xB3L))), p_93)) & g_6[1]) >= 0x58B8BB48L), 1)) > g_280[0][6][4]) , p_93)))))
    { /* block id: 230 */
        uint16_t l_513 = 65531UL;
        int32_t l_514 = (-1L);
        int32_t *l_515 = &g_150[3][7][1];
        int32_t *l_516[7][6][3] = {{{&g_150[0][3][3],&g_43[1][0],&l_469},{(void*)0,&l_469,&l_514},{&l_469,(void*)0,(void*)0},{&l_469,&g_150[0][4][3],&l_469},{&g_150[3][6][3],&l_514,&l_469},{(void*)0,&l_514,(void*)0}},{{&g_150[0][3][3],&l_469,&l_514},{&l_514,&g_447,&g_43[2][7]},{&l_514,&l_469,&g_43[2][4]},{&l_514,&l_514,&g_150[0][3][2]},{&l_514,&g_150[0][3][3],&l_514},{&l_514,&l_514,&g_150[0][4][3]}},{{&g_150[0][3][2],&l_514,&g_43[2][4]},{&g_447,&g_150[3][1][2],&g_150[0][3][3]},{&g_447,&l_514,&l_514},{&g_447,(void*)0,&g_150[2][7][3]},{&g_150[0][3][2],&g_150[3][5][1],&l_469},{&l_514,(void*)0,(void*)0}},{{&l_514,(void*)0,&g_150[1][3][3]},{&l_514,&l_469,(void*)0},{&l_514,&l_514,&g_150[0][3][3]},{&l_514,&g_150[3][3][1],&g_43[1][0]},{&g_150[0][3][3],&l_514,(void*)0},{&l_469,(void*)0,&g_447}},{{&l_469,(void*)0,&l_514},{&g_150[2][0][1],&l_514,&l_469},{&g_43[1][8],&g_150[3][3][1],(void*)0},{&l_514,&l_514,&g_150[0][3][3]},{&l_469,&l_469,&g_150[3][3][1]},{&l_469,(void*)0,&g_150[3][5][1]}},{{(void*)0,(void*)0,&g_150[3][6][3]},{&g_43[2][4],&g_150[3][5][1],&l_469},{&g_150[3][1][2],(void*)0,&l_469},{&g_150[1][3][3],&l_514,(void*)0},{&g_43[2][4],&g_150[3][1][2],&l_469},{&g_150[3][2][3],&l_514,&l_469}},{{&l_469,&l_514,&g_150[3][6][3]},{&l_469,&g_150[0][3][3],&g_150[3][5][1]},{&g_43[2][7],&l_514,&g_150[3][3][1]},{&g_43[1][5],&l_469,&g_150[0][3][3]},{&g_150[3][6][3],&g_447,(void*)0},{(void*)0,&l_469,&l_469}}};
        int i, j, k;
        l_514 = l_513;
        l_520--;
        l_478 = (void*)0;
        for (l_513 = 0; (l_513 == 34); l_513 = safe_add_func_int16_t_s_s(l_513, 6))
        { /* block id: 236 */
            int8_t l_526 = 1L;
            (*l_515) = p_93;
            l_526 |= (!(g_280[3][9][2] ^ (g_27 |= g_180)));
        }
    }
    else
    { /* block id: 241 */
        uint32_t l_560[10] = {0x682B17C4L,0x482D4FF2L,1UL,0x482D4FF2L,0x682B17C4L,0x682B17C4L,0x482D4FF2L,1UL,0x482D4FF2L,0x682B17C4L};
        int32_t *l_564[3][10][8] = {{{&l_518,&l_469,&l_519[1],&l_469,&l_518,&l_518,&l_469,&l_519[1]},{&l_518,&l_518,&l_469,&l_519[1],&l_469,&l_518,&l_518,&l_469},{&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469},{&l_469,&g_150[0][3][3],&l_519[1],&l_519[1],&g_150[0][3][3],&l_469,&g_150[0][3][3],&l_519[1]},{&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0]},{&l_518,&l_469,&l_519[1],&l_469,&l_518,&l_518,&l_469,&l_519[1]},{&l_518,&l_518,&l_469,&l_519[1],&l_469,&l_518,&l_518,&l_469},{&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469},{&l_469,&g_150[0][3][3],&l_519[1],&l_519[1],&g_150[0][3][3],&l_469,&g_150[0][3][3],&l_519[1]},{&l_519[0],&l_518,&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1]}},{{&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3]},{&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0]},{&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0]},{&l_519[0],&l_518,&g_150[0][3][3],&g_150[0][3][3],&l_518,&l_519[0],&l_518,&g_150[0][3][3]},{&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1]},{&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3]},{&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0]},{&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0]},{&l_519[0],&l_518,&g_150[0][3][3],&g_150[0][3][3],&l_518,&l_519[0],&l_518,&g_150[0][3][3]},{&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1]}},{{&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3]},{&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0]},{&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0]},{&l_519[0],&l_518,&g_150[0][3][3],&g_150[0][3][3],&l_518,&l_519[0],&l_518,&g_150[0][3][3]},{&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1]},{&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0],&g_150[0][3][3]},{&l_469,&l_469,&l_519[0],&g_150[0][3][3],&l_519[0],&l_469,&l_469,&l_519[0]},{&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0]},{&l_519[0],&l_518,&g_150[0][3][3],&g_150[0][3][3],&l_518,&l_519[0],&l_518,&g_150[0][3][3]},{&l_519[1],&l_518,&l_519[1],&l_519[0],&l_519[0],&l_519[1],&l_518,&l_519[1]}}};
        uint16_t * const l_574 = &g_280[3][3][0];
        uint32_t l_596 = 0x53573053L;
        uint64_t *l_607 = &g_18[6];
        uint8_t **l_619 = (void*)0;
        uint16_t l_647 = 0x7961L;
        int16_t *l_662 = &g_230;
        int16_t **l_668 = (void*)0;
        int16_t **l_669 = &l_497;
        const int16_t *l_671[10];
        const int16_t **l_670[8];
        uint32_t l_686 = 0x83B7FF53L;
        uint64_t ***l_697[8][6][1] = {{{(void*)0},{&g_95},{&g_95},{&g_95},{&g_95},{(void*)0}},{{(void*)0},{&g_95},{&g_95},{&g_95},{&g_95},{(void*)0}},{{&g_95},{&g_95},{&g_95},{&g_95},{(void*)0},{(void*)0}},{{&g_95},{&g_95},{&g_95},{&g_95},{(void*)0},{&g_95}},{{(void*)0},{&g_95},{&g_95},{&g_95},{&g_95},{&g_95}},{{&g_95},{(void*)0},{&g_95},{&g_95},{&g_95},{(void*)0}},{{&g_95},{&g_95},{&g_95},{&g_95},{&g_95},{&g_95}},{{(void*)0},{&g_95},{&g_95},{&g_95},{(void*)0},{&g_95}}};
        uint64_t l_724[1][10][6] = {{{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL},{18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL,18446744073709551615UL,18446744073709551615UL,0x12357A7235D7BF56LL}}};
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_671[i] = (void*)0;
        for (i = 0; i < 8; i++)
            l_670[i] = &l_671[8];
        for (l_520 = 0; (l_520 != 35); l_520++)
        { /* block id: 244 */
            uint32_t l_544 = 18446744073709551615UL;
            int64_t *l_556 = &g_511;
            int8_t * const * const l_597 = &g_491;
            int32_t l_610 = 0L;
            int16_t *l_629 = &g_252;
            int32_t l_643[6];
            int8_t l_644 = 0x2DL;
            int64_t l_646 = 0xFF5ECE4E832339B7LL;
            int i;
            for (i = 0; i < 6; i++)
                l_643[i] = 0xA8115647L;
            for (l_517 = (-22); (l_517 != 21); ++l_517)
            { /* block id: 247 */
                uint64_t l_531 = 7UL;
                int32_t *l_532 = &l_519[1];
                int32_t l_539 = 0xFA418E9CL;
                int16_t *l_559 = &g_252;
                int32_t **l_561 = &g_42[1][7][1];
                int32_t **l_562 = &g_42[2][8][1];
                int32_t **l_563[1][3];
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 3; j++)
                        l_563[i][j] = &g_42[2][8][1];
                }
                (*l_532) = l_531;
                for (l_469 = (-14); (l_469 != 26); l_469++)
                { /* block id: 251 */
                    int32_t l_540[8][6] = {{0xD3D7B8DDL,0xD3D7B8DDL,0L,1L,0L,0xD3D7B8DDL},{0L,(-1L),1L,1L,(-1L),0L},{0xD3D7B8DDL,0L,1L,0L,0xD3D7B8DDL,0xD3D7B8DDL},{0x81BC31CBL,0L,0L,0x81BC31CBL,(-1L),0x81BC31CBL},{0x81BC31CBL,(-1L),0x81BC31CBL,0L,0L,0x81BC31CBL},{0xD3D7B8DDL,0xD3D7B8DDL,0L,1L,0L,0xD3D7B8DDL},{0L,(-1L),1L,1L,(-1L),0L},{0xD3D7B8DDL,0L,1L,0L,0xD3D7B8DDL,0xD3D7B8DDL}};
                    int32_t **l_548 = &l_478;
                    int i, j;
                    for (g_447 = 0; (g_447 <= 28); ++g_447)
                    { /* block id: 254 */
                        int32_t *l_541 = &l_519[1];
                        int32_t *l_542 = (void*)0;
                        int32_t *l_543[3][2][2];
                        int32_t **l_547 = &l_532;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 2; j++)
                            {
                                for (k = 0; k < 2; k++)
                                    l_543[i][j][k] = &l_519[1];
                            }
                        }
                        l_519[1] = (safe_add_func_uint64_t_u_u(0xB892E46A498B1C1BLL, l_539));
                        ++l_544;
                        if (p_93)
                            continue;
                        (*l_547) = (void*)0;
                    }
                    (*l_548) = l_532;
                }
                if ((safe_sub_func_int32_t_s_s(((safe_div_func_uint32_t_u_u(0x33B659FAL, ((((safe_lshift_func_int16_t_s_u((&g_331 == (l_555[4] = &g_490)), (((0x99EDL ^ (&g_6[7] == l_556)) && l_544) > ((l_564[2][4][1] = (l_478 = ((0xD87A14ECFFDBC68FLL < (safe_mod_func_uint8_t_u_u((((*l_559) = ((*l_497) &= l_544)) || p_93), l_560[9]))) , (void*)0))) == &l_517)))) || (-4L)) , l_544) ^ l_560[1]))) == p_93), p_93)))
                { /* block id: 267 */
                    uint32_t l_569[7][3] = {{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL},{8UL,8UL,0x7AA39FBEL}};
                    uint16_t **l_575[8][2][3] = {{{&g_185[1],&l_512,(void*)0},{(void*)0,(void*)0,&g_185[1]}},{{&g_185[1],&l_512,&g_185[1]},{&g_185[0],(void*)0,&g_185[0]}},{{(void*)0,(void*)0,&l_512},{&l_512,&l_512,&l_512}},{{(void*)0,(void*)0,(void*)0},{&g_185[2],&l_512,&g_185[2]}},{{(void*)0,&g_185[1],&g_185[2]},{&l_512,&g_185[1],&g_185[1]}},{{(void*)0,(void*)0,&g_185[1]},{&g_185[0],&g_185[2],&g_185[2]}},{{&g_185[1],(void*)0,&g_185[1]},{&l_512,&g_185[1],(void*)0}},{{&l_512,(void*)0,&g_185[1]},{&g_185[2],&g_185[1],&g_185[0]}}};
                    int32_t l_598[5][1];
                    uint64_t *l_608 = &g_18[3];
                    uint32_t *l_613 = (void*)0;
                    uint32_t *l_614 = &l_596;
                    uint8_t ***l_620[4][2][4] = {{{&l_619,&l_619,&l_619,&l_619},{&l_619,&l_619,&l_619,&l_619}},{{&l_619,&l_619,&l_619,(void*)0},{&l_619,&l_619,&l_619,&l_619}},{{&l_619,&l_619,&l_619,&l_619},{&l_619,&l_619,&l_619,&l_619}},{{&l_619,&l_619,&l_619,(void*)0},{(void*)0,&l_619,&l_619,&l_619}}};
                    uint32_t l_628 = 0UL;
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_598[i][j] = 1L;
                    }
                    l_598[4][0] |= (safe_add_func_int64_t_s_s(((*g_490) == ((((((g_79 = (safe_add_func_int64_t_s_s(((p_93 && l_569[1][2]) & ((((((safe_mod_func_int64_t_s_s((safe_lshift_func_int16_t_s_s((-1L), (l_574 != (g_185[1] = l_559)))), (safe_mul_func_uint8_t_u_u((((!(safe_rshift_func_uint16_t_u_s(1UL, (0x535AE0EDL > (safe_lshift_func_uint8_t_u_s((+(((safe_add_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u((safe_add_func_int64_t_s_s((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u(1L, g_252)), p_93)), l_596)), g_150[0][3][3])), p_93)) < (*p_94)), l_569[1][2])) <= p_93) < g_363)), l_569[4][0])))))) , p_93) | 0L), l_544)))) & g_284) , &g_491) != l_597) , l_569[6][1]) <= p_93)), p_93))) , 0x80L) & l_544) || l_569[1][2]) || l_544) , (*g_490))), (*p_94)));
                    l_519[0] = ((p_93 != 0x0174160EL) , (safe_add_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s((**g_490), (l_607 == l_608))), g_609)), ((l_610 = ((&l_564[2][4][1] == &l_564[2][4][1]) ^ p_93)) != l_544))), p_93)));
                    l_598[3][0] = (0x0370051CL ^ (l_610 = (((l_630 = (((((safe_mod_func_int8_t_s_s((((*l_614)++) , 0xB7L), ((safe_rshift_func_int16_t_s_u(((((*l_574) |= l_569[1][2]) && p_93) , (((l_621[6] = l_619) != (void*)0) == ((((g_623[3] != (l_627 = (l_569[1][2] , g_625))) < g_282[2]) , p_93) , 0x11L))), p_93)) ^ 0x9A6D7AECL))) , l_628) , (void*)0) != l_629) , p_93)) > 0xC3L) , (-1L))));
                }
                else
                { /* block id: 280 */
                    int64_t l_631 = (-5L);
                    uint16_t l_632 = 0x770EL;
                    int32_t l_640 = 0xC27E2894L;
                    int32_t l_641 = 0xCB0C979AL;
                    ++l_632;
                    if (p_93)
                        break;
                    l_479 = &g_447;
                    l_641 = (((*l_479) &= ((*l_574) = (g_609 == (0x20L >= p_93)))) , (((safe_rshift_func_uint8_t_u_u((l_640 = ((**l_627) = (safe_lshift_func_uint8_t_u_u(((-6L) >= 0x0E28L), (((1L | l_639) ^ p_93) , (*l_479)))))), p_93)) <= p_93) & 1UL));
                }
                if (l_520)
                    goto lbl_642;
            }
            --l_647;
            for (g_511 = 0; (g_511 <= 12); g_511 = safe_add_func_uint8_t_u_u(g_511, 3))
            { /* block id: 295 */
                const uint32_t l_663 = 6UL;
                l_664[0] &= (safe_mul_func_uint8_t_u_u(((((p_93 <= (safe_add_func_int64_t_s_s((l_610 , (((-5L) & p_93) | g_16)), ((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u(0xB5E1L, (l_610 != ((safe_lshift_func_int16_t_s_u((6UL && ((((l_662 = l_629) != &g_230) , 0L) , 0x9943964B191CC9C6LL)), p_93)) ^ g_6[5])))), p_93)) > l_663)))) , p_93) | 7UL) == 0xEFL), (*g_626)));
            }
        }
        l_518 |= (p_93 , (0xD5L ^ (p_93 , (~(safe_lshift_func_int8_t_s_s((((*l_669) = l_512) == (g_672 = &g_252)), ((safe_mod_func_uint8_t_u_u((&l_622[3][0] == &l_622[5][0]), 0x25L)) > (safe_mul_func_int8_t_s_s((*g_491), 1UL)))))))));
        for (p_93 = (-18); (p_93 < (-11)); p_93 = safe_add_func_int64_t_s_s(p_93, 4))
        { /* block id: 305 */
            int32_t *l_680 = &l_519[1];
            int32_t l_683 = 0L;
            int32_t l_685[4] = {0L,0L,0L,0L};
            int8_t **l_694[3];
            uint64_t ***l_695 = (void*)0;
            int64_t l_698 = 0xA2DB491483F3CD4ALL;
            int i;
            for (i = 0; i < 3; i++)
                l_694[i] = &g_491;
            g_42[2][7][0] = l_680;
            for (g_449 = 0; (g_449 > (-2)); g_449--)
            { /* block id: 309 */
                int16_t l_684 = (-1L);
                uint8_t ***l_693[8][5][6] = {{{&l_619,&l_619,&l_621[6],&l_627,&l_621[6],&l_627},{&l_627,&l_621[0],&l_621[6],&l_621[6],(void*)0,&l_621[6]},{&l_619,&l_627,&l_621[6],&l_621[8],&l_619,&l_627},{&l_621[6],&l_621[8],&l_621[6],(void*)0,&l_621[6],&l_627},{(void*)0,&l_621[6],&l_627,&l_619,(void*)0,&l_621[6]}},{{&l_621[0],(void*)0,&l_627,&l_619,(void*)0,&l_621[6]},{(void*)0,&l_621[6],&l_621[6],&l_619,&l_619,&l_621[6]},{&l_619,&l_621[6],&l_627,&l_621[6],&l_627,&l_621[6]},{&l_621[6],(void*)0,&l_627,&l_621[6],&l_627,&l_627},{&l_619,(void*)0,&l_621[6],&l_627,&l_621[0],&l_627}},{{&l_627,&l_621[6],&l_621[6],&l_619,&l_619,&l_621[6]},{&l_627,&l_627,&l_621[6],&l_627,(void*)0,&l_627},{&l_627,(void*)0,&l_621[6],&l_621[3],&l_627,&l_627},{&l_621[3],&l_627,&l_627,&l_627,&l_621[3],&l_621[6]},{&l_621[6],&l_619,&l_627,(void*)0,&l_627,&l_621[6]}},{{&l_621[8],&l_619,&l_621[6],&l_619,&l_619,&l_621[6]},{(void*)0,&l_619,&l_627,&l_621[0],&l_627,&l_621[6]},{&l_619,(void*)0,&l_627,&l_627,&l_621[6],&l_627},{(void*)0,&l_619,&l_621[6],&l_627,&l_621[6],&l_627},{&l_627,&l_621[6],&l_621[6],&l_619,&l_619,&l_621[6]}},{{&l_621[6],&l_627,&l_621[6],(void*)0,&l_619,&l_627},{&l_619,&l_627,&l_621[6],(void*)0,&l_619,&l_627},{(void*)0,&l_619,&l_627,&l_621[6],(void*)0,&l_621[6]},{&l_621[6],&l_619,&l_627,&l_619,&l_621[8],&l_621[6]},{&l_619,&l_621[8],&l_627,&l_621[6],&l_619,&l_621[8]}},{{&l_621[8],&l_627,&l_627,&l_621[6],(void*)0,&l_627},{&l_627,(void*)0,(void*)0,&l_619,&l_619,(void*)0},{&l_619,&l_619,&l_627,(void*)0,&l_621[6],&l_627},{&l_619,(void*)0,&l_621[8],&l_619,&l_621[6],&l_627},{&l_627,&l_619,&l_621[8],(void*)0,&l_619,&l_627}},{{&l_619,(void*)0,&l_627,(void*)0,&l_621[6],(void*)0},{(void*)0,&l_621[6],(void*)0,&l_627,&l_621[6],&l_627},{(void*)0,&l_621[6],&l_627,&l_627,&l_621[8],&l_621[8]},{&l_621[8],&l_619,&l_627,&l_621[8],&l_627,&l_621[8]},{&l_619,&l_619,&l_627,(void*)0,&l_619,&l_627}},{{&l_619,(void*)0,(void*)0,&l_619,&l_621[8],(void*)0},{&l_627,&l_621[6],&l_627,(void*)0,(void*)0,&l_627},{(void*)0,(void*)0,&l_621[8],&l_627,&l_619,&l_627},{&l_621[6],(void*)0,&l_621[8],&l_619,&l_621[6],&l_627},{&l_621[8],&l_621[8],&l_627,(void*)0,&l_621[6],(void*)0}}};
                uint64_t ****l_696[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int32_t l_699[7];
                int32_t l_700[4][10] = {{0xCB6FE681L,0x43BD9DA3L,(-1L),0x3C442239L,(-1L),0x43BD9DA3L,0xCB6FE681L,(-1L),(-3L),0xEF948C91L},{0x43BD9DA3L,0xCB6FE681L,(-1L),(-3L),0xEF948C91L,0x43BD9DA3L,0x43BD9DA3L,0xEF948C91L,(-3L),(-1L)},{0xCB6FE681L,0xCB6FE681L,9L,0x3C442239L,0xEF948C91L,0x7D2FCCCCL,0xCB6FE681L,0xEF948C91L,6L,0xEF948C91L},{0xCB6FE681L,0x43BD9DA3L,(-1L),0x3C442239L,(-1L),0x43BD9DA3L,0xCB6FE681L,(-1L),(-3L),0xEF948C91L}};
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_699[i] = 4L;
                ++l_686;
                l_700[3][8] |= (l_699[6] = (1L >= (safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((((((((g_625 = &g_626) != (l_619 = &g_626)) > (&g_491 != (l_684 , l_694[1]))) , (((*l_680) = p_93) > (&p_92 == (l_697[4][0][0] = l_695)))) , (*g_672)) <= l_698) != p_93), (*p_94))), 0xE1L))));
                for (l_686 = 0; (l_686 >= 55); l_686 = safe_add_func_uint32_t_u_u(l_686, 3))
                { /* block id: 319 */
                    uint8_t l_709 = 255UL;
                    for (g_27 = 0; (g_27 < 4); g_27 = safe_add_func_int32_t_s_s(g_27, 7))
                    { /* block id: 322 */
                        uint16_t l_705 = 0UL;
                        int32_t **l_706[2][2][10] = {{{&l_478,&g_42[1][2][2],(void*)0,&l_564[2][3][6],(void*)0,&l_478,&l_478,(void*)0,&l_564[2][3][6],(void*)0},{&g_42[1][2][2],&g_42[1][2][2],&l_564[0][4][3],&l_564[0][3][4],(void*)0,&l_564[0][8][1],&g_42[1][2][2],(void*)0,(void*)0,(void*)0}},{{&g_42[1][2][2],&l_478,(void*)0,&l_564[0][3][4],(void*)0,&l_478,&g_42[1][2][2],(void*)0,&l_564[2][3][6],(void*)0},{&l_478,&g_42[1][2][2],(void*)0,&l_564[2][3][6],(void*)0,&l_478,&l_478,(void*)0,&l_564[2][3][6],(void*)0}}};
                        int i, j, k;
                        (*l_680) = l_705;
                        g_42[2][8][1] = &l_685[3];
                    }
                    for (l_630 = 14; (l_630 > 24); l_630 = safe_add_func_uint8_t_u_u(l_630, 3))
                    { /* block id: 328 */
                        return &g_30;
                    }
                    l_709++;
                }
            }
            if ((*l_680))
                break;
        }
        l_517 = ((4294967289UL ^ (0x6CL ^ ((*g_491) = (l_712 >= (g_18[0]++))))) || (safe_mod_func_uint32_t_u_u(((-1L) >= (safe_sub_func_int64_t_s_s((((safe_rshift_func_uint16_t_u_s((safe_add_func_int16_t_s_s((safe_unary_minus_func_int64_t_s(0x7FE860BC0C1C11E6LL)), (l_724[0][2][2] = 0xC902L))), 7)) & (~p_93)) == ((safe_add_func_uint8_t_u_u((p_93 , (safe_sub_func_int8_t_s_s(((((safe_rshift_func_uint16_t_u_s((safe_sub_func_uint64_t_u_u(p_93, g_18[0])), p_93)) , g_673) , g_734) | (*p_94)), p_93))), 4UL)) , 0x34L)), 0UL))), 7L)));
    }
    return &g_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_6 g_16 g_42 g_27 g_150 g_43 g_30 g_180 g_280 g_282 g_252 g_186 g_95 g_284 g_331 g_363 g_361 g_79 g_230
 * writes: g_42 g_27 g_180 g_16 g_150 g_230 g_252 g_280 g_282 g_283 g_284 g_79 g_186 g_331 g_363
 */
static uint8_t  func_111(int32_t  p_112, int32_t  p_113, uint64_t  p_114)
{ /* block id: 20 */
    uint32_t l_144 = 1UL;
    uint16_t l_145 = 3UL;
    int32_t l_328 = 0xB66DB365L;
    int8_t l_329 = (-9L);
    int32_t l_338[5];
    int32_t l_403 = (-9L);
    int32_t **l_442 = &g_42[2][8][1];
    int i;
    for (i = 0; i < 5; i++)
        l_338[i] = 1L;
    for (p_112 = 0; (p_112 != 18); p_112 = safe_add_func_uint16_t_u_u(p_112, 9))
    { /* block id: 23 */
        uint32_t l_118 = 0x0BB1179EL;
        return l_118;
    }
    for (p_113 = 0; (p_113 <= 7); p_113 += 1)
    { /* block id: 28 */
        int16_t *l_251 = &g_252;
        int32_t *l_253 = &g_150[2][3][0];
        int32_t **l_254[2][8][4] = {{{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]}},{{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]},{&l_253,&g_42[2][8][1],&g_42[2][8][1],&g_42[2][8][1]},{&g_42[2][8][1],&g_42[2][8][1],&g_42[2][6][0],&g_42[2][8][1]}}};
        int64_t l_295[9] = {0xD8C443C5AED8269CLL,8L,8L,0xD8C443C5AED8269CLL,8L,8L,0xD8C443C5AED8269CLL,8L,8L};
        const int32_t *l_360 = &g_361;
        uint16_t l_366 = 65535UL;
        int i, j, k;
        (*l_253) = (safe_rshift_func_int16_t_s_s(g_18[p_113], (((*l_251) = (g_230 = func_121(g_18[p_113], g_6[4], (((safe_sub_func_uint64_t_u_u((p_113 < ((+p_112) || (safe_add_func_int64_t_s_s((((((g_18[p_113] != (safe_add_func_int16_t_s_s((func_132(((safe_mul_func_uint8_t_u_u(((safe_add_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u((safe_unary_minus_func_uint8_t_u(g_18[6])), 1)) < l_144), 4)), 0x20L)) == l_145), 1L)) , g_16), g_18[p_113]) < g_43[2][4]), 0xB76FL))) , 9L) && g_18[p_113]) <= g_6[1]) | 0xE5L), l_145)))), g_30)) ^ p_113) & g_18[p_113])))) , (-1L))));
        g_42[2][4][1] = l_253;
        for (g_180 = 0; (g_180 <= 7); g_180 += 1)
        { /* block id: 110 */
            uint32_t l_256 = 4294967295UL;
            int32_t l_278 = 0L;
            int32_t l_312 = (-6L);
            const uint64_t l_339[2][7] = {{0x60CB63392B9A8F95LL,0xD8430CE5974A446ELL,0xD8430CE5974A446ELL,0x60CB63392B9A8F95LL,0xD8430CE5974A446ELL,0xD8430CE5974A446ELL,0x60CB63392B9A8F95LL},{0xD8430CE5974A446ELL,0x60CB63392B9A8F95LL,0xD8430CE5974A446ELL,0xD8430CE5974A446ELL,0x60CB63392B9A8F95LL,0xD8430CE5974A446ELL,0xD8430CE5974A446ELL}};
            int i, j;
            for (g_16 = 0; (g_16 <= 7); g_16 += 1)
            { /* block id: 113 */
                int32_t l_286[1];
                int32_t *l_288 = &g_150[0][3][3];
                int32_t l_330 = 8L;
                int32_t l_368 = 7L;
                uint32_t *l_385 = (void*)0;
                int i;
                for (i = 0; i < 1; i++)
                    l_286[i] = (-1L);
                if ((~g_180))
                { /* block id: 114 */
                    uint32_t l_259 = 4UL;
                    uint8_t *l_273 = &g_27;
                    int64_t *l_279 = (void*)0;
                    int64_t *l_281 = &g_282[1];
                    uint32_t *l_285[5];
                    int32_t l_287 = (-1L);
                    uint16_t *l_308 = &g_280[1][7][2];
                    uint16_t *l_309 = (void*)0;
                    uint16_t *l_310 = (void*)0;
                    uint16_t *l_311 = &g_186[5];
                    uint8_t l_313 = 253UL;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_285[i] = &g_79;
                    (*l_253) &= l_256;
                    if ((l_287 |= ((((0x3EL || ((l_259 | (((safe_div_func_int64_t_s_s(1L, ((safe_mod_func_int32_t_s_s(l_145, ((+(((safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((g_79 = ((0x5BC0205DL ^ (p_112 && (g_284 = (safe_mod_func_int64_t_s_s(1L, (g_283 = ((*l_281) |= (g_280[3][3][0] ^= ((((safe_mod_func_uint8_t_u_u((++(*l_273)), (safe_rshift_func_uint16_t_u_s((l_278 || ((-4L) == 255UL)), 11)))) < 0xD8L) & 0x0006L) && 1L))))))))) != (*l_253))), (-8L))), l_286[0])) ^ l_286[0]) | l_145)) , p_114))) | g_30))) ^ p_114) != 0x87EBL)) <= g_150[3][4][3])) ^ g_252) , l_256) | g_6[5])))
                    { /* block id: 123 */
                        int64_t l_289 = 0x861DA19FEDBC8914LL;
                        l_288 = &p_113;
                        if (l_289)
                            break;
                        p_112 ^= 8L;
                        return p_113;
                    }
                    else
                    { /* block id: 128 */
                        (*l_253) = 0xCB3775B8L;
                    }
                    if ((safe_sub_func_int8_t_s_s((-8L), ((*l_273) &= (g_282[0] < (safe_div_func_int8_t_s_s((!l_295[1]), (+(((safe_add_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u(l_278, (g_282[0] && (safe_add_func_uint32_t_u_u(((((0xBD54L ^ (l_312 |= ((*l_311) = ((*l_308) = (safe_lshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_u(((p_112 <= 0xD797E412L) > (((~(l_256 , p_113)) , 0x13FCL) , 3UL)), 1)) & 0x54L), p_114)))))) || l_313) >= p_112) != g_18[7]), p_112))))) <= g_43[2][4]), 0xABCBB65BL)) >= p_112) != p_113)))))))))
                    { /* block id: 135 */
                        int64_t l_316 = 1L;
                        int32_t l_327 = 0x57E358FFL;
                        l_330 ^= (l_287 = (l_329 = ((g_186[5] | (l_328 = (g_283 = ((safe_add_func_int8_t_s_s((((*l_281) = ((l_316 = ((void*)0 != g_95)) < ((*l_288) = (p_112 < p_114)))) ^ ((safe_lshift_func_int8_t_s_u(g_284, p_113)) <= (safe_sub_func_int32_t_s_s((((safe_add_func_int8_t_s_s(((safe_mul_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u(((void*)0 == &l_256), 0x4DAE90DB2C35B8B9LL)) == g_6[0]), g_16)) < 0xB2C7L), g_252)) <= 0x5CL) , l_256), l_327)))), l_256)) ^ l_144)))) != l_145)));
                        g_331 = g_331;
                        (*l_288) = (safe_sub_func_int32_t_s_s((((((!((*l_273) = 1UL)) , &g_230) != (p_112 , &g_230)) >= ((safe_sub_func_uint64_t_u_u(0x3959362763AF5582LL, p_113)) , 255UL)) & 1L), (safe_unary_minus_func_int64_t_s(p_114))));
                        return l_338[4];
                    }
                    else
                    { /* block id: 148 */
                        if (l_339[1][0])
                            break;
                        g_42[0][7][1] = &p_113;
                        return (*l_253);
                    }
                }
                else
                { /* block id: 153 */
                    uint16_t l_344 = 0x7122L;
                    int32_t l_369 = 0L;
                    uint32_t *l_389 = &g_363;
                    for (g_252 = 2; (g_252 <= 7); g_252 += 1)
                    { /* block id: 156 */
                        const int32_t *l_358 = &g_359[6];
                        const int32_t **l_357 = &l_358;
                        uint32_t *l_362 = &g_363;
                        uint16_t *l_364 = (void*)0;
                        uint16_t *l_365 = &l_145;
                        uint16_t l_367[1];
                        uint8_t *l_386 = &g_284;
                        uint32_t *l_388 = (void*)0;
                        uint32_t **l_387[7];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_367[i] = 1UL;
                        for (i = 0; i < 7; i++)
                            l_387[i] = &l_388;
                        l_369 = ((((safe_mul_func_int16_t_s_s(((safe_div_func_int64_t_s_s((l_344 != ((l_328 = (p_114 , ((safe_sub_func_int64_t_s_s(p_114, (((safe_lshift_func_int16_t_s_u(0x1126L, (safe_lshift_func_uint8_t_u_u(((((safe_sub_func_int32_t_s_s((((((safe_div_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s(((*l_365) = ((p_113 , (l_360 = ((*l_357) = &g_43[2][4]))) == (((*l_362) |= (p_112 , 0x0927EC23L)) , &p_112))), p_114)), g_43[2][4])) , 0x0FL) , p_113) < g_30) ^ (-3L)), 1L)) < 0xC3139589938A15CALL) & (-6L)) , l_366), g_180)))) || 1UL) || (*l_288)))) < l_344))) == p_112)), (-5L))) < l_367[0]), 0x5C4BL)) && l_368) > p_114) < p_114);
                        (*l_253) |= (safe_mod_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u((safe_div_func_uint64_t_u_u((0xEF48FCCCL == ((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((0x6DFDD3D1L || 1L) , (g_18[2] == 4294967292UL)), (l_328 = ((l_339[1][0] && (l_369 >= ((p_113 >= (p_113 , 0xF031B403E6935012LL)) && p_113))) ^ l_338[0])))), 1UL)) || 0xDDL)), 1UL)), p_114)), 0)), p_113));
                        (*l_288) &= ((safe_add_func_int8_t_s_s(l_339[1][0], ((*l_386) = (((+g_30) , &g_79) == (l_385 = l_362))))) == (&g_363 == (l_389 = l_288)));
                    }
                }
                for (l_366 = 0; (l_366 <= 7); l_366 += 1)
                { /* block id: 173 */
                    uint64_t l_398 = 0x01020721CA55128ALL;
                    uint16_t *l_404 = (void*)0;
                    uint16_t *l_405 = &g_186[7];
                    uint32_t *l_410 = &g_363;
                    uint32_t *l_411 = &g_79;
                    uint64_t *l_416[7][5] = {{&g_18[6],&l_398,(void*)0,&l_398,&g_18[6]},{&g_18[p_113],&g_18[p_113],&g_18[p_113],&g_18[p_113],&g_18[p_113]},{&g_18[6],&g_18[6],&g_18[p_113],&l_398,&g_18[p_113]},{&g_18[p_113],&g_18[p_113],(void*)0,&g_18[p_113],&g_18[p_113]},{&g_18[p_113],&l_398,&g_18[p_113],&g_18[6],&g_18[6]},{&g_18[p_113],&g_18[p_113],&g_18[p_113],&g_18[p_113],&g_18[p_113]},{&g_18[6],&l_398,(void*)0,&l_398,&g_18[6]}};
                    uint64_t **l_415 = &l_416[3][3];
                    int i, j;
                    for (l_144 = 1; (l_144 <= 7); l_144 += 1)
                    { /* block id: 176 */
                        uint32_t l_392[3];
                        int i;
                        for (i = 0; i < 3; i++)
                            l_392[i] = 4294967295UL;
                        (*l_288) = (safe_rshift_func_uint16_t_u_s(p_113, 6));
                        l_392[0]--;
                        (*l_253) |= (safe_mul_func_int8_t_s_s(p_112, (g_43[2][4] | ((safe_unary_minus_func_int32_t_s((*l_360))) , (l_398 <= (g_30 , l_256))))));
                    }
                    if ((safe_add_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s(((((l_398 && (++(*l_405))) , &g_42[2][0][2]) == (void*)0) || (safe_lshift_func_uint16_t_u_u(((*l_288) < ((*l_411) &= ((void*)0 != l_410))), (g_180 , (safe_sub_func_int16_t_s_s((~(g_252 = (((*l_415) = &g_18[6]) != &p_114))), l_338[4])))))), p_112)), p_113)))
                    { /* block id: 185 */
                        uint32_t l_438 = 0x9907E119L;
                        uint8_t *l_439 = &g_27;
                        int16_t *l_440[2];
                        int32_t l_441 = 0x5EA591C1L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_440[i] = (void*)0;
                        l_441 ^= (0x4977B972L || (safe_rshift_func_uint8_t_u_s((safe_add_func_uint16_t_u_u(((*l_405) = ((g_230 = (((*l_253) = (safe_rshift_func_int8_t_s_u((((safe_mul_func_uint8_t_u_u(((*l_439) = (((++(*l_410)) , ((*l_251) = (g_252 && (safe_add_func_uint32_t_u_u((((safe_lshift_func_int8_t_s_u((l_312 & 0x1957L), (safe_unary_minus_func_uint64_t_u((safe_lshift_func_int8_t_s_s(p_112, ((p_112 || ((safe_rshift_func_uint8_t_u_s(p_114, 1)) , ((l_339[1][0] >= (safe_sub_func_int16_t_s_s((p_114 , 0xCA44L), p_112))) != l_438))) | 0x8FE13AF0781BA64BLL))))))) ^ p_114) != 0x16L), 4294967294UL))))) & l_144)), 0xB1L)) > g_16) , 0x57L), 4))) >= g_230)) && 0UL)), 0xE7B1L)), 1)));
                    }
                    else
                    { /* block id: 193 */
                        g_42[2][8][1] = l_411;
                    }
                }
                for (g_79 = 0; (g_79 <= 7); g_79 += 1)
                { /* block id: 199 */
                    g_42[1][2][0] = &g_43[1][5];
                }
            }
        }
    }
    (*l_442) = &p_113;
    return p_114;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_121(int16_t  p_122, int8_t  p_123, uint8_t  p_124)
{ /* block id: 100 */
    int16_t l_241 = 0xCFF3L;
    int32_t *l_242 = &g_150[2][7][2];
    int32_t *l_243 = &g_150[3][4][1];
    int32_t *l_244[1][7];
    uint32_t l_245 = 0xAA763E71L;
    uint16_t l_248 = 0x0663L;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
            l_244[i][j] = &g_150[0][5][3];
    }
    l_245--;
    l_248++;
    return p_124;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_27 g_150 g_18 g_180 g_16
 * writes: g_42 g_27 g_180 g_16 g_150
 */
static const uint8_t  func_132(int32_t  p_133, uint32_t  p_134)
{ /* block id: 29 */
    int32_t *l_146 = &g_43[2][4];
    int32_t **l_147 = (void*)0;
    int32_t **l_148 = &g_42[2][8][1];
    int32_t l_153[9];
    uint8_t l_156[6][9][4] = {{{255UL,1UL,0x9DL,0xFFL},{1UL,1UL,0xA8L,0xF5L},{0xB1L,255UL,0xFFL,0xF5L},{0x3CL,1UL,0x3CL,0xFFL},{7UL,1UL,6UL,7UL},{0xB1L,0xFFL,0x9DL,1UL},{0xFFL,1UL,0x9DL,0x9DL},{0xB1L,0xB1L,6UL,0xF5L},{7UL,254UL,0x3CL,1UL}},{{0x3CL,1UL,0xFFL,0x3CL},{0xB1L,1UL,0xA8L,1UL},{1UL,254UL,0x9DL,0xF5L},{255UL,0xB1L,0xFFL,0x9DL},{7UL,1UL,0xE4L,1UL},{7UL,0xFFL,0xFFL,7UL},{255UL,1UL,0x9DL,0xFFL},{1UL,1UL,0xA8L,0xF5L},{0xB1L,255UL,0xFFL,0xF5L}},{{0x3CL,1UL,0x3CL,0xFFL},{0x9DL,0x3CL,7UL,0x9DL},{0xFFL,0xE4L,0xADL,0x3CL},{0xE4L,255UL,0xADL,0xADL},{0xFFL,0xFFL,7UL,254UL},{0x9DL,0x4FL,0xA8L,0x3CL},{0xA8L,0x3CL,0xE4L,0xA8L},{0xFFL,0x3CL,1UL,0x3CL},{0x3CL,0x4FL,0xADL,254UL}},{{6UL,0xFFL,0xE4L,0xADL},{0x9DL,255UL,0xF5L,0x3CL},{0x9DL,0xE4L,0xE4L,0x9DL},{6UL,0x3CL,0xADL,0xE4L},{0x3CL,255UL,1UL,254UL},{0xFFL,6UL,0xE4L,254UL},{0xA8L,255UL,0xA8L,0xE4L},{0x9DL,0x3CL,7UL,0x9DL},{0xFFL,0xE4L,0xADL,0x3CL}},{{0xE4L,255UL,0xADL,0xADL},{0xFFL,0xFFL,7UL,254UL},{0x9DL,0x4FL,0xA8L,0x3CL},{0xA8L,0x3CL,0xE4L,0xA8L},{0xFFL,0x3CL,1UL,0x3CL},{0x3CL,0x4FL,0xADL,254UL},{6UL,0xFFL,0xE4L,0xADL},{0x9DL,255UL,0xF5L,0x3CL},{0x9DL,0xE4L,0xE4L,0x9DL}},{{6UL,0x3CL,0xADL,0xE4L},{0x3CL,255UL,1UL,254UL},{0xFFL,6UL,0xE4L,254UL},{0xA8L,255UL,0xA8L,0xE4L},{0x9DL,0x3CL,7UL,0x9DL},{0xFFL,0xE4L,0xADL,0x3CL},{0xE4L,255UL,0xADL,0xADL},{0xFFL,0xFFL,7UL,254UL},{0x9DL,0x4FL,0xA8L,0x3CL}}};
    uint16_t l_162[1][8][10] = {{{0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL,0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL},{0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL,0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL},{0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL,0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL},{0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL,0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL},{0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL,0x2F55L,0xCA6BL,0xCA6BL,0x2F55L,65530UL},{0x2F55L,0x2F55L,0x2F55L,0x8994L,0x43E8L,0x8994L,0x2F55L,0x2F55L,0x8994L,0x43E8L},{0x8994L,0x2F55L,0x2F55L,0x8994L,0x43E8L,0x8994L,0x2F55L,0x2F55L,0x8994L,0x43E8L},{0x8994L,0x2F55L,0x2F55L,0x8994L,0x43E8L,0x8994L,0x2F55L,0x2F55L,0x8994L,0x43E8L}}};
    uint32_t l_166[6][1][5] = {{{18446744073709551609UL,1UL,1UL,18446744073709551609UL,1UL}},{{1UL,0x06151272L,18446744073709551607UL,0x06151272L,1UL}},{{1UL,18446744073709551609UL,1UL,1UL,18446744073709551609UL}},{{1UL,0xB31CC7D8L,0x87891B7CL,0x06151272L,0x87891B7CL}},{{18446744073709551609UL,18446744073709551609UL,0x1121B7D6L,18446744073709551609UL,18446744073709551609UL}},{{0x87891B7CL,0x06151272L,0x87891B7CL,0xB31CC7D8L,1UL}}};
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_153[i] = 0x1E32E665L;
    (*l_148) = l_146;
    for (p_133 = 0; (p_133 <= 2); p_133 += 1)
    { /* block id: 33 */
        int32_t *l_149 = &g_150[0][3][3];
        int32_t *l_151 = &g_150[0][3][3];
        int32_t l_152 = 0x661B5B55L;
        int32_t *l_154[10] = {&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3],&g_150[0][3][3]};
        int32_t l_155 = 1L;
        uint8_t *l_226[10][8][3] = {{{&l_156[5][7][1],&l_156[5][7][1],(void*)0},{&l_156[5][7][1],&g_180,&l_156[0][7][2]},{&g_27,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,&g_180,&l_156[5][7][1]},{&g_27,(void*)0,(void*)0},{&l_156[5][7][1],&g_180,&l_156[2][1][3]},{&l_156[5][7][1],&l_156[5][0][1],&l_156[5][7][1]}},{{&l_156[3][5][0],&l_156[5][7][1],&l_156[4][7][2]},{(void*)0,(void*)0,(void*)0},{&g_180,(void*)0,(void*)0},{(void*)0,&g_27,&l_156[0][8][1]},{(void*)0,&g_27,&g_27},{&l_156[5][7][1],&l_156[5][7][1],&g_27},{&g_27,&l_156[3][0][0],(void*)0},{&g_27,&l_156[5][7][1],&l_156[5][7][1]}},{{&g_180,&g_27,(void*)0},{&l_156[2][8][0],&g_27,&l_156[5][7][1]},{(void*)0,(void*)0,&g_180},{&g_27,(void*)0,&l_156[5][7][1]},{&l_156[5][7][1],&l_156[5][7][1],(void*)0},{(void*)0,&l_156[5][0][1],&l_156[4][7][2]},{(void*)0,&g_180,&g_27},{&l_156[5][7][1],(void*)0,&g_27}},{{(void*)0,&g_180,&l_156[5][7][1]},{(void*)0,(void*)0,&l_156[5][7][1]},{(void*)0,(void*)0,&g_27},{&l_156[5][7][1],&g_180,&g_27},{(void*)0,&l_156[5][7][1],&l_156[4][7][2]},{(void*)0,&g_180,(void*)0},{&l_156[2][8][0],&g_180,&l_156[5][7][1]},{&l_156[5][7][1],&g_27,&g_180}},{{&l_156[5][7][1],&g_180,&l_156[5][7][1]},{&l_156[5][7][1],&l_156[5][7][1],(void*)0},{&l_156[3][5][0],(void*)0,&l_156[5][7][1]},{(void*)0,&g_180,(void*)0},{&l_156[4][5][0],&g_27,&g_27},{(void*)0,&g_27,&g_27},{&l_156[3][5][0],(void*)0,&l_156[0][8][1]},{&l_156[5][7][1],(void*)0,(void*)0}},{{&l_156[5][7][1],&l_156[2][8][0],(void*)0},{(void*)0,&l_156[3][0][0],&g_180},{&l_156[0][8][0],(void*)0,&l_156[0][7][2]},{(void*)0,&l_156[5][7][1],&g_27},{&l_156[5][7][1],&l_156[4][5][0],(void*)0},{&g_180,&l_156[5][7][1],&l_156[2][0][1]},{&l_156[4][1][1],&g_180,&l_156[5][7][1]},{&l_156[2][1][3],&g_180,&g_180}},{{&l_156[4][5][0],&l_156[5][7][1],&g_27},{&l_156[5][7][1],&l_156[4][5][0],&g_180},{&l_156[5][7][1],&l_156[5][7][1],(void*)0},{&l_156[5][7][1],(void*)0,&g_180},{&g_27,&l_156[3][0][0],&l_156[5][7][1]},{(void*)0,&l_156[2][8][0],&g_27},{&l_156[5][7][1],&l_156[5][7][1],&l_156[2][8][0]},{&l_156[0][8][0],(void*)0,&g_27}},{{&l_156[5][7][1],&g_180,&g_27},{&l_156[4][7][2],&l_156[5][7][1],&g_27},{(void*)0,&l_156[5][7][1],&g_27},{&l_156[5][7][1],&g_180,&g_27},{&l_156[2][1][3],&g_27,&l_156[2][8][0]},{&g_180,&l_156[5][7][1],&g_27},{&l_156[0][8][1],&l_156[5][7][1],&l_156[5][7][1]},{&l_156[4][5][0],&l_156[5][7][1],&g_180}},{{&l_156[5][7][1],(void*)0,(void*)0},{&g_27,(void*)0,&g_180},{&l_156[2][0][1],(void*)0,&g_27},{&l_156[4][7][2],&l_156[3][0][0],&g_180},{(void*)0,(void*)0,&l_156[5][7][1]},{(void*)0,(void*)0,&l_156[2][0][1]},{&l_156[4][7][2],&g_180,(void*)0},{&l_156[2][0][1],&l_156[5][7][1],&g_27}},{{&g_27,&g_180,&l_156[0][7][2]},{&l_156[5][7][1],&g_27,&g_180},{&l_156[4][5][0],(void*)0,(void*)0},{&l_156[0][8][1],&g_180,&g_180},{&g_180,&g_180,&g_180},{&l_156[2][1][3],(void*)0,&l_156[4][7][2]},{&l_156[5][7][1],(void*)0,&g_180},{(void*)0,&g_180,(void*)0}}};
        uint32_t l_234 = 0UL;
        int i, j, k;
        l_156[5][7][1]++;
        for (p_134 = 0; (p_134 <= 2); p_134 += 1)
        { /* block id: 37 */
            int32_t l_159 = 0xA0C94918L;
            int32_t l_160 = 0x9B517F45L;
            int32_t l_161[7];
            const uint64_t *l_179 = &g_18[7];
            const uint64_t **l_178 = &l_179;
            int i;
            for (i = 0; i < 7; i++)
                l_161[i] = 0xD848F3A3L;
            l_162[0][6][0]++;
            if (p_134)
                break;
            (*l_148) = &g_150[0][3][3];
            for (l_155 = 3; (l_155 >= 0); l_155 -= 1)
            { /* block id: 43 */
                int32_t l_165[9][10] = {{(-6L),0x32FBB45DL,(-6L),0x2772FB52L,0xA5C670BDL,1L,0L,6L,2L,1L},{0x32FBB45DL,0xA5C670BDL,(-1L),0x6524C083L,0L,0x3C970C75L,0L,6L,6L,0L},{(-1L),2L,(-6L),(-6L),2L,(-1L),6L,0x324362DDL,0L,(-1L)},{0x2ECB4BFEL,(-1L),6L,0x32FBB45DL,0xAB0F4296L,2L,0x3C970C75L,0xDD7E7900L,5L,0x6524C083L},{0x2ECB4BFEL,0L,0x6524C083L,(-1L),(-1L),(-1L),0x6524C083L,0L,0x2ECB4BFEL,0L},{(-1L),0x6524C083L,0L,0x2ECB4BFEL,0L,0x3C970C75L,0xA5C670BDL,(-6L),1L,0xDD7E7900L},{0x32FBB45DL,6L,(-1L),0x2ECB4BFEL,1L,1L,1L,1L,0x2ECB4BFEL,(-1L)},{(-6L),(-6L),(-1L),(-6L),(-1L),0L,0L,0xDD7E7900L,(-1L),0x324362DDL},{0x2772FB52L,0xDD7E7900L,2L,0x6E028AD1L,0x6524C083L,(-1L),0L,(-6L),0L,(-1L)}};
                uint64_t *l_175[1];
                int8_t l_231 = 0x8BL;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_175[i] = &g_18[1];
                l_166[3][0][1]++;
                (*l_148) = g_42[p_134][(l_155 + 5)][p_133];
                for (g_27 = 0; (g_27 <= 3); g_27 += 1)
                { /* block id: 48 */
                    const uint32_t l_176 = 0x3AA6587CL;
                    for (l_152 = 0; (l_152 <= 8); l_152 += 1)
                    { /* block id: 51 */
                        uint16_t *l_173 = &l_162[0][1][2];
                        int i, j, k;
                        l_153[p_134] = ((safe_mul_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((0xD0F4EB8EL && g_150[p_133][(g_27 + 2)][(p_133 + 1)]), (l_156[(p_133 + 1)][(p_134 + 4)][(p_133 + 1)] > ((((*l_173) ^= l_156[(p_133 + 2)][(l_155 + 2)][g_27]) || g_18[2]) ^ g_150[0][3][3])))), (+(l_175[0] == l_175[0])))) ^ p_133);
                    }
                    return l_176;
                }
            }
        }
        g_42[2][8][1] = ((((safe_lshift_func_int16_t_s_s(0xA836L, 11)) ^ ((void*)0 == &l_162[0][3][9])) != 0xC2C7B452L) , &g_43[0][1]);
        for (g_180 = 0; (g_180 <= 2); g_180 += 1)
        { /* block id: 90 */
            for (g_16 = 0; (g_16 <= 2); g_16 += 1)
            { /* block id: 93 */
                int i, j, k;
                (*l_151) = p_134;
            }
            return g_18[6];
        }
    }
    return g_18[6];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_43[i][j], "g_43[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_150[i][j][k], "g_150[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_180, "g_180", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_186[i], "g_186[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_230, "g_230", print_hash_value);
    transparent_crc(g_252, "g_252", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_280[i][j][k], "g_280[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_282[i], "g_282[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_283, "g_283", print_hash_value);
    transparent_crc(g_284, "g_284", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_359[i], "g_359[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_361, "g_361", print_hash_value);
    transparent_crc(g_363, "g_363", print_hash_value);
    transparent_crc(g_447, "g_447", print_hash_value);
    transparent_crc(g_449, "g_449", print_hash_value);
    transparent_crc(g_511, "g_511", print_hash_value);
    transparent_crc(g_609, "g_609", print_hash_value);
    transparent_crc(g_673, "g_673", print_hash_value);
    transparent_crc(g_734, "g_734", print_hash_value);
    transparent_crc(g_737, "g_737", print_hash_value);
    transparent_crc(g_817, "g_817", print_hash_value);
    transparent_crc(g_829, "g_829", print_hash_value);
    transparent_crc(g_868, "g_868", print_hash_value);
    transparent_crc(g_1007, "g_1007", print_hash_value);
    transparent_crc(g_1386, "g_1386", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_1558[i], "g_1558[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1594, "g_1594", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_1850[i], "g_1850[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1959, "g_1959", print_hash_value);
    transparent_crc(g_2101, "g_2101", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2147[i], "g_2147[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2181, "g_2181", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2232[i], "g_2232[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2316, "g_2316", print_hash_value);
    transparent_crc(g_2365, "g_2365", print_hash_value);
    transparent_crc(g_2650, "g_2650", print_hash_value);
    transparent_crc(g_2680, "g_2680", print_hash_value);
    transparent_crc(g_2707, "g_2707", print_hash_value);
    transparent_crc(g_2751, "g_2751", print_hash_value);
    transparent_crc(g_2774, "g_2774", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 669
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 38
breakdown:
   depth: 1, occurrence: 249
   depth: 2, occurrence: 50
   depth: 3, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 12, occurrence: 2
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 5
   depth: 19, occurrence: 5
   depth: 20, occurrence: 2
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 23, occurrence: 2
   depth: 24, occurrence: 3
   depth: 25, occurrence: 3
   depth: 27, occurrence: 7
   depth: 28, occurrence: 3
   depth: 29, occurrence: 2
   depth: 30, occurrence: 1
   depth: 31, occurrence: 2
   depth: 33, occurrence: 2
   depth: 35, occurrence: 3
   depth: 36, occurrence: 1
   depth: 38, occurrence: 1

XXX total number of pointers: 481

XXX times a variable address is taken: 1164
XXX times a pointer is dereferenced on RHS: 462
breakdown:
   depth: 1, occurrence: 291
   depth: 2, occurrence: 132
   depth: 3, occurrence: 31
   depth: 4, occurrence: 8
XXX times a pointer is dereferenced on LHS: 377
breakdown:
   depth: 1, occurrence: 291
   depth: 2, occurrence: 45
   depth: 3, occurrence: 36
   depth: 4, occurrence: 5
XXX times a pointer is compared with null: 61
XXX times a pointer is compared with address of another variable: 23
XXX times a pointer is compared with another pointer: 9
XXX times a pointer is qualified to be dereferenced: 10118

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1218
   level: 2, occurrence: 440
   level: 3, occurrence: 181
   level: 4, occurrence: 64
   level: 5, occurrence: 2
XXX number of pointers point to pointers: 209
XXX number of pointers point to scalars: 272
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.1
XXX average alias set size: 1.39

XXX times a non-volatile is read: 2499
XXX times a non-volatile is write: 1261
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 490
XXX percentage of non-volatile access: 99.7

XXX forward jumps: 0
XXX backward jumps: 13

XXX stmts: 235
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 30
   depth: 2, occurrence: 28
   depth: 3, occurrence: 34
   depth: 4, occurrence: 54
   depth: 5, occurrence: 61

XXX percentage a fresh-made variable is used: 14.5
XXX percentage an existing variable is used: 85.5
********************* end of statistics **********************/

