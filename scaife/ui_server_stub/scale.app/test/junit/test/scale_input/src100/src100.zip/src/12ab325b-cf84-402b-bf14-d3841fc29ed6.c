/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2519103201
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint8_t  f0;
   const uint16_t  f1;
   volatile uint64_t  f2;
   int32_t  f3;
   int16_t  f4;
   unsigned f5 : 1;
   volatile signed f6 : 5;
   const int32_t  f7;
   int32_t  f8;
   uint16_t  f9;
};

struct S1 {
   struct S0  f0;
   volatile unsigned f1 : 19;
};

/* --- GLOBAL VARIABLES --- */
static uint8_t g_20[5][6][4] = {{{0UL,0xF9L,0x2EL,0x2EL},{0UL,0UL,0UL,2UL},{0x38L,0x09L,5UL,0UL},{5UL,0UL,0UL,5UL},{0UL,0UL,0UL,0UL},{0UL,0x09L,0x2EL,2UL}},{{3UL,0UL,0UL,0x2EL},{0x38L,0xF9L,248UL,0UL},{0x38L,0UL,0UL,0x38L},{3UL,0UL,0x2EL,0UL},{0UL,0xF9L,0UL,2UL},{0UL,3UL,248UL,0x09L}},{{0UL,3UL,0UL,248UL},{0x2EL,5UL,0x38L,0x2EL},{0UL,248UL,0x25L,5UL},{248UL,3UL,0x25L,0x25L},{0UL,0UL,0x38L,0x09L},{0x2EL,6UL,0UL,5UL}},{{0UL,5UL,248UL,0UL},{0UL,5UL,0xF9L,5UL},{5UL,6UL,0x25L,0x09L},{0UL,0UL,248UL,0x25L},{0x2EL,3UL,2UL,5UL},{0x2EL,248UL,248UL,0x2EL}},{{0UL,5UL,0x25L,248UL},{5UL,3UL,0xF9L,0x09L},{0UL,0UL,248UL,0x09L},{0UL,3UL,0UL,248UL},{0x2EL,5UL,0x38L,0x2EL},{0UL,248UL,0x25L,5UL}}};
static int32_t g_36[5] = {0x644BB323L,0x644BB323L,0x644BB323L,0x644BB323L,0x644BB323L};
static int64_t g_42 = 0xF851F08A1BAB0C3ELL;
static int8_t g_55 = (-10L);
static int32_t g_83 = 0xD5126306L;
static int32_t *g_82 = &g_83;
static int32_t ** volatile g_85[8][1] = {{&g_82},{&g_82},{&g_82},{&g_82},{&g_82},{&g_82},{&g_82},{&g_82}};
static int8_t g_94 = 0xA1L;
static int64_t g_100 = (-5L);
static struct S0 g_104 = {8UL,6UL,0x27F84FF3FA32FBB2LL,0x22DDF81CL,0x8C9CL,0,3,5L,0x01475504L,65534UL};/* VOLATILE GLOBAL g_104 */
static struct S1 g_108 = {{246UL,1UL,18446744073709551611UL,-1L,-1L,0,-1,0x287B7884L,0xD301F6F3L,0x3E57L},110};/* VOLATILE GLOBAL g_108 */
static struct S1 g_111 = {{0x2FL,0UL,18446744073709551615UL,-3L,0xEB86L,0,1,0x1F252ACEL,0x1B18FD6BL,0x9D5AL},612};/* VOLATILE GLOBAL g_111 */
static struct S1 *g_110[1] = {&g_111};
static volatile struct S1 g_114 = {{0x8FL,0x6F91L,0xAA844380E064424CLL,-6L,1L,0,-3,0xF2DD6158L,0xF353C284L,0xEC12L},371};/* VOLATILE GLOBAL g_114 */
static uint16_t * volatile g_128 = &g_104.f9;/* VOLATILE GLOBAL g_128 */
static uint64_t g_141 = 0xA979A3CF2E7E6B10LL;
static const int32_t *g_158 = &g_111.f0.f7;
static const int32_t **g_157 = &g_158;
static volatile uint16_t g_165 = 0x2736L;/* VOLATILE GLOBAL g_165 */
static volatile uint16_t *g_164 = &g_165;
static int32_t **g_167[1] = {&g_82};
static int32_t g_186 = 1L;
static int16_t g_188[6][7] = {{1L,1L,0L,(-8L),0xD8F4L,0x8FBDL,1L},{1L,0x8CECL,0x8FBDL,0L,0x8FBDL,0x8CECL,1L},{0x8834L,1L,0xA694L,0L,0x1E0DL,1L,(-8L)},{(-6L),0x9D3CL,1L,(-8L),0x8834L,0xD8F4L,0xD8F4L},{1L,0x7C6CL,0xA694L,0x7C6CL,1L,1L,1L},{1L,0x7C6CL,0x8FBDL,1L,0L,0x0C33L,0x8834L}};
static struct S1 g_206 = {{255UL,0xAA05L,0x822CC248D43A7C1BLL,0x27D02BC7L,0xB079L,0,-3,0x2F59C979L,0x9EA22641L,0xE7F3L},244};/* VOLATILE GLOBAL g_206 */
static uint16_t *g_221 = (void*)0;
static uint64_t g_253 = 0UL;
static uint8_t g_257[4][9] = {{0x2FL,5UL,0x85L,0x85L,5UL,0x2FL,253UL,5UL,253UL},{0x2FL,5UL,0x85L,0x85L,5UL,0x2FL,253UL,5UL,253UL},{0x2FL,5UL,0x85L,0x85L,5UL,0x2FL,253UL,5UL,253UL},{0x2FL,5UL,0x85L,0x85L,5UL,0x2FL,253UL,5UL,253UL}};
static struct S1 g_267 = {{1UL,1UL,18446744073709551615UL,7L,0x358AL,0,4,1L,6L,0UL},356};/* VOLATILE GLOBAL g_267 */
static struct S1 g_368[6] = {{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116},{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116},{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116},{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116},{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116},{{0x5DL,0xCF9CL,2UL,6L,1L,0,-1,0x77F1E95DL,-1L,0xA351L},116}};
static struct S1 g_370[6] = {{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700},{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700},{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700},{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700},{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700},{{0xC4L,1UL,7UL,0xB4AB76CDL,-1L,0,2,-9L,0L,0x7B10L},700}};
static struct S0 g_409 = {0xF4L,1UL,0x2FE08B599706261CLL,0xF79A452FL,-2L,0,2,1L,0xA3F5D10AL,0xCEE6L};/* VOLATILE GLOBAL g_409 */
static volatile struct S1 g_488 = {{0x73L,0x2B62L,0UL,0xF63AB216L,0x7018L,0,2,-6L,9L,65535UL},241};/* VOLATILE GLOBAL g_488 */
static volatile int32_t g_496 = (-1L);/* VOLATILE GLOBAL g_496 */
static struct S1 **g_516 = &g_110[0];
static int32_t g_530 = 0L;
static int32_t * volatile g_540 = &g_104.f3;/* VOLATILE GLOBAL g_540 */
static struct S0 ** volatile g_560 = (void*)0;/* VOLATILE GLOBAL g_560 */
static struct S0 g_564[4][9] = {{{255UL,0x3EBCL,0x5EAC779F7514E4D6LL,-1L,0x13BDL,0,-1,-8L,5L,65535UL},{255UL,9UL,1UL,0x4D6C4803L,0xC9B1L,0,1,1L,0x98A2F33FL,0UL},{255UL,0x3EBCL,0x5EAC779F7514E4D6LL,-1L,0x13BDL,0,-1,-8L,5L,65535UL},{255UL,65529UL,18446744073709551615UL,0x8D0232C4L,0L,0,-4,0xBC48B419L,0L,1UL},{0UL,65535UL,0xB8917E6D4CA81285LL,6L,1L,0,-0,0x15F8D277L,-3L,2UL},{255UL,65529UL,18446744073709551615UL,0x8D0232C4L,0L,0,-4,0xBC48B419L,0L,1UL},{255UL,0x3EBCL,0x5EAC779F7514E4D6LL,-1L,0x13BDL,0,-1,-8L,5L,65535UL},{255UL,9UL,1UL,0x4D6C4803L,0xC9B1L,0,1,1L,0x98A2F33FL,0UL},{255UL,0x3EBCL,0x5EAC779F7514E4D6LL,-1L,0x13BDL,0,-1,-8L,5L,65535UL}},{{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{1UL,1UL,0x53553522C6C558C2LL,-3L,1L,0,-1,0xAA956835L,0x34C6B3CFL,1UL},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L}},{{0x2CL,0xB2B2L,2UL,0x61D00633L,0x4522L,0,-2,0xBFC77086L,0x8A310525L,1UL},{255UL,65529UL,18446744073709551615UL,0x8D0232C4L,0L,0,-4,0xBC48B419L,0L,1UL},{0x2CL,0xB2B2L,2UL,0x61D00633L,0x4522L,0,-2,0xBFC77086L,0x8A310525L,1UL},{0xD8L,0xE5B5L,0x7633DC109275C013LL,0x47E85512L,1L,0,3,0L,-1L,65528UL},{255UL,0x3EBCL,0x5EAC779F7514E4D6LL,-1L,0x13BDL,0,-1,-8L,5L,65535UL},{0xD8L,0xE5B5L,0x7633DC109275C013LL,0x47E85512L,1L,0,3,0L,-1L,65528UL},{0x2CL,0xB2B2L,2UL,0x61D00633L,0x4522L,0,-2,0xBFC77086L,0x8A310525L,1UL},{255UL,65529UL,18446744073709551615UL,0x8D0232C4L,0L,0,-4,0xBC48B419L,0L,1UL},{0x2CL,0xB2B2L,2UL,0x61D00633L,0x4522L,0,-2,0xBFC77086L,0x8A310525L,1UL}},{{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L},{0x61L,65530UL,18446744073709551614UL,1L,0xC109L,0,-1,-7L,1L,0UL},{3UL,65530UL,0x9B3F2469AD85E434LL,2L,0x8D8CL,0,4,0x51CEFB50L,0xD74C4A21L,0x1018L}}};
static uint32_t g_595 = 4294967295UL;
static uint32_t *g_594 = &g_595;
static uint16_t g_602 = 0UL;
static uint64_t *g_605 = &g_253;
static uint64_t **g_604 = &g_605;
static uint64_t *** volatile g_603 = &g_604;/* VOLATILE GLOBAL g_603 */
static struct S0 g_608[1] = {{1UL,3UL,0x815CAE4B2D5BB77ALL,0xD395C6B6L,0x8FF7L,0,-0,0xF52A11FEL,-3L,0x86CCL}};
static struct S0 *g_607 = &g_608[0];
static uint32_t g_630 = 0x95532821L;
static volatile struct S1 g_636 = {{0x11L,0x9FADL,0xCAFDBEF95915443FLL,0x24412FF9L,0x80E0L,0,3,0x905729EFL,1L,0x55AEL},204};/* VOLATILE GLOBAL g_636 */
static volatile struct S1 g_637[8] = {{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325},{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325},{{1UL,1UL,0xC7EB909D2FE86D43LL,0xA637A85CL,0x472FL,0,4,-6L,0L,0x4FAFL},152},{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325},{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325},{{1UL,1UL,0xC7EB909D2FE86D43LL,0xA637A85CL,0x472FL,0,4,-6L,0L,0x4FAFL},152},{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325},{{255UL,0x6668L,0x6F232145E80EB6E8LL,0L,-1L,0,1,0xE9ABF09AL,0x68281887L,0x6744L},325}};
static volatile struct S0 g_664 = {0xBBL,0xF503L,1UL,-8L,0x796DL,0,1,0x6CB0A9C6L,-2L,0x1D50L};/* VOLATILE GLOBAL g_664 */
static volatile struct S1 g_680 = {{0xA4L,0xEFF5L,0x3CF0C660DA0CC52DLL,0xACFE029DL,0xC444L,0,-2,0xBCF90FF3L,0x43FA3B65L,0UL},108};/* VOLATILE GLOBAL g_680 */
static volatile struct S1 g_681[2] = {{{250UL,65530UL,0xB6DA9656AE0EF5EFLL,-1L,0xAFD1L,0,-3,0x7CEC088DL,0x7CEAA265L,65535UL},425},{{250UL,65530UL,0xB6DA9656AE0EF5EFLL,-1L,0xAFD1L,0,-3,0x7CEC088DL,0x7CEAA265L,65535UL},425}};
static struct S1 g_732 = {{0xFEL,0x4447L,0xC06B4BE78696FBF4LL,-4L,-1L,0,-0,0xF1022855L,0xE9D5FDA7L,0xC964L},417};/* VOLATILE GLOBAL g_732 */
static const int8_t g_763 = 0x84L;
static int8_t g_795 = 5L;
static int64_t g_796 = (-1L);
static uint32_t g_814 = 18446744073709551611UL;
static const int64_t g_820 = 0L;
static const volatile int64_t g_823 = 0x7A6EFCE780262A36LL;/* VOLATILE GLOBAL g_823 */
static const volatile int64_t *g_822 = &g_823;
static const volatile int64_t * volatile *g_821 = &g_822;
static int8_t g_829 = 1L;
static struct S1 g_847 = {{0x26L,65535UL,18446744073709551608UL,5L,0xD4E7L,0,-4,-1L,-1L,65526UL},632};/* VOLATILE GLOBAL g_847 */
static int16_t *g_854 = &g_267.f0.f4;
static int16_t **g_853[7][2] = {{&g_854,&g_854},{&g_854,&g_854},{&g_854,&g_854},{&g_854,&g_854},{&g_854,&g_854},{&g_854,&g_854},{&g_854,&g_854}};
static volatile struct S0 g_871 = {0xD6L,0x430DL,1UL,0xFB28FD9CL,0L,0,-3,0x09A36C0EL,0xE3A811B3L,0xDB31L};/* VOLATILE GLOBAL g_871 */
static volatile struct S0 g_892 = {0x9DL,0xD0BAL,5UL,0x2C13D7EBL,-5L,0,0,-1L,0x3CD8CAF4L,0x2900L};/* VOLATILE GLOBAL g_892 */
static struct S0 g_902[3][5][4] = {{{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}}},{{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}}},{{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{6UL,65533UL,1UL,0xCA28272DL,0x7E49L,0,1,0xE9894052L,1L,65530UL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}},{{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0x1DL,0xF3A3L,0xD0CF0BC5FB6AA819LL,0x0D53F4EDL,1L,0,-0,0x4DD1B423L,1L,0x9FBAL},{0UL,65535UL,18446744073709551610UL,0L,0xB30BL,0,1,0L,1L,0x2423L},{0UL,0UL,18446744073709551607UL,1L,2L,0,1,0xF8FCC39BL,0xE2A8068DL,0xD28CL}}}};
static uint64_t ***g_966 = (void*)0;
static struct S0 g_982 = {1UL,0x5FA7L,0x61899579B4CB173BLL,1L,1L,0,-4,0xE7873BB2L,0x696203ADL,0UL};/* VOLATILE GLOBAL g_982 */
static uint64_t ****g_999[8][5][6] = {{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}},{{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966},{&g_966,&g_966,&g_966,&g_966,&g_966,&g_966}}};
static struct S1 g_1019 = {{0xD1L,0x91CDL,0xAE026711D9046BCCLL,0x95AA9C60L,0x3E43L,0,0,0x602EECD4L,9L,0UL},530};/* VOLATILE GLOBAL g_1019 */
static const struct S1 *g_1062 = (void*)0;
static const struct S1 **g_1061 = &g_1062;
static const int32_t *g_1095 = &g_982.f3;
static const int32_t ** volatile g_1094 = &g_1095;/* VOLATILE GLOBAL g_1094 */
static int64_t g_1125 = 0x80DB5DE334A24912LL;
static int16_t g_1126 = (-1L);
static int8_t *g_1135 = &g_795;
static int8_t **g_1134 = &g_1135;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_17(uint8_t  p_18, int8_t  p_19);
static int32_t  func_23(uint32_t  p_24, int16_t  p_25, int8_t  p_26);
static int16_t  func_32(uint32_t  p_33);
static int64_t  func_43(uint64_t  p_44, uint8_t  p_45, const uint64_t  p_46, uint8_t  p_47);
static uint8_t  func_58(int16_t  p_59, int64_t * p_60);
static uint16_t  func_63(uint16_t  p_64);
static uint16_t  func_67(int8_t * p_68, int8_t * p_69, int16_t  p_70, const int16_t  p_71, uint8_t  p_72);
static int8_t * func_73(int8_t * const  p_74);
static int8_t * const  func_75(uint16_t  p_76, int32_t * p_77, int8_t  p_78, int16_t  p_79);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_20 g_982.f0 g_1134 g_854 g_128 g_104.f9 g_1135 g_795 g_108.f0.f1 g_186 g_82 g_157 g_1095 g_982.f3 g_370.f0.f5 g_267.f0.f1 g_104.f2
 * writes: g_1134 g_267.f0.f4 g_111.f0.f4 g_795 g_111.f0.f9 g_267.f0.f0 g_829 g_83 g_158
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_4 = 0x7439CB61L;
    int8_t ***l_1136 = &g_1134;
    int16_t *l_1137 = &g_111.f0.f4;
    uint16_t *l_1138 = &g_111.f0.f9;
    uint32_t l_1139 = 0x0412C964L;
    int32_t l_1140 = 0x1E20491EL;
    uint8_t *l_1141[9] = {&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0,&g_267.f0.f0};
    int8_t *l_1142 = &g_829;
    int64_t l_1143 = 0x6EB0CDA95212119FLL;
    int32_t l_1154 = 0x62CAFD23L;
    int i;
    (*g_82) = ((safe_mod_func_int32_t_s_s(l_4, (((*l_1142) = (safe_lshift_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_u(l_4, (g_267.f0.f0 = (l_1140 = (safe_add_func_uint16_t_u_u(((*l_1138) = (((safe_lshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((*g_1135) &= ((func_17(g_20[0][5][1], (6UL < l_4)) != (((((*l_1137) = ((*g_854) = ((safe_div_func_uint64_t_u_u(0xC040BBBF6C618263LL, l_4)) && (((*l_1136) = g_1134) == &g_1135)))) <= l_4) <= (*g_128)) <= l_4)) && l_4)), 0xC1L)), 15)) == 0x6B9FD0C3L) ^ l_4)), l_1139)))))), l_4)) && g_108.f0.f1) != g_186), 2))) || l_1143))) || (-1L));
    (*g_157) = &l_1140;
    l_1154 &= (((*g_1135) = ((safe_mod_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s((*g_128), l_4)) , 4294967295UL), (*g_1095))), (safe_lshift_func_int16_t_s_u(0x0D9BL, ((g_370[3].f0.f5 == 5UL) ^ l_1139))))) < (g_267.f0.f1 > 0x67588CE7476CD793LL))) <= 1UL);
    return g_104.f2;
}


/* ------------------------------------------ */
/* 
 * reads : g_982.f0
 * writes:
 */
static uint8_t  func_17(uint8_t  p_18, int8_t  p_19)
{ /* block id: 1 */
    int16_t l_1121[9][5] = {{(-1L),8L,0x1569L,0x1569L,8L},{0x457CL,0x9BAEL,7L,7L,0x9BAEL},{(-1L),8L,0x1569L,0x1569L,8L},{0x457CL,0x9BAEL,7L,7L,0x9BAEL},{(-1L),8L,0x1569L,8L,0x779FL},{0L,(-5L),0x9BAEL,0x9BAEL,(-5L)},{(-7L),0x779FL,8L,8L,0x779FL},{0L,(-5L),0x9BAEL,0x9BAEL,(-5L)},{(-7L),0x779FL,8L,8L,0x779FL}};
    int32_t l_1129 = 0x42596164L;
    int i, j;
    for (p_19 = 0; (p_19 >= (-10)); --p_19)
    { /* block id: 4 */
        int32_t l_27[4] = {0xBC23CEA2L,0xBC23CEA2L,0xBC23CEA2L,0xBC23CEA2L};
        int32_t l_1122 = 3L;
        int64_t *l_1123 = (void*)0;
        int64_t *l_1124[3];
        int8_t *l_1127 = (void*)0;
        int8_t *l_1128[5][4] = {{&g_829,&g_94,&g_94,&g_829},{&g_94,&g_829,&g_94,&g_94},{&g_829,&g_829,&g_795,&g_829},{&g_829,&g_94,&g_94,&g_829},{&g_94,&g_829,&g_94,&g_94}};
        int32_t *l_1131 = &g_267.f0.f3;
        int i, j;
        for (i = 0; i < 3; i++)
            l_1124[i] = &g_1125;
    }
    return g_982.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_157 g_111.f0.f3
 * writes: g_158 g_111.f0.f3
 */
static int32_t  func_23(uint32_t  p_24, int16_t  p_25, int8_t  p_26)
{ /* block id: 537 */
    int32_t *l_1130 = &g_111.f0.f3;
    (*g_157) = l_1130;
    (*l_1130) = 0x738BBC1DL;
    (*l_1130) = (*l_1130);
    return (*l_1130);
}


/* ------------------------------------------ */
/* 
 * reads : g_36 g_368.f0.f2 g_104.f9 g_157 g_530 g_206.f0.f4 g_206.f0.f3 g_368.f0.f1 g_540 g_409.f4 g_167 g_104.f7 g_108.f0.f8 g_368.f0.f3 g_186 g_114.f0.f8 g_257 g_594 g_595 g_370.f0.f3 g_368.f0.f7 g_108.f0.f3 g_602 g_603 g_206.f0.f9 g_111.f0.f4 g_636 g_637 g_94 g_83 g_368.f0.f9 g_604 g_605 g_253 g_267.f0.f8 g_111.f0.f0 g_564.f4 g_108.f0.f5 g_664 g_20 g_370.f0.f4 g_188 g_680 g_681 g_370.f0.f7 g_128 g_370.f0.f9 g_368.f0.f5 g_111.f0.f3 g_206.f0.f8 g_158 g_267.f0.f9 g_111.f0.f6 g_732 g_104.f1 g_564.f9 g_206.f0.f7 g_108.f0.f0 g_104.f2 g_608.f4 g_114.f0.f3 g_100 g_821 g_822 g_823 g_104.f3 g_982 g_409.f3 g_409.f0 g_104.f0 g_854 g_267.f0.f4 g_1061 g_847.f0.f5 g_608.f7 g_516 g_1094 g_608.f8 g_902.f3 g_111.f0.f5
 * writes: g_36 g_42 g_55 g_82 g_516 g_158 g_206.f0.f4 g_206.f0.f3 g_104.f3 g_409.f4 g_94 g_370.f0.f0 g_186 g_108.f0.f3 g_111.f0.f3 g_267.f0.f8 g_108.f0.f0 g_604 g_607 g_368.f0.f3 g_206.f0.f9 g_111.f0.f4 g_206.f0.f0 g_368.f0.f9 g_111.f0.f0 g_20 g_370.f0.f4 g_104.f9 g_602 g_206.f0.f8 g_253 g_104.f4 g_100 g_966 g_796 g_595 g_608.f9 g_409.f3 g_409.f0 g_999 g_257 g_409.f8 g_267.f0.f4 g_110 g_1095
 */
static int16_t  func_32(uint32_t  p_33)
{ /* block id: 5 */
    int32_t *l_35 = &g_36[3];
    int64_t *l_41 = &g_42;
    int8_t *l_54 = &g_55;
    int32_t *l_81 = &g_36[4];
    int32_t **l_80[6] = {(void*)0,(void*)0,&l_81,(void*)0,(void*)0,&l_81};
    int i;
    (*l_35) ^= 0xBAE055A2L;
    (*l_35) = g_36[3];
    (*l_35) = ((((*l_41) = (safe_lshift_func_int8_t_s_s(g_36[4], 3))) < ((func_43((g_36[3] ^ ((safe_lshift_func_uint8_t_u_s(((*l_35) ^ 0x04523830AE734F12LL), 6)) & (safe_mod_func_uint64_t_u_u((*l_35), (safe_rshift_func_uint16_t_u_u((((*l_54) = 1L) | (safe_lshift_func_uint8_t_u_s(g_36[3], 2))), 5)))))), (((func_58((safe_lshift_func_uint16_t_u_u(func_63(((safe_lshift_func_uint16_t_u_s(func_67(func_73(func_75(g_36[3], (g_82 = l_35), p_33, (*l_81))), l_54, p_33, g_368[0].f0.f2, g_104.f9), p_33)) == 0x65L)), 13)), &g_796) & (*l_81)) , p_33) , p_33), p_33, g_608[0].f8) > 18446744073709551613UL) == g_111.f0.f5)) , p_33);
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_157 g_128 g_104.f9 g_902.f3 g_854 g_267.f0.f4 g_732.f1
 * writes: g_158
 */
static int64_t  func_43(uint64_t  p_44, uint8_t  p_45, const uint64_t  p_46, uint8_t  p_47)
{ /* block id: 527 */
    int32_t *l_1097 = &g_902[1][4][2].f3;
    struct S1 ***l_1100 = &g_516;
    struct S1 ****l_1101 = &l_1100;
    struct S1 * const *l_1103 = &g_110[0];
    struct S1 * const **l_1102 = &l_1103;
    uint16_t * const *l_1106 = &g_221;
    int8_t l_1107 = 0x3BL;
    int32_t *l_1108[1];
    uint64_t l_1109[5][2][4] = {{{18446744073709551610UL,0xD037B11680C3AB29LL,1UL,18446744073709551613UL},{0x1A41D58261B49078LL,0x3DF6A0E477032B1CLL,18446744073709551615UL,18446744073709551613UL}},{{8UL,0xD037B11680C3AB29LL,8UL,18446744073709551615UL},{0x1723D5D2ED82DECELL,18446744073709551610UL,18446744073709551613UL,0x1723D5D2ED82DECELL}},{{0x1A41D58261B49078LL,18446744073709551615UL,0UL,18446744073709551610UL},{18446744073709551615UL,0xD037B11680C3AB29LL,0UL,0UL}},{{0x1A41D58261B49078LL,0x1A41D58261B49078LL,18446744073709551613UL,18446744073709551613UL},{0x1723D5D2ED82DECELL,0x1AA41A07909B4E2ALL,8UL,18446744073709551610UL}},{{8UL,18446744073709551610UL,18446744073709551615UL,8UL},{0x1A41D58261B49078LL,18446744073709551610UL,1UL,18446744073709551610UL}}};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1108[i] = &g_267.f0.f3;
    (*g_157) = l_1097;
    l_1109[0][1][0] ^= (safe_mul_func_uint8_t_u_u(((((((*g_128) ^ (-7L)) & p_45) , (((*l_1101) = l_1100) != l_1102)) | ((*l_1097) < (*l_1097))) || (safe_lshift_func_uint8_t_u_u(((((l_1106 != ((((*l_1097) , 0xF16AL) > l_1107) , &g_164)) != (-1L)) < (*l_1097)) | (*g_854)), g_732.f1))), (*l_1097)));
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_104.f3 g_636.f0.f9 g_594 g_188 g_157 g_111.f0.f0 g_982 g_409.f3 g_409.f0 g_595 g_104.f0 g_821 g_822 g_823 g_854 g_267.f0.f4 g_257 g_1061 g_128 g_104.f9 g_847.f0.f5 g_608.f7 g_516 g_1094
 * writes: g_104.f3 g_966 g_796 g_595 g_608.f9 g_100 g_158 g_409.f3 g_409.f4 g_516 g_409.f0 g_999 g_257 g_409.f8 g_267.f0.f4 g_110 g_1095 g_368.f0.f3
 */
static uint8_t  func_58(int16_t  p_59, int64_t * p_60)
{ /* block id: 463 */
    uint32_t l_960 = 0xC484D023L;
    struct S1 *l_961 = (void*)0;
    uint64_t ***l_963 = &g_604;
    int32_t l_970 = 6L;
    int32_t l_990 = (-1L);
    int32_t *l_992 = &g_982.f3;
    uint8_t *l_1002[3];
    uint8_t **l_1001 = &l_1002[2];
    uint8_t l_1032 = 0xC4L;
    int16_t l_1084 = 0L;
    int32_t l_1086 = 0x693DC406L;
    int i;
    for (i = 0; i < 3; i++)
        l_1002[i] = &g_20[3][0][3];
    for (g_104.f3 = (-24); (g_104.f3 >= 17); g_104.f3 = safe_add_func_uint8_t_u_u(g_104.f3, 9))
    { /* block id: 466 */
        uint64_t l_962 = 5UL;
        uint64_t ***l_965 = (void*)0;
        uint64_t ****l_964[3][10][1] = {{{&l_963},{&l_965},{&l_965},{&l_963},{&l_965},{&l_963},{&l_965},{&l_965},{&l_963},{&l_963}},{{&l_965},{&l_965},{&l_963},{&l_965},{&l_963},{&l_965},{&l_965},{&l_963},{&l_963},{&l_965}},{{&l_965},{&l_963},{&l_965},{&l_963},{&l_965},{&l_965},{&l_963},{&l_963},{&l_965},{&l_965}}};
        uint16_t *l_968 = &g_608[0].f9;
        int32_t l_969 = 0xFCC56DD8L;
        uint32_t l_977 = 0xBBB12674L;
        uint32_t l_1000 = 1UL;
        struct S1 *l_1018 = &g_1019;
        const uint16_t l_1069[10] = {65533UL,0xE655L,65535UL,65535UL,0xE655L,65533UL,0xE655L,65535UL,65535UL,0xE655L};
        int32_t l_1077[1];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1077[i] = 0x6034F3C1L;
        l_970 |= (l_969 &= (((((*l_968) = (((safe_mod_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((((*g_594) = ((((-4L) > ((*p_60) = ((safe_lshift_func_uint8_t_u_s((l_960 = 0x2BL), ((void*)0 != l_961))) > ((l_962 , l_963) != (g_966 = &g_604))))) || (+g_636.f0.f9)) <= (-1L))) < l_962), p_59)), g_188[1][0])) , (void*)0) != &g_822)) < p_59) , p_59) && p_59));
        for (g_100 = 20; (g_100 != (-17)); g_100 = safe_sub_func_int64_t_s_s(g_100, 1))
        { /* block id: 476 */
            int32_t l_986[1][2];
            int32_t l_987[5];
            int16_t l_988 = 0x453FL;
            uint32_t * const l_989 = (void*)0;
            int32_t *l_991 = &g_409.f3;
            struct S1 **l_1066[10] = {&l_1018,&g_110[0],&g_110[0],&g_110[0],&g_110[0],&l_1018,&g_110[0],&g_110[0],&g_110[0],&g_110[0]};
            int8_t l_1085 = 0xB1L;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_986[i][j] = 6L;
            }
            for (i = 0; i < 5; i++)
                l_987[i] = 0L;
            (*g_157) = &l_969;
            (*l_991) &= ((l_990 = (safe_rshift_func_int8_t_s_u(((l_969 < (safe_mul_func_uint8_t_u_u((l_977 > l_969), g_111.f0.f0))) < (safe_sub_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((((((g_982 , (!p_59)) <= p_59) , ((l_987[4] = (safe_lshift_func_uint16_t_u_s(l_986[0][1], 11))) >= l_988)) , l_989) != l_989), p_59)), p_59))), 7))) <= l_986[0][1]);
            l_992 = &l_990;
            for (g_409.f4 = (-25); (g_409.f4 >= 7); ++g_409.f4)
            { /* block id: 484 */
                struct S1 ***l_995 = (void*)0;
                struct S1 ***l_996 = &g_516;
                int32_t l_1010 = 0L;
                int32_t *l_1011 = &l_987[4];
                int32_t l_1028 = 0xED7B2D4AL;
                int32_t l_1029 = (-3L);
                int32_t l_1068[10] = {0xDDB14477L,0xDDB14477L,1L,0xDDB14477L,0xDDB14477L,1L,0xDDB14477L,0xDDB14477L,1L,0xDDB14477L};
                int32_t *l_1078 = &g_368[0].f0.f3;
                int32_t *l_1079 = &g_409.f3;
                int32_t *l_1080 = (void*)0;
                int32_t *l_1081 = &g_108.f0.f3;
                int32_t *l_1082 = &l_969;
                int32_t *l_1083[6] = {&g_564[1][5].f3,&l_1010,&l_1010,&g_564[1][5].f3,&l_1010,&l_1010};
                uint16_t l_1087 = 8UL;
                int i;
                (*l_1011) &= ((*l_992) = ((((&l_961 == ((*l_996) = &g_110[0])) , ((((g_999[7][3][1] = ((++g_409.f0) , &l_963)) != &l_965) == ((l_1000 ^= (*g_594)) == ((l_1001 = (void*)0) == &l_1002[1]))) , 0xD3L)) < ((safe_mul_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((((~((safe_sub_func_int16_t_s_s((l_1010 || 0x1A2103AFL), l_977)) , 0xD563L)) | p_59) , 65535UL), (*l_991))), p_59)) || g_104.f0)) | (**g_821)));
                if ((safe_add_func_int64_t_s_s((**g_821), ((safe_mod_func_uint8_t_u_u((((*l_991) >= 0x9FL) || (18446744073709551615UL && ((((safe_div_func_uint16_t_u_u((l_1018 != (void*)0), (*g_854))) >= ((safe_mul_func_int16_t_s_s(((*l_992) = ((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(((*l_968) = (safe_sub_func_uint8_t_u_u((--g_257[3][8]), ((*g_594) || (((*p_60) = 0xD83AF8B44F719EA0LL) , (*l_992)))))), 7)) != p_59), l_1032)) , (*l_991))), (*g_854))) != 0x4C6CL)) >= p_59) || 0UL))), (-1L))) | l_969))))
                { /* block id: 496 */
                    (*g_157) = (void*)0;
                }
                else
                { /* block id: 498 */
                    uint64_t l_1067 = 0x041A87B9FBE338A1LL;
                    for (g_409.f8 = 2; (g_409.f8 >= 0); g_409.f8 -= 1)
                    { /* block id: 501 */
                        const struct S1 **l_1063 = &g_1062;
                        uint32_t *l_1070 = &l_1000;
                        int32_t *l_1071 = &g_368[0].f0.f3;
                        int32_t *l_1072 = (void*)0;
                        int32_t *l_1073[6][9] = {{&g_902[1][4][2].f3,&g_608[0].f3,(void*)0,&g_608[0].f3,&g_902[1][4][2].f3,&g_902[1][4][2].f3,&g_608[0].f3,(void*)0,&g_608[0].f3},{&g_608[0].f3,(void*)0,(void*)0,(void*)0,(void*)0,&g_608[0].f3,(void*)0,(void*)0,(void*)0},{&g_902[1][4][2].f3,&g_902[1][4][2].f3,&g_608[0].f3,(void*)0,&g_608[0].f3,&g_902[1][4][2].f3,&g_902[1][4][2].f3,&g_608[0].f3,(void*)0},{&g_732.f0.f3,(void*)0,&g_732.f0.f3,&g_608[0].f3,&g_608[0].f3,&g_732.f0.f3,&g_902[1][4][2].f3,(void*)0,&g_732.f0.f3},{(void*)0,&g_732.f0.f3,&g_732.f0.f3,(void*)0,&g_902[1][4][2].f3,(void*)0,&g_732.f0.f3,&g_732.f0.f3,(void*)0},{&g_608[0].f3,&g_732.f0.f3,(void*)0,&g_732.f0.f3,&g_608[0].f3,&g_608[0].f3,&g_732.f0.f3,(void*)0,&g_732.f0.f3}};
                        uint32_t l_1074 = 0UL;
                        int i, j;
                        (*g_516) = (((*l_1070) = (safe_mul_func_uint8_t_u_u((p_59 <= ((*l_1011) < (((((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((safe_div_func_uint8_t_u_u((((safe_lshift_func_uint8_t_u_s((safe_sub_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(p_59, (safe_rshift_func_int16_t_s_s((safe_div_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((+0x1911DAB4L), 4)), (safe_mul_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((((*g_854) ^= (+l_969)) ^ (((l_1063 = g_1061) != ((safe_lshift_func_uint8_t_u_s(7UL, (*l_1011))) , l_1066[4])) , (*g_128))), g_847.f0.f5)), l_1067)))), (*g_594))), 14)))), l_1068[2])), 7)) , l_1069[9]) , (*l_1011)), p_59)) > p_59), 1L)), 0x32CFL)) , l_1067) | 0xF5L) <= 18446744073709551615UL) == 0x6AA5L))), g_608[0].f7))) , l_1018);
                        ++l_1074;
                    }
                }
                ++l_1087;
                for (g_595 = (-13); (g_595 != 3); g_595++)
                { /* block id: 512 */
                    for (l_990 = 0; (l_990 < 21); l_990++)
                    { /* block id: 515 */
                        int32_t **l_1096 = &l_1079;
                        (*g_1094) = ((*g_157) = &l_987[4]);
                        (*l_1078) = (-2L);
                        (*g_157) = ((*l_1096) = &l_987[4]);
                    }
                }
            }
        }
    }
    return p_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_206.f0.f4 g_206.f0.f3 g_368.f0.f1 g_540 g_409.f4 g_167 g_104.f7 g_108.f0.f8 g_368.f0.f3 g_114.f0.f8 g_257 g_594 g_595 g_370.f0.f3 g_368.f0.f7 g_108.f0.f3 g_602 g_603 g_636 g_637 g_94 g_83 g_368.f0.f9 g_604 g_605 g_253 g_564.f4 g_108.f0.f5 g_664 g_20 g_370.f0.f4 g_104.f9 g_188 g_680 g_681 g_370.f0.f7 g_128 g_370.f0.f9 g_368.f0.f5 g_157 g_158 g_267.f0.f9 g_111.f0.f6 g_732 g_104.f1 g_564.f9 g_206.f0.f7 g_108.f0.f0 g_104.f2 g_608.f4 g_111.f0.f4 g_114.f0.f3 g_821 g_822 g_823 g_186 g_206.f0.f9 g_267.f0.f8 g_111.f0.f0 g_111.f0.f3 g_206.f0.f8 g_100
 * writes: g_206.f0.f4 g_206.f0.f3 g_104.f3 g_409.f4 g_94 g_82 g_370.f0.f0 g_186 g_108.f0.f3 g_111.f0.f3 g_267.f0.f8 g_108.f0.f0 g_604 g_607 g_368.f0.f3 g_206.f0.f9 g_111.f0.f4 g_206.f0.f0 g_368.f0.f9 g_111.f0.f0 g_20 g_370.f0.f4 g_104.f9 g_602 g_206.f0.f8 g_158 g_253 g_104.f4 g_100
 */
static uint16_t  func_63(uint16_t  p_64)
{ /* block id: 225 */
    int64_t l_542 = 1L;
    int32_t *l_565 = &g_368[0].f0.f3;
    struct S0 * const *l_638 = (void*)0;
    uint64_t **l_648 = &g_605;
    int32_t l_739 = 0x3B58CB01L;
    int64_t *l_808[4][7] = {{(void*)0,&l_542,&l_542,(void*)0,&l_542,&l_542,(void*)0},{&g_100,(void*)0,&g_100,&l_542,&l_542,&l_542,&g_100},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_542,&l_542,&g_100,(void*)0,&g_100,&l_542,&l_542}};
    const int8_t l_811[2] = {0xA9L,0xA9L};
    const int64_t * const l_819 = &g_820;
    const int64_t * const *l_818 = &l_819;
    uint32_t **l_826 = &g_594;
    int32_t l_840[2][9] = {{0x796C91E8L,(-3L),9L,9L,(-3L),0x796C91E8L,(-3L),9L,9L},{(-1L),(-1L),0x796C91E8L,9L,0x796C91E8L,(-1L),(-1L),0x796C91E8L,9L}};
    uint16_t **l_923 = (void*)0;
    uint16_t ***l_922 = &l_923;
    int64_t l_930[3][1][4] = {{{0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL}},{{0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL}},{{0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL,0x47E5620F77864514LL}}};
    uint64_t l_942 = 18446744073709551615UL;
    int i, j, k;
    for (g_206.f0.f4 = 0; (g_206.f0.f4 != 8); ++g_206.f0.f4)
    { /* block id: 228 */
        int16_t *l_538 = (void*)0;
        int32_t l_543 = 0xFF44478EL;
        uint8_t *l_547 = &g_370[3].f0.f0;
        uint64_t *l_552 = (void*)0;
        int32_t l_576 = (-1L);
        for (p_64 = (-20); (p_64 == 31); p_64 = safe_add_func_int64_t_s_s(p_64, 9))
        { /* block id: 231 */
            int64_t l_541 = 8L;
            uint8_t *l_551[5][1][3] = {{{&g_20[0][4][3],&g_104.f0,&g_20[0][4][3]}},{{&g_20[0][4][3],&g_267.f0.f0,&g_104.f0}},{{&g_267.f0.f0,&g_20[0][4][3],&g_20[0][4][3]}},{{&g_104.f0,&g_20[0][4][3],(void*)0}},{{&g_20[0][5][1],&g_267.f0.f0,&g_108.f0.f0}}};
            const uint64_t *l_555 = &g_253;
            struct S0 *l_556 = &g_104;
            struct S0 *l_563 = &g_564[1][5];
            int i, j, k;
            for (g_206.f0.f3 = (-7); (g_206.f0.f3 < (-16)); g_206.f0.f3 = safe_sub_func_uint64_t_u_u(g_206.f0.f3, 7))
            { /* block id: 234 */
                int16_t *l_537[5][2][8] = {{{&g_188[2][1],&g_108.f0.f4,&g_206.f0.f4,(void*)0,&g_206.f0.f4,&g_267.f0.f4,&g_370[3].f0.f4,&g_108.f0.f4},{&g_188[2][1],&g_188[1][0],&g_111.f0.f4,&g_370[3].f0.f4,&g_370[3].f0.f4,&g_206.f0.f4,&g_111.f0.f4,&g_368[0].f0.f4}},{{(void*)0,&g_370[3].f0.f4,&g_206.f0.f4,(void*)0,(void*)0,&g_370[3].f0.f4,&g_370[3].f0.f4,&g_108.f0.f4},{&g_108.f0.f4,&g_206.f0.f4,&g_111.f0.f4,&g_111.f0.f4,&g_111.f0.f4,&g_111.f0.f4,&g_206.f0.f4,&g_108.f0.f4}},{{&g_370[3].f0.f4,&g_206.f0.f4,(void*)0,&g_370[3].f0.f4,&g_111.f0.f4,&g_108.f0.f4,&g_370[3].f0.f4,&g_111.f0.f4},{&g_267.f0.f4,&g_206.f0.f4,&g_111.f0.f4,&g_370[3].f0.f4,&g_370[3].f0.f4,&g_108.f0.f4,(void*)0,&g_108.f0.f4}},{{&g_370[3].f0.f4,&g_206.f0.f4,&g_368[0].f0.f4,&g_206.f0.f4,&g_108.f0.f4,&g_111.f0.f4,&g_188[4][0],&g_267.f0.f4},{&g_108.f0.f4,&g_206.f0.f4,(void*)0,&g_368[0].f0.f4,&g_108.f0.f4,&g_370[3].f0.f4,&g_370[3].f0.f4,&g_370[3].f0.f4}},{{&g_206.f0.f4,&g_370[3].f0.f4,&g_108.f0.f4,&g_370[3].f0.f4,&g_206.f0.f4,&g_206.f0.f4,(void*)0,&g_188[2][1]},{&g_370[3].f0.f4,&g_188[1][0],&g_368[0].f0.f4,&g_206.f0.f4,&g_188[2][5],&g_267.f0.f4,&g_111.f0.f4,&g_370[3].f0.f4}}};
                int16_t **l_539 = &l_538;
                int i, j, k;
                (*g_540) = (g_368[0].f0.f1 ^ (l_537[2][1][0] != ((*l_539) = l_538)));
            }
            l_542 ^= l_541;
            l_543 = l_542;
            for (g_409.f4 = 0; (g_409.f4 >= 21); g_409.f4 = safe_add_func_uint32_t_u_u(g_409.f4, 7))
            { /* block id: 242 */
                uint8_t **l_548 = &l_547;
                uint8_t *l_550 = &g_108.f0.f0;
                uint8_t **l_549 = &l_550;
                int32_t ***l_553 = &g_167[0];
                int8_t *l_554 = &g_94;
                if ((0UL || ((((((((~p_64) , ((*l_549) = ((*l_548) = l_547))) != l_551[4][0][0]) || 9L) , &g_165) != &g_165) , l_552) != (((*l_554) = (l_553 == &g_85[6][0])) , l_555))))
                { /* block id: 246 */
                    struct S0 **l_557 = &l_556;
                    struct S0 *l_559 = &g_267.f0;
                    struct S0 **l_558 = &l_559;
                    struct S0 *l_562[5];
                    struct S0 **l_561[6] = {(void*)0,(void*)0,&l_562[1],(void*)0,(void*)0,&l_562[1]};
                    int i;
                    for (i = 0; i < 5; i++)
                        l_562[i] = &g_104;
                    l_563 = ((*l_558) = ((*l_557) = l_556));
                }
                else
                { /* block id: 250 */
                    (**l_553) = l_565;
                    return p_64;
                }
                if (l_541)
                    break;
                l_576 |= (((safe_lshift_func_uint8_t_u_u(((*l_547) = (safe_sub_func_uint16_t_u_u(p_64, (safe_mod_func_uint16_t_u_u(p_64, 9UL))))), ((safe_mul_func_int16_t_s_s((safe_sub_func_int8_t_s_s(((p_64 >= ((p_64 == (0x70L != g_104.f7)) || g_108.f0.f8)) ^ l_543), 0UL)), (*l_565))) >= p_64))) ^ p_64) != 65535UL);
            }
        }
    }
lbl_951:
    if (p_64)
    { /* block id: 260 */
        uint64_t *l_598[7];
        int16_t *l_599 = &g_108.f0.f4;
        int32_t l_609 = (-1L);
        int i;
        for (i = 0; i < 7; i++)
            l_598[i] = &g_253;
        for (g_186 = 0; (g_186 >= 0); g_186 -= 1)
        { /* block id: 263 */
            uint16_t **l_578 = &g_221;
            uint16_t ***l_577 = &l_578;
            int64_t *l_589 = (void*)0;
            int64_t **l_590 = &l_589;
            uint32_t **l_591 = (void*)0;
            uint32_t *l_593 = (void*)0;
            uint32_t **l_592 = &l_593;
            uint64_t *l_597 = (void*)0;
            uint64_t **l_596 = &l_597;
            int32_t *l_600 = &g_108.f0.f3;
            struct S0 * const l_606 = &g_111.f0;
            int i;
            (*l_600) &= (((((*l_577) = &g_221) != (void*)0) > (safe_sub_func_uint8_t_u_u((safe_div_func_int16_t_s_s(((((((*l_596) = ((((p_64 , g_114.f0.f8) & (((safe_add_func_int64_t_s_s(g_257[1][7], (safe_mul_func_uint16_t_u_u((((*l_592) = ((safe_div_func_uint8_t_u_u((((*l_590) = l_589) == (void*)0), 0xD6L)) , l_565)) != g_594), (*l_565))))) , p_64) <= (*g_594))) > 0x5C6FL) , (void*)0)) == l_598[5]) , l_599) != (void*)0) >= g_370[3].f0.f3), (*l_565))), p_64))) | g_368[0].f0.f7);
            (*l_600) &= (!g_602);
            for (g_111.f0.f3 = 0; (g_111.f0.f3 <= 0); g_111.f0.f3 += 1)
            { /* block id: 272 */
                for (g_267.f0.f8 = 0; (g_267.f0.f8 >= 0); g_267.f0.f8 -= 1)
                { /* block id: 275 */
                    for (g_108.f0.f0 = 0; (g_108.f0.f0 <= 0); g_108.f0.f0 += 1)
                    { /* block id: 278 */
                        (*g_603) = &l_598[0];
                    }
                }
                g_607 = l_606;
            }
        }
        (*l_565) = 9L;
        return l_609;
    }
    else
    { /* block id: 287 */
        int16_t l_639 = 7L;
        int32_t l_645[3];
        int i;
        for (i = 0; i < 3; i++)
            l_645[i] = (-8L);
        for (g_206.f0.f9 = 0; (g_206.f0.f9 < 8); g_206.f0.f9 = safe_add_func_uint64_t_u_u(g_206.f0.f9, 4))
        { /* block id: 290 */
            int16_t l_631 = 1L;
            int32_t l_640 = 0x2C91ED0DL;
            for (g_111.f0.f4 = 28; (g_111.f0.f4 != (-20)); g_111.f0.f4 = safe_sub_func_uint64_t_u_u(g_111.f0.f4, 6))
            { /* block id: 293 */
                int64_t l_618[5];
                uint32_t *l_629[9] = {&g_595,&g_595,(void*)0,&g_595,&g_595,(void*)0,&g_595,&g_595,(void*)0};
                uint8_t *l_641 = (void*)0;
                uint8_t *l_642 = (void*)0;
                uint8_t *l_643 = &g_206.f0.f0;
                uint16_t *l_644 = &g_368[0].f0.f9;
                int i;
                for (i = 0; i < 5; i++)
                    l_618[i] = 0x4D7690037ECF4AE9LL;
                l_645[1] &= (safe_lshift_func_uint16_t_u_s(((*l_644) ^= (((*l_643) = (((safe_mul_func_uint8_t_u_u(l_618[1], (safe_mod_func_int32_t_s_s(((void*)0 != &l_565), ((safe_lshift_func_int8_t_s_s(((l_640 = (safe_rshift_func_int8_t_s_u((safe_sub_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u(((l_631 ^= (*g_594)) & ((safe_add_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(p_64, p_64)), (((((g_636 , (g_637[5] , l_638)) == l_638) >= l_639) , g_94) || 0x03L))) == p_64)), p_64)) && 6L), (-1L))), 4))) < g_83), p_64)) & 0xFAA31470L))))) <= (*l_565)) || 0xF9CB33C6L)) != p_64)), 10));
            }
            if ((*l_565))
                break;
            if (p_64)
                break;
        }
    }
    if ((safe_add_func_uint8_t_u_u((p_64 <= (***g_603)), (((void*)0 == l_648) ^ (*g_605)))))
    { /* block id: 304 */
        uint16_t l_673 = 65526UL;
        uint32_t *l_676 = &g_630;
        int16_t *l_703 = (void*)0;
        int16_t *l_704 = &g_104.f4;
        int32_t l_714 = 0x1FC49A14L;
        int64_t *l_779 = &g_100;
        int64_t **l_778 = &l_779;
        int16_t l_830 = 0x375DL;
        int32_t l_834 = 2L;
        int32_t l_838 = 0x8BAE74A0L;
        int32_t l_842 = 0L;
        int32_t l_843 = 0x973E3B99L;
        int32_t l_929[9] = {0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L,0x3C11DF77L};
        int i;
        for (g_267.f0.f8 = (-10); (g_267.f0.f8 <= (-4)); g_267.f0.f8++)
        { /* block id: 307 */
            uint16_t *l_657 = &g_602;
            int8_t *l_671 = (void*)0;
            int8_t *l_672 = (void*)0;
            uint8_t *l_674 = &g_20[0][5][1];
            int16_t *l_675[6] = {&g_108.f0.f4,&g_108.f0.f4,&g_108.f0.f4,&g_108.f0.f4,&g_108.f0.f4,&g_108.f0.f4};
            int32_t l_695 = 1L;
            uint32_t l_696 = 0x90A22DCFL;
            const int8_t *l_762[8][5] = {{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0},{&g_763,(void*)0,&g_763,&g_763,(void*)0}};
            const int8_t **l_761 = &l_762[4][2];
            int8_t *l_764 = &g_94;
            int32_t l_837[2];
            uint32_t l_844 = 0x64AEE2F6L;
            uint16_t **l_919 = &g_221;
            uint16_t ***l_918 = &l_919;
            int i, j;
            for (i = 0; i < 2; i++)
                l_837[i] = 2L;
            for (g_111.f0.f0 = 0; (g_111.f0.f0 >= 8); g_111.f0.f0 = safe_add_func_int16_t_s_s(g_111.f0.f0, 1))
            { /* block id: 310 */
                return p_64;
            }
            if ((((safe_mul_func_int16_t_s_s((g_564[1][5].f4 , (safe_mul_func_int16_t_s_s(((l_657 == &g_602) , (safe_add_func_uint64_t_u_u((safe_add_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s((((((((g_108.f0.f5 != (*l_565)) , g_664) , (g_370[3].f0.f4 &= (((safe_lshift_func_uint8_t_u_u(((*l_674) |= (safe_add_func_uint64_t_u_u(1UL, (safe_add_func_int16_t_s_s(((g_664.f8 != (l_673 = p_64)) ^ (*l_565)), p_64))))), 3)) | p_64) != 18446744073709551609UL))) == p_64) | p_64) , l_676) == &g_595), 9)), p_64)), (**g_604)))), (*l_565)))), 0x4A45L)) , 18446744073709551606UL) != 0L))
            { /* block id: 316 */
                int32_t l_688 = 6L;
                int32_t l_716 = 1L;
                for (g_104.f9 = 0; (g_104.f9 <= 3); g_104.f9 += 1)
                { /* block id: 319 */
                    int i, j;
                    return g_188[g_104.f9][(g_104.f9 + 3)];
                }
                (*l_565) = (((*l_657) = (((safe_div_func_uint8_t_u_u(((+p_64) , l_673), ((g_680 , g_681[1]) , (safe_lshift_func_uint16_t_u_u(((((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_s(l_688, 5)) >= ((safe_add_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(((l_695 = (((p_64 < ((*g_605) ^ p_64)) | (((safe_rshift_func_int8_t_s_u(p_64, 1)) <= g_370[3].f0.f7) && p_64)) == 0x44L)) ^ p_64), p_64)) && (*g_128)), 0xEFAEL)) > g_370[3].f0.f9)), 0L)) , (-4L)) < l_696) , (*g_128)), l_673))))) >= 0x2BL) > g_368[0].f0.f5)) != p_64);
                for (g_111.f0.f3 = 0; (g_111.f0.f3 != (-6)); --g_111.f0.f3)
                { /* block id: 327 */
                    int16_t *l_706 = &g_409.f4;
                    struct S1 *l_707 = &g_370[5];
                    for (g_206.f0.f8 = 0; (g_206.f0.f8 <= 11); g_206.f0.f8 = safe_add_func_int8_t_s_s(g_206.f0.f8, 2))
                    { /* block id: 330 */
                        int16_t **l_705[6] = {&l_704,&l_675[0],&l_675[0],&l_704,&l_675[0],&l_675[0]};
                        uint8_t *l_713[4];
                        int32_t *l_715[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        uint32_t l_717 = 0xED44993CL;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_713[i] = &g_257[1][7];
                        (*g_157) = (*g_157);
                        (*l_565) ^= ((safe_sub_func_uint32_t_u_u(((l_703 = &g_188[1][0]) == (l_706 = l_704)), (((void*)0 == l_707) > ((((safe_sub_func_int32_t_s_s(0L, 0xB20F18D3L)) >= (l_695 = ((safe_mod_func_uint8_t_u_u((((!3L) == ((*l_674) ^= g_636.f0.f3)) & p_64), g_267.f0.f9)) & 0x7ECD6508503111A2LL))) , g_111.f0.f6) < p_64)))) >= (*g_594));
                        l_717++;
                        return (*g_128);
                    }
                }
            }
            else
            { /* block id: 341 */
                uint16_t **l_735 = &l_657;
                uint16_t *l_736 = &g_104.f9;
                int32_t *l_737 = &g_36[3];
                int32_t *l_738[6][4][6] = {{{&g_564[1][5].f3,(void*)0,&g_732.f0.f3,&g_732.f0.f3,(void*)0,&g_36[3]},{&g_732.f0.f3,(void*)0,&g_608[0].f3,(void*)0,&g_36[4],&g_530},{(void*)0,&g_732.f0.f3,&g_732.f0.f3,&g_83,&g_370[3].f0.f3,&g_732.f0.f3},{(void*)0,&g_108.f0.f3,&g_732.f0.f3,(void*)0,&g_530,&g_370[3].f0.f3}},{{(void*)0,&g_368[0].f0.f3,(void*)0,&g_108.f0.f3,&g_564[1][5].f3,(void*)0},{&g_732.f0.f3,(void*)0,&g_732.f0.f3,&g_732.f0.f3,(void*)0,&g_732.f0.f3},{&g_530,&g_36[3],&g_368[0].f0.f3,(void*)0,&g_267.f0.f3,&g_36[1]},{&g_36[4],&g_368[0].f0.f3,&g_732.f0.f3,(void*)0,&g_368[0].f0.f3,&g_36[3]}},{{&g_36[4],&g_608[0].f3,(void*)0,(void*)0,(void*)0,&g_368[0].f0.f3},{&g_530,&g_267.f0.f3,&g_564[1][5].f3,&g_732.f0.f3,&g_608[0].f3,&g_267.f0.f3},{&g_732.f0.f3,(void*)0,&g_108.f0.f3,&g_108.f0.f3,&g_36[3],&g_36[3]},{(void*)0,&g_732.f0.f3,&g_530,(void*)0,&g_108.f0.f3,(void*)0}},{{(void*)0,&g_83,&g_108.f0.f3,&g_83,(void*)0,&g_564[1][5].f3},{(void*)0,&g_732.f0.f3,&g_267.f0.f3,(void*)0,(void*)0,&g_368[0].f0.f3},{&g_732.f0.f3,(void*)0,&g_36[3],&g_732.f0.f3,&g_36[1],&g_368[0].f0.f3},{&g_564[1][5].f3,&g_108.f0.f3,&g_267.f0.f3,(void*)0,&g_608[0].f3,&g_564[1][5].f3}},{{&g_36[1],&g_608[0].f3,&g_108.f0.f3,&g_36[3],&g_108.f0.f3,(void*)0},{&g_530,(void*)0,&g_530,&g_732.f0.f3,&g_732.f0.f3,&g_36[3]},{&g_36[3],&l_714,&g_108.f0.f3,&g_370[3].f0.f3,&g_267.f0.f3,&g_267.f0.f3},{&g_108.f0.f3,&g_564[1][5].f3,&g_564[1][5].f3,&g_108.f0.f3,&g_732.f0.f3,&g_368[0].f0.f3}},{{&g_732.f0.f3,&g_564[1][5].f3,(void*)0,&g_36[3],&g_36[3],&g_530},{&g_108.f0.f3,&g_368[0].f0.f3,&g_732.f0.f3,(void*)0,&g_36[3],(void*)0},{&g_732.f0.f3,&g_732.f0.f3,&g_368[0].f0.f3,(void*)0,&l_714,&g_108.f0.f3},{&g_83,&g_108.f0.f3,(void*)0,(void*)0,&g_370[3].f0.f3,&g_564[1][5].f3}}};
                int i, j, k;
                l_739 ^= ((((safe_add_func_uint32_t_u_u(0x8CF0A77AL, ((safe_mod_func_uint16_t_u_u(((((safe_rshift_func_uint8_t_u_u(((l_695 ^= (((*l_704) = (safe_div_func_uint16_t_u_u(((*l_736) = ((p_64 <= (safe_div_func_uint8_t_u_u(0UL, (p_64 && ((((*l_735) = (((**l_648) = (safe_rshift_func_uint16_t_u_u(((*l_657) = 0UL), (4294967295UL ^ ((g_732 , (safe_sub_func_int8_t_s_s(g_104.f1, 0UL))) > g_564[1][5].f9))))) , (void*)0)) != l_675[3]) != p_64))))) <= p_64)), 0x5645L))) <= p_64)) <= g_206.f0.f7), p_64)) == (*l_565)) >= 0x5DE5L) < 6L), p_64)) > 0x0C4AL))) , &l_695) != l_737) || (*g_594));
                return p_64;
            }
            l_739 |= (g_108.f0.f0 != (((*l_764) = ((safe_div_func_uint64_t_u_u((g_104.f2 != g_608[0].f4), 1UL)) && (safe_lshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(3L, g_111.f0.f4)), (safe_lshift_func_uint8_t_u_u((g_114.f0.f3 && (safe_mod_func_int32_t_s_s((!(safe_rshift_func_int8_t_s_u((safe_div_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s((((*l_761) = (void*)0) == (l_671 = &g_94)), (*l_565))) , 0x45L), 0xB8L)), 7))), (*l_565)))), p_64)))), g_104.f7)))) < (*l_565)));
            for (g_100 = 0; (g_100 <= 3); g_100 += 1)
            { /* block id: 357 */
                int64_t ***l_780 = &l_778;
                int64_t **l_782[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int64_t ***l_781 = &l_782[2];
                int64_t **l_784 = (void*)0;
                int64_t ***l_783 = &l_784;
                uint8_t *l_793 = &g_267.f0.f0;
                int8_t *l_794 = &g_795;
                int32_t l_835 = 0x58066683L;
                int32_t l_836 = 0xDB435451L;
                int32_t l_839 = 0x991ED4B0L;
                int32_t l_841 = 0L;
                uint16_t **l_857 = &l_657;
                uint16_t ***l_856 = &l_857;
                int32_t l_928 = 0x864A321EL;
                int32_t l_932 = 0xD7A8C646L;
                int32_t l_933 = 0xEAC01610L;
                int i, j;
            }
        }
        (*g_157) = &l_840[0][6];
        if ((((((p_64 == l_942) == p_64) <= (((((&g_604 != (((*l_565) = ((safe_mod_func_int64_t_s_s(((p_64 || (safe_div_func_uint64_t_u_u((l_714 ^ (**g_821)), (safe_sub_func_int16_t_s_s(((void*)0 == (*g_157)), p_64))))) , 1L), 0x920D07CB71F0F909LL)) <= 1UL)) , &g_604)) && 0x25EDCCA954246FD2LL) < 0xC8955E89L) | 0x3AL) , 0xA2A5B4ECL)) , &l_830) == (void*)0))
        { /* block id: 453 */
            (*l_565) &= (p_64 , (p_64 >= (safe_rshift_func_int8_t_s_u(l_830, 2))));
            if (g_104.f7)
                goto lbl_951;
        }
        else
        { /* block id: 456 */
            return p_64;
        }
        return (*g_128);
    }
    else
    { /* block id: 460 */
        return (*g_128);
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_157 g_530
 * writes: g_158
 */
static uint16_t  func_67(int8_t * p_68, int8_t * p_69, int16_t  p_70, const int16_t  p_71, uint8_t  p_72)
{ /* block id: 222 */
    int32_t *l_529 = &g_206.f0.f3;
    (*g_157) = l_529;
    return g_530;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_516
 */
static int8_t * func_73(int8_t * const  p_74)
{ /* block id: 218 */
    struct S1 **l_513 = (void*)0;
    struct S1 ***l_514 = (void*)0;
    struct S1 ***l_515[7] = {&l_513,&l_513,&l_513,&l_513,&l_513,&l_513,&l_513};
    int32_t l_517 = (-1L);
    int32_t l_518 = (-6L);
    int32_t *l_519 = &g_104.f3;
    int32_t l_520 = 1L;
    int32_t *l_521[8];
    int16_t l_522 = 0x1978L;
    int32_t l_523 = (-9L);
    int16_t l_524 = 0xB67BL;
    int64_t l_525 = 1L;
    uint32_t l_526 = 18446744073709551606UL;
    int i;
    for (i = 0; i < 8; i++)
        l_521[i] = &g_409.f3;
    g_516 = l_513;
    l_526--;
    return &g_94;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t * const  func_75(uint16_t  p_76, int32_t * p_77, int8_t  p_78, int16_t  p_79)
{ /* block id: 11 */
    int32_t *l_84 = &g_36[3];
    int32_t **l_86 = &g_82;
    struct S1 *l_107[2][8] = {{&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108},{&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108,&g_108}};
    int32_t l_168 = 0x45E50017L;
    int32_t l_169[5];
    int32_t l_174 = 6L;
    uint32_t l_192 = 0xE3F43202L;
    int16_t l_215 = 0x5B66L;
    uint16_t *l_223[3][10] = {{&g_104.f9,&g_104.f9,&g_108.f0.f9,&g_104.f9,&g_104.f9,&g_108.f0.f9,&g_104.f9,&g_104.f9,&g_108.f0.f9,&g_104.f9},{&g_104.f9,(void*)0,(void*)0,&g_104.f9,(void*)0,(void*)0,&g_104.f9,(void*)0,(void*)0,&g_104.f9},{(void*)0,&g_104.f9,(void*)0,(void*)0,&g_104.f9,(void*)0,(void*)0,&g_104.f9,(void*)0,(void*)0}};
    const int16_t l_254 = 0xD5BBL;
    const uint32_t l_289 = 1UL;
    uint32_t l_329 = 0x0D66266CL;
    int16_t l_337 = 0x1E07L;
    const struct S0 *l_450[5][8] = {{&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0},{&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0},{&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0},{&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0},{&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0,&g_267.f0}};
    int8_t * const l_465 = &g_94;
    uint32_t l_471 = 4294967291UL;
    uint16_t l_474[7] = {0x6D95L,0x6D95L,0x6D95L,0x6D95L,0x6D95L,0x6D95L,0x6D95L};
    uint16_t l_477 = 0xC23EL;
    int32_t *l_512 = &l_168;
    int i, j;
    for (i = 0; i < 5; i++)
        l_169[i] = 0x403430B8L;
    return &g_94;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_20[i][j][k], "g_20[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_104.f0, "g_104.f0", print_hash_value);
    transparent_crc(g_104.f1, "g_104.f1", print_hash_value);
    transparent_crc(g_104.f2, "g_104.f2", print_hash_value);
    transparent_crc(g_104.f3, "g_104.f3", print_hash_value);
    transparent_crc(g_104.f4, "g_104.f4", print_hash_value);
    transparent_crc(g_104.f5, "g_104.f5", print_hash_value);
    transparent_crc(g_104.f6, "g_104.f6", print_hash_value);
    transparent_crc(g_104.f7, "g_104.f7", print_hash_value);
    transparent_crc(g_104.f8, "g_104.f8", print_hash_value);
    transparent_crc(g_104.f9, "g_104.f9", print_hash_value);
    transparent_crc(g_108.f0.f0, "g_108.f0.f0", print_hash_value);
    transparent_crc(g_108.f0.f1, "g_108.f0.f1", print_hash_value);
    transparent_crc(g_108.f0.f2, "g_108.f0.f2", print_hash_value);
    transparent_crc(g_108.f0.f3, "g_108.f0.f3", print_hash_value);
    transparent_crc(g_108.f0.f4, "g_108.f0.f4", print_hash_value);
    transparent_crc(g_108.f0.f5, "g_108.f0.f5", print_hash_value);
    transparent_crc(g_108.f0.f6, "g_108.f0.f6", print_hash_value);
    transparent_crc(g_108.f0.f7, "g_108.f0.f7", print_hash_value);
    transparent_crc(g_108.f0.f8, "g_108.f0.f8", print_hash_value);
    transparent_crc(g_108.f0.f9, "g_108.f0.f9", print_hash_value);
    transparent_crc(g_108.f1, "g_108.f1", print_hash_value);
    transparent_crc(g_111.f0.f0, "g_111.f0.f0", print_hash_value);
    transparent_crc(g_111.f0.f1, "g_111.f0.f1", print_hash_value);
    transparent_crc(g_111.f0.f2, "g_111.f0.f2", print_hash_value);
    transparent_crc(g_111.f0.f3, "g_111.f0.f3", print_hash_value);
    transparent_crc(g_111.f0.f4, "g_111.f0.f4", print_hash_value);
    transparent_crc(g_111.f0.f5, "g_111.f0.f5", print_hash_value);
    transparent_crc(g_111.f0.f6, "g_111.f0.f6", print_hash_value);
    transparent_crc(g_111.f0.f7, "g_111.f0.f7", print_hash_value);
    transparent_crc(g_111.f0.f8, "g_111.f0.f8", print_hash_value);
    transparent_crc(g_111.f0.f9, "g_111.f0.f9", print_hash_value);
    transparent_crc(g_111.f1, "g_111.f1", print_hash_value);
    transparent_crc(g_114.f0.f0, "g_114.f0.f0", print_hash_value);
    transparent_crc(g_114.f0.f1, "g_114.f0.f1", print_hash_value);
    transparent_crc(g_114.f0.f2, "g_114.f0.f2", print_hash_value);
    transparent_crc(g_114.f0.f3, "g_114.f0.f3", print_hash_value);
    transparent_crc(g_114.f0.f4, "g_114.f0.f4", print_hash_value);
    transparent_crc(g_114.f0.f5, "g_114.f0.f5", print_hash_value);
    transparent_crc(g_114.f0.f6, "g_114.f0.f6", print_hash_value);
    transparent_crc(g_114.f0.f7, "g_114.f0.f7", print_hash_value);
    transparent_crc(g_114.f0.f8, "g_114.f0.f8", print_hash_value);
    transparent_crc(g_114.f0.f9, "g_114.f0.f9", print_hash_value);
    transparent_crc(g_114.f1, "g_114.f1", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_165, "g_165", print_hash_value);
    transparent_crc(g_186, "g_186", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_188[i][j], "g_188[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_206.f0.f0, "g_206.f0.f0", print_hash_value);
    transparent_crc(g_206.f0.f1, "g_206.f0.f1", print_hash_value);
    transparent_crc(g_206.f0.f2, "g_206.f0.f2", print_hash_value);
    transparent_crc(g_206.f0.f3, "g_206.f0.f3", print_hash_value);
    transparent_crc(g_206.f0.f4, "g_206.f0.f4", print_hash_value);
    transparent_crc(g_206.f0.f5, "g_206.f0.f5", print_hash_value);
    transparent_crc(g_206.f0.f6, "g_206.f0.f6", print_hash_value);
    transparent_crc(g_206.f0.f7, "g_206.f0.f7", print_hash_value);
    transparent_crc(g_206.f0.f8, "g_206.f0.f8", print_hash_value);
    transparent_crc(g_206.f0.f9, "g_206.f0.f9", print_hash_value);
    transparent_crc(g_206.f1, "g_206.f1", print_hash_value);
    transparent_crc(g_253, "g_253", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_257[i][j], "g_257[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_267.f0.f0, "g_267.f0.f0", print_hash_value);
    transparent_crc(g_267.f0.f1, "g_267.f0.f1", print_hash_value);
    transparent_crc(g_267.f0.f2, "g_267.f0.f2", print_hash_value);
    transparent_crc(g_267.f0.f3, "g_267.f0.f3", print_hash_value);
    transparent_crc(g_267.f0.f4, "g_267.f0.f4", print_hash_value);
    transparent_crc(g_267.f0.f5, "g_267.f0.f5", print_hash_value);
    transparent_crc(g_267.f0.f6, "g_267.f0.f6", print_hash_value);
    transparent_crc(g_267.f0.f7, "g_267.f0.f7", print_hash_value);
    transparent_crc(g_267.f0.f8, "g_267.f0.f8", print_hash_value);
    transparent_crc(g_267.f0.f9, "g_267.f0.f9", print_hash_value);
    transparent_crc(g_267.f1, "g_267.f1", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_368[i].f0.f0, "g_368[i].f0.f0", print_hash_value);
        transparent_crc(g_368[i].f0.f1, "g_368[i].f0.f1", print_hash_value);
        transparent_crc(g_368[i].f0.f2, "g_368[i].f0.f2", print_hash_value);
        transparent_crc(g_368[i].f0.f3, "g_368[i].f0.f3", print_hash_value);
        transparent_crc(g_368[i].f0.f4, "g_368[i].f0.f4", print_hash_value);
        transparent_crc(g_368[i].f0.f5, "g_368[i].f0.f5", print_hash_value);
        transparent_crc(g_368[i].f0.f6, "g_368[i].f0.f6", print_hash_value);
        transparent_crc(g_368[i].f0.f7, "g_368[i].f0.f7", print_hash_value);
        transparent_crc(g_368[i].f0.f8, "g_368[i].f0.f8", print_hash_value);
        transparent_crc(g_368[i].f0.f9, "g_368[i].f0.f9", print_hash_value);
        transparent_crc(g_368[i].f1, "g_368[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_370[i].f0.f0, "g_370[i].f0.f0", print_hash_value);
        transparent_crc(g_370[i].f0.f1, "g_370[i].f0.f1", print_hash_value);
        transparent_crc(g_370[i].f0.f2, "g_370[i].f0.f2", print_hash_value);
        transparent_crc(g_370[i].f0.f3, "g_370[i].f0.f3", print_hash_value);
        transparent_crc(g_370[i].f0.f4, "g_370[i].f0.f4", print_hash_value);
        transparent_crc(g_370[i].f0.f5, "g_370[i].f0.f5", print_hash_value);
        transparent_crc(g_370[i].f0.f6, "g_370[i].f0.f6", print_hash_value);
        transparent_crc(g_370[i].f0.f7, "g_370[i].f0.f7", print_hash_value);
        transparent_crc(g_370[i].f0.f8, "g_370[i].f0.f8", print_hash_value);
        transparent_crc(g_370[i].f0.f9, "g_370[i].f0.f9", print_hash_value);
        transparent_crc(g_370[i].f1, "g_370[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_409.f0, "g_409.f0", print_hash_value);
    transparent_crc(g_409.f1, "g_409.f1", print_hash_value);
    transparent_crc(g_409.f2, "g_409.f2", print_hash_value);
    transparent_crc(g_409.f3, "g_409.f3", print_hash_value);
    transparent_crc(g_409.f4, "g_409.f4", print_hash_value);
    transparent_crc(g_409.f5, "g_409.f5", print_hash_value);
    transparent_crc(g_409.f6, "g_409.f6", print_hash_value);
    transparent_crc(g_409.f7, "g_409.f7", print_hash_value);
    transparent_crc(g_409.f8, "g_409.f8", print_hash_value);
    transparent_crc(g_409.f9, "g_409.f9", print_hash_value);
    transparent_crc(g_488.f0.f0, "g_488.f0.f0", print_hash_value);
    transparent_crc(g_488.f0.f1, "g_488.f0.f1", print_hash_value);
    transparent_crc(g_488.f0.f2, "g_488.f0.f2", print_hash_value);
    transparent_crc(g_488.f0.f3, "g_488.f0.f3", print_hash_value);
    transparent_crc(g_488.f0.f4, "g_488.f0.f4", print_hash_value);
    transparent_crc(g_488.f0.f5, "g_488.f0.f5", print_hash_value);
    transparent_crc(g_488.f0.f6, "g_488.f0.f6", print_hash_value);
    transparent_crc(g_488.f0.f7, "g_488.f0.f7", print_hash_value);
    transparent_crc(g_488.f0.f8, "g_488.f0.f8", print_hash_value);
    transparent_crc(g_488.f0.f9, "g_488.f0.f9", print_hash_value);
    transparent_crc(g_488.f1, "g_488.f1", print_hash_value);
    transparent_crc(g_496, "g_496", print_hash_value);
    transparent_crc(g_530, "g_530", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_564[i][j].f0, "g_564[i][j].f0", print_hash_value);
            transparent_crc(g_564[i][j].f1, "g_564[i][j].f1", print_hash_value);
            transparent_crc(g_564[i][j].f2, "g_564[i][j].f2", print_hash_value);
            transparent_crc(g_564[i][j].f3, "g_564[i][j].f3", print_hash_value);
            transparent_crc(g_564[i][j].f4, "g_564[i][j].f4", print_hash_value);
            transparent_crc(g_564[i][j].f5, "g_564[i][j].f5", print_hash_value);
            transparent_crc(g_564[i][j].f6, "g_564[i][j].f6", print_hash_value);
            transparent_crc(g_564[i][j].f7, "g_564[i][j].f7", print_hash_value);
            transparent_crc(g_564[i][j].f8, "g_564[i][j].f8", print_hash_value);
            transparent_crc(g_564[i][j].f9, "g_564[i][j].f9", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_595, "g_595", print_hash_value);
    transparent_crc(g_602, "g_602", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_608[i].f0, "g_608[i].f0", print_hash_value);
        transparent_crc(g_608[i].f1, "g_608[i].f1", print_hash_value);
        transparent_crc(g_608[i].f2, "g_608[i].f2", print_hash_value);
        transparent_crc(g_608[i].f3, "g_608[i].f3", print_hash_value);
        transparent_crc(g_608[i].f4, "g_608[i].f4", print_hash_value);
        transparent_crc(g_608[i].f5, "g_608[i].f5", print_hash_value);
        transparent_crc(g_608[i].f6, "g_608[i].f6", print_hash_value);
        transparent_crc(g_608[i].f7, "g_608[i].f7", print_hash_value);
        transparent_crc(g_608[i].f8, "g_608[i].f8", print_hash_value);
        transparent_crc(g_608[i].f9, "g_608[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_630, "g_630", print_hash_value);
    transparent_crc(g_636.f0.f0, "g_636.f0.f0", print_hash_value);
    transparent_crc(g_636.f0.f1, "g_636.f0.f1", print_hash_value);
    transparent_crc(g_636.f0.f2, "g_636.f0.f2", print_hash_value);
    transparent_crc(g_636.f0.f3, "g_636.f0.f3", print_hash_value);
    transparent_crc(g_636.f0.f4, "g_636.f0.f4", print_hash_value);
    transparent_crc(g_636.f0.f5, "g_636.f0.f5", print_hash_value);
    transparent_crc(g_636.f0.f6, "g_636.f0.f6", print_hash_value);
    transparent_crc(g_636.f0.f7, "g_636.f0.f7", print_hash_value);
    transparent_crc(g_636.f0.f8, "g_636.f0.f8", print_hash_value);
    transparent_crc(g_636.f0.f9, "g_636.f0.f9", print_hash_value);
    transparent_crc(g_636.f1, "g_636.f1", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_637[i].f0.f0, "g_637[i].f0.f0", print_hash_value);
        transparent_crc(g_637[i].f0.f1, "g_637[i].f0.f1", print_hash_value);
        transparent_crc(g_637[i].f0.f2, "g_637[i].f0.f2", print_hash_value);
        transparent_crc(g_637[i].f0.f3, "g_637[i].f0.f3", print_hash_value);
        transparent_crc(g_637[i].f0.f4, "g_637[i].f0.f4", print_hash_value);
        transparent_crc(g_637[i].f0.f5, "g_637[i].f0.f5", print_hash_value);
        transparent_crc(g_637[i].f0.f6, "g_637[i].f0.f6", print_hash_value);
        transparent_crc(g_637[i].f0.f7, "g_637[i].f0.f7", print_hash_value);
        transparent_crc(g_637[i].f0.f8, "g_637[i].f0.f8", print_hash_value);
        transparent_crc(g_637[i].f0.f9, "g_637[i].f0.f9", print_hash_value);
        transparent_crc(g_637[i].f1, "g_637[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_664.f0, "g_664.f0", print_hash_value);
    transparent_crc(g_664.f1, "g_664.f1", print_hash_value);
    transparent_crc(g_664.f2, "g_664.f2", print_hash_value);
    transparent_crc(g_664.f3, "g_664.f3", print_hash_value);
    transparent_crc(g_664.f4, "g_664.f4", print_hash_value);
    transparent_crc(g_664.f5, "g_664.f5", print_hash_value);
    transparent_crc(g_664.f6, "g_664.f6", print_hash_value);
    transparent_crc(g_664.f7, "g_664.f7", print_hash_value);
    transparent_crc(g_664.f8, "g_664.f8", print_hash_value);
    transparent_crc(g_664.f9, "g_664.f9", print_hash_value);
    transparent_crc(g_680.f0.f0, "g_680.f0.f0", print_hash_value);
    transparent_crc(g_680.f0.f1, "g_680.f0.f1", print_hash_value);
    transparent_crc(g_680.f0.f2, "g_680.f0.f2", print_hash_value);
    transparent_crc(g_680.f0.f3, "g_680.f0.f3", print_hash_value);
    transparent_crc(g_680.f0.f4, "g_680.f0.f4", print_hash_value);
    transparent_crc(g_680.f0.f5, "g_680.f0.f5", print_hash_value);
    transparent_crc(g_680.f0.f6, "g_680.f0.f6", print_hash_value);
    transparent_crc(g_680.f0.f7, "g_680.f0.f7", print_hash_value);
    transparent_crc(g_680.f0.f8, "g_680.f0.f8", print_hash_value);
    transparent_crc(g_680.f0.f9, "g_680.f0.f9", print_hash_value);
    transparent_crc(g_680.f1, "g_680.f1", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_681[i].f0.f0, "g_681[i].f0.f0", print_hash_value);
        transparent_crc(g_681[i].f0.f1, "g_681[i].f0.f1", print_hash_value);
        transparent_crc(g_681[i].f0.f2, "g_681[i].f0.f2", print_hash_value);
        transparent_crc(g_681[i].f0.f3, "g_681[i].f0.f3", print_hash_value);
        transparent_crc(g_681[i].f0.f4, "g_681[i].f0.f4", print_hash_value);
        transparent_crc(g_681[i].f0.f5, "g_681[i].f0.f5", print_hash_value);
        transparent_crc(g_681[i].f0.f6, "g_681[i].f0.f6", print_hash_value);
        transparent_crc(g_681[i].f0.f7, "g_681[i].f0.f7", print_hash_value);
        transparent_crc(g_681[i].f0.f8, "g_681[i].f0.f8", print_hash_value);
        transparent_crc(g_681[i].f0.f9, "g_681[i].f0.f9", print_hash_value);
        transparent_crc(g_681[i].f1, "g_681[i].f1", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_732.f0.f0, "g_732.f0.f0", print_hash_value);
    transparent_crc(g_732.f0.f1, "g_732.f0.f1", print_hash_value);
    transparent_crc(g_732.f0.f2, "g_732.f0.f2", print_hash_value);
    transparent_crc(g_732.f0.f3, "g_732.f0.f3", print_hash_value);
    transparent_crc(g_732.f0.f4, "g_732.f0.f4", print_hash_value);
    transparent_crc(g_732.f0.f5, "g_732.f0.f5", print_hash_value);
    transparent_crc(g_732.f0.f6, "g_732.f0.f6", print_hash_value);
    transparent_crc(g_732.f0.f7, "g_732.f0.f7", print_hash_value);
    transparent_crc(g_732.f0.f8, "g_732.f0.f8", print_hash_value);
    transparent_crc(g_732.f0.f9, "g_732.f0.f9", print_hash_value);
    transparent_crc(g_732.f1, "g_732.f1", print_hash_value);
    transparent_crc(g_763, "g_763", print_hash_value);
    transparent_crc(g_795, "g_795", print_hash_value);
    transparent_crc(g_796, "g_796", print_hash_value);
    transparent_crc(g_814, "g_814", print_hash_value);
    transparent_crc(g_820, "g_820", print_hash_value);
    transparent_crc(g_823, "g_823", print_hash_value);
    transparent_crc(g_829, "g_829", print_hash_value);
    transparent_crc(g_847.f0.f0, "g_847.f0.f0", print_hash_value);
    transparent_crc(g_847.f0.f1, "g_847.f0.f1", print_hash_value);
    transparent_crc(g_847.f0.f2, "g_847.f0.f2", print_hash_value);
    transparent_crc(g_847.f0.f3, "g_847.f0.f3", print_hash_value);
    transparent_crc(g_847.f0.f4, "g_847.f0.f4", print_hash_value);
    transparent_crc(g_847.f0.f5, "g_847.f0.f5", print_hash_value);
    transparent_crc(g_847.f0.f6, "g_847.f0.f6", print_hash_value);
    transparent_crc(g_847.f0.f7, "g_847.f0.f7", print_hash_value);
    transparent_crc(g_847.f0.f8, "g_847.f0.f8", print_hash_value);
    transparent_crc(g_847.f0.f9, "g_847.f0.f9", print_hash_value);
    transparent_crc(g_847.f1, "g_847.f1", print_hash_value);
    transparent_crc(g_871.f0, "g_871.f0", print_hash_value);
    transparent_crc(g_871.f1, "g_871.f1", print_hash_value);
    transparent_crc(g_871.f2, "g_871.f2", print_hash_value);
    transparent_crc(g_871.f3, "g_871.f3", print_hash_value);
    transparent_crc(g_871.f4, "g_871.f4", print_hash_value);
    transparent_crc(g_871.f5, "g_871.f5", print_hash_value);
    transparent_crc(g_871.f6, "g_871.f6", print_hash_value);
    transparent_crc(g_871.f7, "g_871.f7", print_hash_value);
    transparent_crc(g_871.f8, "g_871.f8", print_hash_value);
    transparent_crc(g_871.f9, "g_871.f9", print_hash_value);
    transparent_crc(g_892.f0, "g_892.f0", print_hash_value);
    transparent_crc(g_892.f1, "g_892.f1", print_hash_value);
    transparent_crc(g_892.f2, "g_892.f2", print_hash_value);
    transparent_crc(g_892.f3, "g_892.f3", print_hash_value);
    transparent_crc(g_892.f4, "g_892.f4", print_hash_value);
    transparent_crc(g_892.f5, "g_892.f5", print_hash_value);
    transparent_crc(g_892.f6, "g_892.f6", print_hash_value);
    transparent_crc(g_892.f7, "g_892.f7", print_hash_value);
    transparent_crc(g_892.f8, "g_892.f8", print_hash_value);
    transparent_crc(g_892.f9, "g_892.f9", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_902[i][j][k].f0, "g_902[i][j][k].f0", print_hash_value);
                transparent_crc(g_902[i][j][k].f1, "g_902[i][j][k].f1", print_hash_value);
                transparent_crc(g_902[i][j][k].f2, "g_902[i][j][k].f2", print_hash_value);
                transparent_crc(g_902[i][j][k].f3, "g_902[i][j][k].f3", print_hash_value);
                transparent_crc(g_902[i][j][k].f4, "g_902[i][j][k].f4", print_hash_value);
                transparent_crc(g_902[i][j][k].f5, "g_902[i][j][k].f5", print_hash_value);
                transparent_crc(g_902[i][j][k].f6, "g_902[i][j][k].f6", print_hash_value);
                transparent_crc(g_902[i][j][k].f7, "g_902[i][j][k].f7", print_hash_value);
                transparent_crc(g_902[i][j][k].f8, "g_902[i][j][k].f8", print_hash_value);
                transparent_crc(g_902[i][j][k].f9, "g_902[i][j][k].f9", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_982.f0, "g_982.f0", print_hash_value);
    transparent_crc(g_982.f1, "g_982.f1", print_hash_value);
    transparent_crc(g_982.f2, "g_982.f2", print_hash_value);
    transparent_crc(g_982.f3, "g_982.f3", print_hash_value);
    transparent_crc(g_982.f4, "g_982.f4", print_hash_value);
    transparent_crc(g_982.f5, "g_982.f5", print_hash_value);
    transparent_crc(g_982.f6, "g_982.f6", print_hash_value);
    transparent_crc(g_982.f7, "g_982.f7", print_hash_value);
    transparent_crc(g_982.f8, "g_982.f8", print_hash_value);
    transparent_crc(g_982.f9, "g_982.f9", print_hash_value);
    transparent_crc(g_1019.f0.f0, "g_1019.f0.f0", print_hash_value);
    transparent_crc(g_1019.f0.f1, "g_1019.f0.f1", print_hash_value);
    transparent_crc(g_1019.f0.f2, "g_1019.f0.f2", print_hash_value);
    transparent_crc(g_1019.f0.f3, "g_1019.f0.f3", print_hash_value);
    transparent_crc(g_1019.f0.f4, "g_1019.f0.f4", print_hash_value);
    transparent_crc(g_1019.f0.f5, "g_1019.f0.f5", print_hash_value);
    transparent_crc(g_1019.f0.f6, "g_1019.f0.f6", print_hash_value);
    transparent_crc(g_1019.f0.f7, "g_1019.f0.f7", print_hash_value);
    transparent_crc(g_1019.f0.f8, "g_1019.f0.f8", print_hash_value);
    transparent_crc(g_1019.f0.f9, "g_1019.f0.f9", print_hash_value);
    transparent_crc(g_1019.f1, "g_1019.f1", print_hash_value);
    transparent_crc(g_1125, "g_1125", print_hash_value);
    transparent_crc(g_1126, "g_1126", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 265
   depth: 1, occurrence: 6
   depth: 2, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 40
breakdown:
   indirect level: 0, occurrence: 15
   indirect level: 1, occurrence: 16
   indirect level: 2, occurrence: 7
   indirect level: 3, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 24
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 16
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 16

XXX max expression depth: 40
breakdown:
   depth: 1, occurrence: 95
   depth: 2, occurrence: 25
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 18, occurrence: 3
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 23, occurrence: 1
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 2
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 40, occurrence: 1

XXX total number of pointers: 234

XXX times a variable address is taken: 484
XXX times a pointer is dereferenced on RHS: 130
breakdown:
   depth: 1, occurrence: 118
   depth: 2, occurrence: 11
   depth: 3, occurrence: 1
XXX times a pointer is dereferenced on LHS: 154
breakdown:
   depth: 1, occurrence: 149
   depth: 2, occurrence: 5
XXX times a pointer is compared with null: 16
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 5
XXX times a pointer is qualified to be dereferenced: 3609

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 772
   level: 2, occurrence: 70
   level: 3, occurrence: 9
XXX number of pointers point to pointers: 79
XXX number of pointers point to scalars: 138
XXX number of pointers point to structs: 17
XXX percent of pointers has null in alias set: 23.1
XXX average alias set size: 1.58

XXX times a non-volatile is read: 826
XXX times a non-volatile is write: 469
XXX times a volatile is read: 58
XXX    times read thru a pointer: 9
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2.6e+03
XXX percentage of non-volatile access: 95.4

XXX forward jumps: 0
XXX backward jumps: 3

XXX stmts: 97
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 28
   depth: 1, occurrence: 12
   depth: 2, occurrence: 21
   depth: 3, occurrence: 17
   depth: 4, occurrence: 9
   depth: 5, occurrence: 10

XXX percentage a fresh-made variable is used: 18.2
XXX percentage an existing variable is used: 81.8
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

