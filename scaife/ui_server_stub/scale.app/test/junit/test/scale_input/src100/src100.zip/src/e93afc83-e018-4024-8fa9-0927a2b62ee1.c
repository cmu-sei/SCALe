/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      3882081477
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static int32_t g_4[10][3][4] = {{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}},{{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L},{0x3C4AB274L,0x6CA2CB51L,0x6CA2CB51L,0x3C4AB274L}}};
static int32_t * volatile g_3 = &g_4[6][2][0];/* VOLATILE GLOBAL g_3 */
static int32_t **g_53 = (void*)0;
static uint16_t g_63 = 65534UL;
static volatile int32_t g_66 = (-10L);/* VOLATILE GLOBAL g_66 */
static volatile int32_t g_67 = 0x392E18E6L;/* VOLATILE GLOBAL g_67 */
static volatile int32_t g_68 = 0x354D1843L;/* VOLATILE GLOBAL g_68 */
static volatile int32_t g_69[9][5][2] = {{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}}};
static volatile int32_t g_70 = 0x505F459CL;/* VOLATILE GLOBAL g_70 */
static volatile int32_t g_71[7][7] = {{0xD2125954L,(-1L),(-1L),0xD2125954L,0x72679F1AL,0x094C655EL,0x72679F1AL},{0xD2125954L,(-1L),(-1L),0xD2125954L,0x72679F1AL,0x094C655EL,0x72679F1AL},{0xD2125954L,(-1L),(-1L),0xD2125954L,0x72679F1AL,0x094C655EL,0x72679F1AL},{0xD2125954L,(-1L),(-1L),0xD2125954L,0x72679F1AL,0x094C655EL,(-1L)},{(-1L),0x094C655EL,0x094C655EL,(-1L),(-1L),0xFA41D407L,(-1L)},{(-1L),0x094C655EL,0x094C655EL,(-1L),(-1L),0xFA41D407L,(-1L)},{(-1L),0x094C655EL,0x094C655EL,(-1L),(-1L),0xFA41D407L,(-1L)}};
static volatile int32_t g_72[4][5] = {{0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL},{0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL},{0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL},{0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL,0x38EDFC7AL}};
static volatile int32_t g_73 = 0x98C3D34EL;/* VOLATILE GLOBAL g_73 */
static volatile int32_t g_74 = (-1L);/* VOLATILE GLOBAL g_74 */
static volatile int32_t g_75 = 0x9E48991CL;/* VOLATILE GLOBAL g_75 */
static volatile int32_t g_76 = 0L;/* VOLATILE GLOBAL g_76 */
static volatile int32_t g_77 = 0xDB5B2921L;/* VOLATILE GLOBAL g_77 */
static volatile int32_t g_78 = 1L;/* VOLATILE GLOBAL g_78 */
static volatile int32_t g_79 = (-1L);/* VOLATILE GLOBAL g_79 */
static volatile int32_t g_80 = 0xDD14A140L;/* VOLATILE GLOBAL g_80 */
static volatile int32_t g_81 = 0x401FF3C8L;/* VOLATILE GLOBAL g_81 */
static volatile int32_t g_82 = 7L;/* VOLATILE GLOBAL g_82 */
static volatile int32_t g_83 = 0x799B58ECL;/* VOLATILE GLOBAL g_83 */
static volatile int32_t g_84[2][10] = {{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)},{(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)}};
static volatile int32_t g_85 = (-10L);/* VOLATILE GLOBAL g_85 */
static volatile int32_t g_86 = 1L;/* VOLATILE GLOBAL g_86 */
static volatile int32_t g_87 = (-7L);/* VOLATILE GLOBAL g_87 */
static volatile int32_t g_88[5] = {(-7L),(-7L),(-7L),(-7L),(-7L)};
static volatile int32_t g_89 = 0x3B787D1AL;/* VOLATILE GLOBAL g_89 */
static volatile int32_t g_90[2][2][9] = {{{0xBB7F4763L,1L,1L,0xBB7F4763L,0xBB7F4763L,1L,1L,0xBB7F4763L,0xBB7F4763L},{0x1248F7C4L,0x63317A7FL,0x1248F7C4L,0x63317A7FL,0x1248F7C4L,0x63317A7FL,0x1248F7C4L,0x63317A7FL,0x1248F7C4L}},{{0xBB7F4763L,0xBB7F4763L,1L,1L,0xBB7F4763L,0xBB7F4763L,1L,1L,0xBB7F4763L},{0L,0x63317A7FL,0L,0x63317A7FL,0L,0x63317A7FL,0L,0x63317A7FL,0L}}};
static volatile int32_t g_91 = 1L;/* VOLATILE GLOBAL g_91 */
static volatile int32_t g_92 = 0x27032CD4L;/* VOLATILE GLOBAL g_92 */
static volatile int32_t g_93 = 0xEDA29731L;/* VOLATILE GLOBAL g_93 */
static volatile int32_t g_94 = 0x970EAE32L;/* VOLATILE GLOBAL g_94 */
static volatile int32_t g_95 = (-1L);/* VOLATILE GLOBAL g_95 */
static volatile int32_t g_96 = (-10L);/* VOLATILE GLOBAL g_96 */
static volatile int32_t g_97 = 0xB2DFF541L;/* VOLATILE GLOBAL g_97 */
static volatile int32_t g_98 = (-1L);/* VOLATILE GLOBAL g_98 */
static volatile int32_t g_99 = 0x3CE9D1BBL;/* VOLATILE GLOBAL g_99 */
static volatile int32_t g_100 = 0L;/* VOLATILE GLOBAL g_100 */
static volatile int32_t g_101 = 0x9AA88D18L;/* VOLATILE GLOBAL g_101 */
static volatile int32_t g_102 = 0xA44ADEF0L;/* VOLATILE GLOBAL g_102 */
static volatile int32_t g_103 = 0x30C92616L;/* VOLATILE GLOBAL g_103 */
static volatile int32_t g_104 = 1L;/* VOLATILE GLOBAL g_104 */
static volatile int32_t g_105 = 1L;/* VOLATILE GLOBAL g_105 */
static volatile int32_t g_106 = 1L;/* VOLATILE GLOBAL g_106 */
static volatile int32_t g_107[8][1][3] = {{{0xA6B6B07CL,0x3E9F7A6BL,0x2A6F4112L}},{{0xC47F9ABEL,0xA6B6B07CL,0x2B02D377L}},{{0xAEBC0183L,0xAEBC0183L,6L}},{{0xC47F9ABEL,6L,0xA6B6B07CL}},{{0xA6B6B07CL,6L,0xC47F9ABEL}},{{6L,0xAEBC0183L,0xAEBC0183L}},{{0x2B02D377L,0xA6B6B07CL,0xC47F9ABEL}},{{0x2A6F4112L,0x3E9F7A6BL,0xA6B6B07CL}}};
static volatile int32_t g_108 = (-2L);/* VOLATILE GLOBAL g_108 */
static volatile int32_t g_109[3] = {0x98CFE46DL,0x98CFE46DL,0x98CFE46DL};
static volatile int32_t g_110 = 0xA9E5F641L;/* VOLATILE GLOBAL g_110 */
static volatile int32_t g_111[3][7] = {{(-10L),0L,(-10L),0L,(-10L),0L,(-10L)},{0xE1F63711L,0xE1F63711L,0xAB14A3D9L,0xAB14A3D9L,0xE1F63711L,0xE1F63711L,0xAB14A3D9L},{2L,0L,2L,0L,2L,0L,2L}};
static volatile int32_t g_112 = 0x510C19EDL;/* VOLATILE GLOBAL g_112 */
static volatile int32_t g_113 = 9L;/* VOLATILE GLOBAL g_113 */
static volatile int32_t g_114 = 9L;/* VOLATILE GLOBAL g_114 */
static volatile int32_t g_115 = 1L;/* VOLATILE GLOBAL g_115 */
static volatile int32_t g_116 = 1L;/* VOLATILE GLOBAL g_116 */
static volatile int32_t g_117 = 7L;/* VOLATILE GLOBAL g_117 */
static volatile int32_t g_118 = (-9L);/* VOLATILE GLOBAL g_118 */
static volatile int32_t g_119[8] = {0x39895558L,0x39895558L,0x39895558L,0x39895558L,0x39895558L,0x39895558L,0x39895558L,0x39895558L};
static volatile int32_t g_120 = 0xEC192D0FL;/* VOLATILE GLOBAL g_120 */
static volatile int32_t g_121 = 0xD2F72762L;/* VOLATILE GLOBAL g_121 */
static volatile int32_t g_122 = 0xB16C6279L;/* VOLATILE GLOBAL g_122 */
static volatile int32_t g_123 = 0x35EF5641L;/* VOLATILE GLOBAL g_123 */
static volatile int32_t g_124 = 0xB9925C1FL;/* VOLATILE GLOBAL g_124 */
static volatile int32_t g_125 = 0L;/* VOLATILE GLOBAL g_125 */
static volatile int32_t g_126 = 0xA4A23C0FL;/* VOLATILE GLOBAL g_126 */
static volatile int32_t g_127 = 0x91DD11AFL;/* VOLATILE GLOBAL g_127 */
static volatile int32_t g_128 = 0x9B23D7FFL;/* VOLATILE GLOBAL g_128 */
static volatile int32_t g_129 = (-7L);/* VOLATILE GLOBAL g_129 */
static volatile int32_t g_130 = 1L;/* VOLATILE GLOBAL g_130 */
static volatile int32_t g_131 = 0xFD74DCC0L;/* VOLATILE GLOBAL g_131 */
static volatile int32_t g_132 = 8L;/* VOLATILE GLOBAL g_132 */
static volatile int32_t g_133 = 1L;/* VOLATILE GLOBAL g_133 */
static volatile int32_t g_134[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
static volatile int32_t g_135 = (-1L);/* VOLATILE GLOBAL g_135 */
static volatile int32_t g_136 = (-3L);/* VOLATILE GLOBAL g_136 */
static volatile int32_t g_137[8] = {0x05353217L,0xFFCED716L,0x05353217L,0x05353217L,0xFFCED716L,0x05353217L,0x05353217L,0xFFCED716L};
static volatile int32_t *g_65[5][6][8] = {{{&g_136,&g_76,&g_116,(void*)0,&g_78,&g_69[5][3][1],&g_90[1][1][1],&g_72[3][3]},{(void*)0,&g_67,&g_88[1],&g_70,&g_81,&g_122,&g_94,&g_126},{&g_112,&g_83,(void*)0,&g_115,&g_107[0][0][1],(void*)0,&g_112,&g_123},{&g_89,&g_112,&g_93,&g_105,&g_77,&g_80,(void*)0,&g_104},{&g_120,&g_123,&g_85,&g_78,&g_100,&g_84[0][0],&g_95,&g_69[5][3][1]},{&g_137[5],&g_118,&g_131,&g_104,&g_107[0][0][1],&g_71[2][3],&g_134[0],&g_86}},{{&g_135,&g_97,(void*)0,(void*)0,&g_97,&g_112,(void*)0,&g_88[1]},{&g_116,&g_130,&g_103,&g_107[0][0][1],&g_72[3][3],&g_136,&g_89,(void*)0},{&g_82,&g_76,&g_99,(void*)0,&g_98,&g_74,&g_77,(void*)0},{&g_100,(void*)0,&g_80,(void*)0,&g_109[0],&g_134[0],&g_118,&g_134[0]},{&g_102,&g_129,&g_113,&g_129,&g_102,&g_108,(void*)0,&g_69[5][3][1]},{&g_88[1],&g_94,(void*)0,&g_125,(void*)0,&g_137[5],&g_82,&g_129}},{{&g_129,(void*)0,(void*)0,&g_105,&g_112,&g_77,(void*)0,&g_99},{(void*)0,&g_116,&g_113,&g_69[5][3][1],&g_126,&g_73,&g_118,&g_126},{(void*)0,&g_102,&g_80,(void*)0,&g_123,(void*)0,&g_77,&g_135},{&g_76,&g_74,&g_99,&g_86,&g_104,&g_82,&g_89,&g_128},{&g_118,&g_95,&g_103,&g_72[3][3],&g_69[5][3][1],&g_96,(void*)0,&g_102},{(void*)0,&g_102,(void*)0,&g_109[0],&g_86,(void*)0,&g_134[0],&g_132}},{{(void*)0,&g_93,&g_131,&g_130,&g_88[1],&g_77,&g_95,(void*)0},{&g_78,&g_66,&g_85,&g_135,(void*)0,&g_113,(void*)0,&g_72[3][3]},{&g_125,&g_94,&g_93,&g_122,(void*)0,&g_131,&g_112,&g_120},{(void*)0,&g_104,(void*)0,&g_94,&g_134[0],&g_134[0],&g_94,(void*)0},{&g_98,&g_98,(void*)0,&g_118,&g_69[5][3][1],&g_119[6],&g_130,&g_100},{(void*)0,&g_76,(void*)0,&g_128,&g_129,&g_88[1],&g_80,&g_100}},{{&g_76,(void*)0,&g_97,&g_118,&g_99,&g_112,&g_83,(void*)0},{&g_110,&g_120,&g_92,&g_94,&g_126,&g_86,&g_109[0],(void*)0},{&g_96,&g_88[1],&g_111[0][6],&g_92,&g_104,(void*)0,&g_79,&g_112},{&g_97,&g_70,&g_73,&g_104,&g_96,&g_119[6],&g_101,&g_114},{&g_82,&g_104,&g_86,&g_99,&g_74,&g_76,&g_109[0],&g_101},{&g_119[6],&g_122,&g_85,&g_79,&g_101,&g_85,(void*)0,&g_74}}};
static volatile int32_t **g_64 = &g_65[3][5][0];
static int8_t g_147 = 0x49L;
static uint16_t g_150 = 0x1089L;
static uint16_t *g_149 = &g_150;
static uint8_t g_151 = 0x8EL;
static int32_t *g_156 = &g_4[6][2][0];
static int32_t **g_155 = &g_156;
static uint32_t g_167 = 0xB5AB6CACL;
static uint32_t g_182 = 4294967291UL;
static uint32_t *g_181 = &g_182;
static uint32_t g_194 = 4294967292UL;
static int64_t g_211[8][6][2] = {{{1L,0L},{0x9698A88581A1E8DBLL,(-3L)},{4L,0x9698A88581A1E8DBLL},{0x0768EFDD03B609C6LL,0xBECFBBAAEE789F30LL},{0x0768EFDD03B609C6LL,0x9698A88581A1E8DBLL},{4L,(-3L)}},{{0x9698A88581A1E8DBLL,0L},{1L,1L},{(-1L),8L},{8L,0x2ECEAEF97A493877LL},{(-1L),(-3L)},{1L,(-7L)}},{{1L,0x2ECEAEF97A493877LL},{0x0768EFDD03B609C6LL,1L},{(-1L),7L},{(-1L),0L},{1L,0xC435FAD4334ECE72LL},{4L,1L}},{{8L,0xBECFBBAAEE789F30LL},{1L,7L},{4L,(-7L)},{7L,0L},{1L,0x9698A88581A1E8DBLL},{(-1L),0x0768EFDD03B609C6LL}},{{1L,0x2ECEAEF97A493877LL},{1L,0xC435FAD4334ECE72LL},{1L,0xC435FAD4334ECE72LL},{1L,0x2ECEAEF97A493877LL},{1L,0x0768EFDD03B609C6LL},{(-1L),0x9698A88581A1E8DBLL}},{{1L,0L},{7L,(-7L)},{4L,7L},{1L,0xBECFBBAAEE789F30LL},{8L,1L},{4L,0xC435FAD4334ECE72LL}},{{1L,0L},{(-1L),7L},{(-1L),1L},{0x0768EFDD03B609C6LL,0x2ECEAEF97A493877LL},{1L,(-7L)},{1L,(-3L)}},{{(-1L),0x2ECEAEF97A493877LL},{8L,8L},{(-1L),1L},{1L,0L},{0x9698A88581A1E8DBLL,(-3L)},{4L,0x9698A88581A1E8DBLL}}};
static uint8_t g_215 = 0x01L;
static int16_t g_218[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
static uint8_t g_220 = 255UL;
static int16_t g_223[1][7] = {{0L,0L,0L,0L,0L,0L,0L}};
static int16_t g_225 = 1L;
static uint16_t g_226 = 0x683FL;
static int8_t g_259[4] = {(-2L),(-2L),(-2L),(-2L)};
static int64_t g_263 = (-1L);
static int8_t g_265[8] = {0xDAL,0xBDL,0xBDL,0xDAL,0xBDL,0xBDL,0xDAL,0xBDL};
static uint32_t g_266 = 0UL;
static uint8_t g_268[7][8] = {{0xE9L,0x15L,0xE9L,0xCAL,0xCAL,0xE9L,0x15L,0xE9L},{0x3DL,0xCAL,0xD0L,0xCAL,0x3DL,0x3DL,0xCAL,0xD0L},{0x3DL,0x3DL,0xCAL,0xD0L,0xCAL,0x3DL,0x3DL,0xCAL},{0xE9L,0xCAL,0xCAL,0xE9L,0x15L,0xE9L,0xCAL,0xE9L},{0xE9L,0x3DL,0x15L,0x15L,0x3DL,0xE9L,0x3DL,0x15L},{0xD0L,0x3DL,0xD0L,0xE9L,0xE9L,0xD0L,0x3DL,0xD0L},{0xCAL,0xE9L,0x15L,0xE9L,0xCAL,0xCAL,0xE9L,0x15L}};
static uint32_t g_274[5][6][4] = {{{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L},{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L}},{{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L},{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L}},{{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L},{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L}},{{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L},{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L}},{{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L},{1UL,0xCCD7B2C7L,1UL,1UL},{0xCCD7B2C7L,0xCCD7B2C7L,0x54771272L,0xCCD7B2C7L},{0xCCD7B2C7L,1UL,1UL,0xCCD7B2C7L}}};
static int16_t g_293 = 0x6039L;
static uint16_t g_294[7] = {0x5306L,0x5306L,0x5306L,0x5306L,0x5306L,0x5306L,0x5306L};
static int64_t g_344[2][2][8] = {{{0x79196BF7D5F75E5ELL,0x6A94C9F59413205ALL,0x79196BF7D5F75E5ELL,0L,(-2L),0x210BA1AC6A4DF166LL,0xE0AACB86EDECE64ALL,0xE0AACB86EDECE64ALL},{0xE0AACB86EDECE64ALL,0xBA36E7A10DB0B287LL,7L,7L,0xBA36E7A10DB0B287LL,0xE0AACB86EDECE64ALL,(-2L),(-1L)}},{{0xE0AACB86EDECE64ALL,0x024A533F771F14BCLL,0x5957E19047CAE5D4LL,0xBA36E7A10DB0B287LL,(-2L),0xBA36E7A10DB0B287LL,0x5957E19047CAE5D4LL,0x024A533F771F14BCLL},{0x79196BF7D5F75E5ELL,0x5957E19047CAE5D4LL,0x210BA1AC6A4DF166LL,0xBA36E7A10DB0B287LL,(-1L),0L,0L,(-1L)}}};
static uint64_t g_387[9] = {0x41CFB4111556C38ALL,0x6B0394F41C5570A1LL,0x41CFB4111556C38ALL,0x41CFB4111556C38ALL,0x6B0394F41C5570A1LL,0x41CFB4111556C38ALL,0x41CFB4111556C38ALL,0x41CFB4111556C38ALL,0x90F2FBF070F4C9D8LL};
static uint64_t g_390[9] = {0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL,0x45E12521B3147C1FLL};
static int32_t g_483[1] = {0x0585EAEFL};
static int32_t g_496[9][2] = {{3L,3L},{3L,3L},{3L,3L},{3L,3L},{3L,3L},{3L,3L},{3L,3L},{3L,3L},{3L,3L}};
static int32_t * const *g_526 = &g_156;
static int64_t g_581 = 0xC15AD43F3C3C12B8LL;
static uint64_t *g_585 = &g_390[3];
static int64_t *g_605 = (void*)0;
static uint8_t g_633 = 0xE3L;
static int64_t **g_680 = &g_605;
static uint32_t *g_712 = &g_274[4][0][2];
static uint32_t **g_711 = &g_712;
static int32_t g_721 = 0x9C9735DDL;
static int16_t g_752[8][4] = {{6L,(-1L),1L,0x1FC1L},{0x4132L,6L,0xF3CAL,0xE5CBL},{4L,0xAD6DL,4L,0xE5CBL},{0xF3CAL,6L,0x4132L,0x1FC1L},{1L,(-1L),6L,6L},{0xD8C0L,0xD8C0L,6L,4L},{1L,0x1576L,0x4132L,(-1L)},{0xF3CAL,0x4132L,4L,0x4132L}};
static int32_t g_767[4] = {7L,7L,7L,7L};
static uint64_t g_784 = 0xF825F1D6685561DELL;
static const uint32_t *g_788 = &g_182;
static const uint32_t **g_787 = &g_788;
static int8_t *g_847 = &g_265[1];
static int8_t * const  volatile * volatile g_846 = &g_847;/* VOLATILE GLOBAL g_846 */
static int8_t * const  volatile * volatile *g_845 = &g_846;
static int16_t *g_851[1][10] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int16_t **g_850 = &g_851[0][0];
static uint8_t *g_950 = &g_268[0][3];
static const int64_t g_1018 = 0xA9574C614F683D93LL;
static uint32_t **g_1064 = &g_181;
static uint32_t ***g_1063[7][7] = {{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064},{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064}};
static int32_t * volatile g_1078 = &g_767[2];/* VOLATILE GLOBAL g_1078 */
static uint64_t **g_1162[4] = {&g_585,&g_585,&g_585,&g_585};
static int32_t *g_1198[2][2][9] = {{{&g_496[8][0],&g_496[8][0],&g_496[4][1],&g_4[6][2][0],&g_496[4][1],&g_496[8][0],&g_496[8][0],&g_496[4][1],&g_4[6][2][0]},{&g_4[9][1][3],&g_496[8][0],&g_4[9][1][3],(void*)0,(void*)0,&g_4[9][1][3],&g_496[8][0],&g_4[9][1][3],(void*)0}},{{&g_4[1][1][3],&g_496[4][1],&g_496[4][1],&g_4[1][1][3],&g_496[8][0],&g_4[1][1][3],&g_496[4][1],&g_496[4][1],&g_4[1][1][3]},{&g_4[6][1][0],(void*)0,&g_4[0][2][0],(void*)0,&g_4[6][1][0],&g_4[6][1][0],(void*)0,&g_4[0][2][0],(void*)0}}};
static int32_t ** volatile g_1199 = &g_1198[1][1][6];/* VOLATILE GLOBAL g_1199 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_5(uint32_t  p_6, int64_t  p_7, int64_t  p_8);
static uint8_t  func_14(int32_t * p_15, int32_t  p_16, uint16_t  p_17);
static int32_t * func_18(int32_t * p_19, const int32_t * const  p_20, int32_t * p_21, int32_t * p_22);
static int16_t  func_25(int32_t  p_26, uint64_t  p_27, uint32_t  p_28, int32_t * p_29);
static int16_t  func_32(int32_t  p_33);
static int32_t * func_35(int32_t * p_36);
static int32_t * const * func_38(uint64_t  p_39, int32_t * const * p_40);
static int32_t * func_42(uint32_t  p_43, int32_t * p_44);
static uint32_t  func_46(uint16_t  p_47, int32_t ** p_48);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_64 g_155 g_63 g_151 g_150 g_65 g_156 g_53 g_167 g_182 g_194 g_147 g_226 g_215 g_266 g_268 g_274 g_218 g_294 g_225 g_223 g_344 g_211 g_293 g_265 g_259 g_483 g_496 g_390 g_220 g_387 g_149 g_752 g_581 g_585 g_767 g_680 g_784 g_787 g_788 g_711 g_847 g_950 g_845 g_846 g_1063 g_1078 g_119 g_1198 g_1199 g_721 g_1018 g_95
 * writes: g_4 g_53 g_63 g_147 g_149 g_151 g_150 g_65 g_156 g_167 g_181 g_182 g_194 g_211 g_215 g_218 g_220 g_226 g_259 g_263 g_265 g_268 g_266 g_274 g_294 g_223 g_344 g_387 g_390 g_483 g_496 g_225 g_526 g_752 g_605 g_293 g_787 g_712 g_950 g_784 g_767 g_581 g_119 g_155 g_69 g_1162 g_1198
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_9 = 0x2A26L;
    int16_t *l_751 = &g_752[2][2];
    int32_t *l_753 = (void*)0;
    uint8_t l_1033 = 0UL;
    int16_t l_1034[7][9] = {{(-10L),0x155FL,0x098AL,0x155FL,(-10L),0x954BL,(-10L),0x155FL,0x098AL},{0x5673L,0x5673L,1L,0x5673L,0x5673L,1L,0x5673L,0x5673L,1L},{(-10L),0x155FL,0x098AL,0x155FL,(-10L),0x954BL,(-10L),0x7429L,(-10L)},{0L,0L,0x5673L,0L,0L,0x5673L,0L,0L,0x5673L},{(-4L),0x7429L,(-10L),0x7429L,(-4L),0x155FL,(-4L),0x7429L,(-10L)},{0L,0L,0x5673L,0L,0L,0x5673L,0L,0L,0x5673L},{(-4L),0x7429L,(-10L),0x7429L,(-4L),0x155FL,(-4L),0x7429L,(-10L)}};
    int32_t l_1249 = 0x8F316E87L;
    int i, j;
    (*g_3) = (g_2 & 5L);
    l_1249 = (&g_2 == ((func_5(l_9, g_4[6][2][0], (safe_sub_func_int8_t_s_s((safe_mul_func_uint8_t_u_u(((((func_14(func_18((((g_483[0] = ((safe_rshift_func_int16_t_s_s(g_2, func_25(g_4[2][1][0], g_4[6][2][0], (((safe_mod_func_int32_t_s_s(((((*l_751) ^= func_32(g_4[9][0][3])) > g_581) <= 0L), 5UL)) , 4294967294UL) , l_9), l_753))) && l_1033)) ^ l_1034[3][0]) , (void*)0), &g_4[6][2][0], l_753, &g_4[5][2][1]), g_721, g_1018) | g_4[6][2][0]) == 0x30L) ^ g_4[6][2][0]) | l_1034[0][6]), 0xA9L)), 9UL))) >= l_1249) , (void*)0));
    return l_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_950 g_220 g_268 g_845 g_846 g_847 g_265 g_585 g_390 g_788 g_182 g_150
 * writes: g_150 g_220 g_268
 */
static uint16_t  func_5(uint32_t  p_6, int64_t  p_7, int64_t  p_8)
{ /* block id: 584 */
    uint32_t *l_1245 = &g_182;
    uint16_t *l_1246 = &g_150;
    int32_t l_1247[4][8] = {{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)}};
    int16_t l_1248 = 7L;
    int i, j;
    l_1248 = (safe_rshift_func_int16_t_s_u((((safe_lshift_func_uint8_t_u_s(((*g_950) = (safe_mod_func_uint32_t_u_u(p_6, (safe_sub_func_int64_t_s_s(((safe_sub_func_uint64_t_u_u(((((!1UL) , (p_8 >= (((*l_1246) ^= (((((safe_sub_func_uint8_t_u_u((*g_950), (safe_div_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u(p_7, ((0x383ACFD3L > (safe_sub_func_int64_t_s_s(((((65530UL ^ ((safe_div_func_uint32_t_u_u((0x5EA882794791A2A7LL > 18446744073709551608UL), p_6)) & 0xA04AD663L)) > 1UL) , (*g_950)) == (***g_845)), 1UL))) || (*g_585)))), (*g_847))) > 250UL), 0x7FB2L)))) , l_1245) == l_1245) < (*g_788)) <= (-1L))) != p_7))) | l_1247[0][0]) > p_8), p_8)) == 0xDC07L), 0xD5055EAF0D14735ALL))))), 5)) , p_8) , 0x9BD9L), l_1247[0][0]));
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_585 g_390 g_95 g_1078 g_950 g_220 g_268
 * writes: g_390 g_767
 */
static uint8_t  func_14(int32_t * p_15, int32_t  p_16, uint16_t  p_17)
{ /* block id: 578 */
    uint32_t l_1202[10][1][5] = {{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}},{{0x93775CA2L,0x8796AB37L,0xC6C0D394L,0xC6C0D394L,0x8796AB37L}}};
    int32_t l_1205 = (-10L);
    int64_t *l_1206 = &g_344[1][0][1];
    int32_t *l_1215[8][5][6] = {{{&g_767[1],&g_4[6][2][0],&g_483[0],&g_767[0],&g_483[0],&g_483[0]},{&g_767[0],&g_483[0],&g_483[0],&g_767[0],&g_483[0],&g_4[6][2][0]},{&g_767[1],&g_4[4][0][3],&g_767[3],&g_4[6][2][0],&g_767[3],&g_483[0]},{&g_767[3],&g_483[0],(void*)0,&g_483[0],&g_767[3],(void*)0},{&g_483[0],&g_4[4][0][3],&g_767[2],(void*)0,&g_483[0],&g_767[3]}},{{&g_767[3],&g_483[0],&g_4[4][0][3],&g_4[4][0][3],&g_483[0],&g_767[3]},{(void*)0,&g_4[6][2][0],&g_767[2],&g_767[3],&g_767[3],(void*)0},{&g_483[0],&g_483[0],(void*)0,&g_767[3],(void*)0,&g_483[0]},{&g_483[0],(void*)0,&g_767[3],&g_767[3],&g_767[2],&g_4[6][2][0]},{(void*)0,&g_767[3],&g_483[0],&g_4[4][0][3],&g_4[4][0][3],&g_483[0]}},{{&g_767[3],&g_767[3],&g_483[0],(void*)0,&g_767[2],&g_4[4][0][3]},{&g_483[0],(void*)0,&g_767[3],&g_483[0],(void*)0,&g_483[0]},{&g_4[4][0][3],(void*)0,&g_4[4][0][3],(void*)0,&g_483[0],&g_483[0]},{&g_767[3],(void*)0,&g_483[0],&g_767[3],&g_767[0],&g_767[0]},{&g_767[3],&g_767[0],&g_767[0],&g_767[3],&g_483[0],(void*)0}},{{&g_767[3],&g_483[0],&g_483[0],(void*)0,&g_4[4][0][3],(void*)0},{&g_4[4][0][3],&g_483[0],&g_767[1],&g_483[0],&g_4[4][0][3],&g_767[2]},{(void*)0,&g_483[0],(void*)0,&g_4[6][2][0],&g_483[0],&g_483[0]},{&g_483[0],&g_767[0],&g_483[0],&g_483[0],&g_767[0],&g_483[0]},{&g_4[6][2][0],(void*)0,(void*)0,&g_4[4][0][3],&g_483[0],&g_767[2]}},{{&g_767[0],(void*)0,&g_767[1],&g_483[0],&g_767[1],(void*)0},{&g_767[0],&g_767[2],&g_483[0],&g_4[4][0][3],(void*)0,(void*)0},{&g_4[6][2][0],&g_483[0],&g_767[0],&g_483[0],&g_483[0],&g_767[0]},{&g_483[0],&g_483[0],&g_483[0],&g_4[6][2][0],(void*)0,&g_483[0]},{(void*)0,&g_767[2],&g_4[4][0][3],&g_483[0],&g_767[1],&g_483[0]}},{{&g_4[4][0][3],(void*)0,&g_4[4][0][3],(void*)0,&g_483[0],&g_483[0]},{&g_767[3],(void*)0,&g_483[0],&g_767[3],&g_767[0],&g_767[0]},{&g_767[3],&g_767[0],&g_767[0],&g_767[3],&g_483[0],(void*)0},{&g_767[3],&g_483[0],&g_483[0],(void*)0,&g_4[4][0][3],(void*)0},{&g_4[4][0][3],&g_483[0],&g_767[1],&g_483[0],&g_4[4][0][3],&g_767[2]}},{{(void*)0,&g_483[0],(void*)0,&g_4[6][2][0],&g_483[0],&g_483[0]},{&g_483[0],&g_767[0],&g_483[0],&g_483[0],&g_767[0],&g_483[0]},{&g_4[6][2][0],(void*)0,(void*)0,&g_4[4][0][3],&g_483[0],&g_767[2]},{&g_767[0],(void*)0,&g_767[1],&g_483[0],&g_767[1],(void*)0},{&g_767[0],&g_767[2],&g_483[0],&g_4[4][0][3],(void*)0,(void*)0}},{{&g_4[6][2][0],&g_483[0],&g_767[0],&g_483[0],&g_483[0],&g_767[0]},{&g_483[0],&g_483[0],&g_483[0],&g_4[6][2][0],(void*)0,&g_483[0]},{(void*)0,&g_767[2],&g_4[4][0][3],&g_483[0],&g_767[1],&g_483[0]},{&g_4[4][0][3],(void*)0,&g_4[4][0][3],(void*)0,&g_483[0],&g_483[0]},{&g_767[3],(void*)0,&g_483[0],&g_767[3],&g_767[0],&g_767[0]}}};
    uint16_t l_1216[6][5];
    int8_t *l_1221 = &g_265[1];
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
            l_1216[i][j] = 0x501EL;
    }
    (*g_1078) = (((l_1202[5][0][4] , ((l_1205 = (1UL == ((*g_585)++))) ^ p_17)) <= ((l_1206 != (void*)0) > g_95)) | (safe_mul_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_add_func_int8_t_s_s(((((safe_div_func_int32_t_s_s((l_1216[4][3] = 1L), (safe_mod_func_int16_t_s_s((((safe_add_func_uint16_t_u_u(p_17, 0x7EFBL)) & p_16) & p_17), p_17)))) == p_16) , l_1221) == l_1221), p_17)) > 0x74ACL), 7)) < p_16), p_16)));
    return (*g_950);
}


/* ------------------------------------------ */
/* 
 * reads : g_147 g_845 g_846 g_847 g_265 g_1063 g_585 g_390 g_63 g_788 g_182 g_1078 g_767 g_581 g_950 g_220 g_268 g_150 g_119 g_293 g_151 g_64 g_65 g_155 g_711 g_4 g_294 g_3 g_218 g_211 g_266 g_1198 g_1199
 * writes: g_147 g_265 g_63 g_767 g_581 g_119 g_150 g_293 g_151 g_496 g_65 g_156 g_712 g_390 g_218 g_752 g_155 g_69 g_294 g_1162 g_266 g_1198
 */
static int32_t * func_18(int32_t * p_19, const int32_t * const  p_20, int32_t * p_21, int32_t * p_22)
{ /* block id: 465 */
    int32_t l_1037 = 1L;
    uint16_t *l_1045 = &g_294[0];
    int32_t l_1050[9][2][3] = {{{0L,0L,0L},{0L,0xCAE57571L,0xC2129D64L}},{{0x631FC61BL,0L,0xC2129D64L},{(-7L),0xC2129D64L,0L}},{{0L,(-1L),1L},{0xC2129D64L,0xC2129D64L,(-1L)}},{{0x8560E827L,0L,0x3C8DAC67L},{0x8560E827L,0x3C8DAC67L,0L}},{{(-1L),0L,0L},{0L,(-7L),0L}},{{0xBD6BB9CFL,0xCAE57571L,1L},{0L,0xCAE57571L,0x8560E827L}},{{0L,(-7L),0x631FC61BL},{0xC2129D64L,0L,0L}},{{0L,0x3C8DAC67L,(-1L)},{0L,0L,(-1L)}},{{0xBD6BB9CFL,(-1L),0L},{0L,0x8560E827L,0x631FC61BL}}};
    uint32_t **l_1060 = &g_181;
    uint32_t ***l_1059 = &l_1060;
    int32_t **l_1124 = &g_156;
    uint64_t **l_1142[1];
    int8_t **l_1172 = &g_847;
    int8_t ***l_1171[2][5] = {{&l_1172,&l_1172,&l_1172,&l_1172,&l_1172},{&l_1172,&l_1172,&l_1172,&l_1172,&l_1172}};
    uint32_t l_1184 = 18446744073709551606UL;
    int32_t l_1186 = (-1L);
    int32_t *l_1197 = &l_1186;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1142[i] = &g_585;
    for (g_147 = 26; (g_147 > 13); --g_147)
    { /* block id: 468 */
        const uint8_t l_1038 = 255UL;
        uint16_t *l_1044 = &g_63;
        uint16_t **l_1046[5];
        uint32_t ***l_1062[2][5][7] = {{{(void*)0,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,(void*)0},{&l_1060,&l_1060,&l_1060,&l_1060,(void*)0,(void*)0,&l_1060},{(void*)0,&l_1060,(void*)0,(void*)0,&l_1060,&l_1060,&l_1060},{&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,(void*)0,(void*)0},{&l_1060,(void*)0,&l_1060,&l_1060,&l_1060,&l_1060,(void*)0}},{{(void*)0,&l_1060,&l_1060,&l_1060,&l_1060,(void*)0,(void*)0},{&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060},{&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060},{&l_1060,&l_1060,&l_1060,&l_1060,(void*)0,(void*)0,&l_1060},{(void*)0,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060,&l_1060}}};
        uint32_t ***l_1065 = (void*)0;
        int32_t l_1072 = 0x951B4C9CL;
        int32_t l_1076 = (-1L);
        uint64_t *l_1116 = (void*)0;
        int64_t *l_1170 = &g_581;
        uint32_t *l_1185 = &g_266;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_1046[i] = &g_149;
        l_1050[1][1][2] |= ((l_1037 || (l_1038 > (safe_sub_func_int16_t_s_s((((((((safe_mod_func_int64_t_s_s(((~((void*)0 != &g_605)) , ((l_1044 != (l_1045 = l_1045)) , (safe_mul_func_int8_t_s_s(((***g_845) &= l_1038), 0UL)))), (~l_1038))) >= l_1038) <= l_1038) || (-7L)) && l_1038) , l_1037) <= 3UL), l_1038)))) , 0xF63691DCL);
        if (l_1038)
        { /* block id: 472 */
            uint32_t ****l_1061[3][7][3] = {{{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0}},{{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059}},{{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0},{&l_1059,&l_1059,&l_1059},{&l_1059,&l_1059,(void*)0}}};
            int16_t *l_1075 = &g_293;
            int32_t *l_1077 = (void*)0;
            int32_t l_1086[6];
            int32_t l_1087 = 0xB7D5FF30L;
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_1086[i] = 0x1BB58B88L;
            (*g_1078) ^= (safe_div_func_uint16_t_u_u((((safe_add_func_uint16_t_u_u((safe_div_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(65530UL, (((l_1062[1][1][5] = l_1059) == (l_1065 = g_1063[0][3])) >= (safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u(l_1038, (*g_585))) < 0L), 9))))), 0x38L)), (l_1072 = ((*l_1044)++)))) >= ((l_1076 = (safe_div_func_uint8_t_u_u((0xBBF7FAFDL && ((((l_1037 & l_1038) , l_1075) != l_1045) , 1UL)), 0x1AL))) , (*g_788))) && (*g_585)), 0xC7AEL));
            for (g_581 = 0; (g_581 >= 0); g_581 -= 1)
            { /* block id: 481 */
                int i;
                g_119[(g_581 + 5)] = (safe_mul_func_uint8_t_u_u((*g_950), 249UL));
                for (g_150 = 0; (g_150 <= 0); g_150 += 1)
                { /* block id: 485 */
                    if (g_119[(g_581 + 5)])
                        break;
                }
                for (g_293 = 0; (g_293 <= 0); g_293 += 1)
                { /* block id: 490 */
                    if (g_119[(g_581 + 5)])
                    { /* block id: 491 */
                        uint32_t l_1081 = 0x45A9286CL;
                        if (l_1081)
                            break;
                    }
                    else
                    { /* block id: 493 */
                        int32_t *l_1084 = &l_1050[4][0][1];
                        (*l_1084) &= (safe_rshift_func_uint16_t_u_u(l_1038, 10));
                    }
                    for (g_151 = 0; (g_151 <= 0); g_151 += 1)
                    { /* block id: 498 */
                        int32_t *l_1085 = &g_496[0][1];
                        (*l_1085) = ((*g_950) && l_1037);
                        (*g_64) = (*g_64);
                    }
                    l_1087 = (l_1086[0] ^= 0x9600E727L);
                }
            }
        }
        else
        { /* block id: 506 */
            int32_t *l_1088 = (void*)0;
            (*g_155) = l_1088;
            return p_21;
        }
        if (((((((*g_847) ^= (safe_sub_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u(((void*)0 == &g_784), (p_20 == ((*g_711) = p_19)))), (*p_22)))) != ((+l_1050[0][0][0]) | (safe_lshift_func_int8_t_s_u(((((safe_div_func_int32_t_s_s((safe_rshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(0x733AE8D01E076BEBLL, ((*g_585) &= 7UL))), (safe_mod_func_uint32_t_u_u(((0xF51AL || 3UL) & l_1038), 0xD6A6DF7DL)))), 7)), 0x27DDCEB5L)) , l_1037) >= 0xCB4DE7A6L) ^ 0xF4L), 2)))) > l_1072) , 0x15L) > l_1076))
        { /* block id: 513 */
            uint32_t l_1106 = 4294967290UL;
            --l_1106;
            l_1037 = (l_1106 >= (*g_585));
        }
        else
        { /* block id: 516 */
            int16_t *l_1113 = &g_218[7];
            uint64_t *l_1114 = &g_390[2];
            uint64_t **l_1115 = &l_1114;
            int16_t *l_1117 = &g_752[2][2];
            const int32_t l_1122 = 0x42E346B6L;
            int32_t l_1130 = 0x51AEBF5EL;
            uint64_t l_1167 = 0xB6757012527A2B41LL;
            if ((safe_lshift_func_uint8_t_u_u((safe_add_func_int32_t_s_s(((*g_950) , (*p_22)), (((((*l_1113) = 0xFBE4L) , (((*l_1115) = l_1114) == &g_784)) , l_1116) == (void*)0))), (((*l_1117) = 4L) < (l_1050[0][0][0] > 1UL)))))
            { /* block id: 520 */
                for (l_1072 = 0; (l_1072 == 9); l_1072 = safe_add_func_int32_t_s_s(l_1072, 8))
                { /* block id: 523 */
                    uint32_t l_1123 = 0x8AC69AEEL;
                    int32_t ***l_1125 = (void*)0;
                    int32_t ***l_1126 = &g_155;
                    uint32_t **l_1129 = &g_181;
                    l_1123 &= (safe_sub_func_uint8_t_u_u(l_1122, l_1122));
                    l_1130 ^= ((*g_1078) = (l_1050[1][1][2] == ((((*l_1126) = l_1124) == &p_21) & (safe_lshift_func_uint8_t_u_s((l_1129 == (void*)0), 6)))));
                }
            }
            else
            { /* block id: 529 */
                uint32_t l_1134 = 4294967288UL;
                int32_t l_1143 = 5L;
                int32_t l_1145 = 0x1996FB79L;
                uint32_t l_1155 = 0UL;
                if ((*p_20))
                    break;
                for (g_63 = 25; (g_63 <= 37); ++g_63)
                { /* block id: 533 */
                    volatile int32_t *l_1133 = &g_71[2][3];
                    int32_t l_1137 = (-8L);
                    uint64_t **l_1144 = (void*)0;
                    l_1133 = (*g_64);
                    for (g_293 = 1; (g_293 >= 0); g_293 -= 1)
                    { /* block id: 537 */
                        int i, j, k;
                        g_69[(g_293 + 7)][(g_293 + 2)][g_293] = ((((*g_711) = ((--l_1134) , (((g_294[g_293] , ((g_294[g_293] >= (((l_1137 , ((((safe_lshift_func_uint16_t_u_s(((l_1143 = (&g_585 == l_1142[0])) ^ ((((void*)0 == l_1144) || l_1145) < l_1122)), 6)) ^ (*g_950)) | l_1137) || (*g_950))) > 0L) <= 0xFBEBE3660FB72D19LL)) == 0x0A6CCAC9L)) >= 0x36A7L) , (void*)0))) != p_22) != 0xD48F409EL);
                        if ((*g_3))
                            break;
                    }
                    for (g_293 = 0; (g_293 < (-4)); g_293--)
                    { /* block id: 546 */
                        int16_t l_1154[3];
                        int32_t *l_1165[7][6] = {{&g_483[0],&g_767[2],&g_483[0],(void*)0,&g_496[8][0],(void*)0},{&g_483[0],&g_4[6][2][0],&g_483[0],&g_4[5][2][2],&g_496[8][0],&g_4[1][0][2]},{&g_483[0],&g_767[2],&g_483[0],(void*)0,(void*)0,&g_483[0]},{&g_4[5][2][2],&g_4[5][2][2],&g_767[0],(void*)0,&g_4[1][0][2],&g_483[0]},{&g_4[6][2][0],&g_767[0],&g_483[0],&g_483[0],&g_483[0],&g_767[0]},{(void*)0,&g_4[6][2][0],&g_483[0],(void*)0,&g_4[5][2][2],&g_483[0]},{&g_483[0],(void*)0,&g_767[0],&g_767[0],(void*)0,&g_483[0]}};
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_1154[i] = (-7L);
                        l_1143 ^= (safe_rshift_func_uint16_t_u_u((((**l_1115)++) != (((safe_div_func_uint32_t_u_u((((((((*l_1113) |= (((*l_1117) = l_1154[0]) | (l_1155 | 0x64L))) || (--(*l_1045))) == 4294967292UL) && ((((safe_div_func_int8_t_s_s((((((g_1162[1] = l_1142[0]) == &g_585) | (0xF49BL <= ((safe_mul_func_uint8_t_u_u(((((((l_1130 & l_1130) & l_1155) || 0x21L) | 0x13L) ^ l_1122) , 0x7EL), 0xA6L)) < l_1145))) | l_1130) == l_1155), l_1154[0])) , 1L) , 0xEDCAF75FL) && l_1122)) , 3UL) | (***g_845)), (*p_20))) & l_1122) != (*p_22))), l_1137));
                        l_1130 = l_1038;
                    }
                    if (l_1038)
                        break;
                }
            }
            for (l_1037 = 6; (l_1037 >= 1); l_1037 -= 1)
            { /* block id: 560 */
                int32_t *l_1166 = &g_767[2];
                ++l_1167;
            }
        }
        l_1050[8][1][2] = (((((*l_1170) = 0x7F558EDCB16DE454LL) == (l_1171[1][4] == (void*)0)) ^ (*p_22)) & (safe_mul_func_uint8_t_u_u(((*g_950) ^ (safe_unary_minus_func_uint16_t_u(0x34AEL))), (l_1076 , (safe_rshift_func_int16_t_s_s(((((l_1186 = (((*l_1185) ^= (l_1184 = ((safe_rshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s(((safe_div_func_int16_t_s_s((1L && l_1076), g_211[5][0][0])) >= l_1076), 0x6E65L)), (*g_950))) != 0x51D2F17AL))) , l_1076)) && l_1076) < l_1037) || (-5L)), 11))))));
    }
    l_1197 = ((*l_1124) = &g_4[6][0][2]);
    (*g_1078) &= (*p_20);
    (*g_1199) = ((*g_155) = g_1198[1][1][6]);
    return (*g_1199);
}


/* ------------------------------------------ */
/* 
 * reads : g_151 g_585 g_147 g_483 g_4 g_767 g_680 g_344 g_390 g_784 g_496 g_226 g_293 g_787 g_155 g_182 g_265 g_274 g_752 g_218 g_788 g_711 g_64 g_65 g_387 g_259 g_156 g_847 g_950 g_220 g_268
 * writes: g_151 g_390 g_483 g_605 g_496 g_226 g_293 g_787 g_156 g_182 g_211 g_752 g_712 g_387 g_950 g_784 g_215 g_265 g_147 g_263 g_268 g_767 g_223 g_65
 */
static int16_t  func_25(int32_t  p_26, uint64_t  p_27, uint32_t  p_28, int32_t * p_29)
{ /* block id: 318 */
    int32_t l_758 = 1L;
    uint8_t *l_759 = (void*)0;
    uint8_t *l_760 = &g_151;
    const int16_t l_764 = 0x0E19L;
    int32_t *l_765 = &g_483[0];
    uint64_t l_766 = 3UL;
    int64_t *l_780 = &g_211[5][0][1];
    int16_t l_783 = 1L;
    uint8_t l_798[8][9][3] = {{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L},{0x18L,0xD3L,0x89L},{0UL,0UL,0x89L},{0xD3L,0x18L,0x89L}},{{0x18L,0xD3L,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL},{0x48L,0UL,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL},{0x48L,0UL,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL}},{{0x48L,0UL,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL},{0x48L,0UL,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL},{0x48L,0UL,0UL},{0x92L,0x92L,0UL},{0UL,0x48L,0UL}}};
    int32_t l_803 = 0x49E455D2L;
    int32_t l_804 = 8L;
    int32_t l_805[6][8] = {{0x4C0BF29EL,1L,0xF3B00255L,1L,0x4C0BF29EL,(-4L),0x4C0BF29EL,1L},{1L,1L,1L,0x1B2EC443L,0x4C0BF29EL,0x1B2EC443L,1L,1L},{0x4C0BF29EL,0x1B2EC443L,1L,1L,1L,0x1B2EC443L,0x4C0BF29EL,0x1B2EC443L},{0x4C0BF29EL,1L,0xF3B00255L,1L,0x4C0BF29EL,(-4L),0x4C0BF29EL,1L},{1L,1L,1L,0x1B2EC443L,0x4C0BF29EL,0x1B2EC443L,1L,1L},{0x4C0BF29EL,0x1B2EC443L,1L,1L,1L,0x1B2EC443L,0x4C0BF29EL,0x1B2EC443L}};
    uint64_t l_806 = 0x71ECBAC37F5CAC3BLL;
    uint16_t l_809[5][10][5] = {{{0x23FCL,0x23C1L,0xC276L,0x8270L,0x8270L},{65531UL,0UL,65531UL,0x1B44L,0xE9C1L},{0UL,0x8270L,0x23C1L,0x32A1L,0x32F2L},{0xE9C1L,0x8B4DL,65527UL,65527UL,0x8B4DL},{0xC276L,0x88A8L,0x23C1L,0x32F2L,65526UL},{0UL,8UL,65531UL,1UL,1UL},{0xC8D6L,0xC276L,0xC276L,0xC8D6L,0x3E78L},{0UL,65527UL,0UL,65534UL,1UL},{0xC276L,0x271AL,0xFE5EL,0x23C1L,0xFE5EL},{0xE9C1L,0xE9C1L,1UL,65534UL,0UL}},{{0UL,0x32A1L,0x3E78L,0xC8D6L,0xC276L},{65531UL,1UL,1UL,1UL,65531UL},{0x23FCL,0x32A1L,65526UL,0x32F2L,0x23C1L},{65534UL,0xE9C1L,0x8B4DL,65527UL,65527UL},{0x32F2L,0x271AL,0x32F2L,0x32A1L,0x23C1L},{0xF60CL,65527UL,0xE9C1L,0x1B44L,65531UL},{0x23C1L,0xC276L,0x8270L,0x8270L,0xC276L},{0x8B4DL,8UL,0xE9C1L,65531UL,0UL},{0x271AL,65526UL,0x8270L,0x271AL,0UL},{0xE9C1L,1UL,1UL,0xE9C1L,0UL}},{{0x23FCL,0xC276L,0xFE5EL,0x32A1L,0x271AL},{1UL,65534UL,0xF60CL,1UL,0xF60CL},{0x3E78L,0x3E78L,0x271AL,0x32A1L,0xFE5EL},{65531UL,8UL,0UL,0xE9C1L,1UL},{0x8270L,0x271AL,0UL,0x271AL,0x8270L},{0x1B44L,8UL,1UL,65527UL,1UL},{0x32A1L,0x3E78L,0xC8D6L,0xC276L,0xC276L},{65527UL,65534UL,65527UL,8UL,1UL},{0x32F2L,0xC276L,0x3E78L,0x88A8L,0x8270L},{1UL,1UL,0x8B4DL,0x8B4DL,1UL}},{{0xC8D6L,65526UL,0x3E78L,0x8270L,0xFE5EL},{65534UL,0UL,65527UL,0UL,0xF60CL},{0x23C1L,0xC8D6L,0xC8D6L,0x23C1L,0x271AL},{65534UL,0x8B4DL,1UL,0x1B44L,0UL},{0xC8D6L,0x23FCL,0UL,0x3E78L,0UL},{1UL,1UL,0UL,0x1B44L,1UL},{0x32F2L,0x88A8L,0x271AL,0x23C1L,0xC8D6L},{65527UL,0UL,0xF60CL,0UL,65527UL},{0x32A1L,0x88A8L,0xFE5EL,0x8270L,0x3E78L},{0x1B44L,1UL,1UL,0x8B4DL,0x8B4DL}},{{0x8270L,0x23FCL,0x8270L,0x88A8L,0x3E78L},{65531UL,0x8B4DL,1UL,8UL,65527UL},{0x3E78L,0xC8D6L,0xC276L,0xC276L,0xC8D6L},{1UL,0UL,1UL,65527UL,1UL},{0x23FCL,65526UL,0x8270L,0x271AL,0UL},{0xE9C1L,1UL,1UL,0xE9C1L,0UL},{0x23FCL,0xC276L,0xFE5EL,0x32A1L,0x271AL},{1UL,65534UL,0xF60CL,1UL,0xF60CL},{0x3E78L,0x3E78L,0x271AL,0x32A1L,0xFE5EL},{65531UL,8UL,0UL,0xE9C1L,1UL}}};
    int8_t **l_901 = &g_847;
    const int32_t l_916 = 0L;
    uint32_t l_1004[10] = {0xAF02B46FL,0xC35B477CL,0xAF02B46FL,1UL,1UL,0xAF02B46FL,0xC35B477CL,0xAF02B46FL,1UL,1UL};
    const int64_t ***l_1014 = (void*)0;
    const int64_t *l_1017[10][8] = {{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0},{&g_1018,&g_1018,&g_1018,(void*)0,&g_1018,&g_1018,&g_1018,(void*)0}};
    const int64_t **l_1016[2];
    const int64_t ***l_1015 = &l_1016[1];
    int32_t l_1029[4] = {0L,0L,0L,0L};
    const int64_t l_1030 = 0x702773F06EA8E8F4LL;
    int32_t *l_1031[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int16_t *l_1032 = &g_223[0][2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1016[i] = &l_1017[7][7];
    if ((safe_add_func_uint64_t_u_u(0xD32B82C3DC35C32BLL, (((safe_sub_func_uint16_t_u_u(l_758, (((*l_760) ^= l_758) && (safe_mul_func_int8_t_s_s(l_758, p_27))))) < ((((*g_585) = l_758) < l_758) & (((safe_unary_minus_func_uint32_t_u(((l_758 > (((*l_765) |= ((0x05L == g_147) || l_764)) > 4294967294UL)) & g_4[6][2][0]))) && (*l_765)) <= l_766))) > p_26))))
    { /* block id: 322 */
        const int32_t l_790 = (-1L);
        uint32_t **l_794 = &g_181;
        int32_t l_801 = 3L;
        int32_t *l_802[2];
        int i;
        for (i = 0; i < 2; i++)
            l_802[i] = &l_801;
        for (l_758 = 0; (l_758 <= 1); l_758 += 1)
        { /* block id: 325 */
            uint16_t l_777 = 0x59D6L;
            int32_t l_785 = 0xF18D57EBL;
            int32_t *l_786 = &g_496[8][0];
            (*l_786) &= (((*l_765) = g_767[2]) || (p_28 != (safe_rshift_func_uint16_t_u_s((((*l_765) < (safe_lshift_func_uint16_t_u_u(((l_785 = ((~(safe_div_func_uint32_t_u_u(0xDACD6EA4L, p_27))) < (safe_mod_func_int16_t_s_s((l_777 || (((safe_mod_func_int16_t_s_s(((((((*g_680) = l_780) == l_780) , (safe_lshift_func_uint16_t_u_u(l_783, 6))) || g_344[1][0][1]) <= l_777), p_28)) <= g_390[5]) , g_784)), (*l_765))))) ^ 250UL), l_777))) , (*l_765)), 4))));
            for (g_226 = 0; (g_226 <= 1); g_226 += 1)
            { /* block id: 332 */
                uint32_t **l_796 = (void*)0;
                for (g_293 = 1; (g_293 >= 0); g_293 -= 1)
                { /* block id: 335 */
                    const uint32_t ***l_789 = &g_787;
                    int i, j, k;
                    (*l_786) ^= ((g_344[l_758][g_293][(g_293 + 5)] <= g_344[l_758][g_293][(g_293 + 5)]) , (((*l_789) = g_787) != (void*)0));
                }
                if ((*l_765))
                { /* block id: 339 */
                    (*l_765) ^= l_790;
                }
                else
                { /* block id: 341 */
                    const uint32_t l_797[2] = {7UL,7UL};
                    int i;
                    for (p_27 = 0; (p_27 <= 8); p_27 += 1)
                    { /* block id: 344 */
                        (*g_155) = (void*)0;
                        (*g_155) = p_29;
                        p_29 = (void*)0;
                    }
                    for (g_182 = 0; (g_182 <= 8); g_182 += 1)
                    { /* block id: 351 */
                        uint64_t *l_793 = &g_390[6];
                        uint32_t ***l_795 = &l_794;
                        (*g_155) = (void*)0;
                        (*l_786) = (0x0B30L | (l_793 != &p_27));
                        if (p_27)
                            continue;
                        (*l_765) = (((*l_795) = l_794) == l_796);
                    }
                    if (l_797[1])
                        continue;
                }
                l_798[4][7][2]--;
            }
        }
        l_806++;
        ++l_809[4][4][4];
        for (p_28 = 2; (p_28 <= 7); p_28 += 1)
        { /* block id: 367 */
            int i;
            (*g_155) = (void*)0;
            if (g_265[p_28])
                continue;
        }
    }
    else
    { /* block id: 371 */
        int16_t *l_815[3];
        const uint32_t l_831 = 4294967295UL;
        uint32_t **l_864 = (void*)0;
        uint32_t ***l_863 = &l_864;
        int32_t l_865 = 0L;
        int32_t l_892 = (-1L);
        uint32_t l_959 = 6UL;
        uint32_t l_981 = 1UL;
        int32_t l_1005 = (-1L);
        int i;
        for (i = 0; i < 3; i++)
            l_815[i] = &l_783;
        for (p_26 = 0; (p_26 <= 8); p_26 += 1)
        { /* block id: 374 */
            int16_t l_812[5][7] = {{0x8841L,0x8841L,2L,(-1L),2L,0x8841L,0x8841L},{0x8841L,2L,(-1L),2L,0x8841L,0x8841L,2L},{8L,0xAA3DL,8L,2L,2L,8L,0xAA3DL},{2L,0xAA3DL,(-1L),(-1L),0xAA3DL,2L,0xAA3DL},{8L,2L,2L,8L,0xAA3DL,8L,2L}};
            uint16_t **l_826 = &g_149;
            uint32_t *l_829 = (void*)0;
            uint32_t *l_830 = &g_182;
            int16_t l_838 = (-7L);
            int32_t **l_887 = &g_156;
            int32_t l_934[6] = {(-1L),0x69B6A34BL,(-1L),(-1L),0x69B6A34BL,(-1L)};
            int8_t *l_943 = &g_147;
            int i, j;
            if (l_812[4][2])
                break;
            if ((safe_sub_func_int64_t_s_s(1L, ((*l_780) = (((l_815[2] == (void*)0) && ((safe_mul_func_int8_t_s_s(((((safe_mod_func_uint64_t_u_u(((g_274[4][0][2] , (safe_mod_func_uint8_t_u_u(l_812[4][2], (safe_add_func_int64_t_s_s((safe_div_func_uint32_t_u_u(((*l_830) |= ((&g_149 == l_826) == ((safe_add_func_uint8_t_u_u(((((void*)0 != l_815[1]) == 0UL) , g_752[2][2]), l_812[0][2])) , l_812[2][1]))), 1L)), (*g_585)))))) ^ l_831), g_218[0])) < l_831) , (void*)0) == &g_585), 255UL)) || p_28)) >= 0xD3D8L)))))
            { /* block id: 378 */
                uint16_t *l_834 = &g_150;
                int32_t l_837 = 0x555105B7L;
                uint32_t *l_859[5] = {&g_194,&g_194,&g_194,&g_194,&g_194};
                int8_t **l_929 = &g_847;
                uint8_t *l_949 = &g_220;
                int8_t l_969[1];
                int i;
                for (i = 0; i < 1; i++)
                    l_969[i] = (-7L);
                if (((((*l_765) = ((p_28 , (safe_add_func_int8_t_s_s(l_831, (l_834 == (((safe_mod_func_uint16_t_u_u(p_26, p_28)) >= ((*g_788) < ((g_752[2][2] |= l_837) > 0xEA45L))) , (l_837 , &g_63)))))) , l_838)) & 0x6CC1F9BAL) > l_837))
                { /* block id: 381 */
                    int32_t *l_860 = &g_496[8][0];
                    int64_t l_868 = (-1L);
                    int i;
                    if ((safe_mul_func_int8_t_s_s(0x8DL, ((l_859[1] = &g_167) != &p_28))))
                    { /* block id: 385 */
                        int64_t *l_870 = (void*)0;
                        int64_t **l_869 = &l_870;
                        (*g_155) = l_860;
                        l_837 &= (((*g_711) = p_29) == (((((*g_680) = l_780) != ((*l_869) = (((safe_sub_func_uint32_t_u_u(((l_865 |= ((void*)0 != l_863)) < (((*g_64) == ((((0xA2B4L | (safe_sub_func_int8_t_s_s(l_868, 0x89L))) <= p_28) == p_26) , (void*)0)) != p_28)), (*l_765))) != p_26) , (void*)0))) > 0x8F5FL) , (void*)0));
                    }
                    else
                    { /* block id: 392 */
                        int64_t l_877 = 0xDC5D2865A4B2F142LL;
                        int64_t *l_878 = &l_868;
                        int32_t l_881 = (-6L);
                        int i;
                        (*g_155) = &l_865;
                    }
                    if ((l_837 != ((-7L) != (!(safe_sub_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_u(((l_865 = ((((*l_765) , &p_29) == l_887) | 0x7E80950FL)) >= (safe_add_func_int8_t_s_s(((p_28 != ((*g_585) = (g_387[p_26]++))) ^ (l_892 = p_26)), ((((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((l_837 >= p_28) | (*l_765)), p_28)), 0UL)) ^ 0xE96DFE83L) & 0x80BAL) && p_26)))), p_27)) != p_27), g_259[0]))))))
                    { /* block id: 404 */
                        (*g_156) &= (safe_sub_func_int32_t_s_s((safe_mul_func_uint8_t_u_u((l_901 == (void*)0), 0x22L)), (safe_lshift_func_uint8_t_u_s((safe_sub_func_uint64_t_u_u(p_27, p_26)), 3))));
                    }
                    else
                    { /* block id: 406 */
                        (*l_887) = ((g_259[0] >= ((safe_mod_func_uint16_t_u_u(((-1L) ^ 0L), ((safe_lshift_func_uint8_t_u_s((safe_mod_func_uint32_t_u_u((((((**l_887) == (safe_rshift_func_int16_t_s_s(p_27, (*l_765)))) ^ l_916) || 1UL) & (safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(p_27, 0x8D6AL)), 0L))), p_26)), 1)) ^ (*g_788)))) || (*l_860))) , (void*)0);
                        (*l_860) &= (l_865 = ((safe_rshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((*l_765), 1UL)), 5)) >= (safe_lshift_func_uint8_t_u_s(g_344[1][0][1], ((safe_lshift_func_uint16_t_u_u((l_929 != &g_847), 8)) || 0xB681C7BCBCAEE780LL)))));
                        (*l_765) ^= l_865;
                        if ((*l_765))
                            continue;
                    }
                }
                else
                { /* block id: 413 */
                    uint8_t l_930 = 255UL;
                    uint64_t *l_982 = &g_784;
                    for (g_151 = 0; (g_151 <= 6); g_151 += 1)
                    { /* block id: 416 */
                        int32_t *l_933[10] = {&g_767[2],&l_803,&l_803,&g_767[2],&l_803,&l_803,&g_767[2],&l_803,&l_803,&g_767[2]};
                        int16_t l_935 = (-6L);
                        int i;
                        --l_930;
                        if (l_831)
                            break;
                        l_934[1] = ((*l_765) ^= l_930);
                        l_935 = l_837;
                    }
                    for (l_803 = 6; (l_803 >= 0); l_803 -= 1)
                    { /* block id: 425 */
                        uint32_t l_936 = 1UL;
                        (*l_765) ^= (((l_936 ^ (safe_mul_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((((safe_add_func_uint8_t_u_u((((*g_847) ^ (((((l_943 != ((((((safe_mod_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((!p_27) , ((g_950 = l_949) != (void*)0)), (p_27 || (safe_add_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s(0x4925L, ((safe_lshift_func_int8_t_s_u(((safe_div_func_uint16_t_u_u(g_387[2], p_28)) , p_26), 3)) != l_837))), (*g_788)))))), l_831)) <= (*g_847)) || p_26) , (void*)0) != (void*)0) , (void*)0)) , (*g_847)) > 0x32L) ^ l_930) , p_26)) , p_28), l_936)) || l_930) , l_930), l_959)), p_26))) , p_26) | (-1L));
                    }
                    (*l_765) = (safe_rshift_func_int8_t_s_u(((((p_28 >= ((((~(((((*l_982) |= (((safe_mod_func_int64_t_s_s(0xB7C92BD70282FD03LL, (*l_765))) == (safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((l_969[0] & (safe_mod_func_int16_t_s_s(((l_981 |= ((safe_mod_func_int64_t_s_s((-10L), ((safe_mul_func_int8_t_s_s(0xEEL, 0x0CL)) && ((safe_div_func_int32_t_s_s((((((safe_add_func_int16_t_s_s((~p_27), ((0UL == (-1L)) || 0xC66916355191AE65LL))) == p_28) == p_26) , 0x3FL) > (*g_950)), p_28)) & l_969[0])))) & 0x557A6563L)) <= 0xF28E672DL), 0x0581L))), p_28)), 8UL))) | (*g_585))) | (*g_585)) <= l_969[0]) >= l_930)) || p_27) <= p_26) <= l_831)) < l_930) , p_29) == &l_959), p_28));
                    for (g_215 = 0; (g_215 <= 6); g_215 += 1)
                    { /* block id: 434 */
                        return (*l_765);
                    }
                }
            }
            else
            { /* block id: 438 */
                uint32_t l_989 = 0xB7B92AE4L;
                int32_t l_1007 = (-9L);
                l_865 = ((safe_sub_func_uint16_t_u_u((((safe_add_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_u(l_989, 11)) >= p_28), (((safe_lshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_s((((**l_901) |= ((l_892 |= (safe_lshift_func_uint8_t_u_s((*g_950), (l_989 , p_28)))) ^ p_27)) >= ((safe_sub_func_int8_t_s_s(((*l_943) = ((safe_add_func_int64_t_s_s((safe_rshift_func_int16_t_s_s((*l_765), 13)), (((*l_765) & ((((p_26 & p_27) || 0x70L) , 18446744073709551612UL) , 0UL)) , (*l_765)))) | (*l_765))), (*g_950))) != l_1004[8])), 4)), p_27)) != 0x50221BEAL) < (*g_585)))) | 18446744073709551615UL) < l_959), p_28)) != l_1005);
                for (g_263 = 0; (g_263 <= 6); g_263 += 1)
                { /* block id: 445 */
                    uint64_t l_1006 = 0x5A4A4F4086A4A578LL;
                    l_1007 = l_1006;
                }
                (*l_765) &= (0x6E8AL & 1L);
            }
            return p_28;
        }
    }
    g_496[8][0] = (safe_sub_func_int8_t_s_s(p_28, (((((*l_765) = (p_27 ^ p_28)) == (((*l_1032) = ((((g_767[2] = ((p_28 ^ ((((safe_rshift_func_int8_t_s_u((safe_mod_func_int16_t_s_s((((*g_950) = ((*l_760) = (&g_605 != ((*l_1015) = (void*)0)))) > ((*g_847) |= (safe_add_func_int64_t_s_s(((((((safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u(p_27, ((((safe_lshift_func_int8_t_s_u((((void*)0 != &g_390[3]) ^ 248UL), p_26)) ^ p_28) & l_1029[1]) , l_809[4][9][4]))), p_28)), p_26)) , 1L) , 0x74F16738L) != 1UL) == 0xAB7E0A10409DC9C5LL) , l_1030), (*g_585))))), l_804)), p_27)) | l_798[2][5][1]) != (*g_585)) >= p_26)) <= (-6L))) > 9UL) , (*g_847)) <= 0x9AL)) != p_26)) >= p_26) , (*g_950))));
    (*l_765) = (-2L);
    (*g_64) = (void*)0;
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_64 g_155 g_63 g_151 g_150 g_65 g_156 g_53 g_167 g_182 g_194 g_147 g_226 g_215 g_266 g_268 g_274 g_218 g_294 g_225 g_223 g_344 g_211 g_293 g_265 g_259 g_483 g_496 g_390 g_220 g_387 g_149
 * writes: g_53 g_63 g_147 g_149 g_151 g_150 g_65 g_156 g_167 g_181 g_182 g_194 g_211 g_215 g_218 g_220 g_226 g_259 g_263 g_265 g_268 g_266 g_274 g_294 g_223 g_344 g_387 g_390 g_483 g_496 g_225 g_526
 */
static int16_t  func_32(int32_t  p_33)
{ /* block id: 2 */
    int8_t l_34[4] = {0xB0L,0xB0L,0xB0L,0xB0L};
    int32_t *l_37 = &g_4[0][2][0];
    int32_t l_538 = 0xDEA721B8L;
    int32_t l_566[4] = {(-1L),(-1L),(-1L),(-1L)};
    uint64_t *l_582 = &g_390[3];
    uint8_t l_608 = 0xF9L;
    int16_t l_701 = (-6L);
    int64_t l_710[6][1][3] = {{{(-6L),0xF247815F7C07A493LL,(-6L)}},{{(-1L),0x8A6764E20A385111LL,0x8D16F8632EEC7FD2LL}},{{(-1L),(-1L),0x8A6764E20A385111LL}},{{(-6L),0x8A6764E20A385111LL,0x8A6764E20A385111LL}},{{0x8A6764E20A385111LL,0xF247815F7C07A493LL,0x8D16F8632EEC7FD2LL}},{{(-6L),0xF247815F7C07A493LL,(-6L)}}};
    int i, j, k;
    if (((g_4[6][2][0] | l_34[1]) != p_33))
    { /* block id: 3 */
        int32_t *l_529 = (void*)0;
        uint32_t l_551 = 1UL;
        (*g_155) = func_35(l_37);
        for (g_226 = (-19); (g_226 >= 42); ++g_226)
        { /* block id: 200 */
            uint16_t *l_544 = (void*)0;
            int32_t l_549 = 0x56886CA4L;
            (*g_155) = l_529;
            for (g_215 = 0; (g_215 != 56); ++g_215)
            { /* block id: 204 */
                uint8_t l_545 = 255UL;
                int32_t l_546 = 0xDDCB5836L;
                uint64_t *l_547 = &g_387[7];
                uint64_t *l_548 = (void*)0;
                uint16_t *l_550 = &g_294[0];
                int32_t *l_552 = &g_483[0];
                (*l_552) &= (p_33 , ((safe_rshift_func_uint8_t_u_s((((void*)0 != &g_223[0][5]) == ((((((*l_550) = ((((((safe_add_func_int64_t_s_s((safe_div_func_int8_t_s_s(l_538, (safe_unary_minus_func_uint64_t_u((g_390[7] = ((*l_547) |= (((safe_mod_func_uint16_t_u_u((p_33 <= g_294[1]), (safe_rshift_func_uint16_t_u_s((l_545 = ((l_544 != (void*)0) && 0x09BE04A1L)), l_546)))) == 1L) == g_223[0][3]))))))), 0xF09C4CCF5B08C5ABLL)) != 0UL) <= (*l_37)) >= l_549) , g_211[5][0][1]) >= l_549)) && 0xCEBFL) , 0UL) , l_551) && g_218[1])), g_496[7][0])) | p_33));
            }
        }
    }
    else
    { /* block id: 212 */
        l_538 = (0xFE48L <= (((+p_33) ^ p_33) & (*g_149)));
    }
    for (g_147 = 0; (g_147 == (-8)); --g_147)
    { /* block id: 217 */
        return p_33;
    }
    for (g_220 = 1; (g_220 <= 8); g_220 += 1)
    { /* block id: 222 */
        int32_t l_560[7] = {0x06BDCF93L,0x06BDCF93L,0x06BDCF93L,0x06BDCF93L,0x06BDCF93L,0x06BDCF93L,0x06BDCF93L};
        int32_t *l_570 = &l_560[0];
        uint8_t l_575[8];
        uint64_t *l_602 = &g_390[3];
        int8_t *l_606 = &g_265[1];
        uint64_t l_677 = 0xFD211C9E42BA7C31LL;
        int8_t l_692 = 6L;
        uint64_t l_697 = 18446744073709551609UL;
        int64_t ***l_718 = (void*)0;
        const uint8_t l_744 = 0xE6L;
        int i;
        for (i = 0; i < 8; i++)
            l_575[i] = 0xB3L;
    }
    return g_344[1][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_64 g_155 g_63 g_151 g_150 g_65 g_156 g_53 g_167 g_182 g_194 g_147 g_226 g_215 g_266 g_268 g_274 g_218 g_294 g_225 g_223 g_344 g_211 g_293 g_265 g_259 g_483 g_496 g_390 g_220
 * writes: g_53 g_63 g_147 g_149 g_151 g_150 g_65 g_156 g_167 g_181 g_182 g_194 g_211 g_215 g_218 g_220 g_226 g_259 g_263 g_265 g_268 g_266 g_274 g_294 g_223 g_344 g_387 g_390 g_483 g_496 g_225 g_526
 */
static int32_t * func_35(int32_t * p_36)
{ /* block id: 4 */
    int32_t * const *l_41 = (void*)0;
    int32_t * const **l_525[10] = {&l_41,&l_41,&l_41,&l_41,&l_41,&l_41,&l_41,&l_41,&l_41,&l_41};
    int i;
    g_526 = func_38(g_4[8][2][1], l_41);
    return p_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_4 g_155 g_63 g_151 g_150 g_65 g_156 g_53 g_167 g_182 g_194 g_147 g_226 g_215 g_266 g_268 g_274 g_218 g_294 g_225 g_223 g_344 g_211 g_293 g_265 g_259 g_483 g_496 g_390 g_220
 * writes: g_53 g_63 g_147 g_149 g_151 g_150 g_65 g_156 g_167 g_181 g_182 g_194 g_211 g_215 g_218 g_220 g_226 g_259 g_263 g_265 g_268 g_266 g_274 g_294 g_223 g_344 g_387 g_390 g_483 g_496 g_225
 */
static int32_t * const * func_38(uint64_t  p_39, int32_t * const * p_40)
{ /* block id: 5 */
    int8_t l_45 = 1L;
    int32_t *l_52 = &g_4[6][2][0];
    int32_t **l_51 = &l_52;
    uint16_t *l_62[9][4][1] = {{{(void*)0},{&g_63},{(void*)0},{&g_63}},{{(void*)0},{&g_63},{&g_63},{&g_63}},{{(void*)0},{(void*)0},{(void*)0},{(void*)0}},{{&g_63},{&g_63},{&g_63},{(void*)0}},{{&g_63},{(void*)0},{&g_63},{(void*)0}},{{&g_63},{&g_63},{&g_63},{&g_63}},{{(void*)0},{(void*)0},{&g_63},{&g_63}},{{(void*)0},{&g_63},{(void*)0},{(void*)0}},{{&g_63},{(void*)0},{(void*)0},{&g_63}}};
    int8_t *l_146 = &g_147;
    uint16_t **l_148[8] = {&l_62[2][2][0],&l_62[1][3][0],&l_62[2][2][0],&l_62[1][3][0],&l_62[2][2][0],&l_62[1][3][0],&l_62[2][2][0],&l_62[1][3][0]};
    const int32_t *l_153 = &g_4[5][2][3];
    const int32_t ** const l_152 = &l_153;
    uint16_t l_154 = 0xB009L;
    uint32_t *l_271 = &g_266;
    uint32_t *l_272 = (void*)0;
    uint32_t *l_273 = &g_274[4][0][2];
    int32_t *l_494 = (void*)0;
    int32_t *l_495[10] = {&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0],&g_496[8][0]};
    uint32_t **l_514 = &g_181;
    const uint32_t * const l_517 = &g_194;
    const uint32_t * const *l_516 = &l_517;
    const int64_t l_524 = 6L;
    int i, j, k;
    (*l_51) = func_42(((*l_273) |= ((*l_271) = (l_45 & func_46((safe_add_func_uint32_t_u_u((p_40 != (g_53 = l_51)), ((safe_div_func_uint32_t_u_u(p_39, ((((safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(((p_39 , p_40) == ((g_63 = p_39) , g_64)), ((g_151 = (safe_mod_func_uint64_t_u_u(((g_149 = (((safe_rshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((*l_146) = ((safe_lshift_func_uint8_t_u_s((*l_52), p_39)) < p_39)), g_4[8][0][2])), 9)) , g_4[3][0][1]) , l_62[5][3][0])) == &g_150), p_39))) | 4294967295UL))), p_39)), 0xA0L)) , &l_52) == l_152) , g_4[5][0][0]))) || l_154))), g_155)))), &g_4[8][2][3]);
    g_496[8][0] &= (safe_mul_func_uint16_t_u_u(((safe_mod_func_uint32_t_u_u(((safe_mul_func_uint8_t_u_u((g_483[0] , (safe_mul_func_int8_t_s_s(((**l_51) <= 0xFD99L), 9L))), (g_274[4][0][2] & p_39))) & (safe_mul_func_int16_t_s_s(g_223[0][3], 0xA5CCL))), p_39)) || (*l_153)), p_39));
    for (g_266 = 0; (g_266 <= 59); g_266++)
    { /* block id: 186 */
        uint32_t l_499 = 0UL;
        int32_t l_505[5];
        int16_t l_513 = 0x0738L;
        uint32_t ***l_515 = &l_514;
        int16_t *l_518 = (void*)0;
        int16_t *l_519 = (void*)0;
        int16_t *l_520 = &g_225;
        int16_t *l_521 = &g_218[7];
        uint8_t *l_522[5][6][8] = {{{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215},{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151},{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215}},{{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151},{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215},{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151}},{{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215},{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151},{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215}},{{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151},{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215},{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151}},{{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215},{&g_268[0][3],&g_268[0][3],&g_220,&g_151,(void*)0,&g_268[0][3],(void*)0,&g_151},{&g_268[0][3],(void*)0,&g_268[0][3],&g_151,(void*)0,&g_215,&g_220,&g_151},{&g_268[0][3],&g_268[0][3],&g_220,&g_268[0][3],(void*)0,&g_268[0][3],(void*)0,&g_268[0][3]},{&g_268[0][3],&g_215,&g_268[0][3],&g_215,(void*)0,(void*)0,&g_220,&g_215}}};
        int32_t l_523 = (-1L);
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_505[i] = 0x39AEACB0L;
        l_499--;
        g_483[0] = (safe_unary_minus_func_uint32_t_u((safe_sub_func_uint64_t_u_u(l_505[2], (((((((!((l_523 = (safe_mod_func_int16_t_s_s((((*l_521) = ((safe_sub_func_uint16_t_u_u(p_39, ((*l_520) = ((0x6E6DL || ((((l_513 | ((g_390[3] < l_505[2]) , ((*g_156) , (((*l_515) = (l_499 , l_514)) != l_516)))) == p_39) < p_39) == g_268[3][2])) == p_39)))) , g_220)) , (-1L)), l_505[2]))) <= g_220)) == 0L) <= (**g_155)) , l_523) & p_39) & l_524) >= 0UL)))));
    }
    return p_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_194 g_63 g_151 g_147 g_156 g_4 g_155 g_215 g_53 g_274 g_218 g_150 g_294 g_226 g_225 g_266 g_223 g_344 g_268 g_211 g_293 g_265 g_259 g_64 g_65 g_167 g_483
 * writes: g_194 g_63 g_151 g_147 g_294 g_223 g_344 g_268 g_387 g_265 g_390 g_226 g_274 g_259 g_65 g_167 g_150 g_483
 */
static int32_t * func_42(uint32_t  p_43, int32_t * p_44)
{ /* block id: 80 */
    uint32_t l_275 = 0x8F9857E4L;
    int32_t l_280[4][3][8] = {{{0x79510EEAL,(-10L),0x6C70B449L,1L,9L,(-1L),(-1L),9L},{(-9L),1L,1L,(-9L),0x6C70B449L,0xF8298D6BL,(-3L),(-7L)},{0x6C70B449L,0xF8298D6BL,(-3L),(-7L),0L,0x9D4E1C92L,9L,(-10L)}},{{0xF338B5EEL,0xF8298D6BL,0x82A4FE22L,0x74578E65L,0x82A4FE22L,0xF8298D6BL,0xF338B5EEL,0x79510EEAL},{1L,1L,0x79510EEAL,0xF8298D6BL,(-9L),(-1L),0x198FB878L,1L},{1L,(-10L),0x74578E65L,0L,(-9L),(-9L),0L,0x74578E65L}},{{1L,1L,0x9D4E1C92L,1L,0x82A4FE22L,0xF338B5EEL,0x74578E65L,(-3L)},{0xF338B5EEL,0x6C70B449L,1L,0x82A4FE22L,0L,(-3L),1L,(-3L)},{0x6C70B449L,1L,(-9L),1L,0x6C70B449L,(-7L),0x9D4E1C92L,0x74578E65L}},{{(-9L),0x198FB878L,(-10L),0L,9L,0x82A4FE22L,0x79510EEAL,1L},{0x79510EEAL,0x9D4E1C92L,(-10L),0xF8298D6BL,0xF8298D6BL,(-10L),0x9D4E1C92L,0x79510EEAL},{9L,0xF338B5EEL,(-9L),0x74578E65L,1L,0x198FB878L,1L,(-10L)}}};
    int32_t l_338 = 0xCEC6AE19L;
    int8_t l_467[6][3] = {{0x00L,0x43L,0x00L},{0x22L,0x24L,0x24L},{0x6DL,0x43L,0x6DL},{0x22L,0x22L,0x24L},{0x00L,0x43L,0x00L},{0x22L,0x24L,0x24L}};
    uint32_t *l_475[2];
    uint16_t *l_478 = &g_150;
    int16_t l_479 = 0x9A49L;
    int16_t *l_480[8][8] = {{&g_225,&g_218[7],&g_218[7],&g_225,&l_479,&g_293,&g_223[0][6],(void*)0},{&g_223[0][4],&l_479,&g_223[0][3],&g_225,&g_225,&g_293,&l_479,&g_223[0][3]},{&g_223[0][6],&g_218[7],&l_479,&g_223[0][2],&g_293,(void*)0,&g_218[7],(void*)0},{&g_223[0][3],&g_223[0][3],&g_293,&g_223[0][3],&g_223[0][3],&g_293,(void*)0,&g_218[7]},{&l_479,(void*)0,&g_293,&g_223[0][6],(void*)0,&g_223[0][3],&l_479,&g_223[0][3]},{&g_223[0][3],&g_223[0][4],&g_293,&l_479,&g_223[0][3],&g_293,(void*)0,&l_479},{(void*)0,&l_479,&g_293,&g_218[7],&g_293,&g_293,&g_218[7],&g_293},{&l_479,&l_479,&l_479,(void*)0,&g_293,&g_223[0][3],&l_479,&g_293}};
    int32_t l_481[9][9] = {{0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL},{0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L},{0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL},{0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L},{0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL},{0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L},{0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL},{0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L,0x88284C36L},{0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL,0x1345A46EL}};
    int32_t *l_482[3][2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_475[i] = &g_194;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
            l_482[i][j] = &g_483[0];
    }
    for (g_194 = 0; (g_194 <= 0); g_194 += 1)
    { /* block id: 83 */
        int32_t l_289 = 0x295E8E2EL;
        int32_t l_290[8];
        int64_t *l_298[4] = {&g_211[5][1][0],&g_211[5][1][0],&g_211[5][1][0],&g_211[5][1][0]};
        int32_t **l_299[1];
        uint16_t *l_352 = (void*)0;
        int i;
        for (i = 0; i < 8; i++)
            l_290[i] = 0xC5B22501L;
        for (i = 0; i < 1; i++)
            l_299[i] = &g_156;
        for (g_63 = 0; (g_63 <= 0); g_63 += 1)
        { /* block id: 86 */
            int64_t l_285 = (-9L);
            int32_t l_288 = 0x1735F61BL;
            for (g_151 = 0; (g_151 <= 0); g_151 += 1)
            { /* block id: 89 */
                uint8_t l_286 = 2UL;
                int32_t l_287 = 0x9A2BFAC5L;
                for (g_147 = 0; (g_147 >= 0); g_147 -= 1)
                { /* block id: 92 */
                    int32_t *l_291 = &l_289;
                    int32_t *l_292[9] = {&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7],&l_280[2][0][7]};
                    int i;
                    l_287 &= ((p_43 , l_275) | (((&g_266 != &g_274[2][5][0]) <= ((safe_div_func_int32_t_s_s((safe_rshift_func_int16_t_s_u(((((p_43 > ((((l_280[0][2][5] = (*g_156)) < 0x35386F4FL) == ((safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((((void*)0 == (*g_155)) & g_215), p_43)), (**g_53))) != g_274[2][5][0])) | g_218[3])) && g_63) & l_285) ^ (*g_156)), l_275)), l_285)) | l_286)) & g_150));
                    --g_294[0];
                }
            }
        }
        if ((**g_155))
        { /* block id: 99 */
            int32_t *l_297[8];
            int i;
            for (i = 0; i < 8; i++)
                l_297[i] = (void*)0;
            if ((*p_44))
                break;
            l_290[1] = l_289;
            l_280[3][1][1] = (((void*)0 != l_298[0]) && l_289);
        }
        else
        { /* block id: 103 */
            uint16_t l_318 = 1UL;
            uint16_t *l_319 = &g_294[0];
            int32_t * const l_343 = &l_289;
            int32_t l_429 = 0L;
            if ((((((&p_44 != l_299[0]) > (safe_lshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s((-1L), g_150)), (((*l_319) |= (safe_div_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((((safe_mul_func_int16_t_s_s(((safe_add_func_uint16_t_u_u(p_43, ((safe_sub_func_uint8_t_u_u(0x44L, p_43)) ^ (l_280[0][2][5] = 8L)))) < (safe_mod_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_u(g_226, p_43)) || p_43), p_43))), l_318)) >= 2L) && (-1L)), (*g_156))), g_225))) , p_43)))) != 0x2B00L) >= l_318) && 0x784CL))
            { /* block id: 106 */
                int8_t l_322 = 0x5CL;
                int16_t l_323 = 0xCB5CL;
                uint32_t *l_330 = &g_274[2][0][1];
                int32_t l_337 = 0xEFBA7E37L;
                uint16_t *l_351 = &g_294[0];
                int32_t *l_406 = (void*)0;
                if ((safe_lshift_func_uint16_t_u_s((((l_322 = (&g_211[5][0][1] != (void*)0)) < 0x3111986F86244AF0LL) && g_274[4][0][2]), 8)))
                { /* block id: 108 */
                    int32_t *l_342 = &l_280[3][1][2];
                    int32_t **l_346 = &g_156;
                    uint16_t **l_353 = &l_351;
                    if ((*p_44))
                    { /* block id: 109 */
                        uint32_t *l_332 = (void*)0;
                        uint32_t **l_331 = &l_332;
                        uint8_t *l_333 = &g_151;
                        int32_t l_336 = 0x6F9C49DCL;
                        l_280[0][2][5] = l_323;
                        l_338 |= (safe_sub_func_int32_t_s_s((((((l_280[0][0][4] < (safe_mul_func_uint8_t_u_u(l_280[0][2][5], g_266))) || (((safe_rshift_func_uint8_t_u_s(((*l_333) = (l_330 != ((*l_331) = &g_274[4][3][3]))), 7)) > p_43) == ((((safe_add_func_uint16_t_u_u(l_336, p_43)) == 0x95EEB294L) != l_318) || 0xCFL))) | p_43) || p_43) , l_337), (*g_156)));
                    }
                    else
                    { /* block id: 114 */
                        int16_t *l_339 = &g_223[0][3];
                        if ((**g_53))
                            break;
                        g_344[1][0][1] |= ((*l_343) = (g_225 , (((((l_318 && ((((((p_43 || (-1L)) <= ((((&p_43 != &g_274[4][0][2]) > ((*l_339) |= 0L)) > (safe_rshift_func_int16_t_s_s(1L, 7))) || p_43)) , l_342) == l_343) != (-1L)) <= 0x2D12A1F4DBF8910ELL)) , p_43) != (*l_342)) != 65531UL) && 0xE2L)));
                        return (*g_53);
                    }
                    if (((*l_343) = ((+(((g_225 , g_215) , l_346) == (void*)0)) <= ((safe_rshift_func_int8_t_s_u(((1L > (p_43 & (0x47L == (l_330 == ((safe_rshift_func_int16_t_s_s((((*l_353) = (l_352 = l_351)) == (void*)0), (*l_342))) , p_44))))) < p_43), 5)) , g_151))))
                    { /* block id: 124 */
                        return (*g_53);
                    }
                    else
                    { /* block id: 126 */
                        int32_t **l_354 = &l_342;
                        int32_t l_357 = 0L;
                        int16_t l_358 = 2L;
                        uint8_t *l_359 = &g_268[5][7];
                        int8_t *l_371 = (void*)0;
                        int8_t *l_372 = &l_322;
                        uint64_t *l_386 = &g_387[7];
                        int8_t *l_388 = &g_265[1];
                        uint64_t *l_389 = &g_390[3];
                        (*l_354) = l_343;
                        (*l_343) = ((((safe_rshift_func_uint8_t_u_s(250UL, 7)) == l_357) == l_358) , (((++(*l_359)) & (safe_lshift_func_int8_t_s_u(g_211[7][1][0], 5))) ^ ((((*l_389) = ((g_211[2][1][1] < (l_280[0][2][5] = (((safe_lshift_func_uint16_t_u_s(((p_43 != (!(safe_mod_func_uint16_t_u_u((((safe_add_func_uint64_t_u_u((((((*l_372) |= p_43) == ((safe_mod_func_uint8_t_u_u((((*l_388) = (safe_rshift_func_uint8_t_u_u((safe_mod_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((((!(**l_354)) && ((*l_386) = (safe_rshift_func_uint16_t_u_s((((safe_rshift_func_int8_t_s_u(((((*l_342) & l_275) , p_43) < 0x8FL), 1)) , (**l_354)) && l_323), 4)))) >= 0x4E90C986L), g_293)), g_265[1])), l_323))) || 1L), (-1L))) || 0xDB1B38B637A08B2CLL)) >= p_43) || g_225), (*l_343))) < g_226) || 1UL), (-5L))))) , p_43), p_43)) || l_280[0][0][7]) && g_4[6][2][1]))) < g_344[1][0][1])) ^ (*l_343)) , g_63)));
                        return (*g_155);
                    }
                }
                else
                { /* block id: 137 */
                    int32_t l_401[4];
                    int32_t l_403 = 9L;
                    int32_t *l_405 = &l_280[0][2][5];
                    uint16_t *l_413 = &g_226;
                    int i;
                    for (i = 0; i < 4; i++)
                        l_401[i] = (-1L);
                    (*g_53) = l_330;
                    for (l_323 = 1; (l_323 <= 6); l_323 += 1)
                    { /* block id: 141 */
                        int8_t *l_402[10][6][4] = {{{&l_322,&g_259[0],&g_265[1],&g_259[3]},{(void*)0,&g_259[2],&g_265[1],&g_259[0]},{&g_265[1],&g_259[0],&l_322,&g_259[0]},{&g_265[1],&g_259[0],&g_265[1],&g_265[1]},{(void*)0,&l_322,&g_265[1],(void*)0},{&l_322,&g_259[0],&l_322,&l_322}},{{&g_259[2],&g_259[0],&l_322,&g_265[1]},{&l_322,&g_259[0],&l_322,&g_265[1]},{&g_265[1],&l_322,&g_259[2],&g_259[2]},{&g_259[2],&g_259[2],&l_322,&g_265[1]},{&g_259[2],&l_322,&g_259[2],&g_259[3]},{&g_265[1],(void*)0,&l_322,&l_322}},{{&l_322,&l_322,&l_322,(void*)0},{&g_265[1],&g_259[2],&l_322,&g_259[0]},{&l_322,&l_322,&l_322,&g_259[0]},{&g_265[1],&g_259[0],&g_259[2],&g_259[0]},{&g_259[2],&g_259[0],&l_322,(void*)0},{&g_259[2],&l_322,&g_259[2],&l_322}},{{&g_265[1],&g_265[1],&l_322,&g_259[3]},{&l_322,&l_322,&l_322,&g_265[1]},{&g_265[1],&g_259[0],&l_322,&g_259[2]},{&l_322,&g_259[0],&l_322,&g_265[1]},{&g_265[1],&l_322,&g_259[2],&g_259[2]},{&g_259[2],&g_259[2],&l_322,&g_265[1]}},{{&g_259[2],&l_322,&g_259[2],&g_259[3]},{&g_265[1],(void*)0,&l_322,&l_322},{&l_322,&l_322,&l_322,(void*)0},{&g_265[1],&g_259[2],&l_322,&g_259[0]},{&l_322,&l_322,&l_322,&g_259[0]},{&g_265[1],&g_259[0],&g_259[2],&g_259[0]}},{{&g_259[2],&g_259[0],&l_322,(void*)0},{&g_259[2],&l_322,&g_259[2],&l_322},{&g_265[1],&g_265[1],&l_322,&g_259[3]},{&l_322,&l_322,&l_322,&g_265[1]},{&g_265[1],&g_259[0],&l_322,&g_259[2]},{&l_322,&g_259[0],&l_322,&g_265[1]}},{{&g_265[1],&l_322,&g_259[2],&g_259[2]},{&g_259[2],&g_259[2],&l_322,&g_265[1]},{&g_259[2],&l_322,&g_259[2],&g_259[3]},{&g_265[1],(void*)0,&l_322,&l_322},{&l_322,&l_322,&l_322,(void*)0},{&g_265[1],&g_259[2],&l_322,&g_259[0]}},{{&l_322,&l_322,&l_322,&g_259[0]},{&g_265[1],&g_259[0],&g_259[2],&g_259[0]},{&g_259[2],&g_259[0],&l_322,(void*)0},{&g_259[2],&l_322,&g_259[2],&l_322},{&g_265[1],&g_265[1],&l_322,&g_259[3]},{&l_322,&l_322,&l_322,&g_265[1]}},{{&g_265[1],&g_259[0],&l_322,&g_259[2]},{&l_322,&g_259[0],&l_322,&g_265[1]},{&g_265[1],&l_322,&g_259[2],&g_259[2]},{&g_259[2],&g_259[2],&l_322,&g_265[1]},{&g_259[2],&l_322,&g_259[2],&g_259[3]},{&g_265[1],(void*)0,&l_322,&l_322}},{{&l_322,&l_322,&l_322,&g_259[3]},{&l_322,&g_259[0],&l_322,&l_322},{(void*)0,&g_265[1],&l_322,&l_322},{&g_259[2],(void*)0,&g_265[1],&l_322},{&g_265[1],&l_322,(void*)0,&g_259[3]},{&g_265[1],&g_265[1],&g_265[1],&g_265[1]}}};
                        int i, j, k;
                    }
                    (**g_53) &= (((safe_lshift_func_int8_t_s_u(g_4[6][2][0], g_294[4])) < (l_280[0][1][6] &= ((g_268[3][1] >= ((safe_mod_func_int8_t_s_s((safe_div_func_int16_t_s_s(1L, p_43)), l_275)) >= (((*l_343) = ((*l_413) ^= p_43)) , (((g_266 != (g_390[3] = (safe_lshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((*p_44) == g_344[1][0][1]), p_43)), p_43)), g_4[5][0][1])), g_194)))) <= (*p_44)) , l_323)))) >= 0x2FC4A7FCL))) > l_275);
                    if ((((safe_unary_minus_func_int16_t_s(((*p_44) || (~1L)))) , ((safe_add_func_uint32_t_u_u(((~(safe_add_func_int8_t_s_s(((0x7D202A44L != l_429) & (-10L)), (~(safe_unary_minus_func_uint32_t_u((((*l_405) = (((safe_lshift_func_uint8_t_u_u((((((safe_mod_func_int16_t_s_s(((p_43 > (p_43 , ((safe_sub_func_int32_t_s_s(((0xDF80L < ((*l_343) = 0x0CA3L)) && 0xBAFA89BE3DDDF1C7LL), 0x2B4A36ACL)) & l_280[0][2][5]))) != p_43), p_43)) > g_266) || g_194) , g_225) != 18446744073709551614UL), p_43)) , l_280[0][2][5]) == 65527UL)) , p_43))))))) >= g_226), (*p_44))) , p_43)) | l_337))
                    { /* block id: 158 */
                        if ((*p_44))
                            break;
                    }
                    else
                    { /* block id: 160 */
                        return p_44;
                    }
                }
                return p_44;
            }
            else
            { /* block id: 165 */
                int32_t l_444[10] = {0xF4F5EA74L,0xF4F5EA74L,7L,0x99ABDCF0L,7L,0xF4F5EA74L,0xF4F5EA74L,7L,0x99ABDCF0L,7L};
                uint64_t *l_461 = &g_387[7];
                int32_t **l_464 = (void*)0;
                int8_t *l_465 = &g_259[1];
                int8_t *l_466[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_466[i] = &g_265[1];
                (*g_64) = (((safe_add_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((l_444[4] , (l_467[3][1] = (safe_div_func_uint16_t_u_u(((!((*l_465) &= ((((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_s((p_43 ^ (safe_mod_func_int32_t_s_s((g_265[1] != (safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((*l_461) = (~0x7CL)), p_43)), g_268[0][3])), (*l_343)))), ((safe_add_func_int32_t_s_s((l_464 != (void*)0), p_43)) | 0xA938F1B1C8B13025LL)))), l_280[1][2][5])), g_226)) && (*p_44)) , (*p_44)) , p_43))) >= 0x46L), 65535UL)))), 6)), 7)) , (-8L)), p_43)) , 0x283143DDFEFCE86ALL) , (*g_64));
            }
            return (*g_53);
        }
        return (*g_155);
    }
    g_483[0] &= ((l_481[7][1] = (l_280[0][2][5] = (((p_43 , (&l_467[5][1] != (void*)0)) != (l_338 = ((0x8F1F4155962D47C7LL || (safe_add_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(l_467[3][1], 13)), 0x34A63BB351583004LL))) >= (~(((safe_rshift_func_uint16_t_u_s((((g_167--) & (((*l_478) = ((void*)0 != &g_387[7])) || 2L)) ^ l_479), p_43)) <= p_43) && g_294[0]))))) == p_43))) & p_43);
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_151 g_150 g_64 g_65 g_156 g_53 g_167 g_182 g_4 g_194 g_147 g_226 g_215 g_266 g_268
 * writes: g_63 g_150 g_65 g_151 g_147 g_156 g_167 g_181 g_182 g_194 g_149 g_211 g_215 g_218 g_220 g_226 g_259 g_263 g_265 g_268
 */
static uint32_t  func_46(uint16_t  p_47, int32_t ** p_48)
{ /* block id: 11 */
    int8_t l_164 = 0x87L;
    int32_t l_165 = 0x4F2F5847L;
    int32_t l_168 = 3L;
    for (g_63 = 0; (g_63 <= 4); g_63 += 1)
    { /* block id: 14 */
        return g_151;
    }
    for (g_150 = 21; (g_150 >= 8); g_150 = safe_sub_func_int8_t_s_s(g_150, 1))
    { /* block id: 19 */
        uint32_t l_159 = 1UL;
        const uint32_t l_216 = 8UL;
        int32_t l_221 = 0L;
        int32_t l_224 = (-1L);
        for (g_63 = 0; (g_63 <= 4); g_63 += 1)
        { /* block id: 22 */
            uint16_t l_189 = 3UL;
            int32_t l_193 = (-1L);
            int16_t l_222[6] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
            int i;
            (*g_64) = (*g_64);
            for (g_151 = 0; (g_151 <= 4); g_151 += 1)
            { /* block id: 26 */
                return p_47;
            }
            for (g_147 = 4; (g_147 >= 0); g_147 -= 1)
            { /* block id: 31 */
                int32_t l_217 = 0x5C270F0CL;
                int32_t *l_269 = &l_168;
                int32_t *l_270 = &l_221;
                int i, j, k;
                l_159++;
                for (g_151 = 0; (g_151 <= 4); g_151 += 1)
                { /* block id: 35 */
                    uint64_t l_173 = 0x35431FA81E3AF264LL;
                    int32_t *l_185[6];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_185[i] = &g_4[6][2][0];
                    for (p_47 = 1; (p_47 <= 4); p_47 += 1)
                    { /* block id: 38 */
                        uint32_t *l_166[8][5][2] = {{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}},{{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0},{&g_167,(void*)0}}};
                        uint32_t **l_178 = (void*)0;
                        uint32_t **l_179 = (void*)0;
                        uint32_t **l_180[4][5] = {{&l_166[5][2][0],(void*)0,&l_166[2][1][1],&l_166[5][1][1],(void*)0},{&l_166[6][2][0],&l_166[2][1][1],&l_166[2][1][1],&l_166[6][2][0],&l_166[5][1][1]},{(void*)0,&l_166[6][2][0],&l_166[5][2][0],(void*)0,(void*)0},{&l_166[5][2][0],&l_166[6][2][0],&l_166[5][2][0],&l_166[5][1][1],&l_166[6][2][0]}};
                        int32_t l_186 = (-10L);
                        uint16_t **l_207 = &g_149;
                        int64_t *l_210 = &g_211[5][0][1];
                        uint8_t *l_212 = (void*)0;
                        uint8_t *l_213 = (void*)0;
                        uint8_t *l_214 = &g_215;
                        int8_t *l_219[10] = {&l_164,&l_164,&l_164,&l_164,&l_164,&l_164,&l_164,&l_164,&l_164,&l_164};
                        int i, j, k;
                        (*p_48) = ((*g_53) = (*p_48));
                        g_194 &= (safe_lshift_func_uint16_t_u_u(((++g_167) >= (safe_sub_func_int16_t_s_s((l_173 = 0x182FL), ((safe_add_func_int16_t_s_s((((safe_div_func_int32_t_s_s((g_65[p_47][g_63][(p_47 + 2)] == (g_181 = l_166[5][2][0])), (safe_add_func_int32_t_s_s(((&g_65[0][3][0] != p_48) | ((*p_48) != l_185[5])), (l_186 , (l_189 = (g_182++))))))) != (!((((((safe_div_func_uint16_t_u_u((p_47 ^ p_47), p_47)) | 1L) , l_193) == 0x6805L) || g_4[8][2][2]) ^ 0x6CC5L))) == l_159), p_47)) & g_4[6][2][0])))), 3));
                        g_220 = (p_47 & ((l_186 = ((g_218[7] = (safe_lshift_func_int8_t_s_s((((p_47 | (g_151 , (safe_rshift_func_uint8_t_u_s((((0L > 0xF154065CL) | ((((safe_rshift_func_int16_t_s_u((safe_lshift_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u(((*l_214) = (((*l_210) = ((((*l_207) = &p_47) == &g_150) , ((g_194 == (((safe_rshift_func_uint8_t_u_u(g_167, g_182)) == 1UL) ^ g_167)) <= g_150))) ^ g_150)), 0)) > l_216), 7)), 10)) > 4L) , g_151) , 0x17017BC3L)) , p_47), l_217)))) , l_186) ^ 0L), 0))) >= 18446744073709551615UL)) < 0xC6L));
                    }
                    if (l_217)
                    { /* block id: 54 */
                        uint16_t *l_256 = &g_226;
                        int8_t *l_257 = &l_164;
                        int8_t *l_258 = &g_259[0];
                        int32_t l_260 = (-3L);
                        int16_t *l_261 = (void*)0;
                        int16_t *l_262 = &g_218[7];
                        int8_t *l_264 = &g_265[1];
                        (*g_64) = (p_47 , (*g_64));
                        l_193 = (**p_48);
                        g_226--;
                        l_168 = (safe_rshift_func_int8_t_s_u((p_47 && 0x6D4CF9D2C0AA69C2LL), (safe_mul_func_int16_t_s_s(((l_217 ^ (safe_rshift_func_int8_t_s_u(0x2BL, 6))) , (safe_mul_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s(((*l_264) = ((safe_mod_func_uint16_t_u_u(((safe_unary_minus_func_uint16_t_u((+((void*)0 != &p_47)))) != (safe_mul_func_uint8_t_u_u((((l_221 = 0x23L) <= (g_263 = ((safe_mul_func_int16_t_s_s(((*l_262) = (~((((((-1L) <= (((safe_rshift_func_int8_t_s_s(((*l_258) = ((*l_257) = ((safe_mod_func_uint16_t_u_u(((*l_256) &= (safe_mod_func_uint32_t_u_u(l_217, 0x8DD45185L))), 2L)) < l_164))), 7)) || 0x4ADD0DCDL) || l_193)) , (**g_53)) == l_260) , p_47) <= g_150))), l_222[3])) > l_165))) > 0L), l_217))), 4L)) , g_215)), g_266)) > (*g_156)), 0xBB8D3784L)), p_47))), g_215))));
                    }
                    else
                    { /* block id: 66 */
                        if (l_165)
                            break;
                        l_217 |= l_222[1];
                        g_268[0][3] ^= (+0x80L);
                    }
                }
                (*l_270) = ((*l_269) |= (**g_53));
            }
        }
    }
    return l_164;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_69[i][j][k], "g_69[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_70, "g_70", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_71[i][j], "g_71[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_72[i][j], "g_72[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_84[i][j], "g_84[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_88[i], "g_88[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_89, "g_89", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_90[i][j][k], "g_90[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_107[i][j][k], "g_107[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_108, "g_108", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_109[i], "g_109[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_110, "g_110", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_111[i][j], "g_111[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_119[i], "g_119[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_134[i], "g_134[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_137[i], "g_137[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_147, "g_147", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_167, "g_167", print_hash_value);
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_194, "g_194", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_211[i][j][k], "g_211[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_215, "g_215", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_218[i], "g_218[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_220, "g_220", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_223[i][j], "g_223[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_226, "g_226", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_259[i], "g_259[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_263, "g_263", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_265[i], "g_265[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_266, "g_266", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_268[i][j], "g_268[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_274[i][j][k], "g_274[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_293, "g_293", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_294[i], "g_294[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_344[i][j][k], "g_344[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_387[i], "g_387[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_390[i], "g_390[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_483[i], "g_483[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_496[i][j], "g_496[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_581, "g_581", print_hash_value);
    transparent_crc(g_633, "g_633", print_hash_value);
    transparent_crc(g_721, "g_721", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_752[i][j], "g_752[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_767[i], "g_767[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_784, "g_784", print_hash_value);
    transparent_crc(g_1018, "g_1018", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 252
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 171
   depth: 2, occurrence: 53
   depth: 3, occurrence: 5
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 22, occurrence: 3
   depth: 23, occurrence: 3
   depth: 24, occurrence: 5
   depth: 25, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 3
   depth: 30, occurrence: 1
   depth: 33, occurrence: 2
   depth: 35, occurrence: 4
   depth: 36, occurrence: 1
   depth: 38, occurrence: 1
   depth: 41, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 233

XXX times a variable address is taken: 758
XXX times a pointer is dereferenced on RHS: 157
breakdown:
   depth: 1, occurrence: 141
   depth: 2, occurrence: 14
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 157
breakdown:
   depth: 1, occurrence: 150
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 27
XXX times a pointer is compared with address of another variable: 8
XXX times a pointer is compared with another pointer: 4
XXX times a pointer is qualified to be dereferenced: 2642

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 649
   level: 2, occurrence: 202
   level: 3, occurrence: 16
XXX number of pointers point to pointers: 76
XXX number of pointers point to scalars: 157
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.9
XXX average alias set size: 1.95

XXX times a non-volatile is read: 1042
XXX times a non-volatile is write: 491
XXX times a volatile is read: 12
XXX    times read thru a pointer: 4
XXX times a volatile is write: 10
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 134
XXX percentage of non-volatile access: 98.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 184
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 20
   depth: 2, occurrence: 26
   depth: 3, occurrence: 23
   depth: 4, occurrence: 32
   depth: 5, occurrence: 50

XXX percentage a fresh-made variable is used: 15.3
XXX percentage an existing variable is used: 84.7
********************* end of statistics **********************/

