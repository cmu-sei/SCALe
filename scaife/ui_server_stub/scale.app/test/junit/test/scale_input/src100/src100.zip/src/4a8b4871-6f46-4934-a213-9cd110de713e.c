/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      2253099941
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_16 = 5UL;/* VOLATILE GLOBAL g_16 */
static uint8_t g_17 = 0xA4L;
static int32_t g_28[9] = {0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL,0x8586FD5DL};
static int32_t g_34 = 0x9C8DDAC0L;
static int32_t *g_33 = &g_34;
static uint32_t g_42 = 4294967295UL;
static uint32_t g_58 = 0xB1D70F3FL;
static uint32_t *g_81 = (void*)0;
static int32_t g_84 = (-9L);
static int16_t g_123 = 0x58C4L;
static int8_t g_126 = (-8L);
static int8_t g_130[4] = {0x63L,0x63L,0x63L,0x63L};
static uint8_t g_133 = 255UL;
static int16_t g_135[5][7] = {{0x42B7L,0xBE49L,0x9694L,5L,0x9694L,0xBE49L,0x42B7L},{0x7448L,0xCA51L,1L,0x81BEL,5L,0x338CL,0x42B7L},{5L,0x42B7L,(-1L),(-1L),0x42B7L,5L,0x7448L},{0xBE49L,(-1L),1L,0x7448L,0xE184L,5L,5L},{0x81BEL,0xE184L,0x9694L,0xE184L,0x81BEL,1L,0x7448L}};
static uint16_t g_138 = 65535UL;
static uint32_t g_260 = 7UL;
static uint8_t g_272 = 1UL;
static const int64_t *g_345 = (void*)0;
static int64_t g_355 = 1L;
static volatile int16_t g_372 = 0x20EAL;/* VOLATILE GLOBAL g_372 */
static volatile int16_t *g_371 = &g_372;
static volatile int16_t * volatile *g_370 = &g_371;
static int32_t *g_397 = &g_84;
static int16_t *g_411 = &g_123;
static int16_t *g_412[3][9] = {{&g_123,&g_123,&g_123,(void*)0,&g_123,(void*)0,&g_123,&g_123,&g_123},{&g_123,&g_123,&g_123,(void*)0,&g_123,(void*)0,&g_123,&g_123,&g_123},{&g_123,&g_123,&g_123,(void*)0,&g_123,(void*)0,&g_123,&g_123,&g_123}};
static uint16_t g_424 = 5UL;
static uint8_t g_483 = 0xB7L;
static int32_t g_508[7][5][7] = {{{0xFF9E4136L,(-3L),0x02607B20L,0x29CF573EL,8L,(-1L),0L},{(-3L),0x24F15F6CL,(-1L),0x30E3283AL,0xD1366A92L,0x720A155FL,(-3L)},{0x4BE40408L,0L,0x02607B20L,0x4BE40408L,0xEB298362L,0L,(-2L)},{0L,0xF3DE3858L,0x29CF573EL,0x29CF573EL,0xF3DE3858L,0L,0xFE4F7517L},{(-3L),0x30E3283AL,0x720A155FL,8L,(-3L),0x720A155FL,0x4BE40408L}},{{0xF3DE3858L,0xFE4F7517L,(-1L),0xD1366A92L,0x29CF573EL,(-1L),0xD1366A92L},{0L,0x30E3283AL,0xFF9E4136L,0xEB298362L,(-2L),0L,0L},{(-2L),0xF3DE3858L,0x720A155FL,0xF3DE3858L,(-2L),(-1L),(-3L)},{0x24F15F6CL,0L,0xEB298362L,(-3L),0x29CF573EL,0xFE4F7517L,0x24F15F6CL},{0xFF9E4136L,0x24F15F6CL,0xFE4F7517L,0x29CF573EL,(-3L),0xEB298362L,0L}},{{0x24F15F6CL,(-3L),(-1L),(-2L),0xF3DE3858L,0x720A155FL,0xF3DE3858L},{(-2L),0L,0L,(-2L),0xEB298362L,0xFF9E4136L,0x30E3283AL},{0L,0xD1366A92L,(-1L),0x29CF573EL,0xD1366A92L,(-1L),0xFE4F7517L},{0xF3DE3858L,0x4BE40408L,0x720A155FL,(-3L),8L,0x720A155FL,0x30E3283AL},{(-3L),0xFE4F7517L,0L,0xF3DE3858L,0x29CF573EL,0x29CF573EL,0xF3DE3858L}},{{0L,(-2L),0L,0xEB298362L,0x4BE40408L,0x02607B20L,0L},{0x4BE40408L,(-3L),0x720A155FL,0xD1366A92L,0x30E3283AL,(-1L),0x24F15F6CL},{(-3L),0L,(-1L),8L,0x29CF573EL,0x02607B20L,(-3L)},{0xFF9E4136L,8L,0L,0x29CF573EL,0x24F15F6CL,0x29CF573EL,0L},{8L,8L,(-1L),0x4BE40408L,(-3L),0x720A155FL,0xD1366A92L}},{{0x30E3283AL,0L,0xFE4F7517L,0x30E3283AL,0xEB298362L,(-1L),0x4BE40408L},{0L,(-3L),0xEB298362L,0x29CF573EL,(-3L),0xFF9E4136L,0xFE4F7517L},{0xD1366A92L,(-2L),0x720A155FL,0x24F15F6CL,0x24F15F6CL,0x720A155FL,(-2L)},{0xD1366A92L,0x720A155FL,(-1L),0xEB298362L,(-1L),0xBD3E7E1DL,0xEB298362L},{0x7EE25E21L,0L,0xB9432272L,0xBD3E7E1DL,0xFE4F7517L,0x720A155FL,1L}},{{0xFE4F7517L,0x29CF573EL,(-3L),0xEB298362L,0L,0x24F15F6CL,(-1L)},{(-1L),1L,(-1L),0xFF9E4136L,(-1L),1L,(-1L)},{(-1L),0L,(-1L),(-1L),(-1L),0x3E3D2872L,1L},{0L,0xFF9E4136L,0x24F15F6CL,0xFE4F7517L,0x29CF573EL,(-3L),0xEB298362L},{0L,1L,(-1L),0L,0xBD3E7E1DL,0x7EE25E21L,0x02607B20L}},{{0x7EE25E21L,(-1L),(-1L),(-1L),(-1L),0x7EE25E21L,0x720A155FL},{0xEB298362L,0xFE4F7517L,(-3L),(-1L),0L,(-3L),0L},{(-1L),0x720A155FL,0xB9432272L,0x29CF573EL,(-1L),0x3E3D2872L,0x29CF573EL},{0x7EE25E21L,0xFE4F7517L,(-1L),0xBD3E7E1DL,0x02607B20L,1L,1L},{0x02607B20L,(-1L),(-3L),(-1L),0x02607B20L,0x24F15F6CL,0L}}};
static volatile int8_t g_576 = 0xBBL;/* VOLATILE GLOBAL g_576 */
static volatile int8_t g_577 = 0x4FL;/* VOLATILE GLOBAL g_577 */
static volatile int8_t g_578 = (-1L);/* VOLATILE GLOBAL g_578 */
static volatile int8_t g_579 = 6L;/* VOLATILE GLOBAL g_579 */
static volatile int8_t g_580 = 1L;/* VOLATILE GLOBAL g_580 */
static volatile int8_t g_581 = 0x58L;/* VOLATILE GLOBAL g_581 */
static volatile int8_t g_582 = (-1L);/* VOLATILE GLOBAL g_582 */
static volatile int8_t g_583 = 3L;/* VOLATILE GLOBAL g_583 */
static volatile int8_t g_584 = 0x68L;/* VOLATILE GLOBAL g_584 */
static volatile int8_t *g_575[10][10][2] = {{{(void*)0,&g_582},{&g_579,&g_577},{&g_577,&g_577},{&g_579,&g_582},{(void*)0,&g_583},{&g_581,&g_579},{&g_580,&g_581},{(void*)0,&g_578},{(void*)0,&g_581},{&g_580,&g_579}},{{&g_581,&g_583},{(void*)0,&g_582},{&g_579,&g_577},{&g_577,&g_577},{&g_579,&g_582},{(void*)0,&g_583},{&g_581,&g_579},{&g_580,&g_581},{(void*)0,&g_578},{(void*)0,&g_581}},{{&g_580,&g_579},{&g_581,&g_583},{(void*)0,&g_582},{&g_579,&g_577},{&g_577,&g_577},{&g_579,&g_582},{(void*)0,&g_583},{&g_581,&g_579},{&g_580,&g_581},{(void*)0,&g_578}},{{(void*)0,&g_581},{&g_580,&g_579},{&g_581,&g_583},{(void*)0,&g_582},{&g_579,&g_577},{&g_577,&g_577},{&g_579,&g_582},{(void*)0,&g_583},{&g_581,&g_579},{&g_580,&g_581}},{{(void*)0,&g_578},{(void*)0,&g_581},{&g_580,&g_579},{&g_581,&g_583},{(void*)0,&g_582},{&g_579,&g_577},{&g_577,&g_577},{&g_579,&g_582},{(void*)0,&g_583},{&g_581,&g_579}},{{&g_580,&g_581},{(void*)0,&g_578},{(void*)0,&g_581},{&g_580,&g_577},{&g_578,&g_580},{(void*)0,&g_579},{&g_577,&g_584},{&g_584,&g_584},{&g_577,&g_579},{(void*)0,&g_580}},{{&g_578,&g_577},{(void*)0,&g_578},{&g_582,&g_576},{&g_582,&g_578},{(void*)0,&g_577},{&g_578,&g_580},{(void*)0,&g_579},{&g_577,&g_584},{&g_584,&g_584},{&g_577,&g_579}},{{(void*)0,&g_580},{&g_578,&g_577},{(void*)0,&g_578},{&g_582,&g_576},{&g_582,&g_578},{(void*)0,&g_577},{&g_578,&g_580},{(void*)0,&g_579},{&g_577,&g_584},{&g_584,&g_584}},{{&g_577,&g_579},{(void*)0,&g_580},{&g_578,&g_577},{(void*)0,&g_578},{&g_582,&g_576},{&g_582,&g_578},{(void*)0,&g_577},{&g_578,&g_580},{(void*)0,&g_579},{&g_577,&g_584}},{{&g_584,&g_584},{&g_577,&g_579},{(void*)0,&g_580},{&g_578,&g_577},{(void*)0,&g_578},{&g_582,&g_576},{&g_582,&g_578},{(void*)0,&g_577},{&g_578,&g_580},{(void*)0,&g_579}}};
static volatile int8_t ** const g_574 = &g_575[2][8][0];
static uint32_t g_599 = 4UL;
static uint64_t g_602 = 1UL;
static uint64_t g_606 = 6UL;
static int8_t g_624 = (-1L);
static uint64_t g_668 = 1UL;
static int8_t g_670[7][7] = {{0x44L,0x54L,0x72L,0x54L,0x44L,0x72L,0x93L},{0x21L,0x2BL,1L,0x21L,1L,0x2BL,0x21L},{6L,0x93L,0L,(-2L),0x93L,(-2L),0L},{0x21L,0x21L,0x17L,0x0FL,(-4L),0x17L,(-4L)},{0x44L,0L,0L,0x44L,(-2L),6L,0x44L},{(-3L),(-4L),1L,1L,(-4L),(-3L),0x2BL},{0x54L,0x44L,0x72L,0x93L,0x93L,0x72L,0x44L}};
static int8_t *g_682 = &g_624;
static int8_t **g_681 = &g_682;
static int64_t *g_723 = &g_355;
static volatile int16_t g_767 = 0xF366L;/* VOLATILE GLOBAL g_767 */
static volatile int16_t g_768 = 0x8BAAL;/* VOLATILE GLOBAL g_768 */
static volatile int16_t g_769 = 0x8147L;/* VOLATILE GLOBAL g_769 */
static volatile int16_t g_770 = 0x370CL;/* VOLATILE GLOBAL g_770 */
static volatile int16_t g_771 = 0xACEEL;/* VOLATILE GLOBAL g_771 */
static volatile int16_t g_772 = 0x2173L;/* VOLATILE GLOBAL g_772 */
static volatile int16_t g_773 = 0L;/* VOLATILE GLOBAL g_773 */
static volatile int16_t g_774 = 2L;/* VOLATILE GLOBAL g_774 */
static volatile int16_t g_775 = (-1L);/* VOLATILE GLOBAL g_775 */
static volatile int16_t g_776 = 0x1561L;/* VOLATILE GLOBAL g_776 */
static volatile int16_t g_777[7][9][4] = {{{6L,(-9L),0xEBD2L,0xE59CL},{0xEBD2L,0xE59CL,0xEBD2L,(-9L)},{6L,0xE59CL,0x6132L,0xE59CL},{6L,(-9L),0xEBD2L,0xE59CL},{0xEBD2L,0xE59CL,0xEBD2L,(-9L)},{6L,0xE59CL,0x6132L,0xE59CL},{6L,(-9L),0xEBD2L,0xE59CL},{0xEBD2L,0xE59CL,0xEBD2L,(-9L)},{6L,0xE59CL,0x6132L,0xE59CL}},{{6L,(-9L),0xEBD2L,0xE59CL},{0xEBD2L,0xE59CL,0xEBD2L,(-9L)},{6L,0xE59CL,0x6132L,0xE59CL},{6L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)}},{{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)}},{{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)}},{{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)}},{{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)}},{{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0xEBD2L,(-6L),0x6132L,(-9L)},{0x6132L,(-9L),0x6132L,(-6L)},{0xEBD2L,(-9L),6L,(-9L)},{0x6132L,0xE59CL,6L,(-6L)},{6L,(-6L),6L,0xE59CL},{0x6132L,(-6L),0xEBD2L,(-6L)}}};
static volatile int16_t g_778 = 1L;/* VOLATILE GLOBAL g_778 */
static volatile int16_t g_779 = 1L;/* VOLATILE GLOBAL g_779 */
static volatile int16_t g_780 = 0xBB1FL;/* VOLATILE GLOBAL g_780 */
static volatile int16_t g_781 = 0xC4BCL;/* VOLATILE GLOBAL g_781 */
static volatile int16_t g_782[6][4] = {{0x0415L,(-8L),0x0415L,(-8L)},{0x0415L,(-8L),0x0415L,(-8L)},{0x0415L,(-8L),0x0415L,(-8L)},{0x0415L,(-8L),0x0415L,(-8L)},{0x0415L,(-8L),0x0415L,(-8L)},{0x0415L,(-8L),0x0415L,(-8L)}};
static volatile int16_t g_783 = 0xFDD3L;/* VOLATILE GLOBAL g_783 */
static volatile int16_t g_784 = 0xC3E1L;/* VOLATILE GLOBAL g_784 */
static volatile int16_t *g_766[2][10][8] = {{{&g_780,&g_778,&g_773,&g_782[3][1],&g_769,&g_771,&g_769,&g_782[3][1]},{(void*)0,&g_778,(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0},{&g_784,&g_771,&g_773,&g_771,&g_784,&g_775,&g_780,&g_782[3][1]},{&g_784,&g_775,&g_780,&g_782[3][1],&g_780,&g_775,&g_784,&g_771},{(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0,&g_780,&g_771},{&g_780,&g_778,&g_773,&g_782[3][1],&g_769,&g_771,&g_769,&g_782[3][1]},{(void*)0,&g_778,(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0},{&g_784,&g_771,&g_773,&g_771,&g_784,&g_775,&g_780,&g_782[3][1]},{&g_784,&g_775,&g_780,&g_782[3][1],&g_780,&g_775,&g_784,&g_771},{(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0,&g_780,&g_771}},{{&g_780,&g_778,&g_773,&g_782[3][1],&g_769,&g_771,&g_769,&g_782[3][1]},{(void*)0,&g_778,(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0},{&g_784,&g_771,&g_773,&g_771,&g_784,&g_775,&g_780,&g_782[3][1]},{&g_784,&g_775,&g_780,&g_782[3][1],&g_780,&g_775,&g_784,&g_771},{(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0,&g_780,&g_771},{&g_780,&g_778,&g_773,&g_782[3][1],&g_769,&g_771,&g_769,&g_782[3][1]},{(void*)0,&g_778,(void*)0,&g_771,&g_780,(void*)0,&g_769,(void*)0},{&g_784,&g_771,&g_773,&g_771,&g_784,&g_775,&g_780,&g_782[3][1]},{&g_784,&g_775,&g_780,&g_782[3][1],&g_780,&g_775,&g_784,&g_771},{(void*)0,&g_771,&g_780,&g_782[3][1],&g_784,&g_782[3][1],(void*)0,(void*)0}}};
static int64_t g_825 = 0xCF51AF3294D6CE4BLL;
static uint8_t *g_845 = &g_272;
static volatile uint64_t g_989 = 0UL;/* VOLATILE GLOBAL g_989 */
static volatile uint64_t *g_988 = &g_989;
static volatile uint64_t * volatile *g_987 = &g_988;
static uint32_t **g_1264 = (void*)0;
static int8_t g_1309 = 0L;
static uint32_t **g_1317[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int8_t **g_1395[1] = {&g_575[7][8][0]};
static int32_t g_1464[8] = {1L,1L,(-10L),1L,1L,(-10L),1L,1L};
static uint64_t *g_1466 = &g_668;
static uint64_t g_1494 = 18446744073709551615UL;
static volatile int32_t * volatile *g_1512 = (void*)0;
static volatile int32_t * volatile ** const g_1511 = &g_1512;
static uint16_t *g_1530 = &g_138;
static uint16_t **g_1529 = &g_1530;
static int32_t g_1588 = 0xBF530425L;
static uint16_t g_1600 = 0x3970L;
static int32_t g_1829 = 0x21669534L;
static int64_t g_1853 = 0L;
static uint8_t g_1854 = 0UL;
static volatile uint8_t * const  volatile g_1888 = &g_16;/* VOLATILE GLOBAL g_1888 */
static volatile uint8_t * const  volatile *g_1887 = &g_1888;
static volatile uint8_t * const  volatile **g_1886 = &g_1887;
static int64_t *g_1891 = &g_825;
static const int32_t *g_1918 = &g_1464[4];
static const int32_t ** volatile g_1917 = &g_1918;/* VOLATILE GLOBAL g_1917 */
static int32_t ** volatile g_1956 = &g_33;/* VOLATILE GLOBAL g_1956 */
static int8_t ***g_2089 = (void*)0;
static int8_t **** const g_2088 = &g_2089;
static int32_t ** const  volatile g_2171 = &g_397;/* VOLATILE GLOBAL g_2171 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_5(int32_t  p_6, uint32_t  p_7, int64_t  p_8, const uint32_t  p_9, uint32_t  p_10);
static int32_t  func_11(int8_t  p_12, uint32_t  p_13, uint16_t  p_14, uint64_t  p_15);
static uint16_t  func_22(int32_t  p_23, uint16_t  p_24, uint32_t  p_25, const uint8_t  p_26);
static int32_t * func_31(uint32_t  p_32);
static int8_t  func_37(int32_t * p_38, uint8_t  p_39, const uint8_t  p_40);
static int16_t  func_49(uint32_t  p_50, uint32_t  p_51, uint32_t * p_52, uint64_t  p_53, uint32_t * const  p_54);
static int32_t  func_59(uint16_t  p_60, uint16_t  p_61, int8_t  p_62);
static int16_t  func_63(uint32_t  p_64, uint32_t * p_65, int32_t * p_66, int8_t  p_67);
static uint16_t  func_68(uint32_t * p_69);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_16 g_17 g_28 g_33 g_34 g_42 g_58 g_84 g_126 g_130 g_138 g_133 g_135 g_123 g_260 g_272 g_345 g_355 g_424 g_411 g_483 g_508 g_574 g_624 g_606 g_668 g_670 g_723 g_845 g_575 g_682 g_987 g_681 g_602 g_397 g_825 g_1464 g_1886 g_1887 g_1888 g_1530 g_1511 g_1512 g_1529 g_1918 g_1588 g_1466 g_2171
 * writes: g_28 g_42 g_58 g_81 g_84 g_123 g_126 g_130 g_133 g_135 g_260 g_138 g_272 g_370 g_397 g_411 g_412 g_424 g_355 g_483 g_508 g_599 g_602 g_606 g_624 g_845 g_681 g_34 g_33 g_825 g_1891 g_668
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    const uint64_t l_2 = 2UL;
    int32_t *l_27 = &g_28[3];
    uint32_t l_1857 = 0xE5182B71L;
    const uint8_t l_2101 = 0UL;
    uint32_t *l_2134 = &g_58;
    int32_t l_2135 = 0x2C48B84CL;
    int16_t l_2142 = 0x584BL;
    uint64_t l_2146[6][8][5] = {{{18446744073709551611UL,0x601C08B7C2BE3310LL,0UL,6UL,0xA69C994987FEF90ALL},{0xB3A682C011293796LL,0UL,6UL,18446744073709551609UL,18446744073709551615UL},{0xB3A682C011293796LL,9UL,1UL,1UL,0x2B9AFBACCF62CA99LL},{18446744073709551611UL,0xBB4CDC51DA63863CLL,0UL,0UL,0xBB4CDC51DA63863CLL},{0xB3A682C011293796LL,0xB0E82ECCA689CC92LL,0xDBF8CDF056B4486CLL,18446744073709551615UL,0x435E988F1AF64B2ALL},{0xB3A682C011293796LL,0x601C08B7C2BE3310LL,1UL,18446744073709551612UL,0xA69C994987FEF90ALL},{18446744073709551611UL,0xA69C994987FEF90ALL,6UL,0UL,0x601C08B7C2BE3310LL},{0xB3A682C011293796LL,0x435E988F1AF64B2ALL,0xAF58675C099A98A9LL,1UL,0xB0E82ECCA689CC92LL}},{{0xB3A682C011293796LL,0xBB4CDC51DA63863CLL,1UL,0UL,0xBB4CDC51DA63863CLL},{18446744073709551611UL,0x2B9AFBACCF62CA99LL,0xDBF8CDF056B4486CLL,0xAF58675C099A98A9LL,9UL},{0xB3A682C011293796LL,18446744073709551615UL,0UL,18446744073709551612UL,0UL},{0xB3A682C011293796LL,0xA69C994987FEF90ALL,0x4AECEC3C89893A38LL,18446744073709551609UL,0x601C08B7C2BE3310LL},{18446744073709551611UL,9UL,0xAF58675C099A98A9LL,0xDBF8CDF056B4486CLL,0x2B9AFBACCF62CA99LL},{0xB3A682C011293796LL,0x03DD94FD9CAA18F0LL,0UL,0UL,0x03DD94FD9CAA18F0LL},{0xB3A682C011293796LL,0x2B9AFBACCF62CA99LL,0xAE388115BFB73286LL,18446744073709551615UL,9UL},{18446744073709551611UL,0x601C08B7C2BE3310LL,0UL,6UL,0xA69C994987FEF90ALL}},{{0xB3A682C011293796LL,0UL,6UL,18446744073709551609UL,18446744073709551615UL},{0xB3A682C011293796LL,9UL,1UL,1UL,0x2B9AFBACCF62CA99LL},{18446744073709551611UL,0xBB4CDC51DA63863CLL,0UL,0UL,0xBB4CDC51DA63863CLL},{0xB3A682C011293796LL,0xB0E82ECCA689CC92LL,0xDBF8CDF056B4486CLL,18446744073709551615UL,0x435E988F1AF64B2ALL},{0xB3A682C011293796LL,0x601C08B7C2BE3310LL,1UL,18446744073709551612UL,0xA69C994987FEF90ALL},{18446744073709551611UL,0xA69C994987FEF90ALL,6UL,0UL,0x601C08B7C2BE3310LL},{0xB3A682C011293796LL,0x435E988F1AF64B2ALL,0xAF58675C099A98A9LL,1UL,0xB0E82ECCA689CC92LL},{0xB3A682C011293796LL,0xBB4CDC51DA63863CLL,1UL,0UL,0xBB4CDC51DA63863CLL}},{{18446744073709551611UL,0x2B9AFBACCF62CA99LL,0xDBF8CDF056B4486CLL,0xAF58675C099A98A9LL,9UL},{0xB3A682C011293796LL,18446744073709551615UL,0UL,18446744073709551612UL,0UL},{0xB3A682C011293796LL,0xA69C994987FEF90ALL,0x4AECEC3C89893A38LL,18446744073709551609UL,0x601C08B7C2BE3310LL},{18446744073709551611UL,9UL,0xAF58675C099A98A9LL,0xDBF8CDF056B4486CLL,0x2B9AFBACCF62CA99LL},{0xB3A682C011293796LL,0x03DD94FD9CAA18F0LL,0UL,0UL,0x03DD94FD9CAA18F0LL},{0xB3A682C011293796LL,0x2B9AFBACCF62CA99LL,0xAE388115BFB73286LL,18446744073709551615UL,9UL},{18446744073709551611UL,0x601C08B7C2BE3310LL,0UL,6UL,0xA69C994987FEF90ALL},{0xB3A682C011293796LL,0UL,6UL,18446744073709551609UL,18446744073709551615UL}},{{0xB3A682C011293796LL,9UL,1UL,1UL,0x2B9AFBACCF62CA99LL},{18446744073709551611UL,0xBB4CDC51DA63863CLL,0UL,0UL,0xBB4CDC51DA63863CLL},{0x6F42574145CF195ALL,7UL,9UL,0UL,0x6221AC64FE558CBCLL},{0x6F42574145CF195ALL,0x316335CE732DFA1ALL,9UL,0xB0E82ECCA689CC92LL,7UL},{0x75D47A2183D87096LL,7UL,2UL,18446744073709551614UL,0x316335CE732DFA1ALL},{0x6F42574145CF195ALL,0x6221AC64FE558CBCLL,0x603AA976E4A88F26LL,18446744073709551615UL,7UL},{0x6F42574145CF195ALL,0xD709080B938057B6LL,0xBB4CDC51DA63863CLL,0x03DD94FD9CAA18F0LL,0xD709080B938057B6LL},{0x75D47A2183D87096LL,9UL,9UL,0x603AA976E4A88F26LL,0xF71746E40E05A9E6LL}},{{0x6F42574145CF195ALL,9UL,18446744073709551614UL,0xB0E82ECCA689CC92LL,18446744073709551611UL},{0x6F42574145CF195ALL,7UL,0x2B9AFBACCF62CA99LL,0x435E988F1AF64B2ALL,0x316335CE732DFA1ALL},{0x75D47A2183D87096LL,0xF71746E40E05A9E6LL,0x603AA976E4A88F26LL,9UL,9UL},{0x6F42574145CF195ALL,0xD83417B985B5D2EBLL,0xD9DB43F6DE9ADA19LL,0x03DD94FD9CAA18F0LL,0xD83417B985B5D2EBLL},{0x6F42574145CF195ALL,9UL,0x601C08B7C2BE3310LL,0UL,0xF71746E40E05A9E6LL},{0x75D47A2183D87096LL,0x316335CE732DFA1ALL,18446744073709551614UL,2UL,7UL},{0x6F42574145CF195ALL,18446744073709551611UL,2UL,0x435E988F1AF64B2ALL,9UL},{0x6F42574145CF195ALL,0xF71746E40E05A9E6LL,0xA69C994987FEF90ALL,18446744073709551615UL,9UL}}};
    int32_t *l_2152 = &g_508[3][2][0];
    int32_t **l_2151 = &l_2152;
    int32_t ***l_2150 = &l_2151;
    int32_t l_2153 = (-9L);
    uint8_t l_2166 = 0x2CL;
    int32_t l_2172 = 0x604F8460L;
    int32_t l_2173[4];
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_2173[i] = (-1L);
    l_2135 &= (l_2 <= (((((*l_2134) = (safe_sub_func_uint32_t_u_u((func_5(func_11(((g_16 > (g_17 , (safe_rshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s(((func_22(((*l_27) ^= l_2), (safe_add_func_int32_t_s_s(((g_17 , func_31(g_17)) == &g_34), (65535UL != g_17))), g_17, g_34) > g_1464[0]) < l_2), 2UL)), l_2)))) , 0xE7L), l_2, l_1857, l_1857), g_1464[4], l_2, l_2101, l_2) ^ 0x559FD32CL), (*g_1918)))) , 0x29D0677EL) ^ g_1588) >= l_2101));
    if ((((safe_add_func_int64_t_s_s((((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((*l_27) , (*l_27)), (((*g_682) ^= (*l_27)) & 1UL))), l_2142)) == (((*g_1466) = ((((!((safe_div_func_uint32_t_u_u(1UL, l_2146[4][0][0])) != (~(((-8L) >= ((safe_lshift_func_int16_t_s_u((*l_27), (*l_27))) ^ (*l_27))) > (*l_27))))) != (*l_27)) , l_2150) == &l_2151)) <= l_2153)) , (-10L)), (-1L))) , (*l_27)) , (*l_27)))
    { /* block id: 981 */
        int32_t **l_2154 = &g_397;
        (*l_2154) = (void*)0;
    }
    else
    { /* block id: 983 */
        int32_t *l_2155 = &g_1464[0];
        int32_t *l_2156 = &g_84;
        int32_t *l_2157 = &l_2135;
        int32_t *l_2158 = &g_84;
        int32_t *l_2159 = (void*)0;
        int32_t *l_2160 = &g_28[3];
        int32_t *l_2161 = &g_34;
        int32_t *l_2162 = &l_2135;
        int32_t *l_2163 = &l_2135;
        int32_t *l_2164[2][10] = {{&g_1464[0],(void*)0,&g_1464[0],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_1464[0]},{&g_28[6],&g_28[6],&g_28[3],(void*)0,(void*)0,&g_28[3],(void*)0,(void*)0,&g_28[3],&g_28[6]}};
        int16_t l_2165 = 0xE669L;
        int64_t l_2174 = 0x14080AC4017E9DC3LL;
        uint16_t l_2175 = 0UL;
        uint16_t l_2178[9][3] = {{65535UL,8UL,8UL},{0x3DE6L,9UL,65535UL},{65535UL,8UL,8UL},{0x3DE6L,9UL,65535UL},{65535UL,8UL,8UL},{0x3DE6L,9UL,65535UL},{65535UL,8UL,8UL},{0x3DE6L,9UL,65535UL},{65535UL,8UL,8UL}};
        int i, j;
        l_2166++;
        (*g_2171) = &l_2135;
        ++l_2175;
        l_2178[2][0] = 0x2215D4AEL;
    }
    return (*l_27);
}


/* ------------------------------------------ */
/* 
 * reads : g_1511 g_1512 g_1887 g_1888 g_16 g_682 g_624 g_28 g_723 g_1529 g_1530 g_138 g_1886
 * writes: g_28 g_355
 */
static const int32_t  func_5(int32_t  p_6, uint32_t  p_7, int64_t  p_8, const uint32_t  p_9, uint32_t  p_10)
{ /* block id: 969 */
    int32_t *l_2111 = &g_1829;
    int32_t **l_2110 = &l_2111;
    int32_t ***l_2112 = &l_2110;
    int32_t l_2113 = 0L;
    int32_t *l_2120 = &g_28[6];
    uint32_t l_2121[9] = {0UL,0x6E1C9573L,0x6E1C9573L,0UL,0x6E1C9573L,0x6E1C9573L,0UL,0x6E1C9573L,0x6E1C9573L};
    int8_t **l_2132 = (void*)0;
    uint64_t l_2133 = 0xC2EE72718B7F7569LL;
    int i;
    l_2113 = ((*l_2120) = ((safe_lshift_func_uint16_t_u_u(0x5008L, (0x33807AF0L & (p_10++)))) == (((safe_add_func_int8_t_s_s((p_7 < ((safe_mul_func_int8_t_s_s(((((*l_2112) = l_2110) != (void*)0) > (l_2113 == (safe_sub_func_int8_t_s_s((safe_mod_func_uint64_t_u_u(p_6, ((safe_add_func_int64_t_s_s((((*g_1511) == (*g_1511)) || p_7), p_6)) , l_2113))), (**g_1887))))), (*g_682))) , p_6)), l_2113)) > l_2113) , l_2113)));
    (*l_2120) = ((((((*g_723) = (*l_2120)) != ((l_2121[8] , p_8) & ((safe_sub_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(((void*)0 == &g_1887), (((((safe_mul_func_int16_t_s_s((((((safe_rshift_func_uint16_t_u_u((**g_1529), 4)) > p_8) >= (***g_1886)) && (***g_1886)) , (*l_2120)), (-8L))) , 0xE95732DEL) || 4294967295UL) , (void*)0) != l_2132))), l_2133)) <= 0xBA5FL) , (**g_1529)), 0x40ABL)) & (*l_2120)))) | p_9) || p_9) ^ (*l_2120));
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_411 g_123 g_723 g_355 g_1886 g_1887 g_1888 g_16 g_1530 g_138 g_682 g_33 g_483 g_34
 * writes: g_1891 g_624 g_123 g_135 g_397 g_483 g_33 g_34
 */
static int32_t  func_11(int8_t  p_12, uint32_t  p_13, uint16_t  p_14, uint64_t  p_15)
{ /* block id: 865 */
    int8_t ***l_1859 = &g_681;
    int8_t **** const l_1858 = &l_1859;
    int32_t l_1860 = 8L;
    uint16_t ** const l_1861 = &g_1530;
    int64_t l_1874 = 0L;
    int32_t l_1875 = (-1L);
    uint8_t ** const l_1876 = &g_845;
    uint32_t l_1878 = 1UL;
    uint64_t l_1895 = 0x2CC503EFC500DB74LL;
    uint32_t * const l_1977 = &l_1878;
    uint32_t * const *l_1976[5][1] = {{&l_1977},{&l_1977},{&l_1977},{&l_1977},{&l_1977}};
    uint32_t *l_1978[8][9][2] = {{{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599}},{{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599}},{{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599}},{{(void*)0,(void*)0},{&g_599,(void*)0},{(void*)0,&g_599},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58}},{{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58}},{{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58}},{{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58}},{{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58},{&g_599,&g_599},{&g_58,&g_599},{&g_599,&g_58}}};
    const uint16_t l_2022 = 1UL;
    int32_t l_2090 = 0x243080F0L;
    int i, j, k;
    if ((((l_1858 == (void*)0) , ((l_1860 >= (l_1861 != &g_1530)) , ((p_13 = (safe_rshift_func_uint16_t_u_s(l_1860, (1UL | (((((((safe_rshift_func_uint16_t_u_s(((l_1875 |= (1L >= (safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s(((safe_add_func_int16_t_s_s((safe_mul_func_int8_t_s_s(((p_14 || l_1860) > p_13), l_1860)), p_14)) >= l_1874), l_1874)), 1)))) ^ 0x6DCDL), 10)) , (void*)0) != l_1876) > (*g_411)) > l_1874) < p_12) , l_1860))))) , l_1874))) < 0x3359L))
    { /* block id: 868 */
        uint8_t **l_1884 = &g_845;
        uint8_t ***l_1883 = &l_1884;
        uint8_t ****l_1885 = &l_1883;
        int32_t l_1896 = 0x4F314112L;
        int16_t *l_1897 = &g_135[3][1];
        int32_t **l_1898 = &g_397;
        uint32_t l_1901 = 4UL;
        uint8_t l_1930 = 0x41L;
        int8_t l_1979 = 0x77L;
        int16_t l_2076[5] = {0xF40CL,0xF40CL,0xF40CL,0xF40CL,0xF40CL};
        int32_t *l_2084 = &g_508[0][3][1];
        int32_t l_2091 = 0x49BAD8ADL;
        uint32_t l_2092 = 7UL;
        int32_t *l_2095[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint64_t l_2096 = 0x18CC4DCA6F6A7A54LL;
        int32_t **l_2099 = &g_33;
        int32_t **l_2100 = &l_2095[0];
        int i;
        (*l_1898) = func_31((!(p_12 , (l_1878 >= ((*l_1897) = ((*g_411) = ((l_1874 != (((*g_723) >= (safe_div_func_int64_t_s_s((safe_mul_func_int8_t_s_s(((((*l_1885) = l_1883) == g_1886) || (**g_1887)), ((*g_682) = (((safe_sub_func_uint16_t_u_u(((g_1891 = &l_1874) != (((((safe_rshift_func_int16_t_s_u(((!((p_15 || (*g_1530)) == l_1878)) <= l_1895), (*g_1530))) || 0x5B57BB2CL) >= l_1874) >= l_1896) , (void*)0)), 65533UL)) , (-4L)) && 0x546254B0L)))), l_1896))) | l_1860)) , p_14)))))));
        for (g_483 = 0; (g_483 <= 3); g_483 += 1)
        { /* block id: 877 */
            int64_t **l_1959 = (void*)0;
            int32_t *l_1968[3];
            uint32_t *l_1972 = &l_1878;
            uint32_t **l_1971[7][3][9] = {{{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,&l_1972},{(void*)0,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972}},{{&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,(void*)0,&l_1972,&l_1972,&l_1972},{&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,(void*)0,&l_1972,&l_1972,(void*)0},{&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,&l_1972,(void*)0}},{{&l_1972,(void*)0,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{(void*)0,&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972}},{{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972},{&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0},{&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,(void*)0,&l_1972}},{{&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,(void*)0,&l_1972,&l_1972},{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,&l_1972}},{{(void*)0,(void*)0,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{(void*)0,&l_1972,(void*)0,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972},{&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972}},{{&l_1972,(void*)0,(void*)0,(void*)0,(void*)0,&l_1972,&l_1972,(void*)0,(void*)0},{&l_1972,&l_1972,&l_1972,&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972},{&l_1972,(void*)0,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,&l_1972,(void*)0}}};
            uint16_t ***l_2011 = &g_1529;
            uint16_t ****l_2010 = &l_2011;
            int8_t l_2073 = 0xD0L;
            uint64_t l_2077[2];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_1968[i] = (void*)0;
            for (i = 0; i < 2; i++)
                l_2077[i] = 1UL;
        }
        --l_2096;
        (*l_2100) = ((*l_2099) = ((*l_1898) = &l_2090));
    }
    else
    { /* block id: 965 */
        (*g_33) ^= p_14;
    }
    return l_2022;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_34 g_17 g_42 g_28 g_58 g_84 g_126 g_130 g_138 g_133 g_135 g_123 g_260 g_272 g_345 g_355 g_424 g_411 g_483 g_508 g_574 g_624 g_606 g_668 g_670 g_723 g_845 g_575 g_682 g_987 g_681 g_602 g_397 g_825
 * writes: g_42 g_58 g_81 g_84 g_28 g_123 g_126 g_130 g_133 g_135 g_260 g_138 g_272 g_370 g_397 g_411 g_412 g_424 g_355 g_483 g_508 g_599 g_602 g_606 g_624 g_845 g_681 g_34 g_33 g_825
 */
static uint16_t  func_22(int32_t  p_23, uint16_t  p_24, uint32_t  p_25, const uint8_t  p_26)
{ /* block id: 4 */
    int32_t l_45 = (-1L);
    uint32_t *l_57 = &g_58;
    int32_t l_1209 = 1L;
    int32_t l_1210 = 0xB7A2F30CL;
    int32_t l_1211 = 1L;
    int32_t l_1212[4][10][2] = {{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}}};
    int16_t l_1222 = 0L;
    int16_t **l_1247[4];
    uint32_t *l_1283 = &g_260;
    uint32_t **l_1282 = &l_1283;
    uint32_t ***l_1281 = &l_1282;
    int64_t **l_1332 = &g_723;
    uint32_t l_1337 = 18446744073709551608UL;
    uint32_t l_1353 = 0UL;
    uint32_t l_1361 = 0xA87F79A4L;
    uint8_t * const *l_1366 = &g_845;
    uint8_t * const **l_1365 = &l_1366;
    uint64_t *l_1465[3];
    int16_t l_1471 = 0x8427L;
    uint16_t **l_1532 = &g_1530;
    uint8_t l_1549 = 0x67L;
    int32_t *l_1557 = &g_1464[0];
    int8_t **l_1606 = &g_682;
    uint16_t l_1618 = 7UL;
    int64_t **l_1657[5];
    uint64_t l_1686 = 8UL;
    uint16_t l_1687 = 0x8968L;
    int32_t l_1706 = (-1L);
    uint8_t l_1833 = 0x92L;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1247[i] = &g_411;
    for (i = 0; i < 3; i++)
        l_1465[i] = &g_602;
    for (i = 0; i < 5; i++)
        l_1657[i] = (void*)0;
    if ((*g_33))
    { /* block id: 5 */
        uint32_t *l_41 = &g_42;
        int32_t l_46 = 0xD36FBC6AL;
        uint32_t l_1190 = 0xE20854DCL;
        int32_t l_1208 = (-1L);
        int32_t l_1213 = (-5L);
        int32_t l_1214 = 1L;
        int32_t l_1215 = 0xDB1E5A83L;
        int32_t l_1216 = 0x1F721679L;
        int8_t l_1217 = 0x5FL;
        int32_t l_1218 = (-1L);
        int32_t l_1219 = 7L;
        int32_t l_1221 = 0xDA4C87CFL;
        int32_t l_1223 = 0xDFA7AA52L;
        int32_t l_1224 = 0L;
        int16_t l_1225 = 0x573AL;
        int32_t l_1226[3];
        uint32_t l_1227 = 4294967293UL;
        int i;
        for (i = 0; i < 3; i++)
            l_1226[i] = (-1L);
        if (((g_17 | (safe_lshift_func_int8_t_s_s(func_37(func_31(((*l_41) ^= 6UL)), p_26, ((safe_div_func_int16_t_s_s(((l_45 = (l_45 != g_34)) >= (0x4ED25E42506ED55CLL || (l_46 && (safe_lshift_func_int16_t_s_s(func_49((safe_sub_func_int32_t_s_s(5L, p_25)), g_28[3], l_57, p_25, l_41), 3))))), p_24)) ^ g_17)), 3))) > l_46))
        { /* block id: 548 */
            int32_t **l_1182 = &g_397;
            (*l_1182) = func_31((g_17 , g_670[6][2]));
        }
        else
        { /* block id: 550 */
            int16_t l_1193 = 0x16CBL;
            int64_t l_1202 = 0xCD31623A3B42A5C7LL;
            int32_t *l_1203 = &g_84;
            int32_t **l_1204 = &g_33;
            int32_t *l_1205 = (void*)0;
            int32_t l_1206 = 0L;
            int32_t *l_1207[1][7][10] = {{{(void*)0,(void*)0,&l_46,(void*)0,&l_46,(void*)0,(void*)0,&l_46,(void*)0,&l_46},{(void*)0,(void*)0,&l_46,(void*)0,&l_46,(void*)0,(void*)0,&l_46,&g_34,&g_34},{&l_46,&l_46,&g_34,&g_34,&g_34,&l_46,&l_46,&g_34,&g_34,&g_34},{&l_46,&l_46,&g_34,&g_34,&g_34,&l_46,&l_46,&g_34,&g_34,&g_34},{&l_46,&l_46,&g_34,&g_34,&g_34,&l_46,&l_46,&g_34,&g_34,&g_34},{&l_46,&l_46,&g_34,&g_34,&g_34,&l_46,&l_46,&g_34,&g_34,&g_34},{&l_46,&l_46,&g_34,&g_34,&g_34,&l_46,&l_46,&g_34,&g_34,&g_34}}};
            int8_t l_1220 = (-1L);
            int i, j, k;
            (*l_1204) = func_31(((((*g_33) = p_26) == ((((+(safe_mod_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((((l_46 , (l_1190 && (safe_lshift_func_uint8_t_u_s((l_1193 | ((*l_1203) = ((l_1190 && ((safe_mul_func_int8_t_s_s((safe_add_func_uint32_t_u_u(((safe_add_func_int32_t_s_s((((*g_682) = (*g_682)) > l_1190), (safe_mod_func_uint64_t_u_u(((0UL && l_1202) , g_123), l_46)))) < 1UL), l_46)), l_1190)) | l_1190)) , 0L))), 5)))) , (void*)0) == &g_397), p_25)), p_25)), (-4L)))) < 0xD7L) ^ 7L) >= (*g_411))) , 0x9E3F052FL));
            l_1227++;
        }
    }
    else
    { /* block id: 557 */
        const int32_t l_1240 = 0xB77A4807L;
        int16_t ***l_1248 = &l_1247[3];
        int16_t **l_1250 = &g_412[0][2];
        int16_t ***l_1249 = &l_1250;
        int32_t l_1251 = 0x9574F087L;
        (*g_397) = (safe_div_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s(((safe_mod_func_int8_t_s_s(((*g_682) = (safe_mul_func_int8_t_s_s(0x18L, (safe_sub_func_int16_t_s_s(l_1240, (((l_1209 &= l_1222) ^ (0xFAEAL ^ ((l_1240 && l_1212[1][8][1]) != ((((safe_div_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((((*l_1248) = l_1247[1]) != ((*l_1249) = (p_24 , (p_25 , &g_411)))), 0x9DC9L)) | 0x7A1E09E1L), 0x676BL)) , 18446744073709551615UL) , l_1212[3][9][1]) , 1L)))) , 0xD9CCL)))))), p_26)) != p_23), 0)) , l_1240), l_1251));
    }
    for (g_825 = 3; (g_825 >= 0); g_825 -= 1)
    { /* block id: 566 */
        int16_t l_1268[10];
        uint32_t *l_1272 = &g_599;
        int32_t l_1310 = 0xDA9B79DCL;
        uint32_t **l_1316 = &l_1283;
        int32_t l_1350 = (-1L);
        int32_t l_1352[1][7];
        int32_t l_1360 = (-4L);
        int8_t ***l_1393 = &g_681;
        int16_t l_1394[1];
        uint32_t l_1429 = 0x117F7F50L;
        uint16_t **l_1533 = (void*)0;
        uint16_t ***l_1622[4] = {&l_1532,&l_1532,&l_1532,&l_1532};
        const int64_t *l_1718[4];
        uint64_t l_1762 = 0xD527FC4BC439A1EFLL;
        int64_t l_1763 = 0L;
        int32_t l_1844 = 0xB68505FEL;
        int i, j;
        for (i = 0; i < 10; i++)
            l_1268[i] = 0x3FADL;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 7; j++)
                l_1352[i][j] = 0xEEC12447L;
        }
        for (i = 0; i < 1; i++)
            l_1394[i] = 0L;
        for (i = 0; i < 4; i++)
            l_1718[i] = &g_355;
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_33
 * writes:
 */
static int32_t * func_31(uint32_t  p_32)
{ /* block id: 2 */
    return g_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_682 g_624 g_411 g_33 g_34
 * writes: g_123 g_424 g_34
 */
static int8_t  func_37(int32_t * p_38, uint8_t  p_39, const uint8_t  p_40)
{ /* block id: 532 */
    int8_t **l_1154 = &g_682;
    int8_t **l_1155 = &g_682;
    uint16_t *l_1157 = &g_424;
    uint16_t **l_1156 = &l_1157;
    int32_t l_1166 = 0L;
    int32_t l_1167 = 8L;
    int32_t l_1168 = 0x6AF7C06FL;
    int32_t l_1172 = 0x42C67F53L;
    int32_t l_1173[7] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
    int i;
lbl_1180:
    (*g_33) |= (safe_rshift_func_uint16_t_u_u(((**l_1156) = (safe_rshift_func_int16_t_s_s(0x9155L, (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s((safe_mul_func_int8_t_s_s(((((1L < (-4L)) && (0xD31CL | (l_1167 = (safe_rshift_func_int16_t_s_s(((l_1155 = l_1154) != (((void*)0 != l_1156) , l_1154)), (l_1166 = ((*g_411) = (safe_lshift_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((safe_add_func_int32_t_s_s(((l_1166 , (*g_682)) & p_39), l_1166)), 0x4B203C75L)), 7UL)) <= 0xF2L), p_39))))))))) != l_1168) ^ 7L), 0UL)), (*g_682))), 0x249DL))))), 11));
    for (g_34 = 24; (g_34 != (-19)); --g_34)
    { /* block id: 541 */
        int32_t *l_1171[1][6];
        uint16_t l_1174 = 0UL;
        uint32_t *l_1178 = &g_260;
        uint32_t **l_1177 = &l_1178;
        uint32_t ***l_1179 = &l_1177;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 6; j++)
                l_1171[i][j] = &g_28[3];
        }
        --l_1174;
        (*l_1179) = l_1177;
    }
    if (l_1168)
        goto lbl_1181;
lbl_1181:
    if (g_34)
        goto lbl_1180;
    return (*g_682);
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_58 g_28 g_34 g_33 g_84 g_126 g_130 g_138 g_133 g_135 g_123 g_260 g_272 g_345 g_355 g_424 g_411 g_483 g_508 g_574 g_624 g_606 g_668 g_670 g_723 g_845 g_575 g_682 g_987 g_681 g_602
 * writes: g_58 g_81 g_84 g_28 g_123 g_126 g_130 g_133 g_135 g_260 g_138 g_272 g_370 g_397 g_411 g_412 g_424 g_355 g_483 g_508 g_599 g_602 g_606 g_624 g_845 g_681
 */
static int16_t  func_49(uint32_t  p_50, uint32_t  p_51, uint32_t * p_52, uint64_t  p_53, uint32_t * const  p_54)
{ /* block id: 8 */
    int32_t l_422[10][2] = {{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)},{(-2L),(-2L)}};
    uint16_t *l_423 = &g_424;
    int32_t *l_1116 = (void*)0;
    int32_t *l_1117 = &g_28[5];
    int32_t l_1122 = 0xAD0E50D0L;
    uint32_t l_1123[5][3] = {{0x8E071274L,0xE5958031L,0x8E071274L},{0x448E7BBEL,4294967295UL,0x448E7BBEL},{0x8E071274L,0xE5958031L,0x8E071274L},{0x448E7BBEL,4294967295UL,0x448E7BBEL},{0x8E071274L,0xE5958031L,0x8E071274L}};
    int64_t *l_1134[5][10][5] = {{{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825}},{{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825}},{{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825}},{{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825}},{{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825}}};
    uint32_t l_1135 = 4294967295UL;
    int32_t *l_1138 = &g_84;
    uint8_t l_1139 = 255UL;
    uint64_t *l_1140 = &g_606;
    int32_t *l_1141 = &l_1122;
    int i, j, k;
    (*l_1117) = func_59(((*l_423) = (func_63((g_17 , (func_68(&g_58) & (safe_sub_func_uint8_t_u_u(((((*l_423) = l_422[2][0]) != g_34) >= 65533UL), ((0xD6L || (safe_unary_minus_func_uint64_t_u(g_355))) , (((8L || g_34) == 0x6828L) , 0xD9L)))))), g_33, &g_34, g_17) & p_53)), g_668, l_422[4][1]);
    for (g_126 = 13; (g_126 == (-7)); g_126 = safe_sub_func_int64_t_s_s(g_126, 9))
    { /* block id: 520 */
        uint16_t l_1120 = 0x8927L;
        int32_t *l_1121[3][8] = {{&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,&g_34,&g_34},{&g_84,&g_34,&g_84,&g_84,&g_34,&g_84,&g_84,&g_34},{&g_34,&g_84,&g_84,&g_34,&g_84,&g_84,&g_34,&g_84}};
        int i, j;
        l_1122 |= ((*l_1117) = (l_1120 = 0xF316E873L));
    }
    (*l_1117) = ((l_1123[2][1] < (safe_sub_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(((((safe_sub_func_int8_t_s_s(((0x84EF7CF1DC5F02BCLL | ((safe_mul_func_int16_t_s_s((safe_mod_func_int16_t_s_s(((l_1135 = ((*g_723) = (*g_723))) ^ p_51), (g_138 ^ p_50))), (5L == (*l_1117)))) <= ((*l_1140) = (((*l_1138) ^= (safe_div_func_uint8_t_u_u((0xD3FB98D3L > (*l_1117)), p_50))) != l_1139)))) , (*g_682)), p_50)) == (*g_682)) | p_50) == 1L), p_50)), p_50))) > (*g_682));
    l_1141 = &g_28[3];
    return p_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_58 g_355 g_126 g_602 g_33 g_34 g_411 g_123 g_670 g_135 g_272 g_133 g_682 g_424 g_723 g_508 g_28 g_138 g_624 g_606 g_130
 * writes: g_58 g_355 g_130 g_28 g_424 g_599 g_272 g_397 g_133 g_681 g_624 g_138 g_123
 */
static int32_t  func_59(uint16_t  p_60, uint16_t  p_61, int8_t  p_62)
{ /* block id: 459 */
    int32_t l_1013 = 0x5E422D82L;
    int32_t l_1053[5][6][4] = {{{0x9ADA0B2CL,0x80CEF46BL,0xD2F17A43L,0x80CEF46BL},{0x33C21D07L,3L,0xBC29B25EL,0xD2F17A43L},{0x80CEF46BL,3L,0x9ADA0B2CL,3L},{0x9ADA0B2CL,3L,0x6E654381L,0xBC29B25EL},{0x9ADA0B2CL,0x6E654381L,0x9ADA0B2CL,0xD2F17A43L},{3L,0xBC29B25EL,0xD2F17A43L,0xD2F17A43L}},{{0x6E654381L,0x6E654381L,0x33C21D07L,0xBC29B25EL},{0xBC29B25EL,3L,0x33C21D07L,3L},{0x6E654381L,0x9ADA0B2CL,0xD2F17A43L,0x33C21D07L},{3L,0x9ADA0B2CL,0x9ADA0B2CL,3L},{0x9ADA0B2CL,3L,0x6E654381L,0xBC29B25EL},{0x9ADA0B2CL,0x6E654381L,0x9ADA0B2CL,0xD2F17A43L}},{{3L,0xBC29B25EL,0xD2F17A43L,0xD2F17A43L},{0x6E654381L,0x6E654381L,0x33C21D07L,0xBC29B25EL},{0xBC29B25EL,3L,0x33C21D07L,3L},{0x6E654381L,0x9ADA0B2CL,0xD2F17A43L,0x33C21D07L},{3L,0x9ADA0B2CL,0x9ADA0B2CL,3L},{0x9ADA0B2CL,3L,0x6E654381L,0xBC29B25EL}},{{0x9ADA0B2CL,0x6E654381L,0x9ADA0B2CL,0xD2F17A43L},{3L,0xBC29B25EL,0xD2F17A43L,0xD2F17A43L},{0x6E654381L,0x6E654381L,0x33C21D07L,0xBC29B25EL},{0xBC29B25EL,3L,0x33C21D07L,3L},{0x6E654381L,0x9ADA0B2CL,0xD2F17A43L,0x33C21D07L},{3L,0x9ADA0B2CL,0x9ADA0B2CL,3L}},{{0x9ADA0B2CL,3L,0x6E654381L,0xBC29B25EL},{0x9ADA0B2CL,0x6E654381L,0x9ADA0B2CL,0xD2F17A43L},{3L,0xBC29B25EL,0xD2F17A43L,0xD2F17A43L},{0x6E654381L,0x6E654381L,0x33C21D07L,0xBC29B25EL},{0xBC29B25EL,3L,0x33C21D07L,3L},{0x6E654381L,0x9ADA0B2CL,0xD2F17A43L,0x33C21D07L}}};
    int32_t l_1055 = 0xC385DED9L;
    int32_t l_1067[5][8][6] = {{{(-1L),(-9L),(-1L),0x01F32F2EL,(-4L),(-1L)},{0x36C78F6EL,0L,0xE0607966L,0x3B4B45A1L,0x709693ECL,(-1L)},{0xDBD53318L,0x618AE52CL,0xE0607966L,0L,(-9L),(-1L)},{0xE8B2AAB6L,0x402472E0L,(-1L),0x423A611BL,0x4D1B414CL,0xA3709CA5L},{0x423A611BL,0x4D1B414CL,0xA3709CA5L,(-1L),1L,1L},{0xF2C8F963L,0L,0x39A0418CL,0L,0xDBD53318L,0x4855A327L},{0xBCBB0921L,0x3B4B45A1L,0xB32A1D05L,0L,4L,0x7AE72572L},{0x36C78F6EL,5L,0x2174DA2DL,0L,1L,0x39A0418CL}},{{(-9L),0x1E988D74L,(-1L),0L,0x605411FEL,0x39A0418CL},{0xC9B7B3D4L,0x402472E0L,0x2174DA2DL,4L,0x6F5FDB87L,0x7AE72572L},{0x4D1B414CL,0x36C78F6EL,0xB32A1D05L,(-9L),0x709693ECL,0x4855A327L},{0x605411FEL,0x6CDB2A1DL,0x39A0418CL,0xBCBB0921L,0x8A8E9A06L,1L},{0xC9B7B3D4L,(-9L),0xA3709CA5L,5L,5L,0xA3709CA5L},{0x6F5FDB87L,0x6F5FDB87L,0x36C78F6EL,(-5L),(-1L),0x4D1B414CL},{0xCE9E2016L,0x8ADFF74BL,5L,0xFDD3558FL,(-1L),0x36C78F6EL},{(-3L),0xCE9E2016L,5L,0xF78A35EFL,(-1L),0x4D1B414CL}},{{0xB2096FD0L,0xF78A35EFL,0x36C78F6EL,0x3F2F0C35L,0xC4121307L,0x423A611BL},{0x3F2F0C35L,0xC4121307L,0x423A611BL,0L,3L,0L},{1L,(-3L),0L,0xF78A35EFL,(-8L),0x01F32F2EL},{(-8L),0L,0xA8E33DD5L,3L,(-3L),(-4L)},{0xCE9E2016L,0L,(-5L),(-6L),3L,0L},{0x0DABAE3BL,1L,0x4D1B414CL,1L,0xE47673BCL,0L},{0x64B9AD72L,0xF78A35EFL,(-5L),0x00BDA49FL,0x0DABAE3BL,(-4L)},{1L,0x2BCD9C65L,0xA8E33DD5L,0x0DABAE3BL,(-1L),0x01F32F2EL}},{{0xC4121307L,0xC60174AFL,0L,(-8L),1L,0L},{0x64B9AD72L,(-1L),0x423A611BL,(-3L),0L,0x423A611BL},{0xBC2721E5L,0x0DABAE3BL,0x36C78F6EL,(-6L),0L,0x4D1B414CL},{0x2BCD9C65L,0xC60174AFL,5L,0L,2L,0x36C78F6EL},{(-8L),0xCC5E7D7EL,5L,0x376E3EE1L,0x0DABAE3BL,0x4D1B414CL},{1L,0L,0x36C78F6EL,0L,1L,0x423A611BL},{0L,1L,0x423A611BL,(-8L),0L,0L},{0xB2096FD0L,1L,0L,0x376E3EE1L,(-3L),0x01F32F2EL}},{{0x00BDA49FL,0xFDD3558FL,0xA8E33DD5L,0xFDD3558FL,0x00BDA49FL,(-4L)},{0x2BCD9C65L,(-3L),(-5L),0x64B9AD72L,0L,0L},{(-1L),0xE47673BCL,0x4D1B414CL,(-3L),0xC4121307L,0L},{(-5L),0L,(-5L),(-3L),0xBC2721E5L,(-4L)},{0xC4121307L,0xCE9E2016L,0xA8E33DD5L,(-1L),2L,0x01F32F2EL},{0xE47673BCL,(-1L),0L,0x00BDA49FL,(-1L),0L},{(-5L),0x0DABAE3BL,0x423A611BL,0L,(-3L),0x423A611BL},{0x0DABAE3BL,0xBC2721E5L,0x36C78F6EL,0x64B9AD72L,1L,0x4D1B414CL}}};
    uint8_t *l_1078 = &g_133;
    int8_t **l_1083[6] = {(void*)0,(void*)0,&g_682,(void*)0,(void*)0,&g_682};
    int8_t ***l_1084[6] = {&g_681,&g_681,&g_681,&g_681,&g_681,&g_681};
    int64_t *l_1085[6][5] = {{&g_825,&g_825,&g_825,&g_825,&g_825},{(void*)0,&g_825,(void*)0,&g_825,(void*)0},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{&g_825,&g_825,&g_825,&g_825,&g_825},{(void*)0,&g_825,(void*)0,&g_825,(void*)0}};
    int32_t *l_1086 = (void*)0;
    int32_t *l_1087 = (void*)0;
    int32_t *l_1088[3][1][3];
    int32_t l_1089 = (-3L);
    uint16_t *l_1109 = &g_138;
    uint64_t *l_1113 = &g_606;
    uint64_t **l_1112 = &l_1113;
    int32_t l_1114 = (-1L);
    int32_t *l_1115 = &l_1053[1][0][2];
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
                l_1088[i][j][k] = &g_84;
        }
    }
    for (g_58 = (-7); (g_58 == 16); ++g_58)
    { /* block id: 462 */
        int32_t l_1046 = 0x992F33A3L;
        uint32_t l_1049 = 0x7F558EDCL;
        int32_t l_1057 = (-1L);
        int8_t l_1058 = 8L;
        int32_t l_1059 = 0xA629AB02L;
        uint16_t l_1060 = 0UL;
        if (p_61)
            break;
        for (g_355 = 0; (g_355 <= 3); g_355 += 1)
        { /* block id: 466 */
            int32_t l_1014 = (-1L);
            int8_t **l_1015 = &g_682;
            int32_t *l_1016[7];
            uint16_t *l_1030 = &g_138;
            uint16_t *l_1031 = (void*)0;
            int i;
            for (i = 0; i < 7; i++)
                l_1016[i] = &g_28[7];
            g_28[3] = (safe_add_func_uint8_t_u_u(0xA1L, ((((((g_130[g_355] = 8L) == l_1013) == g_126) == l_1014) > (l_1015 != (((void*)0 != &g_28[8]) , &g_575[2][8][0]))) <= g_355)));
            for (p_62 = 0; (p_62 <= 3); p_62 += 1)
            { /* block id: 471 */
                int32_t l_1045 = 0x40E062BCL;
                int32_t l_1056 = 0xB7D4EDEBL;
                uint32_t l_1063 = 0x82C726B1L;
                for (p_61 = 0; (p_61 <= 1); p_61 += 1)
                { /* block id: 474 */
                    uint16_t l_1025 = 0x6033L;
                    int32_t l_1047[9];
                    int32_t l_1054 = (-3L);
                    int i;
                    for (i = 0; i < 9; i++)
                        l_1047[i] = (-4L);
                    for (g_424 = 0; (g_424 <= 3); g_424 += 1)
                    { /* block id: 477 */
                        uint32_t l_1021 = 18446744073709551607UL;
                        uint16_t *l_1029 = &g_138;
                        uint16_t **l_1028[2];
                        uint32_t *l_1048 = &g_599;
                        int32_t l_1050 = 0x652DCA85L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1028[i] = &l_1029;
                        l_1013 = ((((*l_1048) = (l_1047[4] ^= ((safe_add_func_uint8_t_u_u((safe_add_func_uint8_t_u_u(g_602, ((l_1021 < (safe_rshift_func_int16_t_s_s((!p_62), 14))) > l_1025))), (((safe_mod_func_uint64_t_u_u(0UL, (((((l_1030 = &g_138) != (l_1031 = &g_424)) && (!((((safe_div_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s((safe_add_func_uint64_t_u_u(((((safe_add_func_uint32_t_u_u((((7L & (safe_div_func_int16_t_s_s(((safe_rshift_func_uint8_t_u_u((l_1045 < p_60), 5)) <= (*g_33)), p_60))) <= p_60) | (*g_411)), 0x2BB18D5BL)) && 0xC2L) , g_670[4][3]) , p_62), l_1045)), p_61)), 0x1FECF77C5B813367LL)) , l_1046) == (*g_33)) <= p_60))) , l_1013) || g_135[0][5]))) != l_1021) , p_61))) > p_60))) >= l_1049) , 0x6DE4548CL);
                        l_1050 |= (-9L);
                        l_1045 = l_1047[4];
                    }
                    for (g_272 = 0; (g_272 <= 1); g_272 += 1)
                    { /* block id: 488 */
                        int64_t l_1051 = 0x2361FC6323FCF1FDLL;
                        int32_t l_1052 = 1L;
                        int32_t **l_1064 = &g_397;
                        --l_1060;
                        l_1063 = (*g_33);
                        l_1059 = (g_135[4][6] == 0xEBA4L);
                        (*l_1064) = func_31(l_1052);
                    }
                }
            }
        }
    }
    for (g_355 = (-10); (g_355 >= (-13)); g_355 = safe_sub_func_uint64_t_u_u(g_355, 4))
    { /* block id: 500 */
        l_1067[4][7][2] = (*g_33);
    }
    g_28[7] &= ((((safe_rshift_func_int16_t_s_s((((((((safe_sub_func_uint64_t_u_u(((l_1067[2][7][2] ^ (safe_mod_func_uint16_t_u_u(p_62, l_1053[1][0][2]))) , ((l_1055 > ((l_1089 = (((safe_div_func_uint64_t_u_u(((l_1053[1][5][1] = (safe_div_func_int64_t_s_s(((*g_723) = (p_60 < (((*l_1078) |= p_62) && (safe_sub_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(((*g_682) = (l_1083[1] != (g_681 = l_1083[4]))), (g_424 > p_60))), l_1055))))), 0xC8E5EDFDFE6D41E5LL))) ^ l_1013), p_61)) , p_60) , l_1067[4][7][2])) , p_61)) != 0x96BBL)), g_424)) , p_60) , p_61) | g_126) ^ p_62) || g_508[3][2][5]) || g_135[1][4]), 12)) && p_61) || p_62) != 0x74AC2F0DL);
    (*l_1115) |= (((safe_add_func_uint8_t_u_u((safe_div_func_int32_t_s_s((p_61 , ((safe_sub_func_int64_t_s_s((safe_div_func_int16_t_s_s((safe_div_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u(((p_60 < p_62) & (((((*g_682) = (((((((((*g_411) = (p_60 >= (safe_mod_func_int64_t_s_s(((*g_723) = (((safe_sub_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(((++(*l_1109)) && ((*g_682) == ((5L > ((l_1088[0][0][1] = &g_84) != (void*)0)) , p_60))), g_272)) , 0x35F9L), p_62)) != 0xA0F54927L) >= g_606)), g_130[0])))) > 1UL) | 1L) <= g_34) && 0x4AD6L) && (*g_33)) , (void*)0) != l_1112)) , p_60) >= p_61) & p_61)))), g_670[3][5])), p_61)), l_1114)), 8UL)) != p_60)), p_61)), p_60)) | p_61) , p_60);
    return (*g_33);
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_84 g_424 g_126 g_133 g_28 g_130 g_272 g_33 g_135 g_17 g_411 g_123 g_483 g_58 g_508 g_138 g_355 g_574 g_624 g_606 g_668 g_670 g_723 g_845 g_575 g_682 g_987 g_681
 * writes: g_84 g_130 g_126 g_355 g_28 g_133 g_272 g_483 g_123 g_58 g_508 g_260 g_424 g_138 g_599 g_602 g_606 g_624 g_845
 */
static int16_t  func_63(uint32_t  p_64, uint32_t * p_65, int32_t * p_66, int8_t  p_67)
{ /* block id: 187 */
    uint8_t *l_431 = (void*)0;
    int32_t *l_434[9][1];
    int8_t *l_438 = &g_130[0];
    int16_t *l_455 = &g_123;
    const uint8_t l_456 = 255UL;
    uint32_t l_457[2][1];
    uint8_t l_522 = 0xB3L;
    uint16_t l_534 = 0UL;
    int16_t l_585 = 9L;
    int64_t l_603 = 0x816F46191668E984LL;
    uint16_t l_634 = 65535UL;
    uint32_t l_639 = 0UL;
    int8_t **l_685 = &l_438;
    uint32_t l_808 = 9UL;
    int16_t l_821 = 0x0D32L;
    uint16_t l_846[8][3] = {{0x8F78L,0x8F78L,0x8F78L},{0x9F1DL,0x9F1DL,0x9F1DL},{0x8F78L,0x8F78L,0x8F78L},{0x9F1DL,0x9F1DL,0x9F1DL},{0x8F78L,0x8F78L,0x8F78L},{0x9F1DL,0x9F1DL,0x9F1DL},{0x8F78L,0x8F78L,0x8F78L},{0x9F1DL,0x9F1DL,0x9F1DL}};
    int64_t l_935 = (-4L);
    uint32_t l_957 = 0x2D38CBF8L;
    int i, j;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
            l_434[i][j] = &g_84;
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_457[i][j] = 8UL;
    }
    if ((!(safe_mod_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u(0x67L, ((&g_272 != l_431) & (safe_mul_func_int8_t_s_s((((((g_84 ^= (*p_66)) | (*p_65)) | g_424) < 0x7CD549C3L) > (+(safe_sub_func_uint32_t_u_u(((p_67 = ((*l_438) = (g_126 , (((g_126 || 4UL) , p_64) == 1UL)))) & g_133), g_28[3])))), g_28[3]))))) && 0x2EL), (*p_66)))))
    { /* block id: 191 */
        int64_t l_461 = 0x7ADA7AEEE0C199E5LL;
        int32_t l_467[10] = {0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L,0xFDD7AFA0L};
        int32_t l_524 = 0xA882F606L;
        uint64_t * const l_605 = &g_606;
        int32_t l_628 = 0xB9DF8E0AL;
        int32_t **l_677 = &l_434[7][0];
        int32_t ***l_676 = &l_677;
        uint8_t *l_843 = &l_522;
        int i;
        for (g_126 = (-22); (g_126 < 18); g_126++)
        { /* block id: 194 */
            int16_t **l_454[8][10][3] = {{{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]}},{{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411}},{{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]}},{{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411}},{{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],(void*)0,&g_412[1][1]},{(void*)0,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_412[1][1],(void*)0,&g_411},{&g_412[1][1],&g_412[1][1],&g_411},{(void*)0,&g_412[1][1],&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]}},{{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_411,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_411,&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411}},{{&g_411,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_411,&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_411,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_411,&g_411}},{{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_411},{&g_411,&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_411,&g_411},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]},{&g_412[1][1],&g_412[1][1],&g_412[1][1]}}};
            int64_t *l_458 = (void*)0;
            int64_t *l_459[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            const int32_t l_460 = 0x3C8BC51BL;
            uint32_t **l_464 = &g_81;
            int64_t l_486 = 0x99E091EBE8FB2D6DLL;
            int32_t l_489 = (-1L);
            int32_t l_559 = 1L;
            int32_t l_560 = 0xF4849F9EL;
            int32_t l_564 = 5L;
            int32_t l_627 = 0xAAAD6D2AL;
            int32_t l_629 = 6L;
            int i, j, k;
            g_28[3] |= ((0UL <= (!g_130[2])) , (safe_mul_func_uint16_t_u_u(0xBEAAL, (((((g_355 = (safe_div_func_int16_t_s_s((-1L), (safe_add_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((safe_lshift_func_int16_t_s_u((safe_add_func_uint64_t_u_u(((l_455 = (void*)0) != (p_64 , &g_135[3][5])), (((1UL != (p_67 || l_456)) || p_64) >= 0UL))), 11)), p_67)), l_457[0][0]))))) ^ g_272) | p_64) | l_460) , l_460))));
            if ((*g_33))
                continue;
            if (l_461)
            { /* block id: 199 */
                int8_t **l_462[7][6][4] = {{{&l_438,&l_438,&l_438,&l_438},{(void*)0,&l_438,&l_438,&l_438},{(void*)0,(void*)0,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,(void*)0,(void*)0,&l_438},{&l_438,&l_438,&l_438,&l_438}},{{(void*)0,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{(void*)0,(void*)0,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,(void*)0}},{{(void*)0,&l_438,&l_438,(void*)0},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{(void*)0,(void*)0,&l_438,(void*)0},{&l_438,&l_438,(void*)0,&l_438},{&l_438,(void*)0,&l_438,(void*)0}},{{&l_438,(void*)0,&l_438,&l_438},{(void*)0,&l_438,&l_438,(void*)0},{(void*)0,(void*)0,&l_438,&l_438},{&l_438,&l_438,(void*)0,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,(void*)0,&l_438,&l_438}},{{&l_438,&l_438,&l_438,(void*)0},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,&l_438,(void*)0},{(void*)0,&l_438,&l_438,(void*)0}},{{(void*)0,(void*)0,&l_438,&l_438},{&l_438,&l_438,(void*)0,&l_438},{&l_438,(void*)0,&l_438,&l_438},{&l_438,&l_438,&l_438,&l_438},{&l_438,(void*)0,&l_438,(void*)0},{&l_438,&l_438,(void*)0,(void*)0}},{{&l_438,&l_438,&l_438,&l_438},{&l_438,&l_438,(void*)0,&l_438},{&l_438,&l_438,&l_438,&l_438},{(void*)0,&l_438,&l_438,(void*)0},{(void*)0,&l_438,&l_438,&l_438},{&l_438,(void*)0,(void*)0,&l_438}}};
                int8_t *l_463 = &g_130[1];
                int i, j, k;
                g_28[4] = ((0x9D32B5142B55E2A2LL == (&p_67 == (l_463 = &p_67))) && (l_464 == (void*)0));
            }
            else
            { /* block id: 202 */
                int16_t l_466[2];
                uint8_t *l_470 = &g_133;
                int32_t l_544 = 0xBA0133BAL;
                const uint32_t *l_553 = &g_58;
                const uint32_t **l_552[9][3] = {{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553},{&l_553,(void*)0,&l_553}};
                int32_t l_562[6][8] = {{(-7L),1L,0L,0L,1L,(-7L),0L,0x647C408AL},{1L,(-7L),0L,0x647C408AL,0xEE81DAB2L,0L,(-8L),0xEE81DAB2L},{0x647C408AL,0xF9A6021FL,0x052F839DL,0x647C408AL,0xF945046CL,0x975D16A3L,0xF945046CL,0x647C408AL},{(-9L),0xF945046CL,(-9L),0L,0x55048935L,0L,0L,0xF9A6021FL},{0xF945046CL,3L,0L,1L,0x2103EF35L,0xEE81DAB2L,0x55048935L,3L},{0xF945046CL,0xF9A6021FL,4L,0x55048935L,0x55048935L,4L,0xF9A6021FL,0xF945046CL}};
                uint64_t * const l_604 = (void*)0;
                uint32_t l_642 = 4294967295UL;
                int i, j;
                for (i = 0; i < 2; i++)
                    l_466[i] = 0xD988L;
                l_467[9] = (g_28[0] = (+l_466[1]));
                if (((g_126 ^ (safe_sub_func_uint8_t_u_u((--(*l_470)), g_130[0]))) <= ((safe_mod_func_int64_t_s_s(g_135[3][0], ((((safe_lshift_func_uint16_t_u_s((l_460 , l_460), ((*g_411) = ((((safe_mod_func_int16_t_s_s((0UL == (safe_mul_func_uint8_t_u_u((g_272 |= g_17), ((((((l_467[7] = (*g_411)) | ((safe_add_func_int32_t_s_s(((g_483--) == (-5L)), (*g_33))) && (*g_33))) , (void*)0) == l_464) , g_58) == 4L)))), (*g_411))) ^ 0x3E39L) , l_454[5][8][0]) == &g_412[2][8])))) , (*p_66)) & 0UL) ^ l_486))) , (-5L))))
                { /* block id: 210 */
                    for (g_58 = 0; (g_58 <= 0); g_58 += 1)
                    { /* block id: 213 */
                        int i, j;
                        if (l_457[(g_58 + 1)][g_58])
                            break;
                        if (l_457[g_58][g_58])
                            break;
                        if (l_457[g_58][g_58])
                            continue;
                    }
                }
                else
                { /* block id: 218 */
                    int8_t l_495 = 3L;
                    int32_t l_496 = 0x40362993L;
                    int32_t *l_507[6][10][4] = {{{(void*)0,(void*)0,(void*)0,&g_508[4][4][2]},{&g_508[4][4][2],&g_508[6][2][6],&g_508[4][3][3],&g_508[4][4][2]},{&g_508[1][1][1],&g_508[4][4][2],(void*)0,&g_508[6][2][6]},{&g_508[4][4][2],(void*)0,(void*)0,(void*)0},{&g_508[1][1][1],&g_508[1][1][1],&g_508[4][3][3],&g_508[4][4][2]},{&g_508[4][4][2],&g_508[5][1][1],(void*)0,&g_508[6][2][6]},{(void*)0,&g_508[6][2][6],&g_508[4][4][2],(void*)0},{&g_508[1][1][1],&g_508[6][2][6],&g_508[4][4][2],&g_508[6][2][6]},{&g_508[6][2][6],&g_508[5][1][1],(void*)0,&g_508[5][1][1]},{&g_508[4][3][3],&g_508[4][4][2],&g_508[4][4][2],(void*)0}},{{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][3][3],(void*)0,(void*)0,&g_508[4][4][2]},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][4][2],&g_508[4][3][3],&g_508[4][4][2],&g_508[5][1][1]},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2]},{(void*)0,(void*)0,&g_508[4][4][2],(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[5][1][1]}},{{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][4][2],(void*)0,&g_508[4][4][2],&g_508[4][4][2]},{&g_508[4][4][2],(void*)0,(void*)0,(void*)0},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][3][3],&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][3][3],(void*)0,(void*)0,&g_508[4][4][2]},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][4][2],&g_508[4][3][3],&g_508[4][4][2],&g_508[5][1][1]}},{{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2]},{(void*)0,(void*)0,&g_508[4][4][2],(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[5][1][1]},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][4][2],(void*)0,&g_508[4][4][2],&g_508[4][4][2]},{&g_508[4][4][2],(void*)0,(void*)0,(void*)0},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][3][3],&g_508[4][4][2],&g_508[4][4][2],(void*)0}},{{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][3][3],(void*)0,(void*)0,&g_508[4][4][2]},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][4][2],&g_508[4][3][3],&g_508[4][4][2],&g_508[5][1][1]},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2]},{(void*)0,(void*)0,&g_508[4][4][2],(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],(void*)0,(void*)0},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[5][1][1]}},{{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][4][2],(void*)0,&g_508[4][4][2],&g_508[4][4][2]},{&g_508[4][4][2],(void*)0,(void*)0,(void*)0},{(void*)0,&g_508[4][4][2],(void*)0,&g_508[5][1][1]},{&g_508[4][3][3],&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{(void*)0,&g_508[4][4][2],&g_508[4][4][2],(void*)0},{&g_508[4][4][2],&g_508[4][4][2],&g_508[1][1][1],&g_508[4][4][2]},{&g_508[4][4][2],&g_508[4][3][3],&g_508[4][4][2],&g_508[4][4][2]},{&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2],&g_508[4][4][2]}}};
                    uint32_t *l_509[2][2][9] = {{{&l_457[1][0],&l_457[0][0],&l_457[0][0],&l_457[0][0],&l_457[1][0],&g_260,&g_260,&l_457[1][0],&l_457[0][0]},{&l_457[0][0],&l_457[0][0],&l_457[0][0],(void*)0,&g_260,&g_260,(void*)0,&l_457[0][0],&l_457[0][0]}},{{&l_457[0][0],&g_260,&g_260,&l_457[0][0],&l_457[0][0],&g_260,&g_260,&l_457[0][0],&g_260},{&g_260,&g_260,(void*)0,(void*)0,&g_260,&g_260,&g_260,&g_260,&g_260}}};
                    int32_t **l_510 = &l_434[7][0];
                    const uint16_t l_523 = 1UL;
                    int i, j, k;
                    (*l_510) = func_31(((((((safe_lshift_func_uint8_t_u_u(((-1L) <= (l_489 = l_486)), (((safe_mod_func_int16_t_s_s((safe_unary_minus_func_int32_t_s((safe_div_func_uint16_t_u_u((l_495 &= 3UL), l_496)))), (safe_mod_func_uint32_t_u_u(((((safe_mul_func_int8_t_s_s((g_424 > (((((g_260 = ((safe_sub_func_int16_t_s_s(l_496, (safe_sub_func_int32_t_s_s((((0x802EL && (p_64 , ((((g_508[4][4][2] |= (safe_lshift_func_uint8_t_u_u(((void*)0 != &p_67), g_272))) , (*p_65)) , (*p_66)) == l_467[9]))) <= p_67) || 0x53L), l_496)))) , l_467[1])) , l_461) < l_466[1]) , 0UL) && 4UL)), 0UL)) , g_483) == p_67) & (*g_33)), (*p_66))))) , l_486) && l_496))) == p_64) < p_67) != (*p_65)) == 4UL) && p_64));
                    if (l_467[4])
                        break;
                    if ((*p_66))
                    { /* block id: 225 */
                        uint16_t *l_521 = &g_424;
                        int8_t l_527[9] = {0xCBL,0x87L,0xCBL,0xCBL,0x87L,0xCBL,0xCBL,0x87L,0xCBL};
                        int i;
                        l_524 &= (((((safe_mod_func_uint64_t_u_u(0xB1DCFD8ECBEC1ACBLL, ((((254UL > (safe_sub_func_int32_t_s_s((safe_unary_minus_func_int32_t_s((l_466[1] | ((((0x9957L == ((p_67 & l_466[0]) == ((((*l_470)++) == (safe_div_func_int8_t_s_s((p_67 <= (!p_64)), ((l_467[9] ^= (((*l_521) = l_460) != 0xD2EEL)) ^ (**l_510))))) | 65527UL))) <= l_489) != l_522) ^ (*g_33))))), l_523))) == (-5L)) && l_489) ^ 0x6FF948422053B2D4LL))) , p_67) == g_130[0]) >= (**l_510)) , l_486);
                        if (l_466[1])
                            continue;
                        l_534 |= (safe_rshift_func_int16_t_s_u(l_527[4], ((safe_lshift_func_uint16_t_u_s(((l_466[1] , 0xBEL) > ((safe_add_func_int16_t_s_s(p_64, 0x6BD9L)) , (p_64 > (**l_510)))), 0)) <= g_508[0][3][2])));
                        g_84 |= (safe_sub_func_int32_t_s_s((safe_sub_func_int8_t_s_s(((*l_438) &= (-6L)), 0x8EL)), 0x28D43EC5L));
                    }
                    else
                    { /* block id: 234 */
                        uint16_t *l_541 = &g_138;
                        int32_t l_545 = 0xC453A6D9L;
                        uint32_t *l_554 = &g_58;
                        l_545 = (safe_lshift_func_uint16_t_u_s((l_544 ^= ((*l_541)--)), 3));
                        g_84 = (p_67 | ((safe_add_func_int16_t_s_s(((((((((*g_411) = (safe_add_func_uint16_t_u_u(0xD667L, ((safe_div_func_int32_t_s_s((((((void*)0 != l_552[3][0]) & g_58) == ((void*)0 != l_554)) || 0x6C92B84BL), (safe_sub_func_int8_t_s_s(((*p_65) && (**l_510)), 0x3AL)))) >= p_67)))) || 1L) || l_524) , &l_523) != &g_424) , p_66) != (void*)0), p_64)) ^ (-1L)));
                        (*l_510) = func_31((safe_mod_func_int32_t_s_s((*p_66), (*p_66))));
                        l_545 ^= l_544;
                    }
                }
                for (l_534 = 0; (l_534 <= 2); l_534 += 1)
                { /* block id: 246 */
                    int32_t l_561 = 0x381AE926L;
                    int32_t l_563 = (-1L);
                    uint32_t l_565 = 1UL;
                    int i;
                    l_565--;
                    return p_67;
                }
                for (g_355 = 16; (g_355 == (-23)); --g_355)
                { /* block id: 252 */
                    uint16_t *l_586 = &g_424;
                    uint32_t *l_597 = &g_58;
                    uint32_t *l_598 = &g_599;
                    int32_t l_600 = (-1L);
                    uint64_t *l_601 = &g_602;
                    uint8_t *l_621 = &g_272;
                    uint8_t *l_622 = &g_483;
                    int8_t *l_623 = &g_624;
                    int32_t l_625 = 0x85C223F3L;
                    int16_t l_626[6][2] = {{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}};
                    int16_t l_633[3][7] = {{0L,3L,0xA32EL,0xA32EL,3L,0L,3L},{0x7679L,0xFBF6L,0xFBF6L,0x7679L,1L,0x7679L,0xFBF6L},{0xC438L,0xC438L,0L,0xA32EL,0L,0xC438L,0xC438L}};
                    int i, j;
                    g_28[6] &= (((l_461 & ((*l_605) = (((safe_sub_func_int8_t_s_s((((((((void*)0 == g_574) , (((((*l_586) ^= l_585) & ((*g_411) &= 0x6964L)) != ((*l_601) = (safe_lshift_func_uint8_t_u_s(((((((safe_lshift_func_uint8_t_u_s((safe_mul_func_int8_t_s_s((safe_div_func_uint32_t_u_u((safe_div_func_int16_t_s_s((0xFBBF288D6D0DACD2LL & (((*l_598) = ((*l_597) &= ((&l_455 == &l_455) , 6UL))) || 0xFEC6212AL)), (-10L))), l_600)), g_508[6][4][0])), 3)) > (-5L)) , g_508[4][4][2]) , l_489) >= l_600) , g_17), 5)))) , 0L)) & l_544) && l_603) && 0L) != (*g_33)), p_67)) , l_604) == l_605))) != p_67) & p_67);
                    if (((((safe_mul_func_uint16_t_u_u(1UL, p_64)) >= (((((((safe_div_func_uint8_t_u_u(l_544, ((((*l_623) |= (((p_64 , ((((*l_622) = ((*l_621) = ((*l_470) = (safe_mod_func_int8_t_s_s(((l_438 == (((safe_rshift_func_int16_t_s_s((safe_mod_func_int16_t_s_s((g_424 , (0x3AD338A6L & (safe_mul_func_uint8_t_u_u((0x81L >= ((*l_438) = l_562[2][2])), (-10L))))), g_424)), (*g_411))) ^ 0xF0L) , (void*)0)) | 0UL), g_123))))) & p_67) | p_67)) != p_64) <= l_562[5][2])) || p_64) , p_64))) != l_466[0]) != l_600) != l_562[4][0]) > 0x82L) , 252UL) & (-2L))) || (*p_65)) | p_64))
                    { /* block id: 265 */
                        uint32_t l_630[2][7][1] = {{{1UL},{0xF1447B60L},{0xF1447B60L},{1UL},{0xF1447B60L},{0xF1447B60L},{1UL}},{{0xF1447B60L},{0xF1447B60L},{1UL},{0xF1447B60L},{0xF1447B60L},{1UL},{0xF1447B60L}}};
                        int i, j, k;
                        l_564 = (*p_66);
                        if (l_600)
                            continue;
                        l_630[0][5][0]--;
                        return p_64;
                    }
                    else
                    { /* block id: 270 */
                        int32_t l_637 = 0L;
                        int32_t l_638 = 0xBA4F0C70L;
                        --l_634;
                        --l_639;
                        l_642 |= 0x867835DDL;
                    }
                }
            }
        }
        if (g_17)
            goto lbl_675;
lbl_675:
        for (l_639 = 25; (l_639 >= 12); --l_639)
        { /* block id: 280 */
            int32_t l_647[9] = {0L,0x0FDFF18DL,0x0FDFF18DL,0L,0x0FDFF18DL,0x0FDFF18DL,0L,0x0FDFF18DL,0x0FDFF18DL};
            int32_t l_648[1];
            int32_t l_666[6][1][2] = {{{0x3D5C4D13L,0x3D5C4D13L}},{{0x3D5C4D13L,0x3D5C4D13L}},{{0x3D5C4D13L,0x3D5C4D13L}},{{0x3D5C4D13L,0x3D5C4D13L}},{{0x3D5C4D13L,0x3D5C4D13L}},{{0x3D5C4D13L,0x3D5C4D13L}}};
            int16_t l_667 = 0xFB10L;
            uint16_t *l_669[9];
            int32_t **l_671 = &l_434[4][0];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_648[i] = 0x83BCC658L;
            for (i = 0; i < 9; i++)
                l_669[i] = (void*)0;
            (*l_671) = func_31(((safe_div_func_int32_t_s_s((l_648[0] = l_647[6]), (safe_add_func_int16_t_s_s((4L >= g_508[0][4][2]), (l_467[9] = (((&g_135[4][6] != (void*)0) , (safe_mul_func_int8_t_s_s(((safe_div_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u(g_483, (0x93E7F5E4456736A0LL < ((((safe_add_func_uint16_t_u_u(l_461, (safe_mod_func_uint32_t_u_u((+((*l_605) ^= (((safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s(0xBBL, l_647[4])), 2)) , (void*)0) != &g_599))), (-9L))))) , 0x200BL) , l_666[3][0][0]) >= 0x7777C7FFL)))) > p_67), l_667)) || p_64), g_668))) | g_138)))))) , g_670[6][2]));
            if ((*g_33))
                continue;
            for (l_524 = 0; (l_524 <= 0); l_524 += 1)
            { /* block id: 288 */
                uint32_t l_672 = 0x016FEDC3L;
                for (g_133 = 0; (g_133 <= 0); g_133 += 1)
                { /* block id: 291 */
                    int i;
                    l_672++;
                }
            }
        }
        (*l_676) = &l_434[0][0];
        if ((safe_add_func_int8_t_s_s(((**l_677) , 0x8AL), (safe_unary_minus_func_uint16_t_u(p_64)))))
        { /* block id: 298 */
            int32_t l_709 = 0xA7F1EFE3L;
            int16_t l_717[9][9] = {{0xE6D1L,0x5636L,0x5636L,0xE6D1L,(-1L),0L,(-1L),0xE6D1L,0x5636L},{(-7L),0L,0x0228L,1L,0xC390L,1L,0x0228L,0L,(-7L)},{0x5636L,0xE6D1L,(-1L),0L,(-1L),0xE6D1L,0x5636L,0x5636L,0xE6D1L},{0L,0xF8CDL,0x0228L,0xF8CDL,0L,0x26C9L,0L,1L,5L},{0x5636L,(-1L),0x5636L,1L,0xEB9CL,0xEB9CL,1L,0x5636L,(-1L)},{(-7L),(-4L),0L,0x3058L,0x0228L,0x26C9L,(-7L),0L,(-7L)},{0xE6D1L,0L,1L,1L,0L,0xE6D1L,0xEB9CL,0xE6D1L,0L},{(-7L),1L,0L,(-4L),0xC390L,0x26C9L,0xC390L,(-4L),0L},{0x17F7L,0x17F7L,(-1L),1L,0xE6D1L,1L,(-1L),0x17F7L,0x17F7L}};
            int32_t l_728[3];
            int8_t ***l_790 = &g_681;
            int32_t l_810 = 0x1400A1CFL;
            uint32_t l_833[3];
            uint8_t **l_844[1][2];
            int i, j;
            for (i = 0; i < 3; i++)
                l_728[i] = 7L;
            for (i = 0; i < 3; i++)
                l_833[i] = 0xBD9462D0L;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_844[i][j] = (void*)0;
            }
            for (l_603 = 0; (l_603 <= 4); l_603 += 1)
            { /* block id: 301 */
                int8_t ***l_683 = (void*)0;
                int8_t ***l_684[4][4][2] = {{{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681}},{{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681}},{{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681}},{{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681},{&g_681,&g_681}}};
                int32_t l_708 = (-1L);
                int64_t *l_720 = &l_461;
                uint32_t **l_725[7][6] = {{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81},{&g_81,&g_81,&g_81,&g_81,&g_81,&g_81}};
                int8_t ****l_791 = &l_683;
                int16_t **l_802 = &g_412[0][5];
                int16_t *l_803 = &l_585;
                uint64_t *l_809 = &g_602;
                uint16_t l_812 = 65529UL;
                int32_t l_822 = (-1L);
                int32_t l_826 = 0x9A3208E1L;
                int32_t l_828 = 0x03074FA1L;
                int32_t l_829 = 0x8984DF2EL;
                int32_t l_830 = 0x12C22664L;
                int32_t l_831 = 1L;
                int32_t l_832 = (-2L);
                int i, j, k;
            }
            l_846[0][0] &= (safe_mul_func_int16_t_s_s(((g_845 = l_843) == &l_522), (**l_677)));
        }
        else
        { /* block id: 387 */
            g_28[3] = (*g_33);
            g_28[3] |= (***l_676);
        }
    }
    else
    { /* block id: 391 */
        int32_t l_849 = 0xBD554C6CL;
        int32_t l_854 = 0x5B477C7FL;
        int32_t l_856 = 1L;
        int32_t l_858 = 1L;
        int32_t l_860 = (-1L);
        int32_t l_861 = 0x26A0FC1DL;
        uint16_t l_936 = 65528UL;
        uint8_t l_996 = 255UL;
        uint32_t *l_1002 = &g_599;
        for (g_58 = 0; (g_58 >= 13); g_58 = safe_add_func_int16_t_s_s(g_58, 2))
        { /* block id: 394 */
            uint16_t l_850 = 65535UL;
            int32_t l_851 = 9L;
            int32_t l_852[1];
            int32_t l_853 = 8L;
            int32_t l_855 = 0xEE2701ECL;
            int32_t l_857 = 1L;
            int32_t l_859 = 9L;
            uint8_t l_862 = 8UL;
            int32_t l_931 = 0x20764903L;
            const int32_t * const l_966 = &l_849;
            int i;
            for (i = 0; i < 1; i++)
                l_852[i] = 7L;
            l_850 = l_849;
            l_862++;
            if (l_860)
                break;
            if ((*g_33))
            { /* block id: 398 */
                int16_t **l_871 = &g_411;
                int32_t l_881 = 0x895713FFL;
                uint16_t l_882 = 65527UL;
                int32_t l_904[7][6] = {{0xC2D40164L,5L,1L,5L,0xC2D40164L,1L},{5L,0xC2D40164L,1L,(-8L),(-8L),1L},{(-8L),(-8L),1L,0xC2D40164L,5L,1L},{0xC2D40164L,5L,1L,5L,0xC2D40164L,1L},{5L,0xC2D40164L,1L,(-8L),(-8L),1L},{(-8L),(-8L),1L,0xC2D40164L,5L,1L},{0xC2D40164L,5L,1L,5L,0xC2D40164L,1L}};
                int16_t l_905[8];
                uint32_t l_932 = 0UL;
                int i, j;
                for (i = 0; i < 8; i++)
                    l_905[i] = 0x338AL;
                if ((((((((safe_rshift_func_uint16_t_u_u((l_860 , (safe_sub_func_int64_t_s_s((safe_rshift_func_int8_t_s_s(((void*)0 != l_871), 6)), (l_882 = (!(safe_rshift_func_int16_t_s_s((safe_rshift_func_int8_t_s_u((safe_sub_func_int8_t_s_s(((((safe_add_func_int64_t_s_s(0x399B88D6E9F1073FLL, (*g_723))) != l_881) < ((p_64 > (p_67 <= l_851)) == l_857)) == 2L), (*g_845))), 7)), 15))))))), p_64)) > 0xABED060702773F06LL) < (*g_33)) > l_857) ^ (*p_66)) && p_67) & p_67))
                { /* block id: 400 */
                    uint16_t *l_885 = (void*)0;
                    int32_t l_899 = 0L;
                    l_905[1] = (safe_div_func_uint16_t_u_u((g_424 |= l_881), ((safe_rshift_func_int16_t_s_s(((*g_411) &= (safe_sub_func_int16_t_s_s(((((l_904[2][0] = (+(safe_mod_func_int8_t_s_s((p_67 = (safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((l_899 &= (safe_sub_func_int16_t_s_s(p_64, 65529UL))), ((((*p_66) | ((255UL == (safe_mul_func_int8_t_s_s(((0x44L >= ((*g_845)--)) && (1L | ((*g_723) = l_858))), p_67))) || (*p_65))) < l_881) , l_861))), l_904[4][5]))), g_138)))) , 0UL) < p_64) , 0L), 0x4C3BL))), 6)) & p_64)));
                }
                else
                { /* block id: 409 */
                    uint64_t *l_916[10] = {&g_602,&g_602,&g_602,&g_602,&g_602,&g_602,&g_602,&g_602,&g_602,&g_602};
                    uint64_t **l_915 = &l_916[8];
                    uint64_t *l_918 = (void*)0;
                    uint64_t **l_917 = &l_918;
                    uint64_t l_924 = 18446744073709551611UL;
                    int32_t l_927 = 0x81CD9DB7L;
                    int i;
                    if ((*p_66))
                        break;
                    l_859 = (safe_rshift_func_uint16_t_u_u((~(l_881 &= (((void*)0 == (*g_574)) & (safe_lshift_func_int16_t_s_s((((safe_sub_func_int16_t_s_s(0L, l_850)) ^ (((*l_915) = &g_602) != ((*l_917) = &g_606))) || (8UL > ((safe_unary_minus_func_int16_t_s(l_904[5][2])) || ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_s(255UL, l_924)), 5)) | g_424)))), p_67))))), l_862));
                    for (l_851 = 0; (l_851 >= 0); --l_851)
                    { /* block id: 417 */
                        uint64_t l_928[3][8] = {{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL},{18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL,18446744073709551615UL,1UL}};
                        int i, j;
                        --l_928[0][1];
                        if ((*p_66))
                            continue;
                    }
                    l_932++;
                }
                l_936++;
                return p_67;
            }
            else
            { /* block id: 425 */
                int32_t **l_952 = &l_434[7][0];
                int16_t l_997 = 0x3166L;
                int32_t l_998[6][5][1] = {{{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL}},{{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL}},{{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL}},{{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL}},{{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL}},{{0x607A123DL},{0x3FB50E2AL},{0x607A123DL},{0x3FB50E2AL},{0x607A123DL}}};
                uint32_t l_999 = 0xFB79BA27L;
                int i, j, k;
                for (p_64 = (-18); (p_64 >= 42); ++p_64)
                { /* block id: 428 */
                    int64_t l_949 = 0L;
                    uint32_t *l_950 = &g_599;
                    int32_t l_951[7] = {0x54AB355EL,0x54AB355EL,0x54AB355EL,0x54AB355EL,0x54AB355EL,0x54AB355EL,0x54AB355EL};
                    int i;
                    g_28[3] = ((safe_rshift_func_int8_t_s_s(((((p_67 > (safe_add_func_uint16_t_u_u(((*p_66) != l_855), (safe_add_func_int8_t_s_s(((safe_mod_func_int8_t_s_s((((&g_574 != (void*)0) , (l_859 = (l_949 = 0L))) && ((((*l_950) = ((((void*)0 != &p_67) & (0xF4258AD6L ^ 0x22D918C0L)) < (-1L))) >= l_949) <= l_861)), (*g_682))) >= (-1L)), (-3L)))))) != (*g_411)) != l_853) > l_951[2]), 5)) > g_130[0]);
                }
                (*l_952) = (p_67 , (void*)0);
                for (l_858 = (-8); (l_858 < 1); l_858++)
                { /* block id: 437 */
                    uint32_t l_965 = 0UL;
                    int32_t *l_968[3];
                    uint64_t *l_991 = &g_606;
                    uint64_t **l_990 = &l_991;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_968[i] = (void*)0;
                    if ((l_857 > (((safe_div_func_uint64_t_u_u(((-4L) != l_957), ((safe_lshift_func_uint16_t_u_s(l_931, 5)) | (p_64 , ((0xA3L ^ (safe_div_func_uint8_t_u_u(p_64, 0x83L))) != (safe_lshift_func_int8_t_s_u((~(l_849 &= (*p_65))), 7))))))) , l_965) , p_67)))
                    { /* block id: 439 */
                        const int32_t *l_967 = &g_84;
                        l_967 = l_966;
                        l_967 = l_968[2];
                    }
                    else
                    { /* block id: 442 */
                        uint32_t *l_976 = &l_639;
                        int64_t *l_992[2];
                        int32_t l_993 = 7L;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_992[i] = (void*)0;
                        l_860 = ((0L ^ (safe_mul_func_uint16_t_u_u(((*p_66) , l_849), (((safe_mod_func_int32_t_s_s(((!(((safe_div_func_int32_t_s_s(((((*l_976)--) , ((safe_add_func_uint8_t_u_u(p_64, ((0xB581L | p_64) < ((void*)0 == p_66)))) || ((g_602 = (safe_lshift_func_uint8_t_u_u(((((((safe_add_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u(((**l_990) = (g_987 == l_990)), g_17)), 0x3446EB6BDF019FF2LL)) >= 0x3FL) ^ l_856) , l_992[1]) != (void*)0) || 0xCB6A089FL), 7))) && 0xA609D8B9862319E2LL))) > l_993), 0x46D5F4F3L)) ^ 0x87CA596B9A9E653DLL) , (*g_33))) && 1L), g_58)) >= (*g_682)) , g_508[3][3][0])))) || p_67);
                        g_84 = (safe_mod_func_int16_t_s_s(0x67BFL, l_996));
                        l_999++;
                    }
                    l_857 = 4L;
                }
                (*l_952) = (void*)0;
            }
        }
        l_858 ^= ((l_1002 == &l_808) , (&g_28[0] != ((safe_add_func_int8_t_s_s((-10L), ((safe_rshift_func_uint8_t_u_u(0x73L, 2)) || (safe_mul_func_int8_t_s_s((**g_681), 0x50L))))) , (void*)0)));
    }
    return p_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_58 g_28 g_34 g_33 g_17 g_84 g_126 g_130 g_138 g_133 g_135 g_123 g_260 g_272 g_345
 * writes: g_58 g_81 g_84 g_28 g_123 g_126 g_130 g_133 g_135 g_260 g_138 g_272 g_370 g_397 g_411 g_412
 */
static uint16_t  func_68(uint32_t * p_69)
{ /* block id: 9 */
    int32_t *l_70 = (void*)0;
    uint32_t l_74 = 0xF96354D1L;
    int32_t l_131 = 0x08EB45E8L;
    uint64_t l_161 = 0xD4334ECE7258F314LL;
    int16_t *l_184 = &g_135[4][6];
    uint8_t l_225 = 0x38L;
    int32_t l_231[1][4][8] = {{{(-1L),8L,8L,(-1L),(-1L),8L,8L,(-1L)},{(-1L),8L,8L,(-1L),(-1L),8L,8L,(-1L)},{(-1L),8L,8L,(-1L),(-1L),8L,8L,(-1L)},{(-1L),8L,8L,(-1L),(-1L),8L,8L,(-1L)}}};
    int32_t l_234[9] = {0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L,0x154DCB41L};
    uint64_t l_301 = 18446744073709551613UL;
    uint64_t l_304[5];
    uint32_t l_406 = 1UL;
    int8_t l_418 = (-1L);
    int32_t **l_419 = &g_397;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_304[i] = 0UL;
    if ((l_70 == (void*)0))
    { /* block id: 10 */
        uint32_t l_78 = 0xFC7A8F60L;
        int32_t *l_127[5][3];
        int64_t *l_354 = &g_355;
        int64_t l_369 = 0x4CD35E44593456A5LL;
        int32_t l_413 = (-8L);
        uint8_t l_414 = 0x6AL;
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 3; j++)
                l_127[i][j] = &g_28[0];
        }
        for (g_58 = 0; (g_58 <= 8); g_58 += 1)
        { /* block id: 13 */
            uint32_t *l_80 = &l_78;
            uint32_t **l_79[4][4] = {{&l_80,&l_80,&l_80,&l_80},{&l_80,&l_80,&l_80,&l_80},{(void*)0,&l_80,(void*)0,&l_80},{(void*)0,&l_80,&l_80,(void*)0}};
            int32_t l_82[2];
            int32_t *l_83[8][4][6] = {{{&g_28[g_58],&g_34,&g_34,&g_84,&g_84,&g_84},{(void*)0,&g_84,&g_84,(void*)0,&g_28[4],&g_28[g_58]},{&g_28[3],&g_28[4],&g_34,&g_34,&g_28[4],&g_28[g_58]},{&g_84,&g_28[3],&g_34,&g_34,&g_28[4],&g_84}},{{&g_28[3],&g_28[4],&g_28[g_58],&g_28[g_58],&g_28[4],(void*)0},{(void*)0,&g_84,&g_28[g_58],&g_28[3],&g_84,(void*)0},{&g_28[6],&g_34,&g_28[g_58],&g_34,&g_28[g_58],&g_28[5]},{&g_28[g_58],&g_28[g_58],&g_28[g_58],(void*)0,&g_34,&g_28[g_58]}},{{&g_84,&g_84,(void*)0,&g_28[g_58],&g_28[g_58],&g_28[g_58]},{(void*)0,&g_28[g_58],&g_28[3],&g_28[g_58],&g_28[4],&g_84},{(void*)0,(void*)0,&g_34,(void*)0,&g_28[g_58],&g_28[g_58]},{&g_28[g_58],(void*)0,&g_28[4],&g_28[g_58],(void*)0,&g_28[g_58]}},{{&g_34,&g_28[g_58],&g_34,&g_34,(void*)0,&g_28[g_58]},{&g_28[g_58],&g_28[g_58],&g_34,(void*)0,&g_84,&g_84},{&g_84,&g_84,&g_28[3],(void*)0,&g_28[4],&g_34},{&g_28[g_58],&g_28[3],&g_28[2],&g_34,&g_84,&g_28[g_58]}},{{&g_34,&g_34,&g_34,&g_28[g_58],&g_28[g_58],&g_28[5]},{&g_28[g_58],&g_28[4],&g_28[1],(void*)0,&g_34,&g_34},{(void*)0,&g_84,&g_28[3],&g_28[g_58],&g_84,(void*)0},{(void*)0,(void*)0,&g_28[g_58],&g_28[g_58],&g_28[g_58],&g_28[1]}},{{&g_84,&g_28[6],&g_28[g_58],&g_28[g_58],&g_28[8],(void*)0},{(void*)0,&g_28[1],&g_28[g_58],&g_28[g_58],&g_84,&g_28[g_58]},{&g_84,&g_28[3],(void*)0,&g_28[g_58],&g_28[g_58],(void*)0},{&g_34,&g_34,&g_28[g_58],(void*)0,&g_28[g_58],&g_84}},{{&g_28[6],&g_28[g_58],&g_28[4],&g_28[g_58],&g_28[g_58],&g_28[g_58]},{&g_28[3],&g_28[6],&g_28[4],&g_28[5],&g_34,&g_84},{&g_28[g_58],&g_28[5],&g_28[g_58],&g_28[2],&g_34,(void*)0},{&g_28[2],&g_34,(void*)0,&g_34,&g_28[g_58],&g_28[g_58]}},{{&g_28[4],&g_84,&g_28[g_58],(void*)0,&g_28[g_58],(void*)0},{&g_28[g_58],&g_28[g_58],&g_28[g_58],&g_28[g_58],&g_28[g_58],&g_28[1]},{(void*)0,&g_28[g_58],(void*)0,&g_28[g_58],&g_28[3],&g_34},{&g_34,(void*)0,&g_28[g_58],&g_28[3],&g_34,&g_34}}};
            int32_t **l_107 = &l_83[3][2][0];
            int16_t *l_122 = &g_123;
            int8_t *l_124 = (void*)0;
            int8_t *l_125 = &g_126;
            int8_t *l_128 = (void*)0;
            int8_t *l_129[10] = {&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0],&g_130[0]};
            uint8_t *l_132 = &g_133;
            int16_t *l_134 = &g_135[4][6];
            int64_t l_136 = (-3L);
            uint16_t l_137 = 65529UL;
            uint8_t l_152 = 0x72L;
            int8_t l_166 = 0L;
            uint64_t l_169 = 0x86662D1DE3320B12LL;
            uint8_t l_245 = 0x33L;
            uint64_t l_291 = 0xED60C2995D31673FLL;
            const int32_t l_325 = 0x88A00115L;
            int32_t l_327 = 0x183E08D4L;
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_82[i] = 0L;
            g_28[3] = ((~1UL) , (safe_add_func_uint32_t_u_u(((g_28[g_58] && g_28[g_58]) == l_74), ((((p_69 != p_69) > (g_84 = ((((((!(l_82[0] = (safe_add_func_uint64_t_u_u(((l_78 > ((l_70 != (g_81 = l_70)) , 0x8D20L)) , g_28[g_58]), 0xCE9E61979B998621LL)))) != g_34) , g_58) > g_28[g_58]) | 1UL) >= (*g_33)))) >= l_78) , (*g_33)))));
            for (l_78 = 0; (l_78 <= 38); l_78++)
            { /* block id: 20 */
                return g_58;
            }
            if ((((((g_28[3] , ((((safe_div_func_uint64_t_u_u(18446744073709551615UL, (((safe_add_func_int16_t_s_s(((*l_134) = (safe_sub_func_uint64_t_u_u(g_17, (safe_add_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u(l_74, ((*l_132) = (!((safe_div_func_uint16_t_u_u((((safe_lshift_func_int16_t_s_u(l_78, 7)) , (g_84 = (+(safe_mod_func_uint32_t_u_u(0x35EF5641L, ((safe_lshift_func_int8_t_s_u(((l_131 ^= (g_130[2] = ((((*l_107) = &g_34) == (((safe_add_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(g_28[3], (safe_add_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s(((*l_125) ^= (+(~(safe_lshift_func_int16_t_s_u(((((*l_122) = g_84) > l_78) < l_78), l_78))))), 5)), 0xA62AF0730FA2875FLL)))), 1UL)), 0x0A8EL)) >= 0x31L) , l_127[2][0])) , 0xABL))) <= 9L), g_34)) , 0x370F7B9EL)))))) <= (*p_69)), g_17)) <= l_82[0]))))) == (*p_69)), g_28[g_58]))))), 0x954DL)) && 0x1FECA7173955FA40LL) && g_130[0]))) <= l_136) < g_34) , g_84)) >= g_17) < l_137) & (*p_69)) && 1L))
            { /* block id: 31 */
                uint64_t l_146 = 0x697889B5E22BCF92LL;
                int32_t l_151 = (-9L);
                int32_t *l_226 = &l_82[0];
                int32_t l_239 = 1L;
                int32_t l_242 = 0xF79196BFL;
                if ((g_138 , ((((safe_add_func_uint8_t_u_u(((l_125 != &g_133) ^ (l_131 = (l_151 |= (g_133 ^ (((+((g_34 , (safe_add_func_uint16_t_u_u((((safe_rshift_func_int8_t_s_u((l_146 && (-8L)), (safe_rshift_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u(65535UL, ((*l_134) = 0xF6ACL))) == (*g_33)), g_84)))) != g_28[3]) >= l_146), l_146))) & 0L)) != 1L) , 0xC8C0L))))), 0x3DL)) , g_138) & g_130[3]) ^ l_152)))
                { /* block id: 35 */
                    l_131 = (g_135[1][3] , (g_28[3] |= 0xB5D02C25L));
                }
                else
                { /* block id: 38 */
                    uint64_t l_153 = 0UL;
                    ++l_153;
                    g_28[5] &= (safe_sub_func_uint64_t_u_u((0x17D6ECEDL >= (~g_58)), (-7L)));
                }
                if ((safe_mod_func_uint16_t_u_u(((l_161 & (((safe_mod_func_uint32_t_u_u(((&g_58 == (g_81 = ((safe_mod_func_uint8_t_u_u(((l_166 >= (g_84 = ((safe_mod_func_int32_t_s_s((g_28[3] ^= l_169), g_34)) && (safe_mul_func_uint8_t_u_u(g_58, g_17))))) , g_133), (((((*l_125) ^= ((safe_add_func_uint64_t_u_u(l_151, l_151)) != g_123)) <= l_151) == 0x6365C1E2L) ^ (-1L)))) , (void*)0))) > l_146), 0x51559326L)) , (void*)0) == (void*)0)) , g_130[1]), g_135[4][6])))
                { /* block id: 46 */
                    uint16_t l_185 = 5UL;
                    uint32_t **l_195 = &g_81;
                    int32_t ***l_224 = &l_107;
                    int32_t l_232 = 0x878282A4L;
                    int32_t l_233 = 0xDA2F8298L;
                    int32_t l_236 = 0L;
                    int32_t l_237 = 1L;
                    int32_t l_238 = 1L;
                    int32_t l_240 = 0x14573A3FL;
                    int32_t l_241 = 0x59F603D1L;
                    int32_t l_243 = 0x5A9678BCL;
                    int32_t l_244 = 7L;
                    for (l_78 = 22; (l_78 == 7); l_78 = safe_sub_func_uint16_t_u_u(l_78, 5))
                    { /* block id: 49 */
                        int64_t *l_180 = &l_136;
                        l_185 = ((safe_sub_func_int8_t_s_s((((((safe_mul_func_int8_t_s_s((-1L), ((*l_125) = g_34))) != g_58) == (((((*l_180) = g_28[4]) == ((!g_130[0]) < (l_151 = g_17))) > g_17) >= g_28[3])) >= ((safe_mul_func_int8_t_s_s(((l_184 == l_122) || g_28[8]), (-6L))) >= g_130[3])) , 0x6DL), g_28[3])) , 0x9C249DFCL);
                    }
                    for (l_136 = 0; (l_136 > (-8)); l_136--)
                    { /* block id: 57 */
                        int32_t **l_203 = &l_127[2][0];
                        (**l_203) ^= ((*p_69) < ((*l_80) = (+((safe_rshift_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(0x9CL, ((safe_div_func_int32_t_s_s((*g_33), 0x45D5CCFCL)) < ((l_195 == (void*)0) < ((-8L) > 0xA3L))))), 2)) >= (safe_add_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((+(((safe_div_func_int32_t_s_s((l_203 != &g_33), 4294967295UL)) | 0x051AL) < l_185)), g_84)) , 0xF582L), 0x7AA4L))))));
                        (**l_203) = ((safe_sub_func_uint32_t_u_u(l_185, 0x20AD96D9L)) > (*p_69));
                        l_70 = p_69;
                    }
                    if ((safe_add_func_uint8_t_u_u((((safe_div_func_int8_t_s_s((((0x0C1A7E2DL <= (((safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s((0UL & (--(*l_80))), ((((safe_div_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s((g_28[1] == ((safe_add_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u(g_135[3][1], (&g_33 != ((*l_224) = &g_33)))) , g_28[4]), g_130[0])) || l_161)), g_130[0])) , (**l_107)), l_225)) <= l_151) && (***l_224)) , l_146))), g_130[0])) , (-1L)) >= 0x6646722DL)) & 18446744073709551613UL) , 0xE0L), g_123)) && (***l_224)) , l_146), 1L)))
                    { /* block id: 65 */
                        if ((*g_33))
                            break;
                        l_226 = p_69;
                        l_231[0][1][6] ^= (safe_rshift_func_int16_t_s_s((safe_div_func_uint16_t_u_u(65535UL, g_126)), 14));
                    }
                    else
                    { /* block id: 69 */
                        int32_t l_235[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_235[i] = 0x9D5A252DL;
                        l_70 = &g_28[2];
                        --l_245;
                        return g_34;
                    }
                    for (g_84 = 0; (g_84 <= (-11)); g_84 = safe_sub_func_int32_t_s_s(g_84, 8))
                    { /* block id: 76 */
                        if ((*g_33))
                            break;
                        g_28[3] |= (*g_33);
                    }
                }
                else
                { /* block id: 80 */
                    const int8_t l_261 = (-1L);
                    for (l_169 = 0; (l_169 <= 4); l_169 += 1)
                    { /* block id: 83 */
                        uint64_t *l_262 = &l_161;
                        int i, j;
                        (*l_226) = (safe_add_func_uint64_t_u_u(((*l_262) = (safe_rshift_func_uint8_t_u_u((((void*)0 == &g_33) == ((safe_add_func_int32_t_s_s(0x0AC3FDCEL, 0x2114B6D7L)) || ((safe_mul_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(g_135[l_169][(l_169 + 2)], (g_138 &= ((*g_33) > (g_260 &= ((*l_80) &= (((void*)0 == &g_81) ^ (*l_226)))))))), l_261)) , (*p_69)))), g_133))), 0x4F45D0BD218EFC80LL));
                    }
                }
            }
            else
            { /* block id: 91 */
                int16_t l_271 = 0xECCFL;
                int64_t *l_277 = (void*)0;
                int64_t *l_278 = &l_136;
                uint32_t l_290 = 4294967295UL;
                int32_t l_362 = 0xE2228E07L;
                g_28[3] = (l_234[6] = (safe_div_func_uint64_t_u_u((g_126 != (((safe_lshift_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u(0x070F4C9D8C37194ELL, (safe_lshift_func_uint16_t_u_u(((l_271 , (g_272++)) < (safe_mul_func_int16_t_s_s((((*l_278) &= (l_271 || l_271)) > (((((safe_mod_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((!((*l_122) |= ((*l_134) = (safe_mod_func_uint32_t_u_u(((0xCBL || ((((*g_33) != l_271) < (safe_div_func_uint32_t_u_u(((safe_div_func_int8_t_s_s(0xBDL, l_271)) || 1UL), (*g_33)))) , 0xB8L)) , (*p_69)), 4294967290UL))))), g_133)), l_290)) > g_34) , 18446744073709551613UL) || 0xE25B234A05A01716LL) || (-1L))), g_28[1]))), l_291)))) ^ (*g_33)), 3)) >= l_290) && 0xE4L)), 18446744073709551607UL)));
                if ((safe_mul_func_uint8_t_u_u(((((g_133 ^ ((((&l_127[1][2] != &l_83[3][2][0]) <= ((!(safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((((safe_lshift_func_uint16_t_u_u(l_271, ((g_28[8] = (0x591AL > l_301)) == ((g_272 , (safe_sub_func_uint8_t_u_u(((((*g_33) | l_271) , g_135[4][6]) | g_138), 0x50L))) || l_304[4])))) , g_130[3]) | (-5L)), g_84)), 0x2DL))) > 1UL)) ^ 1UL) , (*g_33))) , 0x3C897FB1L) < (-1L)) & l_290), l_290)))
                { /* block id: 99 */
                    int32_t l_310 = (-9L);
                    int16_t *l_318 = &l_271;
                    int32_t l_329 = 0L;
                    uint16_t l_330 = 0xB77EL;
                    int64_t l_342[6] = {0x201076E64F549E07LL,0x201076E64F549E07LL,1L,0x201076E64F549E07LL,0x201076E64F549E07LL,1L};
                    int i;
                    for (l_169 = 8; (l_169 > 20); ++l_169)
                    { /* block id: 102 */
                        uint64_t *l_307 = &l_161;
                        int32_t l_315[5][1] = {{0xB1021B9EL},{0xE41CB402L},{0xB1021B9EL},{0xE41CB402L},{0xB1021B9EL}};
                        int32_t l_326 = 0x6AC04568L;
                        int16_t l_328[2];
                        int i, j;
                        for (i = 0; i < 2; i++)
                            l_328[i] = 0xD0AAL;
                        l_326 |= (g_34 <= (((((*l_125) = ((++(*l_307)) | ((l_310 , (safe_mod_func_int32_t_s_s((safe_mod_func_uint64_t_u_u((0xB9ECL || g_34), l_315[1][0])), (safe_rshift_func_int8_t_s_s(((l_318 != l_122) < (safe_lshift_func_uint8_t_u_s((safe_mul_func_int16_t_s_s((g_135[4][6] &= (safe_div_func_int16_t_s_s(((((void*)0 == l_277) | g_130[0]) && g_84), (-1L)))), g_17)), 7))), 7))))) == 0x2385D345L))) > g_133) | l_325) >= l_271));
                        l_327 ^= (*g_33);
                        --l_330;
                        l_315[1][0] ^= (safe_lshift_func_int16_t_s_u(1L, (safe_sub_func_uint32_t_u_u((((*l_132) = ((void*)0 != &g_81)) , (safe_mod_func_uint8_t_u_u((((safe_add_func_uint64_t_u_u(g_138, ((*l_278) |= l_329))) & (!0x28L)) <= ((*l_80) = l_342[2])), ((safe_lshift_func_int16_t_s_u(((((void*)0 == g_345) >= 0L) < l_310), 4)) & l_290)))), (*p_69)))));
                    }
                }
                else
                { /* block id: 114 */
                    uint32_t l_350 = 1UL;
                    int32_t l_360 = 0x69B73E2DL;
                    int32_t l_361[7][2] = {{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}};
                    int32_t *l_365 = (void*)0;
                    uint16_t l_366[4];
                    int i, j;
                    for (i = 0; i < 4; i++)
                        l_366[i] = 0UL;
                    l_362 ^= (((((g_84 = ((safe_div_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(g_272, 0xE1EEL)), (l_350 = g_126))) & ((g_133 | ((safe_mul_func_int8_t_s_s(g_133, (!((l_354 != (void*)0) == 0x53L)))) >= (safe_lshift_func_int16_t_s_s((safe_mul_func_int8_t_s_s((l_360 &= ((l_127[0][1] == p_69) & 8UL)), l_231[0][0][1])), l_361[0][1])))) , l_360))) & l_361[0][1]) <= 0x5EL) && g_17) | g_135[4][6]);
                    g_370 = ((g_58 , ((safe_add_func_uint8_t_u_u((((void*)0 == l_365) == l_366[3]), ((((((((&l_271 != (void*)0) | g_130[0]) >= (safe_div_func_int32_t_s_s((l_134 != &g_123), l_369))) != l_290) , g_126) > g_123) <= 0x1AL) & (*p_69)))) && 0xDCL)) , (void*)0);
                }
            }
        }
        for (l_74 = 14; (l_74 == 54); l_74 = safe_add_func_uint32_t_u_u(l_74, 7))
        { /* block id: 125 */
            uint64_t l_377 = 2UL;
            int32_t l_379 = 0x49B0B221L;
            int32_t l_390 = 0x45F09B39L;
            int32_t *l_395[3][7] = {{&l_234[6],(void*)0,(void*)0,&l_234[6],(void*)0,&l_390,&l_234[6]},{&l_390,&g_28[3],(void*)0,(void*)0,&g_28[3],&l_390,(void*)0},{&g_28[3],&l_234[6],&g_84,&l_379,&l_379,&g_84,&l_234[6]}};
            int16_t *l_409 = &g_123;
            int i, j;
            for (l_131 = 0; (l_131 != (-11)); l_131--)
            { /* block id: 128 */
                int16_t l_378 = 0xB8F5L;
                int32_t l_380 = 0x1706491EL;
                l_378 = l_377;
                l_380 = (l_379 ^= ((void*)0 == &l_225));
                for (l_161 = 0; (l_161 != 15); ++l_161)
                { /* block id: 134 */
                    uint8_t l_385 = 251UL;
                    g_84 &= l_379;
                    for (l_78 = 28; (l_78 <= 31); l_78 = safe_add_func_uint8_t_u_u(l_78, 5))
                    { /* block id: 138 */
                        l_385 = (g_28[3] ^= (*g_33));
                    }
                }
                for (g_58 = 0; (g_58 < 23); g_58++)
                { /* block id: 145 */
                    return g_133;
                }
            }
            for (l_78 = 0; (l_78 <= 0); l_78 += 1)
            { /* block id: 151 */
                int32_t l_389[9] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
                int8_t l_400 = 9L;
                int32_t l_405[10][3] = {{0x1D1EE99DL,1L,1L},{(-1L),(-5L),(-5L)},{0x1D1EE99DL,1L,1L},{(-1L),(-5L),(-5L)},{0x1D1EE99DL,1L,1L},{(-1L),(-5L),(-5L)},{0x1D1EE99DL,1L,1L},{(-1L),(-5L),(-5L)},{0x1D1EE99DL,1L,1L},{(-1L),(-5L),(-5L)}};
                int16_t **l_410[6][5][8] = {{{&l_184,(void*)0,(void*)0,&l_184,&l_184,&l_409,&l_409,&l_184},{(void*)0,(void*)0,&l_184,&l_409,(void*)0,(void*)0,&l_184,&l_184},{(void*)0,(void*)0,&l_184,&l_184,&l_409,&l_409,&l_184,(void*)0},{&l_409,(void*)0,(void*)0,&l_409,&l_184,&l_184,&l_184,&l_409},{&l_184,&l_184,&l_184,&l_184,(void*)0,&l_184,&l_184,&l_409}},{{&l_184,(void*)0,&l_409,(void*)0,&l_184,&l_184,(void*)0,&l_184},{&l_184,&l_409,&l_184,&l_409,(void*)0,&l_184,(void*)0,(void*)0},{&l_184,&l_184,&l_409,&l_409,&l_184,&l_184,&l_409,&l_409},{&l_409,&l_409,&l_184,&l_184,(void*)0,&l_184,&l_184,&l_184},{&l_184,&l_409,(void*)0,&l_409,&l_184,(void*)0,(void*)0,&l_184}},{{&l_409,&l_184,(void*)0,&l_184,(void*)0,(void*)0,(void*)0,&l_409},{(void*)0,(void*)0,(void*)0,&l_409,(void*)0,&l_409,(void*)0,(void*)0},{&l_409,&l_184,&l_409,&l_409,(void*)0,&l_184,&l_409,&l_184},{&l_184,(void*)0,(void*)0,(void*)0,&l_409,(void*)0,&l_409,&l_409},{(void*)0,(void*)0,&l_409,&l_184,(void*)0,(void*)0,(void*)0,&l_409}},{{(void*)0,(void*)0,(void*)0,&l_409,&l_409,(void*)0,(void*)0,(void*)0},{&l_184,&l_409,(void*)0,&l_184,&l_409,&l_409,(void*)0,&l_409},{&l_184,(void*)0,(void*)0,&l_184,&l_184,&l_409,&l_184,(void*)0},{&l_184,&l_409,&l_184,(void*)0,(void*)0,(void*)0,&l_409,(void*)0},{(void*)0,(void*)0,&l_409,(void*)0,&l_409,(void*)0,(void*)0,(void*)0}},{{&l_184,(void*)0,&l_184,&l_184,&l_184,(void*)0,(void*)0,&l_184},{(void*)0,(void*)0,&l_409,&l_184,&l_184,&l_184,&l_184,(void*)0},{&l_184,&l_184,&l_184,&l_184,&l_409,&l_409,&l_184,&l_184},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_184,(void*)0},{&l_184,&l_184,&l_409,&l_409,&l_184,(void*)0,&l_184,&l_184}},{{&l_184,&l_409,(void*)0,&l_409,&l_409,&l_184,&l_184,(void*)0},{&l_184,&l_409,(void*)0,(void*)0,&l_409,&l_409,(void*)0,&l_409},{&l_184,(void*)0,(void*)0,(void*)0,&l_184,&l_184,(void*)0,&l_409},{&l_184,&l_184,&l_409,&l_184,&l_184,(void*)0,&l_409,(void*)0},{(void*)0,&l_184,&l_409,&l_409,&l_184,&l_409,(void*)0,&l_184}}};
                int i, j, k;
                for (g_260 = 0; (g_260 <= 0); g_260 += 1)
                { /* block id: 154 */
                    uint64_t l_391 = 0xAC595C28A2C5BB67LL;
                    int32_t l_394 = (-4L);
                    int32_t **l_396 = (void*)0;
                    int i, j;
                    for (l_379 = 5; (l_379 >= 0); l_379 -= 1)
                    { /* block id: 157 */
                        int32_t **l_388 = &l_127[2][0];
                        int i;
                        (*l_388) = p_69;
                        ++l_391;
                    }
                    for (l_391 = 0; (l_391 <= 0); l_391 += 1)
                    { /* block id: 163 */
                        int i, j, k;
                        if (l_231[g_260][l_78][(l_391 + 7)])
                            break;
                        l_394 = l_231[l_391][g_260][(g_260 + 1)];
                    }
                    g_397 = l_395[2][6];
                    g_28[3] = ((((65531UL <= (safe_sub_func_int8_t_s_s(l_389[6], (g_260 && ((l_400 >= (l_405[6][2] = ((g_135[(g_260 + 4)][(l_78 + 4)] = g_272) , (l_400 | (safe_sub_func_uint8_t_u_u((9UL & (l_389[3] , ((safe_lshift_func_int8_t_s_s((0L || (-2L)), g_260)) > 5L))), g_34)))))) & l_400))))) == g_138) , l_406) | 0x179BEE8F932CA32DLL);
                }
                g_28[7] |= ((((g_84 || g_34) , (safe_mul_func_uint16_t_u_u(g_84, ((*l_184) = g_34)))) | ((g_412[1][1] = (g_411 = l_409)) == (void*)0)) >= ((l_413 == (&g_58 == (void*)0)) , (*g_33)));
                return l_131;
            }
            return g_130[2];
        }
        return l_414;
    }
    else
    { /* block id: 181 */
        uint8_t l_415 = 2UL;
        l_415++;
    }
    (*l_419) = func_31(l_418);
    return g_130[0];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_28[i], "g_28[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_130[i], "g_130[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_133, "g_133", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_135[i][j], "g_135[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_260, "g_260", print_hash_value);
    transparent_crc(g_272, "g_272", print_hash_value);
    transparent_crc(g_355, "g_355", print_hash_value);
    transparent_crc(g_372, "g_372", print_hash_value);
    transparent_crc(g_424, "g_424", print_hash_value);
    transparent_crc(g_483, "g_483", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_508[i][j][k], "g_508[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_576, "g_576", print_hash_value);
    transparent_crc(g_577, "g_577", print_hash_value);
    transparent_crc(g_578, "g_578", print_hash_value);
    transparent_crc(g_579, "g_579", print_hash_value);
    transparent_crc(g_580, "g_580", print_hash_value);
    transparent_crc(g_581, "g_581", print_hash_value);
    transparent_crc(g_582, "g_582", print_hash_value);
    transparent_crc(g_583, "g_583", print_hash_value);
    transparent_crc(g_584, "g_584", print_hash_value);
    transparent_crc(g_599, "g_599", print_hash_value);
    transparent_crc(g_602, "g_602", print_hash_value);
    transparent_crc(g_606, "g_606", print_hash_value);
    transparent_crc(g_624, "g_624", print_hash_value);
    transparent_crc(g_668, "g_668", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_670[i][j], "g_670[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_767, "g_767", print_hash_value);
    transparent_crc(g_768, "g_768", print_hash_value);
    transparent_crc(g_769, "g_769", print_hash_value);
    transparent_crc(g_770, "g_770", print_hash_value);
    transparent_crc(g_771, "g_771", print_hash_value);
    transparent_crc(g_772, "g_772", print_hash_value);
    transparent_crc(g_773, "g_773", print_hash_value);
    transparent_crc(g_774, "g_774", print_hash_value);
    transparent_crc(g_775, "g_775", print_hash_value);
    transparent_crc(g_776, "g_776", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_777[i][j][k], "g_777[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_778, "g_778", print_hash_value);
    transparent_crc(g_779, "g_779", print_hash_value);
    transparent_crc(g_780, "g_780", print_hash_value);
    transparent_crc(g_781, "g_781", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_782[i][j], "g_782[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_783, "g_783", print_hash_value);
    transparent_crc(g_784, "g_784", print_hash_value);
    transparent_crc(g_825, "g_825", print_hash_value);
    transparent_crc(g_989, "g_989", print_hash_value);
    transparent_crc(g_1309, "g_1309", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1464[i], "g_1464[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1494, "g_1494", print_hash_value);
    transparent_crc(g_1588, "g_1588", print_hash_value);
    transparent_crc(g_1600, "g_1600", print_hash_value);
    transparent_crc(g_1829, "g_1829", print_hash_value);
    transparent_crc(g_1853, "g_1853", print_hash_value);
    transparent_crc(g_1854, "g_1854", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 525
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 46
breakdown:
   depth: 1, occurrence: 201
   depth: 2, occurrence: 47
   depth: 3, occurrence: 10
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 9, occurrence: 2
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 17, occurrence: 4
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 3
   depth: 22, occurrence: 4
   depth: 23, occurrence: 3
   depth: 24, occurrence: 3
   depth: 25, occurrence: 3
   depth: 26, occurrence: 1
   depth: 27, occurrence: 4
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 2
   depth: 32, occurrence: 1
   depth: 34, occurrence: 2
   depth: 35, occurrence: 2
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 46, occurrence: 1

XXX total number of pointers: 341

XXX times a variable address is taken: 1009
XXX times a pointer is dereferenced on RHS: 260
breakdown:
   depth: 1, occurrence: 220
   depth: 2, occurrence: 29
   depth: 3, occurrence: 11
XXX times a pointer is dereferenced on LHS: 236
breakdown:
   depth: 1, occurrence: 224
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
XXX times a pointer is compared with null: 47
XXX times a pointer is compared with address of another variable: 12
XXX times a pointer is compared with another pointer: 14
XXX times a pointer is qualified to be dereferenced: 6767

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1133
   level: 2, occurrence: 171
   level: 3, occurrence: 55
   level: 4, occurrence: 5
XXX number of pointers point to pointers: 150
XXX number of pointers point to scalars: 191
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.6
XXX average alias set size: 1.5

XXX times a non-volatile is read: 1771
XXX times a non-volatile is write: 838
XXX times a volatile is read: 20
XXX    times read thru a pointer: 15
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 123
XXX percentage of non-volatile access: 99.1

XXX forward jumps: 2
XXX backward jumps: 5

XXX stmts: 203
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 29
   depth: 2, occurrence: 25
   depth: 3, occurrence: 26
   depth: 4, occurrence: 37
   depth: 5, occurrence: 54

XXX percentage a fresh-made variable is used: 16.5
XXX percentage an existing variable is used: 83.5
********************* end of statistics **********************/

