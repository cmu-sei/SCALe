/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      1156571052
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x928C176BL;
static volatile uint32_t g_6 = 18446744073709551606UL;/* VOLATILE GLOBAL g_6 */
static int32_t g_9[6][8] = {{1L,0xF82BAEF6L,1L,0x752F67D5L,1L,0xF82BAEF6L,1L,0L},{0xF82BAEF6L,0xDD44AD37L,6L,0x8B0D193EL,1L,0x752F67D5L,0x752F67D5L,1L},{0x006310FEL,1L,1L,0x006310FEL,1L,0x229EDCA8L,0L,0x752F67D5L},{0xF82BAEF6L,1L,0L,1L,1L,1L,0L,1L},{1L,1L,0x752F67D5L,0L,6L,0x229EDCA8L,0x8B0D193EL,0x8B0D193EL},{0x752F67D5L,1L,0xDD44AD37L,0xDD44AD37L,1L,0x752F67D5L,0x229EDCA8L,0L}};
static uint32_t g_12 = 2UL;
static uint16_t g_49 = 0x72F3L;
static int8_t g_77 = 0xC8L;
static int32_t g_84 = 1L;
static int32_t * volatile g_83 = &g_84;/* VOLATILE GLOBAL g_83 */
static int64_t g_103 = 4L;
static int32_t g_107[10][7][1] = {{{0x3AC5CED9L},{(-1L)},{1L},{0x213B74EAL},{0x5F2590C1L},{0x2D4CE278L},{0xB4DC16D4L}},{{0x1820E1BCL},{0x706CD285L},{0L},{0x5F2590C1L},{(-1L)},{0x3596026DL},{(-1L)}},{{0x5F2590C1L},{0L},{0x706CD285L},{0x1820E1BCL},{0xB4DC16D4L},{0x2D4CE278L},{0x5F2590C1L}},{{0x213B74EAL},{1L},{(-1L)},{0x3AC5CED9L},{0x2D4CE278L},{0x706CD285L},{0x8B27CD67L}},{{0x706CD285L},{0x2D4CE278L},{0x3AC5CED9L},{(-1L)},{1L},{0x213B74EAL},{0x5F2590C1L}},{{0x2D4CE278L},{0xB4DC16D4L},{0x1820E1BCL},{0x706CD285L},{0L},{0x5F2590C1L},{(-1L)}},{{0x3596026DL},{(-1L)},{0x5F2590C1L},{0L},{0x706CD285L},{0x1820E1BCL},{0xB4DC16D4L}},{{0x2D4CE278L},{0x5F2590C1L},{0x213B74EAL},{1L},{(-1L)},{0x3AC5CED9L},{0x2D4CE278L}},{{0x706CD285L},{0x8B27CD67L},{0x706CD285L},{0x2D4CE278L},{0x3AC5CED9L},{(-1L)},{1L}},{{0x213B74EAL},{0x5F2590C1L},{0x2D4CE278L},{0xB4DC16D4L},{0x1820E1BCL},{0x706CD285L},{0L}}};
static volatile int8_t g_109[10][6][4] = {{{0xFCL,(-1L),0xFCL,0x33L},{0xFCL,0x33L,0x33L,0xFCL},{1L,0x33L,3L,0x33L},{0x33L,(-1L),3L,3L},{1L,1L,0x33L,3L},{0xFCL,(-1L),0xFCL,0x33L}},{{0xFCL,0x33L,0x33L,0xFCL},{1L,0x33L,3L,0x33L},{0x33L,(-1L),3L,3L},{1L,1L,0x33L,3L},{0xFCL,(-1L),0xFCL,0x33L},{0xFCL,0x33L,0x33L,0xFCL}},{{1L,0x33L,3L,0x33L},{0x33L,(-1L),3L,3L},{1L,1L,0x33L,3L},{0xFCL,(-1L),0xFCL,0x33L},{0xFCL,0x33L,0x33L,0xFCL},{1L,0x33L,3L,0x33L}},{{0x33L,(-1L),3L,3L},{1L,1L,0x33L,3L},{0xFCL,(-1L),0xFCL,0x33L},{0xFCL,0x33L,0x33L,0xFCL},{1L,0x33L,3L,0x33L},{0x33L,(-1L),3L,3L}},{{1L,1L,0x33L,3L},{0xFCL,(-1L),0xFCL,0x33L},{0xFCL,0x33L,0x33L,0xFCL},{1L,0x33L,3L,0x33L},{0x33L,(-1L),3L,3L},{1L,1L,0x33L,(-1L)}},{{3L,1L,3L,0xFCL},{3L,0xFCL,0xFCL,3L},{0x33L,0xFCL,(-1L),0xFCL},{0xFCL,1L,(-1L),(-1L)},{0x33L,0x33L,0xFCL,(-1L)},{3L,1L,3L,0xFCL}},{{3L,0xFCL,0xFCL,3L},{0x33L,0xFCL,(-1L),0xFCL},{0xFCL,1L,(-1L),(-1L)},{0x33L,0x33L,0xFCL,(-1L)},{3L,1L,3L,0xFCL},{3L,0xFCL,0xFCL,3L}},{{0x33L,0xFCL,(-1L),0xFCL},{0xFCL,1L,(-1L),(-1L)},{0x33L,0x33L,0xFCL,(-1L)},{3L,1L,3L,0xFCL},{3L,0xFCL,0xFCL,3L},{0x33L,0xFCL,(-1L),0xFCL}},{{0xFCL,1L,(-1L),(-1L)},{0x33L,0x33L,0xFCL,(-1L)},{3L,1L,3L,0xFCL},{3L,0xFCL,0xFCL,3L},{0x33L,0xFCL,(-1L),0xFCL},{0xFCL,1L,(-1L),(-1L)}},{{0x33L,0x33L,0xFCL,(-1L)},{3L,1L,3L,0xFCL},{3L,0xFCL,0xFCL,3L},{0x33L,0xFCL,(-1L),0xFCL},{0xFCL,1L,(-1L),(-1L)},{0x33L,0x33L,0xFCL,(-1L)}}};
static volatile uint64_t g_111 = 0x3412C06D41FC1B3DLL;/* VOLATILE GLOBAL g_111 */
static uint8_t g_126 = 0xD3L;
static uint32_t g_133 = 3UL;
static uint64_t g_137 = 0UL;
static uint32_t g_139 = 0x1AA685BEL;
static int16_t g_144 = 0xFF3CL;
static int8_t g_154 = 4L;
static int16_t g_159 = (-3L);
static uint16_t g_162 = 0xFBAAL;
static uint64_t g_164 = 0x25CFA702CAF5ADCELL;
static int32_t *g_166 = (void*)0;
static int32_t ** volatile g_165[3][10] = {{&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166},{&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166},{&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166}};
static volatile uint32_t g_236 = 1UL;/* VOLATILE GLOBAL g_236 */
static volatile uint32_t *g_235[10] = {&g_236,&g_236,&g_236,&g_236,&g_236,&g_236,&g_236,&g_236,&g_236,&g_236};
static volatile uint32_t **g_234 = &g_235[8];
static uint32_t *g_244 = &g_12;
static uint32_t **g_243 = &g_244;
static uint32_t **g_246 = &g_244;
static volatile uint32_t g_297 = 0x0140F11BL;/* VOLATILE GLOBAL g_297 */
static int16_t *g_308 = &g_144;
static int64_t **g_348 = (void*)0;
static uint16_t g_382[5] = {1UL,1UL,1UL,1UL,1UL};
static int32_t g_423 = 0L;
static volatile int8_t g_459 = 0xFCL;/* VOLATILE GLOBAL g_459 */
static uint8_t g_510 = 0xABL;
static uint16_t *g_539 = (void*)0;
static int32_t * volatile g_555 = &g_423;/* VOLATILE GLOBAL g_555 */
static int32_t * volatile g_578 = &g_423;/* VOLATILE GLOBAL g_578 */
static volatile uint64_t g_595 = 1UL;/* VOLATILE GLOBAL g_595 */
static volatile uint64_t * const  volatile g_594 = &g_595;/* VOLATILE GLOBAL g_594 */
static volatile uint64_t * const  volatile *g_593 = &g_594;
static int32_t g_598[6] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
static int32_t ** volatile g_656[4] = {&g_166,&g_166,&g_166,&g_166};
static int32_t ** volatile g_658 = &g_166;/* VOLATILE GLOBAL g_658 */
static int8_t g_722[4][9][5] = {{{(-10L),(-4L),(-10L),0x13L,0x1DL},{0x1FL,0x27L,0x1FL,0x8CL,0x8CL},{(-10L),(-4L),(-10L),0x13L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)}},{{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL}},{{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)}},{{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL},{(-1L),1L,(-1L),1L,(-10L)},{4L,0x26L,4L,0x1FL,0x1FL}}};
static int16_t g_737 = 1L;
static int32_t ** volatile g_740 = &g_166;/* VOLATILE GLOBAL g_740 */
static int32_t * volatile g_744 = &g_84;/* VOLATILE GLOBAL g_744 */
static int8_t g_915 = 9L;
static uint32_t g_976[7][7] = {{18446744073709551613UL,0x52F6A9C0L,0x52F6A9C0L,18446744073709551613UL,0x628B25DFL,0UL,18446744073709551613UL},{0UL,18446744073709551615UL,0x628B25DFL,0x628B25DFL,18446744073709551615UL,0UL,0x52F6A9C0L},{18446744073709551615UL,18446744073709551613UL,18446744073709551612UL,0xA6076E07L,0xA6076E07L,18446744073709551612UL,18446744073709551613UL},{18446744073709551615UL,0x52F6A9C0L,0UL,18446744073709551615UL,0UL,0UL,0x628B25DFL},{0x765AA0E6L,0x52F6A9C0L,0x765AA0E6L,0UL,0x52F6A9C0L,18446744073709551612UL,18446744073709551612UL},{0x52F6A9C0L,0x628B25DFL,0xA6076E07L,0x628B25DFL,0x52F6A9C0L,0xA6076E07L,0UL},{0UL,18446744073709551612UL,0UL,0UL,0UL,18446744073709551612UL,0UL}};
static volatile int64_t g_994 = 4L;/* VOLATILE GLOBAL g_994 */
static volatile int64_t *g_993 = &g_994;
static volatile int64_t **g_992[10] = {&g_993,&g_993,&g_993,&g_993,&g_993,&g_993,&g_993,&g_993,&g_993,&g_993};
static volatile int64_t ** volatile *g_991 = &g_992[9];
static volatile int64_t ** volatile * volatile *g_990[2][7][4] = {{{(void*)0,&g_991,&g_991,&g_991},{&g_991,&g_991,&g_991,&g_991},{(void*)0,&g_991,&g_991,(void*)0},{&g_991,(void*)0,&g_991,(void*)0},{(void*)0,&g_991,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_991,&g_991,&g_991,&g_991}},{{&g_991,&g_991,(void*)0,&g_991},{(void*)0,&g_991,(void*)0,(void*)0},{(void*)0,&g_991,&g_991,&g_991},{&g_991,&g_991,&g_991,&g_991},{(void*)0,&g_991,&g_991,(void*)0},{&g_991,(void*)0,&g_991,(void*)0},{(void*)0,&g_991,(void*)0,(void*)0}}};
static volatile uint16_t g_1026 = 65535UL;/* VOLATILE GLOBAL g_1026 */
static int32_t ** volatile g_1047 = &g_166;/* VOLATILE GLOBAL g_1047 */
static int64_t * const g_1062 = (void*)0;
static int64_t * const *g_1061 = &g_1062;
static int32_t ** volatile g_1100 = &g_166;/* VOLATILE GLOBAL g_1100 */
static uint8_t *g_1123 = &g_126;
static uint64_t g_1143[6][8] = {{0x6445566892E4BC09LL,1UL,0x6445566892E4BC09LL,0xBF023CCCFC6F9555LL,0xBF023CCCFC6F9555LL,0x6445566892E4BC09LL,1UL,0x6445566892E4BC09LL},{0xA0A9AB15511E3804LL,0xBF023CCCFC6F9555LL,0x9705B26FEB795607LL,0xBF023CCCFC6F9555LL,0xA0A9AB15511E3804LL,0xA0A9AB15511E3804LL,0xBF023CCCFC6F9555LL,0x9705B26FEB795607LL},{0xA0A9AB15511E3804LL,0xA0A9AB15511E3804LL,0xBF023CCCFC6F9555LL,0x9705B26FEB795607LL,0xBF023CCCFC6F9555LL,0xA0A9AB15511E3804LL,0xA0A9AB15511E3804LL,0xBF023CCCFC6F9555LL},{0x6445566892E4BC09LL,0xBF023CCCFC6F9555LL,0xBF023CCCFC6F9555LL,0x6445566892E4BC09LL,1UL,0x6445566892E4BC09LL,0xBF023CCCFC6F9555LL,0xBF023CCCFC6F9555LL},{0xBF023CCCFC6F9555LL,1UL,0x9705B26FEB795607LL,0x9705B26FEB795607LL,1UL,0xBF023CCCFC6F9555LL,1UL,0x9705B26FEB795607LL},{0x6445566892E4BC09LL,1UL,0x6445566892E4BC09LL,0xBF023CCCFC6F9555LL,0xBF023CCCFC6F9555LL,0x6445566892E4BC09LL,1UL,0x6445566892E4BC09LL}};
static int32_t *g_1147[5] = {&g_107[1][2][0],&g_107[1][2][0],&g_107[1][2][0],&g_107[1][2][0],&g_107[1][2][0]};
static int32_t * const g_1354 = (void*)0;
static int32_t ** volatile g_1355 = (void*)0;/* VOLATILE GLOBAL g_1355 */
static int32_t ** volatile g_1356 = &g_166;/* VOLATILE GLOBAL g_1356 */
static int64_t g_1358 = 3L;
static int64_t g_1360 = 0xB2337A63F253613ALL;
static int16_t g_1363 = 5L;
static int32_t ** volatile g_1364 = &g_166;/* VOLATILE GLOBAL g_1364 */
static int32_t **g_1368 = (void*)0;
static int32_t ***g_1367 = &g_1368;
static uint64_t **g_1385 = (void*)0;
static volatile int8_t g_1425 = (-4L);/* VOLATILE GLOBAL g_1425 */
static int8_t g_1530[10] = {0x71L,(-1L),0x71L,(-1L),0x71L,(-1L),0x71L,(-1L),0x71L,(-1L)};
static int32_t ** volatile g_1639 = &g_166;/* VOLATILE GLOBAL g_1639 */
static volatile uint32_t g_1659 = 18446744073709551610UL;/* VOLATILE GLOBAL g_1659 */
static uint32_t g_1688 = 4294967290UL;
static volatile uint8_t g_1776 = 1UL;/* VOLATILE GLOBAL g_1776 */
static volatile uint8_t *g_1775 = &g_1776;
static volatile uint8_t **g_1774 = &g_1775;
static int32_t g_1786 = 0xA614D3B8L;
static const uint32_t g_1799 = 0xA8CA73FAL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint32_t * func_15(uint32_t * p_16, uint32_t  p_17, uint32_t * p_18);
static uint32_t * func_20(int32_t * p_21, uint64_t  p_22);
static uint64_t  func_23(int32_t * p_24, int32_t * p_25, uint32_t * p_26);
static int32_t  func_32(uint64_t  p_33, uint32_t  p_34, uint32_t  p_35, const uint32_t * p_36);
static int64_t  func_50(uint64_t  p_51, int16_t  p_52, uint8_t  p_53, uint32_t * const  p_54);
static int32_t * const  func_61(uint16_t * const  p_62, int32_t * p_63);
static uint16_t * const  func_64(uint16_t  p_65, const uint64_t  p_66);
static uint8_t  func_67(uint8_t  p_68, uint8_t  p_69, int8_t  p_70, uint16_t * p_71);
static uint16_t * func_79(uint32_t  p_80, uint32_t  p_81, uint32_t  p_82);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6
 * writes: g_2 g_6
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_10 = 0L;
    uint32_t *l_19 = &g_12;
    int32_t l_1800 = 6L;
    uint32_t l_1801 = 0xCE4752DDL;
    for (g_2 = 0; (g_2 != 25); g_2 = safe_add_func_uint8_t_u_u(g_2, 8))
    { /* block id: 3 */
        int32_t *l_5 = (void*)0;
        uint32_t *l_11[8][8] = {{(void*)0,&g_12,&g_12,&g_12,(void*)0,(void*)0,&g_12,&g_12},{(void*)0,(void*)0,&g_12,&g_12,&g_12,(void*)0,(void*)0,&g_12},{&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,(void*)0,&g_12},{&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12,&g_12,(void*)0,&g_12,&g_12,&g_12}};
        int32_t l_13 = 0x711DB608L;
        uint32_t *l_14 = &g_12;
        const uint32_t *l_1798 = &g_1799;
        const uint32_t **l_1797 = &l_1798;
        int i, j;
        g_6 ^= 1L;
    }
    return l_1801;
}


/* ------------------------------------------ */
/* 
 * reads : g_1367 g_1047
 * writes: g_1368 g_1786 g_166
 */
static uint32_t * func_15(uint32_t * p_16, uint32_t  p_17, uint32_t * p_18)
{ /* block id: 924 */
    int32_t *l_1787 = &g_1786;
    int32_t *l_1788 = &g_1786;
    int32_t l_1789 = 2L;
    int32_t *l_1790[4];
    int8_t l_1791 = 0x33L;
    int8_t l_1792 = 0x03L;
    uint64_t l_1793 = 0x0075264373FAC6A8LL;
    int32_t **l_1796[9] = {&l_1788,&l_1788,&l_1788,&l_1788,&l_1788,&l_1788,&l_1788,&l_1788,&l_1788};
    int i;
    for (i = 0; i < 4; i++)
        l_1790[i] = &l_1789;
    l_1793--;
    (*g_1367) = (void*)0;
    (*l_1788) = p_17;
    (*g_1047) = p_18;
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_6 g_2 g_83 g_137 g_234 g_243 g_154 g_107 g_162 g_159 g_84 g_103 g_144 g_133 g_297 g_139 g_246 g_244 g_49 g_126 g_236 g_308 g_348 g_77 g_382 g_423 g_164 g_510 g_539 g_235 g_555 g_578 g_593 g_598 g_109 g_658 g_594 g_595 g_111 g_722 g_740 g_744 g_166 g_459 g_915 g_737 g_976 g_990 g_1026 g_1047 g_1100 g_1143 g_1354 g_1356 g_1358 g_1360 g_1363 g_1364 g_1367 g_1385 g_1425 g_993 g_994 g_1530 g_1639 g_1659 g_1688 g_1774 g_1786
 * writes: g_49 g_84 g_243 g_246 g_103 g_154 g_139 g_308 g_159 g_126 g_144 g_348 g_77 g_382 g_423 g_133 g_166 g_164 g_510 g_107 g_737 g_722 g_915 g_976 g_1026 g_1061 g_1123 g_1143 g_1147 g_137 g_1358 g_1360 g_1363 g_1367 g_1385 g_12 g_1688 g_162 g_1786
 */
static uint32_t * func_20(int32_t * p_21, uint64_t  p_22)
{ /* block id: 7 */
    int32_t *l_27 = &g_2;
    int32_t *l_1785 = &g_1786;
    (*l_1785) &= (func_23(p_21, l_27, l_27) , (!(((((safe_rshift_func_int8_t_s_u(p_22, 1)) < (((p_22 , (g_1360 <= (p_22 >= ((((18446744073709551615UL >= p_22) ^ 0x0BL) ^ p_22) && (*l_27))))) && 0L) == 1UL)) ^ (*l_27)) == (-2L)) , p_22)));
    return l_1785;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_6 g_2 g_83 g_137 g_234 g_243 g_154 g_107 g_162 g_159 g_84 g_103 g_144 g_133 g_297 g_139 g_246 g_244 g_49 g_126 g_236 g_308 g_348 g_77 g_382 g_423 g_164 g_510 g_539 g_235 g_555 g_578 g_593 g_598 g_109 g_658 g_594 g_595 g_111 g_722 g_740 g_744 g_166 g_459 g_915 g_737 g_976 g_990 g_1026 g_1047 g_1100 g_1143 g_1354 g_1356 g_1358 g_1360 g_1363 g_1364 g_1367 g_1385 g_1425 g_993 g_994 g_1530 g_1639 g_1659 g_1688 g_1774
 * writes: g_49 g_84 g_243 g_246 g_103 g_154 g_139 g_308 g_159 g_126 g_144 g_348 g_77 g_382 g_423 g_133 g_166 g_164 g_510 g_107 g_737 g_722 g_915 g_976 g_1026 g_1061 g_1123 g_1143 g_1147 g_137 g_1358 g_1360 g_1363 g_1367 g_1385 g_12 g_1688 g_162
 */
static uint64_t  func_23(int32_t * p_24, int32_t * p_25, uint32_t * p_26)
{ /* block id: 8 */
    uint64_t l_31 = 0xCAF1E2CD8491F199LL;
    uint16_t l_1614 = 65527UL;
    int32_t l_1664[2];
    uint32_t l_1695 = 4UL;
    int64_t l_1713[10][8][3] = {{{0xCDD9F8F1F85DC238LL,0x5C4169F0316A2F88LL,0xB3021C851681E1CELL},{0x91189D224E0D7720LL,1L,0xA434608474A63FB5LL},{1L,1L,1L},{1L,0xB28B4D85035A4651LL,0L},{0x91189D224E0D7720LL,0L,0L},{0xCDD9F8F1F85DC238LL,0xE257DB8FDC2FD084LL,0L},{(-6L),0x91189D224E0D7720LL,0L},{0x3B343A0AD9290289LL,0x171D5C56C8C87EA8LL,0L}},{{0x5C4169F0316A2F88LL,0x64016FFD7AF9652ALL,1L},{0xE1C18D5A6B988B26LL,0x64016FFD7AF9652ALL,0xA434608474A63FB5LL},{0x0322E4C401DEE2E6LL,0x171D5C56C8C87EA8LL,0xB3021C851681E1CELL},{0x64016FFD7AF9652ALL,0x91189D224E0D7720LL,0xFBDBD273D7724C60LL},{1L,0xE257DB8FDC2FD084LL,0xB11E9A765FA63891LL},{0x64016FFD7AF9652ALL,0L,0x33CD27E8FCD795E4LL},{0x0322E4C401DEE2E6LL,0xB28B4D85035A4651LL,0xD4DBA20618AD7873LL},{0xE1C18D5A6B988B26LL,1L,0xD4DBA20618AD7873LL}},{{0x5C4169F0316A2F88LL,1L,0x33CD27E8FCD795E4LL},{0x3B343A0AD9290289LL,0x5C4169F0316A2F88LL,0xB11E9A765FA63891LL},{(-6L),(-1L),0xFBDBD273D7724C60LL},{0xCDD9F8F1F85DC238LL,0x5C4169F0316A2F88LL,0xB3021C851681E1CELL},{0x91189D224E0D7720LL,1L,0xA434608474A63FB5LL},{1L,1L,1L},{1L,0xB28B4D85035A4651LL,0L},{0x91189D224E0D7720LL,0L,0L}},{{0xCDD9F8F1F85DC238LL,0xE257DB8FDC2FD084LL,0L},{(-6L),0x91189D224E0D7720LL,0L},{0x3B343A0AD9290289LL,0x171D5C56C8C87EA8LL,0L},{0x5C4169F0316A2F88LL,0x64016FFD7AF9652ALL,1L},{0xE1C18D5A6B988B26LL,0x64016FFD7AF9652ALL,0xA434608474A63FB5LL},{0x0322E4C401DEE2E6LL,0x171D5C56C8C87EA8LL,0xB3021C851681E1CELL},{0x64016FFD7AF9652ALL,0x91189D224E0D7720LL,0xFBDBD273D7724C60LL},{1L,0xE257DB8FDC2FD084LL,0xB11E9A765FA63891LL}},{{0x64016FFD7AF9652ALL,0L,0x33CD27E8FCD795E4LL},{0x0322E4C401DEE2E6LL,0xB28B4D85035A4651LL,0xD4DBA20618AD7873LL},{0xE1C18D5A6B988B26LL,1L,0xD4DBA20618AD7873LL},{0x5C4169F0316A2F88LL,1L,0x33CD27E8FCD795E4LL},{0x3B343A0AD9290289LL,0x5C4169F0316A2F88LL,0xB11E9A765FA63891LL},{(-6L),(-1L),0xFBDBD273D7724C60LL},{0xCDD9F8F1F85DC238LL,0x5C4169F0316A2F88LL,0xB3021C851681E1CELL},{0x91189D224E0D7720LL,1L,0xA434608474A63FB5LL}},{{1L,1L,1L},{1L,0xB28B4D85035A4651LL,0L},{0x91189D224E0D7720LL,0L,0L},{0xCDD9F8F1F85DC238LL,0xE257DB8FDC2FD084LL,0L},{(-6L),0x91189D224E0D7720LL,0L},{0x3B343A0AD9290289LL,0x171D5C56C8C87EA8LL,0L},{0x5C4169F0316A2F88LL,0x64016FFD7AF9652ALL,1L},{0xE1C18D5A6B988B26LL,0x64016FFD7AF9652ALL,0xA434608474A63FB5LL}},{{0x0322E4C401DEE2E6LL,0x171D5C56C8C87EA8LL,0xB3021C851681E1CELL},{0x64016FFD7AF9652ALL,0x91189D224E0D7720LL,0xFBDBD273D7724C60LL},{1L,0xE257DB8FDC2FD084LL,0xB11E9A765FA63891LL},{0x64016FFD7AF9652ALL,0L,0x33CD27E8FCD795E4LL},{0L,0x81E4F5F38BED2A22LL,1L},{0xFB789CEA79581AF8LL,0x2C662942ED0CE65ALL,1L},{0x833B623FC31126B0LL,0xF715330EA55EF7DCLL,0x91189D224E0D7720LL},{0x4D22C2F79B4BA601LL,0x833B623FC31126B0LL,0xCDD9F8F1F85DC238LL}},{{0x87A3A265A2AF0BE9LL,(-1L),(-6L)},{0x735D12C9DAFBBE66LL,0x833B623FC31126B0LL,0x3B343A0AD9290289LL},{(-10L),0xF715330EA55EF7DCLL,0x5C4169F0316A2F88LL},{0x2C662942ED0CE65ALL,0x2C662942ED0CE65ALL,0xE1C18D5A6B988B26LL},{0x2C662942ED0CE65ALL,0x81E4F5F38BED2A22LL,0x0322E4C401DEE2E6LL},{(-10L),0x05A883033FED6DE1LL,0x64016FFD7AF9652ALL},{0x735D12C9DAFBBE66LL,0x40B59C396BBE1132LL,1L},{0x87A3A265A2AF0BE9LL,(-10L),0x64016FFD7AF9652ALL}},{{0x4D22C2F79B4BA601LL,(-1L),0x0322E4C401DEE2E6LL},{0x833B623FC31126B0LL,0x20EC08C89E2F9E18LL,0xE1C18D5A6B988B26LL},{0xFB789CEA79581AF8LL,0x20EC08C89E2F9E18LL,0x5C4169F0316A2F88LL},{0L,(-1L),0x3B343A0AD9290289LL},{0x20EC08C89E2F9E18LL,(-10L),(-6L)},{0xF715330EA55EF7DCLL,0x40B59C396BBE1132LL,0xCDD9F8F1F85DC238LL},{0x20EC08C89E2F9E18LL,0x05A883033FED6DE1LL,0x91189D224E0D7720LL},{0L,0x81E4F5F38BED2A22LL,1L}},{{0xFB789CEA79581AF8LL,0x2C662942ED0CE65ALL,1L},{0x833B623FC31126B0LL,0xF715330EA55EF7DCLL,0x91189D224E0D7720LL},{0x4D22C2F79B4BA601LL,0x833B623FC31126B0LL,0xCDD9F8F1F85DC238LL},{0x87A3A265A2AF0BE9LL,(-1L),(-6L)},{0x735D12C9DAFBBE66LL,0x833B623FC31126B0LL,0x3B343A0AD9290289LL},{(-10L),0xF715330EA55EF7DCLL,0x5C4169F0316A2F88LL},{0x2C662942ED0CE65ALL,0x2C662942ED0CE65ALL,0xE1C18D5A6B988B26LL},{0x2C662942ED0CE65ALL,0x81E4F5F38BED2A22LL,0x0322E4C401DEE2E6LL}}};
    int8_t l_1737 = (-1L);
    uint32_t l_1741 = 0UL;
    uint8_t **l_1773 = (void*)0;
    int64_t *l_1779 = (void*)0;
    int64_t *l_1780[2];
    int32_t *l_1781 = &l_1664[0];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1664[i] = 0x17B24D42L;
    for (i = 0; i < 2; i++)
        l_1780[i] = (void*)0;
    if (((+(safe_rshift_func_int16_t_s_s((l_31 >= l_31), 5))) , 8L))
    { /* block id: 9 */
        int32_t l_47 = 0L;
        uint16_t *l_48 = &g_49;
        uint32_t * const l_57[9][9][3] = {{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}},{{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12},{&g_12,&g_12,&g_12}}};
        int64_t *l_1357 = &g_1358;
        int64_t *l_1359 = &g_1360;
        uint32_t l_1361 = 0x1E2D5B7FL;
        int16_t *l_1362 = &g_1363;
        int32_t *l_1587 = &g_423;
        int32_t l_1706 = 0L;
        int32_t l_1708 = 1L;
        int32_t l_1710 = 7L;
        int32_t *l_1739 = &l_1664[1];
        int32_t *l_1740[7][1] = {{&g_2},{&g_2},{&l_1708},{&g_2},{&g_2},{&l_1708},{&g_2}};
        int32_t **l_1757 = &l_1740[1][0];
        int i, j, k;
        if (((*l_1587) = func_32((safe_sub_func_int16_t_s_s(((safe_mod_func_int64_t_s_s((l_47 = (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(g_12, ((((*l_1362) |= (((g_6 && ((8L <= ((*l_1359) ^= (((l_31 , ((*l_48) = (safe_unary_minus_func_int16_t_s((safe_unary_minus_func_uint32_t_u((l_47 > 0xBBC1L))))))) , ((*l_1357) &= ((l_47 != (func_50(((-1L) == ((safe_mod_func_int8_t_s_s(((l_47 < l_47) != 0x2BD68E480B0DEBF6LL), l_47)) , g_12)), g_2, l_31, l_57[7][8][2]) | l_31)) , (-1L)))) > l_31))) , (*g_594))) , g_382[3]) , l_1361)) == 0x2A25L) ^ 8L))), 0xFB01L))), 0x2721CB28AD678F67LL)) > l_31), 0x060DL)), (*g_244), l_31, &g_12)))
        { /* block id: 797 */
            int32_t l_1594 = 0L;
            int16_t l_1607 = 0xE5E1L;
            (*l_1587) = ((((*l_48) = (safe_lshift_func_uint16_t_u_u((safe_mod_func_int64_t_s_s(((*l_1359) = (safe_mul_func_int8_t_s_s(l_1594, l_1594))), (safe_mod_func_uint64_t_u_u((((**g_246) = 0x84FBDB10L) && l_1594), 7UL)))), 2))) == (safe_div_func_uint16_t_u_u((~((+(1UL >= (safe_sub_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(l_1594, (((((((**g_234) < (safe_rshift_func_uint8_t_u_s((*l_1587), 4))) != 0x682FL) != 65527UL) | l_1594) , 18446744073709551606UL) , (*l_1587)))), (*p_26))))) & l_1594)), l_1607))) & l_31);
            for (g_126 = 0; (g_126 != 11); g_126++)
            { /* block id: 804 */
                int32_t *l_1610 = &g_84;
                int32_t **l_1611[9][8][3] = {{{&g_166,&g_166,&g_166},{&l_1610,&g_166,(void*)0},{&l_1587,(void*)0,&g_166},{&g_166,&l_1610,&l_1610},{&l_1610,&g_166,(void*)0},{&l_1610,(void*)0,&g_166},{(void*)0,&g_166,&g_166},{&g_166,&l_1587,&l_1610}},{{&l_1587,&g_166,(void*)0},{&l_1610,(void*)0,&g_166},{&g_166,&g_166,&l_1587},{(void*)0,&l_1610,(void*)0},{(void*)0,(void*)0,&g_166},{&l_1587,&g_166,&l_1587},{(void*)0,&g_166,(void*)0},{&g_166,&l_1610,&l_1587}},{{&l_1610,&g_166,&l_1610},{&g_166,&l_1587,&l_1610},{(void*)0,&g_166,&l_1587},{&l_1587,&l_1587,&l_1587},{&l_1587,(void*)0,(void*)0},{&l_1587,&l_1610,&l_1587},{&l_1587,&g_166,(void*)0},{&l_1587,&l_1587,&l_1587}},{{&l_1587,&l_1610,(void*)0},{&l_1587,&l_1610,&l_1587},{&l_1610,&l_1587,&l_1587},{&l_1587,&l_1587,&l_1610},{(void*)0,(void*)0,&l_1610},{&l_1610,&l_1587,&l_1587},{(void*)0,(void*)0,&g_166},{&l_1610,&l_1587,&l_1610}},{{(void*)0,(void*)0,(void*)0},{(void*)0,&l_1587,&l_1587},{&g_166,&l_1587,&g_166},{&g_166,&l_1610,&l_1587},{&g_166,&l_1610,&g_166},{&g_166,&l_1587,&l_1587},{&l_1610,&g_166,(void*)0},{&g_166,&l_1610,(void*)0}},{{&g_166,(void*)0,&l_1587},{&g_166,&l_1587,&l_1610},{&g_166,&g_166,&g_166},{(void*)0,&l_1587,&l_1610},{(void*)0,&g_166,&g_166},{&l_1610,&l_1587,&l_1610},{(void*)0,(void*)0,&g_166},{&l_1610,(void*)0,&l_1610}},{{(void*)0,&l_1587,&g_166},{&l_1587,&l_1610,&l_1610},{&l_1610,&g_166,&l_1587},{&l_1587,&l_1610,(void*)0},{&l_1587,&g_166,(void*)0},{&l_1587,&l_1610,&l_1587},{&l_1587,&g_166,&g_166},{&l_1587,&l_1610,&l_1587}},{{&l_1587,&g_166,&g_166},{&l_1587,&l_1610,&l_1587},{(void*)0,&l_1587,(void*)0},{&g_166,(void*)0,&l_1610},{&l_1610,(void*)0,&g_166},{(void*)0,&l_1587,&l_1587},{&l_1610,&g_166,&l_1610},{&g_166,&l_1587,&l_1610}},{{(void*)0,&g_166,&l_1587},{&l_1587,&l_1587,&l_1587},{&l_1587,(void*)0,(void*)0},{&l_1587,&l_1610,&l_1587},{&l_1587,&g_166,(void*)0},{&l_1587,&l_1587,&l_1587},{&l_1587,&l_1610,(void*)0},{&l_1587,&l_1610,&l_1587}}};
                int i, j, k;
                l_1587 = (p_24 = l_1610);
                (*l_1587) = (*p_25);
            }
            (*l_1587) = (safe_mod_func_uint64_t_u_u((l_1614 , l_1607), (*g_993)));
            return l_31;
        }
        else
        { /* block id: 811 */
            int8_t l_1623 = (-1L);
            int32_t l_1635 = 0x0CE14B63L;
            int32_t l_1712 = 0xF3D20F3BL;
            int16_t l_1715 = 1L;
            const uint32_t l_1736 = 0x95643043L;
lbl_1696:
            if (l_1614)
            { /* block id: 812 */
                uint64_t l_1624 = 0x201956810ACE3625LL;
                uint32_t **l_1644 = (void*)0;
                for (g_133 = 0; (g_133 <= 0); g_133 += 1)
                { /* block id: 815 */
                    uint8_t l_1658 = 0x35L;
                    int i;
                    if (g_1530[(g_133 + 4)])
                    { /* block id: 816 */
                        uint64_t *l_1633 = &g_164;
                        int8_t *l_1634[1][8][10] = {{{(void*)0,&l_1623,&l_1623,(void*)0,&l_1623,&g_1530[1],&g_1530[(g_133 + 8)],&g_77,&l_1623,&g_77},{&l_1623,&g_1530[(g_133 + 8)],(void*)0,&g_77,(void*)0,&g_915,&l_1623,&g_1530[(g_133 + 8)],&l_1623,&g_1530[9]},{&g_1530[(g_133 + 8)],(void*)0,&g_1530[(g_133 + 8)],&g_77,&g_1530[(g_133 + 8)],(void*)0,&g_77,&g_915,&g_1530[(g_133 + 8)],(void*)0},{&g_1530[1],(void*)0,&g_1530[(g_133 + 8)],&g_915,&g_1530[(g_133 + 4)],&g_1530[9],&g_1530[(g_133 + 8)],&g_1530[9],&g_1530[(g_133 + 4)],&g_915},{&g_77,&g_77,&g_77,(void*)0,&l_1623,&l_1623,&g_77,&g_722[2][0][0],&g_77,&g_77},{&l_1623,&g_1530[(g_133 + 8)],(void*)0,&l_1623,&g_1530[(g_133 + 8)],(void*)0,&g_1530[1],&g_722[2][0][0],&g_77,&l_1623},{&g_77,&g_1530[9],&g_77,&g_915,&g_77,(void*)0,&g_915,&g_1530[9],&g_915,&l_1623},{&g_915,&l_1623,&g_1530[(g_133 + 8)],&g_1530[9],&g_915,&g_1530[(g_133 + 4)],&g_1530[(g_133 + 4)],&g_915,&g_1530[9],&g_1530[(g_133 + 8)]}}};
                        int i, j, k;
                        l_1635 ^= (safe_sub_func_int64_t_s_s(((((g_1530[(g_133 + 8)] ^ ((g_915 = (4294967292UL ^ (g_1530[(g_133 + 8)] ^ (((((*l_1633) ^= (((((*g_308) != (0x610BL & (((((safe_sub_func_uint64_t_u_u((((safe_mul_func_int16_t_s_s(((((safe_rshift_func_uint16_t_u_s(l_1623, ((l_1624 < l_1624) & (safe_rshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u((safe_sub_func_int8_t_s_s((((l_1624 < l_1614) ^ 0UL) && g_1530[(g_133 + 8)]), (*l_1587))), 0)), g_1530[(g_133 + 4)])), 7))))) != (*g_594)) , (*p_24)) <= (*p_24)), g_722[2][0][0])) , g_1530[(g_133 + 4)]) ^ l_1623), 5L)) == l_1614) < 1L) , l_31) < 0x54L))) < (*p_25)) || 0xD7C8C8B1D0C04568LL) >= (*l_1587))) != g_1530[(g_133 + 8)]) || 0xB5C7L) >= (-9L))))) >= l_1624)) >= 0L) <= g_107[1][2][0]) && g_1530[(g_133 + 4)]), (*l_1587)));
                        if (g_164)
                            goto lbl_1696;
                        return l_1635;
                    }
                    else
                    { /* block id: 821 */
                        uint16_t **l_1636 = &l_48;
                        int8_t *l_1637 = &l_1623;
                        int32_t l_1638 = 1L;
                        (*l_1587) = ((((*g_244) = (((*l_1636) = &g_49) == (void*)0)) , l_1637) != (void*)0);
                        if (l_1638)
                            break;
                        if ((*p_25))
                            break;
                    }
                    if (l_47)
                        goto lbl_1756;
                    if ((*p_25))
                        continue;
                    for (l_1614 = 0; (l_1614 <= 0); l_1614 += 1)
                    { /* block id: 831 */
                        const int32_t *l_1648 = &l_47;
                        const int32_t **l_1647 = &l_1648;
                        const int32_t ***l_1649 = &l_1647;
                        int8_t *l_1660 = (void*)0;
                        int8_t *l_1661 = &g_915;
                        (*g_1639) = p_24;
                        (*l_1587) = ((((safe_lshift_func_int8_t_s_s((l_1614 >= (safe_rshift_func_int16_t_s_u(((l_1644 != (void*)0) >= 0xE94A2C0C297A0580LL), 6))), ((*l_1661) |= ((safe_add_func_uint32_t_u_u(((((&g_1354 != ((*l_1649) = (g_107[5][5][0] , l_1647))) || 250UL) <= (safe_mod_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u(((l_1624 || (*p_24)) & l_1658), g_1530[(g_133 + 4)])) != g_1659), 0x18L)), 65526UL)) , (*p_26)), (*g_244)))) > (-1L)), 2L)) | 0xFA9E9E9E2193C2C8LL)))) == (*g_166)) == 0UL) >= (*l_1648));
                    }
                }
            }
            else
            { /* block id: 838 */
                uint32_t l_1665 = 7UL;
                uint64_t l_1674 = 0UL;
                int32_t l_1679 = 1L;
                int32_t l_1680[5] = {0L,0L,0L,0L,0L};
                int32_t *l_1681 = &l_1635;
                int32_t *l_1682 = &l_1664[0];
                int32_t *l_1683 = &l_1680[2];
                int32_t *l_1684 = &l_1664[1];
                int32_t *l_1685 = &l_1679;
                int32_t *l_1686 = &l_1680[0];
                int32_t *l_1687[5] = {&l_1664[0],&l_1664[0],&l_1664[0],&l_1664[0],&l_1664[0]};
                int i;
                for (l_31 = 3; (l_31 <= 44); l_31 = safe_add_func_uint64_t_u_u(l_31, 9))
                { /* block id: 841 */
                    for (g_137 = 0; (g_137 <= 3); g_137 += 1)
                    { /* block id: 844 */
                        int i;
                        l_1664[1] = (&l_1587 != (void*)0);
                        (*l_1587) = (((l_1665 , (l_1665 && ((safe_add_func_int16_t_s_s(0x5922L, l_1665)) , ((safe_rshift_func_int8_t_s_u((((safe_sub_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(l_1674, ((*g_308) &= (((*l_1587) && (safe_mod_func_uint32_t_u_u(8UL, 4L))) <= (**g_246))))), 0xB48AL)) , l_1674) != 65526UL), l_1664[1])) ^ l_1635)))) && g_598[2]) <= l_1635);
                    }
                    for (g_737 = 0; (g_737 <= 9); g_737 += 1)
                    { /* block id: 851 */
                        return l_1674;
                    }
                    (*l_1587) |= (safe_mod_func_int8_t_s_s(0xA7L, 253UL));
                }
                g_1688++;
                (*l_1682) |= (safe_lshift_func_int8_t_s_s((4294967292UL && (safe_mul_func_uint8_t_u_u(l_1695, (*l_1587)))), 1));
            }
            for (l_31 = 0; (l_31 <= 2); l_31 += 1)
            { /* block id: 862 */
                uint32_t l_1699 = 0x60A4D19BL;
                int32_t l_1704 = 0x73FDC3DCL;
                int32_t l_1707 = 0x380A68ADL;
                int32_t l_1711 = 0x1CCA43C9L;
                int32_t l_1714 = 3L;
                int32_t l_1716 = 0x07728472L;
                int32_t l_1717 = 0xFD86C90DL;
                uint32_t l_1721 = 4294967287UL;
                (*l_1587) = (*p_25);
                if ((*p_24))
                    break;
                for (g_137 = 0; (g_137 <= 1); g_137 += 1)
                { /* block id: 867 */
                    int32_t *l_1697 = &g_423;
                    int i, j;
                    l_1697 = &l_1664[g_137];
                    l_1699 &= (!l_1695);
                    for (g_1358 = 3; (g_1358 <= 9); g_1358 += 1)
                    { /* block id: 872 */
                        if (g_1360)
                            goto lbl_1696;
                        (*l_1587) &= ((0xF8L || ((*l_1697) = l_1635)) >= l_1623);
                        return (**g_593);
                    }
                }
                for (g_162 = 0; (g_162 <= 2); g_162 += 1)
                { /* block id: 881 */
                    int32_t l_1709[10];
                    uint16_t l_1718 = 1UL;
                    uint32_t ***l_1725 = &g_246;
                    int8_t *l_1726 = (void*)0;
                    uint8_t *l_1734 = (void*)0;
                    uint8_t *l_1735 = &g_510;
                    int32_t **l_1738 = &g_166;
                    int i, j;
                    for (i = 0; i < 10; i++)
                        l_1709[i] = (-1L);
                    l_1704 |= (safe_mul_func_uint16_t_u_u((safe_mod_func_int32_t_s_s(l_1664[0], ((*l_1587) = (*p_25)))), (*g_308)));
                    for (g_139 = 0; (g_139 <= 2); g_139 += 1)
                    { /* block id: 886 */
                        if (g_2)
                            goto lbl_1696;
                        return l_1635;
                    }
                    for (g_1360 = 2; (g_1360 >= 0); g_1360 -= 1)
                    { /* block id: 892 */
                        int32_t *l_1705[3];
                        int i, j;
                        for (i = 0; i < 3; i++)
                            l_1705[i] = &l_47;
                        --l_1718;
                    }
                    (*l_1738) = func_61(func_64((l_1721 , (safe_unary_minus_func_int8_t_s((l_1635 &= (safe_mod_func_int16_t_s_s((l_1715 == (((*l_1725) = &p_26) != &p_26)), 0x4F4EL)))))), (((!((safe_div_func_int32_t_s_s(((((safe_add_func_int32_t_s_s(((*l_1587) != (((((*l_1735) = (safe_mod_func_uint8_t_u_u((l_1664[0] ^= (l_1712 , (l_1713[7][7][0] && (*p_26)))), l_1712))) && g_382[2]) | (*p_26)) <= 0x4BE61657L)), (*p_26))) , 18446744073709551611UL) ^ l_1714) , 0xCAFDAB48L), l_1736)) == l_1712)) , l_1737) <= g_164)), &l_1712);
                }
            }
        }
        l_1741++;
lbl_1756:
        for (g_1363 = 1; (g_1363 < (-20)); g_1363--)
        { /* block id: 906 */
            int32_t l_1746 = 0xB170FEB5L;
            int32_t l_1747 = 0x053BFC60L;
            int32_t l_1748 = 0xB15B9B13L;
            int32_t l_1749 = 0L;
            int32_t l_1750 = (-1L);
            int32_t l_1751 = 0xF7B92D22L;
            int32_t l_1752 = (-1L);
            uint32_t l_1753 = 0x895589F2L;
            --l_1753;
            return (*g_594);
        }
        (*l_1757) = p_24;
    }
    else
    { /* block id: 912 */
        int64_t l_1760 = (-8L);
        for (g_1360 = 0; (g_1360 >= 25); g_1360 = safe_add_func_uint64_t_u_u(g_1360, 1))
        { /* block id: 915 */
            uint32_t l_1761 = 0x90C547C9L;
            l_1761 |= l_1760;
        }
    }
    (*l_1781) |= ((((!(safe_sub_func_int16_t_s_s((safe_add_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((g_1360 = (safe_lshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((((l_1773 != g_1774) <= (((l_31 < (safe_rshift_func_uint8_t_u_u(((*p_25) , ((l_1614 > 18446744073709551609UL) == l_1741)), ((*g_594) ^ (-1L))))) >= 0x7214L) | 0x0578A7A80BEE009FLL)) & l_1737), l_1737)), 0))) ^ l_1741) & (*g_308)), 0x2BL)), l_1713[7][7][0])), 0x81A4L))) , (void*)0) != (void*)0) >= g_915);
    return (**g_593);
}


/* ------------------------------------------ */
/* 
 * reads : g_103 g_1356 g_166 g_1364 g_1367 g_1385 g_144 g_12 g_744 g_84 g_243 g_244 g_423 g_737 g_976 g_308 g_234 g_235 g_236 g_159 g_162 g_510 g_594 g_595 g_1425 g_1100 g_555 g_1047 g_993 g_994 g_382 g_658 g_598 g_107
 * writes: g_103 g_166 g_1367 g_1385 g_12 g_423 g_737 g_915 g_154 g_144 g_159 g_1363 g_49 g_382 g_510 g_164 g_126 g_84
 */
static int32_t  func_32(uint64_t  p_33, uint32_t  p_34, uint32_t  p_35, const uint32_t * p_36)
{ /* block id: 649 */
    int32_t **l_1366 = &g_1147[0];
    int32_t ***l_1365 = &l_1366;
    int32_t *l_1370[3];
    uint8_t *l_1380 = &g_510;
    uint8_t *l_1383 = &g_126;
    int32_t l_1390 = 0L;
    uint32_t ***l_1397 = &g_246;
    int16_t * const *l_1442 = &g_308;
    int32_t l_1485 = 0x3658CE85L;
    int32_t l_1495 = 0xD3C0888DL;
    int i;
    for (i = 0; i < 3; i++)
        l_1370[i] = &g_2;
    for (g_103 = 0; (g_103 >= 0); g_103 -= 1)
    { /* block id: 652 */
        int32_t ****l_1369 = &g_1367;
        int32_t **l_1371 = &g_166;
        int32_t l_1372 = 0x78BF2B1BL;
        const int16_t **l_1412 = (void*)0;
        uint32_t l_1420 = 0xC6FA0189L;
        uint16_t **l_1433 = &g_539;
        uint16_t l_1434[1][4];
        int32_t l_1466 = 0x10162DDDL;
        int32_t l_1469[9][10][2] = {{{(-5L),0x264D7789L},{0L,0L},{0L,1L},{0x7EC3E35FL,1L},{0x218CF469L,0xCD92930EL},{1L,0xCD92930EL},{0x218CF469L,1L},{0x7EC3E35FL,1L},{0L,0L},{0L,0x264D7789L}},{{(-5L),1L},{0x330183CCL,(-1L)},{0x77FACEBFL,1L},{(-1L),(-1L)},{1L,(-1L)},{0L,1L},{0x9F6241BAL,0L},{3L,0x9F6241BAL},{(-1L),0x264D7789L},{0x496F37CEL,0x987F0B6EL}},{{3L,5L},{0x987F0B6EL,1L},{0xCD92930EL,0xAA8E1F29L},{1L,(-1L)},{(-1L),1L},{1L,0xC9C53DEDL},{0x330183CCL,1L},{0xB67F8D10L,0x264D7789L},{5L,0xD266EAB6L},{0L,0xB67F8D10L}},{{0L,1L},{0xAA8E1F29L,0L},{1L,0x37516BA2L},{(-1L),1L},{0xD266EAB6L,(-5L)},{0L,0x7EC3E35FL},{0x24821627L,0x264D7789L},{1L,0x77FACEBFL},{0x330183CCL,0x496F37CEL},{1L,1L}},{{1L,1L},{1L,0x218CF469L},{0x37516BA2L,1L},{(-1L),0x24821627L},{3L,(-1L)},{0xC9C53DEDL,0x264D7789L},{0xC9C53DEDL,(-1L)},{3L,0x24821627L},{(-1L),1L},{0x37516BA2L,0x218CF469L}},{{1L,1L},{1L,1L},{1L,0x496F37CEL},{0x330183CCL,0x77FACEBFL},{1L,0x264D7789L},{0x24821627L,0x7EC3E35FL},{0L,(-5L)},{0xD266EAB6L,1L},{(-1L),0x37516BA2L},{1L,0L}},{{0xAA8E1F29L,1L},{0x264D7789L,0xE5ADF924L},{0x5F636309L,0x0C67AE14L},{(-1L),0xD0B3A447L},{0xE5ADF924L,0x1B33B6F1L},{(-1L),0xD7258280L},{0L,(-4L)},{(-1L),0x03E23F10L},{0xE16C135FL,0x330183CCL},{0xC9A5F1EBL,1L}},{{1L,(-1L)},{0xAA9C6444L,1L},{(-8L),0xD0B3A447L},{0x7AC33B9EL,1L},{0xAA9C6444L,6L},{1L,1L},{0x66D711DAL,3L},{0xE16C135FL,(-1L)},{0x03E23F10L,(-4L)},{0x33F5F030L,0x7AC33B9EL}},{{(-1L),0L},{0L,0xD0B3A447L},{6L,0x264D7789L},{0x5F636309L,0x6189525DL},{6L,0x177044CFL},{0L,0xC9A5F1EBL},{0xE16C135FL,0xC9A5F1EBL},{0L,0x177044CFL},{6L,0x6189525DL},{0x5F636309L,0x264D7789L}}};
        uint8_t *l_1545 = (void*)0;
        uint64_t l_1555 = 0x94BE8374699FAE5CLL;
        int8_t l_1579 = 0xE8L;
        uint32_t l_1584 = 7UL;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 4; j++)
                l_1434[i][j] = 0x9944L;
        }
        (*g_1364) = (*g_1356);
        if (((l_1365 == ((*l_1369) = g_1367)) , (l_1372 = (((*l_1371) = l_1370[1]) != p_36))))
        { /* block id: 657 */
            int32_t l_1373 = (-5L);
            uint8_t *l_1381 = (void*)0;
            uint8_t **l_1382[4][10] = {{&l_1381,&l_1381,&l_1381,&l_1381,&l_1380,&l_1381,&l_1381,&l_1380,&l_1381,&l_1381},{&l_1381,&l_1381,&l_1381,&l_1381,&l_1380,&l_1380,&l_1381,&l_1381,&l_1381,&l_1381},{&l_1380,&l_1381,&l_1381,&l_1381,&l_1381,&l_1381,&l_1381,&l_1380,&l_1380,&l_1381},{&l_1380,&l_1381,&l_1381,&l_1381,&l_1381,&l_1380,&l_1381,&l_1381,&l_1380,&l_1381}};
            uint64_t ***l_1386 = (void*)0;
            uint64_t ***l_1387[10][2];
            int16_t * const *l_1441 = &g_308;
            int32_t *l_1443 = &g_84;
            int i, j;
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 2; j++)
                    l_1387[i][j] = &g_1385;
            }
            (*l_1371) = l_1370[1];
            l_1373 = 6L;
            g_423 &= (safe_add_func_uint8_t_u_u(((0x72B1E7BCL && ((**g_243) = (((safe_mul_func_uint8_t_u_u((l_1390 &= ((safe_mul_func_int64_t_s_s(p_35, ((g_1385 = ((p_35 > ((l_1380 == (l_1383 = l_1381)) & (~l_1373))) , g_1385)) == ((safe_div_func_int8_t_s_s(((0x65C6E42E2FB44802LL && (-4L)) , g_144), p_34)) , (void*)0)))) || p_35)), 5UL)) , (*p_36)) >= (*g_744)))) ^ p_33), 0x1BL));
            for (g_737 = 0; (g_737 <= 0); g_737 += 1)
            { /* block id: 667 */
                int32_t *l_1391[10] = {&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2};
                uint32_t ***l_1396 = &g_243;
                uint8_t *** const l_1430 = &l_1382[1][0];
                int32_t *l_1445[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int32_t l_1451 = 2L;
                int i;
                for (g_423 = 0; (g_423 <= 0); g_423 += 1)
                { /* block id: 670 */
                    uint32_t l_1400 = 4294967291UL;
                    int32_t l_1407 = (-5L);
                    (*l_1371) = l_1391[6];
                    for (g_915 = 2; (g_915 <= 6); g_915 += 1)
                    { /* block id: 674 */
                        int8_t *l_1401[9][9][3] = {{{&g_722[2][7][0],&g_154,(void*)0},{&g_154,&g_915,&g_722[2][0][0]},{&g_77,&g_915,&g_77},{&g_154,&g_154,&g_722[2][0][0]},{&g_77,(void*)0,&g_915},{&g_722[2][0][0],&g_722[2][0][4],&g_722[2][0][4]},{&g_77,&g_915,&g_77},{&g_154,(void*)0,&g_77},{(void*)0,&g_154,&g_154}},{{&g_154,&g_722[2][0][0],&g_77},{&g_77,&g_154,&g_77},{&g_915,(void*)0,&g_154},{&g_722[1][2][1],&g_915,(void*)0},{&g_722[1][5][3],&g_722[2][0][4],&g_154},{&g_154,(void*)0,&g_77},{&g_722[3][8][2],&g_154,&g_722[3][0][2]},{&g_154,&g_915,&g_154},{&g_915,&g_915,&g_722[3][3][2]}},{{&g_154,&g_154,&g_722[3][2][1]},{&g_722[3][7][1],&g_154,&g_915},{&g_915,&g_77,(void*)0},{&g_722[2][0][0],&g_722[3][6][3],(void*)0},{&g_722[2][0][0],&g_915,(void*)0},{&g_722[2][0][0],&g_915,&g_915},{&g_722[1][1][2],&g_77,&g_722[2][7][0]},{&g_154,&g_915,&g_154},{&g_722[3][2][1],&g_915,&g_77}},{{&g_722[3][7][1],(void*)0,&g_154},{&g_154,&g_722[2][7][0],&g_77},{&g_154,&g_915,&g_722[2][0][0]},{&g_77,(void*)0,&g_77},{&g_722[2][0][0],&g_722[2][0][0],&g_154},{&g_154,&g_722[0][3][2],(void*)0},{&g_722[1][7][4],&g_722[2][0][0],&g_154},{&g_154,&g_77,&g_77},{&g_722[1][7][4],&g_722[3][8][2],&g_915}},{{&g_154,&g_77,&g_722[1][2][1]},{&g_722[2][0][0],&g_722[3][3][2],&g_722[1][5][3]},{&g_77,&g_154,&g_154},{&g_154,&g_915,&g_722[3][8][2]},{&g_154,&g_722[0][5][2],&g_154},{&g_722[3][7][1],&g_722[2][0][4],&g_915},{&g_722[3][2][1],&g_154,&g_154},{&g_154,&g_722[2][0][0],&g_722[3][7][1]},{&g_722[0][5][2],&g_77,&g_915}},{{&g_915,&g_77,&g_722[2][0][0]},{&g_722[2][0][0],&g_722[3][2][1],&g_722[2][0][0]},{&g_722[2][0][0],&g_77,&g_722[2][0][0]},{&g_915,&g_77,&g_722[1][1][2]},{(void*)0,&g_722[2][0][0],&g_915},{&g_77,&g_154,&g_154},{&g_722[2][0][0],&g_722[2][0][4],&g_722[2][0][0]},{&g_77,&g_722[0][5][2],&g_915},{&g_77,&g_915,&g_722[3][3][2]}},{{&g_77,&g_154,(void*)0},{&g_722[3][3][2],&g_722[3][3][2],(void*)0},{(void*)0,&g_77,&g_154},{&g_722[2][0][0],&g_722[3][8][2],&g_915},{&g_77,&g_77,&g_77},{&g_915,&g_722[2][0][0],&g_915},{&g_915,&g_722[0][3][2],&g_154},{&g_915,&g_722[2][0][0],(void*)0},{&g_722[2][0][0],(void*)0,(void*)0}},{{(void*)0,&g_915,&g_722[3][3][2]},{&g_722[1][2][1],&g_722[2][7][0],&g_915},{&g_722[2][0][0],(void*)0,&g_722[2][0][0]},{(void*)0,&g_915,&g_154},{&g_915,&g_915,&g_915},{&g_77,&g_77,&g_722[1][1][2]},{&g_722[2][0][0],&g_722[1][7][4],&g_722[2][0][0]},{&g_722[0][3][2],&g_915,&g_722[2][0][0]},{&g_722[3][8][2],&g_77,&g_722[2][0][0]}},{{&g_722[0][3][2],&g_154,&g_915},{&g_722[2][0][0],&g_915,&g_722[3][7][1]},{&g_77,&g_77,&g_154},{&g_915,&g_722[3][0][2],&g_915},{(void*)0,&g_154,&g_154},{&g_722[2][0][0],&g_915,&g_722[3][8][2]},{&g_722[1][2][1],(void*)0,&g_154},{(void*)0,&g_722[1][5][3],&g_722[1][5][3]},{&g_722[2][0][0],&g_154,&g_722[1][2][1]}}};
                        int16_t *l_1402[5] = {&g_737,&g_737,&g_737,&g_737,&g_737};
                        uint16_t *l_1403 = &g_49;
                        int32_t l_1404 = 0x2846F7C5L;
                        int i, j, k;
                        l_1404 ^= (safe_mul_func_uint16_t_u_u(((*l_1403) = ((g_976[(g_737 + 2)][(g_423 + 5)] & (((safe_sub_func_uint8_t_u_u(((void*)0 == p_36), (l_1396 == (l_1397 = l_1396)))) == 3UL) && (safe_lshift_func_int8_t_s_s((g_154 = l_1400), (((*g_308) = p_34) != (g_1363 = (l_1373 || l_1400))))))) | l_1400)), p_34));
                    }
                    if (l_1400)
                    { /* block id: 682 */
                        uint32_t l_1410 = 0xB4AFE434L;
                        uint16_t *l_1411 = &g_382[3];
                        int8_t *l_1419 = &g_154;
                        l_1420 = (((*l_1419) = (((**g_234) , (safe_rshift_func_uint8_t_u_s((l_1407 &= ((void*)0 != &l_1397)), ((&g_308 == ((safe_rshift_func_uint16_t_u_u(((*l_1411) = l_1410), 9)) , l_1412)) >= (safe_add_func_int32_t_s_s((((safe_div_func_uint16_t_u_u((((*l_1380) ^= (((((0xCBC8L == (((((((safe_div_func_uint32_t_u_u((((((((0x843BCB10L >= (**g_243)) != l_1400) & p_33) > 0xD6L) , 18446744073709551607UL) ^ 0x47140851E773D19ELL) || l_1400), (*p_36))) == g_159) ^ 18446744073709551608UL) <= 0UL) , &g_593) == &g_593) && (*g_308))) == l_1373) < p_33) != g_162) , p_33)) ^ 8UL), p_33)) > 65535UL) && p_35), p_34)))))) && (*g_594))) & g_976[4][0]);
                        if (p_35)
                            continue;
                    }
                    else
                    { /* block id: 689 */
                        int8_t *l_1435 = &g_154;
                        int32_t l_1436 = 0x106481D5L;
                        l_1407 = (((0UL > (safe_lshift_func_uint8_t_u_s(1UL, ((*l_1435) = (safe_sub_func_int8_t_s_s((g_1425 , ((safe_mod_func_int32_t_s_s((safe_mod_func_uint64_t_u_u(((l_1430 == (void*)0) , p_34), (safe_div_func_int16_t_s_s(((*g_308) && p_34), ((((&g_539 != l_1433) > 0x4DL) >= l_1434[0][0]) , 3UL))))), l_1400)) > p_35)), p_33)))))) || l_1407) | p_33);
                        (*l_1371) = (*g_1100);
                        l_1436 = (*g_555);
                    }
                }
                for (g_164 = 0; (g_164 <= 0); g_164 += 1)
                { /* block id: 698 */
                    uint16_t l_1438[7] = {65533UL,65533UL,65535UL,65533UL,65533UL,65535UL,65533UL};
                    int32_t **l_1444[7][10] = {{&l_1391[5],&l_1391[6],(void*)0,&l_1443,&l_1391[6],&l_1443,&l_1443,(void*)0,&l_1391[0],&l_1391[0]},{&l_1370[1],(void*)0,&l_1443,&l_1370[2],&l_1443,&l_1370[1],&l_1370[1],(void*)0,&l_1370[1],&l_1370[1]},{&l_1370[2],&l_1391[0],&l_1391[6],&l_1391[6],&l_1391[6],&l_1391[6],&l_1391[0],&l_1370[2],&l_1443,(void*)0},{&l_1443,&l_1370[1],&l_1370[1],(void*)0,(void*)0,(void*)0,&l_1370[2],&l_1370[1],&l_1370[1],&l_1391[6]},{&l_1443,(void*)0,&l_1370[1],(void*)0,&l_1391[0],&l_1370[1],(void*)0,&l_1370[2],&l_1370[1],&l_1443},{(void*)0,(void*)0,&l_1391[6],(void*)0,&l_1391[0],&l_1391[5],&l_1391[0],(void*)0,&l_1391[6],(void*)0},{&l_1391[6],&l_1370[1],&l_1443,(void*)0,(void*)0,&l_1370[2],&l_1391[6],(void*)0,(void*)0,&l_1443}};
                    int i, j;
                    for (g_126 = 0; (g_126 <= 0); g_126 += 1)
                    { /* block id: 701 */
                        int32_t l_1437 = 0xB56B3503L;
                        l_1438[0]++;
                        l_1442 = l_1441;
                    }
                    l_1445[5] = (l_1443 = ((*l_1371) = l_1443));
                    for (g_154 = 1; (g_154 <= 9); g_154 += 1)
                    { /* block id: 710 */
                        uint16_t *l_1454 = &l_1438[6];
                        uint16_t *l_1455 = &l_1434[0][0];
                        int i;
                        (*g_166) = (safe_sub_func_uint8_t_u_u(p_33, (p_33 != (p_34 && 0L))));
                        l_1370[1] = ((*g_1047) = (*l_1371));
                        g_423 ^= (((((*l_1380) = 249UL) , l_1391[6]) != &l_1373) >= (g_382[3] ^= ((safe_mod_func_uint64_t_u_u(((**l_1371) <= (!(*l_1443))), (l_1451 ^= p_33))) ^ (((safe_sub_func_uint8_t_u_u((((((*l_1455) = ((*l_1454) = ((void*)0 != p_36))) || (safe_mul_func_int16_t_s_s((*l_1443), p_34))) , 0L) >= g_162), p_34)) && (*g_993)) , 0x1DL))));
                        (*l_1371) = (*g_658);
                    }
                    (*g_555) = ((*g_166) = (-4L));
                }
            }
        }
        else
        { /* block id: 726 */
            int8_t l_1458 = 0x75L;
            int32_t l_1464 = 0L;
            int32_t l_1467 = (-3L);
            int32_t l_1471 = 0xCA3F7029L;
            int32_t l_1474 = 0xCE4DD89FL;
            int32_t l_1475 = 0x5B3170C2L;
            int32_t l_1481 = (-2L);
            int32_t l_1486 = (-8L);
            int32_t l_1492 = (-1L);
            int32_t l_1496 = 0xE04FE015L;
            int32_t l_1497 = 0x77D173EDL;
            int64_t *l_1522 = &g_1358;
            for (g_84 = 1; (g_84 <= 4); g_84 += 1)
            { /* block id: 729 */
                uint32_t l_1460 = 18446744073709551609UL;
                int32_t l_1468 = 0x793885CBL;
                int32_t l_1472 = 9L;
                int32_t l_1473 = 0x9BCC42A8L;
                int32_t l_1477 = 1L;
                int32_t l_1478 = 0x624660E4L;
                int32_t l_1480 = 1L;
                int32_t l_1482 = 0x30AEA364L;
                int32_t l_1484 = 0x6E85D9D8L;
                int32_t l_1487 = 0x365D4B8BL;
                int32_t l_1488 = 0xE07C14B7L;
                int32_t l_1489 = (-3L);
                int32_t l_1491 = 0x2902A513L;
                int32_t l_1494[8][8][4] = {{{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L},{1L,0x61FEDCE0L,0x61FEDCE0L,1L},{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L}},{{1L,0x61FEDCE0L,0x61FEDCE0L,1L},{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L},{1L,0x61FEDCE0L,0x61FEDCE0L,1L},{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL}},{{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L},{1L,0x61FEDCE0L,0x61FEDCE0L,1L},{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L},{1L,0x61FEDCE0L,0x61FEDCE0L,1L}},{{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL},{1L,0x353A728EL,1L,0x61FEDCE0L},{1L,0x61FEDCE0L,0x61FEDCE0L,1L},{(-1L),0x61FEDCE0L,0x3E3AC6CDL,0x61FEDCE0L},{0x61FEDCE0L,0x353A728EL,0x3E3AC6CDL,0x3E3AC6CDL},{(-1L),(-1L),0x61FEDCE0L,0x3E3AC6CDL}},{{1L,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L},{1L,(-1L),0x353A728EL,0x353A728EL},{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L}},{{1L,(-1L),0x353A728EL,0x353A728EL},{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L},{1L,(-1L),0x353A728EL,0x353A728EL},{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L}},{{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L},{1L,(-1L),0x353A728EL,0x353A728EL},{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L},{1L,(-1L),0x353A728EL,0x353A728EL}},{{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL},{0x61FEDCE0L,1L,0x353A728EL,1L},{1L,(-1L),0x353A728EL,0x353A728EL},{0x61FEDCE0L,0x61FEDCE0L,1L,0x353A728EL},{0x3E3AC6CDL,(-1L),0x3E3AC6CDL,1L},{0x3E3AC6CDL,1L,1L,0x3E3AC6CDL}}};
                uint64_t l_1511 = 18446744073709551615UL;
                uint8_t *l_1525 = (void*)0;
                uint16_t *l_1536[4][4] = {{&g_382[4],&g_382[4],&g_162,&g_382[4]},{&g_382[4],&g_49,&g_49,&g_382[4]},{&g_49,&g_382[4],&g_49,&g_49},{&g_382[4],&g_382[4],&g_162,&g_382[4]}};
                uint32_t l_1558 = 0xE8668F73L;
                int16_t l_1583 = 0x0BEAL;
                int i, j, k;
                for (g_737 = 0; (g_737 <= 4); g_737 += 1)
                { /* block id: 732 */
                    int64_t l_1459 = 1L;
                    int32_t l_1465[10][5][4] = {{{0x92259769L,0x80B5D301L,0x62231622L,7L},{0L,0x46DD9473L,(-4L),(-4L)},{7L,7L,0xB6978205L,3L},{0xAEC14AA8L,1L,1L,0L},{(-4L),(-5L),0L,1L}},{{(-7L),(-5L),0xFD1C9353L,0L},{(-5L),1L,0x55036CC6L,3L},{1L,7L,0xC4C932B2L,(-4L)},{0xCD8E8003L,0x46DD9473L,(-1L),7L},{0L,0x80B5D301L,(-5L),0L}},{{0x1BFB8A0AL,0x6DBCD79CL,0xC4C932B2L,0x1BFB8A0AL},{0x46DD9473L,0L,1L,0xCBA672C8L},{3L,0xFD1C9353L,(-1L),0L},{0xFEAEB4C2L,0x38EEA390L,0L,0xF9F23B23L},{0x55036CC6L,0x8E621331L,0L,0x8E621331L}},{{(-5L),0x068AC307L,0x6D42E40EL,1L},{(-1L),0L,1L,0L},{0x38EEA390L,0L,(-1L),1L},{0x38EEA390L,0xF42499DDL,1L,0x55036CC6L},{(-1L),1L,0x6D42E40EL,0L}},{{(-5L),0x80B5D301L,0L,0x1BFB8A0AL},{0x55036CC6L,0xFE2EFA6CL,0L,(-1L)},{0xFEAEB4C2L,3L,(-1L),0x068AC307L},{3L,0x80B5D301L,0L,1L},{0xC4C932B2L,(-1L),0xB7872870L,0x55036CC6L}},{{(-5L),0xC4C932B2L,0L,(-1L)},{0x1BFB8A0AL,0L,0x46DD9473L,(-4L)},{1L,0xB7872870L,0xB7872870L,1L},{0xF42499DDL,0x1BFB8A0AL,0xFE2EFA6CL,0xFD1C9353L},{3L,0x8E621331L,(-7L),0L}},{{(-1L),0L,0L,0L},{1L,0x8E621331L,0xFEAEB4C2L,0xFD1C9353L},{(-5L),0x1BFB8A0AL,1L,1L},{1L,0xB7872870L,1L,(-4L)},{0L,0L,0L,(-1L)}},{{0x38EEA390L,0xC4C932B2L,(-5L),0x55036CC6L},{1L,(-1L),0x6D42E40EL,1L},{(-1L),0x80B5D301L,0xFEAEB4C2L,0x068AC307L},{0x55036CC6L,3L,0L,(-1L)},{(-1L),0xFE2EFA6CL,(-1L),0x1BFB8A0AL}},{{0xFE2EFA6CL,0x80B5D301L,0xFE2EFA6CL,0L},{0xC4C932B2L,1L,9L,0x55036CC6L},{1L,0xF42499DDL,0L,1L},{0x068AC307L,0L,0L,0L},{1L,0L,9L,1L}},{{0xC4C932B2L,0x068AC307L,0xFE2EFA6CL,0x8E621331L},{0xFE2EFA6CL,0x8E621331L,(-1L),0xF9F23B23L},{(-1L),0x38EEA390L,0L,0L},{0x55036CC6L,0xFD1C9353L,0xFEAEB4C2L,0x8E621331L},{(-1L),0x1BFB8A0AL,0x6D42E40EL,(-5L)}}};
                    uint32_t l_1498 = 8UL;
                    uint32_t l_1519 = 0x16BD1FF8L;
                    int16_t * const l_1523 = (void*)0;
                    int16_t **l_1524 = &g_308;
                    uint8_t *l_1526[4][6][2] = {{{&g_126,(void*)0},{&g_126,&g_126},{&g_126,(void*)0},{&g_126,&g_126},{(void*)0,&g_126},{&g_126,(void*)0}},{{&g_126,&g_126},{&g_126,(void*)0},{&g_126,&g_126},{(void*)0,&g_126},{&g_126,(void*)0},{&g_126,&g_126}},{{&g_126,(void*)0},{&g_126,&g_126},{(void*)0,&g_126},{&g_126,(void*)0},{&g_126,&g_126},{&g_126,(void*)0}},{{&g_126,&g_126},{(void*)0,&g_126},{(void*)0,&g_126},{(void*)0,(void*)0},{(void*)0,&g_126},{(void*)0,&g_126}}};
                    int i, j, k;
                    l_1460++;
                    for (g_144 = 0; (g_144 <= 9); g_144 += 1)
                    { /* block id: 736 */
                        int32_t *l_1463 = &g_84;
                        int i, j, k;
                        if (g_598[(g_737 + 1)])
                            break;
                        (*l_1371) = l_1463;
                        return g_107[(g_84 + 4)][g_84][g_103];
                    }
                }
            }
        }
        return p_33;
    }
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_83 g_137 g_234 g_243 g_154 g_107 g_162 g_159 g_84 g_103 g_144 g_6 g_133 g_297 g_139 g_246 g_244 g_12 g_49 g_126 g_236 g_308 g_348 g_77 g_382 g_423 g_164 g_510 g_539 g_235 g_555 g_578 g_593 g_598 g_109 g_658 g_594 g_595 g_111 g_722 g_740 g_744 g_166 g_459 g_915 g_737 g_976 g_990 g_1026 g_1047 g_1100 g_1143 g_1354 g_1356
 * writes: g_84 g_243 g_246 g_103 g_154 g_139 g_308 g_159 g_126 g_144 g_348 g_77 g_382 g_423 g_133 g_166 g_164 g_510 g_107 g_49 g_737 g_722 g_915 g_976 g_1026 g_1061 g_1123 g_1143 g_1147 g_137
 */
static int64_t  func_50(uint64_t  p_51, int16_t  p_52, uint8_t  p_53, uint32_t * const  p_54)
{ /* block id: 11 */
    int16_t l_60 = (-1L);
    int8_t *l_76[2];
    int32_t l_78 = 0x9758AC42L;
    uint16_t *l_540 = &g_162;
    uint16_t **l_541 = &l_540;
    uint32_t *l_542 = &g_133;
    int64_t *l_543[1][5] = {{&g_103,&g_103,&g_103,&g_103,&g_103}};
    int32_t l_544 = 0x2C6CCA28L;
    int32_t l_545[4][8] = {{0xE6CF7CFFL,1L,0x6AF3CC06L,1L,0xE6CF7CFFL,0L,0xDBFF308EL,(-1L)},{1L,0xD32B743EL,0x853264C2L,0x6AF3CC06L,0x6AF3CC06L,0x853264C2L,0xD32B743EL,1L},{(-1L),0L,0x853264C2L,0x9D3B9253L,0xDBFF308EL,0xE6CF7CFFL,0xDBFF308EL,0x9D3B9253L},{0x6AF3CC06L,1L,0x6AF3CC06L,(-1L),0x9D3B9253L,0xE6CF7CFFL,0x853264C2L,0x853264C2L}};
    int32_t l_546 = 0x8A60A37BL;
    uint32_t l_547 = 5UL;
    uint16_t *l_548 = &g_49;
    int32_t l_704 = 3L;
    int32_t *l_739 = &g_2;
    int i, j;
    for (i = 0; i < 2; i++)
        l_76[i] = &g_77;
    for (p_52 = (-23); (p_52 != (-29)); --p_52)
    { /* block id: 14 */
        return l_60;
    }
    (*g_1356) = func_61(func_64((((func_67((safe_mod_func_int64_t_s_s((l_546 = (l_545[2][5] = (l_544 = (((p_51 | ((l_542 = (l_60 , ((safe_lshift_func_int16_t_s_u(((g_2 && ((((l_78 = g_2) , func_79(l_78, l_78, p_52)) != ((*l_541) = l_540)) , g_423)) , p_51), l_60)) , l_542))) != (*g_234))) >= l_60) , l_60)))), l_547)), g_137, l_547, l_548) != l_704) , (*g_308)) , g_111), p_52), l_739);
    return (*l_739);
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_740 g_744 g_84 g_77 g_107 g_246 g_244 g_12 g_593 g_594 g_595 g_133 g_139 g_83 g_243 g_658 g_166 g_137 g_722 g_49 g_382 g_510 g_162 g_423 g_578 g_109 g_459 g_915 g_308 g_144 g_159 g_164 g_737 g_598 g_976 g_990 g_236 g_555 g_1026 g_1047 g_103 g_1100 g_154 g_234 g_235 g_1143 g_297 g_126 g_6 g_1354
 * writes: g_166 g_84 g_77 g_423 g_133 g_510 g_382 g_139 g_722 g_49 g_915 g_144 g_159 g_103 g_976 g_164 g_1026 g_1061 g_1123 g_737 g_107 g_1143 g_1147 g_154 g_137
 */
static int32_t * const  func_61(uint16_t * const  p_62, int32_t * p_63)
{ /* block id: 338 */
    const uint32_t l_756 = 0x0686FAC9L;
    uint8_t *l_760[4];
    int32_t l_768[1];
    const int32_t l_777 = 5L;
    int64_t l_792 = 0xE8B46F4A59C74F21LL;
    int16_t l_793[9];
    uint32_t l_797 = 1UL;
    int64_t ***l_868[10][3] = {{&g_348,&g_348,&g_348},{&g_348,&g_348,&g_348},{&g_348,&g_348,&g_348},{&g_348,&g_348,&g_348},{&g_348,&g_348,&g_348},{(void*)0,&g_348,&g_348},{&g_348,&g_348,&g_348},{(void*)0,&g_348,(void*)0},{&g_348,&g_348,&g_348},{&g_348,&g_348,&g_348}};
    int64_t ***l_869[9];
    int32_t l_885 = 6L;
    uint16_t **l_937 = &g_539;
    uint64_t *l_1083[8][4][8] = {{{&g_137,&g_137,&g_137,(void*)0,&g_164,&g_164,&g_164,&g_164},{&g_137,&g_164,&g_137,&g_164,(void*)0,&g_164,&g_137,&g_164},{&g_137,(void*)0,&g_137,&g_137,&g_164,&g_137,&g_137,&g_137},{(void*)0,&g_164,&g_164,(void*)0,(void*)0,&g_137,&g_137,&g_164}},{{(void*)0,&g_137,(void*)0,(void*)0,(void*)0,(void*)0,&g_137,&g_137},{&g_164,&g_164,&g_137,&g_164,&g_164,&g_137,&g_164,&g_164},{&g_164,&g_164,&g_164,&g_164,&g_164,&g_164,&g_137,&g_164},{(void*)0,&g_137,&g_164,&g_164,&g_164,&g_164,&g_137,&g_164}},{{&g_164,&g_164,&g_164,(void*)0,(void*)0,(void*)0,(void*)0,&g_164},{&g_137,&g_137,&g_137,&g_164,&g_137,(void*)0,(void*)0,&g_137},{(void*)0,(void*)0,(void*)0,&g_164,&g_164,&g_164,(void*)0,&g_137},{(void*)0,&g_164,(void*)0,&g_164,&g_164,&g_137,(void*)0,&g_164}},{{&g_137,&g_137,(void*)0,(void*)0,&g_164,&g_164,&g_137,&g_164},{(void*)0,&g_137,&g_164,&g_164,(void*)0,&g_137,&g_137,&g_164},{(void*)0,(void*)0,&g_164,&g_137,&g_164,(void*)0,(void*)0,&g_164},{&g_137,&g_164,&g_164,&g_164,(void*)0,&g_164,&g_164,&g_137}},{{&g_137,&g_137,(void*)0,(void*)0,&g_164,&g_164,&g_137,&g_164},{&g_164,(void*)0,&g_164,(void*)0,&g_137,&g_164,&g_164,&g_164},{(void*)0,&g_164,&g_164,&g_137,(void*)0,(void*)0,(void*)0,&g_164},{&g_164,(void*)0,&g_164,&g_137,&g_164,&g_164,&g_164,&g_164}},{{&g_137,&g_164,(void*)0,&g_164,&g_137,&g_164,(void*)0,&g_164},{&g_137,&g_137,(void*)0,&g_164,&g_164,&g_137,&g_164,&g_164},{(void*)0,&g_164,&g_164,(void*)0,&g_137,&g_137,&g_164,&g_164},{&g_137,(void*)0,(void*)0,&g_137,&g_137,&g_137,(void*)0,&g_164}},{{&g_137,&g_137,(void*)0,&g_164,&g_164,&g_164,&g_164,&g_164},{&g_164,&g_164,&g_164,&g_164,&g_137,&g_164,(void*)0,&g_137},{&g_164,&g_137,&g_164,&g_164,&g_164,&g_137,&g_164,&g_137},{&g_164,&g_164,&g_164,&g_164,&g_137,&g_137,&g_137,&g_164}},{{&g_137,&g_164,(void*)0,&g_137,(void*)0,&g_164,&g_164,&g_137},{&g_164,&g_137,&g_164,&g_164,&g_164,&g_164,(void*)0,(void*)0},{&g_164,&g_137,&g_137,&g_164,&g_164,&g_164,&g_137,&g_164},{&g_137,&g_164,&g_164,&g_137,(void*)0,&g_164,(void*)0,&g_137}}};
    uint64_t ***l_1136 = (void*)0;
    int32_t **l_1180 = &g_166;
    uint32_t ***l_1220 = &g_246;
    uint32_t l_1237 = 0x00EB299BL;
    int32_t l_1268 = 0L;
    int32_t l_1280[3][3] = {{0L,0L,0L},{0xFF8093D6L,0x7DF27945L,0xFF8093D6L},{0L,0L,0L}};
    uint16_t l_1333[8][10] = {{0x3D66L,0x97B5L,0x689DL,0x689DL,0x97B5L,0x3D66L,0x2A67L,8UL,65530UL,0x689DL},{0x69EFL,0xBF18L,65529UL,0x2274L,65532UL,0x507AL,0x2274L,0x69EFL,65535UL,0x69EFL},{0x69EFL,0x3D66L,0x9601L,0x97B5L,0x9601L,0x3D66L,0x69EFL,0x2917L,0x3D66L,0xBF18L},{0x3D66L,0x69EFL,0x2917L,0x3D66L,0xBF18L,65530UL,0x9601L,8UL,0x2917L,0x2917L},{1UL,65530UL,65532UL,0x9601L,0x9601L,65532UL,65530UL,1UL,0x97B5L,0x2A67L},{0x689DL,65529UL,65535UL,0x2917L,0x2974L,0x507AL,0x2A67L,0x2974L,65529UL,0x9601L},{0xCF3BL,1UL,65535UL,0x2974L,0x3D66L,0x2974L,65535UL,1UL,0xCF3BL,65535UL},{0x2917L,0x689DL,65532UL,0x2A67L,0x689DL,0x69EFL,0x9601L,0x2917L,0x2274L,0x2A67L}};
    int32_t * const l_1336[3][4][3] = {{{(void*)0,&g_2,&g_2},{&l_768[0],&g_2,&g_2},{(void*)0,&g_2,&g_2},{(void*)0,&g_2,&g_2}},{{&l_768[0],&g_2,&g_2},{(void*)0,&g_2,&g_2},{(void*)0,&g_2,&g_2},{&l_768[0],&g_2,&g_2}},{{(void*)0,&g_2,&g_2},{(void*)0,&g_2,&g_2},{&l_768[0],&g_2,&g_2},{(void*)0,&g_2,&g_2}}};
    int32_t * const l_1337 = &g_84;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_760[i] = (void*)0;
    for (i = 0; i < 1; i++)
        l_768[i] = 0x9FCE3B05L;
    for (i = 0; i < 9; i++)
        l_793[i] = 0x5569L;
    for (i = 0; i < 9; i++)
        l_869[i] = &g_348;
    if ((*p_63))
    { /* block id: 339 */
        uint32_t *l_762 = &g_133;
        int32_t l_765 = (-1L);
        int32_t l_782 = (-1L);
        int32_t l_784 = 0x2D234402L;
        int16_t l_785 = (-2L);
        int32_t l_786 = 0xBBFC154DL;
        int32_t l_787 = 0x311C0824L;
        int32_t l_788 = 0xFE619AF5L;
        int32_t l_789 = (-7L);
        int32_t l_790 = 9L;
        int32_t l_791[2][7] = {{0xC6570E84L,0xC6570E84L,(-3L),6L,2L,6L,(-3L)},{0xC6570E84L,0xC6570E84L,(-3L),6L,2L,6L,(-3L)}};
        int i, j;
        (*g_740) = p_63;
        if ((*p_63))
        { /* block id: 341 */
            uint16_t ***l_741 = (void*)0;
            uint16_t **l_743 = (void*)0;
            uint16_t ***l_742 = &l_743;
            int32_t l_763 = (-2L);
            (*g_744) &= (&p_62 == ((*l_742) = &g_539));
            for (g_77 = 0; (g_77 <= (-20)); --g_77)
            { /* block id: 346 */
                const int16_t l_749 = 0xDE8AL;
                int64_t *l_757[5][2] = {{&g_103,&g_103},{&g_103,&g_103},{&g_103,&g_103},{&g_103,&g_103},{&g_103,&g_103}};
                uint8_t **l_761 = &l_760[1];
                int32_t *l_764 = &g_423;
                int32_t *l_766 = (void*)0;
                int32_t *l_767 = &l_763;
                int i, j;
                l_768[0] ^= ((*l_767) = (safe_add_func_int64_t_s_s(l_749, (safe_sub_func_int64_t_s_s(((254UL & ((((g_107[8][6][0] , l_749) || (safe_rshift_func_uint16_t_u_s((safe_add_func_uint32_t_u_u((**g_246), l_756)), (((void*)0 != l_757[1][1]) & (((((safe_div_func_int32_t_s_s(((*l_764) = ((((((*l_761) = l_760[1]) == &g_126) , l_762) == (void*)0) != l_763)), 0x03EC2B29L)) != 0L) ^ 1L) <= l_763) && l_765))))) <= (**g_593)) <= 0x10D59024L)) == 0UL), g_133)))));
                if (l_763)
                    continue;
            }
        }
        else
        { /* block id: 353 */
            const uint8_t l_780 = 0xB3L;
            int8_t *l_781 = &g_77;
            int32_t *l_783[4][10][5] = {{{&g_2,&l_768[0],&l_768[0],&g_2,&l_768[0]},{&g_2,&g_423,&g_84,(void*)0,&l_768[0]},{&g_423,(void*)0,&g_84,(void*)0,&l_768[0]},{&l_768[0],&g_2,(void*)0,(void*)0,&g_2},{(void*)0,(void*)0,&g_423,&g_2,&l_765},{&g_423,&g_2,&g_423,&l_765,&g_84},{(void*)0,&l_768[0],(void*)0,&l_768[0],&l_768[0]},{&g_423,&g_84,&g_423,(void*)0,&l_765},{(void*)0,&g_423,(void*)0,(void*)0,&g_84},{&l_768[0],&l_765,&l_768[0],&g_423,(void*)0}},{{&g_423,&g_84,(void*)0,&g_84,&g_423},{&g_2,&g_423,&g_423,&g_2,&g_423},{&g_2,&l_765,(void*)0,&l_768[0],&g_84},{(void*)0,&g_423,&g_423,&g_423,&g_423},{&l_768[0],&l_768[0],&g_423,(void*)0,&g_423},{&g_423,&g_84,(void*)0,&l_768[0],(void*)0},{(void*)0,(void*)0,&g_84,&l_768[0],&g_84},{&g_84,&g_84,&g_84,&g_84,&l_765},{&l_765,(void*)0,&g_84,(void*)0,&g_423},{&g_423,&l_765,&l_768[0],&g_423,(void*)0}},{{&g_84,&l_768[0],(void*)0,(void*)0,&l_768[0]},{(void*)0,&g_84,&l_765,(void*)0,&g_84},{&l_768[0],&l_768[0],(void*)0,(void*)0,&g_84},{&g_84,&l_768[0],&g_2,(void*)0,(void*)0},{&l_768[0],&l_768[0],&l_768[0],&l_765,&g_423},{(void*)0,&l_765,&g_423,&g_84,&g_423},{&g_84,(void*)0,&g_423,(void*)0,(void*)0},{&g_423,&g_423,&g_423,&g_423,&g_423},{&l_768[0],&g_2,&l_768[0],&l_768[0],(void*)0},{(void*)0,&g_84,&g_2,(void*)0,&l_768[0]}},{{(void*)0,&l_768[0],(void*)0,&g_2,(void*)0},{(void*)0,(void*)0,&l_765,&g_2,&g_423},{(void*)0,&g_84,(void*)0,&g_423,(void*)0},{&g_423,&g_2,&l_768[0],&l_768[0],&g_423},{(void*)0,&g_84,&g_84,(void*)0,&g_423},{&g_84,(void*)0,(void*)0,&g_423,(void*)0},{(void*)0,&l_768[0],&l_768[0],(void*)0,&g_84},{&g_2,&g_84,&g_423,&g_423,&g_84},{(void*)0,&g_2,&l_768[0],(void*)0,&l_768[0]},{&l_765,&g_423,(void*)0,&l_768[0],(void*)0}}};
            uint16_t l_794 = 0UL;
            int i, j, k;
            l_768[0] &= (safe_mul_func_int8_t_s_s(g_139, ((safe_mul_func_uint8_t_u_u(((l_782 = ((*l_781) |= (((safe_add_func_int32_t_s_s((safe_sub_func_int32_t_s_s(l_777, (*g_83))), l_777)) , (((*l_762) = (**g_243)) == (**g_243))) , ((safe_add_func_uint64_t_u_u((((l_780 <= l_765) , (((l_780 && 6UL) != l_777) != (**g_658))) , l_756), g_139)) , 0x35L)))) & 0xE7L), g_137)) , g_133)));
            --l_794;
            ++l_797;
            return p_63;
        }
    }
    else
    { /* block id: 362 */
        uint32_t l_828 = 0x65575A6BL;
        int32_t l_843 = 0x9C80FDB6L;
        int64_t ***l_867 = &g_348;
        int32_t l_875[7] = {0x3146DF4EL,0x3146DF4EL,0x3146DF4EL,0x3146DF4EL,0x3146DF4EL,0x3146DF4EL,0x3146DF4EL};
        int32_t *l_899[9][5][1] = {{{&l_768[0]},{&l_885},{&l_768[0]},{&l_768[0]},{&l_768[0]}},{{&l_885},{&l_768[0]},{&l_768[0]},{&l_768[0]},{&l_885}},{{&l_768[0]},{&l_768[0]},{&l_768[0]},{&l_885},{&l_768[0]}},{{&l_768[0]},{&l_768[0]},{&l_885},{&l_768[0]},{&l_768[0]}},{{&l_768[0]},{&l_885},{&l_768[0]},{&l_768[0]},{&l_768[0]}},{{&l_885},{&l_768[0]},{&l_768[0]},{&l_768[0]},{&l_885}},{{&l_768[0]},{&l_768[0]},{&l_768[0]},{&l_885},{&l_768[0]}},{{&l_768[0]},{&l_768[0]},{&l_885},{&l_768[0]},{&l_768[0]}},{{&l_768[0]},{&l_885},{&l_768[0]},{&l_768[0]},{&l_768[0]}}};
        int i, j, k;
        if (((((0x61EF4809L || (safe_rshift_func_int8_t_s_s((p_62 != (void*)0), 3))) & l_792) >= 0x96CF090FL) , (safe_div_func_int32_t_s_s((safe_add_func_int64_t_s_s((safe_div_func_uint8_t_u_u(l_756, (safe_sub_func_int64_t_s_s(((-8L) & ((safe_rshift_func_uint16_t_u_s((safe_mul_func_int16_t_s_s((((safe_mod_func_uint16_t_u_u(((~(safe_mul_func_uint16_t_u_u(((((safe_div_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(0UL, 11)), ((safe_sub_func_int64_t_s_s(((safe_div_func_int16_t_s_s((((((((g_722[2][0][0] , (void*)0) == &p_63) , l_797) == 0L) | g_49) , (void*)0) == p_63), 0x3C6DL)) < 0xFABFF4F3L), (*g_594))) , 255UL))) , l_777) >= (-9L)) & l_793[0]), (*p_62)))) & l_793[3]), (*p_62))) , 0x77L) || 7UL), l_792)), 9)) > (*p_62))), 0x004B6DBA52002F2ELL)))), 0x3D51671E8E7EBF46LL)), 4294967295UL))))
        { /* block id: 363 */
            int32_t *l_827[5];
            int i;
            for (i = 0; i < 5; i++)
                l_827[i] = &l_768[0];
            l_828--;
            for (g_510 = (-16); (g_510 != 15); g_510++)
            { /* block id: 367 */
                uint64_t l_833[4][5] = {{18446744073709551615UL,0xA7BA713252D26D82LL,0xA7BA713252D26D82LL,18446744073709551615UL,0xA7BA713252D26D82LL},{0UL,0UL,0xAE8DB227900947BDLL,0UL,0UL},{0xA7BA713252D26D82LL,18446744073709551615UL,0xA7BA713252D26D82LL,0xA7BA713252D26D82LL,18446744073709551615UL},{0UL,0xF0B5C33DAC13CB9BLL,0xF0B5C33DAC13CB9BLL,0UL,0xF0B5C33DAC13CB9BLL}};
                int i, j;
                if (l_833[0][4])
                    break;
            }
        }
        else
        { /* block id: 370 */
            int32_t *l_834 = &l_768[0];
            int32_t l_853 = 0x8A6EAEC1L;
            int64_t ***l_866 = &g_348;
            int32_t l_877 = 0x361352C7L;
            int32_t l_883 = (-1L);
            int32_t l_884 = 0x8CCDD4F0L;
            int32_t l_886 = 0xA8F0C9FCL;
            int32_t l_887 = 0L;
            int32_t l_891 = 0xAB66D3AAL;
            int32_t l_892 = 3L;
            int32_t l_893 = 0xE81CB332L;
            int32_t l_917 = 1L;
            int32_t l_918 = 0x2EA9D544L;
            int32_t l_919 = 0x4763D57FL;
            int32_t l_921 = 0L;
            uint32_t l_924 = 0x730058F9L;
            (*l_834) = (*g_83);
lbl_903:
            for (l_797 = 15; (l_797 == 10); l_797 = safe_sub_func_int32_t_s_s(l_797, 7))
            { /* block id: 374 */
                int32_t *l_839 = &g_84;
                (*l_839) ^= ((*l_834) = (safe_lshift_func_uint8_t_u_u(g_162, 2)));
            }
            for (g_77 = 3; (g_77 >= 0); g_77 -= 1)
            { /* block id: 380 */
                int64_t l_842 = (-1L);
                int32_t *l_852[7] = {&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2};
                uint32_t l_894[7][9][4] = {{{0x37E070AAL,0xD4D7146FL,0UL,18446744073709551612UL},{18446744073709551615UL,0x0567A499L,5UL,0xAFE08E82L},{0x3525DF32L,0xA729B4CEL,9UL,0x0F768EBBL},{0x1425C235L,0x05D8E752L,0x93F4BAF7L,0xA729B4CEL},{0x2DDAC875L,0UL,1UL,0xD745BBD1L},{0x0567A499L,18446744073709551615UL,9UL,0UL},{0UL,0x21D3D821L,0x21D3D821L,0UL},{18446744073709551615UL,0x3525DF32L,0x05D8E752L,1UL},{18446744073709551615UL,0x0567A499L,0xF4D36ECFL,7UL}},{{18446744073709551615UL,18446744073709551615UL,0UL,7UL},{8UL,0x0567A499L,0x93F4BAF7L,1UL},{0xA729B4CEL,0x3525DF32L,0UL,0UL},{0x1425C235L,0x21D3D821L,0xAFE08E82L,0UL},{0xA6987914L,18446744073709551615UL,18446744073709551615UL,0xD745BBD1L},{0UL,0UL,2UL,0xA729B4CEL},{18446744073709551615UL,0x05D8E752L,0x21D3D821L,0x0F768EBBL},{0xA6987914L,0xA729B4CEL,0x56521332L,0xAFE08E82L},{18446744073709551615UL,0x0567A499L,0UL,18446744073709551612UL}},{{18446744073709551612UL,7UL,1UL,18446744073709551615UL},{8UL,0UL,0xAFE08E82L,0x93F4BAF7L},{0x3525DF32L,0x4DD7DB41L,0xF4D36ECFL,0UL},{0x4DD7DB41L,7UL,0xED39FCDBL,0xA729B4CEL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0xAFE08E82L},{18446744073709551615UL,18446744073709551615UL,9UL,0x0266CA0DL},{18446744073709551615UL,0x05D8E752L,0x589756E3L,18446744073709551615UL},{0x2DDAC875L,0x3525DF32L,0x589756E3L,0xD745BBD1L},{18446744073709551615UL,0UL,9UL,0x1A98B2D1L}},{{18446744073709551615UL,0x21D3D821L,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,0xED39FCDBL,1UL},{0x4DD7DB41L,0x1425C235L,0xF4D36ECFL,0x0F768EBBL},{0x3525DF32L,18446744073709551615UL,0xAFE08E82L,0x0266CA0DL},{8UL,18446744073709551615UL,1UL,1UL},{18446744073709551612UL,0UL,0UL,0x3525DF32L},{18446744073709551615UL,0x21D3D821L,0x56521332L,18446744073709551615UL},{0xA6987914L,0x4DD7DB41L,0x21D3D821L,0xD745BBD1L},{18446744073709551615UL,18446744073709551615UL,2UL,18446744073709551612UL}},{{0UL,0x05D8E752L,18446744073709551615UL,7UL},{0xA6987914L,18446744073709551612UL,0xAFE08E82L,0xAFE08E82L},{0x1425C235L,0x1425C235L,0UL,18446744073709551615UL},{0xA729B4CEL,7UL,0x93F4BAF7L,0x3525DF32L},{8UL,18446744073709551615UL,0UL,0x93F4BAF7L},{18446744073709551615UL,18446744073709551615UL,0xF4D36ECFL,0x3525DF32L},{18446744073709551615UL,7UL,0x05D8E752L,18446744073709551615UL},{18446744073709551615UL,0x1425C235L,0x21D3D821L,0xAFE08E82L},{0UL,18446744073709551612UL,9UL,7UL}},{{0x0567A499L,0x05D8E752L,1UL,18446744073709551612UL},{0x2DDAC875L,18446744073709551615UL,0x93F4BAF7L,0xD745BBD1L},{0x1425C235L,0x4DD7DB41L,9UL,18446744073709551615UL},{0x3525DF32L,0x47B2D3B5L,0x9FF67065L,18446744073709551615UL},{9UL,0x21D3D821L,6UL,0xFF3F9E8AL},{1UL,0x5B7FEC92L,0xA729B4CEL,1UL},{0x21D3D821L,9UL,0UL,0x589756E3L},{6UL,0x4A4605B8L,2UL,0xFF3F9E8AL},{0x56521332L,5UL,0x1425C235L,5UL}},{{0xEE4F4E19L,0x47B2D3B5L,1UL,0xED39FCDBL},{18446744073709551611UL,1UL,0x9FF67065L,0UL},{0x2DDAC875L,18446744073709551615UL,18446744073709551611UL,0x56521332L},{0x2DDAC875L,18446744073709551615UL,0x9FF67065L,1UL},{18446744073709551611UL,0x56521332L,1UL,6UL},{0xEE4F4E19L,0x5B7FEC92L,0x1425C235L,0UL},{0x56521332L,0xF4D36ECFL,2UL,0x21D3D821L},{6UL,0x2DDAC875L,0UL,8UL},{0x21D3D821L,1UL,0xA729B4CEL,5UL}}};
                int i, j, k;
                l_853 ^= ((*l_834) > ((safe_div_func_int32_t_s_s((l_843 = (1UL == (((*g_244) >= l_842) > l_842))), (safe_mod_func_uint64_t_u_u(18446744073709551615UL, 0xA59DF1B1BDE29A68LL)))) || ((safe_add_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u((((*p_62) = (((safe_lshift_func_int16_t_s_u(l_842, (*l_834))) == (*l_834)) > (*l_834))) | 0L), g_423)), (*p_63))) , l_842)));
                for (g_139 = 0; (g_139 <= 3); g_139 += 1)
                { /* block id: 386 */
                    int32_t l_858 = 0L;
                    uint32_t *l_861 = &l_797;
                    int64_t ***l_865[4][10] = {{&g_348,(void*)0,&g_348,&g_348,(void*)0,(void*)0,&g_348,&g_348,(void*)0,&g_348},{&g_348,(void*)0,(void*)0,(void*)0,(void*)0,&g_348,(void*)0,&g_348,(void*)0,(void*)0},{(void*)0,&g_348,(void*)0,(void*)0,(void*)0,&g_348,&g_348,&g_348,&g_348,&g_348},{(void*)0,(void*)0,&g_348,&g_348,(void*)0,(void*)0,&g_348,&g_348,&g_348,&g_348}};
                    int64_t ****l_864[10][2][7] = {{{&l_865[1][3],&l_865[3][5],&l_865[3][5],(void*)0,&l_865[1][7],&l_865[0][6],&l_865[3][7]},{&l_865[0][0],(void*)0,&l_865[3][7],&l_865[0][6],&l_865[1][7],(void*)0,&l_865[3][5]}},{{(void*)0,&l_865[0][0],&l_865[3][5],&l_865[3][5],&l_865[1][7],&l_865[1][1],(void*)0},{&l_865[3][5],&l_865[1][3],&l_865[3][9],(void*)0,&l_865[1][7],&l_865[3][4],&l_865[3][5]}},{{&l_865[3][5],&l_865[2][9],&l_865[3][5],&l_865[3][5],&l_865[1][7],&l_865[3][5],&l_865[3][5]},{(void*)0,(void*)0,&l_865[3][5],&l_865[3][4],&l_865[1][7],(void*)0,&l_865[3][9]}},{{&l_865[2][9],&l_865[3][5],(void*)0,&l_865[1][1],&l_865[1][7],&l_865[3][5],&l_865[3][5]},{&l_865[1][3],&l_865[3][5],&l_865[3][5],(void*)0,&l_865[1][7],&l_865[0][6],&l_865[3][7]}},{{&l_865[0][0],(void*)0,&l_865[3][7],&l_865[0][6],&l_865[1][7],(void*)0,&l_865[3][5]},{(void*)0,&l_865[0][0],&l_865[3][5],&l_865[3][5],&l_865[1][7],&l_865[1][1],(void*)0}},{{&l_865[3][5],&l_865[1][3],&l_865[3][9],(void*)0,&l_865[1][7],&l_865[3][4],&l_865[3][5]},{&l_865[3][5],&l_865[2][9],&l_865[3][5],&l_865[3][5],&l_865[1][7],&l_865[3][5],&l_865[3][5]}},{{(void*)0,(void*)0,&l_865[3][5],&l_865[3][4],&l_865[1][7],(void*)0,&l_865[3][9]},{&l_865[2][9],&l_865[3][5],&l_865[1][3],(void*)0,&l_865[1][5],(void*)0,(void*)0}},{{&l_865[3][5],&l_865[1][7],&l_865[3][5],&l_865[3][5],&l_865[1][5],&l_865[3][5],&l_865[0][0]},{(void*)0,&l_865[2][3],&l_865[0][0],&l_865[3][5],&l_865[1][5],&l_865[3][5],&l_865[3][5]}},{{&l_865[2][3],(void*)0,(void*)0,(void*)0,&l_865[1][5],(void*)0,&l_865[1][3]},{&l_865[1][7],&l_865[3][5],(void*)0,&l_865[3][5],&l_865[1][5],(void*)0,&l_865[3][5]}},{{&l_865[3][5],&l_865[3][5],&l_865[2][9],&l_865[1][1],&l_865[1][5],&l_865[1][1],&l_865[2][9]},{&l_865[0][9],&l_865[0][9],&l_865[3][5],(void*)0,&l_865[1][5],&l_865[3][5],(void*)0}}};
                    int8_t *l_872 = &g_722[2][0][0];
                    int32_t l_879 = 1L;
                    int32_t l_881 = 0xC754C8AEL;
                    int32_t l_882 = 0L;
                    int32_t l_888 = 0xB986897EL;
                    int32_t l_889 = (-1L);
                    int32_t l_890[6];
                    int i, j, k;
                    for (i = 0; i < 6; i++)
                        l_890[i] = 3L;
                    if (((safe_lshift_func_int8_t_s_u(((*l_872) = ((((*l_834) , (((0x63891599F2F6EA77LL || (l_858 == 0x97L)) == (safe_div_func_int64_t_s_s(l_858, 0x8106E659B6BFA21ELL))) , ((((*l_861)++) & ((l_868[3][0] = (l_867 = (l_866 = &g_348))) == l_869[2])) < (safe_rshift_func_uint16_t_u_s(l_858, 1))))) || (*l_834)) > 1UL)), 2)) , 0L))
                    { /* block id: 392 */
                        int16_t l_873 = 0xB404L;
                        int32_t l_874 = 0L;
                        int32_t l_876 = 0x96C0F1E2L;
                        int32_t l_878 = 0L;
                        int32_t l_880[5];
                        int i;
                        for (i = 0; i < 5; i++)
                            l_880[i] = 0x5E29C181L;
                        if ((*g_578))
                            break;
                        l_894[4][1][0]++;
                    }
                    else
                    { /* block id: 395 */
                        int32_t **l_897 = (void*)0;
                        int32_t **l_898[8][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                        int i, j;
                        p_63 = &l_875[5];
                        l_899[5][0][0] = &l_892;
                    }
                    for (l_881 = 0; (l_881 <= 3); l_881 += 1)
                    { /* block id: 401 */
                        return l_852[5];
                    }
                    for (l_884 = 3; (l_884 >= 0); l_884 -= 1)
                    { /* block id: 406 */
                        uint16_t l_900 = 65526UL;
                        int32_t **l_906 = &l_899[8][0][0];
                        int i, j, k;
                        --l_900;
                        if (l_884)
                            goto lbl_903;
                        (*l_834) &= (0x9CD8AD3FL < g_109[(g_77 + 2)][l_884][g_139]);
                        (*l_906) = (((safe_mul_func_int16_t_s_s(g_722[l_884][(g_77 + 5)][(g_139 + 1)], (0x0C1CDCA5L || (*p_63)))) || g_109[(g_77 + 2)][l_884][g_139]) , (void*)0);
                    }
                }
            }
            for (g_423 = 0; (g_423 <= 8); ++g_423)
            { /* block id: 416 */
                int8_t l_909 = (-1L);
                int32_t l_910 = (-1L);
                int32_t l_911 = (-1L);
                int32_t l_912 = 2L;
                int32_t l_913 = 0x146A85C5L;
                int32_t l_914 = 1L;
                int32_t l_916 = 0x73156BCBL;
                int32_t l_920 = 0xA4A1C75DL;
                int32_t l_922 = 0xDE03E150L;
                int32_t l_923 = 0L;
                --l_924;
            }
        }
    }
    for (g_49 = 0; (g_49 <= 0); g_49 += 1)
    { /* block id: 423 */
        int32_t l_929 = 0xAD74FA5EL;
        uint16_t **l_938[9][6] = {{&g_539,&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,&g_539,&g_539,(void*)0},{&g_539,&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539,(void*)0},{&g_539,&g_539,&g_539,&g_539,(void*)0,&g_539},{(void*)0,&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,&g_539,&g_539,&g_539}};
        int32_t *l_951 = &g_423;
        uint32_t l_988 = 0x5C9865B1L;
        uint16_t l_1010 = 0x2E4FL;
        int64_t *l_1015 = &g_103;
        int32_t l_1024 = 0x745E87C3L;
        int32_t l_1025[4] = {(-2L),(-2L),(-2L),(-2L)};
        int i, j;
        if (l_792)
            break;
        for (g_423 = 0; (g_423 <= 8); g_423 += 1)
        { /* block id: 427 */
            int8_t l_932 = 0x97L;
            uint16_t ***l_939 = &l_938[8][0];
            int32_t l_1001 = (-1L);
            int32_t l_1003 = 0L;
            uint32_t *l_1016 = &l_797;
            int32_t *l_1017 = &l_768[0];
            int32_t *l_1018 = (void*)0;
            int32_t *l_1019 = &l_885;
            int32_t *l_1020 = &g_84;
            int32_t *l_1021 = (void*)0;
            int32_t *l_1022 = &l_1001;
            int32_t *l_1023[4][6] = {{&l_885,&g_84,&l_1003,&g_84,&l_885,&l_1003},{&g_84,&l_885,&l_1003,&l_885,&l_885,&l_1003},{&l_885,&l_885,&l_1003,&l_885,&g_84,&l_1003},{&l_885,&g_84,&l_1003,(void*)0,&l_885,&l_885}};
            int i, j;
            if ((((**g_243) && (safe_rshift_func_int16_t_s_u(0xA1E4L, (8UL & ((l_929 , ((((((safe_div_func_int8_t_s_s(0L, l_932)) , (safe_lshift_func_uint8_t_u_s(0x33L, ((safe_sub_func_int64_t_s_s(((l_937 == ((*l_939) = l_938[8][0])) && l_932), (-6L))) ^ 0xDF128E50L)))) > 0x89526A79L) , (void*)0) == (void*)0) && l_929)) & g_459))))) || (*g_744)))
            { /* block id: 429 */
                uint16_t l_954[7][4][5] = {{{0UL,3UL,65535UL,65533UL,0x7315L},{0xBCF6L,0x7BB0L,0x7BB0L,0xBCF6L,65533UL},{0UL,0xE96BL,4UL,1UL,65533UL},{0x7BB0L,0UL,0x7315L,0x0A7AL,0x7315L}},{{0x0A7AL,0x0A7AL,65533UL,1UL,4UL},{65535UL,0xA4C9L,65533UL,0xBCF6L,0x7BB0L},{65535UL,65533UL,0x7315L,65533UL,65535UL},{1UL,0xA4C9L,4UL,65535UL,0x0A7AL}},{{1UL,0x0A7AL,0x7BB0L,0xE96BL,0xE96BL},{65535UL,0UL,65535UL,0xA4C9L,0x0A7AL},{65535UL,0xE96BL,0x0A7AL,0xA4C9L,65535UL},{0x0A7AL,0x7BB0L,0xE96BL,0xE96BL,0x7BB0L}},{{0x7BB0L,3UL,0x0A7AL,65535UL,4UL},{0UL,3UL,65535UL,65533UL,0x7315L},{0xBCF6L,0x7BB0L,0x7BB0L,0xBCF6L,65533UL},{0UL,0xE96BL,4UL,1UL,65533UL}},{{0x7BB0L,0UL,0x7315L,0x0A7AL,0x7315L},{0x0A7AL,0x0A7AL,65533UL,1UL,4UL},{65535UL,0xA4C9L,65533UL,0xBCF6L,0x7BB0L},{65535UL,65533UL,0x7315L,65533UL,65535UL}},{{1UL,0xA4C9L,4UL,65535UL,0x0A7AL},{1UL,0x0A7AL,0x7BB0L,0xE96BL,0xE96BL},{65535UL,0UL,65535UL,0xA4C9L,0x0A7AL},{65535UL,0xE96BL,0x0A7AL,0xA4C9L,65535UL}},{{0x0A7AL,0x7BB0L,0xE96BL,0xE96BL,0x7BB0L},{0x7BB0L,3UL,0x0A7AL,65535UL,4UL},{0UL,3UL,65535UL,65533UL,0x7315L},{0xBCF6L,0x7BB0L,0x7BB0L,0xBCF6L,65533UL}}};
                int i, j, k;
                for (g_915 = 6; (g_915 >= 0); g_915 -= 1)
                { /* block id: 432 */
                    int32_t **l_952 = &g_166;
                    int32_t **l_953 = &l_951;
                    int32_t *l_955 = &l_885;
                    int32_t *l_956 = &g_84;
                    int i, j, k;
                    (*l_956) = ((*l_955) &= (((safe_add_func_int16_t_s_s((((((void*)0 != (*g_593)) == (((((safe_mul_func_int16_t_s_s(((*g_308) = (safe_sub_func_int64_t_s_s(g_107[g_423][(g_49 + 6)][g_49], (((safe_mul_func_int16_t_s_s(l_932, (safe_add_func_int32_t_s_s(((*p_62) || (safe_unary_minus_func_int16_t_s((0x56E39F98L ^ (((*l_953) = l_951) == &g_423))))), (l_932 < 0L))))) > l_954[3][2][3]) == 1UL)))), (*p_62))) <= l_929) != (**g_246)) > 246UL) & l_954[1][2][4])) >= (-1L)) >= 1UL), 0x9898L)) , l_792) , (*g_83)));
                    g_976[4][0] |= (((safe_mul_func_int8_t_s_s(((safe_mod_func_uint16_t_u_u((((*g_308) , ((((((*g_308) = ((safe_add_func_uint32_t_u_u((safe_unary_minus_func_uint16_t_u((((((safe_rshift_func_uint8_t_u_s(((g_103 = (*l_956)) , (l_932 > (&g_235[3] == ((((safe_add_func_int16_t_s_s(1L, ((g_77 = (((safe_add_func_int64_t_s_s(((((((((((0x1B09L < (safe_mod_func_uint16_t_u_u(((*p_62) = (*p_62)), (safe_rshift_func_uint8_t_u_s((safe_sub_func_uint32_t_u_u((&g_594 == (void*)0), l_768[0])), g_164))))) | (*l_951)) >= 249UL) == 0x3DF0L) ^ (*l_951)) , l_954[3][2][3]) , l_932) , 0x7FL) != 0xB2L) , l_793[7]), 0x0A45381B3F030291LL)) < 0UL) , 0xECL)) == l_932))) == g_737) ^ g_159) , &g_235[1])))), 3)) > 1UL) < 1UL) ^ l_793[3]) & (*l_951)))), 0x3DB8D1C8L)) != (-2L))) <= l_797) <= (*l_956)) , (**g_593)) == (*l_951))) || l_932), g_133)) >= g_598[2]), 255UL)) , (*p_62)) || (*l_955));
                }
            }
            else
            { /* block id: 443 */
                uint64_t *l_979 = &g_164;
                int32_t *l_989 = &l_768[0];
                int32_t l_1002 = 0xDAE3ECA9L;
                l_1003 |= ((safe_add_func_uint16_t_u_u((((*l_979) = (*l_951)) & (safe_mod_func_int8_t_s_s(g_77, (safe_lshift_func_int8_t_s_s(((safe_lshift_func_int16_t_s_u((safe_sub_func_uint16_t_u_u((*p_62), 0x024AL)), (l_1002 = (((*l_989) = (l_756 != (l_988 = 0x92L))) == (g_990[1][2][1] == (((safe_lshift_func_int8_t_s_s((safe_mod_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(g_236, (l_1001 = (*p_62)))), l_932)), 0)) || 0xD414L) , (void*)0)))))) , 0xF6L), (*l_951)))))), 1L)) <= g_2);
                for (g_77 = 1; (g_77 <= 8); g_77 += 1)
                { /* block id: 452 */
                    if ((*l_951))
                        break;
                }
            }
            (*l_1019) ^= ((safe_div_func_uint32_t_u_u((((*l_1017) = (safe_div_func_uint32_t_u_u(((*l_1016) = ((safe_sub_func_int32_t_s_s(((((*l_951) >= l_1010) != (l_1001 != (0UL < 0xA4L))) | (safe_lshift_func_int16_t_s_u((safe_sub_func_int16_t_s_s(l_768[0], (*l_951))), ((void*)0 == l_1015)))), 0L)) != 0x0CF6DF82L)), 0xA94D22DFL))) == 0x84A1E976L), 4294967295UL)) , (*g_555));
            g_1026++;
            if ((*l_951))
                continue;
        }
    }
    for (g_144 = (-15); (g_144 >= 11); g_144 = safe_add_func_uint16_t_u_u(g_144, 3))
    { /* block id: 465 */
        uint64_t * const l_1041 = (void*)0;
        uint64_t * const *l_1040 = &l_1041;
        uint64_t * const **l_1039[1][6][9] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040,&l_1040}}};
        int32_t l_1046 = (-8L);
        int64_t *l_1058 = &g_103;
        int64_t **l_1057[4] = {&l_1058,&l_1058,&l_1058,&l_1058};
        uint32_t *l_1084 = &g_139;
        int32_t l_1087[9][9][1] = {{{0xDC7F9A91L},{0L},{0x58682449L},{0x10461EF6L},{0x133D9136L},{0x899DA8AFL},{0x899DA8AFL},{0x133D9136L},{0x10461EF6L}},{{0x58682449L},{0L},{0xDC7F9A91L},{(-4L)},{0x7EBDCC77L},{0x7D624979L},{(-8L)},{0xEC52874CL},{0x3CE7310CL}},{{0x78CFCC30L},{4L},{(-10L)},{0x0CDA4A9AL},{1L},{0x9D12DD73L},{(-3L)},{0x9D12DD73L},{1L}},{{0x0CDA4A9AL},{(-10L)},{4L},{0x78CFCC30L},{0x3CE7310CL},{0xEC52874CL},{(-8L)},{0x7D624979L},{0x7EBDCC77L}},{{(-4L)},{0xDC7F9A91L},{0L},{0x58682449L},{0x10461EF6L},{0x133D9136L},{0x899DA8AFL},{0x899DA8AFL},{0x133D9136L}},{{0x10461EF6L},{0x58682449L},{0L},{0xDC7F9A91L},{(-4L)},{0x7EBDCC77L},{0x7D624979L},{(-8L)},{0xEC52874CL}},{{0x3CE7310CL},{0x78CFCC30L},{4L},{(-10L)},{0x0CDA4A9AL},{1L},{0x9D12DD73L},{(-3L)},{0x9D12DD73L}},{{1L},{0x0CDA4A9AL},{(-10L)},{4L},{0x78CFCC30L},{0x3CE7310CL},{0xEC52874CL},{(-8L)},{0x7D624979L}},{{0x7EBDCC77L},{(-4L)},{0xDC7F9A91L},{0L},{0x58682449L},{0x10461EF6L},{0x133D9136L},{0x899DA8AFL},{0x899DA8AFL}}};
        uint8_t l_1091 = 0xF9L;
        int16_t l_1140 = 0x6837L;
        uint8_t **l_1169 = &l_760[0];
        int32_t *l_1186 = (void*)0;
        uint32_t l_1187[4];
        int32_t l_1213 = 0xA5FC11A3L;
        int64_t l_1214 = (-1L);
        int32_t **l_1250 = &g_1147[0];
        int32_t * const l_1285 = &l_1268;
        int8_t l_1331 = 2L;
        int8_t l_1348 = 1L;
        uint64_t **l_1349 = &l_1083[7][3][4];
        int64_t l_1350 = 0xCFD6542CDDD1E26ALL;
        uint64_t *l_1352 = (void*)0;
        uint64_t **l_1351 = &l_1352;
        int16_t *l_1353[6][2][3] = {{{(void*)0,(void*)0,(void*)0},{&g_159,&l_1140,&l_793[3]}},{{&g_144,(void*)0,(void*)0},{&g_159,&g_159,(void*)0}},{{(void*)0,&g_144,&g_737},{&l_1140,&g_159,&l_1140}},{{(void*)0,(void*)0,&g_159},{&g_737,&l_1140,&l_1140}},{{&g_159,(void*)0,&g_737},{&l_793[3],&g_737,(void*)0}},{{&g_159,&g_159,(void*)0},{&g_737,&l_793[3],&l_793[3]}}};
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_1187[i] = 0UL;
        if (l_793[3])
            break;
        if ((~((g_722[2][0][0] == ((!(safe_add_func_uint16_t_u_u(0UL, (safe_mod_func_uint32_t_u_u(((l_768[0] = ((((safe_mod_func_uint16_t_u_u(65532UL, ((*p_62) = 1UL))) && 0x0DL) | (((&g_593 != l_1039[0][5][7]) != (safe_mod_func_uint32_t_u_u(((safe_mul_func_int16_t_s_s(0xB946L, l_1046)) == 9L), (*g_83)))) & 0x9AE67702L)) , l_797)) , 0x607B9CADL), (**g_243)))))) || 0x54L)) > 0x146ED61E49636F5ELL)))
        { /* block id: 469 */
            int32_t **l_1048 = &g_166;
            (*g_1047) = &l_1046;
            (*l_1048) = (void*)0;
        }
        else
        { /* block id: 472 */
            int64_t * const *l_1059 = &l_1058;
            int64_t * const **l_1060[10][2][6] = {{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}},{{&l_1059,&l_1059,&l_1059,&l_1059,&l_1059,&l_1059},{(void*)0,&l_1059,(void*)0,&l_1059,(void*)0,&l_1059}}};
            uint32_t *l_1085 = &g_139;
            int32_t *l_1086[7][5][7] = {{{(void*)0,(void*)0,&g_423,&l_768[0],&g_423,&l_885,&g_2},{&g_84,&l_768[0],&g_84,&g_84,&l_768[0],&l_885,&l_768[0]},{&g_2,&l_1046,(void*)0,&l_1046,(void*)0,&l_885,&l_1046},{(void*)0,&g_84,&g_423,&l_768[0],(void*)0,&l_885,&l_885},{&g_423,(void*)0,&l_885,(void*)0,&g_423,&g_84,&g_84}},{{&l_768[0],&g_2,(void*)0,&l_768[0],&l_768[0],&g_423,(void*)0},{&l_768[0],(void*)0,&l_768[0],&g_84,&g_2,&g_423,&l_768[0]},{&l_768[0],&l_768[0],&l_768[0],&l_1046,&g_423,&g_423,&g_2},{&g_423,&g_2,(void*)0,(void*)0,&l_768[0],(void*)0,&l_885},{(void*)0,&g_423,&l_1046,(void*)0,&l_885,&l_1046,&l_1046}},{{&g_2,&l_768[0],&g_423,&l_768[0],&l_768[0],&l_1046,(void*)0},{&g_84,&g_2,&g_423,(void*)0,(void*)0,(void*)0,&l_768[0]},{(void*)0,&g_84,&l_1046,(void*)0,&g_423,(void*)0,&l_768[0]},{(void*)0,(void*)0,(void*)0,&g_2,&l_1046,&g_2,(void*)0},{&l_885,&l_885,&l_768[0],&g_423,&g_84,(void*)0,&g_2}},{{&g_423,&l_768[0],&l_768[0],&g_423,(void*)0,&l_768[0],&g_2},{(void*)0,&l_1046,(void*)0,&l_768[0],&g_84,&l_768[0],&g_423},{&l_768[0],&l_1046,&l_885,&l_1046,&l_1046,&g_2,&l_1046},{&g_84,&l_1046,&g_423,&l_768[0],&g_423,&g_423,&g_2},{&g_84,&l_1046,(void*)0,&l_768[0],(void*)0,&g_423,&l_768[0]}},{{&g_2,&g_84,&l_768[0],&l_885,&g_2,&l_768[0],&l_768[0]},{&l_885,&l_1046,&g_423,(void*)0,&l_768[0],&g_2,&l_768[0]},{&l_768[0],(void*)0,(void*)0,&g_423,&l_768[0],&l_885,&g_2},{&l_768[0],(void*)0,&l_885,&l_885,(void*)0,&l_768[0],&g_423},{&l_768[0],&l_1046,&g_2,&g_84,&l_768[0],&g_84,&g_84}},{{&l_1046,&l_768[0],&l_768[0],&g_84,&g_84,&l_768[0],&l_1046},{&g_423,&l_1046,&l_1046,(void*)0,(void*)0,&l_768[0],&g_423},{(void*)0,(void*)0,&l_1046,&l_1046,(void*)0,&l_1046,&g_2},{(void*)0,(void*)0,&g_2,(void*)0,&g_423,&g_2,&g_423},{&g_2,&l_1046,&l_768[0],&g_2,&g_84,&g_2,&g_423}},{{&l_885,&g_84,&g_84,&g_2,&l_768[0],&g_84,&l_768[0]},{&g_84,&l_1046,&l_885,(void*)0,&g_84,&l_1046,&l_885},{&g_84,&g_2,(void*)0,&l_1046,&l_885,&l_885,&l_1046},{&g_2,(void*)0,&g_2,(void*)0,&g_84,&g_84,&l_768[0]},{&l_768[0],&l_885,&l_885,&g_84,&l_1046,&l_768[0],&g_2}}};
            int16_t *l_1088 = (void*)0;
            int16_t *l_1089[6][1][4] = {{{&g_737,&g_737,&g_144,&l_793[3]}},{{&l_793[3],&g_737,&g_144,&g_737}},{{&g_737,&g_737,&g_737,&g_144}},{{&g_737,&g_737,&g_737,&g_737}},{{&g_737,&g_737,&g_737,&l_793[3]}},{{&g_737,&g_737,&g_737,&g_737}}};
            uint32_t l_1090 = 1UL;
            uint16_t *l_1092 = &g_49;
            int32_t **l_1104[10] = {&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5],&l_1086[1][1][5]};
            uint64_t **l_1138 = &l_1083[4][0][0];
            uint64_t ***l_1137 = &l_1138;
            int64_t **l_1154 = &l_1058;
            uint8_t **l_1171 = &g_1123;
            int i, j, k;
            if (((safe_add_func_int16_t_s_s((l_793[3] >= ((safe_mul_func_uint16_t_u_u(((*l_1092) &= (((((((((g_109[7][4][1] && ((((((*l_1084) = (g_133 &= ((safe_rshift_func_int8_t_s_s(((((l_1057[3] != (g_1061 = l_1059)) , (((safe_mul_func_uint16_t_u_u((--(*p_62)), (((safe_rshift_func_int8_t_s_s(((*g_594) , (safe_lshift_func_uint16_t_u_s(((*g_308) != (l_768[0] = (safe_sub_func_int32_t_s_s(((safe_add_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((((l_1046 = (safe_lshift_func_uint8_t_u_s(((safe_add_func_uint16_t_u_u(l_885, (((((l_1046 > (l_1083[3][1][4] != l_1083[3][1][4])) , l_1084) == l_1085) | l_768[0]) && (-10L)))) && (*g_244)), 0))) >= 4294967295UL) == l_1087[0][8][0]), 0x4033L)) > (*g_308)), g_164)) , l_797), (*g_308))) || 1UL), (**g_246))))), (*g_308)))), 5)) != 0xBDL) <= g_103))) , 18446744073709551615UL) <= l_793[3])) < g_103) ^ l_1087[4][3][0]), 6)) < (-1L)))) | 0x272E329DL) > g_107[6][6][0]) & l_1087[1][7][0]) >= g_2)) & 0x54CCBA8B109634E7LL) & 0UL) <= 4294967291UL) , l_1090) != l_793[3]) , l_1046) ^ l_1091) < 0x50L)), l_793[3])) < l_1087[0][8][0])), l_1087[0][8][0])) && 0xB819L))
            { /* block id: 480 */
                int64_t l_1097 = 0L;
                int32_t * const l_1099 = (void*)0;
                int32_t l_1111 = 1L;
                uint8_t *l_1122 = &g_510;
                int64_t ***l_1182 = &l_1057[0];
                int32_t l_1185[7][10][3] = {{{0x35657616L,(-1L),(-8L)},{5L,5L,0xB28C2D5AL},{(-1L),0x35657616L,(-8L)},{0x450FA199L,0x1CA54E77L,0xB28C2D5AL},{(-1L),(-1L),(-8L)},{0x1CA54E77L,0x450FA199L,0xB28C2D5AL},{0x35657616L,(-1L),(-8L)},{5L,5L,0xB28C2D5AL},{(-1L),0x35657616L,(-8L)},{0x450FA199L,0x1CA54E77L,0xB28C2D5AL}},{{(-1L),(-1L),(-8L)},{0x1CA54E77L,0x450FA199L,0xB28C2D5AL},{0x35657616L,(-1L),(-8L)},{5L,5L,0xB28C2D5AL},{(-1L),0x35657616L,(-8L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L}},{{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L}},{{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L}},{{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L}},{{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L}},{{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L},{1L,1L,(-1L)},{0xB8DD9225L,0x0611BBCCL,5L},{0xF153EBF0L,(-6L),(-1L)},{0xA89E6ACDL,0xA89E6ACDL,5L},{(-6L),0xF153EBF0L,(-1L)},{0x0611BBCCL,0xB8DD9225L,5L}}};
                int i, j, k;
                for (g_510 = 15; (g_510 > 58); ++g_510)
                { /* block id: 483 */
                    int32_t **l_1103 = &l_1086[1][1][5];
                    int8_t l_1105 = 0xD2L;
                    const int32_t *l_1107 = &l_777;
                    const int32_t **l_1106 = &l_1107;
                    int32_t l_1144 = 0x25FF60CDL;
                    int32_t *l_1145 = &g_598[3];
                    for (g_139 = 0; (g_139 <= 5); g_139 += 1)
                    { /* block id: 486 */
                        int32_t * const l_1098 = &l_1046;
                        l_1097 = (safe_lshift_func_uint8_t_u_u(1UL, 7));
                        return l_1099;
                    }
                    (*g_1100) = l_1099;
                    if ((((safe_mod_func_uint32_t_u_u((((((l_1104[1] = l_1103) != (void*)0) , ((l_1105 ^ g_109[7][4][1]) , (((*l_1106) = &g_107[1][2][0]) == &l_777))) && 0x21L) , (safe_mod_func_int64_t_s_s((safe_unary_minus_func_int16_t_s((18446744073709551614UL <= ((((l_1097 >= 0x1312A4CBL) & (*g_578)) | 18446744073709551613UL) < l_797)))), g_154))), 0xC1623A15L)) , 0x2A66DF067FAC8895LL) & l_1087[1][7][0]))
                    { /* block id: 493 */
                        uint8_t l_1112 = 0xB8L;
                        --l_1112;
                        (*l_1103) = (*g_740);
                    }
                    else
                    { /* block id: 496 */
                        uint32_t l_1115[9];
                        int32_t l_1139 = (-5L);
                        int32_t l_1141 = 0xE5BE8CF3L;
                        int32_t *l_1142 = &g_107[3][2][0];
                        int32_t **l_1146 = &l_1142;
                        int i;
                        for (i = 0; i < 9; i++)
                            l_1115[i] = 8UL;
                        l_1115[4] ^= l_756;
                        l_1144 &= (((*l_1058) = ((((safe_mul_func_int16_t_s_s((g_1143[3][1] |= (((((((*l_1142) = (safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((l_1122 == (g_1123 = l_760[1])), (*p_62))), (safe_sub_func_int32_t_s_s((l_768[0] = (l_1141 ^= (l_1140 &= ((g_737 = (((safe_add_func_uint64_t_u_u(18446744073709551615UL, (safe_add_func_uint32_t_u_u(((((l_1115[4] , (l_1139 = (((safe_add_func_uint16_t_u_u((*p_62), (((g_236 , (safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint16_t_u_u((*p_62), 14)), 4))) , l_1136) != l_1137))) > 4294967290UL) > 9UL))) & l_1087[3][1][0]) != g_162) ^ g_423), (**g_246))))) , 0x3AE45C9687479FB8LL) , 0x0CE5L)) & (*g_308))))), (**g_243)))))) , (*g_244)) >= (**g_243)) , (*g_234)) == (void*)0) | 18446744073709551608UL)), l_1115[4])) != g_12) | 18446744073709551615UL) ^ l_1046)) < l_792);
                        l_1139 = (((*l_1146) = l_1145) != (g_1147[0] = &g_598[3]));
                        (*g_578) |= l_1115[4];
                    }
                }
                if ((l_1087[4][8][0] = ((l_768[0] &= (l_1087[4][4][0] != g_737)) == (((safe_mul_func_uint16_t_u_u((((l_885 ^ ((safe_mod_func_int64_t_s_s(l_1091, ((0x3FB4EE40L >= 0UL) || (((void*)0 == l_1154) > (-1L))))) >= l_1140)) != 65535UL) || l_885), l_797)) | (*g_308)) & (*p_62)))))
                { /* block id: 516 */
                    int16_t l_1157 = 0L;
                    int64_t ***l_1181 = (void*)0;
                    const uint32_t l_1183[2][8] = {{4294967295UL,4294967295UL,0UL,4294967295UL,4294967295UL,0UL,4294967295UL,4294967295UL},{4294967286UL,4294967295UL,4294967286UL,4294967286UL,4294967295UL,4294967286UL,4294967286UL,4294967295UL}};
                    int i, j;
                    for (g_84 = 0; (g_84 >= (-19)); g_84 = safe_sub_func_uint8_t_u_u(g_84, 8))
                    { /* block id: 519 */
                        uint64_t l_1158 = 0x933EF9876C35B4C8LL;
                        uint8_t ***l_1170[3][5] = {{&l_1169,&l_1169,&l_1169,&l_1169,&l_1169},{&l_1169,&l_1169,&l_1169,&l_1169,&l_1169},{&l_1169,&l_1169,&l_1169,&l_1169,&l_1169}};
                        const int32_t **l_1179 = (void*)0;
                        const int32_t ***l_1178 = &l_1179;
                        int8_t *l_1184 = &g_915;
                        int i, j;
                        l_1087[0][8][0] ^= 0xE6982A61L;
                        (*g_578) &= (l_885 = (0xD8L || l_1157));
                        --l_1158;
                        l_1185[4][2][0] ^= (safe_mod_func_int8_t_s_s(((*l_1184) |= ((safe_mul_func_int8_t_s_s(((safe_div_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((l_1171 = (g_107[2][6][0] , l_1169)) != l_1169), ((safe_rshift_func_int16_t_s_s((*g_308), 1)) ^ (((((l_793[3] < ((safe_div_func_int64_t_s_s((safe_rshift_func_int16_t_s_s((g_737 |= ((l_1111 = (((((((*l_1178) = (void*)0) != l_1180) , (l_1157 >= ((l_1181 != l_1182) , (**g_593)))) | l_1097) | (*g_308)) & g_722[2][0][0])) | 0xBF2EL)), 1)), l_1183[1][3])) || l_1087[0][8][0])) == g_12) ^ (*g_308)) != g_162) , l_1097)))), l_1091)) != l_1087[0][8][0]), l_1097)) > (*g_308))), l_756));
                    }
                }
                else
                { /* block id: 531 */
                    l_1186 = ((*l_1180) = &l_1185[4][2][0]);
                    l_1187[0]--;
                    for (g_154 = 27; (g_154 > 15); g_154 = safe_sub_func_uint16_t_u_u(g_154, 7))
                    { /* block id: 537 */
                        uint32_t l_1192 = 0xD8FF9B78L;
                        int32_t * const l_1195 = (void*)0;
                        (*l_1180) = (*g_658);
                        l_1192++;
                        return l_1195;
                    }
                }
                if ((safe_lshift_func_int16_t_s_u((g_159 = (safe_lshift_func_int8_t_s_s(g_297, ((safe_sub_func_uint16_t_u_u((*p_62), (*p_62))) >= (0xFF76L & (g_126 > 0x3F91102DL)))))), (*p_62))))
                { /* block id: 544 */
                    uint16_t l_1206 = 65535UL;
                    int64_t *l_1212[8][1] = {{&l_1097},{(void*)0},{&l_1097},{(void*)0},{&l_1097},{(void*)0},{&l_1097},{(void*)0}};
                    int32_t *l_1222[10] = {(void*)0,(void*)0,&l_1185[2][9][2],(void*)0,(void*)0,&l_1185[2][9][2],(void*)0,(void*)0,&l_1185[2][9][2],(void*)0};
                    const int16_t * const l_1228[9][8] = {{(void*)0,&l_793[3],&g_737,&l_793[3],&l_1140,&l_1140,&l_793[3],&g_737},{&l_793[3],&l_793[3],(void*)0,(void*)0,(void*)0,&g_737,&g_144,&l_793[3]},{(void*)0,&g_737,&g_144,&l_793[3],&g_144,&g_737,&g_144,&l_793[3]},{&g_737,(void*)0,&g_737,(void*)0,&g_144,(void*)0,&l_793[3],&g_737},{&l_1140,&l_793[3],(void*)0,&l_793[3],&g_144,&g_144,&g_144,&g_144},{&l_1140,&g_144,&g_144,&l_1140,&g_144,&l_793[3],&l_793[3],(void*)0},{&g_737,(void*)0,&l_793[3],&l_793[3],&g_144,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_793[3],(void*)0,(void*)0,&l_793[3],&l_1140,(void*)0},{&l_793[3],&g_144,(void*)0,&g_737,&l_1140,&g_144,(void*)0,(void*)0}};
                    int i, j;
                    l_1111 ^= (((g_137++) >= (1L || ((((*l_1122) = ((1L < ((((*g_308) , l_1206) != 7L) , (*g_308))) & l_1206)) > g_722[2][0][0]) != ((!((safe_sub_func_uint32_t_u_u((((((((safe_mod_func_uint16_t_u_u(((((**l_1182) != l_1212[2][0]) & 0x80428EF9E6057E83LL) && l_1213), (*g_308))) , 0UL) > l_1214) >= l_1206) >= l_1206) == g_1026) != (*g_308)), l_1206)) == g_159)) != 0xA6L)))) <= g_2);
                    for (g_84 = 0; (g_84 == (-2)); --g_84)
                    { /* block id: 550 */
                        int32_t *l_1217[4];
                        uint32_t ****l_1221 = &l_1220;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_1217[i] = &g_84;
                        l_1217[1] = l_1217[1];
                        l_768[0] |= (safe_mul_func_int16_t_s_s((((((*l_1221) = l_1220) != &g_246) & ((*p_62) = 65535UL)) >= ((void*)0 != (*g_593))), (g_159 = 0x696DL)));
                    }
                    if (l_1206)
                    { /* block id: 557 */
                        const int32_t l_1223 = (-5L);
                        (*l_1180) = l_1222[2];
                        (*l_1180) = (void*)0;
                        (*l_1180) = (void*)0;
                        if (l_1223)
                            continue;
                    }
                    else
                    { /* block id: 562 */
                        int16_t *l_1226[10] = {&l_793[7],&g_144,&g_144,&l_793[7],&g_144,&g_144,&l_793[7],&g_144,&g_144,&l_793[7]};
                        int16_t **l_1227 = &l_1089[3][0][3];
                        const int32_t l_1236 = (-4L);
                        int i;
                        l_885 = (safe_div_func_int32_t_s_s((255UL != ((((((*l_1227) = l_1226[2]) == l_1228[5][3]) | (safe_div_func_int8_t_s_s(0x1DL, l_1111))) > ((l_768[0] ^= (-1L)) ^ ((safe_div_func_int64_t_s_s((safe_sub_func_int64_t_s_s(((**l_1059) ^= ((void*)0 != &g_991)), (!(*g_594)))), l_1236)) & (*p_62)))) | (*p_62))), 8L));
                        l_1111 = 0xC4DD8614L;
                        if (l_1237)
                            break;
                    }
                }
                else
                { /* block id: 570 */
                    for (g_139 = 0; (g_139 <= 3); g_139 += 1)
                    { /* block id: 573 */
                        uint8_t l_1238 = 0x42L;
                        int32_t *l_1241 = &l_768[0];
                        uint64_t l_1242 = 18446744073709551611UL;
                        l_1238--;
                        (*l_1180) = l_1241;
                        l_1242--;
                    }
                }
            }
            else
            { /* block id: 579 */
                uint32_t l_1247 = 0xFF065D93L;
                int32_t ***l_1251 = (void*)0;
                int32_t **l_1252[2];
                int8_t *l_1267 = &g_154;
                uint32_t **l_1269 = &g_244;
                int32_t l_1270 = 1L;
                int i;
                for (i = 0; i < 2; i++)
                    l_1252[i] = &g_1147[2];
                l_1270 &= (safe_div_func_uint16_t_u_u(l_1247, (safe_sub_func_uint8_t_u_u((g_137 | ((l_1250 != (l_1252[0] = &g_1147[4])) || (safe_rshift_func_uint8_t_u_u(((~0xC1L) || g_6), (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((((g_1143[3][1]--) , 65527UL) & (safe_mul_func_int8_t_s_s((0x34A61673L <= (!((((safe_sub_func_int8_t_s_s(((*l_1267) = (((0xEBL & 0L) , 0x1AE70DB2L) , g_49)), 248UL)) & l_1268) , (void*)0) != l_1269))), l_1247))), 10)), 3)) >= 0xC1L) == (-6L)))))), l_792))));
                if ((*g_555))
                    break;
            }
            l_1186 = ((*l_1180) = ((*g_744) , &l_1087[0][8][0]));
            if ((safe_div_func_uint32_t_u_u(0x070BA1CCL, ((**l_1180) ^= (**g_234)))))
            { /* block id: 589 */
                uint32_t l_1277[4][6][7] = {{{0x2EBB2E74L,0xBDA7C5F1L,0x947D3CAEL,0xDEA70745L,0x30EDBA3FL,0UL,0UL},{0x2EBB2E74L,0UL,0x4203B29AL,0UL,0x2EBB2E74L,0UL,0x28A4A0F2L},{0x71329ED4L,0x43CF90B1L,0xEC73C34EL,0UL,0x30EDBA3FL,2UL,5UL},{0x30EDBA3FL,0x43CF90B1L,0x4203B29AL,0xDEA70745L,0xDD016B10L,0x28A4A0F2L,5UL},{0x71329ED4L,0UL,0x947D3CAEL,0x6AE67A82L,0xDD016B10L,2UL,0x28A4A0F2L},{0x2EBB2E74L,0xBDA7C5F1L,0x947D3CAEL,0xDEA70745L,0x30EDBA3FL,0UL,0UL}},{{0x2EBB2E74L,0UL,0x4203B29AL,0UL,0x2EBB2E74L,0UL,0x28A4A0F2L},{0x71329ED4L,0x43CF90B1L,0xEC73C34EL,0UL,0x30EDBA3FL,2UL,5UL},{0x30EDBA3FL,0x43CF90B1L,0x4203B29AL,0xDEA70745L,0xDD016B10L,0x28A4A0F2L,5UL},{0x71329ED4L,0UL,0x947D3CAEL,0x6AE67A82L,0xDD016B10L,2UL,0x28A4A0F2L},{0x2EBB2E74L,0xBDA7C5F1L,0x947D3CAEL,0xDEA70745L,0x30EDBA3FL,0UL,0UL},{0x2EBB2E74L,0UL,0x4203B29AL,0UL,0x2EBB2E74L,0UL,0x28A4A0F2L}},{{0x71329ED4L,0x1850CED3L,6UL,0x7D467C4FL,2UL,0x4203B29AL,0xEA308454L},{2UL,0x1850CED3L,0x670F2ABCL,0x618323E0L,0UL,0xEC73C34EL,0xEA308454L},{0x478BA25CL,0x7D467C4FL,0x9128AA50L,1UL,0UL,0x4203B29AL,0xEC73C34EL},{0x28A4A0F2L,1UL,0x9128AA50L,0x618323E0L,2UL,0x947D3CAEL,0x947D3CAEL},{0x28A4A0F2L,0x7D467C4FL,0x670F2ABCL,0x7D467C4FL,0x28A4A0F2L,0x947D3CAEL,0xEC73C34EL},{0x478BA25CL,0x1850CED3L,6UL,0x7D467C4FL,2UL,0x4203B29AL,0xEA308454L}},{{2UL,0x1850CED3L,0x670F2ABCL,0x618323E0L,0UL,0xEC73C34EL,0xEA308454L},{0x478BA25CL,0x7D467C4FL,0x9128AA50L,1UL,0UL,0x4203B29AL,0xEC73C34EL},{0x28A4A0F2L,1UL,0x9128AA50L,0x618323E0L,2UL,0x947D3CAEL,0x947D3CAEL},{0x28A4A0F2L,0x7D467C4FL,0x670F2ABCL,0x7D467C4FL,0x28A4A0F2L,0x947D3CAEL,0xEC73C34EL},{0x478BA25CL,0x1850CED3L,6UL,0x7D467C4FL,2UL,0x4203B29AL,0xEA308454L},{2UL,0x1850CED3L,0x670F2ABCL,0x618323E0L,0UL,0xEC73C34EL,0xEA308454L}}};
                int32_t * const l_1283[4][8][8] = {{{&l_1087[0][8][0],&l_1213,&l_1087[0][6][0],&l_768[0],&l_1213,(void*)0,&l_768[0],(void*)0},{(void*)0,(void*)0,&l_1046,&l_1087[0][6][0],&l_1087[0][7][0],&l_1087[7][6][0],&l_768[0],(void*)0},{&l_768[0],(void*)0,&l_1087[8][8][0],&l_1213,(void*)0,(void*)0,&l_1213,&l_1087[8][8][0]},{&l_1087[7][6][0],&l_1087[7][6][0],&g_84,&l_885,&l_768[0],(void*)0,&l_1046,&g_84},{&l_885,&l_885,&l_1087[0][8][0],&l_1087[5][5][0],&l_1046,&g_423,(void*)0,&g_84},{&l_885,&l_768[0],(void*)0,&l_885,&l_768[0],&l_885,&g_84,&l_1087[8][8][0]},{&l_1268,(void*)0,&l_885,&l_1213,&g_423,&g_84,&l_885,(void*)0},{(void*)0,&l_1213,&l_1087[3][7][0],&l_1087[0][6][0],&l_768[0],&l_1087[5][5][0],&g_423,(void*)0}},{{&l_768[0],&g_84,&l_885,&l_768[0],(void*)0,&l_768[0],(void*)0,&l_768[0]},{&l_1087[8][4][0],&l_768[0],(void*)0,&g_84,&l_1087[5][5][0],&l_1046,(void*)0,(void*)0},{&l_768[0],&l_885,&l_768[0],&l_768[0],&l_768[0],&l_885,&l_768[0],(void*)0},{&g_84,&l_885,&g_423,&g_84,(void*)0,&l_768[0],&g_84,&g_423},{&l_768[0],&g_84,&l_768[0],&l_1213,(void*)0,&l_1087[8][8][0],&l_885,&l_768[0]},{&g_84,(void*)0,&g_84,&g_423,&l_768[0],&l_768[0],(void*)0,(void*)0},{(void*)0,&l_885,&g_84,&g_423,&l_768[0],&l_768[0],(void*)0,(void*)0},{&g_423,(void*)0,(void*)0,&l_885,(void*)0,&l_768[0],&l_768[0],&l_768[0]}},{{(void*)0,(void*)0,&l_1087[0][8][0],&l_1213,&l_768[0],(void*)0,&l_1213,&g_84},{&l_1213,&l_1046,(void*)0,&g_423,&l_768[0],&g_423,&g_423,&l_768[0]},{(void*)0,&l_1268,&l_1268,(void*)0,&l_1046,(void*)0,(void*)0,&g_423},{&l_885,(void*)0,&l_768[0],(void*)0,(void*)0,&g_423,(void*)0,(void*)0},{&l_1046,(void*)0,&l_768[0],&l_768[0],&l_1087[8][4][0],(void*)0,(void*)0,(void*)0},{&g_84,&l_1268,(void*)0,&l_885,&l_1213,&g_423,&g_84,&l_885},{&l_1087[7][6][0],&l_1046,&l_768[0],&l_1087[5][5][0],&g_423,(void*)0,(void*)0,&l_1087[0][7][0]},{&l_768[0],(void*)0,&l_1087[0][6][0],(void*)0,&l_1087[3][7][0],&l_768[0],&l_885,&g_423}},{{&l_885,(void*)0,(void*)0,(void*)0,&l_1087[0][6][0],&l_768[0],&l_885,&l_1087[0][8][0]},{&l_768[0],&l_885,&l_1087[7][6][0],&l_768[0],(void*)0,&l_768[0],&l_1087[7][6][0],&l_885},{(void*)0,&l_1087[0][8][0],(void*)0,&l_768[0],(void*)0,(void*)0,&l_768[0],&g_423},{&l_1087[5][5][0],(void*)0,&l_768[0],&l_1046,(void*)0,(void*)0,&l_768[0],&l_1087[0][6][0]},{(void*)0,&l_1046,(void*)0,(void*)0,&l_1213,&g_84,&l_1087[7][6][0],&l_768[0]},{&l_1213,&g_84,&l_1087[7][6][0],&l_768[0],(void*)0,&l_885,&l_885,&l_1087[3][7][0]},{&l_768[0],&l_1087[0][8][0],(void*)0,&l_1087[8][4][0],&g_84,(void*)0,&l_885,(void*)0},{&l_768[0],(void*)0,&l_1087[0][6][0],&g_84,&l_1046,&l_768[0],(void*)0,&g_84}}};
                int32_t * const l_1284 = &l_768[0];
                int64_t l_1311 = 0x27619A03F016B768LL;
                int i, j, k;
                for (l_1091 = 0; (l_1091 < 60); l_1091 = safe_add_func_int64_t_s_s(l_1091, 9))
                { /* block id: 592 */
                    int32_t *l_1276[6][3] = {{(void*)0,&g_423,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_423,(void*)0,(void*)0},{(void*)0,&g_423,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_423,(void*)0,(void*)0}};
                    int32_t * const l_1286 = &l_885;
                    const uint32_t l_1310 = 0x3607FCA4L;
                    int i, j;
                }
            }
            else
            { /* block id: 615 */
                uint32_t **l_1315[10] = {&l_1084,&l_1084,&l_1084,&l_1084,&l_1084,&l_1084,&l_1084,&l_1084,&l_1084,&l_1084};
                int32_t l_1320 = 1L;
                int8_t *l_1321[8] = {&g_722[3][3][3],(void*)0,(void*)0,&g_722[3][3][3],(void*)0,(void*)0,&g_722[3][3][3],(void*)0};
                int32_t l_1327 = 0xBB168862L;
                int32_t l_1329[3];
                int i;
                for (i = 0; i < 3; i++)
                    l_1329[i] = 0x12F3203EL;
                if ((**l_1180))
                    break;
                if (((*g_593) != ((**l_1137) = (((+((((**l_1180) > ((safe_div_func_int64_t_s_s((0x52L <= ((l_1315[2] == (((*p_62) = 0xCD45L) , &g_244)) | (l_1320 = ((((**l_1180) , (safe_sub_func_int64_t_s_s((-2L), ((safe_lshift_func_uint8_t_u_u(((l_1320 , 248UL) == l_1320), 6)) ^ (*g_244))))) < (*l_1186)) , g_737)))), g_49)) >= (**l_1180))) , g_722[2][0][0]) , (*l_1285))) == (**l_1180)) , (void*)0))))
                { /* block id: 620 */
                    for (l_885 = 0; (l_885 < 20); l_885 = safe_add_func_uint32_t_u_u(l_885, 7))
                    { /* block id: 623 */
                        (*l_1285) = (safe_mul_func_uint16_t_u_u(((**l_1180) , ((void*)0 != p_62)), (*l_1285)));
                    }
                }
                else
                { /* block id: 626 */
                    int32_t l_1326[4];
                    int8_t l_1328 = 0L;
                    int16_t l_1330 = 1L;
                    int8_t l_1332 = 0L;
                    int i;
                    for (i = 0; i < 4; i++)
                        l_1326[i] = 0x8730C258L;
                    ++l_1333[3][0];
                    if (l_1328)
                        continue;
                }
            }
            return l_1337;
        }
    }
    return g_1354;
}


/* ------------------------------------------ */
/* 
 * reads : g_77 g_594 g_595 g_308 g_144 g_159 g_84 g_722 g_126 g_578 g_423
 * writes: g_144 g_159 g_84 g_423 g_164 g_737
 */
static uint16_t * const  func_64(uint16_t  p_65, const uint64_t  p_66)
{ /* block id: 320 */
    int32_t l_707 = 0x27EA1FCDL;
    uint32_t l_716[6][8] = {{4UL,0x7CE9BBF4L,0UL,0x8AF897C4L,0UL,18446744073709551615UL,0x6A85F7A4L,1UL},{0UL,1UL,1UL,1UL,1UL,0UL,0xC3A0E803L,0x1B8FDEB5L},{1UL,0x8AF897C4L,0UL,0xC3A0E803L,0x5CA1EC71L,0xB5AA43EEL,0x6F391CCCL,18446744073709551615UL},{1UL,0x1B8FDEB5L,0xB5AA43EEL,0xC3A0E803L,0UL,0xC3A0E803L,0xB5AA43EEL,0x1B8FDEB5L},{0x6F391CCCL,0UL,2UL,1UL,18446744073709551615UL,0x7CE9BBF4L,1UL,1UL},{1UL,4UL,0x1B8FDEB5L,2UL,0x6F391CCCL,1UL,1UL,0x6F391CCCL}};
    int32_t **l_719[5][3] = {{(void*)0,&g_166,&g_166},{&g_166,&g_166,&g_166},{(void*)0,(void*)0,&g_166},{&g_166,&g_166,&g_166},{&g_166,(void*)0,&g_166}};
    uint64_t *l_720 = (void*)0;
    uint64_t l_721[7];
    uint32_t l_725 = 4294967294UL;
    uint64_t *l_735 = &g_164;
    int16_t *l_736 = &g_737;
    int32_t *l_738 = &g_423;
    int i, j;
    for (i = 0; i < 7; i++)
        l_721[i] = 0x4BC450637032E9C1LL;
    g_84 ^= ((safe_rshift_func_uint8_t_u_s((0xA8E780E6053818E1LL >= (l_721[5] = (18446744073709551615UL == (&g_555 == (((*g_308) = ((((l_707 , (g_77 > (safe_lshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s((l_707 = (safe_rshift_func_int16_t_s_s(((&g_159 == ((safe_div_func_uint32_t_u_u((((-7L) > (((l_716[4][7] != ((safe_mod_func_uint16_t_u_u(((*g_594) || 1L), p_65)) == p_65)) || 0x14L) == l_716[4][7])) && p_65), l_716[5][2])) , (void*)0)) >= 0x0589D411EE221BCDLL), p_66))), (*g_308))), 10)))) && p_66) , p_65) & p_65)) , l_719[1][2]))))), 3)) < p_66);
lbl_727:
    if (g_159)
        goto lbl_724;
    if (g_722[2][0][0])
    { /* block id: 325 */
lbl_724:
        (*g_578) = (~g_126);
        l_725 = 1L;
    }
    else
    { /* block id: 329 */
        int32_t *l_726 = (void*)0;
        l_726 = l_726;
        if (l_707)
            goto lbl_727;
    }
    (*l_738) |= (safe_mul_func_uint16_t_u_u(p_66, ((safe_add_func_uint16_t_u_u(p_66, ((safe_lshift_func_int16_t_s_s(((*l_736) = ((*g_308) = (!((*l_735) = p_66)))), 13)) < p_66))) || (l_738 == (void*)0))));
    return &g_382[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_84 g_49 g_308 g_144 g_159 g_510 g_83 g_555 g_236 g_246 g_244 g_12 g_126 g_382 g_578 g_297 g_593 g_243 g_423 g_103 g_598 g_109 g_133 g_234 g_235 g_658 g_594 g_595 g_107
 * writes: g_510 g_423 g_107 g_126 g_49 g_103 g_154 g_84 g_144 g_159 g_166 g_133 g_77 g_382
 */
static uint8_t  func_67(uint8_t  p_68, uint8_t  p_69, int8_t  p_70, uint16_t * p_71)
{ /* block id: 265 */
    int32_t *l_549 = &g_84;
    int32_t **l_550 = &l_549;
    const int16_t l_591 = 0x0695L;
    int64_t l_601 = 0xD0A79EC6AE3A0E2BLL;
    int32_t l_607 = (-10L);
    int32_t l_610[8][9][2] = {{{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L}},{{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L}},{{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L}},{{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L}},{{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L}},{{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L}},{{0x8B8F3544L,0x3513BB58L},{6L,6L},{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x8B8F3544L,0x13A566B7L},{0x8B8F3544L,0x3513BB58L},{6L,6L}},{{0x3513BB58L,0x8B8F3544L},{0x13A566B7L,0x8B8F3544L},{0x3513BB58L,6L},{6L,0x3513BB58L},{0x3513BB58L,(-1L)},{0x3513BB58L,0x13A566B7L},{(-1L),(-1L)},{0x13A566B7L,0x3513BB58L},{(-1L),0x3513BB58L}}};
    int32_t l_618 = (-1L);
    uint16_t l_620[6][3][3] = {{{0UL,4UL,65535UL},{8UL,1UL,8UL},{65535UL,4UL,0UL}},{{65535UL,0x82AFL,0UL},{0xAB39L,65535UL,8UL},{65535UL,65535UL,65535UL}},{{0xAB39L,65535UL,65535UL},{65535UL,65535UL,0xAB39L},{65535UL,65535UL,65535UL}},{{8UL,65535UL,0xAB39L},{0UL,0x82AFL,65535UL},{0UL,4UL,65535UL}},{{8UL,1UL,8UL},{65535UL,4UL,0UL},{65535UL,0x82AFL,0UL}},{{0xAB39L,65535UL,8UL},{65535UL,65535UL,65535UL},{0xAB39L,65535UL,65535UL}}};
    uint32_t l_632[6] = {0xE2CF7B02L,0xE2CF7B02L,0xE2CF7B02L,0xE2CF7B02L,0xE2CF7B02L,0xE2CF7B02L};
    uint32_t l_702 = 0x480B6FDCL;
    int32_t l_703[8][5][2] = {{{0L,5L},{1L,1L},{1L,0x9A315014L},{0xCAA24CEFL,0x47204E48L},{0xFBA75351L,0L}},{{(-1L),0xCBA85E7BL},{0L,(-9L)},{1L,(-9L)},{0L,0xCBA85E7BL},{(-1L),0L}},{{0xFBA75351L,0x47204E48L},{0xCAA24CEFL,0x9A315014L},{1L,1L},{1L,5L},{0L,0L}},{{7L,2L},{0L,0x4EA13693L},{1L,0x52A92A88L},{0xECF8D4C4L,1L},{0x998AB758L,0L}},{{0x998AB758L,1L},{0xECF8D4C4L,0x52A92A88L},{1L,0x4EA13693L},{0L,2L},{7L,0L}},{{0L,5L},{1L,1L},{1L,0x9A315014L},{0xCAA24CEFL,0x47204E48L},{0xFBA75351L,0L}},{{(-1L),0xCBA85E7BL},{0L,(-9L)},{1L,(-9L)},{0L,0xCBA85E7BL},{(-1L),0L}},{{0xFBA75351L,0x47204E48L},{0xCAA24CEFL,0x9A315014L},{1L,1L},{1L,5L},{0L,0L}}};
    int i, j, k;
    (*l_550) = l_549;
    if ((safe_mod_func_uint64_t_u_u((*l_549), ((*p_71) || (*g_308)))))
    { /* block id: 267 */
        int32_t l_556 = (-1L);
        const uint16_t l_577 = 65534UL;
        int32_t *l_592 = &g_107[6][1][0];
        int32_t *l_596 = (void*)0;
        int32_t *l_597[9] = {&g_598[2],&g_598[2],&g_598[2],&g_598[2],&g_598[2],&g_598[2],&g_598[2],&g_598[2],&g_598[2]};
        uint8_t *l_599 = (void*)0;
        uint8_t *l_600 = (void*)0;
        int32_t l_602 = 0xAFCB5AB9L;
        int i;
        for (g_510 = 0; (g_510 == 33); g_510 = safe_add_func_uint16_t_u_u(g_510, 1))
        { /* block id: 270 */
            (*l_550) = (*l_550);
            (*l_550) = (void*)0;
            (*g_555) = (*g_83);
        }
        (*g_578) = ((l_556 && ((safe_sub_func_uint32_t_u_u(p_69, ((((safe_mul_func_uint16_t_u_u((safe_div_func_int32_t_s_s((0UL >= (safe_div_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((safe_rshift_func_int16_t_s_u((safe_div_func_int8_t_s_s(p_69, (safe_div_func_uint8_t_u_u(((((safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_s((l_556 & (g_236 || ((void*)0 != &g_234))), ((p_68 > (**g_246)) != p_70))), (-1L))) , p_68) && p_70) , 4UL), g_126)))), (*p_71))), p_68)), l_556))), 9UL)), l_577)) != p_70) != 1UL) == g_382[2]))) || 0L)) ^ (-1L));
        l_602 = ((((0x260C805BL < (safe_mul_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((safe_add_func_int8_t_s_s(g_297, (safe_mod_func_int64_t_s_s(0xCE6029E203B5993BLL, p_68)))), 1)), p_70))) > ((((g_126 &= (((safe_div_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_u(0UL, 1)) > (((l_556 = (((((*l_592) = (l_591 >= ((-10L) <= ((((*g_308) < (*g_308)) , 7UL) && 0x5AL)))) , g_593) != (void*)0) != (-1L))) , l_549) != (*g_243))), g_423)) , &g_137) == &g_137)) > l_601) <= 0x14L) || p_70)) , 0x197BDA7BL) ^ p_70);
    }
    else
    { /* block id: 280 */
        int32_t *l_603 = &g_84;
        int32_t *l_604 = &g_423;
        int32_t *l_605 = &g_423;
        int32_t *l_606 = &g_84;
        int32_t *l_608 = &g_423;
        int32_t *l_609 = &g_423;
        int32_t *l_611 = &g_423;
        int32_t *l_612 = &g_84;
        int32_t *l_613 = &g_423;
        int32_t *l_614 = &g_423;
        int32_t *l_615 = &l_607;
        int32_t *l_616 = (void*)0;
        int32_t *l_617[7][3][9] = {{{&l_610[4][2][0],&g_2,&g_2,&l_610[4][0][0],&g_84,(void*)0,&g_423,&l_610[4][0][0],&l_610[4][0][0]},{&g_2,&g_84,&g_423,&g_84,&l_610[6][8][1],(void*)0,&l_610[4][0][0],&g_2,&l_610[4][0][0]},{&l_607,&g_84,&g_423,&l_607,&g_423,&l_607,&g_423,&g_84,&l_607}},{{&g_84,(void*)0,&l_610[4][0][0],&g_423,&l_610[4][2][0],(void*)0,&g_2,&g_423,&l_607},{(void*)0,&l_610[4][2][0],&l_610[4][0][0],(void*)0,&g_2,&l_610[6][8][1],&l_610[4][0][0],(void*)0,&g_423},{&g_84,(void*)0,&g_2,&l_610[4][0][0],&l_610[4][0][0],&g_2,&g_423,&l_610[4][2][0],&g_2}},{{&g_2,&g_423,&g_423,(void*)0,&l_610[4][0][0],&g_2,(void*)0,&l_610[4][0][0],&l_607},{&g_2,&g_423,&g_2,&g_84,&g_84,&g_423,&g_84,&g_84,&g_2},{(void*)0,(void*)0,(void*)0,&g_2,&l_610[4][0][0],&g_2,(void*)0,&g_423,&l_610[7][2][0]}},{{&l_610[4][0][0],&l_610[4][2][0],&g_423,&g_84,&g_423,(void*)0,(void*)0,&g_423,&l_610[4][0][0]},{(void*)0,&l_610[4][0][0],(void*)0,&l_610[4][0][0],&g_84,&g_84,&g_2,&l_610[6][8][1],&g_423},{&g_423,&l_610[4][0][0],&g_2,&l_607,&g_423,(void*)0,&g_84,&g_423,&l_610[4][0][0]}},{{&l_610[4][0][0],&g_2,&g_423,&l_607,&g_423,&l_610[4][0][0],&l_610[4][0][0],&l_610[4][0][0],&g_423},{&l_610[4][0][0],&g_2,&g_2,&l_610[4][0][0],&l_610[4][0][0],&l_610[4][0][0],&g_423,&l_607,&l_610[4][0][0]},{&l_610[4][0][0],&l_610[4][0][0],&l_610[4][0][0],&g_84,(void*)0,&l_610[1][6][0],&g_2,&g_423,&g_423}},{{&l_610[4][0][0],&g_423,&g_423,&g_2,&l_610[4][0][0],&l_607,&g_2,&l_610[4][0][0],&g_423},{&g_2,(void*)0,&g_2,&g_84,&g_423,&l_610[4][0][0],&g_2,&g_2,(void*)0},{&l_610[1][0][1],(void*)0,(void*)0,(void*)0,&g_423,&l_610[4][0][0],&g_423,&g_2,&g_423}},{{&l_607,&g_84,&l_610[4][0][0],&l_610[4][0][0],&g_84,&l_607,(void*)0,&g_2,&l_610[4][0][0]},{&l_610[4][0][0],&g_423,&g_423,(void*)0,&g_423,&l_610[1][6][0],&l_610[4][0][0],(void*)0,(void*)0},{&l_610[6][8][1],&l_607,&l_610[4][2][0],(void*)0,&l_610[4][0][0],&l_610[4][0][0],(void*)0,&l_607,&l_610[4][0][0]}}};
        int8_t l_619 = 0x1AL;
        uint16_t l_653 = 0xE369L;
        int32_t **l_657 = (void*)0;
        int i, j, k;
        --l_620[3][0][1];
        for (g_49 = (-10); (g_49 < 7); ++g_49)
        { /* block id: 284 */
            uint16_t l_636 = 0x063EL;
            int32_t l_654 = (-1L);
            int32_t l_655[7][3] = {{0L,0L,0L},{(-1L),0x6FECE31EL,(-1L)},{0L,0L,0L},{0xB9019512L,0x6FECE31EL,0xB9019512L},{0L,0L,0L},{(-1L),0x6FECE31EL,(-1L)},{0L,0L,0L}};
            int i, j;
            for (p_69 = (-28); (p_69 != 12); p_69++)
            { /* block id: 287 */
                uint16_t ** const l_635[7][4][4] = {{{(void*)0,&g_539,&g_539,&g_539},{&g_539,&g_539,(void*)0,&g_539},{&g_539,(void*)0,&g_539,&g_539},{(void*)0,&g_539,&g_539,&g_539}},{{(void*)0,&g_539,(void*)0,&g_539},{&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539}},{{&g_539,&g_539,(void*)0,&g_539},{&g_539,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,(void*)0},{&g_539,(void*)0,(void*)0,&g_539}},{{&g_539,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,(void*)0},{&g_539,&g_539,(void*)0,&g_539}},{{(void*)0,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,(void*)0},{&g_539,&g_539,&g_539,&g_539},{(void*)0,&g_539,&g_539,&g_539}},{{&g_539,(void*)0,&g_539,&g_539},{(void*)0,(void*)0,&g_539,(void*)0},{&g_539,&g_539,&g_539,&g_539},{&g_539,(void*)0,&g_539,&g_539}},{{(void*)0,&g_539,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539},{(void*)0,(void*)0,&g_539,&g_539},{&g_539,&g_539,&g_539,&g_539}}};
                int64_t *l_637 = &g_103;
                int32_t l_642 = 0L;
                int8_t *l_643[2][3][4] = {{{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77}},{{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77},{&g_77,&g_77,&g_77,&g_77}}};
                int i, j, k;
                (*l_550) = (void*)0;
                (*l_603) = ((((safe_add_func_int8_t_s_s((g_154 = (safe_div_func_uint8_t_u_u((((((p_70 || ((*l_637) |= ((p_68 || ((~l_632[3]) <= (safe_lshift_func_uint16_t_u_s((l_635[4][1][2] == (void*)0), 13)))) , l_636))) > ((g_598[2] == (*p_71)) & (safe_lshift_func_int16_t_s_u((((safe_add_func_int32_t_s_s((0x5D6939E7L & 1UL), p_68)) == l_642) < l_642), 7)))) && g_109[4][3][0]) < (**g_246)) || p_68), g_12))), g_133)) == l_636) == p_69) ^ g_126);
                return l_636;
            }
            l_655[0][1] ^= ((+((safe_lshift_func_uint8_t_u_u(p_68, (p_68 , 0UL))) <= (-2L))) , ((((*l_613) = p_68) < 0x96C140D1L) || (safe_mul_func_uint8_t_u_u((4294967293UL > (safe_mod_func_uint32_t_u_u(((safe_mod_func_int16_t_s_s(l_653, ((*g_308) = (((l_654 = ((g_382[2] , 0L) & 0xF63FL)) , 0x775A58B1BDCE53FFLL) || (**l_550))))) | (*p_71)), (**g_234)))), 0x71L))));
        }
        (*g_658) = ((*l_550) = l_609);
    }
    for (g_133 = 0; (g_133 != 50); g_133++)
    { /* block id: 304 */
        uint32_t l_663 = 0xE09B9A57L;
        int32_t l_664 = 0xCFF7DF80L;
        uint64_t * const l_665 = (void*)0;
        uint64_t *l_666 = &g_164;
        uint64_t **l_667 = (void*)0;
        uint64_t **l_668 = &l_666;
        int32_t *l_669 = &l_610[4][0][0];
        int64_t *l_672 = &l_601;
        int64_t *l_673 = &g_103;
        uint32_t ** const *l_678[3];
        int8_t *l_696 = &g_77;
        uint8_t *l_697 = (void*)0;
        uint8_t *l_698 = &g_126;
        uint16_t *l_699 = &g_382[4];
        int16_t l_700 = 0x14F9L;
        uint8_t *l_701 = &g_510;
        int i;
        for (i = 0; i < 3; i++)
            l_678[i] = &g_246;
        (*l_669) &= ((l_664 = (l_663 &= (&g_348 == &g_348))) && (l_665 == ((*l_668) = l_666)));
        (*l_669) = ((((*g_594) || (((*l_669) , (0xBD62L ^ (safe_mod_func_int64_t_s_s(((*l_673) = ((*l_672) ^= (*l_669))), ((p_69 & (safe_add_func_int32_t_s_s(((((safe_add_func_int8_t_s_s((((((void*)0 != l_678[2]) | (safe_mul_func_uint8_t_u_u(((*l_701) |= (safe_mod_func_int64_t_s_s((safe_unary_minus_func_int16_t_s(((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(((*l_699) |= (safe_rshift_func_int8_t_s_u((safe_add_func_uint8_t_u_u(((*l_698) = (((*g_555) = (((*p_71) = (p_70 | (safe_lshift_func_int16_t_s_u(((safe_sub_func_uint8_t_u_u((((*l_696) = 6L) == p_69), 0L)) & 1UL), (*p_71))))) < 0x520FL)) < p_68)), 0x15L)), 3))), l_700)), 0x86E46885AED47D26LL)) , 0xF837L))), g_107[2][2][0]))), 0x65L))) && 0xAC8E2D593A734AECLL) | p_70), 0x25L)) == 0L) ^ p_69) >= p_68), (*g_244)))) , 0x73552D7D8E779ABELL))))) , l_702)) , &l_601) == l_673);
    }
    return l_703[7][1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_83 g_137 g_234 g_243 g_154 g_107 g_162 g_159 g_84 g_103 g_144 g_6 g_133 g_297 g_139 g_246 g_244 g_12 g_49 g_126 g_236 g_308 g_348 g_77 g_382 g_423 g_164 g_2 g_510 g_539
 * writes: g_84 g_243 g_246 g_103 g_154 g_139 g_308 g_159 g_126 g_144 g_348 g_77 g_382 g_423 g_133 g_166 g_164 g_510
 */
static uint16_t * func_79(uint32_t  p_80, uint32_t  p_81, uint32_t  p_82)
{ /* block id: 18 */
    int32_t l_93 = 0x4433A031L;
    int32_t *l_105[9][1][6];
    uint64_t *l_169[4][5][3] = {{{&g_164,&g_164,&g_164},{&g_137,&g_137,(void*)0},{&g_164,&g_164,&g_164},{&g_137,&g_164,&g_137},{&g_164,(void*)0,&g_137}},{{&g_164,&g_164,&g_164},{(void*)0,&g_164,(void*)0},{(void*)0,&g_137,&g_164},{&g_164,&g_164,&g_164},{&g_137,&g_164,&g_164}},{{&g_164,(void*)0,&g_164},{(void*)0,&g_164,(void*)0},{&g_137,&g_164,&g_164},{(void*)0,(void*)0,&g_137},{(void*)0,&g_137,&g_137}},{{(void*)0,&g_164,&g_164},{&g_137,&g_137,(void*)0},{(void*)0,&g_164,&g_164},{&g_164,&g_137,&g_164},{&g_137,&g_137,&g_164}}};
    int32_t **l_204 = (void*)0;
    uint32_t ***l_245 = &g_243;
    int8_t l_259 = 0L;
    uint64_t l_260 = 0UL;
    int32_t **l_261 = &l_105[4][0][4];
    int64_t *l_367 = (void*)0;
    int64_t **l_366[4][9][4] = {{{&l_367,&l_367,(void*)0,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,(void*)0,(void*)0,(void*)0},{(void*)0,&l_367,(void*)0,&l_367},{&l_367,(void*)0,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0},{(void*)0,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,(void*)0,(void*)0,&l_367}},{{(void*)0,&l_367,(void*)0,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,(void*)0,&l_367,&l_367},{(void*)0,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0},{&l_367,&l_367,&l_367,&l_367},{(void*)0,(void*)0,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0}},{{&l_367,(void*)0,&l_367,&l_367},{&l_367,(void*)0,(void*)0,(void*)0},{(void*)0,&l_367,(void*)0,&l_367},{&l_367,(void*)0,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0},{(void*)0,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,(void*)0,(void*)0,&l_367},{(void*)0,&l_367,(void*)0,&l_367}},{{&l_367,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,&l_367},{&l_367,(void*)0,&l_367,&l_367},{(void*)0,&l_367,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0},{&l_367,&l_367,&l_367,&l_367},{(void*)0,(void*)0,&l_367,&l_367},{&l_367,&l_367,&l_367,(void*)0},{&l_367,(void*)0,&l_367,&l_367}}};
    int16_t l_379 = 0xCAB0L;
    int32_t * const *l_424 = (void*)0;
    int64_t l_475 = 0x23026E50C411E09DLL;
    uint32_t l_485 = 0xF0C70A02L;
    int8_t l_498 = 7L;
    int32_t l_499 = 0x05787FA0L;
    uint16_t l_531 = 0xAA67L;
    int32_t l_537 = (-6L);
    uint64_t l_538 = 0UL;
    int i, j, k;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 6; k++)
                l_105[i][j][k] = (void*)0;
        }
    }
    (*g_83) = p_82;
lbl_335:
    for (p_80 = 0; (p_80 != 8); p_80 = safe_add_func_int32_t_s_s(p_80, 1))
    { /* block id: 22 */
        int8_t *l_94 = &g_77;
        int64_t *l_101 = (void*)0;
        int64_t *l_102[10] = {&g_103,(void*)0,&g_103,(void*)0,&g_103,(void*)0,&g_103,(void*)0,&g_103,(void*)0};
        uint32_t l_104 = 0UL;
        int32_t l_106 = 9L;
        int32_t l_108 = 0L;
        int32_t *l_167 = &l_106;
        uint64_t **l_229 = &l_169[2][1][0];
        int i;
    }
    if ((((*l_261) = (((safe_mod_func_int32_t_s_s((safe_sub_func_uint32_t_u_u(((g_137 , g_234) == (((safe_add_func_int64_t_s_s(((safe_mod_func_int32_t_s_s((((((*l_245) = g_243) != (g_246 = &g_244)) <= (safe_lshift_func_uint8_t_u_s(((((safe_mod_func_int32_t_s_s(0L, (((safe_sub_func_uint8_t_u_u((g_154 , (((safe_rshift_func_int16_t_s_u(((safe_mul_func_uint16_t_u_u(0xC4D6L, 0xD2A8L)) != ((safe_rshift_func_int8_t_s_u(((p_81 >= g_107[9][4][0]) | p_82), 5)) == p_81)), g_162)) == g_159) , 249UL)), 0xB7L)) || (*g_83)) & 0xBD64L))) & 0x798EL) ^ p_80) && 0L), l_259))) < 0xD03CFEF64EFBD567LL), 0xBB9593E8L)) >= l_260), 0xBB62B9BB11EFF711LL)) | 1L) , (*l_245))), 4294967290UL)), 2UL)) , 0UL) , (void*)0)) != &g_84))
    { /* block id: 105 */
        uint8_t l_262 = 0UL;
        int32_t l_263 = 0x53BC850EL;
        int32_t l_264 = 0xF3BF57D7L;
        int32_t l_265 = 1L;
        uint64_t **l_375[6];
        int32_t *l_476 = &l_264;
        int i;
        for (i = 0; i < 6; i++)
            l_375[i] = &l_169[2][1][2];
        if ((l_262 = p_81))
        { /* block id: 107 */
            int8_t l_266 = 0x9FL;
            uint8_t l_267 = 251UL;
            int64_t *l_277 = &g_103;
            int8_t *l_283 = &l_259;
            int8_t *l_292 = &g_154;
            int32_t l_293 = (-3L);
            int32_t l_294 = 0x26E57CC7L;
            uint32_t *l_298 = &g_139;
            int64_t **l_327 = &l_277;
            l_267++;
            l_294 &= (safe_sub_func_uint8_t_u_u((p_82 & (l_264 = (safe_div_func_uint16_t_u_u((l_265 != (safe_sub_func_int64_t_s_s(((*l_277) ^= (~0x57L)), (~2L)))), (safe_mod_func_uint64_t_u_u(((((*l_283) |= (safe_lshift_func_int8_t_s_u(g_144, 6))) != (safe_rshift_func_uint8_t_u_u(p_81, (safe_lshift_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((l_293 |= ((safe_sub_func_uint8_t_u_u((p_80 & ((g_137 == ((*l_292) |= g_144)) != p_81)), l_264)) && (-1L))), 7)) , 0x4717L) != 0x92CAL), g_6))))) != p_82), g_133)))))), 0xFDL));
            if ((l_294 = (safe_add_func_uint32_t_u_u(l_264, ((*l_298) ^= ((p_80 & g_297) != g_107[3][6][0]))))))
            { /* block id: 117 */
                int8_t l_306 = 0L;
                int16_t l_334 = (-2L);
                for (l_263 = (-25); (l_263 <= 24); ++l_263)
                { /* block id: 120 */
                    uint32_t l_324[3][9] = {{0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L,0x3E762944L}};
                    int32_t *l_326[4][2][7] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,(void*)0,&l_294,(void*)0,&l_294}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,(void*)0,&l_294,(void*)0,&l_294}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,(void*)0,&l_294,(void*)0,&l_294}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_294,(void*)0,&l_294,(void*)0,&l_294,(void*)0,&l_294}}};
                    int i, j, k;
                    for (l_293 = 1; (l_293 <= 9); l_293 += 1)
                    { /* block id: 123 */
                        int16_t *l_307 = &g_159;
                        uint8_t *l_320 = (void*)0;
                        uint8_t *l_321[5][9] = {{&g_126,&g_126,&l_267,&l_267,&g_126,&g_126,&l_262,&l_267,&l_267},{&l_262,&l_262,&g_126,&g_126,&g_126,&g_126,&l_262,&l_262,&g_126},{&l_267,&l_267,&l_262,&l_262,&l_262,&l_262,&l_262,&l_262,&l_267},{&g_126,&l_262,&l_267,&g_126,&l_267,&l_262,&l_262,&l_267,&g_126},{&g_126,&l_262,&g_126,&l_262,&l_262,&l_267,&g_126,&g_126,&l_267}};
                        int16_t *l_322 = &g_144;
                        int32_t l_323 = 1L;
                        int32_t l_325 = (-1L);
                        int i, j;
                        l_325 = ((l_264 = (safe_unary_minus_func_int32_t_s((l_323 &= (((*l_298) = (**g_246)) > (safe_div_func_int64_t_s_s((safe_div_func_int64_t_s_s((l_306 || ((g_308 = l_307) != (void*)0)), (safe_lshift_func_int8_t_s_u(((*l_292) = p_81), ((((*l_307) = (p_80 == g_49)) >= ((safe_sub_func_int16_t_s_s(((*l_322) = (safe_div_func_uint8_t_u_u((g_126 ^= ((+(safe_sub_func_uint8_t_u_u(7UL, (safe_mul_func_uint16_t_u_u(p_80, l_306))))) == 0L)), p_82))), g_49)) < g_103)) <= p_81))))), p_80))))))) > l_324[0][4]);
                        (*l_261) = l_326[1][1][6];
                        g_84 ^= (l_327 == ((safe_add_func_uint32_t_u_u((g_297 < g_137), (((safe_lshift_func_uint8_t_u_s(((safe_div_func_int64_t_s_s((((((l_323 ^ ((0x51L ^ (g_126 = l_306)) == g_49)) ^ (g_162 , l_306)) , 0xA4C5BDC9EAAF24BCLL) < p_80) < l_334), g_137)) ^ g_139), g_107[5][3][0])) > p_82) , (-7L)))) , (void*)0));
                        if (g_103)
                            goto lbl_335;
                    }
                }
            }
            else
            { /* block id: 139 */
                uint32_t l_336 = 0xCA66366EL;
                int32_t l_337[1][4][4] = {{{(-1L),0x3655EE23L,(-1L),0x288803EDL},{(-1L),0x288803EDL,0x288803EDL,(-1L)},{1L,0x288803EDL,(-7L),0x288803EDL},{0x288803EDL,0x3655EE23L,(-7L),(-7L)}}};
                int i, j, k;
                l_337[0][3][2] = (l_336 &= 0x93EADBCFL);
            }
        }
        else
        { /* block id: 143 */
            int32_t l_339[6];
            int i;
            for (i = 0; i < 6; i++)
                l_339[i] = 0x6CE9E952L;
            l_339[3] = ((&g_103 == (void*)0) ^ (+g_236));
        }
        if (((p_82 = p_82) , 0x5A39968EL))
        { /* block id: 147 */
            int8_t l_340 = 0xF3L;
            int32_t l_341 = 0x6915950CL;
            int64_t *l_346[9][8] = {{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103},{&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103,&g_103}};
            int64_t **l_345 = &l_346[0][1];
            int64_t l_352 = 0xCC790F11AC0BC284LL;
            uint16_t l_427 = 1UL;
            uint64_t l_443 = 8UL;
            int8_t l_446 = 0xA5L;
            int i, j;
            if ((*g_83))
            { /* block id: 148 */
                int32_t l_342 = 0L;
                int64_t ***l_347 = &l_345;
                int8_t *l_351 = &g_154;
                uint32_t *l_353 = &g_139;
                int64_t ***l_368 = &l_366[3][8][1];
                l_342 |= (l_341 = l_340);
                l_265 = (((((*g_308) || (((*l_347) = l_345) != (g_348 = g_348))) & (((safe_sub_func_int8_t_s_s(((*l_351) = p_82), (((*l_353)++) >= (l_340 , (((safe_sub_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_s((+((safe_sub_func_uint8_t_u_u(((+(safe_rshift_func_uint8_t_u_s((((*l_368) = l_366[2][2][3]) == (void*)0), (((1L & ((-1L) & 0x7DCDL)) == (*g_308)) && 1L)))) , 0x4FL), 0x53L)) != p_80)), 5)) | p_80), l_342)) > l_341) <= 6UL))))) == p_81) == l_352)) < g_133) > p_82);
            }
            else
            { /* block id: 157 */
                uint64_t **l_374[4][6] = {{&l_169[0][4][0],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_169[0][4][0],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_169[0][4][0],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&l_169[1][1][0],&l_169[0][2][0],(void*)0,&l_169[0][2][0],&l_169[1][1][0]}};
                uint64_t ***l_373 = &l_374[1][3];
                int8_t *l_376 = &g_154;
                int8_t *l_377 = (void*)0;
                int8_t *l_378 = &l_259;
                int32_t l_387 = 0xECFBAD74L;
                int64_t *l_425[3][5] = {{&l_352,&l_352,&l_352,&l_352,&l_352},{&l_352,&l_352,&l_352,&l_352,&l_352},{&l_352,&l_352,&l_352,&l_352,&l_352}};
                int32_t l_453 = 0L;
                int i, j;
                if (((safe_rshift_func_int8_t_s_s((g_382[2] |= (safe_add_func_int8_t_s_s((l_379 = ((*l_378) = ((*l_376) ^= (((*l_373) = (g_84 , (void*)0)) == l_375[3])))), (l_265 = (safe_rshift_func_int8_t_s_u((g_77 ^= 0x69L), 5)))))), (safe_div_func_int64_t_s_s((l_264 || (safe_add_func_int32_t_s_s(l_341, (&g_348 == &g_348)))), ((((*g_308) = (p_82 ^ 0x1541L)) , l_387) || l_341))))) || p_80))
                { /* block id: 166 */
                    int32_t * const l_422[1] = {&g_423};
                    int32_t * const *l_421 = &l_422[0];
                    int32_t * const **l_420[8][1][7] = {{{&l_421,(void*)0,&l_421,&l_421,&l_421,&l_421,&l_421}},{{&l_421,&l_421,&l_421,&l_421,&l_421,&l_421,(void*)0}},{{&l_421,&l_421,(void*)0,&l_421,&l_421,&l_421,&l_421}},{{&l_421,&l_421,&l_421,&l_421,&l_421,&l_421,(void*)0}},{{&l_421,&l_421,&l_421,&l_421,&l_421,&l_421,&l_421}},{{&l_421,&l_421,&l_421,&l_421,&l_421,&l_421,&l_421}},{{&l_421,(void*)0,&l_421,&l_421,&l_421,&l_421,&l_421}},{{&l_421,&l_421,&l_421,&l_421,&l_421,&l_421,&l_421}}};
                    uint8_t *l_426[3][9][7] = {{{&l_262,&g_126,&l_262,&l_262,(void*)0,&g_126,&l_262},{(void*)0,&l_262,&g_126,&l_262,(void*)0,&l_262,&l_262},{&g_126,(void*)0,&g_126,&l_262,(void*)0,&g_126,&g_126},{(void*)0,&l_262,&l_262,&l_262,&g_126,&g_126,(void*)0},{&g_126,(void*)0,&l_262,&l_262,&l_262,(void*)0,&l_262},{&g_126,&l_262,(void*)0,&g_126,&g_126,&l_262,(void*)0},{&l_262,(void*)0,&g_126,&g_126,(void*)0,&l_262,&g_126},{&l_262,&l_262,&l_262,&l_262,&g_126,(void*)0,&l_262},{&g_126,(void*)0,&l_262,&g_126,&g_126,(void*)0,&g_126}},{{&g_126,&g_126,&l_262,&l_262,&l_262,&g_126,&g_126},{(void*)0,&l_262,(void*)0,&l_262,&l_262,&g_126,&l_262},{&g_126,&l_262,(void*)0,&g_126,&l_262,&g_126,&l_262},{(void*)0,&g_126,(void*)0,(void*)0,&g_126,&l_262,&l_262},{&l_262,(void*)0,&l_262,(void*)0,&g_126,&l_262,&l_262},{(void*)0,&g_126,&l_262,&g_126,&l_262,&l_262,(void*)0},{&l_262,(void*)0,&l_262,&l_262,&l_262,(void*)0,&l_262},{&g_126,&g_126,(void*)0,(void*)0,(void*)0,&l_262,(void*)0},{(void*)0,&l_262,&l_262,&l_262,(void*)0,&g_126,&l_262}},{{&l_262,(void*)0,&g_126,&g_126,&g_126,&l_262,&g_126},{(void*)0,(void*)0,(void*)0,(void*)0,&l_262,&l_262,&l_262},{&g_126,(void*)0,&l_262,&g_126,&g_126,(void*)0,(void*)0},{&g_126,(void*)0,&l_262,&g_126,&g_126,&l_262,&l_262},{&l_262,(void*)0,(void*)0,&l_262,&l_262,&g_126,&g_126},{&l_262,&g_126,&l_262,(void*)0,&l_262,&l_262,&l_262},{&l_262,&g_126,&g_126,&l_262,(void*)0,&g_126,(void*)0},{&g_126,&g_126,&l_262,&g_126,(void*)0,(void*)0,&g_126},{&g_126,&g_126,&g_126,&l_262,&g_126,&l_262,&l_262}}};
                    int i, j, k;
                    if (((safe_div_func_int64_t_s_s((1L | (l_427 = ((((~(safe_lshift_func_int16_t_s_s((~(g_139 > ((**l_345) = (safe_lshift_func_int8_t_s_s((0x7335672AL | l_265), 1))))), (safe_lshift_func_int16_t_s_u((((((((((safe_lshift_func_int8_t_s_u((((safe_add_func_int8_t_s_s(p_80, (l_387 = (((((safe_lshift_func_int8_t_s_u((l_262 != (((((safe_div_func_uint32_t_u_u(((safe_div_func_int8_t_s_s((l_263 , (safe_div_func_int32_t_s_s((((safe_div_func_uint16_t_u_u(((((*l_378) |= (&g_166 != (l_424 = ((safe_sub_func_uint16_t_u_u((safe_sub_func_int64_t_s_s((safe_mul_func_int16_t_s_s((*g_308), p_80)), p_81)), (*g_308))) , &g_166)))) == p_82) >= p_80), p_81)) && g_107[8][5][0]) || 5UL), p_80))), 0x25L)) , 0x45939E3DL), p_81)) <= 0x938A7613L) <= 6L) , l_425[2][2]) == l_425[2][4])), 5)) , p_81) == l_341) , (void*)0) == (void*)0)))) < g_137) != 0x687DL), l_264)) > l_265) , l_387) < p_82) == 8L) || p_80) > (-1L)) || p_80) & (**g_246)), 11))))) | p_81) & 0xF12418ACEA6FD6B7LL) && g_126))), (-1L))) ^ (*g_83)))
                    { /* block id: 172 */
                        uint32_t **l_428 = (void*)0;
                        l_428 = &g_244;
                    }
                    else
                    { /* block id: 174 */
                        uint8_t l_429 = 0x4DL;
                        (**l_421) = l_429;
                        (**l_421) |= l_427;
                        l_264 &= l_429;
                        (**l_421) = ((((!p_80) & (((l_429 && (safe_mod_func_uint64_t_u_u(0x01E494C05B71E515LL, g_423))) , 9L) && (safe_rshift_func_int8_t_s_u(p_81, 2)))) ^ (7UL || (safe_rshift_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u((--g_126), 3)), (l_443 <= (safe_lshift_func_uint8_t_u_u((((-10L) && (*g_308)) , 1UL), 1))))), 6)))) != 0x57L);
                    }
                    (**l_421) &= l_446;
                    for (g_133 = 0; (g_133 <= 3); g_133 += 1)
                    { /* block id: 184 */
                        uint16_t l_450 = 65535UL;
                        int64_t ***l_454 = &l_366[2][2][3];
                        l_387 = 0x40813638L;
                        l_453 = (safe_mul_func_uint16_t_u_u(((g_144 >= (safe_unary_minus_func_uint16_t_u((l_450 || 0xAA443E822A53195CLL)))) | ((l_387 = (safe_mul_func_int8_t_s_s(p_81, g_139))) <= 0x6FAAFD4BL)), 0xB518L));
                        (*l_454) = &l_346[6][3];
                    }
                    for (g_144 = (-16); (g_144 >= (-25)); g_144--)
                    { /* block id: 192 */
                        if ((*g_83))
                            break;
                    }
                }
                else
                { /* block id: 195 */
                    int32_t **l_457 = &g_166;
                    (*l_457) = ((*l_261) = (void*)0);
                }
                (*l_261) = &l_453;
                for (g_139 = 0; (g_139 <= 2); g_139 += 1)
                { /* block id: 202 */
                    int32_t **l_458 = &g_166;
                    int32_t l_460[9] = {0x64444413L,0x9509F36BL,0x9509F36BL,0x64444413L,0x9509F36BL,0x9509F36BL,0x64444413L,0x9509F36BL,0x9509F36BL};
                    uint64_t l_461[3][2][4] = {{{0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL}}};
                    uint64_t l_464 = 18446744073709551615UL;
                    int i, j, k;
                    (*l_458) = ((*l_261) = &l_387);
                    for (l_259 = 0; (l_259 <= 3); l_259 += 1)
                    { /* block id: 207 */
                        int i, j;
                        ++l_461[2][0][1];
                        if (g_382[g_139])
                            continue;
                        if (p_81)
                            continue;
                        l_464--;
                    }
                    for (g_164 = 0; (g_164 <= 4); g_164 += 1)
                    { /* block id: 215 */
                        int32_t *l_467 = &l_264;
                        int i, j;
                        (*l_467) = (((*l_458) = (g_382[g_164] , l_467)) == (l_476 = ((safe_mul_func_int8_t_s_s(((((safe_mod_func_uint8_t_u_u(l_443, (safe_lshift_func_uint8_t_u_u(((~((0x85380D960568237DLL || 0xF843F08F745A5F23LL) ^ (((p_80 && (p_82 & (p_80 , 0x1D57L))) >= 0x2FD5L) < l_262))) >= g_133), l_475)))) | p_81) | 18446744073709551606UL) != p_82), 0x6EL)) , (void*)0)));
                        (*l_467) = p_80;
                    }
                }
            }
        }
        else
        { /* block id: 223 */
            const int64_t *l_487 = &l_475;
            const int64_t **l_486 = &l_487;
            int32_t l_488 = (-1L);
            int32_t l_489 = (-2L);
            for (g_84 = 26; (g_84 == (-25)); g_84--)
            { /* block id: 226 */
                uint64_t l_490[9] = {0x555B17CB2DE0D5E9LL,7UL,7UL,0x555B17CB2DE0D5E9LL,7UL,7UL,0x555B17CB2DE0D5E9LL,7UL,7UL};
                int i;
                (*l_476) = (((g_103 = ((void*)0 == g_348)) != p_80) <= ((((*l_476) != (safe_rshift_func_uint16_t_u_u((g_2 , (p_82 <= 0x99B8E3C385C1908DLL)), ((((safe_div_func_int8_t_s_s(((safe_sub_func_int8_t_s_s(((l_485 , g_348) != l_486), l_488)) == (*g_244)), p_80)) == 1UL) , p_81) || g_126)))) , g_12) & (*l_476)));
                l_490[1]--;
            }
        }
    }
    else
    { /* block id: 232 */
        int32_t l_494 = 0x74B48B60L;
        int32_t l_495[7] = {3L,3L,3L,3L,3L,3L,3L};
        int16_t l_497[9];
        uint16_t l_500 = 0x8CA5L;
        int i;
        for (i = 0; i < 9; i++)
            l_497[i] = 6L;
        for (g_103 = 0; (g_103 <= 0); g_103 += 1)
        { /* block id: 235 */
            int32_t l_493[3][6] = {{1L,(-1L),1L,1L,(-1L),1L},{1L,0L,0xB8F5E76FL,1L,0L,1L},{1L,0x19B21BCFL,1L,1L,0x19B21BCFL,0xB8F5E76FL}};
            int32_t l_496 = 0x2D5FE883L;
            int i, j;
            ++l_500;
            for (g_126 = 1; (g_126 <= 9); g_126 += 1)
            { /* block id: 239 */
                int32_t l_525 = (-8L);
                uint16_t *l_530 = &g_382[2];
                int i;
                (*g_83) &= (p_80 && (l_497[8] != g_12));
                for (l_494 = 4; (l_494 >= 0); l_494 -= 1)
                { /* block id: 243 */
                    uint8_t *l_506 = (void*)0;
                    int32_t l_507 = (-8L);
                    int32_t l_508 = 0xCA314888L;
                    uint8_t *l_509 = &g_510;
                    int i, j, k;
                    g_84 |= (((safe_sub_func_uint64_t_u_u(((safe_unary_minus_func_uint8_t_u((++(*l_509)))) | ((p_80 &= ((((safe_lshift_func_uint8_t_u_u((1UL >= (safe_lshift_func_int8_t_s_u(g_107[(l_494 + 1)][(g_103 + 4)][g_103], 7))), (safe_mul_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(((safe_div_func_uint8_t_u_u(((p_82 ^ (&g_235[7] == &g_235[8])) && (((safe_mul_func_uint8_t_u_u(((g_107[(l_494 + 1)][(g_103 + 4)][g_103] | l_525) ^ (safe_mul_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((((p_81 || ((p_82 <= g_2) & p_82)) <= (**g_246)) < 0x63L), p_81)), 0x10L))), g_6)) & g_159) <= g_162)), 9L)) , (-1L)), l_500)) , (*g_308)), 0L)))) , l_525) | l_495[6]) != p_81)) ^ l_525)), l_493[0][2])) != 1UL) <= 0xD2L);
                    return l_530;
                }
            }
        }
        ++l_531;
    }
    for (g_77 = 0; (g_77 >= (-24)); g_77 = safe_sub_func_int32_t_s_s(g_77, 5))
    { /* block id: 255 */
        int32_t *l_536 = (void*)0;
        (*l_261) = l_536;
        l_538 ^= l_537;
    }
    return g_539;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_9[i][j], "g_9[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_107[i][j][k], "g_107[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_109[i][j][k], "g_109[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_144, "g_144", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_236, "g_236", print_hash_value);
    transparent_crc(g_297, "g_297", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_382[i], "g_382[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_423, "g_423", print_hash_value);
    transparent_crc(g_459, "g_459", print_hash_value);
    transparent_crc(g_510, "g_510", print_hash_value);
    transparent_crc(g_595, "g_595", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_598[i], "g_598[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_722[i][j][k], "g_722[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_737, "g_737", print_hash_value);
    transparent_crc(g_915, "g_915", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_976[i][j], "g_976[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_994, "g_994", print_hash_value);
    transparent_crc(g_1026, "g_1026", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1143[i][j], "g_1143[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1358, "g_1358", print_hash_value);
    transparent_crc(g_1360, "g_1360", print_hash_value);
    transparent_crc(g_1363, "g_1363", print_hash_value);
    transparent_crc(g_1425, "g_1425", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1530[i], "g_1530[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1659, "g_1659", print_hash_value);
    transparent_crc(g_1688, "g_1688", print_hash_value);
    transparent_crc(g_1776, "g_1776", print_hash_value);
    transparent_crc(g_1786, "g_1786", print_hash_value);
    transparent_crc(g_1799, "g_1799", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 490
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 59
breakdown:
   depth: 1, occurrence: 309
   depth: 2, occurrence: 78
   depth: 3, occurrence: 11
   depth: 4, occurrence: 7
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 5
   depth: 18, occurrence: 1
   depth: 19, occurrence: 8
   depth: 20, occurrence: 3
   depth: 21, occurrence: 1
   depth: 22, occurrence: 3
   depth: 23, occurrence: 2
   depth: 24, occurrence: 1
   depth: 25, occurrence: 5
   depth: 26, occurrence: 4
   depth: 28, occurrence: 1
   depth: 30, occurrence: 3
   depth: 33, occurrence: 1
   depth: 34, occurrence: 2
   depth: 36, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 40, occurrence: 1
   depth: 41, occurrence: 2
   depth: 48, occurrence: 1
   depth: 54, occurrence: 1
   depth: 59, occurrence: 1

XXX total number of pointers: 387

XXX times a variable address is taken: 1158
XXX times a pointer is dereferenced on RHS: 245
breakdown:
   depth: 1, occurrence: 199
   depth: 2, occurrence: 46
XXX times a pointer is dereferenced on LHS: 236
breakdown:
   depth: 1, occurrence: 225
   depth: 2, occurrence: 11
XXX times a pointer is compared with null: 29
XXX times a pointer is compared with address of another variable: 3
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 6947

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1481
   level: 2, occurrence: 346
   level: 3, occurrence: 10
XXX number of pointers point to pointers: 136
XXX number of pointers point to scalars: 251
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30
XXX average alias set size: 1.48

XXX times a non-volatile is read: 1388
XXX times a non-volatile is write: 758
XXX times a volatile is read: 105
XXX    times read thru a pointer: 37
XXX times a volatile is write: 25
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1.34e+03
XXX percentage of non-volatile access: 94.3

XXX forward jumps: 3
XXX backward jumps: 6

XXX stmts: 306
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 35
   depth: 2, occurrence: 49
   depth: 3, occurrence: 45
   depth: 4, occurrence: 54
   depth: 5, occurrence: 88

XXX percentage a fresh-made variable is used: 15.5
XXX percentage an existing variable is used: 84.5
********************* end of statistics **********************/

