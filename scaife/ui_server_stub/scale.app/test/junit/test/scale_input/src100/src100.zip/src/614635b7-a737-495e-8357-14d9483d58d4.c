/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: dcef523
 * Options:   (none)
 * Seed:      686852145
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S1 {
   const volatile signed f0 : 1;
   volatile signed f1 : 10;
   volatile int32_t  f2;
   signed f3 : 24;
};

/* --- GLOBAL VARIABLES --- */
static const uint32_t g_5 = 0x515FDC8DL;
static int32_t g_7 = 1L;
static int32_t g_9[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static struct S1 g_30 = {-0,-21,0x65BDA124L,-1};/* VOLATILE GLOBAL g_30 */


/* --- FORWARD DECLARATIONS --- */
static struct S1  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_9 g_30
 * writes: g_7 g_9
 */
static struct S1  func_1(void)
{ /* block id: 0 */
    int8_t l_4 = 0xBAL;
    int32_t *l_6 = &g_7;
    int32_t *l_8 = &g_9[1];
    int32_t l_23 = (-1L);
    int32_t l_24[2];
    int64_t l_25 = 1L;
    uint32_t l_27 = 1UL;
    int i;
    for (i = 0; i < 2; i++)
        l_24[i] = 0xB221494FL;
    (*l_8) = ((*l_6) = (safe_sub_func_uint64_t_u_u((l_4 ^ g_5), g_5)));
    for (l_4 = (-22); (l_4 == 3); l_4 = safe_add_func_int16_t_s_s(l_4, 5))
    { /* block id: 5 */
        int32_t *l_12 = &g_9[1];
        int32_t *l_13 = &g_9[1];
        int32_t *l_14 = &g_7;
        int32_t *l_15 = &g_7;
        int32_t *l_16 = &g_7;
        int32_t *l_17 = &g_9[6];
        int32_t *l_18 = &g_9[1];
        int32_t *l_19 = &g_7;
        int32_t *l_20 = &g_9[4];
        int32_t *l_21 = &g_9[1];
        int32_t *l_22[1];
        int16_t l_26 = 0xEB76L;
        int i;
        for (i = 0; i < 1; i++)
            l_22[i] = &g_7;
        (*l_8) ^= g_7;
        (*l_6) &= g_9[3];
        (*l_8) ^= 0L;
        l_27++;
    }
    return g_30;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30.f0, "g_30.f0", print_hash_value);
    transparent_crc(g_30.f1, "g_30.f1", print_hash_value);
    transparent_crc(g_30.f2, "g_30.f2", print_hash_value);
    transparent_crc(g_30.f3, "g_30.f3", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 3
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 2
XXX structs with bitfields in the program: 1
breakdown:
   indirect level: 0, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 1
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 1
   depth: 4, occurrence: 1

XXX total number of pointers: 13

XXX times a variable address is taken: 13
XXX times a pointer is dereferenced on RHS: 0
breakdown:
XXX times a pointer is dereferenced on LHS: 5
breakdown:
   depth: 1, occurrence: 5
XXX times a pointer is compared with null: 0
XXX times a pointer is compared with address of another variable: 0
XXX times a pointer is compared with another pointer: 0
XXX times a pointer is qualified to be dereferenced: 420

XXX max dereference level: 1
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 9
XXX number of pointers point to pointers: 0
XXX number of pointers point to scalars: 13
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 0
XXX average alias set size: 1

XXX times a non-volatile is read: 7
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 9.41
XXX percentage an existing variable is used: 90.6
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
********************* end of statistics **********************/

